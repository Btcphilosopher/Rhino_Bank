package com.example.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountBalances
import com.example.data.model.CashNote
import com.example.data.model.CounterpartyExposure
import com.example.data.model.NovationRecord
import com.example.data.model.PositionRecord
import com.example.data.model.QuantityBasis
import com.example.data.model.SyntheticTranche
import com.example.data.model.TradeRecord
import com.example.data.model.TradeType
import com.example.engine.CheckStatus
import com.example.engine.PreTradeControls
import com.example.engine.PreTradeValidationResult
import com.example.engine.TrancheWorksAdapter
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberPending
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanSynthetic
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldGain
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldContainerBorder
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GraphiteBase
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceRaised
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryPrimary
import com.example.ui.theme.IvorySecondary
import com.example.ui.theme.MonospaceNumberMedium
import com.example.ui.theme.MonospaceNumberSmall
import com.example.ui.theme.RubyContainer
import com.example.ui.theme.RubyLoss

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeTicketWorkspace(
    selectedCashNote: CashNote?,
    selectedSyntheticTranche: SyntheticTranche?,
    accountBalances: AccountBalances,
    positions: List<PositionRecord>,
    dealerExposures: List<CounterpartyExposure>,
    novations: List<NovationRecord>,
    riskOfficerSigned: Boolean,
    onToggleRiskOfficerSignoff: (Boolean) -> Unit,
    onExecuteCashTicket: (CashNote, TradeType, Double, QuantityBasis, Double, String) -> Unit,
    onExecuteSyntheticTicket: (SyntheticTranche, TradeType, Double, String) -> Unit,
    onCreateNovation: (String, String, String) -> Unit,
    onGrantDealerConsent: (String) -> Unit,
    onGrantCalcAgentConsent: (String) -> Unit,
    onFinalizeNovation: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var ticketTypeIndex by remember { mutableStateOf(0) } // 0: Funded Cash Note, 1: Synthetic Protection, 2: Novation Transfer

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteBase)
            .padding(14.dp)
            .testTag("trade_ticket_workspace"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Tab Switcher
        item {
            TabRow(
                selectedTabIndex = ticketTypeIndex,
                containerColor = GraphiteSurface,
                contentColor = IvoryPrimary,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .border(1.dp, GraphiteBorder, RoundedCornerShape(6.dp))
            ) {
                Tab(
                    selected = ticketTypeIndex == 0,
                    onClick = { ticketTypeIndex = 0 },
                    modifier = Modifier.testTag("tab_cash_ticket")
                ) {
                    Text("CASH NOTE TICKET", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (ticketTypeIndex == 0) GoldPrimary else IvoryMuted, modifier = Modifier.padding(vertical = 10.dp))
                }
                Tab(
                    selected = ticketTypeIndex == 1,
                    onClick = { ticketTypeIndex = 1 },
                    modifier = Modifier.testTag("tab_synthetic_ticket")
                ) {
                    Text("SYNTHETIC PROTECTION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (ticketTypeIndex == 1) CyanSynthetic else IvoryMuted, modifier = Modifier.padding(vertical = 10.dp))
                }
                Tab(
                    selected = ticketTypeIndex == 2,
                    onClick = { ticketTypeIndex = 2 },
                    modifier = Modifier.testTag("tab_novation_workflow")
                ) {
                    Text("NOVATION / TRANSFER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (ticketTypeIndex == 2) GoldBright else IvoryMuted, modifier = Modifier.padding(vertical = 10.dp))
                }
            }
        }

        when (ticketTypeIndex) {
            0 -> {
                item {
                    CashNoteTicketForm(
                        note = selectedCashNote,
                        accountBalances = accountBalances,
                        positions = positions,
                        dealerExposures = dealerExposures,
                        riskOfficerSigned = riskOfficerSigned,
                        onToggleRiskOfficerSignoff = onToggleRiskOfficerSignoff,
                        onSubmitTrade = onExecuteCashTicket
                    )
                }
            }
            1 -> {
                item {
                    SyntheticProtectionTicketForm(
                        tranche = selectedSyntheticTranche,
                        accountBalances = accountBalances,
                        dealerExposures = dealerExposures,
                        riskOfficerSigned = riskOfficerSigned,
                        onToggleRiskOfficerSignoff = onToggleRiskOfficerSignoff,
                        onSubmitTrade = onExecuteSyntheticTicket
                    )
                }
            }
            2 -> {
                item {
                    NovationWorkflowPanel(
                        novations = novations,
                        onCreateNovation = onCreateNovation,
                        onGrantDealerConsent = onGrantDealerConsent,
                        onGrantCalcAgentConsent = onGrantCalcAgentConsent,
                        onFinalizeNovation = onFinalizeNovation
                    )
                }
            }
        }
    }
}

@Composable
private fun CashNoteTicketForm(
    note: CashNote?,
    accountBalances: AccountBalances,
    positions: List<PositionRecord>,
    dealerExposures: List<CounterpartyExposure>,
    riskOfficerSigned: Boolean,
    onToggleRiskOfficerSignoff: (Boolean) -> Unit,
    onSubmitTrade: (CashNote, TradeType, Double, QuantityBasis, Double, String) -> Unit
) {
    if (note == null) {
        Box(
            modifier = Modifier.fillMaxWidth().background(GraphiteSurface).padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Please select a Cash Note in the Market Workspace first.", color = IvoryMuted, fontSize = 12.sp)
        }
        return
    }

    var isBuy by remember { mutableStateOf(true) }
    var quantityInput by remember { mutableStateOf("5000000") } // $5M face
    var priceInput by remember { mutableStateOf(String.format("%.2f", note.modelPrice)) }
    var quantityBasis by remember { mutableStateOf(QuantityBasis.ORIGINAL_FACE) }
    var counterparty by remember { mutableStateOf("Goldman Sachs") }

    val enteredQty = quantityInput.toDoubleOrNull() ?: 5_000_000.0
    val priceVal = priceInput.toDoubleOrNull() ?: note.modelPrice
    val factor = note.principalFactor

    // Math: Consideration before accrued = originalFace * factor * price / 100
    val consideration = TrancheWorksAdapter.calculateConsideration(
        enteredFace = enteredQty,
        principalFactor = factor,
        pricePer100 = priceVal,
        basis = quantityBasis
    )
    val (origFace, currFace) = TrancheWorksAdapter.resolveFaces(enteredQty, factor, quantityBasis)
    val accrued = TrancheWorksAdapter.calculateAccruedInterest(currFace, note.couponSpreadBps)
    val fees = 1_500.0
    val totalCashRequired = if (isBuy) consideration + accrued + fees else consideration + accrued - fees

    // Pre-Trade Controls Validation
    val validationResult = remember(note, isBuy, enteredQty, priceVal, quantityBasis, counterparty, riskOfficerSigned, accountBalances) {
        PreTradeControls.validateCashTrade(
            note = note,
            tradeType = if (isBuy) TradeType.CASH_BUY else TradeType.CASH_SELL,
            tradedCurrentFace = currFace,
            totalConsideration = totalCashRequired,
            counterparty = counterparty,
            accountBalances = accountBalances,
            existingPositions = positions,
            existingDealerExposures = dealerExposures,
            userIsQibCertified = true,
            riskOfficerSignedOff = riskOfficerSigned
        )
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, GoldContainerBorder, RoundedCornerShape(8.dp)).testTag("cash_ticket_form")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // Header
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("FUNDED CDO NOTE TRADE TICKET", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldBright, letterSpacing = 0.5.sp)
                    Text("${note.trancheName} (${note.dealId})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = IvoryPrimary)
                    Text("ISIN: ${note.isin} • Principal Factor: ${String.format("%.4f", factor)}", style = MonospaceNumberSmall, color = IvoryDim)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(GoldContainer)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text("SECONDARY", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = GoldBright)
                }
            }

            // Buy / Sell Selector
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isBuy) EmeraldGain else GraphiteBase)
                        .clickable { isBuy = true }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("BUY CASH NOTE", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (isBuy) GraphiteBase else IvorySecondary)
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (!isBuy) RubyLoss else GraphiteBase)
                        .clickable { isBuy = false }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("SELL CASH NOTE", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (!isBuy) GraphiteBase else IvorySecondary)
                }
            }

            // Inputs: Counterparty, Quantity, Price
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = counterparty,
                    onValueChange = { counterparty = it },
                    label = { Text("Counterparty", fontSize = 10.sp, color = IvoryMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = IvoryPrimary, unfocusedTextColor = IvoryPrimary, focusedBorderColor = GoldPrimary, unfocusedBorderColor = GraphiteBorder),
                    modifier = Modifier.weight(1f).testTag("ticket_counterparty_input")
                )
                OutlinedTextField(
                    value = priceInput,
                    onValueChange = { priceInput = it },
                    label = { Text("Price (% Par / 100)", fontSize = 10.sp, color = IvoryMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = IvoryPrimary, unfocusedTextColor = IvoryPrimary, focusedBorderColor = GoldPrimary, unfocusedBorderColor = GraphiteBorder),
                    modifier = Modifier.weight(1f).testTag("ticket_price_input")
                )
            }

            // Quantity & Basis
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = quantityInput,
                    onValueChange = { quantityInput = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Traded Quantity ($)", fontSize = 10.sp, color = IvoryMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = IvoryPrimary, unfocusedTextColor = IvoryPrimary, focusedBorderColor = GoldPrimary, unfocusedBorderColor = GraphiteBorder),
                    modifier = Modifier.weight(1f).testTag("ticket_quantity_input")
                )

                // Basis Toggle
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .background(GraphiteBase)
                        .clip(RoundedCornerShape(4.dp))
                        .border(1.dp, GraphiteBorder, RoundedCornerShape(4.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (quantityBasis == QuantityBasis.ORIGINAL_FACE) GoldContainer else GraphiteBase)
                            .clickable { quantityBasis = QuantityBasis.ORIGINAL_FACE }
                            .padding(vertical = 14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("ORIG FACE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (quantityBasis == QuantityBasis.ORIGINAL_FACE) GoldBright else IvoryMuted)
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (quantityBasis == QuantityBasis.CURRENT_FACE) GoldContainer else GraphiteBase)
                            .clickable { quantityBasis = QuantityBasis.CURRENT_FACE }
                            .padding(vertical = 14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("CURR FACE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (quantityBasis == QuantityBasis.CURRENT_FACE) GoldBright else IvoryMuted)
                    }
                }
            }

            // Consideration Arithmetic Box
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GraphiteBase)
                    .clip(RoundedCornerShape(6.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text("DOCUMENTED CONSIDERATION & SETTLEMENT ARITHMETIC", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = GoldBright)
                Text(
                    text = "Formula: ${if (quantityBasis == QuantityBasis.ORIGINAL_FACE) "Original Face ($${formatNum(origFace)}) × Factor (${factor}) × Price (${priceVal})/100" else "Current Face ($${formatNum(currFace)}) × Price (${priceVal})/100"}",
                    style = MonospaceNumberSmall,
                    fontSize = 10.sp,
                    color = IvoryDim
                )
                Spacer(modifier = Modifier.height(4.dp))
                CalculationRow("Principal Consideration", "$${String.format("%,.2f", consideration)}")
                CalculationRow("Accrued Interest (Actual/360)", "+$${String.format("%,.2f", accrued)}")
                CalculationRow("Clearing / Settlement Fees", "+$${String.format("%,.2f", fees)}")
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(GraphiteBorder))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("TOTAL DVP SETTLEMENT CASH", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = IvoryPrimary)
                    Text("$${String.format("%,.2f", totalCashRequired)}", style = MonospaceNumberMedium, color = GoldBright)
                }
            }

            // Pre-Trade Controls Breakdown
            PreTradeControlsCard(
                validation = validationResult,
                riskOfficerSigned = riskOfficerSigned,
                onToggleRiskOfficerSignoff = onToggleRiskOfficerSignoff
            )

            // Submit Button
            Button(
                onClick = {
                    if (validationResult.canExecute) {
                        onSubmitTrade(
                            note,
                            if (isBuy) TradeType.CASH_BUY else TradeType.CASH_SELL,
                            enteredQty,
                            quantityBasis,
                            priceVal,
                            counterparty
                        )
                    }
                },
                enabled = validationResult.canExecute,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isBuy) EmeraldGain else RubyLoss,
                    contentColor = GraphiteBase,
                    disabledContainerColor = GraphiteSurfaceRaised,
                    disabledContentColor = IvoryDim
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().height(42.dp).testTag("submit_cash_trade_button")
            ) {
                Text(
                    text = if (validationResult.canExecute) "EXECUTE ${if (isBuy) "BUY" else "SELL"} TRADE TICKET" else "PRE-TRADE CONTROLS BLOCKING",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun SyntheticProtectionTicketForm(
    tranche: SyntheticTranche?,
    accountBalances: AccountBalances,
    dealerExposures: List<CounterpartyExposure>,
    riskOfficerSigned: Boolean,
    onToggleRiskOfficerSignoff: (Boolean) -> Unit,
    onSubmitTrade: (SyntheticTranche, TradeType, Double, String) -> Unit
) {
    if (tranche == null) {
        Box(
            modifier = Modifier.fillMaxWidth().background(GraphiteSurface).padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Please select a Synthetic Tranche in the Market Workspace first.", color = IvoryMuted, fontSize = 12.sp)
        }
        return
    }

    var isBuyProtection by remember { mutableStateOf(true) } // Buy Protection (Short Credit) vs Sell Protection (Long Credit)
    var notionalInput by remember { mutableStateOf("15000000") } // $15M
    var counterparty by remember { mutableStateOf("Morgan Stanley") }

    val tradedNotional = notionalInput.toDoubleOrNull() ?: 15_000_000.0
    val runningPremiumQuarterly = TrancheWorksAdapter.calculateQuarterlyPremium(tradedNotional, tranche.runningPremiumBps)
    val upfrontCash = TrancheWorksAdapter.calculateUpfrontCash(tradedNotional, tranche.upfrontPct)
    val maxLossObligation = TrancheWorksAdapter.calculateMaxLossObligation(tranche, tradedNotional)
    val initialMargin = TrancheWorksAdapter.calculateInitialMargin(tradedNotional, tranche.initialMarginPct)

    val validationResult = remember(tranche, isBuyProtection, tradedNotional, counterparty, riskOfficerSigned, accountBalances) {
        PreTradeControls.validateSyntheticTrade(
            tranche = tranche,
            tradeType = if (isBuyProtection) TradeType.SYNTHETIC_BUY_PROTECTION else TradeType.SYNTHETIC_SELL_PROTECTION,
            tradedNotional = tradedNotional,
            counterparty = counterparty,
            accountBalances = accountBalances,
            existingDealerExposures = dealerExposures,
            riskOfficerSignedOff = riskOfficerSigned
        )
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, CyanContainer, RoundedCornerShape(8.dp)).testTag("synthetic_ticket_form")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // Header
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("SYNTHETIC CREDIT TRANCHE TRADE TICKET", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CyanSynthetic, letterSpacing = 0.5.sp)
                    Text(tranche.trancheName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = IvoryPrimary)
                    Text("${tranche.referencePortfolio} • Attachment: ${tranche.attachmentPoint}% – ${tranche.detachmentPoint}%", style = MonospaceNumberSmall, color = IvoryDim)
                }
                Box(
                    modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(CyanContainer).padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text("ISDA DERIVATIVE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = CyanSynthetic)
                }
            }

            // Buy Protection vs Sell Protection Action Buttons
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isBuyProtection) EmeraldGain else GraphiteBase)
                        .clickable { isBuyProtection = true }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("BUY PROTECTION", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (isBuyProtection) GraphiteBase else IvorySecondary)
                        Text("Short Credit Risk", fontSize = 8.sp, color = if (isBuyProtection) GraphiteBase else IvoryDim)
                    }
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (!isBuyProtection) CyanSynthetic else GraphiteBase)
                        .clickable { isBuyProtection = false }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("SELL PROTECTION", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (!isBuyProtection) GraphiteBase else IvorySecondary)
                        Text("Long Credit Risk", fontSize = 8.sp, color = if (!isBuyProtection) GraphiteBase else IvoryDim)
                    }
                }
            }

            // Direction Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isBuyProtection) EmeraldContainer.copy(alpha = 0.3f) else CyanContainer.copy(alpha = 0.3f))
                    .border(0.5.dp, if (isBuyProtection) EmeraldGain else CyanSynthetic, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = if (isBuyProtection)
                        "DIRECTION: SHORT CREDIT EXPOSURE. You pay running premium (${tranche.runningPremiumBps} bps) to dealer and receive payout if reference defaults breach attachment point."
                    else
                        "DIRECTION: LONG CREDIT EXPOSURE. You receive running premium (${tranche.runningPremiumBps} bps) and assume potential loss obligation up to tranche detachment point.",
                    fontSize = 10.sp,
                    color = IvoryPrimary
                )
            }

            // Notional and Dealer
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = notionalInput,
                    onValueChange = { notionalInput = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Reference Notional ($)", fontSize = 10.sp, color = IvoryMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = IvoryPrimary, unfocusedTextColor = IvoryPrimary, focusedBorderColor = CyanSynthetic, unfocusedBorderColor = GraphiteBorder),
                    modifier = Modifier.weight(1f).testTag("syn_notional_input")
                )
                OutlinedTextField(
                    value = counterparty,
                    onValueChange = { counterparty = it },
                    label = { Text("Derivative Dealer (ISDA)", fontSize = 10.sp, color = IvoryMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = IvoryPrimary, unfocusedTextColor = IvoryPrimary, focusedBorderColor = CyanSynthetic, unfocusedBorderColor = GraphiteBorder),
                    modifier = Modifier.weight(1f).testTag("syn_cpty_input")
                )
            }

            // Economics & Exposure Grid
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GraphiteBase)
                    .clip(RoundedCornerShape(6.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text("CONTRACTUAL CASH FLOWS & MARGIN REQUIREMENTS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = CyanSynthetic)
                CalculationRow("Running Spread", "${tranche.runningPremiumBps} bps / yr ($${formatNum(runningPremiumQuarterly)} / quarter)")
                CalculationRow("Upfront Settlement Cash", "$${formatNum(upfrontCash)} (${tranche.upfrontPct}%)")
                CalculationRow("Initial Margin Posting (CSA)", "$${formatNum(initialMargin)} (${tranche.initialMarginPct}%)")
                CalculationRow("Max Potential Loss Obligation", "$${formatNum(maxLossObligation)} (Tranche Width: ${tranche.trancheWidthPct}%)")
            }

            // Pre-Trade Controls Breakdown
            PreTradeControlsCard(
                validation = validationResult,
                riskOfficerSigned = riskOfficerSigned,
                onToggleRiskOfficerSignoff = onToggleRiskOfficerSignoff
            )

            // Submit Button
            Button(
                onClick = {
                    if (validationResult.canExecute) {
                        onSubmitTrade(
                            tranche,
                            if (isBuyProtection) TradeType.SYNTHETIC_BUY_PROTECTION else TradeType.SYNTHETIC_SELL_PROTECTION,
                            tradedNotional,
                            counterparty
                        )
                    }
                },
                enabled = validationResult.canExecute,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isBuyProtection) EmeraldGain else CyanSynthetic,
                    contentColor = GraphiteBase
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().height(42.dp).testTag("submit_synthetic_trade_button")
            ) {
                Text(
                    text = if (validationResult.canExecute) "EXECUTE ${if (isBuyProtection) "BUY PROTECTION" else "SELL PROTECTION"} CONTRACT" else "PRE-TRADE CONTROLS BLOCKING",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun NovationWorkflowPanel(
    novations: List<NovationRecord>,
    onCreateNovation: (String, String, String) -> Unit,
    onGrantDealerConsent: (String) -> Unit,
    onGrantCalcAgentConsent: (String) -> Unit,
    onFinalizeNovation: (String) -> Unit
) {
    var transfereeInput by remember { mutableStateOf("Rhino Apex Credit Fund II") }
    var remainingDealerInput by remember { mutableStateOf("Morgan Stanley Derivative Products") }
    var tradeRefInput by remember { mutableStateOf("TRD-SYN-001") }

    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, GoldContainerBorder, RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("DERIVATIVE POSITION TRANSFER & NOVATION CONSENT WORKFLOW", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldBright, letterSpacing = 0.5.sp)
            Text(
                "An offset trade does NOT remove a derivative contract. Full position legal transfer requires mutual tripartite consent under the ISDA Novation Protocol.",
                fontSize = 10.sp,
                color = IvoryDim
            )

            // Create Novation Request Box
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GraphiteBase)
                    .clip(RoundedCornerShape(6.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("INITIATE NEW NOVATION TRANSFER", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = IvorySecondary)
                OutlinedTextField(
                    value = tradeRefInput,
                    onValueChange = { tradeRefInput = it },
                    label = { Text("Derivative Trade Reference", fontSize = 9.sp, color = IvoryMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = IvoryPrimary, unfocusedTextColor = IvoryPrimary, focusedBorderColor = GoldPrimary, unfocusedBorderColor = GraphiteBorder),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = transfereeInput,
                        onValueChange = { transfereeInput = it },
                        label = { Text("Transferee (New Holder)", fontSize = 9.sp, color = IvoryMuted) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = IvoryPrimary, unfocusedTextColor = IvoryPrimary, focusedBorderColor = GoldPrimary, unfocusedBorderColor = GraphiteBorder),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = remainingDealerInput,
                        onValueChange = { remainingDealerInput = it },
                        label = { Text("Remaining Party (Dealer)", fontSize = 9.sp, color = IvoryMuted) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = IvoryPrimary, unfocusedTextColor = IvoryPrimary, focusedBorderColor = GoldPrimary, unfocusedBorderColor = GraphiteBorder),
                        modifier = Modifier.weight(1f)
                    )
                }

                Button(
                    onClick = { onCreateNovation(tradeRefInput, transfereeInput, remainingDealerInput) },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = GraphiteBase),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth().height(36.dp)
                ) {
                    Text("SUBMIT TRIPARTITE NOVATION REQUEST", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Existing Novations
            Text("PENDING & COMPLETED NOVATION CONTRACTS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = IvoryMuted)

            if (novations.isEmpty()) {
                Text("No novations currently registered.", fontSize = 11.sp, color = IvoryDim)
            } else {
                novations.forEach { nov ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = GraphiteBase),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().border(0.5.dp, GraphiteBorder, RoundedCornerShape(6.dp))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(nov.novationId, style = MonospaceNumberSmall, color = GoldPrimary)
                                Text(nov.status.displayName, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (nov.allContractualConsentsSatisfied) EmeraldGain else AmberPending)
                            }
                            Text("Transferor: ${nov.transferor} → Transferee: ${nov.transferee}", fontSize = 10.sp, color = IvoryPrimary)
                            Text("Remaining Party: ${nov.remainingParty} • Calc Agent: ${nov.calculationAgent}", fontSize = 9.sp, color = IvoryDim)

                            // Consent Checkboxes
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                ConsentIndicator("Remaining Dealer Consent", nov.dealerConsentGranted)
                                ConsentIndicator("Calculation Agent Approval", nov.calculationAgentConsentGranted)
                                ConsentIndicator("ISDA Protocol Signed", nov.isdaConfirmationSigned)
                            }

                            // Interactive Consent Actions
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (!nov.dealerConsentGranted) {
                                    Button(
                                        onClick = { onGrantDealerConsent(nov.novationId) },
                                        colors = ButtonDefaults.buttonColors(containerColor = GraphiteSurfaceRaised, contentColor = GoldBright),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.weight(1f).height(30.dp)
                                    ) {
                                        Text("Grant Dealer Consent", fontSize = 9.sp)
                                    }
                                }
                                if (!nov.calculationAgentConsentGranted) {
                                    Button(
                                        onClick = { onGrantCalcAgentConsent(nov.novationId) },
                                        colors = ButtonDefaults.buttonColors(containerColor = GraphiteSurfaceRaised, contentColor = CyanSynthetic),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.weight(1f).height(30.dp)
                                    ) {
                                        Text("Approve Calc Agent", fontSize = 9.sp)
                                    }
                                }
                                if (nov.allContractualConsentsSatisfied && nov.status.name != "COMPLETED_EFFECTIVE") {
                                    Button(
                                        onClick = { onFinalizeNovation(nov.novationId) },
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGain, contentColor = GraphiteBase),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.weight(1f).height(30.dp)
                                    ) {
                                        Text("Complete Transfer", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PreTradeControlsCard(
    validation: PreTradeValidationResult,
    riskOfficerSigned: Boolean,
    onToggleRiskOfficerSignoff: (Boolean) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteBase),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth().border(0.5.dp, if (validation.canExecute) EmeraldGain.copy(alpha = 0.5f) else AmberPending, RoundedCornerShape(6.dp)).testTag("pre_trade_controls_card")
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("BACKEND PRE-TRADE RISK & COMPLIANCE CONTROLS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = IvoryMuted)
                Text(
                    text = if (validation.canExecute) "ALL CONTROLS PASSED" else "CONDITIONS PENDING",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (validation.canExecute) EmeraldGain else AmberPending
                )
            }

            validation.checks.forEach { check ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = when (check.status) {
                                CheckStatus.PASSED -> Icons.Default.CheckCircle
                                CheckStatus.WARNING -> Icons.Default.Warning
                                CheckStatus.FAILED -> Icons.Default.Lock
                                CheckStatus.REQUIRES_APPROVAL -> Icons.Default.Security
                            },
                            contentDescription = check.status.name,
                            tint = when (check.status) {
                                CheckStatus.PASSED -> EmeraldGain
                                CheckStatus.WARNING -> AmberPending
                                CheckStatus.FAILED -> RubyLoss
                                CheckStatus.REQUIRES_APPROVAL -> GoldBright
                            },
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(check.name, fontSize = 10.sp, color = IvorySecondary)
                    }
                    Text(check.detailValue, fontSize = 9.sp, color = IvoryDim)
                }
            }

            // Risk Officer Sign-off interactive control
            if (validation.requiresRiskOfficerApproval || riskOfficerSigned) {
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(GraphiteBorder))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Risk Officer Sign-Off (Trades > $10M)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldBright)
                        Text("Application compliance authorization sign-off", fontSize = 8.sp, color = IvoryDim)
                    }
                    Switch(
                        checked = riskOfficerSigned,
                        onCheckedChange = onToggleRiskOfficerSignoff,
                        colors = SwitchDefaults.colors(checkedThumbColor = GoldPrimary, checkedTrackColor = GoldContainer),
                        modifier = Modifier.testTag("risk_officer_switch")
                    )
                }
            }
        }
    }
}

@Composable
private fun ConsentIndicator(label: String, isGranted: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = label,
            tint = if (isGranted) EmeraldGain else IvoryDim,
            modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, fontSize = 8.sp, color = if (isGranted) IvorySecondary else IvoryDim)
    }
}

@Composable
private fun CalculationRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 10.sp, color = IvoryMuted)
        Text(value, style = MonospaceNumberSmall, color = IvorySecondary)
    }
}

private fun formatNum(n: Double): String {
    return if (n >= 1_000_000) String.format("%.2fM", n / 1_000_000.0)
    else if (n >= 1_000) String.format("%.1fK", n / 1_000.0)
    else String.format("%.2f", n)
}
