package com.example.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuditEvent
import com.example.data.model.LifecycleEvent
import com.example.data.model.LifecycleEventType
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberPending
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldGain
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldContainerBorder
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GraphiteBase
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceRaised
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryPrimary
import com.example.ui.theme.IvorySecondary
import com.example.ui.theme.MonospaceNumberSmall
import com.example.ui.theme.RubyContainer
import com.example.ui.theme.RubyLoss
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SurveillanceWorkspace(
    lifecycleEvents: List<LifecycleEvent>,
    auditTrail: List<AuditEvent>,
    onApplyDeterioration: (String) -> Unit,
    onApplyWaterfallDistribution: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.US)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteBase)
            .padding(14.dp)
            .testTag("surveillance_workspace"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Lifecycle Controls Hub
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GoldContainerBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("TRANCHEWORKS SURVEILLANCE & LIFECYCLE EVENT CONTROLS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldBright, letterSpacing = 0.5.sp)
                    Text("Execute lifecycle cash-flow distributions or simulate portfolio credit impairment shocks.", fontSize = 10.sp, color = IvoryDim)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { onApplyWaterfallDistribution("RHINO-CLO-2024-1") },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGain, contentColor = GraphiteBase),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f).height(40.dp).testTag("trigger_distribution_button")
                        ) {
                            Icon(Icons.Default.AttachMoney, contentDescription = "Distribute", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("RUN WATERFALL PAYMENT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onApplyDeterioration("RHINO-CLO-2024-1") },
                            colors = ButtonDefaults.buttonColors(containerColor = RubyLoss, contentColor = GraphiteBase),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f).height(40.dp).testTag("trigger_stress_button")
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = "Stress", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("APPLY COLLATERAL SHOCK", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Applied Lifecycle Events
        item {
            Text("LIFECYCLE DISTRIBUTIONS & CREDIT IMPAIRMENT EVENTS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IvoryPrimary)
        }

        if (lifecycleEvents.isEmpty()) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().background(GraphiteSurface).border(1.dp, GraphiteBorder, RoundedCornerShape(8.dp)).padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No lifecycle distributions or credit shocks applied yet. Click 'Run Waterfall Payment' or 'Apply Collateral Shock'.", color = IvoryMuted, fontSize = 11.sp)
                }
            }
        } else {
            items(lifecycleEvents) { evt ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().border(0.5.dp, if (evt.eventType == LifecycleEventType.COLLATERAL_DETERIORATION) RubyLoss.copy(alpha = 0.5f) else EmeraldGain.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(evt.id, style = MonospaceNumberSmall, color = GoldPrimary)
                            Text(timeFormatter.format(Date(evt.timestamp)), fontSize = 9.sp, color = IvoryDim)
                        }
                        Text(evt.title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = IvoryPrimary)
                        Text(evt.details, fontSize = 10.sp, color = IvorySecondary)
                        Text("Financial Impact: ${evt.financialImpact}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (evt.eventType == LifecycleEventType.COLLATERAL_DETERIORATION) RubyLoss else EmeraldGain)
                    }
                }
            }
        }

        // Immutable Audit Trail
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("IMMUTABLE CRYPTOGRAPHIC AUDIT LOG", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IvoryPrimary)
                Text("${auditTrail.size} EVENTS RECORDED", fontSize = 9.sp, color = IvoryDim)
            }
        }

        items(auditTrail.take(15)) { audit ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GraphiteSurface)
                    .border(0.5.dp, GraphiteBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(audit.action, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = GoldBright)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(timeFormatter.format(Date(audit.timestamp)), fontSize = 8.sp, color = IvoryDim)
                    }
                    Text(audit.details, fontSize = 10.sp, color = IvorySecondary)
                    Text("Entity: ${audit.entityId} • Verification: ${audit.verificationHash}", style = MonospaceNumberSmall, fontSize = 8.sp, color = IvoryDim)
                }
            }
        }
    }
}
