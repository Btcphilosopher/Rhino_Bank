/**
 * RHINO FREE BANK SCOTLAND
 * Full-Stack Express Server & Gemini Intelligence Integration
 */

import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// AI Intelligence API Endpoint
app.post('/api/intelligence', async (req: Request, res: Response) => {
  try {
    const { query, financialSnapshot } = req.body;

    if (!query) {
      return res.status(400).json({ error: 'Query parameter is required' });
    }

    const systemInstruction = `
You are RHINO EDINBURGH INTELLIGENCE, the institutional financial intelligence system of Rhino Free Bank Scotland (founded in Edinburgh).
You provide rigorous, quantitative, and explainable analysis grounded strictly in the provided structured application state.

Guidelines:
1. Grounding: Answer ONLY based on the provided financial state snapshot (Balance Sheet, CET1, NIM, Private Notes, PoS Validator Network, Scottish Economy, FX, and Portfolios).
2. Structure: Return your response strictly as JSON with this schema:
   {
     "answer": "Clear, precise financial explanation in Scottish institutional tone (restrained, rigorous, direct)",
     "citations": [
       {"source": "Balance Sheet | Private Notes | PoS Validator | Scottish Economy", "metric": "Metric Name", "value": "Metric Value", "timestamp": "Snapshot time"}
     ],
     "calculationBreakdown": "Step-by-step mathematical derivation if applicable",
     "underlyingAssumptions": ["List of core assumptions or regulatory constraints"],
     "modelConfidenceScore": 98
   }
3. Never invent financial data not present in the snapshot.
4. If asked about regulatory status, mention the synthetic institutional simulation boundary.
`;

    const prompt = `
CURRENT FINANCIAL SNAPSHOT:
${JSON.stringify(financialSnapshot, null, 2)}

USER QUERY:
${query}

Provide a structured, institutional answer with exact metrics and citations.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        temperature: 0.2,
      },
    });

    const text = response.text || '{}';
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = {
        answer: text,
        citations: [],
        underlyingAssumptions: ['Standard institutional baseline'],
        modelConfidenceScore: 90,
      };
    }

    return res.json({
      query,
      ...parsed,
      evaluatedTimestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    });
  } catch (error: any) {
    console.error('Intelligence Engine Error:', error);
    return res.status(500).json({
      error: 'Failed to process intelligence request',
      details: error.message,
    });
  }
});

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'OPERATIONAL',
    institution: 'Rhino Free Bank Scotland PLC',
    headquarters: 'St Andrew Square, Edinburgh EH2 2BD',
    consensusNetwork: 'Rhino Sterling PoS Validation Grid',
    timestamp: new Date().toISOString(),
  });
});

// Mount Vite in development mode
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static dist in production
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`[RHINO BANK] Institutional Server active on http://0.0.0.0:${PORT}`);
  });
}

startServer();
