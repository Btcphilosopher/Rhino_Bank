/**
 * RHINO FREE BANK SCOTLAND
 * Rhino Commercial & Corporate Treasury Operations
 */

import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';

export const CorporateTreasury: React.FC = () => {
  const { fxRates, processTransfer } = useBank();

  const [selectedPair, setSelectedPair] = useState(fxRates[0]);
  const [fxTradeAmount, setFxTradeAmount] = useState('100000');
  const [fxTradeSide, setFxTradeSide] = useState<'BUY' | 'SELL'>('BUY');
  const [fxConfirmation, setFxConfirmation] = useState('');

  const handleExecuteFx = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(fxTradeAmount);
    if (isNaN(amt) || amt <= 0) return;

    const rate = fxTradeSide === 'BUY' ? selectedPair.offer : selectedPair.bid;
    const counterAmt = amt * rate;

    await processTransfer({
      fromAccountId: 'acc-retail-curr',
      toAccountName: `FX Liquidity Desk (${selectedPair.pair})`,
      toAccountDetails: 'TREASURY-FX-CLEAR',
      amount: amt,
      currency: 'GBP',
      paymentType: 'FX_CONVERSION',
      category: 'TREASURY',
    });

    setFxConfirmation(`Executed Spot FX: ${fxTradeSide} ${selectedPair.baseCurrency} ${amt.toLocaleString()} @ ${rate.toFixed(4)} → ${selectedPair.quoteCurrency} ${counterAmt.toLocaleString('en-GB', { minimumFractionDigits: 2 })}.`);
    setTimeout(() => setFxConfirmation(''), 5000);
  };

  return (
    <div className="space-y-6">
      
      {/* Corporate Treasury Master Strip */}
      <div className="stone-panel p-6 rounded-sm border border-[#252E3D]">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-[#C68B45] uppercase tracking-wider mb-1">
              RHINO COMMERCIAL · EDINBURGH CORPORATE TREASURY DESK
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F4F1EA] tracking-tight">
              Corporate Cash & Working Capital
            </h1>
            <p className="text-xs text-[#9DAEC2] mt-1">
              Liquidity Management, Debt Maturity Ladders, Invoice Financing & Multi-Currency FX
            </p>
          </div>

          <div className="text-left md:text-right">
            <div className="text-xs text-[#8B9BB4]">Corporate Operating Balance</div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-[#F4F1EA] tabular-nums tracking-tight">
              £14,850,200.00
            </div>
            <div className="text-[11px] text-[#22C55E] font-mono mt-0.5">
              £25M Committed Revolving Credit Facility Active
            </div>
          </div>
        </div>

        {/* Treasury Metrics Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-5 mt-5 border-t border-[#1F2735] text-xs font-mono">
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">30-DAY CASH FORECAST</span>
            <span className="text-[#22C55E] font-bold text-sm">+£2.45M Net Inflow</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">WORKING CAPITAL RATIO</span>
            <span className="text-[#F4F1EA] font-bold text-sm">1.84x (Healthy)</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">TOTAL DEBT OUTSTANDING</span>
            <span className="text-[#F4F1EA] font-bold text-sm">£8.50M (Senior Note)</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">FX EXPOSURE HEDGED</span>
            <span className="text-[#C68B45] font-bold text-sm">88.5% (EUR & USD)</span>
          </div>
        </div>
      </div>

      {fxConfirmation && (
        <div className="p-3 bg-[#13231B] border border-emerald-800/60 text-emerald-300 text-xs font-mono rounded-sm">
          {fxConfirmation}
        </div>
      )}

      {/* Main Grid: Corporate Debt Maturity Ladder & Spot/Forward FX Desk */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Debt Maturity Ladder & Cashflow Forecast */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Debt Maturity Ladder */}
          <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
              <div>
                <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
                  Corporate Debt & Funding Maturity Ladder
                </h2>
                <span className="text-[11px] font-mono text-[#8B9BB4]">
                  Scheduled refinancing & principal redemption schedule
                </span>
              </div>
              <span className="text-xs font-mono text-[#C68B45]">
                Weighted Avg Maturity: 4.2y
              </span>
            </div>

            <div className="space-y-3 font-mono text-xs">
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#F4F1EA]">Q4 2026: Working Capital Revolver</span>
                  <span className="text-[#8B9BB4]">£2,000,000 (Base + 1.25%)</span>
                </div>
                <div className="w-full h-2 bg-[#141A24] rounded-xs overflow-hidden">
                  <div className="h-full bg-[#C68B45]" style={{ width: '25%' }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#F4F1EA]">Q2 2028: Speyside Malt Inventory Note</span>
                  <span className="text-[#8B9BB4]">£3,500,000 (5.80% Fixed)</span>
                </div>
                <div className="w-full h-2 bg-[#141A24] rounded-xs overflow-hidden">
                  <div className="h-full bg-[#22C55E]" style={{ width: '45%' }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#F4F1EA]">Q1 2031: Edinburgh Infrastructure Secured Note</span>
                  <span className="text-[#8B9BB4]">£10,000,000 (5.25% Fixed)</span>
                </div>
                <div className="w-full h-2 bg-[#141A24] rounded-xs overflow-hidden">
                  <div className="h-full bg-[#3B82F6]" style={{ width: '80%' }}></div>
                </div>
              </div>
            </div>
          </div>

          {/* 8 Currency FX Rate Board */}
          <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
              <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
                Rhino FX Institutional Currency Grid
              </h2>
              <span className="text-xs font-mono text-[#8B9BB4]">
                8 Live Currency Pairs
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-[#1F2735] text-[#5A697E] text-[10px] uppercase">
                    <th className="pb-2 font-medium">Currency Pair</th>
                    <th className="pb-2 font-medium">Spot Rate</th>
                    <th className="pb-2 font-medium">Bid</th>
                    <th className="pb-2 font-medium">Offer</th>
                    <th className="pb-2 font-medium">1M Forward</th>
                    <th className="pb-2 font-medium">3M Forward</th>
                    <th className="pb-2 font-medium text-right">Day Change</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1F2735]">
                  {fxRates.map(fx => (
                    <tr
                      key={fx.pair}
                      onClick={() => setSelectedPair(fx)}
                      className={`cursor-pointer transition-colors ${selectedPair.pair === fx.pair ? 'bg-[#1D2533]' : 'hover:bg-[#141B26]'}`}
                    >
                      <td className="py-2.5 font-bold text-[#F4F1EA]">{fx.pair}</td>
                      <td className="py-2.5 text-[#C68B45] font-semibold">{fx.spotRate.toFixed(4)}</td>
                      <td className="py-2.5 text-[#E6EDF3]">{fx.bid.toFixed(4)}</td>
                      <td className="py-2.5 text-[#E6EDF3]">{fx.offer.toFixed(4)}</td>
                      <td className="py-2.5 text-[#8B9BB4]">{fx.forward1Month.toFixed(4)}</td>
                      <td className="py-2.5 text-[#8B9BB4]">{fx.forward3Month.toFixed(4)}</td>
                      <td className={`py-2.5 text-right font-semibold ${fx.dayChangePct >= 0 ? 'text-[#22C55E]' : 'text-[#EF4444]'}`}>
                        {fx.dayChangePct >= 0 ? '+' : ''}{fx.dayChangePct.toFixed(2)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* Right Col: Instant FX Execution Desk */}
        <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
            <h3 className="text-base font-serif font-bold text-[#F4F1EA]">
              Institutional FX Desk
            </h3>
            <span className="text-xs font-mono text-[#C68B45]">
              {selectedPair.pair}
            </span>
          </div>

          <form onSubmit={handleExecuteFx} className="space-y-4 font-mono text-xs">
            <div>
              <label className="text-[#8B9BB4] block mb-1">Currency Pair</label>
              <select
                value={selectedPair.pair}
                onChange={(e) => {
                  const found = fxRates.find(f => f.pair === e.target.value);
                  if (found) setSelectedPair(found);
                }}
                className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
              >
                {fxRates.map(f => (
                  <option key={f.pair} value={f.pair}>{f.pair} — Spot {f.spotRate.toFixed(4)}</option>
                ))}
              </select>
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setFxTradeSide('BUY')}
                className={`flex-1 py-2 rounded-sm font-semibold transition-colors ${
                  fxTradeSide === 'BUY'
                    ? 'bg-[#22C55E] text-[#0F141C]'
                    : 'bg-[#121721] text-[#8B9BB4] border border-[#1F2735]'
                }`}
              >
                BUY {selectedPair.baseCurrency} @ {selectedPair.offer.toFixed(4)}
              </button>
              <button
                type="button"
                onClick={() => setFxTradeSide('SELL')}
                className={`flex-1 py-2 rounded-sm font-semibold transition-colors ${
                  fxTradeSide === 'SELL'
                    ? 'bg-[#EF4444] text-[#F4F1EA]'
                    : 'bg-[#121721] text-[#8B9BB4] border border-[#1F2735]'
                }`}
              >
                SELL {selectedPair.baseCurrency} @ {selectedPair.bid.toFixed(4)}
              </button>
            </div>

            <div>
              <label className="text-[#8B9BB4] block mb-1">Notional Amount ({selectedPair.baseCurrency})</label>
              <input
                type="number"
                step="10000"
                min="1000"
                required
                value={fxTradeAmount}
                onChange={(e) => setFxTradeAmount(e.target.value)}
                className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA] text-base font-bold"
              />
            </div>

            <div className="bg-[#121721] p-3 rounded-sm border border-[#1F2735] text-[11px] text-[#8B9BB4] space-y-1">
              <div className="flex justify-between">
                <span>Indicative Settlement Value:</span>
                <span className="text-[#F4F1EA] font-semibold">
                  {selectedPair.quoteCurrency} {((parseFloat(fxTradeAmount) || 0) * (fxTradeSide === 'BUY' ? selectedPair.offer : selectedPair.bid)).toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Spread:</span>
                <span className="text-[#22C55E]">{selectedPair.spreadPips} pips (Institutional)</span>
              </div>
              <div className="flex justify-between">
                <span>30-Day Implied Volatility:</span>
                <span className="text-[#C68B45]">{selectedPair.impliedVol30DPct}%</span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-[#C68B45] hover:bg-[#D89B55] text-[#0F141C] font-semibold rounded-sm transition-colors text-xs"
            >
              Execute Spot Settlement
            </button>
          </form>
        </div>

      </div>

    </div>
  );
};
