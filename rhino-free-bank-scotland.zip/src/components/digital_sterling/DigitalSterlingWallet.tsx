/**
 * RHINO FREE BANK SCOTLAND
 * Rhino Sterling Digital (RSD) Multi-Money Wallet & Interoperability Layer
 */

import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';

export const DigitalSterlingWallet: React.FC = () => {
  const {
    accounts,
    transactions,
    posNetwork,
    convertMoney,
    processTransfer
  } = useBank();

  const rsdAccount = accounts.find(a => a.type === 'RSD_WALLET') || accounts[1];
  const gbpCurrentAccount = accounts.find(a => a.type === 'CURRENT') || accounts[0];

  const [convertAmount, setConvertAmount] = useState('');
  const [convertDirection, setConvertDirection] = useState<'GBP_TO_RSD' | 'RSD_TO_GBP'>('GBP_TO_RSD');
  const [recipientAlias, setRecipientAlias] = useState('');
  const [rsdSendAmount, setRsdSendAmount] = useState('');
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [nfcSimulating, setNfcSimulating] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');

  const handleConvert = async (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(convertAmount);
    if (isNaN(amountNum) || amountNum <= 0) return;

    if (convertDirection === 'GBP_TO_RSD') {
      if (gbpCurrentAccount.balance < amountNum) {
        setStatusMsg('Insufficient Bank Deposit balance');
        return;
      }
      await convertMoney({
        fromType: 'GBP_DEPOSIT',
        toType: 'RSD_DIGITAL',
        amount: amountNum,
      });
      setStatusMsg(`Successfully converted £${amountNum.toLocaleString()} GBP to RSD Digital Sterling (1:1 par)`);
    } else {
      if (rsdAccount.balance < amountNum) {
        setStatusMsg('Insufficient RSD balance');
        return;
      }
      await convertMoney({
        fromType: 'RSD_DIGITAL',
        toType: 'GBP_DEPOSIT',
        amount: amountNum,
      });
      setStatusMsg(`Successfully redeemed RSD ${amountNum.toLocaleString()} to Bank Deposit (1:1 par)`);
    }
    setConvertAmount('');
  };

  const handleSendRSD = async (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(rsdSendAmount);
    if (isNaN(amountNum) || amountNum <= 0) return;

    await processTransfer({
      fromAccountId: rsdAccount.id,
      toAccountName: recipientAlias || 'Strathclyde Research Lab',
      toAccountDetails: 'RSD-GLA-99201',
      amount: amountNum,
      currency: 'RSD',
      paymentType: 'RSD_TRANSFER',
      category: 'COMMERCE',
    });
    setRsdSendAmount('');
    setRecipientAlias('');
    setStatusMsg(`Sent RSD ${amountNum.toLocaleString()} with sub-second finality at Block #${posNetwork.blockHeight}`);
  };

  const handleSimulateNFC = () => {
    setNfcSimulating(true);
    setTimeout(async () => {
      await processTransfer({
        fromAccountId: rsdAccount.id,
        toAccountName: 'Edinburgh Waverley Transit Terminal',
        toAccountDetails: 'RSD-ED-TRANSIT',
        amount: 3.80,
        currency: 'RSD',
        paymentType: 'RSD_TRANSFER',
        category: 'COMMERCE',
      });
      setNfcSimulating(false);
      setStatusMsg('NFC Contactless Tap: Settled RSD 3.80 at Waverley Transit Terminal.');
    }, 1200);
  };

  const rsdTransactions = transactions.filter(t => t.currency === 'RSD' || t.type === 'RSD_TRANSFER');

  return (
    <div className="space-y-6">
      
      {/* RSD Header & Multi-Money Architecture Overview */}
      <div className="stone-panel p-6 rounded-sm border border-[#252E3D]">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-[#C68B45] uppercase tracking-wider mb-1">
              DIGITAL STERLING INTERFACE · RSD LEDGER LAYER
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F4F1EA] tracking-tight">
              Rhino Sterling Digital (RSD)
            </h1>
            <p className="text-xs text-[#9DAEC2] mt-1">
              Synthetic Sovereign-Grade Digital Money · Validated by 9-Node Proof-of-Stake Grid
            </p>
          </div>

          <div className="text-left md:text-right">
            <div className="text-xs text-[#8B9BB4]">Digital Sterling Balance</div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-[#C68B45] tabular-nums tracking-tight">
              RSD {rsdAccount.balance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-[#8B9BB4] font-mono mt-0.5">
              1 RSD = £1.00 GBP (Audited 100% Reserve Parity)
            </div>
          </div>
        </div>

        {/* Multi-Money Interoperability Visual Banner */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-5 mt-5 border-t border-[#1F2735] text-xs font-mono">
          <div className="bg-[#121721] p-3 rounded-sm border border-[#1F2735]">
            <span className="text-[#5A697E] block text-[10px]">LAYER 1: BANK DEPOSITS</span>
            <span className="text-[#F4F1EA] font-semibold">£{gbpCurrentAccount.balance.toLocaleString()} GBP</span>
            <span className="text-[10px] text-[#8B9BB4] block mt-1">Direct Commercial Bank Money</span>
          </div>

          <div className="bg-[#121721] p-3 rounded-sm border border-[#C68B45]/30">
            <span className="text-[#C68B45] block text-[10px]">LAYER 2: RHINO STERLING DIGITAL</span>
            <span className="text-[#C68B45] font-semibold">RSD {rsdAccount.balance.toLocaleString()}</span>
            <span className="text-[10px] text-[#8B9BB4] block mt-1">Sub-second Atomic PoS Settlement</span>
          </div>

          <div className="bg-[#121721] p-3 rounded-sm border border-[#1F2735]">
            <span className="text-[#5A697E] block text-[10px]">LAYER 3: PRIVATE NOTES</span>
            <span className="text-[#F4F1EA] font-semibold">£450,000,000 Issued</span>
            <span className="text-[10px] text-[#8B9BB4] block mt-1">Negotiable Monetary Collateral</span>
          </div>
        </div>
      </div>

      {statusMsg && (
        <div className="p-3 bg-[#13231B] border border-emerald-800/60 text-emerald-300 text-xs font-mono rounded-sm">
          {statusMsg}
        </div>
      )}

      {/* Main Grid: Conversion Workbench & Transfer + QR / NFC */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Money Conversion Layer (Par Exchange Engine) */}
        <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
            <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
              Multi-Money Conversion Desk
            </h2>
            <span className="text-xs font-mono text-[#22C55E]">
              1:1 Par Exchange · Zero Slippage
            </span>
          </div>

          <form onSubmit={handleConvert} className="space-y-4 font-mono text-xs">
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setConvertDirection('GBP_TO_RSD')}
                className={`flex-1 py-2 rounded-sm border transition-colors ${
                  convertDirection === 'GBP_TO_RSD'
                    ? 'bg-[#C68B45] text-[#0F141C] font-semibold border-[#C68B45]'
                    : 'bg-[#121721] text-[#8B9BB4] border-[#1F2735] hover:text-[#F4F1EA]'
                }`}
              >
                Deposit £ → Mint RSD
              </button>
              <button
                type="button"
                onClick={() => setConvertDirection('RSD_TO_GBP')}
                className={`flex-1 py-2 rounded-sm border transition-colors ${
                  convertDirection === 'RSD_TO_GBP'
                    ? 'bg-[#C68B45] text-[#0F141C] font-semibold border-[#C68B45]'
                    : 'bg-[#121721] text-[#8B9BB4] border-[#1F2735] hover:text-[#F4F1EA]'
                }`}
              >
                Redeem RSD → Bank £
              </button>
            </div>

            <div>
              <div className="flex justify-between text-[#8B9BB4] mb-1">
                <span>Conversion Amount</span>
                <span>
                  Source Available: {convertDirection === 'GBP_TO_RSD' ? `£${gbpCurrentAccount.balance.toLocaleString()}` : `RSD ${rsdAccount.balance.toLocaleString()}`}
                </span>
              </div>
              <input
                type="number"
                step="1"
                min="1"
                placeholder="1000.00"
                value={convertAmount}
                onChange={(e) => setConvertAmount(e.target.value)}
                className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2.5 text-[#F4F1EA] text-lg font-bold"
              />
            </div>

            <div className="bg-[#121721] p-3 rounded-sm border border-[#1F2735] text-[11px] text-[#8B9BB4] space-y-1">
              <div className="flex justify-between">
                <span>Settlement Protocol:</span>
                <span className="text-[#F4F1EA]">Rhino PoS Ledger Internal Clearing</span>
              </div>
              <div className="flex justify-between">
                <span>Finality Latency:</span>
                <span className="text-[#22C55E]">~0.85s (Immediate)</span>
              </div>
              <div className="flex justify-between">
                <span>Reserve Backing:</span>
                <span className="text-[#F4F1EA]">100% Cash at Bank of England</span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-[#1D2533] hover:bg-[#283446] border border-[#C68B45]/40 text-[#F4F1EA] font-semibold rounded-sm transition-colors text-xs"
            >
              Execute 1:1 Atomic Par Conversion
            </button>
          </form>
        </div>

        {/* Instant RSD Transfer & Contactless/QR Simulation */}
        <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
            <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
              RSD Instant Pay & Merchant Acceptance
            </h2>
            <span className="text-xs font-mono text-[#C68B45]">
              Sub-second Settlement
            </span>
          </div>

          <form onSubmit={handleSendRSD} className="space-y-3 font-mono text-xs">
            <div>
              <label className="text-[#8B9BB4] block mb-1">Payee RSD Wallet Alias / QR ID</label>
              <input
                type="text"
                placeholder="e.g. RSD-GLA-99201 or Merchant ID"
                value={recipientAlias}
                onChange={(e) => setRecipientAlias(e.target.value)}
                className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
              />
            </div>

            <div>
              <label className="text-[#8B9BB4] block mb-1">Amount (RSD)</label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                placeholder="250.00"
                value={rsdSendAmount}
                onChange={(e) => setRsdSendAmount(e.target.value)}
                className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA] text-base font-bold"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-[#C68B45] hover:bg-[#D89B55] text-[#0F141C] font-semibold rounded-sm transition-colors text-xs"
            >
              Send Digital Sterling Instant Transfer
            </button>
          </form>

          {/* Quick Simulated Merchant Interactions */}
          <div className="pt-3 border-t border-[#1F2735] grid grid-cols-2 gap-2 font-mono text-xs">
            <button
              onClick={() => setQrModalOpen(true)}
              className="p-2.5 bg-[#121721] hover:bg-[#1A222E] border border-[#1F2735] text-[#F4F1EA] rounded-sm transition-colors text-center"
            >
              Generate QR Payment Link
            </button>
            <button
              onClick={handleSimulateNFC}
              disabled={nfcSimulating}
              className="p-2.5 bg-[#121721] hover:bg-[#1A222E] border border-[#1F2735] text-[#F4F1EA] rounded-sm transition-colors text-center"
            >
              {nfcSimulating ? 'Processing Tap...' : 'Simulate NFC Tap (£3.80)'}
            </button>
          </div>
        </div>

      </div>

      {/* RSD Transaction History & PoS Block Hash Verification */}
      <div className="stone-panel p-5 rounded-sm border border-[#252E3D]">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
            RSD Ledger Transactions & PoS Finality Log
          </h2>
          <span className="text-xs font-mono text-[#8B9BB4]">
            Consensus Quorum 9/9 Active
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#1F2735] text-[#5A697E] text-[10px] uppercase">
                <th className="pb-2 font-medium">Timestamp</th>
                <th className="pb-2 font-medium">Transaction ID</th>
                <th className="pb-2 font-medium">From / To</th>
                <th className="pb-2 font-medium">PoS Block</th>
                <th className="pb-2 font-medium">Risk Check</th>
                <th className="pb-2 font-medium text-right">Amount (RSD)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F2735]">
              {rsdTransactions.map(tx => (
                <tr key={tx.id} className="hover:bg-[#141B26] transition-colors">
                  <td className="py-2.5 text-[#8B9BB4]">{tx.timestamp.substring(11)}</td>
                  <td className="py-2.5 text-[#C68B45]">{tx.id}</td>
                  <td className="py-2.5 text-[#E6EDF3] font-sans">
                    {tx.payerName} → {tx.payeeName}
                  </td>
                  <td className="py-2.5 text-[#9DAEC2]">#{tx.validatorBlockHeight}</td>
                  <td className="py-2.5 text-[#22C55E]">{tx.complianceCheck}</td>
                  <td className="py-2.5 text-right font-bold text-[#C68B45] tabular-nums">
                    RSD {tx.amount.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* QR Code Modal Simulation */}
      {qrModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#0A0D14]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="stone-panel p-6 rounded-sm border border-[#252E3D] max-w-sm w-full space-y-4 text-center shadow-2xl">
            <h3 className="text-base font-serif font-bold text-[#F4F1EA]">
              Rhino RSD Dynamic QR
            </h3>
            <div className="w-48 h-48 mx-auto bg-white p-3 rounded-sm flex items-center justify-center border-4 border-[#C68B45]">
              <div className="w-full h-full border-2 border-black grid grid-cols-6 grid-rows-6 gap-0.5 bg-black p-1">
                {Array.from({ length: 36 }).map((_, i) => (
                  <div
                    key={i}
                    className={`rounded-xs ${i % 2 === 0 || i % 7 === 0 ? 'bg-white' : 'bg-black'}`}
                  ></div>
                ))}
              </div>
            </div>
            <div className="font-mono text-xs text-[#8B9BB4]">
              <span>Alias: </span>
              <span className="text-[#F4F1EA] font-semibold">{rsdAccount.accountNumber}</span>
            </div>
            <button
              onClick={() => setQrModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold bg-[#1D2533] hover:bg-[#283446] text-[#F4F1EA] rounded-sm"
            >
              Close QR Code
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
