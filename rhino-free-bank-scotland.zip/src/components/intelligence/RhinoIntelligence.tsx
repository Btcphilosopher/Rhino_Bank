/**
 * RHINO FREE BANK SCOTLAND
 * Rhino Edinburgh Intelligence — Structured Grounded AI Financial Assistant
 */

import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import { AIIntelligenceResponse } from '../../types/financial';

export const RhinoIntelligence: React.FC = () => {
  const { queryIntelligence } = useBank();

  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeResponse, setActiveResponse] = useState<AIIntelligenceResponse | null>(null);

  const sampleQueries = [
    'What is our current liquidity and LCR position?',
    'What happens to our Net Interest Margin if the Bank Rate rises 100bp?',
    'Show me the structural details of RHINO EDINBURGH NOTE 01.',
    'What is our PoS validator consensus health and active node distribution?',
    'Which Scottish regions have the fastest credit expansion rate?',
  ];

  const handleRunQuery = async (queryText: string) => {
    if (!queryText.trim()) return;
    setLoading(true);
    try {
      const res = await queryIntelligence(queryText);
      setActiveResponse(res);
    } catch {
      // Handled in context
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Intelligence Header */}
      <div className="stone-panel p-6 rounded-sm border border-[#252E3D]">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-[#C68B45] uppercase tracking-wider mb-1">
              RHINO EDINBURGH INTELLIGENCE · GROUNDED FINANCIAL REASONING ENGINE
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F4F1EA] tracking-tight">
              Institutional Intelligence Assistant
            </h1>
            <p className="text-xs text-[#9DAEC2] mt-1">
              Deterministic Grounding · Explicit Citations, Calculation Proofs & Assumption Auditing
            </p>
          </div>

          <div className="text-left md:text-right">
            <div className="text-xs text-[#8B9BB4]">Inference Engine</div>
            <div className="text-sm font-mono font-bold text-[#C68B45]">
              Gemini 3.8 Flash (Server-Side Proxy)
            </div>
            <div className="text-[11px] text-[#22C55E] font-mono mt-0.5">
              Zero-Hallucination Structured Data Enforced
            </div>
          </div>
        </div>

        {/* Query Input Box */}
        <div className="pt-5 mt-5 border-t border-[#1F2735] space-y-3">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleRunQuery(inputQuery);
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              placeholder="Ask structured financial intelligence (e.g. 'What is our CET1 ratio under rate stress?')..."
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              className="flex-1 bg-[#121721] border border-[#252E3D] rounded-sm p-3 text-xs font-mono text-[#F4F1EA] focus:outline-none focus:border-[#C68B45]"
            />
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-3 bg-[#C68B45] hover:bg-[#D89B55] text-[#0F141C] font-semibold text-xs font-mono rounded-sm transition-colors shrink-0"
            >
              {loading ? 'Evaluating Model...' : 'Execute Analysis'}
            </button>
          </form>

          {/* Quick Preset Prompts */}
          <div className="flex flex-wrap gap-2">
            {sampleQueries.map((q, i) => (
              <button
                key={i}
                onClick={() => {
                  setInputQuery(q);
                  handleRunQuery(q);
                }}
                className="px-2.5 py-1 text-[11px] font-mono bg-[#141A24] hover:bg-[#1D2533] border border-[#222B38] text-[#8B9BB4] hover:text-[#F4F1EA] rounded-xs transition-colors text-left"
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Structured AI Analysis Output */}
      {activeResponse && (
        <div className="stone-panel p-6 rounded-sm border border-[#C68B45]/50 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#1F2735] gap-2">
            <div>
              <span className="text-[10px] font-mono text-[#C68B45] uppercase tracking-wider block">
                AUDITED INTELLIGENCE RESPONSE
              </span>
              <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
                {activeResponse.query}
              </h2>
            </div>
            <div className="text-xs font-mono text-right">
              <span className="text-[#8B9BB4]">Confidence: </span>
              <span className="text-[#22C55E] font-bold">{activeResponse.modelConfidenceScore}%</span>
              <span className="text-[#5A697E]"> · {activeResponse.evaluatedTimestamp}</span>
            </div>
          </div>

          {/* Primary Answer Paragraph */}
          <div className="p-4 bg-[#121721] rounded-sm border border-[#1F2735] text-[#E6EDF3] text-sm leading-relaxed font-sans">
            {activeResponse.answer}
          </div>

          {/* Calculation Breakdown (if present) */}
          {activeResponse.calculationBreakdown && (
            <div className="space-y-2 font-mono text-xs">
              <span className="text-[#C68B45] font-bold block uppercase text-[10px]">
                MATHEMATICAL / FORMULA DERIVATION PROOF
              </span>
              <div className="p-3 bg-[#0D121A] border border-[#1F2735] text-[#D8D1C5] rounded-sm">
                {activeResponse.calculationBreakdown}
              </div>
            </div>
          )}

          {/* Citations Grid */}
          {activeResponse.citations && activeResponse.citations.length > 0 && (
            <div className="space-y-2 font-mono text-xs">
              <span className="text-[#8B9BB4] font-bold block uppercase text-[10px]">
                GROUNDED SOURCE CITATIONS & TELEMETRY TIMESTAMP
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                {activeResponse.citations.map((c, idx) => (
                  <div key={idx} className="bg-[#121721] p-2.5 rounded-sm border border-[#1F2735] space-y-0.5">
                    <span className="text-[#5A697E] text-[10px] block">{c.source}</span>
                    <span className="text-[#F4F1EA] font-semibold block">{c.metric}: {c.value}</span>
                    <span className="text-[#8B9BB4] text-[10px] block">{c.timestamp}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Underlying Assumptions */}
          {activeResponse.underlyingAssumptions && activeResponse.underlyingAssumptions.length > 0 && (
            <div className="pt-3 border-t border-[#1F2735] font-mono text-xs space-y-1">
              <span className="text-[#5A697E] block text-[10px] uppercase">
                UNDERLYING MODEL ASSUMPTIONS & BOUNDARIES:
              </span>
              <ul className="list-disc list-inside text-[#8B9BB4] text-[11px] space-y-0.5">
                {activeResponse.underlyingAssumptions.map((ass, i) => (
                  <li key={i}>{ass}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

    </div>
  );
};
