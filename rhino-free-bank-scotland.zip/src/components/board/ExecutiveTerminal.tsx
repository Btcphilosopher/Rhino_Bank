/**
 * RHINO FREE BANK SCOTLAND
 * Executive Board Terminal & Institutional Drill-Down Cockpit
 */

import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import hqImage from '../../assets/images/rhino_edinburgh_hq_1790502589843.jpg';

export const ExecutiveTerminal: React.FC = () => {
  const {
    balanceSheet,
    posNetwork,
    macro,
    privateNotes,
    transactions,
    journalEntries,
  } = useBank();

  const [drillLevel, setDrillLevel] = useState<'BANK' | 'DIVISION' | 'PRODUCT' | 'TRANSACTION'>('BANK');
  const [selectedDivision, setSelectedDivision] = useState<'RETAIL' | 'COMMERCIAL' | 'PRIVATE_NOTE_HOUSE' | 'TREASURY'>('TREASURY');

  return (
    <div className="space-y-6">
      
      {/* Board Executive Header */}
      <div className="stone-panel p-6 rounded-sm border border-[#252E3D]">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-[#C68B45] uppercase tracking-wider mb-1">
              RHINO FREE BANK SCOTLAND · BOARD OF DIRECTORS EXECUTIVE COCKPIT
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F4F1EA] tracking-tight">
              Executive Management Terminal
            </h1>
            <p className="text-xs text-[#9DAEC2] mt-1">
              St Andrew Square Headquarters · Institutional Governance & Granular Drill-Down
            </p>
          </div>

          <div className="text-left md:text-right">
            <div className="text-xs text-[#8B9BB4]">Institutional Return on Equity</div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-[#22C55E] tabular-nums tracking-tight">
              {balanceSheet.metrics.returnOnEquityPct}% ROE
            </div>
            <div className="text-[11px] text-[#8B9BB4] font-mono mt-0.5">
              Cost/Income Ratio: {balanceSheet.metrics.costToIncomeRatioPct}% · NIM {balanceSheet.metrics.netInterestMarginPct}%
            </div>
          </div>
        </div>

        {/* Drill-down Navigation */}
        <div className="flex gap-2 pt-5 mt-5 border-t border-[#1F2735] font-mono text-xs">
          <span className="text-[#8B9BB4] py-1.5 self-center">Drill Level:</span>
          <button
            onClick={() => setDrillLevel('BANK')}
            className={`px-3 py-1.5 rounded-sm transition-colors ${
              drillLevel === 'BANK'
                ? 'bg-[#C68B45] text-[#0F141C] font-semibold'
                : 'bg-[#121721] text-[#8B9BB4] hover:text-[#F4F1EA]'
            }`}
          >
            Level 1: Whole Bank Macro
          </button>
          <button
            onClick={() => setDrillLevel('DIVISION')}
            className={`px-3 py-1.5 rounded-sm transition-colors ${
              drillLevel === 'DIVISION'
                ? 'bg-[#C68B45] text-[#0F141C] font-semibold'
                : 'bg-[#121721] text-[#8B9BB4] hover:text-[#F4F1EA]'
            }`}
          >
            Level 2: Operating Divisions
          </button>
          <button
            onClick={() => setDrillLevel('PRODUCT')}
            className={`px-3 py-1.5 rounded-sm transition-colors ${
              drillLevel === 'PRODUCT'
                ? 'bg-[#C68B45] text-[#0F141C] font-semibold'
                : 'bg-[#121721] text-[#8B9BB4] hover:text-[#F4F1EA]'
            }`}
          >
            Level 3: Product & Note Pools
          </button>
          <button
            onClick={() => setDrillLevel('TRANSACTION')}
            className={`px-3 py-1.5 rounded-sm transition-colors ${
              drillLevel === 'TRANSACTION'
                ? 'bg-[#C68B45] text-[#0F141C] font-semibold'
                : 'bg-[#121721] text-[#8B9BB4] hover:text-[#F4F1EA]'
            }`}
          >
            Level 4: General Ledger Journals
          </button>
        </div>
      </div>

      {/* LEVEL 1: WHOLE BANK VIEW */}
      {drillLevel === 'BANK' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs">
            <div className="stone-panel p-4 rounded-sm border border-[#252E3D]">
              <span className="text-[#5A697E] block text-[10px]">TOTAL ASSETS</span>
              <span className="text-xl font-bold text-[#F4F1EA] block mt-1">£{(balanceSheet.assets.totalAssets / 1000000000).toFixed(3)}B</span>
              <span className="text-[#22C55E] text-[10px]">+5.4% YoY</span>
            </div>
            <div className="stone-panel p-4 rounded-sm border border-[#252E3D]">
              <span className="text-[#5A697E] block text-[10px]">TOTAL DEPOSITS</span>
              <span className="text-xl font-bold text-[#F4F1EA] block mt-1">£{((balanceSheet.liabilities.retailDeposits + balanceSheet.liabilities.commercialDeposits) / 1000000000).toFixed(3)}B</span>
              <span className="text-[#8B9BB4] text-[10px]">Retail & Commercial</span>
            </div>
            <div className="stone-panel p-4 rounded-sm border border-[#252E3D]">
              <span className="text-[#5A697E] block text-[10px]">CET1 PRUDENTIAL CAPITAL</span>
              <span className="text-xl font-bold text-[#22C55E] block mt-1">{balanceSheet.metrics.cet1RatioSimulatedPct}%</span>
              <span className="text-[#8B9BB4] text-[10px]">Min Requirement 10.5%</span>
            </div>
            <div className="stone-panel p-4 rounded-sm border border-[#252E3D]">
              <span className="text-[#5A697E] block text-[10px]">LIQUIDITY COVERAGE (LCR)</span>
              <span className="text-xl font-bold text-[#C68B45] block mt-1">{balanceSheet.metrics.liquidityCoverageRatioPct}%</span>
              <span className="text-[#8B9BB4] text-[10px]">Min Requirement 100%</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
              <h3 className="text-base font-serif font-bold text-[#F4F1EA]">
                St Andrew Square Headquarters Operations
              </h3>
              <div className="relative overflow-hidden rounded-sm border border-[#C68B45]/30">
                <img
                  src={hqImage}
                  alt="Rhino Bank Edinburgh St Andrew Square Headquarters"
                  referrerPolicy="no-referrer"
                  className="w-full h-56 object-cover brightness-95"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A0D14]/90 via-transparent to-transparent p-4 flex flex-col justify-end">
                  <span className="font-serif font-bold text-base text-[#F4F1EA]">
                    Rhino Free Bank Scotland PLC — Executive Council
                  </span>
                  <span className="font-mono text-xs text-[#C68B45]">
                    Founded on Edinburgh Enlightenment Principles · Re-engineered for 2030
                  </span>
                </div>
              </div>
            </div>

            <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-3 font-mono text-xs">
              <h3 className="text-sm font-serif font-bold text-[#F4F1EA]">
                Consensus & Macro Highlights
              </h3>
              <div className="space-y-2 divide-y divide-[#1F2735]">
                <div className="flex justify-between py-1.5">
                  <span className="text-[#8B9BB4]">Bank of England Rate:</span>
                  <span className="text-[#F4F1EA] font-semibold">{macro.bankRatePct}%</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-[#8B9BB4]">PoS Block Height:</span>
                  <span className="text-[#C68B45] font-bold">#{posNetwork.blockHeight}</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-[#8B9BB4]">Active Nodes:</span>
                  <span className="text-[#22C55E]">{posNetwork.activeValidatorsCount} / 9 Active</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-[#8B9BB4]">Private Notes Issued:</span>
                  <span className="text-[#F4F1EA]">{privateNotes.length} Series (£450M)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* LEVEL 2: OPERATING DIVISIONS */}
      {drillLevel === 'DIVISION' && (
        <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex gap-2 font-mono text-xs">
            <button
              onClick={() => setSelectedDivision('TREASURY')}
              className={`px-3 py-1.5 rounded-sm ${selectedDivision === 'TREASURY' ? 'bg-[#C68B45] text-[#0F141C] font-semibold' : 'bg-[#121721] text-[#8B9BB4]'}`}
            >
              Treasury & Capital
            </button>
            <button
              onClick={() => setSelectedDivision('PRIVATE_NOTE_HOUSE')}
              className={`px-3 py-1.5 rounded-sm ${selectedDivision === 'PRIVATE_NOTE_HOUSE' ? 'bg-[#C68B45] text-[#0F141C] font-semibold' : 'bg-[#121721] text-[#8B9BB4]'}`}
            >
              Private Note House
            </button>
            <button
              onClick={() => setSelectedDivision('COMMERCIAL')}
              className={`px-3 py-1.5 rounded-sm ${selectedDivision === 'COMMERCIAL' ? 'bg-[#C68B45] text-[#0F141C] font-semibold' : 'bg-[#121721] text-[#8B9BB4]'}`}
            >
              Commercial Banking
            </button>
            <button
              onClick={() => setSelectedDivision('RETAIL')}
              className={`px-3 py-1.5 rounded-sm ${selectedDivision === 'RETAIL' ? 'bg-[#C68B45] text-[#0F141C] font-semibold' : 'bg-[#121721] text-[#8B9BB4]'}`}
            >
              Retail & RSD Digital
            </button>
          </div>

          <div className="p-4 bg-[#121721] rounded-sm border border-[#1F2735] font-mono text-xs space-y-2">
            <span className="text-[#C68B45] font-bold block uppercase text-sm">
              {selectedDivision.replace(/_/g, ' ')} DIVISIONAL REPORT
            </span>
            <p className="text-[#D8D1C5] font-sans">
              Autonomous Scottish operating unit. Fully reconciled to the central general ledger.
            </p>
          </div>
        </div>
      )}

      {/* LEVEL 3: PRODUCT & NOTE POOLS */}
      {drillLevel === 'PRODUCT' && (
        <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <h3 className="text-base font-serif font-bold text-[#F4F1EA]">
            Note Instrument Portfolio Breakdown
          </h3>
          <div className="space-y-3 font-mono text-xs">
            {privateNotes.map(n => (
              <div key={n.id} className="p-3 bg-[#121721] rounded-sm border border-[#1F2735] flex justify-between items-center">
                <div>
                  <span className="font-bold text-[#F4F1EA] block">{n.name} ({n.isin})</span>
                  <span className="text-[11px] text-[#8B9BB4]">{n.collateralDescription}</span>
                </div>
                <div className="text-right">
                  <span className="font-bold text-[#C68B45] block">£{n.issuedAmount.toLocaleString()}</span>
                  <span className="text-[10px] text-[#22C55E]">{n.collateralRatioPct}% Coverage</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* LEVEL 4: GENERAL LEDGER JOURNALS */}
      {drillLevel === 'TRANSACTION' && (
        <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-[#1F2735]">
            <h3 className="text-base font-serif font-bold text-[#F4F1EA]">
              Double-Entry General Ledger Journal Logs
            </h3>
            <span className="text-xs font-mono text-[#8B9BB4]">
              {journalEntries.length} Reconciled Entries
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-[#1F2735] text-[#5A697E] text-[10px] uppercase">
                  <th className="pb-2 font-medium">Journal ID</th>
                  <th className="pb-2 font-medium">Timestamp</th>
                  <th className="pb-2 font-medium">Subledger</th>
                  <th className="pb-2 font-medium">Debit Account</th>
                  <th className="pb-2 font-medium">Credit Account</th>
                  <th className="pb-2 font-medium text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1F2735]">
                {journalEntries.map(j => (
                  <tr key={j.id} className="hover:bg-[#141B26]">
                    <td className="py-2.5 text-[#C68B45] font-semibold">{j.id}</td>
                    <td className="py-2.5 text-[#8B9BB4]">{j.timestamp}</td>
                    <td className="py-2.5 text-[#E6EDF3]">{j.subledger}</td>
                    <td className="py-2.5 text-[#22C55E] text-[11px] truncate max-w-xs">{j.debitAccount}</td>
                    <td className="py-2.5 text-[#EF4444] text-[11px] truncate max-w-xs">{j.creditAccount}</td>
                    <td className="py-2.5 text-right font-bold text-[#F4F1EA] tabular-nums">
                      {j.currency} {j.debitAmount.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
};
