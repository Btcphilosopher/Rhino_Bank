/**
 * RHINO FREE BANK SCOTLAND
 * Model Governance Registry & Immutable Audit Explorer
 */

import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';

export const AuditAndModelGovernance: React.FC = () => {
  const { modelRegistry, auditLogs } = useBank();
  const [governanceTab, setGovernanceTab] = useState<'AUDIT_LOG' | 'MODEL_REGISTRY'>('AUDIT_LOG');

  return (
    <div className="space-y-6">
      
      {/* Governance Header */}
      <div className="stone-panel p-6 rounded-sm border border-[#252E3D]">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-[#C68B45] uppercase tracking-wider mb-1">
              INSTITUTIONAL GOVERNANCE · MODEL VALIDATION & IMMUTABLE AUDIT LOG
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F4F1EA] tracking-tight">
              Model Governance & Audit Explorer
            </h1>
            <p className="text-xs text-[#9DAEC2] mt-1">
              Cryptographic Event Log Reconstruction · Model Challenger Benchmarks & Quantitative Validation
            </p>
          </div>

          <div className="text-left md:text-right">
            <div className="text-xs text-[#8B9BB4]">Total Audit Records</div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-[#F4F1EA] tabular-nums tracking-tight">
              {auditLogs.length} Verified
            </div>
            <div className="text-[11px] text-[#22C55E] font-mono mt-0.5">
              100% Cryptographically Verified Hashes
            </div>
          </div>
        </div>

        {/* Sub Navigation */}
        <div className="flex gap-2 pt-5 mt-5 border-t border-[#1F2735]">
          <button
            onClick={() => setGovernanceTab('AUDIT_LOG')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm transition-colors ${
              governanceTab === 'AUDIT_LOG'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40'
                : 'text-[#8B9BB4] hover:text-[#F4F1EA]'
            }`}
          >
            01. Chronological Audit Explorer ({auditLogs.length})
          </button>
          <button
            onClick={() => setGovernanceTab('MODEL_REGISTRY')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm transition-colors ${
              governanceTab === 'MODEL_REGISTRY'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40'
                : 'text-[#8B9BB4] hover:text-[#F4F1EA]'
            }`}
          >
            02. Model Governance Registry ({modelRegistry.length} Models)
          </button>
        </div>
      </div>

      {/* VIEW 1: AUDIT LOG EXPLORER */}
      {governanceTab === 'AUDIT_LOG' && (
        <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
            <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
              Chronological Audit Reconstruction
            </h2>
            <span className="text-xs font-mono text-[#8B9BB4]">
              Immutable SHA-256 Digest Simulation
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {auditLogs.map(log => (
              <div
                key={log.id}
                className="p-3.5 bg-[#121721] rounded-sm border border-[#1F2735] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[#C68B45] font-bold">{log.id}</span>
                    <span className="text-[#4E5D73]">·</span>
                    <span className="text-[#22C55E] text-[10px]">{log.actionType}</span>
                    <span className="text-[#4E5D73]">·</span>
                    <span className="text-[#8B9BB4] text-[10px]">{log.timestamp}</span>
                  </div>
                  <p className="text-[#E6EDF3] text-xs font-sans">
                    {log.details}
                  </p>
                  <div className="text-[10px] text-[#5A697E]">
                    Actor: <span className="text-[#9DAEC2]">{log.actor}</span> ({log.role})
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[10px] text-[#8B9BB4] block">HASH PROOF</span>
                  <span className="text-[10px] text-[#C68B45]">{log.immutableHash}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW 2: MODEL GOVERNANCE REGISTRY */}
      {governanceTab === 'MODEL_REGISTRY' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {modelRegistry.map(model => (
              <div
                key={model.modelId}
                className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-3 font-mono text-xs"
              >
                <div className="flex justify-between items-start">
                  <span className="text-[#C68B45] font-bold">{model.modelId}</span>
                  <span className="text-[10px] text-[#22C55E] bg-emerald-950/80 px-1.5 py-0.5 rounded-xs font-semibold">
                    {model.validationStatus}
                  </span>
                </div>

                <div>
                  <h3 className="text-sm font-serif font-bold text-[#F4F1EA] font-sans">
                    {model.name}
                  </h3>
                  <span className="text-[10px] text-[#8B9BB4]">
                    Version {model.version} · {model.authorDivision}
                  </span>
                </div>

                <p className="text-[#D8D1C5] text-xs font-sans leading-relaxed">
                  {model.purpose}
                </p>

                <div className="pt-2 border-t border-[#1F2735] space-y-1 text-[11px] text-[#8B9BB4]">
                  <div>
                    <span className="text-[#5A697E] block text-[10px]">METHODOLOGY</span>
                    <span className="text-[#F4F1EA]">{model.methodology}</span>
                  </div>
                  <div>
                    <span className="text-[#5A697E] block text-[10px]">DEPLOYED / LAST AUDIT</span>
                    <span className="text-[#E6EDF3]">{model.deploymentDate} · {model.lastAuditDate}</span>
                  </div>
                  {model.challengerModelBenchmark && (
                    <div>
                      <span className="text-[#5A697E] block text-[10px]">CHALLENGER BENCHMARK</span>
                      <span className="text-[#22C55E]">{model.challengerModelBenchmark}</span>
                    </div>
                  )}
                  <div>
                    <span className="text-[#5A697E] block text-[10px]">LIMITATIONS</span>
                    <span className="text-amber-300/80">{model.limitations}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
