/**
 * RHINO FREE BANK SCOTLAND
 * Rhino Private Edinburgh — Ultra-HNW Wealth & Estate Engineering
 */

import React, { useState } from 'react';

export const RhinoPrivate: React.FC = () => {
  const [estateSimulationAge, setEstateSimulationAge] = useState(55);
  const [trustStructure, setTrustStructure] = useState<'DISCRETIONARY_SCOTS_TRUST' | 'FAMILY_LIMITED_PARTNERSHIP'>('DISCRETIONARY_SCOTS_TRUST');

  const totalNetWorth = 8450000;
  const liquidAssets = 3120000;
  const privateEquityAndNotes = 2450000;
  const realEstateValuation = 2880000;
  const liabilities = 412800; // Mortgage

  // Estate planning simulation derivation
  const ihtThreshold = 1000000; // Spousal allowance + residential nil-rate
  const taxableEstate = Math.max(0, (totalNetWorth - liabilities) - ihtThreshold);
  const projectedIHTLiability = trustStructure === 'DISCRETIONARY_SCOTS_TRUST' ? taxableEstate * 0.20 : taxableEstate * 0.12;

  return (
    <div className="space-y-6">
      
      {/* Private Bank Master Header */}
      <div className="stone-panel p-6 rounded-sm border border-[#252E3D]">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-[#C68B45] uppercase tracking-wider mb-1">
              RHINO PRIVATE EDINBURGH · CHARLOTTE SQUARE WEALTH DESK
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F4F1EA] tracking-tight">
              Rhino Private Wealth & Estates
            </h1>
            <p className="text-xs text-[#9DAEC2] mt-1">
              Bespoke Private Note Syndicates, Family Office Structuring & Multi-Asset Wealth Preservation
            </p>
          </div>

          <div className="text-left md:text-right">
            <div className="text-xs text-[#8B9BB4]">Total Private Net Worth</div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-[#F4F1EA] tabular-nums tracking-tight">
              £{(totalNetWorth - liabilities).toLocaleString('en-GB', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-[#22C55E] font-mono mt-0.5">
              +£428,500 (+5.6%) portfolio return 12-month trailing
            </div>
          </div>
        </div>

        {/* Wealth Breakdown Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-5 mt-5 border-t border-[#1F2735] text-xs font-mono">
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">LIQUID ASSETS & CASH</span>
            <span className="text-[#F4F1EA] font-bold text-sm">£{liquidAssets.toLocaleString()}</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">PRIVATE NOTES & CREDIT</span>
            <span className="text-[#C68B45] font-bold text-sm">£{privateEquityAndNotes.toLocaleString()}</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">SCOTTISH PRIME PROPERTY</span>
            <span className="text-[#F4F1EA] font-bold text-sm">£{realEstateValuation.toLocaleString()}</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">TOTAL LIABILITIES</span>
            <span className="text-[#EF4444] font-bold text-sm">£{liabilities.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Family Office Wealth Matrix & Estate Engineering Simulation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Wealth Assets Matrix & Relationship Office */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Wealth Allocation Matrix */}
          <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
              <div>
                <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
                  Private Client Holdings & Syndicate Allocations
                </h2>
                <span className="text-[11px] font-mono text-[#8B9BB4]">
                  Asset diversification and annual yield profile
                </span>
              </div>
              <span className="text-xs font-mono text-[#C68B45]">
                Yield: 5.42% Weighted
              </span>
            </div>

            <div className="space-y-3 font-mono text-xs">
              <div className="bg-[#121721] p-3.5 rounded-sm border border-[#1F2735] flex justify-between items-center">
                <div>
                  <span className="text-[#F4F1EA] font-bold block text-sm">
                    RHINO EDINBURGH NOTE 01 (Infrastructure)
                  </span>
                  <span className="text-[#8B9BB4] text-[11px]">
                    Senior Secured · £400,000 Allocation · 5.25% Annual Coupon
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[#F4F1EA] font-bold block">£403,400.00</span>
                  <span className="text-[#22C55E] text-[10px]">+£21,000/yr Income</span>
                </div>
              </div>

              <div className="bg-[#121721] p-3.5 rounded-sm border border-[#1F2735] flex justify-between items-center">
                <div>
                  <span className="text-[#F4F1EA] font-bold block text-sm">
                    Speyside Distillers Maturing Cask Note
                  </span>
                  <span className="text-[#8B9BB4] text-[11px]">
                    Single Malt Collateralized · 5.80% Fixed Coupon
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[#F4F1EA] font-bold block">£650,000.00</span>
                  <span className="text-[#22C55E] text-[10px]">+£37,700/yr Income</span>
                </div>
              </div>

              <div className="bg-[#121721] p-3.5 rounded-sm border border-[#1F2735] flex justify-between items-center">
                <div>
                  <span className="text-[#F4F1EA] font-bold block text-sm">
                    Edinburgh Charlotte Square Residential Freehold
                  </span>
                  <span className="text-[#8B9BB4] text-[11px]">
                    Prime Georgian Townhouse (Valued Q3 2026)
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[#F4F1EA] font-bold block">£2,140,000.00</span>
                  <span className="text-[#C68B45] text-[10px]">+4.2% YoY Appreciation</span>
                </div>
              </div>

              <div className="bg-[#121721] p-3.5 rounded-sm border border-[#1F2735] flex justify-between items-center">
                <div>
                  <span className="text-[#F4F1EA] font-bold block text-sm">
                    Scottish Gilt & Global Equity Liquid Portfolio
                  </span>
                  <span className="text-[#8B9BB4] text-[11px]">
                    UK Gilts, SSE PLC, SMT PLC & Green Infrastructure
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[#F4F1EA] font-bold block">£2,066,000.00</span>
                  <span className="text-[#22C55E] text-[10px]">+8.4% 12M Return</span>
                </div>
              </div>
            </div>
          </div>

          {/* Private Banking Relationship Desk */}
          <div className="stone-panel p-5 rounded-sm border border-[#252E3D]">
            <h3 className="text-sm font-serif font-bold text-[#F4F1EA] mb-2">
              Assigned Private Client Relationship Officer
            </h3>
            <div className="flex items-center gap-4 text-xs font-mono">
              <div className="w-10 h-10 rounded-sm bg-[#1D2533] border border-[#C68B45]/40 flex items-center justify-center text-[#F4F1EA] font-serif font-bold">
                LM
              </div>
              <div>
                <span className="text-[#F4F1EA] font-bold block">Lady Morag Campbell, FRSE</span>
                <span className="text-[#8B9BB4]">Senior Managing Director · Charlotte Square Private Office</span>
                <span className="text-[#C68B45] block text-[10px] mt-0.5">Direct Secure Terminal: +44 131 496 0192 · morag.campbell@rhinobank.scot</span>
              </div>
            </div>
          </div>

        </div>

        {/* Right Col: Estate Planning & Tax Simulation Engine */}
        <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
            <h3 className="text-base font-serif font-bold text-[#F4F1EA]">
              Estate & Tax Engine
            </h3>
            <span className="text-xs font-mono text-[#C68B45]">
              Scots Trust Law
            </span>
          </div>

          <div className="space-y-4 font-mono text-xs">
            <div>
              <label className="text-[#8B9BB4] block mb-1">
                Simulation Horizon / Age: <span className="text-[#F4F1EA] font-bold">{estateSimulationAge} Years</span>
              </label>
              <input
                type="range"
                min="40"
                max="90"
                value={estateSimulationAge}
                onChange={(e) => setEstateSimulationAge(parseInt(e.target.value))}
                className="w-full accent-[#C68B45]"
              />
            </div>

            <div>
              <label className="text-[#8B9BB4] block mb-1">Structuring Vehicle</label>
              <select
                value={trustStructure}
                onChange={(e) => setTrustStructure(e.target.value as any)}
                className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
              >
                <option value="DISCRETIONARY_SCOTS_TRUST">Discretionary Scots Trust (Family Protection)</option>
                <option value="FAMILY_LIMITED_PARTNERSHIP">Scottish Family Limited Partnership (SFLP)</option>
              </select>
            </div>

            <div className="bg-[#121721] p-3 rounded-sm border border-[#1F2735] space-y-2 text-[11px]">
              <div className="flex justify-between">
                <span className="text-[#8B9BB4]">Gross Estate:</span>
                <span className="text-[#F4F1EA] font-semibold">£{totalNetWorth.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8B9BB4]">Nil-Rate Deductions:</span>
                <span className="text-[#22C55E]">£{ihtThreshold.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8B9BB4]">Business Relief (Private Notes):</span>
                <span className="text-[#22C55E]">100% APR / BPR Qualified</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-[#1F2735]">
                <span className="text-[#8B9BB4]">Projected Estate Tax:</span>
                <span className="text-[#C68B45] font-bold">£{projectedIHTLiability.toLocaleString('en-GB', { maximumFractionDigits: 0 })}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8B9BB4]">Effective Tax Rate:</span>
                <span className="text-[#22C55E] font-bold">{((projectedIHTLiability / totalNetWorth) * 100).toFixed(1)}% (Optimized)</span>
              </div>
            </div>

            <button
              onClick={() => alert('Generated Charlotte Square Estate Planning Memorandum (Simulation Document).')}
              className="w-full py-2.5 bg-[#1A222E] hover:bg-[#242F40] border border-[#2D3A4E] text-[#F4F1EA] font-semibold rounded-sm transition-colors text-xs"
            >
              Export Estate Optimization Memorandum
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
