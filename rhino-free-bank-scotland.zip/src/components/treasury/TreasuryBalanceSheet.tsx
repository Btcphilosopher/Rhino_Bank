/**
 * RHINO FREE BANK SCOTLAND
 * Bank Treasury Engine & Reconciling Institutional Balance Sheet
 */

import React from 'react';
import { useBank } from '../../context/BankContext';

export const TreasuryBalanceSheet: React.FC = () => {
  const { balanceSheet, macro } = useBank();

  return (
    <div className="space-y-6">
      
      {/* Treasury Master Cockpit */}
      <div className="stone-panel p-6 rounded-sm border border-[#252E3D]">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-[#C68B45] uppercase tracking-wider mb-1">
              BANK TREASURY ENGINE · INSTITUTIONAL BALANCE SHEET RECONCILIATION
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F4F1EA] tracking-tight">
              Treasury & Prudential Balance Sheet
            </h1>
            <p className="text-xs text-[#9DAEC2] mt-1">
              Double-Entry General Ledger Reconciliation · Assets = Liabilities + Equity (Delta: £{balanceSheet.reconciliationDelta.toFixed(2)})
            </p>
          </div>

          <div className="text-left md:text-right">
            <div className="text-xs text-[#8B9BB4]">Total Bank Assets</div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-[#F4F1EA] tabular-nums tracking-tight">
              £{(balanceSheet.assets.totalAssets / 1000000000).toFixed(3)} Billion
            </div>
            <div className="text-[11px] text-[#22C55E] font-mono mt-0.5">
              CET1 Ratio: {balanceSheet.metrics.cet1RatioSimulatedPct}% (Well Capitalized)
            </div>
          </div>
        </div>

        {/* Prudential Metrics Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-5 mt-5 border-t border-[#1F2735] text-xs font-mono">
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">CET1 RATIO</span>
            <span className="text-[#22C55E] font-bold text-sm">{balanceSheet.metrics.cet1RatioSimulatedPct}%</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">LIQUIDITY COVERAGE (LCR)</span>
            <span className="text-[#22C55E] font-bold text-sm">{balanceSheet.metrics.liquidityCoverageRatioPct}%</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">NET STABLE FUNDING</span>
            <span className="text-[#F4F1EA] font-bold text-sm">{balanceSheet.metrics.netStableFundingRatioPct}%</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">NET INTEREST MARGIN</span>
            <span className="text-[#C68B45] font-bold text-sm">{balanceSheet.metrics.netInterestMarginPct}%</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">RETURN ON EQUITY</span>
            <span className="text-[#F4F1EA] font-bold text-sm">{balanceSheet.metrics.returnOnEquityPct}%</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">COST / INCOME</span>
            <span className="text-[#22C55E] font-bold text-sm">{balanceSheet.metrics.costToIncomeRatioPct}%</span>
          </div>
        </div>
      </div>

      {/* Main Balance Sheet Grid: Assets vs Liabilities & Equity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
        
        {/* ASSETS COLUMN */}
        <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
            <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
              ASSETS (USES OF CAPITAL)
            </h2>
            <span className="text-sm font-bold text-[#F4F1EA] tabular-nums">
              £{(balanceSheet.assets.totalAssets / 1000000).toLocaleString('en-GB', { minimumFractionDigits: 1 })}M
            </span>
          </div>

          <div className="space-y-2 divide-y divide-[#1F2735]">
            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">Cash & Reserves at Bank of England</span>
                <span className="text-[10px] text-[#8B9BB4]">Central Bank Reserve Accounts & Clearing Funds</span>
              </div>
              <span className="font-bold text-[#F4F1EA] tabular-nums">
                £{(balanceSheet.assets.cashAndBoEReserves / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">Liquid High-Quality Securities (HQLA)</span>
                <span className="text-[10px] text-[#8B9BB4]">HM Treasury Gilts & Supranational Bonds</span>
              </div>
              <span className="font-bold text-[#F4F1EA] tabular-nums">
                £{(balanceSheet.assets.liquidHighQualitySecurities / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">Retail Mortgage Portfolio</span>
                <span className="text-[10px] text-[#8B9BB4]">Prime Scottish Residential Properties (Avg LTV 55.8%)</span>
              </div>
              <span className="font-bold text-[#F4F1EA] tabular-nums">
                £{(balanceSheet.assets.mortgageBook / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">Commercial & SME Lending Facilities</span>
                <span className="text-[10px] text-[#8B9BB4]">Scottish Corporate Working Capital & Growth Loans</span>
              </div>
              <span className="font-bold text-[#F4F1EA] tabular-nums">
                £{(balanceSheet.assets.commercialAndSMELending / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">Customer Retail Loans & Credit</span>
                <span className="text-[10px] text-[#8B9BB4]">Personal Loans & Card Receivables</span>
              </div>
              <span className="font-bold text-[#F4F1EA] tabular-nums">
                £{(balanceSheet.assets.customerLoansRetail / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">Infrastructure Contract Receivables</span>
                <span className="text-[10px] text-[#8B9BB4]">Offshore Wind, Hydro & Green Ferry Farebox Streams</span>
              </div>
              <span className="font-bold text-[#C68B45] tabular-nums">
                £{(balanceSheet.assets.infrastructureReceivables / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">Private Note Portfolio (Held to Maturity)</span>
                <span className="text-[10px] text-[#8B9BB4]">Syndicated Private Notes & Collateral Pools</span>
              </div>
              <span className="font-bold text-[#F4F1EA] tabular-nums">
                £{(balanceSheet.assets.privateNotePortfolioHeld / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">Other Tangible & Intangible Assets</span>
                <span className="text-[10px] text-[#8B9BB4]">Properties, Tech Grid & Clearing Nodes</span>
              </div>
              <span className="font-bold text-[#F4F1EA] tabular-nums">
                £{(balanceSheet.assets.otherAssets / 1000000).toFixed(1)}M
              </span>
            </div>
          </div>
        </div>

        {/* LIABILITIES & EQUITY COLUMN */}
        <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
            <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
              LIABILITIES & EQUITY (SOURCES OF FUNDS)
            </h2>
            <span className="text-sm font-bold text-[#F4F1EA] tabular-nums">
              £{((balanceSheet.liabilities.totalLiabilities + balanceSheet.equity.totalEquity) / 1000000).toLocaleString('en-GB', { minimumFractionDigits: 1 })}M
            </span>
          </div>

          <div className="space-y-2 divide-y divide-[#1F2735]">
            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">Retail Customer Deposits</span>
                <span className="text-[10px] text-[#8B9BB4]">Current Accounts, Fixed Bonds & ISAs</span>
              </div>
              <span className="font-bold text-[#F4F1EA] tabular-nums">
                £{(balanceSheet.liabilities.retailDeposits / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">Commercial Corporate Deposits</span>
                <span className="text-[10px] text-[#8B9BB4]">Operating Cash & Treasury Placements</span>
              </div>
              <span className="font-bold text-[#F4F1EA] tabular-nums">
                £{(balanceSheet.liabilities.commercialDeposits / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">Issued Private Note Obligations</span>
                <span className="text-[10px] text-[#8B9BB4]">7 Registered Series (Senior Secured & Tier 2)</span>
              </div>
              <span className="font-bold text-[#C68B45] tabular-nums">
                £{(balanceSheet.liabilities.issuedPrivateNotesObligations / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">RSD Digital Sterling in Circulation</span>
                <span className="text-[10px] text-[#8B9BB4]">PoS Grid Wallets & Smart Escrows</span>
              </div>
              <span className="font-bold text-[#C68B45] tabular-nums">
                £{(balanceSheet.liabilities.rsdDigitalSterlingInCirculation / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">Wholesale Interbank Funding</span>
                <span className="text-[10px] text-[#8B9BB4]">Term Repo Facilities & Bilateral Credit</span>
              </div>
              <span className="font-bold text-[#F4F1EA] tabular-nums">
                £{(balanceSheet.liabilities.wholesaleFunding / 1000000).toFixed(1)}M
              </span>
            </div>

            {/* EQUITY SECTION */}
            <div className="pt-3 pb-1 border-t border-[#252E3D]">
              <span className="text-[10px] text-[#C68B45] uppercase font-bold tracking-wider block">
                SHAREHOLDERS' EQUITY & RESERVES
              </span>
            </div>

            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">Paid-in Capital</span>
                <span className="text-[10px] text-[#8B9BB4]">Tier 1 Core Common Equity</span>
              </div>
              <span className="font-bold text-[#22C55E] tabular-nums">
                £{(balanceSheet.equity.paidInCapital / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="flex justify-between py-2">
              <div>
                <span className="text-[#F4F1EA] font-semibold block">Retained Earnings & Reserves</span>
                <span className="text-[10px] text-[#8B9BB4]">Accumulated Net Retained Profit</span>
              </div>
              <span className="font-bold text-[#22C55E] tabular-nums">
                £{((balanceSheet.equity.retainedEarnings + balanceSheet.equity.prudentialReserves) / 1000000).toFixed(1)}M
              </span>
            </div>
          </div>
        </div>

      </div>

      {/* Value at Risk & Sensitivities Risk Panel */}
      <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-3">
        <span className="text-xs font-mono text-[#C68B45] uppercase">
          QUANTITATIVE RISK ENGINE · VALUE-AT-RISK & SENSITIVITY DECOMPOSITION
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono pt-1">
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">1-DAY 99% VaR</span>
            <span className="text-[#F4F1EA] font-bold text-sm">£{(balanceSheet.metrics.var1Day99Pct / 1000000).toFixed(2)}M</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">EXPECTED SHORTFALL (ES 99%)</span>
            <span className="text-[#EF4444] font-bold text-sm">£{(balanceSheet.metrics.expectedShortfall99Pct / 1000000).toFixed(2)}M</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">DV01 (1bp RATE SHIFT)</span>
            <span className="text-[#EF4444] font-bold text-sm">£{Math.abs(balanceSheet.metrics.dv01InterestRateSensitivity).toLocaleString()}</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">CS01 (1bp SPREAD WIDENING)</span>
            <span className="text-[#EF4444] font-bold text-sm">£{Math.abs(balanceSheet.metrics.cs01CreditSpreadSensitivity).toLocaleString()}</span>
          </div>
        </div>
      </div>

    </div>
  );
};
