/**
 * RHINO FREE BANK SCOTLAND
 * Architectural Header - Top Bar Contract
 */

import React from 'react';
import { useBank } from '../../context/BankContext';

export type ActiveTab = 
  | 'RETAIL'
  | 'DIGITAL_STERLING'
  | 'NOTE_HOUSE'
  | 'VALIDATOR'
  | 'COMMERCIAL'
  | 'PRIVATE_BANK'
  | 'MARKETS'
  | 'TREASURY'
  | 'MACRO_MAP'
  | 'INTELLIGENCE'
  | 'GOVERNANCE'
  | 'BOARD';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab }) => {
  const { posNetwork, macro } = useBank();

  return (
    <header className="sticky top-0 z-40 bg-[#0F141C]/95 backdrop-blur border-b border-[#252E3D]">
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        
        {/* Zone 1: Single Text Element Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button 
            onClick={() => setActiveTab('RETAIL')}
            className="text-left group flex items-center gap-3 focus:outline-none"
          >
            <div className="w-8 h-8 rounded-sm bg-gradient-to-br from-[#C68B45] via-[#8C5D28] to-[#1D2533] flex items-center justify-center text-white font-serif font-bold text-base shadow-sm border border-[#C68B45]/40">
              R
            </div>
            <div>
              <span className="font-serif text-lg font-bold tracking-tight text-[#F4F1EA] block leading-none">
                RHINO FREE BANK
              </span>
              <span className="text-[10px] tracking-[0.2em] text-[#C68B45] font-mono block uppercase mt-0.5">
                SCOTLAND · EDINBURGH 1826/2026
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links (Clean single-line labels) */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2 overflow-x-auto py-1">
          <button
            onClick={() => setActiveTab('RETAIL')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap transition-colors ${
              activeTab === 'RETAIL'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40 shadow-xs'
                : 'text-[#9DAEC2] hover:text-[#F4F1EA] hover:bg-[#161D27]'
            }`}
          >
            Retail Account
          </button>

          <button
            onClick={() => setActiveTab('DIGITAL_STERLING')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap transition-colors ${
              activeTab === 'DIGITAL_STERLING'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40 shadow-xs'
                : 'text-[#9DAEC2] hover:text-[#F4F1EA] hover:bg-[#161D27]'
            }`}
          >
            RSD Digital Money
          </button>

          <button
            onClick={() => setActiveTab('NOTE_HOUSE')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap transition-colors ${
              activeTab === 'NOTE_HOUSE'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40 shadow-xs'
                : 'text-[#9DAEC2] hover:text-[#F4F1EA] hover:bg-[#161D27]'
            }`}
          >
            Private Note House
          </button>

          <button
            onClick={() => setActiveTab('VALIDATOR')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap transition-colors ${
              activeTab === 'VALIDATOR'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40 shadow-xs'
                : 'text-[#9DAEC2] hover:text-[#F4F1EA] hover:bg-[#161D27]'
            }`}
          >
            PoS Validator Grid
          </button>

          <button
            onClick={() => setActiveTab('COMMERCIAL')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap transition-colors ${
              activeTab === 'COMMERCIAL'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40 shadow-xs'
                : 'text-[#9DAEC2] hover:text-[#F4F1EA] hover:bg-[#161D27]'
            }`}
          >
            Commercial
          </button>

          <button
            onClick={() => setActiveTab('PRIVATE_BANK')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap transition-colors ${
              activeTab === 'PRIVATE_BANK'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40 shadow-xs'
                : 'text-[#9DAEC2] hover:text-[#F4F1EA] hover:bg-[#161D27]'
            }`}
          >
            Rhino Private
          </button>

          <button
            onClick={() => setActiveTab('MARKETS')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap transition-colors ${
              activeTab === 'MARKETS'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40 shadow-xs'
                : 'text-[#9DAEC2] hover:text-[#F4F1EA] hover:bg-[#161D27]'
            }`}
          >
            Capital Markets
          </button>

          <button
            onClick={() => setActiveTab('TREASURY')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap transition-colors ${
              activeTab === 'TREASURY'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40 shadow-xs'
                : 'text-[#9DAEC2] hover:text-[#F4F1EA] hover:bg-[#161D27]'
            }`}
          >
            Bank Treasury
          </button>

          <button
            onClick={() => setActiveTab('MACRO_MAP')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap transition-colors ${
              activeTab === 'MACRO_MAP'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40 shadow-xs'
                : 'text-[#9DAEC2] hover:text-[#F4F1EA] hover:bg-[#161D27]'
            }`}
          >
            Scottish Macro Map
          </button>

          <button
            onClick={() => setActiveTab('INTELLIGENCE')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap transition-colors ${
              activeTab === 'INTELLIGENCE'
                ? 'bg-[#1D2533] text-[#C68B45] border border-[#C68B45]/40 shadow-xs'
                : 'text-[#9DAEC2] hover:text-[#F4F1EA] hover:bg-[#161D27]'
            }`}
          >
            AI Intelligence
          </button>

          <button
            onClick={() => setActiveTab('GOVERNANCE')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap transition-colors ${
              activeTab === 'GOVERNANCE'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40 shadow-xs'
                : 'text-[#9DAEC2] hover:text-[#F4F1EA] hover:bg-[#161D27]'
            }`}
          >
            Governance
          </button>

          <button
            onClick={() => setActiveTab('BOARD')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap transition-colors ${
              activeTab === 'BOARD'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40 shadow-xs'
                : 'text-[#9DAEC2] hover:text-[#F4F1EA] hover:bg-[#161D27]'
            }`}
          >
            Board Terminal
          </button>
        </nav>

        {/* Zone 3: Primary Action & Real-Time Telemetry */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="hidden sm:flex items-center gap-2 text-xs font-mono text-[#9DAEC2]">
            <span className="text-[#8B9BB4]">BoE Rate</span>
            <span className="text-[#F4F1EA] font-semibold tabular-nums">{macro.bankRatePct.toFixed(2)}%</span>
            <span className="text-[#4E5D73]">·</span>
            <span className="text-[#8B9BB4]">Block</span>
            <span className="text-[#C68B45] font-semibold tabular-nums">#{posNetwork.blockHeight}</span>
          </div>

          <button
            onClick={() => setActiveTab('INTELLIGENCE')}
            className="px-3.5 py-1.5 text-xs font-semibold text-[#0F141C] bg-[#C68B45] hover:bg-[#D89B55] rounded-sm transition-colors whitespace-nowrap shadow-xs flex items-center gap-1.5"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#0F141C]"></span>
            <span>Edinburgh Intelligence</span>
          </button>
        </div>

      </div>
    </header>
  );
};
