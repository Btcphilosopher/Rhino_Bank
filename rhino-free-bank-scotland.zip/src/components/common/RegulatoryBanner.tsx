/**
 * RHINO FREE BANK SCOTLAND
 * Regulatory Status & Synthetic Simulation Disclosure Banner
 */

import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';

export const RegulatoryBanner: React.FC = () => {
  const { regulatoryStatus } = useBank();
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="bg-[#121822] border-b border-[#252E3D] text-[#8B9BB4] text-xs">
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-2 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[#C68B45] font-mono font-semibold uppercase tracking-wider text-[10px]">
            SIMULATION SANDBOX
          </span>
          <span className="text-[#4E5D73]">·</span>
          <span className="text-[#D8D1C5]">
            Rhino Free Bank Scotland PLC is a fictional institutional banking architecture and financial engineering simulation.
          </span>
          <span className="text-[#4E5D73]">·</span>
          <span className="text-[#9DAEC2] font-mono">
            Status: {regulatoryStatus.permission_status}
          </span>
        </div>

        <button
          onClick={() => setExpanded(!expanded)}
          className="text-[#C68B45] hover:text-[#D89B55] underline text-xs font-mono shrink-0"
        >
          {expanded ? 'Hide Regulatory Object' : 'View Regulatory Object'}
        </button>
      </div>

      {expanded && (
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-3 bg-[#0A0E14] border-t border-[#1D2533] grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-[11px]">
          <div>
            <span className="text-[#5A697E] block">JURISDICTION</span>
            <span className="text-[#E6EDF3]">{regulatoryStatus.jurisdiction}</span>
          </div>
          <div>
            <span className="text-[#5A697E] block">SUPERVISORY BODY</span>
            <span className="text-[#E6EDF3]">{regulatoryStatus.regulator}</span>
          </div>
          <div>
            <span className="text-[#5A697E] block">SYNTHETIC PERMISSION</span>
            <span className="text-[#E6EDF3]">{regulatoryStatus.permission}</span>
          </div>
          <div>
            <span className="text-[#5A697E] block">EFFECTIVE / EXPIRY</span>
            <span className="text-[#E6EDF3]">{regulatoryStatus.effective_date} · {regulatoryStatus.expiry_date}</span>
          </div>
          <div className="col-span-full pt-1 text-[#8B9BB4] border-t border-[#1A222E]">
            <span className="text-[#5A697E]">DISCLOSURE NOTICE: </span>
            {regulatoryStatus.customer_facing_disclosure}
          </div>
        </div>
      )}
    </div>
  );
};
