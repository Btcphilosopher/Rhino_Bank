/**
 * RHINO FREE BANK SCOTLAND
 * Capital Markets & Retail Investment Platform
 */

import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import { PortfolioAssetTwin } from '../../types/financial';

export const InstitutionalMarkets: React.FC = () => {
  const { portfolioAssets } = useBank();
  const [selectedAsset, setSelectedAsset] = useState<PortfolioAssetTwin>(portfolioAssets[0]);

  const totalPortfolioValue = portfolioAssets.reduce((sum, a) => sum + a.totalValue, 0);
  const totalUnrealizedGain = portfolioAssets.reduce((sum, a) => sum + a.unrealizedGainLoss, 0);
  const totalAnnualDividendIncome = portfolioAssets.reduce((sum, a) => sum + (a.totalValue * (a.dividendYieldAnnualPct / 100)), 0);

  return (
    <div className="space-y-6">
      
      {/* Portfolio Master Header */}
      <div className="stone-panel p-6 rounded-sm border border-[#252E3D]">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-[#C68B45] uppercase tracking-wider mb-1">
              CAPITAL MARKETS & SECURITIES · SCOTTISH INVESTMENT DESK
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F4F1EA] tracking-tight">
              Institutional Securities & Portfolios
            </h1>
            <p className="text-xs text-[#9DAEC2] mt-1">
              Scottish Gilts, Sovereign Infrastructure, Green Energy Equities & Bespoke Private Notes
            </p>
          </div>

          <div className="text-left md:text-right">
            <div className="text-xs text-[#8B9BB4]">Total Portfolio Valuation</div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-[#F4F1EA] tabular-nums tracking-tight">
              £{totalPortfolioValue.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-[#22C55E] font-mono mt-0.5">
              +£{totalUnrealizedGain.toLocaleString()} (+{((totalUnrealizedGain / (totalPortfolioValue - totalUnrealizedGain)) * 100).toFixed(2)}%) Unrealized Gain
            </div>
          </div>
        </div>

        {/* Portfolio Stats Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-5 mt-5 border-t border-[#1F2735] text-xs font-mono">
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">ANNUAL DIVIDEND CASHFLOW</span>
            <span className="text-[#22C55E] font-bold text-sm">£{totalAnnualDividendIncome.toLocaleString('en-GB', { maximumFractionDigits: 0 })}/yr</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">WEIGHTED DIVIDEND YIELD</span>
            <span className="text-[#F4F1EA] font-bold text-sm">{((totalAnnualDividendIncome / totalPortfolioValue) * 100).toFixed(2)}%</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">WEIGHTED ESG SCORE</span>
            <span className="text-[#C68B45] font-bold text-sm">88.4 / 100 (Prime)</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">ACTIVE HOLDINGS</span>
            <span className="text-[#F4F1EA] font-bold text-sm">{portfolioAssets.length} Strategic Positions</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Securities Ledger & Asset Deep Dive */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Securities Table */}
        <div className="lg:col-span-2 stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
            <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
              Securities Ledger & Holdings
            </h2>
            <span className="text-xs font-mono text-[#8B9BB4]">
              Mark-to-Market Real-Time Pricing
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-[#1F2735] text-[#5A697E] text-[10px] uppercase">
                  <th className="pb-2 font-medium">Symbol / Asset</th>
                  <th className="pb-2 font-medium">Class</th>
                  <th className="pb-2 font-medium">Units</th>
                  <th className="pb-2 font-medium">Current Price</th>
                  <th className="pb-2 font-medium">Allocation</th>
                  <th className="pb-2 font-medium text-right">Valuation (£)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1F2735]">
                {portfolioAssets.map(asset => (
                  <tr
                    key={asset.id}
                    onClick={() => setSelectedAsset(asset)}
                    className={`cursor-pointer transition-colors ${selectedAsset.id === asset.id ? 'bg-[#1D2533]' : 'hover:bg-[#141B26]'}`}
                  >
                    <td className="py-3">
                      <span className="font-bold text-[#F4F1EA] block">{asset.symbol}</span>
                      <span className="text-[10px] text-[#8B9BB4] font-sans">{asset.name}</span>
                    </td>
                    <td className="py-3 text-[#9DAEC2]">{asset.assetClass.replace(/_/g, ' ')}</td>
                    <td className="py-3 text-[#E6EDF3]">{asset.units.toLocaleString()}</td>
                    <td className="py-3 text-[#C68B45] font-semibold">£{asset.currentPrice.toFixed(2)}</td>
                    <td className="py-3 text-[#8B9BB4]">{asset.allocationPct}%</td>
                    <td className="py-3 text-right font-bold text-[#F4F1EA] tabular-nums">
                      £{asset.totalValue.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Col: Selected Asset Detail */}
        <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
            <h3 className="text-base font-serif font-bold text-[#F4F1EA]">
              {selectedAsset.symbol}
            </h3>
            <span className="text-xs font-mono text-[#22C55E]">
              ESG: {selectedAsset.esgScore}/100
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <span className="font-serif font-bold text-sm text-[#F4F1EA] block">
              {selectedAsset.name}
            </span>

            <div className="bg-[#121721] p-3 rounded-sm border border-[#1F2735] space-y-1.5 text-[11px]">
              <div className="flex justify-between">
                <span className="text-[#8B9BB4]">Total Position:</span>
                <span className="text-[#F4F1EA] font-semibold">£{selectedAsset.totalValue.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8B9BB4]">Average Cost:</span>
                <span className="text-[#E6EDF3]">£{selectedAsset.avgCostPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8B9BB4]">Unrealized Return:</span>
                <span className={`font-semibold ${selectedAsset.unrealizedGainLoss >= 0 ? 'text-[#22C55E]' : 'text-[#EF4444]'}`}>
                  +£{selectedAsset.unrealizedGainLoss.toLocaleString()} ({selectedAsset.unrealizedGainLossPct}%)
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8B9BB4]">Annual Dividend Yield:</span>
                <span className="text-[#C68B45] font-semibold">{selectedAsset.dividendYieldAnnualPct}%</span>
              </div>
            </div>

            <div className="pt-2 border-t border-[#1F2735] flex gap-2">
              <button
                onClick={() => alert(`Submitted buy order for ${selectedAsset.symbol} on Edinburgh Securities Exchange.`)}
                className="flex-1 py-2 bg-[#C68B45] hover:bg-[#D89B55] text-[#0F141C] font-semibold rounded-sm text-xs"
              >
                Buy Additional Units
              </button>
              <button
                onClick={() => alert(`Submitted limit sell order for ${selectedAsset.symbol}.`)}
                className="flex-1 py-2 bg-[#1A222E] hover:bg-[#242F40] border border-[#2D3A4E] text-[#F4F1EA] font-semibold rounded-sm text-xs"
              >
                Rebalance / Trim
              </button>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
