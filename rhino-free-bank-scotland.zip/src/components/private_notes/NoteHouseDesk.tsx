/**
 * RHINO FREE BANK SCOTLAND
 * Private Note House & Capital Markets Issuance Workbench
 */

import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import { NoteClass, PrivateNoteTwin } from '../../types/financial';
import { PrivateNoteHouseService } from '../../services/privateNoteHouse';
import noteCertImage from '../../assets/images/rhino_note_certificate_1790502628366.jpg';

export const NoteHouseDesk: React.FC = () => {
  const {
    privateNotes,
    noteOrders,
    issuePrivateNote,
    placeNoteOrder
  } = useBank();

  const [selectedNote, setSelectedNote] = useState<PrivateNoteTwin>(privateNotes[0]);
  const [activeSubTab, setActiveSubTab] = useState<'ISSUANCE_DESK' | 'ORDER_BOOK' | 'PORTFOLIO_HOLDINGS'>('ISSUANCE_DESK');
  const [termSheetModalOpen, setTermSheetModalOpen] = useState(false);
  const [activeTermSheetText, setActiveTermSheetText] = useState('');

  // New Note Issuance Form State
  const [issueName, setIssueName] = useState('');
  const [issueClass, setIssueClass] = useState<NoteClass>('RHINO_INFRASTRUCTURE_NOTE');
  const [issueSize, setIssueSize] = useState('50000000');
  const [issueCoupon, setIssueCoupon] = useState('5.50');
  const [issueMaturity, setIssueMaturity] = useState('5');
  const [issueCollateralDesc, setIssueCollateralDesc] = useState('Highland Hydroelectric & pumped storage receivables');
  const [issueCollateralVal, setIssueCollateralVal] = useState('75000000');
  const [issueSeniority, setIssueSeniority] = useState<'SENIOR_SECURED' | 'SENIOR_UNSECURED' | 'SUBORDINATED'>('SENIOR_SECURED');

  // Order Book Form State
  const [orderSide, setOrderSide] = useState<'BID' | 'OFFER'>('BID');
  const [orderAmount, setOrderAmount] = useState('2000000');
  const [orderPrice, setOrderPrice] = useState('100.85');
  const [orderParticipant, setOrderParticipant] = useState('Edinburgh Merchant Trust');

  const handleIssueSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const size = parseFloat(issueSize);
    const coupon = parseFloat(issueCoupon);
    const maturity = parseFloat(issueMaturity);
    const collateralVal = parseFloat(issueCollateralVal);

    if (isNaN(size) || isNaN(coupon) || isNaN(maturity) || isNaN(collateralVal)) return;

    const newNote = issuePrivateNote({
      name: issueName || `Rhino Scottish ${issueClass.replace(/RHINO_|_NOTE/g, '')} Note Series`,
      noteClass: issueClass,
      issuer: 'Rhino Free Bank Scotland PLC (Private Note House)',
      faceValue: 1000,
      issueSize: size,
      maturityYears: maturity,
      couponAnnualPct: coupon,
      collateralDescription: issueCollateralDesc,
      collateralValue: collateralVal,
      seniority: issueSeniority,
      covenants: ['Negative Pledge on Collateral Pool', 'Minimum 125% Asset Coverage', 'Quarterly Auditor Certificate'],
      settlementMechanism: 'RSD_ATOMIC_DELIVERY',
    });

    setSelectedNote(newNote);
    setActiveTermSheetText(PrivateNoteHouseService.generateElectronicTermSheet(newNote));
    setTermSheetModalOpen(true);
    setIssueName('');
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(orderAmount);
    const prc = parseFloat(orderPrice);
    if (isNaN(amt) || isNaN(prc)) return;

    placeNoteOrder({
      noteId: selectedNote.id,
      isin: selectedNote.isin,
      side: orderSide,
      participant: orderParticipant,
      participantType: 'EDINBURGH_PRIVATE_BANK',
      faceAmount: amt,
      pricePct: prc,
      yieldPct: Math.round(((selectedNote.couponAnnualPct / (prc / 100))) * 100) / 100,
      orderType: 'LIMIT',
    });

    setOrderAmount('');
  };

  const noteSpecificOrders = noteOrders.filter(o => o.noteId === selectedNote.id || o.isin === selectedNote.isin);

  return (
    <div className="space-y-6">
      
      {/* Top Banner & Flagship Note Overview */}
      <div className="stone-panel p-6 rounded-sm border border-[#252E3D]">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-[#C68B45] uppercase tracking-wider mb-1">
              SCOTTISH PRIVATE NOTE HOUSE · INSTITUTIONAL NOTE DESK
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F4F1EA] tracking-tight">
              Private Note Issuance & Secondary Market
            </h1>
            <p className="text-xs text-[#9DAEC2] mt-1">
              7 Regulated Synthetic Instrument Classes · Negotiable Monetary Collateral & Atomic Delivery
            </p>
          </div>

          <div className="text-left md:text-right">
            <div className="text-xs text-[#8B9BB4]">Total Issued Note Volume</div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-[#F4F1EA] tabular-nums tracking-tight">
              £{privateNotes.reduce((sum, n) => sum + n.issuedAmount, 0).toLocaleString('en-GB')}
            </div>
            <div className="text-[11px] text-[#22C55E] font-mono mt-0.5">
              100% Fully Collateralized & Supervised
            </div>
          </div>
        </div>

        {/* Sub Navigation Bar */}
        <div className="flex gap-2 pt-5 mt-5 border-t border-[#1F2735]">
          <button
            onClick={() => setActiveSubTab('ISSUANCE_DESK')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm transition-colors ${
              activeSubTab === 'ISSUANCE_DESK'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40'
                : 'text-[#8B9BB4] hover:text-[#F4F1EA] hover:bg-[#141A24]'
            }`}
          >
            01. Note Issuance Desk
          </button>
          <button
            onClick={() => setActiveSubTab('ORDER_BOOK')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm transition-colors ${
              activeSubTab === 'ORDER_BOOK'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40'
                : 'text-[#8B9BB4] hover:text-[#F4F1EA] hover:bg-[#141A24]'
            }`}
          >
            02. Institutional Order Book
          </button>
          <button
            onClick={() => setActiveSubTab('PORTFOLIO_HOLDINGS')}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm transition-colors ${
              activeSubTab === 'PORTFOLIO_HOLDINGS'
                ? 'bg-[#1D2533] text-[#F4F1EA] border border-[#C68B45]/40'
                : 'text-[#8B9BB4] hover:text-[#F4F1EA] hover:bg-[#141A24]'
            }`}
          >
            03. Note Registry ({privateNotes.length} Issues)
          </button>
        </div>
      </div>

      {/* SUB-VIEW 1: NOTE ISSUANCE DESK */}
      {activeSubTab === 'ISSUANCE_DESK' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Left 2 Cols: Structuring Workbench */}
          <div className="lg:col-span-2 stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
              <div>
                <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
                  New Private Note Structuring Desk
                </h2>
                <span className="text-[11px] font-mono text-[#8B9BB4]">
                  Workflow: Structuring → Collateral Audit → Pricing → Term Sheet Execution
                </span>
              </div>
              <span className="text-xs font-mono text-[#C68B45]">
                Scots Law Standard
              </span>
            </div>

            <form onSubmit={handleIssueSubmit} className="space-y-4 font-mono text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[#8B9BB4] block mb-1">Instrument Series Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Rhino Lothian Grid Infrastructure Note"
                    value={issueName}
                    onChange={(e) => setIssueName(e.target.value)}
                    className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
                  />
                </div>

                <div>
                  <label className="text-[#8B9BB4] block mb-1">Note Class (7 Regulatory Categories)</label>
                  <select
                    value={issueClass}
                    onChange={(e) => setIssueClass(e.target.value as NoteClass)}
                    className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
                  >
                    <option value="RHINO_INFRASTRUCTURE_NOTE">Rhino Infrastructure Note</option>
                    <option value="RHINO_COMMODITY_NOTE">Rhino Commodity Note (e.g. Whisky / Energy)</option>
                    <option value="RHINO_REVENUE_NOTE">Rhino Revenue Note (Farebox / Tolls)</option>
                    <option value="RHINO_MERCHANT_NOTE">Rhino Merchant Note (SME Working Capital)</option>
                    <option value="RHINO_SECURED_NOTE">Rhino Secured Note (Asset Pool)</option>
                    <option value="RHINO_INSTITUTIONAL_NOTE">Rhino Institutional Note (Tier 2 Funding)</option>
                    <option value="RHINO_PRIVATE_NOTE">Rhino Private Note (Bespoke Negotiable)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-[#8B9BB4] block mb-1">Nominal Issue Size (£ GBP)</label>
                  <input
                    type="number"
                    step="1000000"
                    min="1000000"
                    required
                    value={issueSize}
                    onChange={(e) => setIssueSize(e.target.value)}
                    className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
                  />
                </div>

                <div>
                  <label className="text-[#8B9BB4] block mb-1">Coupon Annual (%)</label>
                  <input
                    type="number"
                    step="0.05"
                    min="1.0"
                    max="15.0"
                    required
                    value={issueCoupon}
                    onChange={(e) => setIssueCoupon(e.target.value)}
                    className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
                  />
                </div>

                <div>
                  <label className="text-[#8B9BB4] block mb-1">Maturity (Years)</label>
                  <input
                    type="number"
                    step="1"
                    min="1"
                    max="30"
                    required
                    value={issueMaturity}
                    onChange={(e) => setIssueMaturity(e.target.value)}
                    className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[#8B9BB4] block mb-1">Collateral Pool Description</label>
                  <input
                    type="text"
                    required
                    value={issueCollateralDesc}
                    onChange={(e) => setIssueCollateralDesc(e.target.value)}
                    className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
                  />
                </div>

                <div>
                  <label className="text-[#8B9BB4] block mb-1">Collateral Valuation (£ GBP)</label>
                  <input
                    type="number"
                    step="1000000"
                    required
                    value={issueCollateralVal}
                    onChange={(e) => setIssueCollateralVal(e.target.value)}
                    className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
                  />
                </div>
              </div>

              <div>
                <label className="text-[#8B9BB4] block mb-1">Seniority Structure</label>
                <select
                  value={issueSeniority}
                  onChange={(e) => setIssueSeniority(e.target.value as any)}
                  className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
                >
                  <option value="SENIOR_SECURED">Senior Secured (Priority Lien on Collateral)</option>
                  <option value="SENIOR_UNSECURED">Senior Unsecured (General Bank Obligation)</option>
                  <option value="SUBORDINATED">Subordinated / Mezzanine</option>
                </select>
              </div>

              <div className="pt-3 border-t border-[#1F2735] flex justify-end gap-3">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#C68B45] hover:bg-[#D89B55] text-[#0F141C] font-semibold rounded-sm transition-colors text-xs"
                >
                  Structure Note & Generate Term Sheet
                </button>
              </div>
            </form>
          </div>

          {/* Right Col: Flagship Note Highlight & Physical Certificate Visual */}
          <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-[#C68B45] uppercase">
                FLAGSHIP ISSUE SPECIFICATION
              </span>
              <span className="text-xs font-mono text-[#22C55E]">
                {selectedNote.syntheticCreditRating}
              </span>
            </div>

            <div className="relative overflow-hidden rounded-sm border border-[#C68B45]/40 shadow-lg">
              <img
                src={noteCertImage}
                alt="Engraved Scottish Note Certificate"
                referrerPolicy="no-referrer"
                className="w-full h-44 object-cover brightness-95 contrast-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0D14]/90 via-transparent to-transparent p-3 flex flex-col justify-between">
                <span className="text-[10px] font-mono text-[#C68B45]">
                  {selectedNote.isin}
                </span>
                <div>
                  <h3 className="text-sm font-serif font-bold text-[#F4F1EA]">
                    {selectedNote.name}
                  </h3>
                  <span className="text-[10px] font-mono text-[#9DAEC2]">
                    Coupon {selectedNote.couponAnnualPct}% · Due {selectedNote.maturityDate}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-2 text-xs font-mono pt-1 divide-y divide-[#1F2735]">
              <div className="flex justify-between py-1.5">
                <span className="text-[#8B9BB4]">Issue Nominal:</span>
                <span className="text-[#F4F1EA] font-semibold">£{selectedNote.issuedAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-[#8B9BB4]">Indicative Yield:</span>
                <span className="text-[#C68B45] font-semibold">{selectedNote.yieldAnnualPct}%</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-[#8B9BB4]">Duration (Macaulay):</span>
                <span className="text-[#F4F1EA]">{selectedNote.durationYears.toFixed(2)} Years</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-[#8B9BB4]">Collateral Ratio:</span>
                <span className="text-[#22C55E] font-semibold">{selectedNote.collateralRatioPct}% Coverage</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-[#8B9BB4]">Secondary Price:</span>
                <span className="text-[#F4F1EA] font-bold">{selectedNote.marketPriceIndicativePct}%</span>
              </div>
            </div>

            <button
              onClick={() => {
                setActiveTermSheetText(PrivateNoteHouseService.generateElectronicTermSheet(selectedNote));
                setTermSheetModalOpen(true);
              }}
              className="w-full py-2 bg-[#1A222E] hover:bg-[#242F40] border border-[#2D3A4E] text-[#F4F1EA] text-xs font-mono rounded-sm transition-colors"
            >
              View Full Electronic Term Sheet
            </button>
          </div>

        </div>
      )}

      {/* SUB-VIEW 2: INSTITUTIONAL ORDER BOOK */}
      {activeSubTab === 'ORDER_BOOK' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Order Book Table */}
          <div className="lg:col-span-2 stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
              <div>
                <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
                  Note Order Book · {selectedNote.name} ({selectedNote.isin})
                </h2>
                <span className="text-[11px] font-mono text-[#8B9BB4]">
                  Synthetic Secondary Trading & Liquidity Grid
                </span>
              </div>
              <span className="text-xs font-mono text-[#C68B45]">
                Indicative: {selectedNote.marketPriceIndicativePct}%
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-[#1F2735] text-[#5A697E] text-[10px] uppercase">
                    <th className="pb-2 font-medium">Time</th>
                    <th className="pb-2 font-medium">Participant</th>
                    <th className="pb-2 font-medium">Side</th>
                    <th className="pb-2 font-medium">Price (%)</th>
                    <th className="pb-2 font-medium">Yield (%)</th>
                    <th className="pb-2 font-medium text-right">Face Amount (£)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1F2735]">
                  {noteSpecificOrders.map(ord => (
                    <tr key={ord.id} className="hover:bg-[#141B26] transition-colors">
                      <td className="py-2.5 text-[#8B9BB4]">{ord.timestamp}</td>
                      <td className="py-2.5 text-[#E6EDF3] font-sans font-medium">{ord.participant}</td>
                      <td className={`py-2.5 font-bold ${ord.side === 'BID' ? 'text-[#22C55E]' : 'text-[#EF4444]'}`}>
                        {ord.side}
                      </td>
                      <td className="py-2.5 text-[#F4F1EA] font-semibold">{ord.pricePct.toFixed(2)}%</td>
                      <td className="py-2.5 text-[#C68B45]">{ord.yieldPct.toFixed(2)}%</td>
                      <td className="py-2.5 text-right font-bold text-[#F4F1EA] tabular-nums">
                        £{ord.faceAmount.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Place Order Panel */}
          <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
            <h3 className="text-base font-serif font-bold text-[#F4F1EA]">
              Submit Trade Order / RFQ
            </h3>

            <form onSubmit={handlePlaceOrder} className="space-y-3 font-mono text-xs">
              <div>
                <label className="text-[#8B9BB4] block mb-1">Target Instrument</label>
                <select
                  value={selectedNote.id}
                  onChange={(e) => {
                    const found = privateNotes.find(n => n.id === e.target.value);
                    if (found) setSelectedNote(found);
                  }}
                  className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
                >
                  {privateNotes.map(n => (
                    <option key={n.id} value={n.id}>
                      {n.name} ({n.isin})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setOrderSide('BID')}
                  className={`flex-1 py-2 rounded-sm font-semibold transition-colors ${
                    orderSide === 'BID'
                      ? 'bg-[#22C55E] text-[#0F141C]'
                      : 'bg-[#121721] text-[#8B9BB4] border border-[#1F2735]'
                  }`}
                >
                  BID (Buy)
                </button>
                <button
                  type="button"
                  onClick={() => setOrderSide('OFFER')}
                  className={`flex-1 py-2 rounded-sm font-semibold transition-colors ${
                    orderSide === 'OFFER'
                      ? 'bg-[#EF4444] text-[#F4F1EA]'
                      : 'bg-[#121721] text-[#8B9BB4] border border-[#1F2735]'
                  }`}
                >
                  OFFER (Sell)
                </button>
              </div>

              <div>
                <label className="text-[#8B9BB4] block mb-1">Institutional Participant</label>
                <select
                  value={orderParticipant}
                  onChange={(e) => setOrderParticipant(e.target.value)}
                  className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
                >
                  <option value="Scottish Pension Fund Pool">Scottish Pension Fund Pool</option>
                  <option value="Edinburgh Merchant Trust">Edinburgh Merchant Trust</option>
                  <option value="Caledonian Family Office">Caledonian Family Office</option>
                  <option value="Standard Life Heritage Syndicate">Standard Life Heritage Syndicate</option>
                  <option value="Edinburgh University Endowment">Edinburgh University Endowment</option>
                  <option value="Rhino Treasury Reserve">Rhino Treasury Reserve Desk</option>
                </select>
              </div>

              <div>
                <label className="text-[#8B9BB4] block mb-1">Limit Price (% of par)</label>
                <input
                  type="number"
                  step="0.05"
                  required
                  value={orderPrice}
                  onChange={(e) => setOrderPrice(e.target.value)}
                  className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
                />
              </div>

              <div>
                <label className="text-[#8B9BB4] block mb-1">Face Value Amount (£ GBP)</label>
                <input
                  type="number"
                  step="100000"
                  required
                  value={orderAmount}
                  onChange={(e) => setOrderAmount(e.target.value)}
                  className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA] text-base font-bold"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#C68B45] hover:bg-[#D89B55] text-[#0F141C] font-semibold rounded-sm transition-colors text-xs"
              >
                Submit Institutional Order
              </button>
            </form>
          </div>

        </div>
      )}

      {/* SUB-VIEW 3: COMPLETE NOTE REGISTRY */}
      {activeSubTab === 'PORTFOLIO_HOLDINGS' && (
        <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
            <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
              All Active Issued Private Notes
            </h2>
            <span className="text-xs font-mono text-[#8B9BB4]">
              {privateNotes.length} Issues Operational
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {privateNotes.map(n => (
              <div
                key={n.id}
                onClick={() => setSelectedNote(n)}
                className={`p-4 rounded-sm border cursor-pointer transition-all ${
                  selectedNote.id === n.id
                    ? 'bg-[#1B2330] border-[#C68B45]/60 shadow-md'
                    : 'bg-[#121721] border-[#1F2735] hover:border-[#2D3A4E]'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="text-[10px] font-mono text-[#C68B45]">
                    {n.isin}
                  </span>
                  <span className="text-[10px] font-mono text-[#22C55E]">
                    {n.syntheticCreditRating}
                  </span>
                </div>
                <h4 className="text-sm font-serif font-bold text-[#F4F1EA] leading-tight mb-2">
                  {n.name}
                </h4>
                <div className="space-y-1 text-xs font-mono text-[#8B9BB4]">
                  <div className="flex justify-between">
                    <span>Size:</span>
                    <span className="text-[#F4F1EA]">£{n.issuedAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Coupon:</span>
                    <span className="text-[#C68B45] font-semibold">{n.couponAnnualPct}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Maturity:</span>
                    <span className="text-[#F4F1EA]">{n.maturityDate} ({n.maturityYears}y)</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Electronic Term Sheet Modal */}
      {termSheetModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#0A0D14]/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="stone-panel p-6 rounded-sm border border-[#C68B45]/60 max-w-2xl w-full space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-[#1F2735] pb-3">
              <h3 className="text-base font-serif font-bold text-[#F4F1EA]">
                Electronic Term Sheet Execution
              </h3>
              <button
                onClick={() => setTermSheetModalOpen(false)}
                className="text-[#8B9BB4] hover:text-[#F4F1EA] text-sm font-mono"
              >
                ✕
              </button>
            </div>

            <pre className="p-4 bg-[#0A0D14] border border-[#1F2735] text-[#D8D1C5] font-mono text-xs overflow-x-auto max-h-96 rounded-sm whitespace-pre-wrap leading-relaxed">
              {activeTermSheetText}
            </pre>

            <div className="flex justify-end gap-2 pt-2 border-t border-[#1F2735]">
              <button
                onClick={() => setTermSheetModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold bg-[#C68B45] text-[#0F141C] rounded-sm"
              >
                Confirm & Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
