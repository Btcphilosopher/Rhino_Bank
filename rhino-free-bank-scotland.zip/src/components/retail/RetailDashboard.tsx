/**
 * RHINO FREE BANK SCOTLAND
 * Retail Banking Dashboard & Payment Card Operations
 */

import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import cardImage from '../../assets/images/rhino_private_card_1790502604292.jpg';

export const RetailDashboard: React.FC = () => {
  const {
    accounts,
    cards,
    transactions,
    processTransfer,
    activeCausalPayment,
    toggleCardFreeze,
    updateCardLimit,
    toggleCardFeature,
  } = useBank();

  const [transferModalOpen, setTransferModalOpen] = useState(false);
  const [recipientName, setRecipientName] = useState('');
  const [recipientAccount, setRecipientAccount] = useState('');
  const [transferAmount, setTransferAmount] = useState('');
  const [selectedAccountId, setSelectedAccountId] = useState(accounts[0]?.id || 'acc-retail-curr');
  const [transferType, setTransferType] = useState<'FASTER_PAYMENTS' | 'RSD_TRANSFER' | 'CARD_PURCHASE'>('FASTER_PAYMENTS');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const currentAccount = accounts.find(a => a.type === 'CURRENT') || accounts[0];
  const savingsAccounts = accounts.filter(a => a.type !== 'CURRENT' && a.type !== 'RSD_WALLET');
  const primaryCard = cards[0];

  const totalRetailLiquidity = accounts
    .filter(a => a.type === 'CURRENT' || a.type.includes('SAVINGS') || a.type.includes('ISA') || a.type.includes('NOTICE') || a.type.includes('FIXED'))
    .reduce((sum, a) => sum + a.balance, 0);

  const handleExecutePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(transferAmount);
    if (isNaN(amountNum) || amountNum <= 0) return;

    setIsSubmitting(true);
    try {
      await processTransfer({
        fromAccountId: selectedAccountId,
        toAccountName: recipientName || 'Edinburgh Merchant Syndicate',
        toAccountDetails: recipientAccount || '80-22-19 / 491028',
        amount: amountNum,
        currency: 'GBP',
        paymentType: transferType,
        category: 'COMMERCE',
      });
      setTransferModalOpen(false);
      setRecipientName('');
      setRecipientAccount('');
      setTransferAmount('');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Welcome & Total Liquidity Header */}
      <div className="stone-panel p-6 rounded-sm border border-[#252E3D]">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-[#C68B45] uppercase tracking-wider mb-1">
              RETAIL ACCOUNT · EDINBURGH CLIENT ID #88492
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F4F1EA] tracking-tight">
              Good morning, Alexander
            </h1>
            <p className="text-xs text-[#9DAEC2] mt-1">
              Scottish Current & Multi-Reserve Balances · Real-Time Clearing Active
            </p>
          </div>

          <div className="text-left md:text-right">
            <div className="text-xs text-[#8B9BB4]">Total Retail Liquidity</div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-[#F4F1EA] tabular-nums tracking-tight">
              £{totalRetailLiquidity.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-[#22C55E] font-mono mt-0.5">
              +£1,240.50 interest accrued this period
            </div>
          </div>
        </div>

        {/* Primary Action Buttons */}
        <div className="flex flex-wrap gap-2 pt-5 mt-5 border-t border-[#1F2735]">
          <button
            onClick={() => {
              setTransferType('FASTER_PAYMENTS');
              setTransferModalOpen(true);
            }}
            className="px-4 py-2 text-xs font-semibold text-[#0F141C] bg-[#C68B45] hover:bg-[#D89B55] rounded-sm transition-colors whitespace-nowrap"
          >
            Send Payment (Faster Payments)
          </button>
          <button
            onClick={() => {
              setTransferType('RSD_TRANSFER');
              setTransferModalOpen(true);
            }}
            className="px-4 py-2 text-xs font-medium text-[#F4F1EA] bg-[#1A222F] hover:bg-[#232D3E] border border-[#2F3C4F] rounded-sm transition-colors whitespace-nowrap"
          >
            Transfer to RSD Digital Wallet
          </button>
          <button
            onClick={() => {
              setRecipientName('George Street Merchant');
              setTransferAmount('125.00');
              setTransferType('CARD_PURCHASE');
              setTransferModalOpen(true);
            }}
            className="px-4 py-2 text-xs font-medium text-[#9DAEC2] hover:text-[#F4F1EA] bg-[#141A24] hover:bg-[#1C2533] border border-[#232B38] rounded-sm transition-colors whitespace-nowrap"
          >
            Simulate Card Payment
          </button>
        </div>
      </div>

      {/* Main Grid: Accounts Ledger & Physical/Virtual Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Main Accounts & Savings Breakdown */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Main Scottish Current Account Card */}
          <div className="stone-panel p-5 rounded-sm border border-[#252E3D]">
            <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
              <div>
                <span className="text-xs font-serif font-bold text-[#F4F1EA] block">
                  {currentAccount.name}
                </span>
                <span className="text-[11px] font-mono text-[#8B9BB4]">
                  Sort Code: {currentAccount.sortCode} · Acc: {currentAccount.accountNumber}
                </span>
              </div>
              <span className="text-xs font-mono text-[#22C55E]">
                {currentAccount.interestRateAnnual}% AER
              </span>
            </div>

            <div className="py-4 flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
              <div>
                <span className="text-xs text-[#8B9BB4] block">Available Balance</span>
                <span className="text-3xl font-mono font-bold text-[#F4F1EA] tabular-nums">
                  £{currentAccount.balance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="text-xs font-mono text-[#8B9BB4]">
                <span>Annual Projected Interest: </span>
                <span className="text-[#D8D1C5]">£{currentAccount.projectedInterestAnnual.toFixed(2)}</span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-3 border-t border-[#1F2735] text-xs font-mono">
              <div className="bg-[#121721] p-2.5 rounded-sm">
                <span className="text-[#5A697E] block text-[10px]">MONTHLY INFLOW</span>
                <span className="text-[#F4F1EA] font-semibold">£6,500.00</span>
              </div>
              <div className="bg-[#121721] p-2.5 rounded-sm">
                <span className="text-[#5A697E] block text-[10px]">MONTHLY SPEND</span>
                <span className="text-[#F4F1EA] font-semibold">£2,140.20</span>
              </div>
              <div className="bg-[#121721] p-2.5 rounded-sm">
                <span className="text-[#5A697E] block text-[10px]">ACTIVE STANDING ORDERS</span>
                <span className="text-[#F4F1EA] font-semibold">4 Active</span>
              </div>
            </div>
          </div>

          {/* Scottish Savings & Reserve Accounts */}
          <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
                Scottish Savings & Fixed Capital Accounts
              </h2>
              <span className="text-xs font-mono text-[#C68B45]">
                5 Active Products
              </span>
            </div>

            <div className="divide-y divide-[#1F2735]">
              {savingsAccounts.map(acc => (
                <div key={acc.id} className="py-3.5 flex items-center justify-between gap-4">
                  <div>
                    <div className="text-xs font-semibold text-[#F4F1EA]">{acc.name}</div>
                    <div className="text-[11px] font-mono text-[#8B9BB4] flex items-center gap-2 mt-0.5">
                      <span>{acc.sortCode} / {acc.accountNumber}</span>
                      <span>·</span>
                      <span className="text-[#C68B45]">{acc.interestRateAnnual}% Interest Rate</span>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-sm font-mono font-bold text-[#F4F1EA] tabular-nums">
                      £{acc.balance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                    </div>
                    <div className="text-[10px] font-mono text-[#8B9BB4]">
                      +£{acc.accruedInterest.toFixed(2)} accrued
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Retail Transactions Ledger */}
          <div className="stone-panel p-5 rounded-sm border border-[#252E3D]">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
                Recent Account Activity & Settlement
              </h2>
              <span className="text-xs font-mono text-[#8B9BB4]">
                Automated PoS Ledger Clearance
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-[#1F2735] text-[#5A697E] text-[10px] uppercase">
                    <th className="pb-2 font-medium">Timestamp</th>
                    <th className="pb-2 font-medium">Counterparty / Description</th>
                    <th className="pb-2 font-medium">Type</th>
                    <th className="pb-2 font-medium">Block</th>
                    <th className="pb-2 font-medium text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1F2735]">
                  {transactions.slice(0, 6).map(tx => (
                    <tr key={tx.id} className="hover:bg-[#141B26] transition-colors">
                      <td className="py-2.5 text-[#8B9BB4]">{tx.timestamp.substring(11)}</td>
                      <td className="py-2.5 text-[#E6EDF3] font-sans font-medium">{tx.payeeName}</td>
                      <td className="py-2.5 text-[#9DAEC2]">{tx.type.replace('_', ' ')}</td>
                      <td className="py-2.5 text-[#C68B45]">#{tx.validatorBlockHeight}</td>
                      <td className="py-2.5 text-right font-bold text-[#F4F1EA] tabular-nums">
                        {tx.currency === 'RSD' ? 'RSD ' : '£'}
                        {tx.amount.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* Right Col: Rhino Card Dashboard & Spend Controls */}
        <div className="space-y-6">
          
          {/* Physical Titanium Card Graphic */}
          <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-[#C68B45] uppercase">
                {primaryCard.tier.replace('_', ' ')}
              </span>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded-sm ${primaryCard.isFrozen ? 'bg-red-950/80 text-red-400' : 'bg-emerald-950/80 text-emerald-400'}`}>
                {primaryCard.isFrozen ? 'CARD FROZEN' : 'ACTIVE & VERIFIED'}
              </span>
            </div>

            {/* High-Fidelity Card Visual */}
            <div className="relative overflow-hidden rounded-sm border border-[#C68B45]/40 shadow-lg">
              <img
                src={cardImage}
                alt="Rhino Private Bank Titanium Card"
                referrerPolicy="no-referrer"
                className="w-full h-48 object-cover brightness-90 contrast-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0D14]/90 via-transparent to-transparent p-4 flex flex-col justify-between">
                <div className="flex justify-between items-start">
                  <span className="font-serif font-bold text-xs text-[#F4F1EA] tracking-wider">
                    RHINO FREE BANK SCOTLAND
                  </span>
                  <span className="font-mono text-[10px] text-[#C68B45]">
                    {primaryCard.cardType.replace('_', ' ')}
                  </span>
                </div>
                <div>
                  <div className="font-mono text-base tracking-widest text-[#F4F1EA] font-semibold">
                    {primaryCard.cardNumberMasked}
                  </div>
                  <div className="flex justify-between items-end mt-1 text-[11px] font-mono text-[#9DAEC2]">
                    <span>{primaryCard.cardholderName}</span>
                    <span>EXP {primaryCard.expiry}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Card Controls */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-[#9DAEC2]">Card Status</span>
                <button
                  onClick={() => toggleCardFreeze(primaryCard.id)}
                  className={`px-3 py-1 text-xs font-mono rounded-sm transition-colors ${
                    primaryCard.isFrozen
                      ? 'bg-[#22C55E] text-[#0F141C] font-semibold'
                      : 'bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/30 hover:bg-[#EF4444]/30'
                  }`}
                >
                  {primaryCard.isFrozen ? 'Unfreeze Card' : 'Freeze Card'}
                </button>
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-[#9DAEC2]">Contactless Payments</span>
                <button
                  onClick={() => toggleCardFeature(primaryCard.id, 'contactless')}
                  className={`text-xs font-mono ${primaryCard.contactlessEnabled ? 'text-[#22C55E]' : 'text-[#8B9BB4]'}`}
                >
                  {primaryCard.contactlessEnabled ? 'Enabled' : 'Disabled'}
                </button>
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-[#9DAEC2]">Online & Foreign POS</span>
                <button
                  onClick={() => toggleCardFeature(primaryCard.id, 'online')}
                  className={`text-xs font-mono ${primaryCard.onlinePaymentsEnabled ? 'text-[#22C55E]' : 'text-[#8B9BB4]'}`}
                >
                  {primaryCard.onlinePaymentsEnabled ? 'Enabled' : 'Disabled'}
                </button>
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-[#9DAEC2]">ATM Cash Withdrawals</span>
                <button
                  onClick={() => toggleCardFeature(primaryCard.id, 'atm')}
                  className={`text-xs font-mono ${primaryCard.atmWithdrawalsEnabled ? 'text-[#22C55E]' : 'text-[#8B9BB4]'}`}
                >
                  {primaryCard.atmWithdrawalsEnabled ? 'Enabled' : 'Disabled'}
                </button>
              </div>

              {/* Monthly Spend Meter */}
              <div className="pt-2 border-t border-[#1F2735]">
                <div className="flex justify-between text-xs font-mono mb-1">
                  <span className="text-[#8B9BB4]">Monthly Spend</span>
                  <span className="text-[#F4F1EA]">
                    £{primaryCard.monthlySpent.toLocaleString()} / £{primaryCard.monthlySpendLimit.toLocaleString()}
                  </span>
                </div>
                <div className="w-full h-1.5 bg-[#141A24] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#C68B45]"
                    style={{ width: `${(primaryCard.monthlySpent / primaryCard.monthlySpendLimit) * 100}%` }}
                  ></div>
                </div>
              </div>

              {/* Wallet Integration Simulation */}
              <div className="pt-2 flex gap-2">
                <div className="flex-1 bg-[#121721] p-2 text-center rounded-sm border border-[#1F2735] text-[11px] font-mono text-[#9DAEC2]">
                   Apple Pay Active
                </div>
                <div className="flex-1 bg-[#121721] p-2 text-center rounded-sm border border-[#1F2735] text-[11px] font-mono text-[#9DAEC2]">
                  G Google Wallet Active
                </div>
              </div>
            </div>

          </div>

          {/* Mortgage & Property Twin Overview */}
          <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-3">
            <span className="text-xs font-mono text-[#C68B45] uppercase">
              MORTGAGE DIGITAL TWIN
            </span>
            <h3 className="text-sm font-serif font-bold text-[#F4F1EA]">
              Edinburgh New Town Residential Facility
            </h3>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1">
              <div>
                <span className="text-[#5A697E] block text-[10px]">PROPERTY VALUATION</span>
                <span className="text-[#F4F1EA] font-semibold">£740,000.00</span>
              </div>
              <div>
                <span className="text-[#5A697E] block text-[10px]">OUTSTANDING BALANCE</span>
                <span className="text-[#F4F1EA] font-semibold">£412,800.00</span>
              </div>
              <div>
                <span className="text-[#5A697E] block text-[10px]">CURRENT LTV</span>
                <span className="text-[#22C55E] font-semibold">55.78% (Prime)</span>
              </div>
              <div>
                <span className="text-[#5A697E] block text-[10px]">MORTGAGE RATE</span>
                <span className="text-[#C68B45] font-semibold">4.85% (5-Yr Fixed)</span>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Causal Payment Simulation Tracker (Appears when payment is executing) */}
      {activeCausalPayment && (
        <div className="fixed inset-0 z-50 bg-[#0A0D14]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="stone-panel p-6 rounded-sm border border-[#C68B45]/50 max-w-xl w-full space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-[#1F2735] pb-3">
              <div>
                <span className="text-[10px] font-mono text-[#C68B45] uppercase tracking-wider block">
                  RHINO CAUSAL SETTLEMENT ENGINE
                </span>
                <h3 className="text-base font-serif font-bold text-[#F4F1EA]">
                  Clearing {activeCausalPayment.transaction.currency} {activeCausalPayment.transaction.amount.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                </h3>
              </div>
              <span className="text-xs font-mono text-[#8B9BB4]">
                Block #{activeCausalPayment.transaction.validatorBlockHeight}
              </span>
            </div>

            <div className="space-y-2 font-mono text-xs">
              {activeCausalPayment.steps.map((step, idx) => (
                <div
                  key={step.step}
                  className={`p-2.5 rounded-sm border flex items-center justify-between transition-all ${
                    step.status === 'COMPLETED'
                      ? 'bg-[#121F17] border-emerald-900/60 text-emerald-300'
                      : step.status === 'PROCESSING'
                      ? 'bg-[#221B12] border-amber-900/80 text-amber-200 animate-pulse'
                      : 'bg-[#12161F] border-[#1D2533] text-[#5A697E]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] bg-black/40 border border-current">
                      {idx + 1}
                    </span>
                    <div>
                      <span className="font-semibold block">{step.step.replace(/_/g, ' ')}</span>
                      <span className="text-[10px] opacity-80">{step.detail}</span>
                    </div>
                  </div>
                  <span className="text-[10px] shrink-0">{step.latencyMs}ms</span>
                </div>
              ))}
            </div>

            {activeCausalPayment.isComplete && (
              <div className="pt-2 text-center">
                <button
                  onClick={() => window.location.reload()}
                  className="px-4 py-2 text-xs font-semibold bg-[#C68B45] text-[#0F141C] rounded-sm"
                >
                  Close & Reconcile Ledger
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Transfer Modal */}
      {transferModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#0A0D14]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="stone-panel p-6 rounded-sm border border-[#252E3D] max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-[#1F2735] pb-3">
              <h3 className="text-base font-serif font-bold text-[#F4F1EA]">
                Send Scottish Payment
              </h3>
              <button
                onClick={() => setTransferModalOpen(false)}
                className="text-[#8B9BB4] hover:text-[#F4F1EA] text-sm font-mono"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleExecutePayment} className="space-y-3 font-mono text-xs">
              <div>
                <label className="text-[#8B9BB4] block mb-1">Debiting Account</label>
                <select
                  value={selectedAccountId}
                  onChange={(e) => setSelectedAccountId(e.target.value)}
                  className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
                >
                  {accounts.map(a => (
                    <option key={a.id} value={a.id}>
                      {a.name} — £{a.balance.toLocaleString()}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[#8B9BB4] block mb-1">Recipient Name / Merchant</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Edinburgh Distillers Guild"
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
                />
              </div>

              <div>
                <label className="text-[#8B9BB4] block mb-1">Account & Sort Code / RSD Alias</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 80-22-19 / 839201"
                  value={recipientAccount}
                  onChange={(e) => setRecipientAccount(e.target.value)}
                  className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA]"
                />
              </div>

              <div>
                <label className="text-[#8B9BB4] block mb-1">Amount (£ GBP)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  required
                  placeholder="0.00"
                  value={transferAmount}
                  onChange={(e) => setTransferAmount(e.target.value)}
                  className="w-full bg-[#121721] border border-[#252E3D] rounded-sm p-2 text-[#F4F1EA] text-base font-bold"
                />
              </div>

              <div className="pt-3 border-t border-[#1F2735] flex gap-2 justify-end">
                <button
                  type="button"
                  onClick={() => setTransferModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-[#8B9BB4] hover:text-[#F4F1EA]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-xs font-semibold bg-[#C68B45] hover:bg-[#D89B55] text-[#0F141C] rounded-sm transition-colors"
                >
                  {isSubmitting ? 'Authenticating...' : 'Authorize Settlement'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
