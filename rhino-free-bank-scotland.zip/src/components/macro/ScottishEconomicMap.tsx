/**
 * RHINO FREE BANK SCOTLAND
 * Scottish Regional Economic Map & Edinburgh Financial Centre Digital Twin
 */

import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import { MacroShockType } from '../../services/macroEconomicEngine';
import skylineImage from '../../assets/images/edinburgh_skyline_financial_1790502616241.jpg';

export const ScottishEconomicMap: React.FC = () => {
  const {
    macro,
    regions,
    applyMacroShock
  } = useBank();

  const [selectedRegion, setSelectedRegion] = useState(regions[0]);
  const [activeShockType, setActiveShockType] = useState<MacroShockType>(macro.activeScenarioName);
  const [causalLogs, setCausalLogs] = useState<string[]>([]);

  const handleTriggerShock = (type: MacroShockType) => {
    setActiveShockType(type);
    const result = applyMacroShock(type);
    setCausalLogs(result.causalChain);
  };

  return (
    <div className="space-y-6">
      
      {/* Macro Master Strip */}
      <div className="stone-panel p-6 rounded-sm border border-[#252E3D]">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-[#C68B45] uppercase tracking-wider mb-1">
              SCOTTISH REGIONAL CORRIDOR · MACROECONOMIC SHOCK ENGINE
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F4F1EA] tracking-tight">
              Scottish Financial Map & Digital Twin
            </h1>
            <p className="text-xs text-[#9DAEC2] mt-1">
              6 Regional Economic Hubs · Causal Macroeconomic Stress Transmission Engine
            </p>
          </div>

          <div className="text-left md:text-right">
            <div className="text-xs text-[#8B9BB4]">Bank of England Base Rate</div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-[#C68B45] tabular-nums tracking-tight">
              {macro.bankRatePct.toFixed(2)}%
            </div>
            <div className="text-[11px] text-[#22C55E] font-mono mt-0.5">
              Scotland GDP Growth: {macro.scotlandGdpGrowthPct}% · Inflation {macro.scotlandInflationCpiPct}%
            </div>
          </div>
        </div>

        {/* Macro Shock Scenario Selector */}
        <div className="pt-5 mt-5 border-t border-[#1F2735] space-y-2">
          <span className="text-[10px] font-mono text-[#8B9BB4] uppercase block">
            Inject Macroeconomic Shock Scenario (Deterministic Causal Propagation)
          </span>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => handleTriggerShock('BASELINE_STABLE')}
              className={`px-3 py-1.5 text-xs font-mono rounded-sm transition-colors ${
                macro.activeScenarioName === 'BASELINE_STABLE'
                  ? 'bg-[#C68B45] text-[#0F141C] font-semibold'
                  : 'bg-[#121721] text-[#8B9BB4] border border-[#1F2735] hover:text-[#F4F1EA]'
              }`}
            >
              Baseline Stable (4.50%)
            </button>
            <button
              onClick={() => handleTriggerShock('RATE_HIKE_100BP')}
              className={`px-3 py-1.5 text-xs font-mono rounded-sm transition-colors ${
                macro.activeScenarioName === 'RATE_HIKE_100BP'
                  ? 'bg-[#EF4444] text-[#F4F1EA] font-semibold'
                  : 'bg-[#121721] text-[#8B9BB4] border border-[#1F2735] hover:text-[#F4F1EA]'
              }`}
            >
              Rate Hike +100bp (5.50%)
            </button>
            <button
              onClick={() => handleTriggerShock('RATE_CUT_50BP')}
              className={`px-3 py-1.5 text-xs font-mono rounded-sm transition-colors ${
                macro.activeScenarioName === 'RATE_CUT_50BP'
                  ? 'bg-[#22C55E] text-[#0F141C] font-semibold'
                  : 'bg-[#121721] text-[#8B9BB4] border border-[#1F2735] hover:text-[#F4F1EA]'
              }`}
            >
              Rate Cut -50bp (4.00%)
            </button>
            <button
              onClick={() => handleTriggerShock('NORTH_SEA_ENERGY_SURGE')}
              className={`px-3 py-1.5 text-xs font-mono rounded-sm transition-colors ${
                macro.activeScenarioName === 'NORTH_SEA_ENERGY_SURGE'
                  ? 'bg-[#3B82F6] text-[#F4F1EA] font-semibold'
                  : 'bg-[#121721] text-[#8B9BB4] border border-[#1F2735] hover:text-[#F4F1EA]'
              }`}
            >
              North Sea Energy Surge (Oil $98)
            </button>
            <button
              onClick={() => handleTriggerShock('SCOTTISH_PROPERTY_STRESS')}
              className={`px-3 py-1.5 text-xs font-mono rounded-sm transition-colors ${
                macro.activeScenarioName === 'SCOTTISH_PROPERTY_STRESS'
                  ? 'bg-purple-600 text-white font-semibold'
                  : 'bg-[#121721] text-[#8B9BB4] border border-[#1F2735] hover:text-[#F4F1EA]'
              }`}
            >
              Property Stress (-4.2% HPI)
            </button>
          </div>
        </div>
      </div>

      {/* Causal Shock Step Progression Box */}
      {causalLogs.length > 0 && (
        <div className="stone-panel p-5 rounded-sm border border-[#C68B45]/50 space-y-2 bg-[#141B26]">
          <span className="text-xs font-mono text-[#C68B45] uppercase font-bold">
            CAUSAL SHOCK PROPAGATION CHAIN · {macro.activeScenarioName}
          </span>
          <div className="space-y-1 text-xs font-mono text-[#D8D1C5]">
            {causalLogs.map((log, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className="text-[#C68B45]">→</span>
                <span>{log}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Grid: Scottish Regional Map & Edinburgh Financial District Twin */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Scottish Regional Grid */}
        <div className="lg:col-span-2 stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
            <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
              Scottish Economic Corridor Hubs
            </h2>
            <span className="text-xs font-mono text-[#8B9BB4]">
              Select a city for local credit & deposit analytics
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 font-mono text-xs">
            {regions.map(r => (
              <div
                key={r.id}
                onClick={() => setSelectedRegion(r)}
                className={`p-3.5 rounded-sm border cursor-pointer transition-all ${
                  selectedRegion.id === r.id
                    ? 'bg-[#1B2330] border-[#C68B45]/70 shadow-md'
                    : 'bg-[#121721] border-[#1F2735] hover:border-[#2D3A4E]'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="font-bold text-[#F4F1EA] text-sm">
                    {r.city}
                  </span>
                  <span className="text-[10px] text-[#22C55E]">
                    +{r.creditGrowthRatePct}% Growth
                  </span>
                </div>

                <div className="text-[11px] text-[#8B9BB4] space-y-1">
                  <div className="flex justify-between">
                    <span>Deposits:</span>
                    <span className="text-[#F4F1EA] font-semibold">£{(r.totalRhinoDeposits / 1000000).toFixed(0)}M</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Lending:</span>
                    <span className="text-[#F4F1EA]">£{(r.totalRhinoLending / 1000000).toFixed(0)}M</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Default Rate:</span>
                    <span className="text-[#C68B45]">{r.defaultRatePct}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Active Clients:</span>
                    <span className="text-[#E6EDF3]">{r.activeCommercialClients}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Regional Industry Tags */}
          <div className="pt-3 border-t border-[#1F2735] font-mono text-xs">
            <span className="text-[#8B9BB4] block mb-2">
              Dominant Economic Sectors in {selectedRegion.city}:
            </span>
            <div className="flex flex-wrap gap-2">
              {selectedRegion.dominantIndustries.map((ind, i) => (
                <span key={i} className="px-2.5 py-1 bg-[#121721] border border-[#1F2735] text-[#D8D1C5] text-[11px] rounded-xs">
                  {ind}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Edinburgh Financial Centre Virtual Twin */}
        <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
            <h3 className="text-base font-serif font-bold text-[#F4F1EA]">
              Edinburgh Financial Centre
            </h3>
            <span className="text-xs font-mono text-[#C68B45]">
              Virtual Twin
            </span>
          </div>

          <div className="relative overflow-hidden rounded-sm border border-[#C68B45]/40 shadow-lg">
            <img
              src={skylineImage}
              alt="Edinburgh Financial District Skyline"
              referrerPolicy="no-referrer"
              className="w-full h-44 object-cover brightness-95 contrast-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0A0D14]/90 via-transparent to-transparent p-3 flex flex-col justify-between">
              <span className="text-[10px] font-mono text-[#C68B45]">
                EDINBURGH NEW TOWN & CALTON SECTOR
              </span>
              <div>
                <h4 className="text-sm font-serif font-bold text-[#F4F1EA]">
                  St Andrew Square Headquarters
                </h4>
                <span className="text-[10px] font-mono text-[#9DAEC2]">
                  Clearing Hub · Sovereign Note Archive · Primary Vault
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-2 text-xs font-mono divide-y divide-[#1F2735]">
            <div className="flex justify-between py-1.5">
              <span className="text-[#8B9BB4]">St Andrew Square:</span>
              <span className="text-[#F4F1EA] font-semibold">Executive HQ & Capital Markets</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-[#8B9BB4]">Charlotte Square:</span>
              <span className="text-[#F4F1EA]">Rhino Private Wealth & Estates</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-[#8B9BB4]">George Street:</span>
              <span className="text-[#F4F1EA]">Commercial Treasury & FX Desk</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-[#8B9BB4]">Waverley Hub:</span>
              <span className="text-[#F4F1EA]">RSD Transit & Retail Clearing</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
