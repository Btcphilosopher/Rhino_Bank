/**
 * RHINO FREE BANK SCOTLAND
 * Proof-of-Stake Consensus Control Room & Validator Economics Terminal
 */

import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import { ValidatorNodeTwin } from '../../types/financial';
import { ValidatorEngineService } from '../../services/validatorEngine';

export const ValidatorControlRoom: React.FC = () => {
  const {
    validators,
    posNetwork,
    toggleValidatorStatus,
    toggleByzantineFault,
    stakeRSD,
  } = useBank();

  const [selectedValidator, setSelectedValidator] = useState<ValidatorNodeTwin>(validators[0]);
  const [stakeInput, setStakeInput] = useState('500000');
  const [stakeSuccessMsg, setStakeSuccessMsg] = useState('');

  const economics = ValidatorEngineService.calculateValidatorEconomics(
    selectedValidator,
    posNetwork.totalNetworkStake
  );

  const handleDelegateStake = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(stakeInput);
    if (isNaN(amt) || amt <= 0) return;

    stakeRSD(selectedValidator.id, amt);
    setStakeSuccessMsg(`Delegated RSD ${amt.toLocaleString()} stake to ${selectedValidator.name}`);
    setStakeInput('');
    setTimeout(() => setStakeSuccessMsg(''), 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Validator Grid Master Telemetry Cockpit */}
      <div className="stone-panel p-6 rounded-sm border border-[#252E3D]">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-[#C68B45] uppercase tracking-wider mb-1">
              RHINO STERLING VALIDATION NETWORK · PROOF-OF-STAKE CONSENSUS GRID
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F4F1EA] tracking-tight">
              Validator Control Room
            </h1>
            <p className="text-xs text-[#9DAEC2] mt-1">
              Simulated 9-Node European Optical Ring · LMD-GHOST Finality & Slashing Protection
            </p>
          </div>

          <div className="text-left md:text-right">
            <div className="text-xs text-[#8B9BB4]">Total Network Stake</div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-[#C68B45] tabular-nums tracking-tight">
              RSD {posNetwork.totalNetworkStake.toLocaleString('en-GB')}
            </div>
            <div className="text-[11px] text-[#22C55E] font-mono mt-0.5">
              Consensus Health: {posNetwork.consensusHealthPct}% · Finality {posNetwork.finalityTimeSeconds}s
            </div>
          </div>
        </div>

        {/* Real-time Consensus Metric Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-5 mt-5 border-t border-[#1F2735] text-xs font-mono">
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">BLOCK HEIGHT</span>
            <span className="text-[#F4F1EA] font-bold text-sm">#{posNetwork.blockHeight}</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">ACTIVE EPOCH</span>
            <span className="text-[#F4F1EA] font-bold text-sm">Epoch {posNetwork.currentEpoch}</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">ACTIVE NODES</span>
            <span className="text-[#22C55E] font-bold text-sm">
              {posNetwork.activeValidatorsCount} / {validators.length} Online
            </span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">AVG RING LATENCY</span>
            <span className="text-[#F4F1EA] font-bold text-sm">{posNetwork.averageLatencyMs}ms</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">THROUGHPUT</span>
            <span className="text-[#C68B45] font-bold text-sm">{posNetwork.transactionsPerSecond} TPS</span>
          </div>
          <div className="bg-[#121721] p-3 rounded-sm">
            <span className="text-[#5A697E] block text-[10px]">TOTAL REWARDS</span>
            <span className="text-[#F4F1EA] font-bold text-sm">RSD {posNetwork.totalRewardsDistributed.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {stakeSuccessMsg && (
        <div className="p-3 bg-[#13231B] border border-emerald-800/60 text-emerald-300 text-xs font-mono rounded-sm">
          {stakeSuccessMsg}
        </div>
      )}

      {/* Main Grid: 9 Regional Nodes List & Node Inspector / R-Economics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: 9 Regional Validator Nodes Grid */}
        <div className="lg:col-span-2 stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
            <h2 className="text-base font-serif font-bold text-[#F4F1EA]">
              Regional Validator Node Grid
            </h2>
            <span className="text-xs font-mono text-[#8B9BB4]">
              Select a node to inspect telemetry & economics
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 font-mono text-xs">
            {validators.map(v => (
              <div
                key={v.id}
                onClick={() => setSelectedValidator(v)}
                className={`p-3.5 rounded-sm border cursor-pointer transition-all ${
                  selectedValidator.id === v.id
                    ? 'bg-[#1B2330] border-[#C68B45]/70 shadow-md'
                    : 'bg-[#121721] border-[#1F2735] hover:border-[#2D3A4E]'
                }`}
              >
                <div className="flex justify-between items-start mb-1.5">
                  <span className="font-bold text-[#F4F1EA] text-xs">
                    {v.city.toUpperCase()}
                  </span>
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded-xs font-semibold ${
                      v.status === 'ACTIVE'
                        ? 'bg-emerald-950/80 text-emerald-400'
                        : 'bg-red-950/80 text-red-400'
                    }`}
                  >
                    {v.status}
                  </span>
                </div>

                <div className="text-[11px] text-[#8B9BB4] space-y-1">
                  <div className="flex justify-between">
                    <span>Stake:</span>
                    <span className="text-[#F4F1EA] font-semibold">RSD {(v.stakeAmount / 1000000).toFixed(1)}M</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Share:</span>
                    <span className="text-[#C68B45]">{v.stakeSharePct.toFixed(1)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Uptime:</span>
                    <span className="text-[#22C55E]">{v.uptimePct}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Latency:</span>
                    <span className="text-[#F4F1EA]">{v.latencyMs}ms</span>
                  </div>
                </div>

                {v.isByzantineSimulated && (
                  <div className="mt-2 text-[10px] text-amber-400 font-bold bg-amber-950/40 p-1 rounded-xs border border-amber-800/40 text-center">
                    BYZANTINE FAULT ACTIVE
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Recent Blocks & Attestation Quorum Log */}
          <div className="pt-4 border-t border-[#1F2735]">
            <h3 className="text-xs font-mono text-[#8B9BB4] uppercase mb-3">
              Live Block Production & Quorum Attestations
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-[#1F2735] text-[#5A697E] text-[10px] uppercase">
                    <th className="pb-2 font-medium">Block</th>
                    <th className="pb-2 font-medium">Proposing Node</th>
                    <th className="pb-2 font-medium">Tx Count</th>
                    <th className="pb-2 font-medium">Block Hash</th>
                    <th className="pb-2 font-medium text-right">Attestation Score</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1F2735]">
                  {posNetwork.recentBlocks.map(blk => (
                    <tr key={blk.blockNumber} className="hover:bg-[#141B26] transition-colors">
                      <td className="py-2 text-[#C68B45] font-bold">#{blk.blockNumber}</td>
                      <td className="py-2 text-[#E6EDF3] font-sans font-medium">{blk.proposer}</td>
                      <td className="py-2 text-[#F4F1EA]">{blk.txCount} txs</td>
                      <td className="py-2 text-[#8B9BB4]">{blk.hash}</td>
                      <td className="py-2 text-right text-[#22C55E] font-semibold">{blk.attestationScorePct}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Col: Node Inspector, Fault Injection & R-Analytics Economics */}
        <div className="space-y-6">
          
          {/* Selected Node Details & Incident Testing */}
          <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#1F2735]">
              <h3 className="text-base font-serif font-bold text-[#F4F1EA]">
                Node Inspector: {selectedValidator.city}
              </h3>
              <span className="text-xs font-mono text-[#C68B45]">
                {selectedValidator.id}
              </span>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div className="bg-[#121721] p-3 rounded-sm border border-[#1F2735] space-y-1">
                <span className="text-[#5A697E] block text-[10px]">OPERATOR ENTITY</span>
                <span className="text-[#F4F1EA] font-semibold">{selectedValidator.operator}</span>
                <span className="text-[#8B9BB4] block text-[10px] mt-1">{selectedValidator.hardwareSpecs}</span>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <div className="bg-[#121721] p-2 rounded-sm">
                  <span className="text-[#5A697E] block text-[10px]">BLOCKS PROPOSED</span>
                  <span className="text-[#F4F1EA] font-semibold">{selectedValidator.blocksProposed.toLocaleString()}</span>
                </div>
                <div className="bg-[#121721] p-2 rounded-sm">
                  <span className="text-[#5A697E] block text-[10px]">ATTESTATIONS</span>
                  <span className="text-[#F4F1EA] font-semibold">{selectedValidator.attestationsCount.toLocaleString()}</span>
                </div>
                <div className="bg-[#121721] p-2 rounded-sm">
                  <span className="text-[#5A697E] block text-[10px]">MISSED ATTESTS</span>
                  <span className="text-[#EF4444] font-semibold">{selectedValidator.missedAttestations}</span>
                </div>
                <div className="bg-[#121721] p-2 rounded-sm">
                  <span className="text-[#5A697E] block text-[10px]">SLASH EVENTS</span>
                  <span className="text-[#22C55E] font-semibold">{selectedValidator.slashingCount}</span>
                </div>
              </div>

              {/* Synthetic Incident & Testing Controls */}
              <div className="pt-3 border-t border-[#1F2735] space-y-2">
                <span className="text-[10px] font-mono text-[#8B9BB4] block uppercase">
                  Fault Simulation & Chaos Testing
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={() => toggleValidatorStatus(selectedValidator.id)}
                    className={`flex-1 py-1.5 text-xs font-mono rounded-sm transition-colors ${
                      selectedValidator.status === 'ACTIVE'
                        ? 'bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/40 hover:bg-[#EF4444]/30'
                        : 'bg-[#22C55E] text-[#0F141C] font-semibold'
                    }`}
                  >
                    {selectedValidator.status === 'ACTIVE' ? 'Simulate Node Offline' : 'Restore Online'}
                  </button>
                  <button
                    onClick={() => toggleByzantineFault(selectedValidator.id)}
                    className={`flex-1 py-1.5 text-xs font-mono rounded-sm border transition-colors ${
                      selectedValidator.isByzantineSimulated
                        ? 'bg-amber-500 text-[#0F141C] font-bold border-amber-400'
                        : 'bg-[#121721] text-[#8B9BB4] border-[#1F2735] hover:text-[#F4F1EA]'
                    }`}
                  >
                    {selectedValidator.isByzantineSimulated ? 'Disable Byzantine' : 'Inject Byzantine Fault'}
                  </button>
                </div>
              </div>

              {/* Delegate Stake */}
              <form onSubmit={handleDelegateStake} className="pt-3 border-t border-[#1F2735] space-y-2">
                <span className="text-[10px] font-mono text-[#8B9BB4] block uppercase">
                  Delegate RSD Stake
                </span>
                <div className="flex gap-2">
                  <input
                    type="number"
                    step="10000"
                    min="1000"
                    placeholder="500,000"
                    value={stakeInput}
                    onChange={(e) => setStakeInput(e.target.value)}
                    className="flex-1 bg-[#121721] border border-[#252E3D] rounded-sm p-1.5 text-[#F4F1EA]"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 bg-[#C68B45] hover:bg-[#D89B55] text-[#0F141C] font-semibold rounded-sm text-xs"
                  >
                    Stake RSD
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* R-Analytics: Validator Economics Module */}
          <div className="stone-panel p-5 rounded-sm border border-[#252E3D] space-y-3">
            <span className="text-xs font-mono text-[#C68B45] uppercase">
              R-ANALYTICS · VALIDATOR ECONOMICS MODEL
            </span>
            <h3 className="text-sm font-serif font-bold text-[#F4F1EA]">
              Yield & Operational Profitability Derivation
            </h3>

            <div className="space-y-1.5 text-xs font-mono divide-y divide-[#1F2735]">
              <div className="flex justify-between py-1">
                <span className="text-[#8B9BB4]">Stake Weight ($w_i$):</span>
                <span className="text-[#F4F1EA] font-semibold">{economics.stakeSharePct}%</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#8B9BB4]">Est. Daily Block Proposals:</span>
                <span className="text-[#F4F1EA]">{economics.estimatedDailyBlocks} blocks/day</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#8B9BB4]">Est. Gross Rewards:</span>
                <span className="text-[#C68B45] font-semibold">RSD {economics.estimatedDailyGrossRSD}/day</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#8B9BB4]">Annual Gross Staking Yield:</span>
                <span className="text-[#22C55E] font-semibold">{economics.annualGrossYieldPct}%</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#8B9BB4]">Annual OpEx (H/W + Energy):</span>
                <span className="text-[#EF4444]">£{economics.estimatedAnnualOpCostGBP.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#8B9BB4]">Estimated Net Yield:</span>
                <span className="text-[#22C55E] font-bold">{economics.netYieldPct}% p.a.</span>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
