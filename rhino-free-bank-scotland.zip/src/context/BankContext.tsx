/**
 * RHINO FREE BANK SCOTLAND
 * Central Financial State & Machine Context
 */

import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import {
  AccountTwin,
  AuditEvent,
  BalanceSheetTwin,
  CausalPaymentStep,
  FXRateTwin,
  JournalEntry,
  MacroEconomicEnvironment,
  ModelGovernanceEntry,
  NoteOrder,
  PaymentCard,
  PoSNetworkState,
  PortfolioAssetTwin,
  PrivateNoteTwin,
  RegulatoryStatus,
  ScottishRegionTwin,
  TransactionTwin,
  ValidatorNodeTwin,
  AIIntelligenceResponse
} from '../types/financial';
import {
  INITIAL_ACCOUNTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_BALANCE_SHEET,
  INITIAL_CARDS,
  INITIAL_FX_RATES,
  INITIAL_JOURNAL_ENTRIES,
  INITIAL_MACRO,
  INITIAL_MODEL_REGISTRY,
  INITIAL_ORDERS,
  INITIAL_PORTFOLIO_ASSETS,
  INITIAL_POS_NETWORK,
  INITIAL_PRIVATE_NOTES,
  INITIAL_REGULATORY_STATUS,
  INITIAL_SCOTTISH_REGIONS,
  INITIAL_TRANSACTIONS,
  INITIAL_VALIDATORS
} from '../services/seedData';
import { FinancialLedgerService } from '../services/financialLedger';
import { ValidatorEngineService } from '../services/validatorEngine';
import { NoteStructureParams, PrivateNoteHouseService } from '../services/privateNoteHouse';
import { MacroEconomicEngineService, MacroShockType } from '../services/macroEconomicEngine';

interface BankContextType {
  regulatoryStatus: RegulatoryStatus;
  accounts: AccountTwin[];
  cards: PaymentCard[];
  transactions: TransactionTwin[];
  journalEntries: JournalEntry[];
  privateNotes: PrivateNoteTwin[];
  noteOrders: NoteOrder[];
  validators: ValidatorNodeTwin[];
  posNetwork: PoSNetworkState;
  balanceSheet: BalanceSheetTwin;
  macro: MacroEconomicEnvironment;
  regions: ScottishRegionTwin[];
  fxRates: FXRateTwin[];
  portfolioAssets: PortfolioAssetTwin[];
  modelRegistry: ModelGovernanceEntry[];
  auditLogs: AuditEvent[];
  activeCausalPayment: {
    transaction: TransactionTwin;
    steps: CausalPaymentStep[];
    currentStepIndex: number;
    isComplete: boolean;
  } | null;

  // Actions
  processTransfer: (params: {
    fromAccountId: string;
    toAccountName: string;
    toAccountDetails: string;
    amount: number;
    currency: string;
    paymentType: TransactionTwin['type'];
    category: TransactionTwin['category'];
  }) => Promise<TransactionTwin>;

  convertMoney: (params: {
    fromType: 'GBP_DEPOSIT' | 'RSD_DIGITAL' | 'NOTE_COLLATERAL';
    toType: 'GBP_DEPOSIT' | 'RSD_DIGITAL';
    amount: number;
  }) => Promise<void>;

  issuePrivateNote: (params: NoteStructureParams) => PrivateNoteTwin;
  placeNoteOrder: (order: Omit<NoteOrder, 'id' | 'timestamp' | 'status'>) => void;
  toggleValidatorStatus: (nodeId: string) => void;
  toggleByzantineFault: (nodeId: string) => void;
  stakeRSD: (nodeId: string, amount: number) => void;
  applyMacroShock: (shockType: MacroShockType) => { causalChain: string[] };
  toggleCardFreeze: (cardId: string) => void;
  updateCardLimit: (cardId: string, limit: number) => void;
  toggleCardFeature: (cardId: string, feature: 'contactless' | 'online' | 'atm') => void;
  queryIntelligence: (query: string) => Promise<AIIntelligenceResponse>;
}

const BankContext = createContext<BankContextType | undefined>(undefined);

export const BankProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [regulatoryStatus] = useState<RegulatoryStatus>(INITIAL_REGULATORY_STATUS);
  const [accounts, setAccounts] = useState<AccountTwin[]>(INITIAL_ACCOUNTS);
  const [cards, setCards] = useState<PaymentCard[]>(INITIAL_CARDS);
  const [transactions, setTransactions] = useState<TransactionTwin[]>(INITIAL_TRANSACTIONS);
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(INITIAL_JOURNAL_ENTRIES);
  const [privateNotes, setPrivateNotes] = useState<PrivateNoteTwin[]>(INITIAL_PRIVATE_NOTES);
  const [noteOrders, setNoteOrders] = useState<NoteOrder[]>(INITIAL_ORDERS);
  const [validators, setValidators] = useState<ValidatorNodeTwin[]>(INITIAL_VALIDATORS);
  const [posNetwork, setPosNetwork] = useState<PoSNetworkState>(INITIAL_POS_NETWORK);
  const [balanceSheet, setBalanceSheet] = useState<BalanceSheetTwin>(INITIAL_BALANCE_SHEET);
  const [macro, setMacro] = useState<MacroEconomicEnvironment>(INITIAL_MACRO);
  const [regions, setRegions] = useState<ScottishRegionTwin[]>(INITIAL_SCOTTISH_REGIONS);
  const [fxRates] = useState<FXRateTwin[]>(INITIAL_FX_RATES);
  const [portfolioAssets] = useState<PortfolioAssetTwin[]>(INITIAL_PORTFOLIO_ASSETS);
  const [modelRegistry] = useState<ModelGovernanceEntry[]>(INITIAL_MODEL_REGISTRY);
  const [auditLogs, setAuditLogs] = useState<AuditEvent[]>(INITIAL_AUDIT_LOGS);

  const [activeCausalPayment, setActiveCausalPayment] = useState<BankContextType['activeCausalPayment']>(null);

  // Background PoS Consensus Ticker (Simulates live blocks every 3.5 seconds)
  useEffect(() => {
    const interval = setInterval(() => {
      setPosNetwork(prevNetwork => {
        const result = ValidatorEngineService.processConsensusTick(prevNetwork, validators);
        setValidators(result.updatedValidators);
        return result.updatedNetwork;
      });
    }, 3500);

    return () => clearInterval(interval);
  }, [validators]);

  // Log an immutable audit entry
  const addAuditLog = useCallback((actionType: AuditEvent['actionType'], details: string, role: string = 'SYSTEM') => {
    const newEvent: AuditEvent = {
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      actor: 'RHINO_OPERATING_SYSTEM',
      role,
      actionType,
      details,
      immutableHash: '0x' + Array.from({ length: 16 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      verifiedStatus: 'CRYPTOGRAPHICALLY_VERIFIED',
    };
    setAuditLogs(prev => [newEvent, ...prev.slice(0, 49)]);
  }, []);

  // Process Transfer with Causal Animated Workflow
  const processTransfer = useCallback(async (params: {
    fromAccountId: string;
    toAccountName: string;
    toAccountDetails: string;
    amount: number;
    currency: string;
    paymentType: TransactionTwin['type'];
    category: TransactionTwin['category'];
  }): Promise<TransactionTwin> => {
    const fromAcc = accounts.find(a => a.id === params.fromAccountId) || accounts[0];
    const txId = `tx-${Date.now()}`;
    const blockHeight = posNetwork.blockHeight + 1;
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 19);

    const steps: CausalPaymentStep[] = [
      { step: 'AUTHENTICATION', status: 'PROCESSING', timestamp: nowStr, latencyMs: 14, detail: 'Cryptographic device signature & biometric auth check' },
      { step: 'MERCHANT_CHECK', status: 'PENDING', timestamp: nowStr, latencyMs: 22, detail: 'Account validation & sanctions screening' },
      { step: 'PAYMENT_ROUTER', status: 'PENDING', timestamp: nowStr, latencyMs: 18, detail: 'Routing through Rhino Edinburgh Core Settlement Engine' },
      { step: 'RSD_LEDGER', status: 'PENDING', timestamp: nowStr, latencyMs: 31, detail: 'Double-entry debit & subledger posting' },
      { step: 'VALIDATOR_CONSENSUS', status: 'PENDING', timestamp: nowStr, latencyMs: 45, detail: 'PoS Validator network attestation quorum (9/9 nodes)' },
      { step: 'FINALITY_ATTESTATION', status: 'PENDING', timestamp: nowStr, latencyMs: 12, detail: 'Block inclusion & cryptographic finality guarantee' },
      { step: 'MERCHANT_SETTLEMENT', status: 'PENDING', timestamp: nowStr, latencyMs: 8, detail: 'Funds available in recipient account' },
    ];

    const newTx: TransactionTwin = {
      id: txId,
      payerName: fromAcc.name,
      payerAccount: fromAcc.accountNumber,
      payeeName: params.toAccountName,
      payeeAccount: params.toAccountDetails,
      amount: params.amount,
      currency: params.currency,
      type: params.paymentType,
      category: params.category,
      timestamp: nowStr,
      status: 'PENDING',
      riskScore: Math.floor(Math.random() * 5) + 1,
      complianceCheck: 'PASSED',
      validatorBlockHeight: blockHeight,
      finalityTimestamp: nowStr,
      journalEntryId: `JRN-${Date.now()}`,
      causalSteps: steps,
    };

    setActiveCausalPayment({
      transaction: newTx,
      steps,
      currentStepIndex: 0,
      isComplete: false,
    });

    // Step-by-step causal animation progression
    for (let i = 0; i < steps.length; i++) {
      await new Promise(r => setTimeout(r, 220));
      steps[i].status = 'COMPLETED';
      if (i + 1 < steps.length) {
        steps[i + 1].status = 'PROCESSING';
      }
      setActiveCausalPayment(prev => prev ? {
        ...prev,
        steps: [...steps],
        currentStepIndex: i + 1,
        isComplete: i === steps.length - 1,
      } : null);
    }

    newTx.status = 'SETTLED';

    // Update Accounts
    setAccounts(prevAccs => prevAccs.map(acc => {
      if (acc.id === params.fromAccountId) {
        return {
          ...acc,
          balance: Math.round((acc.balance - params.amount) * 100) / 100,
          availableBalance: Math.round((acc.availableBalance - params.amount) * 100) / 100,
        };
      }
      return acc;
    }));

    // Post to Journal
    const journal = FinancialLedgerService.createJournalEntry(newTx, params.paymentType === 'RSD_TRANSFER' ? 'VALIDATOR' : 'CUSTOMER');
    setJournalEntries(prev => [journal, ...prev]);

    // Update Transactions list
    setTransactions(prev => [newTx, ...prev]);

    // Reconcile Balance Sheet
    setBalanceSheet(prevBS => FinancialLedgerService.reconcileBalanceSheet(prevBS));

    addAuditLog('TRANSACTION_SETTLED', `Settled ${params.currency} ${params.amount.toLocaleString()} from ${fromAcc.name} to ${params.toAccountName}.`);

    return newTx;
  }, [accounts, posNetwork.blockHeight, addAuditLog]);

  // Convert Money (Bank deposit <-> RSD)
  const convertMoney = useCallback(async (params: {
    fromType: 'GBP_DEPOSIT' | 'RSD_DIGITAL' | 'NOTE_COLLATERAL';
    toType: 'GBP_DEPOSIT' | 'RSD_DIGITAL';
    amount: number;
  }) => {
    const currAcc = accounts.find(a => a.type === 'CURRENT') || accounts[0];
    const rsdAcc = accounts.find(a => a.type === 'RSD_WALLET') || accounts[1];

    if (params.fromType === 'GBP_DEPOSIT' && params.toType === 'RSD_DIGITAL') {
      setAccounts(prev => prev.map(a => {
        if (a.id === currAcc.id) return { ...a, balance: a.balance - params.amount, availableBalance: a.availableBalance - params.amount };
        if (a.id === rsdAcc.id) return { ...a, balance: a.balance + params.amount, availableBalance: a.availableBalance + params.amount };
        return a;
      }));
      addAuditLog('TRANSACTION_SETTLED', `Converted £${params.amount.toLocaleString()} Bank Deposit to RSD Digital Sterling (1:1 par exchange).`);
    } else if (params.fromType === 'RSD_DIGITAL' && params.toType === 'GBP_DEPOSIT') {
      setAccounts(prev => prev.map(a => {
        if (a.id === rsdAcc.id) return { ...a, balance: a.balance - params.amount, availableBalance: a.availableBalance - params.amount };
        if (a.id === currAcc.id) return { ...a, balance: a.balance + params.amount, availableBalance: a.availableBalance + params.amount };
        return a;
      }));
      addAuditLog('TRANSACTION_SETTLED', `Converted RSD ${params.amount.toLocaleString()} Digital Sterling to Bank Deposit (1:1 par redemption).`);
    }
  }, [accounts, addAuditLog]);

  // Issue New Private Note
  const issuePrivateNote = useCallback((params: NoteStructureParams): PrivateNoteTwin => {
    const structuredNote = PrivateNoteHouseService.structureNewNote(params);
    setPrivateNotes(prev => [structuredNote, ...prev]);

    // Update Balance Sheet (Assets + Receivables, Liabilities + Issued Notes)
    setBalanceSheet(prevBS => {
      const updated = {
        ...prevBS,
        assets: {
          ...prevBS.assets,
          infrastructureReceivables: prevBS.assets.infrastructureReceivables + params.collateralValue,
          totalAssets: prevBS.assets.totalAssets + params.collateralValue,
        },
        liabilities: {
          ...prevBS.liabilities,
          issuedPrivateNotesObligations: prevBS.liabilities.issuedPrivateNotesObligations + params.issueSize,
          totalLiabilities: prevBS.liabilities.totalLiabilities + params.issueSize,
        }
      };
      return FinancialLedgerService.reconcileBalanceSheet(updated);
    });

    addAuditLog('NOTE_ISSUANCE', `Issued ${structuredNote.name} (${structuredNote.isin}) nominal £${(structuredNote.issuedAmount).toLocaleString()} with coupon ${structuredNote.couponAnnualPct}%.`);

    return structuredNote;
  }, [addAuditLog]);

  // Place Order on Note Order Book
  const placeNoteOrder = useCallback((order: Omit<NoteOrder, 'id' | 'timestamp' | 'status'>) => {
    const newOrder: NoteOrder = {
      ...order,
      id: `ord-${Date.now()}`,
      timestamp: new Date().toTimeString().substring(0, 8),
      status: 'OPEN',
    };
    setNoteOrders(prev => [newOrder, ...prev]);
    addAuditLog('TRANSACTION_SETTLED', `Placed Note Order: ${order.side} ${order.faceAmount.toLocaleString()} ${order.isin} @ ${order.pricePct}% (${order.participant}).`);
  }, [addAuditLog]);

  // Toggle Validator Status (Online / Offline)
  const toggleValidatorStatus = useCallback((nodeId: string) => {
    setValidators(prev => prev.map(v => {
      if (v.id === nodeId) {
        const nextStatus = v.status === 'ACTIVE' ? 'OFFLINE' : 'ACTIVE';
        addAuditLog('GOVERNANCE_OVERRIDE', `Validator ${v.name} status updated to ${nextStatus}.`);
        return { ...v, status: nextStatus };
      }
      return v;
    }));
  }, [addAuditLog]);

  // Toggle Byzantine Fault Mode
  const toggleByzantineFault = useCallback((nodeId: string) => {
    setValidators(prev => prev.map(v => {
      if (v.id === nodeId) {
        const nextMode = !v.isByzantineSimulated;
        addAuditLog('GOVERNANCE_OVERRIDE', `Byzantine fault simulation ${nextMode ? 'ENABLED' : 'DISABLED'} on ${v.name}.`);
        return { ...v, isByzantineSimulated: nextMode };
      }
      return v;
    }));
  }, [addAuditLog]);

  // Stake RSD to a validator node
  const stakeRSD = useCallback((nodeId: string, amount: number) => {
    setValidators(prev => prev.map(v => {
      if (v.id === nodeId) {
        return { ...v, stakeAmount: v.stakeAmount + amount };
      }
      return v;
    }));
    setAccounts(prev => prev.map(a => {
      if (a.type === 'RSD_WALLET') {
        return { ...a, balance: a.balance - amount, availableBalance: a.availableBalance - amount };
      }
      return a;
    }));
    addAuditLog('TRANSACTION_SETTLED', `Delegated Stake: RSD ${amount.toLocaleString()} to node ${nodeId}.`);
  }, [addAuditLog]);

  // Apply Macroeconomic Shock
  const applyMacroShock = useCallback((shockType: MacroShockType) => {
    const result = MacroEconomicEngineService.applyMacroShock(
      shockType,
      macro,
      balanceSheet,
      privateNotes,
      regions
    );

    setMacro(result.updatedMacro);
    setBalanceSheet(result.updatedBalanceSheet);
    setPrivateNotes(result.updatedNotes);
    setRegions(result.updatedRegions);

    addAuditLog('MACRO_SHOCK_APPLIED', `Applied Macro Shock Scenario: ${shockType}. Base rate ${result.updatedMacro.bankRatePct}%.`);

    return { causalChain: result.causalChainExplanation };
  }, [macro, balanceSheet, privateNotes, regions, addAuditLog]);

  // Card Controls
  const toggleCardFreeze = useCallback((cardId: string) => {
    setCards(prev => prev.map(c => {
      if (c.id === cardId) {
        const nextState = !c.isFrozen;
        addAuditLog('GOVERNANCE_OVERRIDE', `Card ${c.cardNumberMasked} ${nextState ? 'FROZEN' : 'UNFROZEN'}.`);
        return { ...c, isFrozen: nextState };
      }
      return c;
    }));
  }, [addAuditLog]);

  const updateCardLimit = useCallback((cardId: string, limit: number) => {
    setCards(prev => prev.map(c => c.id === cardId ? { ...c, monthlySpendLimit: limit } : c));
  }, []);

  const toggleCardFeature = useCallback((cardId: string, feature: 'contactless' | 'online' | 'atm') => {
    setCards(prev => prev.map(c => {
      if (c.id === cardId) {
        if (feature === 'contactless') return { ...c, contactlessEnabled: !c.contactlessEnabled };
        if (feature === 'online') return { ...c, onlinePaymentsEnabled: !c.onlinePaymentsEnabled };
        if (feature === 'atm') return { ...c, atmWithdrawalsEnabled: !c.atmWithdrawalsEnabled };
      }
      return c;
    }));
  }, []);

  // AI Financial Intelligence Query
  const queryIntelligence = useCallback(async (queryText: string): Promise<AIIntelligenceResponse> => {
    const snapshot = {
      institution: 'Rhino Free Bank Scotland',
      regulatoryStatus,
      balanceSheet: {
        totalAssets: `£${(balanceSheet.assets.totalAssets / 1000000).toFixed(1)}M`,
        totalLiabilities: `£${(balanceSheet.liabilities.totalLiabilities / 1000000).toFixed(1)}M`,
        totalEquity: `£${(balanceSheet.equity.totalEquity / 1000000).toFixed(1)}M`,
        cet1RatioPct: `${balanceSheet.metrics.cet1RatioSimulatedPct}%`,
        liquidityCoverageRatioPct: `${balanceSheet.metrics.liquidityCoverageRatioPct}%`,
        netInterestMarginPct: `${balanceSheet.metrics.netInterestMarginPct}%`,
        reconciliationDelta: `£${balanceSheet.reconciliationDelta}`,
      },
      macro: {
        bankRatePct: `${macro.bankRatePct}%`,
        scotlandGdpGrowthPct: `${macro.scotlandGdpGrowthPct}%`,
        scotlandInflationCpiPct: `${macro.scotlandInflationCpiPct}%`,
        unemploymentRatePct: `${macro.unemploymentRatePct}%`,
        activeScenario: macro.activeScenarioName,
      },
      flagshipNote: privateNotes.find(n => n.id === 'note-edi-01'),
      allNotesCount: privateNotes.length,
      posValidatorNetwork: {
        activeValidators: `${posNetwork.activeValidatorsCount} / ${validators.length}`,
        totalStakeRSD: `£${(posNetwork.totalNetworkStake / 1000000).toFixed(1)}M`,
        healthPct: `${posNetwork.consensusHealthPct}%`,
        blockHeight: posNetwork.blockHeight,
      },
      scottishRegions: regions.map(r => ({ city: r.city, deposits: `£${(r.totalRhinoDeposits / 1000000).toFixed(1)}M`, creditGrowth: `${r.creditGrowthRatePct}%` })),
    };

    try {
      const res = await fetch('/api/intelligence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: queryText, financialSnapshot: snapshot }),
      });

      if (!res.ok) {
        throw new Error(`Intelligence API returned ${res.status}`);
      }

      const data = await res.json();
      return data;
    } catch {
      // Robust client-side fallback if server offline or API key pending
      return {
        query: queryText,
        answer: `RHINO INTELLIGENCE ANALYSIS: Based on current balance sheet telemetry, Rhino Free Bank Scotland maintains £${(balanceSheet.assets.totalAssets / 1000000000).toFixed(2)}B in total assets with a CET1 prudential capital ratio of ${balanceSheet.metrics.cet1RatioSimulatedPct}% and an LCR of ${balanceSheet.metrics.liquidityCoverageRatioPct}%. The Proof-of-Stake validator grid operates with ${posNetwork.activeValidatorsCount}/${validators.length} nodes online and ${posNetwork.consensusHealthPct}% consensus health at Base Rate ${macro.bankRatePct}%.`,
        citations: [
          { source: 'Bank Balance Sheet', metric: 'Total Assets', value: `£${(balanceSheet.assets.totalAssets / 1000000000).toFixed(2)}B`, timestamp: balanceSheet.timestamp },
          { source: 'Prudential Capital', metric: 'CET1 Ratio', value: `${balanceSheet.metrics.cet1RatioSimulatedPct}%`, timestamp: balanceSheet.timestamp },
          { source: 'PoS Validator Grid', metric: 'Quorum Health', value: `${posNetwork.consensusHealthPct}%`, timestamp: 'Real-time' },
        ],
        calculationBreakdown: `CET1 Ratio = Total Tier 1 Equity (£${(balanceSheet.equity.totalEquity / 1000000).toFixed(1)}M) / Risk-Weighted Assets (£${((balanceSheet.assets.totalAssets * 0.48) / 1000000).toFixed(1)}M) = ${balanceSheet.metrics.cet1RatioSimulatedPct}%.`,
        underlyingAssumptions: [
          'Scots Law private note settlement simulation sandbox',
          'Asset-liability duration matching within +/- 0.45 years',
          'Inter-node network latency <= 25ms across Edinburgh-Glasgow-London optical ring'
        ],
        modelConfidenceScore: 98,
        evaluatedTimestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      };
    }
  }, [regulatoryStatus, balanceSheet, macro, privateNotes, posNetwork, validators, regions]);

  return (
    <BankContext.Provider
      value={{
        regulatoryStatus,
        accounts,
        cards,
        transactions,
        journalEntries,
        privateNotes,
        noteOrders,
        validators,
        posNetwork,
        balanceSheet,
        macro,
        regions,
        fxRates,
        portfolioAssets,
        modelRegistry,
        auditLogs,
        activeCausalPayment,
        processTransfer,
        convertMoney,
        issuePrivateNote,
        placeNoteOrder,
        toggleValidatorStatus,
        toggleByzantineFault,
        stakeRSD,
        applyMacroShock,
        toggleCardFreeze,
        updateCardLimit,
        toggleCardFeature,
        queryIntelligence,
      }}
    >
      {children}
    </BankContext.Provider>
  );
};

export const useBank = () => {
  const context = useContext(BankContext);
  if (!context) {
    throw new Error('useBank must be used within a BankProvider');
  }
  return context;
};
