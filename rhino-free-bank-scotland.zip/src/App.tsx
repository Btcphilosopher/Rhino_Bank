/**
 * RHINO FREE BANK SCOTLAND
 * Main Application Root
 */

import React, { useState } from 'react';
import { BankProvider } from './context/BankContext';
import { Header, ActiveTab } from './components/common/Header';
import { RegulatoryBanner } from './components/common/RegulatoryBanner';
import { RetailDashboard } from './components/retail/RetailDashboard';
import { DigitalSterlingWallet } from './components/digital_sterling/DigitalSterlingWallet';
import { NoteHouseDesk } from './components/private_notes/NoteHouseDesk';
import { ValidatorControlRoom } from './components/validator/ValidatorControlRoom';
import { CorporateTreasury } from './components/commercial/CorporateTreasury';
import { RhinoPrivate } from './components/private_bank/RhinoPrivate';
import { InstitutionalMarkets } from './components/investments/InstitutionalMarkets';
import { TreasuryBalanceSheet } from './components/treasury/TreasuryBalanceSheet';
import { ScottishEconomicMap } from './components/macro/ScottishEconomicMap';
import { RhinoIntelligence } from './components/intelligence/RhinoIntelligence';
import { AuditAndModelGovernance } from './components/governance/AuditAndModelGovernance';
import { ExecutiveTerminal } from './components/board/ExecutiveTerminal';

export function AppContent() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('RETAIL');

  return (
    <div className="min-h-screen bg-[#0A0D14] text-[#E6EDF3] flex flex-col font-sans">
      
      {/* Top Bar Contract Header */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Regulatory Disclosure Banner */}
      <RegulatoryBanner />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto p-4 sm:p-6">
        {activeTab === 'RETAIL' && <RetailDashboard />}
        {activeTab === 'DIGITAL_STERLING' && <DigitalSterlingWallet />}
        {activeTab === 'NOTE_HOUSE' && <NoteHouseDesk />}
        {activeTab === 'VALIDATOR' && <ValidatorControlRoom />}
        {activeTab === 'COMMERCIAL' && <CorporateTreasury />}
        {activeTab === 'PRIVATE_BANK' && <RhinoPrivate />}
        {activeTab === 'MARKETS' && <InstitutionalMarkets />}
        {activeTab === 'TREASURY' && <TreasuryBalanceSheet />}
        {activeTab === 'MACRO_MAP' && <ScottishEconomicMap />}
        {activeTab === 'INTELLIGENCE' && <RhinoIntelligence />}
        {activeTab === 'GOVERNANCE' && <AuditAndModelGovernance />}
        {activeTab === 'BOARD' && <ExecutiveTerminal />}
      </main>

      {/* Institutional Footer */}
      <footer className="border-t border-[#1F2735] bg-[#0A0D14] py-6 px-4 sm:px-6 text-xs text-[#5A697E] font-mono">
        <div className="max-w-[1600px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="text-[#C68B45] font-bold">RHINO FREE BANK SCOTLAND</span>
            <span>·</span>
            <span>St Andrew Square, Edinburgh EH2 2BD</span>
            <span>·</span>
            <span>Established 1826 · Re-engineered 2026–2030</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-[#8B9BB4]">
            <span>Double-Entry General Ledger Active</span>
            <span>·</span>
            <span>9-Node PoS Ring Validated</span>
            <span>·</span>
            <span className="text-[#C68B45]">Synthetic Simulation Environment</span>
          </div>
        </div>
      </footer>

    </div>
  );
}

export default function App() {
  return (
    <BankProvider>
      <AppContent />
    </BankProvider>
  );
}
