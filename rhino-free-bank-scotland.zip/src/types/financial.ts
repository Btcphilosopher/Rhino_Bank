/**
 * RHINO FREE BANK SCOTLAND
 * Domain Types and Structural Definitions
 */

export interface RegulatoryStatus {
  jurisdiction: string;
  regulator: string;
  permission: string;
  permission_status: 'SIMULATION_ACTIVE' | 'SYNTHETIC_AUTHORISED' | 'SANDBOX_OPERATIONAL';
  effective_date: string;
  expiry_date: string;
  scope: string;
  customer_facing_disclosure: string;
  simulated: boolean;
}

export type AccountType = 'CURRENT' | 'INSTANT_SAVINGS' | 'NOTICE_30' | 'FIXED_TERM_1YR' | 'CASH_ISA_SIM' | 'PREMIUM_RESERVE' | 'RSD_WALLET' | 'CORPORATE_CURRENT' | 'TREASURY_RESERVE';

export interface AccountTwin {
  id: string;
  accountNumber: string;
  sortCode: string;
  name: string;
  type: AccountType;
  currency: string;
  balance: number;
  availableBalance: number;
  pendingBalance: number;
  interestRateAnnual: number;
  accruedInterest: number;
  projectedInterestAnnual: number;
  openedDate: string;
  status: 'ACTIVE' | 'FROZEN' | 'RESTRICTED';
}

export interface PaymentCard {
  id: string;
  cardNumberMasked: string;
  cardholderName: string;
  expiry: string;
  cvv: string;
  cardType: 'PHYSICAL_TITANIUM' | 'VIRTUAL_INSTANT' | 'DISPOSABLE_SINGLE_USE';
  tier: 'RHINO_STANDARD' | 'RHINO_PRIVATE' | 'RHINO_COMMERCIAL';
  isFrozen: boolean;
  contactlessEnabled: boolean;
  onlinePaymentsEnabled: boolean;
  atmWithdrawalsEnabled: boolean;
  monthlySpendLimit: number;
  monthlySpent: number;
  applePayEnrolled: boolean;
  googlePayEnrolled: boolean;
}

export interface CausalPaymentStep {
  step: 'AUTHENTICATION' | 'MERCHANT_CHECK' | 'PAYMENT_ROUTER' | 'RSD_LEDGER' | 'VALIDATOR_CONSENSUS' | 'FINALITY_ATTESTATION' | 'MERCHANT_SETTLEMENT';
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED';
  timestamp: string;
  latencyMs: number;
  detail: string;
}

export interface TransactionTwin {
  id: string;
  payerName: string;
  payerAccount: string;
  payeeName: string;
  payeeAccount: string;
  amount: number;
  currency: string;
  type: 'RSD_TRANSFER' | 'FASTER_PAYMENTS' | 'CARD_PURCHASE' | 'NOTE_SETTLEMENT' | 'INTEREST_PAYOUT' | 'FX_CONVERSION' | 'STAKING_REWARD' | 'DIRECT_DEBIT';
  category: 'FINANCE' | 'TREASURY' | 'RETAIL' | 'COMMERCE' | 'ENERGY' | 'INFRASTRUCTURE' | 'GOVERNMENT' | 'TECH';
  timestamp: string;
  status: 'SETTLED' | 'PENDING' | 'CONFIRMING' | 'REVERSED';
  riskScore: number; // 0 - 100
  complianceCheck: 'PASSED' | 'REVIEW_FLAGGED' | 'EXEMPT';
  validatorBlockHeight: number;
  finalityTimestamp: string;
  journalEntryId: string;
  causalSteps?: CausalPaymentStep[];
}

export type NoteClass = 
  | 'RHINO_PRIVATE_NOTE'
  | 'RHINO_MERCHANT_NOTE'
  | 'RHINO_INSTITUTIONAL_NOTE'
  | 'RHINO_SECURED_NOTE'
  | 'RHINO_INFRASTRUCTURE_NOTE'
  | 'RHINO_COMMODITY_NOTE'
  | 'RHINO_REVENUE_NOTE';

export interface PrivateNoteTwin {
  id: string;
  isin: string;
  name: string;
  noteClass: NoteClass;
  issuer: string;
  faceValue: number;
  issuedAmount: number;
  outstandingAmount: number;
  currency: string;
  couponAnnualPct: number;
  yieldAnnualPct: number;
  durationYears: number;
  maturityYears: number;
  issuanceDate: string;
  maturityDate: string;
  collateralDescription: string;
  collateralValue: number;
  collateralRatioPct: number; // e.g. 140%
  ltvPct: number;
  seniority: 'SENIOR_SECURED' | 'SENIOR_UNSECURED' | 'MEZZANINE' | 'SUBORDINATED';
  covenants: string[];
  settlementMechanism: 'RSD_ATOMIC_DELIVERY' | 'FASTER_PAYMENTS' | 'TREASURY_BILATERAL';
  syntheticCreditRating: 'AAA(synth)' | 'AA+(synth)' | 'AA(synth)' | 'A+(synth)' | 'A(synth)' | 'BBB+(synth)';
  marketPriceIndicativePct: number; // e.g. 101.40
  liquidityTier: 'TIER_1_HIGH' | 'TIER_2_MODERATE' | 'TIER_3_INSTITUTIONAL_RFQ';
  secondaryMarketStatus: 'ACTIVE_TRADING' | 'ALLOCATION_CLOSED' | 'MATURED';
  legalDocumentationStatus: 'EXECUTED_TERM_SHEET' | 'PROSPECTUS_SYNTH_VERIFIED';
  currentHolders: { entity: string; allocationAmount: number; allocationPct: number }[];
}

export interface NoteOrder {
  id: string;
  noteId: string;
  isin: string;
  side: 'BID' | 'OFFER';
  participant: string;
  participantType: 'SCOTTISH_PENSION' | 'EDINBURGH_PRIVATE_BANK' | 'UK_INSURER' | 'INFRASTRUCTURE_FUND' | 'FAMILY_OFFICE' | 'CORPORATE_TREASURY' | 'UNIVERSITY_ENDOWMENT' | 'SOVEREIGN_STYLE_FUND';
  faceAmount: number;
  pricePct: number;
  yieldPct: number;
  timestamp: string;
  orderType: 'LIMIT' | 'RFQ' | 'BLOCK_TRADE';
  status: 'OPEN' | 'MATCHED' | 'SETTLED' | 'CANCELLED';
}

export interface ValidatorNodeTwin {
  id: string;
  name: string;
  city: 'Edinburgh' | 'Glasgow' | 'London' | 'Manchester' | 'Leeds' | 'Aberdeen' | 'Dublin' | 'Amsterdam' | 'Frankfurt';
  status: 'ACTIVE' | 'STANDBY' | 'DEGRADED' | 'OFFLINE';
  stakeAmount: number; // in RSD (£ equivalent)
  stakeSharePct: number;
  uptimePct: number;
  latencyMs: number;
  blocksProposed: number;
  attestationsCount: number;
  missedAttestations: number;
  slashingCount: number;
  accumulatedRewards: number;
  annualYieldPct: number;
  hardwareSpecs: string;
  isByzantineSimulated: boolean;
  operator: string;
}

export interface PoSNetworkState {
  currentEpoch: number;
  blockHeight: number;
  totalNetworkStake: number;
  activeValidatorsCount: number;
  consensusHealthPct: number;
  averageLatencyMs: number;
  transactionsPerSecond: number;
  finalityTimeSeconds: number;
  lastFinalizedBlock: number;
  slashingEventsCount: number;
  totalRewardsDistributed: number;
  recentBlocks: {
    blockNumber: number;
    proposer: string;
    city: string;
    txCount: number;
    hash: string;
    timestamp: string;
    attestationScorePct: number;
  }[];
}

export interface JournalEntry {
  id: string;
  timestamp: string;
  reference: string;
  description: string;
  transactionType: string;
  debitAccount: string;
  debitAmount: number;
  creditAccount: string;
  creditAmount: number;
  currency: string;
  status: 'POSTED' | 'PENDING' | 'RECONCILED' | 'REVERSED';
  subledger: 'CUSTOMER' | 'SECURITIES' | 'TREASURY' | 'VALIDATOR' | 'PAYMENTS';
}

export interface BalanceSheetTwin {
  timestamp: string;
  assets: {
    cashAndBoEReserves: number;
    liquidHighQualitySecurities: number;
    customerLoansRetail: number;
    commercialAndSMELending: number;
    mortgageBook: number;
    privateNotePortfolioHeld: number;
    infrastructureReceivables: number;
    otherAssets: number;
    totalAssets: number;
  };
  liabilities: {
    retailDeposits: number;
    commercialDeposits: number;
    rsdDigitalSterlingInCirculation: number;
    issuedPrivateNotesObligations: number;
    wholesaleFunding: number;
    otherLiabilities: number;
    totalLiabilities: number;
  };
  equity: {
    paidInCapital: number;
    retainedEarnings: number;
    prudentialReserves: number;
    totalEquity: number;
  };
  reconciliationDelta: number; // Must equal 0 (Assets - (Liabilities + Equity))
  metrics: {
    cet1RatioSimulatedPct: number; // e.g. 18.4%
    liquidityCoverageRatioPct: number; // e.g. 210%
    netStableFundingRatioPct: number; // e.g. 142%
    netInterestMarginPct: number; // e.g. 3.12%
    returnOnEquityPct: number; // e.g. 14.8%
    costToIncomeRatioPct: number; // e.g. 38.2%
    leverageRatioPct: number; // e.g. 6.8%
    var1Day99Pct: number; // Value at Risk £
    expectedShortfall99Pct: number; // £
    dv01InterestRateSensitivity: number; // £ / 1bp shift
    cs01CreditSpreadSensitivity: number; // £ / 1bp shift
  };
}

export interface MacroEconomicEnvironment {
  bankRatePct: number; // Bank of England Base Rate
  scotlandGdpGrowthPct: number;
  scotlandInflationCpiPct: number;
  unemploymentRatePct: number;
  averageWageGrowthPct: number;
  averageHousePriceScotland: number;
  housePriceGrowthAnnualPct: number;
  brentCrudeUsd: number;
  renewableEnergyOutputGWh: number;
  businessFormationRateAnnualPct: number;
  activeScenarioName: 'BASELINE_STABLE' | 'RATE_HIKE_100BP' | 'RATE_CUT_50BP' | 'NORTH_SEA_ENERGY_SURGE' | 'SCOTTISH_PROPERTY_STRESS';
  shockDescription: string;
}

export interface ScottishRegionTwin {
  id: string;
  city: string;
  population: number;
  dominantIndustries: string[];
  totalRhinoDeposits: number;
  totalRhinoLending: number;
  activeCommercialClients: number;
  infrastructureNotesFinanced: number;
  gvaContributionAnnual: number;
  creditGrowthRatePct: number;
  defaultRatePct: number;
}

export interface FXRateTwin {
  pair: string; // e.g. 'GBP/USD'
  baseCurrency: string;
  quoteCurrency: string;
  spotRate: number;
  bid: number;
  offer: number;
  spreadPips: number;
  dayChangePct: number;
  forward1Month: number;
  forward3Month: number;
  impliedVol30DPct: number;
}

export interface PortfolioAssetTwin {
  id: string;
  symbol: string;
  name: string;
  assetClass: 'UK_EQUITY' | 'GLOBAL_EQUITY' | 'SCOTTISH_GILT' | 'RHINO_NOTE' | 'INFRASTRUCTURE' | 'COMMODITY' | 'CASH_RSD';
  units: number;
  avgCostPrice: number;
  currentPrice: number;
  totalValue: number;
  allocationPct: number;
  unrealizedGainLoss: number;
  unrealizedGainLossPct: number;
  dividendYieldAnnualPct: number;
  esgScore: number;
}

export interface IntelligenceCitation {
  source: string;
  metric: string;
  value: string;
  timestamp: string;
}

export interface AIIntelligenceResponse {
  query: string;
  answer: string;
  citations: IntelligenceCitation[];
  calculationBreakdown?: string;
  underlyingAssumptions: string[];
  modelConfidenceScore: number; // 0 - 100
  evaluatedTimestamp: string;
}

export interface ModelGovernanceEntry {
  modelId: string;
  name: string;
  version: string;
  authorDivision: string;
  purpose: string;
  primaryInputs: string[];
  methodology: string;
  validationStatus: 'VALIDATED_APPROVED' | 'IN_REVIEW' | 'CHALLENGER_BENCHMARKED';
  deploymentDate: string;
  lastAuditDate: string;
  limitations: string;
  challengerModelBenchmark?: string;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  actor: string;
  role: string;
  actionType: 'TRANSACTION_SETTLED' | 'NOTE_ISSUANCE' | 'VALIDATOR_SLASH' | 'MACRO_SHOCK_APPLIED' | 'CREDIT_DECISION' | 'GOVERNANCE_OVERRIDE' | 'COMPLIANCE_CLEARANCE';
  details: string;
  immutableHash: string;
  verifiedStatus: 'CRYPTOGRAPHICALLY_VERIFIED' | 'PENDING_VALIDATOR_ATTESTATION';
}
