/**
 * RHINO FREE BANK SCOTLAND
 * Double-Entry Accounting Engine & Balance Sheet Service
 */

import {
  BalanceSheetTwin,
  JournalEntry,
  TransactionTwin
} from '../types/financial';

export class FinancialLedgerService {
  /**
   * Generates an immutable journal entry and performs double-entry posting.
   */
  public static createJournalEntry(
    transaction: TransactionTwin,
    subledger: 'CUSTOMER' | 'SECURITIES' | 'TREASURY' | 'VALIDATOR' | 'PAYMENTS'
  ): JournalEntry {
    let debitAccount = '';
    let creditAccount = '';

    switch (transaction.type) {
      case 'CARD_PURCHASE':
        debitAccount = `Customer Account: ${transaction.payerAccount} (Retail Deposit)`;
        creditAccount = `Merchant Settlement Clearing: ${transaction.payeeName}`;
        break;
      case 'RSD_TRANSFER':
        debitAccount = `RSD Digital Wallet: ${transaction.payerAccount}`;
        creditAccount = `RSD Digital Wallet: ${transaction.payeeAccount}`;
        break;
      case 'NOTE_SETTLEMENT':
        debitAccount = 'Bank Reserves / Cash at Bank of England';
        creditAccount = `Issued Private Note Obligation (${transaction.payeeAccount})`;
        break;
      case 'STAKING_REWARD':
        debitAccount = 'Bank PoS Network Treasury Incentive Expense';
        creditAccount = `Validator Staking Vault: ${transaction.payeeAccount}`;
        break;
      case 'FASTER_PAYMENTS':
      default:
        debitAccount = `Payer Account: ${transaction.payerAccount}`;
        creditAccount = `Payee Settlement: ${transaction.payeeAccount}`;
        break;
    }

    const entry: JournalEntry = {
      id: `JRN-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      reference: `REF-${transaction.id}`,
      description: `${transaction.type} - ${transaction.payerName} → ${transaction.payeeName}`,
      transactionType: transaction.type,
      debitAccount,
      debitAmount: transaction.amount,
      creditAccount,
      creditAmount: transaction.amount,
      currency: transaction.currency,
      status: 'RECONCILED',
      subledger,
    };

    return entry;
  }

  /**
   * Recalculates balance sheet metrics and ensures Assets = Liabilities + Equity
   */
  public static reconcileBalanceSheet(
    current: BalanceSheetTwin,
    rateShockBp: number = 0
  ): BalanceSheetTwin {
    const assets = { ...current.assets };
    const liabilities = { ...current.liabilities };
    const equity = { ...current.equity };

    // Total Assets calculation
    assets.totalAssets =
      assets.cashAndBoEReserves +
      assets.liquidHighQualitySecurities +
      assets.customerLoansRetail +
      assets.commercialAndSMELending +
      assets.mortgageBook +
      assets.privateNotePortfolioHeld +
      assets.infrastructureReceivables +
      assets.otherAssets;

    // Total Liabilities calculation
    liabilities.totalLiabilities =
      liabilities.retailDeposits +
      liabilities.commercialDeposits +
      liabilities.rsdDigitalSterlingInCirculation +
      liabilities.issuedPrivateNotesObligations +
      liabilities.wholesaleFunding +
      liabilities.otherLiabilities;

    // Total Equity calculation
    equity.totalEquity =
      equity.paidInCapital +
      equity.retainedEarnings +
      equity.prudentialReserves;

    // Reconciliation Check: Delta MUST equal 0.00
    const delta = Math.round((assets.totalAssets - (liabilities.totalLiabilities + equity.totalEquity)) * 100) / 100;

    // Risk-weighted Assets (RWA) estimation for CET1
    // Cash: 0%, HQLA Gilts: 5%, Mortgages: 35%, Commercial: 75%, Infrastructure: 50%
    const rwa =
      assets.cashAndBoEReserves * 0.00 +
      assets.liquidHighQualitySecurities * 0.05 +
      assets.customerLoansRetail * 0.60 +
      assets.commercialAndSMELending * 0.75 +
      assets.mortgageBook * 0.35 +
      assets.privateNotePortfolioHeld * 0.50 +
      assets.infrastructureReceivables * 0.40;

    const cet1RatioSimulatedPct = Math.round(((equity.totalEquity / rwa) * 100) * 100) / 100;

    // LCR = High Quality Liquid Assets / 30-day net cash outflow
    const hqla = assets.cashAndBoEReserves + assets.liquidHighQualitySecurities;
    const estimated30DOutflows = (liabilities.retailDeposits * 0.05) + (liabilities.commercialDeposits * 0.15) + (liabilities.rsdDigitalSterlingInCirculation * 0.10);
    const liquidityCoverageRatioPct = Math.round((hqla / estimated30DOutflows) * 1000) / 10;

    // Net Interest Margin calculation with rate shock effect
    const baseNIM = 3.18;
    const rateEffect = (rateShockBp / 100) * 0.18; // Positive asset repricing faster than deposit beta
    const netInterestMarginPct = Math.max(1.5, Math.round((baseNIM + rateEffect) * 100) / 100);

    // Value at Risk & Sensitivities
    const var1Day99Pct = Math.round(assets.totalAssets * 0.0016);
    const expectedShortfall99Pct = Math.round(var1Day99Pct * 1.43);
    const dv01InterestRateSensitivity = -Math.round((assets.liquidHighQualitySecurities * 0.00045) + (assets.mortgageBook * 0.00018));
    const cs01CreditSpreadSensitivity = -Math.round((assets.privateNotePortfolioHeld * 0.00065) + (assets.commercialAndSMELending * 0.00025));

    return {
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      assets,
      liabilities,
      equity,
      reconciliationDelta: delta,
      metrics: {
        ...current.metrics,
        cet1RatioSimulatedPct,
        liquidityCoverageRatioPct,
        netInterestMarginPct,
        var1Day99Pct,
        expectedShortfall99Pct,
        dv01InterestRateSensitivity,
        cs01CreditSpreadSensitivity,
      }
    };
  }
}
