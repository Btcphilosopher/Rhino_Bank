/**
 * RHINO FREE BANK SCOTLAND
 * Private Note House & Capital Markets Issuance Service
 */

import { NoteClass, NoteOrder, PrivateNoteTwin } from '../types/financial';

export interface NoteStructureParams {
  name: string;
  noteClass: NoteClass;
  issuer: string;
  faceValue: number;
  issueSize: number;
  maturityYears: number;
  couponAnnualPct: number;
  collateralDescription: string;
  collateralValue: number;
  seniority: 'SENIOR_SECURED' | 'SENIOR_UNSECURED' | 'MEZZANINE' | 'SUBORDINATED';
  covenants: string[];
  settlementMechanism: 'RSD_ATOMIC_DELIVERY' | 'FASTER_PAYMENTS' | 'TREASURY_BILATERAL';
}

export class PrivateNoteHouseService {
  /**
   * Generates a synthetic ISIN code adhering to GB convention
   */
  public static generateSyntheticISIN(): string {
    const chars = '0123456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    let code = 'GB00RHN';
    for (let i = 0; i < 4; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    code += Math.floor(Math.random() * 10);
    return code;
  }

  /**
   * Prices and structures a new private note instrument
   */
  public static structureNewNote(params: NoteStructureParams): PrivateNoteTwin {
    const collateralRatioPct = Math.round((params.collateralValue / params.issueSize) * 100);
    const ltvPct = Math.round((params.issueSize / params.collateralValue) * 1000) / 10;
    
    // Duration estimation (Macaulay duration approximation)
    const y = params.couponAnnualPct / 100;
    const n = params.maturityYears;
    const durationYears = Math.round(((1 + y) / y - (1 + y + n * (0.05 - y)) / (0.05 * Math.pow(1 + y, n) - 0.05 + y)) * 100) / 100 || (params.maturityYears * 0.85);

    // Yield and Credit Rating simulation
    let rating: PrivateNoteTwin['syntheticCreditRating'] = 'AA(synth)';
    if (collateralRatioPct >= 140 && params.seniority === 'SENIOR_SECURED') {
      rating = 'AAA(synth)';
    } else if (collateralRatioPct >= 120) {
      rating = 'AA+(synth)';
    } else if (params.seniority === 'SUBORDINATED') {
      rating = 'A(synth)';
    } else {
      rating = 'A+(synth)';
    }

    const baseGiltYield = 4.25;
    let spreadPct = 1.45;
    if (rating === 'AAA(synth)') spreadPct = 0.85;
    else if (rating === 'AA+(synth)') spreadPct = 1.15;
    else if (rating === 'A+(synth)') spreadPct = 1.65;
    else if (rating === 'A(synth)') spreadPct = 1.95;
    const yieldAnnualPct = Math.round((baseGiltYield + spreadPct) * 100) / 100;
    const marketPriceIndicativePct = Math.round(((params.couponAnnualPct / yieldAnnualPct) * 100) * 100) / 100;

    const isin = this.generateSyntheticISIN();
    const issuanceDate = new Date().toISOString().substring(0, 10);
    const maturityDate = new Date(Date.now() + params.maturityYears * 365.25 * 86400000).toISOString().substring(0, 10);

    return {
      id: `note-${Date.now()}`,
      isin,
      name: params.name,
      noteClass: params.noteClass,
      issuer: params.issuer,
      faceValue: params.faceValue,
      issuedAmount: params.issueSize,
      outstandingAmount: params.issueSize,
      currency: 'GBP',
      couponAnnualPct: params.couponAnnualPct,
      yieldAnnualPct,
      durationYears: Math.max(0.5, Math.min(params.maturityYears, durationYears)),
      maturityYears: params.maturityYears,
      issuanceDate,
      maturityDate,
      collateralDescription: params.collateralDescription,
      collateralValue: params.collateralValue,
      collateralRatioPct,
      ltvPct,
      seniority: params.seniority,
      covenants: params.covenants.length > 0 ? params.covenants : ['Pari Passu Status', 'Quarterly Collateral Valuation'],
      settlementMechanism: params.settlementMechanism,
      syntheticCreditRating: rating,
      marketPriceIndicativePct,
      liquidityTier: params.issueSize >= 50000000 ? 'TIER_1_HIGH' : 'TIER_2_MODERATE',
      secondaryMarketStatus: 'ACTIVE_TRADING',
      legalDocumentationStatus: 'EXECUTED_TERM_SHEET',
      currentHolders: [
        { entity: 'Rhino Syndicate Primary Allocations', allocationAmount: params.issueSize * 0.6, allocationPct: 60 },
        { entity: 'Scottish Institutional Liquidity Vault', allocationAmount: params.issueSize * 0.4, allocationPct: 40 }
      ]
    };
  }

  /**
   * Generates electronic term sheet text for institutional compliance
   */
  public static generateElectronicTermSheet(note: PrivateNoteTwin): string {
    return `
================================================================================
RHINO FREE BANK SCOTLAND — PRIVATE NOTE HOUSE
SYNTHETIC ELECTRONIC TERM SHEET & PRICING MEMORANDUM
================================================================================
INSTRUMENT IDENTIFIER : ${note.isin}
INSTRUMENT NAME       : ${note.name}
NOTE CLASS            : ${note.noteClass.replace(/_/g, ' ')}
ISSUER                : ${note.issuer}
GOVERNING JURISDICTION: Scots Law / Synthetic Simulation Sandbox
ISSUE DATE            : ${note.issuanceDate}
MATURITY DATE         : ${note.maturityDate} (${note.maturityYears} Years)
TOTAL NOMINAL SIZE    : £${(note.issuedAmount).toLocaleString('en-GB')} GBP
DENOMINATION / FACE   : £${note.faceValue.toLocaleString('en-GB')}
COUPON (ANNUAL)       : ${note.couponAnnualPct.toFixed(2)}% (Payable Semi-Annually in RSD/GBP)
INDICATIVE YIELD      : ${note.yieldAnnualPct.toFixed(2)}%
ESTIMATED DURATION    : ${note.durationYears.toFixed(2)} Years
SYNTHETIC RATING      : ${note.syntheticCreditRating}
SENIORITY             : ${note.seniority}
COLLATERAL ASSET      : ${note.collateralDescription}
COLLATERAL VALUATION  : £${note.collateralValue.toLocaleString('en-GB')} (${note.collateralRatioPct}% Coverage, LTV ${note.ltvPct}%)
SETTLEMENT PROTOCOL   : ${note.settlementMechanism} (Atomic Delivery-vs-Payment)
DOCUMENTATION STATUS  : ${note.legalDocumentationStatus}
COVENANTS:
${note.covenants.map((c, i) => `  [${i + 1}] ${c}`).join('\n')}
================================================================================
DISCLOSURE: This is a synthetic institutional monetary instrument simulation.
================================================================================
`;
  }
}
