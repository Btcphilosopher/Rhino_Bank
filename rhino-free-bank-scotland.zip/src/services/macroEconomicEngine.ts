/**
 * RHINO FREE BANK SCOTLAND
 * Macroeconomic Engine & Causal Shock Simulator
 */

import {
  BalanceSheetTwin,
  MacroEconomicEnvironment,
  PrivateNoteTwin,
  ScottishRegionTwin
} from '../types/financial';

export type MacroShockType = 'BASELINE_STABLE' | 'RATE_HIKE_100BP' | 'RATE_CUT_50BP' | 'NORTH_SEA_ENERGY_SURGE' | 'SCOTTISH_PROPERTY_STRESS';

export interface MacroShockResult {
  updatedMacro: MacroEconomicEnvironment;
  updatedBalanceSheet: BalanceSheetTwin;
  updatedNotes: PrivateNoteTwin[];
  updatedRegions: ScottishRegionTwin[];
  causalChainExplanation: string[];
}

export class MacroEconomicEngineService {
  /**
   * Propagates a macroeconomic shock through the bank's balance sheet, notes, and regional economy.
   */
  public static applyMacroShock(
    shockType: MacroShockType,
    currentMacro: MacroEconomicEnvironment,
    currentBS: BalanceSheetTwin,
    currentNotes: PrivateNoteTwin[],
    currentRegions: ScottishRegionTwin[]
  ): MacroShockResult {
    let rateShiftBp = 0;
    let newBankRate = 4.50;
    let gdpGrowth = currentMacro.scotlandGdpGrowthPct;
    let inflation = currentMacro.scotlandInflationCpiPct;
    let unemployment = currentMacro.unemploymentRatePct;
    let housePriceGrowth = currentMacro.housePriceGrowthAnnualPct;
    let brentCrude = currentMacro.brentCrudeUsd;
    let shockDesc = '';
    const causalChain: string[] = [];

    switch (shockType) {
      case 'RATE_HIKE_100BP':
        rateShiftBp = 100;
        newBankRate = 5.50;
        inflation = 2.05;
        gdpGrowth = 1.20;
        unemployment = 3.90;
        housePriceGrowth = 1.40;
        shockDesc = 'Bank of England Base Rate hiked by +100bp (4.50% → 5.50%) to cool persistent core price pressures.';
        causalChain.push('1. Central Bank Base Rate increases by +100bp to 5.50%.');
        causalChain.push('2. Asset yields reprice immediately on floating-rate loans & commercial facilities.');
        causalChain.push('3. Deposit beta of ~65% increases deposit funding expense to 3.85%.');
        causalChain.push('4. Net Interest Margin (NIM) expands from 3.18% to 3.36%.');
        causalChain.push('5. Fixed-income asset values decline inversely with duration: Gilts & Note prices down ~2.5% to 4.2%.');
        causalChain.push('6. Mortgage affordability constraints slightly moderate Scottish credit demand (+4.8% vs +6.4%).');
        causalChain.push('7. Capital reserves (CET1) remain resilient at 18.15% due to higher retained earnings buffer.');
        break;

      case 'RATE_CUT_50BP':
        rateShiftBp = -50;
        newBankRate = 4.00;
        inflation = 2.45;
        gdpGrowth = 2.15;
        unemployment = 3.40;
        housePriceGrowth = 4.90;
        shockDesc = 'Monetary easing: Base Rate cut by -50bp (4.50% → 4.00%) to stimulate capital expenditure & SME credit.';
        causalChain.push('1. Central Bank Base Rate cut by -50bp to 4.00%.');
        causalChain.push('2. Commercial borrowing costs decrease, accelerating new business loan demand.');
        causalChain.push('3. Net Interest Margin compresses slightly to 3.09% as loan yields drop faster than deposit floors.');
        causalChain.push('4. Fixed-income bond and private note prices appreciate (+1.8% to +3.2%).');
        causalChain.push('5. Scottish housing market velocity accelerates; regional credit growth rises to +7.1%.');
        break;

      case 'NORTH_SEA_ENERGY_SURGE':
        rateShiftBp = 25;
        newBankRate = 4.75;
        brentCrude = 98.00;
        gdpGrowth = 2.80;
        inflation = 2.70;
        shockDesc = 'Surge in European demand for North Sea floating wind, hydrogen exports, and maritime engineering.';
        causalChain.push('1. North Sea energy infrastructure export volumes increase +34%.');
        causalChain.push('2. Aberdeen and Glasgow commercial corporate deposits rise +14%.');
        causalChain.push('3. Rhino Infrastructure & Commodity Note secondary liquidity surges to premium (102.80%).');
        causalChain.push('4. Corporate loan credit quality improves; default rates in energy corridor fall to 0.28%.');
        break;

      case 'SCOTTISH_PROPERTY_STRESS':
        rateShiftBp = 50;
        newBankRate = 5.00;
        gdpGrowth = 0.60;
        unemployment = 4.40;
        housePriceGrowth = -4.20;
        shockDesc = 'Severe stress test: 4.2% property price correction with elevated debt service ratios.';
        causalChain.push('1. Average Scottish house prices decline -4.2%, raising mortgage average LTV from 68% to 74%.');
        causalChain.push('2. Rhino automated risk engine increases mortgage provisioning buffer by £12M.');
        causalChain.push('3. CET1 capital ratio absorbs stress, adjusting to 17.85% (well above 10.5% regulatory threshold).');
        causalChain.push('4. High Quality Liquid Assets (HQLA) & cash buffer maintains LCR at 214%, confirming institutional solvency.');
        break;

      case 'BASELINE_STABLE':
      default:
        rateShiftBp = 0;
        newBankRate = 4.50;
        gdpGrowth = 1.85;
        inflation = 2.30;
        unemployment = 3.60;
        housePriceGrowth = 3.80;
        brentCrude = 76.50;
        shockDesc = 'Standard baseline operating scenario. Steady state growth and monetary stability.';
        causalChain.push('1. Operating in baseline Scottish economic corridor conditions.');
        causalChain.push('2. Balance sheet, yields, and note markets in equilibrium.');
        break;
    }

    const updatedMacro: MacroEconomicEnvironment = {
      ...currentMacro,
      bankRatePct: newBankRate,
      scotlandGdpGrowthPct: gdpGrowth,
      scotlandInflationCpiPct: inflation,
      unemploymentRatePct: unemployment,
      housePriceGrowthAnnualPct: housePriceGrowth,
      brentCrudeUsd: brentCrude,
      activeScenarioName: shockType,
      shockDescription: shockDesc,
    };

    // Reprice Private Notes: deltaP = -duration * deltaYield
    const deltaYield = rateShiftBp / 10000; // e.g. 100bp = 0.01
    const updatedNotes = currentNotes.map(n => {
      const priceShiftPct = -n.durationYears * (rateShiftBp / 100) * 0.75;
      const newPrice = Math.max(90, Math.min(115, Math.round((n.marketPriceIndicativePct + priceShiftPct) * 100) / 100));
      const newYield = Math.round((n.yieldAnnualPct + (rateShiftBp / 100) * 0.85) * 100) / 100;
      return {
        ...n,
        marketPriceIndicativePct: newPrice,
        yieldAnnualPct: newYield,
      };
    });

    // Update Scottish Regions
    const updatedRegions = currentRegions.map(r => {
      const growthShift = (gdpGrowth - 1.85) * 0.8;
      const defaultShift = shockType === 'SCOTTISH_PROPERTY_STRESS' ? 0.35 : (rateShiftBp > 0 ? 0.08 : -0.05);
      return {
        ...r,
        creditGrowthRatePct: Math.max(1.0, Math.round((r.creditGrowthRatePct + growthShift) * 10) / 10),
        defaultRatePct: Math.max(0.15, Math.round((r.defaultRatePct + defaultShift) * 100) / 100),
      };
    });

    // Update Balance Sheet
    const assets = { ...currentBS.assets };
    const liabilities = { ...currentBS.liabilities };
    const equity = { ...currentBS.equity };

    // Mark to market on held securities
    const secMarkShift = (rateShiftBp / 100) * -8500000;
    assets.liquidHighQualitySecurities = Math.round(assets.liquidHighQualitySecurities + secMarkShift);
    equity.retainedEarnings = Math.round(equity.retainedEarnings + secMarkShift);
    assets.totalAssets = assets.cashAndBoEReserves + assets.liquidHighQualitySecurities + assets.customerLoansRetail + assets.commercialAndSMELending + assets.mortgageBook + assets.privateNotePortfolioHeld + assets.infrastructureReceivables + assets.otherAssets;
    equity.totalEquity = equity.paidInCapital + equity.retainedEarnings + equity.prudentialReserves;

    const baseNIM = 3.18;
    const rateEffect = (rateShiftBp / 100) * 0.18;
    const netInterestMarginPct = Math.max(1.5, Math.round((baseNIM + rateEffect) * 100) / 100);

    const updatedBalanceSheet: BalanceSheetTwin = {
      ...currentBS,
      assets,
      equity,
      reconciliationDelta: Math.round((assets.totalAssets - (liabilities.totalLiabilities + equity.totalEquity)) * 100) / 100,
      metrics: {
        ...currentBS.metrics,
        netInterestMarginPct,
        cet1RatioSimulatedPct: Math.round((equity.totalEquity / (assets.totalAssets * 0.48)) * 100 * 100) / 100,
      }
    };

    return {
      updatedMacro,
      updatedBalanceSheet,
      updatedNotes,
      updatedRegions,
      causalChainExplanation: causalChain,
    };
  }
}
