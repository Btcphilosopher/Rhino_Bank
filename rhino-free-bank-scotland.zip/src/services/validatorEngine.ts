/**
 * RHINO FREE BANK SCOTLAND
 * Proof-of-Stake Consensus Engine & Validator Operations
 */

import { PoSNetworkState, ValidatorNodeTwin } from '../types/financial';

export class ValidatorEngineService {
  /**
   * Simulates a PoS consensus tick: picks a block proposer proportional to stake,
   * gathers attestations from active nodes, computes rewards/penalties, and creates a block.
   */
  public static processConsensusTick(
    networkState: PoSNetworkState,
    validators: ValidatorNodeTwin[]
  ): {
    updatedNetwork: PoSNetworkState;
    updatedValidators: ValidatorNodeTwin[];
    newBlockInfo: { blockNumber: number; proposer: string; city: string; txCount: number };
  } {
    const activeValidators = validators.filter(v => v.status === 'ACTIVE');
    if (activeValidators.length === 0) {
      return {
        updatedNetwork: networkState,
        updatedValidators: validators,
        newBlockInfo: { blockNumber: networkState.blockHeight, proposer: 'None', city: 'None', txCount: 0 }
      };
    }

    // Weighted random selection based on stake
    const totalActiveStake = activeValidators.reduce((sum, v) => sum + v.stakeAmount, 0);
    let rand = Math.random() * totalActiveStake;
    let chosenProposer = activeValidators[0];

    for (const v of activeValidators) {
      if (rand < v.stakeAmount) {
        chosenProposer = v;
        break;
      }
      rand -= v.stakeAmount;
    }

    const nextBlockHeight = networkState.blockHeight + 1;
    const txCount = Math.floor(25 + Math.random() * 40);
    const blockRewardRSD = 1.25 + (txCount * 0.02);

    // Compute updated validator records
    const updatedValidators = validators.map(v => {
      if (v.status === 'OFFLINE') {
        return {
          ...v,
          missedAttestations: v.missedAttestations + 1,
          uptimePct: Math.max(90, Math.round((v.uptimePct - 0.01) * 100) / 100),
        };
      }

      if (v.id === chosenProposer.id) {
        return {
          ...v,
          blocksProposed: v.blocksProposed + 1,
          attestationsCount: v.attestationsCount + 1,
          accumulatedRewards: Math.round((v.accumulatedRewards + blockRewardRSD) * 100) / 100,
        };
      }

      // Byzantine node check (simulated fault injection)
      if (v.isByzantineSimulated) {
        const shouldSlash = Math.random() < 0.05;
        return {
          ...v,
          slashingCount: shouldSlash ? v.slashingCount + 1 : v.slashingCount,
          stakeAmount: shouldSlash ? Math.round(v.stakeAmount * 0.98) : v.stakeAmount,
          accumulatedRewards: shouldSlash ? Math.max(0, v.accumulatedRewards - 500) : v.accumulatedRewards,
        };
      }

      // Normal active node attestation
      return {
        ...v,
        attestationsCount: v.attestationsCount + 1,
        accumulatedRewards: Math.round((v.accumulatedRewards + (blockRewardRSD * 0.15)) * 100) / 100,
      };
    });

    const hash = '0x' + Array.from({ length: 12 }, () => Math.floor(Math.random() * 16).toString(16)).join('') + '...' + Array.from({ length: 4 }, () => Math.floor(Math.random() * 16).toString(16)).join('');

    const newBlock = {
      blockNumber: nextBlockHeight,
      proposer: chosenProposer.name,
      city: chosenProposer.city,
      txCount,
      hash,
      timestamp: 'Just now',
      attestationScorePct: Math.round((activeValidators.length / validators.length) * 1000) / 10,
    };

    const updatedNetwork: PoSNetworkState = {
      ...networkState,
      blockHeight: nextBlockHeight,
      currentEpoch: Math.floor(nextBlockHeight / 200) + 1,
      totalRewardsDistributed: Math.round((networkState.totalRewardsDistributed + blockRewardRSD) * 100) / 100,
      activeValidatorsCount: activeValidators.length,
      consensusHealthPct: Math.round((activeValidators.length / validators.length) * 1000) / 10,
      recentBlocks: [newBlock, ...networkState.recentBlocks.slice(0, 5)],
    };

    return {
      updatedNetwork,
      updatedValidators,
      newBlockInfo: {
        blockNumber: nextBlockHeight,
        proposer: chosenProposer.name,
        city: chosenProposer.city,
        txCount,
      }
    };
  }

  /**
   * Validator Economics calculation model (R-analytical equivalent)
   */
  public static calculateValidatorEconomics(validator: ValidatorNodeTwin, networkTotalStake: number) {
    const stakeShare = validator.stakeAmount / networkTotalStake;
    const estimatedDailyBlocks = stakeShare * 28800; // ~3s block time
    const blockRewardEstimate = 1.65; // RSD per block
    const estimatedDailyGrossRSD = estimatedDailyBlocks * blockRewardEstimate;
    const annualGrossYieldPct = ((estimatedDailyGrossRSD * 365) / validator.stakeAmount) * 100;
    const estimatedAnnualOpCostGBP = 14200; // Hardware, electricity, colocation
    const netYieldPct = Math.max(0, Math.round((annualGrossYieldPct - (estimatedAnnualOpCostGBP / validator.stakeAmount * 100)) * 100) / 100);

    return {
      stakeSharePct: Math.round(stakeShare * 10000) / 100,
      estimatedDailyBlocks: Math.round(estimatedDailyBlocks),
      estimatedDailyGrossRSD: Math.round(estimatedDailyGrossRSD * 100) / 100,
      annualGrossYieldPct: Math.round(annualGrossYieldPct * 100) / 100,
      estimatedAnnualOpCostGBP,
      netYieldPct,
    };
  }
}
