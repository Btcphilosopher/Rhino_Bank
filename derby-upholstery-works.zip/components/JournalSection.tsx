'use client';

import React, { useState } from 'react';
import { WORKSHOP_JOURNAL } from '@/data/mockData';
import { JournalArticle } from '@/types/furniture';
import { BookOpen, X, ArrowRight, Clock, User, FileText } from 'lucide-react';

export const JournalSection: React.FC = () => {
  const [selectedArticle, setSelectedArticle] = useState<JournalArticle | null>(null);

  return (
    <section id="journal" className="w-full bg-[#EEE9E0] py-16 border-b border-[#7A8081]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="border-b border-[#272A2C]/20 pb-6 mb-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono-spec tracking-widest text-[#173B52] bg-[#D9D0C2] inline-block px-2.5 py-1 mb-2 border-l-2 border-[#173B52]">
              SECTION 09 // EDITORIAL & ESSAYS
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif-arch font-bold text-[#173B52] uppercase">
              THE WORKSHOP JOURNAL
            </h2>
            <p className="text-sm text-[#272A2C]/80 max-w-2xl mt-1 font-sans">
              Essays on the structural anatomy of seating, Midlands manufacturing history, 
              ergonomic geometry, and the conservation of 20th-century British furniture.
            </p>
          </div>

          <div className="text-xs font-mono-spec text-[#7A8081]">
            DERBY ARCHIVES // ISSUED MONTHLY
          </div>
        </div>

        {/* Article Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {WORKSHOP_JOURNAL.map((art) => (
            <div
              key={art.id}
              onClick={() => setSelectedArticle(art)}
              className="bg-[#D9D0C2]/40 border border-[#7A8081]/30 flex flex-col justify-between group cursor-pointer hover:border-[#173B52] transition-all shadow-sm"
            >
              <div>
                <div className="relative aspect-[16/10] overflow-hidden border-b border-[#7A8081]/30">
                  <img
                    src={art.heroImage}
                    alt={art.title}
                    className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500 filter saturate-[0.9]"
                  />
                  <div className="absolute top-3 left-3 bg-[#173B52] text-[#EEE9E0] text-[9px] font-mono-spec px-2 py-0.5">
                    {art.category}
                  </div>
                </div>

                <div className="p-5 space-y-3">
                  <div className="flex items-center space-x-2 text-[10px] font-mono-spec text-[#7A8081]">
                    <span>{art.date}</span>
                    <span>•</span>
                    <span>{art.readTime}</span>
                  </div>

                  <h3 className="text-lg font-serif-arch font-bold text-[#173B52] leading-tight group-hover:text-[#272A2C] transition-colors">
                    {art.title}
                  </h3>

                  <p className="text-xs text-[#272A2C]/80 font-sans line-clamp-3">
                    {art.summary}
                  </p>
                </div>
              </div>

              <div className="p-5 pt-0">
                <div className="text-xs font-mono-spec font-bold text-[#173B52] flex items-center space-x-1 group-hover:text-[#D9632A] transition-colors">
                  <span>READ ESSAY</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Article Reader Modal */}
      {selectedArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#272A2C]/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-[#EEE9E0] border-2 border-[#173B52] w-full max-w-3xl max-h-[90vh] overflow-y-auto shadow-2xl relative my-8">
            {/* Top Bar */}
            <div className="bg-[#173B52] text-[#EEE9E0] px-6 py-3 flex items-center justify-between font-mono-spec text-xs border-b border-[#272A2C]">
              <div className="flex items-center space-x-3">
                <span className="text-[#A77A43] font-bold">WORKSHOP JOURNAL</span>
                <span className="text-[#EEE9E0]/40">|</span>
                <span>{selectedArticle.category}</span>
              </div>
              <button
                onClick={() => setSelectedArticle(null)}
                className="p-1 hover:bg-[#272A2C] text-[#EEE9E0] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Article Body */}
            <div className="p-6 sm:p-10 space-y-6">
              <div>
                <div className="text-[10px] font-mono-spec text-[#D9632A] font-bold uppercase">
                  {selectedArticle.date} • {selectedArticle.readTime} • BY {selectedArticle.author}
                </div>
                <h2 className="text-2xl sm:text-3xl font-serif-arch font-bold text-[#173B52] mt-1 leading-tight">
                  {selectedArticle.title}
                </h2>
                <p className="text-sm font-sans italic text-[#7A8081] mt-1">
                  {selectedArticle.subtitle}
                </p>
              </div>

              <img
                src={selectedArticle.heroImage}
                alt={selectedArticle.title}
                className="w-full aspect-[16/9] object-cover border border-[#272A2C]/20 shadow-md"
              />

              {/* Text paragraphs */}
              <div className="space-y-4 font-sans text-sm text-[#272A2C] leading-relaxed">
                {selectedArticle.content.map((p, idx) => (
                  <p key={idx}>{p}</p>
                ))}
              </div>

              {/* Technical Specifications callout */}
              {selectedArticle.specs && (
                <div className="bg-[#D9D0C2] p-5 border border-[#7A8081]/30 font-mono-spec text-xs space-y-2 mt-6">
                  <div className="text-[10px] font-bold text-[#173B52] uppercase">
                    TECHNICAL ARCHIVAL LOG
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[#272A2C]">
                    {selectedArticle.specs.map((s, i) => (
                      <div key={i} className="flex justify-between border-b border-[#7A8081]/20 pb-1">
                        <span className="text-[#7A8081]">{s.label}:</span>
                        <span className="font-bold">{s.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
