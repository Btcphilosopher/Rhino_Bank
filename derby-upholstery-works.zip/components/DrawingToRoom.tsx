'use client';

import React, { useState } from 'react';
import { ArrowRight, Check, Compass, Ruler, Hammer, Scissors, Home } from 'lucide-react';

interface NarrativeStep {
  step: number;
  stageCode: string;
  title: string;
  subtitle: string;
  image: string;
  caption: string;
  technicalSpecs: { label: string; value: string }[];
  detailNote: string;
}

const NARRATIVE_STEPS: NarrativeStep[] = [
  {
    step: 1,
    stageCode: 'STAGE 01 // DRAWING OFFICE',
    title: 'The Architectural Drawing',
    subtitle: 'Calculated in Derby on coordinate CAD grids.',
    image: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?q=80&w=1200&auto=format&fit=crop',
    caption: 'Every piece begins as an engineering drawing with precise pitch, seat rake, and load calculations.',
    technicalSpecs: [
      { label: 'COORDINATES', value: 'AutoCAD / Rhino 3D' },
      { label: 'SEAT PITCH', value: '104° Ergonomic Rake' },
      { label: 'TOLERANCE', value: '±0.5mm strict' },
    ],
    detailNote: 'Before any wood is cut, load lines and deflection forces are simulated to ensure structural stability over 25 years.',
  },
  {
    step: 2,
    stageCode: 'STAGE 02 // MILL & JOINERY',
    title: 'Kiln-Dried Hardwood Frame',
    subtitle: 'Sustainable British Ash cut and hand-mortised.',
    image: 'https://images.unsplash.com/photo-1540518614846-7ede433c4ef7?q=80&w=1200&auto=format&fit=crop',
    caption: 'Heavy 35mm solid ash rails shaped and locked together with mortise and tenon joints.',
    technicalSpecs: [
      { label: 'TIMBER', value: 'Kiln-Dried Ash (FSC)' },
      { label: 'MOISTURE', value: '8% - 10%' },
      { label: 'JOINTS', value: 'Double Dowelled Tenon' },
    ],
    detailNote: 'We never use soft pine or plywood for primary load rails. The frame is the uncompromising skeleton of the chair.',
  },
  {
    step: 3,
    stageCode: 'STAGE 03 // SUSPENSION & PADDING',
    title: 'Webbing & Ergonomic Core',
    subtitle: 'Carbon steel serpentine springs tensioned to 180 N/m.',
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=1200&auto=format&fit=crop',
    caption: 'Interlocking steel springs and Italian Pirelli webbing provide progressive support without bottoming out.',
    technicalSpecs: [
      { label: 'SPRINGS', value: '9-Gauge Carbon Steel' },
      { label: 'WEBBING', value: 'Italian Heavy Jute' },
      { label: 'CORE', value: '45kg/m³ Cold Cure' },
    ],
    detailNote: 'Silent nylon insulation clips ensure that the spring deck remains completely squeak-free throughout decades of continuous use.',
  },
  {
    step: 4,
    stageCode: 'STAGE 04 // TAILORING & FINISH',
    title: 'Precision Upholstery & Stitching',
    subtitle: 'Hand-tailored Melton wool and saddle-stitched leather.',
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?q=80&w=1200&auto=format&fit=crop',
    caption: 'Master tailors align the cloth grain, hand-tack perimeter weltings, and finish solid brass castors.',
    technicalSpecs: [
      { label: 'SEAM ALLOWANCE', value: '12mm Double Stitched' },
      { label: 'THREAD', value: 'Bonded Nylon Tex 90' },
      { label: 'HARDWARE', value: 'Machined C360 Brass' },
    ],
    detailNote: 'Every top-stitch is aligned to within 0.5mm. Fluted channels and piping are hand-shaped to create sculptural depth.',
  },
  {
    step: 5,
    stageCode: 'STAGE 05 // INSTALLED IN ARCHITECTURE',
    title: 'Installed in the Room',
    subtitle: 'The piece takes its permanent place in British architecture.',
    image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?q=80&w=1200&auto=format&fit=crop',
    caption: 'The finished bespoke sofa sitting proudly in a contemporary architectural residence.',
    technicalSpecs: [
      { label: 'SETTING', value: 'Architectural Residence' },
      { label: 'LIFESPAN', value: 'Multi-Generational' },
      { label: 'ORIGIN', value: 'Handmade in Derby, UK' },
    ],
    detailNote: 'Built strictly to room dimensions, the furniture integrates seamlessly into the spatial geometry of the building.',
  },
];

export const DrawingToRoom: React.FC = () => {
  const [activeStepIndex, setActiveStepIndex] = useState<number>(0);
  const currentStep = NARRATIVE_STEPS[activeStepIndex];

  return (
    <section className="w-full bg-[#EEE9E0] py-16 border-b border-[#7A8081]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="border-b border-[#272A2C]/20 pb-6 mb-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono-spec tracking-widest text-[#173B52] bg-[#D9D0C2] inline-block px-2.5 py-1 mb-2 border-l-2 border-[#173B52]">
              SECTION 04 // SIGNATURE NARRATIVE
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif-arch font-bold text-[#173B52] uppercase">
              FROM DRAWING TO ROOM
            </h2>
            <p className="text-sm text-[#272A2C]/80 max-w-2xl mt-1 font-sans">
              Follow the journey of a single bespoke commission: from the initial CAD coordinate drawing 
              in our design office to the timber mill, the upholstery bay, and the finished architectural interior.
            </p>
          </div>

          {/* Step indicator pills */}
          <div className="flex items-center space-x-2">
            {NARRATIVE_STEPS.map((step, idx) => (
              <button
                key={step.step}
                onClick={() => setActiveStepIndex(idx)}
                className={`w-9 h-9 font-mono-spec text-xs font-bold transition-all cursor-pointer flex items-center justify-center border ${
                  activeStepIndex === idx
                    ? 'bg-[#173B52] text-[#EEE9E0] border-[#173B52]'
                    : 'bg-[#D9D0C2]/50 text-[#272A2C] border-[#7A8081]/30 hover:bg-[#D9D0C2]'
                }`}
              >
                0{step.step}
              </button>
            ))}
          </div>
        </div>

        {/* Main Narrative Display Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-[#D9D0C2]/40 border border-[#7A8081]/30 p-6 sm:p-8 shadow-sm">
          {/* Left: Cinematic Photo Stage (7 Cols) */}
          <div className="lg:col-span-7 relative group overflow-hidden border border-[#272A2C]/20 shadow-md">
            <img
              src={currentStep.image}
              alt={currentStep.title}
              className="w-full aspect-[16/10] object-cover filter saturate-[0.95] group-hover:scale-102 transition-transform duration-700"
            />
            {/* Overlay Tag */}
            <div className="absolute top-4 left-4 bg-[#173B52] text-[#EEE9E0] text-[10px] font-mono-spec px-3 py-1 border-l-2 border-[#D9632A]">
              {currentStep.stageCode}
            </div>
            {/* Bottom Caption bar */}
            <div className="absolute bottom-0 inset-x-0 bg-[#272A2C]/90 backdrop-blur-sm text-[#EEE9E0] p-3 text-xs font-mono-spec flex justify-between items-center">
              <span>{currentStep.caption}</span>
            </div>
          </div>

          {/* Right: Technical Explanation & Metrics (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <div className="text-[10px] font-mono-spec text-[#D9632A] uppercase tracking-widest font-bold">
                PHASE 0{currentStep.step} OF 05
              </div>
              <h3 className="text-2xl sm:text-3xl font-serif-arch font-bold text-[#173B52] mt-1">
                {currentStep.title}
              </h3>
              <p className="text-xs font-mono-spec text-[#A77A43] font-semibold mt-1">
                {currentStep.subtitle}
              </p>
            </div>

            <p className="text-xs sm:text-sm text-[#272A2C] leading-relaxed font-sans">
              {currentStep.detailNote}
            </p>

            {/* Technical Parameters Matrix */}
            <div className="bg-[#EEE9E0] p-4 border border-[#7A8081]/30 space-y-2 font-mono-spec text-xs">
              <div className="text-[10px] text-[#7A8081] uppercase tracking-wider border-b border-[#7A8081]/20 pb-1">
                ENGINEERING METRICS
              </div>
              {currentStep.technicalSpecs.map((spec, i) => (
                <div key={i} className="flex justify-between items-center text-[#272A2C]">
                  <span className="text-[#7A8081]">{spec.label}:</span>
                  <span className="font-bold text-[#173B52]">{spec.value}</span>
                </div>
              ))}
            </div>

            {/* Step Navigation Controls */}
            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => setActiveStepIndex(Math.max(0, activeStepIndex - 1))}
                disabled={activeStepIndex === 0}
                className="px-4 py-2 border border-[#173B52] text-[#173B52] font-mono-spec text-xs hover:bg-[#173B52] hover:text-[#EEE9E0] transition-colors disabled:opacity-40 cursor-pointer"
              >
                ← PREVIOUS PHASE
              </button>

              <button
                onClick={() => setActiveStepIndex(Math.min(NARRATIVE_STEPS.length - 1, activeStepIndex + 1))}
                disabled={activeStepIndex === NARRATIVE_STEPS.length - 1}
                className="px-4 py-2 bg-[#173B52] text-[#EEE9E0] font-mono-spec text-xs hover:bg-[#272A2C] transition-colors disabled:opacity-40 cursor-pointer flex items-center space-x-1"
              >
                <span>NEXT PHASE</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
