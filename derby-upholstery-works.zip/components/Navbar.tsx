'use client';

import React, { useState, useEffect } from 'react';
import { ProjectItem } from '@/types/furniture';
import { 
  Compass, 
  Layers, 
  FileText, 
  Briefcase, 
  BookOpen, 
  ShoppingBag, 
  Menu, 
  X,
  Sliders,
  Sparkles
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  projectItems: ProjectItem[];
  onOpenProjectDrawer: () => void;
  onOpenTradePortal: () => void;
  tradeMode: boolean;
  setTradeMode: (mode: boolean) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  projectItems,
  onOpenProjectDrawer,
  tradeMode,
  setTradeMode,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'home', label: 'THE ATELIER' },
    { id: 'catalogue', label: 'FURNITURE' },
    { id: 'configurator', label: 'BESPOKE CONFIG' },
    { id: 'anatomy', label: 'ANATOMY' },
    { id: 'materials', label: 'MATERIALS' },
    { id: 'craft', label: 'CRAFT & RESTORATION' },
    { id: 'trade', label: 'TRADE / ARCHITECTS' },
    { id: 'journal', label: 'JOURNAL' },
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
    if (id === 'trade') {
      setTradeMode(true);
    }
  };

  const totalCount = projectItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <>
      {/* Top Engineering Coordinates Strip */}
      <div className="bg-[#173B52] text-[#EEE9E0] text-[11px] font-mono-spec py-1.5 px-4 sm:px-8 border-b border-[#272A2C]/20 flex justify-between items-center z-50 relative">
        <div className="flex items-center space-x-3 sm:space-x-6 overflow-hidden">
          <span className="flex items-center space-x-1 text-[#D9632A] font-semibold">
            <span className="w-1.5 h-1.5 rounded-full bg-[#D9632A] animate-pulse inline-block" />
            <span>DERBY WORKSHOP / ACTIVE</span>
          </span>
          <span className="hidden md:inline text-[#EEE9E0]/60">LOC: 52.9225° N, 1.4746° W</span>
          <span className="hidden lg:inline text-[#EEE9E0]/60">TOLERANCE: ±0.5MM</span>
          <span className="text-[#A77A43]">EST. DERWENT VALLEY</span>
        </div>
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => {
              setTradeMode(!tradeMode);
              if (!tradeMode) setActiveTab('trade');
            }}
            className={`px-2 py-0.5 text-[10px] uppercase font-mono-spec transition-colors ${
              tradeMode 
                ? 'bg-[#A77A43] text-white font-bold' 
                : 'text-[#EEE9E0]/80 hover:text-white border border-[#EEE9E0]/30'
            }`}
          >
            {tradeMode ? 'TRADE PORTAL ACTIVE' : 'SWITCH TO B2B TRADE'}
          </button>
          <span className="hidden sm:inline text-[#EEE9E0]/50 font-mono-spec text-[10px]">DERBY, ENGLAND</span>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          scrolled
            ? 'bg-[#EEE9E0]/95 backdrop-blur-md shadow-sm border-b border-[#7A8081]/20 py-3'
            : 'bg-[#EEE9E0] border-b border-[#7A8081]/20 py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Logo Lockup */}
          <button
            onClick={() => handleNavClick('home')}
            className="text-left group flex items-center space-x-3 cursor-pointer"
          >
            <div className="w-9 h-9 border border-[#173B52] bg-[#173B52] text-[#EEE9E0] flex items-center justify-center font-mono-spec font-bold text-sm tracking-tighter group-hover:bg-[#D9632A] group-hover:border-[#D9632A] transition-colors">
              DUW
            </div>
            <div>
              <div className="font-serif-arch font-bold text-sm sm:text-base tracking-[0.2em] text-[#173B52] leading-tight group-hover:text-[#272A2C] transition-colors">
                DERBY
              </div>
              <div className="text-[10px] tracking-[0.25em] font-mono-spec text-[#7A8081] font-semibold leading-none">
                UPHOLSTERY WORKS
              </div>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center space-x-1 lg:space-x-3">
            {navLinks.map((link) => {
              const isActive = activeTab === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`px-3 py-1.5 text-xs font-mono-spec tracking-wider transition-all cursor-pointer relative ${
                    isActive
                      ? 'text-[#173B52] font-bold'
                      : 'text-[#272A2C]/80 hover:text-[#173B52] hover:bg-[#D9D0C2]/40'
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-3 right-3 h-[2px] bg-[#173B52]" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Icons */}
          <div className="flex items-center space-x-3">
            {/* Quick Config Button */}
            <button
              onClick={() => handleNavClick('configurator')}
              className="hidden sm:flex items-center space-x-1.5 text-xs font-mono-spec px-3 py-1.5 border border-[#173B52] text-[#173B52] hover:bg-[#173B52] hover:text-[#EEE9E0] transition-all cursor-pointer"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>CONFIGURATOR</span>
            </button>

            {/* "YOUR PROJECT" Drawer Button */}
            <button
              onClick={onOpenProjectDrawer}
              className="flex items-center space-x-2 bg-[#173B52] text-[#EEE9E0] px-3.5 py-2 hover:bg-[#272A2C] transition-all cursor-pointer font-mono-spec text-xs relative"
              aria-label="Open your project drawer"
            >
              <FileText className="w-4 h-4 text-[#A77A43]" />
              <span className="hidden sm:inline">YOUR PROJECT</span>
              <span className="inline-block bg-[#D9632A] text-white text-[10px] px-1.5 py-0.2 rounded-none font-bold">
                {totalCount}
              </span>
            </button>

            {/* Mobile menu trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 text-[#173B52] hover:bg-[#D9D0C2]/50 cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="xl:hidden border-t border-[#7A8081]/20 bg-[#EEE9E0] px-4 pt-3 pb-6 space-y-1">
            <div className="grid grid-cols-1 gap-1">
              {navLinks.map((link) => {
                const isActive = activeTab === link.id;
                return (
                  <button
                    key={link.id}
                    onClick={() => handleNavClick(link.id)}
                    className={`text-left px-3 py-2.5 text-sm font-mono-spec tracking-wider transition-colors flex justify-between items-center ${
                      isActive
                        ? 'bg-[#173B52] text-[#EEE9E0] font-bold'
                        : 'text-[#272A2C] hover:bg-[#D9D0C2]/50'
                    }`}
                  >
                    <span>{link.label}</span>
                    {isActive && <span className="text-[10px] text-[#A77A43]">ACTIVE</span>}
                  </button>
                );
              })}
            </div>
            <div className="pt-3 border-t border-[#7A8081]/20 flex flex-col space-y-2">
              <button
                onClick={() => {
                  setTradeMode(!tradeMode);
                  setMobileMenuOpen(false);
                }}
                className="w-full text-center py-2 text-xs font-mono-spec bg-[#D9D0C2] text-[#272A2C] font-semibold"
              >
                {tradeMode ? 'DISABLE TRADE PORTAL' : 'ENABLE ARCHITECT / TRADE MODE'}
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
