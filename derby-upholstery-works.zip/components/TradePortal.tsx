'use client';

import React, { useState } from 'react';
import { TRADE_PROJECTS, DRAWING_REVISIONS, MATERIALS_DATABASE } from '@/data/mockData';
import { TradeProject, DrawingRevision, MaterialSwatch } from '@/types/furniture';
import { 
  Briefcase, 
  FileText, 
  Layers, 
  CheckCircle2, 
  Clock, 
  Download, 
  Send, 
  Plus, 
  Box, 
  Sliders,
  ChevronRight,
  ShieldCheck,
  Building2
} from 'lucide-react';

interface TradePortalProps {
  onOpenSampleBox: () => void;
  sampleItemsCount: number;
}

export const TradePortal: React.FC<TradePortalProps> = ({
  onOpenSampleBox,
  sampleItemsCount,
}) => {
  const [activeTab, setActiveTab] = useState<'PROJECTS' | 'DRAWINGS' | 'SAMPLES' | 'SCHEDULE'>('PROJECTS');
  const [selectedProject, setSelectedProject] = useState<TradeProject>(TRADE_PROJECTS[0]);
  const [drawingRevisions, setDrawingRevisions] = useState<DrawingRevision[]>(DRAWING_REVISIONS);
  const [sampleRequested, setSampleRequested] = useState<boolean>(false);

  const handleApproveRevision = (id: string) => {
    setDrawingRevisions((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status: 'APPROVED', date: 'TODAY' } : d))
    );
  };

  return (
    <section id="trade" className="w-full bg-[#272A2C] text-[#EEE9E0] py-16 border-b border-[#7A8081]/30 relative overflow-hidden">
      {/* Background blueprint dark grid */}
      <div className="absolute inset-0 bg-blueprint-dark opacity-40 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Portal Header */}
        <div className="border-b border-[#7A8081]/30 pb-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono-spec tracking-widest text-[#A77A43] bg-[#173B52] inline-block px-2.5 py-1 mb-2 border-l-2 border-[#D9632A]">
              B2B SPECIFIER PORTAL // ARCHITECTS & INTERIOR DESIGNERS
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif-arch font-bold text-[#EEE9E0] uppercase">
              DESIGNER & ARCHITECT PORTAL
            </h2>
            <p className="text-sm text-[#EEE9E0]/70 max-w-2xl mt-1 font-sans">
              Dedicated commercial project management, CAD drawing revision workflows, trade material schedules, 
              and direct workshop production telemetry.
            </p>
          </div>

          {/* Trade Account Badge */}
          <div className="bg-[#173B52] p-3 border border-[#7A8081]/40 flex items-center space-x-3">
            <Building2 className="w-5 h-5 text-[#A77A43]" />
            <div>
              <div className="text-[10px] font-mono-spec text-[#EEE9E0]/60">TRADE SPECIFIER ACC</div>
              <div className="font-mono-spec text-xs font-bold text-[#EEE9E0]">
                GOULDEN & THORNE ARCHITECTURE
              </div>
            </div>
          </div>
        </div>

        {/* Portal Navigation Tabs */}
        <div className="flex items-center space-x-2 border-b border-[#7A8081]/30 mb-8 overflow-x-auto">
          {[
            { id: 'PROJECTS', label: 'LIVE CONTRACT PROJECTS' },
            { id: 'DRAWINGS', label: 'CAD DRAWINGS & REVISIONS' },
            { id: 'SAMPLES', label: 'TRADE SAMPLE BOXES' },
            { id: 'SCHEDULE', label: 'CRIB 5 MATERIAL SCHEDULE' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-3 text-xs font-mono-spec tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-[#173B52] text-[#EEE9E0] font-bold border-b-2 border-[#D9632A]'
                  : 'text-[#EEE9E0]/60 hover:text-[#EEE9E0] hover:bg-[#173B52]/40'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* TAB 1: LIVE CONTRACT PROJECTS */}
        {activeTab === 'PROJECTS' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Project List (7 Cols) */}
            <div className="lg:col-span-7 space-y-4">
              {TRADE_PROJECTS.map((proj) => {
                const isSelected = selectedProject.id === proj.id;
                return (
                  <div
                    key={proj.id}
                    onClick={() => setSelectedProject(proj)}
                    className={`bg-[#173B52]/70 border p-5 transition-all cursor-pointer relative ${
                      isSelected
                        ? 'border-[#D9632A] ring-1 ring-[#D9632A]'
                        : 'border-[#7A8081]/30 hover:border-[#EEE9E0]/50'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="text-[10px] font-mono-spec text-[#A77A43] font-bold">
                          {proj.code} // {proj.projectType}
                        </div>
                        <h4 className="text-xl font-serif-arch font-bold text-[#EEE9E0] mt-0.5">
                          {proj.title}
                        </h4>
                        <div className="text-xs font-mono-spec text-[#EEE9E0]/70 mt-0.5">
                          CLIENT: {proj.client} • {proj.location}
                        </div>
                      </div>
                      <span className="bg-[#272A2C] text-[#D9632A] text-[10px] font-mono-spec px-2.5 py-1 font-bold border border-[#7A8081]/30">
                        {proj.status.replace('_', ' ')}
                      </span>
                    </div>

                    <p className="text-xs text-[#EEE9E0]/80 mt-3 font-sans">
                      {proj.furnitureDescription}
                    </p>

                    {/* Progress Bar */}
                    <div className="mt-4 space-y-1">
                      <div className="flex justify-between text-[10px] font-mono-spec text-[#EEE9E0]/60">
                        <span>WORKSHOP PROGRESS</span>
                        <span className="text-[#A77A43] font-bold">{proj.progressPercentage}%</span>
                      </div>
                      <div className="w-full bg-[#272A2C] h-2 border border-[#7A8081]/30">
                        <div
                          className="bg-[#D9632A] h-full transition-all duration-500"
                          style={{ width: `${proj.progressPercentage}%` }}
                        />
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-[#7A8081]/20 flex justify-between items-center text-[10px] font-mono-spec text-[#EEE9E0]/60">
                      <span>CURRENT REV: <strong className="text-[#EEE9E0]">{proj.currentRevision}</strong></span>
                      <span>DELIVERY: <strong className="text-[#EEE9E0]">{proj.deliveryDate}</strong></span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Selected Project Full Spec Inspector (5 Cols) */}
            <div className="lg:col-span-5 bg-[#173B52] border border-[#272A2C] p-6 space-y-5 shadow-xl">
              <div className="border-b border-[#EEE9E0]/20 pb-3">
                <div className="text-[10px] font-mono-spec text-[#A77A43] tracking-widest uppercase">
                  CONTRACT PROJECT FILE
                </div>
                <h3 className="text-2xl font-serif-arch font-bold text-[#EEE9E0] mt-1">
                  {selectedProject.title}
                </h3>
                <div className="text-xs font-mono-spec text-[#D9632A]">
                  UNITS: {selectedProject.unitsCount} BESPOKE ITEMS
                </div>
              </div>

              <div className="space-y-3 font-mono-spec text-xs bg-[#272A2C]/60 p-4 border border-[#7A8081]/30">
                <div className="flex justify-between border-b border-[#7A8081]/30 pb-1.5">
                  <span className="text-[#EEE9E0]/60">PROJECT CODE:</span>
                  <span className="text-[#EEE9E0] font-bold">{selectedProject.code}</span>
                </div>
                <div className="flex justify-between border-b border-[#7A8081]/30 pb-1.5">
                  <span className="text-[#EEE9E0]/60">LEAD DESIGNER:</span>
                  <span className="text-[#EEE9E0]">{selectedProject.leadDesigner}</span>
                </div>
                <div className="flex justify-between border-b border-[#7A8081]/30 pb-1.5">
                  <span className="text-[#EEE9E0]/60">DRAWING REVISION:</span>
                  <span className="text-[#A77A43] font-bold">{selectedProject.currentRevision}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#EEE9E0]/60">EST. DISPATCH:</span>
                  <span className="text-[#D9632A] font-bold">{selectedProject.deliveryDate}</span>
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-[10px] font-mono-spec text-[#A77A43] uppercase">
                  ACTIVE PRODUCTION LOG
                </div>
                <div className="bg-[#272A2C] p-3 text-xs text-[#EEE9E0]/80 space-y-1 font-mono-spec">
                  <div>• Ash frame milling completed in Bay 02.</div>
                  <div>• Crib 5 heavy Melton fabric delivered from Leeds mill.</div>
                  <div>• Upholstery team executing hand top-stitching.</div>
                </div>
              </div>

              <button
                onClick={() => {
                  alert(`Downloaded CAD Production drawing set & cutting schedule for ${selectedProject.title}.`);
                }}
                className="w-full py-3 bg-[#D9632A] hover:bg-[#D9632A]/90 text-white font-mono-spec text-xs font-bold tracking-wider transition-colors flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>DOWNLOAD FULL CAD & CUTTING PACK</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: CAD DRAWINGS & REVISIONS */}
        {activeTab === 'DRAWINGS' && (
          <div className="space-y-4">
            <div className="bg-[#173B52] p-4 border border-[#7A8081]/30 flex justify-between items-center font-mono-spec text-xs">
              <span className="text-[#A77A43] font-bold">DERBY DRAWING REGISTER // DWG-ARCHIVE-2026</span>
              <span className="text-[#EEE9E0]/70">ALL ELEVATIONS SCALED TO BS 8888</span>
            </div>

            <div className="space-y-3">
              {drawingRevisions.map((rev) => (
                <div
                  key={rev.id}
                  className="bg-[#173B52]/60 border border-[#7A8081]/30 p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2 font-mono-spec text-xs">
                      <span className="bg-[#272A2C] text-[#A77A43] px-2 py-0.5 font-bold">
                        {rev.drawingNumber}
                      </span>
                      <span className="text-[#D9632A] font-bold">{rev.revision}</span>
                      <span className="text-[#EEE9E0]/60">• SCALE: {rev.scale}</span>
                    </div>
                    <h4 className="text-lg font-serif-arch font-bold text-[#EEE9E0]">
                      {rev.title}
                    </h4>
                    <p className="text-xs text-[#EEE9E0]/70 font-sans">
                      {rev.notes}
                    </p>
                    <div className="text-[10px] font-mono-spec text-[#7A8081]">
                      APPROVED BY: {rev.approvedBy} • {rev.date}
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 shrink-0">
                    <button
                      onClick={() => alert(`Opening CAD elevation viewer for ${rev.drawingNumber}`)}
                      className="px-3 py-2 border border-[#EEE9E0]/30 text-[#EEE9E0] font-mono-spec text-xs hover:bg-[#EEE9E0]/10 transition-colors cursor-pointer"
                    >
                      VIEW CAD
                    </button>
                    {rev.status !== 'APPROVED' ? (
                      <button
                        onClick={() => handleApproveRevision(rev.id)}
                        className="px-4 py-2 bg-[#A77A43] hover:bg-[#A77A43]/90 text-white font-mono-spec text-xs font-bold transition-colors cursor-pointer"
                      >
                        SIGN OFF REV
                      </button>
                    ) : (
                      <div className="px-3 py-2 bg-[#272A2C] text-[#A77A43] font-mono-spec text-xs font-bold flex items-center space-x-1 border border-[#A77A43]/40">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#D9632A]" />
                        <span>APPROVED</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: SAMPLES */}
        {activeTab === 'SAMPLES' && (
          <div className="bg-[#173B52] border border-[#272A2C] p-8 space-y-6">
            <div className="max-w-2xl">
              <h3 className="text-2xl font-serif-arch font-bold text-[#EEE9E0]">
                REQUEST ARCHITECTURAL SAMPLE BOX
              </h3>
              <p className="text-xs text-[#EEE9E0]/80 mt-1 font-sans leading-relaxed">
                We assemble curated wooden specimen boxes containing heavy-weight British wools, full-grain aniline leather swatches, 
                kiln-dried ash timber chips, and solid turned brass hardware samples.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono-spec text-xs">
              <div className="bg-[#272A2C] p-4 border border-[#7A8081]/30">
                <div className="text-[10px] text-[#A77A43]">BOX TYPE A</div>
                <div className="font-bold text-sm text-[#EEE9E0] mt-1">HOSPITALITY CRIB 5</div>
                <div className="text-[10px] text-[#EEE9E0]/60 mt-1">Heavy Meltons, Velvets & Crib 5 Leathers</div>
              </div>
              <div className="bg-[#272A2C] p-4 border border-[#7A8081]/30">
                <div className="text-[10px] text-[#A77A43]">BOX TYPE B</div>
                <div className="font-bold text-sm text-[#EEE9E0] mt-1">RESIDENTIAL LUXURY</div>
                <div className="text-[10px] text-[#EEE9E0]/60 mt-1">Raw Belgian Linens, Bouclé & Aniline Hides</div>
              </div>
              <div className="bg-[#272A2C] p-4 border border-[#7A8081]/30">
                <div className="text-[10px] text-[#A77A43]">BOX TYPE C</div>
                <div className="font-bold text-sm text-[#EEE9E0] mt-1">TIMBER & HARDWARE</div>
                <div className="text-[10px] text-[#EEE9E0]/60 mt-1">Ash, Oak, Brass & Cast Iron finishes</div>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => {
                  setSampleRequested(true);
                  setTimeout(() => setSampleRequested(false), 3000);
                }}
                className="py-3 px-8 bg-[#D9632A] hover:bg-[#D9632A]/90 text-white font-mono-spec text-xs font-bold tracking-wider transition-colors cursor-pointer"
              >
                {sampleRequested ? 'SAMPLE BOX REQUEST DISPATCHED TO DERBY WORKS' : 'ORDER COMPLETE SPECIFIER SAMPLE BOX'}
              </button>
            </div>
          </div>
        )}

        {/* TAB 4: SCHEDULE */}
        {activeTab === 'SCHEDULE' && (
          <div className="bg-[#173B52] border border-[#272A2C] p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-[#EEE9E0]/20 pb-3 font-mono-spec text-xs">
              <span className="font-bold text-[#A77A43]">CONTRACT MATERIAL SCHEDULE // COMPLIANCE SHEET</span>
              <span className="text-[#EEE9E0]/60">BS 5852 CRIB 5 / CAL 117</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono-spec text-xs">
                <thead>
                  <tr className="border-b border-[#7A8081]/30 text-[#A77A43]">
                    <th className="py-2">CODE</th>
                    <th className="py-2">MATERIAL</th>
                    <th className="py-2">COMPOSITION</th>
                    <th className="py-2">MARTINDALE</th>
                    <th className="py-2">FIRE CERT</th>
                    <th className="py-2">TRADE RATE</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#7A8081]/20 text-[#EEE9E0]">
                  {MATERIALS_DATABASE.map((mat) => (
                    <tr key={mat.id} className="hover:bg-[#272A2C]/40">
                      <td className="py-2.5 font-bold text-[#D9632A]">{mat.id.toUpperCase()}</td>
                      <td className="py-2.5 font-semibold">{mat.name}</td>
                      <td className="py-2.5 text-[#EEE9E0]/70">{mat.composition}</td>
                      <td className="py-2.5">{mat.rubCount.toLocaleString()}</td>
                      <td className="py-2.5 text-[#A77A43]">{mat.fireRating.split('/')[0]}</td>
                      <td className="py-2.5 font-bold">£{mat.pricePerMeter}/m</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
