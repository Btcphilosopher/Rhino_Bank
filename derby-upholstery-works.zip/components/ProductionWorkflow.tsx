'use client';

import React, { useState, useEffect } from 'react';
import { Clock, CheckCircle2, ChevronRight, Activity, ArrowRight, ShieldCheck } from 'lucide-react';

interface StageDetail {
  id: string;
  time: string;
  code: string;
  name: string;
  location: string;
  craftsperson: string;
  inspectionStandard: string;
  description: string;
}

const WORKSHOP_STAGES: StageDetail[] = [
  {
    id: 'stg-01',
    time: '08:00 - 09:30',
    code: 'BAY-01 / CAD',
    name: 'CAD Dimensioning & Scale Plans',
    location: 'Design Drawing Office, Level 2',
    craftsperson: 'H. Faulkner (Structural CAD Lead)',
    inspectionStandard: 'Elevation coordinates signed off to ±0.5mm',
    description: 'Client architectural plans are translated into CNC cutting files and 1:1 joinery templates with strict pitch and rake verification.',
  },
  {
    id: 'stg-02',
    time: '09:30 - 11:45',
    code: 'BAY-02 / MILL',
    name: 'Hardwood Milling & Mortise Joinery',
    location: 'Timber Mill & Joinery Cell',
    craftsperson: 'T. Holme & J. Wright (Master Joiners)',
    inspectionStandard: 'Ash moisture content 8-10%, Mortise tenon fit 0.1mm',
    description: 'FSC Kiln-dried Derbyshire Ash is cross-cut, planed, and mortised. Frame rails are glued, clamped in hydraulic presses, and cured under controlled ambient humidity.',
  },
  {
    id: 'stg-03',
    time: '11:45 - 13:15',
    code: 'BAY-03 / SUSPENSION',
    name: 'Spring Deck & Webbing Tensioning',
    location: 'Suspension & Chassis Cell',
    craftsperson: 'M. Robinson (Spring Specialist)',
    inspectionStandard: '180 N/m tension calibration & silent clip check',
    description: '9-gauge sinuous springs are cross-tied with paper-wrapped anti-squeak wire. Heavy Italian jute webbing is hand-stretched in cross-weave pattern.',
  },
  {
    id: 'stg-04',
    time: '13:15 - 15:00',
    code: 'BAY-04 / CORE',
    name: 'Multi-Density Core & Calico Wrapping',
    location: 'Padding & Ergonomics Bench',
    craftsperson: 'D. Kelly (Core Sculptor)',
    inspectionStandard: 'BS 5852 Crib 5 barrier envelope certification',
    description: 'CMHR 45kg/m³ Cold Cure foam is topped with natural Dunlop latex and 300gsm British wool wrap before hand-stitching the unbleached cotton calico barrier.',
  },
  {
    id: 'stg-05',
    time: '15:00 - 16:30',
    code: 'BAY-05 / TAILORING',
    name: 'Master Tailoring & Top-Stitching',
    location: 'Cleanroom Upholstery Bay',
    craftsperson: 'E. Vance & S. Clarke (Master Upholsterers)',
    inspectionStandard: 'Grain alignment check, double top-stitch 12mm allowance',
    description: 'Melton wool or full-grain leather is cut, pattern-matched, and pulled taut across the frame rails with magnetic tacks and double-needle perimeter stitching.',
  },
  {
    id: 'stg-06',
    time: '16:30 - 17:30',
    code: 'BAY-06 / QC',
    name: 'Quality Inspection & White-Glove Dispatch',
    location: 'Final Inspection & Crating Dock',
    craftsperson: 'A. Mercer (Quality Director)',
    inspectionStandard: '24-point audit signed off with stamped certificate',
    description: 'Every seam, joint, torque-tested castor, and cushion rebound rate is audited before the piece is wrapped in breathable padded cotton blankets for direct delivery.',
  },
];

export const ProductionWorkflow: React.FC = () => {
  const [activeStageId, setActiveStageId] = useState<string>('stg-05');
  const [currentHour, setCurrentHour] = useState<string>('15:42');

  const activeStage = WORKSHOP_STAGES.find((s) => s.id === activeStageId) || WORKSHOP_STAGES[4];

  return (
    <section className="w-full bg-[#173B52] text-[#EEE9E0] py-16 border-b border-[#272A2C] relative overflow-hidden">
      {/* Background blueprint grid */}
      <div className="absolute inset-0 bg-blueprint-dark opacity-30 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="border-b border-[#EEE9E0]/20 pb-6 mb-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono-spec tracking-widest text-[#A77A43] bg-[#272A2C] inline-block px-2.5 py-1 mb-2 border-l-2 border-[#D9632A]">
              SECTION 07 // WORKSHOP TELEMETRY
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif-arch font-bold text-[#EEE9E0] uppercase">
              IN THE DERBY WORKSHOP
            </h2>
            <p className="text-sm text-[#EEE9E0]/70 max-w-2xl mt-1 font-sans">
              Furniture moves through our Derwent Valley facility with the rigor of a precision drawing office. 
              Track the daily manufacturing rhythm across our specialist bays.
            </p>
          </div>

          {/* Real-time workshop clock widget */}
          <div className="bg-[#272A2C] p-3 border border-[#7A8081]/40 flex items-center space-x-3">
            <div className="w-2.5 h-2.5 rounded-full bg-[#D9632A] animate-ping" />
            <div>
              <div className="text-[9px] font-mono-spec text-[#7A8081]">DERBY ATELIER TIME</div>
              <div className="font-mono-spec text-sm font-bold text-[#EEE9E0]">
                {currentHour} GMT // ACTIVE SHIFT
              </div>
            </div>
          </div>
        </div>

        {/* Workflow Pipeline Timeline Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 mb-8">
          {WORKSHOP_STAGES.map((stg, index) => {
            const isSelected = activeStageId === stg.id;
            return (
              <button
                key={stg.id}
                onClick={() => setActiveStageId(stg.id)}
                className={`p-3 text-left border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#D9632A] text-white border-[#D9632A] shadow-lg scale-102'
                    : 'bg-[#272A2C]/80 text-[#EEE9E0]/70 border-[#7A8081]/30 hover:bg-[#272A2C]'
                }`}
              >
                <div>
                  <div className="text-[9px] font-mono-spec uppercase font-bold opacity-80">
                    STAGE 0{index + 1}
                  </div>
                  <div className="text-xs font-mono-spec font-bold mt-1 line-clamp-1">
                    {stg.name.split(' ')[0]} {stg.name.split(' ')[1]}
                  </div>
                </div>
                <div className="text-[10px] font-mono-spec opacity-90 mt-2">
                  {stg.time.split(' ')[0]}
                </div>
              </button>
            );
          })}
        </div>

        {/* Main Stage Detail Inspector */}
        <div className="bg-[#272A2C] border border-[#7A8081]/40 p-6 sm:p-8 shadow-xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-4">
            <div className="flex items-center space-x-3">
              <span className="bg-[#173B52] text-[#A77A43] text-xs font-mono-spec px-3 py-1 font-bold">
                {activeStage.code}
              </span>
              <span className="text-xs font-mono-spec text-[#EEE9E0]/60">
                TIME SLOT: {activeStage.time}
              </span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-serif-arch font-bold text-[#EEE9E0]">
              {activeStage.name}
            </h3>

            <p className="text-xs sm:text-sm text-[#EEE9E0]/80 leading-relaxed font-sans">
              {activeStage.description}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 font-mono-spec text-xs">
              <div className="bg-[#173B52]/70 p-3 border border-[#7A8081]/30">
                <div className="text-[10px] text-[#A77A43] uppercase">LOCATION</div>
                <div className="font-bold text-[#EEE9E0] mt-0.5">{activeStage.location}</div>
              </div>
              <div className="bg-[#173B52]/70 p-3 border border-[#7A8081]/30">
                <div className="text-[10px] text-[#A77A43] uppercase">STATION LEAD</div>
                <div className="font-bold text-[#EEE9E0] mt-0.5">{activeStage.craftsperson}</div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 bg-[#173B52] p-5 border border-[#7A8081]/40 space-y-4">
            <div className="text-[10px] font-mono-spec text-[#D9632A] uppercase tracking-widest font-bold flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4" />
              <span>QUALITY INSPECTION AUDIT</span>
            </div>

            <div className="text-sm font-sans text-[#EEE9E0] font-semibold border-l-2 border-[#A77A43] pl-3">
              &ldquo;{activeStage.inspectionStandard}&rdquo;
            </div>

            <div className="text-[11px] font-mono-spec text-[#EEE9E0]/70 space-y-1">
              <div>✓ Calibrated Digital Gauges</div>
              <div>✓ 100% Traceability Batch Logs</div>
              <div>✓ Derby Workshop Stamped Certificate</div>
            </div>

            <div className="pt-2">
              <div className="text-[10px] font-mono-spec text-[#A77A43]">
                WORKSHOP STATUS: ZERO DEFECT STANDARD
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
