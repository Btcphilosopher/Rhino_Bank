'use client';

import React, { useState, useMemo } from 'react';
import { PRODUCTS_CATALOGUE, MATERIALS_DATABASE } from '@/data/mockData';
import { FurnitureProduct, MaterialSwatch, CustomConfiguration, ArmStyle, BackStyle, LegFinish, CushionFill } from '@/types/furniture';
import { 
  Sliders, 
  Ruler, 
  Check, 
  Layers, 
  ArrowRight, 
  FileCheck, 
  Info, 
  Maximize2,
  Sparkles,
  Download
} from 'lucide-react';

interface ConfiguratorProps {
  onAddToProject: (config: CustomConfiguration) => void;
  onRequestQuote: (config: CustomConfiguration) => void;
}

export const Configurator: React.FC<ConfiguratorProps> = ({
  onAddToProject,
  onRequestQuote,
}) => {
  // Selected Model
  const [selectedProduct, setSelectedProduct] = useState<FurnitureProduct>(PRODUCTS_CATALOGUE[0]);

  // Dimension States
  const [width, setWidth] = useState<number>(selectedProduct.defaultDimensions.width);
  const [depth, setDepth] = useState<number>(selectedProduct.defaultDimensions.depth);
  const [height, setHeight] = useState<number>(selectedProduct.defaultDimensions.height);
  const [seatHeight, setSeatHeight] = useState<number>(selectedProduct.defaultDimensions.seatHeight);

  // Styling States
  const [armStyle, setArmStyle] = useState<ArmStyle>('STRAIGHT_MINIMAL');
  const [backStyle, setBackStyle] = useState<BackStyle>('TIGHT_BACK');
  const [legFinish, setLegFinish] = useState<LegFinish>('TURNED_ASH');
  const [cushionFill, setCushionFill] = useState<CushionFill>('COLD_CURE_DOWN_WRAP');
  const [selectedMaterial, setSelectedMaterial] = useState<MaterialSwatch>(MATERIALS_DATABASE[0]);
  const [piping, setPiping] = useState<'MATCHING' | 'CONTRAST_LEATHER' | 'NO_PIPING'>('MATCHING');
  const [stitching, setStitching] = useState<'SINGLE_NEEDLE' | 'DOUBLE_TOPSTITCH' | 'SADDLE_HAND_STITCH'>('DOUBLE_TOPSTITCH');
  const [quantity, setQuantity] = useState<number>(1);
  const [addedSuccess, setAddedSuccess] = useState<boolean>(false);

  // When model changes, update default dimensions
  const handleProductChange = (prod: FurnitureProduct) => {
    setSelectedProduct(prod);
    setWidth(prod.defaultDimensions.width);
    setDepth(prod.defaultDimensions.depth);
    setHeight(prod.defaultDimensions.height);
    setSeatHeight(prod.defaultDimensions.seatHeight);
  };

  // Dynamic Price Engine Calculation
  const { estimatedPrice, dimensionDelta, materialDelta, hardwareDelta, fabricRequirementMeters } = useMemo(() => {
    // 1. Base price
    const base = selectedProduct.basePrice;

    // 2. Dimension surcharge (proportional to volume change from default)
    const defaultVol = selectedProduct.defaultDimensions.width * selectedProduct.defaultDimensions.depth;
    const currentVol = width * depth;
    const volRatio = currentVol / defaultVol;
    const dimDelta = Math.round((volRatio - 1) * 850);

    // 3. Material requirement calculation based on surface area approximation
    const fabricMeters = Number(((width * 2 + depth * 2 + height * 2) / 1000 * 1.8).toFixed(1));
    const matDelta = Math.round(fabricMeters * (selectedMaterial.pricePerMeter - 100));

    // 4. Leg hardware surcharge
    let hwDelta = 0;
    if (legFinish === 'BRUSHED_BRASS') hwDelta = 180;
    if (legFinish === 'CAST_IRON') hwDelta = 140;
    if (legFinish === 'SMOKED_OAK') hwDelta = 90;

    // 5. Cushion filling surcharge
    let fillDelta = 0;
    if (cushionFill === 'POCKET_SPRUNG_WOOL') fillDelta = 220;
    if (cushionFill === 'DUAL_DENSITY_LATEX') fillDelta = 160;

    const totalPerUnit = Math.max(selectedProduct.basePrice * 0.8, base + dimDelta + matDelta + hwDelta + fillDelta);

    return {
      estimatedPrice: totalPerUnit * quantity,
      dimensionDelta: dimDelta,
      materialDelta: matDelta,
      hardwareDelta: hwDelta + fillDelta,
      fabricRequirementMeters: fabricMeters,
    };
  }, [selectedProduct, width, depth, height, selectedMaterial, legFinish, cushionFill, quantity]);

  const currentConfiguration: CustomConfiguration = {
    productId: selectedProduct.id,
    productName: selectedProduct.name,
    productCode: selectedProduct.code,
    width,
    depth,
    height,
    seatHeight,
    armStyle,
    backStyle,
    legFinish,
    cushionFill,
    material: selectedMaterial,
    piping,
    stitching,
    quantity,
    estimatedPrice,
    calculatedLeadTime: selectedProduct.leadTimeWeeks,
  };

  const handleAdd = () => {
    onAddToProject(currentConfiguration);
    setAddedSuccess(true);
    setTimeout(() => setAddedSuccess(false), 2500);
  };

  // Visual SVG proportional scaling
  // Base scale calculation: normal width 2140 maps to ~380px in SVG
  const svgWidthRatio = Math.min(1.4, Math.max(0.7, width / 2140));
  const svgHeightRatio = Math.min(1.3, Math.max(0.8, height / 780));

  return (
    <section id="configurator" className="w-full bg-[#EEE9E0] py-16 border-b border-[#7A8081]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="border-b border-[#272A2C]/20 pb-6 mb-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono-spec tracking-widest text-[#173B52] bg-[#D9D0C2] inline-block px-2.5 py-1 mb-2">
              SECTION 02 // PARAMETRIC BESPOKE ENGINE
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif-arch font-bold text-[#173B52] uppercase">
              DESIGN YOUR PIECE
            </h2>
            <p className="text-sm text-[#272A2C]/80 max-w-2xl mt-1">
              Select an archetype, adjust structural dimensions in millimeter increments, choose kiln-dried timbers, 
              hardware finishes, and hand-woven British upholstery fabrics.
            </p>
          </div>

          {/* Model Selector Strip */}
          <div className="flex items-center space-x-1 overflow-x-auto pb-2 md:pb-0">
            {PRODUCTS_CATALOGUE.slice(0, 4).map((prod) => (
              <button
                key={prod.id}
                onClick={() => handleProductChange(prod)}
                className={`px-3 py-2 text-xs font-mono-spec transition-all whitespace-nowrap cursor-pointer ${
                  selectedProduct.id === prod.id
                    ? 'bg-[#173B52] text-[#EEE9E0] font-bold shadow-sm'
                    : 'bg-[#D9D0C2]/60 text-[#272A2C] hover:bg-[#D9D0C2]'
                }`}
              >
                {prod.name.replace('The ', '')}
              </button>
            ))}
          </div>
        </div>

        {/* Configurator 2-Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Interactive Parametric Blueprint Visualiser (7 Cols) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Live Vector Blueprint Viewport */}
            <div className="bg-[#272A2C] text-[#EEE9E0] p-6 border border-[#173B52] relative shadow-lg overflow-hidden flex flex-col justify-between min-h-[460px]">
              {/* Blueprint Grid Overlay */}
              <div className="absolute inset-0 bg-blueprint-dark pointer-events-none opacity-40" />

              {/* Viewport Top Bar */}
              <div className="relative z-10 flex items-center justify-between border-b border-[#7A8081]/30 pb-3 font-mono-spec text-[11px]">
                <div className="flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-[#D9632A]" />
                  <span className="text-[#A77A43] font-bold">{selectedProduct.code}</span>
                  <span>// BESPOKE PARAMETRIC MODEL</span>
                </div>
                <div className="text-[#EEE9E0]/70 text-right">
                  <span>SCALE: 1:10 PROPORTIONAL</span>
                </div>
              </div>

              {/* Scalable Dynamic SVG Blueprint */}
              <div className="relative z-10 flex-1 flex items-center justify-center my-6">
                <svg
                  className="w-full max-h-[300px] transition-all duration-300 ease-out"
                  viewBox="0 0 600 320"
                  fill="none"
                  style={{ transform: `scale(${0.9 + (svgWidthRatio - 1) * 0.2})` }}
                >
                  {/* Outer Dimension Dimensioning Lines */}
                  {/* Width Line */}
                  <line x1="80" y1="40" x2="520" y2="40" stroke="#D9632A" strokeWidth="1" strokeDasharray="2 2" />
                  <line x1="80" y1="35" x2="80" y2="45" stroke="#D9632A" strokeWidth="1.5" />
                  <line x1="520" y1="35" x2="520" y2="45" stroke="#D9632A" strokeWidth="1.5" />
                  <text x="300" y="32" fill="#D9632A" fontSize="12" fontFamily="monospace" textAnchor="middle" fontWeight="bold">
                    WIDTH: {width} MM
                  </text>

                  {/* Height Line */}
                  <line x1="550" y1="60" x2="550" y2="250" stroke="#A77A43" strokeWidth="1" strokeDasharray="2 2" />
                  <line x1="545" y1="60" x2="555" y2="60" stroke="#A77A43" strokeWidth="1.5" />
                  <line x1="545" y1="250" x2="555" y2="250" stroke="#A77A43" strokeWidth="1.5" />
                  <text x="560" y="155" fill="#A77A43" fontSize="10" fontFamily="monospace" textAnchor="start">
                    H: {height}MM
                  </text>

                  {/* Main Furniture Geometry */}
                  <g className="transition-all duration-200">
                    {/* Shadow Ground */}
                    <ellipse cx="300" cy="265" rx={180 * svgWidthRatio} ry="10" fill="#000" fillOpacity="0.4" />

                    {/* Legs */}
                    {legFinish === 'BRUSHED_BRASS' && (
                      <>
                        <rect x={120} y="230" width="16" height="30" fill="#A77A43" stroke="#D9D0C2" strokeWidth="1" />
                        <rect x={464} y="230" width="16" height="30" fill="#A77A43" stroke="#D9D0C2" strokeWidth="1" />
                        <circle cx={128} cy="262" r="5" fill="#A77A43" />
                        <circle cx={472} cy="262" r="5" fill="#A77A43" />
                      </>
                    )}
                    {legFinish === 'CAST_IRON' && (
                      <>
                        <polygon points="120,230 134,230 130,260 124,260" fill="#272A2C" stroke="#7A8081" strokeWidth="1.5" />
                        <polygon points="466,230 480,230 476,260 470,260" fill="#272A2C" stroke="#7A8081" strokeWidth="1.5" />
                      </>
                    )}
                    {legFinish === 'TURNED_ASH' && (
                      <>
                        <rect x={120} y="230" width="14" height="30" fill="#D9D0C2" stroke="#7A8081" strokeWidth="1" />
                        <rect x={466} y="230" width="14" height="30" fill="#D9D0C2" stroke="#7A8081" strokeWidth="1" />
                      </>
                    )}
                    {legFinish === 'SMOKED_OAK' && (
                      <>
                        <rect x={120} y="230" width="14" height="30" fill="#3D3028" stroke="#A77A43" strokeWidth="1" />
                        <rect x={466} y="230" width="14" height="30" fill="#3D3028" stroke="#A77A43" strokeWidth="1" />
                      </>
                    )}

                    {/* Main Upholstery Body colored by Selected Material */}
                    {/* Backrest */}
                    <rect
                      x={140}
                      y={70}
                      width={320}
                      height={100}
                      rx="3"
                      fill={selectedMaterial.hex}
                      stroke="#EEE9E0"
                      strokeWidth="1.5"
                      fillOpacity="0.9"
                    />

                    {/* Backrest Stitching/Fluting effect */}
                    {backStyle === 'FLUTED_CHANNEL' && (
                      <>
                        <line x1="200" y1="70" x2="200" y2="170" stroke="#EEE9E0" strokeWidth="1" strokeDasharray="4 2" />
                        <line x1="260" y1="70" x2="260" y2="170" stroke="#EEE9E0" strokeWidth="1" strokeDasharray="4 2" />
                        <line x1="340" y1="70" x2="340" y2="170" stroke="#EEE9E0" strokeWidth="1" strokeDasharray="4 2" />
                        <line x1="400" y1="70" x2="400" y2="170" stroke="#EEE9E0" strokeWidth="1" strokeDasharray="4 2" />
                      </>
                    )}
                    {backStyle === 'DEEP_BUTTONED' && (
                      <>
                        <circle cx="200" cy="110" r="3" fill="#272A2C" />
                        <circle cx="260" cy="110" r="3" fill="#272A2C" />
                        <circle cx="340" cy="110" r="3" fill="#272A2C" />
                        <circle cx="400" cy="110" r="3" fill="#272A2C" />
                      </>
                    )}

                    {/* Arms */}
                    {armStyle === 'STRAIGHT_MINIMAL' && (
                      <>
                        <rect x={100} y="110" width="40" height="110" rx="2" fill={selectedMaterial.hex} stroke="#EEE9E0" strokeWidth="1.5" />
                        <rect x={460} y="110" width="40" height="110" rx="2" fill={selectedMaterial.hex} stroke="#EEE9E0" strokeWidth="1.5" />
                      </>
                    )}
                    {armStyle === 'ENGLISH_ROLL' && (
                      <>
                        <path d="M 100 220 L 100 130 C 100 100, 140 100, 140 130 L 140 220 Z" fill={selectedMaterial.hex} stroke="#EEE9E0" strokeWidth="1.5" />
                        <path d="M 460 220 L 460 130 C 460 100, 500 100, 500 130 L 500 220 Z" fill={selectedMaterial.hex} stroke="#EEE9E0" strokeWidth="1.5" />
                      </>
                    )}
                    {armStyle === 'ARCHITECTURAL_BOX' && (
                      <>
                        <rect x={90} y="95" width="50" height="125" rx="0" fill={selectedMaterial.hex} stroke="#EEE9E0" strokeWidth="2" />
                        <rect x={460} y="95" width="50" height="125" rx="0" fill={selectedMaterial.hex} stroke="#EEE9E0" strokeWidth="2" />
                      </>
                    )}
                    {armStyle === 'FLUTED_SLIM' && (
                      <>
                        <rect x={115} y="120" width="25" height="100" rx="4" fill={selectedMaterial.hex} stroke="#EEE9E0" strokeWidth="1.5" />
                        <rect x={460} y="120" width="25" height="100" rx="4" fill={selectedMaterial.hex} stroke="#EEE9E0" strokeWidth="1.5" />
                      </>
                    )}

                    {/* Base Seat Deck & Thick Cushions */}
                    <rect x={135} y="180" width="160" height="45" rx="3" fill={selectedMaterial.hex} stroke="#EEE9E0" strokeWidth="1.5" />
                    <rect x={305} y="180" width="160" height="45" rx="3" fill={selectedMaterial.hex} stroke="#EEE9E0" strokeWidth="1.5" />

                    {/* Piping Accent */}
                    {piping === 'CONTRAST_LEATHER' && (
                      <>
                        <rect x={135} y="180" width="160" height="45" rx="3" fill="none" stroke="#6F302D" strokeWidth="2" />
                        <rect x={305} y="180" width="160" height="45" rx="3" fill="none" stroke="#6F302D" strokeWidth="2" />
                      </>
                    )}

                    {/* Plinth Frame Base */}
                    <rect x={100} y="220" width="400" height="12" fill="#272A2C" stroke="#7A8081" strokeWidth="1" />
                  </g>
                </svg>
              </div>

              {/* Bottom Real-Time Material & Spec Tag */}
              <div className="relative z-10 bg-[#173B52] p-3 border-t border-[#7A8081]/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 font-mono-spec text-xs">
                <div className="flex items-center space-x-2">
                  <span className="w-3.5 h-3.5 border border-[#EEE9E0]" style={{ backgroundColor: selectedMaterial.hex }} />
                  <span className="font-bold text-[#EEE9E0]">{selectedMaterial.name}</span>
                  <span className="text-[#A77A43]">({selectedMaterial.colour})</span>
                </div>
                <div className="text-[11px] text-[#EEE9E0]/70">
                  EST. CLOTH: <span className="text-[#EEE9E0] font-bold">{fabricRequirementMeters}M</span> | RUB COUNT: <span className="text-[#EEE9E0] font-bold">{selectedMaterial.rubCount.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Live Price & Spec Breakdown Box */}
            <div className="bg-[#D9D0C2] border border-[#7A8081]/40 p-5 space-y-4">
              <div className="flex justify-between items-center border-b border-[#272A2C]/20 pb-3">
                <div>
                  <div className="text-[10px] font-mono-spec text-[#7A8081] uppercase tracking-wider">
                    CALCULATED UNIT ESTIMATE
                  </div>
                  <div className="text-2xl sm:text-3xl font-serif-arch font-bold text-[#173B52]">
                    £{estimatedPrice.toLocaleString()} <span className="text-xs font-sans text-[#272A2C] font-normal">EX VAT</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] font-mono-spec text-[#7A8081]">LEAD TIME</div>
                  <div className="text-sm font-mono-spec font-bold text-[#D9632A]">{selectedProduct.leadTimeWeeks}</div>
                </div>
              </div>

              {/* Price itemization */}
              <div className="space-y-1.5 font-mono-spec text-xs text-[#272A2C]">
                <div className="flex justify-between">
                  <span>Base Model ({selectedProduct.name}):</span>
                  <span>£{selectedProduct.basePrice.toLocaleString()}</span>
                </div>
                {dimensionDelta !== 0 && (
                  <div className="flex justify-between text-[#173B52]">
                    <span>Custom Dimension Delta ({width} × {depth}mm):</span>
                    <span>{dimensionDelta > 0 ? `+£${dimensionDelta}` : `-£${Math.abs(dimensionDelta)}`}</span>
                  </div>
                )}
                {materialDelta !== 0 && (
                  <div className="flex justify-between text-[#173B52]">
                    <span>Material Grade ({selectedMaterial.priceBand}):</span>
                    <span>{materialDelta > 0 ? `+£${materialDelta}` : `-£${Math.abs(materialDelta)}`}</span>
                  </div>
                )}
                {hardwareDelta > 0 && (
                  <div className="flex justify-between text-[#173B52]">
                    <span>Hardware / Core Specification:</span>
                    <span>+£{hardwareDelta}</span>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="pt-2 flex flex-col sm:flex-row gap-3">
                <button
                  onClick={handleAdd}
                  className="flex-1 py-3 bg-[#173B52] hover:bg-[#272A2C] text-[#EEE9E0] font-mono-spec text-xs font-bold tracking-wider transition-colors flex items-center justify-center space-x-2 cursor-pointer"
                >
                  {addedSuccess ? (
                    <>
                      <Check className="w-4 h-4 text-[#A77A43]" />
                      <span>ADDED TO YOUR PROJECT!</span>
                    </>
                  ) : (
                    <>
                      <Layers className="w-4 h-4" />
                      <span>ADD TO YOUR PROJECT</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => onRequestQuote(currentConfiguration)}
                  className="px-6 py-3 bg-[#D9632A] hover:bg-[#D9632A]/90 text-white font-mono-spec text-xs font-bold tracking-wider transition-colors cursor-pointer text-center"
                >
                  REQUEST FORMAL QUOTE
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Parametric Controls & Material Swatches (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            {/* Control Panel Card */}
            <div className="bg-[#EEE9E0] border border-[#272A2C]/30 p-6 space-y-6 shadow-sm">
              <div className="flex items-center justify-between border-b border-[#272A2C]/20 pb-3">
                <h3 className="font-mono-spec text-xs font-bold text-[#173B52] tracking-wider uppercase flex items-center space-x-2">
                  <Ruler className="w-4 h-4 text-[#D9632A]" />
                  <span>1. STRUCTURAL DIMENSIONS (MM)</span>
                </h3>
                <span className="text-[10px] font-mono-spec text-[#7A8081]">STEP: 10MM</span>
              </div>

              {/* Width Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between font-mono-spec text-xs">
                  <span className="text-[#272A2C] font-semibold">OVERALL WIDTH:</span>
                  <span className="text-[#173B52] font-bold text-sm bg-[#D9D0C2] px-2 py-0.5">{width} MM</span>
                </div>
                <input
                  type="range"
                  min={selectedProduct.dimensionLimits.minWidth}
                  max={selectedProduct.dimensionLimits.maxWidth}
                  step={10}
                  value={width}
                  onChange={(e) => setWidth(Number(e.target.value))}
                  className="w-full accent-[#173B52] cursor-pointer"
                />
                <div className="flex justify-between text-[10px] font-mono-spec text-[#7A8081]">
                  <span>MIN: {selectedProduct.dimensionLimits.minWidth}MM</span>
                  <span>MAX: {selectedProduct.dimensionLimits.maxWidth}MM</span>
                </div>
              </div>

              {/* Depth Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between font-mono-spec text-xs">
                  <span className="text-[#272A2C] font-semibold">OVERALL DEPTH:</span>
                  <span className="text-[#173B52] font-bold text-sm bg-[#D9D0C2] px-2 py-0.5">{depth} MM</span>
                </div>
                <input
                  type="range"
                  min={selectedProduct.dimensionLimits.minDepth}
                  max={selectedProduct.dimensionLimits.maxDepth}
                  step={10}
                  value={depth}
                  onChange={(e) => setDepth(Number(e.target.value))}
                  className="w-full accent-[#173B52] cursor-pointer"
                />
              </div>

              {/* Height Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between font-mono-spec text-xs">
                  <span className="text-[#272A2C] font-semibold">BACKREST HEIGHT:</span>
                  <span className="text-[#173B52] font-bold text-sm bg-[#D9D0C2] px-2 py-0.5">{height} MM</span>
                </div>
                <input
                  type="range"
                  min={selectedProduct.dimensionLimits.minHeight}
                  max={selectedProduct.dimensionLimits.maxHeight}
                  step={10}
                  value={height}
                  onChange={(e) => setHeight(Number(e.target.value))}
                  className="w-full accent-[#173B52] cursor-pointer"
                />
              </div>

              {/* Arm Style Selector */}
              <div className="space-y-2 pt-2 border-t border-[#272A2C]/15">
                <label className="font-mono-spec text-xs font-bold text-[#173B52] uppercase block">
                  2. ARM ARCHITECTURE
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'STRAIGHT_MINIMAL', label: 'STRAIGHT MINIMAL' },
                    { id: 'ENGLISH_ROLL', label: 'ENGLISH ROLL' },
                    { id: 'ARCHITECTURAL_BOX', label: 'BOXED PLINTH' },
                    { id: 'FLUTED_SLIM', label: 'FLUTED SLIM' },
                  ].map((item) => (
                    <button
                      key={item.id}
                      onClick={() => setArmStyle(item.id as ArmStyle)}
                      className={`p-2 text-[11px] font-mono-spec text-left border transition-all cursor-pointer ${
                        armStyle === item.id
                          ? 'bg-[#173B52] text-[#EEE9E0] border-[#173B52] font-bold'
                          : 'bg-[#D9D0C2]/40 text-[#272A2C] border-[#7A8081]/30 hover:bg-[#D9D0C2]'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Leg / Plinth Finish */}
              <div className="space-y-2 pt-2 border-t border-[#272A2C]/15">
                <label className="font-mono-spec text-xs font-bold text-[#173B52] uppercase block">
                  3. LEG HARDWARE & BASE
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'TURNED_ASH', label: 'SOLID ASH', note: 'Standard' },
                    { id: 'SMOKED_OAK', label: 'SMOKED OAK', note: '+£90' },
                    { id: 'BRUSHED_BRASS', label: 'DERBY BRASS', note: '+£180' },
                    { id: 'CAST_IRON', label: 'CAST IRON', note: '+£140' },
                    { id: 'BLACKENED_STEEL', label: 'BLACK STEEL', note: '+£120' },
                  ].map((item) => (
                    <button
                      key={item.id}
                      onClick={() => setLegFinish(item.id as LegFinish)}
                      className={`p-2 text-left border transition-all cursor-pointer ${
                        legFinish === item.id
                          ? 'bg-[#173B52] text-[#EEE9E0] border-[#173B52]'
                          : 'bg-[#D9D0C2]/40 text-[#272A2C] border-[#7A8081]/30 hover:bg-[#D9D0C2]'
                      }`}
                    >
                      <div className="font-mono-spec text-[10px] font-bold">{item.label}</div>
                      <div className="text-[9px] text-[#A77A43] font-mono-spec">{item.note}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Material Selection Swatches */}
              <div className="space-y-3 pt-2 border-t border-[#272A2C]/15">
                <div className="flex justify-between items-center">
                  <label className="font-mono-spec text-xs font-bold text-[#173B52] uppercase">
                    4. PRIMARY UPHOLSTERY FABRIC / LEATHER
                  </label>
                  <span className="text-[10px] font-mono-spec text-[#A77A43]">{selectedMaterial.priceBand}</span>
                </div>

                <div className="grid grid-cols-2 gap-2 max-h-[220px] overflow-y-auto pr-1">
                  {MATERIALS_DATABASE.map((mat) => (
                    <button
                      key={mat.id}
                      onClick={() => setSelectedMaterial(mat)}
                      className={`p-2 border flex items-start space-x-2 text-left transition-all cursor-pointer ${
                        selectedMaterial.id === mat.id
                          ? 'bg-[#173B52] text-[#EEE9E0] border-[#173B52]'
                          : 'bg-[#D9D0C2]/30 text-[#272A2C] border-[#7A8081]/30 hover:bg-[#D9D0C2]'
                      }`}
                    >
                      <span
                        className="w-5 h-5 rounded-none shrink-0 border border-[#272A2C]/40 mt-0.5"
                        style={{ backgroundColor: mat.hex }}
                      />
                      <div className="min-w-0">
                        <div className="text-[11px] font-mono-spec font-bold truncate">{mat.name}</div>
                        <div className="text-[9px] opacity-75 font-mono-spec">{mat.category} • {mat.colour}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity */}
              <div className="flex items-center justify-between pt-2 border-t border-[#272A2C]/15">
                <span className="font-mono-spec text-xs font-bold text-[#173B52] uppercase">
                  5. QUANTITY (UNITS)
                </span>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-8 h-8 bg-[#D9D0C2] hover:bg-[#173B52] hover:text-[#EEE9E0] font-mono-spec font-bold text-sm cursor-pointer flex items-center justify-center"
                  >
                    -
                  </button>
                  <span className="w-10 text-center font-mono-spec font-bold text-sm text-[#173B52]">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-8 h-8 bg-[#D9D0C2] hover:bg-[#173B52] hover:text-[#EEE9E0] font-mono-spec font-bold text-sm cursor-pointer flex items-center justify-center"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
