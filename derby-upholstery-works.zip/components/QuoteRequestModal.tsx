'use client';

import React, { useState } from 'react';
import { ProjectItem, CustomConfiguration } from '@/types/furniture';
import { X, CheckCircle, UploadCloud, FileText, Send, Building2, User } from 'lucide-react';

interface QuoteRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  projectItems: ProjectItem[];
  directConfig?: CustomConfiguration | null;
  onClearProject?: () => void;
}

export const QuoteRequestModal: React.FC<QuoteRequestModalProps> = ({
  isOpen,
  onClose,
  projectItems,
  directConfig,
  onClearProject,
}) => {
  const [clientType, setClientType] = useState<'INTERIOR_DESIGNER' | 'ARCHITECT' | 'HOSPITALITY' | 'PRIVATE'>('INTERIOR_DESIGNER');
  const [name, setName] = useState<string>('');
  const [company, setCompany] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [roomType, setRoomType] = useState<string>('HOTEL_LOUNGE');
  const [budget, setBudget] = useState<string>('5K_15K');
  const [timeline, setTimeline] = useState<string>('STANDARD_6_WEEKS');
  const [notes, setNotes] = useState<string>('');
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [quoteReference, setQuoteReference] = useState<string>('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const refCode = `DUW-Q-${Math.floor(1000 + Math.random() * 9000)}-${new Date().getFullYear()}`;
    setQuoteReference(refCode);
    setSubmitted(true);
    if (onClearProject) {
      onClearProject();
    }
  };

  const handleSimulateUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploadedFileName(e.target.files[0].name);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#272A2C]/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-[#EEE9E0] border-2 border-[#173B52] w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl relative my-8">
        {/* Top Header */}
        <div className="bg-[#173B52] text-[#EEE9E0] px-6 py-3 flex items-center justify-between font-mono-spec text-xs border-b border-[#272A2C]">
          <div className="flex items-center space-x-2">
            <FileText className="w-4 h-4 text-[#A77A43]" />
            <span className="font-bold tracking-wider">BESPOKE QUOTE SPECIFICATION ENGINE</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-[#272A2C] text-[#EEE9E0] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          /* Submission Success State */
          <div className="p-8 text-center space-y-5 font-mono-spec">
            <div className="w-12 h-12 rounded-full bg-[#173B52] text-[#A77A43] flex items-center justify-center mx-auto border-2 border-[#D9632A]">
              <CheckCircle className="w-6 h-6 text-[#D9632A]" />
            </div>
            <div className="space-y-1">
              <div className="text-xs text-[#D9632A] font-bold uppercase">
                QUOTE SPECIFICATION LOGGED // DERBY WORKSHOP
              </div>
              <h3 className="text-2xl font-serif-arch font-bold text-[#173B52]">
                ENQUIRY REF: {quoteReference}
              </h3>
            </div>
            <p className="text-xs text-[#272A2C] max-w-md mx-auto font-sans leading-relaxed">
              Thank you, <strong>{name || 'Specifier'}</strong>. Our drawing office is preparing your dimensioned CAD elevations, 
              timber joinery schedule, and formal pricing proposal. We will contact you at <strong>{email}</strong> within 24 hours.
            </p>
            <div className="pt-4 border-t border-[#7A8081]/30">
              <button
                onClick={onClose}
                className="px-6 py-2.5 bg-[#173B52] text-[#EEE9E0] text-xs font-mono-spec font-bold hover:bg-[#272A2C] transition-colors cursor-pointer"
              >
                RETURN TO WORKSHOP
              </button>
            </div>
          </div>
        ) : (
          /* Main Quote Form */
          <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6">
            <div>
              <div className="text-[10px] font-mono-spec text-[#D9632A] uppercase font-bold">
                COMMISSION FORM
              </div>
              <h3 className="text-2xl font-serif-arch font-bold text-[#173B52]">
                REQUEST A BESPOKE QUOTE
              </h3>
              <p className="text-xs text-[#272A2C]/80 font-sans mt-0.5">
                Provide project requirements, dimensional parameters, or floor plans.
              </p>
            </div>

            {/* Client Role Selector */}
            <div className="space-y-2">
              <label className="block font-mono-spec text-xs font-bold text-[#173B52] uppercase">
                1. SPECIFIER CLASSIFICATION
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'INTERIOR_DESIGNER', label: 'INTERIOR DESIGNER' },
                  { id: 'ARCHITECT', label: 'ARCHITECT' },
                  { id: 'HOSPITALITY', label: 'HOTEL / CONTRACT' },
                  { id: 'PRIVATE', label: 'PRIVATE CLIENT' },
                ].map((item) => (
                  <button
                    type="button"
                    key={item.id}
                    onClick={() => setClientType(item.id as any)}
                    className={`p-2 text-[10px] font-mono-spec text-center border transition-all cursor-pointer ${
                      clientType === item.id
                        ? 'bg-[#173B52] text-[#EEE9E0] border-[#173B52] font-bold'
                        : 'bg-[#D9D0C2]/50 text-[#272A2C] border-[#7A8081]/30 hover:bg-[#D9D0C2]'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Contact Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="font-mono-spec text-[11px] text-[#272A2C] font-semibold">
                  FULL NAME *
                </label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Thomas Faulkner"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#EEE9E0] border border-[#7A8081]/40 p-2 text-xs font-mono-spec focus:outline-none focus:border-[#173B52]"
                />
              </div>

              <div className="space-y-1">
                <label className="font-mono-spec text-[11px] text-[#272A2C] font-semibold">
                  PRACTICE / STUDIO NAME
                </label>
                <input
                  type="text"
                  placeholder="e.g. Faulkner Architecture Studio"
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  className="w-full bg-[#EEE9E0] border border-[#7A8081]/40 p-2 text-xs font-mono-spec focus:outline-none focus:border-[#173B52]"
                />
              </div>

              <div className="space-y-1">
                <label className="font-mono-spec text-[11px] text-[#272A2C] font-semibold">
                  EMAIL ADDRESS *
                </label>
                <input
                  required
                  type="email"
                  placeholder="specifier@studio.co.uk"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#EEE9E0] border border-[#7A8081]/40 p-2 text-xs font-mono-spec focus:outline-none focus:border-[#173B52]"
                />
              </div>

              <div className="space-y-1">
                <label className="font-mono-spec text-[11px] text-[#272A2C] font-semibold">
                  PHONE NUMBER
                </label>
                <input
                  type="tel"
                  placeholder="+44 20 7946 0912"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-[#EEE9E0] border border-[#7A8081]/40 p-2 text-xs font-mono-spec focus:outline-none focus:border-[#173B52]"
                />
              </div>
            </div>

            {/* Project Parameters */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-[#272A2C]/15">
              <div className="space-y-1">
                <label className="font-mono-spec text-[11px] text-[#272A2C] font-semibold">
                  ROOM / TYPOLOGY
                </label>
                <select
                  value={roomType}
                  onChange={(e) => setRoomType(e.target.value)}
                  className="w-full bg-[#EEE9E0] border border-[#7A8081]/40 p-2 text-xs font-mono-spec focus:outline-none focus:border-[#173B52]"
                >
                  <option value="HOTEL_LOUNGE">Hotel Lounge / Reception</option>
                  <option value="RESIDENTIAL_LIVING">Private Residential Living</option>
                  <option value="RESTAURANT_BANQUETTE">Restaurant Banquette / Dining</option>
                  <option value="BOARDROOM_COMMERCIAL">Executive Office / Boardroom</option>
                  <option value="HERITAGE_PROPERTY">Heritage Conservation Project</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-mono-spec text-[11px] text-[#272A2C] font-semibold">
                  ESTIMATED BUDGET
                </label>
                <select
                  value={budget}
                  onChange={(e) => setBudget(e.target.value)}
                  className="w-full bg-[#EEE9E0] border border-[#7A8081]/40 p-2 text-xs font-mono-spec focus:outline-none focus:border-[#173B52]"
                >
                  <option value="2K_5K">£2,500 - £5,000 (Single Bespoke Piece)</option>
                  <option value="5K_15K">£5,000 - £15,000 (Suite / Modular Group)</option>
                  <option value="15K_50K">£15,000 - £50,000 (Commercial Fitout)</option>
                  <option value="50K_PLUS">£50,000+ (Full Hospitality Contract)</option>
                </select>
              </div>
            </div>

            {/* File Upload Simulator */}
            <div className="space-y-1 pt-2 border-t border-[#272A2C]/15">
              <label className="font-mono-spec text-[11px] text-[#272A2C] font-semibold flex items-center justify-between">
                <span>ATTACH ARCHITECTURAL CAD / FLOOR PLAN (OPTIONAL)</span>
                <span className="text-[10px] text-[#7A8081]">DWG, PDF, STEP, IFC</span>
              </label>
              <div className="border border-dashed border-[#7A8081]/50 bg-[#D9D0C2]/30 p-4 text-center cursor-pointer hover:bg-[#D9D0C2]/60 transition-colors relative">
                <input
                  type="file"
                  onChange={handleSimulateUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                />
                <UploadCloud className="w-6 h-6 text-[#173B52] mx-auto mb-1" />
                <div className="text-xs font-mono-spec text-[#173B52] font-semibold">
                  {uploadedFileName ? `ATTACHED: ${uploadedFileName}` : 'DRAG & DROP CAD PLAN OR CLICK TO UPLOAD'}
                </div>
              </div>
            </div>

            {/* Custom Notes */}
            <div className="space-y-1">
              <label className="font-mono-spec text-[11px] text-[#272A2C] font-semibold">
                DIMENSION NOTES & CUSTOM DETAILS
              </label>
              <textarea
                rows={3}
                placeholder="Specific wall dimensions, access stairwell constraints, custom seat depths, or bespoke leather preferences..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-[#EEE9E0] border border-[#7A8081]/40 p-2 text-xs font-mono-spec focus:outline-none focus:border-[#173B52]"
              />
            </div>

            {/* Submit CTA */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3.5 bg-[#D9632A] hover:bg-[#D9632A]/90 text-white font-mono-spec text-xs font-bold tracking-widest transition-colors flex items-center justify-center space-x-2 cursor-pointer shadow-md"
              >
                <Send className="w-4 h-4" />
                <span>TRANSMIT SPECIFICATION TO DERBY WORKSHOP</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
