'use client';

import React from 'react';
import { Compass, MapPin, Mail, Phone, ArrowUpRight } from 'lucide-react';

interface FooterProps {
  onNavClick: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavClick }) => {
  return (
    <footer className="bg-[#173B52] text-[#EEE9E0] border-t border-[#272A2C] pt-16 pb-12 font-sans relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Top Massive Architectural Brand Statement */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 border-b border-[#EEE9E0]/15 pb-12 items-start">
          <div className="lg:col-span-6 space-y-4">
            <div className="w-10 h-10 border border-[#A77A43] bg-[#272A2C] text-[#EEE9E0] flex items-center justify-center font-mono-spec font-bold text-sm">
              DUW
            </div>
            <div>
              <h2 className="font-serif-arch font-bold text-3xl sm:text-5xl tracking-widest text-[#EEE9E0] uppercase leading-none">
                DERBY
              </h2>
              <div className="text-xl sm:text-2xl tracking-[0.25em] font-mono-spec text-[#A77A43] font-bold mt-1">
                UPHOLSTERY WORKS
              </div>
            </div>
            <p className="text-xs sm:text-sm text-[#EEE9E0]/70 font-sans max-w-md leading-relaxed">
              Bespoke British furniture engineered with structural discipline and master hand-craftsmanship in Derby, England.
            </p>
            <div className="text-xs font-mono-spec text-[#D9632A] font-semibold">
              MADE TO FIT. MADE TO LAST.
            </div>
          </div>

          {/* Navigation Links Columns (6 Cols) */}
          <div className="lg:col-span-6 grid grid-cols-2 sm:grid-cols-3 gap-6 font-mono-spec text-xs">
            <div className="space-y-3">
              <div className="text-[#A77A43] font-bold uppercase tracking-wider text-[11px]">
                MANUFACTURING
              </div>
              <ul className="space-y-2 text-[#EEE9E0]/80">
                <li>
                  <button onClick={() => onNavClick('catalogue')} className="hover:text-white cursor-pointer">
                    Furniture Catalogue
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavClick('configurator')} className="hover:text-white cursor-pointer">
                    Bespoke Configurator
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavClick('anatomy')} className="hover:text-white cursor-pointer">
                    The Exploded Chair
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavClick('materials')} className="hover:text-white cursor-pointer">
                    Material Archive
                  </button>
                </li>
              </ul>
            </div>

            <div className="space-y-3">
              <div className="text-[#A77A43] font-bold uppercase tracking-wider text-[11px]">
                SPECIFIERS
              </div>
              <ul className="space-y-2 text-[#EEE9E0]/80">
                <li>
                  <button onClick={() => onNavClick('trade')} className="hover:text-white cursor-pointer">
                    Architect B2B Portal
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavClick('craft')} className="hover:text-white cursor-pointer">
                    Heritage Restoration
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavClick('journal')} className="hover:text-white cursor-pointer">
                    Workshop Journal
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavClick('trade')} className="hover:text-white cursor-pointer">
                    Sample Box Requests
                  </button>
                </li>
              </ul>
            </div>

            <div className="space-y-3">
              <div className="text-[#A77A43] font-bold uppercase tracking-wider text-[11px]">
                DERBY ATELIER
              </div>
              <div className="text-[#EEE9E0]/70 space-y-1 text-[11px]">
                <div>Derwent Valley Mills</div>
                <div>Derby, DE1 3AY</div>
                <div>United Kingdom</div>
                <div className="pt-2 text-[#A77A43]">T: +44 (0)1332 890 142</div>
                <div>E: spec@derbyworks.co.uk</div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Coordinates & Copyright Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between font-mono-spec text-[11px] text-[#EEE9E0]/50 gap-4">
          <div className="flex items-center space-x-4">
            <span>© {new Date().getFullYear()} DERBY UPHOLSTERY WORKS LTD.</span>
            <span>ALL RIGHTS RESERVED.</span>
          </div>
          <div className="flex items-center space-x-6">
            <span>52.9225° N, 1.4746° W</span>
            <span>DERBY / ENGLAND</span>
            <span className="text-[#D9632A]">BS 5852 / FSC CERTIFIED</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
