'use client';

import React, { useState, useMemo } from 'react';
import { MATERIALS_DATABASE } from '@/data/mockData';
import { MaterialSwatch, MaterialCategory } from '@/types/furniture';
import { 
  Layers, 
  Sun, 
  Moon, 
  Flame, 
  ShieldCheck, 
  Check, 
  Plus, 
  Search, 
  Filter,
  Eye
} from 'lucide-react';

interface MaterialLibraryProps {
  onAddSample: (material: MaterialSwatch) => void;
  sampleItems: MaterialSwatch[];
}

export const MaterialLibrary: React.FC<MaterialLibraryProps> = ({
  onAddSample,
  sampleItems,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('ALL');
  const [selectedLighting, setSelectedLighting] = useState<'DAYLIGHT' | 'WARM' | 'STUDIO'>('DAYLIGHT');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [inspectingMaterial, setInspectingMaterial] = useState<MaterialSwatch>(MATERIALS_DATABASE[0]);

  const categories = ['ALL', 'WOOL', 'LINEN', 'LEATHER', 'VELVET', 'BOUCLE', 'PERFORMANCE'];

  const filteredMaterials = useMemo(() => {
    return MATERIALS_DATABASE.filter((mat) => {
      const matchCategory = activeCategory === 'ALL' || mat.category === activeCategory;
      const matchSearch = mat.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          mat.colour.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          mat.composition.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          mat.origin.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCategory && matchSearch;
    });
  }, [activeCategory, searchQuery]);

  // Lighting overlay styling
  const lightingFilterClass = useMemo(() => {
    if (selectedLighting === 'WARM') return 'sepia-[0.25] brightness-[0.96] hue-rotate-[-10deg]';
    if (selectedLighting === 'STUDIO') return 'contrast-[1.05] brightness-[1.02]';
    return 'brightness-[1.0]'; // Natural daylight
  }, [selectedLighting]);

  const isSampleAdded = (id: string) => sampleItems.some((s) => s.id === id);

  return (
    <section id="materials" className="w-full bg-[#D9D0C2] py-16 border-b border-[#7A8081]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="border-b border-[#272A2C]/20 pb-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono-spec tracking-widest text-[#173B52] bg-[#EEE9E0] inline-block px-2.5 py-1 mb-2 border-l-2 border-[#173B52]">
              SECTION 05 // THE MATERIAL ARCHIVE
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif-arch font-bold text-[#173B52] uppercase">
              MATERIAL LIBRARY
            </h2>
            <p className="text-sm text-[#272A2C]/80 max-w-2xl mt-1 font-sans">
              From heavy Derbyshire Melton wools and Irish linens to full-grain vegetable-tanned hides. 
              Every textile is engineered for contract-grade durability and tactile warmth.
            </p>
          </div>

          {/* Lighting Environment Simulator */}
          <div className="bg-[#EEE9E0] p-2.5 border border-[#7A8081]/40 flex items-center space-x-2">
            <span className="text-[10px] font-mono-spec text-[#7A8081] uppercase tracking-wider pl-1">
              LIGHTING SIMULATOR:
            </span>
            <button
              onClick={() => setSelectedLighting('DAYLIGHT')}
              className={`px-2 py-1 text-[10px] font-mono-spec transition-all cursor-pointer ${
                selectedLighting === 'DAYLIGHT'
                  ? 'bg-[#173B52] text-[#EEE9E0] font-bold'
                  : 'text-[#272A2C] hover:bg-[#D9D0C2]'
              }`}
            >
              DAYLIGHT (5000K)
            </button>
            <button
              onClick={() => setSelectedLighting('WARM')}
              className={`px-2 py-1 text-[10px] font-mono-spec transition-all cursor-pointer ${
                selectedLighting === 'WARM'
                  ? 'bg-[#173B52] text-[#EEE9E0] font-bold'
                  : 'text-[#272A2C] hover:bg-[#D9D0C2]'
              }`}
            >
              WARM (3000K)
            </button>
            <button
              onClick={() => setSelectedLighting('STUDIO')}
              className={`px-2 py-1 text-[10px] font-mono-spec transition-all cursor-pointer ${
                selectedLighting === 'STUDIO'
                  ? 'bg-[#173B52] text-[#EEE9E0] font-bold'
                  : 'text-[#272A2C] hover:bg-[#D9D0C2]'
              }`}
            >
              STUDIO (4000K)
            </button>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-8">
          {/* Category Tabs */}
          <div className="flex items-center space-x-1 overflow-x-auto pb-2 sm:pb-0">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1.5 text-xs font-mono-spec tracking-wider transition-all whitespace-nowrap cursor-pointer ${
                  activeCategory === cat
                    ? 'bg-[#173B52] text-[#EEE9E0] font-bold'
                    : 'bg-[#EEE9E0] text-[#272A2C] hover:bg-[#EEE9E0]/80'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-[#7A8081] absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="SEARCH FABRIC / LEATHER / ORIGIN..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#EEE9E0] border border-[#7A8081]/40 pl-9 pr-3 py-1.5 text-xs font-mono-spec text-[#272A2C] placeholder-[#7A8081] focus:outline-none focus:border-[#173B52]"
            />
          </div>
        </div>

        {/* Main Swatch Grid & Inspector Detail (12 Cols) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Swatch Grid (8 Cols) */}
          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredMaterials.map((mat) => {
              const inBox = isSampleAdded(mat.id);
              const isSelected = inspectingMaterial.id === mat.id;
              return (
                <div
                  key={mat.id}
                  onClick={() => setInspectingMaterial(mat)}
                  className={`bg-[#EEE9E0] border p-4 transition-all cursor-pointer relative group flex flex-col justify-between ${
                    isSelected
                      ? 'border-[#173B52] ring-2 ring-[#173B52]/20 shadow-md'
                      : 'border-[#7A8081]/30 hover:border-[#173B52]'
                  }`}
                >
                  <div>
                    {/* Swatch Color Block with Lighting Filter */}
                    <div
                      className={`w-full h-24 border border-[#272A2C]/20 mb-3 relative overflow-hidden transition-all duration-300 ${lightingFilterClass}`}
                      style={{ backgroundColor: mat.hex }}
                    >
                      {/* Subtle woven texture overlay */}
                      <div className="absolute inset-0 bg-dot-matrix opacity-20 pointer-events-none" />
                      <div className="absolute top-2 left-2 bg-[#272A2C]/80 text-[#EEE9E0] text-[9px] font-mono-spec px-1.5 py-0.5">
                        {mat.priceBand}
                      </div>
                      <div className="absolute bottom-2 right-2 bg-[#EEE9E0]/90 text-[#272A2C] text-[9px] font-mono-spec px-1.5 py-0.5 font-bold">
                        {mat.rubCount.toLocaleString()} RUBS
                      </div>
                    </div>

                    <div className="text-[10px] font-mono-spec text-[#D9632A] uppercase font-bold">
                      {mat.category} // {mat.origin.split(',')[0]}
                    </div>
                    <h4 className="text-base font-serif-arch font-bold text-[#173B52] leading-tight mt-0.5">
                      {mat.name}
                    </h4>
                    <div className="text-xs font-mono-spec text-[#7A8081] mt-0.5">
                      COLOUR: {mat.colour}
                    </div>
                  </div>

                  <div className="pt-3 border-t border-[#7A8081]/20 mt-3 flex items-center justify-between">
                    <span className="font-mono-spec text-xs font-bold text-[#173B52]">
                      £{mat.pricePerMeter}/M
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onAddSample(mat);
                      }}
                      className={`px-2.5 py-1 text-[10px] font-mono-spec transition-colors flex items-center space-x-1 cursor-pointer ${
                        inBox
                          ? 'bg-[#173B52] text-[#EEE9E0] font-bold'
                          : 'bg-[#D9D0C2] hover:bg-[#173B52] hover:text-[#EEE9E0] text-[#272A2C]'
                      }`}
                    >
                      {inBox ? (
                        <>
                          <Check className="w-3 h-3 text-[#A77A43]" />
                          <span>IN SAMPLE BOX</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-3 h-3" />
                          <span>ADD SAMPLE</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right: Detailed Material Specification Sheet (4 Cols) */}
          <div className="lg:col-span-4 bg-[#173B52] text-[#EEE9E0] p-6 border border-[#272A2C] shadow-lg space-y-6">
            <div className="border-b border-[#EEE9E0]/20 pb-4">
              <div className="text-[10px] font-mono-spec text-[#A77A43] tracking-widest uppercase">
                MATERIAL ARCHIVE SPECIFICATION
              </div>
              <h3 className="text-2xl font-serif-arch font-bold text-[#EEE9E0] mt-1">
                {inspectingMaterial.name}
              </h3>
              <div className="text-xs font-mono-spec text-[#D9632A] font-semibold">
                SUPPLIER: {inspectingMaterial.supplier}
              </div>
            </div>

            {/* Large Macro Zoom Preview */}
            <div
              className={`w-full h-32 border border-[#EEE9E0]/40 relative overflow-hidden transition-all duration-300 ${lightingFilterClass}`}
              style={{ backgroundColor: inspectingMaterial.hex }}
            >
              <div className="absolute inset-0 bg-dot-matrix opacity-25" />
              <div className="absolute bottom-2 left-2 bg-[#272A2C]/90 text-[#EEE9E0] text-[10px] font-mono-spec px-2 py-0.5">
                MACRO SURFACE // {inspectingMaterial.colour}
              </div>
            </div>

            <p className="text-xs text-[#EEE9E0]/80 leading-relaxed font-sans">
              {inspectingMaterial.description}
            </p>

            {/* Technical Specification Matrix */}
            <div className="space-y-2 bg-[#272A2C]/60 p-4 border border-[#7A8081]/30 font-mono-spec text-xs">
              <div className="flex justify-between border-b border-[#7A8081]/30 pb-1">
                <span className="text-[#EEE9E0]/60">COMPOSITION:</span>
                <span className="font-bold text-[#EEE9E0] text-right">{inspectingMaterial.composition}</span>
              </div>
              <div className="flex justify-between border-b border-[#7A8081]/30 pb-1">
                <span className="text-[#EEE9E0]/60">MARTINDALE RUBS:</span>
                <span className="text-[#A77A43] font-bold">{inspectingMaterial.rubCount.toLocaleString()} Cycles</span>
              </div>
              <div className="flex justify-between border-b border-[#7A8081]/30 pb-1">
                <span className="text-[#EEE9E0]/60">FIRE RATING:</span>
                <span className="text-[#D9632A]">{inspectingMaterial.fireRating}</span>
              </div>
              <div className="flex justify-between border-b border-[#7A8081]/30 pb-1">
                <span className="text-[#EEE9E0]/60">WEIGHT:</span>
                <span>{inspectingMaterial.weight}</span>
              </div>
              <div className="flex justify-between border-b border-[#7A8081]/30 pb-1">
                <span className="text-[#EEE9E0]/60">ORIGIN:</span>
                <span>{inspectingMaterial.origin}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#EEE9E0]/60">CARE:</span>
                <span className="text-[10px] text-right">{inspectingMaterial.care}</span>
              </div>
            </div>

            {/* Action */}
            <button
              onClick={() => onAddSample(inspectingMaterial)}
              className="w-full py-3 bg-[#D9632A] hover:bg-[#D9632A]/90 text-white font-mono-spec text-xs font-bold tracking-widest transition-colors flex items-center justify-center space-x-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>REQUEST ARCHITECTURAL SWATCH</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
