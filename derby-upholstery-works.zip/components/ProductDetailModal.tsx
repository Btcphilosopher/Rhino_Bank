'use client';

import React from 'react';
import { FurnitureProduct } from '@/types/furniture';
import { X, Sliders, FileText, CheckCircle2, Download, ShieldCheck, Ruler, ArrowRight } from 'lucide-react';

interface ProductDetailModalProps {
  product: FurnitureProduct | null;
  onClose: () => void;
  onConfigure: (product: FurnitureProduct) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onConfigure,
}) => {
  if (!product) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#272A2C]/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-[#EEE9E0] border-2 border-[#173B52] w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl relative my-8">
        {/* Top Technical Bar */}
        <div className="bg-[#173B52] text-[#EEE9E0] px-6 py-3 flex items-center justify-between font-mono-spec text-xs border-b border-[#272A2C]">
          <div className="flex items-center space-x-3">
            <span className="text-[#A77A43] font-bold">SPECIFICATION SHEET</span>
            <span className="text-[#EEE9E0]/40">|</span>
            <span>{product.code}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-[#272A2C] text-[#EEE9E0] cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 sm:p-8 space-y-8">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between border-b border-[#272A2C]/20 pb-4 gap-2">
            <div>
              <div className="text-[10px] font-mono-spec text-[#D9632A] uppercase font-bold">
                {product.category} // BESPOKE MANUFACTURE
              </div>
              <h2 className="text-3xl sm:text-4xl font-serif-arch font-bold text-[#173B52]">
                {product.name}
              </h2>
              <p className="text-xs font-mono-spec text-[#A77A43] mt-0.5">
                {product.strapline}
              </p>
            </div>
            <div className="text-right font-mono-spec">
              <div className="text-xs text-[#7A8081]">BASE ESTIMATE</div>
              <div className="text-2xl font-bold text-[#173B52]">£{product.basePrice.toLocaleString()}</div>
              <div className="text-[10px] text-[#7A8081]">LEAD TIME: {product.leadTimeWeeks}</div>
            </div>
          </div>

          {/* Photo & Blueprint Grid */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div className="md:col-span-7">
              <img
                src={product.image}
                alt={product.name}
                className="w-full aspect-[16/11] object-cover border border-[#272A2C]/20 shadow-md"
              />
            </div>
            <div className="md:col-span-5 bg-[#D9D0C2] p-5 border border-[#7A8081]/30 space-y-3 font-mono-spec text-xs">
              <div className="text-[10px] text-[#173B52] font-bold uppercase border-b border-[#272A2C]/20 pb-1">
                ARCHITECTURAL DIMENSIONS
              </div>
              <div className="space-y-1.5 text-[#272A2C]">
                <div className="flex justify-between">
                  <span>STANDARD WIDTH:</span>
                  <span className="font-bold">{product.defaultDimensions.width} MM</span>
                </div>
                <div className="flex justify-between">
                  <span>BESPOKE WIDTH RANGE:</span>
                  <span className="text-[#173B52] font-bold">{product.dimensionLimits.minWidth} - {product.dimensionLimits.maxWidth} MM</span>
                </div>
                <div className="flex justify-between">
                  <span>STANDARD DEPTH:</span>
                  <span className="font-bold">{product.defaultDimensions.depth} MM</span>
                </div>
                <div className="flex justify-between">
                  <span>OVERALL HEIGHT:</span>
                  <span className="font-bold">{product.defaultDimensions.height} MM</span>
                </div>
                <div className="flex justify-between">
                  <span>SEAT HEIGHT:</span>
                  <span className="font-bold">{product.defaultDimensions.seatHeight} MM</span>
                </div>
              </div>

              <div className="pt-2 border-t border-[#272A2C]/20 text-[10px] text-[#7A8081]">
                * All pieces can be customized to the millimeter for commercial and residential drawings.
              </div>
            </div>
          </div>

          {/* Detailed Structural Specifications Matrix */}
          <div className="space-y-3">
            <div className="text-xs font-mono-spec font-bold text-[#173B52] uppercase tracking-wider">
              STRUCTURAL ENGINEERING SPECIFICATION
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono-spec text-xs">
              <div className="bg-[#EEE9E0] p-4 border border-[#7A8081]/30 space-y-1">
                <div className="text-[10px] text-[#A77A43] font-bold">CARCASS & TIMBER</div>
                <div className="text-[#272A2C] font-semibold">{product.frameMaterial}</div>
              </div>
              <div className="bg-[#EEE9E0] p-4 border border-[#7A8081]/30 space-y-1">
                <div className="text-[10px] text-[#A77A43] font-bold">JOINERY METHOD</div>
                <div className="text-[#272A2C] font-semibold">{product.joinery}</div>
              </div>
              <div className="bg-[#EEE9E0] p-4 border border-[#7A8081]/30 space-y-1">
                <div className="text-[10px] text-[#A77A43] font-bold">SUSPENSION MATRIX</div>
                <div className="text-[#272A2C] font-semibold">{product.suspension}</div>
              </div>
              <div className="bg-[#EEE9E0] p-4 border border-[#7A8081]/30 space-y-1">
                <div className="text-[10px] text-[#A77A43] font-bold">CUSHION CORE</div>
                <div className="text-[#272A2C] font-semibold">{product.cushion}</div>
              </div>
            </div>
          </div>

          {/* Action Strip */}
          <div className="pt-4 border-t border-[#272A2C]/20 flex flex-col sm:flex-row justify-between gap-3">
            <button
              onClick={() => {
                alert(`Architectural CAD spec sheet PDF downloaded for ${product.name} (Ref: ${product.code}).`);
              }}
              className="py-3 px-4 border border-[#173B52] text-[#173B52] font-mono-spec text-xs hover:bg-[#D9D0C2] transition-colors flex items-center justify-center space-x-2 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>DOWNLOAD CAD SPEC PDF</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onConfigure(product);
              }}
              className="py-3 px-6 bg-[#D9632A] hover:bg-[#D9632A]/90 text-white font-mono-spec text-xs font-bold tracking-wider transition-colors flex items-center justify-center space-x-2 cursor-pointer"
            >
              <Sliders className="w-4 h-4" />
              <span>CUSTOMISE THIS PIECE IN CONFIGURATOR</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
