'use client';

import React, { useState } from 'react';
import { Layers, ChevronRight, CheckCircle, HelpCircle, Shield, Sparkles } from 'lucide-react';

interface StructuralLayer {
  id: number;
  code: string;
  name: string;
  subtitle: string;
  material: string;
  tolerance: string;
  lifespan: string;
  description: string;
  engineeringPoints: string[];
}

const STRUCTURAL_LAYERS: StructuralLayer[] = [
  {
    id: 1,
    code: 'LYR-01-FRAME',
    name: 'Kiln-Dried Hardwood Ash Frame',
    subtitle: 'The Load-Bearing Carcass',
    material: '35mm Solid Derbyshire Ash (FSC Certified, 8-10% moisture)',
    tolerance: '±0.5mm mortise-and-tenon joints',
    lifespan: '25-Year Structural Guarantee',
    description: 'The foundation of all longevity. We never use chipboard, softwood, or metal brackets. Every joint is machined with precision tenons, glued with waterproof PVA, and double-dowelled by hand.',
    engineeringPoints: [
      'Stress-tested corner blocks screwed in three axes',
      'Engineered cross-rails resist frame racking under 450kg dynamic loads',
      'Naturally resilient grain alignment prevents splitting',
    ],
  },
  {
    id: 2,
    code: 'LYR-02-SUSPENSION',
    name: 'Tempered Carbon Steel Springs & Jute Webbing',
    subtitle: 'Dynamic Ergonomic Suspension',
    material: '9-Gauge British Sinuous Springs & 180 N/m Italian Pirelli Webbing',
    tolerance: 'Tensioned to 180 N/m strictly calibrated',
    lifespan: '100,000+ Deflection Cycles',
    description: 'Suspension gives the chair its progressive resistance. Sinuous springs are cross-tied with sound-dampening paper-wrapped wire to eliminate squeaking over decades.',
    engineeringPoints: [
      'Even weight dispersion across the pelvic lumbar zone',
      'Silent-clip nylon acoustic isolators at all rail fixings',
      'Hand-tensioned cross-woven jute webbing beneath back cushion deck',
    ],
  },
  {
    id: 3,
    code: 'LYR-03-CORE',
    name: 'Multi-Density High-Resilience Core',
    subtitle: 'Ergonomic Support Matrix',
    material: '45kg/m³ CMHR Cold-Cure Foam & Natural Dunlop Latex Core',
    tolerance: 'BS 5852 Crib 5 Commercial Fire Compliant',
    lifespan: '15+ Years Indentation Retention',
    description: 'We construct our cushions with a tiered density core: firm supportive base topped with soft conforming open-cell latex, eliminating the flat sag of cheap commercial seating.',
    engineeringPoints: [
      'No hazardous fluorocarbons or toxic flame-retardant PBDEs',
      'Channelled air pockets for thermal breathability',
      'Anatomically sculpted seat pitch preventing slide fatigue',
    ],
  },
  {
    id: 4,
    code: 'LYR-04-BATTING',
    name: 'Natural British Wool Batting & Calico',
    subtitle: 'Thermal & Acoustic Envelope',
    material: '300gsm Undyed Lambswool Fleece & 100% Unbleached Cotton Calico',
    tolerance: 'Hand-stretched barrier layer',
    lifespan: 'Lifetime Natural Barrier',
    description: 'Before any decorative fabric touches the chair, a hand-stitched calico casing encloses the core. A layer of natural Derbyshire wool provides natural fire resistance, moisture wicking, and soft crown contours.',
    engineeringPoints: [
      'Naturally self-extinguishing wool eliminates chemical spray treatments',
      'Prevents outer fabric from friction wear against the internal foam',
      'Creates the signature rounded crown profile',
    ],
  },
  {
    id: 5,
    code: 'LYR-05-UPHOLSTERY',
    name: 'Tailored Cloth & Top-Stitching',
    subtitle: 'The Architectural Skin',
    material: 'Derbyshire Heavy Melton Wool / Full-Grain Aniline Leather',
    tolerance: '12mm Seam Allowance, Double-Stitched',
    lifespan: '80,000 to 120,000 Martindale Rubs',
    description: 'Cut with digital CAD precision or hand-sheared across the grain. Every panel is matched for pattern alignment and tensioned evenly across the timber rails with magnetic tacks.',
    engineeringPoints: [
      'Heavy-duty bonded nylon thread (Tex 90 gauge)',
      'Perimeter piped edge provides structural seam reinforcement',
      'Hand-pleated corners and concealed bottom dust-cover lining',
    ],
  },
  {
    id: 6,
    code: 'LYR-06-HARDWARE',
    name: 'Solid Derby Brass & Cast Iron Hardware',
    subtitle: 'Machined Ground Interface',
    material: 'Solid Turned C36000 Brass / Cast Iron Plinths',
    tolerance: 'Machined to ±0.2mm tolerance',
    lifespan: 'Indefinite / Develops Natural Patina',
    description: 'Turned on precision lathes in Derby. Solid brass ferrules and heavy castors anchor the piece with authentic industrial permanence.',
    engineeringPoints: [
      'M10 threaded steel insert dowels anchored into hardwood corner blocks',
      'Subtle brushed satin finish with micro-crystalline wax seal',
      'Floor-protective acoustic felt dampers embedded in foot pads',
    ],
  },
];

export const ExplodedChair: React.FC = () => {
  const [activeLayerId, setActiveLayerId] = useState<number>(1);
  const [explodedOffset, setExplodedOffset] = useState<number>(45);

  const activeLayer = STRUCTURAL_LAYERS.find((l) => l.id === activeLayerId) || STRUCTURAL_LAYERS[0];

  return (
    <section id="anatomy" className="w-full bg-[#272A2C] text-[#EEE9E0] py-16 border-b border-[#7A8081]/30 relative overflow-hidden">
      {/* Background blueprint dark grid */}
      <div className="absolute inset-0 bg-blueprint-dark opacity-40 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="border-b border-[#7A8081]/30 pb-6 mb-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono-spec tracking-widest text-[#A77A43] bg-[#173B52] inline-block px-2.5 py-1 mb-2 border-l-2 border-[#D9632A]">
              SECTION 03 // STRUCTURAL ANATOMY
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif-arch font-bold text-[#EEE9E0] uppercase">
              THE EXPLODED CHAIR
            </h2>
            <p className="text-sm text-[#EEE9E0]/70 max-w-2xl mt-1 font-sans">
              Most furniture hides its shortcuts under a flashy fabric cover. 
              Here is the complete mechanical breakdown of a Derby armchair from timber skeleton to hand-turned brass.
            </p>
          </div>

          {/* Explode Offset Scrub Slider */}
          <div className="bg-[#173B52] p-3 border border-[#7A8081]/30 flex items-center space-x-3">
            <span className="text-[11px] font-mono-spec text-[#A77A43]">EXPLOSION SPREAD:</span>
            <input
              type="range"
              min={10}
              max={90}
              value={explodedOffset}
              onChange={(e) => setExplodedOffset(Number(e.target.value))}
              className="accent-[#D9632A] cursor-pointer w-28"
            />
            <span className="font-mono-spec text-xs text-[#EEE9E0] font-bold">{explodedOffset}%</span>
          </div>
        </div>

        {/* Interactive 2-Column Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left: Interactive Multi-Layer CAD Exploded SVG Stage (7 Cols) */}
          <div className="lg:col-span-7 bg-[#173B52]/60 border border-[#7A8081]/40 p-6 min-h-[480px] flex flex-col justify-between relative shadow-2xl">
            {/* Viewport Header */}
            <div className="flex justify-between items-center font-mono-spec text-[11px] text-[#EEE9E0]/60 border-b border-[#7A8081]/30 pb-2">
              <span className="text-[#D9632A] font-bold">ISOMETRIC DISASSEMBLY // LAYER 0{activeLayer.id}</span>
              <span>DERBY WORKS INSPECTION SPEC</span>
            </div>

            {/* Dynamic Interactive Exploded Diagram */}
            <div className="my-8 flex items-center justify-center relative">
              <svg className="w-full max-h-[340px]" viewBox="0 0 600 360" fill="none">
                {/* Crosshairs */}
                <line x1="300" y1="20" x2="300" y2="340" stroke="#7A8081" strokeWidth="0.5" strokeDasharray="4 4" />
                <line x1="40" y1="180" x2="560" y2="180" stroke="#7A8081" strokeWidth="0.5" strokeDasharray="4 4" />

                {/* Layer 6: Brass Hardware (Bottom) */}
                <g 
                  onClick={() => setActiveLayerId(6)}
                  className="cursor-pointer transition-all duration-300 hover:opacity-100"
                  style={{ 
                    transform: `translateY(${explodedOffset * 0.9}px)`,
                    opacity: activeLayerId === 6 ? 1 : 0.6 
                  }}
                >
                  <rect x="160" y="270" width="18" height="30" fill="#A77A43" stroke="#EEE9E0" strokeWidth="1" />
                  <rect x="422" y="270" width="18" height="30" fill="#A77A43" stroke="#EEE9E0" strokeWidth="1" />
                  <circle cx="169" cy="305" r="7" fill="#A77A43" stroke="#EEE9E0" strokeWidth="1" />
                  <circle cx="431" cy="305" r="7" fill="#A77A43" stroke="#EEE9E0" strokeWidth="1" />
                  <text x="140" y="325" fill="#A77A43" fontSize="9" fontFamily="monospace">06: SOLID BRASS CASTORS</text>
                </g>

                {/* Layer 1: Kiln-Dried Hardwood Frame */}
                <g 
                  onClick={() => setActiveLayerId(1)}
                  className="cursor-pointer transition-all duration-300 hover:opacity-100"
                  style={{ 
                    transform: `translateY(${explodedOffset * 0.4}px)`,
                    opacity: activeLayerId === 1 ? 1 : 0.6 
                  }}
                >
                  <rect x="140" y="210" width="320" height="35" fill="#D9D0C2" fillOpacity="0.3" stroke="#D9D0C2" strokeWidth="2" />
                  <rect x="140" y="110" width="35" height="100" fill="#D9D0C2" fillOpacity="0.3" stroke="#D9D0C2" strokeWidth="2" />
                  <rect x="425" y="110" width="35" height="100" fill="#D9D0C2" fillOpacity="0.3" stroke="#D9D0C2" strokeWidth="2" />
                  <rect x="175" y="80" width="250" height="35" fill="#D9D0C2" fillOpacity="0.3" stroke="#D9D0C2" strokeWidth="2" />
                  <circle cx="175" cy="210" r="4" fill="#D9632A" />
                  <circle cx="425" cy="210" r="4" fill="#D9632A" />
                  <text x="470" y="225" fill="#D9D0C2" fontSize="9" fontFamily="monospace">01: HARDWOOD ASH</text>
                </g>

                {/* Layer 2: Springs & Webbing */}
                <g 
                  onClick={() => setActiveLayerId(2)}
                  className="cursor-pointer transition-all duration-300 hover:opacity-100"
                  style={{ 
                    transform: `translateY(${explodedOffset * 0.05}px)`,
                    opacity: activeLayerId === 2 ? 1 : 0.6 
                  }}
                >
                  <path d="M 180 195 Q 200 180 220 195 T 260 195 T 300 195 T 340 195 T 380 195 T 420 195" fill="none" stroke="#D9632A" strokeWidth="3" />
                  <line x1="220" y1="120" x2="220" y2="200" stroke="#7A8081" strokeWidth="4" strokeDasharray="3 3" />
                  <line x1="300" y1="120" x2="300" y2="200" stroke="#7A8081" strokeWidth="4" strokeDasharray="3 3" />
                  <line x1="380" y1="120" x2="380" y2="200" stroke="#7A8081" strokeWidth="4" strokeDasharray="3 3" />
                  <text x="60" y="195" fill="#D9632A" fontSize="9" fontFamily="monospace">02: CARBON SPRINGS</text>
                </g>

                {/* Layer 3: High Density Core Foam */}
                <g 
                  onClick={() => setActiveLayerId(3)}
                  className="cursor-pointer transition-all duration-300 hover:opacity-100"
                  style={{ 
                    transform: `translateY(${-explodedOffset * 0.3}px)`,
                    opacity: activeLayerId === 3 ? 1 : 0.6 
                  }}
                >
                  <rect x="165" y="155" width="270" height="35" rx="3" fill="#EEE9E0" fillOpacity="0.4" stroke="#EEE9E0" strokeWidth="1.5" />
                  <rect x="195" y="70" width="210" height="80" rx="3" fill="#EEE9E0" fillOpacity="0.3" stroke="#EEE9E0" strokeWidth="1.5" />
                  <text x="470" y="155" fill="#EEE9E0" fontSize="9" fontFamily="monospace">03: CMHR FOAM CORE</text>
                </g>

                {/* Layer 4: Wool Batting & Calico */}
                <g 
                  onClick={() => setActiveLayerId(4)}
                  className="cursor-pointer transition-all duration-300 hover:opacity-100"
                  style={{ 
                    transform: `translateY(${-explodedOffset * 0.6}px)`,
                    opacity: activeLayerId === 4 ? 1 : 0.6 
                  }}
                >
                  <rect x="155" y="145" width="290" height="45" rx="5" fill="#D9D0C2" fillOpacity="0.5" stroke="#A77A43" strokeWidth="1" strokeDasharray="4 2" />
                  <text x="60" y="145" fill="#A77A43" fontSize="9" fontFamily="monospace">04: WOOL BATTING</text>
                </g>

                {/* Layer 5: Tailored Outer Upholstery */}
                <g 
                  onClick={() => setActiveLayerId(5)}
                  className="cursor-pointer transition-all duration-300 hover:opacity-100"
                  style={{ 
                    transform: `translateY(${-explodedOffset * 0.9}px)`,
                    opacity: activeLayerId === 5 ? 1 : 0.6 
                  }}
                >
                  <rect x="150" y="135" width="300" height="55" rx="4" fill="#173B52" stroke="#D9632A" strokeWidth="1.5" />
                  <rect x="180" y="45" width="240" height="90" rx="3" fill="#173B52" stroke="#D9632A" strokeWidth="1.5" />
                  <text x="470" y="70" fill="#D9632A" fontSize="9" fontFamily="monospace">05: MELTON CLOTH</text>
                </g>
              </svg>
            </div>

            {/* Quick Step Buttons Bar */}
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-1 border-t border-[#7A8081]/30 pt-3">
              {STRUCTURAL_LAYERS.map((layer) => (
                <button
                  key={layer.id}
                  onClick={() => setActiveLayerId(layer.id)}
                  className={`py-1.5 px-2 text-[10px] font-mono-spec transition-all cursor-pointer text-center ${
                    activeLayerId === layer.id
                      ? 'bg-[#D9632A] text-white font-bold'
                      : 'bg-[#272A2C] text-[#EEE9E0]/70 hover:bg-[#D9D0C2]/20'
                  }`}
                >
                  0{layer.id} {layer.code.split('-')[2]}
                </button>
              ))}
            </div>
          </div>

          {/* Right: Technical Inspector Sheet for Active Layer (5 Cols) */}
          <div className="lg:col-span-5 bg-[#173B52] border border-[#272A2C] p-6 space-y-6 shadow-xl">
            <div className="border-b border-[#EEE9E0]/20 pb-4">
              <div className="text-[10px] font-mono-spec text-[#A77A43] tracking-widest uppercase">
                {activeLayer.code} // ENGINEERING SPEC
              </div>
              <h3 className="text-2xl font-serif-arch font-bold text-[#EEE9E0] mt-1">
                {activeLayer.name}
              </h3>
              <div className="text-xs font-mono-spec text-[#D9632A] font-semibold">
                {activeLayer.subtitle}
              </div>
            </div>

            <p className="text-xs text-[#EEE9E0]/80 leading-relaxed font-sans">
              {activeLayer.description}
            </p>

            {/* Specification Metrics */}
            <div className="space-y-2 bg-[#272A2C]/60 p-4 border border-[#7A8081]/40 font-mono-spec text-xs">
              <div className="flex justify-between border-b border-[#7A8081]/30 pb-1.5">
                <span className="text-[#EEE9E0]/60">MATERIAL CODE</span>
                <span className="text-[#EEE9E0] font-bold text-right">{activeLayer.material}</span>
              </div>
              <div className="flex justify-between border-b border-[#7A8081]/30 pb-1.5">
                <span className="text-[#EEE9E0]/60">TOLERANCE</span>
                <span className="text-[#A77A43]">{activeLayer.tolerance}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#EEE9E0]/60">SERVICE LIFE</span>
                <span className="text-[#D9632A] font-bold">{activeLayer.lifespan}</span>
              </div>
            </div>

            {/* Engineering Inspection Checklist */}
            <div className="space-y-2">
              <div className="text-[10px] font-mono-spec text-[#A77A43] uppercase tracking-wider">
                DERBY STRUCTURAL CRITERIA
              </div>
              <ul className="space-y-1.5 text-xs text-[#EEE9E0]/80">
                {activeLayer.engineeringPoints.map((pt, i) => (
                  <li key={i} className="flex items-start space-x-2">
                    <CheckCircle className="w-3.5 h-3.5 text-[#D9632A] shrink-0 mt-0.5" />
                    <span>{pt}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
