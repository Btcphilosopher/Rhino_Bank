'use client';

import React, { useState } from 'react';
import { PRODUCTS_CATALOGUE } from '@/data/mockData';
import { FurnitureProduct } from '@/types/furniture';
import { Sliders, Eye, FileText, ArrowRight, Check } from 'lucide-react';

interface ProductCatalogueProps {
  onSelectProduct: (product: FurnitureProduct) => void;
  onConfigureProduct: (product: FurnitureProduct) => void;
}

export const ProductCatalogue: React.FC<ProductCatalogueProps> = ({
  onSelectProduct,
  onConfigureProduct,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('ALL');

  const categories = ['ALL', 'SOFAS', 'ARMCHAIRS', 'BANQUETTES', 'DINING', 'HEADBOARDS', 'OTTOMANS'];

  const filteredProducts = PRODUCTS_CATALOGUE.filter((p) => {
    if (activeCategory === 'ALL') return true;
    return p.category === activeCategory;
  });

  return (
    <section id="catalogue" className="w-full bg-[#EEE9E0] py-16 border-b border-[#7A8081]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="border-b border-[#272A2C]/20 pb-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono-spec tracking-widest text-[#173B52] bg-[#D9D0C2] inline-block px-2.5 py-1 mb-2 border-l-2 border-[#173B52]">
              SECTION 08 // ARCHITECTURAL FURNITURE CATALOGUE
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif-arch font-bold text-[#173B52] uppercase">
              THE BESPOKE COLLECTION
            </h2>
            <p className="text-sm text-[#272A2C]/80 max-w-2xl mt-1 font-sans">
              Each piece is an architectural specification, not an off-the-shelf commodity. 
              Dimensions, seat rakes, timber species, and upholstery textiles are tailored to your floor plan.
            </p>
          </div>

          {/* Category Filter Tabs */}
          <div className="flex items-center space-x-1 overflow-x-auto pb-2 md:pb-0">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1.5 text-xs font-mono-spec tracking-wider transition-all whitespace-nowrap cursor-pointer ${
                  activeCategory === cat
                    ? 'bg-[#173B52] text-[#EEE9E0] font-bold'
                    : 'bg-[#D9D0C2]/50 text-[#272A2C] hover:bg-[#D9D0C2]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="bg-[#D9D0C2]/40 border border-[#7A8081]/30 flex flex-col justify-between group hover:border-[#173B52] transition-all shadow-sm"
            >
              <div>
                {/* Product Image Stage */}
                <div className="relative aspect-[16/11] overflow-hidden border-b border-[#7A8081]/30">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500 filter saturate-[0.92]"
                  />
                  {/* Top code badge */}
                  <div className="absolute top-3 left-3 bg-[#173B52] text-[#EEE9E0] text-[10px] font-mono-spec px-2.5 py-0.5">
                    {product.code}
                  </div>
                  <div className="absolute bottom-3 right-3 bg-[#272A2C]/90 text-[#EEE9E0] text-[10px] font-mono-spec px-2 py-0.5 font-bold">
                    LEAD TIME: {product.leadTimeWeeks}
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="text-[10px] font-mono-spec text-[#D9632A] uppercase font-bold">
                        {product.category} // MADE IN DERBY
                      </div>
                      <h3 className="text-xl font-serif-arch font-bold text-[#173B52] mt-0.5">
                        {product.name}
                      </h3>
                    </div>
                    <div className="text-right font-mono-spec">
                      <div className="text-[9px] text-[#7A8081]">FROM</div>
                      <div className="text-sm font-bold text-[#173B52]">
                        £{product.basePrice.toLocaleString()}
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-[#272A2C]/80 line-clamp-2 font-sans">
                    {product.strapline}
                  </p>

                  {/* Standard Dimensions strip */}
                  <div className="bg-[#EEE9E0] p-2.5 border border-[#7A8081]/20 font-mono-spec text-[10px] text-[#272A2C] grid grid-cols-3 gap-1 text-center">
                    <div>
                      <span className="text-[#7A8081] block">WIDTH</span>
                      <span className="font-bold">{product.defaultDimensions.width}MM</span>
                    </div>
                    <div>
                      <span className="text-[#7A8081] block">DEPTH</span>
                      <span className="font-bold">{product.defaultDimensions.depth}MM</span>
                    </div>
                    <div>
                      <span className="text-[#7A8081] block">HEIGHT</span>
                      <span className="font-bold">{product.defaultDimensions.height}MM</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="p-5 pt-0 grid grid-cols-2 gap-2">
                <button
                  onClick={() => onSelectProduct(product)}
                  className="py-2.5 bg-transparent border border-[#173B52] text-[#173B52] font-mono-spec text-xs hover:bg-[#173B52] hover:text-[#EEE9E0] transition-colors cursor-pointer flex items-center justify-center space-x-1"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>VIEW SPECS</span>
                </button>
                <button
                  onClick={() => onConfigureProduct(product)}
                  className="py-2.5 bg-[#D9632A] text-white font-mono-spec text-xs font-bold hover:bg-[#D9632A]/90 transition-colors cursor-pointer flex items-center justify-center space-x-1"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>CUSTOMISE</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
