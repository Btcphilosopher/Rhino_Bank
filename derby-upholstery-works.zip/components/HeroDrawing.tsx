'use client';

import React, { useState, useEffect } from 'react';
import { Sliders, Play, RotateCcw, ArrowRight, Eye, Layers, Compass, CheckCircle2 } from 'lucide-react';

interface HeroDrawingProps {
  onConfigureClick: () => void;
  onExploreSpecsClick: () => void;
  onRequestQuoteClick: () => void;
}

export const HeroDrawing: React.FC<HeroDrawingProps> = ({
  onConfigureClick,
  onExploreSpecsClick,
  onRequestQuoteClick,
}) => {
  const [heroMode, setHeroMode] = useState<'DRAWING_OFFICE' | 'THE_FRAME' | 'DERBY_WORKSHOP'>('DRAWING_OFFICE');
  const [morphStage, setMorphStage] = useState<number>(5); // 1 to 5
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  // Auto-play the morph sequence on initial mount
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying) {
      timer = setInterval(() => {
        setMorphStage((prev) => {
          if (prev >= 5) {
            setIsPlaying(false);
            return 5;
          }
          return prev + 1;
        });
      }, 1400);
    }
    return () => clearInterval(timer);
  }, [isPlaying]);

  const handlePlayMorph = () => {
    setMorphStage(1);
    setIsPlaying(true);
  };

  return (
    <section className="relative w-full bg-[#EEE9E0] border-b border-[#7A8081]/30 overflow-hidden pt-8 pb-16 lg:py-16">
      {/* Background blueprint grid */}
      <div className="absolute inset-0 bg-blueprint-grid opacity-60 pointer-events-none" />

      {/* Hero Header Lockup */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between border-b border-[#272A2C]/15 pb-8 mb-8">
          <div className="space-y-3">
            <div className="inline-flex items-center space-x-2 text-xs font-mono-spec tracking-widest text-[#173B52] bg-[#D9D0C2]/60 px-2.5 py-1 border-l-2 border-[#173B52]">
              <span>SPECIFICATION 2026 // DERBY MANUFACTURING</span>
              <span className="text-[#D9632A]">●</span>
              <span>ASH FRAME NO. 01</span>
            </div>
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-serif-arch font-bold tracking-tight text-[#173B52] uppercase leading-[0.95]">
              CRAFT WITH <br />
              <span className="text-[#272A2C]">ENGINEERING</span> <br />
              <span className="text-[#A77A43] italic font-normal">DISCIPLINE.</span>
            </h1>
            <p className="max-w-xl text-sm sm:text-base text-[#272A2C]/80 font-sans leading-relaxed pt-2">
              Every beautiful chair contains a frame, tolerances, webbing, springs, tension, and proportion.
              Designed and bespoke-manufactured in Derby, England.
            </p>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="mt-6 lg:mt-0 flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-2">
            <span className="text-[11px] font-mono-spec text-[#7A8081] uppercase tracking-wider mr-2">
              PERSPECTIVE:
            </span>
            <div className="inline-flex p-1 bg-[#D9D0C2]/50 border border-[#7A8081]/30">
              <button
                onClick={() => { setHeroMode('DRAWING_OFFICE'); setMorphStage(5); }}
                className={`px-3 py-1.5 text-xs font-mono-spec tracking-wider transition-all cursor-pointer ${
                  heroMode === 'DRAWING_OFFICE'
                    ? 'bg-[#173B52] text-[#EEE9E0] font-semibold shadow-sm'
                    : 'text-[#272A2C] hover:text-[#173B52]'
                }`}
              >
                THE DRAWING OFFICE
              </button>
              <button
                onClick={() => { setHeroMode('THE_FRAME'); setMorphStage(3); }}
                className={`px-3 py-1.5 text-xs font-mono-spec tracking-wider transition-all cursor-pointer ${
                  heroMode === 'THE_FRAME'
                    ? 'bg-[#173B52] text-[#EEE9E0] font-semibold shadow-sm'
                    : 'text-[#272A2C] hover:text-[#173B52]'
                }`}
              >
                THE FRAME (50/50)
              </button>
              <button
                onClick={() => { setHeroMode('DERBY_WORKSHOP'); }}
                className={`px-3 py-1.5 text-xs font-mono-spec tracking-wider transition-all cursor-pointer ${
                  heroMode === 'DERBY_WORKSHOP'
                    ? 'bg-[#173B52] text-[#EEE9E0] font-semibold shadow-sm'
                    : 'text-[#272A2C] hover:text-[#173B52]'
                }`}
              >
                WORKSHOP ATELIER
              </button>
            </div>
          </div>
        </div>

        {/* Main Hero Interactive Visual Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Main Visual Stage (8 Cols) */}
          <div className="lg:col-span-8 bg-[#EEE9E0] border border-[#272A2C]/20 shadow-md relative overflow-hidden group min-h-[460px] sm:min-h-[540px] flex flex-col justify-between">
            {/* Top technical drawing status bar */}
            <div className="bg-[#272A2C] text-[#EEE9E0] px-4 py-2 flex items-center justify-between font-mono-spec text-[11px] border-b border-[#7A8081]/40">
              <div className="flex items-center space-x-3">
                <span className="text-[#A77A43] font-bold">CAD ELEVATION // DWG-2026-SF01</span>
                <span className="text-[#EEE9E0]/50">|</span>
                <span>STAGE: 0{morphStage} OF 05</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="inline-block w-2 h-2 rounded-full bg-[#D9632A] animate-ping" />
                <span className="text-[#EEE9E0]/80">REAL-TIME RENDER</span>
              </div>
            </div>

            {/* Visual Canvas Area */}
            <div className="relative flex-1 flex items-center justify-center p-6 sm:p-10 overflow-hidden bg-blueprint-grid">
              {/* CAD Crosshairs & Grid Coordinate Accents */}
              <div className="absolute top-4 left-4 font-mono-spec text-[10px] text-[#7A8081] space-y-0.5 pointer-events-none">
                <div>X: +2140.00 MM</div>
                <div>Y: +0980.00 MM</div>
                <div>Z: +0780.00 MM</div>
              </div>
              <div className="absolute top-4 right-4 font-mono-spec text-[10px] text-[#7A8081] text-right pointer-events-none">
                <div>SCALE 1:10 @ A1</div>
                <div>DERBY FOUNDRY SPEC</div>
                <div className="text-[#A77A43]">TOLERANCE ±0.5MM</div>
              </div>

              {/* STAGE 1: Pure CAD Silhouette & Wireframe */}
              {morphStage === 1 && (
                <div className="w-full max-w-xl aspect-[16/10] border border-dashed border-[#173B52]/40 relative flex items-center justify-center p-4">
                  <svg className="w-full h-full text-[#173B52]" viewBox="0 0 600 350" fill="none" stroke="currentColor" strokeWidth="1.5">
                    {/* Sofa base frame */}
                    <rect x="60" y="210" width="480" height="40" strokeDasharray="4 2" />
                    {/* Arms */}
                    <rect x="60" y="110" width="60" height="100" />
                    <rect x="480" y="110" width="60" height="100" />
                    {/* Back rest */}
                    <rect x="120" y="80" width="360" height="130" strokeDasharray="3 3" />
                    {/* Seat Cushions */}
                    <rect x="120" y="180" width="180" height="30" />
                    <rect x="300" y="180" width="180" height="30" />
                    {/* Turned Legs */}
                    <line x1="90" y1="250" x2="90" y2="290" strokeWidth="3" />
                    <line x1="510" y1="250" x2="510" y2="290" strokeWidth="3" />
                    <line x1="300" y1="250" x2="300" y2="290" strokeWidth="2" strokeDasharray="2 2" />
                    {/* Measurement Callouts */}
                    <line x1="60" y1="310" x2="540" y2="310" stroke="#D9632A" strokeWidth="1" />
                    <text x="300" y="325" fill="#D9632A" fontSize="12" fontFamily="monospace" textAnchor="middle">WIDTH: 2140 MM</text>
                  </svg>
                  <div className="absolute bottom-2 left-3 bg-[#173B52] text-[#EEE9E0] text-[9px] font-mono-spec px-2 py-0.5">
                    STAGE 01 // GEOMETRIC SILHOUETTE
                  </div>
                </div>
              )}

              {/* STAGE 2: Frame Joinery & Mortise Schedule */}
              {morphStage === 2 && (
                <div className="w-full max-w-xl aspect-[16/10] border border-[#272A2C]/30 relative flex items-center justify-center p-4 bg-[#D9D0C2]/30">
                  <svg className="w-full h-full" viewBox="0 0 600 350" fill="none">
                    {/* Ash Timber Frame representation */}
                    <rect x="70" y="210" width="460" height="35" fill="#A77A43" fillOpacity="0.25" stroke="#A77A43" strokeWidth="2" />
                    <rect x="70" y="110" width="50" height="100" fill="#A77A43" fillOpacity="0.2" stroke="#A77A43" strokeWidth="2" />
                    <rect x="480" y="110" width="50" height="100" fill="#A77A43" fillOpacity="0.2" stroke="#A77A43" strokeWidth="2" />
                    <rect x="120" y="80" width="360" height="40" fill="#A77A43" fillOpacity="0.2" stroke="#A77A43" strokeWidth="2" />
                    {/* Mortise joint nodes */}
                    <circle cx="120" cy="210" r="5" fill="#D9632A" />
                    <circle cx="480" cy="210" r="5" fill="#D9632A" />
                    <circle cx="120" cy="110" r="5" fill="#D9632A" />
                    <circle cx="480" cy="110" r="5" fill="#D9632A" />
                    <line x1="120" y1="210" x2="160" y2="260" stroke="#D9632A" strokeWidth="1" />
                    <text x="165" y="270" fill="#272A2C" fontSize="10" fontFamily="monospace" fontWeight="bold">MORTISE & TENON / 35MM ASH</text>
                  </svg>
                  <div className="absolute bottom-2 left-3 bg-[#A77A43] text-white text-[9px] font-mono-spec px-2 py-0.5">
                    STAGE 02 // HARDWOOD ASH CARCASS & JOINTS
                  </div>
                </div>
              )}

              {/* STAGE 3: Webbing & Carbon Steel Springs */}
              {morphStage === 3 && (
                <div className="w-full max-w-xl aspect-[16/10] border border-[#272A2C]/40 relative flex items-center justify-center p-4 bg-[#D9D0C2]/40">
                  <svg className="w-full h-full" viewBox="0 0 600 350" fill="none">
                    {/* Frame */}
                    <rect x="70" y="200" width="460" height="40" stroke="#272A2C" strokeWidth="2" />
                    {/* Sinuous Carbon Steel Springs */}
                    <path d="M 120 220 Q 140 200 160 220 T 200 220 T 240 220 T 280 220 T 320 220 T 360 220 T 400 220 T 440 220 T 480 220" fill="none" stroke="#173B52" strokeWidth="3" />
                    {/* Interwoven Jute Webbing Lines */}
                    <line x1="160" y1="130" x2="160" y2="240" stroke="#7A8081" strokeWidth="6" strokeDasharray="4 4" />
                    <line x1="240" y1="130" x2="240" y2="240" stroke="#7A8081" strokeWidth="6" strokeDasharray="4 4" />
                    <line x1="320" y1="130" x2="320" y2="240" stroke="#7A8081" strokeWidth="6" strokeDasharray="4 4" />
                    <line x1="400" y1="130" x2="400" y2="240" stroke="#7A8081" strokeWidth="6" strokeDasharray="4 4" />
                    <line x1="480" y1="130" x2="480" y2="240" stroke="#7A8081" strokeWidth="6" strokeDasharray="4 4" />
                  </svg>
                  <div className="absolute bottom-2 left-3 bg-[#173B52] text-[#EEE9E0] text-[9px] font-mono-spec px-2 py-0.5">
                    STAGE 03 // 8-GAUGE STEEL SPRINGS & PIRELLI WEBBING
                  </div>
                </div>
              )}

              {/* STAGE 4: Foam, Down Core & Calico Wrap */}
              {morphStage === 4 && (
                <div className="w-full max-w-xl aspect-[16/10] border border-[#272A2C]/40 relative flex items-center justify-center p-4 bg-[#D9D0C2]/70">
                  <div className="w-full h-full flex items-center justify-center relative">
                    <div className="w-4/5 h-3/5 bg-[#EEE9E0] border-2 border-dashed border-[#7A8081] rounded-sm p-4 flex flex-col justify-between shadow-inner">
                      <div className="font-mono-spec text-[10px] text-[#272A2C] font-semibold">
                        CALICO BARRIER ENVELOPE // HIGH RESILIENCE DUAL CORE (45KG/M³)
                      </div>
                      <div className="flex justify-between items-center text-[10px] font-mono-spec text-[#7A8081]">
                        <span>NATURAL BRITISH WOOL WRAP: 300GSM</span>
                        <span>CRIB 5 COMPLIANT</span>
                      </div>
                    </div>
                  </div>
                  <div className="absolute bottom-2 left-3 bg-[#272A2C] text-[#EEE9E0] text-[9px] font-mono-spec px-2 py-0.5">
                    STAGE 04 // INTERNAL ERGONOMIC DENSITY & BATTING
                  </div>
                </div>
              )}

              {/* STAGE 5: Finished Masterpiece Render */}
              {morphStage === 5 && (
                <div className="w-full h-full relative flex items-center justify-center animate-fade-in">
                  {heroMode === 'DRAWING_OFFICE' && (
                    <div className="relative w-full h-full flex items-center justify-center">
                      <img
                        src="https://images.unsplash.com/photo-1555041469-a586c61ea9bc?q=80&w=1200&auto=format&fit=crop"
                        alt="The Derby Bespoke Sofa in Drawing Office Setting"
                        className="w-full h-full max-h-[380px] object-cover border border-[#272A2C]/20 shadow-lg filter saturate-[0.95]"
                      />
                      {/* Architectural Floating Spec Overlay */}
                      <div className="absolute top-4 left-4 bg-[#173B52]/90 backdrop-blur-sm text-[#EEE9E0] p-3 text-[11px] font-mono-spec space-y-1 border-l-2 border-[#D9632A]">
                        <div className="font-bold text-[#A77A43]">THE DERBY SOFA / 01</div>
                        <div>FABRIC: DERBYSHIRE NAVY MELTON</div>
                        <div>FRAME: FSC KILN-DRIED ASH</div>
                        <div>PRICE FROM: £3,200</div>
                      </div>
                    </div>
                  )}

                  {heroMode === 'THE_FRAME' && (
                    <div className="relative w-full h-full flex items-center justify-center">
                      {/* Split 50/50 Concept */}
                      <div className="grid grid-cols-2 w-full h-full max-h-[380px] border border-[#272A2C]/20 overflow-hidden shadow-lg">
                        {/* Left half: Exposed frame & webbing */}
                        <div className="bg-[#272A2C] p-6 text-[#EEE9E0] flex flex-col justify-between relative border-r-2 border-[#D9632A]">
                          <div className="font-mono-spec text-xs text-[#A77A43] font-bold">
                            50% EXPOSED ASH SKELETON
                          </div>
                          <div className="space-y-1 font-mono-spec text-[11px] text-[#EEE9E0]/80">
                            <div>• Double Mortise & Tenon</div>
                            <div>• Tempered Carbon Sinuous Springs</div>
                            <div>• Heavy Jute Cross-Webbing</div>
                          </div>
                          <div className="text-[10px] font-mono-spec text-[#D9632A]">
                            BEAUTY HAS A FRAME.
                          </div>
                        </div>
                        {/* Right half: Finished Upholstery */}
                        <div className="relative">
                          <img
                            src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=800&auto=format&fit=crop"
                            alt="Finished Bespoke Armchair"
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute bottom-3 right-3 bg-[#173B52]/90 text-white text-[10px] font-mono-spec px-2 py-1">
                            TAILORED MELTON WOOL
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {heroMode === 'DERBY_WORKSHOP' && (
                    <div className="relative w-full h-full flex items-center justify-center">
                      <img
                        src="https://images.unsplash.com/photo-1540518614846-7ede433c4ef7?q=80&w=1200&auto=format&fit=crop"
                        alt="Derby Upholstery Works Workshop"
                        className="w-full h-full max-h-[380px] object-cover border border-[#272A2C]/20 shadow-lg"
                      />
                      <div className="absolute bottom-4 left-4 bg-[#272A2C]/90 text-[#EEE9E0] p-3 text-[11px] font-mono-spec border-l-2 border-[#A77A43]">
                        <div className="font-bold text-[#A77A43]">DERWENT VALLEY WORKSHOP // BAY 03</div>
                        <div className="text-[#EEE9E0]/80">Hand joinery, tailoring & final inspection under natural north light.</div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Bottom Timeline Controls */}
            <div className="bg-[#D9D0C2] border-t border-[#7A8081]/30 p-3 sm:p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center space-x-2">
                <button
                  onClick={handlePlayMorph}
                  disabled={isPlaying}
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#173B52] hover:bg-[#272A2C] text-[#EEE9E0] text-xs font-mono-spec transition-colors disabled:opacity-50 cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>{isPlaying ? 'PLAYING CAD BUILD...' : 'PLAY CAD ANIMATION'}</span>
                </button>
                <button
                  onClick={() => setMorphStage(1)}
                  className="p-1.5 text-[#272A2C] hover:bg-[#EEE9E0] border border-[#7A8081]/30 cursor-pointer"
                  title="Reset to Stage 1"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>

              {/* Stage Step Tabs */}
              <div className="flex items-center space-x-1 sm:space-x-1.5 overflow-x-auto w-full sm:w-auto">
                {[
                  { step: 1, label: '01 CAD' },
                  { step: 2, label: '02 FRAME' },
                  { step: 3, label: '03 SPRINGS' },
                  { step: 4, label: '04 CORE' },
                  { step: 5, label: '05 FINISHED' },
                ].map((item) => (
                  <button
                    key={item.step}
                    onClick={() => { setMorphStage(item.step); setIsPlaying(false); }}
                    className={`px-2.5 py-1 text-[11px] font-mono-spec transition-all cursor-pointer ${
                      morphStage === item.step
                        ? 'bg-[#272A2C] text-[#EEE9E0] font-bold border-b-2 border-[#D9632A]'
                        : 'bg-[#EEE9E0] text-[#7A8081] hover:text-[#272A2C]'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Hero Data & Specification Sidebar (4 Cols) */}
          <div className="lg:col-span-4 space-y-4">
            {/* Architectural Spec Card */}
            <div className="bg-[#173B52] text-[#EEE9E0] p-6 border border-[#272A2C] shadow-md space-y-5">
              <div className="flex items-center justify-between border-b border-[#EEE9E0]/20 pb-3">
                <span className="font-mono-spec text-xs tracking-wider text-[#A77A43] font-bold">
                  STRUCTURAL MATRIX
                </span>
                <span className="font-mono-spec text-[10px] text-[#EEE9E0]/60">
                  REF: DUW-SF-01
                </span>
              </div>

              <div className="space-y-3 font-mono-spec text-xs">
                <div className="flex justify-between border-b border-[#EEE9E0]/10 pb-1.5">
                  <span className="text-[#EEE9E0]/60">STANDARD SPAN</span>
                  <span className="font-bold text-[#EEE9E0]">2140 MM</span>
                </div>
                <div className="flex justify-between border-b border-[#EEE9E0]/10 pb-1.5">
                  <span className="text-[#EEE9E0]/60">BESPOKE RANGE</span>
                  <span className="text-[#A77A43]">1600 — 3200 MM</span>
                </div>
                <div className="flex justify-between border-b border-[#EEE9E0]/10 pb-1.5">
                  <span className="text-[#EEE9E0]/60">SEAT DEPTH</span>
                  <span>620 MM</span>
                </div>
                <div className="flex justify-between border-b border-[#EEE9E0]/10 pb-1.5">
                  <span className="text-[#EEE9E0]/60">FRAME WOOD</span>
                  <span>FSC KILN-DRIED ASH</span>
                </div>
                <div className="flex justify-between border-b border-[#EEE9E0]/10 pb-1.5">
                  <span className="text-[#EEE9E0]/60">JOINERY</span>
                  <span>MORTISE & TENON</span>
                </div>
                <div className="flex justify-between border-b border-[#EEE9E0]/10 pb-1.5">
                  <span className="text-[#EEE9E0]/60">LEAD TIME</span>
                  <span className="text-[#D9632A] font-bold">5-7 WEEKS</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 space-y-2">
                <button
                  onClick={onConfigureClick}
                  className="w-full py-3 bg-[#D9632A] hover:bg-[#D9632A]/90 text-white font-mono-spec font-bold text-xs tracking-widest flex items-center justify-center space-x-2 transition-colors cursor-pointer"
                >
                  <Sliders className="w-4 h-4" />
                  <span>CUSTOMISE YOUR DIMENSIONS</span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={onExploreSpecsClick}
                    className="py-2.5 px-2 bg-transparent border border-[#EEE9E0]/30 hover:bg-[#EEE9E0]/10 text-[#EEE9E0] font-mono-spec text-[11px] tracking-wider transition-colors cursor-pointer text-center"
                  >
                    VIEW CATALOGUE
                  </button>
                  <button
                    onClick={onRequestQuoteClick}
                    className="py-2.5 px-2 bg-[#A77A43] hover:bg-[#A77A43]/90 text-white font-mono-spec text-[11px] tracking-wider transition-colors cursor-pointer text-center font-semibold"
                  >
                    REQUEST QUOTE
                  </button>
                </div>
              </div>
            </div>

            {/* Derby Engineering Quote Card */}
            <div className="bg-[#D9D0C2] p-5 border border-[#7A8081]/30 font-sans space-y-2">
              <div className="text-[10px] font-mono-spec uppercase text-[#7A8081] tracking-widest">
                THE DERBY PRINCIPLE
              </div>
              <p className="text-xs text-[#272A2C] leading-relaxed italic">
                &ldquo;We do not build soft furniture that sags after three seasons. Every piece is built around the frame, calculated like an architectural span.&rdquo;
              </p>
              <div className="text-[11px] font-mono-spec text-[#173B52] font-semibold pt-1">
                — DERBY UPHOLSTERY WORKS / WORKSHOP MANUAL
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
