'use client';

import React from 'react';
import { ProjectItem } from '@/types/furniture';
import { X, Trash2, ArrowRight, FileText, Send, Sliders, Box } from 'lucide-react';

interface ProjectDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  projectItems: ProjectItem[];
  onRemoveItem: (id: string) => void;
  onOpenQuoteModal: () => void;
}

export const ProjectDrawer: React.FC<ProjectDrawerProps> = ({
  isOpen,
  onClose,
  projectItems,
  onRemoveItem,
  onOpenQuoteModal,
}) => {
  if (!isOpen) return null;

  const totalEstimatedCost = projectItems.reduce(
    (acc, item) => acc + (item.estimatedPrice || 0) * (item.quantity || 1),
    0
  );

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-[#272A2C]/60 backdrop-blur-xs transition-opacity"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#EEE9E0] border-l-2 border-[#173B52] shadow-2xl flex flex-col justify-between">
          {/* Drawer Header */}
          <div className="bg-[#173B52] text-[#EEE9E0] p-4 flex items-center justify-between font-mono-spec text-xs border-b border-[#272A2C]">
            <div className="flex items-center space-x-2">
              <FileText className="w-4 h-4 text-[#A77A43]" />
              <span className="font-bold tracking-wider">YOUR PROJECT SCHEDULE</span>
              <span className="bg-[#D9632A] text-white text-[10px] px-1.5 py-0.2">
                {projectItems.length} ITEMS
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-1 hover:bg-[#272A2C] text-[#EEE9E0] cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Drawer Item List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {projectItems.length === 0 ? (
              <div className="text-center py-16 space-y-3 font-mono-spec">
                <Box className="w-10 h-10 text-[#7A8081] mx-auto opacity-40" />
                <div className="text-sm font-bold text-[#173B52]">YOUR PROJECT IS EMPTY</div>
                <p className="text-xs text-[#7A8081] max-w-xs mx-auto">
                  Configure bespoke furniture pieces or select material swatches from the archive to add to your project schedule.
                </p>
              </div>
            ) : (
              projectItems.map((item) => (
                <div
                  key={item.id}
                  className="bg-[#D9D0C2]/50 border border-[#7A8081]/30 p-4 relative space-y-2 group"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="text-[10px] font-mono-spec text-[#D9632A] uppercase font-bold">
                        {item.type.replace('_', ' ')}
                      </div>
                      <h4 className="text-sm font-serif-arch font-bold text-[#173B52]">
                        {item.title}
                      </h4>
                      <div className="text-xs font-mono-spec text-[#7A8081]">{item.subtitle}</div>
                    </div>
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="p-1 text-[#7A8081] hover:text-[#6F302D] cursor-pointer"
                      title="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {item.specs && (
                    <div className="bg-[#EEE9E0] p-2 text-[10px] font-mono-spec text-[#272A2C] border border-[#7A8081]/20">
                      {item.specs}
                    </div>
                  )}

                  <div className="flex justify-between items-center text-xs font-mono-spec pt-1">
                    <span className="text-[#7A8081]">QTY: {item.quantity}</span>
                    {item.estimatedPrice ? (
                      <span className="font-bold text-[#173B52]">
                        £{(item.estimatedPrice * item.quantity).toLocaleString()}
                      </span>
                    ) : (
                      <span className="text-[#A77A43] font-bold">COMPLIMENTARY SWATCH</span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Drawer Footer & Checkout / Quote CTA */}
          {projectItems.length > 0 && (
            <div className="bg-[#D9D0C2] border-t border-[#7A8081]/40 p-4 space-y-3">
              <div className="flex justify-between items-center font-mono-spec text-xs">
                <span className="text-[#7A8081] uppercase">ESTIMATED PROJECT SUM:</span>
                <span className="text-lg font-serif-arch font-bold text-[#173B52]">
                  £{totalEstimatedCost.toLocaleString()} <span className="text-[10px] font-sans text-[#272A2C]">EX VAT</span>
                </span>
              </div>

              <div className="space-y-2">
                <button
                  onClick={() => {
                    onClose();
                    onOpenQuoteModal();
                  }}
                  className="w-full py-3 bg-[#D9632A] hover:bg-[#D9632A]/90 text-white font-mono-spec text-xs font-bold tracking-widest transition-colors flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>REQUEST FORMAL SPECIFICATION QUOTE</span>
                </button>

                <p className="text-[10px] font-mono-spec text-[#7A8081] text-center">
                  * All bespoke submissions receive dimensioned CAD drawings & trade schedules within 24 hours.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
