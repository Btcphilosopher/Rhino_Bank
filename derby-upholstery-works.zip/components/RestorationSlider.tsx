'use client';

import React, { useState } from 'react';
import { History, Shield, CheckCircle, Wrench, Clock, Scissors } from 'lucide-react';

export const RestorationSlider: React.FC = () => {
  const [sliderPos, setSliderPos] = useState<number>(50); // percentage 0 to 100

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    setSliderPos((x / rect.width) * 100);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const touch = e.touches[0];
    const x = Math.max(0, Math.min(touch.clientX - rect.left, rect.width));
    setSliderPos((x / rect.width) * 100);
  };

  return (
    <section id="craft" className="w-full bg-[#EEE9E0] py-16 border-b border-[#7A8081]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="border-b border-[#272A2C]/20 pb-6 mb-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono-spec tracking-widest text-[#173B52] bg-[#D9D0C2] inline-block px-2.5 py-1 mb-2 border-l-2 border-[#173B52]">
              SECTION 06 // HERITAGE & RESTORATION
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif-arch font-bold text-[#173B52] uppercase">
              BEFORE / AFTER CONSERVATION
            </h2>
            <p className="text-sm text-[#272A2C]/80 max-w-2xl mt-1 font-sans">
              We preserve the historic engineering of heirloom furniture. Drag the slider to reveal 
              the full structural reconstruction of a 1934 LMS Railway Director’s Armchair.
            </p>
          </div>

          <div className="bg-[#173B52] text-[#EEE9E0] px-4 py-2 font-mono-spec text-xs flex items-center space-x-2">
            <Wrench className="w-4 h-4 text-[#A77A43]" />
            <span>44 HOURS TRADITIONAL CONSERVATION</span>
          </div>
        </div>

        {/* 2-Column Comparison Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left: Interactive Before / After Split Slider (7 Cols) */}
          <div className="lg:col-span-7">
            <div
              className="relative w-full aspect-[4/3] overflow-hidden border-2 border-[#272A2C] shadow-xl select-none cursor-ew-resize group"
              onMouseMove={handleMouseMove}
              onTouchMove={handleTouchMove}
            >
              {/* "AFTER" Restored Image (Full Background) */}
              <img
                src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=1200&auto=format&fit=crop"
                alt="After: Restored Railway Director Armchair in Oxblood Hide"
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4 bg-[#173B52] text-[#EEE9E0] text-[11px] font-mono-spec px-3 py-1 font-bold z-10">
                AFTER // FULLY RESTORED 2026
              </div>

              {/* "BEFORE" Worn Image (Clipped Left Layer) */}
              <div
                className="absolute inset-0 overflow-hidden"
                style={{ width: `${sliderPos}%` }}
              >
                <img
                  src="https://images.unsplash.com/photo-1503602642458-232111445657?q=80&w=1200&auto=format&fit=crop"
                  alt="Before: Derelict Worn 1934 Armchair"
                  className="absolute inset-0 w-full h-full object-cover filter grayscale contrast-125"
                  style={{ width: '100%', maxWidth: 'none' }}
                />
                <div className="absolute top-4 left-4 bg-[#6F302D] text-white text-[11px] font-mono-spec px-3 py-1 font-bold z-10">
                  BEFORE // DERELICT LMS 1934
                </div>
              </div>

              {/* Divider Line & Handle */}
              <div
                className="absolute top-0 bottom-0 w-[3px] bg-[#D9632A] z-20 pointer-events-none"
                style={{ left: `${sliderPos}%` }}
              >
                <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 bg-[#173B52] text-[#EEE9E0] border-2 border-[#D9632A] flex items-center justify-center font-mono-spec text-[10px] font-bold shadow-lg">
                  ↔
                </div>
              </div>

              {/* Bottom Instruction Bar */}
              <div className="absolute bottom-3 inset-x-4 z-10 bg-[#272A2C]/85 backdrop-blur-sm text-[#EEE9E0] p-2.5 text-[11px] font-mono-spec flex justify-between items-center">
                <span>DRAG SLIDER TO INSPECT RESTORATION BOUNDARY</span>
                <span className="text-[#A77A43] font-bold">{Math.round(sliderPos)}% SPLIT</span>
              </div>
            </div>
          </div>

          {/* Right: Technical Restoration Log Sheet (5 Cols) */}
          <div className="lg:col-span-5 bg-[#D9D0C2] border border-[#7A8081]/40 p-6 space-y-5">
            <div className="border-b border-[#272A2C]/20 pb-3">
              <div className="text-[10px] font-mono-spec text-[#6F302D] tracking-widest uppercase font-bold">
                RESTORATION LOG // CASE 2026-R84
              </div>
              <h3 className="text-2xl font-serif-arch font-bold text-[#173B52] mt-1">
                LMS Railway Director&apos;s Armchair
              </h3>
              <p className="text-xs font-mono-spec text-[#7A8081]">
                COMMISSIONED 1934 // DERBY RAILWAY HEADQUARTERS
              </p>
            </div>

            {/* Scope of Work */}
            <div className="space-y-2 text-xs text-[#272A2C] font-sans leading-relaxed">
              <p>
                <strong>The Challenge:</strong> Arrived with cracked English oak seat rails, decayed animal glue, 
                collapsed coil springs, and desiccated split leather.
              </p>
              <p>
                <strong>The Intervention:</strong> Total frame disassembly, re-tenoning, hand-knotted Italian jute webbing, 
                8-way hand-tied copper springs, 100% curled horsehair stuffing, and full-grain aniline Oxblood leather.
              </p>
            </div>

            {/* Stage Checklist */}
            <div className="space-y-2 bg-[#EEE9E0] p-4 border border-[#7A8081]/30 font-mono-spec text-xs">
              <div className="text-[10px] text-[#7A8081] uppercase tracking-wider font-bold">
                CONSERVATION PROCESS
              </div>
              <div className="flex items-center space-x-2 text-[#173B52]">
                <CheckCircle className="w-4 h-4 text-[#D9632A] shrink-0" />
                <span>Oak Frame Re-jointed & Hydraulically Clamped</span>
              </div>
              <div className="flex items-center space-x-2 text-[#173B52]">
                <CheckCircle className="w-4 h-4 text-[#D9632A] shrink-0" />
                <span>Hand-Tied 8-Way Spring Suspension Restored</span>
              </div>
              <div className="flex items-center space-x-2 text-[#173B52]">
                <CheckCircle className="w-4 h-4 text-[#D9632A] shrink-0" />
                <span>Curled Horsehair & Lambswool Stuffing</span>
              </div>
              <div className="flex items-center space-x-2 text-[#173B52]">
                <CheckCircle className="w-4 h-4 text-[#D9632A] shrink-0" />
                <span>Midlands Full-Grain Oxblood Leather Upholstery</span>
              </div>
            </div>

            <div className="p-3 bg-[#173B52] text-[#EEE9E0] text-xs font-mono-spec flex justify-between items-center">
              <span>HAVE A HERITAGE PIECE?</span>
              <span className="text-[#A77A43] font-bold underline cursor-pointer">
                SUBMIT RESTORATION ENQUIRY →
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
