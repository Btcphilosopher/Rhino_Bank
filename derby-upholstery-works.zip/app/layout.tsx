import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'DERBY UPHOLSTERY WORKS — Bespoke Furniture / Engineered by Hand',
  description: 'Bespoke British furniture and upholstery engineered with structural discipline and master craftsmanship in Derby, England. Made to fit. Made to last.',
  openGraph: {
    title: 'DERBY UPHOLSTERY WORKS — Bespoke Furniture / Engineered by Hand',
    description: 'Bespoke British furniture and upholstery engineered with structural discipline and master craftsmanship in Derby, England.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'DERBY UPHOLSTERY WORKS — Bespoke Furniture / Engineered by Hand',
    description: 'Bespoke British furniture and upholstery engineered with structural discipline and master craftsmanship in Derby, England.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400&family=JetBrains+Mono:wght@400;500;600;700&family=Cinzel:wght@400;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="bg-[#EEE9E0] text-[#272A2C] font-sans antialiased selection:bg-[#173B52] selection:text-[#EEE9E0]" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
