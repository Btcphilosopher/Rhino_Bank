'use client';

import React, { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { HeroDrawing } from '@/components/HeroDrawing';
import { Configurator } from '@/components/Configurator';
import { ExplodedChair } from '@/components/ExplodedChair';
import { DrawingToRoom } from '@/components/DrawingToRoom';
import { MaterialLibrary } from '@/components/MaterialLibrary';
import { RestorationSlider } from '@/components/RestorationSlider';
import { ProductionWorkflow } from '@/components/ProductionWorkflow';
import { ProductCatalogue } from '@/components/ProductCatalogue';
import { ProductDetailModal } from '@/components/ProductDetailModal';
import { TradePortal } from '@/components/TradePortal';
import { JournalSection } from '@/components/JournalSection';
import { ProjectDrawer } from '@/components/ProjectDrawer';
import { QuoteRequestModal } from '@/components/QuoteRequestModal';
import { Footer } from '@/components/Footer';
import { FurnitureProduct, CustomConfiguration, MaterialSwatch, ProjectItem } from '@/types/furniture';
import { PRODUCTS_CATALOGUE, MATERIALS_DATABASE } from '@/data/mockData';

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [tradeMode, setTradeMode] = useState<boolean>(false);

  // Selected product for detailed modal spec view
  const [modalProduct, setModalProduct] = useState<FurnitureProduct | null>(null);

  // "YOUR PROJECT" State
  const [projectItems, setProjectItems] = useState<ProjectItem[]>([
    {
      id: 'init-item-01',
      type: 'CUSTOM_PIECE',
      title: 'The Derby Sofa (Bespoke 2400mm)',
      subtitle: 'Ref: DUW-SF-01 // Kiln-Dried Ash',
      specs: 'W: 2400mm • D: 980mm • Derbyshire Heavy Melton (Navy) • Turned Ash Legs',
      estimatedPrice: 3580,
      quantity: 1,
    },
    {
      id: 'init-item-02',
      type: 'MATERIAL_SAMPLE',
      title: 'Derby Oxblood Pull-Up Leather',
      subtitle: 'Full-Grain Vegetable Tanned Cowhide',
      specs: 'Martindale: 110,000 • Crib 5 Compliant • Swatch Size: 150 × 150mm',
      quantity: 1,
    },
  ]);

  const [isProjectDrawerOpen, setIsProjectDrawerOpen] = useState<boolean>(false);
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState<boolean>(false);
  const [directQuoteConfig, setDirectQuoteConfig] = useState<CustomConfiguration | null>(null);

  // Add custom configuration to Project
  const handleAddConfiguration = (config: CustomConfiguration) => {
    const newItem: ProjectItem = {
      id: `proj-item-${Date.now()}`,
      type: 'CUSTOM_PIECE',
      title: `${config.productName} (Custom ${config.width}mm)`,
      subtitle: `Code: ${config.productCode} • ${config.material.name}`,
      specs: `W: ${config.width}mm • D: ${config.depth}mm • H: ${config.height}mm • ${config.armStyle} • ${config.legFinish}`,
      estimatedPrice: config.estimatedPrice / config.quantity,
      configuration: config,
      quantity: config.quantity,
    };
    setProjectItems((prev) => [newItem, ...prev]);
    setIsProjectDrawerOpen(true);
  };

  // Direct Quote from Configurator
  const handleRequestDirectQuote = (config: CustomConfiguration) => {
    setDirectQuoteConfig(config);
    setIsQuoteModalOpen(true);
  };

  // Add Swatch sample to Project Box
  const handleAddSample = (material: MaterialSwatch) => {
    const alreadyExists = projectItems.some(
      (item) => item.type === 'MATERIAL_SAMPLE' && item.title === material.name
    );
    if (alreadyExists) {
      setIsProjectDrawerOpen(true);
      return;
    }

    const newSample: ProjectItem = {
      id: `sample-${material.id}-${Date.now()}`,
      type: 'MATERIAL_SAMPLE',
      title: material.name,
      subtitle: `${material.category} • ${material.colour} • Origin: ${material.origin}`,
      specs: `Rub Count: ${material.rubCount.toLocaleString()} • Fire Cert: ${material.fireRating.split('/')[0]}`,
      materialSample: material,
      quantity: 1,
    };
    setProjectItems((prev) => [newSample, ...prev]);
    setIsProjectDrawerOpen(true);
  };

  const handleRemoveProjectItem = (id: string) => {
    setProjectItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleClearProject = () => {
    setProjectItems([]);
  };

  // Handle configure piece from catalogue
  const handleConfigureFromCatalogue = (product: FurnitureProduct) => {
    setActiveTab('configurator');
    const el = document.getElementById('configurator');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const sampleItemsList = projectItems
    .filter((item) => item.type === 'MATERIAL_SAMPLE' && item.materialSample)
    .map((item) => item.materialSample!);

  return (
    <div className="min-h-screen flex flex-col bg-[#EEE9E0] text-[#272A2C]">
      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        projectItems={projectItems}
        onOpenProjectDrawer={() => setIsProjectDrawerOpen(true)}
        onOpenTradePortal={() => {
          setTradeMode(true);
          setActiveTab('trade');
        }}
        tradeMode={tradeMode}
        setTradeMode={setTradeMode}
      />

      {/* Main Page Views */}
      <main className="flex-1 w-full">
        {/* Dedicated Trade View or Main Atelier View */}
        {activeTab === 'trade' || tradeMode ? (
          <div className="animate-fade-in">
            <TradePortal
              onOpenSampleBox={() => setIsProjectDrawerOpen(true)}
              sampleItemsCount={sampleItemsList.length}
            />
            {/* Quick access to Material Library within trade */}
            <MaterialLibrary
              onAddSample={handleAddSample}
              sampleItems={sampleItemsList}
            />
          </div>
        ) : activeTab === 'configurator' ? (
          <div className="animate-fade-in">
            <Configurator
              onAddToProject={handleAddConfiguration}
              onRequestQuote={handleRequestDirectQuote}
            />
            <ExplodedChair />
          </div>
        ) : activeTab === 'catalogue' ? (
          <div className="animate-fade-in">
            <ProductCatalogue
              onSelectProduct={(p) => setModalProduct(p)}
              onConfigureProduct={handleConfigureFromCatalogue}
            />
            <MaterialLibrary
              onAddSample={handleAddSample}
              sampleItems={sampleItemsList}
            />
          </div>
        ) : activeTab === 'anatomy' ? (
          <div className="animate-fade-in">
            <ExplodedChair />
            <DrawingToRoom />
          </div>
        ) : activeTab === 'materials' ? (
          <div className="animate-fade-in">
            <MaterialLibrary
              onAddSample={handleAddSample}
              sampleItems={sampleItemsList}
            />
          </div>
        ) : activeTab === 'craft' ? (
          <div className="animate-fade-in">
            <RestorationSlider />
            <ProductionWorkflow />
            <ExplodedChair />
          </div>
        ) : activeTab === 'journal' ? (
          <div className="animate-fade-in">
            <JournalSection />
          </div>
        ) : (
          /* Comprehensive Complete Atelier Homepage Flow */
          <>
            {/* 1. Signature Hero CAD Drawing Morph Animation */}
            <HeroDrawing
              onConfigureClick={() => {
                setActiveTab('configurator');
                const el = document.getElementById('configurator');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              onExploreSpecsClick={() => {
                setActiveTab('catalogue');
                const el = document.getElementById('catalogue');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              onRequestQuoteClick={() => setIsQuoteModalOpen(true)}
            />

            {/* 2. Structural Philosophy & Exploded Chair Anatomy */}
            <ExplodedChair />

            {/* 3. Parametric Bespoke Configurator & Dimension Controls */}
            <Configurator
              onAddToProject={handleAddConfiguration}
              onRequestQuote={handleRequestDirectQuote}
            />

            {/* 4. Signature Narrative: From Drawing to Room */}
            <DrawingToRoom />

            {/* 5. The Material Archive & Lighting Simulator */}
            <MaterialLibrary
              onAddSample={handleAddSample}
              sampleItems={sampleItemsList}
            />

            {/* 6. Heritage Restoration & LMS Railway Chair Conservation Slider */}
            <RestorationSlider />

            {/* 7. Workshop Telemetry & Production Workflow Clock */}
            <ProductionWorkflow />

            {/* 8. Architectural Bespoke Collection Catalogue */}
            <ProductCatalogue
              onSelectProduct={(p) => setModalProduct(p)}
              onConfigureProduct={handleConfigureFromCatalogue}
            />

            {/* 9. Workshop Journal Essays */}
            <JournalSection />
          </>
        )}
      </main>

      {/* Persistent "YOUR PROJECT" Drawer */}
      <ProjectDrawer
        isOpen={isProjectDrawerOpen}
        onClose={() => setIsProjectDrawerOpen(false)}
        projectItems={projectItems}
        onRemoveItem={handleRemoveProjectItem}
        onOpenQuoteModal={() => {
          setIsProjectDrawerOpen(false);
          setIsQuoteModalOpen(true);
        }}
      />

      {/* Bespoke Quote Request Modal */}
      <QuoteRequestModal
        isOpen={isQuoteModalOpen}
        onClose={() => {
          setIsQuoteModalOpen(false);
          setDirectQuoteConfig(null);
        }}
        projectItems={projectItems}
        directConfig={directQuoteConfig}
        onClearProject={handleClearProject}
      />

      {/* Detailed Product Architectural Spec Modal */}
      <ProductDetailModal
        product={modalProduct}
        onClose={() => setModalProduct(null)}
        onConfigure={handleConfigureFromCatalogue}
      />

      {/* Footer */}
      <Footer onNavClick={(tab) => setActiveTab(tab)} />
    </div>
  );
}
