export type MaterialCategory = 'WOOL' | 'LINEN' | 'COTTON' | 'VELVET' | 'LEATHER' | 'BOUCLE' | 'PERFORMANCE';

export interface MaterialSwatch {
  id: string;
  name: string;
  category: MaterialCategory;
  supplier: string;
  colour: string;
  hex: string;
  composition: string;
  rubCount: number; // Martindale
  fireRating: string;
  weight: string;
  care: string;
  priceBand: 'BAND A' | 'BAND B' | 'BAND C' | 'BAND D' | 'BAND E (BESPOKE)';
  pricePerMeter: number;
  origin: string;
  texturePattern?: string;
  description: string;
  inStock: boolean;
}

export type LegFinish = 'TURNED_ASH' | 'SMOKED_OAK' | 'BRUSHED_BRASS' | 'CAST_IRON' | 'BLACKENED_STEEL';
export type ArmStyle = 'STRAIGHT_MINIMAL' | 'ENGLISH_ROLL' | 'ARCHITECTURAL_BOX' | 'FLUTED_SLIM';
export type BackStyle = 'TIGHT_BACK' | 'SCATTER_CUSHION' | 'FLUTED_CHANNEL' | 'DEEP_BUTTONED';
export type CushionFill = 'COLD_CURE_DOWN_WRAP' | 'DUAL_DENSITY_LATEX' | 'POCKET_SPRUNG_WOOL';

export interface FurnitureProduct {
  id: string;
  code: string;
  name: string;
  category: 'SOFAS' | 'ARMCHAIRS' | 'DINING' | 'BANQUETTES' | 'HEADBOARDS' | 'OTTOMANS';
  strapline: string;
  description: string;
  basePrice: number;
  defaultDimensions: {
    width: number;
    depth: number;
    height: number;
    seatHeight: number;
    seatDepth: number;
  };
  dimensionLimits: {
    minWidth: number;
    maxWidth: number;
    minDepth: number;
    maxDepth: number;
    minHeight: number;
    maxHeight: number;
  };
  frameMaterial: string;
  joinery: string;
  suspension: string;
  cushion: string;
  leadTimeWeeks: string;
  image: string;
  schematicSvg?: string;
  tags: string[];
}

export interface CustomConfiguration {
  productId: string;
  productName: string;
  productCode: string;
  width: number;
  depth: number;
  height: number;
  seatHeight: number;
  armStyle: ArmStyle;
  backStyle: BackStyle;
  legFinish: LegFinish;
  cushionFill: CushionFill;
  material: MaterialSwatch;
  piping: 'MATCHING' | 'CONTRAST_LEATHER' | 'NO_PIPING';
  stitching: 'SINGLE_NEEDLE' | 'DOUBLE_TOPSTITCH' | 'SADDLE_HAND_STITCH';
  quantity: number;
  notes?: string;
  estimatedPrice: number;
  calculatedLeadTime: string;
}

export interface ProjectItem {
  id: string;
  type: 'CUSTOM_PIECE' | 'STANDARD_PRODUCT' | 'MATERIAL_SAMPLE';
  title: string;
  subtitle: string;
  specs: string;
  estimatedPrice?: number;
  configuration?: CustomConfiguration;
  materialSample?: MaterialSwatch;
  quantity: number;
}

export interface TradeProject {
  id: string;
  code: string;
  title: string;
  client: string;
  projectType: 'HOSPITALITY' | 'COMMERCIAL' | 'RESIDENTIAL' | 'HERITAGE';
  location: string;
  furnitureDescription: string;
  unitsCount: number;
  status: 'DRAWING_REVIEW' | 'FABRIC_APPROVAL' | 'FRAME_JOINERY' | 'WEBBING_PADDING' | 'UPHOLSTERY' | 'QUALITY_INSPECTION' | 'DISPATCH_READY';
  progressPercentage: number;
  currentRevision: string;
  revisionDate: string;
  leadDesigner: string;
  deliveryDate: string;
  cadFileUrl?: string;
}

export interface DrawingRevision {
  id: string;
  projectId: string;
  projectTitle: string;
  drawingNumber: string;
  revision: string;
  title: string;
  scale: string;
  date: string;
  approvedBy: string;
  status: 'APPROVED' | 'IN_REVIEW' | 'SUPERSEDED';
  notes: string;
}

export interface JournalArticle {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  category: 'CRAFT & ENGINEERING' | 'DERBY ARCHIVE' | 'MATERIALS' | 'RESTORATION';
  readTime: string;
  date: string;
  author: string;
  heroImage: string;
  summary: string;
  content: string[];
  specs?: { label: string; value: string }[];
}
