'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { ArrowRight, Menu, X } from 'lucide-react';

interface NavbarProps {
  onOpenRFQ: () => void;
}

export function Navbar({ onOpenRFQ }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#151819]/95 backdrop-blur-md border-b border-[#25292B]'
          : 'bg-gradient-to-b from-[#151819]/90 to-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        {/* Zone 1: Single text element wordmark */}
        <Link
          href="/"
          className="text-base font-semibold tracking-wider text-[#E8E9E6] hover:text-white transition-colors uppercase"
        >
          SHEFFIELD PRECISION WORKS
        </Link>

        {/* Zone 2: Clean text navigation links */}
        <nav className="hidden lg:flex items-center gap-8 text-xs uppercase tracking-wider font-medium text-[#A8AFB1]">
          <a
            href="#capabilities"
            className="hover:text-[#E8E9E6] transition-colors py-1 hover:border-b border-[#C96532]"
          >
            Capabilities
          </a>
          <a
            href="#transformation"
            className="hover:text-[#E8E9E6] transition-colors py-1 hover:border-b border-[#C96532]"
          >
            Production Flow
          </a>
          <a
            href="#sectors"
            className="hover:text-[#E8E9E6] transition-colors py-1 hover:border-b border-[#C96532]"
          >
            Sectors
          </a>
          <a
            href="#materials"
            className="hover:text-[#E8E9E6] transition-colors py-1 hover:border-b border-[#C96532]"
          >
            Alloys & Specs
          </a>
          <a
            href="#heritage"
            className="hover:text-[#E8E9E6] transition-colors py-1 hover:border-b border-[#C96532]"
          >
            Heritage
          </a>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-4">
          <button
            onClick={onOpenRFQ}
            className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#151819] bg-[#E8E9E6] hover:bg-white active:scale-[0.98] transition-all rounded-none border border-[#E8E9E6] hover:border-white shadow-sm"
          >
            <span>Request RFQ</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-[#E8E9E6] hover:text-white"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#151819] border-b border-[#25292B] px-6 py-6 space-y-4">
          <nav className="flex flex-col gap-4 text-sm font-medium tracking-wide uppercase text-[#A8AFB1]">
            <a
              href="#capabilities"
              onClick={() => setMobileMenuOpen(false)}
              className="hover:text-white transition-colors"
            >
              Capabilities
            </a>
            <a
              href="#transformation"
              onClick={() => setMobileMenuOpen(false)}
              className="hover:text-white transition-colors"
            >
              Production Flow
            </a>
            <a
              href="#sectors"
              onClick={() => setMobileMenuOpen(false)}
              className="hover:text-white transition-colors"
            >
              Sectors
            </a>
            <a
              href="#materials"
              onClick={() => setMobileMenuOpen(false)}
              className="hover:text-white transition-colors"
            >
              Alloys & Specs
            </a>
            <a
              href="#heritage"
              onClick={() => setMobileMenuOpen(false)}
              className="hover:text-white transition-colors"
            >
              Heritage
            </a>
          </nav>
          <div className="pt-4 border-t border-[#25292B]">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenRFQ();
              }}
              className="w-full py-3 px-4 text-xs font-semibold uppercase tracking-wider text-[#151819] bg-[#E8E9E6] hover:bg-white transition-colors flex items-center justify-center gap-2"
            >
              <span>Request Technical RFQ</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
