'use client';

import React, { useState } from 'react';
import { CheckCircle2, ChevronRight, Layers, Ruler, Shield, Sparkles } from 'lucide-react';

interface StageDetail {
  id: string;
  step: string;
  title: string;
  subtitle: string;
  description: string;
  grainStructure: string;
  tolerance: string;
  surfaceFinish: string;
  inspectionMode: string;
  metallurgyNotes: string[];
}

export function SignatureTransformation() {
  const [selectedStage, setSelectedStage] = useState<number>(1);
  const [activeFinish, setActiveFinish] = useState<string>('brushed');

  const stages: StageDetail[] = [
    {
      id: 'raw',
      step: 'STAGE 01',
      title: 'Certified Forged Steel Billet',
      subtitle: 'Vacuum Arc Remelted (VAR) Ingot',
      description: 'Precision begins at the molecular level. Sourced directly from Sheffield certified electric arc melt facilities with complete heat traceability (BS EN 10204 3.1 certification).',
      grainStructure: 'Equiaxed fine-grain austenitic microstructure',
      tolerance: 'Pre-machining stock +3.0 / -0.0 mm',
      surfaceFinish: 'As-forged hot rolled (Ra 6.3 - 12.5 µm)',
      inspectionMode: 'Ultrasonic flaw detection to AMS 2154 Class AA',
      metallurgyNotes: [
        'Sheffield 316L / 1.4404 vacuum melted melt chemistry',
        'Inclusion rating ASTM E45 method A < 1.0',
        '100% Spark spectrometry verified on delivery',
      ],
    },
    {
      id: 'machined',
      step: 'STAGE 02',
      title: '5-Axis Multi-Task CNC Machining',
      subtitle: 'Simultaneous Milling & Mill-Turn Cells',
      description: 'Hermle & DMG Mori 5-axis machining centres running high-pressure coolant (80 bar) through precision carbide tooling to achieve zero-vibration harmonic stability.',
      grainStructure: 'Work-hardened surface layer with stabilized core',
      tolerance: 'Critical bore diameter: ±0.005 mm (5 microns)',
      surfaceFinish: 'Precision turned & milled (Ra 0.28 µm)',
      inspectionMode: 'Renishaw high-speed in-process radio probes',
      metallurgyNotes: [
        'Controlled toolpath cycle eliminates thermal deflection',
        'Interrupted cut compensation for thin-walled aerospace housings',
        'Cryogenic deburring and ultrasonic wash',
      ],
    },
    {
      id: 'inspected',
      step: 'STAGE 03',
      title: 'UKAS CMM Metrology & Certification',
      subtitle: 'Climate-Controlled Cleanroom Inspection',
      description: 'Zeiss coordinate measuring machines with continuous scanning probes map 12,000 discrete surface coordinates inside a constant 20.0°C (±0.2°C) metrology lab.',
      grainStructure: 'Full metallurgical integrity report generated',
      tolerance: 'Zero non-conformances across 48 datum points',
      surfaceFinish: 'Mirror-lapped seal faces (Ra 0.10 µm)',
      inspectionMode: 'Zeiss Calypso 3D scan & laser interferometer',
      metallurgyNotes: [
        'Digital FAIR (First Article Inspection Report) to AS9102',
        'Permanent micro-percussion laser part etching',
        'Hermetic sealed packaging with desiccants for global dispatch',
      ],
    },
  ];

  const steelFinishes = [
    { id: 'mirror', name: 'Mirror-Polished Stainless', desc: 'Ra < 0.08 µm for dynamic hydraulic & shaft seals' },
    { id: 'brushed', name: 'Brushed Stainless (316L)', desc: 'Directional satin grain for high-corrosion aerospace housings' },
    { id: 'darkened', name: 'Black Oxide / Darkened Steel', desc: 'Anti-glare military & rail optical chassis finish' },
    { id: 'ground', name: 'Precision-Ground Surface', desc: 'Cylindrical grinding with sub-micron geometric roundness' },
    { id: 'heattreat', name: 'Heat-Treated & Quenched', desc: 'Induction hardened 58-62 HRC wear-resistant gear teeth' },
    { id: 'oiled', name: 'Lightly Oiled Preservation', desc: 'Vapour corrosion inhibitor protection for shipping' },
  ];

  const current = stages[selectedStage];

  return (
    <section id="transformation" className="py-24 bg-[#151819] border-b border-[#25292B]">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="space-y-3 max-w-3xl mb-16">
          <div className="flex items-center gap-2">
            <span className="w-5 h-[1.5px] bg-[#C96532]" />
            <p className="text-xs uppercase tracking-[0.25em] font-mono text-[#A8AFB1]">
              SIGNATURE METALLURGY & PRODUCTION
            </p>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#E8E9E6] uppercase">
            RAW STEEL <span className="text-[#536873]">→</span> MACHINED PART <span className="text-[#536873]">→</span> INSPECTED COMPONENT
          </h2>
          <p className="text-[#A8AFB1] text-base leading-relaxed">
            The entire Sheffield Precision Works proposition embodied in a single continuum. 
            We control every micro-step from certified billet chemistry to laser-verified coordinate inspection.
          </p>
        </div>

        {/* 3-Stage Progress Nav Selector */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {stages.map((stage, idx) => {
            const isActive = selectedStage === idx;
            return (
              <button
                key={stage.id}
                onClick={() => setSelectedStage(idx)}
                className={`text-left p-6 transition-all border ${
                  isActive
                    ? 'bg-[#25292B] border-[#E8E9E6] shadow-lg'
                    : 'bg-[#151819] border-[#25292B] hover:border-[#536873] opacity-80 hover:opacity-100'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono font-semibold tracking-wider text-[#C96532]">
                    {stage.step}
                  </span>
                  <span className="text-xs font-mono text-[#536873]">
                    0{idx + 1} / 03
                  </span>
                </div>
                <h3 className="text-lg font-semibold text-[#E8E9E6] mb-1">
                  {stage.title}
                </h3>
                <p className="text-xs font-mono text-[#A8AFB1]">
                  {stage.subtitle}
                </p>
              </button>
            );
          })}
        </div>

        {/* Deep Dive Inspection Panel for Active Stage */}
        <div className="bg-[#25292B]/40 border border-[#25292B] p-8 lg:p-10 mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            
            {/* Left: Detailed Analysis */}
            <div className="lg:col-span-7 space-y-6">
              <div>
                <span className="text-xs font-mono uppercase tracking-widest text-[#C96532]">
                  ENGINEERING SPECIFICATION // {current.step}
                </span>
                <h4 className="text-2xl font-bold text-[#E8E9E6] mt-1 mb-3">
                  {current.title}
                </h4>
                <p className="text-[#A8AFB1] text-sm leading-relaxed">
                  {current.description}
                </p>
              </div>

              {/* Technical Spec Matrix */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="bg-[#151819] p-4 border border-[#25292B]">
                  <p className="text-[11px] font-mono uppercase text-[#A8AFB1]">Microstructure</p>
                  <p className="text-sm font-semibold text-[#E8E9E6] mt-1">{current.grainStructure}</p>
                </div>
                <div className="bg-[#151819] p-4 border border-[#25292B]">
                  <p className="text-[11px] font-mono uppercase text-[#A8AFB1]">Tolerance Achieved</p>
                  <p className="text-sm font-semibold text-[#E8E9E6] font-mono tabular-nums mt-1">{current.tolerance}</p>
                </div>
                <div className="bg-[#151819] p-4 border border-[#25292B]">
                  <p className="text-[11px] font-mono uppercase text-[#A8AFB1]">Surface Roughness</p>
                  <p className="text-sm font-semibold text-[#E8E9E6] font-mono mt-1">{current.surfaceFinish}</p>
                </div>
                <div className="bg-[#151819] p-4 border border-[#25292B]">
                  <p className="text-[11px] font-mono uppercase text-[#A8AFB1]">Metrology Verification</p>
                  <p className="text-sm font-semibold text-[#E8E9E6] mt-1">{current.inspectionMode}</p>
                </div>
              </div>

              {/* Quality Checklist */}
              <div className="space-y-2 pt-2">
                <p className="text-xs font-mono uppercase tracking-wider text-[#A8AFB1]">Sheffield Quality Assurance:</p>
                {current.metallurgyNotes.map((note, i) => (
                  <div key={i} className="flex items-center gap-2.5 text-xs text-[#E8E9E6] font-mono">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{note}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Tactile Physical Finishes Library */}
            <div className="lg:col-span-5 bg-[#151819] p-6 border border-[#25292B] flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between border-b border-[#25292B] pb-3 mb-4">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-[#C96532]" />
                    <span className="text-xs font-mono uppercase tracking-wider text-[#E8E9E6] font-semibold">
                      STEEL SURFACE FINISHES
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-[#A8AFB1]">
                    SHEFFIELD SPEC
                  </span>
                </div>
                <p className="text-xs text-[#A8AFB1] mb-4">
                  Select a precision surface finish to view technical roughness parameters:
                </p>

                <div className="space-y-2">
                  {steelFinishes.map((f) => (
                    <button
                      key={f.id}
                      onClick={() => setActiveFinish(f.id)}
                      className={`w-full text-left p-3 text-xs transition-all border ${
                        activeFinish === f.id
                          ? 'bg-[#25292B] border-[#E8E9E6] text-[#E8E9E6]'
                          : 'bg-[#151819] border-[#25292B] text-[#A8AFB1] hover:text-[#E8E9E6] hover:border-[#536873]'
                      }`}
                    >
                      <div className="flex items-center justify-between font-mono font-medium">
                        <span>{f.name}</span>
                        {activeFinish === f.id && <ChevronRight className="w-3.5 h-3.5 text-[#C96532]" />}
                      </div>
                      <p className="text-[11px] text-[#A8AFB1] mt-1 font-sans">{f.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-[#25292B] flex items-center justify-between text-[11px] font-mono text-[#536873]">
                <span>DIN EN ISO 1302 COMPLIANT</span>
                <span className="text-[#C96532]">100% TRACEABLE</span>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
