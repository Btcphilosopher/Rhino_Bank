'use client';

import React, { useState } from 'react';
import { ArrowRight, ShieldCheck, Plane, Train, Zap, Shield, HeartPulse, Factory } from 'lucide-react';

interface SectorDetail {
  id: string;
  name: string;
  icon: any;
  leadTime: string;
  standard: string;
  components: string[];
  alloys: string[];
  caseStudy: string;
  tolerance: string;
}

export function SectorsMatrix() {
  const [activeSector, setActiveSector] = useState<string>('aerospace');

  const sectors: SectorDetail[] = [
    {
      id: 'aerospace',
      name: 'Aerospace & Space Systems',
      icon: Plane,
      leadTime: '3-6 Weeks Fast-Track',
      standard: 'AS9100D / EN 9100',
      components: [
        'Turbine rotor seal rings',
        'Auxiliary power unit (APU) housings',
        'Landing gear trunnion shafts',
        'Hydraulic actuator manifolds',
      ],
      alloys: ['Inconel 718', 'Ti-6Al-4V Grade 5', '17-4PH Stainless', 'Maraging 300 Steel'],
      caseStudy: 'Zero-defect delivery of 420 jet engine stator shroud rings for leading UK aerospace manufacturer with 100% CMM traceability.',
      tolerance: '±0.003 mm',
    },
    {
      id: 'rail',
      name: 'High-Speed Rail & Rolling Stock',
      icon: Train,
      leadTime: '2-4 Weeks',
      standard: 'RISAS / BS EN 15085',
      components: [
        'Traction motor drive pinions',
        'High-speed axle journals & bearings',
        'Bogie suspension linkages',
        'Pneumatic brake valve housings',
      ],
      alloys: ['EN24T / 817M40', 'EN19 / 709M40', 'Cast Austenitic Manganese', 'Sheffield Tool Steel'],
      caseStudy: 'Precision finish-machined driving wheel pinions for UK intercity express fleets surviving 1.2M service miles without measurable tooth wear.',
      tolerance: '±0.008 mm',
    },
    {
      id: 'defence',
      name: 'Defence & Marine Engineering',
      icon: Shield,
      leadTime: '4-8 Weeks Strict Security',
      standard: 'DEF STAN 02-729 / ISO 9001',
      components: [
        'Submarine propulsion shaft sleeves',
        'Gun turret azimuth gear assemblies',
        'Armoured vehicle drive hubs',
        'Sonar transducer pressure hulls',
      ],
      alloys: ['Monel K500', 'Super Duplex 2507', 'BS 970 High Tensile', 'Sheffield Carbon Steel'],
      caseStudy: 'Subsea naval titanium-stainless composite valves certified for 600 bar operating hydrostatic pressure.',
      tolerance: '±0.005 mm',
    },
    {
      id: 'energy',
      name: 'Nuclear & High-Pressure Energy',
      icon: Zap,
      leadTime: '4-6 Weeks',
      standard: 'RCC-M / ASME Section III',
      components: [
        'Reactor coolant pump impellers',
        'High-pressure steam bypass valves',
        'Turbine diaphragm nozzle rings',
        'Fusion vacuum vessel port flanges',
      ],
      alloys: ['316L (Nuclear Grade)', 'Alloy 625', 'Hastelloy C276', '15-5PH Stainless'],
      caseStudy: 'Supplied precision turned reactor primary circuit sealing flanges with helium leak rates < 1x10⁻⁹ mbar·l/s.',
      tolerance: '±0.002 mm',
    },
    {
      id: 'medical',
      name: 'Medical & Orthopaedic Devices',
      icon: HeartPulse,
      leadTime: '2-4 Weeks',
      standard: 'ISO 13485 Compliant Cleanroom',
      components: [
        'Prosthetic hip femoral stems',
        'Surgical robotic arm joints',
        'Centrifuge high-speed rotor bells',
        'MRI cryogenic containment seals',
      ],
      alloys: ['316LVM Bio-dur', 'Co-Cr-Mo ASTM F75', 'Grade 23 Ti-6Al-4V ELI'],
      caseStudy: 'Micro-milled surgical robotics components with Ra < 0.05 µm mirror lapping, processed under validated cleanroom protocols.',
      tolerance: '±0.0015 mm',
    },
    {
      id: 'machinery',
      name: 'Heavy Industrial Machinery',
      icon: Factory,
      leadTime: '1-3 Weeks',
      standard: 'DIN ISO 2768-mK',
      components: [
        'Rolling mill eccentric shafts',
        'Extruder feed screws & barrels',
        'Heavy hydraulic cylinder caps',
        'High-torque planetary carriers',
      ],
      alloys: ['4140 Quenched & Tempered', 'AISI 4340 Alloy', 'Sheffield D2 Tool Steel'],
      caseStudy: 'Refurbished and finish-ground 4.5-tonne rolling mill pinion shafts with sub-second geometric concentricity.',
      tolerance: '±0.010 mm',
    },
  ];

  const current = sectors.find(s => s.id === activeSector) || sectors[0];
  const CurrentIcon = current.icon;

  return (
    <section id="sectors" className="py-24 bg-[#151819] border-b border-[#25292B]">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="space-y-3 max-w-3xl mb-14">
          <div className="flex items-center gap-2">
            <span className="w-5 h-[1.5px] bg-[#C96532]" />
            <p className="text-xs uppercase tracking-[0.25em] font-mono text-[#A8AFB1]">
              MISSION-CRITICAL SUPPLY
            </p>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#E8E9E6] uppercase">
            SECTORS & CRITICAL INFRASTRUCTURE
          </h2>
          <p className="text-[#A8AFB1] text-base leading-relaxed">
            Supplying British and international prime contractors across aerospace, high-speed rail, 
            nuclear energy, and naval defence with full material batch pedigree and AS9100D compliance.
          </p>
        </div>

        {/* Sectors Interactive Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 mb-8">
          {sectors.map((s) => {
            const Icon = s.icon;
            const isActive = s.id === activeSector;
            return (
              <button
                key={s.id}
                onClick={() => setActiveSector(s.id)}
                className={`p-4 text-left transition-all border flex flex-col justify-between h-32 ${
                  isActive
                    ? 'bg-[#25292B] border-[#E8E9E6] text-white shadow-md'
                    : 'bg-[#151819] border-[#25292B] text-[#A8AFB1] hover:text-[#E8E9E6] hover:border-[#536873]'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'text-[#C96532]' : 'text-[#536873]'}`} />
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide leading-snug">
                    {s.name.split(' ')[0]}
                  </p>
                  <p className="text-[10px] font-mono text-[#536873] mt-0.5">
                    {s.standard.split('/')[0]}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Sector Deep Dive Console */}
        <div className="bg-[#25292B]/50 border border-[#25292B] p-8 lg:p-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Column: Sector Overview & Components */}
            <div className="lg:col-span-7 space-y-6">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-[#151819] border border-[#25292B]">
                  <CurrentIcon className="w-6 h-6 text-[#C96532]" />
                </div>
                <div>
                  <span className="text-xs font-mono uppercase text-[#A8AFB1]">SECTOR APPLICATION</span>
                  <h3 className="text-2xl font-bold text-[#E8E9E6]">{current.name}</h3>
                </div>
              </div>

              {/* Components List */}
              <div className="space-y-3">
                <p className="text-xs font-mono uppercase tracking-wider text-[#A8AFB1]">
                  TYPICAL CRITICAL COMPONENTS MACHINED:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {current.components.map((c, i) => (
                    <div key={i} className="bg-[#151819] p-3 border border-[#25292B] flex items-center gap-2.5">
                      <span className="w-1.5 h-1.5 bg-[#C96532] shrink-0" />
                      <span className="text-xs font-mono text-[#E8E9E6]">{c}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Case Study Evidence */}
              <div className="bg-[#151819] p-5 border-l-2 border-[#C96532] space-y-2">
                <span className="text-[11px] font-mono uppercase tracking-wider text-[#A8AFB1]">
                  VERIFIED INDUSTRY TRACK RECORD:
                </span>
                <p className="text-xs text-[#E8E9E6] leading-relaxed">
                  &ldquo;{current.caseStudy}&rdquo;
                </p>
              </div>
            </div>

            {/* Right Column: Standards & Alloys */}
            <div className="lg:col-span-5 bg-[#151819] p-6 border border-[#25292B] space-y-6">
              <div>
                <p className="text-[11px] font-mono uppercase text-[#A8AFB1]">ACCREDITATION & STANDARDS</p>
                <p className="text-lg font-bold font-mono text-[#E8E9E6] mt-0.5">{current.standard}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-[11px] font-mono uppercase text-[#A8AFB1]">TOLERANCE CAPACITY</p>
                  <p className="text-base font-bold font-mono text-[#C96532] mt-0.5 tabular-nums">{current.tolerance}</p>
                </div>
                <div>
                  <p className="text-[11px] font-mono uppercase text-[#A8AFB1]">BATCH LEAD TIME</p>
                  <p className="text-base font-bold font-mono text-[#E8E9E6] mt-0.5">{current.leadTime}</p>
                </div>
              </div>

              <div className="space-y-2 border-t border-[#25292B] pt-4">
                <p className="text-[11px] font-mono uppercase text-[#A8AFB1]">APPROVED METALLURGICAL ALLOYS:</p>
                <div className="flex flex-wrap gap-2">
                  {current.alloys.map((alloy, i) => (
                    <span
                      key={i}
                      className="text-xs font-mono text-[#E8E9E6] bg-[#25292B] px-2.5 py-1 border border-[#25292B]"
                    >
                      {alloy}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <a
                  href="#rfq"
                  className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 text-xs font-mono font-semibold uppercase tracking-wider text-[#151819] bg-[#E8E9E6] hover:bg-white transition-colors"
                >
                  <span>REQUEST SECTOR SPECIFICATION</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
