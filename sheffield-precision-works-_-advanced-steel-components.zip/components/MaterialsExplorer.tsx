'use client';

import React, { useState } from 'react';
import { Search, SlidersHorizontal, Check, Download, ShieldCheck } from 'lucide-react';

interface SteelGrade {
  grade: string;
  category: 'stainless' | 'hightensile' | 'superalloys' | 'toolsteel';
  standard: string;
  tensile: string;
  yieldStrength: string;
  hardness: string;
  machinability: string;
  composition: { element: string; pct: string }[];
  applications: string;
  notes: string;
}

const STEEL_GRADES: SteelGrade[] = [
  {
    grade: '316L Stainless Steel',
    category: 'stainless',
    standard: 'BS EN 10088-3 / 1.4404 / UNS S31603',
    tensile: '550 - 700 MPa',
    yieldStrength: '240 MPa min',
    hardness: '160 - 190 HB',
    machinability: '45% (Austenitic)',
    composition: [
      { element: 'Cr', pct: '16.5 - 18.5%' },
      { element: 'Ni', pct: '10.0 - 13.0%' },
      { element: 'Mo', pct: '2.0 - 2.5%' },
      { element: 'C', pct: '≤ 0.030%' },
    ],
    applications: 'Aerospace hydraulic manifolds, offshore subsea flanges, medical centrifuge housings.',
    notes: 'Ultra-low carbon prevents intergranular corrosion after welding. Vacuum arc remelted for high purity.',
  },
  {
    grade: '17-4 PH Precipitation Hardening',
    category: 'stainless',
    standard: 'AMS 5643 / UNS S17400 / 1.4542',
    tensile: '930 - 1,310 MPa (H900)',
    yieldStrength: '790 - 1,170 MPa',
    hardness: '38 - 44 HRC',
    machinability: '55% (Condition A)',
    composition: [
      { element: 'Cr', pct: '15.0 - 17.5%' },
      { element: 'Ni', pct: '3.0 - 5.0%' },
      { element: 'Cu', pct: '3.0 - 5.0%' },
      { element: 'Nb', pct: '0.15 - 0.45%' },
    ],
    applications: 'High-speed jet engine compressor blades, nuclear valve stems, missile fin actuators.',
    notes: 'Martensitic precipitation hardening alloy combining extreme tensile strength with corrosion resistance.',
  },
  {
    grade: 'EN24T / 817M40 High Tensile',
    category: 'hightensile',
    standard: 'BS 970: 1983 / 34CrNiMo6',
    tensile: '850 - 1,000 MPa',
    yieldStrength: '680 MPa min',
    hardness: '248 - 302 HB (28-32 HRC)',
    machinability: '65% (Tempered)',
    composition: [
      { element: 'Ni', pct: '1.30 - 1.80%' },
      { element: 'Cr', pct: '0.90 - 1.40%' },
      { element: 'Mo', pct: '0.20 - 0.35%' },
      { element: 'C', pct: '0.36 - 0.44%' },
    ],
    applications: 'Locomotive traction pinions, high-torque splined shafts, heavy crane drive gears.',
    notes: 'A premier British engineering nickel-chromium-molybdenum alloy with outstanding shock and fatigue endurance.',
  },
  {
    grade: 'Inconel 718 Nickel Superalloy',
    category: 'superalloys',
    standard: 'AMS 5662 / UNS N07718',
    tensile: '1,240 - 1,400 MPa',
    yieldStrength: '1,030 MPa',
    hardness: '36 - 44 HRC',
    machinability: '15% (Severe work-hardening)',
    composition: [
      { element: 'Ni+Co', pct: '50.0 - 55.0%' },
      { element: 'Cr', pct: '17.0 - 21.0%' },
      { element: 'Mo', pct: '2.8 - 3.3%' },
      { element: 'Nb+Ta', pct: '4.75 - 5.50%' },
    ],
    applications: 'Rocket propulsion turbopumps, gas turbine discs, deep-water oil well completion tools.',
    notes: 'Retains immense mechanical properties from cryogenic temperatures up to 700°C. Requires rigid 5-axis tooling.',
  },
  {
    grade: 'Maraging Steel 300 (Vascomax)',
    category: 'hightensile',
    standard: 'AMS 6514 / UNS K93120',
    tensile: '2,050 MPa',
    yieldStrength: '2,000 MPa',
    hardness: '50 - 55 HRC',
    machinability: '35% (Pre-aged)',
    composition: [
      { element: 'Ni', pct: '18.0 - 19.0%' },
      { element: 'Co', pct: '8.5 - 9.5%' },
      { element: 'Mo', pct: '4.7 - 5.2%' },
      { element: 'Ti', pct: '0.5 - 0.8%' },
    ],
    applications: 'Centrifuge rotor cylinders, aerospace rocket motor cases, ultra-high-pressure valve plungers.',
    notes: 'Carbon-free iron-nickel martensite with zero dimensional distortion during age-hardening thermal cycle.',
  },
  {
    grade: 'Sheffield D2 Cold Work Tool Steel',
    category: 'toolsteel',
    standard: 'AISI D2 / BS BD2 / 1.2379',
    tensile: '1,800 MPa',
    yieldStrength: '1,650 MPa',
    hardness: '58 - 62 HRC (Hardened)',
    machinability: '25% (Annealed: 50%)',
    composition: [
      { element: 'Cr', pct: '11.0 - 13.0%' },
      { element: 'C', pct: '1.40 - 1.60%' },
      { element: 'Mo', pct: '0.70 - 1.20%' },
      { element: 'V', pct: '0.70 - 1.10%' },
    ],
    applications: 'Forming rolls, precision punches, high-wear slitter knives, extrusion dies.',
    notes: 'High carbon, high chromium alloy offering maximum abrasive wear resistance and dimensional stability.',
  },
];

export function MaterialsExplorer() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeGrade, setActiveGrade] = useState<SteelGrade>(STEEL_GRADES[0]);

  const filteredGrades = STEEL_GRADES.filter((item) => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch =
      item.grade.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.standard.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.applications.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <section id="materials" className="py-24 bg-[#151819] border-b border-[#25292B]">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="space-y-3 max-w-3xl mb-14">
          <div className="flex items-center gap-2">
            <span className="w-5 h-[1.5px] bg-[#C96532]" />
            <p className="text-xs uppercase tracking-[0.25em] font-mono text-[#A8AFB1]">
              METALLURGICAL DIRECTORY
            </p>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#E8E9E6] uppercase">
            CERTIFIED SHEFFIELD STEEL GRADES
          </h2>
          <p className="text-[#A8AFB1] text-base leading-relaxed">
            Every component is machined from certified ingot chemistry with complete EN 10204 3.1 
            inspection test certificates, spectrometer verification, and heat lot micro-cleanliness.
          </p>
        </div>

        {/* Search & Category Filter Toolbar */}
        <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-[#25292B]/40 p-4 border border-[#25292B] mb-8">
          
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-1 w-full sm:w-auto">
            {[
              { id: 'all', label: 'All Alloys' },
              { id: 'stainless', label: 'Stainless & PH' },
              { id: 'hightensile', label: 'High Tensile' },
              { id: 'superalloys', label: 'Superalloys' },
              { id: 'toolsteel', label: 'Tool Steels' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 text-xs font-mono uppercase tracking-wider transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-[#E8E9E6] text-[#151819] font-bold shadow-sm'
                    : 'text-[#A8AFB1] hover:text-[#E8E9E6]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Search Field */}
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-[#A8AFB1] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search grade or standard..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs font-mono bg-[#151819] border border-[#25292B] text-[#E8E9E6] placeholder-[#536873] focus:outline-none focus:border-[#C96532]"
            />
          </div>
        </div>

        {/* Split View: Table List on Left, Active Spec Sheet on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Table List */}
          <div className="lg:col-span-7 overflow-x-auto border border-[#25292B]">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#25292B] border-b border-[#25292B] text-[11px] font-mono uppercase text-[#A8AFB1]">
                  <th className="py-3 px-4">Alloy Grade</th>
                  <th className="py-3 px-4">Tensile (MPa)</th>
                  <th className="py-3 px-4">Hardness</th>
                  <th className="py-3 px-4">Machinability</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#25292B] text-xs font-mono">
                {filteredGrades.map((g) => {
                  const isSelected = activeGrade?.grade === g.grade;
                  return (
                    <tr
                      key={g.grade}
                      onClick={() => setActiveGrade(g)}
                      className={`cursor-pointer transition-colors ${
                        isSelected
                          ? 'bg-[#25292B] text-[#E8E9E6]'
                          : 'hover:bg-[#25292B]/40 text-[#A8AFB1] hover:text-[#E8E9E6]'
                      }`}
                    >
                      <td className="py-4 px-4 font-semibold text-[#E8E9E6]">
                        {g.grade}
                        <span className="block text-[10px] text-[#536873] font-normal truncate max-w-[180px]">
                          {g.standard.split('/')[0]}
                        </span>
                      </td>
                      <td className="py-4 px-4 tabular-nums text-[#E8E9E6]">{g.tensile}</td>
                      <td className="py-4 px-4 tabular-nums text-[#C96532] font-semibold">{g.hardness}</td>
                      <td className="py-4 px-4 text-[#A8AFB1]">{g.machinability}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Right Active Spec Sheet */}
          {activeGrade && (
            <div className="lg:col-span-5 bg-[#25292B]/50 border border-[#25292B] p-6 sm:p-8 space-y-6">
              <div className="border-b border-[#25292B] pb-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono uppercase text-[#C96532] font-semibold">
                    METALLURGY DATA SHEET
                  </span>
                  <span className="text-[10px] font-mono text-[#A8AFB1] border border-[#25292B] px-2 py-0.5">
                    BS EN 10204 3.1
                  </span>
                </div>
                <h3 className="text-2xl font-bold text-[#E8E9E6] mt-1">{activeGrade.grade}</h3>
                <p className="text-xs font-mono text-[#A8AFB1] mt-0.5">{activeGrade.standard}</p>
              </div>

              {/* Chemical Chemistry */}
              <div className="space-y-2">
                <p className="text-[11px] font-mono uppercase text-[#A8AFB1]">
                  NOMINAL CHEMICAL COMPOSITION:
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {activeGrade.composition.map((c, i) => (
                    <div key={i} className="bg-[#151819] p-2 border border-[#25292B] text-center">
                      <span className="text-xs font-mono font-bold text-[#C96532] block">{c.element}</span>
                      <span className="text-[11px] font-mono text-[#E8E9E6]">{c.pct}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Mechanical Properties */}
              <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                <div className="bg-[#151819] p-3 border border-[#25292B]">
                  <span className="text-[10px] text-[#A8AFB1] block">TENSILE STRENGTH</span>
                  <span className="font-bold text-[#E8E9E6]">{activeGrade.tensile}</span>
                </div>
                <div className="bg-[#151819] p-3 border border-[#25292B]">
                  <span className="text-[10px] text-[#A8AFB1] block">MIN YIELD (Rp0.2)</span>
                  <span className="font-bold text-[#E8E9E6]">{activeGrade.yieldStrength}</span>
                </div>
                <div className="bg-[#151819] p-3 border border-[#25292B]">
                  <span className="text-[10px] text-[#A8AFB1] block">HARDNESS RATING</span>
                  <span className="font-bold text-[#C96532]">{activeGrade.hardness}</span>
                </div>
                <div className="bg-[#151819] p-3 border border-[#25292B]">
                  <span className="text-[10px] text-[#A8AFB1] block">MACHINABILITY</span>
                  <span className="font-bold text-[#E8E9E6]">{activeGrade.machinability}</span>
                </div>
              </div>

              {/* Applications & Metallurgical notes */}
              <div className="space-y-2 text-xs">
                <p className="text-[11px] font-mono uppercase text-[#A8AFB1]">COMMON APPLICATIONS:</p>
                <p className="text-[#E8E9E6] font-mono bg-[#151819] p-3 border border-[#25292B] leading-relaxed">
                  {activeGrade.applications}
                </p>
              </div>

              <div className="border-t border-[#25292B] pt-4">
                <a
                  href="#rfq"
                  className="w-full inline-flex items-center justify-center py-2.5 px-4 text-xs font-mono font-semibold uppercase tracking-wider text-[#151819] bg-[#E8E9E6] hover:bg-white transition-colors"
                >
                  SPECIFY {activeGrade.grade.split(' ')[0]} FOR QUOTE
                </a>
              </div>
            </div>
          )}

        </div>

      </div>
    </section>
  );
}
