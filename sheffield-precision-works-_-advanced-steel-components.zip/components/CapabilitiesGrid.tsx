/* eslint-disable @next/next/no-img-element */
'use client';

import React, { useState } from 'react';
import { ArrowRight, Cpu, Layers, Ruler, ShieldCheck, Cog } from 'lucide-react';

interface CapabilitiesGridProps {
  onSelectCapability: (capTitle: string) => void;
}

export function CapabilitiesGrid({ onSelectCapability }: CapabilitiesGridProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'machining' | 'metrology' | 'alloys'>('all');

  const capabilities = [
    {
      id: 'cnc',
      category: 'machining',
      number: '01',
      title: '5-Axis Simultaneous CNC Machining',
      tagline: 'High-rigidity machining centres for complex monolithic aerospace and power generation components.',
      specs: ['Up to Ø1,200 mm turning', 'X: 1,600 mm, Y: 1,400 mm, Z: 1,000 mm', 'High-pressure 80-bar through-spindle coolant', 'Hermle C42 & DMG Mori NTX cells'],
      image: '/images/sheff_cnc_5axis_machining_1790414159406.jpg',
      large: true,
      tolerance: '±0.005 mm',
    },
    {
      id: 'metrology',
      category: 'metrology',
      number: '02',
      title: 'Automated UKAS Metrology & CMM Inspection',
      tagline: 'Zeiss coordinate measuring machines operating within a 20.0°C ±0.2°C cleanroom metrology environment.',
      specs: ['Continuous laser scanning probe', 'Optical 3D coordinate scanning', 'Sub-micron volumetric accuracy (0.9 + L/350 µm)', 'Digital AS9102 FAIR reports'],
      image: '/images/sheff_cmm_inspection_1790414177557.jpg',
      large: false,
      tolerance: '±0.001 mm',
    },
    {
      id: 'components',
      category: 'machining',
      number: '03',
      title: 'Precision Shafts, Helical Gears & Flanges',
      tagline: 'High-integrity turned components, splined shafts, and gear teeth ground to AGMA Class 14 specifications.',
      specs: ['Sub-micron cylindrical grinding', 'Internal & external spline hobbing', 'Dynamic balance to ISO 1940 G1.0', 'Mirror micro-finishing (Ra 0.08 µm)'],
      image: '/images/sheff_precision_shafts_gears_1790414142466.jpg',
      large: false,
      tolerance: '±0.002 mm',
    },
    {
      id: 'metallurgy',
      category: 'alloys',
      number: '04',
      title: 'Specialized Metallurgy & Vacuum Heat Treatment',
      tagline: 'Controlled thermal cycles, cryogenic stabilization, and Nadcap-approved induction hardening.',
      specs: ['Vacuum furnace up to 1,350°C', 'Liquid nitrogen deep cryo (-196°C)', 'Complete melt batch traceability (BS EN 10204 3.1)', 'Hardness testing (Vickers, Rockwell, Brinell)'],
      image: null,
      large: true,
      tolerance: 'Nadcap Approved',
    },
  ];

  const filtered = activeTab === 'all' 
    ? capabilities 
    : capabilities.filter(c => c.category === activeTab);

  return (
    <section id="capabilities" className="py-24 bg-[#151819] border-b border-[#25292B]">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-14">
          <div className="space-y-3 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="w-5 h-[1.5px] bg-[#C96532]" />
              <p className="text-xs uppercase tracking-[0.25em] font-mono text-[#A8AFB1]">
                CORE ENGINEERING CAPABILITIES
              </p>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#E8E9E6] uppercase">
              ADVANCED MANUFACTURING INFRASTRUCTURE
            </h2>
            <p className="text-[#A8AFB1] text-base leading-relaxed">
              Equipped with late-2020s Industry 4.0 automation, multi-axis machining cells, and 
              in-situ robotic inspection directly in Sheffield’s Don Valley industrial corridor.
            </p>
          </div>

          {/* Interactive Filter Tabs */}
          <div className="flex items-center gap-1 p-1 bg-[#25292B] border border-[#25292B] shrink-0">
            {[
              { id: 'all', label: 'All Capabilities' },
              { id: 'machining', label: 'CNC Machining' },
              { id: 'metrology', label: 'Metrology & CMM' },
              { id: 'alloys', label: 'Metallurgy' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-1.5 text-xs font-mono uppercase tracking-wider transition-colors ${
                  activeTab === tab.id
                    ? 'bg-[#E8E9E6] text-[#151819] font-bold shadow-sm'
                    : 'text-[#A8AFB1] hover:text-[#E8E9E6]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Asymmetric Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
          {filtered.map((item) => {
            const colSpan = item.large ? 'lg:col-span-7' : 'lg:col-span-5';

            return (
              <div
                key={item.id}
                className={`${colSpan} group bg-[#25292B]/30 hover:bg-[#25292B]/60 transition-all border border-[#25292B] hover:border-[#536873] flex flex-col justify-between overflow-hidden`}
              >
                {/* Image Section (if present) */}
                {item.image && (
                  <div className="relative h-64 sm:h-72 w-full overflow-hidden bg-[#151819]">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 filter brightness-[0.9] contrast-[1.05]"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#151819] via-[#151819]/20 to-transparent" />
                    
                    {/* Top right specification badge */}
                    <div className="absolute top-4 right-4 bg-[#151819]/90 backdrop-blur-sm border border-[#25292B] px-3 py-1 text-xs font-mono text-[#E8E9E6] tabular-nums">
                      CAL: <span className="text-[#C96532] font-semibold">{item.tolerance}</span>
                    </div>

                    {/* Bottom left editorial number */}
                    <div className="absolute bottom-4 left-4 text-xs font-mono uppercase tracking-widest text-[#E8E9E6] flex items-center gap-2">
                      <span className="text-[#C96532] font-bold">{item.number}.</span>
                      <span className="text-[#A8AFB1]">CAPABILITY CELL</span>
                    </div>
                  </div>
                )}

                {/* If no image, custom architectural metallurgy card */}
                {!item.image && (
                  <div className="p-8 bg-gradient-to-br from-[#25292B] to-[#151819] border-b border-[#25292B] relative">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-xs font-mono text-[#C96532] font-bold">
                        {item.number}. SPECIALIZED METALLURGY
                      </span>
                      <span className="text-xs font-mono text-[#E8E9E6] bg-[#151819] px-3 py-1 border border-[#25292B]">
                        {item.tolerance}
                      </span>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs font-mono uppercase tracking-wider text-[#A8AFB1]">
                        Thermal Cycle Control
                      </p>
                      <p className="text-2xl font-bold font-mono text-[#E8E9E6]">
                        1,350°C Vacuum · -196°C Cryo
                      </p>
                    </div>
                  </div>
                )}

                {/* Content Details */}
                <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between space-y-6">
                  <div className="space-y-3">
                    <h3 className="text-xl sm:text-2xl font-bold text-[#E8E9E6]">
                      {item.title}
                    </h3>
                    <p className="text-sm text-[#A8AFB1] leading-relaxed">
                      {item.tagline}
                    </p>
                  </div>

                  {/* Bulleted Specs */}
                  <div className="space-y-2 border-t border-[#25292B] pt-4">
                    <p className="text-[11px] font-mono uppercase tracking-wider text-[#536873]">
                      CELL PARAMETERS:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono text-[#E8E9E6]">
                      {item.specs.map((spec, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <span className="w-1 h-1 bg-[#C96532] shrink-0" />
                          <span className="truncate">{spec}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Action Link */}
                  <div className="pt-2">
                    <button
                      onClick={() => onSelectCapability(item.title)}
                      className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-[#E8E9E6] hover:text-[#C96532] transition-colors group/btn"
                    >
                      <span>SPECIFY THIS CELL IN RFQ</span>
                      <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
