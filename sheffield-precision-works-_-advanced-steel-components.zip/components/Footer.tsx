'use client';

import React from 'react';
import Link from 'next/link';
import { ArrowUp, MapPin, Mail, Phone, ShieldCheck } from 'lucide-react';

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#151819] text-[#A8AFB1] border-t border-[#25292B] pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Top Tier */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-[#25292B]">
          
          {/* Brand Info */}
          <div className="lg:col-span-5 space-y-4">
            <Link
              href="/"
              className="text-base font-semibold tracking-wider text-[#E8E9E6] uppercase"
            >
              SHEFFIELD PRECISION WORKS
            </Link>
            <p className="text-xs font-mono text-[#C96532] uppercase tracking-widest">
              PRECISION IN STEEL. ENGINEERED IN SHEFFIELD.
            </p>
            <p className="text-xs text-[#A8AFB1] max-w-sm leading-relaxed">
              World-class precision engineering, 5-axis CNC machining, and UKAS coordinate metrology. 
              Engineering critical components for aerospace, defence, rail, and nuclear infrastructure.
            </p>
            <div className="pt-2 text-xs font-mono text-[#536873] space-y-1">
              <p>Registered in England & Wales: No. 04819201</p>
              <p>VAT ID: GB 719 3201 84</p>
            </div>
          </div>

          {/* Quick Navigation */}
          <div className="lg:col-span-2 space-y-3">
            <p className="text-xs font-mono uppercase tracking-wider text-[#E8E9E6] font-semibold">
              NAVIGATION
            </p>
            <ul className="space-y-2 text-xs font-mono">
              <li><a href="#capabilities" className="hover:text-[#E8E9E6] transition-colors">Capabilities</a></li>
              <li><a href="#transformation" className="hover:text-[#E8E9E6] transition-colors">Production Flow</a></li>
              <li><a href="#sectors" className="hover:text-[#E8E9E6] transition-colors">Target Sectors</a></li>
              <li><a href="#materials" className="hover:text-[#E8E9E6] transition-colors">Steel Alloys</a></li>
              <li><a href="#heritage" className="hover:text-[#E8E9E6] transition-colors">Sheffield Heritage</a></li>
              <li><a href="#rfq" className="hover:text-[#E8E9E6] transition-colors">Submit RFQ</a></li>
            </ul>
          </div>

          {/* Plant & Works Location */}
          <div className="lg:col-span-3 space-y-3">
            <p className="text-xs font-mono uppercase tracking-wider text-[#E8E9E6] font-semibold">
              MANUFACTURING WORKS
            </p>
            <div className="space-y-2 text-xs font-mono">
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#C96532] shrink-0 mt-0.5" />
                <span>
                  Don Valley Advanced Manufacturing Park<br />
                  Europa Way, Sheffield, S9 2RX<br />
                  United Kingdom
                </span>
              </div>
              <div className="flex items-center gap-2 pt-1">
                <Phone className="w-3.5 h-3.5 text-[#C96532] shrink-0" />
                <span>+44 (0) 114 288 9400</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#C96532] shrink-0" />
                <span>enquiries@sheffieldprecisionworks.co.uk</span>
              </div>
            </div>
          </div>

          {/* Quality Standards Certifications */}
          <div className="lg:col-span-2 space-y-3">
            <p className="text-xs font-mono uppercase tracking-wider text-[#E8E9E6] font-semibold">
              ACCREDITATIONS
            </p>
            <div className="space-y-2 text-xs font-mono text-[#E8E9E6]">
              <div className="p-2 bg-[#25292B] border border-[#25292B]">
                <span className="block font-bold">AS9100D / ISO 9001</span>
                <span className="text-[10px] text-[#536873]">Aerospace Certified</span>
              </div>
              <div className="p-2 bg-[#25292B] border border-[#25292B]">
                <span className="block font-bold">UKAS LAB 0418</span>
                <span className="text-[10px] text-[#536873]">ISO/IEC 17025 Metrology</span>
              </div>
              <div className="p-2 bg-[#25292B] border border-[#25292B]">
                <span className="block font-bold">MADE IN SHEFFIELD</span>
                <span className="text-[10px] text-[#536873]">Mark License #1882</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Tier: Copyright & Back to Top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono">
          <p className="text-[#536873]">
            &copy; {new Date().getFullYear()} Sheffield Precision Works Ltd. All rights reserved. 
            Precision in Steel. Engineered in Sheffield.
          </p>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 text-[#A8AFB1] hover:text-[#E8E9E6] transition-colors"
          >
            <span>RETURN TO TOP</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
}
