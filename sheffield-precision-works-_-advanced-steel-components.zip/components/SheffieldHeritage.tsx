'use client';

import React from 'react';
import { ShieldCheck, Award, Factory, Compass } from 'lucide-react';

export function SheffieldHeritage() {
  const milestones = [
    {
      year: '1856',
      title: 'The Crucible & Bessemer Revolution',
      location: 'River Don & Attercliffe Basin',
      description: 'Sir Henry Bessemer establishes the Bessemer Steel Works in Sheffield, pioneering mass-produced decarbonized steel and transforming the Upper Don Valley into the metallurgical capital of the globe.',
    },
    {
      year: '1913',
      title: 'Invention of Rustless Stainless Steel',
      location: 'Brown Firth Research Laboratories, Sheffield',
      description: 'Harry Brearley creates the first rustless martensitic stainless chromium alloy in Sheffield, revolutionizing worldwide precision cutting, naval armaments, and engineering components.',
    },
    {
      year: '1970',
      title: 'Precision Aerospace Forging & Nuclear Rings',
      location: 'Don Valley Industrial Works',
      description: 'Sheffield engineers develop vacuum induction melting and heavy hydraulic forging for Rolls-Royce Olympus jet engines and British high-speed rail locomotive axle sets.',
    },
    {
      year: '2026+',
      title: 'Industry 4.0 Sheffield Precision Works',
      location: 'Advanced Manufacturing Park, Sheffield, UK',
      description: 'Automated 5-axis CNC machining, autonomous robotic handling cells, and micron-level CMM laser metrology. Sheffield steel heritage engineered for 21st-century aerospace and defence.',
    },
  ];

  return (
    <section id="heritage" className="py-24 bg-[#151819] border-b border-[#25292B]">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="space-y-3 max-w-3xl mb-16">
          <div className="flex items-center gap-2">
            <span className="w-5 h-[1.5px] bg-[#C96532]" />
            <p className="text-xs uppercase tracking-[0.25em] font-mono text-[#A8AFB1]">
              INDUSTRIAL ARCHITECTURE & CONTINUITY
            </p>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#E8E9E6] uppercase">
            SHEFFIELD STEEL HERITAGE TRANSFORMED
          </h2>
          <p className="text-[#A8AFB1] text-base leading-relaxed">
            The Don Valley has forged the backbone of global industry for over 170 years. 
            We do not look back with nostalgic sentimentality — we carry Sheffield’s mastery of 
            steel forward into autonomous 5-axis multi-tasking cells and micron metrology.
          </p>
        </div>

        {/* Timeline Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {milestones.map((m, idx) => (
            <div
              key={m.year}
              className="bg-[#25292B]/30 border border-[#25292B] p-6 sm:p-8 flex flex-col justify-between hover:border-[#536873] transition-colors"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-2xl font-bold font-mono text-[#E8E9E6]">
                    {m.year}
                  </span>
                  <span className="text-[10px] font-mono text-[#C96532] uppercase tracking-wider">
                    CHRONOLOGY 0{idx + 1}
                  </span>
                </div>
                <h3 className="text-base font-bold text-[#E8E9E6] mb-1">
                  {m.title}
                </h3>
                <p className="text-[11px] font-mono text-[#536873] mb-4 uppercase">
                  {m.location}
                </p>
                <p className="text-xs text-[#A8AFB1] leading-relaxed">
                  {m.description}
                </p>
              </div>

              <div className="pt-6 mt-6 border-t border-[#25292B]">
                <span className="text-[10px] font-mono text-[#536873] uppercase tracking-widest">
                  SHEFFIELD METALLURGICAL RECORD
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Industrial Credibility Stats Bar */}
        <div className="bg-[#25292B]/50 border border-[#25292B] p-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="space-y-1">
              <p className="text-3xl sm:text-4xl font-bold font-mono text-[#E8E9E6] tabular-nums">170+</p>
              <p className="text-xs uppercase tracking-wider text-[#A8AFB1]">Years of Sheffield Steel Roots</p>
            </div>
            <div className="space-y-1">
              <p className="text-3xl sm:text-4xl font-bold font-mono text-[#E8E9E6] tabular-nums">100%</p>
              <p className="text-xs uppercase tracking-wider text-[#A8AFB1]">UK Melt Origin Verified</p>
            </div>
            <div className="space-y-1">
              <p className="text-3xl sm:text-4xl font-bold font-mono text-[#E8E9E6] tabular-nums">12,000</p>
              <p className="text-xs uppercase tracking-wider text-[#A8AFB1]">m² High-Rigidity Production Floor</p>
            </div>
            <div className="space-y-1">
              <p className="text-3xl sm:text-4xl font-bold font-mono text-[#C96532] tabular-nums">0.000%</p>
              <p className="text-xs uppercase tracking-wider text-[#A8AFB1]">Zero Tolerance Deviation</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
