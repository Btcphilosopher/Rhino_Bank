'use client';

import React, { useState } from 'react';
import { Sliders, FileText, CheckCircle2, ArrowRight, ShieldCheck, UploadCloud, Clock, Cpu } from 'lucide-react';

interface EngineeringRFQProps {
  initialCapability?: string;
}

export function EngineeringRFQ({ initialCapability }: EngineeringRFQProps) {
  const [componentType, setComponentType] = useState('Flange');
  const [alloyGrade, setAlloyGrade] = useState('316L Stainless');
  const [toleranceClass, setToleranceClass] = useState('aerospace');
  const [batchQuantity, setBatchQuantity] = useState(25);
  const [surfaceFinish, setSurfaceFinish] = useState('0.4');
  const [cadFileUploaded, setCadFileUploaded] = useState(false);
  const [fileName, setFileName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Form details
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');

  const [refCode, setRefCode] = useState('SPW-2026-8491');

  const toleranceOptions = [
    { id: 'standard', name: 'Standard General (DIN ISO 2768-m)', tol: '±0.100 mm', leadTime: '10 Working Days' },
    { id: 'fine', name: 'Precision Engineering (DIN ISO 2768-f)', tol: '±0.025 mm', leadTime: '14 Working Days' },
    { id: 'aerospace', name: 'Aerospace Grade (AS9100D)', tol: '±0.005 mm', leadTime: '18 Working Days' },
    { id: 'submicron', name: 'Sub-Micron Critical Metrology', tol: '±0.002 mm', leadTime: '21 Working Days' },
  ];

  const currentTolerance = toleranceOptions.find(t => t.id === toleranceClass) || toleranceOptions[2];

  const handleSimulateUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFileName(e.target.files[0].name);
      setCadFileUploaded(true);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setRefCode(`SPW-2026-${Math.floor(1000 + Math.random() * 9000)}`);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 600);
  };

  return (
    <section id="rfq" className="py-24 bg-[#151819] border-b border-[#25292B]">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="space-y-3 max-w-3xl mb-14">
          <div className="flex items-center gap-2">
            <span className="w-5 h-[1.5px] bg-[#C96532]" />
            <p className="text-xs uppercase tracking-[0.25em] font-mono text-[#A8AFB1]">
              TECHNICAL DRAWING & RFQ
            </p>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#E8E9E6] uppercase">
            REQUEST MANUFACTURING SPECIFICATION
          </h2>
          <p className="text-[#A8AFB1] text-base leading-relaxed">
            Submit 3D CAD models (.STEP, .IGES) or 2D drawings for rapid metallurgical feasibility review 
            by Sheffield precision manufacturing engineers. Complete with AS9102 FAIR documentation options.
          </p>
        </div>

        {isSubmitted ? (
          <div className="bg-[#25292B]/60 border border-emerald-500/40 p-8 sm:p-12 text-center max-w-2xl mx-auto space-y-6">
            <div className="w-16 h-16 bg-emerald-500/10 border border-emerald-500/40 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8 text-emerald-400" />
            </div>
            <div>
              <span className="text-xs font-mono uppercase text-[#A8AFB1]">RFQ SUBMISSION LOGGED</span>
              <h3 className="text-2xl font-bold text-[#E8E9E6] mt-1">
                Specification Queued with Sheffield Engineering
              </h3>
              <p className="text-xs font-mono text-[#C96532] mt-2">
                REFERENCE CODE: {refCode}
              </p>
            </div>
            <p className="text-sm text-[#A8AFB1] leading-relaxed">
              Thank you, <span className="text-[#E8E9E6] font-semibold">{name || 'Engineer'}</span>. 
              Our senior production metallurgist at the Don Valley Advanced Manufacturing Works 
              will review your {alloyGrade} {componentType} specification and deliver a formal quotation 
              within 4 business hours.
            </p>
            <div className="bg-[#151819] p-4 border border-[#25292B] text-left text-xs font-mono space-y-2 max-w-md mx-auto">
              <div className="flex justify-between text-[#A8AFB1]">
                <span>Component:</span>
                <span className="text-[#E8E9E6] font-bold">{componentType}</span>
              </div>
              <div className="flex justify-between text-[#A8AFB1]">
                <span>Material:</span>
                <span className="text-[#E8E9E6]">{alloyGrade}</span>
              </div>
              <div className="flex justify-between text-[#A8AFB1]">
                <span>Tolerance Target:</span>
                <span className="text-[#C96532]">{currentTolerance.tol}</span>
              </div>
              <div className="flex justify-between text-[#A8AFB1]">
                <span>Batch Quantity:</span>
                <span className="text-[#E8E9E6]">{batchQuantity} units</span>
              </div>
            </div>
            <button
              onClick={() => setIsSubmitted(false)}
              className="px-6 py-2.5 text-xs font-mono uppercase tracking-wider text-[#151819] bg-[#E8E9E6] hover:bg-white font-semibold transition-colors"
            >
              Configure Another RFQ
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            
            {/* Left 7 Cols: Interactive Technical Configurator */}
            <div className="lg:col-span-7 bg-[#25292B]/30 border border-[#25292B] p-6 sm:p-8 space-y-8">
              
              {/* Component Geometry Type */}
              <div className="space-y-3">
                <label className="text-xs font-mono uppercase tracking-wider text-[#E8E9E6] block">
                  01. Component Geometry Classification
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    'Precision Flange',
                    'Turned Shaft',
                    '5-Axis Housing',
                    'Helical Gear',
                    'Valve Body',
                    'Custom Monolith',
                  ].map((type) => (
                    <button
                      type="button"
                      key={type}
                      onClick={() => setComponentType(type)}
                      className={`p-3 text-left text-xs font-mono transition-all border ${
                        componentType === type
                          ? 'bg-[#E8E9E6] text-[#151819] font-bold border-[#E8E9E6]'
                          : 'bg-[#151819] text-[#A8AFB1] border-[#25292B] hover:text-[#E8E9E6] hover:border-[#536873]'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Alloy Material Selection */}
              <div className="space-y-3">
                <label className="text-xs font-mono uppercase tracking-wider text-[#E8E9E6] block">
                  02. Sheffield Certified Steel & Alloy Grade
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    '316L Stainless',
                    '17-4PH Hardened',
                    'Inconel 718',
                    'EN24T High Tensile',
                    'Maraging 300',
                    'Sheffield D2 Tool',
                  ].map((grade) => (
                    <button
                      type="button"
                      key={grade}
                      onClick={() => setAlloyGrade(grade)}
                      className={`p-3 text-left text-xs font-mono transition-all border ${
                        alloyGrade === grade
                          ? 'bg-[#E8E9E6] text-[#151819] font-bold border-[#E8E9E6]'
                          : 'bg-[#151819] text-[#A8AFB1] border-[#25292B] hover:text-[#E8E9E6] hover:border-[#536873]'
                      }`}
                    >
                      {grade}
                    </button>
                  ))}
                </div>
              </div>

              {/* Tolerance Class */}
              <div className="space-y-3">
                <label className="text-xs font-mono uppercase tracking-wider text-[#E8E9E6] block">
                  03. Dimensional Tolerance & Inspection Class
                </label>
                <div className="space-y-2">
                  {toleranceOptions.map((opt) => (
                    <button
                      type="button"
                      key={opt.id}
                      onClick={() => setToleranceClass(opt.id)}
                      className={`w-full p-3.5 text-left text-xs font-mono transition-all border flex items-center justify-between ${
                        toleranceClass === opt.id
                          ? 'bg-[#25292B] border-[#E8E9E6] text-[#E8E9E6]'
                          : 'bg-[#151819] border-[#25292B] text-[#A8AFB1] hover:border-[#536873]'
                      }`}
                    >
                      <div>
                        <span className="font-semibold block">{opt.name}</span>
                        <span className="text-[11px] text-[#536873]">Est. Production: {opt.leadTime}</span>
                      </div>
                      <span className="text-[#C96532] font-bold tabular-nums text-sm">
                        {opt.tol}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Batch Quantity Slider */}
              <div className="space-y-3">
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="uppercase text-[#E8E9E6]">04. Production Batch Quantity</span>
                  <span className="font-bold text-[#E8E9E6] tabular-nums bg-[#151819] px-3 py-1 border border-[#25292B]">
                    {batchQuantity} UNITS
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="500"
                  value={batchQuantity}
                  onChange={(e) => setBatchQuantity(Number(e.target.value))}
                  className="w-full h-1.5 bg-[#25292B] appearance-none cursor-pointer accent-[#C96532]"
                />
                <div className="flex justify-between text-[10px] font-mono text-[#536873]">
                  <span>1 (Prototype)</span>
                  <span>50 (Pilot Batch)</span>
                  <span>500+ (Volume Supply)</span>
                </div>
              </div>

              {/* Surface Finish Roughness */}
              <div className="space-y-3">
                <label className="text-xs font-mono uppercase tracking-wider text-[#E8E9E6] block">
                  05. Required Surface Roughness (Ra)
                </label>
                <div className="grid grid-cols-4 gap-2 text-xs font-mono text-center">
                  {[
                    { id: '1.6', label: 'Ra 1.6 µm', desc: 'Milled' },
                    { id: '0.8', label: 'Ra 0.8 µm', desc: 'Fine Turned' },
                    { id: '0.4', label: 'Ra 0.4 µm', desc: 'Ground' },
                    { id: '0.1', label: 'Ra 0.1 µm', desc: 'Mirror Lapped' },
                  ].map((rf) => (
                    <button
                      type="button"
                      key={rf.id}
                      onClick={() => setSurfaceFinish(rf.id)}
                      className={`p-2.5 border transition-all ${
                        surfaceFinish === rf.id
                          ? 'bg-[#E8E9E6] text-[#151819] font-bold border-[#E8E9E6]'
                          : 'bg-[#151819] text-[#A8AFB1] border-[#25292B] hover:text-[#E8E9E6]'
                      }`}
                    >
                      <span className="block font-bold">{rf.label}</span>
                      <span className="text-[10px] text-[#536873]">{rf.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* CAD Upload Slot */}
              <div className="border border-dashed border-[#536873] p-6 text-center bg-[#151819]">
                <UploadCloud className="w-8 h-8 text-[#C96532] mx-auto mb-2" />
                <p className="text-xs font-mono text-[#E8E9E6] font-semibold">
                  ATTACH 3D CAD MODEL OR 2D PDF DRAWING
                </p>
                <p className="text-[11px] font-mono text-[#A8AFB1] mt-1">
                  Supported formats: .STEP, .STP, .IGES, .SLDPRT, .DWG, .PDF (Max 50MB)
                </p>
                <label className="mt-4 inline-block px-4 py-2 bg-[#25292B] text-xs font-mono uppercase tracking-wider text-[#E8E9E6] hover:bg-[#536873] cursor-pointer transition-colors border border-[#536873]">
                  <span>{cadFileUploaded ? `Selected: ${fileName}` : 'Browse Files'}</span>
                  <input
                    type="file"
                    className="hidden"
                    onChange={handleSimulateUpload}
                  />
                </label>
              </div>

            </div>

            {/* Right 5 Cols: Contact Details & Live Manufacturing Estimation */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Live Spec Summary Card */}
              <div className="bg-[#25292B]/50 border border-[#25292B] p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-[#25292B] pb-3">
                  <span className="text-xs font-mono uppercase text-[#A8AFB1]">MANUFACTURING PROFILE</span>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/40 px-2 py-0.5 border border-emerald-800">
                    CAPACITY READY
                  </span>
                </div>
                
                <div className="space-y-2 text-xs font-mono">
                  <div className="flex justify-between">
                    <span className="text-[#A8AFB1]">Component:</span>
                    <span className="text-[#E8E9E6] font-bold">{componentType}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#A8AFB1]">Material Alloy:</span>
                    <span className="text-[#E8E9E6]">{alloyGrade}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#A8AFB1]">Tolerance:</span>
                    <span className="text-[#C96532] font-bold">{currentTolerance.tol}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#A8AFB1]">Surface Roughness:</span>
                    <span className="text-[#E8E9E6]">Ra {surfaceFinish} µm</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#A8AFB1]">Batch Size:</span>
                    <span className="text-[#E8E9E6]">{batchQuantity} parts</span>
                  </div>
                  <div className="flex justify-between border-t border-[#25292B] pt-2">
                    <span className="text-[#A8AFB1]">Est. Production Window:</span>
                    <span className="text-[#E8E9E6] font-semibold">{currentTolerance.leadTime}</span>
                  </div>
                </div>

                <div className="pt-2 text-[11px] font-mono text-[#536873] border-t border-[#25292B]">
                  Includes full UKAS 3D CMM inspection report & BS EN 10204 3.1 material certificate.
                </div>
              </div>

              {/* Contact Information Fields */}
              <div className="bg-[#25292B]/30 border border-[#25292B] p-6 space-y-4">
                <span className="text-xs font-mono uppercase text-[#E8E9E6] font-semibold block">
                  CONTACT & DISPATCH DETAILS
                </span>

                <div className="space-y-3 text-xs font-mono">
                  <div>
                    <label className="text-[11px] text-[#A8AFB1] block mb-1">Full Name / Lead Engineer *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Dr. Thomas Vance"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3 py-2 bg-[#151819] border border-[#25292B] text-[#E8E9E6] focus:outline-none focus:border-[#C96532]"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-[#A8AFB1] block mb-1">Corporate Email Address *</label>
                    <input
                      type="email"
                      required
                      placeholder="t.vance@aerospace-systems.co.uk"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3 py-2 bg-[#151819] border border-[#25292B] text-[#E8E9E6] focus:outline-none focus:border-[#C96532]"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] text-[#A8AFB1] block mb-1">Company / Organization *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. BAE Systems / Rolls-Royce"
                        value={company}
                        onChange={(e) => setCompany(e.target.value)}
                        className="w-full px-3 py-2 bg-[#151819] border border-[#25292B] text-[#E8E9E6] focus:outline-none focus:border-[#C96532]"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-[#A8AFB1] block mb-1">Contact Phone</label>
                      <input
                        type="tel"
                        placeholder="+44 (0) 114 ..."
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full px-3 py-2 bg-[#151819] border border-[#25292B] text-[#E8E9E6] focus:outline-none focus:border-[#C96532]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] text-[#A8AFB1] block mb-1">Technical Notes / Special Requirements</label>
                    <textarea
                      rows={3}
                      placeholder="Special heat treatment, cryogenic cycling, or defence compliance notes..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="w-full px-3 py-2 bg-[#151819] border border-[#25292B] text-[#E8E9E6] focus:outline-none focus:border-[#C96532]"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 px-4 text-xs font-semibold uppercase tracking-wider text-[#151819] bg-[#E8E9E6] hover:bg-white active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <span>PROCESSING FEASIBILITY...</span>
                  ) : (
                    <>
                      <span>SUBMIT SPECIFICATION FOR QUOTE</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>

                <p className="text-[10px] font-mono text-[#536873] text-center">
                  Protected by mutual non-disclosure agreement (NDA). ITAR / UK MoD compliant.
                </p>
              </div>

            </div>

          </form>
        )}

      </div>
    </section>
  );
}
