/* eslint-disable @next/next/no-img-element */
'use client';

import React, { useState } from 'react';
import { ArrowRight, Crosshair, ShieldCheck, Activity, Sliders, CheckCircle2 } from 'lucide-react';

interface HeroProps {
  onExploreCapabilities: () => void;
  onOpenRFQ: () => void;
}

export function Hero({ onExploreCapabilities, onOpenRFQ }: HeroProps) {
  const [telemetryActive, setTelemetryActive] = useState(true);
  const [activeStage, setActiveStage] = useState<'raw' | 'machined' | 'inspected'>('machined');

  const stageData = {
    raw: {
      label: 'Stage 01: Raw Forged Billet',
      sub: 'Vacuum Arc Remelted (VAR) 316L Sheffield steel ingot with certified micro-cleanliness',
      spec: 'ASTM A276 / EN 10088-3',
      hardness: '165 HB',
      roughness: 'Ra 6.3 µm',
      density: '7.99 g/cm³',
    },
    machined: {
      label: 'Stage 02: 5-Axis Precision Machined',
      sub: 'High-rigidity multi-axis turning & milling with high-pressure coolant micro-chamfering',
      spec: 'AS9100D Aerospace Certified',
      hardness: 'Cryo-Treated 32 HRC',
      roughness: 'Ra 0.28 µm',
      density: 'Tolerance ±0.005 mm',
    },
    inspected: {
      label: 'Stage 03: Automated UKAS CMM Metrology',
      sub: 'Laser interferometry and ruby stylus coordinate measurement in 20.0°C controlled lab',
      spec: 'UKAS Lab Accr. 0418',
      hardness: '100% Eddy Current Passed',
      roughness: 'Laser Holography Validated',
      density: 'Zero Critical Deviations',
    },
  };

  return (
    <section className="relative min-h-[92vh] lg:min-h-screen flex flex-col justify-between pt-28 pb-12 overflow-hidden bg-[#151819] border-b border-[#25292B]">
      {/* Background Image Container with Measured Contrast Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src="/images/sheff_hero_precision_works_1790414109797.jpg"
          alt="Sheffield Precision Works advanced Industry 4.0 manufacturing works"
          className="w-full h-full object-cover object-right md:object-center filter brightness-[0.92] contrast-[1.05]"
          referrerPolicy="no-referrer"
        />
        {/* Cinematic Scrim: deep black architecture gradient on the left, subtle bottom fade */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#151819] via-[#151819]/80 to-transparent lg:w-[65%]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#151819] via-transparent to-[#151819]/40" />
        {/* Subtle grid pattern overlay */}
        <div
          className="absolute inset-0 opacity-[0.03] pointer-events-none"
          style={{
            backgroundImage: `linear-gradient(#E8E9E6 1px, transparent 1px), linear-gradient(90deg, #E8E9E6 1px, transparent 1px)`,
            backgroundSize: '40px 40px',
          }}
        />
      </div>

      {/* Main Hero Content Frame */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 w-full my-auto py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Negative space for Website Headline */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Tagline / Subtitle kicker */}
            <div className="flex items-center gap-3">
              <span className="w-6 h-[1.5px] bg-[#C96532]" />
              <p className="text-xs uppercase tracking-[0.25em] font-mono text-[#A8AFB1]">
                PRECISION IN STEEL. ENGINEERED IN SHEFFIELD.
              </p>
            </div>

            {/* Main Dominant Headline */}
            <div className="space-y-2">
              <h1 className="text-4xl sm:text-5xl md:text-6xl xl:text-7xl font-bold tracking-tight text-[#E8E9E6] uppercase leading-[1.05]">
                PRECISION <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#E8E9E6] via-[#A8AFB1] to-[#536873]">
                  IN STEEL.
                </span>
              </h1>
              
              <div className="pt-2">
                <span className="inline-block text-xs uppercase tracking-[0.2em] font-mono text-[#A8AFB1] bg-[#25292B]/80 px-3 py-1.5 border-l-2 border-[#C96532]">
                  ADVANCED MANUFACTURING / SHEFFIELD / UNITED KINGDOM
                </span>
              </div>
            </div>

            {/* Description */}
            <p className="text-[#A8AFB1] text-base md:text-lg max-w-xl leading-relaxed font-normal">
              Sheffield Precision Works transforms two centuries of British metallurgy into 
              Industry 4.0 aerospace, rail, and defence manufacturing. Sub-micron tolerances, 
              5-axis machining cells, and robotic inspection engineered for the world&apos;s most demanding environments.
            </p>

            {/* CTAs */}
            <div className="pt-4 flex flex-wrap items-center gap-4">
              <button
                onClick={onExploreCapabilities}
                className="inline-flex items-center gap-3 px-6 py-3.5 text-xs font-semibold uppercase tracking-wider text-[#151819] bg-[#E8E9E6] hover:bg-white active:scale-[0.98] transition-all shadow-md group"
              >
                <span>EXPLORE CAPABILITIES</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onOpenRFQ}
                className="inline-flex items-center gap-3 px-6 py-3.5 text-xs font-semibold uppercase tracking-wider text-[#E8E9E6] bg-[#25292B]/90 hover:bg-[#25292B] border border-[#536873]/60 hover:border-[#A8AFB1] transition-all"
              >
                <Sliders className="w-3.5 h-3.5 text-[#C96532]" />
                <span>SPECIFY DRAWING & RFQ</span>
              </button>
            </div>

            {/* Trust Markers Row */}
            <div className="pt-6 grid grid-cols-3 gap-6 border-t border-[#25292B]/90 max-w-lg">
              <div>
                <p className="text-xl md:text-2xl font-bold font-mono text-[#E8E9E6] tabular-nums">±0.002<span className="text-xs text-[#A8AFB1] ml-0.5">mm</span></p>
                <p className="text-[11px] uppercase tracking-wider text-[#A8AFB1] mt-0.5">Tolerance Limit</p>
              </div>
              <div>
                <p className="text-xl md:text-2xl font-bold font-mono text-[#E8E9E6] tabular-nums">AS9100D</p>
                <p className="text-[11px] uppercase tracking-wider text-[#A8AFB1] mt-0.5">Aerospace Standard</p>
              </div>
              <div>
                <p className="text-xl md:text-2xl font-bold font-mono text-[#E8E9E6] tabular-nums">24 / 7</p>
                <p className="text-[11px] uppercase tracking-wider text-[#A8AFB1] mt-0.5">Automated Cells</p>
              </div>
            </div>

          </div>

          {/* Right Column: Industry 4.0 Restrained Technical Overlays */}
          <div className="lg:col-span-5 relative">
            
            {/* Engineering Annotation Box directly highlighting the component in the scene */}
            <div className="relative backdrop-blur-md bg-[#151819]/85 border border-[#536873]/50 p-5 shadow-2xl space-y-4">
              
              {/* Header with Telemetry Switch */}
              <div className="flex items-center justify-between border-b border-[#25292B] pb-3">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#C96532] animate-pulse" />
                  <span className="text-xs font-mono font-semibold uppercase tracking-widest text-[#E8E9E6]">
                    INSPECTION TELEMETRY
                  </span>
                </div>
                <button
                  onClick={() => setTelemetryActive(!telemetryActive)}
                  className="text-[11px] font-mono text-[#A8AFB1] hover:text-white uppercase transition-colors"
                >
                  {telemetryActive ? '[LIVE ACTIVE]' : '[PAUSED]'}
                </button>
              </div>

              {/* Precise Restrained Technical Annotations as specified in the prompt */}
              <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                <div className="bg-[#25292B]/50 p-2.5 border border-[#25292B]">
                  <span className="text-[10px] text-[#A8AFB1] block">PART ID</span>
                  <span className="font-bold text-[#E8E9E6]">PART 04</span>
                </div>
                <div className="bg-[#25292B]/50 p-2.5 border border-[#25292B]">
                  <span className="text-[10px] text-[#A8AFB1] block">ALLOY GRADE</span>
                  <span className="font-bold text-[#E8E9E6]">316L AUSTENITIC</span>
                </div>
                <div className="bg-[#25292B]/50 p-2.5 border border-[#25292B]">
                  <span className="text-[10px] text-[#A8AFB1] block">NOMINAL BORE</span>
                  <span className="font-bold text-[#E8E9E6]">Ø120 MM</span>
                </div>
                <div className="bg-[#25292B]/50 p-2.5 border border-[#25292B]">
                  <span className="text-[10px] text-[#A8AFB1] block">CALIBRATION</span>
                  <span className="font-bold text-[#E8E9E6]">TOLERANCE ±0.02</span>
                </div>
              </div>

              {/* Status and Batch tags */}
              <div className="flex items-center justify-between text-xs font-mono pt-1">
                <div className="flex items-center gap-1.5 text-emerald-400 font-semibold tracking-wider">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>INSPECTION PASS</span>
                </div>
                <div className="text-[#A8AFB1]">
                  BATCH: <span className="text-[#E8E9E6] font-bold">26-091</span>
                </div>
              </div>

              {/* Live Sensor Feed */}
              {telemetryActive && (
                <div className="mt-3 pt-3 border-t border-[#25292B] space-y-2 text-[11px] font-mono">
                  <div className="flex justify-between text-[#A8AFB1]">
                    <span>CMM Stylus Contact:</span>
                    <span className="text-[#E8E9E6] tabular-nums">0.0018 mm dev</span>
                  </div>
                  <div className="flex justify-between text-[#A8AFB1]">
                    <span>Surface Roughness (Ra):</span>
                    <span className="text-[#E8E9E6] tabular-nums">0.24 µm (Spec &lt;0.40)</span>
                  </div>
                  <div className="flex justify-between text-[#A8AFB1]">
                    <span>Inspection Ambient Temp:</span>
                    <span className="text-[#E8E9E6] tabular-nums">20.0 °C calibrated</span>
                  </div>
                </div>
              )}
            </div>

            {/* Discrete Sheffield Hallmarking Stamp */}
            <div className="mt-4 flex items-center justify-end gap-2 text-[10px] font-mono uppercase tracking-widest text-[#536873]">
              <Crosshair className="w-3.5 h-3.5 text-[#C96532]" />
              <span>SHEFFIELD WORKS METROLOGY DIVISION // CELL 07</span>
            </div>

          </div>
        </div>
      </div>

      {/* Bottom Signature Visual Transition: RAW STEEL → MACHINED PART → INSPECTED COMPONENT */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 w-full pt-4">
        <div className="bg-[#151819]/90 border border-[#25292B] p-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            
            <div className="flex items-center gap-3">
              <span className="text-xs uppercase font-mono tracking-widest text-[#A8AFB1]">
                PRODUCTION TRANSITION:
              </span>
              <div className="flex items-center gap-1">
                {(['raw', 'machined', 'inspected'] as const).map((stage, idx) => (
                  <button
                    key={stage}
                    onClick={() => setActiveStage(stage)}
                    className={`px-3 py-1 text-xs font-mono uppercase transition-all flex items-center gap-1.5 ${
                      activeStage === stage
                        ? 'bg-[#E8E9E6] text-[#151819] font-bold'
                        : 'text-[#A8AFB1] hover:text-white bg-[#25292B]/60'
                    }`}
                  >
                    <span>0{idx + 1}.</span>
                    <span>{stage === 'raw' ? 'RAW STEEL' : stage === 'machined' ? 'MACHINED PART' : 'INSPECTED COMPONENT'}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Active Stage Quick Info */}
            <div className="text-xs font-mono text-[#A8AFB1] flex items-center gap-4">
              <span className="hidden sm:inline text-[#E8E9E6] font-medium">{stageData[activeStage].label}</span>
              <span className="hidden md:inline">·</span>
              <span className="text-[#C96532] font-semibold">{stageData[activeStage].hardness}</span>
              <span className="hidden lg:inline">·</span>
              <span className="hidden lg:inline">{stageData[activeStage].roughness}</span>
            </div>

          </div>
        </div>
      </div>

    </section>
  );
}
