import type {Metadata} from 'next';
import { Plus_Jakarta_Sans, JetBrains_Mono } from 'next/font/google';
import './globals.css';

const sans = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

const mono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Sheffield Precision Works — Precision in Steel. Engineered in Sheffield.',
  description: 'Precision in steel. Engineered in Sheffield. World-class precision CNC machining, forged aerospace alloys, and Industry 4.0 metrology from Sheffield, United Kingdom.',
  openGraph: {
    title: 'Sheffield Precision Works — Precision in Steel. Engineered in Sheffield.',
    description: 'Precision in steel. Engineered in Sheffield. World-class precision CNC machining, forged aerospace alloys, and Industry 4.0 metrology from Sheffield, United Kingdom.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Sheffield Precision Works — Precision in Steel. Engineered in Sheffield.',
    description: 'Precision in steel. Engineered in Sheffield. World-class precision CNC machining, forged aerospace alloys, and Industry 4.0 metrology from Sheffield, United Kingdom.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${sans.variable} ${mono.variable} scroll-smooth antialiased`}>
      <body className="bg-[#151819] text-[#E8E9E6] min-h-screen selection:bg-[#C96532] selection:text-white" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
