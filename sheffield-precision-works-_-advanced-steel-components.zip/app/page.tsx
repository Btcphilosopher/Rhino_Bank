'use client';

import React, { useRef, useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { SignatureTransformation } from '@/components/SignatureTransformation';
import { CapabilitiesGrid } from '@/components/CapabilitiesGrid';
import { SectorsMatrix } from '@/components/SectorsMatrix';
import { MaterialsExplorer } from '@/components/MaterialsExplorer';
import { SheffieldHeritage } from '@/components/SheffieldHeritage';
import { EngineeringRFQ } from '@/components/EngineeringRFQ';
import { Footer } from '@/components/Footer';

export default function Home() {
  const [selectedCapability, setSelectedCapability] = useState<string>('');

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectCapability = (capTitle: string) => {
    setSelectedCapability(capTitle);
    scrollToSection('rfq');
  };

  return (
    <main className="min-h-screen bg-[#151819] text-[#E8E9E6]">
      {/* Top 3-Zone Navigation */}
      <Navbar onOpenRFQ={() => scrollToSection('rfq')} />

      {/* Cinematic 16:9 Hero Section with Sheffield Works Machinery & Telemetry */}
      <Hero
        onExploreCapabilities={() => scrollToSection('capabilities')}
        onOpenRFQ={() => scrollToSection('rfq')}
      />

      {/* Signature Transition: Raw Steel -> Machined Part -> Inspected Component */}
      <SignatureTransformation />

      {/* Core Engineering Capabilities (5-Axis CNC, Metrology, Shafts & Gears) */}
      <CapabilitiesGrid onSelectCapability={handleSelectCapability} />

      {/* Critical Infrastructure & Sectors Matrix (Aerospace, Rail, Defence, Nuclear) */}
      <SectorsMatrix />

      {/* Interactive Sheffield Steel & Alloy Directory */}
      <MaterialsExplorer />

      {/* Sheffield Heritage to Industry 4.0 Continuum */}
      <SheffieldHeritage />

      {/* Technical Drawing & Engineering RFQ Estimator */}
      <EngineeringRFQ initialCapability={selectedCapability} />

      {/* Corporate Industrial Footer */}
      <Footer />
    </main>
  );
}
