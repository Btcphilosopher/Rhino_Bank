import { LightningInvoice, DigitalPassport } from '../types';

const SAT_TO_GBP = 0.00074; // Approx fiat exchange rate: ~£1 = 1,350 sats
const SAT_TO_USD = 0.00095;

export interface WalletState {
  satsBalance: number;
  lightningAddress: string;
  transactions: {
    id: string;
    type: 'TIP' | 'PURCHASE' | 'EARNING' | 'DEPOSIT';
    description: string;
    satsAmount: number;
    timestamp: string;
    txHash: string;
  }[];
  purchasedPassports: DigitalPassport[];
}

type WalletListener = (state: WalletState) => void;

class LightningService {
  private walletState: WalletState = {
    satsBalance: 125000, // Initial demo wallet
    lightningAddress: 'dj_pro@shefunderground.btc',
    transactions: [
      {
        id: 'tx-001',
        type: 'DEPOSIT',
        description: 'Initial Wallet Lightning Top-Up',
        satsAmount: 125000,
        timestamp: new Date().toISOString(),
        txHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
      }
    ],
    purchasedPassports: []
  };

  private listeners: Set<WalletListener> = new Set();

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const saved = localStorage.getItem('sheffield_wallet_state');
      if (saved) {
        this.walletState = JSON.parse(saved);
      }
    } catch {
      // fallback
    }
  }

  private saveToStorage() {
    try {
      localStorage.setItem('sheffield_wallet_state', JSON.stringify(this.walletState));
    } catch {
      // fallback
    }
    this.notify();
  }

  public subscribe(listener: WalletListener) {
    this.listeners.add(listener);
    listener(this.walletState);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach(fn => fn({ ...this.walletState }));
  }

  public satsToFiat(sats: number, currency: 'GBP' | 'USD' = 'GBP'): string {
    if (currency === 'GBP') {
      const gbp = sats * SAT_TO_GBP;
      return `£${gbp.toFixed(2)}`;
    } else {
      const usd = sats * SAT_TO_USD;
      return `$${usd.toFixed(2)}`;
    }
  }

  // Generate a valid-looking Lightning invoice
  public createInvoice(satsAmount: number, description: string): LightningInvoice {
    const randomHex = Array.from({ length: 16 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const invoiceId = `inv_${Date.now()}_${randomHex.substring(0, 6)}`;
    const paymentRequest = `lnbc${satsAmount}u1p${randomHex}00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000`;

    const invoice: LightningInvoice = {
      id: invoiceId,
      paymentRequest,
      satsAmount,
      fiatApprox: this.satsToFiat(satsAmount),
      description,
      expiresAt: Date.now() + 1000 * 60 * 10, // 10 minutes
      status: 'PENDING',
      createdAt: Date.now()
    };

    return invoice;
  }

  // Simulate instant Lightning settlement
  public payInvoiceWithWallet(invoice: LightningInvoice): boolean {
    if (this.walletState.satsBalance < invoice.satsAmount) {
      return false; // Insufficient funds
    }

    const txHash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;

    this.walletState.satsBalance -= invoice.satsAmount;
    this.walletState.transactions.unshift({
      id: `tx-${Date.now()}`,
      type: 'PURCHASE',
      description: invoice.description,
      satsAmount: invoice.satsAmount,
      timestamp: new Date().toISOString(),
      txHash
    });

    this.saveToStorage();
    return true;
  }

  public sendTip(artistName: string, satsAmount: number): boolean {
    if (this.walletState.satsBalance < satsAmount) return false;

    const txHash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;

    this.walletState.satsBalance -= satsAmount;
    this.walletState.transactions.unshift({
      id: `tip-${Date.now()}`,
      type: 'TIP',
      description: `⚡ Lightning Tip to ${artistName}`,
      satsAmount,
      timestamp: new Date().toISOString(),
      txHash
    });

    this.saveToStorage();
    return true;
  }

  public registerPurchasedPassport(trackId: string, trackTitle: string, artist: string, satsAmount: number): DigitalPassport {
    const randomHex = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const passport: DigitalPassport = {
      id: `pass-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      trackId,
      trackTitle,
      artist,
      purchaseDate: new Date().toISOString(),
      satsAmount,
      txHash: `0x${randomHex}`,
      signature: `SIG_LN_SHEFFIELD_${randomHex.toUpperCase()}`,
      licenseType: 'DJ Performance & Commercial Broadcast',
      format: 'WAV',
      downloadUrl: '#download-wav'
    };

    // Check if already in passport list
    if (!this.walletState.purchasedPassports.some(p => p.trackId === trackId)) {
      this.walletState.purchasedPassports.unshift(passport);
      this.saveToStorage();
    }

    return passport;
  }

  public hasPurchasedTrack(trackId: string): boolean {
    return this.walletState.purchasedPassports.some(p => p.trackId === trackId);
  }

  public depositSats(satsAmount: number) {
    const txHash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
    this.walletState.satsBalance += satsAmount;
    this.walletState.transactions.unshift({
      id: `dep-${Date.now()}`,
      type: 'DEPOSIT',
      description: 'Lightning Node Wallet Deposit',
      satsAmount,
      timestamp: new Date().toISOString(),
      txHash
    });
    this.saveToStorage();
  }

  public getWalletState(): WalletState {
    return { ...this.walletState };
  }
}

export const lightningService = new LightningService();
