import { Track } from '../types';

export interface AudioState {
  isPlaying: boolean;
  currentTrack: Track | null;
  currentTime: number;
  duration: number;
  volume: number; // 0 to 1
  isMuted: boolean;
  playbackRate: number; // 0.8 to 1.2
  isLooping: boolean;
  loopA: number | null;
  loopB: number | null;
  cuePoint: number | null;
}

type Listener = (state: AudioState) => void;

class AudioService {
  private ctx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private gainNode: GainNode | null = null;
  private activeSource: AudioBufferSourceNode | null = null;
  private timerId: number | null = null;

  private state: AudioState = {
    isPlaying: false,
    currentTrack: null,
    currentTime: 0,
    duration: 180,
    volume: 0.8,
    isMuted: false,
    playbackRate: 1.0,
    isLooping: false,
    loopA: null,
    loopB: null,
    cuePoint: null,
  };

  private listeners: Set<Listener> = new Set();

  constructor() {
    // Lazy init context on first user interaction
  }

  private initAudio() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.gainNode = this.ctx.createGain();
      this.gainNode.gain.value = this.state.isMuted ? 0 : this.state.volume;

      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 128;
      this.gainNode.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public subscribe(listener: Listener) {
    this.listeners.add(listener);
    listener(this.state);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((fn) => fn({ ...this.state }));
  }

  // Generate a realistic synthesis buffer for electronic audio based on BPM & preset
  private createElectronicSynthBuffer(track: Track): AudioBuffer {
    this.initAudio();
    const sampleRate = this.ctx!.sampleRate;
    const duration = Math.min(track.duration || 180, 180); // Cap demo buffer at 3 mins
    const buffer = this.ctx!.createBuffer(2, sampleRate * duration, sampleRate);
    const left = buffer.getChannelData(0);
    const right = buffer.getChannelData(1);

    const bpm = track.bpm || 128;
    const beatDuration = 60 / bpm;
    const subBeat = beatDuration / 4; // 16th note

    // Synthesize techno / house kick, bassline, and acid sweep into the buffer
    for (let i = 0; i < buffer.length; i++) {
      const t = i / sampleRate;
      const beatNum = Math.floor(t / beatDuration);
      const beatProgress = (t % beatDuration) / beatDuration;

      // Four-on-the-floor Punchy Kick
      let kick = 0;
      if (beatProgress < 0.25) {
        const kickEnv = Math.exp(-beatProgress * 25);
        const freq = 130 * Math.exp(-beatProgress * 30) + 40;
        kick = Math.sin(2 * Math.PI * freq * beatProgress) * kickEnv * 0.7;
      }

      // Offbeat Hi-Hat (on every half beat)
      let hat = 0;
      const hatProgress = (t % (beatDuration / 2)) / (beatDuration / 2);
      if (beatNum % 1 !== 0 || hatProgress > 0.4) {
        if (hatProgress < 0.2) {
          const hatEnv = Math.exp(-hatProgress * 35);
          hat = (Math.random() * 2 - 1) * hatEnv * 0.25;
        }
      }

      // Acid 303 / Synth Bassline on 16th notes
      const subIndex = Math.floor((t % beatDuration) / subBeat);
      let bass = 0;
      if (subIndex === 1 || subIndex === 3 || subIndex === 2) {
        const bassProgress = (t % subBeat) / subBeat;
        const bassEnv = Math.exp(-bassProgress * 12);
        const cutoffMod = 200 + Math.sin(t * 0.8) * 600 + (track.genre === 'Acid' ? 800 : 200);
        const bassFreq = track.genre === 'Acid' ? 65 : 55;
        // Sawtooth approximation
        const saw = (2 * ((t * bassFreq) % 1) - 1);
        bass = Math.tanh(saw * (cutoffMod / 150)) * bassEnv * 0.35;
      }

      // Synth Pad / Atmosphere
      const pad = Math.sin(2 * Math.PI * (220 + Math.sin(t * 0.1) * 20) * t) * 0.08 * Math.min(t / 10, 1);

      const sample = (kick + hat + bass + pad) * 0.6;
      left[i] = sample;
      right[i] = sample;
    }

    return buffer;
  }

  public playTrack(track: Track) {
    this.initAudio();

    if (this.state.currentTrack?.id !== track.id) {
      this.stopCurrentSource();
      this.state.currentTrack = track;
      this.state.currentTime = 0;
      this.state.duration = track.duration;
      this.state.loopA = null;
      this.state.loopB = null;
      this.state.cuePoint = 0;
    }

    if (!this.state.isPlaying) {
      this.startPlaybackAt(this.state.currentTime);
    }
  }

  private startPlaybackAt(time: number) {
    if (!this.state.currentTrack) return;
    this.initAudio();

    this.stopCurrentSource();

    try {
      const audioBuffer = this.createElectronicSynthBuffer(this.state.currentTrack);
      const source = this.ctx!.createBufferSource();
      source.buffer = audioBuffer;
      source.playbackRate.value = this.state.playbackRate;
      source.connect(this.gainNode!);

      const offset = Math.min(time, this.state.duration);
      source.start(0, offset);
      this.activeSource = source;

      this.state.isPlaying = true;
      this.state.currentTime = offset;
      this.notify();

      this.startProgressTimer();
    } catch (err) {
      console.warn('Audio playback synthesis error:', err);
      this.state.isPlaying = false;
      this.notify();
    }
  }

  private startProgressTimer() {
    this.stopProgressTimer();
    let lastTimestamp = performance.now();

    const tick = () => {
      if (!this.state.isPlaying) return;

      const now = performance.now();
      const delta = (now - lastTimestamp) / 1000;
      lastTimestamp = now;

      this.state.currentTime += delta * this.state.playbackRate;

      // Handle A/B Loop
      if (
        this.state.isLooping &&
        this.state.loopA !== null &&
        this.state.loopB !== null &&
        this.state.loopB > this.state.loopA
      ) {
        if (this.state.currentTime >= this.state.loopB) {
          this.seek(this.state.loopA);
          return;
        }
      }

      if (this.state.currentTime >= this.state.duration) {
        this.state.currentTime = 0;
        if (!this.state.isLooping) {
          this.pause();
        } else {
          this.startPlaybackAt(0);
        }
        return;
      }

      this.notify();
      this.timerId = requestAnimationFrame(tick);
    };

    this.timerId = requestAnimationFrame(tick);
  }

  private stopProgressTimer() {
    if (this.timerId !== null) {
      cancelAnimationFrame(this.timerId);
      this.timerId = null;
    }
  }

  private stopCurrentSource() {
    if (this.activeSource) {
      try {
        this.activeSource.stop();
        this.activeSource.disconnect();
      } catch {
        // ignore
      }
      this.activeSource = null;
    }
  }

  public pause() {
    this.stopCurrentSource();
    this.stopProgressTimer();
    this.state.isPlaying = false;
    this.notify();
  }

  public togglePlayPause() {
    if (!this.state.currentTrack) return;
    if (this.state.isPlaying) {
      this.pause();
    } else {
      this.startPlaybackAt(this.state.currentTime);
    }
  }

  public seek(seconds: number) {
    const newTime = Math.max(0, Math.min(seconds, this.state.duration));
    this.state.currentTime = newTime;
    if (this.state.isPlaying) {
      this.startPlaybackAt(newTime);
    } else {
      this.notify();
    }
  }

  public setVolume(vol: number) {
    this.state.volume = Math.max(0, Math.min(1, vol));
    if (this.gainNode) {
      this.gainNode.gain.value = this.state.isMuted ? 0 : this.state.volume;
    }
    this.notify();
  }

  public toggleMute() {
    this.state.isMuted = !this.state.isMuted;
    if (this.gainNode) {
      this.gainNode.gain.value = this.state.isMuted ? 0 : this.state.volume;
    }
    this.notify();
  }

  public setPlaybackRate(rate: number) {
    this.state.playbackRate = Math.max(0.7, Math.min(1.3, rate));
    if (this.activeSource) {
      this.activeSource.playbackRate.value = this.state.playbackRate;
    }
    this.notify();
  }

  public toggleLoop() {
    this.state.isLooping = !this.state.isLooping;
    this.notify();
  }

  public setLoopA() {
    this.state.loopA = this.state.currentTime;
    this.state.isLooping = true;
    this.notify();
  }

  public setLoopB() {
    if (this.state.loopA !== null && this.state.currentTime > this.state.loopA) {
      this.state.loopB = this.state.currentTime;
      this.state.isLooping = true;
    }
    this.notify();
  }

  public clearLoop() {
    this.state.loopA = null;
    this.state.loopB = null;
    this.notify();
  }

  public setCuePoint(point: number) {
    this.state.cuePoint = point;
    this.notify();
  }

  public jumpToCue() {
    if (this.state.cuePoint !== null) {
      this.seek(this.state.cuePoint);
    }
  }

  public getFrequencyData(array: Uint8Array) {
    if (this.analyser) {
      this.analyser.getByteFrequencyData(array);
    } else {
      array.fill(0);
    }
  }

  public getState(): AudioState {
    return { ...this.state };
  }
}

export const audioService = new AudioService();
