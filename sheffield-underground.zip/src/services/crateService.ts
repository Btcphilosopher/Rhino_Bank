import { Track } from '../types';

export interface CrateItem {
  track: Track;
  format: 'WAV' | 'MP3' | 'AIFF' | 'STEMS';
  license: 'Standard' | 'DJ Performance' | 'Commercial';
  addedAt: string;
}

type CrateListener = (items: CrateItem[]) => void;

class CrateService {
  private items: CrateItem[] = [];
  private listeners: Set<CrateListener> = new Set();

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const saved = localStorage.getItem('sheffield_dj_crate');
      if (saved) {
        this.items = JSON.parse(saved);
      }
    } catch {
      // fallback
    }
  }

  private saveToStorage() {
    try {
      localStorage.setItem('sheffield_dj_crate', JSON.stringify(this.items));
    } catch {
      // fallback
    }
    this.notify();
  }

  public subscribe(listener: CrateListener) {
    this.listeners.add(listener);
    listener(this.items);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach(fn => fn([...this.items]));
  }

  public addToCrate(track: Track, format: 'WAV' | 'MP3' | 'AIFF' | 'STEMS' = 'WAV', license: 'Standard' | 'DJ Performance' | 'Commercial' = 'DJ Performance') {
    if (!this.items.some(i => i.track.id === track.id)) {
      this.items.push({
        track,
        format,
        license,
        addedAt: new Date().toISOString()
      });
      this.saveToStorage();
    }
  }

  public removeFromCrate(trackId: string) {
    this.items = this.items.filter(i => i.track.id !== trackId);
    this.saveToStorage();
  }

  public clearCrate() {
    this.items = [];
    this.saveToStorage();
  }

  public getTotalSats(): number {
    return this.items.reduce((sum, item) => sum + item.track.satsPrice, 0);
  }

  public getItems(): CrateItem[] {
    return [...this.items];
  }

  public exportRekordboxXml(): string {
    const xmlHeader = `<?xml version="1.0" encoding="UTF-8"?>\n<DJ_PLAYLISTS Version="1.0.0">\n  <PRODUCT Name="Sheffield Underground DJ Workstation" Version="2.0"/>\n  <COLLECTION Entries="${this.items.length}">\n`;
    
    const entries = this.items.map((item, index) => {
      return `    <TRACK TrackID="${index + 1}" Name="${item.track.title}" Artist="${item.track.artist}" Album="${item.track.label}" Genre="${item.track.genre}" AverageBpm="${item.track.bpm}" Tonality="${item.track.camelotKey}" TotalTime="${item.track.duration}"/>`;
    }).join('\n');

    const xmlFooter = `\n  </COLLECTION>\n</DJ_PLAYLISTS>`;
    return xmlHeader + entries + xmlFooter;
  }
}

export const crateService = new CrateService();
