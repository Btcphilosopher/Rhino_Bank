import React, { useState, useEffect } from 'react';
import { ActiveTab, Track } from './types';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { AudioPlayer } from './components/AudioPlayer';
import { DjModeModal } from './components/DjModeModal';
import { LightningModal } from './components/LightningModal';
import { WalletDrawer } from './components/WalletDrawer';

import { HomeView } from './views/HomeView';
import { MusicView } from './views/MusicView';
import { TrackDetailView } from './views/TrackDetailView';
import { DjPoolView } from './views/DjPoolView';
import { VideoSetsView } from './views/VideoSetsView';
import { EquipmentView } from './views/EquipmentView';
import { ProducerView } from './views/ProducerView';
import { LibraryView } from './views/LibraryView';
import { CreatorStudioView } from './views/CreatorStudioView';
import { TerminalView } from './views/TerminalView';

import { MOCK_TRACKS } from './data/mockData';
import { audioService, AudioState } from './services/audioService';
import { Zap, Disc } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [selectedTrack, setSelectedTrack] = useState<Track | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Modals state
  const [isDjModeOpen, setIsDjModeOpen] = useState(false);
  const [isLightningModalOpen, setIsLightningModalOpen] = useState(false);
  const [lightningModalTrack, setLightningModalTrack] = useState<Track | null>(null);
  const [isWalletDrawerOpen, setIsWalletDrawerOpen] = useState(false);

  // Audio state listener
  const [audioState, setAudioState] = useState<AudioState>(audioService.getState());

  useEffect(() => {
    const unsub = audioService.subscribe((s) => setAudioState(s));
    return () => unsub();
  }, []);

  const handlePlayTrack = (track: Track) => {
    audioService.playTrack(track);
  };

  const handleSelectTrack = (track: Track) => {
    setSelectedTrack(track);
    setActiveTab('track_detail');
  };

  const handleOpenPayLightning = (track?: Track) => {
    setLightningModalTrack(track || selectedTrack || MOCK_TRACKS[0]);
    setIsLightningModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#F0F0F0] flex flex-col font-mono selection:bg-[#FFD700] selection:text-black">
      
      {/* Navbar Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        openLightningModal={() => handleOpenPayLightning()}
        openWalletDrawer={() => setIsWalletDrawerOpen(true)}
        searchQuery={searchQuery}
        onSearchChange={(q) => {
          setSearchQuery(q);
          if (activeTab !== 'music') setActiveTab('music');
        }}
      />

      {/* Hero Banner (Shown on Home View) */}
      {activeTab === 'home' && (
        <Hero
          onBrowseClick={() => setActiveTab('music')}
          onListenMixesClick={() => setActiveTab('video')}
          onPayLightningClick={() => handleOpenPayLightning()}
          featuredTrack={MOCK_TRACKS[0]}
          onPlayTrack={handlePlayTrack}
        />
      )}

      {/* Main View Router Content */}
      <main className="flex-1 pb-28">
        {(activeTab === 'home') && (
          <HomeView
            onSelectTrack={handleSelectTrack}
            currentTrackId={audioState.currentTrack?.id}
            isPlaying={audioState.isPlaying}
            onPlayTrack={handlePlayTrack}
            setActiveTab={setActiveTab}
            openLightningModal={() => handleOpenPayLightning()}
          />
        )}

        {(activeTab === 'music' || activeTab === 'charts') && (
          <MusicView
            onSelectTrack={handleSelectTrack}
            currentTrackId={audioState.currentTrack?.id}
            isPlaying={audioState.isPlaying}
            onPlayTrack={handlePlayTrack}
            searchQuery={searchQuery}
          />
        )}

        {activeTab === 'track_detail' && selectedTrack && (
          <TrackDetailView
            track={selectedTrack}
            onBack={() => setActiveTab('music')}
            isPlaying={audioState.isPlaying && audioState.currentTrack?.id === selectedTrack.id}
            onPlayTrack={handlePlayTrack}
            onPayLightning={handleOpenPayLightning}
          />
        )}

        {activeTab === 'dj_pool' && (
          <DjPoolView
            onSelectTrack={handleSelectTrack}
            currentTrackId={audioState.currentTrack?.id}
            isPlaying={audioState.isPlaying}
            onPlayTrack={handlePlayTrack}
            openLightningModal={() => handleOpenPayLightning()}
          />
        )}

        {activeTab === 'video' && <VideoSetsView />}

        {activeTab === 'equipment' && (
          <EquipmentView openLightningModal={() => handleOpenPayLightning()} />
        )}

        {activeTab === 'samples' && (
          <ProducerView openLightningModal={() => handleOpenPayLightning()} />
        )}

        {activeTab === 'library' && <LibraryView />}

        {activeTab === 'creator_studio' && <CreatorStudioView />}

        {activeTab === 'terminal' && <TerminalView />}
      </main>

      {/* Bottom Audio Workstation Player Bar */}
      <AudioPlayer
        onOpenDjMode={() => setIsDjModeOpen(true)}
        onOpenTrackDetail={(track) => {
          setSelectedTrack(track);
          setActiveTab('track_detail');
        }}
        onPayLightning={(track) => handleOpenPayLightning(track)}
      />

      {/* Fullscreen DJ Workstation Modal */}
      <DjModeModal
        isOpen={isDjModeOpen}
        onClose={() => setIsDjModeOpen(false)}
        onSelectTrack={handleSelectTrack}
      />

      {/* Lightning Payment Modal */}
      <LightningModal
        isOpen={isLightningModalOpen}
        onClose={() => setIsLightningModalOpen(false)}
        track={lightningModalTrack}
      />

      {/* Wallet Drawer */}
      <WalletDrawer
        isOpen={isWalletDrawerOpen}
        onClose={() => setIsWalletDrawerOpen(false)}
      />

      {/* Footer (Matching Mockup) */}
      <footer className="bg-[#050505] border-t border-[#222] text-gray-400 text-xs font-mono py-8 px-4 md:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded bg-[#FFD700] text-black font-black flex items-center justify-center text-[10px]">
              ⚡
            </div>
            <div>
              <span className="font-black text-white uppercase italic">SHEFFIELD UNDERGROUND</span>
              <span className="text-[10px] text-[#FFD700] ml-2 font-mono uppercase">DJ & PRODUCER MARKETPLACE</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-[11px] text-gray-500 uppercase font-mono">
            <button onClick={() => setActiveTab('library')} className="hover:text-white">MY LIBRARY</button>
            <button onClick={() => setActiveTab('creator_studio')} className="hover:text-white">ARTIST STUDIO</button>
            <button onClick={() => setActiveTab('terminal')} className="hover:text-white">TERMINAL</button>
            <button onClick={() => setActiveTab('dj_pool')} className="hover:text-white">DJ CRATE</button>
          </div>

          <div className="text-[10px] text-gray-600 font-mono">
            © 2026 Sheffield Underground. Built in Sheffield. Played everywhere.
          </div>

        </div>
      </footer>

    </div>
  );
}
