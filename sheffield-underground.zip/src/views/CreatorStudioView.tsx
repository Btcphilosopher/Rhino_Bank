import React, { useState } from 'react';
import { Upload, Zap, TrendingUp, BarChart2, CheckCircle2, ShieldCheck } from 'lucide-react';

export const CreatorStudioView: React.FC = () => {
  const [title, setTitle] = useState('');
  const [genre, setGenre] = useState('Techno');
  const [bpm, setBpm] = useState('128');
  const [satsPrice, setSatsPrice] = useState('2500');
  const [isPublished, setIsPublished] = useState(false);

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault();
    setIsPublished(true);
    setTimeout(() => setIsPublished(false), 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 space-y-8 font-mono">
      <div className="border-b border-[#22262e] pb-6">
        <h1 className="text-3xl font-black text-white uppercase tracking-tight flex items-center gap-3">
          <Upload className="w-8 h-8 text-[#f59e0b]" />
          ARTIST STUDIO & LIGHTNING CREATOR DASHBOARD
        </h1>
        <p className="text-xs text-gray-400 font-sans mt-1">
          Publish your electronic music, set custom sats prices, keep 100% of direct Lightning sales, and track real-time audience analytics.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Upload Form */}
        <div className="lg:col-span-7 bg-[#101217] border border-[#22262e] rounded-xl p-6 space-y-4">
          <h2 className="text-base font-bold text-white uppercase flex items-center gap-2">
            <Upload className="w-4 h-4 text-[#f59e0b]" />
            PUBLISH NEW RELEASE
          </h2>

          <form onSubmit={handleUpload} className="space-y-4 text-xs">
            <div>
              <label className="text-gray-400 font-bold block mb-1">TRACK TITLE</label>
              <input
                type="text"
                required
                placeholder="e.g. Steel City Acid Drop"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-[#181b22] border border-[#3a414e] rounded p-2.5 text-white focus:outline-none focus:border-[#f59e0b]"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-gray-400 font-bold block mb-1">GENRE</label>
                <select
                  value={genre}
                  onChange={(e) => setGenre(e.target.value)}
                  className="w-full bg-[#181b22] border border-[#3a414e] rounded p-2.5 text-white focus:outline-none focus:border-[#f59e0b]"
                >
                  <option value="Techno">Techno</option>
                  <option value="Acid">Acid</option>
                  <option value="Deep House">Deep House</option>
                  <option value="Breakbeat">Breakbeat</option>
                </select>
              </div>
              <div>
                <label className="text-gray-400 font-bold block mb-1">BPM</label>
                <input
                  type="number"
                  value={bpm}
                  onChange={(e) => setBpm(e.target.value)}
                  className="w-full bg-[#181b22] border border-[#3a414e] rounded p-2.5 text-white focus:outline-none focus:border-[#f59e0b]"
                />
              </div>
              <div>
                <label className="text-gray-400 font-bold block mb-1">SATS PRICE</label>
                <input
                  type="number"
                  value={satsPrice}
                  onChange={(e) => setSatsPrice(e.target.value)}
                  className="w-full bg-[#181b22] border border-[#3a414e] rounded p-2.5 text-white focus:outline-none focus:border-[#f59e0b]"
                />
              </div>
            </div>

            <div className="border-2 border-dashed border-[#2d323c] rounded-lg p-6 text-center space-y-1">
              <Upload className="w-8 h-8 text-gray-500 mx-auto" />
              <p className="text-white font-bold">DRAG & DROP LOSSLESS WAV / STEMS HERE</p>
              <p className="text-gray-500 text-[10px]">Supports 24-bit WAV, AIFF, FLAC up to 500MB</p>
            </div>

            <button
              type="submit"
              className="w-full bg-[#f59e0b] hover:bg-[#fbbf24] text-black font-black text-sm uppercase py-3 rounded shadow-lg transition-all"
            >
              PUBLISH TO SHEFFIELD UNDERGROUND
            </button>
          </form>

          {isPublished && (
            <div className="bg-emerald-500/10 border border-emerald-500/40 text-emerald-400 text-xs p-3 rounded font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              Track published to Lightning network marketplace successfully!
            </div>
          )}
        </div>

        {/* Analytics Card */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#101217] border border-[#22262e] rounded-xl p-6 space-y-4">
            <h2 className="text-base font-bold text-white uppercase flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-[#f59e0b]" />
              CREATOR REVENUE STATS
            </h2>

            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="bg-[#181b22] border border-[#2d323c] rounded p-4">
                <div className="text-[10px] text-gray-400 uppercase font-bold">TOTAL SATS EARNED</div>
                <div className="text-xl font-black text-[#f59e0b] mt-1">1,482,000</div>
              </div>
              <div className="bg-[#181b22] border border-[#2d323c] rounded p-4">
                <div className="text-[10px] text-gray-400 uppercase font-bold">TOTAL DOWNLOADS</div>
                <div className="text-xl font-black text-emerald-400 mt-1">3,412</div>
              </div>
            </div>

            <div className="bg-[#181b22] border border-[#2d323c] rounded p-4 space-y-2">
              <div className="text-xs text-gray-400 uppercase font-bold">LIGHTNING ADDRESS SETTLEMENT</div>
              <p className="text-xs text-white font-bold">steelcity@shefunderground.btc</p>
              <p className="text-[10px] text-gray-500">Sales settle directly into your Lightning wallet instantly with 0% platform fee.</p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
