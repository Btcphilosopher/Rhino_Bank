import React, { useState } from 'react';
import { Track, Genre, KeySignature } from '../types';
import { TrackCard } from '../components/TrackCard';
import { TrackListRow } from '../components/TrackListRow';
import { MOCK_TRACKS } from '../data/mockData';
import { Filter, SlidersHorizontal, Grid, List, Zap, Disc } from 'lucide-react';

interface MusicViewProps {
  onSelectTrack: (track: Track) => void;
  currentTrackId?: string;
  isPlaying: boolean;
  onPlayTrack: (track: Track) => void;
  searchQuery?: string;
}

const ALL_GENRES: Genre[] = [
  'Techno', 'Deep House', 'House', 'Acid', 'Industrial',
  'Drum & Bass', 'Garage', 'Breakbeat', 'Electro', 'Trance', 'Ambient', 'Hardcore'
];

export const MusicView: React.FC<MusicViewProps> = ({
  onSelectTrack,
  currentTrackId,
  isPlaying,
  onPlayTrack,
  searchQuery = ''
}) => {
  const [selectedGenre, setSelectedGenre] = useState<string>('ALL');
  const [selectedMixType, setSelectedMixType] = useState<string>('ALL');
  const [bpmRange, setBpmRange] = useState<number>(135);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredTracks = MOCK_TRACKS.filter((track) => {
    if (selectedGenre !== 'ALL' && track.genre !== selectedGenre) return false;
    if (selectedMixType !== 'ALL' && track.mixType !== selectedMixType) return false;
    if (track.bpm > bpmRange) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const match =
        track.title.toLowerCase().includes(q) ||
        track.artist.toLowerCase().includes(q) ||
        track.genre.toLowerCase().includes(q) ||
        track.camelotKey.toLowerCase().includes(q) ||
        track.key.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 space-y-8 font-mono">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#22262e] pb-6">
        <div>
          <h1 className="text-3xl font-black text-white uppercase tracking-tight flex items-center gap-2">
            <Disc className="w-7 h-7 text-[#f59e0b]" />
            MUSIC MARKETPLACE
          </h1>
          <p className="text-xs text-gray-400 font-sans mt-1">
            Browse losslessly mastered electronic music, extended mixes, DJ tools and stems.
          </p>
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-2 bg-[#121418] border border-[#2d323c] p-1 rounded">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 rounded transition-colors ${viewMode === 'grid' ? 'bg-[#f59e0b] text-black font-bold' : 'text-gray-400 hover:text-white'}`}
            title="Grid View"
          >
            <Grid className="w-4 h-4" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`p-2 rounded transition-colors ${viewMode === 'list' ? 'bg-[#f59e0b] text-black font-bold' : 'text-gray-400 hover:text-white'}`}
            title="List View"
          >
            <List className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-[#101217] border border-[#22262e] rounded-xl p-4 space-y-4">
        
        {/* Genre Pills */}
        <div className="flex overflow-x-auto gap-2 pb-2 text-xs uppercase font-bold no-scrollbar">
          <button
            onClick={() => setSelectedGenre('ALL')}
            className={`px-3 py-1.5 rounded whitespace-nowrap transition-colors ${
              selectedGenre === 'ALL'
                ? 'bg-[#f59e0b] text-black'
                : 'bg-[#181b22] text-gray-400 hover:text-white hover:bg-[#252a36]'
            }`}
          >
            ALL GENRES
          </button>
          {ALL_GENRES.map((g) => (
            <button
              key={g}
              onClick={() => setSelectedGenre(g)}
              className={`px-3 py-1.5 rounded whitespace-nowrap transition-colors ${
                selectedGenre === g
                  ? 'bg-[#f59e0b] text-black'
                  : 'bg-[#181b22] text-gray-400 hover:text-white hover:bg-[#252a36]'
              }`}
            >
              {g}
            </button>
          ))}
        </div>

        {/* Secondary Filter Sliders */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-[#1d212a] text-xs">
          
          <div>
            <label className="text-gray-400 uppercase font-bold block mb-1">
              MAX BPM: <span className="text-[#f59e0b]">{bpmRange} BPM</span>
            </label>
            <input
              type="range"
              min={115}
              max={150}
              value={bpmRange}
              onChange={(e) => setBpmRange(parseInt(e.target.value, 10))}
              className="w-full h-1.5 bg-[#1f242d] accent-[#f59e0b] rounded cursor-pointer"
            />
          </div>

          <div>
            <label className="text-gray-400 uppercase font-bold block mb-1">
              MIX TYPE
            </label>
            <select
              value={selectedMixType}
              onChange={(e) => setSelectedMixType(e.target.value)}
              className="w-full bg-[#181b22] border border-[#2d323c] rounded px-3 py-1.5 text-xs font-mono text-white focus:outline-none focus:border-[#f59e0b]"
            >
              <option value="ALL">ALL MIXES</option>
              <option value="Original Mix">ORIGINAL MIX</option>
              <option value="Extended Mix">EXTENDED MIX</option>
              <option value="Dub">DUB</option>
            </select>
          </div>

          <div className="flex items-end">
            <button
              onClick={() => {
                setSelectedGenre('ALL');
                setSelectedMixType('ALL');
                setBpmRange(150);
              }}
              className="w-full bg-[#181b22] hover:bg-[#252a36] text-gray-400 hover:text-white border border-[#2d323c] py-1.5 rounded text-xs uppercase"
            >
              RESET FILTERS
            </button>
          </div>

        </div>

      </div>

      {/* Track Grid or List Output */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredTracks.map((track) => (
            <TrackCard
              key={track.id}
              track={track}
              isPlaying={isPlaying && currentTrackId === track.id}
              onPlay={onPlayTrack}
              onSelectTrack={onSelectTrack}
            />
          ))}
        </div>
      ) : (
        <div className="space-y-2">
          {filteredTracks.map((track, i) => (
            <TrackListRow
              key={track.id}
              rank={i + 1}
              track={track}
              isPlaying={isPlaying && currentTrackId === track.id}
              onPlay={onPlayTrack}
              onSelectTrack={onSelectTrack}
            />
          ))}
        </div>
      )}

      {filteredTracks.length === 0 && (
        <div className="text-center py-12 text-gray-500 font-mono">
          No tracks match your current filters.
        </div>
      )}

    </div>
  );
};
