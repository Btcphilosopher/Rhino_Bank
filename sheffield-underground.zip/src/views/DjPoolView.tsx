import React, { useState, useEffect } from 'react';
import { Track } from '../types';
import { crateService, CrateItem } from '../services/crateService';
import { MOCK_TRACKS } from '../data/mockData';
import { Disc, Download, Trash2, Zap, ArrowRight, Sliders, CheckCircle2 } from 'lucide-react';
import { TrackListRow } from '../components/TrackListRow';

interface DjPoolViewProps {
  onSelectTrack: (track: Track) => void;
  currentTrackId?: string;
  isPlaying: boolean;
  onPlayTrack: (track: Track) => void;
  openLightningModal: () => void;
}

export const DjPoolView: React.FC<DjPoolViewProps> = ({
  onSelectTrack,
  currentTrackId,
  isPlaying,
  onPlayTrack,
  openLightningModal
}) => {
  const [crateItems, setCrateItems] = useState<CrateItem[]>(crateService.getItems());
  const [selectedBaseTrack, setSelectedBaseTrack] = useState<Track>(MOCK_TRACKS[0]);
  const [exportedXml, setExportedXml] = useState<string | null>(null);

  useEffect(() => {
    const unsub = crateService.subscribe((items) => setCrateItems(items));
    return () => unsub();
  }, []);

  const totalSats = crateService.getTotalSats();

  // Smart Mix Compatibility logic: Find tracks within +- 6 BPM and Camelot Key harmony
  const compatibleTracks = MOCK_TRACKS.filter((t) => {
    if (t.id === selectedBaseTrack.id) return false;
    const bpmDiff = Math.abs(t.bpm - selectedBaseTrack.bpm);
    if (bpmDiff > 6) return false;

    // Same key or matching numerical Camelot
    const baseNum = parseInt(selectedBaseTrack.camelotKey, 10);
    const targetNum = parseInt(t.camelotKey, 10);
    const keyDiff = Math.abs(baseNum - targetNum);

    return keyDiff === 0 || keyDiff === 1 || keyDiff === 11;
  });

  const handleExportRekordbox = () => {
    const xml = crateService.exportRekordboxXml();
    setExportedXml(xml);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 space-y-12 font-mono">
      
      {/* Header */}
      <div className="border-b border-[#22262e] pb-6">
        <h1 className="text-3xl font-black text-white uppercase tracking-tight flex items-center gap-3">
          <Disc className="w-8 h-8 text-[#f59e0b]" />
          MY DJ CRATE & HARMONIC MIX ENGINE
        </h1>
        <p className="text-xs text-gray-400 font-sans mt-1">
          Prepare your sets, export Rekordbox XML playlists, and analyze key/BPM mix compatibility.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: My DJ Crate */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between bg-[#101217] border border-[#22262e] rounded-xl p-4">
            <div>
              <h2 className="text-base font-bold text-white uppercase">
                MY DJ CRATE ({crateItems.length} TRACKS)
              </h2>
              <div className="text-xs text-[#f59e0b] font-bold mt-0.5">
                TOTAL: {totalSats.toLocaleString()} SATS
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleExportRekordbox}
                disabled={crateItems.length === 0}
                className="bg-[#181b22] hover:bg-[#252a36] text-white border border-[#2d323c] text-xs px-3 py-2 rounded flex items-center gap-1.5 disabled:opacity-50"
              >
                <Download className="w-4 h-4 text-[#f59e0b]" />
                REKORDBOX XML
              </button>

              <button
                onClick={openLightningModal}
                disabled={crateItems.length === 0}
                className="bg-[#f59e0b] hover:bg-[#fbbf24] text-black font-black text-xs uppercase px-4 py-2 rounded flex items-center gap-1 disabled:opacity-50"
              >
                <Zap className="w-4 h-4 fill-black" />
                CHECKOUT CRATE
              </button>
            </div>
          </div>

          {/* Crate Items Table */}
          {crateItems.length > 0 ? (
            <div className="space-y-2">
              {crateItems.map((item) => (
                <div key={item.track.id} className="relative group">
                  <TrackListRow
                    track={item.track}
                    isPlaying={isPlaying && currentTrackId === item.track.id}
                    onPlay={onPlayTrack}
                    onSelectTrack={onSelectTrack}
                  />
                  <button
                    onClick={() => crateService.removeFromCrate(item.track.id)}
                    className="absolute right-3 top-3 text-red-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity p-1 bg-black/80 rounded"
                    title="Remove from Crate"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-[#101217] border border-dashed border-[#2d323c] rounded-xl p-12 text-center text-gray-500">
              <Disc className="w-12 h-12 mx-auto mb-3 text-gray-600" />
              <p className="text-sm font-bold uppercase text-gray-400">YOUR DJ CRATE IS EMPTY</p>
              <p className="text-xs font-sans mt-1">Browse the marketplace and add tracks to build your set list.</p>
            </div>
          )}

          {exportedXml && (
            <div className="bg-[#121418] border border-[#f59e0b]/40 rounded-lg p-4 space-y-2">
              <div className="flex justify-between items-center text-xs font-bold text-[#f59e0b]">
                <span>REKORDBOX XML GENERATED</span>
                <button onClick={() => setExportedXml(null)} className="text-gray-400 hover:text-white text-[10px]">CLOSE</button>
              </div>
              <textarea
                readOnly
                value={exportedXml}
                rows={5}
                className="w-full bg-[#08090b] text-[10px] text-gray-300 font-mono p-3 rounded border border-[#22262e] focus:outline-none"
              />
            </div>
          )}
        </div>

        {/* Right Column: Smart Mix Compatibility Engine */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#101217] border border-[#2d323c] rounded-xl p-6 space-y-4">
            <div className="flex items-center gap-2 border-b border-[#22262e] pb-3">
              <Sliders className="w-5 h-5 text-[#f59e0b]" />
              <h3 className="text-sm font-black uppercase text-white">
                SMART HARMONIC MIX ENGINE
              </h3>
            </div>

            <div className="space-y-2">
              <label className="text-xs text-gray-400 font-bold uppercase block">
                SELECT BASE TRACK:
              </label>
              <select
                value={selectedBaseTrack.id}
                onChange={(e) => {
                  const found = MOCK_TRACKS.find(t => t.id === e.target.value);
                  if (found) setSelectedBaseTrack(found);
                }}
                className="w-full bg-[#181b22] border border-[#3a414e] rounded px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#f59e0b]"
              >
                {MOCK_TRACKS.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.title} ({t.bpm} BPM / {t.camelotKey})
                  </option>
                ))}
              </select>
            </div>

            {/* Base Track Info */}
            <div className="bg-[#181b22] border border-[#2d323c] rounded-lg p-3 space-y-1">
              <div className="text-xs font-bold text-white uppercase">{selectedBaseTrack.title}</div>
              <div className="text-[11px] text-gray-400">{selectedBaseTrack.artist}</div>
              <div className="flex gap-3 text-[10px] text-[#f59e0b] pt-1 font-bold">
                <span>{selectedBaseTrack.bpm} BPM</span>
                <span>KEY: {selectedBaseTrack.camelotKey} ({selectedBaseTrack.key})</span>
              </div>
            </div>

            {/* Compatible Matches */}
            <div className="space-y-2 pt-2">
              <h4 className="text-xs font-bold uppercase text-gray-400">
                RECOMMENDED COMPATIBLE NEXT TRACKS:
              </h4>

              <div className="space-y-2">
                {compatibleTracks.map((track) => (
                  <div key={track.id} className="bg-[#121418] border border-[#22262e] hover:border-[#f59e0b]/40 rounded p-3 flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white truncate">{track.title}</div>
                      <div className="text-[10px] text-gray-400">{track.artist}</div>
                      <div className="text-[10px] text-emerald-400 font-bold">
                        {track.bpm} BPM • Key Match {track.camelotKey}
                      </div>
                    </div>
                    <button
                      onClick={() => crateService.addToCrate(track)}
                      className="bg-[#181b22] hover:bg-[#f59e0b] hover:text-black text-gray-300 p-2 rounded border border-[#2d323c] text-[10px] uppercase font-bold transition-colors"
                    >
                      + CRATE
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
