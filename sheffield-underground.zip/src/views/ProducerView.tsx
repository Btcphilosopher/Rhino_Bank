import React from 'react';
import { MOCK_SAMPLE_PACKS } from '../data/mockData';
import { Sliders, Zap, Download } from 'lucide-react';

interface ProducerViewProps {
  openLightningModal: () => void;
}

export const ProducerView: React.FC<ProducerViewProps> = ({ openLightningModal }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 space-y-8 font-mono">
      <div className="border-b border-[#22262e] pb-6">
        <h1 className="text-3xl font-black text-white uppercase tracking-tight flex items-center gap-3">
          <Sliders className="w-8 h-8 text-[#f59e0b]" />
          PRODUCER MARKETPLACE: SAMPLES & STEMS
        </h1>
        <p className="text-xs text-gray-400 font-sans mt-1">
          High-grade 24-bit WAV sample packs, 303 acid loops, 909 drum kits and stems.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {MOCK_SAMPLE_PACKS.map((pack) => (
          <div key={pack.id} className="bg-[#101217] border border-[#22262e] rounded-xl p-6 flex flex-col md:flex-row gap-6 items-center">
            <img src={pack.coverUrl} alt={pack.title} className="w-32 h-32 rounded-lg object-cover border border-[#2d323c] flex-shrink-0" />
            <div className="space-y-3 flex-1 min-w-0">
              <div>
                <div className="text-[10px] text-[#f59e0b] font-bold uppercase">{pack.genre} • {pack.format}</div>
                <h3 className="text-lg font-black text-white uppercase truncate">{pack.title}</h3>
                <p className="text-xs text-gray-400 font-sans mt-1">{pack.description}</p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-[#1d212a]">
                <div className="text-sm font-black text-[#f59e0b] flex items-center gap-1">
                  <Zap className="w-4 h-4 fill-[#f59e0b]" />
                  {pack.satsPrice.toLocaleString()} SATS
                </div>

                <button
                  onClick={openLightningModal}
                  className="bg-[#f59e0b] hover:bg-[#fbbf24] text-black font-black text-xs uppercase px-4 py-2 rounded flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  BUY PACK
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
