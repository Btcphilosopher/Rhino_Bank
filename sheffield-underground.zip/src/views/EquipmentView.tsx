import React, { useState } from 'react';
import { EquipmentProduct } from '../types';
import { MOCK_EQUIPMENT } from '../data/mockData';
import { Cpu, Zap, ShieldCheck, ShoppingCart, Star } from 'lucide-react';

interface EquipmentViewProps {
  openLightningModal: () => void;
}

export const EquipmentView: React.FC<EquipmentViewProps> = ({ openLightningModal }) => {
  const [selectedProduct, setSelectedProduct] = useState<EquipmentProduct | null>(null);

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 space-y-8 font-mono">
      
      {/* Header */}
      <div className="border-b border-[#22262e] pb-6">
        <h1 className="text-3xl font-black text-white uppercase tracking-tight flex items-center gap-3">
          <Cpu className="w-8 h-8 text-[#f59e0b]" />
          PRO DJ EQUIPMENT & USED GEAR MARKETPLACE
        </h1>
        <p className="text-xs text-gray-400 font-sans mt-1">
          Buy CDJs, analog mixers, turntables, vintage synths & studio gear with Bitcoin Lightning.
        </p>
      </div>

      {/* Equipment Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {MOCK_EQUIPMENT.map((item) => (
          <div
            key={item.id}
            className="bg-[#101217] border border-[#22262e] hover:border-[#f59e0b]/50 rounded-xl p-5 flex flex-col justify-between space-y-4 transition-all hover:bg-[#151820]"
          >
            {/* Image & Condition Badge */}
            <div className="relative aspect-video rounded-lg overflow-hidden bg-[#181b22] border border-[#2d323c]">
              <img
                src={item.imageUrl}
                alt={item.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-2 left-2 bg-black/80 text-[#f59e0b] border border-[#f59e0b]/40 text-[10px] font-bold px-2 py-0.5 rounded uppercase">
                {item.condition}
              </div>
            </div>

            {/* Title & Brand */}
            <div className="space-y-1">
              <div className="text-[10px] text-gray-500 uppercase font-bold">{item.brand} • {item.category}</div>
              <h3 className="text-sm font-bold text-white uppercase line-clamp-2">{item.name}</h3>
              <p className="text-xs text-gray-400 font-sans line-clamp-2 mt-1">{item.description}</p>
            </div>

            {/* Price & Buy Button */}
            <div className="pt-3 border-t border-[#1d212a] flex items-center justify-between">
              <div>
                <div className="text-sm font-black text-[#f59e0b] flex items-center gap-1">
                  <Zap className="w-4 h-4 fill-[#f59e0b]" />
                  {item.satsPrice.toLocaleString()} SATS
                </div>
                <div className="text-[10px] text-gray-500">{item.fiatPrice}</div>
              </div>

              <button
                onClick={openLightningModal}
                className="bg-[#f59e0b] hover:bg-[#fbbf24] text-black font-black text-xs uppercase px-4 py-2.5 rounded flex items-center gap-1.5 shadow-md"
              >
                <Zap className="w-3.5 h-3.5 fill-black" />
                BUY GEAR
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
