import React from 'react';
import { Track, ActiveTab } from '../types';
import { TrackCard } from '../components/TrackCard';
import { TrackListRow } from '../components/TrackListRow';
import { MOCK_TRACKS } from '../data/mockData';
import { ShieldCheck, Zap, Download, Globe, TrendingUp, Sparkles, Check, ArrowRight } from 'lucide-react';

interface HomeViewProps {
  onSelectTrack: (track: Track) => void;
  currentTrackId?: string;
  isPlaying: boolean;
  onPlayTrack: (track: Track) => void;
  setActiveTab: (tab: ActiveTab) => void;
  openLightningModal: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onSelectTrack,
  currentTrackId,
  isPlaying,
  onPlayTrack,
  setActiveTab,
  openLightningModal
}) => {
  return (
    <div className="space-y-12 pb-16">
      
      {/* New Releases & Top Charts Grid (Matching Mockup) */}
      <section className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* New Releases Carousel / Grid (Left 8 cols) */}
          <div className="lg:col-span-8 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-black font-mono text-white uppercase tracking-wider flex items-center gap-2">
                NEW RELEASES
              </h2>
              <button
                onClick={() => setActiveTab('music')}
                className="text-xs font-mono text-[#f59e0b] hover:underline flex items-center gap-1 font-bold"
              >
                VIEW ALL <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {MOCK_TRACKS.slice(0, 6).map((track) => (
                <TrackCard
                  key={track.id}
                  track={track}
                  isPlaying={isPlaying && currentTrackId === track.id}
                  onPlay={onPlayTrack}
                  onSelectTrack={onSelectTrack}
                />
              ))}
            </div>
          </div>

          {/* Right Top Charts & DJ Feature Info (Right 4 cols) */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Top Charts Row List */}
            <div className="bg-[#0a0c0f] border border-[#22262e] rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-[#1d212a] pb-3">
                <h3 className="text-sm font-black font-mono text-white uppercase tracking-wider flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-[#f59e0b]" />
                  TOP CHARTS
                </h3>
                <button
                  onClick={() => setActiveTab('charts')}
                  className="text-[11px] font-mono text-gray-400 hover:text-[#f59e0b]"
                >
                  VIEW ALL →
                </button>
              </div>

              <div className="space-y-2">
                {MOCK_TRACKS.slice(0, 5).map((track, i) => (
                  <TrackListRow
                    key={track.id}
                    rank={i + 1}
                    track={track}
                    isPlaying={isPlaying && currentTrackId === track.id}
                    onPlay={onPlayTrack}
                    onSelectTrack={onSelectTrack}
                  />
                ))}
              </div>
            </div>

            {/* Built For DJs Feature Card (Matching Mockup) */}
            <div className="bg-[#101217] border border-[#2d323c] rounded-xl p-5 space-y-4">
              <h4 className="text-xs font-mono font-black uppercase text-white tracking-widest border-b border-[#22262e] pb-2">
                BUILT FOR DJ'S
              </h4>

              <ul className="space-y-2.5 text-xs font-mono text-gray-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#f59e0b] flex-shrink-0" />
                  High quality WAV, FLAC & MP3
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#f59e0b] flex-shrink-0" />
                  Extended mixes & 32-bar intros
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#f59e0b] flex-shrink-0" />
                  No DJ tags or audio watermarks
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#f59e0b] flex-shrink-0" />
                  Camelot key & exact BPM metadata
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#f59e0b] flex-shrink-0" />
                  100% DJ & Club Ready
                </li>
              </ul>

              {/* Promo Coupon Box */}
              <div className="bg-[#181b22] border border-[#f59e0b]/30 rounded-lg p-3 text-center space-y-1">
                <div className="text-[11px] font-mono font-bold text-[#f59e0b] uppercase">
                  10% OFF YOUR FIRST ORDER
                </div>
                <div className="text-xs font-mono font-black text-white tracking-widest bg-black/60 py-1 rounded border border-[#f59e0b]/50">
                  Use code: SHEFFIELD10
                </div>
                <div className="text-[9px] text-gray-500 font-mono">
                  One use per customer over Lightning
                </div>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* Value Propositions Strip (Matching Mockup Footer Strip) */}
      <section className="bg-[#0a0c0f] border-y border-[#1d212a] py-8">
        <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-2 md:grid-cols-5 gap-6 text-center font-mono">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-full bg-[#f59e0b]/10 border border-[#f59e0b]/30 flex items-center justify-center mx-auto text-[#f59e0b]">
              <Sparkles className="w-5 h-5" />
            </div>
            <h5 className="text-xs font-bold text-white uppercase">DJ FOCUSED</h5>
            <p className="text-[11px] text-gray-400 font-sans">Curated for peak time sets and dancefloors.</p>
          </div>

          <div className="space-y-2">
            <div className="w-10 h-10 rounded-full bg-[#f59e0b]/10 border border-[#f59e0b]/30 flex items-center justify-center mx-auto text-[#f59e0b]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h5 className="text-xs font-bold text-white uppercase">SECURE & PRIVATE</h5>
            <p className="text-[11px] text-gray-400 font-sans">Lightning payments keep you in full control.</p>
          </div>

          <div className="space-y-2">
            <div className="w-10 h-10 rounded-full bg-[#f59e0b]/10 border border-[#f59e0b]/30 flex items-center justify-center mx-auto text-[#f59e0b]">
              <Download className="w-5 h-5" />
            </div>
            <h5 className="text-xs font-bold text-white uppercase">INSTANT ACCESS</h5>
            <p className="text-[11px] text-gray-400 font-sans">Download your lossless tracks immediately.</p>
          </div>

          <div className="space-y-2">
            <div className="w-10 h-10 rounded-full bg-[#f59e0b]/10 border border-[#f59e0b]/30 flex items-center justify-center mx-auto text-[#f59e0b]">
              <Globe className="w-5 h-5" />
            </div>
            <h5 className="text-xs font-bold text-white uppercase">GLOBAL SCENE</h5>
            <p className="text-[11px] text-gray-400 font-sans">Supporting underground culture worldwide.</p>
          </div>

          <div className="space-y-2 col-span-2 md:col-span-1">
            <div className="w-10 h-10 rounded-full bg-[#f59e0b]/10 border border-[#f59e0b]/30 flex items-center justify-center mx-auto text-[#f59e0b]">
              <Zap className="w-5 h-5 fill-[#f59e0b]" />
            </div>
            <h5 className="text-xs font-bold text-white uppercase">BITCOIN ECONOMY</h5>
            <p className="text-[11px] text-gray-400 font-sans">From Sheffield to the world via sats.</p>
          </div>
        </div>
      </section>

      {/* Stay in the Loop Newsletter (Matching Mockup) */}
      <section className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="bg-[#101217] border border-[#2d323c] rounded-xl p-8 flex flex-col md:flex-row items-center justify-between gap-6 font-mono">
          <div className="space-y-1">
            <h3 className="text-lg font-black text-white uppercase">STAY IN THE LOOP</h3>
            <p className="text-xs text-gray-400 font-sans">
              New music, live DJ sets, stem drops & exclusive Lightning offers.
            </p>
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto">
            <input
              type="email"
              placeholder="Enter your email"
              className="bg-[#181b22] border border-[#3a414e] rounded px-4 py-3 text-xs font-mono text-white focus:outline-none focus:border-[#f59e0b] w-full md:w-80"
            />
            <button className="bg-[#f59e0b] hover:bg-[#fbbf24] text-black font-black text-xs uppercase px-6 py-3 rounded flex-shrink-0 transition-colors">
              SUBSCRIBE
            </button>
          </div>
        </div>
      </section>

    </div>
  );
};
