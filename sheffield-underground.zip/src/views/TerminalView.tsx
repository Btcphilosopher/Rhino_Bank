import React, { useState, useEffect, useRef } from 'react';
import { Terminal, Zap, Cpu, Server, Activity } from 'lucide-react';
import { lightningService } from '../services/lightningService';

export const TerminalView: React.FC = () => {
  const [input, setInput] = useState('');
  const [logs, setLogs] = useState<string[]>([
    'SHEFFIELD UNDERGROUND TERMINAL OS [v2.4.0-LN-STATION]',
    'Connected to Node: 03a58d1979201948194810a9182a1820... @ 127.0.0.1:9735',
    'Active Lightning Channels: 14 | Total Capacity: 250,000,000 SATS',
    'Type "/help" or "/status" for commands.',
    '------------------------------------------------------------------'
  ]);

  const terminalEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const cmd = input.trim();
    const newLogs = [...logs, `> ${cmd}`];

    if (cmd === '/help') {
      newLogs.push('AVAILABLE COMMANDS:');
      newLogs.push('  /status   - Check Lightning node status & channels');
      newLogs.push('  /mempool  - View Bitcoin mempool & sats/vB fee rate');
      newLogs.push('  /balance  - Print wallet sats balance');
      newLogs.push('  /clear    - Clear terminal logs');
    } else if (cmd === '/status') {
      newLogs.push('⚡ NODE STATUS: ONLINE');
      newLogs.push('⚡ ACTIVE CHANNELS: 14 (100% Routed)');
      newLogs.push('⚡ SYNC STATUS: 100% (BLOCK 892,410)');
    } else if (cmd === '/mempool') {
      newLogs.push('₿ MEMPOOL STATUS: 12 sat/vB (Low Priority) | 18 sat/vB (High Priority)');
    } else if (cmd === '/balance') {
      const w = lightningService.getWalletState();
      newLogs.push(`⚡ WALLET SATS BALANCE: ${w.satsBalance.toLocaleString()} SATS`);
    } else if (cmd === '/clear') {
      setLogs([]);
      setInput('');
      return;
    } else {
      newLogs.push(`Unknown command: "${cmd}". Type /help for assistance.`);
    }

    setLogs(newLogs);
    setInput('');
  };

  return (
    <div className="max-w-6xl mx-auto px-4 md:px-8 py-8 space-y-6 font-mono">
      <div className="flex items-center justify-between border-b border-[#22262e] pb-4">
        <div className="flex items-center gap-2">
          <Terminal className="w-6 h-6 text-[#f59e0b]" />
          <h1 className="text-xl font-black uppercase text-white tracking-widest">
            UNDERGROUND TERMINAL COMMAND CENTRE
          </h1>
        </div>
        <div className="flex items-center gap-2 text-xs text-emerald-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          NODE SYNCED 100%
        </div>
      </div>

      <div className="bg-[#050608] border border-[#22262e] rounded-xl p-6 h-[500px] flex flex-col justify-between shadow-2xl text-xs">
        <div className="overflow-y-auto space-y-1 pr-2 text-emerald-400">
          {logs.map((log, i) => (
            <div key={i} className="leading-relaxed whitespace-pre-wrap">{log}</div>
          ))}
          <div ref={terminalEndRef} />
        </div>

        <form onSubmit={handleCommand} className="flex items-center gap-2 pt-4 border-t border-[#1d212a] mt-4">
          <span className="text-[#f59e0b] font-bold">&gt;</span>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type /help, /status, /balance..."
            className="w-full bg-transparent text-white font-mono text-xs focus:outline-none"
          />
        </form>
      </div>
    </div>
  );
};
