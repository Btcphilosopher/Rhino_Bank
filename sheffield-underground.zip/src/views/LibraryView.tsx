import React, { useState, useEffect } from 'react';
import { lightningService, WalletState } from '../services/lightningService';
import { Download, ShieldCheck, Sparkles, Disc } from 'lucide-react';

export const LibraryView: React.FC = () => {
  const [wallet, setWallet] = useState<WalletState>(lightningService.getWalletState());

  useEffect(() => {
    const unsub = lightningService.subscribe(w => setWallet(w));
    return () => unsub();
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 space-y-8 font-mono">
      <div className="border-b border-[#22262e] pb-6">
        <h1 className="text-3xl font-black text-white uppercase tracking-tight flex items-center gap-3">
          <Disc className="w-8 h-8 text-[#f59e0b]" />
          MY MUSIC LIBRARY & DIGITAL PASSPORTS
        </h1>
        <p className="text-xs text-gray-400 font-sans mt-1">
          Your purchased music collection, lossless WAV master downloads, and signed digital provenance records.
        </p>
      </div>

      {wallet.purchasedPassports.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {wallet.purchasedPassports.map((passport) => (
            <div key={passport.id} className="bg-[#101217] border border-[#f59e0b]/40 rounded-xl p-6 space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-black text-white uppercase">{passport.trackTitle}</h3>
                  <p className="text-xs text-gray-400 font-sans">{passport.artist}</p>
                </div>
                <div className="bg-emerald-500/10 border border-emerald-500/40 text-emerald-400 text-[10px] font-bold px-2 py-1 rounded">
                  PASSPORT VERIFIED
                </div>
              </div>

              <div className="bg-[#181b22] border border-[#2d323c] rounded p-3 text-[10px] space-y-1 font-mono text-gray-300">
                <div>SIGNATURE: <span className="text-[#f59e0b] break-all">{passport.signature}</span></div>
                <div>TX HASH: <span className="text-gray-400 break-all">{passport.txHash}</span></div>
                <div>LICENSE: <span className="text-white">{passport.licenseType}</span></div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-xs text-[#f59e0b] font-bold">{passport.satsAmount.toLocaleString()} SATS PAID</span>
                <a
                  href="#download"
                  onClick={(e) => {
                    e.preventDefault();
                    alert(`Downloading lossless 24-bit WAV master for "${passport.trackTitle}"...`);
                  }}
                  className="bg-[#f59e0b] hover:bg-[#fbbf24] text-black font-black text-xs uppercase px-4 py-2 rounded flex items-center gap-1.5"
                >
                  <Download className="w-4 h-4" />
                  DOWNLOAD WAV
                </a>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-[#101217] border border-dashed border-[#2d323c] rounded-xl p-12 text-center text-gray-500">
          <Sparkles className="w-12 h-12 mx-auto mb-3 text-gray-600" />
          <p className="text-sm font-bold uppercase text-gray-400">NO PURCHASED PASSPORTS YET</p>
          <p className="text-xs font-sans mt-1">Purchases made with Lightning will automatically appear here with digital signed passports.</p>
        </div>
      )}
    </div>
  );
};
