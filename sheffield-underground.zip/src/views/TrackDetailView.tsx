import React, { useState } from 'react';
import { Track } from '../types';
import { Play, Pause, Zap, ShoppingCart, Disc, Sliders, ShieldCheck, Download, ArrowLeft, Heart, Share2 } from 'lucide-react';
import { crateService } from '../services/crateService';
import { audioService } from '../services/audioService';

interface TrackDetailViewProps {
  track: Track;
  onBack: () => void;
  isPlaying: boolean;
  onPlayTrack: (track: Track) => void;
  onPayLightning: (track: Track) => void;
}

export const TrackDetailView: React.FC<TrackDetailViewProps> = ({
  track,
  onBack,
  isPlaying,
  onPlayTrack,
  onPayLightning
}) => {
  const [selectedFormat, setSelectedFormat] = useState<'WAV' | 'MP3' | 'AIFF' | 'FLAC' | 'STEMS'>('WAV');
  const [selectedLicense, setSelectedLicense] = useState<'Standard' | 'DJ Performance' | 'Commercial'>('DJ Performance');

  const handleAddToCart = () => {
    crateService.addToCrate(track, selectedFormat, selectedLicense);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 md:px-8 py-8 space-y-8 font-mono">
      
      {/* Back Button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-xs font-mono text-gray-400 hover:text-white uppercase transition-colors"
      >
        <ArrowLeft className="w-4 h-4 text-[#f59e0b]" />
        BACK TO MARKETPLACE
      </button>

      {/* Main Track Banner & Cover */}
      <div className="bg-[#101217] border border-[#2d323c] rounded-xl p-6 md:p-8 grid grid-cols-1 md:grid-cols-12 gap-8 items-center shadow-2xl">
        
        {/* Cover Artwork */}
        <div className="md:col-span-5 relative aspect-square rounded-lg overflow-hidden bg-[#181b22] border border-[#2d323c]">
          <img
            src={track.coverUrl}
            alt={track.title}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <button
            onClick={() => onPlayTrack(track)}
            className="absolute inset-0 bg-black/50 opacity-0 hover:opacity-100 flex items-center justify-center transition-opacity"
          >
            <div className="w-16 h-16 rounded-full bg-[#f59e0b] text-black flex items-center justify-center shadow-2xl">
              {isPlaying ? <Pause className="w-8 h-8 fill-black" /> : <Play className="w-8 h-8 fill-black ml-1" />}
            </div>
          </button>
        </div>

        {/* Track Metadata & Purchase Action */}
        <div className="md:col-span-7 space-y-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 bg-[#f59e0b]/20 border border-[#f59e0b]/40 text-[#f59e0b] text-xs font-bold px-2.5 py-1 rounded uppercase">
              <Disc className="w-3.5 h-3.5" />
              {track.mixType} • {track.genre}
            </div>

            <h1 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight">
              {track.title}
            </h1>

            <p className="text-base text-gray-300 font-sans">
              Artist: <strong className="text-white">{track.artist}</strong> • Label: <strong className="text-white">{track.label}</strong>
            </p>
          </div>

          {/* Technical DJ Metrics Grid */}
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 bg-[#181b22] border border-[#2d323c] rounded-lg p-4 text-center">
            <div>
              <div className="text-[10px] text-gray-500 uppercase font-bold">BPM</div>
              <div className="text-xl font-black text-[#f59e0b]">{track.bpm}</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase font-bold">KEY / CAMELOT</div>
              <div className="text-xl font-black text-[#f59e0b]">{track.camelotKey}</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase font-bold">ENERGY</div>
              <div className="text-xl font-black text-emerald-400">{track.energyLevel}/10</div>
            </div>
            <div className="hidden sm:block">
              <div className="text-[10px] text-gray-500 uppercase font-bold">INTRO/OUTRO</div>
              <div className="text-sm font-bold text-gray-300">{track.introBars}B / {track.outroBars}B</div>
            </div>
          </div>

          {/* Audio Format Selector */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase text-gray-400 block">
              CHOOSE LOSSLESS AUDIO FORMAT:
            </label>
            <div className="flex flex-wrap gap-2">
              {(['WAV', 'AIFF', 'FLAC', 'MP3', 'STEMS'] as const).map((fmt) => (
                <button
                  key={fmt}
                  onClick={() => setSelectedFormat(fmt)}
                  className={`px-3 py-2 rounded text-xs font-bold uppercase border transition-colors ${
                    selectedFormat === fmt
                      ? 'bg-[#f59e0b] text-black border-[#f59e0b]'
                      : 'bg-[#181b22] text-gray-300 border-[#2d323c] hover:border-gray-500'
                  }`}
                >
                  {fmt} {fmt === 'WAV' && '(24-bit / 44.1kHz)'}
                </button>
              ))}
            </div>
          </div>

          {/* Purchase CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              onClick={() => onPayLightning(track)}
              className="flex-1 bg-[#f59e0b] hover:bg-[#fbbf24] text-black font-black text-sm uppercase py-3.5 px-6 rounded flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(245,158,11,0.3)] transition-all"
            >
              <Zap className="w-4 h-4 fill-black" />
              BUY NOW WITH LIGHTNING ({track.satsPrice.toLocaleString()} SATS)
            </button>

            <button
              onClick={handleAddToCart}
              className="bg-[#181b22] hover:bg-[#252a36] text-white border border-[#3a414e] font-bold text-xs uppercase px-5 py-3.5 rounded flex items-center justify-center gap-2 transition-colors"
            >
              <ShoppingCart className="w-4 h-4 text-[#f59e0b]" />
              ADD TO CRATE
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
