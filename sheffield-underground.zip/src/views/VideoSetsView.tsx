import React, { useState } from 'react';
import { VideoContent } from '../types';
import { MOCK_VIDEOS } from '../data/mockData';
import { Radio, Zap, Eye, Heart, MessageSquare, Play, Share2 } from 'lucide-react';
import { lightningService } from '../services/lightningService';

export const VideoSetsView: React.FC = () => {
  const [selectedVideo, setSelectedVideo] = useState<VideoContent>(MOCK_VIDEOS[0]);
  const [tipSuccessMessage, setTipSuccessMessage] = useState<string | null>(null);

  const handleTip = (amount: number) => {
    const success = lightningService.sendTip(selectedVideo.artistName, amount);
    if (success) {
      setTipSuccessMessage(`⚡ Sent ${amount.toLocaleString()} Sats tip to ${selectedVideo.artistName}!`);
      setTimeout(() => setTipSuccessMessage(null), 3000);
    } else {
      setTipSuccessMessage('Insufficient wallet balance for tip.');
      setTimeout(() => setTipSuccessMessage(null), 3000);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 space-y-8 font-mono">
      
      {/* Header */}
      <div className="border-b border-[#22262e] pb-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-black text-white uppercase tracking-tight flex items-center gap-3">
            <Radio className="w-8 h-8 text-red-500 animate-pulse" />
            LIVE DJ SETS & UNDERGROUND BROADCASTS
          </h1>
          <p className="text-xs text-gray-400 font-sans mt-1">
            Watch recorded festival sets, club recordings, studio broadcasts & tip DJs live with sats.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Video Player & Controls */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Main Video Screen Container */}
          <div className="bg-black rounded-xl overflow-hidden border border-[#2d323c] shadow-2xl relative aspect-video">
            <video
              src={selectedVideo.videoUrl}
              controls
              poster={selectedVideo.thumbnailUrl}
              className="w-full h-full object-cover"
            />
            {selectedVideo.isLive && (
              <div className="absolute top-4 left-4 bg-red-600 text-white font-black text-xs px-3 py-1 rounded flex items-center gap-1.5 uppercase animate-pulse">
                <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                LIVE STREAM
              </div>
            )}
          </div>

          {/* Video Metadata & Tipping Bar */}
          <div className="bg-[#101217] border border-[#22262e] rounded-xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-[#1f242d] pb-4">
              <div>
                <h2 className="text-xl font-black text-white uppercase">
                  {selectedVideo.title}
                </h2>
                <p className="text-xs text-gray-400 font-sans mt-1">
                  Recorded at {selectedVideo.venueName} ({selectedVideo.location})
                </p>
              </div>

              {/* Lightning Tipping Widget */}
              <div className="space-y-2">
                <div className="text-[10px] text-gray-400 uppercase font-bold">
                  ⚡ TIP THE DJ WITH LIGHTNING:
                </div>
                <div className="flex items-center gap-2">
                  {[1000, 5000, 10000].map((sats) => (
                    <button
                      key={sats}
                      onClick={() => handleTip(sats)}
                      className="bg-[#181b22] hover:bg-[#f59e0b] hover:text-black text-[#f59e0b] border border-[#f59e0b]/40 font-bold text-xs px-3 py-1.5 rounded transition-all"
                    >
                      ⚡ {sats.toLocaleString()}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {tipSuccessMessage && (
              <div className="bg-emerald-500/10 border border-emerald-500/40 text-emerald-400 text-xs p-3 rounded text-center font-bold">
                {tipSuccessMessage}
              </div>
            )}

            {/* Tracklist Timestamps */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase text-gray-400">
                SET TRACKLIST TIMESTAMPS:
              </h3>
              <div className="space-y-1.5">
                {selectedVideo.tracklist.map((item, idx) => (
                  <div key={idx} className="bg-[#181b22] border border-[#2d323c] rounded p-2 text-xs flex items-center justify-between">
                    <span className="text-[#f59e0b] font-bold">{item.time}</span>
                    <span className="text-gray-300 font-sans">{item.trackName}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

        {/* Right Column: Other DJ Sets List */}
        <div className="lg:col-span-4 space-y-4">
          <h3 className="text-sm font-bold uppercase text-white">
            EXPLORE SETS & RECORDINGS
          </h3>

          <div className="space-y-3">
            {MOCK_VIDEOS.map((vid) => (
              <div
                key={vid.id}
                onClick={() => setSelectedVideo(vid)}
                className={`bg-[#101217] border rounded-lg p-3 cursor-pointer transition-all flex items-center gap-3 ${
                  selectedVideo.id === vid.id ? 'border-[#f59e0b] bg-[#181b22]' : 'border-[#22262e] hover:border-gray-500'
                }`}
              >
                <div className="relative w-24 aspect-video rounded overflow-hidden bg-black flex-shrink-0">
                  <img src={vid.thumbnailUrl} alt={vid.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    <Play className="w-4 h-4 text-[#f59e0b] fill-[#f59e0b]" />
                  </div>
                </div>

                <div className="min-w-0">
                  <h4 className="text-xs font-bold text-white truncate">{vid.title}</h4>
                  <p className="text-[10px] text-gray-400">{vid.artistName}</p>
                  <p className="text-[9px] text-[#f59e0b] mt-1">{vid.viewsCount.toLocaleString()} VIEWS</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
