export type AudioFormat = 'MP3' | 'WAV' | 'AIFF' | 'FLAC' | 'STEMS';

export type KeySignature = 
  | 'C Minor' | 'C Major' | 'C# Minor' | 'C# Major'
  | 'D Minor' | 'D Major' | 'Eb Minor' | 'Eb Major'
  | 'E Minor' | 'E Major' | 'F Minor' | 'F Major'
  | 'F# Minor' | 'F# Major' | 'G Minor' | 'G Major'
  | 'Ab Minor' | 'Ab Major' | 'A Minor' | 'A Major'
  | 'Bb Minor' | 'Bb Major' | 'B Minor' | 'B Major';

export type CamelotKey = 
  | '1A' | '1B' | '2A' | '2B' | '3A' | '3B' | '4A' | '4B'
  | '5A' | '5B' | '6A' | '6B' | '7A' | '7B' | '8A' | '8B'
  | '9A' | '9B' | '10A' | '10B' | '11A' | '11B' | '12A' | '12B';

export type Genre = 
  | 'Techno' 
  | 'Deep House' 
  | 'House' 
  | 'Acid' 
  | 'Industrial' 
  | 'Drum & Bass' 
  | 'Garage' 
  | 'Breakbeat' 
  | 'Electro' 
  | 'Trance' 
  | 'Ambient' 
  | 'Hardcore';

export interface StemTrack {
  id: string;
  name: string; // e.g. 'Drums', 'Bass', 'Synths', 'Vocals'
  color: string;
  muted: boolean;
  volume: number;
}

export interface Track {
  id: string;
  title: string;
  artist: string;
  artistId: string;
  label: string;
  labelId: string;
  genre: Genre;
  subgenre?: string;
  bpm: number;
  key: KeySignature;
  camelotKey: CamelotKey;
  energyLevel: number; // 1 - 10
  danceability: number; // 1 - 10
  duration: number; // seconds
  releaseDate: string;
  satsPrice: number;
  fiatApprox: string;
  coverUrl: string;
  previewAudioUrl: string; // Web Audio synth preset or audio sample
  isDjReady: boolean;
  mixType: 'Original Mix' | 'Extended Mix' | 'Dub' | 'Radio Edit' | 'Remix' | 'Acapella' | 'DJ Tool' | 'Stem Pack';
  introBars: number;
  outroBars: number;
  breakdownSec: number;
  dropSec: number;
  waveformPeaks: number[]; // 50-100 normalized points
  stems?: StemTrack[];
  downloadsCount: number;
  playsCount: number;
  isrc?: string;
}

export interface Album {
  id: string;
  title: string;
  artist: string;
  artistId: string;
  label: string;
  coverUrl: string;
  releaseDate: string;
  genre: Genre;
  satsPrice: number;
  tracksCount: number;
  trackIds: string[];
  description: string;
}

export interface Artist {
  id: string;
  name: string;
  handle: string;
  avatarUrl: string;
  bannerUrl: string;
  location: string;
  bio: string;
  genres: Genre[];
  followersCount: number;
  monthlyListeners: number;
  totalSatsEarned: number;
  lightningAddress: string;
  isVerified: boolean;
  equipmentUsed: string[];
  socials: {
    soundcloud?: string;
    instagram?: string;
    residentAdvisor?: string;
    spotify?: string;
  };
}

export interface Label {
  id: string;
  name: string;
  logoUrl: string;
  bannerUrl: string;
  location: string;
  description: string;
  releaseCount: number;
  artistIds: string[];
}

export interface EquipmentProduct {
  id: string;
  name: string;
  brand: string;
  category: 'CDJ & Media Players' | 'Mixers' | 'Turntables' | 'Synths & Samplers' | 'Headphones' | 'Studio Monitors' | 'Controllers' | 'Hardware';
  condition: 'Brand New' | 'Mint' | 'Ex-Demo' | 'Used - Like New' | 'Used - Good';
  satsPrice: number;
  fiatPrice: string;
  imageUrl: string;
  description: string;
  specs: { [key: string]: string };
  sellerName: string;
  sellerLocation: string;
  isUsed: boolean;
  stockCount: number;
  rating: number;
}

export interface VideoContent {
  id: string;
  title: string;
  artistName: string;
  venueName: string;
  location: string;
  thumbnailUrl: string;
  videoUrl: string;
  duration: string;
  viewsCount: number;
  likesCount: number;
  satsPriceToBuy?: number;
  isLive: boolean;
  recordedDate: string;
  tracklist: { time: string; trackName: string }[];
}

export interface EventItem {
  id: string;
  title: string;
  venue: string;
  location: string;
  date: string;
  time: string;
  imageUrl: string;
  lineup: string[];
  satsTicketPrice: number;
  availableTickets: number;
  description: string;
}

export interface SamplePack {
  id: string;
  title: string;
  producerName: string;
  coverUrl: string;
  genre: Genre;
  samplesCount: number;
  sizeMb: number;
  satsPrice: number;
  description: string;
  format: string; // e.g., '24-bit WAV / 44.1kHz'
}

export interface DigitalPassport {
  id: string;
  trackId: string;
  trackTitle: string;
  artist: string;
  purchaseDate: string;
  satsAmount: number;
  txHash: string;
  signature: string;
  licenseType: 'DJ Performance & Commercial Broadcast' | 'Personal DJ Crate' | 'Stems Remix License';
  format: AudioFormat;
  downloadUrl: string;
}

export interface LightningInvoice {
  id: string;
  paymentRequest: string; // lnbc...
  satsAmount: number;
  fiatApprox: string;
  description: string;
  expiresAt: number; // timestamp
  status: 'PENDING' | 'EXPIRED' | 'PAID';
  txHash?: string;
  createdAt: number;
}

export type ActiveTab = 
  | 'home' 
  | 'music' 
  | 'track_detail'
  | 'dj_pool' 
  | 'video' 
  | 'equipment' 
  | 'samples' 
  | 'events' 
  | 'artist_profile' 
  | 'label_profile' 
  | 'library' 
  | 'creator_studio' 
  | 'terminal'
  | 'charts';
