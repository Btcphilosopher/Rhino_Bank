import React, { useState, useEffect } from 'react';
import { X, Zap, ArrowDownLeft, ArrowUpRight, Copy, Check, Download, ShieldCheck, Plus, RefreshCw } from 'lucide-react';
import { lightningService, WalletState } from '../services/lightningService';

interface WalletDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WalletDrawer: React.FC<WalletDrawerProps> = ({ isOpen, onClose }) => {
  const [wallet, setWallet] = useState<WalletState>(lightningService.getWalletState());
  const [copied, setCopied] = useState(false);
  const [depositSats, setDepositSats] = useState('10000');

  useEffect(() => {
    const unsub = lightningService.subscribe(w => setWallet(w));
    return () => unsub();
  }, []);

  if (!isOpen) return null;

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(wallet.lightningAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTopUp = () => {
    const amount = parseInt(depositSats, 10);
    if (!isNaN(amount) && amount > 0) {
      lightningService.depositSats(amount);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-end">
      <div className="bg-[#0D0D0D] border-l border-[#222] w-full max-w-md h-full flex flex-col p-6 text-white font-mono space-y-6 overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#222] pb-4">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-[#FFD700] fill-[#FFD700]" />
            <h3 className="text-sm font-black uppercase text-white tracking-widest italic">
              BITCOIN LIGHTNING WALLET
            </h3>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Balance Card */}
        <div className="bg-[#151515] border border-[#222] rounded-xl p-5 space-y-3 relative overflow-hidden">
          <div className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">
            AVAILABLE SATS BALANCE
          </div>
          <div className="text-3xl font-black text-[#FFD700]">
            {wallet.satsBalance.toLocaleString()} <span className="text-sm text-gray-400">SATS</span>
          </div>
          <div className="text-xs text-gray-400">
            ≈ {lightningService.satsToFiat(wallet.satsBalance, 'GBP')} GBP / {lightningService.satsToFiat(wallet.satsBalance, 'USD')} USD
          </div>

          <div className="pt-2 flex items-center justify-between text-[11px] text-gray-400 border-t border-[#222]">
            <span>LIGHTNING ADDRESS:</span>
            <button
              onClick={handleCopyAddress}
              className="text-[#FFD700] hover:underline flex items-center gap-1 font-bold"
            >
              {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              {wallet.lightningAddress}
            </button>
          </div>
        </div>

        {/* Top Up Sats Simulation */}
        <div className="bg-[#111] border border-[#222] rounded-lg p-4 space-y-3">
          <h4 className="text-xs font-bold uppercase text-white flex items-center gap-1.5">
            <Plus className="w-4 h-4 text-[#FFD700]" />
            TOP UP WALLET BALANCE
          </h4>
          <div className="flex items-center gap-2">
            <input
              type="number"
              value={depositSats}
              onChange={(e) => setDepositSats(e.target.value)}
              className="bg-[#181818] border border-[#333] rounded px-3 py-2 text-xs font-mono text-white w-full focus:outline-none focus:border-[#FFD700]"
            />
            <button
              onClick={handleTopUp}
              className="bg-[#FFD700] hover:bg-[#ffe033] text-black font-black text-xs px-4 py-2 rounded uppercase flex-shrink-0"
            >
              DEPOSIT SATS
            </button>
          </div>
        </div>

        {/* Recent Transactions List */}
        <div className="flex-1 space-y-3 min-h-[200px]">
          <h4 className="text-xs font-bold uppercase text-gray-400">
            RECENT LIGHTNING ACTIVITY
          </h4>

          <div className="space-y-2">
            {wallet.transactions.map((tx) => (
              <div key={tx.id} className="bg-[#111] border border-[#222] rounded p-3 space-y-1">
                <div className="flex justify-between items-start text-xs">
                  <span className="font-bold text-white flex items-center gap-1">
                    {tx.type === 'DEPOSIT' || tx.type === 'EARNING' ? (
                      <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <ArrowUpRight className="w-3.5 h-3.5 text-[#FFD700]" />
                    )}
                    {tx.description}
                  </span>
                  <span className={`font-bold ${tx.type === 'DEPOSIT' ? 'text-emerald-400' : 'text-[#FFD700]'}`}>
                    {tx.type === 'DEPOSIT' ? '+' : '-'}{tx.satsAmount.toLocaleString()} SATS
                  </span>
                </div>
                <div className="flex justify-between text-[10px] text-gray-500">
                  <span>{new Date(tx.timestamp).toLocaleTimeString()}</span>
                  <span className="truncate max-w-[150px]">{tx.txHash.substring(0, 16)}...</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
