import React from 'react';
import { Play, Pause, ShoppingCart, Zap, Disc } from 'lucide-react';
import { Track } from '../types';
import { crateService } from '../services/crateService';

interface TrackListRowProps {
  rank?: number;
  track: Track;
  isPlaying: boolean;
  onPlay: (track: Track) => void;
  onSelectTrack: (track: Track) => void;
}

export const TrackListRow: React.FC<TrackListRowProps> = ({
  rank,
  track,
  isPlaying,
  onPlay,
  onSelectTrack
}) => {
  return (
    <div 
      onClick={() => onSelectTrack(track)}
      className="group bg-[#0D0D0D] hover:bg-[#151515] border border-[#222] hover:border-[#FFD700]/40 rounded-lg p-2.5 transition-all flex items-center justify-between gap-3 cursor-pointer select-none"
    >
      {/* Left Rank & Artwork & Title */}
      <div className="flex items-center gap-3 min-w-0">
        {rank !== undefined && (
          <span className="w-5 text-center font-mono font-black text-sm text-[#666] group-hover:text-[#FFD700]">
            {rank}
          </span>
        )}

        <div className="relative w-11 h-11 rounded bg-[#181818] overflow-hidden flex-shrink-0">
          <img
            src={track.coverUrl}
            alt={track.title}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <button
            onClick={(e) => {
              e.stopPropagation();
              onPlay(track);
            }}
            className={`absolute inset-0 bg-black/60 flex items-center justify-center transition-opacity ${
              isPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
            }`}
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 text-[#FFD700] fill-[#FFD700]" />
            ) : (
              <Play className="w-4 h-4 text-[#FFD700] fill-[#FFD700] ml-0.5" />
            )}
          </button>
        </div>

        <div className="min-w-0">
          <h5 className="font-mono font-bold text-xs text-white truncate group-hover:text-[#FFD700] transition-colors">
            {track.title}
          </h5>
          <p className="text-[11px] text-gray-400 truncate">
            {track.artist}
          </p>
          <div className="flex items-center gap-2 text-[10px] font-mono text-gray-500">
            <span>{track.mixType}</span>
            <span>•</span>
            <span className="text-gray-300 font-semibold">{track.bpm} BPM</span>
            <span>•</span>
            <span className="text-[#FFD700]">{track.camelotKey}</span>
          </div>
        </div>
      </div>

      {/* Right Price & Add to Crate */}
      <div className="flex items-center gap-3 flex-shrink-0">
        <div className="text-right hidden sm:block">
          <div className="font-mono font-bold text-xs text-[#FFD700] flex items-center justify-end gap-1">
            <Zap className="w-3 h-3 fill-[#FFD700]" />
            {track.satsPrice.toLocaleString()} SATS
          </div>
          <div className="text-[10px] text-gray-500 font-mono">
            {track.fiatApprox}
          </div>
        </div>

        <button
          onClick={(e) => {
            e.stopPropagation();
            crateService.addToCrate(track);
          }}
          className="bg-[#181818] hover:bg-[#FFD700] hover:text-black text-gray-300 p-2 rounded border border-[#333] transition-colors"
          title="Add to DJ Crate"
        >
          <ShoppingCart className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
