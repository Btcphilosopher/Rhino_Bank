import React, { useState, useEffect, useRef } from 'react';
import { X, Play, Pause, Repeat, Sliders, Volume2, Disc, Zap, ArrowRight, ShieldCheck, Download } from 'lucide-react';
import { Track } from '../types';
import { audioService, AudioState } from '../services/audioService';
import { MOCK_TRACKS } from '../data/mockData';

interface DjModeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTrack: (track: Track) => void;
}

export const DjModeModal: React.FC<DjModeModalProps> = ({
  isOpen,
  onClose,
  onSelectTrack
}) => {
  const [audioState, setAudioState] = useState<AudioState>(audioService.getState());
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const unsub = audioService.subscribe((s) => setAudioState(s));
    return () => unsub();
  }, []);

  // Visualizer loop for DJ Mode
  useEffect(() => {
    if (!isOpen) return;
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const freqData = new Uint8Array(64);

    const render = () => {
      audioService.getFrequencyData(freqData);
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw dual stereo spectrum lines
      const width = canvas.width;
      const height = canvas.height;
      const barWidth = width / freqData.length;

      ctx.beginPath();
      ctx.moveTo(0, height / 2);

      for (let i = 0; i < freqData.length; i++) {
        const val = freqData[i];
        const amp = (val / 255) * (height / 2.2);
        const x = i * barWidth;
        const y = height / 2 - amp;
        ctx.lineTo(x, y);
      }

      ctx.strokeStyle = '#FFD700';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Mirror bottom
      ctx.beginPath();
      ctx.moveTo(0, height / 2);
      for (let i = 0; i < freqData.length; i++) {
        const val = freqData[i];
        const amp = (val / 255) * (height / 2.2);
        const x = i * barWidth;
        const y = height / 2 + amp;
        ctx.lineTo(x, y);
      }
      ctx.strokeStyle = 'rgba(255, 215, 0, 0.4)';
      ctx.lineWidth = 1;
      ctx.stroke();

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [isOpen, audioState.isPlaying]);

  if (!isOpen) return null;

  const track = audioState.currentTrack || MOCK_TRACKS[0];

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0A0A0A] text-white flex flex-col overflow-hidden font-mono select-none">
      
      {/* Top Workstation Header */}
      <div className="bg-[#0D0D0D] border-b border-[#222] px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-[#FFD700] text-black font-black flex items-center justify-center font-mono">
            <Disc className="w-5 h-5 animate-spin" />
          </div>
          <div>
            <h2 className="text-lg font-black uppercase text-white tracking-widest flex items-center gap-2 italic">
              SHEFFIELD DJ WORKSTATION <span className="text-[#FFD700] text-xs font-normal not-italic">v2.4 PRO</span>
            </h2>
            <p className="text-xs text-gray-400">
              Harmonic Key & Beat Grid Waveform Analysis Terminal
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="bg-[#151515] hover:bg-[#222] p-2 rounded text-gray-400 hover:text-white transition-colors"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      {/* Main DJ Deck & Waveform Section */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        
        {/* Track Title & Technical Metrics */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center bg-[#111] border border-[#222] rounded-xl p-6">
          <div className="lg:col-span-8 flex items-center gap-5">
            <img
              src={track.coverUrl}
              alt={track.title}
              className="w-24 h-24 rounded-lg object-cover border border-[#222]"
              referrerPolicy="no-referrer"
            />
            <div className="space-y-1">
              <div className="inline-block bg-[#FFD700]/20 border border-[#FFD700]/40 text-[#FFD700] text-[10px] font-bold px-2 py-0.5 rounded uppercase">
                {track.mixType} • {track.genre}
              </div>
              <h1 className="text-2xl font-black text-white uppercase tracking-tight italic">
                {track.title}
              </h1>
              <p className="text-sm text-gray-400 font-sans">
                {track.artist} — <span className="text-gray-500">{track.label}</span>
              </p>
              <div className="flex items-center gap-4 text-xs pt-1 text-gray-400">
                <span>ISRC: <strong className="text-gray-200">{track.isrc}</strong></span>
                <span>Intro: <strong className="text-gray-200">{track.introBars} bars</strong></span>
                <span>Outro: <strong className="text-gray-200">{track.outroBars} bars</strong></span>
              </div>
            </div>
          </div>

          {/* Key & BPM Readout Terminal */}
          <div className="lg:col-span-4 grid grid-cols-3 gap-3 text-center">
            <div className="bg-[#181818] border border-[#222] rounded p-3">
              <div className="text-[10px] text-gray-500 font-bold uppercase">BPM</div>
              <div className="text-2xl font-black text-[#FFD700]">{track.bpm}</div>
            </div>
            <div className="bg-[#181818] border border-[#222] rounded p-3">
              <div className="text-[10px] text-gray-500 font-bold uppercase">CAMELOT KEY</div>
              <div className="text-2xl font-black text-[#FFD700]">{track.camelotKey}</div>
            </div>
            <div className="bg-[#181818] border border-[#222] rounded p-3">
              <div className="text-[10px] text-gray-500 font-bold uppercase">ENERGY</div>
              <div className="text-2xl font-black text-emerald-400">{track.energyLevel}/10</div>
            </div>
          </div>
        </div>

        {/* Dual Deck Waveform Visualizer */}
        <div className="bg-[#111] border border-[#222] rounded-xl p-6 space-y-4">
          <div className="flex justify-between items-center text-xs text-gray-400">
            <span className="font-bold uppercase text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#FFD700]" />
              SPECTRUM FREQUENCY & BEAT GRID WAVEFORM
            </span>
            <div className="flex gap-4">
              <span>BREAKDOWN: <strong className="text-[#FFD700]">{formatTime(track.breakdownSec)}</strong></span>
              <span>DROP: <strong className="text-[#FFD700]">{formatTime(track.dropSec)}</strong></span>
            </div>
          </div>

          {/* Dual Spectrum Canvas */}
          <div className="w-full h-32 bg-[#050505] rounded border border-[#222] overflow-hidden relative">
            <canvas ref={canvasRef} width={1200} height={128} className="w-full h-full" />
            
            {/* Beat Grid Lines */}
            <div className="absolute inset-0 pointer-events-none flex justify-between opacity-20">
              {Array.from({ length: 32 }).map((_, i) => (
                <div key={i} className="h-full w-px bg-white" />
              ))}
            </div>

            {/* Playhead Marker */}
            <div 
              className="absolute top-0 bottom-0 w-0.5 bg-red-500 shadow-[0_0_10px_red]"
              style={{ left: `${(audioState.currentTime / audioState.duration) * 100}%` }}
            />
          </div>

          {/* Waveform Seek Slider */}
          <input
            type="range"
            min={0}
            max={track.duration || 180}
            value={audioState.currentTime}
            onChange={(e) => audioService.seek(parseFloat(e.target.value))}
            className="w-full h-2 bg-[#222] accent-[#FFD700] rounded cursor-pointer"
          />

          {/* Transport Controls */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
            <div className="flex items-center gap-2">
              <button
                onClick={() => audioService.togglePlayPause()}
                className="bg-[#FFD700] hover:bg-[#ffe033] text-black font-black px-6 py-2.5 rounded text-sm flex items-center gap-2 shadow-lg"
              >
                {audioState.isPlaying ? <Pause className="w-4 h-4 fill-black" /> : <Play className="w-4 h-4 fill-black" />}
                {audioState.isPlaying ? 'PAUSE' : 'PLAY DECK'}
              </button>

              <button
                onClick={() => audioService.setLoopA()}
                className="bg-[#181818] hover:bg-[#222] text-white px-3 py-2.5 rounded text-xs border border-[#333]"
              >
                IN (A)
              </button>
              <button
                onClick={() => audioService.setLoopB()}
                className="bg-[#181818] hover:bg-[#222] text-white px-3 py-2.5 rounded text-xs border border-[#333]"
              >
                OUT (B)
              </button>
              <button
                onClick={() => audioService.clearLoop()}
                className="bg-[#181818] hover:bg-[#222] text-gray-400 px-3 py-2.5 rounded text-xs"
              >
                CLEAR LOOP
              </button>
            </div>

            {/* Hot Cues 1-4 */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-500 font-bold">HOT CUES:</span>
              {[1, 2, 3, 4].map((num) => (
                <button
                  key={num}
                  onClick={() => audioService.setCuePoint((track.duration / 4) * (num - 1))}
                  className="w-9 h-9 rounded bg-[#181818] hover:bg-[#FFD700] hover:text-black border border-[#333] text-white text-xs font-bold transition-colors"
                >
                  {num}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Stems Mixer Module */}
        {track.stems && (
          <div className="bg-[#111] border border-[#222] rounded-xl p-6 space-y-4">
            <h3 className="text-sm font-bold uppercase text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#FFD700]" />
              STEMS MULTI-TRACK MIXER
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {track.stems.map((stem) => (
                <div key={stem.id} className="bg-[#181818] border border-[#222] rounded p-4 space-y-3">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-gray-200">{stem.name}</span>
                    <span className="text-[10px] text-[#FFD700]">{stem.volume}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    defaultValue={stem.volume}
                    className="w-full h-1.5 bg-[#111] accent-[#FFD700] rounded"
                  />
                  <button className="w-full py-1 bg-[#111] border border-[#222] rounded text-[10px] text-gray-400 hover:text-white uppercase font-bold">
                    MUTE STEM
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
