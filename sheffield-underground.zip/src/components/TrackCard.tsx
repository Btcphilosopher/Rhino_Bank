import React from 'react';
import { Play, Pause, ShoppingCart, Zap, Disc } from 'lucide-react';
import { Track } from '../types';
import { crateService } from '../services/crateService';
import { audioService } from '../services/audioService';

interface TrackCardProps {
  track: Track;
  isPlaying: boolean;
  onPlay: (track: Track) => void;
  onSelectTrack: (track: Track) => void;
}

export const TrackCard: React.FC<TrackCardProps> = ({
  track,
  isPlaying,
  onPlay,
  onSelectTrack
}) => {
  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    crateService.addToCrate(track, 'WAV', 'DJ Performance');
  };

  return (
    <div 
      onClick={() => onSelectTrack(track)}
      className="group bg-[#111111] border border-[#222] hover:border-[#FFD700]/60 rounded-lg p-3 transition-all hover:bg-[#161616] cursor-pointer flex flex-col justify-between relative shadow-lg hover:shadow-[0_0_20px_rgba(255,215,0,0.15)]"
    >
      {/* Artwork Container */}
      <div className="relative aspect-square rounded-md overflow-hidden bg-[#181818] mb-3">
        <img
          src={track.coverUrl}
          alt={track.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          referrerPolicy="no-referrer"
        />
        
        {/* Play Overlay */}
        <div 
          onClick={(e) => {
            e.stopPropagation();
            onPlay(track);
          }}
          className={`absolute inset-0 bg-black/60 flex items-center justify-center transition-opacity ${
            isPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
          }`}
        >
          <div className="w-12 h-12 rounded-full bg-[#FFD700] text-black flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform">
            {isPlaying ? (
              <Pause className="w-6 h-6 fill-black" />
            ) : (
              <Play className="w-6 h-6 fill-black ml-0.5" />
            )}
          </div>
        </div>

        {/* DJ Ready Badge */}
        {track.isDjReady && (
          <div className="absolute top-2 left-2 bg-black/90 border border-[#FFD700]/40 backdrop-blur-sm text-[#FFD700] text-[9px] font-mono font-bold px-2 py-0.5 rounded flex items-center gap-1 uppercase">
            <Disc className="w-3 h-3" />
            DJ READY
          </div>
        )}

        {/* Key Badge */}
        <div className="absolute bottom-2 right-2 bg-black/90 text-white text-[10px] font-mono font-bold px-2 py-0.5 rounded border border-[#333]">
          {track.camelotKey} ({track.key})
        </div>
      </div>

      {/* Info */}
      <div className="space-y-1">
        <h4 className="text-sm font-bold font-mono text-white truncate group-hover:text-[#FFD700] transition-colors">
          {track.title}
        </h4>
        <p className="text-xs text-gray-400 font-sans truncate">
          {track.artist}
        </p>
        <div className="flex items-center justify-between text-[11px] font-mono text-gray-500 pt-1">
          <span>{track.mixType}</span>
          <span className="text-gray-300 font-semibold">{track.bpm} BPM</span>
        </div>
      </div>

      {/* Price & Crate Action */}
      <div className="mt-3 pt-2 border-t border-[#222] flex items-center justify-between">
        <div className="flex items-center gap-1 text-[#FFD700] font-mono font-bold text-xs">
          <Zap className="w-3.5 h-3.5 fill-[#FFD700]" />
          <span>{track.satsPrice.toLocaleString()} SATS</span>
        </div>

        <button
          onClick={handleAddToCart}
          className="bg-[#1a1a1a] hover:bg-[#FFD700] hover:text-black text-gray-300 p-2 rounded border border-[#333] transition-colors"
          title="Add to DJ Crate"
        >
          <ShoppingCart className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
