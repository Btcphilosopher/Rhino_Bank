import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Repeat, Disc, Zap, Maximize2, Sliders } from 'lucide-react';
import { audioService, AudioState } from '../services/audioService';
import { Track } from '../types';

interface AudioPlayerProps {
  onOpenDjMode: () => void;
  onOpenTrackDetail: (track: Track) => void;
  onPayLightning: (track: Track) => void;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({
  onOpenDjMode,
  onOpenTrackDetail,
  onPayLightning
}) => {
  const [audioState, setAudioState] = useState<AudioState>(audioService.getState());
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const unsub = audioService.subscribe((s) => setAudioState(s));
    return () => unsub();
  }, []);

  // Audio spectrum visualizer animation loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const freqData = new Uint8Array(32);

    const render = () => {
      audioService.getFrequencyData(freqData);
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const barWidth = (canvas.width / freqData.length) - 1;
      for (let i = 0; i < freqData.length; i++) {
        const val = freqData[i];
        const barHeight = (val / 255) * canvas.height;
        ctx.fillStyle = audioState.isPlaying ? '#FFD700' : '#444444';
        ctx.fillRect(i * (barWidth + 1), canvas.height - barHeight, barWidth, barHeight);
      }

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [audioState.isPlaying]);

  const track = audioState.currentTrack;
  if (!track) return null;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-[#0D0D0D]/95 backdrop-blur-lg border-t border-[#FFD700]/30 text-white p-3 shadow-2xl">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Track Info */}
        <div className="flex items-center gap-3 w-full md:w-1/4">
          <div 
            onClick={() => onOpenTrackDetail(track)}
            className="relative w-12 h-12 rounded bg-[#181818] overflow-hidden flex-shrink-0 cursor-pointer group border border-[#222]"
          >
            <img
              src={track.coverUrl}
              alt={track.title}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
              <Maximize2 className="w-4 h-4 text-[#FFD700]" />
            </div>
          </div>

          <div className="min-w-0 flex-1">
            <div 
              onClick={() => onOpenTrackDetail(track)}
              className="font-mono font-bold text-xs text-white truncate cursor-pointer hover:text-[#FFD700] transition-colors"
            >
              {track.title}
            </div>
            <div className="text-[11px] text-gray-400 truncate">
              {track.artist}
            </div>
            <div className="flex items-center gap-2 text-[10px] font-mono text-[#FFD700]">
              <span>{track.bpm} BPM</span>
              <span>•</span>
              <span>{track.camelotKey}</span>
            </div>
          </div>
        </div>

        {/* Center Controls & Seekbar */}
        <div className="flex-1 w-full max-w-xl space-y-1.5">
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={() => audioService.toggleLoop()}
              className={`p-1.5 rounded text-xs font-mono transition-colors ${
                audioState.isLooping ? 'text-[#FFD700] bg-[#FFD700]/20 font-bold' : 'text-gray-400 hover:text-white'
              }`}
              title="Toggle Loop"
            >
              <Repeat className="w-4 h-4" />
            </button>

            <button
              onClick={() => audioService.seek(0)}
              className="text-gray-400 hover:text-white transition-colors"
              title="Cue Start"
            >
              <SkipBack className="w-4 h-4" />
            </button>

            <button
              onClick={() => audioService.togglePlayPause()}
              className="w-10 h-10 rounded-full bg-[#FFD700] text-black flex items-center justify-center shadow-[0_0_15px_rgba(255,215,0,0.3)] hover:scale-105 active:scale-95 transition-all"
            >
              {audioState.isPlaying ? (
                <Pause className="w-5 h-5 fill-black" />
              ) : (
                <Play className="w-5 h-5 fill-black ml-0.5" />
              )}
            </button>

            <button
              onClick={() => audioService.seek(audioState.duration)}
              className="text-gray-400 hover:text-white transition-colors"
              title="Skip End"
            >
              <SkipForward className="w-4 h-4" />
            </button>

            {/* Spectrum Visualizer Canvas */}
            <div className="w-24 h-6 bg-[#111] rounded border border-[#222] overflow-hidden hidden sm:block">
              <canvas ref={canvasRef} width={96} height={24} className="w-full h-full" />
            </div>
          </div>

          {/* Progress Seek Bar */}
          <div className="flex items-center gap-2 text-[10px] font-mono text-gray-400">
            <span>{formatTime(audioState.currentTime)}</span>
            <input
              type="range"
              min={0}
              max={audioState.duration || 100}
              value={audioState.currentTime}
              onChange={(e) => audioService.seek(parseFloat(e.target.value))}
              className="w-full h-1.5 bg-[#222] accent-[#FFD700] rounded-lg cursor-pointer"
            />
            <span>{formatTime(audioState.duration)}</span>
          </div>
        </div>

        {/* Right Pitch & DJ Workstation & Buy Lightning Button */}
        <div className="flex items-center gap-3 justify-end w-full md:w-auto">
          
          {/* Pitch Control */}
          <div className="hidden lg:flex items-center gap-1.5 bg-[#151515] border border-[#333] px-2 py-1 rounded text-[10px] font-mono">
            <span className="text-gray-400">PITCH:</span>
            <span className="text-[#FFD700] font-bold">
              {((audioState.playbackRate - 1) * 100).toFixed(1)}%
            </span>
            <input
              type="range"
              min={0.8}
              max={1.2}
              step={0.01}
              value={audioState.playbackRate}
              onChange={(e) => audioService.setPlaybackRate(parseFloat(e.target.value))}
              className="w-16 h-1 bg-[#222] accent-[#FFD700] rounded cursor-pointer"
            />
          </div>

          {/* Fullscreen DJ Mode Trigger */}
          <button
            onClick={onOpenDjMode}
            className="bg-[#151515] hover:bg-[#222] border border-[#333] text-[#FFD700] text-xs font-mono font-bold px-3 py-1.5 rounded flex items-center gap-1.5 transition-colors"
            title="Launch Fullscreen DJ Mode Workstation"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>DJ MODE</span>
          </button>

          {/* Quick Buy with Lightning */}
          <button
            onClick={() => onPayLightning(track)}
            className="bg-[#FFD700] hover:bg-[#ffe033] text-black text-xs font-mono font-bold px-3 py-1.5 rounded flex items-center gap-1 shadow-md transition-all"
          >
            <Zap className="w-3.5 h-3.5 fill-black" />
            <span>BUY {track.satsPrice.toLocaleString()} SATS</span>
          </button>

        </div>

      </div>
    </div>
  );
};
