import React, { useState } from 'react';
import { Play, Zap, Info, ShieldCheck, ArrowRight, Music, Radio } from 'lucide-react';
import { Track } from '../types';

interface HeroProps {
  onBrowseClick: () => void;
  onListenMixesClick: () => void;
  onPayLightningClick: () => void;
  featuredTrack: Track;
  onPlayTrack: (track: Track) => void;
}

export const Hero: React.FC<HeroProps> = ({
  onBrowseClick,
  onListenMixesClick,
  onPayLightningClick,
  featuredTrack,
  onPlayTrack
}) => {
  const [selectedLicense, setSelectedLicense] = useState('standard');

  return (
    <section className="relative bg-[#0A0A0A] border-b border-[#222] overflow-hidden">
      {/* Background Nocturnal Industrial Image Overlay */}
      <div className="absolute inset-0 z-0 opacity-30 mix-blend-luminosity">
        <img
          src="https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=1920&auto=format&fit=crop&q=80"
          alt="Sheffield Nocturnal Skyline"
          className="w-full h-full object-cover object-center filter contrast-125 saturate-50"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0A0A0A] via-[#0A0A0A]/80 to-[#0A0A0A]/90" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-transparent to-[#0A0A0A]/60" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-8 py-12 md:py-20 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        
        {/* Left Column: Headline & Branding */}
        <div className="lg:col-span-7 space-y-6">
          <div className="inline-flex items-center gap-2 bg-[#FFD700]/10 border border-[#FFD700]/30 px-3 py-1 rounded text-[11px] font-mono text-[#FFD700] uppercase tracking-widest font-semibold">
            <span className="w-2 h-2 rounded-full bg-[#FFD700] animate-ping" />
            BITCOIN-NATIVE ELECTRONIC MUSIC MARKETPLACE
          </div>

          <h1 className="text-4xl sm:text-6xl xl:text-7xl font-black tracking-tighter text-white uppercase leading-[0.9] italic font-mono">
            SHEFFIELD <br />
            SOUND. <br />
            <span className="text-[#FFD700] drop-shadow-[0_0_25px_rgba(255,215,0,0.3)]">
              GLOBAL ENERGY.
            </span>
          </h1>

          <p className="text-gray-300 text-base sm:text-lg max-w-xl font-sans font-light leading-relaxed">
            Underground EDM. Built in Sheffield. Played everywhere.
            Discover, buy, and download lossless WAV, Stems, and DJ tools directly from independent producers over Bitcoin Lightning.
          </p>

          <div className="flex flex-wrap items-center gap-4 pt-2">
            <button
              onClick={onBrowseClick}
              className="bg-[#FFD700] hover:bg-[#ffe033] text-black font-black font-mono text-sm uppercase tracking-widest px-6 py-3.5 rounded flex items-center gap-2 shadow-[0_0_25px_rgba(255,215,0,0.3)] transition-all hover:scale-105 active:scale-95"
            >
              <Music className="w-4 h-4 fill-black" />
              BROWSE TRACKS
            </button>

            <button
              onClick={onListenMixesClick}
              className="bg-[#151515] hover:bg-[#222] border border-[#333] text-white font-bold font-mono text-sm uppercase tracking-widest px-6 py-3.5 rounded flex items-center gap-2 transition-all hover:border-[#FFD700]"
            >
              <Radio className="w-4 h-4 text-[#FFD700]" />
              LISTEN TO MIXES
            </button>
          </div>
        </div>

        {/* Right Column: Quick Lightning Purchase Widget (Matching Mockup) */}
        <div className="lg:col-span-5">
          <div className="bg-[#111111]/95 border border-[#222] rounded-xl p-6 shadow-2xl relative overflow-hidden backdrop-blur-md">
            
            {/* Top Voltage Badge */}
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-lg font-black font-mono uppercase text-white tracking-wide italic">
                  BUY TRACKS. SUPPORT ARTISTS.
                </h3>
                <p className="text-xs text-gray-400 font-mono mt-1">
                  Pay instantly with Bitcoin Lightning.
                </p>
              </div>
              <div className="w-10 h-10 rounded-lg bg-[#FFD700]/10 border border-[#FFD700]/40 flex items-center justify-center text-[#FFD700]">
                <Zap className="w-6 h-6 fill-[#FFD700]" />
              </div>
            </div>

            {/* License Selection dropdown */}
            <div className="space-y-3 mb-6">
              <label className="text-xs font-mono font-bold uppercase text-gray-300 block tracking-wider">
                SELECT LICENSE
              </label>
              <div className="relative">
                <select
                  value={selectedLicense}
                  onChange={(e) => setSelectedLicense(e.target.value)}
                  className="w-full bg-[#181818] border border-[#333] rounded text-xs font-mono text-white px-3 py-2.5 focus:outline-none focus:border-[#FFD700] appearance-none"
                >
                  <option value="standard">Standard License (MP3 / WAV Lossless) - 2,500 Sats</option>
                  <option value="dj_pro">DJ Performance License (WAV + Extended Mix) - 3,500 Sats</option>
                  <option value="stems">Stems & Remix Pack (Full Multi-track) - 5,000 Sats</option>
                </select>
                <Info className="w-4 h-4 text-gray-500 absolute right-3 top-3 pointer-events-none" />
              </div>
            </div>

            {/* Payment CTA Button */}
            <div className="space-y-3">
              <button
                onClick={onPayLightningClick}
                className="w-full bg-[#FFD700] hover:bg-[#ffe033] text-black font-black font-mono text-sm uppercase tracking-widest py-3.5 rounded flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(255,215,0,0.3)] transition-all hover:scale-[1.02] active:scale-98"
              >
                <Zap className="w-4 h-4 fill-black" />
                PAY WITH LIGHTNING
              </button>

              <div className="text-[11px] font-mono text-gray-400 space-y-1 pt-1">
                <p className="font-semibold text-gray-300">Instant. Global. Private.</p>
                <p className="text-gray-500">No banks. No borders. Direct artist settlement.</p>
              </div>
            </div>

            {/* Footer Power Badge */}
            <div className="mt-6 pt-4 border-t border-[#222] flex items-center justify-between text-[10px] font-mono text-gray-500 uppercase">
              <span>POWERED BY</span>
              <div className="flex items-center gap-1 font-bold text-white">
                <Zap className="w-3 h-3 text-[#FFD700] fill-[#FFD700]" />
                LIGHTNING NETWORK
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
