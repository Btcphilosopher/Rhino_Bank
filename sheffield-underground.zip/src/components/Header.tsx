import React, { useState, useEffect } from 'react';
import { ActiveTab } from '../types';
import { crateService } from '../services/crateService';
import { lightningService } from '../services/lightningService';
import { Zap, ShoppingBag, Search, Terminal, Disc, Radio, Sliders, Cpu, User } from 'lucide-react';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  openLightningModal: () => void;
  openWalletDrawer: () => void;
  onSearchChange?: (query: string) => void;
  searchQuery?: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  openLightningModal,
  openWalletDrawer,
  onSearchChange,
  searchQuery = ''
}) => {
  const [crateCount, setCrateCount] = useState(0);
  const [crateTotalSats, setCrateTotalSats] = useState(0);
  const [walletSats, setWalletSats] = useState(0);

  useEffect(() => {
    const unsubCrate = crateService.subscribe(items => {
      setCrateCount(items.length);
      setCrateTotalSats(crateService.getTotalSats());
    });

    const unsubWallet = lightningService.subscribe(w => {
      setWalletSats(w.satsBalance);
    });

    return () => {
      unsubCrate();
      unsubWallet();
    };
  }, []);

  return (
    <header className="sticky top-0 z-40 bg-[#0D0D0D]/95 backdrop-blur-md border-b border-[#222] text-[#F0F0F0] px-4 md:px-8 py-3 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        
        {/* Brand Logo & Name (Artistic Flair Italic Logo) */}
        <div 
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          {/* Geometric Gold Diamond Icon */}
          <div className="w-10 h-10 bg-[#151515] border border-[#FFD700] rounded-sm flex items-center justify-center p-2 shadow-[0_0_15px_rgba(255,215,0,0.15)] group-hover:border-white transition-all">
            <div className="w-4 h-4 bg-[#FFD700] rounded-sm transform rotate-45 group-hover:scale-110 transition-transform"></div>
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-black tracking-tighter leading-none italic text-white group-hover:text-[#FFD700] transition-colors">
              SHEFFIELD<br/>UNDERGROUND
            </span>
            <span className="text-[9px] font-mono tracking-widest text-[#FFD700] uppercase mt-0.5">
              DJ & PRODUCER MARKET
            </span>
          </div>
        </div>

        {/* Primary Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-[11px] font-mono font-bold uppercase tracking-widest text-[#888]">
          <button
            onClick={() => setActiveTab('music')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'music' || activeTab === 'home'
                ? 'text-[#FFD700] bg-[#FFD700]/10 border-b-2 border-[#FFD700]'
                : 'hover:text-white hover:bg-white/5'
            }`}
          >
            MUSIC
          </button>
          
          <button
            onClick={() => setActiveTab('charts')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'charts'
                ? 'text-[#FFD700] bg-[#FFD700]/10 border-b-2 border-[#FFD700]'
                : 'hover:text-white hover:bg-white/5'
            }`}
          >
            CHARTS
          </button>

          <button
            onClick={() => setActiveTab('dj_pool')}
            className={`px-3 py-1.5 rounded transition-colors flex items-center gap-1 ${
              activeTab === 'dj_pool'
                ? 'text-[#FFD700] bg-[#FFD700]/10 border-b-2 border-[#FFD700]'
                : 'hover:text-white hover:bg-white/5'
            }`}
          >
            <Disc className="w-3.5 h-3.5 text-[#FFD700]" />
            DJ TOOLS
          </button>

          <button
            onClick={() => setActiveTab('video')}
            className={`px-3 py-1.5 rounded transition-colors flex items-center gap-1 ${
              activeTab === 'video'
                ? 'text-[#FFD700] bg-[#FFD700]/10 border-b-2 border-[#FFD700]'
                : 'hover:text-white hover:bg-white/5'
            }`}
          >
            <Radio className="w-3.5 h-3.5 text-red-500 animate-pulse" />
            SETS & LIVE
          </button>

          <button
            onClick={() => setActiveTab('equipment')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'equipment'
                ? 'text-[#FFD700] bg-[#FFD700]/10 border-b-2 border-[#FFD700]'
                : 'hover:text-white hover:bg-white/5'
            }`}
          >
            EQUIPMENT
          </button>

          <button
            onClick={() => setActiveTab('samples')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'samples'
                ? 'text-[#FFD700] bg-[#FFD700]/10 border-b-2 border-[#FFD700]'
                : 'hover:text-white hover:bg-white/5'
            }`}
          >
            SAMPLES & STEMS
          </button>

          <button
            onClick={() => setActiveTab('terminal')}
            className={`px-2.5 py-1.5 rounded transition-colors flex items-center gap-1.5 border ${
              activeTab === 'terminal'
                ? 'text-[#FFD700] bg-[#FFD700]/20 border-[#FFD700]'
                : 'text-[#888] hover:text-white border-[#333] bg-[#111]'
            }`}
            title="Underground Terminal (Cyberpunk CLI)"
          >
            <Terminal className="w-3.5 h-3.5 text-[#FFD700]" />
            TERMINAL
          </button>
        </nav>

        {/* Global Search Bar */}
        <div className="flex-1 max-w-xs relative hidden md:block">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#666]" />
          <input
            type="text"
            placeholder="Search tracks, BPM, key, gear..."
            value={searchQuery}
            onChange={(e) => onSearchChange && onSearchChange(e.target.value)}
            className="w-full bg-[#111] border border-[#222] rounded text-xs font-mono text-gray-200 pl-9 pr-3 py-2 focus:outline-none focus:border-[#FFD700] transition-colors placeholder:text-[#555]"
          />
        </div>

        {/* Right Utility Bar: Lightning Pay, DJ Crate, Wallet */}
        <div className="flex items-center gap-3">
          
          {/* Lightning Balance Indicator */}
          <button
            onClick={openWalletDrawer}
            className="text-right cursor-pointer hover:opacity-80 transition-opacity hidden sm:block"
          >
            <div className="text-[10px] uppercase tracking-widest text-[#FFD700] font-mono">Lightning Balance</div>
            <div className="font-mono text-sm font-bold text-white">
              {walletSats.toLocaleString()} <span className="text-xs opacity-50">SATS</span>
            </div>
          </button>

          {/* Lightning Payment CTA Button */}
          <button
            onClick={openLightningModal}
            className="bg-[#FFD700] hover:bg-[#ffe033] text-black font-black text-xs font-mono uppercase tracking-widest px-3 md:px-4 py-2.5 rounded-sm flex items-center gap-1.5 shadow-[0_0_15px_rgba(255,215,0,0.2)] transition-all hover:scale-105 active:scale-95"
          >
            <Zap className="w-4 h-4 fill-black" />
            <span className="hidden sm:inline">PAY WITH LIGHTNING</span>
            <span className="sm:hidden">⚡ SATS</span>
          </button>

          {/* DJ Crate / Cart Button */}
          <button
            onClick={() => setActiveTab('dj_pool')}
            className="bg-[#151515] hover:bg-[#222] border border-[#333] text-white text-xs font-mono font-semibold px-3 py-2 rounded flex items-center gap-2 transition-colors relative"
            title="My DJ Crate"
          >
            <ShoppingBag className="w-4 h-4 text-[#FFD700]" />
            <span className="hidden sm:inline uppercase">CRATE</span>
            <span className="bg-[#FFD700] text-black text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
              {crateCount}
            </span>
            {crateCount > 0 && (
              <span className="hidden xl:inline text-[#FFD700] font-bold text-[11px]">
                {crateTotalSats.toLocaleString()} SATS
              </span>
            )}
          </button>

        </div>

      </div>

      {/* Mobile Submenu Tabs */}
      <div className="flex lg:hidden overflow-x-auto gap-2 pt-2 mt-2 border-t border-[#222] text-xs font-mono uppercase no-scrollbar">
        <button
          onClick={() => setActiveTab('music')}
          className={`px-3 py-1 rounded whitespace-nowrap ${
            activeTab === 'music' || activeTab === 'home' ? 'text-[#FFD700] bg-[#FFD700]/20 font-bold' : 'text-[#888]'
          }`}
        >
          MUSIC
        </button>
        <button
          onClick={() => setActiveTab('charts')}
          className={`px-3 py-1 rounded whitespace-nowrap ${
            activeTab === 'charts' ? 'text-[#FFD700] bg-[#FFD700]/20 font-bold' : 'text-[#888]'
          }`}
        >
          CHARTS
        </button>
        <button
          onClick={() => setActiveTab('dj_pool')}
          className={`px-3 py-1 rounded whitespace-nowrap ${
            activeTab === 'dj_pool' ? 'text-[#FFD700] bg-[#FFD700]/20 font-bold' : 'text-[#888]'
          }`}
        >
          DJ TOOLS
        </button>
        <button
          onClick={() => setActiveTab('video')}
          className={`px-3 py-1 rounded whitespace-nowrap ${
            activeTab === 'video' ? 'text-[#FFD700] bg-[#FFD700]/20 font-bold' : 'text-[#888]'
          }`}
        >
          LIVE & SETS
        </button>
        <button
          onClick={() => setActiveTab('equipment')}
          className={`px-3 py-1 rounded whitespace-nowrap ${
            activeTab === 'equipment' ? 'text-[#FFD700] bg-[#FFD700]/20 font-bold' : 'text-[#888]'
          }`}
        >
          EQUIPMENT
        </button>
        <button
          onClick={() => setActiveTab('samples')}
          className={`px-3 py-1 rounded whitespace-nowrap ${
            activeTab === 'samples' ? 'text-[#FFD700] bg-[#FFD700]/20 font-bold' : 'text-[#888]'
          }`}
        >
          SAMPLES & STEMS
        </button>
        <button
          onClick={() => setActiveTab('creator_studio')}
          className={`px-3 py-1 rounded whitespace-nowrap ${
            activeTab === 'creator_studio' ? 'text-[#FFD700] bg-[#FFD700]/20 font-bold' : 'text-[#888]'
          }`}
        >
          ARTIST STUDIO
        </button>
        <button
          onClick={() => setActiveTab('terminal')}
          className={`px-3 py-1 rounded whitespace-nowrap ${
            activeTab === 'terminal' ? 'text-[#FFD700] bg-[#FFD700]/20 font-bold' : 'text-[#888]'
          }`}
        >
          TERMINAL
        </button>
      </div>
    </header>
  );
};
