import React, { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { X, Zap, Copy, Check, ShieldCheck, Download, AlertCircle, Sparkles } from 'lucide-react';
import { LightningInvoice, Track, DigitalPassport } from '../types';
import { lightningService } from '../services/lightningService';

interface LightningModalProps {
  isOpen: boolean;
  onClose: () => void;
  track?: Track | null;
  customSatsAmount?: number;
  customDescription?: string;
  onPaymentSuccess?: (passport?: DigitalPassport) => void;
}

export const LightningModal: React.FC<LightningModalProps> = ({
  isOpen,
  onClose,
  track,
  customSatsAmount = 2500,
  customDescription,
  onPaymentSuccess
}) => {
  const [invoice, setInvoice] = useState<LightningInvoice | null>(null);
  const [copied, setCopied] = useState(false);
  const [isPaying, setIsPaying] = useState(false);
  const [isPaid, setIsPaid] = useState(false);
  const [txHash, setTxHash] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [passport, setPassport] = useState<DigitalPassport | null>(null);

  const amount = track ? track.satsPrice : customSatsAmount;
  const description = customDescription || (track ? `Purchase: ${track.title} (${track.artist}) - Lossless WAV` : 'Sheffield Underground Lightning Checkout');

  useEffect(() => {
    if (isOpen) {
      const newInvoice = lightningService.createInvoice(amount, description);
      setInvoice(newInvoice);
      setIsPaid(false);
      setIsPaying(false);
      setError(null);
      setPassport(null);
    }
  }, [isOpen, amount, description]);

  if (!isOpen || !invoice) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(invoice.paymentRequest);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePayWithWallet = () => {
    setIsPaying(true);
    setError(null);

    setTimeout(() => {
      const success = lightningService.payInvoiceWithWallet(invoice);
      if (success) {
        setIsPaid(true);
        setIsPaying(false);
        const hash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
        setTxHash(hash);

        let registeredPassport: DigitalPassport | undefined;
        if (track) {
          registeredPassport = lightningService.registerPurchasedPassport(
            track.id,
            track.title,
            track.artist,
            track.satsPrice
          );
          setPassport(registeredPassport);
        }

        if (onPaymentSuccess) {
          onPaymentSuccess(registeredPassport);
        }
      } else {
        setIsPaying(false);
        setError('Insufficient balance in Lightning wallet. Please top up your wallet.');
      }
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#0D0D0D] border border-[#222] rounded-xl max-w-md w-full p-6 relative shadow-2xl space-y-6 text-white font-mono">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 border-b border-[#222] pb-4">
          <div className="w-10 h-10 rounded-lg bg-[#FFD700]/10 border border-[#FFD700]/40 flex items-center justify-center text-[#FFD700]">
            <Zap className="w-6 h-6 fill-[#FFD700]" />
          </div>
          <div>
            <h3 className="text-base font-black uppercase text-white tracking-wide italic">
              PAY WITH LIGHTNING
            </h3>
            <p className="text-xs text-gray-400">
              Bitcoin Lightning Network Invoice
            </p>
          </div>
        </div>

        {!isPaid ? (
          <>
            {/* Amount & Description */}
            <div className="bg-[#151515] border border-[#222] rounded-lg p-4 space-y-2 text-center">
              <div className="text-3xl font-black text-[#FFD700] flex items-center justify-center gap-2">
                <Zap className="w-6 h-6 fill-[#FFD700]" />
                {invoice.satsAmount.toLocaleString()} SATS
              </div>
              <div className="text-xs text-gray-400 font-sans">
                {invoice.fiatApprox} • {invoice.description}
              </div>
            </div>

            {/* QR Code */}
            <div className="bg-white p-4 rounded-xl flex items-center justify-center mx-auto w-fit border-4 border-[#FFD700]">
              <QRCodeSVG
                value={invoice.paymentRequest}
                size={180}
                level="M"
                includeMargin={false}
              />
            </div>

            {/* Invoice String Box */}
            <div className="space-y-1">
              <div className="flex justify-between items-center text-[10px] text-gray-400 uppercase">
                <span>LIGHTNING INVOICE (LNBC)</span>
                <span>EXPIRES IN 09:58</span>
              </div>
              <div className="flex items-center gap-2 bg-[#151515] border border-[#222] rounded p-2">
                <input
                  type="text"
                  readOnly
                  value={invoice.paymentRequest}
                  className="bg-transparent text-[10px] text-gray-400 font-mono w-full focus:outline-none truncate"
                />
                <button
                  onClick={handleCopy}
                  className="bg-[#222] hover:bg-[#333] text-white text-[10px] font-bold px-2 py-1 rounded flex items-center gap-1 flex-shrink-0"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  {copied ? 'COPIED' : 'COPY'}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/40 rounded p-3 text-xs text-red-400 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                {error}
              </div>
            )}

            {/* Actions */}
            <div className="space-y-2">
              <button
                onClick={handlePayWithWallet}
                disabled={isPaying}
                className="w-full bg-[#FFD700] hover:bg-[#ffe033] text-black font-black text-sm uppercase tracking-wider py-3.5 rounded flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(255,215,0,0.3)] transition-all hover:scale-102 active:scale-98 disabled:opacity-50"
              >
                <Zap className="w-4 h-4 fill-black" />
                {isPaying ? 'SETTLING ON LIGHTNING...' : 'PAY NOW WITH WALLET (1-CLICK)'}
              </button>

              <p className="text-[10px] text-center text-gray-500 uppercase">
                DEMO LIGHTNING SETTLEMENT SIMULATION
              </p>
            </div>
          </>
        ) : (
          /* Payment Success Confirmation */
          <div className="space-y-6 text-center py-4">
            <div className="w-16 h-16 bg-emerald-500/20 border-2 border-emerald-500 rounded-full flex items-center justify-center mx-auto text-emerald-400 animate-bounce">
              <Check className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h4 className="text-xl font-black text-white uppercase italic">
                PAYMENT SETTLED ⚡
              </h4>
              <p className="text-xs text-emerald-400 font-bold">
                Invoice paid instantly via Lightning Network!
              </p>
            </div>

            {/* Transaction Hash & Passport Details */}
            <div className="bg-[#151515] border border-[#222] rounded-lg p-4 space-y-2 text-left text-xs">
              <div className="flex justify-between text-gray-400">
                <span>AMOUNT PAID:</span>
                <strong className="text-[#FFD700]">{invoice.satsAmount.toLocaleString()} SATS</strong>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>STATUS:</span>
                <strong className="text-emerald-400">SETTLED (1 CONFIRMATION)</strong>
              </div>
              <div className="space-y-1 pt-2 border-t border-[#222]">
                <span className="text-[10px] text-gray-500 uppercase">TRANSACTION HASH:</span>
                <p className="text-[10px] text-gray-400 break-all font-mono">
                  {txHash}
                </p>
              </div>
            </div>

            {/* Passport Certificate Badge */}
            {passport && (
              <div className="bg-[#111] border border-[#FFD700]/40 rounded p-3 text-left space-y-1">
                <div className="flex items-center gap-2 text-xs font-bold text-[#FFD700]">
                  <Sparkles className="w-4 h-4" />
                  DIGITAL MUSIC PASSPORT GENERATED
                </div>
                <p className="text-[11px] text-gray-300">
                  Signature: {passport.signature}
                </p>
              </div>
            )}

            <button
              onClick={onClose}
              className="w-full bg-[#151515] hover:bg-[#222] border border-[#333] text-white font-bold text-xs uppercase py-3 rounded transition-colors"
            >
              DONE & CONTINUE
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
