/**
 * RhinoQuant Synthetic Commodities - Full-Stack Express Server
 */

import express from 'express';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

import { COMMODITY_MASTER, getCommodityById } from './src/quant/master';
import { generateCommodityCurve } from './src/quant/curves';
import { RQQLCompiler } from './src/quant/rqql';
import { calculatePortfolioRisk, calculatePnLAttribution } from './src/quant/risk';
import { runMonteCarloSimulation } from './src/quant/monteCarlo';
import { calculateSparkSpread, calculateNetExposure, optimizePortfolioHedge } from './src/quant/specialist';
import { INITIAL_AUDIT_LOGS, INITIAL_POSITIONS, INITIAL_SYNTHETICS, INITIAL_TRADES } from './src/quant/store';
import { AuditEvent, PortfolioPosition, SyntheticInstrument, TradeRecord } from './src/types/commodity';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Server-side Gemini Client Initialization
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  aiClient = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// In-Memory State
let syntheticsStore: SyntheticInstrument[] = [...INITIAL_SYNTHETICS];
let tradesStore: TradeRecord[] = [...INITIAL_TRADES];
let positionsStore: PortfolioPosition[] = [...INITIAL_POSITIONS];
let auditLogsStore: AuditEvent[] = [...INITIAL_AUDIT_LOGS];

// ----------------------------------------------------
// API ROUTES
// ----------------------------------------------------

// GET /api/commodities
app.get('/api/commodities', (req, res) => {
  res.json({ success: true, count: COMMODITY_MASTER.length, commodities: COMMODITY_MASTER });
});

// GET /api/curves
app.get('/api/curves', (req, res) => {
  const commId = (req.query.commodity_id as string) || 'WTI';
  const curve = generateCommodityCurve(commId);
  res.json({ success: true, curve });
});

// GET /api/curves/all
app.get('/api/curves/all', (req, res) => {
  const allCurves = COMMODITY_MASTER.map((c) => generateCommodityCurve(c.commodity_id));
  res.json({ success: true, curves: allCurves });
});

// GET /api/synthetics
app.get('/api/synthetics', (req, res) => {
  res.json({ success: true, synthetics: syntheticsStore });
});

// POST /api/synthetics (Create Synthetic Instrument)
app.post('/api/synthetics', (req, res) => {
  try {
    const { name, type, referenceCommodityId, quantity, quantityUnit, priceFormula, currency, settlementRule } = req.body;

    const parseRes = RQQLCompiler.validateAndParse(priceFormula);
    if (!parseRes.isValid) {
      return res.status(400).json({ success: false, errors: parseRes.errors });
    }

    const newSynth: SyntheticInstrument = {
      id: `SYNTH-${String(syntheticsStore.length + 1).padStart(3, '0')}`,
      symbol: `${referenceCommodityId}_SYNTH_${Date.now().toString().slice(-4)}`,
      name: name || `Custom ${type} ${referenceCommodityId}`,
      type: type || 'SyntheticForward',
      referenceCommodityId: referenceCommodityId || 'WTI',
      legs: parseRes.variablesFound.map((v, idx) => ({
        id: `LEG-${idx + 1}`,
        legType: 'LONG',
        commodity_id: v.commodityId,
        tenor: v.tenor,
        ratio: 1.0,
        unit: 'barrel',
      })),
      quantity: Number(quantity) || 10000,
      quantityUnit: quantityUnit || 'barrel',
      maturityDate: '2027-12-31',
      currency: currency || 'USD',
      priceFormula,
      fairValue: parseRes.variablesFound[0]?.resolvedValue || 92.10,
      settlementRule: settlementRule || 'MONTHLY_AVERAGE',
      createdTimestamp: new Date().toISOString(),
      status: 'ACTIVE',
      delta: 1.0,
      gamma: 0.001,
      vega: 0.25,
      theta: -0.02,
      basisDelta: 0.20,
      marginRequirement: Number(quantity || 10000) * 11,
    };

    syntheticsStore.unshift(newSynth);

    // Audit Event
    auditLogsStore.unshift({
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: 'QUANT_USER',
      action: 'CREATE_SYNTHETIC',
      objectType: 'SYNTHETIC_INSTRUMENT',
      objectId: newSynth.id,
      newValue: `Created ${newSynth.name} with formula: ${priceFormula}`,
      source: 'RhinoQuant API',
    });

    res.json({ success: true, synthetic: newSynth });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/formula/parse (RQQL Formula Compiler Endpoint)
app.post('/api/formula/parse', (req, res) => {
  const { formula, marketPrices } = req.body;
  const result = RQQLCompiler.validateAndParse(formula || '', marketPrices || {});
  let calculatedPayoff = 0;
  if (result.isValid) {
    const varVals: Record<string, number> = {};
    for (const v of result.variablesFound) {
      varVals[v.name] = v.resolvedValue || 92.10;
    }
    calculatedPayoff = RQQLCompiler.evaluate(formula, varVals);
  }
  res.json({ success: true, result, calculatedPayoff });
});

// GET /api/positions
app.get('/api/positions', (req, res) => {
  res.json({ success: true, positions: positionsStore });
});

// GET /api/risk
app.get('/api/risk', (req, res) => {
  const risk = calculatePortfolioRisk(positionsStore);
  const pnlAttr = calculatePnLAttribution(positionsStore);
  res.json({ success: true, risk, pnlAttr });
});

// GET /api/trades
app.get('/api/trades', (req, res) => {
  res.json({ success: true, trades: tradesStore });
});

// POST /api/trades (Execute Trade)
app.post('/api/trades', (req, res) => {
  try {
    const { syntheticId, side, quantity, price, trader, counterparty } = req.body;
    const synth = syntheticsStore.find((s) => s.id === syntheticId) || syntheticsStore[0];

    const tradeId = `TRD-${Math.floor(1000 + Math.random() * 9000)}`;
    const newTrade: TradeRecord = {
      id: tradeId,
      syntheticId: synth.id,
      instrumentName: synth.name,
      commodity_id: synth.referenceCommodityId,
      side: side || 'BUY',
      quantity: Number(quantity) || synth.quantity,
      unit: synth.quantityUnit,
      price: Number(price) || synth.fairValue,
      currency: synth.currency,
      trader: trader || 'Quant Trader',
      timestamp: new Date().toISOString(),
      counterparty: counterparty || 'Rhino Clearing Corp',
      status: 'ACTIVE',
    };

    tradesStore.unshift(newTrade);

    // Create associated position
    const newPos: PortfolioPosition = {
      id: `POS-${Date.now()}`,
      tradeId,
      syntheticId: synth.id,
      instrumentName: synth.name,
      commodity_id: synth.referenceCommodityId,
      exposureType: 'SYNTHETIC',
      side: newTrade.side,
      quantity: newTrade.quantity,
      unit: newTrade.unit,
      entryPrice: newTrade.price,
      currentValue: newTrade.price * 1.008,
      notionalValue: newTrade.quantity * newTrade.price,
      unrealisedPnL: (newTrade.price * 0.008) * newTrade.quantity,
      realisedPnL: 0,
      dailyPnL: (newTrade.price * 0.005) * newTrade.quantity,
      delta: synth.delta,
      vega: synth.vega,
      gamma: synth.gamma,
      basisDelta: synth.basisDelta,
      bucketedDeltas: {
        m1: newTrade.quantity * newTrade.price * 0.3,
        m3: newTrade.quantity * newTrade.price * 0.25,
        m6: newTrade.quantity * newTrade.price * 0.20,
        m12: newTrade.quantity * newTrade.price * 0.15,
        m24: newTrade.quantity * newTrade.price * 0.10,
        m36: 0,
      },
    };

    positionsStore.unshift(newPos);

    // Audit Event
    auditLogsStore.unshift({
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: trader || 'Quant Trader',
      action: 'EXECUTE_TRADE',
      objectType: 'TRADE_RECORD',
      objectId: tradeId,
      newValue: `${newTrade.side} ${newTrade.quantity.toLocaleString()} ${newTrade.unit} ${synth.name} @ $${newTrade.price}`,
      source: 'Trade Desk',
    });

    res.json({ success: true, trade: newTrade, position: newPos });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/monte-carlo
app.post('/api/monte-carlo', (req, res) => {
  try {
    const config = req.body;
    const result = runMonteCarloSimulation({
      modelType: config.modelType || 'GeometricBrownianMotion',
      spot: Number(config.spot) || 92.10,
      drift: Number(config.drift) || 0.02,
      volatility: Number(config.volatility) || 0.30,
      meanReversionSpeed: Number(config.meanReversionSpeed) || 1.5,
      longTermMean: Number(config.longTermMean) || 90.0,
      jumpIntensity: Number(config.jumpIntensity) || 2.0,
      jumpMean: Number(config.jumpMean) || -0.05,
      jumpVol: Number(config.jumpVol) || 0.15,
      timeHorizonYears: Number(config.timeHorizonYears) || 1.0,
      numSteps: Number(config.numSteps) || 252,
      numPaths: Math.min(10000, Number(config.numPaths) || 1000),
    });
    res.json({ success: true, result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/specialist/spark-spread
app.get('/api/specialist/spark-spread', (req, res) => {
  const result = calculateSparkSpread({
    powerPriceMWh: Number(req.query.powerPrice) || 58.50,
    gasPriceMMBtu: Number(req.query.gasPrice) || 3.14,
    carbonPriceTonne: Number(req.query.carbonPrice) || 84.20,
    heatRateMMBtuPerMWh: Number(req.query.heatRate) || 7.0,
    carbonIntensityTonnePerMWh: Number(req.query.carbonIntensity) || 0.37,
  });
  res.json({ success: true, result });
});

// POST /api/hedge-optimize
app.post('/api/hedge-optimize', (req, res) => {
  const { targetCommodity, unhedgedNotional, availableCollateral } = req.body;
  const result = optimizePortfolioHedge(targetCommodity || 'WTI', unhedgedNotional || 10000000, availableCollateral || 25000000);
  res.json({ success: true, result });
});

// GET /api/audit
app.get('/api/audit', (req, res) => {
  res.json({ success: true, count: auditLogsStore.length, logs: auditLogsStore });
});

// POST /api/gemini/research (Server-Side Gemini Quantitative Analyst Assistant)
app.post('/api/gemini/research', async (req, res) => {
  try {
    const { prompt, context } = req.body;
    if (!aiClient) {
      return res.status(500).json({
        success: false,
        error: 'GEMINI_API_KEY environment variable is missing on the server.',
      });
    }

    const systemInstruction = `
You are the Lead Quantitative Financial Engineer and Commodities Strategist for RhinoQuant (Rhino Bank Institutional Quantitative Platform).
Your role is to assist quants, portfolio managers, and traders with:
1. Mathematical analysis of synthetic commodity payoffs, forward curves, contango/backwardation, and storage/convenience yields.
2. Stress test scenarios, SPAN initial margin analysis, and bucketed curve delta risk management.
3. Formulating RQQL (RhinoQuant Quantitative Language) formulas for complex crack, crush, basis, and basket synthetics.
4. Structuring optimal portfolio hedges for energy, metals, agriculture, power, carbon, and freight exposures.

Maintain a professional, precise, institutional quantitative tone. Include mathematical formulas in LaTeX notation where relevant.
    `.trim();

    const currentRisk = calculatePortfolioRisk(positionsStore);

    const fullPrompt = `
User Query: "${prompt}"

Current Platform Context:
- Active Positions Count: ${positionsStore.length}
- Total Portfolio Notional: $${currentRisk.portfolioNotional.toLocaleString()}
- Daily P&L: $${currentRisk.dailyPnL.toLocaleString()}
- 1D 99% VaR: $${currentRisk.var99_1d.toLocaleString()}
- Expected Shortfall 99%: $${currentRisk.expectedShortfall99.toLocaleString()}
- Initial Margin Requirement: $${currentRisk.initialMargin.toLocaleString()}
- Selected Context: ${JSON.stringify(context || {})}
    `.trim();

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: fullPrompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({ success: true, text: response.text });
  } catch (err: any) {
    console.error('Gemini Research Error:', err);
    res.status(500).json({ success: false, error: err.message || 'Failed to process research request' });
  }
});

// ----------------------------------------------------
// VITE MIDDLEWARE & STATIC FILE SERVING
// ----------------------------------------------------

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[RhinoQuant Engine] Express server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
