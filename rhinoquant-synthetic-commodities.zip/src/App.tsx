/**
 * RhinoQuant Synthetic Commodities - Root Application Component
 */

import React, { useEffect, useState } from 'react';
import { Header, WorkspaceTab } from './components/Header';
import { MarketsScreen } from './components/MarketsScreen';
import { CurvesScreen } from './components/CurvesScreen';
import { SyntheticsScreen } from './components/SyntheticsScreen';
import { PortfolioScreen } from './components/PortfolioScreen';
import { RiskScreen } from './components/RiskScreen';
import { ScenariosScreen } from './components/ScenariosScreen';
import { TradingScreen } from './components/TradingScreen';
import { SettlementScreen } from './components/SettlementScreen';
import { ResearchScreen } from './components/ResearchScreen';
import { SystemScreen } from './components/SystemScreen';
import { AiResearchModal } from './components/AiResearchModal';

import { AuditEvent, PortfolioPosition, PnLAttribution, RiskMetrics, SyntheticInstrument, TradeRecord } from './types/commodity';
import { calculatePortfolioRisk, calculatePnLAttribution } from './quant/risk';
import { INITIAL_AUDIT_LOGS, INITIAL_POSITIONS, INITIAL_SYNTHETICS, INITIAL_TRADES } from './quant/store';

export default function App() {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('MARKETS');
  const [isLiveTicks, setIsLiveTicks] = useState(true);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [userRole, setUserRole] = useState('Chief Quant');
  const [selectedCommodityId, setSelectedCommodityId] = useState('WTI');

  // Application Stores
  const [synthetics, setSynthetics] = useState<SyntheticInstrument[]>(INITIAL_SYNTHETICS);
  const [trades, setTrades] = useState<TradeRecord[]>(INITIAL_TRADES);
  const [positions, setPositions] = useState<PortfolioPosition[]>(INITIAL_POSITIONS);
  const [auditLogs, setAuditLogs] = useState<AuditEvent[]>(INITIAL_AUDIT_LOGS);

  // Derived Risk Metrics
  const risk: RiskMetrics = calculatePortfolioRisk(positions);
  const pnlAttribution: PnLAttribution = calculatePnLAttribution(positions);

  // Fetch updated data from API on mount
  const refreshData = async () => {
    try {
      const [synRes, trdRes, posRes, audRes] = await Promise.all([
        fetch('/api/synthetics').then((r) => r.json()),
        fetch('/api/trades').then((r) => r.json()),
        fetch('/api/positions').then((r) => r.json()),
        fetch('/api/audit').then((r) => r.json()),
      ]);

      if (synRes.success) setSynthetics(synRes.synthetics);
      if (trdRes.success) setTrades(trdRes.trades);
      if (posRes.success) setPositions(posRes.positions);
      if (audRes.success) setAuditLogs(audRes.logs);
    } catch (err) {
      console.warn('API fetch fallback to local store:', err);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  // Simulated Market Ticks Loop
  useEffect(() => {
    if (!isLiveTicks) return;

    const interval = setInterval(() => {
      setPositions((prev) =>
        prev.map((p) => {
          const tickPct = (Math.random() - 0.49) * 0.004; // small random price walk
          const newVal = Number((p.currentValue * (1 + tickPct)).toFixed(2));
          const dailyPnLChange = (newVal - p.currentValue) * p.quantity;

          return {
            ...p,
            currentValue: newVal,
            unrealisedPnL: Number((p.unrealisedPnL + dailyPnLChange).toFixed(2)),
            dailyPnL: Number((p.dailyPnL + dailyPnLChange).toFixed(2)),
          };
        })
      );
    }, 2500);

    return () => clearInterval(interval);
  }, [isLiveTicks]);

  const handleSelectCommodityForCurve = (id: string) => {
    setSelectedCommodityId(id);
    setActiveTab('CURVES');
  };

  const handleSelectCommodityForSynthetic = (id: string) => {
    setSelectedCommodityId(id);
    setActiveTab('SYNTHETICS');
  };

  return (
    <div className="min-h-screen bg-[#0B0F17] text-slate-100 font-sans flex flex-col antialiased">
      {/* Top Header Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isLiveTicks={isLiveTicks}
        setIsLiveTicks={setIsLiveTicks}
        onOpenAiResearch={() => setIsAiModalOpen(true)}
        userRole={userRole}
        setUserRole={setUserRole}
        var99_1d={risk.var99_1d}
      />

      {/* Main Viewport Workspace */}
      <main className="flex-1 overflow-y-auto">
        {activeTab === 'MARKETS' && (
          <MarketsScreen
            onSelectCommodityForCurve={handleSelectCommodityForCurve}
            onSelectCommodityForSynthetic={handleSelectCommodityForSynthetic}
          />
        )}

        {activeTab === 'CURVES' && <CurvesScreen initialCommodityId={selectedCommodityId} />}

        {activeTab === 'SYNTHETICS' && (
          <SyntheticsScreen
            synthetics={synthetics}
            onSyntheticCreated={refreshData}
            preselectedCommodityId={selectedCommodityId}
          />
        )}

        {activeTab === 'PORTFOLIO' && <PortfolioScreen positions={positions} pnlAttribution={pnlAttribution} />}

        {activeTab === 'RISK' && <RiskScreen risk={risk} />}

        {activeTab === 'SCENARIOS' && <ScenariosScreen />}

        {activeTab === 'TRADING' && (
          <TradingScreen
            trades={trades}
            synthetics={synthetics}
            auditLogs={auditLogs}
            onTradeExecuted={refreshData}
          />
        )}

        {activeTab === 'SETTLEMENT' && <SettlementScreen />}

        {activeTab === 'RESEARCH' && <ResearchScreen />}

        {activeTab === 'SYSTEM' && <SystemScreen />}
      </main>

      {/* AI Assistant Drawer Modal */}
      <AiResearchModal isOpen={isAiModalOpen} onClose={() => setIsAiModalOpen(false)} />
    </div>
  );
}
