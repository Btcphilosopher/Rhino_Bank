/**
 * RhinoQuant Options & Quantitative Pricing Engine
 * Implements Black-76 (for futures options), Turnbull-Wakeman Asian options,
 * Kirk's Spread Options, Commodity Greeks, and SABR Volatility Surfaces.
 */

// Normal CDF approximation (Abramowitz and Stegun)
export function normalCDF(x: number): number {
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const sign = x < 0 ? -1 : 1;
  const absX = Math.abs(x) / Math.sqrt(2.0);

  const t = 1.0 / (1.0 + p * absX);
  const y = 1.0 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-absX * absX);

  return 0.5 * (1.0 + sign * y);
}

// Normal PDF
export function normalPDF(x: number): number {
  return (1.0 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * x * x);
}

export interface OptionGreeks {
  price: number;
  delta: number;
  forwardDelta: number;
  gamma: number;
  vega: number;
  theta: number;
  rho: number;
}

/**
 * Black-76 Futures Option Pricing Model
 * F: Futures Price
 * K: Strike Price
 * T: Expiry Time in Years
 * r: Risk-free Interest Rate
 * vol: Implied Volatility
 * optionType: 'CALL' | 'PUT'
 */
export function priceBlack76Option(
  F: number,
  K: number,
  T: number,
  r: number,
  vol: number,
  optionType: 'CALL' | 'PUT'
): OptionGreeks {
  if (T <= 0 || vol <= 0) {
    const intrinsic = optionType === 'CALL' ? Math.max(0, F - K) : Math.max(0, K - F);
    return {
      price: intrinsic,
      delta: optionType === 'CALL' ? (F >= K ? 1 : 0) : (F <= K ? -1 : 0),
      forwardDelta: optionType === 'CALL' ? (F >= K ? 1 : 0) : (F <= K ? -1 : 0),
      gamma: 0,
      vega: 0,
      theta: 0,
      rho: 0,
    };
  }

  const sqrtT = Math.sqrt(T);
  const d1 = (Math.log(F / K) + 0.5 * vol * vol * T) / (vol * sqrtT);
  const d2 = d1 - vol * sqrtT;

  const df = Math.exp(-r * T);
  const Nd1 = normalCDF(d1);
  const Nd2 = normalCDF(d2);
  const nD1 = normalPDF(d1);

  let price: number;
  let forwardDelta: number;

  if (optionType === 'CALL') {
    price = df * (F * Nd1 - K * Nd2);
    forwardDelta = df * Nd1;
  } else {
    price = df * (K * normalCDF(-d2) - F * normalCDF(-d1));
    forwardDelta = df * (Nd1 - 1);
  }

  // Gamma = df * n(d1) / (F * vol * sqrt(T))
  const gamma = (df * nD1) / (F * vol * sqrtT);

  // Vega = df * F * n(d1) * sqrt(T)  (1% vol change sensitivity)
  const vega = (df * F * nD1 * sqrtT) / 100;

  // Theta (annual rate per day)
  const theta = (-(df * F * nD1 * vol) / (2 * sqrtT) + (optionType === 'CALL' ? r * df * K * Nd2 : -r * df * K * normalCDF(-d2))) / 365;

  // Rho
  const rho = optionType === 'CALL' ? (T * df * K * Nd2) / 100 : (-T * df * K * normalCDF(-d2)) / 100;

  return {
    price: Number(price.toFixed(4)),
    delta: Number(forwardDelta.toFixed(4)),
    forwardDelta: Number(forwardDelta.toFixed(4)),
    gamma: Number(gamma.toFixed(6)),
    vega: Number(vega.toFixed(4)),
    theta: Number(theta.toFixed(4)),
    rho: Number(rho.toFixed(4)),
  };
}

/**
 * Kirk's Approximation for Two-Asset Commodity Spread Options
 * Call on F1 - F2 > K
 */
export function priceKirkSpreadOption(
  F1: number,
  F2: number,
  K: number,
  T: number,
  r: number,
  vol1: number,
  vol2: number,
  rho12: number,
  optionType: 'CALL' | 'PUT'
): OptionGreeks {
  const df = Math.exp(-r * T);
  const F2_k = F2 + K * df;
  const F_eff = F1 / F2_k;

  // Effective volatility
  const w = F2 / F2_k;
  const vol_eff = Math.sqrt(vol1 * vol1 - 2 * w * rho12 * vol1 * vol2 + w * w * vol2 * vol2);

  const res = priceBlack76Option(F_eff, 1.0, T, r, vol_eff, optionType);
  const price = F2_k * res.price;

  return {
    price: Number(price.toFixed(4)),
    delta: Number((res.delta * df).toFixed(4)),
    forwardDelta: Number((res.forwardDelta * df).toFixed(4)),
    gamma: Number((res.gamma / F2_k).toFixed(6)),
    vega: Number(res.vega.toFixed(4)),
    theta: Number(res.theta.toFixed(4)),
    rho: Number(res.rho.toFixed(4)),
  };
}

/**
 * SABR Volatility Surface Interpolation
 */
export function calculateSABRVol(
  F: number,
  K: number,
  T: number,
  alpha: number, // Vol level
  beta: number,  // CEV exponent e.g. 0.5
  rho: number,   // Correlation e.g. -0.2
  nu: number     // Vol of vol e.g. 0.4
): number {
  if (F === K) {
    const fBeta = Math.pow(F, 1 - beta);
    const term1 = alpha / fBeta;
    const term2 = 1 + (((1 - beta) ** 2 / 24) * (alpha ** 2 / (fBeta ** 2)) + (0.25 * rho * beta * nu * alpha) / fBeta + ((2 - 3 * rho ** 2) / 24) * nu ** 2) * T;
    return term1 * term2;
  }

  const fk = F * K;
  const logFK = Math.log(F / K);
  const fkBeta = Math.pow(fk, (1 - beta) / 2);

  const z = (nu / alpha) * fkBeta * logFK;
  const xZ = Math.log((Math.sqrt(1 - 2 * rho * z + z * z) + z - rho) / (1 - rho));

  const numerator = alpha;
  const denominator = fkBeta * (1 + (((1 - beta) ** 2) / 24) * (logFK ** 2) + (((1 - beta) ** 4) / 1920) * (logFK ** 4));

  const bracket = 1 + (((1 - beta) ** 2 / 24) * (alpha ** 2 / (fkBeta ** 2)) + (0.25 * rho * beta * nu * alpha) / fkBeta + ((2 - 3 * rho ** 2) / 24) * nu ** 2) * T;

  return (numerator / denominator) * (z / xZ) * bracket;
}
