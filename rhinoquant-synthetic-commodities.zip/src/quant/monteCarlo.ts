/**
 * RhinoQuant Vectorised Monte Carlo Simulation Engine
 * Supports Geometric Brownian Motion, Mean-Reverting Ornstein-Uhlenbeck,
 * Seasonal Mean-Reversion, and Merton Jump Diffusion for Commodity Price Paths.
 */

export interface MonteCarloConfig {
  modelType: 'GeometricBrownianMotion' | 'MeanReversion' | 'SeasonalMeanReversion' | 'JumpDiffusion';
  spot: number;
  drift: number; // e.g. 0.02 (2%)
  volatility: number; // e.g. 0.30 (30%)
  meanReversionSpeed: number; // kappa e.g. 1.5
  longTermMean: number; // theta e.g. 90.0
  jumpIntensity: number; // lambda e.g. 2.0 per year
  jumpMean: number; // e.g. -0.05
  jumpVol: number; // e.g. 0.15
  timeHorizonYears: number; // T e.g. 1.0 (1 year)
  numSteps: number; // N e.g. 252 (daily steps)
  numPaths: number; // e.g. 10,000
}

export interface MonteCarloResult {
  percentiles: {
    p5: number[];
    p25: number[];
    p50: number[];
    p75: number[];
    p95: number[];
  };
  terminalMean: number;
  terminalStdDev: number;
  terminalMin: number;
  terminalMax: number;
  var99: number;
  cvar99: number;
  executionTimeMs: number;
  samplePaths: number[][]; // 5 representative paths
}

/**
 * Standard Normal Random Generator (Box-Muller Transform)
 */
function randomNormal(): number {
  let u = 0;
  let v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

/**
 * Executes Monte Carlo Price Path Simulations
 */
export function runMonteCarloSimulation(config: MonteCarloConfig): MonteCarloResult {
  const startTime = performance.now();
  const {
    modelType,
    spot,
    drift,
    volatility,
    meanReversionSpeed,
    longTermMean,
    jumpIntensity,
    jumpMean,
    jumpVol,
    timeHorizonYears,
    numSteps,
    numPaths,
  } = config;

  const dt = timeHorizonYears / numSteps;
  const sqrtDt = Math.sqrt(dt);

  // Store matrix of paths: [numPaths][numSteps + 1]
  const paths: number[][] = new Array(numPaths);
  const terminalValues: number[] = new Array(numPaths);

  for (let p = 0; p < numPaths; p++) {
    const path = new Array(numSteps + 1);
    path[0] = spot;
    let s = spot;

    for (let t = 1; t <= numSteps; t++) {
      const z = randomNormal();

      if (modelType === 'GeometricBrownianMotion') {
        // dS = s * (mu * dt + sigma * dW)
        const dS = s * (drift * dt + volatility * sqrtDt * z);
        s = Math.max(0.01, s + dS);
      } else if (modelType === 'MeanReversion' || modelType === 'SeasonalMeanReversion') {
        // dS = kappa * (theta - S) * dt + sigma * S * dW
        let currentMean = longTermMean;
        if (modelType === 'SeasonalMeanReversion') {
          // Add seasonal sine wave to long term mean
          const currentT = t * dt;
          currentMean = longTermMean * (1 + 0.15 * Math.sin(2 * Math.PI * currentT));
        }
        const dS = meanReversionSpeed * (currentMean - s) * dt + volatility * s * sqrtDt * z;
        s = Math.max(0.01, s + dS);
      } else if (modelType === 'JumpDiffusion') {
        // Merton Jump Diffusion
        const dS_cont = s * (drift * dt + volatility * sqrtDt * z);
        let jumpComp = 0;
        // Poisson jump check
        if (Math.random() < jumpIntensity * dt) {
          const jumpZ = randomNormal();
          const jumpSize = Math.exp(jumpMean + jumpVol * jumpZ) - 1;
          jumpComp = s * jumpSize;
        }
        s = Math.max(0.01, s + dS_cont + jumpComp);
      }

      path[t] = Number(s.toFixed(2));
    }

    paths[p] = path;
    terminalValues[p] = path[numSteps];
  }

  // Calculate percentile trajectories across time steps
  const percentiles = {
    p5: new Array<number>(numSteps + 1),
    p25: new Array<number>(numSteps + 1),
    p50: new Array<number>(numSteps + 1),
    p75: new Array<number>(numSteps + 1),
    p95: new Array<number>(numSteps + 1),
  };

  for (let t = 0; t <= numSteps; t++) {
    const stepVals = new Array<number>(numPaths);
    for (let p = 0; p < numPaths; p++) {
      stepVals[p] = paths[p][t];
    }
    stepVals.sort((a, b) => a - b);

    percentiles.p5[t] = stepVals[Math.floor(numPaths * 0.05)];
    percentiles.p25[t] = stepVals[Math.floor(numPaths * 0.25)];
    percentiles.p50[t] = stepVals[Math.floor(numPaths * 0.50)];
    percentiles.p75[t] = stepVals[Math.floor(numPaths * 0.75)];
    percentiles.p95[t] = stepVals[Math.floor(numPaths * 0.95)];
  }

  // Terminal stats
  terminalValues.sort((a, b) => a - b);
  const sum = terminalValues.reduce((a, b) => a + b, 0);
  const terminalMean = sum / numPaths;
  const variance = terminalValues.reduce((a, b) => a + Math.pow(b - terminalMean, 2), 0) / numPaths;
  const terminalStdDev = Math.sqrt(variance);

  const var99Idx = Math.floor(numPaths * 0.01);
  const var99Val = spot - terminalValues[var99Idx];

  let cvarSum = 0;
  for (let i = 0; i <= var99Idx; i++) {
    cvarSum += spot - terminalValues[i];
  }
  const cvar99Val = cvarSum / (var99Idx + 1);

  const endTime = performance.now();

  return {
    percentiles,
    terminalMean: Number(terminalMean.toFixed(2)),
    terminalStdDev: Number(terminalStdDev.toFixed(2)),
    terminalMin: Number(terminalValues[0].toFixed(2)),
    terminalMax: Number(terminalValues[numPaths - 1].toFixed(2)),
    var99: Number(var99Val.toFixed(2)),
    cvar99: Number(cvar99Val.toFixed(2)),
    executionTimeMs: Number((endTime - startTime).toFixed(1)),
    samplePaths: paths.slice(0, 5),
  };
}
