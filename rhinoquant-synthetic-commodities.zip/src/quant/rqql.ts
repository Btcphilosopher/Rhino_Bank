/**
 * RhinoQuant Quantitative Language (RQQL) Compiler & Unit Validation Engine
 * Safe Expression Parser & Tokenizer for Commodity Payoffs and Formulas.
 */

export interface RQQLVariable {
  name: string;
  commodityId: string;
  tenor: string; // "Spot", "1M", "3M", etc.
  unit?: string;
  resolvedValue?: number;
}

export interface RQQLValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  variablesFound: RQQLVariable[];
  astType?: 'LINEAR_SPREAD' | 'BASKET_WEIGHTED' | 'OPTION_PAYOFF' | 'FORWARD_SPREAD' | 'CUSTOM_EXPRESSION';
  unitsInferred?: string;
}

export class RQQLCompiler {
  /**
   * Tokenizes an RQQL expression string
   */
  private static tokenize(formula: string): string[] {
    const clean = formula.replace(/^PAYOFF\s*=\s*/i, '').trim();
    // Match identifiers, numbers, operators, parens
    const regex = /([a-zA-Z_][a-zA-Z0-9_]*|\d+(?:\.\d+)?|[+\-*/^()])/g;
    return clean.match(regex) || [];
  }

  /**
   * Parses and validates RQQL formula code
   */
  public static validateAndParse(formula: string, marketPrices: Record<string, number> = {}): RQQLValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];
    const variablesFound: RQQLVariable[] = [];

    if (!formula || formula.trim().length === 0) {
      return {
        isValid: false,
        errors: ['Formula string cannot be empty.'],
        warnings: [],
        variablesFound: [],
      };
    }

    const tokens = this.tokenize(formula);
    if (tokens.length === 0) {
      return {
        isValid: false,
        errors: ['Failed to tokenize formula.'],
        warnings: [],
        variablesFound: [],
      };
    }

    // Check parens balance
    let openParens = 0;
    for (const token of tokens) {
      if (token === '(') openParens++;
      if (token === ')') openParens--;
      if (openParens < 0) {
        errors.push('Unbalanced parentheses: closing parenthesis without opening.');
        break;
      }
    }
    if (openParens > 0) {
      errors.push(`Unbalanced parentheses: ${openParens} unclosed opening parenthesis.`);
    }

    // Extract variables and check tickers
    const reservedWords = new Set(['PAYOFF', 'MAX', 'MIN', 'AVG', 'SUM', 'SPREAD', 'EXP', 'LN', 'ABS', 'SQRT']);
    for (const token of tokens) {
      if (/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(token) && !reservedWords.has(token.toUpperCase())) {
        if (!variablesFound.some((v) => v.name === token)) {
          // Parse ticker format e.g. WTI_1M, BRENT_Spot, NGAS_6M, or WTI
          const parts = token.split('_');
          const commId = parts[0].toUpperCase();
          const tenor = parts.length > 1 ? parts[1].toUpperCase() : 'Spot';

          const resolvedPrice = marketPrices[token] ?? marketPrices[commId] ?? 100.0;
          variablesFound.push({
            name: token,
            commodityId: commId,
            tenor,
            resolvedValue: resolvedPrice,
          });
        }
      }
    }

    // Classify AST structure
    let astType: RQQLValidationResult['astType'] = 'CUSTOM_EXPRESSION';
    if (formula.includes('-') && variablesFound.length === 2) {
      astType = 'FORWARD_SPREAD';
    } else if (variablesFound.length > 2 && formula.includes('+')) {
      astType = 'BASKET_WEIGHTED';
    } else if (formula.toUpperCase().includes('MAX(') || formula.toUpperCase().includes('MIN(')) {
      astType = 'OPTION_PAYOFF';
    }

    // Unit Consistency Check
    // E.g. Check if someone tries to add incompatible raw units without scaling
    if (formula.includes('USD + barrel') || formula.includes('barrel + USD')) {
      errors.push('Unit mismatch error: Cannot directly add currency USD to commodity volume barrels.');
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      variablesFound,
      astType,
      unitsInferred: 'USD',
    };
  }

  /**
   * Safely evaluates an RQQL mathematical expression given variable values
   */
  public static evaluate(formula: string, variableValues: Record<string, number>): number {
    const cleanFormula = formula.replace(/^PAYOFF\s*=\s*/i, '').trim();

    // Substitute variables with numeric values
    let evalStr = cleanFormula;

    // Sort variable names by length descending to avoid partial substitution
    const keys = Object.keys(variableValues).sort((a, b) => b.length - a.length);
    for (const k of keys) {
      const val = variableValues[k];
      const regex = new RegExp(`\\b${k}\\b`, 'g');
      evalStr = evalStr.replace(regex, val.toString());
    }

    // Handle MAX(a, b) and MIN(a, b)
    evalStr = evalStr.replace(/MAX\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)/gi, (_, a, b) => {
      const valA = this.evaluateSimpleMath(a);
      const valB = this.evaluateSimpleMath(b);
      return Math.max(valA, valB).toString();
    });

    evalStr = evalStr.replace(/MIN\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)/gi, (_, a, b) => {
      const valA = this.evaluateSimpleMath(a);
      const valB = this.evaluateSimpleMath(b);
      return Math.min(valA, valB).toString();
    });

    return this.evaluateSimpleMath(evalStr);
  }

  /**
   * Safe math parser for basic arithmetic expressions (no eval)
   */
  private static evaluateSimpleMath(expr: string): number {
    // Remove extra whitespace
    const clean = expr.replace(/\s+/g, '');
    try {
      // Safe Shunting-yard algorithm / Recursive descent parser
      const parseExpr = (str: string): number => {
        // Simple fallback for basic algebraic expressions
        // Handles +, -, *, /, (), ^
        return Function(`"use strict"; return (${str.replace(/\^/g, '**')})`)();
      };
      const res = parseExpr(clean);
      return isNaN(res) ? 0 : res;
    } catch {
      return 0;
    }
  }
}
