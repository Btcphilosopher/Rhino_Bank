/**
 * RhinoQuant Curve Engine
 * Calculates forward curves, contango/backwardation classification,
 * cost-of-carry storage models, convenience yields, roll yield, and spreads.
 */

import { CommodityCurveData, CurvePoint, MarketRegime } from '../types/commodity';
import { getCommodityById } from './master';

// Base benchmark prices for seed curves
const BASE_SPOT_PRICES: Record<string, number> = {
  WTI: 92.10,
  BRENT: 96.40,
  NGAS: 3.14,
  RBOB: 2.68,
  HOIL: 2.85,
  POWER: 58.50,
  CARBON: 84.20,
  GOLD: 2850.10,
  SILVER: 32.40,
  COPPER: 9850.00, // per metric tonne
  ALUMINIUM: 2540.00,
  CORN: 4.45,
  WHEAT: 5.82,
  SOYBEAN: 10.25,
  SOYMEAL: 325.00,
  SOYOIL: 0.46,
  COFFEE: 2.45,
  COCOA: 7850.00,
  CATTLE: 1.84,
  FREIGHT_DRY: 22400.00,
};

// Tenors in months
export const TENORS = [
  { label: 'Spot', months: 0 },
  { label: '1M', months: 1 },
  { label: '2M', months: 2 },
  { label: '3M', months: 3 },
  { label: '6M', months: 6 },
  { label: '12M', months: 12 },
  { label: '18M', months: 18 },
  { label: '24M', months: 24 },
  { label: '36M', months: 36 },
];

/**
 * Calculates theoretical forward price given spot, risk-free rate, storage cost, convenience yield, and time
 * F = S * exp((r + u - y) * T)
 */
export function calculateTheoreticalForwardPrice(
  spot: number,
  r: number, // Risk-free rate e.g. 0.045
  u: number, // Storage cost % e.g. 0.04
  y: number, // Convenience yield % e.g. 0.02
  T: number  // Time in years (months / 12)
): number {
  if (T === 0) return spot;
  return spot * Math.exp((r + u - y) * T);
}

/**
 * Implies Convenience Yield y from Spot S and Futures F
 * y = r + u - (1 / T) * ln(F / S)
 */
export function implyConvenienceYield(
  spot: number,
  futures: number,
  r: number,
  u: number,
  T: number
): number {
  if (T <= 0 || spot <= 0 || futures <= 0) return 0;
  return r + u - (1 / T) * Math.log(futures / spot);
}

/**
 * Generates forward curve data for a given commodity ID
 */
export function generateCommodityCurve(commodityId: string, customSpot?: number): CommodityCurveData {
  const master = getCommodityById(commodityId);
  const spot = customSpot ?? (BASE_SPOT_PRICES[commodityId] || 100.0);
  const vol = master?.typical_volatility || 0.30;
  const storageCostPct = master?.annual_storage_cost_pct || 0.04;
  const riskFreeRate = 0.045; // 4.5% US Treasury / SOFR baseline

  // Determine structural regime for commodity
  // WTI/Brent: slight backwardation or contango depending on inventory
  // NatGas: seasonal winter contango, summer dip
  let convenienceYield = 0.03;
  if (commodityId === 'WTI' || commodityId === 'BRENT') {
    convenienceYield = 0.06; // Backwardation bias
  } else if (commodityId === 'NGAS') {
    convenienceYield = 0.01; // Contango bias
  } else if (commodityId === 'GOLD' || commodityId === 'SILVER') {
    convenienceYield = 0.002; // Pure financial contango (cost of carry)
  } else if (commodityId === 'COCOA' || commodityId === 'POWER') {
    convenienceYield = 0.12; // High current scarcity convenience yield
  }

  const points: CurvePoint[] = TENORS.map((t) => {
    let price: number;
    const T = t.months / 12;

    if (t.months === 0) {
      price = spot;
    } else if (commodityId === 'NGAS') {
      // Seasonal natural gas curve adjustment (Winter Dec-Feb spike)
      const baseFwd = calculateTheoreticalForwardPrice(spot, riskFreeRate, storageCostPct, convenienceYield, T);
      const seasonalFactor = Math.sin((t.months * Math.PI) / 6) * 0.18;
      price = baseFwd * (1 + seasonalFactor);
    } else {
      price = calculateTheoreticalForwardPrice(spot, riskFreeRate, storageCostPct, convenienceYield, T);
    }

    // Add small bid-ask spread
    const halfSpread = price * 0.0008;
    const bid = Number((price - halfSpread).toFixed(2));
    const ask = Number((price + halfSpread).toFixed(2));
    const mid = Number(price.toFixed(2));

    return {
      tenor: t.label,
      months: t.months,
      price: mid,
      bid,
      ask,
      openInterest: Math.round(150000 * Math.exp(-t.months / 12) + 20000),
      volume: Math.round(45000 * Math.exp(-t.months / 8) + 5000),
      impliedVol: Number((vol * (1 + 0.08 * Math.exp(-t.months / 6))).toFixed(4)),
    };
  });

  const spotPt = points[0].price;
  const m1Pt = points[1].price;
  const m12Pt = points[5].price;

  // Front Slope = (F_1M - Spot) / Spot
  const frontSlopePct = Number(((m1Pt - spotPt) / spotPt).toFixed(4));
  
  // Annualised Roll Yield = ((Spot - F_1M) / F_1M) * 12
  const annualisedRollYieldPct = Number((((spotPt - m1Pt) / m1Pt) * 12).toFixed(4));

  // Determine Regime
  let regime: MarketRegime = 'FLAT';
  if (frontSlopePct > 0.002) {
    regime = 'CONTANGO';
  } else if (frontSlopePct < -0.002) {
    regime = 'BACKWARDATION';
  }

  // Basis = Spot - 1M Futures
  const basis = Number((spotPt - m1Pt).toFixed(2));

  // Implied Convenience Yield at 12M
  const impliedConvYield = implyConvenienceYield(spotPt, m12Pt, riskFreeRate, storageCostPct, 1.0);

  return {
    commodity_id: commodityId,
    symbol: master?.symbol || commodityId,
    asOfDate: new Date().toISOString().split('T')[0],
    regime,
    spotPrice: spotPt,
    points,
    frontSlopePct,
    annualisedRollYieldPct,
    convenienceYieldPct: Number(impliedConvYield.toFixed(4)),
    basis,
  };
}

/**
 * Calculates Calendar Spread between two tenors on a curve
 */
export function calculateCalendarSpread(curve: CommodityCurveData, leg1Tenor: string, leg2Tenor: string) {
  const p1 = curve.points.find((p) => p.tenor === leg1Tenor)?.price || 0;
  const p2 = curve.points.find((p) => p.tenor === leg2Tenor)?.price || 0;
  return {
    leg1Price: p1,
    leg2Price: p2,
    spread: Number((p1 - p2).toFixed(2)),
    spreadPct: p2 > 0 ? Number(((p1 - p2) / p2).toFixed(4)) : 0,
  };
}
