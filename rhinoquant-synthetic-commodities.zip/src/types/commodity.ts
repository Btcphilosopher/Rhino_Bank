/**
 * RhinoQuant Synthetic Commodities - Type Definitions
 */

export type SectorType = 'ENERGY' | 'METALS' | 'AGRICULTURE' | 'LIVESTOCK' | 'SOFTS' | 'FREIGHT' | 'ENVIRONMENTAL';

export type CurrencyCode = 'USD' | 'EUR' | 'GBP' | 'CHF' | 'JPY' | 'CAD' | 'AUD' | 'CNY';

export type QuantityUnit = 'barrel' | 'MMBtu' | 'MWh' | 'tonne' | 'metric_tonne' | 'kg' | 'oz' | 'bushel' | 'gallon' | 'lbs' | 'lot';

export type DeliveryMethod = 'physical' | 'financial_cash';

export type MarketRegime = 'CONTANGO' | 'BACKWARDATION' | 'FLAT';

export interface CommodityMasterItem {
  commodity_id: string;
  symbol: string;
  name: string;
  sector: SectorType;
  currency: CurrencyCode;
  unit: QuantityUnit;
  quantity_unit: string; // e.g. "1,000 barrels"
  location: string;
  quality: string;
  delivery_method: DeliveryMethod;
  storage_characteristics: string;
  seasonality: 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE';
  exchange: string;
  description: string;
  typical_volatility: number; // annualised %
  annual_storage_cost_pct: number; // % of spot price per year
}

export interface CurvePoint {
  tenor: string; // "Spot", "1M", "2M", "3M", "6M", "12M", "18M", "24M", "36M"
  months: number; // 0, 1, 2, 3, 6, 12, 18, 24, 36
  price: number;
  bid: number;
  ask: number;
  openInterest: number;
  volume: number;
  impliedVol: number;
}

export interface CommodityCurveData {
  commodity_id: string;
  symbol: string;
  asOfDate: string;
  regime: MarketRegime;
  spotPrice: number;
  points: CurvePoint[];
  frontSlopePct: number;
  annualisedRollYieldPct: number;
  convenienceYieldPct: number;
  basis: number; // Spot - 1M Futures
}

export interface MarketObservation {
  id: string;
  timestamp: string;
  instrument: string;
  commodity_id: string;
  bid: number;
  ask: number;
  mid: number;
  last: number;
  volume: number;
  open_interest: number;
  settlement: number;
  source: string;
  qualityScore: number; // 0-100
  staleFlag: boolean;
  outlierFlag: boolean;
}

export type SyntheticInstrumentType =
  | 'SyntheticForward'
  | 'CommoditySwap'
  | 'BasisSwap'
  | 'CalendarSpread'
  | 'CrackSpread'
  | 'CrushSpread'
  | 'CommodityBasket'
  | 'SyntheticCommodityIndex'
  | 'CommodityOption';

export interface SyntheticLeg {
  id: string;
  legType: 'FIXED' | 'FLOATING' | 'LONG' | 'SHORT';
  commodity_id: string;
  tenor: string;
  ratio: number;
  fixedPrice?: number;
  unit: QuantityUnit;
  referenceIndex?: string;
}

export interface SyntheticInstrument {
  id: string;
  symbol: string;
  name: string;
  type: SyntheticInstrumentType;
  referenceCommodityId: string;
  legs: SyntheticLeg[];
  quantity: number;
  quantityUnit: QuantityUnit;
  maturityDate: string;
  currency: CurrencyCode;
  priceFormula: string; // RQQL Formula string
  fairValue: number;
  strikePrice?: number;
  optionType?: 'CALL' | 'PUT';
  settlementRule: 'MONTHLY_AVERAGE' | 'DAILY_AVERAGE' | 'BULLET_EXPIRY' | 'PHYSICAL';
  createdTimestamp: string;
  status: 'DRAFT' | 'ACTIVE' | 'TERMINATED';
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  basisDelta: number;
  marginRequirement: number;
}

export interface PortfolioPosition {
  id: string;
  tradeId: string;
  syntheticId: string;
  instrumentName: string;
  commodity_id: string;
  exposureType: 'PHYSICAL' | 'FINANCIAL' | 'SYNTHETIC';
  side: 'BUY' | 'SELL';
  quantity: number;
  unit: QuantityUnit;
  entryPrice: number;
  currentValue: number;
  notionalValue: number;
  unrealisedPnL: number;
  realisedPnL: number;
  dailyPnL: number;
  delta: number;
  vega: number;
  gamma: number;
  basisDelta: number;
  bucketedDeltas: {
    m1: number;
    m3: number;
    m6: number;
    m12: number;
    m24: number;
    m36: number;
  };
}

export interface TradeRecord {
  id: string;
  syntheticId: string;
  instrumentName: string;
  commodity_id: string;
  side: 'BUY' | 'SELL';
  quantity: number;
  unit: QuantityUnit;
  price: number;
  currency: CurrencyCode;
  trader: string;
  timestamp: string;
  counterparty: string;
  status: 'DRAFT' | 'PENDING' | 'CONFIRMED' | 'ACTIVE' | 'SETTLED' | 'TERMINATED';
}

export interface RiskMetrics {
  portfolioNotional: number;
  portfolioMarketValue: number;
  dailyPnL: number;
  var95_1d: number;
  var99_1d: number;
  var99_10d: number;
  expectedShortfall99: number;
  totalSpotDelta: number;
  totalVega: number;
  totalGamma: number;
  totalBasisRisk: number;
  initialMargin: number;
  maintenanceMargin: number;
  collateralPosted: number;
  availableCollateral: number;
  potentialFutureExposure: number;
  bucketedCurveRisk: {
    m1: number;
    m3: number;
    m6: number;
    m12: number;
    m18: number;
    m24: number;
    m36: number;
  };
}

export interface PnLAttribution {
  spotPnL: number;
  curvePnL: number;
  rollPnL: number;
  volatilityPnL: number;
  fxPnL: number;
  carryPnL: number;
  thetaPnL: number;
  basisPnL: number;
  correlationPnL: number;
  tradingPnL: number;
  feesPnL: number;
  totalPnL: number;
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  commodityShocksPct: Record<string, number>; // e.g. { WTI: 0.10, BRENT: -0.15, NGAS: 0.40 }
  volatilityShockPoints: number;
  fxShockPct: number;
  historicalReference?: string;
  estimatedPnL: number;
  estimatedMarginCall: number;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  objectType: string;
  objectId: string;
  oldValue?: string;
  newValue?: string;
  source: string;
}

export interface UserRoleInfo {
  role: 'Trader' | 'Quant' | 'RiskManager' | 'PortfolioManager' | 'Operations' | 'Treasury' | 'Compliance' | 'Administrator' | 'ReadOnly';
  userName: string;
  permissions: string[];
}
