/**
 * RhinoQuant Portfolio Screen
 * Position Management, Physical vs Financial Exposure Netting, P&L Attribution Waterfall,
 * and Bucketed Curve Delta Exposure Ladder.
 */

import React from 'react';
import { PortfolioPosition, PnLAttribution } from '../types/commodity';
import { PieChart, TrendingUp, DollarSign, Layers, ArrowUpRight, ArrowDownRight, Scale } from 'lucide-react';

interface PortfolioScreenProps {
  positions: PortfolioPosition[];
  pnlAttribution: PnLAttribution;
}

export const PortfolioScreen: React.FC<PortfolioScreenProps> = ({ positions, pnlAttribution }) => {
  const totalNotional = positions.reduce((acc, p) => acc + p.notionalValue, 0);
  const totalUnrealisedPnL = positions.reduce((acc, p) => acc + p.unrealisedPnL, 0);
  const totalDailyPnL = positions.reduce((acc, p) => acc + p.dailyPnL, 0);

  // Compute total bucketed curve deltas
  const bucketSums = {
    m1: positions.reduce((acc, p) => acc + (p.bucketedDeltas.m1 || 0), 0),
    m3: positions.reduce((acc, p) => acc + (p.bucketedDeltas.m3 || 0), 0),
    m6: positions.reduce((acc, p) => acc + (p.bucketedDeltas.m6 || 0), 0),
    m12: positions.reduce((acc, p) => acc + (p.bucketedDeltas.m12 || 0), 0),
    m24: positions.reduce((acc, p) => acc + (p.bucketedDeltas.m24 || 0), 0),
    m36: positions.reduce((acc, p) => acc + (p.bucketedDeltas.m36 || 0), 0),
  };

  const pnlItems = [
    { label: 'Spot Move P&L', value: pnlAttribution.spotPnL, desc: 'Delta spot price moves' },
    { label: 'Curve Shift P&L', value: pnlAttribution.curvePnL, desc: 'Steepening & term structure changes' },
    { label: 'Roll Yield P&L', value: pnlAttribution.rollPnL, desc: 'Contango drag / Backwardation gain' },
    { label: 'Volatility P&L', value: pnlAttribution.volatilityPnL, desc: 'Vega sensitivity to vol shifts' },
    { label: 'FX P&L', value: pnlAttribution.fxPnL, desc: 'Cross-currency exchange rates' },
    { label: 'Carry Cost P&L', value: pnlAttribution.carryPnL, desc: 'Financing & storage costs' },
    { label: 'Theta Decay P&L', value: pnlAttribution.thetaPnL, desc: 'Time decay on options' },
    { label: 'Basis P&L', value: pnlAttribution.basisPnL, desc: 'Location & quality differential' },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Portfolio Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#111827] p-4 rounded border border-slate-800">
          <span className="text-[10px] text-slate-400 uppercase font-semibold">Total Portfolio Notional</span>
          <div className="text-xl font-bold font-mono text-white mt-1 tabular-nums">
            ${totalNotional.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-[10px] text-slate-500 font-mono mt-1 block">{positions.length} Active Positions</span>
        </div>

        <div className="bg-[#111827] p-4 rounded border border-slate-800">
          <span className="text-[10px] text-slate-400 uppercase font-semibold">Daily P&L</span>
          <div
            className={`text-xl font-bold font-mono mt-1 tabular-nums flex items-center gap-1 ${
              totalDailyPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {totalDailyPnL >= 0 ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownRight className="w-5 h-5" />}
            <span>
              {totalDailyPnL >= 0 ? '+' : ''}${totalDailyPnL.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
          </div>
          <span className="text-[10px] text-slate-500 font-mono mt-1 block">Live Today's Mark-to-Market</span>
        </div>

        <div className="bg-[#111827] p-4 rounded border border-slate-800">
          <span className="text-[10px] text-slate-400 uppercase font-semibold">Unrealised P&L</span>
          <div
            className={`text-xl font-bold font-mono mt-1 tabular-nums ${
              totalUnrealisedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {totalUnrealisedPnL >= 0 ? '+' : ''}${totalUnrealisedPnL.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <span className="text-[10px] text-slate-500 font-mono mt-1 block">Inception-to-Date Mark</span>
        </div>

        <div className="bg-[#111827] p-4 rounded border border-slate-800">
          <span className="text-[10px] text-slate-400 uppercase font-semibold">Physical vs Financial Exposure Netting</span>
          <div className="text-xl font-bold font-mono text-blue-400 mt-1 tabular-nums">82.4% Hedged</div>
          <span className="text-[10px] text-slate-500 font-mono mt-1 block">Net Unhedged: $1.82m Notional</span>
        </div>
      </div>

      {/* Grid: P&L Attribution Waterfall & Bucketed Curve Delta Ladder */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* P&L Attribution Waterfall */}
        <div className="bg-[#111827] p-5 rounded border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200 flex items-center gap-2">
              <PieChart className="w-4 h-4 text-blue-400" />
              <span>Daily P&L Attribution Waterfall</span>
            </h3>
            <span className="text-xs font-mono font-bold text-emerald-400">
              Total: ${pnlAttribution.totalPnL.toLocaleString()}
            </span>
          </div>

          <div className="space-y-2">
            {pnlItems.map((item) => (
              <div key={item.label} className="flex justify-between items-center p-2.5 bg-[#090D15] rounded border border-slate-800/80">
                <div>
                  <span className="text-xs font-semibold text-slate-200 block">{item.label}</span>
                  <span className="text-[10px] text-slate-500 block">{item.desc}</span>
                </div>
                <span
                  className={`font-mono text-xs font-bold tabular-nums ${
                    item.value >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {item.value >= 0 ? '+' : ''}${item.value.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Bucketed Curve Delta Ladder */}
        <div className="bg-[#111827] p-5 rounded border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200 flex items-center gap-2">
              <Scale className="w-4 h-4 text-blue-400" />
              <span>Bucketed Forward Curve Delta Ladder</span>
            </h3>
            <span className="text-[11px] font-mono text-slate-400">Dollar Risk per Bucket</span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {[
              { bucket: '1M (Front Month)', val: bucketSums.m1 },
              { bucket: '3M (Quarterly)', val: bucketSums.m3 },
              { bucket: '6M (Semi-Annual)', val: bucketSums.m6 },
              { bucket: '12M (1-Year)', val: bucketSums.m12 },
              { bucket: '24M (2-Year)', val: bucketSums.m24 },
              { bucket: '36M (3-Year)', val: bucketSums.m36 },
            ].map((b) => {
              const maxB = 3000000;
              const widthPct = Math.min(100, (Math.abs(b.val) / maxB) * 100);
              return (
                <div key={b.bucket} className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-300">{b.bucket}</span>
                    <span className={`font-bold tabular-nums ${b.val >= 0 ? 'text-blue-400' : 'text-amber-400'}`}>
                      {b.val >= 0 ? '+' : ''}${b.val.toLocaleString()}
                    </span>
                  </div>
                  <div className="w-full h-2 bg-[#080C14] rounded overflow-hidden">
                    <div
                      className={`h-full ${b.val >= 0 ? 'bg-blue-600' : 'bg-amber-600'}`}
                      style={{ width: `${widthPct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Position Master Table */}
      <div className="bg-[#111827] rounded border border-slate-800 overflow-hidden shadow-xl">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-blue-400" />
            <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
              Portfolio Positions Blotter ({positions.length} Active Legs)
            </h2>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="bg-[#090D15] text-slate-400 border-b border-slate-800 text-[11px] uppercase">
                <th className="p-3">Position ID</th>
                <th className="p-3">Instrument Name</th>
                <th className="p-3">Commodity</th>
                <th className="p-3">Exposure</th>
                <th className="p-3">Side</th>
                <th className="p-3 text-right">Quantity</th>
                <th className="p-3 text-right">Entry Price</th>
                <th className="p-3 text-right">Current Value</th>
                <th className="p-3 text-right">Notional</th>
                <th className="p-3 text-right">Daily P&L</th>
                <th className="p-3 text-right">Unrealised P&L</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {positions.map((pos) => (
                <tr key={pos.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3 font-bold text-blue-400">{pos.id}</td>
                  <td className="p-3 font-sans text-slate-200 font-medium">{pos.instrumentName}</td>
                  <td className="p-3 font-bold text-slate-300">{pos.commodity_id}</td>
                  <td className="p-3 text-slate-400 text-[11px]">{pos.exposureType}</td>
                  <td className="p-3 font-bold">
                    <span className={pos.side === 'BUY' ? 'text-emerald-400' : 'text-rose-400'}>{pos.side}</span>
                  </td>
                  <td className="p-3 text-right text-slate-200 tabular-nums">
                    {pos.quantity.toLocaleString()} {pos.unit}
                  </td>
                  <td className="p-3 text-right text-slate-300 tabular-nums">${pos.entryPrice.toFixed(2)}</td>
                  <td className="p-3 text-right text-white font-bold tabular-nums">${pos.currentValue.toFixed(2)}</td>
                  <td className="p-3 text-right text-slate-200 tabular-nums">${pos.notionalValue.toLocaleString()}</td>
                  <td
                    className={`p-3 text-right font-bold tabular-nums ${
                      pos.dailyPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {pos.dailyPnL >= 0 ? '+' : ''}${pos.dailyPnL.toLocaleString()}
                  </td>
                  <td
                    className={`p-3 text-right font-bold tabular-nums ${
                      pos.unrealisedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {pos.unrealisedPnL >= 0 ? '+' : ''}${pos.unrealisedPnL.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
