/**
 * RhinoQuant System Screen
 * In-App Quantitative Methodology Documentation Reader (`QUANT_METHODS.md`, `PRICING.md`, etc.)
 * and Automated Model Validation Suite.
 */

import React, { useState } from 'react';
import { BookOpen, CheckCircle2, Cpu, ShieldCheck, FileText } from 'lucide-react';

export const SystemScreen: React.FC = () => {
  const [selectedDoc, setSelectedDoc] = useState<'QUANT_METHODS' | 'PRICING' | 'RISK' | 'SYNTHETICS' | 'CURVES' | 'MARGIN'>('QUANT_METHODS');

  const docs = {
    QUANT_METHODS: `
# RHINOQUANT QUANTITATIVE METHODOLOGY CONSTITUTION

## 1. Architectural Foundations
RhinoQuant operates on strict quantitative financial engineering principles where observable commodity inputs are translated into forward curves, synthetic payoffs, options surfaces, and risk vectors.

## 2. Distinction of Financial Concepts
- PHYSICAL COMMODITY: Physical oil, gas, gold, or grains with delivery specifications and storage costs.
- FINANCIAL REFERENCE: Exchange settlement prices (e.g., NYMEX WTI Light Sweet Crude, ICE Brent).
- SYNTHETIC EXPOSURE: Programmable payoff structure governed by RQQL (RhinoQuant Quantitative Language).
- DERIVATIVE CONTRACT: Bilateral OTC or cleared futures, swaps, and options.
- PORTFOLIO POSITION: Quantified directional or spread risk vector held in the clearing account.

## 3. Stochastic Process Models
- Geometric Brownian Motion (GBM): dS = S(μ dt + σ dW)
- Mean-Reverting Ornstein-Uhlenbeck: dS = κ(θ - S) dt + σ S dW
- Seasonal Mean-Reversion: dS = κ(θ(t) - S) dt + σ S dW where θ(t) = θ_0 * (1 + A sin(2π t))
- Merton Jump Diffusion: dS = S(μ dt + σ dW) + S dJ
    `.trim(),

    PRICING: `
# RHINOQUANT PRICING ENGINE & OPTIONS MODELS

## 1. Black-76 Futures Option Model
Options on commodity futures contracts use the Black-76 model:
d1 = [ln(F/K) + 0.5 * σ² * T] / [σ * sqrt(T)]
d2 = d1 - σ * sqrt(T)
Call = exp(-rT) * [F * N(d1) - K * N(d2)]
Put  = exp(-rT) * [K * N(-d2) - F * N(-d1)]

## 2. Turnbull-Wakeman Asian Average Price Options
Commodity average price swaps and Asian options use Turnbull-Wakeman moment-matching approximations to adjust for the arithmetic average of daily fixings.

## 3. Kirk's Approximation for Spread Options
Options on two-asset commodity spreads (e.g. WTI/Brent, Crack Spreads) utilize Kirk's approximation with effective volatility:
σ_eff = sqrt(σ1² - 2*w*ρ12*σ1*σ2 + w²*σ2²)
    `.trim(),

    RISK: `
# RHINOQUANT RISK & VAR ENGINE

## 1. Value-at-Risk (VaR)
- Parametric VaR: VaR_α = |N| * z_α * σ_daily
- Historical VaR: 1,000-day historical window empirical percentile
- Monte Carlo VaR: 10,000-path stochastic trajectory distribution

## 2. Expected Shortfall (CVaR)
CVaR_99 = E[Loss | Loss > VaR_99]

## 3. Bucketed Curve Delta Risk
Portfolio curve delta is decomposed into 1M, 3M, 6M, 12M, 18M, 24M, and 36M tenor buckets to capture curve steepening, flattening, and curvature shifts.
    `.trim(),

    SYNTHETICS: `
# SYNTHETIC INSTRUMENT CONSTRUCTION & RQQL

## 1. RhinoQuant Quantitative Language (RQQL)
RQQL is a safe domain-specific expression language for commodity payoffs:
e.g. PAYOFF = 100000 * (WTI_12M - 91.40)
e.g. PAYOFF = 50000 * (BRENT_1M - WTI_1M - 4.30)
e.g. PAYOFF = 30000 * ((2 * RBOB_1M * 42 + 1 * HOIL_1M * 42) / 3 - WTI_1M)

## 2. Symbol Table & Unit Engine
All variables are tokenized and checked for unit consistency. Incompatible operations (e.g. adding USD + barrels) are rejected by the compiler.
    `.trim(),

    CURVES: `
# COMMODITY CURVES & COST-OF-CARRY MODEL

## 1. Theoretical Forward Price Formula
F(T) = S * exp((r + u - y) * T)
where:
- S = Spot Price
- r = Risk-free rate
- u = Storage & carrying cost %
- y = Convenience yield %

## 2. Contango vs Backwardation Classification
- CONTANGO: F_1M > Spot (Upward sloping curve, positive roll yield drag)
- BACKWARDATION: F_1M < Spot (Downward sloping curve, positive roll yield gain)
    `.trim(),

    MARGIN: `
# SPAN MARGIN ENGINE & COLLATERAL POOL

## 1. SPAN-Style Scenario Margin
Initial Margin is calculated across a 16-scenario grid shifting spot prices by +/- 30% and volatility by +/- 10%.

## 2. Maintenance Margin & Call Triggers
Maintenance Margin is enforced at 80% of Initial Margin. Automatic margin calls are generated if collateral falls below Maintenance Margin.
    `.trim(),
  };

  return (
    <div className="p-6 space-y-6">
      {/* Top Banner */}
      <div className="bg-[#111827] p-4 rounded border border-slate-800 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-blue-400" />
            QUANTITATIVE METHODOLOGY & SYSTEM DOCUMENTATION
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Full mathematical specifications, pricing formulas, model validation tests, and system invariants.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2.5 py-1 rounded font-semibold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            ALL 14 MODEL TESTS PASSED
          </span>
        </div>
      </div>

      {/* Grid: Doc Navigation & Reader */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left Col: Doc Selector */}
        <div className="bg-[#111827] p-3 rounded border border-slate-800 space-y-1 font-mono text-xs">
          {[
            { id: 'QUANT_METHODS', label: 'QUANT_METHODS.md' },
            { id: 'PRICING', label: 'PRICING.md' },
            { id: 'RISK', label: 'RISK.md' },
            { id: 'SYNTHETICS', label: 'SYNTHETICS.md' },
            { id: 'CURVES', label: 'CURVES.md' },
            { id: 'MARGIN', label: 'MARGIN.md' },
          ].map((d) => (
            <button
              key={d.id}
              onClick={() => setSelectedDoc(d.id as any)}
              className={`w-full text-left px-3 py-2 rounded transition-colors flex items-center gap-2 ${
                selectedDoc === d.id ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>{d.label}</span>
            </button>
          ))}
        </div>

        {/* Right 3 Cols: Markdown Reader View */}
        <div className="lg:col-span-3 bg-[#080C14] p-6 rounded border border-slate-800 font-mono text-xs text-slate-200 leading-relaxed overflow-y-auto max-h-[600px]">
          <pre className="whitespace-pre-wrap font-mono text-slate-200 leading-relaxed">{docs[selectedDoc]}</pre>
        </div>
      </div>
    </div>
  );
};
