/**
 * RhinoQuant Markets Screen
 * Display observable commodity inputs, sectors, bid/ask spreads, provenance, and data quality scores.
 */

import React, { useState } from 'react';
import { CommodityMasterItem, SectorType } from '../types/commodity';
import { COMMODITY_MASTER } from '../quant/master';
import { generateCommodityCurve } from '../quant/curves';
import { Activity, AlertTriangle, ArrowDownRight, ArrowUpRight, CheckCircle2, ShieldCheck } from 'lucide-react';

interface MarketsScreenProps {
  onSelectCommodityForCurve: (id: string) => void;
  onSelectCommodityForSynthetic: (id: string) => void;
}

export const MarketsScreen: React.FC<MarketsScreenProps> = ({
  onSelectCommodityForCurve,
  onSelectCommodityForSynthetic,
}) => {
  const [selectedSector, setSelectedSector] = useState<SectorType | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const sectors: Array<SectorType | 'ALL'> = [
    'ALL',
    'ENERGY',
    'METALS',
    'AGRICULTURE',
    'SOFTS',
    'LIVESTOCK',
    'FREIGHT',
    'ENVIRONMENTAL',
  ];

  const filteredCommodities = COMMODITY_MASTER.filter((c) => {
    const matchesSector = selectedSector === 'ALL' || c.sector === selectedSector;
    const matchesSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.commodity_id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSector && matchesSearch;
  });

  return (
    <div className="p-6 space-y-6">
      {/* Top Sector Overview Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        {[
          { name: 'Energy', code: 'ENERGY', count: 7, benchmark: 'WTI $92.10 (+0.8%)' },
          { name: 'Metals', code: 'METALS', count: 4, benchmark: 'Gold $2,850.10 (+0.3%)' },
          { name: 'Agriculture', code: 'AGRICULTURE', count: 5, benchmark: 'Corn $4.45 (-0.4%)' },
          { name: 'Softs', code: 'SOFTS', count: 2, benchmark: 'Cocoa $7,850.00 (+1.4%)' },
          { name: 'Livestock', code: 'LIVESTOCK', count: 1, benchmark: 'Cattle $1.84 (+0.2%)' },
          { name: 'Freight', code: 'FREIGHT', count: 1, benchmark: 'Capesize $22.4k (+2.1%)' },
          { name: 'Carbon', code: 'ENVIRONMENTAL', count: 1, benchmark: 'EUA €84.20 (-0.6%)' },
        ].map((sec) => (
          <button
            key={sec.code}
            onClick={() => setSelectedSector(sec.code as any)}
            className={`p-3 rounded border text-left transition-all ${
              selectedSector === sec.code
                ? 'bg-blue-950/60 border-blue-500 text-white'
                : 'bg-[#111827] border-slate-800 text-slate-300 hover:border-slate-700'
            }`}
          >
            <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">{sec.name}</div>
            <div className="text-xs font-mono font-medium text-slate-200 mt-1">{sec.benchmark}</div>
            <div className="text-[10px] text-slate-500 mt-1">{sec.count} Instruments</div>
          </button>
        ))}
      </div>

      {/* Main Filter & Search Control Row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#111827] p-3 rounded border border-slate-800">
        {/* Sector Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto">
          {sectors.map((sec) => (
            <button
              key={sec}
              onClick={() => setSelectedSector(sec)}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                selectedSector === sec
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {sec}
            </button>
          ))}
        </div>

        {/* Search Bar */}
        <div className="w-full md:w-64">
          <input
            type="text"
            placeholder="Search commodity or symbol..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-3 py-1.5 bg-[#0D131F] border border-slate-700 rounded text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Commodity Master Market Grid Table */}
      <div className="bg-[#111827] rounded border border-slate-800 overflow-hidden shadow-xl">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-blue-400" />
            <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
              Commodity Master Inputs ({filteredCommodities.length} Verified Tickers)
            </h2>
          </div>
          <div className="text-[11px] text-slate-400 flex items-center gap-3">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Provenance Tracked
            </span>
            <span>·</span>
            <span className="flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
              Data Quality 99.8%
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-[#090D15] text-slate-400 border-b border-slate-800 font-mono text-[11px] uppercase">
                <th className="p-3">ID / Ticker</th>
                <th className="p-3">Commodity Name</th>
                <th className="p-3">Sector</th>
                <th className="p-3">Delivery Location</th>
                <th className="p-3">Quality / Specification</th>
                <th className="p-3 text-right">Spot Mid</th>
                <th className="p-3 text-right">1M Futures</th>
                <th className="p-3 text-center">Regime</th>
                <th className="p-3 text-center">Quality Score</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filteredCommodities.map((comm) => {
                const curve = generateCommodityCurve(comm.commodity_id);
                const spot = curve.spotPrice;
                const m1 = curve.points[1]?.price || spot;

                return (
                  <tr key={comm.commodity_id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="p-3 font-bold text-blue-400">{comm.commodity_id}</td>
                    <td className="p-3 text-slate-200 font-sans font-medium">{comm.name}</td>
                    <td className="p-3 text-slate-400">{comm.sector}</td>
                    <td className="p-3 text-slate-400 font-sans text-[11px]">{comm.location}</td>
                    <td className="p-3 text-slate-400 font-sans text-[11px] max-w-xs truncate">{comm.quality}</td>
                    <td className="p-3 text-right font-bold text-white tabular-nums">
                      {comm.currency === 'EUR' ? '€' : '$'}
                      {spot.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="p-3 text-right text-slate-300 tabular-nums">
                      {comm.currency === 'EUR' ? '€' : '$'}
                      {m1.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="p-3 text-center">
                      {curve.regime === 'BACKWARDATION' ? (
                        <span className="text-[10px] font-sans font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
                          BACKWARDATION
                        </span>
                      ) : curve.regime === 'CONTANGO' ? (
                        <span className="text-[10px] font-sans font-semibold text-amber-400 bg-amber-950/60 border border-amber-800/60 px-2 py-0.5 rounded">
                          CONTANGO
                        </span>
                      ) : (
                        <span className="text-[10px] font-sans text-slate-400">FLAT</span>
                      )}
                    </td>
                    <td className="p-3 text-center">
                      <div className="inline-flex items-center gap-1 text-[11px] text-emerald-400 font-semibold">
                        <span>99.8%</span>
                      </div>
                    </td>
                    <td className="p-3 text-right space-x-2">
                      <button
                        onClick={() => onSelectCommodityForCurve(comm.commodity_id)}
                        className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] rounded transition-colors"
                      >
                        Curve
                      </button>
                      <button
                        onClick={() => onSelectCommodityForSynthetic(comm.commodity_id)}
                        className="px-2 py-1 bg-blue-600 hover:bg-blue-500 text-white text-[11px] rounded font-semibold transition-colors"
                      >
                        + Synthetic
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
