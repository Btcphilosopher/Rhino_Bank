/**
 * RhinoQuant Institutional Header & Top Bar Navigation
 */

import React from 'react';
import { Activity, Bot, ChevronDown, Cpu, RefreshCw, ShieldAlert, Sparkles } from 'lucide-react';

export type WorkspaceTab =
  | 'MARKETS'
  | 'CURVES'
  | 'SYNTHETICS'
  | 'PORTFOLIO'
  | 'RISK'
  | 'SCENARIOS'
  | 'TRADING'
  | 'SETTLEMENT'
  | 'RESEARCH'
  | 'SYSTEM';

interface HeaderProps {
  activeTab: WorkspaceTab;
  setActiveTab: (tab: WorkspaceTab) => void;
  isLiveTicks: boolean;
  setIsLiveTicks: (live: boolean) => void;
  onOpenAiResearch: () => void;
  userRole: string;
  setUserRole: (role: string) => void;
  var99_1d: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  isLiveTicks,
  setIsLiveTicks,
  onOpenAiResearch,
  userRole,
  setUserRole,
  var99_1d,
}) => {
  const tabs: WorkspaceTab[] = [
    'MARKETS',
    'CURVES',
    'SYNTHETICS',
    'PORTFOLIO',
    'RISK',
    'SCENARIOS',
    'TRADING',
    'SETTLEMENT',
    'RESEARCH',
    'SYSTEM',
  ];

  const roles = [
    'Trader',
    'Quant',
    'RiskManager',
    'PortfolioManager',
    'Operations',
    'Treasury',
    'Compliance',
    'Administrator',
    'ReadOnly',
  ];

  return (
    <header className="bg-[#0D131F] border-b border-slate-800 text-slate-200 select-none sticky top-0 z-40">
      {/* Top Banner Row */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800/80 text-xs">
        {/* Zone 1: Single element Brand */}
        <div className="flex items-center gap-3">
          <a href="#" className="flex items-center gap-2 font-bold text-base tracking-wider text-white">
            <span className="bg-blue-600 text-white p-1 rounded font-mono text-xs">RQ</span>
            <span>RHINOQUANT</span>
          </a>
          <span className="text-slate-500 hidden sm:inline">·</span>
          <span className="text-slate-400 font-medium hidden sm:inline">Synthetic Commodities Platform</span>
          <span className="text-slate-600">·</span>
          <span className="text-slate-400 font-mono text-[11px] text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
            SIMULATED FEED (CUSHING / LME / ICE)
          </span>
        </div>

        {/* Top Controls Right */}
        <div className="flex items-center gap-4">
          {/* Quick Risk Indicator */}
          <div className="hidden lg:flex items-center gap-2 text-slate-400 font-mono text-xs">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            <span>1D VaR 99%:</span>
            <span className="text-amber-300 font-semibold tabular-nums">${(var99_1d / 1000).toFixed(1)}k</span>
          </div>

          <div className="h-3 w-px bg-slate-800 hidden sm:block" />

          {/* Live Ticks Toggle */}
          <button
            onClick={() => setIsLiveTicks(!isLiveTicks)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors ${
              isLiveTicks ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/60' : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
            title="Toggle live simulated tick streaming"
          >
            <Activity className={`w-3.5 h-3.5 ${isLiveTicks ? 'animate-spin' : ''}`} />
            <span>{isLiveTicks ? 'Ticks Active' : 'Pause Ticks'}</span>
          </button>

          {/* AI Research Workbench Drawer Trigger */}
          <button
            onClick={onOpenAiResearch}
            className="flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-blue-700 to-indigo-700 hover:from-blue-600 hover:to-indigo-600 text-white rounded font-medium text-xs shadow-sm transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-200" />
            <span>Quant Assistant</span>
          </button>

          {/* Role Switcher */}
          <div className="relative group">
            <button className="flex items-center gap-1.5 px-2 py-1 bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 rounded text-xs text-slate-300">
              <span className="text-slate-400">Role:</span>
              <span className="font-semibold text-white">{userRole}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>
            <div className="absolute right-0 top-full mt-1 w-40 bg-[#121927] border border-slate-700 rounded shadow-xl hidden group-hover:block z-50 py-1">
              {roles.map((r) => (
                <button
                  key={r}
                  onClick={() => setUserRole(r)}
                  className={`w-full text-left px-3 py-1.5 text-xs hover:bg-slate-800 transition-colors ${
                    userRole === r ? 'text-blue-400 font-semibold bg-blue-950/30' : 'text-slate-300'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs Bar */}
      <div className="flex items-center overflow-x-auto px-3 bg-[#090D15]">
        {tabs.map((tab) => {
          const isActive = activeTab === tab;
          return (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2.5 text-xs font-semibold tracking-wider whitespace-nowrap transition-colors border-b-2 ${
                isActive
                  ? 'border-blue-500 text-blue-400 bg-slate-900/60'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/30'
              }`}
            >
              {tab}
            </button>
          );
        })}
      </div>
    </header>
  );
};
