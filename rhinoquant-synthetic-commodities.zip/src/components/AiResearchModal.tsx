/**
 * RhinoQuant AI Quantitative Research Drawer Modal
 */

import React, { useState } from 'react';
import { Bot, RefreshCw, Send, Sparkles, X } from 'lucide-react';

interface AiResearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AiResearchModal: React.FC<AiResearchModalProps> = ({ isOpen, onClose }) => {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = async () => {
    if (!prompt.trim()) return;
    setIsLoading(true);
    setResponse(null);

    try {
      const res = await fetch('/api/gemini/research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      });
      const data = await res.json();
      if (data.success) {
        setResponse(data.text);
      } else {
        setResponse(`Error: ${data.error}`);
      }
    } catch (err: any) {
      setResponse(`Error: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex justify-end">
      <div className="w-full max-w-lg bg-[#0D131F] border-l border-slate-800 h-full flex flex-col justify-between p-6 space-y-4 shadow-2xl">
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-400" />
              <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                RhinoQuant Quantitative Analyst Assistant
              </h3>
            </div>
            <button onClick={onClose} className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Prompt Ideas */}
          <div className="space-y-1.5">
            <span className="text-[10px] uppercase font-mono text-slate-400 font-semibold block">Suggested Queries:</span>
            <div className="flex flex-wrap gap-1.5 font-mono text-[11px]">
              {[
                'Analyze WTI/Brent backwardation vs contango risk',
                'Construct 3:2:1 crack spread RQQL formula',
                'Calculate SPAN initial margin for 100k bbl WTI',
                'Recommend optimal hedge for European NatGas spike',
              ].map((p) => (
                <button
                  key={p}
                  onClick={() => setPrompt(p)}
                  className="px-2 py-1 bg-[#111827] hover:bg-slate-800 text-blue-300 border border-slate-800 rounded text-left transition-colors"
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* Output Window */}
          <div className="h-80 bg-[#080C14] rounded border border-slate-800 p-4 overflow-y-auto font-mono text-xs text-slate-200 leading-relaxed space-y-2">
            {isLoading ? (
              <div className="flex items-center justify-center h-full text-blue-400 gap-2">
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Querying Gemini 2.5 Flash Server-Side API...</span>
              </div>
            ) : response ? (
              <div className="whitespace-pre-wrap">{response}</div>
            ) : (
              <div className="text-slate-500 italic text-center pt-24 text-[11px]">
                Type a natural language quantitative finance prompt or click a suggested query above.
              </div>
            )}
          </div>
        </div>

        {/* Input Bar */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
          <input
            type="text"
            placeholder="Ask a quantitative finance question..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            className="w-full bg-[#111827] border border-slate-700 rounded px-3 py-2 text-xs text-white font-mono placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !prompt.trim()}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-bold shrink-0 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
