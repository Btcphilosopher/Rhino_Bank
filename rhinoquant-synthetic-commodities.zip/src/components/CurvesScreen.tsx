/**
 * RhinoQuant Curves Screen
 * Interactive Forward Curves Terminal, Contango/Backwardation Diagnostics,
 * Convenience Yield Calibrator, Roll Yield, and Calendar Spreads.
 */

import React, { useState } from 'react';
import { CommodityCurveData } from '../types/commodity';
import { COMMODITY_MASTER } from '../quant/master';
import { calculateCalendarSpread, generateCommodityCurve } from '../quant/curves';
import { TrendingDown, TrendingUp, Layers, RefreshCw, Sliders } from 'lucide-react';

interface CurvesScreenProps {
  initialCommodityId?: string;
}

export const CurvesScreen: React.FC<CurvesScreenProps> = ({ initialCommodityId = 'WTI' }) => {
  const [selectedCommodityId, setSelectedCommodityId] = useState(initialCommodityId);
  const [compareCommodityId, setCompareCommodityId] = useState<string | null>('BRENT');

  // Custom storage & convenience yield inputs for interactive calibration
  const [riskFreeRatePct, setRiskFreeRatePct] = useState(4.5);
  const [storageCostPct, setStorageCostPct] = useState(4.0);
  const [convenienceYieldPct, setConvenienceYieldPct] = useState(6.0);

  const curve = generateCommodityCurve(selectedCommodityId);
  const compareCurve = compareCommodityId ? generateCommodityCurve(compareCommodityId) : null;

  const calendarSpread1M3M = calculateCalendarSpread(curve, '1M', '3M');
  const calendarSpread1M12M = calculateCalendarSpread(curve, '1M', '12M');

  // Compute SVG chart coordinates
  const points = curve.points;
  const maxPrice = Math.max(...points.map((p) => p.price), compareCurve ? Math.max(...compareCurve.points.map((p) => p.price)) : 0) * 1.05;
  const minPrice = Math.min(...points.map((p) => p.price), compareCurve ? Math.min(...compareCurve.points.map((p) => p.price)) : 1000) * 0.95;

  const chartWidth = 700;
  const chartHeight = 260;
  const padding = 40;

  const getSvgX = (index: number) => padding + (index / (points.length - 1)) * (chartWidth - 2 * padding);
  const getSvgY = (price: number) => chartHeight - padding - ((price - minPrice) / (maxPrice - minPrice || 1)) * (chartHeight - 2 * padding);

  const curvePathD = points.reduce((acc, p, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${getSvgX(i)} ${getSvgY(p.price)}`, '');
  const comparePathD = compareCurve
    ? compareCurve.points.reduce((acc, p, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${getSvgX(i)} ${getSvgY(p.price)}`, '')
    : '';

  return (
    <div className="p-6 space-y-6">
      {/* Top Header & Commodity Selector Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#111827] p-4 rounded border border-slate-800">
        <div className="flex items-center gap-4">
          <div>
            <label className="text-[10px] text-slate-400 uppercase font-semibold block">Primary Curve</label>
            <select
              value={selectedCommodityId}
              onChange={(e) => setSelectedCommodityId(e.target.value)}
              className="mt-1 bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs font-bold text-blue-400 focus:outline-none"
            >
              {COMMODITY_MASTER.map((c) => (
                <option key={c.commodity_id} value={c.commodity_id}>
                  {c.commodity_id} - {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] text-slate-400 uppercase font-semibold block">Overlay Curve</label>
            <select
              value={compareCommodityId || ''}
              onChange={(e) => setCompareCommodityId(e.target.value || null)}
              className="mt-1 bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs font-semibold text-amber-400 focus:outline-none"
            >
              <option value="">None (Single Curve)</option>
              {COMMODITY_MASTER.filter((c) => c.commodity_id !== selectedCommodityId).map((c) => (
                <option key={c.commodity_id} value={c.commodity_id}>
                  {c.commodity_id} - {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick Diagnostics */}
        <div className="flex items-center gap-6 font-mono text-xs">
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Curve Regime</span>
            <span
              className={`font-bold ${
                curve.regime === 'BACKWARDATION' ? 'text-emerald-400' : curve.regime === 'CONTANGO' ? 'text-amber-400' : 'text-slate-300'
              }`}
            >
              {curve.regime}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Annualised Roll Yield</span>
            <span className="font-bold text-slate-200 tabular-nums">{(curve.annualisedRollYieldPct * 100).toFixed(2)}%</span>
          </div>

          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Basis (Spot - 1M)</span>
            <span className="font-bold text-blue-400 tabular-nums">${curve.basis.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Grid Layout: SVG Chart & Curve Points Data Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Interactive Visual Curve Canvas */}
        <div className="lg:col-span-2 bg-[#111827] p-5 rounded border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-400" />
              <h2 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
                Term Structure Canvas: {curve.symbol} ({curve.commodity_id})
                {compareCurve ? ` vs ${compareCurve.symbol} (${compareCurve.commodity_id})` : ''}
              </h2>
            </div>
            <div className="text-[11px] font-mono text-slate-400">
              As of {curve.asOfDate} · NYMEX/ICE Settlement
            </div>
          </div>

          {/* SVG Chart */}
          <div className="w-full overflow-x-auto bg-[#090D15] p-3 rounded border border-slate-800">
            <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-auto">
              {/* Horizontal gridlines */}
              {[0.2, 0.4, 0.6, 0.8].map((ratio) => {
                const y = padding + ratio * (chartHeight - 2 * padding);
                const priceVal = maxPrice - ratio * (maxPrice - minPrice);
                return (
                  <g key={ratio}>
                    <line x1={padding} y1={y} x2={chartWidth - padding} y2={y} stroke="#1E293B" strokeDasharray="3 3" />
                    <text x={padding - 8} y={y + 3} fill="#64748B" fontSize="10" textAnchor="end" className="font-mono">
                      ${priceVal.toFixed(1)}
                    </text>
                  </g>
                );
              })}

              {/* Tenor X-Axis Labels */}
              {points.map((p, i) => {
                const x = getSvgX(i);
                return (
                  <g key={p.tenor}>
                    <line x1={x} y1={chartHeight - padding} x2={x} y2={chartHeight - padding + 5} stroke="#334155" />
                    <text x={x} y={chartHeight - padding + 18} fill="#94A3B8" fontSize="10" textAnchor="middle" className="font-mono font-semibold">
                      {p.tenor}
                    </text>
                  </g>
                );
              })}

              {/* Compare Curve Path */}
              {compareCurve && (
                <path d={comparePathD} fill="none" stroke="#F59E0B" strokeWidth="2" strokeDasharray="4 4" />
              )}

              {/* Primary Curve Path */}
              <path d={curvePathD} fill="none" stroke="#3B82F6" strokeWidth="3" />

              {/* Data Points */}
              {points.map((p, i) => {
                const x = getSvgX(i);
                const y = getSvgY(p.price);
                return (
                  <g key={p.tenor} className="group cursor-pointer">
                    <circle cx={x} cy={y} r="5" fill="#1D4ED8" stroke="#FFFFFF" strokeWidth="2" />
                    <text x={x} y={y - 12} fill="#60A5FA" fontSize="11" fontWeight="bold" textAnchor="middle" className="font-mono">
                      ${p.price.toFixed(2)}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Legend */}
          <div className="flex items-center gap-6 text-xs font-mono text-slate-400 pt-1">
            <div className="flex items-center gap-2">
              <div className="w-3 h-1 bg-blue-500 rounded" />
              <span>{curve.symbol} ({curve.commodity_id})</span>
            </div>
            {compareCurve && (
              <div className="flex items-center gap-2">
                <div className="w-3 h-1 bg-amber-500 border-dashed rounded" />
                <span>{compareCurve.symbol} ({compareCurve.commodity_id})</span>
              </div>
            )}
          </div>
        </div>

        {/* Right Col: Cost-of-Carry Model Calibrator */}
        <div className="bg-[#111827] p-5 rounded border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Sliders className="w-4 h-4 text-blue-400" />
            <h3 className="text-xs font-semibold uppercase text-slate-200">Storage & Convenience Yield Model</h3>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 bg-[#090D15] rounded border border-slate-800 text-slate-300">
              <span className="text-[11px] text-slate-400 block">Theoretical Carry Formula:</span>
              <span className="font-bold text-blue-400 text-sm">F(T) = S · exp((r + u - y)T)</span>
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">
                Risk-Free Financing Rate (r): <span className="text-white font-bold">{riskFreeRatePct}%</span>
              </label>
              <input
                type="range"
                min="0"
                max="10"
                step="0.1"
                value={riskFreeRatePct}
                onChange={(e) => setRiskFreeRatePct(parseFloat(e.target.value))}
                className="w-full accent-blue-600"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">
                Storage & Carrying Cost (u): <span className="text-white font-bold">{storageCostPct}%</span>
              </label>
              <input
                type="range"
                min="0"
                max="15"
                step="0.1"
                value={storageCostPct}
                onChange={(e) => setStorageCostPct(parseFloat(e.target.value))}
                className="w-full accent-blue-600"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">
                Implied Convenience Yield (y): <span className="text-white font-bold">{convenienceYieldPct}%</span>
              </label>
              <input
                type="range"
                min="0"
                max="25"
                step="0.1"
                value={convenienceYieldPct}
                onChange={(e) => setConvenienceYieldPct(parseFloat(e.target.value))}
                className="w-full accent-blue-600"
              />
            </div>

            {/* Implied Net Cost of Carry Rate */}
            <div className="pt-2 border-t border-slate-800">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Net Cost of Carry (r + u - y):</span>
                <span className={`font-bold tabular-nums ${riskFreeRatePct + storageCostPct - convenienceYieldPct < 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {(riskFreeRatePct + storageCostPct - convenienceYieldPct).toFixed(2)}%
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Curve Tenor Points Detailed Table */}
      <div className="bg-[#111827] rounded border border-slate-800 overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 text-xs font-semibold uppercase tracking-wider text-slate-200">
          Forward Curve Tenor Data ({curve.commodity_id})
        </div>
        <table className="w-full text-left text-xs font-mono">
          <thead>
            <tr className="bg-[#090D15] text-slate-400 border-b border-slate-800 text-[11px] uppercase">
              <th className="p-3">Tenor</th>
              <th className="p-3">Months</th>
              <th className="p-3 text-right">Bid</th>
              <th className="p-3 text-right">Ask</th>
              <th className="p-3 text-right">Mid Settlement</th>
              <th className="p-3 text-right">Spread vs Spot</th>
              <th className="p-3 text-right">Implied Volatility</th>
              <th className="p-3 text-right">Open Interest</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {points.map((pt) => {
              const spread = pt.price - curve.spotPrice;
              return (
                <tr key={pt.tenor} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3 font-bold text-blue-400">{pt.tenor}</td>
                  <td className="p-3 text-slate-300">{pt.months}M</td>
                  <td className="p-3 text-right text-slate-400 tabular-nums">${pt.bid.toFixed(2)}</td>
                  <td className="p-3 text-right text-slate-400 tabular-nums">${pt.ask.toFixed(2)}</td>
                  <td className="p-3 text-right font-bold text-white tabular-nums">${pt.price.toFixed(2)}</td>
                  <td className={`p-3 text-right font-semibold tabular-nums ${spread >= 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {spread >= 0 ? '+' : ''}${spread.toFixed(2)}
                  </td>
                  <td className="p-3 text-right text-slate-300 tabular-nums">{(pt.impliedVol * 100).toFixed(1)}%</td>
                  <td className="p-3 text-right text-slate-400 tabular-nums">{pt.openInterest.toLocaleString()}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
