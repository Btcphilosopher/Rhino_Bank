/**
 * RhinoQuant Risk Dashboard & SPAN Margin Engine
 * VaR, Expected Shortfall (CVaR), Options Greeks, Margin Calls, Counterparty Credit Exposure.
 */

import React from 'react';
import { RiskMetrics } from '../types/commodity';
import { ShieldAlert, AlertTriangle, Activity, Scale, Zap, Lock } from 'lucide-react';

interface RiskScreenProps {
  risk: RiskMetrics;
}

export const RiskScreen: React.FC<RiskScreenProps> = ({ risk }) => {
  return (
    <div className="p-6 space-y-6">
      {/* Top Value-at-Risk Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#111827] p-4 rounded border border-slate-800">
          <span className="text-[10px] text-slate-400 uppercase font-semibold">1-Day 95% Value-at-Risk</span>
          <div className="text-xl font-bold font-mono text-amber-400 mt-1 tabular-nums">
            ${risk.var95_1d.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-[10px] text-slate-500 font-mono mt-1 block">Parametric Normal Distribution</span>
        </div>

        <div className="bg-[#111827] p-4 rounded border border-slate-800">
          <span className="text-[10px] text-slate-400 uppercase font-semibold">1-Day 99% Value-at-Risk</span>
          <div className="text-xl font-bold font-mono text-amber-300 mt-1 tabular-nums">
            ${risk.var99_1d.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-[10px] text-slate-500 font-mono mt-1 block">Historical Simulation Replay</span>
        </div>

        <div className="bg-[#111827] p-4 rounded border border-slate-800">
          <span className="text-[10px] text-slate-400 uppercase font-semibold">Expected Shortfall 99% (CVaR)</span>
          <div className="text-xl font-bold font-mono text-rose-400 mt-1 tabular-nums">
            ${risk.expectedShortfall99.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-[10px] text-slate-500 font-mono mt-1 block">Tail Risk Average Loss Beyond 99%</span>
        </div>

        <div className="bg-[#111827] p-4 rounded border border-slate-800">
          <span className="text-[10px] text-slate-400 uppercase font-semibold">10-Day 99% Regulatory VaR</span>
          <div className="text-xl font-bold font-mono text-amber-400 mt-1 tabular-nums">
            ${risk.var99_10d.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-[10px] text-slate-500 font-mono mt-1 block">Basel III Commodity Trading Limit</span>
        </div>
      </div>

      {/* Grid: Commodity Greeks & SPAN Margin Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Commodity Greeks Summary Table */}
        <div className="bg-[#111827] p-5 rounded border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200 flex items-center gap-2">
              <Zap className="w-4 h-4 text-blue-400" />
              <span>Portfolio Sensitivity Greeks Matrix</span>
            </h3>
            <span className="text-[11px] font-mono text-slate-400">First & Second Order Sensitivities</span>
          </div>

          <div className="space-y-2 font-mono text-xs">
            <div className="flex justify-between items-center p-3 bg-[#090D15] rounded border border-slate-800">
              <span className="text-slate-300">Spot Delta (Delta Dollar Equivalent):</span>
              <span className="font-bold text-white tabular-nums">${risk.totalSpotDelta.toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-[#090D15] rounded border border-slate-800">
              <span className="text-slate-300">Vega (Volatility 1% Shift Sensitivity):</span>
              <span className="font-bold text-blue-400 tabular-nums">${risk.totalVega.toLocaleString()} / vol point</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-[#090D15] rounded border border-slate-800">
              <span className="text-slate-300">Gamma (Spot Convexity Sensitivity):</span>
              <span className="font-bold text-slate-200 tabular-nums">{risk.totalGamma}</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-[#090D15] rounded border border-slate-800">
              <span className="text-slate-300">Basis Risk Delta (Cross-Commodity Spread):</span>
              <span className="font-bold text-amber-400 tabular-nums">${risk.totalBasisRisk.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* SPAN Margin & Collateral Management */}
        <div className="bg-[#111827] p-5 rounded border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200 flex items-center gap-2">
              <Scale className="w-4 h-4 text-blue-400" />
              <span>SPAN Margin & Collateral Pool</span>
            </h3>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
              MARGIN ADEQUATE
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between items-center p-2.5 bg-[#090D15] rounded border border-slate-800">
              <span className="text-slate-400">Initial Margin Requirement (SPAN):</span>
              <span className="font-bold text-amber-300 tabular-nums">${risk.initialMargin.toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center p-2.5 bg-[#090D15] rounded border border-slate-800">
              <span className="text-slate-400">Maintenance Margin Trigger:</span>
              <span className="font-bold text-slate-300 tabular-nums">${risk.maintenanceMargin.toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center p-2.5 bg-[#090D15] rounded border border-slate-800">
              <span className="text-slate-400">Collateral Posted (Cash / US Treasuries):</span>
              <span className="font-bold text-emerald-400 tabular-nums">${risk.collateralPosted.toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center p-2.5 bg-[#090D15] rounded border border-slate-800">
              <span className="text-slate-400">Available Excess Collateral Buffer:</span>
              <span className="font-bold text-blue-400 tabular-nums">${risk.availableCollateral.toLocaleString()}</span>
            </div>

            {/* Collateral Utilization Progress Bar */}
            <div className="pt-2">
              <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                <span>Margin Utilization:</span>
                <span className="font-bold text-slate-200">
                  {((risk.initialMargin / risk.collateralPosted) * 100).toFixed(1)}%
                </span>
              </div>
              <div className="w-full h-2.5 bg-[#080C14] rounded overflow-hidden">
                <div
                  className="h-full bg-blue-600 rounded"
                  style={{ width: `${(risk.initialMargin / risk.collateralPosted) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Counterparty Credit Exposure (PFE & CSA Thresholds) */}
      <div className="bg-[#111827] rounded border border-slate-800 p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-blue-400" />
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
              OTC Counterparty Credit Exposure & Potential Future Exposure (PFE)
            </h3>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          <div className="p-3 bg-[#090D15] rounded border border-slate-800">
            <span className="text-[10px] text-slate-400 block uppercase">1-Year PFE (95% Confidence)</span>
            <span className="text-base font-bold text-amber-400 block mt-1">${risk.potentialFutureExposure.toLocaleString()}</span>
          </div>

          <div className="p-3 bg-[#090D15] rounded border border-slate-800">
            <span className="text-[10px] text-slate-400 block uppercase">Barclays Capital OTC Netting Set</span>
            <span className="text-base font-bold text-slate-200 block mt-1">Current Exposure: $1.42m</span>
            <span className="text-[10px] text-slate-500 block">CSA Minimum Transfer Amount: $250,000</span>
          </div>

          <div className="p-3 bg-[#090D15] rounded border border-slate-800">
            <span className="text-[10px] text-slate-400 block uppercase">Goldman Sachs OTC Netting Set</span>
            <span className="text-base font-bold text-slate-200 block mt-1">Current Exposure: $850,000</span>
            <span className="text-[10px] text-slate-500 block">CSA Minimum Transfer Amount: $250,000</span>
          </div>
        </div>
      </div>
    </div>
  );
};
