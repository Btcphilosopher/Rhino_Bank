/**
 * RhinoQuant Synthetics Screen
 * Synthetic Instrument Builder, RQQL Code Editor, AST Validator & Payoff Visualizer.
 */

import React, { useState } from 'react';
import { CommodityMasterItem, SyntheticInstrument, SyntheticInstrumentType } from '../types/commodity';
import { COMMODITY_MASTER } from '../quant/master';
import { RQQLCompiler } from '../quant/rqql';
import { Code2, Play, Plus, Sparkles, CheckCircle2, AlertCircle, Layers } from 'lucide-react';

interface SyntheticsScreenProps {
  synthetics: SyntheticInstrument[];
  onSyntheticCreated: () => void;
  preselectedCommodityId?: string;
}

export const SyntheticsScreen: React.FC<SyntheticsScreenProps> = ({
  synthetics,
  onSyntheticCreated,
  preselectedCommodityId = 'WTI',
}) => {
  const [synthType, setSynthType] = useState<SyntheticInstrumentType>('SyntheticForward');
  const [referenceCommodityId, setReferenceCommodityId] = useState(preselectedCommodityId);
  const [synthName, setSynthName] = useState('WTI / Brent Differential Basis Swap');
  const [quantity, setQuantity] = useState(50000);
  const [formulaCode, setFormulaCode] = useState('PAYOFF = 50000 * (BRENT_1M - WTI_1M - 4.30)');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [creationMessage, setCreationMessage] = useState<string | null>(null);

  // Validate formula in real time via RQQL Compiler
  const validation = RQQLCompiler.validateAndParse(formulaCode);

  // Preset formula templates
  const applyPreset = (preset: 'FORWARD' | 'BASIS' | 'CRACK' | 'BASKET' | 'CRUSH') => {
    if (preset === 'FORWARD') {
      setSynthType('SyntheticForward');
      setReferenceCommodityId('WTI');
      setSynthName('WTI Jun 2027 Synthetic Forward (+35bp Basis)');
      setQuantity(100000);
      setFormulaCode('PAYOFF = 100000 * (WTI_12M - 91.40)');
    } else if (preset === 'BASIS') {
      setSynthType('BasisSwap');
      setReferenceCommodityId('WTI');
      setSynthName('WTI / Brent Differential Basis Swap');
      setQuantity(50000);
      setFormulaCode('PAYOFF = 50000 * (BRENT_1M - WTI_1M - 4.30)');
    } else if (preset === 'CRACK') {
      setSynthType('CrackSpread');
      setReferenceCommodityId('WTI');
      setSynthName('3:2:1 Refinery Crack Spread (WTI -> Gasoline/HOIL)');
      setQuantity(30000);
      setFormulaCode('PAYOFF = 30000 * ((2 * RBOB_1M * 42 + 1 * HOIL_1M * 42) / 3 - WTI_1M)');
    } else if (preset === 'BASKET') {
      setSynthType('CommodityBasket');
      setReferenceCommodityId('WTI');
      setSynthName('Rhino Diversified Energy Basket Index');
      setQuantity(10000);
      setFormulaCode('PAYOFF = 0.30 * WTI_1M + 0.25 * BRENT_1M + 0.20 * NGAS_1M + 0.15 * POWER_1M + 0.10 * CARBON_1M');
    } else if (preset === 'CRUSH') {
      setSynthType('CrushSpread');
      setReferenceCommodityId('SOYBEAN');
      setSynthName('Soybean Crush Spread (Soy -> Meal & Oil)');
      setQuantity(20000);
      setFormulaCode('PAYOFF = 20000 * (0.022 * ZM_1M + 11.0 * ZL_1M - ZS_1M)');
    }
  };

  const handleCreateSynthetic = async () => {
    if (!validation.isValid) return;
    setIsSubmitting(true);
    setCreationMessage(null);

    try {
      const res = await fetch('/api/synthetics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: synthName,
          type: synthType,
          referenceCommodityId,
          quantity,
          priceFormula: formulaCode,
          quantityUnit: 'barrel',
          currency: 'USD',
          settlementRule: 'MONTHLY_AVERAGE',
        }),
      });

      const data = await res.json();
      if (data.success) {
        setCreationMessage(`Successfully created synthetic instrument ${data.synthetic.id}!`);
        onSyntheticCreated();
      } else {
        setCreationMessage(`Error: ${data.errors?.join(', ')}`);
      }
    } catch (err: any) {
      setCreationMessage(`Error: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Top Banner & Formula Presets Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#111827] p-4 rounded border border-slate-800">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <Code2 className="w-4 h-4 text-blue-400" />
            SYNTHETIC COMMODITY WORKBENCH (RQQL COMPILER)
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Define custom payoff mathematics, pricing rules, and leg combinations for synthetic commodities.
          </p>
        </div>

        {/* Presets */}
        <div className="flex items-center gap-1.5 overflow-x-auto">
          <span className="text-[11px] font-mono text-slate-400 uppercase font-semibold mr-1">Presets:</span>
          {[
            { label: 'Synthetic Forward', id: 'FORWARD' },
            { label: 'WTI/Brent Basis', id: 'BASIS' },
            { label: '3:2:1 Crack Spread', id: 'CRACK' },
            { label: 'Soybean Crush', id: 'CRUSH' },
            { label: 'Energy Basket', id: 'BASKET' },
          ].map((p) => (
            <button
              key={p.id}
              onClick={() => applyPreset(p.id as any)}
              className="px-2.5 py-1 bg-[#0D131F] hover:bg-slate-800 text-blue-300 border border-slate-700/80 rounded text-xs font-mono transition-colors whitespace-nowrap"
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Form Editor & Compiler Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Payoff Formula Editor & Configuration */}
        <div className="lg:col-span-2 bg-[#111827] p-5 rounded border border-slate-800 space-y-5">
          {/* Form Header Inputs */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                Instrument Structure Type
              </label>
              <select
                value={synthType}
                onChange={(e) => setSynthType(e.target.value as any)}
                className="w-full bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs font-semibold text-white focus:outline-none"
              >
                <option value="SyntheticForward">Synthetic Forward</option>
                <option value="CommoditySwap">Fixed/Floating Swap</option>
                <option value="BasisSwap">Differential Basis Swap</option>
                <option value="CalendarSpread">Calendar Spread</option>
                <option value="CrackSpread">Refinery Crack Spread</option>
                <option value="CrushSpread">Agricultural Crush Spread</option>
                <option value="CommodityBasket">Commodity Basket</option>
                <option value="SyntheticCommodityIndex">Synthetic Commodity Index</option>
                <option value="CommodityOption">Commodity Option (Black-76)</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                Primary Reference Asset
              </label>
              <select
                value={referenceCommodityId}
                onChange={(e) => setReferenceCommodityId(e.target.value)}
                className="w-full bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs font-semibold text-blue-400 focus:outline-none"
              >
                {COMMODITY_MASTER.map((c) => (
                  <option key={c.commodity_id} value={c.commodity_id}>
                    {c.commodity_id} - {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">Notional Quantity</label>
              <input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs font-mono font-bold text-white focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">Instrument Name</label>
            <input
              type="text"
              value={synthName}
              onChange={(e) => setSynthName(e.target.value)}
              className="w-full bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs font-semibold text-white focus:outline-none"
            />
          </div>

          {/* RQQL Code Editor */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[10px] text-slate-400 uppercase font-semibold flex items-center gap-1.5">
                <Code2 className="w-3.5 h-3.5 text-blue-400" />
                <span>RhinoQuant Quantitative Language (RQQL) Code</span>
              </label>
              <span className="text-[10px] font-mono text-slate-500">Safe Abstract Syntax Tree Compiler</span>
            </div>

            <div className="relative">
              <textarea
                rows={4}
                value={formulaCode}
                onChange={(e) => setFormulaCode(e.target.value)}
                className="w-full bg-[#080C14] border border-slate-700 rounded p-3 text-xs font-mono text-emerald-300 focus:outline-none focus:border-blue-500 leading-relaxed tracking-wide selection:bg-blue-800"
                placeholder="e.g. PAYOFF = 50000 * (BRENT_1M - WTI_1M - 4.30)"
              />
            </div>
          </div>

          {/* Submit Action */}
          <div className="flex items-center justify-between pt-2">
            <button
              onClick={handleCreateSynthetic}
              disabled={!validation.isValid || isSubmitting}
              className={`px-5 py-2 rounded text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-colors ${
                validation.isValid && !isSubmitting
                  ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <Plus className="w-4 h-4" />
              <span>{isSubmitting ? 'Compiling & Registering...' : 'Create Synthetic Exposure'}</span>
            </button>

            {creationMessage && (
              <span className={`text-xs font-mono ${creationMessage.startsWith('Error') ? 'text-rose-400' : 'text-emerald-400'}`}>
                {creationMessage}
              </span>
            )}
          </div>
        </div>

        {/* Right Col: AST Validation Inspector & Symbols Table */}
        <div className="bg-[#111827] p-5 rounded border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-semibold uppercase text-slate-200 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-blue-400" />
              Compiler AST Diagnostic
            </h3>
            {validation.isValid ? (
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                AST VERIFIED
              </span>
            ) : (
              <span className="text-[10px] font-mono text-rose-400 bg-rose-950/60 border border-rose-800/60 px-2 py-0.5 rounded flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                SYNTAX ERROR
              </span>
            )}
          </div>

          {/* Classification & Structure */}
          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 bg-[#090D15] rounded border border-slate-800">
              <span className="text-[10px] text-slate-400 block uppercase">Inferred AST Structure</span>
              <span className="font-bold text-blue-400 text-sm mt-0.5 block">{validation.astType || 'CUSTOM'}</span>
            </div>

            {/* Error Diagnostics */}
            {validation.errors.length > 0 && (
              <div className="p-3 bg-rose-950/30 border border-rose-800/60 rounded text-rose-300 space-y-1">
                <span className="font-bold block text-[11px] text-rose-400 uppercase">Compilation Errors:</span>
                {validation.errors.map((err, i) => (
                  <p key={i} className="text-[11px]">
                    · {err}
                  </p>
                ))}
              </div>
            )}

            {/* Symbol Table */}
            <div>
              <span className="text-[11px] font-semibold text-slate-300 block mb-1">Symbol Table Variables:</span>
              {validation.variablesFound.length === 0 ? (
                <p className="text-[11px] text-slate-500 italic">No variables detected in formula.</p>
              ) : (
                <div className="space-y-1">
                  {validation.variablesFound.map((v) => (
                    <div key={v.name} className="flex justify-between items-center p-2 bg-[#080C14] rounded border border-slate-800">
                      <span className="text-blue-400 font-bold">{v.name}</span>
                      <span className="text-slate-400 text-[11px]">
                        {v.commodityId} ({v.tenor}) @ ${v.resolvedValue?.toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Active Synthetic Instruments Registry Table */}
      <div className="bg-[#111827] rounded border border-slate-800 overflow-hidden shadow-xl">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-blue-400" />
            <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
              Active Synthetic Instrument Master ({synthetics.length} Instruments)
            </h2>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="bg-[#090D15] text-slate-400 border-b border-slate-800 text-[11px] uppercase">
                <th className="p-3">ID</th>
                <th className="p-3">Instrument Name</th>
                <th className="p-3">Type</th>
                <th className="p-3">Reference Asset</th>
                <th className="p-3 text-right">Quantity</th>
                <th className="p-3 text-right">Fair Value</th>
                <th className="p-3 font-sans">Payoff Formula</th>
                <th className="p-3 text-right">Initial Margin</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {synthetics.map((s) => (
                <tr key={s.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3 font-bold text-blue-400">{s.id}</td>
                  <td className="p-3 font-sans font-medium text-slate-200">{s.name}</td>
                  <td className="p-3 text-slate-400">{s.type}</td>
                  <td className="p-3 text-slate-300 font-bold">{s.referenceCommodityId}</td>
                  <td className="p-3 text-right text-slate-200 tabular-nums">
                    {s.quantity.toLocaleString()} {s.quantityUnit}
                  </td>
                  <td className="p-3 text-right font-bold text-emerald-400 tabular-nums">${s.fairValue.toFixed(2)}</td>
                  <td className="p-3 text-slate-300 text-[11px] max-w-xs truncate">{s.priceFormula}</td>
                  <td className="p-3 text-right text-amber-300 tabular-nums">${s.marginRequirement.toLocaleString()}</td>
                  <td className="p-3 text-center">
                    <span className="text-[10px] font-sans font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
                      {s.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
