/**
 * RhinoQuant Trading Screen
 * Trade Blotter, OTC Trade Lifecycle State Machine, and Immutable Audit Log Inspector.
 */

import React, { useState } from 'react';
import { AuditEvent, SyntheticInstrument, TradeRecord } from '../types/commodity';
import { Activity, Plus, RefreshCw, Layers, ShieldCheck, FileText, CheckCircle2 } from 'lucide-react';

interface TradingScreenProps {
  trades: TradeRecord[];
  synthetics: SyntheticInstrument[];
  auditLogs: AuditEvent[];
  onTradeExecuted: () => void;
}

export const TradingScreen: React.FC<TradingScreenProps> = ({
  trades,
  synthetics,
  auditLogs,
  onTradeExecuted,
}) => {
  const [selectedSynthId, setSelectedSynthId] = useState(synthetics[0]?.id || '');
  const [side, setSide] = useState<'BUY' | 'SELL'>('BUY');
  const [quantity, setQuantity] = useState(100000);
  const [price, setPrice] = useState(91.40);
  const [trader, setTrader] = useState('E. Vance (Chief Quant)');
  const [counterparty, setCounterparty] = useState('Barclays Capital OTC');
  const [isExecuting, setIsExecuting] = useState(false);
  const [tradeMessage, setTradeMessage] = useState<string | null>(null);

  const handleExecuteTrade = async () => {
    setIsExecuting(true);
    setTradeMessage(null);

    try {
      const res = await fetch('/api/trades', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          syntheticId: selectedSynthId,
          side,
          quantity,
          price,
          trader,
          counterparty,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setTradeMessage(`Executed trade ${data.trade.id}! Position updated in portfolio.`);
        onTradeExecuted();
      } else {
        setTradeMessage(`Execution Error: ${data.error}`);
      }
    } catch (err: any) {
      setTradeMessage(`Error: ${err.message}`);
    } finally {
      setIsExecuting(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Top Trade Capture Panel */}
      <div className="bg-[#111827] p-5 rounded border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-blue-400" />
            <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
              OTC Trade Capture & Execution Console
            </h2>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
            STP DIRECT CLEARING ACTIVE
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-6 gap-3">
          <div className="md:col-span-2">
            <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
              Synthetic Instrument
            </label>
            <select
              value={selectedSynthId}
              onChange={(e) => setSelectedSynthId(e.target.value)}
              className="w-full bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs font-semibold text-blue-400 focus:outline-none"
            >
              {synthetics.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.id} - {s.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">Side</label>
            <select
              value={side}
              onChange={(e) => setSide(e.target.value as any)}
              className={`w-full bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs font-bold focus:outline-none ${
                side === 'BUY' ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              <option value="BUY">BUY / LONG</option>
              <option value="SELL">SELL / SHORT</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">Quantity</label>
            <input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(Number(e.target.value))}
              className="w-full bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs font-mono font-bold text-white focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">Execution Price</label>
            <input
              type="number"
              step="0.01"
              value={price}
              onChange={(e) => setPrice(Number(e.target.value))}
              className="w-full bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs font-mono font-bold text-white focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">Counterparty</label>
            <input
              type="text"
              value={counterparty}
              onChange={(e) => setCounterparty(e.target.value)}
              className="w-full bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs text-white focus:outline-none"
            />
          </div>
        </div>

        <div className="flex items-center justify-between pt-2">
          <button
            onClick={handleExecuteTrade}
            disabled={isExecuting}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-colors shadow-lg"
          >
            <Plus className="w-4 h-4" />
            <span>{isExecuting ? 'Booking Trade...' : 'Execute & Book Trade'}</span>
          </button>

          {tradeMessage && (
            <span className={`text-xs font-mono ${tradeMessage.startsWith('Execution Error') ? 'text-rose-400' : 'text-emerald-400'}`}>
              {tradeMessage}
            </span>
          )}
        </div>
      </div>

      {/* Trade Blotter Table */}
      <div className="bg-[#111827] rounded border border-slate-800 overflow-hidden shadow-xl">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-blue-400" />
            <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
              Institutional Trade Blotter ({trades.length} Records)
            </h2>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="bg-[#090D15] text-slate-400 border-b border-slate-800 text-[11px] uppercase">
                <th className="p-3">Trade ID</th>
                <th className="p-3 font-sans">Instrument Name</th>
                <th className="p-3">Commodity</th>
                <th className="p-3">Side</th>
                <th className="p-3 text-right">Quantity</th>
                <th className="p-3 text-right">Price</th>
                <th className="p-3">Trader</th>
                <th className="p-3">Counterparty</th>
                <th className="p-3">Timestamp</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {trades.map((t) => (
                <tr key={t.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3 font-bold text-blue-400">{t.id}</td>
                  <td className="p-3 font-sans font-medium text-slate-200">{t.instrumentName}</td>
                  <td className="p-3 font-bold text-slate-300">{t.commodity_id}</td>
                  <td className="p-3 font-bold">
                    <span className={t.side === 'BUY' ? 'text-emerald-400' : 'text-rose-400'}>{t.side}</span>
                  </td>
                  <td className="p-3 text-right text-slate-200 tabular-nums">
                    {t.quantity.toLocaleString()} {t.unit}
                  </td>
                  <td className="p-3 text-right font-bold text-white tabular-nums">${t.price.toFixed(2)}</td>
                  <td className="p-3 text-slate-400">{t.trader}</td>
                  <td className="p-3 text-slate-300">{t.counterparty}</td>
                  <td className="p-3 text-slate-500 text-[11px]">{t.timestamp.replace('T', ' ').slice(0, 19)}</td>
                  <td className="p-3 text-center">
                    <span className="text-[10px] font-sans font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
                      {t.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Immutable Audit Log Trail */}
      <div className="bg-[#111827] rounded border border-slate-800 overflow-hidden shadow-xl">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-400" />
            <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
              Immutable Audit Trail ({auditLogs.length} System Audit Events)
            </h2>
          </div>
        </div>

        <div className="divide-y divide-slate-800/60 font-mono text-xs p-2">
          {auditLogs.map((log) => (
            <div key={log.id} className="p-3 hover:bg-slate-800/30 transition-colors flex items-start justify-between gap-4">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-blue-400">{log.id}</span>
                  <span className="text-slate-500">·</span>
                  <span className="text-slate-300 font-semibold">{log.action}</span>
                  <span className="text-slate-500">·</span>
                  <span className="text-slate-400">User: {log.user}</span>
                </div>
                <p className="text-slate-300 text-[11px] font-sans">{log.newValue}</p>
              </div>
              <div className="text-right shrink-0">
                <span className="text-[11px] text-slate-500">{log.timestamp.replace('T', ' ').slice(0, 19)}</span>
                <span className="text-[10px] text-slate-400 block">{log.source}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
