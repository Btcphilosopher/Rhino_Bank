/**
 * RhinoQuant Scenarios & Stress Testing Screen
 * Stress Test Matrix, Shock Shifters, and Historical Crisis Replays.
 */

import React, { useState } from 'react';
import { StressScenario } from '../types/commodity';
import { Activity, ShieldAlert, Sliders, RefreshCw, AlertTriangle, Flame } from 'lucide-react';

export const ScenariosScreen: React.FC = () => {
  // Custom Shock Vector Sliders
  const [wtiShockPct, setWtiShockPct] = useState(-15);
  const [brentShockPct, setBrentShockPct] = useState(-15);
  const [ngasShockPct, setNgasShockPct] = useState(30);
  const [goldShockPct, setGoldShockPct] = useState(10);
  const [volatilityShockPts, setVolatilityShockPts] = useState(12);

  const historicalScenarios: StressScenario[] = [
    {
      id: 'HIST-2020-OIL',
      name: '2020 April Negative WTI Crude Crash',
      description: 'Record storage collapse at Cushing causing WTI front month to plunge below zero.',
      commodityShocksPct: { WTI: -65, BRENT: -45, RBOB: -50, HOIL: -40 },
      volatilityShockPoints: 35,
      fxShockPct: 2.5,
      historicalReference: 'April 20, 2020 WTI Settlement -$37.63/bbl',
      estimatedPnL: -2840000,
      estimatedMarginCall: 3400000,
    },
    {
      id: 'HIST-2022-GAS',
      name: '2022 European Energy Crisis & Gas Shock',
      description: 'Extreme European natural gas & power spike following Nord Stream curtailments.',
      commodityShocksPct: { NGAS: 120, POWER: 180, CARBON: 40, WTI: 25 },
      volatilityShockPoints: 48,
      fxShockPct: -4.2,
      historicalReference: 'August 2022 TTF Gas peak €340/MWh',
      estimatedPnL: 1950000,
      estimatedMarginCall: 5200000,
    },
    {
      id: 'HIST-2008-LEHMAN',
      name: '2008 Lehman Brothers Global Recession',
      description: 'Severe cross-commodity liquidate-everything recessionary collapse.',
      commodityShocksPct: { WTI: -55, COPPER: -60, CORN: -40, GOLD: 15 },
      volatilityShockPoints: 28,
      fxShockPct: 5.0,
      historicalReference: 'Q4 2008 Global De-leveraging Episode',
      estimatedPnL: -3120000,
      estimatedMarginCall: 4100000,
    },
  ];

  // Calculate Custom Shock P&L
  const customEstimatedPnL =
    wtiShockPct * 92100 + brentShockPct * 2150 + ngasShockPct * 8845 - volatilityShockPts * 12500;

  return (
    <div className="p-6 space-y-6">
      {/* Top Banner */}
      <div className="bg-[#111827] p-4 rounded border border-slate-800 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            STRESS TESTING & HISTORICAL CRISIS REPLAY MATRIX
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Simulate portfolio performance under multi-asset shock vectors and historical stress episodes.
          </p>
        </div>
      </div>

      {/* Grid: Custom Shock Vectors & Matrix Heatmap */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Custom Multi-Asset Shock Sliders */}
        <div className="bg-[#111827] p-5 rounded border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-blue-400" />
              <span>Custom Shock Vector Shifter</span>
            </h3>
            <span
              className={`text-xs font-mono font-bold tabular-nums ${
                customEstimatedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              Estimated Stress P&L: {customEstimatedPnL >= 0 ? '+' : ''}${customEstimatedPnL.toLocaleString()}
            </span>
          </div>

          <div className="space-y-4 font-mono text-xs">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-300">WTI Crude Shock:</span>
                <span className={`font-bold ${wtiShockPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {wtiShockPct >= 0 ? '+' : ''}{wtiShockPct}%
                </span>
              </div>
              <input
                type="range"
                min="-50"
                max="50"
                value={wtiShockPct}
                onChange={(e) => setWtiShockPct(Number(e.target.value))}
                className="w-full accent-blue-600"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-300">Brent Crude Shock:</span>
                <span className={`font-bold ${brentShockPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {brentShockPct >= 0 ? '+' : ''}{brentShockPct}%
                </span>
              </div>
              <input
                type="range"
                min="-50"
                max="50"
                value={brentShockPct}
                onChange={(e) => setBrentShockPct(Number(e.target.value))}
                className="w-full accent-blue-600"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-300">Natural Gas Shock:</span>
                <span className={`font-bold ${ngasShockPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {ngasShockPct >= 0 ? '+' : ''}{ngasShockPct}%
                </span>
              </div>
              <input
                type="range"
                min="-50"
                max="50"
                value={ngasShockPct}
                onChange={(e) => setNgasShockPct(Number(e.target.value))}
                className="w-full accent-blue-600"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-300">Implied Volatility Shift:</span>
                <span className="font-bold text-amber-400">+{volatilityShockPts} vol points</span>
              </div>
              <input
                type="range"
                min="0"
                max="40"
                value={volatilityShockPts}
                onChange={(e) => setVolatilityShockPts(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>
          </div>
        </div>

        {/* Matrix Shock Grid Heatmap */}
        <div className="bg-[#111827] p-5 rounded border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200 flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-400" />
              <span>Multi-Asset Commodity Stress Matrix</span>
            </h3>
          </div>

          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="bg-[#090D15] text-slate-400 border-b border-slate-800 text-[10px] uppercase">
                <th className="p-2">Commodity</th>
                <th className="p-2 text-center text-rose-400">-30%</th>
                <th className="p-2 text-center text-rose-300">-10%</th>
                <th className="p-2 text-center text-emerald-300">+10%</th>
                <th className="p-2 text-center text-emerald-400">+30%</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-[11px]">
              {[
                { comm: 'WTI Crude', p30m: '-$2.76m', p10m: '-$920k', p10p: '+$920k', p30p: '+$2.76m' },
                { comm: 'Brent Crude', p30m: '-$64k', p10m: '-$21k', p10p: '+$21k', p30p: '+$64k' },
                { comm: 'Natural Gas', p30m: '-$26k', p10m: '-$8.8k', p10p: '+$8.8k', p30p: '+$26k' },
                { comm: 'Gold', p30m: '-$140k', p10m: '-$46k', p10p: '+$46k', p30p: '+$140k' },
              ].map((row) => (
                <tr key={row.comm} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-bold text-slate-200">{row.comm}</td>
                  <td className="p-2.5 text-center text-rose-400 font-bold">{row.p30m}</td>
                  <td className="p-2.5 text-center text-rose-300">{row.p10m}</td>
                  <td className="p-2.5 text-center text-emerald-300">{row.p10p}</td>
                  <td className="p-2.5 text-center text-emerald-400 font-bold">{row.p30p}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Historical Crisis Episodes Table */}
      <div className="bg-[#111827] rounded border border-slate-800 overflow-hidden shadow-xl">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
            Saved Historical Crisis Replay Library ({historicalScenarios.length} Episodes)
          </h2>
        </div>

        <div className="divide-y divide-slate-800">
          {historicalScenarios.map((scen) => (
            <div key={scen.id} className="p-4 hover:bg-slate-800/30 transition-colors space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-bold text-sm text-white">{scen.name}</span>
                  <span className="text-xs text-slate-500 font-mono ml-3">Ref: {scen.historicalReference}</span>
                </div>
                <div className="flex items-center gap-4 font-mono text-xs">
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase block">Stress P&L</span>
                    <span className={`font-bold ${scen.estimatedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {scen.estimatedPnL >= 0 ? '+' : ''}${scen.estimatedPnL.toLocaleString()}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase block">Margin Call Trigger</span>
                    <span className="font-bold text-amber-400">${scen.estimatedMarginCall.toLocaleString()}</span>
                  </div>
                </div>
              </div>
              <p className="text-xs text-slate-400">{scen.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
