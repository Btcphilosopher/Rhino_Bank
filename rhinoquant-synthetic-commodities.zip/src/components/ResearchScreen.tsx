/**
 * RhinoQuant Research Workbench
 * Server-Side Gemini Quantitative Analyst, Vectorised Monte Carlo Path Simulator,
 * and Strategy Backtesting & Hedge Optimizer.
 */

import React, { useState } from 'react';
import { MonteCarloConfig, MonteCarloResult } from '../quant/monteCarlo';
import { Activity, Bot, Sparkles, Play, RefreshCw, Send, Sliders, ShieldCheck, Zap } from 'lucide-react';

export const ResearchScreen: React.FC = () => {
  // Monte Carlo Simulation Config State
  const [mcModelType, setMcModelType] = useState<MonteCarloConfig['modelType']>('GeometricBrownianMotion');
  const [mcSpot, setMcSpot] = useState(92.10);
  const [mcDrift, setMcDrift] = useState(0.02);
  const [mcVol, setMcVol] = useState(0.30);
  const [mcMeanReversion, setMcMeanReversion] = useState(1.5);
  const [mcLongTermMean, setMcLongTermMean] = useState(90.0);
  const [mcPaths, setMcPaths] = useState(1000);
  const [mcResult, setMcResult] = useState<MonteCarloResult | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);

  // Gemini Quantitative Analyst Chat State
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  const handleRunMonteCarlo = async () => {
    setIsSimulating(true);
    try {
      const res = await fetch('/api/monte-carlo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          modelType: mcModelType,
          spot: mcSpot,
          drift: mcDrift,
          volatility: mcVol,
          meanReversionSpeed: mcMeanReversion,
          longTermMean: mcLongTermMean,
          timeHorizonYears: 1.0,
          numSteps: 252,
          numPaths: mcPaths,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setMcResult(data.result);
      }
    } catch (err) {
      console.error('Monte Carlo Error:', err);
    } finally {
      setIsSimulating(false);
    }
  };

  const handleAskGemini = async () => {
    if (!aiPrompt.trim()) return;
    setIsAiLoading(true);
    setAiResponse(null);

    try {
      const res = await fetch('/api/gemini/research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: aiPrompt, context: { mcModelType, mcSpot, mcVol } }),
      });
      const data = await res.json();
      if (data.success) {
        setAiResponse(data.text);
      } else {
        setAiResponse(`Error: ${data.error}`);
      }
    } catch (err: any) {
      setAiResponse(`Failed to call Gemini Research Assistant: ${err.message}`);
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Top Banner */}
      <div className="bg-[#111827] p-4 rounded border border-slate-800 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-400" />
            RHINOQUANT RESEARCH WORKBENCH & MONTE CARLO LAB
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Run vectorised stochastic price path simulations and query the server-side Gemini Quantitative Strategist.
          </p>
        </div>
      </div>

      {/* Grid: Monte Carlo Simulator & AI Assistant */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Col: Monte Carlo Path Simulator */}
        <div className="bg-[#111827] p-5 rounded border border-slate-800 space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200 flex items-center gap-2">
              <Activity className="w-4 h-4 text-blue-400" />
              <span>Stochastic Price Path Simulator</span>
            </h3>
            <button
              onClick={handleRunMonteCarlo}
              disabled={isSimulating}
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow"
            >
              <Play className="w-3.5 h-3.5" />
              <span>{isSimulating ? 'Simulating...' : `Run ${mcPaths.toLocaleString()} Paths`}</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3 font-mono text-xs">
            <div>
              <label className="text-[10px] text-slate-400 uppercase block mb-1">Stochastic Process</label>
              <select
                value={mcModelType}
                onChange={(e) => setMcModelType(e.target.value as any)}
                className="w-full bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs text-white focus:outline-none"
              >
                <option value="GeometricBrownianMotion">Geometric Brownian Motion (GBM)</option>
                <option value="MeanReversion">Mean-Reverting Ornstein-Uhlenbeck</option>
                <option value="SeasonalMeanReversion">Seasonal Mean-Reversion (NatGas/Power)</option>
                <option value="JumpDiffusion">Merton Jump Diffusion</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 uppercase block mb-1">Initial Spot Price ($)</label>
              <input
                type="number"
                step="0.1"
                value={mcSpot}
                onChange={(e) => setMcSpot(Number(e.target.value))}
                className="w-full bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-400 uppercase block mb-1">Annual Drift (μ)</label>
              <input
                type="number"
                step="0.01"
                value={mcDrift}
                onChange={(e) => setMcDrift(Number(e.target.value))}
                className="w-full bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-400 uppercase block mb-1">Volatility (σ)</label>
              <input
                type="number"
                step="0.01"
                value={mcVol}
                onChange={(e) => setMcVol(Number(e.target.value))}
                className="w-full bg-[#0D131F] border border-slate-700 rounded px-3 py-1.5 text-xs text-white focus:outline-none"
              />
            </div>
          </div>

          {/* Monte Carlo Results Display */}
          {mcResult && (
            <div className="p-4 bg-[#090D15] rounded border border-slate-800 space-y-3 font-mono text-xs">
              <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                <span className="text-slate-400">Execution Time:</span>
                <span className="font-bold text-emerald-400">{mcResult.executionTimeMs} ms</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-500 block">Terminal Mean Price:</span>
                  <span className="font-bold text-white">${mcResult.terminalMean}</span>
                </div>

                <div>
                  <span className="text-slate-500 block">Terminal Std Dev:</span>
                  <span className="font-bold text-white">${mcResult.terminalStdDev}</span>
                </div>

                <div>
                  <span className="text-slate-500 block">Simulated 1Y 99% VaR:</span>
                  <span className="font-bold text-amber-400">${mcResult.var99}</span>
                </div>

                <div>
                  <span className="text-slate-500 block">Simulated 1Y 99% CVaR:</span>
                  <span className="font-bold text-rose-400">${mcResult.cvar99}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Col: AI Quantitative Strategist (Gemini 2.5 Flash Server-Side) */}
        <div className="bg-[#111827] p-5 rounded border border-slate-800 space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200 flex items-center gap-2">
                <Bot className="w-4 h-4 text-blue-400" />
                <span>AI Quantitative Strategist (Gemini 2.5 Flash)</span>
              </h3>
              <span className="text-[10px] font-mono text-blue-400 bg-blue-950/60 border border-blue-800/60 px-2 py-0.5 rounded">
                SERVER-SIDE API
              </span>
            </div>

            {/* Response Output Box */}
            <div className="h-64 bg-[#080C14] rounded border border-slate-800 p-3 overflow-y-auto font-mono text-xs text-slate-200 space-y-2">
              {isAiLoading ? (
                <div className="flex items-center gap-2 text-blue-400 py-8 justify-center">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Formulating quantitative analysis...</span>
                </div>
              ) : aiResponse ? (
                <div className="whitespace-pre-wrap leading-relaxed text-slate-200">{aiResponse}</div>
              ) : (
                <div className="text-slate-500 text-[11px] italic pt-8 text-center">
                  Ask the Quantitative Strategist about curve regime shifts, crack spread hedging, option skew, or RQQL payoff optimization.
                </div>
              )}
            </div>
          </div>

          {/* Prompt Input Box */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Ask e.g. How to structure an optimal WTI/Brent basis hedge for Q4?"
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAskGemini()}
                className="w-full bg-[#0D131F] border border-slate-700 rounded px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono"
              />
              <button
                onClick={handleAskGemini}
                disabled={isAiLoading || !aiPrompt.trim()}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 text-white rounded text-xs font-bold transition-colors shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
