/**
 * RhinoQuant Settlement Screen
 * Fixing Calendars, Monthly Average Observations, Cashflow Engine & Multi-Currency Converter.
 */

import React, { useState } from 'react';
import { CurrencyCode } from '../types/commodity';
import { Calendar, DollarSign, RefreshCw, CheckCircle2 } from 'lucide-react';

export const SettlementScreen: React.FC = () => {
  const [selectedCurrency, setSelectedCurrency] = useState<CurrencyCode>('USD');

  const currencies: CurrencyCode[] = ['USD', 'EUR', 'GBP', 'CHF', 'JPY', 'CAD', 'AUD', 'CNY'];

  const fxRates: Record<CurrencyCode, number> = {
    USD: 1.0,
    EUR: 0.915,
    GBP: 0.782,
    CHF: 0.885,
    JPY: 148.5,
    CAD: 1.365,
    AUD: 1.512,
    CNY: 7.240,
  };

  const fixingObservations = [
    { date: '2026-10-01', instrument: 'WTI_JUN27_FWD', index: 'WTI Cushing Settlement', value: 92.40, status: 'VERIFIED' },
    { date: '2026-10-02', instrument: 'WTI_JUN27_FWD', index: 'WTI Cushing Settlement', value: 92.85, status: 'VERIFIED' },
    { date: '2026-10-03', instrument: 'WTI_JUN27_FWD', index: 'WTI Cushing Settlement', value: 92.10, status: 'VERIFIED' },
    { date: '2026-10-04', instrument: 'WTI_JUN27_FWD', index: 'WTI Cushing Settlement', value: 91.95, status: 'VERIFIED' },
    { date: '2026-10-05', instrument: 'WTI_JUN27_FWD', index: 'WTI Cushing Settlement', value: 92.10, status: 'FINAL' },
  ];

  const cashflows = [
    { id: 'CF-1001', tradeId: 'TRD-8801', date: '2026-10-31', party: 'Barclays Capital', amountUsd: 45000, type: 'VARIATION_MARGIN' },
    { id: 'CF-1002', tradeId: 'TRD-8802', date: '2026-10-31', party: 'Goldman Sachs', amountUsd: 12500, type: 'MONTHLY_SWAP_SETTLEMENT' },
    { id: 'CF-1003', tradeId: 'TRD-8803', date: '2026-11-15', party: 'Morgan Stanley', amountUsd: 3200, type: 'BASKET_INDEX_FIXING' },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Top Multi-Currency Selection Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#111827] p-4 rounded border border-slate-800">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-blue-400" />
            FIXING, SETTLEMENT & MULTI-CURRENCY CONVERSION ENGINE
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Monitor daily index fixings, calculate monthly average cashflows, and convert settlement P&L across currencies.
          </p>
        </div>

        {/* Currency Switcher */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400 uppercase text-[11px] font-semibold">Base Settlement Currency:</span>
          <div className="flex items-center gap-1 bg-[#0D131F] p-1 rounded border border-slate-700">
            {currencies.map((c) => (
              <button
                key={c}
                onClick={() => setSelectedCurrency(c)}
                className={`px-2.5 py-1 rounded font-bold transition-colors ${
                  selectedCurrency === c ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Grid: Fixing Calendar & Cashflows Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Daily Index Fixing Table */}
        <div className="bg-[#111827] rounded border border-slate-800 overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
              Daily Index Fixing Observations (NYMEX / ICE)
            </h3>
            <span className="text-[10px] font-mono text-emerald-400">AUTOMATED FEED ACTIVE</span>
          </div>

          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="bg-[#090D15] text-slate-400 border-b border-slate-800 text-[11px] uppercase">
                <th className="p-3">Fixing Date</th>
                <th className="p-3">Instrument</th>
                <th className="p-3">Index Source</th>
                <th className="p-3 text-right">Fixing Price</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {fixingObservations.map((obs, i) => (
                <tr key={i} className="hover:bg-slate-800/40">
                  <td className="p-3 text-slate-300">{obs.date}</td>
                  <td className="p-3 font-bold text-blue-400">{obs.instrument}</td>
                  <td className="p-3 text-slate-400 text-[11px] font-sans">{obs.index}</td>
                  <td className="p-3 text-right font-bold text-white tabular-nums">${obs.value.toFixed(2)}</td>
                  <td className="p-3 text-center">
                    <span className="text-[10px] font-sans font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
                      {obs.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Scheduled Settlement Cashflows Table */}
        <div className="bg-[#111827] rounded border border-slate-800 overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
              Scheduled Settlement Cashflows ({selectedCurrency})
            </h3>
            <span className="text-[11px] font-mono text-slate-400">
              FX Rate: 1 USD = {fxRates[selectedCurrency]} {selectedCurrency}
            </span>
          </div>

          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="bg-[#090D15] text-slate-400 border-b border-slate-800 text-[11px] uppercase">
                <th className="p-3">Cashflow ID</th>
                <th className="p-3">Settlement Date</th>
                <th className="p-3">Counterparty</th>
                <th className="p-3">Type</th>
                <th className="p-3 text-right">Converted Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {cashflows.map((cf) => {
                const converted = cf.amountUsd * fxRates[selectedCurrency];
                return (
                  <tr key={cf.id} className="hover:bg-slate-800/40">
                    <td className="p-3 font-bold text-blue-400">{cf.id}</td>
                    <td className="p-3 text-slate-300">{cf.date}</td>
                    <td className="p-3 text-slate-200 font-sans">{cf.party}</td>
                    <td className="p-3 text-slate-400 text-[11px]">{cf.type}</td>
                    <td className="p-3 text-right font-bold text-emerald-400 tabular-nums">
                      {selectedCurrency} {converted.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
