/**
 * Accounting Query Language Types
 */

export interface AccountingQuery {
  rawInput: string;
  intent:
    | 'UNUSUAL_EXPENSES'
    | 'PERIOD_DELTA'
    | 'UNUSUAL_REVENUE'
    | 'CUSTOMER_EXPLANATION'
    | 'STRUCTURAL_ACCOUNTS'
    | 'YEAR_END_JOURNALS'
    | 'SUPPLIER_CONCENTRATION'
    | 'MARGIN_DETERIORATION'
    | 'LARGE_TRANSACTIONS'
    | 'RECURRING_PAYMENTS'
    | 'WORKING_CAPITAL_CHANGE'
    | 'VOLATILITY_SEARCH'
    | 'DUPLICATE_INVOICES'
    | 'RELATIONSHIP_SEARCH'
    | 'CUSTOM_FILTER';
  metric?: string;
  accountGroup?: string;
  thresholdAmount?: number;
  periodName?: string;
  comparisonPeriod?: string;
  anomalyMethod?: 'Z_SCORE' | 'MAD' | 'PERCENTILE' | 'ACCOUNTING_TIMING';
  materialityFilter?: 'ALL' | 'HIGH_ONLY';
}
