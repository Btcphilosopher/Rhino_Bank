/**
 * Investigation Workbench Model
 * Case management, evidence tracking, accountant notes, and interpretation state.
 */

import { DiscoveryItem } from './discovery';

export interface EvidenceItem {
  id: string;
  type: 'JOURNAL' | 'INVOICE' | 'ACCOUNT' | 'COUNTERPARTY' | 'CALCULATION' | 'STATEMENT_NOTE';
  title: string;
  referenceCode: string;
  amount?: number;
  currency?: string;
  date?: string;
  details: Record<string, any>;
  sourceFile?: string;
}

export interface AccountantNote {
  id: string;
  timestamp: string;
  authorName: string;
  authorRole: string;
  content: string;
  taggedEvidenceIds?: string[];
}

export interface InvestigationCase {
  id: string;
  caseNumber: string; // e.g. "INV-2026-089"
  discoveryId: string;
  discovery: DiscoveryItem;
  title: string;
  assignedRole: string;
  assignedUser: string;
  status:
    | 'UNREVIEWED'
    | 'REVIEWING'
    | 'EXPLAINED'
    | 'EXPECTED'
    | 'DATA_ISSUE'
    | 'ACCOUNTING_ADJUSTMENT'
    | 'BUSINESS_EVENT'
    | 'REQUIRES_FURTHER_REVIEW'
    | 'RESOLVED';
  evidence: EvidenceItem[];
  notes: AccountantNote[];
  createdAt: string;
  updatedAt: string;
  isBookmarked: boolean;
  exportedAt?: string;
}
