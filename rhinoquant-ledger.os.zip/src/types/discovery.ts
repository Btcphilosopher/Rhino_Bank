/**
 * Discovery Engine & Analytical Dimensions Model
 * 12 distinct, non-collapsed observation dimensions
 */

export type DiscoveryCategory =
  | 'REVENUE_MOVEMENT'
  | 'SUPPLIER_CONCENTRATION'
  | 'YEAR_END_JOURNALS'
  | 'RECEIVABLES_DETERIORATION'
  | 'EXPENSE_RECLASSIFICATION'
  | 'DUPLICATE_INVOICE'
  | 'MARGIN_ANOMALY'
  | 'STATEMENT_RECONCILIATION';

export type DimensionLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface ObservationDimensions {
  materiality: DimensionLevel;         // Absolute & relative financial size
  novelty: DimensionLevel;             // Structural first-time presence or deviation
  magnitude: DimensionLevel;           // Standard deviations (Z-score)
  volatility: DimensionLevel;          // Deviation from historical variance
  timing: DimensionLevel;              // Period-end / after-hours / weekend spikes
  concentration: DimensionLevel;       // HHI index / top-N account dominance
  deviation: DimensionLevel;           // Trend/seasonality residual
  relationship: DimensionLevel;        // Shift in graph degree or account pairings
  persistence: DimensionLevel;         // One-off vs recurring pattern
  reversal: DimensionLevel;            // Subsequent period cancellation probability
  accountingSignificance: DimensionLevel; // Key Audit Matter or GAAP sensitivity
  dataQuality: DimensionLevel;         // Completeness, duplicate indicators
}

export interface DiscoveryItem {
  id: string;
  code: string; // e.g. "DISC-2026-001"
  title: string;
  category: DiscoveryCategory;
  summary: string;
  detailedReasoning: string[];
  impactAmount: number;
  currency: string;
  dimensions: ObservationDimensions;
  relatedAccountCodes: string[];
  relatedCounterpartyIds?: string[];
  relatedJournalIds?: string[];
  periodName: string;
  dateDetected: string;
  explanationState:
    | 'UNREVIEWED'
    | 'REVIEWING'
    | 'EXPLAINED'
    | 'EXPECTED'
    | 'DATA_ISSUE'
    | 'ACCOUNTING_ADJUSTMENT'
    | 'BUSINESS_EVENT'
    | 'REQUIRES_FURTHER_REVIEW'
    | 'RESOLVED';
  isSynthetic: boolean;
  score: number; // Transparent prioritization index for ranking
}

export type PrioritisationMode =
  | 'MATERIALITY'
  | 'AUDIT_REVIEW'
  | 'FINANCIAL_CONTROL'
  | 'MANAGEMENT_REVIEW'
  | 'FORENSIC_REVIEW'
  | 'CASH_REVIEW'
  | 'REVENUE_REVIEW'
  | 'EXPENSE_REVIEW'
  | 'YEAR_END_REVIEW';
