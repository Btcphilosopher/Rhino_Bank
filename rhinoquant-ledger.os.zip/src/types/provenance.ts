/**
 * Data Provenance & Calculation Lineage
 * Unpack every formula, transformation, source transaction, and math trace.
 */

export interface SourceDataRef {
  sourceType: 'JOURNAL_LINE' | 'INVOICE' | 'TRIAL_BALANCE' | 'STATEMENT_NOTE' | 'TAXONOMY';
  sourceFile: string;
  sourceSystem: string;
  recordCount: number;
  totalDebit: number;
  totalCredit: number;
  netAmount: number;
  sampleRecordIds: string[];
}

export interface CalculationLineage {
  id: string;
  metricName: string;
  formattedResult: string;
  numericResult: number;
  currency: string;
  formula: string;
  timePeriod: string;
  filtersApplied: string[];
  assumptions: string[];
  modelVersion: string;
  transformations: string[];
  sourceRefs: SourceDataRef[];
}

export interface AuditTrailLog {
  id: string;
  timestamp: string;
  userName: string;
  userRole: string;
  action: string; // e.g. "VIEW_EVIDENCE", "CHANGE_STATUS", "RUN_SEARCH", "EXPORT_REPORT"
  targetEntityId: string;
  details: string;
}
