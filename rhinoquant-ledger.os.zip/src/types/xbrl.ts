/**
 * XBRL / iXBRL Taxonomy Architecture Types
 */

export interface TaxonomyConcept {
  id: string; // e.g. "ifrs-full:RevenueFromContractsWithCustomers"
  name: string;
  label: string;
  documentation: string;
  periodType: 'duration' | 'instant';
  balance: 'credit' | 'debit';
  isAbstract: boolean;
}

export interface XBRLFact {
  id: string;
  conceptId: string;
  conceptLabel: string;
  value: number;
  decimals: number;
  unit: string;
  period: string; // e.g. "2026-01-01 to 2026-12-31"
  entity: string;
  isAudited: boolean;
  taxonomyStandard: 'IFRS' | 'UK_GAAP' | 'US_GAAP';
  sourceTag: string;
}

export interface StatementReconciliationCheck {
  id: string;
  checkName: string;
  primaryFactLabel: string;
  secondaryFactLabel: string;
  statement1: string;
  statement2: string;
  amount1: number;
  amount2: number;
  variance: number;
  isBalanced: boolean;
  notes: string;
}
