/**
 * Universal Accounting Data Model
 * Canonical accounting representation independent of source ERPs.
 */

export type AccountCategory =
  | 'REVENUE'
  | 'COST_OF_SALES'
  | 'OPERATING_EXPENSE'
  | 'NON_OPERATING_INCOME'
  | 'NON_OPERATING_EXPENSE'
  | 'CURRENT_ASSET'
  | 'NON_CURRENT_ASSET'
  | 'CURRENT_LIABILITY'
  | 'NON_CURRENT_LIABILITY'
  | 'EQUITY';

export interface Organisation {
  id: string;
  name: string;
  baseCurrency: string;
  createdTimestamp: string;
}

export interface LegalEntity {
  id: string;
  organisationId: string;
  code: string;
  name: string;
  country: string;
  functionalCurrency: string;
}

export interface FiscalYear {
  id: string;
  entityId: string;
  year: number;
  startDate: string;
  endDate: string;
  isClosed: boolean;
}

export interface AccountingPeriod {
  id: string;
  fiscalYearId: string;
  periodNumber: number; // 1-12 or 13 for adjustment
  name: string; // e.g. "Dec 2026"
  startDate: string;
  endDate: string;
  isClosed: boolean;
}

export interface Account {
  id: string;
  entityId: string;
  code: string; // e.g. "4000"
  name: string; // e.g. "Commercial Sales Revenue"
  category: AccountCategory;
  groupName: string; // e.g. "Core Sales"
  normalBalance: 'DEBIT' | 'CREDIT';
  isIntercompany: boolean;
  isActive: boolean;
}

export interface Journal {
  id: string;
  entityId: string;
  periodId: string;
  journalNumber: string;
  postingDate: string; // YYYY-MM-DD
  postingTimestamp: string; // ISO 8601
  sourceSystem: string; // e.g. "SAP S/4HANA", "Xero", "Manual Entry"
  sourceFile?: string;
  journalType: 'MANUAL' | 'SYSTEM' | 'RECURRING' | 'YEAR_END_ADJUSTMENT' | 'REVERSAL';
  description: string;
  userId: string;
  userName: string;
  userRole: string;
  approvalUserId?: string;
  approvalStatus: 'APPROVED' | 'AUTO_POSTED' | 'PENDING_REVIEW';
  isReversal: boolean;
  reversedJournalId?: string;
  isSynthetic: boolean;
  totalDebit: number;
  totalCredit: number;
  currency: string;
}

export interface JournalLine {
  id: string;
  journalId: string;
  lineNumber: number;
  accountId: string;
  accountCode: string;
  accountName: string;
  accountCategory: AccountCategory;
  debit: number;
  credit: number;
  amount: number; // net debit - credit
  currency: string;
  fxRate: number;
  amountFunctional: number;
  description: string;
  counterpartyId?: string;
  counterpartyName?: string;
  counterpartyType?: 'CUSTOMER' | 'SUPPLIER' | 'EMPLOYEE' | 'BANK' | 'INTERCOMPANY';
  departmentCode?: string;
  departmentName?: string;
  costCentreCode?: string;
  projectCode?: string;
  documentRef?: string;
  postingDate: string;
  postingTimestamp: string;
  sourceRecordId: string;
  isSynthetic: boolean;
}

export interface Counterparty {
  id: string;
  entityId: string;
  code: string;
  name: string;
  type: 'CUSTOMER' | 'SUPPLIER' | 'INTERCOMPANY' | 'BANK';
  country: string;
  riskRating: 'LOW' | 'MEDIUM' | 'HIGH';
  paymentTermsDays: number;
  firstTransactionDate: string;
  lastTransactionDate: string;
  totalVolumeYTD: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  entityId: string;
  counterpartyId: string;
  counterpartyName: string;
  type: 'ACCOUNTS_RECEIVABLE' | 'ACCOUNTS_PAYABLE';
  issueDate: string;
  dueDate: string;
  amount: number;
  currency: string;
  status: 'PAID' | 'OPEN' | 'OVERDUE' | 'DISPUTED' | 'CREDIT_NOTE';
  description: string;
  journalId?: string;
  sourceFile?: string;
  isSynthetic: boolean;
}

export interface FinancialStatementRow {
  lineItem: string;
  accountCodes: string[];
  currentPeriod: number;
  priorPeriod: number;
  variance: number;
  variancePercent: number;
  noteRef?: string;
}

export interface FinancialStatementReport {
  title: string;
  periodName: string;
  currency: string;
  rows: FinancialStatementRow[];
  totalAssets?: number;
  totalLiabilities?: number;
  totalEquity?: number;
  netIncome?: number;
}
