/**
 * RHINO DEMO HOLDINGS PLC - Deterministic Synthetic Dataset Generator
 * Produces a full canonical accounting dataset with 10 years of history and
 * embedded financial research phenomena.
 */

import {
  Account,
  AccountingPeriod,
  Counterparty,
  Invoice,
  Journal,
  JournalLine,
  LegalEntity,
  Organisation
} from '../types/accounting';
import { DiscoveryItem } from '../types/discovery';
import { StatementReconciliationCheck, XBRLFact } from '../types/xbrl';

export interface SyntheticDataset {
  organisation: Organisation;
  legalEntity: LegalEntity;
  periods: AccountingPeriod[];
  accounts: Account[];
  counterparties: Counterparty[];
  journals: Journal[];
  journalLines: JournalLine[];
  invoices: Invoice[];
  discoveries: DiscoveryItem[];
  xbrlFacts: XBRLFact[];
  reconciliationChecks: StatementReconciliationCheck[];
}

export function generateRhinoDemoDataset(): SyntheticDataset {
  const org: Organisation = {
    id: 'org-rhino-01',
    name: 'RHINO DEMO HOLDINGS PLC',
    baseCurrency: 'GBP',
    createdTimestamp: '2017-01-01T00:00:00Z',
  };

  const legalEntity: LegalEntity = {
    id: 'ent-rhino-uk',
    organisationId: org.id,
    code: 'UK01',
    name: 'Rhino UK Operating Ltd',
    country: 'GB',
    functionalCurrency: 'GBP',
  };

  // Generate 10 Fiscal Years of Accounting Periods (2017 to 2026)
  const periods: AccountingPeriod[] = [];
  for (let yr = 2017; yr <= 2026; yr++) {
    for (let m = 1; m <= 12; m++) {
      const monthStr = m < 10 ? `0${m}` : `${m}`;
      const lastDay = new Date(yr, m, 0).getDate();
      periods.push({
        id: `p-${yr}-${monthStr}`,
        fiscalYearId: `fy-${yr}`,
        periodNumber: m,
        name: `${getMonthName(m)} ${yr}`,
        startDate: `${yr}-${monthStr}-01`,
        endDate: `${yr}-${monthStr}-${lastDay}`,
        isClosed: yr < 2026 || (yr === 2026 && m < 12),
      });
    }
  }

  // Generate Nominal Chart of Accounts (~300 accounts)
  const accounts: Account[] = [
    // Revenue (4000-4999)
    { id: 'acc-4000', entityId: legalEntity.id, code: '4000', name: 'Commercial Sales Revenue', category: 'REVENUE', groupName: 'Core Revenue', normalBalance: 'CREDIT', isIntercompany: false, isActive: true },
    { id: 'acc-4010', entityId: legalEntity.id, code: '4010', name: 'Enterprise License Revenue', category: 'REVENUE', groupName: 'Core Revenue', normalBalance: 'CREDIT', isIntercompany: false, isActive: true },
    { id: 'acc-4020', entityId: legalEntity.id, code: '4020', name: 'Maintenance & Support Revenue', category: 'REVENUE', groupName: 'Services Revenue', normalBalance: 'CREDIT', isIntercompany: false, isActive: true },
    { id: 'acc-4050', entityId: legalEntity.id, code: '4050', name: 'Professional Services Consulting', category: 'REVENUE', groupName: 'Services Revenue', normalBalance: 'CREDIT', isIntercompany: false, isActive: true },
    { id: 'acc-4090', entityId: legalEntity.id, code: '4090', name: 'Intercompany Revenue - EU Sub', category: 'REVENUE', groupName: 'Intercompany Revenue', normalBalance: 'CREDIT', isIntercompany: true, isActive: true },

    // Cost of Sales (5000-5999)
    { id: 'acc-5000', entityId: legalEntity.id, code: '5000', name: 'Direct Cloud Infrastructure Costs', category: 'COST_OF_SALES', groupName: 'Direct Cost', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },
    { id: 'acc-5010', entityId: legalEntity.id, code: '5010', name: 'Hardware Components & Logistics', category: 'COST_OF_SALES', groupName: 'Direct Cost', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },
    { id: 'acc-5050', entityId: legalEntity.id, code: '5050', name: 'Subcontracted Technical Labor', category: 'COST_OF_SALES', groupName: 'Direct Labor', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },

    // Operating Expenses (6000-7999)
    { id: 'acc-6000', entityId: legalEntity.id, code: '6000', name: 'Executive & Administrative Staff Salaries', category: 'OPERATING_EXPENSE', groupName: 'Personnel Costs', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },
    { id: 'acc-6010', entityId: legalEntity.id, code: '6010', name: 'Engineering & Product Staff Payroll', category: 'OPERATING_EXPENSE', groupName: 'Personnel Costs', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },
    { id: 'acc-6200', entityId: legalEntity.id, code: '6200', name: 'Legal & Audit Professional Fees', category: 'OPERATING_EXPENSE', groupName: 'Professional Services', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },
    { id: 'acc-6210', entityId: legalEntity.id, code: '6210', name: 'Management Consulting & Advisory', category: 'OPERATING_EXPENSE', groupName: 'Professional Services', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },
    { id: 'acc-6500', entityId: legalEntity.id, code: '6500', name: 'SaaS Software & IT Subscriptions', category: 'OPERATING_EXPENSE', groupName: 'IT & Technology', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },
    { id: 'acc-6800', entityId: legalEntity.id, code: '6800', name: 'Commercial Premises Lease & Utilities', category: 'OPERATING_EXPENSE', groupName: 'Occupancy', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },
    { id: 'acc-6900', entityId: legalEntity.id, code: '6900', name: 'Global Marketing & Brand Advertising', category: 'OPERATING_EXPENSE', groupName: 'Sales & Marketing', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },

    // Current Assets (1000-1499)
    { id: 'acc-1100', entityId: legalEntity.id, code: '1100', name: 'Barclays Primary Operating Bank Account', category: 'CURRENT_ASSET', groupName: 'Cash & Cash Equivalents', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },
    { id: 'acc-1200', entityId: legalEntity.id, code: '1200', name: 'Trade Accounts Receivable', category: 'CURRENT_ASSET', groupName: 'Receivables', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },
    { id: 'acc-1250', entityId: legalEntity.id, code: '1250', name: 'Allowance for Expected Credit Losses', category: 'CURRENT_ASSET', groupName: 'Receivables', normalBalance: 'CREDIT', isIntercompany: false, isActive: true },
    { id: 'acc-1300', entityId: legalEntity.id, code: '1300', name: 'Prepaid Expenses & Accrued Income', category: 'CURRENT_ASSET', groupName: 'Prepayments', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },
    { id: 'acc-1400', entityId: legalEntity.id, code: '1400', name: 'Finished Goods Inventory', category: 'CURRENT_ASSET', groupName: 'Inventory', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },

    // Non-Current Assets (1500-1999)
    { id: 'acc-1600', entityId: legalEntity.id, code: '1600', name: 'Data Center Hardware & Servers', category: 'NON_CURRENT_ASSET', groupName: 'Property, Plant & Equipment', normalBalance: 'DEBIT', isIntercompany: false, isActive: true },
    { id: 'acc-1650', entityId: legalEntity.id, code: '1650', name: 'Accumulated Depreciation - Hardware', category: 'NON_CURRENT_ASSET', groupName: 'Property, Plant & Equipment', normalBalance: 'CREDIT', isIntercompany: false, isActive: true },

    // Current Liabilities (2000-2499)
    { id: 'acc-2100', entityId: legalEntity.id, code: '2100', name: 'Trade Accounts Payable', category: 'CURRENT_LIABILITY', groupName: 'Payables', normalBalance: 'CREDIT', isIntercompany: false, isActive: true },
    { id: 'acc-2200', entityId: legalEntity.id, code: '2200', name: 'Accrued Operating Expenses & Payroll Tax', category: 'CURRENT_LIABILITY', groupName: 'Accruals', normalBalance: 'CREDIT', isIntercompany: false, isActive: true },
    { id: 'acc-2300', entityId: legalEntity.id, code: '2300', name: 'Deferred Revenue - Unearned Contracts', category: 'CURRENT_LIABILITY', groupName: 'Deferred Income', normalBalance: 'CREDIT', isIntercompany: false, isActive: true },
    { id: 'acc-2400', entityId: legalEntity.id, code: '2400', name: 'Corporation Tax Payable', category: 'CURRENT_LIABILITY', groupName: 'Taxation Liabilities', normalBalance: 'CREDIT', isIntercompany: false, isActive: true },

    // Equity (3000-3999)
    { id: 'acc-3000', entityId: legalEntity.id, code: '3000', name: 'Ordinary Share Capital', category: 'EQUITY', groupName: 'Share Capital', normalBalance: 'CREDIT', isIntercompany: false, isActive: true },
    { id: 'acc-3200', entityId: legalEntity.id, code: '3200', name: 'Retained Earnings', category: 'EQUITY', groupName: 'Reserves', normalBalance: 'CREDIT', isIntercompany: false, isActive: true },
  ];

  // Key Counterparties
  const counterparties: Counterparty[] = [
    { id: 'cp-c01', entityId: legalEntity.id, code: 'CUST-001', name: 'Apex Global Corp', type: 'CUSTOMER', country: 'GB', riskRating: 'LOW', paymentTermsDays: 30, firstTransactionDate: '2018-03-15', lastTransactionDate: '2026-12-31', totalVolumeYTD: 1420000 },
    { id: 'cp-c02', entityId: legalEntity.id, code: 'CUST-002', name: 'Vanguard Logistics Ltd', type: 'CUSTOMER', country: 'GB', riskRating: 'MEDIUM', paymentTermsDays: 45, firstTransactionDate: '2019-06-10', lastTransactionDate: '2026-12-31', totalVolumeYTD: 980000 },
    { id: 'cp-c03', entityId: legalEntity.id, code: 'CUST-003', name: 'Orion Technology Group', type: 'CUSTOMER', country: 'US', riskRating: 'LOW', paymentTermsDays: 30, firstTransactionDate: '2020-01-20', lastTransactionDate: '2026-12-31', totalVolumeYTD: 850000 },
    { id: 'cp-c04', entityId: legalEntity.id, code: 'CUST-004', name: 'Quantum Infra Corp', type: 'CUSTOMER', country: 'DE', riskRating: 'HIGH', paymentTermsDays: 60, firstTransactionDate: '2021-11-05', lastTransactionDate: '2026-12-31', totalVolumeYTD: 720000 },
    { id: 'cp-s01', entityId: legalEntity.id, code: 'SUPP-001', name: 'Titanium Components Ltd', type: 'SUPPLIER', country: 'GB', riskRating: 'MEDIUM', paymentTermsDays: 30, firstTransactionDate: '2017-05-12', lastTransactionDate: '2026-12-30', totalVolumeYTD: 1820000 },
    { id: 'cp-s02', entityId: legalEntity.id, code: 'SUPP-002', name: 'Global Logistics SA', type: 'SUPPLIER', country: 'FR', riskRating: 'LOW', paymentTermsDays: 30, firstTransactionDate: '2018-09-01', lastTransactionDate: '2026-12-28', totalVolumeYTD: 940000 },
    { id: 'cp-s03', entityId: legalEntity.id, code: 'SUPP-003', name: 'ABC Industrial Ltd', type: 'SUPPLIER', country: 'GB', riskRating: 'HIGH', paymentTermsDays: 14, firstTransactionDate: '2022-04-18', lastTransactionDate: '2026-12-30', totalVolumeYTD: 340000 },
    { id: 'cp-s04', entityId: legalEntity.id, code: 'SUPP-004', name: 'Apex Advisory Partners', type: 'SUPPLIER', country: 'GB', riskRating: 'LOW', paymentTermsDays: 30, firstTransactionDate: '2020-02-14', lastTransactionDate: '2026-12-15', totalVolumeYTD: 420000 },
  ];

  const journals: Journal[] = [];
  const journalLines: JournalLine[] = [];
  const invoices: Invoice[] = [];

  // 1. Generate Baseline Monthly Historical Accounting Records (2017 to 2026)
  let journalCounter = 1000;
  for (let yr = 2017; yr <= 2026; yr++) {
    for (let m = 1; m <= 12; m++) {
      const monthStr = m < 10 ? `0${m}` : `${m}`;
      const periodId = `p-${yr}-${monthStr}`;
      const isCurrentYear = yr === 2026;
      
      // Monthly Sales Revenue baseline (£1.2m - £1.6m per month)
      const isDecember = m === 12;
      const baseRev = 1350000 + Math.sin(m) * 100000 + (yr - 2017) * 40000;
      // Injected Phenomenon 1: December 2026 Massive Revenue Spike (+£2.74m extra)
      const monthRevenue = (isCurrentYear && isDecember) ? baseRev + 2741829 : baseRev;

      const jId = `jnl-${journalCounter++}`;
      const postingDate = `${yr}-${monthStr}-28`;
      const postingTimestamp = `${postingDate}T16:30:00Z`;

      journals.push({
        id: jId,
        entityId: legalEntity.id,
        periodId,
        journalNumber: `JNL-${yr}-${monthStr}-01`,
        postingDate,
        postingTimestamp,
        sourceSystem: 'SAP S/4HANA',
        sourceFile: `sales_ledger_${yr}_M${monthStr}.csv`,
        journalType: 'SYSTEM',
        description: `Monthly Commercial Revenue & Receivables Recognition M${monthStr}`,
        userId: 'SYS_AUTOMATION',
        userName: 'SAP Automated Billing Engine',
        userRole: 'SYSTEM_BOT',
        approvalStatus: 'AUTO_POSTED',
        isReversal: false,
        isSynthetic: true,
        totalDebit: monthRevenue,
        totalCredit: monthRevenue,
        currency: 'GBP',
      });

      // Dr Trade Receivables (1200)
      journalLines.push({
        id: `line-${jId}-1`,
        journalId: jId,
        lineNumber: 1,
        accountId: 'acc-1200',
        accountCode: '1200',
        accountName: 'Trade Accounts Receivable',
        accountCategory: 'CURRENT_ASSET',
        debit: monthRevenue,
        credit: 0,
        amount: monthRevenue,
        currency: 'GBP',
        fxRate: 1.0,
        amountFunctional: monthRevenue,
        description: `Monthly Revenue Ledger Post M${m}`,
        counterpartyId: 'cp-c01',
        counterpartyName: 'Apex Global Corp',
        counterpartyType: 'CUSTOMER',
        departmentCode: 'DEP-SALES',
        departmentName: 'Commercial Sales',
        postingDate,
        postingTimestamp,
        sourceRecordId: `REC-SAP-${yr}-${m}-01`,
        isSynthetic: true,
      });

      // Cr Sales Revenue (4000)
      journalLines.push({
        id: `line-${jId}-2`,
        journalId: jId,
        lineNumber: 2,
        accountId: 'acc-4000',
        accountCode: '4000',
        accountName: 'Commercial Sales Revenue',
        accountCategory: 'REVENUE',
        debit: 0,
        credit: monthRevenue,
        amount: -monthRevenue,
        currency: 'GBP',
        fxRate: 1.0,
        amountFunctional: -monthRevenue,
        description: `Monthly Revenue Ledger Post M${m}`,
        departmentCode: 'DEP-SALES',
        departmentName: 'Commercial Sales',
        postingDate,
        postingTimestamp,
        sourceRecordId: `REC-SAP-${yr}-${m}-02`,
        isSynthetic: true,
      });

      // Monthly Direct Cloud Infrastructure Expense (£450k)
      const cloudCost = 420000 + Math.random() * 30000;
      const jIdCost = `jnl-${journalCounter++}`;
      journals.push({
        id: jIdCost,
        entityId: legalEntity.id,
        periodId,
        journalNumber: `JNL-${yr}-${monthStr}-02`,
        postingDate: `${yr}-${monthStr}-15`,
        postingTimestamp: `${yr}-${monthStr}-15T10:15:00Z`,
        sourceSystem: 'SAP S/4HANA',
        sourceFile: `ap_journal_${yr}_M${monthStr}.csv`,
        journalType: 'SYSTEM',
        description: `Cloud Infrastructure & Subcontractor Cost Settlement M${monthStr}`,
        userId: 'SYS_AUTOMATION',
        userName: 'SAP AP Posting Bot',
        userRole: 'SYSTEM_BOT',
        approvalStatus: 'AUTO_POSTED',
        isReversal: false,
        isSynthetic: true,
        totalDebit: cloudCost,
        totalCredit: cloudCost,
        currency: 'GBP',
      });

      journalLines.push({
        id: `line-${jIdCost}-1`,
        journalId: jIdCost,
        lineNumber: 1,
        accountId: 'acc-5000',
        accountCode: '5000',
        accountName: 'Direct Cloud Infrastructure Costs',
        accountCategory: 'COST_OF_SALES',
        debit: cloudCost,
        credit: 0,
        amount: cloudCost,
        currency: 'GBP',
        fxRate: 1.0,
        amountFunctional: cloudCost,
        description: `AWS / Cloud Infra Monthly Invoice M${m}`,
        departmentCode: 'DEP-INFRA',
        departmentName: 'Cloud Infrastructure',
        postingDate: `${yr}-${monthStr}-15`,
        postingTimestamp: `${yr}-${monthStr}-15T10:15:00Z`,
        sourceRecordId: `REC-AWS-${yr}-${m}`,
        isSynthetic: true,
      });

      journalLines.push({
        id: `line-${jIdCost}-2`,
        journalId: jIdCost,
        lineNumber: 2,
        accountId: 'acc-2100',
        accountCode: '2100',
        accountName: 'Trade Accounts Payable',
        accountCategory: 'CURRENT_LIABILITY',
        debit: 0,
        credit: cloudCost,
        amount: -cloudCost,
        currency: 'GBP',
        fxRate: 1.0,
        amountFunctional: -cloudCost,
        description: `AWS / Cloud Infra Monthly AP Accrual`,
        counterpartyId: 'cp-s01',
        counterpartyName: 'Titanium Components Ltd',
        counterpartyType: 'SUPPLIER',
        postingDate: `${yr}-${monthStr}-15`,
        postingTimestamp: `${yr}-${monthStr}-15T10:15:00Z`,
        sourceRecordId: `REC-AP-${yr}-${m}`,
        isSynthetic: true,
      });
    }
  }

  // 2. Inject Specific High-Materiality Research Phenomena (2026 Fiscal Year End)

  // Phenomenon 1: 14 Late Manual Year-End Revenue Journals on 31 Dec 2026
  const lateUsers = ['J_SMITH', 'M_TAYLOR', 'D_VANCE'];
  const lateTargetCustomers = [
    { id: 'cp-c01', name: 'Apex Global Corp', amt: 840000 },
    { id: 'cp-c02', name: 'Vanguard Logistics Ltd', amt: 620000 },
    { id: 'cp-c03', name: 'Orion Technology Group', amt: 710000 },
    { id: 'cp-c04', name: 'Quantum Infra Corp', amt: 571829 },
  ];

  lateTargetCustomers.forEach((c, idx) => {
    const lateJnlId = `jnl-late-31dec-${idx + 1}`;
    const timeStr = `2026-12-31T${20 + idx}:${15 + idx * 5}:00Z`;
    journals.push({
      id: lateJnlId,
      entityId: legalEntity.id,
      periodId: 'p-2026-12',
      journalNumber: `MAN-2026-12-YE${10 + idx}`,
      postingDate: '2026-12-31',
      postingTimestamp: timeStr,
      sourceSystem: 'Manual Journal Entry Portal',
      sourceFile: 'yearend_manual_adjustments_2026.xlsx',
      journalType: 'MANUAL',
      description: `Year-End Top-Side Revenue Adjustment - Contract Milestone Recognition #${idx + 1}`,
      userId: lateUsers[idx % lateUsers.length],
      userName: 'John Smith (Group Controller)',
      userRole: 'FINANCIAL_CONTROLLER',
      approvalUserId: 'CFO_OVERRIDE',
      approvalStatus: 'APPROVED',
      isReversal: false,
      isSynthetic: true,
      totalDebit: c.amt,
      totalCredit: c.amt,
      currency: 'GBP',
    });

    journalLines.push({
      id: `line-${lateJnlId}-1`,
      journalId: lateJnlId,
      lineNumber: 1,
      accountId: 'acc-1200',
      accountCode: '1200',
      accountName: 'Trade Accounts Receivable',
      accountCategory: 'CURRENT_ASSET',
      debit: c.amt,
      credit: 0,
      amount: c.amt,
      currency: 'GBP',
      fxRate: 1.0,
      amountFunctional: c.amt,
      description: `Unbilled Revenue Accrual - ${c.name} (Milestone Year-End)`,
      counterpartyId: c.id,
      counterpartyName: c.name,
      counterpartyType: 'CUSTOMER',
      departmentCode: 'DEP-EXEC',
      departmentName: 'Executive Office',
      postingDate: '2026-12-31',
      postingTimestamp: timeStr,
      sourceRecordId: `MAN-YE-LINE-${idx + 1}-A`,
      isSynthetic: true,
    });

    journalLines.push({
      id: `line-${lateJnlId}-2`,
      journalId: lateJnlId,
      lineNumber: 2,
      accountId: 'acc-4000',
      accountCode: '4000',
      accountName: 'Commercial Sales Revenue',
      accountCategory: 'REVENUE',
      debit: 0,
      credit: c.amt,
      amount: -c.amt,
      currency: 'GBP',
      fxRate: 1.0,
      amountFunctional: -c.amt,
      description: `Year-End Top-Side Revenue Adjustment - ${c.name}`,
      departmentCode: 'DEP-EXEC',
      departmentName: 'Executive Office',
      postingDate: '2026-12-31',
      postingTimestamp: timeStr,
      sourceRecordId: `MAN-YE-LINE-${idx + 1}-B`,
      isSynthetic: true,
    });

    invoices.push({
      id: `inv-ye-${idx + 1}`,
      invoiceNumber: `INV-2026-YE0${idx + 1}`,
      entityId: legalEntity.id,
      counterpartyId: c.id,
      counterpartyName: c.name,
      type: 'ACCOUNTS_RECEIVABLE',
      issueDate: '2026-12-31',
      dueDate: '2027-02-28',
      amount: c.amt,
      currency: 'GBP',
      status: 'OPEN',
      description: `Contract Milestone Recognition - Unbilled AR - ${c.name}`,
      journalId: lateJnlId,
      sourceFile: 'yearend_manual_adjustments_2026.xlsx',
      isSynthetic: true,
    });
  });

  // Phenomenon 2: Duplicate Invoices (£84,220 from ABC Industrial Ltd)
  const dupJnl1 = 'jnl-dup-84220-1';
  const dupJnl2 = 'jnl-dup-84220-2';

  journals.push({
    id: dupJnl1,
    entityId: legalEntity.id,
    periodId: 'p-2026-12',
    journalNumber: `AP-2026-8842A`,
    postingDate: '2026-12-28',
    postingTimestamp: '2026-12-28T11:20:00Z',
    sourceSystem: 'Xero AP Integration',
    sourceFile: 'ap_invoices_dec_2026.csv',
    journalType: 'SYSTEM',
    description: 'Factory Plant Maintenance Services - ABC Industrial Ltd',
    userId: 'P_GREEN',
    userName: 'Peter Green (AP Specialist)',
    userRole: 'ACCOUNTANT',
    approvalStatus: 'APPROVED',
    isReversal: false,
    isSynthetic: true,
    totalDebit: 84220,
    totalCredit: 84220,
    currency: 'GBP',
  });

  journalLines.push({
    id: `line-${dupJnl1}-1`,
    journalId: dupJnl1,
    lineNumber: 1,
    accountId: 'acc-6800',
    accountCode: '6800',
    accountName: 'Commercial Premises Lease & Utilities',
    accountCategory: 'OPERATING_EXPENSE',
    debit: 84220,
    credit: 0,
    amount: 84220,
    currency: 'GBP',
    fxRate: 1.0,
    amountFunctional: 84220,
    description: 'Factory Maintenance Invoice #ABC-9921',
    counterpartyId: 'cp-s03',
    counterpartyName: 'ABC Industrial Ltd',
    counterpartyType: 'SUPPLIER',
    postingDate: '2026-12-28',
    postingTimestamp: '2026-12-28T11:20:00Z',
    sourceRecordId: 'REC-DUP-1',
    isSynthetic: true,
  });

  journalLines.push({
    id: `line-${dupJnl1}-2`,
    journalId: dupJnl1,
    lineNumber: 2,
    accountId: 'acc-2100',
    accountCode: '2100',
    accountName: 'Trade Accounts Payable',
    accountCategory: 'CURRENT_LIABILITY',
    debit: 0,
    credit: 84220,
    amount: -84220,
    currency: 'GBP',
    fxRate: 1.0,
    amountFunctional: -84220,
    description: 'Trade AP - ABC Industrial Ltd',
    counterpartyId: 'cp-s03',
    counterpartyName: 'ABC Industrial Ltd',
    counterpartyType: 'SUPPLIER',
    postingDate: '2026-12-28',
    postingTimestamp: '2026-12-28T11:20:00Z',
    sourceRecordId: 'REC-DUP-2',
    isSynthetic: true,
  });

  journals.push({
    id: dupJnl2,
    entityId: legalEntity.id,
    periodId: 'p-2026-12',
    journalNumber: `AP-2026-8842B`,
    postingDate: '2026-12-30',
    postingTimestamp: '2026-12-30T14:45:00Z',
    sourceSystem: 'Manual AP Batch Entry',
    sourceFile: 'manual_vendor_claims.xlsx',
    journalType: 'MANUAL',
    description: 'Plant Maintenance Service Retainer - ABC Industrial Ltd',
    userId: 'H_EVANS',
    userName: 'Hannah Evans (Controller)',
    userRole: 'CONTROLLER',
    approvalStatus: 'APPROVED',
    isReversal: false,
    isSynthetic: true,
    totalDebit: 84220,
    totalCredit: 84220,
    currency: 'GBP',
  });

  journalLines.push({
    id: `line-${dupJnl2}-1`,
    journalId: dupJnl2,
    lineNumber: 1,
    accountId: 'acc-6800',
    accountCode: '6800',
    accountName: 'Commercial Premises Lease & Utilities',
    accountCategory: 'OPERATING_EXPENSE',
    debit: 84220,
    credit: 0,
    amount: 84220,
    currency: 'GBP',
    fxRate: 1.0,
    amountFunctional: 84220,
    description: 'Plant Maintenance Invoice #ABC-9921-DUP',
    counterpartyId: 'cp-s03',
    counterpartyName: 'ABC Industrial Ltd',
    counterpartyType: 'SUPPLIER',
    postingDate: '2026-12-30',
    postingTimestamp: '2026-12-30T14:45:00Z',
    sourceRecordId: 'REC-DUP-3',
    isSynthetic: true,
  });

  journalLines.push({
    id: `line-${dupJnl2}-2`,
    journalId: dupJnl2,
    lineNumber: 2,
    accountId: 'acc-2100',
    accountCode: '2100',
    accountName: 'Trade Accounts Payable',
    accountCategory: 'CURRENT_LIABILITY',
    debit: 0,
    credit: 84220,
    amount: -84220,
    currency: 'GBP',
    fxRate: 1.0,
    amountFunctional: -84220,
    description: 'Trade AP - ABC Industrial Ltd',
    counterpartyId: 'cp-s03',
    counterpartyName: 'ABC Industrial Ltd',
    counterpartyType: 'SUPPLIER',
    postingDate: '2026-12-30',
    postingTimestamp: '2026-12-30T14:45:00Z',
    sourceRecordId: 'REC-DUP-4',
    isSynthetic: true,
  });

  invoices.push({
    id: 'inv-dup-1',
    invoiceNumber: 'INV-ABC-9921',
    entityId: legalEntity.id,
    counterpartyId: 'cp-s03',
    counterpartyName: 'ABC Industrial Ltd',
    type: 'ACCOUNTS_PAYABLE',
    issueDate: '2026-12-28',
    dueDate: '2027-01-11',
    amount: 84220,
    currency: 'GBP',
    status: 'OPEN',
    description: 'Factory Plant Maintenance Services',
    journalId: dupJnl1,
    sourceFile: 'ap_invoices_dec_2026.csv',
    isSynthetic: true,
  });

  invoices.push({
    id: 'inv-dup-2',
    invoiceNumber: 'INV-ABC-9921-DUP',
    entityId: legalEntity.id,
    counterpartyId: 'cp-s03',
    counterpartyName: 'ABC Industrial Ltd',
    type: 'ACCOUNTS_PAYABLE',
    issueDate: '2026-12-30',
    dueDate: '2027-01-13',
    amount: 84220,
    currency: 'GBP',
    status: 'OPEN',
    description: 'Plant Maintenance Service Retainer',
    journalId: dupJnl2,
    sourceFile: 'manual_vendor_claims.xlsx',
    isSynthetic: true,
  });

  // 3. Pre-Calculated Research Discovery Feed (Ranked by Materiality & Novelty)
  const discoveries: DiscoveryItem[] = [
    {
      id: 'disc-2026-001',
      code: 'DISC-2026-001',
      title: 'December Revenue Movement (+£2.74m)',
      category: 'REVENUE_MOVEMENT',
      summary: 'December revenue is 3.8 standard deviations above historical monthly pattern. 82% concentrated in 4 customer accounts.',
      detailedReasoning: [
        'Total December revenue reached £4.09m versus historical monthly baseline of £1.35m (+203% YoY).',
        '82% (£2.25m) of the increase is concentrated in four major customer accounts (Apex Global Corp, Vanguard Logistics, Orion Tech, Quantum Infra).',
        '14 manual journal entries were posted on 31 December between 18:00 and 23:30 GMT by user J_SMITH.',
        'Nominal account family: 4000 (Commercial Sales Revenue) Dr 1200 (Trade Receivables). All journals share unbilled milestone descriptions.'
      ],
      impactAmount: 2741829,
      currency: 'GBP',
      dimensions: {
        materiality: 'CRITICAL',
        novelty: 'HIGH',
        magnitude: 'CRITICAL',
        volatility: 'HIGH',
        timing: 'CRITICAL',
        concentration: 'HIGH',
        deviation: 'CRITICAL',
        relationship: 'MEDIUM',
        persistence: 'LOW',
        reversal: 'HIGH',
        accountingSignificance: 'CRITICAL',
        dataQuality: 'MEDIUM',
      },
      relatedAccountCodes: ['4000', '1200'],
      relatedCounterpartyIds: ['cp-c01', 'cp-c02', 'cp-c03', 'cp-c04'],
      relatedJournalIds: ['jnl-late-31dec-1', 'jnl-late-31dec-2', 'jnl-late-31dec-3', 'jnl-late-31dec-4'],
      periodName: 'Dec 2026',
      dateDetected: '2026-12-31',
      explanationState: 'UNREVIEWED',
      isSynthetic: true,
      score: 98.4,
    },
    {
      id: 'disc-2026-002',
      code: 'DISC-2026-002',
      title: 'Supplier Spend Concentration Shift (Top 5 = 63%)',
      category: 'SUPPLIER_CONCENTRATION',
      summary: 'Top 5 suppliers now represent 63% of total accounts payable purchases vs 41% in prior year. Herfindahl-Hirschman Index increased by +820 points.',
      detailedReasoning: [
        'Titanium Components Ltd spend expanded by +145% YoY (£1.82m total), becoming 38% of total AP outlay.',
        'Global Logistics SA spend increased to £940k (19% of total AP outlay).',
        '3 mid-tier suppliers were discontinued in Q2, concentrating supply chain risk onto two primary vendor relationships.'
      ],
      impactAmount: 2760000,
      currency: 'GBP',
      dimensions: {
        materiality: 'HIGH',
        novelty: 'HIGH',
        magnitude: 'HIGH',
        volatility: 'MEDIUM',
        timing: 'LOW',
        concentration: 'CRITICAL',
        deviation: 'HIGH',
        relationship: 'CRITICAL',
        persistence: 'HIGH',
        reversal: 'LOW',
        accountingSignificance: 'HIGH',
        dataQuality: 'HIGH',
      },
      relatedAccountCodes: ['5000', '2100'],
      relatedCounterpartyIds: ['cp-s01', 'cp-s02'],
      periodName: 'Dec 2026',
      dateDetected: '2026-12-30',
      explanationState: 'UNREVIEWED',
      isSynthetic: true,
      score: 91.2,
    },
    {
      id: 'disc-2026-003',
      code: 'DISC-2026-003',
      title: 'Unusual Year-End Manual Journals (14 Entries)',
      category: 'YEAR_END_JOURNALS',
      summary: '14 manual journal entries posted within final 6 hours of fiscal year accounting window totaling £2.74m.',
      detailedReasoning: [
        'User J_SMITH (John Smith, Group Controller) posted 14 top-side journals directly to Executive Office department.',
        'Symmetry: 100% Dr 1200 (Trade Receivables) / Cr 4000 (Commercial Revenue).',
        'No matching automated delivery receipt or dispatch log found in ERP warehouse system.'
      ],
      impactAmount: 2741829,
      currency: 'GBP',
      dimensions: {
        materiality: 'CRITICAL',
        novelty: 'HIGH',
        magnitude: 'CRITICAL',
        volatility: 'MEDIUM',
        timing: 'CRITICAL',
        concentration: 'MEDIUM',
        deviation: 'CRITICAL',
        relationship: 'HIGH',
        persistence: 'LOW',
        reversal: 'HIGH',
        accountingSignificance: 'CRITICAL',
        dataQuality: 'MEDIUM',
      },
      relatedAccountCodes: ['1200', '4000'],
      relatedJournalIds: ['jnl-late-31dec-1', 'jnl-late-31dec-2', 'jnl-late-31dec-3', 'jnl-late-31dec-4'],
      periodName: 'Dec 2026',
      dateDetected: '2026-12-31',
      explanationState: 'REQUIRES_FURTHER_REVIEW',
      isSynthetic: true,
      score: 94.8,
    },
    {
      id: 'disc-2026-004',
      code: 'DISC-2026-004',
      title: 'Receivables Deterioration & Working Capital Strain (£1.20m)',
      category: 'RECEIVABLES_DETERIORATION',
      summary: 'Days Sales Outstanding (DSO) increased from 42 days to 68 days. £1.20m in aged receivables past due >90 days.',
      detailedReasoning: [
        'Trade Accounts Receivable balance expanded to £3.84m at year-end.',
        'Quantum Infra Corp account shows £571k past 90 days due date with zero cash collection since October.',
        'Operating cash conversion ratio fell from 88% to 41%.'
      ],
      impactAmount: 1200000,
      currency: 'GBP',
      dimensions: {
        materiality: 'HIGH',
        novelty: 'MEDIUM',
        magnitude: 'HIGH',
        volatility: 'HIGH',
        timing: 'LOW',
        concentration: 'HIGH',
        deviation: 'HIGH',
        relationship: 'MEDIUM',
        persistence: 'CRITICAL',
        reversal: 'LOW',
        accountingSignificance: 'HIGH',
        dataQuality: 'HIGH',
      },
      relatedAccountCodes: ['1200', '1250', '1100'],
      relatedCounterpartyIds: ['cp-c04'],
      periodName: 'Dec 2026',
      dateDetected: '2026-12-28',
      explanationState: 'UNREVIEWED',
      isSynthetic: true,
      score: 88.5,
    },
    {
      id: 'disc-2026-005',
      code: 'DISC-2026-005',
      title: 'Possible Duplicate Invoice & Dual Entry (£84,220)',
      category: 'DUPLICATE_INVOICE',
      summary: 'Potential duplicate invoice detected for supplier ABC Industrial Ltd. Identical amount £84,220 posted 2 days apart.',
      detailedReasoning: [
        'Invoice #INV-ABC-9921 posted on 28 Dec (£84,220) via automated Xero AP parser.',
        'Invoice #INV-ABC-9921-DUP posted on 30 Dec (£84,220) via manual batch entry by user H_EVANS.',
        'Description similarity: 97%. Amount: Exact £84,220. Status: Both open in Accounts Payable.'
      ],
      impactAmount: 84220,
      currency: 'GBP',
      dimensions: {
        materiality: 'MEDIUM',
        novelty: 'HIGH',
        magnitude: 'MEDIUM',
        volatility: 'LOW',
        timing: 'HIGH',
        concentration: 'MEDIUM',
        deviation: 'HIGH',
        relationship: 'MEDIUM',
        persistence: 'LOW',
        reversal: 'HIGH',
        accountingSignificance: 'MEDIUM',
        dataQuality: 'CRITICAL',
      },
      relatedAccountCodes: ['6800', '2100'],
      relatedCounterpartyIds: ['cp-s03'],
      relatedJournalIds: [dupJnl1, dupJnl2],
      periodName: 'Dec 2026',
      dateDetected: '2026-12-30',
      explanationState: 'UNREVIEWED',
      isSynthetic: true,
      score: 84.1,
    },
    {
      id: 'disc-2026-006',
      code: 'DISC-2026-006',
      title: 'Expense Reclassification Shift (Professional Fees -> Software)',
      category: 'EXPENSE_RECLASSIFICATION',
      summary: '£380,000 reclassified from Account 6200 (Professional Fees) to Account 6500 (Software Subscriptions) in Q3.',
      detailedReasoning: [
        'Historical monthly professional fees dropped from £95k/mo to £12k/mo starting August 2026.',
        'Software Subscriptions account experienced an offset increase of +£380k over the same period.',
        'Vendor Apex Advisory Partners invoices were redirected from Legal/Audit line item to SaaS IT subscriptions.'
      ],
      impactAmount: 380000,
      currency: 'GBP',
      dimensions: {
        materiality: 'MEDIUM',
        novelty: 'HIGH',
        magnitude: 'MEDIUM',
        volatility: 'MEDIUM',
        timing: 'LOW',
        concentration: 'MEDIUM',
        deviation: 'HIGH',
        relationship: 'HIGH',
        persistence: 'HIGH',
        reversal: 'LOW',
        accountingSignificance: 'MEDIUM',
        dataQuality: 'MEDIUM',
      },
      relatedAccountCodes: ['6200', '6500'],
      relatedCounterpartyIds: ['cp-s04'],
      periodName: 'Sep 2026',
      dateDetected: '2026-09-30',
      explanationState: 'EXPLAINED',
      isSynthetic: true,
      score: 79.8,
    },
    {
      id: 'disc-2026-007',
      code: 'DISC-2026-007',
      title: 'Gross Margin Anomaly vs Falling Unit Prices',
      category: 'MARGIN_ANOMALY',
      summary: 'Gross margin expanded from 36.4% to 41.2% despite average product selling prices falling by 4.5%.',
      detailedReasoning: [
        'Commercial sales unit prices decreased due to enterprise volume discounting.',
        'Cost of Sales line item 5010 (Hardware Components) was reduced by £410k via a year-end inventory cost revaluation.',
        'The gross margin expansion is driven by inventory capitalisation rather than operational efficiency.'
      ],
      impactAmount: 410000,
      currency: 'GBP',
      dimensions: {
        materiality: 'HIGH',
        novelty: 'MEDIUM',
        magnitude: 'HIGH',
        volatility: 'MEDIUM',
        timing: 'MEDIUM',
        concentration: 'LOW',
        deviation: 'HIGH',
        relationship: 'HIGH',
        persistence: 'LOW',
        reversal: 'HIGH',
        accountingSignificance: 'HIGH',
        dataQuality: 'GOOD' as any,
      },
      relatedAccountCodes: ['4000', '5000', '1400'],
      periodName: 'Dec 2026',
      dateDetected: '2026-12-31',
      explanationState: 'UNREVIEWED',
      isSynthetic: true,
      score: 83.0,
    },
    {
      id: 'disc-2026-008',
      code: 'DISC-2026-008',
      title: 'XBRL Note 14 vs Balance Sheet Deferred Tax Variance (£420k)',
      category: 'STATEMENT_RECONCILIATION',
      summary: 'Unexplained £420,000 discrepancy between Note 14 (Taxation Schedule) and Balance Sheet Account 2400.',
      detailedReasoning: [
        'Balance sheet corporation tax liability reads £680,000.',
        'XBRL iXBRL Note 14 tagged fact `uk-gaap:CorporationTaxPayable` calculates £1,100,000.',
        'Variance of £420,000 represents an unmapped deferred tax asset offset.'
      ],
      impactAmount: 420000,
      currency: 'GBP',
      dimensions: {
        materiality: 'HIGH',
        novelty: 'CRITICAL',
        magnitude: 'HIGH',
        volatility: 'LOW',
        timing: 'LOW',
        concentration: 'LOW',
        deviation: 'CRITICAL',
        relationship: 'CRITICAL',
        persistence: 'HIGH',
        reversal: 'LOW',
        accountingSignificance: 'CRITICAL',
        dataQuality: 'HIGH',
      },
      relatedAccountCodes: ['2400'],
      periodName: 'Dec 2026',
      dateDetected: '2026-12-31',
      explanationState: 'UNREVIEWED',
      isSynthetic: true,
      score: 87.4,
    }
  ];

  // XBRL Facts
  const xbrlFacts: XBRLFact[] = [
    { id: 'fact-01', conceptId: 'ifrs-full:RevenueFromContractsWithCustomers', conceptLabel: 'Revenue from Contracts with Customers', value: 18941829, decimals: 0, unit: 'GBP', period: '2026-01-01 to 2026-12-31', entity: 'Rhino UK Operating Ltd', isAudited: true, taxonomyStandard: 'IFRS', sourceTag: 'ixbrl_tag_rev_2026' },
    { id: 'fact-02', conceptId: 'ifrs-full:CostOfSales', conceptLabel: 'Cost of Sales', value: 11140000, decimals: 0, unit: 'GBP', period: '2026-01-01 to 2026-12-31', entity: 'Rhino UK Operating Ltd', isAudited: true, taxonomyStandard: 'IFRS', sourceTag: 'ixbrl_tag_cos_2026' },
    { id: 'fact-03', conceptId: 'ifrs-full:GrossProfit', conceptLabel: 'Gross Profit', value: 7801829, decimals: 0, unit: 'GBP', period: '2026-01-01 to 2026-12-31', entity: 'Rhino UK Operating Ltd', isAudited: true, taxonomyStandard: 'IFRS', sourceTag: 'ixbrl_tag_gp_2026' },
    { id: 'fact-04', conceptId: 'ifrs-full:TradeAndOtherReceivablesCurrent', conceptLabel: 'Trade and Other Receivables', value: 3841829, decimals: 0, unit: 'GBP', period: '2026-12-31', entity: 'Rhino UK Operating Ltd', isAudited: true, taxonomyStandard: 'IFRS', sourceTag: 'ixbrl_tag_ar_2026' },
    { id: 'fact-05', conceptId: 'uk-gaap:CorporationTaxPayableNote14', conceptLabel: 'Corporation Tax Payable (Note 14)', value: 1100000, decimals: 0, unit: 'GBP', period: '2026-12-31', entity: 'Rhino UK Operating Ltd', isAudited: false, taxonomyStandard: 'UK_GAAP', sourceTag: 'ixbrl_tag_tax_note' },
  ];

  const reconciliationChecks: StatementReconciliationCheck[] = [
    { id: 'rec-01', checkName: 'Balance Sheet Equilibrium', primaryFactLabel: 'Total Assets (£8,241,829)', secondaryFactLabel: 'Total Liabilities + Equity (£8,241,829)', statement1: 'Balance Sheet', statement2: 'Balance Sheet', amount1: 8241829, amount2: 8241829, variance: 0, isBalanced: true, notes: 'A = L + E verified.' },
    { id: 'rec-02', checkName: 'P&L Revenue vs Journal Ledger Sum', primaryFactLabel: 'P&L Line Item Revenue (£18,941,829)', secondaryFactLabel: 'Account 4000 Ledger Net Credit (£18,941,829)', statement1: 'Income Statement', statement2: 'General Ledger', amount1: 18941829, amount2: 18941829, variance: 0, isBalanced: true, notes: 'Ledger matches P&L line exactly.' },
    { id: 'rec-03', checkName: 'Note 14 Tax Provision vs Balance Sheet Accrual', primaryFactLabel: 'Note 14 Tax Schedule (£1,100,000)', secondaryFactLabel: 'BS Account 2400 Liability (£680,000)', statement1: 'Notes to Accounts', statement2: 'Balance Sheet', amount1: 1100000, amount2: 680000, variance: 420000, isBalanced: false, notes: 'UNEXPLAINED VARIANCE: £420,000 difference requires audit review.' },
  ];

  return {
    organisation: org,
    legalEntity,
    periods,
    accounts,
    counterparties,
    journals,
    journalLines,
    invoices,
    discoveries,
    xbrlFacts,
    reconciliationChecks,
  };
}

function getMonthName(m: number): string {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return months[m - 1] || 'Jan';
}
