/**
 * Investigation Workbench - 3-Pane Forensic Accounting Workstation
 */

import React, { useState } from 'react';
import { DiscoveryItem } from '../../types/discovery';
import { InvestigationCase, AccountantNote } from '../../types/investigation';
import { SyntheticDataset } from '../../data/simulator';
import {
  FileText,
  Bookmark,
  CheckCircle2,
  Clock,
  ArrowLeft,
  Download,
  Plus,
  Send,
  Database,
  Search,
  ChevronRight,
  Calculator,
  UserCheck
} from 'lucide-react';

interface InvestigationWorkbenchProps {
  discovery: DiscoveryItem;
  dataset: SyntheticDataset;
  onBack: () => void;
  onOpenCalcExplorer: (metricId: string) => void;
}

export const InvestigationWorkbench: React.FC<InvestigationWorkbenchProps> = ({
  discovery,
  dataset,
  onBack,
  onOpenCalcExplorer,
}) => {
  const [explanationState, setExplanationState] = useState<string>(
    discovery.explanationState || 'UNREVIEWED'
  );
  const [isBookmarked, setIsBookmarked] = useState<boolean>(false);
  const [notes, setNotes] = useState<AccountantNote[]>([
    {
      id: 'note-1',
      timestamp: new Date().toISOString(),
      authorName: 'Tom (Lead Auditor)',
      authorRole: 'FORENSIC_ACCOUNTANT',
      content: `Case opened from Discovery Engine flag #${discovery.code}. Examining 14 top-side December revenue manual postings and related unbilled AR milestone schedules.`,
    },
  ]);
  const [newNoteText, setNewNoteText] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Filter relevant transactions for analysis pane
  const relatedLines = dataset.journalLines.filter((line) => {
    if (discovery.relatedAccountCodes.includes(line.accountCode)) return true;
    if (discovery.relatedJournalIds?.includes(line.journalId)) return true;
    if (discovery.relatedCounterpartyIds?.includes(line.counterpartyId || '')) return true;
    return false;
  });

  const filteredLines = relatedLines.filter(
    (line) =>
      line.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      line.accountName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (line.counterpartyName && line.counterpartyName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleAddNote = () => {
    if (!newNoteText.trim()) return;
    const note: AccountantNote = {
      id: `note-${Date.now()}`,
      timestamp: new Date().toISOString(),
      authorName: 'Tom (Lead Auditor)',
      authorRole: 'FORENSIC_ACCOUNTANT',
      content: newNoteText.trim(),
    };
    setNotes([note, ...notes]);
    setNewNoteText('');
  };

  const handleExportEvidence = () => {
    const bundle = {
      discoveryCode: discovery.code,
      title: discovery.title,
      category: discovery.category,
      impactAmount: discovery.impactAmount,
      currency: discovery.currency,
      explanationState,
      notes,
      evidenceLineCount: relatedLines.length,
      sampleLines: relatedLines.slice(0, 20),
      exportedAt: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(bundle, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `EVIDENCE_BUNDLE_${discovery.code}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const states = [
    'UNREVIEWED',
    'REVIEWING',
    'EXPLAINED',
    'EXPECTED',
    'DATA_ISSUE',
    'ACCOUNTING_ADJUSTMENT',
    'BUSINESS_EVENT',
    'REQUIRES_FURTHER_REVIEW',
    'RESOLVED',
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0b0e14] text-slate-200 overflow-hidden">
      {/* Workstation Header Bar */}
      <div className="h-14 border-b border-[#21262d] bg-[#131722] px-4 flex items-center justify-between shrink-0 font-mono">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded hover:bg-[#21262d] text-slate-400 hover:text-slate-100 transition-colors"
            title="Back to Discovery Feed"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <span className="text-xs text-amber-400 font-bold">CASE: {discovery.code}</span>
          <span className="text-slate-600">|</span>
          <h2 className="text-sm font-bold text-white truncate max-w-md">{discovery.title}</h2>
        </div>

        <div className="flex items-center gap-3">
          {/* Explanation State Dropdown */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-400">STATE:</span>
            <select
              value={explanationState}
              onChange={(e) => setExplanationState(e.target.value)}
              className="px-2.5 py-1 text-xs rounded bg-[#161b22] border border-[#30363d] text-amber-300 font-bold focus:outline-none focus:border-amber-500"
            >
              {states.map((s) => (
                <option key={s} value={s}>
                  {s.replace('_', ' ')}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => setIsBookmarked(!isBookmarked)}
            className={`p-1.5 rounded border ${
              isBookmarked
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                : 'bg-[#161b22] text-slate-400 border-[#30363d] hover:text-white'
            }`}
            title="Bookmark Case"
          >
            <Bookmark className="w-4 h-4" />
          </button>

          <button
            onClick={handleExportEvidence}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-amber-500 text-[#0d1117] font-bold text-xs hover:bg-amber-400 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>EXPORT EVIDENCE</span>
          </button>
        </div>
      </div>

      {/* 3-Pane Main Workstation Area */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        {/* PANE 1: EVIDENCE & PROVENANCE CHAIN (Left 3 cols) */}
        <div className="lg:col-span-3 border-r border-[#21262d] bg-[#0d1117] p-4 overflow-y-auto space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-[#21262d]">
            <span className="font-bold text-slate-300 text-xs">EVIDENCE & PROVENANCE</span>
            <span className="text-[10px] text-amber-400">{relatedLines.length} facts</span>
          </div>

          {/* Key Evidence Metrics */}
          <div className="bg-[#131722] p-3 rounded border border-[#21262d] space-y-2">
            <div>
              <div className="text-[10px] text-slate-500">IMPACT AMOUNT</div>
              <div className="text-lg font-bold text-amber-400">
                £{discovery.impactAmount.toLocaleString('en-GB')}
              </div>
            </div>
            <div className="pt-2 border-t border-[#1c212c] grid grid-cols-2 gap-2 text-[11px]">
              <div>
                <div className="text-[10px] text-slate-500">PERIOD</div>
                <div className="text-slate-200">{discovery.periodName}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500">DETECTED</div>
                <div className="text-slate-200">{discovery.dateDetected}</div>
              </div>
            </div>
          </div>

          {/* Inspection Tool Button */}
          <button
            onClick={() => onOpenCalcExplorer(discovery.id)}
            className="w-full py-2 px-3 rounded bg-[#161b22] border border-[#30363d] hover:border-cyan-500/50 text-cyan-300 flex items-center justify-center gap-2 transition-colors font-bold text-xs"
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>INSPECT MATH LINEAGE</span>
          </button>

          {/* Detailed Reasonings */}
          <div className="space-y-2">
            <span className="text-[11px] text-slate-400 font-bold uppercase">REASONING TRACE</span>
            {discovery.detailedReasoning.map((r, i) => (
              <div key={i} className="p-2.5 rounded bg-[#131722] border border-[#21262d] text-slate-300 text-[11px] leading-relaxed">
                {r}
              </div>
            ))}
          </div>

          {/* Related Accounts & Counterparties */}
          <div className="space-y-2 pt-2 border-t border-[#21262d]">
            <span className="text-[11px] text-slate-400 font-bold uppercase">RELATED OBJECTS</span>
            <div className="space-y-1">
              {discovery.relatedAccountCodes.map((code) => (
                <div key={code} className="p-2 rounded bg-[#161b22] border border-[#30363d] flex justify-between items-center text-[11px]">
                  <span className="text-amber-400 font-bold">Account {code}</span>
                  <span className="text-slate-400 text-[10px]">General Ledger</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* PANE 2: DEEP ANALYSIS & DATA GRID (Middle 6 cols) */}
        <div className="lg:col-span-6 border-r border-[#21262d] bg-[#0b0e14] flex flex-col overflow-hidden">
          {/* Filter Bar */}
          <div className="p-3 border-b border-[#21262d] bg-[#131722] flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-1 max-w-sm">
              <Search className="w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Filter evidence transactions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-[#161b22] border border-[#30363d] rounded px-2.5 py-1 text-xs text-slate-200 focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>

            <div className="text-xs font-mono text-slate-400">
              Showing <span className="text-amber-400 font-bold">{filteredLines.length}</span> transaction lines
            </div>
          </div>

          {/* Interactive Financial Transaction Grid */}
          <div className="flex-1 overflow-auto p-4">
            <table className="w-full text-left border-collapse font-mono text-xs">
              <thead>
                <tr className="border-b border-[#21262d] text-slate-400 text-[11px] uppercase pb-2">
                  <th className="py-2 px-2 font-semibold">Date</th>
                  <th className="py-2 px-2 font-semibold">Journal</th>
                  <th className="py-2 px-2 font-semibold">Account</th>
                  <th className="py-2 px-2 font-semibold">Description / Counterparty</th>
                  <th className="py-2 px-2 font-semibold text-right">Debit</th>
                  <th className="py-2 px-2 font-semibold text-right">Credit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1c212c]">
                {filteredLines.map((line) => (
                  <tr key={line.id} className="hover:bg-[#131722] transition-colors text-slate-300">
                    <td className="py-2 px-2 whitespace-nowrap text-slate-400 text-[11px]">
                      {line.postingDate}
                    </td>
                    <td className="py-2 px-2 whitespace-nowrap font-bold text-amber-400/90 text-[11px]">
                      {line.journalId}
                    </td>
                    <td className="py-2 px-2 whitespace-nowrap">
                      <span className="font-bold text-slate-200">{line.accountCode}</span>{' '}
                      <span className="text-[10px] text-slate-500 truncate max-w-[100px] inline-block">{line.accountName}</span>
                    </td>
                    <td className="py-2 px-2">
                      <div className="text-slate-200 text-[11px] font-sans truncate max-w-[200px]">{line.description}</div>
                      {line.counterpartyName && (
                        <div className="text-[10px] text-amber-400/80 font-mono">CP: {line.counterpartyName}</div>
                      )}
                    </td>
                    <td className="py-2 px-2 text-right tabular-nums font-mono text-slate-200">
                      {line.debit > 0 ? `£${line.debit.toLocaleString('en-GB')}` : '-'}
                    </td>
                    <td className="py-2 px-2 text-right tabular-nums font-mono text-emerald-400 font-medium">
                      {line.credit > 0 ? `£${line.credit.toLocaleString('en-GB')}` : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* PANE 3: ACCOUNTANT NOTES & INTERPRETATION (Right 3 cols) */}
        <div className="lg:col-span-3 bg-[#0d1117] p-4 flex flex-col overflow-hidden font-mono text-xs">
          <div className="pb-2 border-b border-[#21262d] flex items-center justify-between mb-3">
            <span className="font-bold text-slate-300">ACCOUNTANT INTERPRETATION</span>
            <UserCheck className="w-3.5 h-3.5 text-amber-400" />
          </div>

          {/* Add Note Input */}
          <div className="mb-4 bg-[#131722] p-3 rounded border border-[#21262d] space-y-2">
            <textarea
              value={newNoteText}
              onChange={(e) => setNewNoteText(e.target.value)}
              placeholder="Record forensic observations or explanation notes..."
              rows={3}
              className="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500 resize-none font-sans"
            />
            <button
              onClick={handleAddNote}
              className="w-full py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-[#0d1117] font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
            >
              <Send className="w-3 h-3" />
              <span>SAVE INTERPRETATION NOTE</span>
            </button>
          </div>

          {/* Notes Log Stream */}
          <div className="flex-1 overflow-y-auto space-y-3">
            <span className="text-[10px] text-slate-500 uppercase font-semibold">AUDIT LOG NOTES</span>
            {notes.map((note) => (
              <div key={note.id} className="p-3 rounded bg-[#131722] border border-[#21262d] space-y-1.5">
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span className="text-amber-400 font-bold">{note.authorName}</span>
                  <span>{new Date(note.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed font-sans">{note.content}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
