/**
 * Financial Statements & XBRL / iXBRL Architecture View
 */

import React, { useState } from 'react';
import { SyntheticDataset } from '../../data/simulator';
import { FileCode2, CheckCircle, AlertTriangle, Layers, BookOpen } from 'lucide-react';

interface FinancialStatementsViewProps {
  dataset: SyntheticDataset;
}

export const FinancialStatementsView: React.FC<FinancialStatementsViewProps> = ({ dataset }) => {
  const [activeSubTab, setActiveSubTab] = useState<'pnl' | 'balancesheet' | 'xbrl' | 'reconciliation'>('reconciliation');

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0b0e14] text-slate-200 overflow-hidden font-mono text-xs">
      {/* Sub-navigation */}
      <div className="h-12 border-b border-[#21262d] bg-[#131722] px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setActiveSubTab('reconciliation')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'reconciliation'
                ? 'bg-[#21262d] text-amber-300 font-bold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            STATEMENT RECONCILIATION
          </button>
          <button
            onClick={() => setActiveSubTab('pnl')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'pnl'
                ? 'bg-[#21262d] text-amber-300 font-bold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            INCOME STATEMENT (P&L)
          </button>
          <button
            onClick={() => setActiveSubTab('balancesheet')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'balancesheet'
                ? 'bg-[#21262d] text-amber-300 font-bold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            BALANCE SHEET
          </button>
          <button
            onClick={() => setActiveSubTab('xbrl')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'xbrl'
                ? 'bg-[#21262d] text-amber-300 font-bold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            XBRL / iXBRL TAXONOMY
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* SUBTAB 1: STATEMENT RECONCILIATION ENGINE */}
        {activeSubTab === 'reconciliation' && (
          <div className="space-y-4">
            <div className="p-4 bg-[#131722] border border-[#21262d] rounded-lg">
              <h3 className="font-bold text-slate-100 text-sm mb-1">STATEMENT RECONCILIATION ENGINE</h3>
              <p className="text-slate-400 text-xs font-sans">
                Automated cross-statement consistency verification checks between General Ledger, Balance Sheet, and XBRL Note Schedules.
              </p>
            </div>

            <div className="space-y-3">
              {dataset.reconciliationChecks.map((check) => (
                <div
                  key={check.id}
                  className={`p-4 rounded-lg border ${
                    check.isBalanced
                      ? 'bg-[#131722] border-[#21262d]'
                      : 'bg-amber-500/10 border-amber-500/40'
                  }`}
                >
                  <div className="flex items-center justify-between pb-2 border-b border-[#21262d] mb-2">
                    <div className="flex items-center gap-2">
                      {check.isBalanced ? (
                        <CheckCircle className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-amber-400" />
                      )}
                      <span className="font-bold text-slate-100">{check.checkName}</span>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        check.isBalanced ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-300'
                      }`}
                    >
                      {check.isBalanced ? 'BALANCED' : 'UNEXPLAINED VARIANCE'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono my-2">
                    <div>
                      <span className="text-[10px] text-slate-500">{check.statement1}</span>
                      <div className="text-slate-200 font-bold">{check.primaryFactLabel}</div>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500">{check.statement2}</span>
                      <div className="text-slate-200 font-bold">{check.secondaryFactLabel}</div>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500">VARIANCE</span>
                      <div className={`font-bold ${check.variance > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                        £{check.variance.toLocaleString('en-GB')}
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 font-sans italic border-t border-[#1c212c] pt-2 mt-2">
                    {check.notes}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SUBTAB 2: INCOME STATEMENT (P&L) */}
        {activeSubTab === 'pnl' && (
          <div className="p-6 bg-[#131722] border border-[#21262d] rounded-lg space-y-4">
            <h3 className="font-bold text-slate-100 text-sm">PROFIT & LOSS STATEMENT (FY 2026)</h3>
            <div className="space-y-2 border-t border-[#21262d] pt-3 text-xs">
              <StatementRow label="Commercial Sales Revenue (Acc 4000)" amount={18941829} isHeader />
              <StatementRow label="Direct Cost of Sales (Acc 5000-5050)" amount={-11140000} />
              <StatementRow label="GROSS PROFIT" amount={7801829} isTotal />
              <StatementRow label="Operating Expenses (Acc 6000-6900)" amount={-5204000} />
              <StatementRow label="OPERATING PROFIT (EBIT)" amount={2597829} isTotal />
            </div>
          </div>
        )}

        {/* SUBTAB 3: BALANCE SHEET */}
        {activeSubTab === 'balancesheet' && (
          <div className="p-6 bg-[#131722] border border-[#21262d] rounded-lg space-y-4">
            <h3 className="font-bold text-slate-100 text-sm">BALANCE SHEET (AS AT 31 DEC 2026)</h3>
            <div className="space-y-2 border-t border-[#21262d] pt-3 text-xs">
              <StatementRow label="Cash & Cash Equivalents (Acc 1100)" amount={2381000} />
              <StatementRow label="Trade Accounts Receivable (Acc 1200)" amount={3841829} />
              <StatementRow label="Inventory & PPE (Acc 1400-1600)" amount={2019000} />
              <StatementRow label="TOTAL ASSETS" amount={8241829} isTotal />
              <StatementRow label="Trade Accounts Payable (Acc 2100)" amount={-4850000} />
              <StatementRow label="Corporation Tax Payable (Acc 2400)" amount={-680000} />
              <StatementRow label="Share Capital & Retained Earnings" amount={-2711829} />
              <StatementRow label="TOTAL LIABILITIES & EQUITY" amount={-8241829} isTotal />
            </div>
          </div>
        )}

        {/* SUBTAB 4: XBRL / iXBRL TAXONOMY */}
        {activeSubTab === 'xbrl' && (
          <div className="space-y-4">
            <div className="p-4 bg-[#131722] border border-[#21262d] rounded-lg">
              <h3 className="font-bold text-slate-100 text-sm mb-1">XBRL / iXBRL MACHINE-READABLE TAXONOMY FACTS</h3>
              <p className="text-slate-400 text-xs font-sans">
                Taxonomy concepts mapped to machine-readable IFRS / UK GAAP tags with full provenance.
              </p>
            </div>

            <div className="border border-[#21262d] rounded overflow-hidden">
              <table className="w-full text-left border-collapse">
                <thead className="bg-[#131722] border-b border-[#21262d] text-slate-400 text-[11px]">
                  <tr>
                    <th className="p-2.5">Concept ID</th>
                    <th className="p-2.5">Label</th>
                    <th className="p-2.5">Standard</th>
                    <th className="p-2.5">Source Tag</th>
                    <th className="p-2.5 text-right">Tagged Fact Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1c212c]">
                  {dataset.xbrlFacts.map((fact) => (
                    <tr key={fact.id} className="hover:bg-[#131722] transition-colors">
                      <td className="p-2.5 font-bold text-amber-400">{fact.conceptId}</td>
                      <td className="p-2.5 font-sans text-slate-200">{fact.conceptLabel}</td>
                      <td className="p-2.5 text-slate-400">{fact.taxonomyStandard}</td>
                      <td className="p-2.5 text-slate-500 text-[10px]">{fact.sourceTag}</td>
                      <td className="p-2.5 text-right font-bold text-emerald-400 tabular-nums">
                        £{fact.value.toLocaleString('en-GB')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const StatementRow: React.FC<{ label: string; amount: number; isHeader?: boolean; isTotal?: boolean }> = ({
  label,
  amount,
  isHeader,
  isTotal,
}) => (
  <div
    className={`flex justify-between items-center p-2 rounded ${
      isTotal ? 'bg-[#161b22] border border-[#30363d] font-bold text-amber-400' : 'text-slate-300'
    }`}
  >
    <span className={isHeader ? 'font-bold text-slate-100' : ''}>{label}</span>
    <span className="tabular-nums">£{Math.abs(amount).toLocaleString('en-GB')}</span>
  </div>
);
