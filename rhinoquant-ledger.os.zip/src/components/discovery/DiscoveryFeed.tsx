/**
 * Discovery Feed Component - "WHAT IS INTERESTING?"
 * The core accounting research terminal view.
 */

import React, { useState } from 'react';
import { DiscoveryItem, PrioritisationMode, DimensionLevel } from '../../types/discovery';
import { AlertTriangle, ArrowRight, Shield, Sparkles, Filter, Layers, Clock, TrendingUp, DollarSign } from 'lucide-react';

interface DiscoveryFeedProps {
  discoveries: DiscoveryItem[];
  onSelectDiscovery: (discovery: DiscoveryItem) => void;
  onRunSignatureDemo: (demoId: string) => void;
  organisationName: string;
}

export const DiscoveryFeed: React.FC<DiscoveryFeedProps> = ({
  discoveries,
  onSelectDiscovery,
  onRunSignatureDemo,
  organisationName,
}) => {
  const [activeMode, setActiveMode] = useState<PrioritisationMode>('MATERIALITY');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const modes: { id: PrioritisationMode; label: string }[] = [
    { id: 'MATERIALITY', label: 'MATERIALITY' },
    { id: 'AUDIT_REVIEW', label: 'AUDIT REVIEW' },
    { id: 'FINANCIAL_CONTROL', label: 'FINANCIAL CONTROL' },
    { id: 'FORENSIC_REVIEW', label: 'FORENSIC REVIEW' },
    { id: 'CASH_REVIEW', label: 'CASH REVIEW' },
    { id: 'REVENUE_REVIEW', label: 'REVENUE REVIEW' },
    { id: 'YEAR_END_REVIEW', label: 'YEAR-END REVIEW' },
  ];

  const signatureDemos = [
    { id: 'demo1_changed', label: 'DEMO 1: What Changed This Year?', icon: '🔍' },
    { id: 'demo2_yearend', label: 'DEMO 2: Year-End Activity', icon: '⏱️' },
    { id: 'demo3_revenue', label: 'DEMO 3: Revenue Decomposition', icon: '📈' },
    { id: 'demo4_cash', label: 'DEMO 4: Cash & Working Capital', icon: '💸' },
    { id: 'demo5_suppliers', label: 'DEMO 5: Supplier Concentration', icon: '🏭' },
    { id: 'demo6_duplicates', label: 'DEMO 6: Duplicate Invoices', icon: '👯' },
  ];

  const filteredDiscoveries = discoveries.filter((d) => {
    if (selectedCategory !== 'ALL' && d.category !== selectedCategory) return false;
    if (activeMode === 'REVENUE_REVIEW' && d.category !== 'REVENUE_MOVEMENT') return false;
    if (activeMode === 'YEAR_END_REVIEW' && d.category !== 'YEAR_END_JOURNALS' && d.category !== 'REVENUE_MOVEMENT') return false;
    if (activeMode === 'CASH_REVIEW' && d.category !== 'RECEIVABLES_DETERIORATION' && d.category !== 'SUPPLIER_CONCENTRATION') return false;
    return true;
  });

  return (
    <div className="flex-1 overflow-y-auto p-6 bg-[#0b0e14] text-slate-200">
      {/* Terminal Title Header */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#21262d]">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 mb-1">
            <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span>ACCOUNTING RESEARCH TERMINAL // REAL-TIME SCAN</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white font-mono flex items-center gap-3">
            <span>WHAT IS INTERESTING?</span>
            <span className="text-xs px-2 py-0.5 rounded bg-[#161b22] border border-[#30363d] text-slate-400 font-normal">
              {organisationName}
            </span>
          </h1>
        </div>

        {/* Dataset Stats Bar */}
        <div className="flex items-center gap-4 text-xs font-mono bg-[#131722] p-2.5 rounded border border-[#21262d]">
          <div>
            <div className="text-slate-500 text-[10px]">TIME HORIZON</div>
            <div className="text-slate-200 font-semibold">10 YEARS (2017-2026)</div>
          </div>
          <div className="w-px h-6 bg-[#21262d]" />
          <div>
            <div className="text-slate-500 text-[10px]">JOURNAL LINES</div>
            <div className="text-slate-200 font-semibold">1,248,392</div>
          </div>
          <div className="w-px h-6 bg-[#21262d]" />
          <div>
            <div className="text-slate-500 text-[10px]">TOTAL VALUE</div>
            <div className="text-amber-400 font-semibold">£184.2M</div>
          </div>
        </div>
      </div>

      {/* Signature Demos Quick Trigger Bar */}
      <div className="mb-6 bg-[#131722] border border-[#21262d] rounded-lg p-3">
        <div className="text-[11px] font-mono text-slate-400 mb-2 font-semibold uppercase tracking-wider flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Signature Accounting Demos (Interactive Scenarios)</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {signatureDemos.map((demo) => (
            <button
              key={demo.id}
              onClick={() => onRunSignatureDemo(demo.id)}
              className="px-2.5 py-2 rounded bg-[#161b22] border border-[#30363d] hover:border-amber-500/50 hover:bg-[#1c212c] text-left transition-colors flex items-center gap-2 group"
            >
              <span className="text-sm">{demo.icon}</span>
              <span className="text-[11px] font-mono text-slate-300 group-hover:text-amber-300 truncate">
                {demo.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Prioritisation Modes & Filter Segmented Controls */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1 bg-[#131722] p-1 rounded-lg border border-[#21262d] overflow-x-auto">
          {modes.map((mode) => (
            <button
              key={mode.id}
              onClick={() => setActiveMode(mode.id)}
              className={`px-3 py-1.5 text-xs font-mono font-medium rounded transition-colors whitespace-nowrap ${
                activeMode === mode.id
                  ? 'bg-amber-500 text-[#0d1117] font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#1c212c]'
              }`}
            >
              {mode.label}
            </button>
          ))}
        </div>

        <div className="text-xs font-mono text-slate-400">
          Showing <span className="text-amber-400 font-bold">{filteredDiscoveries.length}</span> research candidates
        </div>
      </div>

      {/* Discovery Items Feed List */}
      <div className="space-y-4">
        {filteredDiscoveries.map((discovery, idx) => (
          <div
            key={discovery.id}
            className="bg-[#131722] border border-[#21262d] hover:border-amber-500/40 rounded-lg p-5 transition-all shadow-lg"
          >
            {/* Top Bar on Discovery Item */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 mb-3 pb-3 border-b border-[#1c212c]">
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs text-amber-400 font-bold px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/20">
                  #{idx + 1 < 10 ? `0${idx + 1}` : idx + 1}
                </span>
                <span className="font-mono text-xs text-slate-400">{discovery.code}</span>
                <span className="font-mono text-xs text-slate-500">·</span>
                <span className="font-mono text-xs text-slate-400">{discovery.periodName}</span>
                <span className="font-mono text-xs text-slate-500">·</span>
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#1c212c] text-slate-300">
                  {discovery.category.replace('_', ' ')}
                </span>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-[10px] font-mono text-slate-500">IMPACT VALUE</div>
                  <div className="text-sm font-mono font-bold text-amber-400">
                    £{discovery.impactAmount.toLocaleString('en-GB')}
                  </div>
                </div>

                <button
                  onClick={() => onSelectDiscovery(discovery)}
                  className="px-3.5 py-1.5 rounded bg-amber-500 text-[#0d1117] hover:bg-amber-400 font-mono text-xs font-bold transition-colors flex items-center gap-1.5 shrink-0"
                >
                  <span>INVESTIGATE</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Title & Summary */}
            <div className="mb-4">
              <h3 className="text-base font-bold text-white mb-1 tracking-tight font-mono">
                {discovery.title}
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed font-sans">
                {discovery.summary}
              </p>
            </div>

            {/* Reasoning Bullet Highlights */}
            <div className="mb-4 bg-[#0d1117] p-3 rounded border border-[#1c212c] text-xs font-mono space-y-1 text-slate-400">
              {discovery.detailedReasoning.map((reason, rIdx) => (
                <div key={rIdx} className="flex items-start gap-2">
                  <span className="text-amber-400 select-none">›</span>
                  <span>{reason}</span>
                </div>
              ))}
            </div>

            {/* 12 Transparent Analytical Dimensions Breakdown */}
            <div className="pt-2 border-t border-[#1c212c]">
              <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider mb-2 font-semibold">
                ANALYTICAL DIMENSIONS // TRANSPARENT RESEARCH METRICS
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 text-[11px] font-mono">
                <DimensionChip label="Materiality" value={discovery.dimensions.materiality} />
                <DimensionChip label="Novelty" value={discovery.dimensions.novelty} />
                <DimensionChip label="Magnitude" value={discovery.dimensions.magnitude} />
                <DimensionChip label="Volatility" value={discovery.dimensions.volatility} />
                <DimensionChip label="Timing" value={discovery.dimensions.timing} />
                <DimensionChip label="Concentration" value={discovery.dimensions.concentration} />
                <DimensionChip label="Deviation" value={discovery.dimensions.deviation} />
                <DimensionChip label="Relationship" value={discovery.dimensions.relationship} />
                <DimensionChip label="Persistence" value={discovery.dimensions.persistence} />
                <DimensionChip label="Reversal" value={discovery.dimensions.reversal} />
                <DimensionChip label="Significance" value={discovery.dimensions.accountingSignificance} />
                <DimensionChip label="Data Quality" value={discovery.dimensions.dataQuality} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const DimensionChip: React.FC<{ label: string; value: DimensionLevel }> = ({ label, value }) => {
  const getStyle = (val: DimensionLevel) => {
    switch (val) {
      case 'CRITICAL':
        return 'text-red-400 bg-red-500/10 border-red-500/30';
      case 'HIGH':
        return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
      case 'MEDIUM':
        return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30';
      case 'LOW':
      default:
        return 'text-slate-400 bg-[#161b22] border-[#21262d]';
    }
  };

  return (
    <div className={`px-2 py-1 rounded border ${getStyle(value)} flex items-center justify-between`}>
      <span className="text-slate-400 text-[10px] truncate">{label}</span>
      <span className="font-bold text-[10px]">{value}</span>
    </div>
  );
};
