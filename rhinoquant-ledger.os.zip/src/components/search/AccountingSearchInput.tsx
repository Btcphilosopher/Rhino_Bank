/**
 * Accounting Search Input & Results Explorer Modal
 */

import React, { useState } from 'react';
import { parseAndExecuteAccountingQuery, QueryExecutionResult } from '../../engine/searchParser';
import { SyntheticDataset } from '../../data/simulator';
import { Search, X, Sparkles, ArrowRight, CornerDownLeft } from 'lucide-react';

interface AccountingSearchInputProps {
  isOpen: boolean;
  onClose: () => void;
  dataset: SyntheticDataset;
  onSelectDiscovery: (discoveryId: string) => void;
}

export const AccountingSearchInput: React.FC<AccountingSearchInputProps> = ({
  isOpen,
  onClose,
  dataset,
  onSelectDiscovery,
}) => {
  const [searchInput, setSearchInput] = useState<string>('');
  const [result, setResult] = useState<QueryExecutionResult | null>(null);

  if (!isOpen) return null;

  const sampleQueries = [
    'largest unusual expenses this year',
    'what changed most between March and April?',
    'show unusual year-end journals',
    'which suppliers have become more concentrated?',
    'find possible duplicate invoices',
    'show transactions above £100,000',
    'find recurring payments that increased sharply',
    'what changed in working capital?',
  ];

  const handleExecuteSearch = (queryText: string) => {
    setSearchInput(queryText);
    const execResult = parseAndExecuteAccountingQuery(queryText, dataset);
    setResult(execResult);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-mono">
      <div className="bg-[#0d1117] border border-[#21262d] rounded-xl w-full max-w-4xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Search Bar Header */}
        <div className="p-4 border-b border-[#21262d] bg-[#131722] flex items-center gap-3">
          <Search className="w-5 h-5 text-amber-400 shrink-0" />
          <input
            type="text"
            placeholder="Type accounting research query (e.g. 'show unusual year-end journals')..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleExecuteSearch(searchInput)}
            autoFocus
            className="w-full bg-transparent text-slate-100 placeholder-slate-500 text-sm focus:outline-none"
          />
          <button
            onClick={() => handleExecuteSearch(searchInput)}
            className="px-3 py-1.5 bg-amber-500 text-[#0d1117] rounded font-bold text-xs hover:bg-amber-400 shrink-0 flex items-center gap-1"
          >
            <span>SEARCH</span>
            <CornerDownLeft className="w-3 h-3" />
          </button>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white shrink-0">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sample Preset Queries */}
        <div className="p-3 bg-[#161b22] border-b border-[#21262d] flex items-center gap-2 overflow-x-auto text-xs">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span className="text-slate-500 shrink-0">Try:</span>
          {sampleQueries.map((sq) => (
            <button
              key={sq}
              onClick={() => handleExecuteSearch(sq)}
              className="px-2.5 py-1 rounded bg-[#21262d] text-slate-300 hover:text-amber-300 hover:bg-[#30363d] whitespace-nowrap transition-colors"
            >
              {sq}
            </button>
          ))}
        </div>

        {/* Search Results Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {result ? (
            <div className="space-y-4">
              {/* Parsed Intent Summary Card */}
              <div className="p-3 bg-[#131722] border border-amber-500/30 rounded text-xs space-y-1">
                <div className="text-amber-400 font-bold">QUERY PARSER RESULT</div>
                <p className="text-slate-300 font-sans">{result.summaryText}</p>
              </div>

              {/* Matching Discoveries */}
              {result.matchingDiscoveries.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs text-slate-400 font-bold uppercase">MATCHING RESEARCH DISCOVERIES</div>
                  {result.matchingDiscoveries.map((disc) => (
                    <div
                      key={disc.id}
                      onClick={() => {
                        onSelectDiscovery(disc.id);
                        onClose();
                      }}
                      className="p-3 rounded bg-[#131722] border border-[#21262d] hover:border-amber-500/50 cursor-pointer flex justify-between items-center transition-colors"
                    >
                      <div>
                        <div className="font-bold text-amber-300 text-xs">{disc.title}</div>
                        <div className="text-slate-400 text-xs font-sans mt-0.5">{disc.summary}</div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-amber-400 shrink-0" />
                    </div>
                  ))}
                </div>
              )}

              {/* Matching Transaction Lines */}
              {result.matchingLines.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs text-slate-400 font-bold uppercase">MATCHING TRANSACTION LINES ({result.matchingLines.length})</div>
                  <div className="border border-[#21262d] rounded overflow-hidden">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead className="bg-[#131722] text-slate-400 border-b border-[#21262d]">
                        <tr>
                          <th className="p-2">Date</th>
                          <th className="p-2">Account</th>
                          <th className="p-2">Description</th>
                          <th className="p-2 text-right">Amount</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#1c212c]">
                        {result.matchingLines.map((l) => (
                          <tr key={l.id} className="hover:bg-[#131722]">
                            <td className="p-2 text-slate-400">{l.postingDate}</td>
                            <td className="p-2 text-slate-200 font-bold">{l.accountCode}</td>
                            <td className="p-2 text-slate-300 font-sans">{l.description}</td>
                            <td className="p-2 text-right font-bold text-emerald-400 tabular-nums">
                              £{l.amount.toLocaleString('en-GB')}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-12 text-slate-500 text-xs">
              Select or type a query above to execute deterministic natural language search against the general ledger.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
