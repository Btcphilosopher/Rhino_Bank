/**
 * Relationship Graph View
 * Interactive accounting network graph visualization.
 */

import React, { useState } from 'react';
import { Network, Share2, Filter, Layers, Zap } from 'lucide-react';

export const RelationshipGraphView: React.FC = () => {
  const [selectedNode, setSelectedNode] = useState<string | null>('cp-s01');

  const nodes = [
    { id: 'ent-1', label: 'Rhino UK Operating Ltd', type: 'COMPANY', x: 400, y: 250, color: '#f59e0b' },
    { id: 'acc-4000', label: 'Account 4000 (Commercial Sales)', type: 'ACCOUNT', x: 250, y: 150, color: '#22c55e' },
    { id: 'acc-1200', label: 'Account 1200 (Receivables)', type: 'ACCOUNT', x: 250, y: 350, color: '#38bdf8' },
    { id: 'acc-2100', label: 'Account 2100 (Trade AP)', type: 'ACCOUNT', x: 550, y: 150, color: '#ef4444' },
    { id: 'cp-c01', label: 'Apex Global Corp', type: 'CUSTOMER', x: 100, y: 150, color: '#38bdf8' },
    { id: 'cp-c02', label: 'Vanguard Logistics', type: 'CUSTOMER', x: 100, y: 350, color: '#38bdf8' },
    { id: 'cp-s01', label: 'Titanium Components Ltd', type: 'SUPPLIER', x: 700, y: 150, color: '#f59e0b' },
    { id: 'cp-s03', label: 'ABC Industrial Ltd', type: 'SUPPLIER', x: 700, y: 350, color: '#f59e0b' },
    { id: 'user-jsmith', label: 'User J_SMITH (Controller)', type: 'USER', x: 400, y: 50, color: '#a855f7' },
  ];

  const edges = [
    { source: 'user-jsmith', target: 'acc-4000', label: 'POSTED_MANUAL_JOURNAL (£2.74M)', color: '#a855f7' },
    { source: 'cp-c01', target: 'acc-4000', label: 'BILLED (£1.42M)', color: '#22c55e' },
    { source: 'cp-c02', target: 'acc-1200', label: 'UNPAID AR (£980K)', color: '#ef4444' },
    { source: 'cp-s01', target: 'acc-2100', label: 'SUPPLIED AP (£1.82M)', color: '#f59e0b' },
    { source: 'cp-s03', target: 'acc-2100', label: 'DUPLICATE INVOICE (£84.2K)', color: '#ef4444' },
    { source: 'acc-4000', target: 'ent-1', label: 'CREDIT_ENTRY', color: '#22c55e' },
    { source: 'acc-2100', target: 'ent-1', label: 'DEBIT_ENTRY', color: '#ef4444' },
  ];

  const currentNode = nodes.find((n) => n.id === selectedNode);

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0b0e14] text-slate-200 overflow-hidden font-mono text-xs">
      {/* Header Bar */}
      <div className="h-12 border-b border-[#21262d] bg-[#131722] px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <Network className="w-4 h-4 text-amber-400" />
          <span className="font-bold text-slate-100">ACCOUNTING RELATIONSHIP GRAPH</span>
        </div>
        <div className="text-[11px] text-slate-400">
          Nodes: <span className="text-amber-400 font-bold">{nodes.length}</span> | Edges: <span className="text-amber-400 font-bold">{edges.length}</span>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        {/* Interactive Network Graph Canvas */}
        <div className="lg:col-span-9 bg-[#0d1117] relative p-4 flex items-center justify-center overflow-hidden">
          <svg className="w-full h-full max-w-4xl max-h-[500px]" viewBox="0 0 800 450">
            {/* Render Edges */}
            {edges.map((e, idx) => {
              const srcNode = nodes.find((n) => n.id === e.source);
              const tgtNode = nodes.find((n) => n.id === e.target);
              if (!srcNode || !tgtNode) return null;

              return (
                <g key={idx}>
                  <line
                    x1={srcNode.x}
                    y1={srcNode.y}
                    x2={tgtNode.x}
                    y2={tgtNode.y}
                    stroke={e.color}
                    strokeWidth="1.5"
                    strokeDasharray={e.label.includes('DUPLICATE') ? '4' : 'none'}
                    opacity="0.6"
                  />
                  <text
                    x={(srcNode.x + tgtNode.x) / 2}
                    y={(srcNode.y + tgtNode.y) / 2 - 6}
                    fill={e.color}
                    fontSize="9"
                    fontFamily="IBM Plex Mono"
                    textAnchor="middle"
                  >
                    {e.label}
                  </text>
                </g>
              );
            })}

            {/* Render Nodes */}
            {nodes.map((n) => {
              const isSelected = selectedNode === n.id;
              return (
                <g
                  key={n.id}
                  onClick={() => setSelectedNode(n.id)}
                  className="cursor-pointer group"
                >
                  <circle
                    cx={n.x}
                    cy={n.y}
                    r={isSelected ? 18 : 14}
                    fill={n.color}
                    fillOpacity={isSelected ? 0.9 : 0.6}
                    stroke="#ffffff"
                    strokeWidth={isSelected ? 2 : 1}
                    className="transition-all"
                  />
                  <text
                    x={n.x}
                    y={n.y + 26}
                    fill="#e2e8f0"
                    fontSize="10"
                    fontFamily="IBM Plex Mono"
                    fontWeight={isSelected ? 'bold' : 'normal'}
                    textAnchor="middle"
                  >
                    {n.label}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Selected Node Details Panel */}
        <div className="lg:col-span-3 border-l border-[#21262d] bg-[#131722] p-4 font-mono text-xs space-y-4">
          <div className="pb-2 border-b border-[#21262d]">
            <span className="font-bold text-slate-100">NODE INSPECTOR</span>
          </div>

          {currentNode ? (
            <div className="space-y-3">
              <div>
                <span className="text-[10px] text-slate-500">TYPE:</span>
                <div className="text-amber-400 font-bold">{currentNode.type}</div>
              </div>
              <div>
                <span className="text-[10px] text-slate-500">LABEL:</span>
                <div className="text-slate-100 font-bold font-sans">{currentNode.label}</div>
              </div>

              <div className="pt-2 border-t border-[#1c212c]">
                <span className="text-[10px] text-slate-500 uppercase">CONNECTED RELATIONSHIPS</span>
                <div className="mt-2 space-y-1.5 text-[11px]">
                  {edges
                    .filter((e) => e.source === currentNode.id || e.target === currentNode.id)
                    .map((e, i) => (
                      <div key={i} className="p-2 rounded bg-[#161b22] border border-[#30363d] text-slate-300">
                        {e.label}
                      </div>
                    ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-slate-500 text-xs">Select any graph node to inspect relationships.</div>
          )}
        </div>
      </div>
    </div>
  );
};
