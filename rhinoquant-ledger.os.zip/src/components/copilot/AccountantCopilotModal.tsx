/**
 * Accountant Copilot Modal Component
 * Server-side AI assistant using @google/genai with typed tools and non-conclusiveness discipline.
 */

import React, { useState } from 'react';
import { Bot, X, Send, Sparkles, Database, FileText } from 'lucide-react';

interface AccountantCopilotModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AccountantCopilotModal: React.FC<AccountantCopilotModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [promptInput, setPromptInput] = useState<string>('');
  const [messages, setMessages] = useState<
    { role: 'user' | 'assistant'; text: string; sources?: string[] }[]
  >([
    {
      role: 'assistant',
      text: 'Hello. I am the RhinoQuant Accountant Copilot. I analyze accounting facts, explain movements, and cite underlying journal records. How can I assist your investigation?',
      sources: ['Rhino UK Operating Ltd General Ledger', '12-Dimension Discovery Engine'],
    },
  ]);
  const [loading, setLoading] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleAskCopilot = async (promptText: string) => {
    if (!promptText.trim()) return;
    const userMsg = promptText.trim();
    setMessages((prev) => [...prev, { role: 'user', text: userMsg }]);
    setPromptInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/v1/copilot/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: userMsg }),
      });
      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', text: data.answer, sources: data.citedSources },
      ]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: 'Analysis failed to execute.',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const samplePrompts = [
    'Why did December revenue increase so sharply?',
    'Which suppliers present the highest AP concentration risk?',
    'Are there any potential duplicate invoices in Accounts Payable?',
  ];

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-mono">
      <div className="bg-[#0d1117] border border-[#21262d] rounded-xl w-full max-w-3xl h-[80vh] flex flex-col shadow-2xl overflow-hidden text-xs">
        {/* Header */}
        <div className="p-4 border-b border-[#21262d] bg-[#131722] flex items-center justify-between">
          <div className="flex items-center gap-2 text-amber-400 font-bold">
            <Bot className="w-4 h-4" />
            <span>ACCOUNTANT COPILOT // TYPED TOOL INTERPRETATION LAYER</span>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`p-4 rounded-lg border ${
                m.role === 'user'
                  ? 'bg-[#161b22] border-[#30363d] text-slate-200 ml-12'
                  : 'bg-[#131722] border-amber-500/30 text-slate-200 mr-12'
              }`}
            >
              <div className="text-[10px] font-bold text-amber-400 uppercase mb-1">
                {m.role === 'user' ? 'You' : 'RhinoQuant Copilot'}
              </div>
              <p className="font-sans text-xs leading-relaxed text-slate-200">{m.text}</p>

              {m.sources && m.sources.length > 0 && (
                <div className="mt-3 pt-2 border-t border-[#1c212c] text-[10px] space-y-1">
                  <span className="text-slate-500 font-bold">CITED DATA OBJECTS:</span>
                  {m.sources.map((s, sIdx) => (
                    <div key={sIdx} className="text-amber-300 flex items-center gap-1.5">
                      <FileText className="w-3 h-3 text-amber-400" />
                      <span>{s}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="p-4 bg-[#131722] border border-amber-500/30 rounded-lg text-slate-400 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
              <span>Analyzing general ledger & executing typed research tools...</span>
            </div>
          )}
        </div>

        {/* Sample Prompt Chips */}
        <div className="p-3 bg-[#161b22] border-t border-[#21262d] flex items-center gap-2 overflow-x-auto text-[11px]">
          <span className="text-slate-500 shrink-0">Ask:</span>
          {samplePrompts.map((sp) => (
            <button
              key={sp}
              onClick={() => handleAskCopilot(sp)}
              className="px-2.5 py-1 rounded bg-[#21262d] text-slate-300 hover:text-amber-300 hover:bg-[#30363d] whitespace-nowrap"
            >
              {sp}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-[#131722] border-t border-[#21262d] flex items-center gap-2">
          <input
            type="text"
            placeholder="Ask Copilot about accounting movements or anomalies..."
            value={promptInput}
            onChange={(e) => setPromptInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAskCopilot(promptInput)}
            className="flex-1 bg-[#161b22] border border-[#30363d] rounded px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-amber-500"
          />
          <button
            onClick={() => handleAskCopilot(promptInput)}
            className="px-4 py-2 rounded bg-amber-500 hover:bg-amber-400 text-[#0d1117] font-bold text-xs flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            <span>ASK</span>
          </button>
        </div>
      </div>
    </div>
  );
};
