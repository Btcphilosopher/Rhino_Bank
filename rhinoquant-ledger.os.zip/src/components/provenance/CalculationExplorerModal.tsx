/**
 * Calculation Explorer Modal Component
 * Unpacks mathematical lineage, formulas, filters, and source data references.
 */

import React, { useState, useEffect } from 'react';
import { CalculationLineage } from '../../types/provenance';
import { Calculator, X, Database, FileText, CheckCircle2 } from 'lucide-react';

interface CalculationExplorerModalProps {
  isOpen: boolean;
  onClose: () => void;
  metricId: string;
}

export const CalculationExplorerModal: React.FC<CalculationExplorerModalProps> = ({
  isOpen,
  onClose,
  metricId,
}) => {
  const [lineage, setLineage] = useState<CalculationLineage | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    if (isOpen) {
      setLoading(true);
      fetch(`/api/v1/calculations/${metricId}`)
        .then((res) => res.json())
        .then((data) => {
          setLineage(data);
          setLoading(false);
        })
        .catch((err) => {
          console.error(err);
          setLoading(false);
        });
    }
  }, [isOpen, metricId]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-mono">
      <div className="bg-[#0d1117] border border-[#21262d] rounded-xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden text-xs">
        {/* Header */}
        <div className="p-4 border-b border-[#21262d] bg-[#131722] flex items-center justify-between">
          <div className="flex items-center gap-2 text-cyan-400 font-bold">
            <Calculator className="w-4 h-4" />
            <span>CALCULATION EXPLORER // MATHEMATICAL LINEAGE</span>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          {loading || !lineage ? (
            <div className="text-center py-8 text-slate-500">Loading calculation provenance...</div>
          ) : (
            <div className="space-y-4">
              {/* Metric Result Box */}
              <div className="p-4 bg-[#131722] border border-[#21262d] rounded-lg space-y-2">
                <div className="text-[10px] text-slate-500 font-bold uppercase">{lineage.metricName}</div>
                <div className="text-2xl font-bold text-cyan-400">{lineage.formattedResult}</div>
                <div className="text-[11px] text-slate-400">Formula: <span className="text-slate-200 font-bold">{lineage.formula}</span></div>
              </div>

              {/* Filters & Time Period */}
              <div className="p-4 bg-[#131722] border border-[#21262d] rounded-lg space-y-2">
                <span className="text-[10px] text-slate-500 font-bold uppercase">FILTERS & TIME WINDOW</span>
                <div className="text-slate-200 font-bold">{lineage.timePeriod}</div>
                <ul className="list-disc list-inside text-slate-300 text-[11px] space-y-1">
                  {lineage.filtersApplied.map((f, i) => (
                    <li key={i}>{f}</li>
                  ))}
                </ul>
              </div>

              {/* Transformations & Pipeline */}
              <div className="p-4 bg-[#131722] border border-[#21262d] rounded-lg space-y-2">
                <span className="text-[10px] text-slate-500 font-bold uppercase">TRANSFORMATION PIPELINE</span>
                <div className="space-y-1">
                  {lineage.transformations.map((t, i) => (
                    <div key={i} className="flex items-center gap-2 text-slate-300">
                      <span className="text-cyan-400">›</span>
                      <span>{t}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Source Data References */}
              <div className="p-4 bg-[#131722] border border-[#21262d] rounded-lg space-y-2">
                <span className="text-[10px] text-slate-500 font-bold uppercase">SOURCE DATA PROVENANCE</span>
                {lineage.sourceRefs.map((sr, i) => (
                  <div key={i} className="p-2.5 rounded bg-[#161b22] border border-[#30363d] space-y-1">
                    <div className="flex justify-between text-slate-200 font-bold">
                      <span>{sr.sourceSystem}</span>
                      <span className="text-amber-400">{sr.recordCount} Records</span>
                    </div>
                    <div className="text-[10px] text-slate-400">Source File: {sr.sourceFile}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
