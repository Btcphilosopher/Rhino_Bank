/**
 * Ledger Explorer Component
 * General Ledger, Chart of Accounts, Journal Explorer, and Counterparties
 */

import React, { useState } from 'react';
import { SyntheticDataset } from '../../data/simulator';
import { Search, Filter, ArrowUpDown, Clock, FileText, Users, Hash } from 'lucide-react';

interface LedgerExplorerProps {
  dataset: SyntheticDataset;
  onOpenCalcExplorer: (metricId: string) => void;
}

export const LedgerExplorer: React.FC<LedgerExplorerProps> = ({ dataset, onOpenCalcExplorer }) => {
  const [subTab, setSubTab] = useState<'accounts' | 'journals' | 'transactions' | 'counterparties'>('journals');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [showLateDecOnly, setShowLateDecOnly] = useState<boolean>(false);

  // Filter Journals
  const filteredJournals = dataset.journals.filter((j) => {
    if (showLateDecOnly && j.postingDate !== '2026-12-31') return false;
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      return (
        j.journalNumber.toLowerCase().includes(term) ||
        j.description.toLowerCase().includes(term) ||
        j.userName.toLowerCase().includes(term)
      );
    }
    return true;
  });

  // Filter Transactions
  const filteredLines = dataset.journalLines.filter((l) => {
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      return (
        l.accountCode.toLowerCase().includes(term) ||
        l.description.toLowerCase().includes(term) ||
        (l.counterpartyName && l.counterpartyName.toLowerCase().includes(term))
      );
    }
    return true;
  });

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0b0e14] text-slate-200 overflow-hidden font-mono text-xs">
      {/* Sub-navigation Header */}
      <div className="h-12 border-b border-[#21262d] bg-[#131722] px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setSubTab('journals')}
            className={`px-3 py-1.5 rounded transition-colors ${
              subTab === 'journals'
                ? 'bg-[#21262d] text-amber-300 font-bold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            JOURNAL EXPLORER
          </button>
          <button
            onClick={() => setSubTab('accounts')}
            className={`px-3 py-1.5 rounded transition-colors ${
              subTab === 'accounts'
                ? 'bg-[#21262d] text-amber-300 font-bold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            CHART OF ACCOUNTS
          </button>
          <button
            onClick={() => setSubTab('transactions')}
            className={`px-3 py-1.5 rounded transition-colors ${
              subTab === 'transactions'
                ? 'bg-[#21262d] text-amber-300 font-bold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            TRANSACTION GRID
          </button>
          <button
            onClick={() => setSubTab('counterparties')}
            className={`px-3 py-1.5 rounded transition-colors ${
              subTab === 'counterparties'
                ? 'bg-[#21262d] text-amber-300 font-bold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            COUNTERPARTIES
          </button>
        </div>

        {/* Filter Controls */}
        <div className="flex items-center gap-3">
          {subTab === 'journals' && (
            <button
              onClick={() => setShowLateDecOnly(!showLateDecOnly)}
              className={`px-2.5 py-1 rounded text-[11px] font-bold border transition-colors ${
                showLateDecOnly
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                  : 'bg-[#161b22] text-slate-400 border-[#30363d]'
              }`}
            >
              ⏱️ 31 Dec Year-End Manual Postings
            </button>
          )}

          <div className="flex items-center gap-2 bg-[#161b22] border border-[#30363d] rounded px-2.5 py-1">
            <Search className="w-3.5 h-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search ledger..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-transparent text-xs text-slate-200 focus:outline-none w-36"
            />
          </div>
        </div>
      </div>

      {/* Main View Area */}
      <div className="flex-1 overflow-auto p-4">
        {/* VIEW 1: JOURNAL EXPLORER */}
        {subTab === 'journals' && (
          <div className="space-y-4">
            <div className="p-3 bg-[#131722] border border-[#21262d] rounded flex items-center justify-between text-slate-400">
              <div>
                31 DECEMBER FY2026 JOURNAL ACTIVITY: <span className="text-amber-400 font-bold">14,281 Total Journals Posted</span>
              </div>
              <div className="text-[11px] text-slate-500">
                Displaying {filteredJournals.length} journals
              </div>
            </div>

            <div className="border border-[#21262d] rounded overflow-hidden">
              <table className="w-full text-left border-collapse">
                <thead className="bg-[#131722] border-b border-[#21262d] text-slate-400 text-[11px]">
                  <tr>
                    <th className="p-2.5">Journal Number</th>
                    <th className="p-2.5">Posting Date & Time</th>
                    <th className="p-2.5">Type</th>
                    <th className="p-2.5">Description</th>
                    <th className="p-2.5">User & Role</th>
                    <th className="p-2.5 text-right">Debit / Credit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1c212c]">
                  {filteredJournals.map((j) => (
                    <tr key={j.id} className="hover:bg-[#131722] transition-colors">
                      <td className="p-2.5 font-bold text-amber-400">{j.journalNumber}</td>
                      <td className="p-2.5 text-slate-300">
                        {j.postingDate} <span className="text-slate-500 text-[10px]">{j.postingTimestamp.slice(11, 19)}</span>
                      </td>
                      <td className="p-2.5">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            j.journalType === 'MANUAL'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {j.journalType}
                        </span>
                      </td>
                      <td className="p-2.5 text-slate-200 font-sans">{j.description}</td>
                      <td className="p-2.5 text-slate-300">
                        {j.userName} <span className="text-[10px] text-slate-500">({j.userRole})</span>
                      </td>
                      <td className="p-2.5 text-right font-bold text-amber-400 tabular-nums">
                        £{j.totalDebit.toLocaleString('en-GB')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* VIEW 2: CHART OF ACCOUNTS */}
        {subTab === 'accounts' && (
          <div className="border border-[#21262d] rounded overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead className="bg-[#131722] border-b border-[#21262d] text-slate-400 text-[11px]">
                <tr>
                  <th className="p-2.5">Code</th>
                  <th className="p-2.5">Account Name</th>
                  <th className="p-2.5">Category</th>
                  <th className="p-2.5">Group</th>
                  <th className="p-2.5">Normal Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1c212c]">
                {dataset.accounts.map((acc) => (
                  <tr key={acc.id} className="hover:bg-[#131722] transition-colors">
                    <td className="p-2.5 font-bold text-amber-400">{acc.code}</td>
                    <td className="p-2.5 font-bold text-slate-200 font-sans">{acc.name}</td>
                    <td className="p-2.5 text-slate-300">{acc.category}</td>
                    <td className="p-2.5 text-slate-400">{acc.groupName}</td>
                    <td className="p-2.5 text-slate-400">{acc.normalBalance}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* VIEW 3: TRANSACTIONS GRID */}
        {subTab === 'transactions' && (
          <div className="border border-[#21262d] rounded overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead className="bg-[#131722] border-b border-[#21262d] text-slate-400 text-[11px]">
                <tr>
                  <th className="p-2.5">Posting Date</th>
                  <th className="p-2.5">Account Code</th>
                  <th className="p-2.5">Description</th>
                  <th className="p-2.5">Counterparty</th>
                  <th className="p-2.5 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1c212c]">
                {filteredLines.map((l) => (
                  <tr key={l.id} className="hover:bg-[#131722] transition-colors">
                    <td className="p-2.5 text-slate-400">{l.postingDate}</td>
                    <td className="p-2.5 font-bold text-slate-200">{l.accountCode}</td>
                    <td className="p-2.5 text-slate-300 font-sans">{l.description}</td>
                    <td className="p-2.5 text-amber-400">{l.counterpartyName || '-'}</td>
                    <td className="p-2.5 text-right font-bold text-emerald-400 tabular-nums">
                      £{l.amount.toLocaleString('en-GB')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* VIEW 4: COUNTERPARTIES */}
        {subTab === 'counterparties' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {dataset.counterparties.map((cp) => (
              <div key={cp.id} className="p-4 bg-[#131722] border border-[#21262d] rounded-lg space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-400 font-bold">{cp.code}</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      cp.riskRating === 'HIGH'
                        ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                        : 'bg-emerald-500/20 text-emerald-400'
                    }`}
                  >
                    RISK: {cp.riskRating}
                  </span>
                </div>

                <h3 className="font-bold text-slate-100 text-sm font-sans truncate">{cp.name}</h3>

                <div className="pt-2 border-t border-[#1c212c] grid grid-cols-2 gap-2 text-[10px]">
                  <div>
                    <span className="text-slate-500">TYPE:</span>
                    <div className="text-slate-300">{cp.type}</div>
                  </div>
                  <div>
                    <span className="text-slate-500">2026 YTD VOL:</span>
                    <div className="text-amber-400 font-bold">£{cp.totalVolumeYTD.toLocaleString('en-GB')}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
