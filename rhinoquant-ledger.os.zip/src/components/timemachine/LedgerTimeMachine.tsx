/**
 * Accounting Time Machine Component
 * Animate and inspect accounting evolution across fiscal checkpoints.
 */

import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Clock, Calendar } from 'lucide-react';

export const LedgerTimeMachine: React.FC = () => {
  const checkpoints = [
    { date: '01 JAN 2026', label: 'FY26 Opening Balance', rev: 0, ar: 1200000, cash: 4100000, hhi: 1320, anomaly: 'None' },
    { date: '31 MAR 2026', label: 'Q1 Close', rev: 4050000, ar: 1450000, cash: 3800000, hhi: 1450, anomaly: 'Normal' },
    { date: '30 JUN 2026', label: 'Q2 Half-Year Close', rev: 8150000, ar: 1800000, cash: 3400000, hhi: 1620, anomaly: 'Supplier Shift' },
    { date: '30 SEP 2026', label: 'Q3 Close', rev: 12200000, ar: 2100000, cash: 2900000, hhi: 1850, anomaly: 'Expense Reclass' },
    { date: '31 DEC 2026', label: 'FY26 Year-End Close', rev: 18941829, ar: 3841829, cash: 2381000, hhi: 2140, anomaly: 'Dec Revenue Surge' },
  ];

  const [activeIdx, setActiveIdx] = useState<number>(4);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying) {
      timer = setInterval(() => {
        setActiveIdx((prev) => (prev + 1) % checkpoints.length);
      }, 1500);
    }
    return () => clearInterval(timer);
  }, [isPlaying]);

  const cp = checkpoints[activeIdx];

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0b0e14] text-slate-200 overflow-hidden font-mono text-xs">
      {/* Control Header */}
      <div className="h-14 border-b border-[#21262d] bg-[#131722] px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <Clock className="w-4 h-4 text-amber-400" />
          <span className="font-bold text-slate-100">LEDGER TIME MACHINE</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-amber-500 text-[#0d1117] font-bold text-xs hover:bg-amber-400 transition-colors"
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isPlaying ? 'PAUSE EVOLUTION' : 'ANIMATE TIME EVOLUTION'}</span>
          </button>
          <button
            onClick={() => {
              setIsPlaying(false);
              setActiveIdx(0);
            }}
            className="p-1.5 rounded bg-[#161b22] border border-[#30363d] text-slate-400 hover:text-white"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Checkpoint Display */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Timeline Slider Track */}
        <div className="p-4 bg-[#131722] border border-[#21262d] rounded-lg space-y-3">
          <div className="flex justify-between text-xs font-bold text-slate-400">
            <span>CHECKPOINT: {cp.date}</span>
            <span className="text-amber-400">{cp.label}</span>
          </div>

          <div className="grid grid-cols-5 gap-2">
            {checkpoints.map((item, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setIsPlaying(false);
                  setActiveIdx(idx);
                }}
                className={`p-3 rounded border text-center transition-all ${
                  activeIdx === idx
                    ? 'bg-amber-500 text-[#0d1117] font-bold border-amber-400'
                    : 'bg-[#161b22] border-[#30363d] text-slate-400 hover:text-white'
                }`}
              >
                <div className="text-[10px]">{item.date}</div>
                <div className="text-[9px] opacity-80 mt-1 truncate">{item.label}</div>
              </button>
            ))}
          </div>
        </div>

        {/* State Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <TimeCard title="CUMULATIVE REVENUE" value={`£${cp.rev.toLocaleString('en-GB')}`} />
          <TimeCard title="TRADE RECEIVABLES (AR)" value={`£${cp.ar.toLocaleString('en-GB')}`} highlight />
          <TimeCard title="OPERATING CASH BALANCE" value={`£${cp.cash.toLocaleString('en-GB')}`} />
          <TimeCard title="SUPPLIER HHI INDEX" value={`${cp.hhi} HHI`} />
        </div>

        {/* Emerged Anomaly Banner */}
        <div className="p-4 bg-[#131722] border border-[#21262d] rounded-lg">
          <span className="text-[10px] text-slate-500 font-bold uppercase">EMERGING FINANCIAL PHENOMENON</span>
          <div className="text-base font-bold text-amber-400 mt-1">{cp.anomaly}</div>
        </div>
      </div>
    </div>
  );
};

const TimeCard: React.FC<{ title: string; value: string; highlight?: boolean }> = ({ title, value, highlight }) => (
  <div className={`p-4 bg-[#131722] border ${highlight ? 'border-amber-500/50' : 'border-[#21262d]'} rounded-lg space-y-1`}>
    <div className="text-[10px] text-slate-500">{title}</div>
    <div className="text-xl font-bold text-slate-100">{value}</div>
  </div>
);
