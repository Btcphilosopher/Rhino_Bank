/**
 * Analysis Workstation - Variance Bridge, Concentration Engine & Working Capital Graph
 */

import React, { useState } from 'react';
import { SyntheticDataset } from '../../data/simulator';
import { TrendingUp, PieChart, DollarSign, Activity, Layers } from 'lucide-react';

interface AnalysisWorkstationProps {
  dataset: SyntheticDataset;
}

export const AnalysisWorkstation: React.FC<AnalysisWorkstationProps> = ({ dataset }) => {
  const [subTab, setSubTab] = useState<'variance' | 'concentration' | 'workingcapital' | 'ratios'>('variance');

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0b0e14] text-slate-200 overflow-hidden font-mono text-xs">
      {/* Sub-navigation */}
      <div className="h-12 border-b border-[#21262d] bg-[#131722] px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setSubTab('variance')}
            className={`px-3 py-1.5 rounded transition-colors ${
              subTab === 'variance'
                ? 'bg-[#21262d] text-amber-300 font-bold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            VARIANCE DECOMPOSITION
          </button>
          <button
            onClick={() => setSubTab('concentration')}
            className={`px-3 py-1.5 rounded transition-colors ${
              subTab === 'concentration'
                ? 'bg-[#21262d] text-amber-300 font-bold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            CONCENTRATION ENGINE
          </button>
          <button
            onClick={() => setSubTab('workingcapital')}
            className={`px-3 py-1.5 rounded transition-colors ${
              subTab === 'workingcapital'
                ? 'bg-[#21262d] text-amber-300 font-bold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            WORKING CAPITAL & CASH
          </button>
          <button
            onClick={() => setSubTab('ratios')}
            className={`px-3 py-1.5 rounded transition-colors ${
              subTab === 'ratios'
                ? 'bg-[#21262d] text-amber-300 font-bold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            RATIO MATRIX
          </button>
        </div>
      </div>

      {/* Main Analysis Body */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* SUBTAB 1: VARIANCE DECOMPOSITION */}
        {subTab === 'variance' && (
          <div className="space-y-6">
            <div className="p-4 bg-[#131722] border border-[#21262d] rounded-lg">
              <h3 className="font-bold text-slate-100 text-sm mb-1">VARIANCE BRIDGE & WATERFALL DECOMPOSITION</h3>
              <p className="text-slate-400 text-xs font-sans">
                Decomposing Operating Cost Increase (+£1.42m YoY) into underlying cost driver components.
              </p>

              {/* Waterfall Visual Breakdown */}
              <div className="mt-6 space-y-3">
                <WaterfallBar label="Prior Year Operating Base" amount={11480000} isTotal />
                <WaterfallBar label="+ Personnel Payroll & Salaries" amount={410000} isIncrease />
                <WaterfallBar label="+ Data Center & Energy Costs" amount={290000} isIncrease />
                <WaterfallBar label="+ Professional Advisory & Legal" amount={250000} isIncrease />
                <WaterfallBar label="+ Premises Rent & Occupancy" amount={180000} isIncrease />
                <WaterfallBar label="+ Other Operating Outlays" amount={290000} isIncrease />
                <WaterfallBar label="Current Year Operating Total" amount={12900000} isTotal />
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 2: CONCENTRATION ENGINE */}
        {subTab === 'concentration' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Supplier AP Concentration */}
              <div className="p-4 bg-[#131722] border border-[#21262d] rounded-lg space-y-3">
                <div className="flex justify-between items-center border-b border-[#21262d] pb-2">
                  <span className="font-bold text-slate-100">ACCOUNTS PAYABLE CONCENTRATION</span>
                  <span className="text-amber-400 font-bold">HHI: 2,140</span>
                </div>
                <p className="text-slate-400 text-xs font-sans">
                  Top 5 suppliers represent 63% of total accounts payable outlay (£3.10m / £4.85m).
                </p>

                <div className="space-y-2 pt-2">
                  <ConcentrationRow name="Titanium Components Ltd" pct={38} amount={1820000} />
                  <ConcentrationRow name="Global Logistics SA" pct={19} amount={940000} />
                  <ConcentrationRow name="Apex Advisory Partners" pct={9} amount={420000} />
                  <ConcentrationRow name="ABC Industrial Ltd" pct={7} amount={340000} />
                  <ConcentrationRow name="Remaining 42 Suppliers" pct={27} amount={1330000} />
                </div>
              </div>

              {/* Customer AR Revenue Concentration */}
              <div className="p-4 bg-[#131722] border border-[#21262d] rounded-lg space-y-3">
                <div className="flex justify-between items-center border-b border-[#21262d] pb-2">
                  <span className="font-bold text-slate-100">REVENUE CUSTOMER CONCENTRATION</span>
                  <span className="text-amber-400 font-bold">HHI: 1,890</span>
                </div>
                <p className="text-slate-400 text-xs font-sans">
                  Top 4 customers represent 71% of December revenue increase (£2.25m / £2.74m).
                </p>

                <div className="space-y-2 pt-2">
                  <ConcentrationRow name="Apex Global Corp" pct={31} amount={840000} />
                  <ConcentrationRow name="Orion Technology Group" pct={26} amount={710000} />
                  <ConcentrationRow name="Vanguard Logistics Ltd" pct={23} amount={620000} />
                  <ConcentrationRow name="Quantum Infra Corp" pct={20} amount={571829} />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 3: WORKING CAPITAL & CASH FLOW GRAPH */}
        {subTab === 'workingcapital' && (
          <div className="p-6 bg-[#131722] border border-[#21262d] rounded-lg space-y-6">
            <h3 className="font-bold text-slate-100 text-sm">WORKING CAPITAL INVESTIGATION CHAIN</h3>
            <p className="text-slate-400 text-xs font-sans">
              Tracing cash conversion bottleneck: Profit (£7.80m) -&gt; Receivables (+£3.84m) -&gt; Cash Collection Strain.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 text-center">
              <FlowBox title="1. REVENUE" value="£18.94M" sub="Dec Surge +£2.74m" color="border-emerald-500/40" />
              <FlowBox title="2. RECEIVABLES" value="£3.84M" sub="DSO = 68 Days" color="border-amber-500/50" highlight />
              <FlowBox title="3. CASH COLLECTED" value="£15.10M" sub="Cash Conversion = 41%" color="border-red-500/40" />
              <FlowBox title="4. PAYABLES OUTFLOW" value="£4.85M" sub="Supplier Spend 63% Top 5" color="border-cyan-500/40" />
              <FlowBox title="5. NET OPERATING CASH" value="£2.38M" sub="Down 42% YoY" color="border-purple-500/40" />
            </div>
          </div>
        )}

        {/* SUBTAB 4: RATIO MATRIX */}
        {subTab === 'ratios' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <RatioCard title="Gross Profit Margin" current="41.19%" prior="36.40%" status="ANOMALY_REVIEW" />
            <RatioCard title="Days Sales Outstanding (DSO)" current="68.2 Days" prior="42.1 Days" status="DETERIORATING" />
            <RatioCard title="Current Ratio" current="1.84x" prior="2.15x" status="STABLE" />
            <RatioCard title="Working Capital Turnover" current="4.93x" prior="6.81x" status="STRAINED" />
            <RatioCard title="Supplier Concentration Index (HHI)" current="2,140" prior="1,320" status="CONCENTRATED" />
            <RatioCard title="Operating Cash Conversion" current="41.2%" prior="88.4%" status="ATTENTION_REQUIRED" />
          </div>
        )}
      </div>
    </div>
  );
};

const WaterfallBar: React.FC<{ label: string; amount: number; isIncrease?: boolean; isTotal?: boolean }> = ({
  label,
  amount,
  isIncrease,
  isTotal,
}) => (
  <div className="flex items-center justify-between p-2.5 rounded bg-[#161b22] border border-[#30363d]">
    <span className={`font-mono text-xs ${isTotal ? 'font-bold text-amber-400' : 'text-slate-300'}`}>{label}</span>
    <span className={`font-mono text-xs font-bold ${isIncrease ? 'text-amber-400' : isTotal ? 'text-slate-100' : 'text-slate-300'}`}>
      £{amount.toLocaleString('en-GB')}
    </span>
  </div>
);

const ConcentrationRow: React.FC<{ name: string; pct: number; amount: number }> = ({ name, pct, amount }) => (
  <div className="space-y-1">
    <div className="flex justify-between text-xs">
      <span className="text-slate-200 font-sans">{name}</span>
      <span className="text-amber-400 font-bold">{pct}% (£{amount.toLocaleString('en-GB')})</span>
    </div>
    <div className="h-2 bg-[#161b22] rounded-full overflow-hidden">
      <div className="h-full bg-amber-500 rounded-full" style={{ width: `${pct}%` }} />
    </div>
  </div>
);

const FlowBox: React.FC<{ title: string; value: string; sub: string; color: string; highlight?: boolean }> = ({
  title,
  value,
  sub,
  color,
  highlight,
}) => (
  <div className={`p-4 bg-[#161b22] border ${color} rounded-lg ${highlight ? 'ring-2 ring-amber-500/50' : ''}`}>
    <div className="text-[10px] text-slate-500 font-bold">{title}</div>
    <div className="text-base font-bold text-slate-100 mt-1">{value}</div>
    <div className="text-[10px] text-amber-400 mt-1">{sub}</div>
  </div>
);

const RatioCard: React.FC<{ title: string; current: string; prior: string; status: string }> = ({
  title,
  current,
  prior,
  status,
}) => (
  <div className="p-4 bg-[#131722] border border-[#21262d] rounded-lg space-y-2">
    <div className="text-[10px] text-slate-500 uppercase">{title}</div>
    <div className="text-xl font-bold text-amber-400">{current}</div>
    <div className="flex justify-between items-center text-[10px] text-slate-400 pt-2 border-t border-[#1c212c]">
      <span>PRIOR: {prior}</span>
      <span className="text-amber-400 font-bold">{status}</span>
    </div>
  </div>
);
