/**
 * TopBar Component - Strict 1-row, 3-zone Top Bar Contract
 */

import React from 'react';
import { Search, Bot, Calculator, ShieldCheck, Database, SlidersHorizontal } from 'lucide-react';

interface TopBarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenSearch: () => void;
  onOpenCopilot: () => void;
  onOpenCalcExplorer: () => void;
  organisationName: string;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  setActiveTab,
  onOpenSearch,
  onOpenCopilot,
  onOpenCalcExplorer,
  organisationName,
}) => {
  const navItems = [
    { id: 'discover', label: 'DISCOVER' },
    { id: 'ledger', label: 'LEDGER' },
    { id: 'statements', label: 'STATEMENTS' },
    { id: 'analysis', label: 'ANALYSIS' },
    { id: 'graph', label: 'GRAPH' },
    { id: 'investigations', label: 'INVESTIGATIONS' },
    { id: 'timemachine', label: 'TIME MACHINE' },
    { id: 'data', label: 'DATA' },
  ];

  return (
    <header className="h-14 border-b border-[#21262d] bg-[#0d1117] px-4 flex items-center justify-between shrink-0 select-none">
      {/* Zone 1: Single-element Brand Title */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-[#0d1117] font-black text-xs tracking-tighter">
            RQ
          </div>
          <span className="text-sm font-bold tracking-tight text-slate-100 font-mono">
            RHINOQUANT <span className="text-amber-400 font-normal">LEDGER.OS</span>
          </span>
        </div>
        <div className="hidden lg:flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#161b22] border border-[#30363d] text-[11px] text-slate-400 font-mono">
          <Database className="w-3 h-3 text-amber-400" />
          <span className="truncate max-w-[180px]">{organisationName}</span>
        </div>
      </div>

      {/* Zone 2: Navigation Links */}
      <nav className="hidden md:flex items-center gap-1 text-xs font-mono font-medium">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`px-3 py-1.5 rounded transition-colors whitespace-nowrap ${
                isActive
                  ? 'bg-[#21262d] text-amber-300 font-semibold border border-amber-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#161b22]'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: Primary Actions */}
      <div className="flex items-center gap-2">
        <button
          onClick={onOpenSearch}
          className="flex items-center gap-2 px-2.5 py-1.5 rounded bg-[#161b22] border border-[#30363d] text-xs text-slate-300 hover:border-amber-500/50 hover:text-white transition-colors"
          title="Accounting Search (Ctrl+K)"
        >
          <Search className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden sm:inline font-mono text-[11px]">Search...</span>
          <kbd className="hidden sm:inline-block px-1 py-0.2 text-[9px] font-mono bg-[#21262d] text-slate-400 rounded">
            Ctrl K
          </kbd>
        </button>

        <button
          onClick={onOpenCalcExplorer}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded bg-[#161b22] border border-[#30363d] text-xs text-slate-300 hover:border-amber-500/50 hover:text-white transition-colors font-mono text-[11px]"
          title="Inspect Math Lineage"
        >
          <Calculator className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden xl:inline">Calc Explorer</span>
        </button>

        <button
          onClick={onOpenCopilot}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-amber-500/10 border border-amber-500/40 text-amber-300 hover:bg-amber-500/20 text-xs font-mono font-medium transition-colors"
        >
          <Bot className="w-3.5 h-3.5 text-amber-400" />
          <span>Copilot AI</span>
        </button>
      </div>
    </header>
  );
};
