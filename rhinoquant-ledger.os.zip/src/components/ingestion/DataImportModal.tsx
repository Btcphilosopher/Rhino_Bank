/**
 * Data Import & Ingestion Modal
 */

import React, { useState } from 'react';
import Papa from 'papaparse';
import { Upload, FileSpreadsheet, CheckCircle2, X } from 'lucide-react';

interface DataImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDatasetImported: (datasetName: string, rows: any[]) => void;
}

export const DataImportModal: React.FC<DataImportModalProps> = ({
  isOpen,
  onClose,
  onDatasetImported,
}) => {
  const [datasetName, setDatasetName] = useState<string>('');
  const [importedRows, setImportedRows] = useState<any[]>([]);
  const [statusMessage, setStatusMessage] = useState<string>('');

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!datasetName) {
      setDatasetName(file.name.replace(/\.[^/.]+$/, ''));
    }

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        setImportedRows(results.data);
        setStatusMessage(`Successfully parsed ${results.data.length} records from ${file.name}.`);
      },
    });
  };

  const handleConfirmImport = () => {
    if (importedRows.length === 0) return;
    fetch('/api/v1/datasets/import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ datasetName, rows: importedRows }),
    })
      .then((res) => res.json())
      .then((data) => {
        onDatasetImported(datasetName || 'Imported Accounting Dataset', importedRows);
        onClose();
      })
      .catch((err) => console.error(err));
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-mono text-xs">
      <div className="bg-[#0d1117] border border-[#21262d] rounded-xl w-full max-w-xl p-6 space-y-4 shadow-2xl">
        <div className="flex justify-between items-center border-b border-[#21262d] pb-3">
          <div className="flex items-center gap-2 text-amber-400 font-bold">
            <Upload className="w-4 h-4" />
            <span>IMPORT ACCOUNTING DATASET</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-slate-400 text-[10px] uppercase font-bold block mb-1">
              ORGANISATION / DATASET NAME
            </label>
            <input
              type="text"
              placeholder="e.g. Acme Corp Ltd General Ledger"
              value={datasetName}
              onChange={(e) => setDatasetName(e.target.value)}
              className="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-slate-100 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="border-2 border-dashed border-[#30363d] rounded-lg p-6 text-center space-y-2 hover:border-amber-500/50 transition-colors">
            <FileSpreadsheet className="w-8 h-8 text-amber-400 mx-auto" />
            <div className="text-slate-300 font-bold">Select CSV, Excel, Parquet, or JSON File</div>
            <div className="text-[10px] text-slate-500">Supports General Ledger, Trial Balance, Invoices, Payments, XBRL</div>
            <input
              type="file"
              accept=".csv,.json,.txt"
              onChange={handleFileUpload}
              className="hidden"
              id="file-upload-input"
            />
            <label
              htmlFor="file-upload-input"
              className="inline-block mt-2 px-4 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-[#0d1117] font-bold cursor-pointer transition-colors"
            >
              BROWSE FILE
            </label>
          </div>

          {statusMessage && (
            <div className="p-3 bg-[#131722] border border-emerald-500/30 text-emerald-400 rounded flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>{statusMessage}</span>
            </div>
          )}
        </div>

        <div className="pt-3 border-t border-[#21262d] flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded bg-[#161b22] border border-[#30363d] text-slate-400 hover:text-white"
          >
            CANCEL
          </button>
          <button
            onClick={handleConfirmImport}
            disabled={importedRows.length === 0}
            className="px-4 py-2 rounded bg-amber-500 hover:bg-amber-400 text-[#0d1117] font-bold disabled:opacity-50 transition-colors"
          >
            CONFIRM IMPORT & RUN DISCOVERY ENGINE
          </button>
        </div>
      </div>
    </div>
  );
};
