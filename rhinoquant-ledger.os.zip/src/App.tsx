/**
 * RhinoQuant Ledger.OS — Main Application Component
 */

import React, { useState, useEffect } from 'react';
import { generateRhinoDemoDataset, SyntheticDataset } from './data/simulator';
import { DiscoveryItem } from './types/discovery';
import { TopBar } from './components/layout/TopBar';
import { DiscoveryFeed } from './components/discovery/DiscoveryFeed';
import { InvestigationWorkbench } from './components/investigation/InvestigationWorkbench';
import { LedgerExplorer } from './components/ledger/LedgerExplorer';
import { FinancialStatementsView } from './components/statements/FinancialStatementsView';
import { AnalysisWorkstation } from './components/analysis/AnalysisWorkstation';
import { RelationshipGraphView } from './components/graph/RelationshipGraphView';
import { LedgerTimeMachine } from './components/timemachine/LedgerTimeMachine';
import { AccountingSearchInput } from './components/search/AccountingSearchInput';
import { CalculationExplorerModal } from './components/provenance/CalculationExplorerModal';
import { AccountantCopilotModal } from './components/copilot/AccountantCopilotModal';
import { DataImportModal } from './components/ingestion/DataImportModal';

export default function App() {
  const [dataset, setDataset] = useState<SyntheticDataset>(() => generateRhinoDemoDataset());
  const [activeTab, setActiveTab] = useState<string>('discover');
  const [selectedDiscovery, setSelectedDiscovery] = useState<DiscoveryItem | null>(null);

  // Modals
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isCopilotOpen, setIsCopilotOpen] = useState<boolean>(false);
  const [isCalcExplorerOpen, setIsCalcExplorerOpen] = useState<boolean>(false);
  const [calcMetricId, setCalcMetricId] = useState<string>('december_revenue');
  const [isImportOpen, setIsImportOpen] = useState<boolean>(false);

  // Keyboard Shortcuts (e.g. Ctrl+K for search)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleOpenCalcExplorer = (metricId: string) => {
    setCalcMetricId(metricId);
    setIsCalcExplorerOpen(true);
  };

  const handleSelectDiscovery = (discovery: DiscoveryItem) => {
    setSelectedDiscovery(discovery);
  };

  const handleRunSignatureDemo = (demoId: string) => {
    switch (demoId) {
      case 'demo1_changed':
        setActiveTab('analysis');
        break;
      case 'demo2_yearend':
        const yeDisc = dataset.discoveries.find((d) => d.category === 'YEAR_END_JOURNALS') || dataset.discoveries[0];
        setSelectedDiscovery(yeDisc);
        break;
      case 'demo3_revenue':
        const revDisc = dataset.discoveries.find((d) => d.category === 'REVENUE_MOVEMENT') || dataset.discoveries[0];
        setSelectedDiscovery(revDisc);
        break;
      case 'demo4_cash':
        setActiveTab('analysis');
        break;
      case 'demo5_suppliers':
        const suppDisc = dataset.discoveries.find((d) => d.category === 'SUPPLIER_CONCENTRATION') || dataset.discoveries[1];
        setSelectedDiscovery(suppDisc);
        break;
      case 'demo6_duplicates':
        const dupDisc = dataset.discoveries.find((d) => d.category === 'DUPLICATE_INVOICE') || dataset.discoveries[4];
        setSelectedDiscovery(dupDisc);
        break;
      default:
        setActiveTab('discover');
        break;
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0b0e14] text-slate-200 overflow-hidden select-none">
      {/* Universal Top Navigation */}
      <TopBar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          if (tab !== 'investigations') setSelectedDiscovery(null);
        }}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenCopilot={() => setIsCopilotOpen(true)}
        onOpenCalcExplorer={() => handleOpenCalcExplorer('december_revenue')}
        organisationName={dataset.organisation.name}
      />

      {/* Main Content Workspace */}
      <main className="flex-1 flex overflow-hidden">
        {selectedDiscovery ? (
          <InvestigationWorkbench
            discovery={selectedDiscovery}
            dataset={dataset}
            onBack={() => setSelectedDiscovery(null)}
            onOpenCalcExplorer={handleOpenCalcExplorer}
          />
        ) : (
          <>
            {activeTab === 'discover' && (
              <DiscoveryFeed
                discoveries={dataset.discoveries}
                onSelectDiscovery={handleSelectDiscovery}
                onRunSignatureDemo={handleRunSignatureDemo}
                organisationName={dataset.organisation.name}
              />
            )}

            {activeTab === 'ledger' && (
              <LedgerExplorer dataset={dataset} onOpenCalcExplorer={handleOpenCalcExplorer} />
            )}

            {activeTab === 'statements' && <FinancialStatementsView dataset={dataset} />}

            {activeTab === 'analysis' && <AnalysisWorkstation dataset={dataset} />}

            {activeTab === 'graph' && <RelationshipGraphView />}

            {activeTab === 'investigations' && (
              <DiscoveryFeed
                discoveries={dataset.discoveries}
                onSelectDiscovery={handleSelectDiscovery}
                onRunSignatureDemo={handleRunSignatureDemo}
                organisationName={dataset.organisation.name}
              />
            )}

            {activeTab === 'timemachine' && <LedgerTimeMachine />}

            {activeTab === 'data' && (
              <div className="flex-1 p-6 font-mono text-xs space-y-4">
                <div className="p-4 bg-[#131722] border border-[#21262d] rounded-lg flex justify-between items-center">
                  <div>
                    <h3 className="font-bold text-slate-100 text-sm">DATA SOURCES & INGESTION</h3>
                    <p className="text-slate-400 font-sans">Active dataset: {dataset.organisation.name}</p>
                  </div>
                  <button
                    onClick={() => setIsImportOpen(true)}
                    className="px-4 py-2 bg-amber-500 text-[#0d1117] font-bold rounded hover:bg-amber-400 transition-colors"
                  >
                    IMPORT NEW DATASET
                  </button>
                </div>

                <div className="p-4 bg-[#131722] border border-[#21262d] rounded-lg space-y-2">
                  <div className="font-bold text-amber-400">PROVENANCE LOGS</div>
                  <div className="text-slate-300">1,248,392 financial facts mapped to canonical accounting model.</div>
                  <div className="text-slate-500 text-[10px]">Source Systems: SAP S/4HANA, Xero, Manual Journal Entry Portal.</div>
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* Global Modals */}
      <AccountingSearchInput
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        dataset={dataset}
        onSelectDiscovery={(id) => {
          const disc = dataset.discoveries.find((d) => d.id === id);
          if (disc) setSelectedDiscovery(disc);
        }}
      />

      <CalculationExplorerModal
        isOpen={isCalcExplorerOpen}
        onClose={() => setIsCalcExplorerOpen(false)}
        metricId={calcMetricId}
      />

      <AccountantCopilotModal
        isOpen={isCopilotOpen}
        onClose={() => setIsCopilotOpen(false)}
      />

      <DataImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        onDatasetImported={(name) => {
          dataset.organisation.name = name;
          setDataset({ ...dataset });
        }}
      />
    </div>
  );
}
