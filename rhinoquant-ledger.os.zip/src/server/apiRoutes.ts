/**
 * Express REST API Routes for RhinoQuant Ledger.OS
 */

import { Router, Request, Response } from 'express';
import { generateRhinoDemoDataset, SyntheticDataset } from '../data/simulator';
import { parseAndExecuteAccountingQuery } from '../engine/searchParser';
import { getCalculationLineage } from '../engine/calculationExplorer';
import { handleCopilotRequest } from './copilotHandler';
import { InvestigationCase, AccountantNote } from '../types/investigation';

// Active in-memory state initialized with RHINO DEMO HOLDINGS PLC
let currentDataset: SyntheticDataset = generateRhinoDemoDataset();

const casesStore: Map<string, InvestigationCase> = new Map();

// Populate initial investigation cases from discoveries
currentDataset.discoveries.forEach((d) => {
  casesStore.set(`case-${d.id}`, {
    id: `case-${d.id}`,
    caseNumber: `INV-2026-${d.code.slice(-3)}`,
    discoveryId: d.id,
    discovery: d,
    title: d.title,
    assignedRole: 'FORENSIC_ACCOUNTANT',
    assignedUser: 'Tom (Lead Auditor)',
    status: d.explanationState,
    evidence: [
      {
        id: `ev-${d.id}-1`,
        type: 'JOURNAL',
        title: `Primary Evidence Record: ${d.title}`,
        referenceCode: d.relatedJournalIds?.[0] || d.relatedAccountCodes[0],
        amount: d.impactAmount,
        currency: d.currency,
        date: d.dateDetected,
        details: {
          accountCodes: d.relatedAccountCodes,
          period: d.periodName,
          reasons: d.detailedReasoning,
        },
        sourceFile: 'sales_ledger_2026_M12.csv',
      },
    ],
    notes: [
      {
        id: `note-${d.id}-1`,
        timestamp: new Date().toISOString(),
        authorName: 'Tom (Lead Auditor)',
        authorRole: 'FORENSIC_ACCOUNTANT',
        content: `Initial case opened from Discovery Engine flag. Reviewing supporting contract milestones and user posting logs.`,
      },
    ],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isBookmarked: false,
  });
});

export const apiRouter = Router();

// Health Check
apiRouter.get('/health', (req: Request, res: Response) => {
  res.json({
    status: 'HEALTHY',
    version: '2.6.0-prod',
    dataset: currentDataset.organisation.name,
    totalTransactions: currentDataset.journalLines.length,
    activeDiscoveries: currentDataset.discoveries.length,
    timestamp: new Date().toISOString(),
  });
});

// Import Dataset
apiRouter.post('/datasets/import', (req: Request, res: Response) => {
  const { datasetName, rows } = req.body;
  if (datasetName) {
    currentDataset.organisation.name = datasetName;
  }
  res.json({
    success: true,
    message: `Imported ${rows ? rows.length : 1420} transactions into ${currentDataset.organisation.name}.`,
    dataset: currentDataset.organisation,
  });
});

// Accounts
apiRouter.get('/accounts', (req: Request, res: Response) => {
  res.json({
    count: currentDataset.accounts.length,
    accounts: currentDataset.accounts,
  });
});

apiRouter.get('/accounts/:id', (req: Request, res: Response) => {
  const acc = currentDataset.accounts.find((a) => a.id === req.params.id || a.code === req.params.id);
  if (!acc) return res.status(404).json({ error: 'Account not found' });
  res.json(acc);
});

apiRouter.get('/accounts/:id/movements', (req: Request, res: Response) => {
  const accCode = req.params.id;
  const lines = currentDataset.journalLines.filter((l) => l.accountCode === accCode || l.accountId === accCode);
  const totalDebit = lines.reduce((a, b) => a + b.debit, 0);
  const totalCredit = lines.reduce((a, b) => a + b.credit, 0);

  res.json({
    accountCode: accCode,
    lineCount: lines.length,
    totalDebit,
    totalCredit,
    netMovement: totalDebit - totalCredit,
    lines: lines.slice(0, 100),
  });
});

// Journals & Transactions
apiRouter.get('/journals', (req: Request, res: Response) => {
  res.json({
    count: currentDataset.journals.length,
    journals: currentDataset.journals.slice(0, 100),
  });
});

apiRouter.get('/transactions', (req: Request, res: Response) => {
  res.json({
    count: currentDataset.journalLines.length,
    transactions: currentDataset.journalLines.slice(0, 200),
  });
});

// Discovery Engine Endpoints
apiRouter.post('/discovery/search', (req: Request, res: Response) => {
  const { query } = req.body;
  const result = parseAndExecuteAccountingQuery(query || '', currentDataset);
  res.json(result);
});

apiRouter.get('/discovery/interesting', (req: Request, res: Response) => {
  const mode = (req.query.mode as string) || 'MATERIALITY';
  res.json({
    datasetName: currentDataset.organisation.name,
    totalFactCount: currentDataset.journalLines.length,
    prioritisationMode: mode,
    discoveries: currentDataset.discoveries,
  });
});

apiRouter.get('/discovery/anomalies', (req: Request, res: Response) => {
  const anomalies = currentDataset.discoveries.filter((d) => d.dimensions.magnitude === 'CRITICAL' || d.dimensions.deviation === 'CRITICAL');
  res.json({ anomalies });
});

apiRouter.get('/discovery/concentrations', (req: Request, res: Response) => {
  const concentrations = currentDataset.discoveries.filter((d) => d.category === 'SUPPLIER_CONCENTRATION' || d.dimensions.concentration === 'CRITICAL');
  res.json({ concentrations });
});

apiRouter.get('/discovery/relationships', (req: Request, res: Response) => {
  res.json({
    nodes: [
      { id: 'ent-1', label: 'Rhino UK Operating Ltd', type: 'COMPANY' },
      { id: 'acc-4000', label: 'Account 4000 (Revenue)', type: 'ACCOUNT' },
      { id: 'acc-1200', label: 'Account 1200 (Receivables)', type: 'ACCOUNT' },
      { id: 'acc-2100', label: 'Account 2100 (Trade AP)', type: 'ACCOUNT' },
      { id: 'cp-c01', label: 'Apex Global Corp', type: 'CUSTOMER' },
      { id: 'cp-c02', label: 'Vanguard Logistics', type: 'CUSTOMER' },
      { id: 'cp-s01', label: 'Titanium Components Ltd', type: 'SUPPLIER' },
      { id: 'user-jsmith', label: 'User J_SMITH', type: 'USER' },
    ],
    edges: [
      { source: 'user-jsmith', target: 'acc-4000', label: 'POSTED_MANUAL_JOURNAL', value: 2741829 },
      { source: 'cp-c01', target: 'acc-4000', label: 'BILLED_REVENUE', value: 1420000 },
      { source: 'cp-s01', target: 'acc-2100', label: 'SUPPLIED_INFRA', value: 1820000 },
    ],
  });
});

// Investigations
apiRouter.get('/investigations', (req: Request, res: Response) => {
  const list = Array.from(casesStore.values());
  res.json({ count: list.length, cases: list });
});

apiRouter.get('/investigations/:id', (req: Request, res: Response) => {
  const c = casesStore.get(req.params.id) || Array.from(casesStore.values()).find((item) => item.discoveryId === req.params.id || item.caseNumber === req.params.id);
  if (!c) return res.status(404).json({ error: 'Case not found' });
  res.json(c);
});

apiRouter.patch('/investigations/:id', (req: Request, res: Response) => {
  const c = casesStore.get(req.params.id) || Array.from(casesStore.values()).find((item) => item.discoveryId === req.params.id || item.caseNumber === req.params.id);
  if (!c) return res.status(404).json({ error: 'Case not found' });

  const { status, noteText, isBookmarked } = req.body;
  if (status) {
    c.status = status;
    c.discovery.explanationState = status;
  }
  if (typeof isBookmarked === 'boolean') {
    c.isBookmarked = isBookmarked;
  }
  if (noteText) {
    const newNote: AccountantNote = {
      id: `note-${Date.now()}`,
      timestamp: new Date().toISOString(),
      authorName: 'Tom (Lead Auditor)',
      authorRole: 'FORENSIC_ACCOUNTANT',
      content: noteText,
    };
    c.notes.push(newNote);
  }
  c.updatedAt = new Date().toISOString();
  casesStore.set(c.id, c);

  res.json(c);
});

// Calculation Explorer
apiRouter.get('/calculations/:id', (req: Request, res: Response) => {
  const lineage = getCalculationLineage(req.params.id, currentDataset);
  res.json(lineage);
});

apiRouter.get('/provenance/:id', (req: Request, res: Response) => {
  const lineage = getCalculationLineage(req.params.id, currentDataset);
  res.json(lineage);
});

// XBRL Taxonomies & Reconciliations
apiRouter.get('/taxonomies', (req: Request, res: Response) => {
  res.json({
    facts: currentDataset.xbrlFacts,
    reconciliationChecks: currentDataset.reconciliationChecks,
  });
});

// Copilot
apiRouter.post('/copilot/ask', async (req: Request, res: Response) => {
  const { prompt } = req.body;
  const result = await handleCopilotRequest(prompt || 'What is interesting in this dataset?', currentDataset);
  res.json(result);
});
