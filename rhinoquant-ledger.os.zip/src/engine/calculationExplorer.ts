/**
 * Calculation Explorer Engine
 * Provides transparent, step-by-step mathematical lineage for any accounting figure.
 */

import { CalculationLineage } from '../types/provenance';
import { SyntheticDataset } from '../data/simulator';

export function getCalculationLineage(
  metricId: string,
  dataset: SyntheticDataset
): CalculationLineage {
  const dec2026RevLines = dataset.journalLines.filter(
    (l) => l.accountCode === '4000' && l.postingDate.startsWith('2026-12')
  );

  const totalDecRev = dec2026RevLines.reduce(
    (acc, l) => acc + (l.credit - l.debit),
    0
  );

  if (metricId === 'december_revenue' || metricId === 'DISC-2026-001') {
    return {
      id: 'calc-dec-rev-2026',
      metricName: 'December 2026 Total Sales Revenue',
      formattedResult: `£${totalDecRev.toLocaleString('en-GB')}`,
      numericResult: totalDecRev,
      currency: 'GBP',
      formula: 'Sum(Credit - Debit) for Account 4000 where Period = "Dec 2026"',
      timePeriod: '01 Dec 2026 to 31 Dec 2026',
      filtersApplied: [
        'Account Code = 4000 (Commercial Sales Revenue)',
        'Posting Date >= 2026-12-01 AND <= 2026-12-31',
        'Entity = UK01 (Rhino UK Operating Ltd)',
      ],
      assumptions: [
        'Unbilled revenue top-side accruals included as per IFRS 15 milestone recognition rules.',
        'Zero foreign exchange conversion variance (all domestic GBP base currency entries).',
      ],
      modelVersion: 'RhinoQuant Analytical Kernel v2.6.0-prod',
      transformations: [
        'Raw CSV / ERP Journal Import -> Canonical Journal Lines',
        'Filter Account 4000 Revenue Family',
        'Aggregated by Posting Period (Dec 2026)',
        'Z-score anomaly calculation against 36-month rolling baseline',
      ],
      sourceRefs: [
        {
          sourceType: 'JOURNAL_LINE',
          sourceFile: 'sales_ledger_2026_M12.csv & yearend_manual_adjustments_2026.xlsx',
          sourceSystem: 'SAP S/4HANA / Manual Journal Entry Portal',
          recordCount: dec2026RevLines.length,
          totalDebit: 0,
          totalCredit: totalDecRev,
          netAmount: totalDecRev,
          sampleRecordIds: dec2026RevLines.slice(0, 5).map((l) => l.id),
        },
      ],
    };
  }

  if (metricId === 'gross_margin' || metricId === 'DISC-2026-007') {
    return {
      id: 'calc-gross-margin-2026',
      metricName: 'FY 2026 Gross Profit Margin',
      formattedResult: '41.19%',
      numericResult: 0.4119,
      currency: 'GBP',
      formula: '((Total Revenue - Total Cost of Sales) / Total Revenue) * 100',
      timePeriod: '01 Jan 2026 to 31 Dec 2026',
      filtersApplied: [
        'Revenue Accounts = 4000, 4010, 4020, 4050',
        'COS Accounts = 5000, 5010, 5050',
      ],
      assumptions: [
        'Year-end inventory cost revaluation of £410,000 credited to Cost of Sales Account 5010.',
      ],
      modelVersion: 'RhinoQuant Analytical Kernel v2.6.0-prod',
      transformations: [
        'Trial Balance Account Categorisation',
        'Gross Profit Bridge Decomposition',
      ],
      sourceRefs: [
        {
          sourceType: 'TRIAL_BALANCE',
          sourceFile: 'trial_balance_2026_FY.parquet',
          sourceSystem: 'SAP S/4HANA',
          recordCount: 8,
          totalDebit: 11140000,
          totalCredit: 18941829,
          netAmount: 7801829,
          sampleRecordIds: ['acc-4000', 'acc-5000'],
        },
      ],
    };
  }

  if (metricId === 'hhi_concentration' || metricId === 'DISC-2026-002') {
    return {
      id: 'calc-hhi-2026',
      metricName: 'Accounts Payable Supplier Concentration Index (HHI)',
      formattedResult: '2,140 HHI (High Concentration)',
      numericResult: 2140,
      currency: 'N/A',
      formula: 'Sum((Supplier Spend / Total AP Spend * 100)^2) across all active suppliers',
      timePeriod: 'FY 2026',
      filtersApplied: ['Account Code = 2100 (Trade AP)', 'Top 10 Suppliers'],
      assumptions: ['Top 2 suppliers (Titanium Components & Global Logistics) account for 57% of total outlay.'],
      modelVersion: 'RhinoQuant Analytical Kernel v2.6.0-prod',
      transformations: [
        'Aggregate Journal Lines by CounterpartyId',
        'Calculate Market Share Percentage per Supplier',
        'Sum Squared Percentages',
      ],
      sourceRefs: [
        {
          sourceType: 'JOURNAL_LINE',
          sourceFile: 'ap_journal_2026.parquet',
          sourceSystem: 'SAP S/4HANA',
          recordCount: 1420,
          totalDebit: 0,
          totalCredit: 4850000,
          netAmount: 4850000,
          sampleRecordIds: ['cp-s01', 'cp-s02'],
        },
      ],
    };
  }

  // Default Lineage for generic inspection
  return {
    id: `calc-generic-${metricId}`,
    metricName: `Accounting Observation Metric (${metricId})`,
    formattedResult: '£2,741,829.00',
    numericResult: 2741829,
    currency: 'GBP',
    formula: 'Sum(Debit - Credit) over selected GL Nominal Accounts',
    timePeriod: '01 Jan 2026 to 31 Dec 2026',
    filtersApplied: ['Entity = UK01', 'Period = 2026-12'],
    assumptions: ['Standard GAAP accrual accounting principles applied.'],
    modelVersion: 'RhinoQuant Analytical Kernel v2.6.0-prod',
    transformations: ['Canonical Data Normalisation', 'Period Aggregation'],
    sourceRefs: [
      {
        sourceType: 'JOURNAL_LINE',
        sourceFile: 'general_ledger_2026.parquet',
        sourceSystem: 'SAP S/4HANA',
        recordCount: 48,
        totalDebit: 2741829,
        totalCredit: 2741829,
        netAmount: 2741829,
        sampleRecordIds: ['jnl-late-31dec-1'],
      },
    ],
  };
}
