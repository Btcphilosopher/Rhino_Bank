/**
 * Accounting Search Engine & Query Parser
 * Deterministic query parser converting natural language queries into structured AccountingQuery
 * and executing against the dataset.
 */

import { AccountingQuery } from '../types/query';
import { SyntheticDataset } from '../data/simulator';
import { JournalLine, Journal } from '../types/accounting';
import { DiscoveryItem } from '../types/discovery';

export interface QueryExecutionResult {
  parsedQuery: AccountingQuery;
  matchingDiscoveries: DiscoveryItem[];
  matchingJournals: Journal[];
  matchingLines: JournalLine[];
  summaryText: string;
}

export function parseAndExecuteAccountingQuery(
  rawInput: string,
  dataset: SyntheticDataset
): QueryExecutionResult {
  const query = parseQueryText(rawInput);

  let filteredDiscoveries: DiscoveryItem[] = [...dataset.discoveries];
  let filteredJournals: Journal[] = [...dataset.journals];
  let filteredLines: JournalLine[] = [...dataset.journalLines];

  switch (query.intent) {
    case 'UNUSUAL_EXPENSES':
      filteredDiscoveries = dataset.discoveries.filter(
        (d) => d.category === 'EXPENSE_RECLASSIFICATION' || d.category === 'DUPLICATE_INVOICE' || d.category === 'SUPPLIER_CONCENTRATION'
      );
      filteredLines = dataset.journalLines.filter(
        (l) => (l.accountCategory === 'OPERATING_EXPENSE' || l.accountCategory === 'COST_OF_SALES') && l.amount > 50000
      );
      break;

    case 'YEAR_END_JOURNALS':
      filteredDiscoveries = dataset.discoveries.filter(
        (d) => d.category === 'YEAR_END_JOURNALS' || d.category === 'REVENUE_MOVEMENT'
      );
      filteredJournals = dataset.journals.filter(
        (j) => j.postingDate === '2026-12-31' && j.journalType === 'MANUAL'
      );
      filteredLines = dataset.journalLines.filter(
        (l) => l.postingDate === '2026-12-31'
      );
      break;

    case 'UNUSUAL_REVENUE':
    case 'CUSTOMER_EXPLANATION':
      filteredDiscoveries = dataset.discoveries.filter(
        (d) => d.category === 'REVENUE_MOVEMENT' || d.category === 'RECEIVABLES_DETERIORATION'
      );
      filteredLines = dataset.journalLines.filter(
        (l) => l.accountCode === '4000' && l.postingDate.startsWith('2026-12')
      );
      break;

    case 'SUPPLIER_CONCENTRATION':
      filteredDiscoveries = dataset.discoveries.filter(
        (d) => d.category === 'SUPPLIER_CONCENTRATION' || d.category === 'DUPLICATE_INVOICE'
      );
      filteredLines = dataset.journalLines.filter(
        (l) => l.counterpartyType === 'SUPPLIER'
      );
      break;

    case 'DUPLICATE_INVOICES':
      filteredDiscoveries = dataset.discoveries.filter(
        (d) => d.category === 'DUPLICATE_INVOICE'
      );
      filteredLines = dataset.journalLines.filter((l) =>
        l.description.toLowerCase().includes('duplicate') || l.description.toLowerCase().includes('abc')
      );
      break;

    case 'LARGE_TRANSACTIONS':
      const threshold = query.thresholdAmount || 100000;
      filteredLines = dataset.journalLines.filter(
        (l) => Math.abs(l.amount) >= threshold
      );
      filteredJournals = dataset.journals.filter(
        (j) => j.totalDebit >= threshold
      );
      break;

    default:
      // Generic search over description, account, counterparty
      const searchLower = rawInput.toLowerCase().trim();
      if (searchLower.length > 0) {
        filteredDiscoveries = dataset.discoveries.filter((d) =>
          d.title.toLowerCase().includes(searchLower) ||
          d.summary.toLowerCase().includes(searchLower)
        );
        filteredLines = dataset.journalLines.filter((l) =>
          l.description.toLowerCase().includes(searchLower) ||
          l.accountName.toLowerCase().includes(searchLower) ||
          (l.counterpartyName && l.counterpartyName.toLowerCase().includes(searchLower))
        );
      }
      break;
  }

  const summaryText = buildSummaryText(query, filteredDiscoveries, filteredLines);

  return {
    parsedQuery: query,
    matchingDiscoveries: filteredDiscoveries,
    matchingJournals: filteredJournals.slice(0, 20),
    matchingLines: filteredLines.slice(0, 50),
    summaryText,
  };
}

function parseQueryText(rawInput: string): AccountingQuery {
  const input = rawInput.toLowerCase();

  if (input.includes('year-end') || input.includes('31 dec') || input.includes('year end')) {
    return {
      rawInput,
      intent: 'YEAR_END_JOURNALS',
      periodName: 'Dec 2026',
      anomalyMethod: 'ACCOUNTING_TIMING',
      materialityFilter: 'HIGH_ONLY',
    };
  }

  if (input.includes('revenue') || input.includes('customer')) {
    return {
      rawInput,
      intent: 'UNUSUAL_REVENUE',
      accountGroup: 'Core Revenue',
      anomalyMethod: 'Z_SCORE',
    };
  }

  if (input.includes('supplier') || input.includes('concentration')) {
    return {
      rawInput,
      intent: 'SUPPLIER_CONCENTRATION',
      accountGroup: 'Payables',
    };
  }

  if (input.includes('duplicate') || input.includes('copy')) {
    return {
      rawInput,
      intent: 'DUPLICATE_INVOICES',
    };
  }

  if (input.includes('expense') || input.includes('cost')) {
    return {
      rawInput,
      intent: 'UNUSUAL_EXPENSES',
      accountGroup: 'Operating Expenses',
    };
  }

  if (input.includes('100,000') || input.includes('large') || input.includes('100k')) {
    return {
      rawInput,
      intent: 'LARGE_TRANSACTIONS',
      thresholdAmount: 100000,
    };
  }

  return {
    rawInput,
    intent: 'CUSTOM_FILTER',
  };
}

function buildSummaryText(
  query: AccountingQuery,
  discoveries: DiscoveryItem[],
  lines: JournalLine[]
): string {
  if (discoveries.length > 0) {
    return `Query "${query.rawInput}" resolved to intent [${query.intent}]. Found ${discoveries.length} key accounting research discovery candidates and ${lines.length} matching journal lines.`;
  }
  return `Query "${query.rawInput}" executed against General Ledger. Displaying ${lines.length} relevant financial transaction lines.`;
}
