# RhinoQuant Collateral Management Platform

Institutional-grade collateral management, margin, secured funding, and collateral optimisation platform for banks, broker-dealers, hedge funds, clearing members, and asset managers.

## 1. System Architecture

```
rhinoquant-collateral/
├── src/
│   ├── engines/
│   │   ├── valuationEngine.ts         # Dirty prices, accrued interest, FX, haircut ladders
│   │   ├── eligibilityEngine.ts       # Versioned rule evaluations, whitelists, maturity caps
│   │   ├── marginEngine.ts            # ISDA netting, thresholding, MTA, rounding, idempotency
│   │   ├── optimisationEngine.ts      # Multi-agreement constrained mathematical allocation solver
│   │   ├── repoEngine.ts              # Secured funding, ACT/360 accruals, two-leg substitutions
│   │   ├── scenarioEngine.ts          # Deterministic multi-factor stress test simulator
│   │   └── reconciliationEngine.ts    # Custody statement matching & exception queue
│   ├── context/
│   │   └── CollateralContext.tsx      # Reactive store with strict double-pledge prevention
│   ├── data/
│   │   └── syntheticMasterData.ts     # Realistic multi-currency institutional test seed data
│   ├── tests/
│   │   └── financialTestSuite.ts      # Automated runner for 15 mandatory financial test cases
│   └── components/
│       ├── layout/                    # Institutional TopBar (3-Zone contract) & WorkspaceNav
│       ├── overview/                  # Collateral Overview & global KPIs
│       ├── inventory/                 # Inventory & Asset Master with valuation inspector
│       ├── margin/                    # Margin Calls lifecycle queue & calculation trace
│       ├── optimisation/              # Mathematical allocation workbench & approval workflow
│       ├── repo/                      # Repo desk, day-count interest, two-leg substitution
│       ├── risk/                      # Stress testing with yield, spread, equity & FX shocks
│       ├── reconciliation/            # Custody reconciliation vs Euroclear, DTCC, Clearstream
│       ├── agreements/                # Governing CSAs, GMRAs, and live eligibility simulator
│       ├── audit/                     # Immutable append-only audit trail with state diffs
│       ├── tests/                     # Interactive verification suite for 15 quantitative tests
│       └── docs/                      # Methodology formulas, conventions, and REST API contract
```

## 2. Quantitative Financial Engine

- **Valuation Conventions**: Bond clean prices + accrued interest = dirty price. Day count conventions (`ACT/ACT`, `ACT/360`, `ACT/365`, `30/360`) evaluated against issue and last coupon dates.
- **Regulatory Haircuts**: Basel/BCBS-IOSCO schedules + mandatory 800 bps currency mismatch surcharge + 500 bps single-issuer concentration add-ons.
- **Margin Netting Sequence**: Total Obligation $\rightarrow$ Net Collateral Held $\rightarrow$ Gross Shortfall $\rightarrow$ Contractual Threshold $\rightarrow$ Minimum Transfer Amount (MTA suppression) $\rightarrow$ Rounding Increment $\rightarrow$ Required Transfer.
- **Constrained Optimization**: Linear/mixed-integer solver minimizing funding drag while strictly respecting inventory availability (preventing double pledging), concentration limits, and minimum lot sizes.
- **Controlled Two-Leg Substitution**: Validates Leg 1 (replacement asset eligibility, availability, and haircut coverage) before permitting Leg 2 (release of original collateral).
- **Audit & Governance**: Immutable audit trail recording actor, timestamp, previous state, new state, operational rationale, and SHA-256 hash.

## 3. Mandatory Financial Test Cases Verified

1. Eligible Cash Collateral Valuation (0% domestic haircut, 100% recognised).
2. Bond Accrued Interest & Haircut Schedule (clean + accrued = dirty price).
3. Currency Mismatch Regulatory Surcharge (+8.0% FX add-on).
4. Ineligible Security Rejection (sub-investment grade excluded from AA CSA).
5. Concentration Limit Breach Surcharge (+500 bps on >20% issuer share).
6. Sub-MTA Margin Call Suppression ($150k shortfall suppressed below $250k MTA).
7. Contractual Rounding Increment (rounds to nearest $25k multiple).
8. Partial Collateral Delivery & Ledger Invariant.
9. Margin Call Idempotency Protection (duplicate call prevention).
10. Multi-Agreement Allocation Invariant (zero double pledging).
11. Two-Leg Substitution Ineligibility Guard.
12. Settlement Variance & Custody Reconciliation (flags Euroclear discrepancy).
13. Historical Calculation Audit Immutability.
14. Compound Stress Test & Liquidity Shortfall.
15. Repo Day-Count Interest Accrual (ACT/360 interest formula validation).
