/**
 * RhinoQuant Collateral Management Platform
 * Central State Store & Transactional Invariant Coordinator
 */

import React, { createContext, useContext, useState, useMemo, useCallback } from 'react';
import { 
  AssetMaster, 
  InventoryPosition, 
  CollateralAgreement, 
  Counterparty, 
  MarketDataSnapshot, 
  MarginCall, 
  RepoTrade, 
  ReconciliationRecord, 
  SettlementInstruction, 
  AuditEvent, 
  OptimizationRun, 
  StressScenario, 
  StressScenarioResult,
  MarginCallStatus
} from '../types/models';
import { 
  INITIAL_ASSETS, 
  INITIAL_MARKET_DATA, 
  INITIAL_AGREEMENTS, 
  INITIAL_COUNTERPARTIES, 
  INITIAL_INVENTORY, 
  INITIAL_MARGIN_CALLS, 
  INITIAL_REPO_TRADES, 
  EXTERNAL_CUSTODY_STATEMENTS 
} from '../data/syntheticMasterData';
import { calculateValuation } from '../engines/valuationEngine';
import { calculateMarginCall, validateMarginCallTransition } from '../engines/marginEngine';
import { runCollateralOptimisation } from '../engines/optimisationEngine';
import { validateCollateralSubstitution, evaluateRepoPosition } from '../engines/repoEngine';
import { PRESET_SCENARIOS, runStressScenario } from '../engines/scenarioEngine';
import { performCustodyReconciliation } from '../engines/reconciliationEngine';

export type UserRole = 'VIEWER' | 'COLLATERAL_OPERATOR' | 'RISK_ANALYST' | 'APPROVER' | 'AUDITOR' | 'ADMIN';

interface CollateralContextType {
  // Data
  counterparties: Counterparty[];
  assets: AssetMaster[];
  marketData: Record<string, MarketDataSnapshot>;
  agreements: CollateralAgreement[];
  inventory: InventoryPosition[];
  marginCalls: MarginCall[];
  repoTrades: RepoTrade[];
  reconciliationRecords: ReconciliationRecord[];
  settlementInstructions: SettlementInstruction[];
  auditEvents: AuditEvent[];
  activeOptimizationRun: OptimizationRun | null;
  activeStressResult: StressScenarioResult | null;
  currentScenario: StressScenario;
  userRole: UserRole;
  
  // Computed portfolio metrics
  totalInventoryDirtyUSD: number;
  totalRecognisedCollateralUSD: number;
  totalPledgedUSD: number;
  totalFreeCollateralUSD: number;
  haircutDragUSD: number;
  openMarginCallsCount: number;
  totalOpenMarginCallsUSD: number;
  unsettledTransfersCount: number;
  openExceptionsCount: number;

  // Actions
  setUserRole: (role: UserRole) => void;
  updateMarginCallStatus: (callId: string, newStatus: MarginCallStatus, disputeReason?: string, disputeAmount?: number) => { success: boolean; message: string };
  runNewMarginCalculation: (agreementId: string, currentExposureUSD: number, imRequirementUSD: number, vmRequirementUSD: number) => MarginCall;
  runOptimisationSolver: (targetAgreementIds: string[], objective: 'MINIMIZE_FUNDING_COST' | 'PRESERVE_LIQUIDITY' | 'MINIMIZE_FX_FRICTION') => OptimizationRun;
  approveOptimisationPlan: (runId: string) => { success: boolean; message: string };
  executeSubstitution: (tradeId: string, replacementAssetId: string, quantity: number) => { success: boolean; message: string };
  selectAndRunStressScenario: (scenario: StressScenario) => void;
  resolveException: (recordId: string, resolutionNotes: string) => void;
  runPortfolioEODCycle: () => void;
  addPositionPledgeAdjustment: (positionId: string, newPledgedQty: number, rationale: string) => { success: boolean; message: string };
  freezePositionDispute: (positionId: string, frozenAmount: number, reason: string) => { success: boolean; message: string };
  updateAgreementSchedule: (agreementId: string, updates: Partial<CollateralAgreement>) => void;
  resetToInitialDemoState: () => void;
}

const CollateralContext = createContext<CollateralContextType | undefined>(undefined);

export const CollateralProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [counterparties, setCounterparties] = useState<Counterparty[]>(INITIAL_COUNTERPARTIES);
  const [assets, setAssets] = useState<AssetMaster[]>(INITIAL_ASSETS);
  const [marketData, setMarketData] = useState<Record<string, MarketDataSnapshot>>(INITIAL_MARKET_DATA);
  const [agreements, setAgreements] = useState<CollateralAgreement[]>(INITIAL_AGREEMENTS);
  const [inventory, setInventory] = useState<InventoryPosition[]>(INITIAL_INVENTORY);
  const [marginCalls, setMarginCalls] = useState<MarginCall[]>(INITIAL_MARGIN_CALLS);
  const [repoTrades, setRepoTrades] = useState<RepoTrade[]>(INITIAL_REPO_TRADES);
  const [settlementInstructions, setSettlementInstructions] = useState<SettlementInstruction[]>([
    {
      id: 'SETTLE-INIT-001',
      instructionRef: 'SWIFT-MT542-992014',
      marginCallId: 'MC-20261024-003',
      direction: 'FREE_OF_PAYMENT_DELIVERY',
      assetId: 'AST-UST-10Y',
      quantity: 400000,
      currency: 'USD',
      custodian: 'DTCC',
      counterpartyId: 'CP-CITADEL',
      counterpartyBic: 'CITDGB22',
      intendedSettlementDate: '2026-10-25',
      status: 'TRANSMITTED',
      createdTimestamp: '2026-10-24T08:25:00Z'
    }
  ]);
  const [auditEvents, setAuditEvents] = useState<AuditEvent[]>([
    {
      id: 'AUD-INIT-001',
      timestamp: '2026-10-24T06:00:00Z',
      actor: 'system.rhino.eod',
      action: 'INITIALIZE_INVENTORY_SNAPSHOT',
      entityType: 'INVENTORY',
      entityId: 'PORTFOLIO_ALL',
      rationale: 'Daily opening valuation snapshot and position lock',
      hash: 'sha256:4a8b79e2c109dfb3...'
    },
    {
      id: 'AUD-INIT-002',
      timestamp: '2026-10-24T07:15:00Z',
      actor: 'm.vance (Collateral Ops)',
      action: 'MARGIN_CALL_ISSUED',
      entityType: 'MARGIN_CALL',
      entityId: 'MC-20261024-001',
      rationale: 'Daily VM call issued to BNP Paribas Arbitrage ($2,450,000)',
      hash: 'sha256:9f7a18b2c4510ea4...'
    }
  ]);
  const [activeOptimizationRun, setActiveOptimizationRun] = useState<OptimizationRun | null>(null);
  const [currentScenario, setCurrentScenario] = useState<StressScenario>(PRESET_SCENARIOS[4]);
  const [activeStressResult, setActiveStressResult] = useState<StressScenarioResult | null>(null);
  const [userRole, setUserRole] = useState<UserRole>('COLLATERAL_OPERATOR');

  // Initial reconciliation records
  const [reconciliationRecords, setReconciliationRecords] = useState<ReconciliationRecord[]>(() => 
    performCustodyReconciliation(INITIAL_INVENTORY, INITIAL_ASSETS, INITIAL_MARKET_DATA, EXTERNAL_CUSTODY_STATEMENTS)
  );

  const logAudit = useCallback((
    action: string,
    entityType: AuditEvent['entityType'],
    entityId: string,
    rationale: string,
    previousState?: any,
    newState?: any
  ) => {
    const event: AuditEvent = {
      id: `AUD-${Date.now().toString(36).toUpperCase()}-${Math.floor(Math.random() * 900 + 100)}`,
      timestamp: new Date().toISOString(),
      actor: `${userRole.toLowerCase()}@rhinobank.com`,
      action,
      entityType,
      entityId,
      previousState,
      newState,
      rationale,
      hash: `sha256:${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`
    };
    setAuditEvents(prev => [event, ...prev]);
  }, [userRole]);

  // Computed portfolio metrics
  const {
    totalInventoryDirtyUSD,
    totalRecognisedCollateralUSD,
    totalPledgedUSD,
    totalFreeCollateralUSD,
    haircutDragUSD
  } = useMemo(() => {
    const assetMap = new Map(assets.map(a => [a.id, a]));
    let totalDirty = 0;
    let totalRecognised = 0;
    let totalPledged = 0;
    let totalFree = 0;

    for (const pos of inventory) {
      const asset = assetMap.get(pos.assetId);
      if (!asset) continue;
      const mkt = marketData[asset.id];
      if (!mkt) continue;

      const fullVal = calculateValuation(pos.id, asset, mkt, pos.totalQuantity);
      totalDirty += fullVal.dirtyMarketValueUSD;
      totalRecognised += fullVal.recognisedCollateralValueUSD;

      const pledgedVal = calculateValuation(pos.id, asset, mkt, pos.pledgedQuantity);
      totalPledged += pledgedVal.recognisedCollateralValueUSD;

      const freeQty = Math.max(0, pos.totalQuantity - pos.pledgedQuantity - pos.pendingDeliveryQuantity - pos.frozenDisputedQuantity);
      const freeVal = calculateValuation(pos.id, asset, mkt, freeQty);
      totalFree += freeVal.recognisedCollateralValueUSD;
    }

    return {
      totalInventoryDirtyUSD: totalDirty,
      totalRecognisedCollateralUSD: totalRecognised,
      totalPledgedUSD: totalPledged,
      totalFreeCollateralUSD: totalFree,
      haircutDragUSD: Math.max(0, totalDirty - totalRecognised)
    };
  }, [assets, inventory, marketData]);

  const openMarginCallsCount = useMemo(() => {
    return marginCalls.filter(c => c.status !== 'SETTLED' && c.status !== 'CANCELLED').length;
  }, [marginCalls]);

  const totalOpenMarginCallsUSD = useMemo(() => {
    return marginCalls
      .filter(c => c.status !== 'SETTLED' && c.status !== 'CANCELLED')
      .reduce((sum, c) => sum + (c.direction === 'DELIVER_COLLATERAL' ? c.requiredTransferAmountUSD : 0), 0);
  }, [marginCalls]);

  const unsettledTransfersCount = useMemo(() => {
    return settlementInstructions.filter(s => s.status !== 'SETTLED' && s.status !== 'CANCELLED').length;
  }, [settlementInstructions]);

  const openExceptionsCount = useMemo(() => {
    return reconciliationRecords.filter(r => r.status === 'UNMATCHED' && r.resolutionStatus !== 'RESOLVED').length;
  }, [reconciliationRecords]);

  // Margin Call status update with transition validation and audit
  const updateMarginCallStatus = useCallback((
    callId: string, 
    newStatus: MarginCallStatus, 
    disputeReason?: string, 
    disputeAmount?: number
  ) => {
    const targetCall = marginCalls.find(c => c.id === callId);
    if (!targetCall) {
      return { success: false, message: `Margin call ${callId} not found` };
    }

    // Role checking
    if (newStatus === 'ISSUED' && userRole === 'AUDITOR') {
      return { success: false, message: 'Auditor role is read-only and cannot issue margin calls' };
    }

    const validation = validateMarginCallTransition(targetCall.status, newStatus);
    if (!validation.valid) {
      return { success: false, message: validation.reason || 'Invalid transition' };
    }

    setMarginCalls(prev => prev.map(c => {
      if (c.id === callId) {
        return {
          ...c,
          status: newStatus,
          disputeReason: disputeReason ?? c.disputeReason,
          disputeAmountUSD: disputeAmount ?? c.disputeAmountUSD,
          updatedAt: new Date().toISOString()
        };
      }
      return c;
    }));

    logAudit(
      `MARGIN_CALL_STATUS_${newStatus}`,
      'MARGIN_CALL',
      callId,
      `Margin call state transitioned from ${targetCall.status} to ${newStatus}${disputeReason ? `: ${disputeReason}` : ''}`,
      { status: targetCall.status },
      { status: newStatus }
    );

    return { success: true, message: `Margin call status updated to ${newStatus}` };
  }, [marginCalls, userRole, logAudit]);

  // Run new margin calculation
  const runNewMarginCalculation = useCallback((
    agreementId: string,
    currentExposureUSD: number,
    imRequirementUSD: number,
    vmRequirementUSD: number
  ) => {
    const agreement = agreements.find(a => a.id === agreementId);
    if (!agreement) throw new Error(`Agreement ${agreementId} not found`);

    const snapshot = {
      agreementId,
      counterpartyId: agreement.counterpartyId,
      valuationDate: new Date().toISOString(),
      currentMarkToMarketUSD: currentExposureUSD,
      initialMarginUSD: imRequirementUSD,
      variationMarginUSD: vmRequirementUSD,
      collateralHeldRecognisedUSD: 4500000,
      collateralDeliveredRecognisedUSD: 0
    };

    const { call, isDuplicate } = calculateMarginCall(snapshot, agreement, marginCalls);
    if (!isDuplicate) {
      setMarginCalls(prev => [call, ...prev]);
      logAudit(
        'CALCULATE_MARGIN_CALL',
        'MARGIN_CALL',
        call.id,
        `Calculated margin call for ${agreement.name}: Required Transfer = $${call.requiredTransferAmountUSD.toLocaleString()}`
      );
    }
    return call;
  }, [agreements, marginCalls, logAudit]);

  // Optimisation Solver
  const runOptimisationSolver = useCallback((
    targetAgreementIds: string[],
    objective: 'MINIMIZE_FUNDING_COST' | 'PRESERVE_LIQUIDITY' | 'MINIMIZE_FX_FRICTION'
  ) => {
    const targetAgreements = targetAgreementIds.map(id => {
      const ag = agreements.find(a => a.id === id)!;
      const call = marginCalls.find(c => c.agreementId === id && c.status !== 'SETTLED');
      const req = call ? call.requiredTransferAmountUSD : 3000000;
      return {
        agreement: ag,
        requiredTransferUSD: req
      };
    });

    const optResult = runCollateralOptimisation({
      targetAgreements,
      inventory,
      assets,
      marketData,
      objective
    });

    setActiveOptimizationRun(optResult);
    logAudit(
      'RUN_OPTIMISATION_SOLVER',
      'OPTIMISATION',
      optResult.id,
      `Ran mathematical solver for ${targetAgreementIds.length} agreements. Objective: ${objective}. Total allocated: $${Math.round(optResult.totalAllocatedRecognisedUSD).toLocaleString()}`
    );

    return optResult;
  }, [agreements, marginCalls, inventory, assets, marketData, logAudit]);

  // Approve optimization and create settlement instructions
  const approveOptimisationPlan = useCallback((runId: string) => {
    if (!activeOptimizationRun || activeOptimizationRun.id !== runId) {
      return { success: false, message: 'Optimization proposal not found or expired' };
    }

    if (userRole === 'VIEWER' || userRole === 'AUDITOR') {
      return { success: false, message: 'Current role lacks authorization to approve collateral allocations' };
    }

    // Step 1: Check inventory invariants
    const updatedInventory = [...inventory];
    const newInstructions: SettlementInstruction[] = [];

    for (const agAlloc of activeOptimizationRun.allocatedItems) {
      const agreement = agreements.find(a => a.id === agAlloc.agreementId);
      const cpty = counterparties.find(c => c.id === agreement?.counterpartyId);

      for (const item of agAlloc.items) {
        const posIdx = updatedInventory.findIndex(p => p.id === item.positionId);
        if (posIdx === -1) continue;

        const pos = updatedInventory[posIdx];
        const avail = pos.totalQuantity - pos.pledgedQuantity - pos.pendingDeliveryQuantity - pos.frozenDisputedQuantity;

        if (item.allocatedNominal > avail) {
          return {
            success: false,
            message: `TRANSACTION REJECTED: Position ${pos.id} cannot pledge ${item.allocatedNominal.toLocaleString()} units; available balance is ${avail.toLocaleString()}!`
          };
        }

        // Safe transactional update
        updatedInventory[posIdx] = {
          ...pos,
          pledgedQuantity: pos.pledgedQuantity + item.allocatedNominal,
          lastUpdated: new Date().toISOString()
        };

        // Create settlement instruction
        newInstructions.push({
          id: `SETTLE-OPT-${Date.now()}-${Math.floor(Math.random() * 900)}`,
          instructionRef: `SWIFT-MT542-OPT-${Math.floor(Math.random() * 900000 + 100000)}`,
          allocationId: runId,
          direction: 'FREE_OF_PAYMENT_DELIVERY',
          assetId: item.assetId,
          quantity: item.allocatedNominal,
          currency: agreement?.baseCurrency || 'USD',
          custodian: pos.custodian,
          counterpartyId: cpty?.id || 'UNKNOWN',
          counterpartyBic: cpty?.settlementBic || 'RHINOGB2L',
          intendedSettlementDate: new Date(Date.now() + 86400000).toISOString().slice(0, 10),
          status: 'TRANSMITTED',
          createdTimestamp: new Date().toISOString()
        });
      }
    }

    // Mark optimization run approved
    setActiveOptimizationRun(prev => prev ? {
      ...prev,
      approved: true,
      approvedBy: `${userRole.toLowerCase()}@rhinobank.com`,
      approvedAt: new Date().toISOString()
    } : null);

    setInventory(updatedInventory);
    setSettlementInstructions(prev => [...newInstructions, ...prev]);

    logAudit(
      'APPROVE_OPTIMISATION_ALLOCATION',
      'OPTIMISATION',
      runId,
      `Approved optimal allocation. Created ${newInstructions.length} settlement instructions and locked collateral inventory.`
    );

    return { success: true, message: `Optimization approved! Generated ${newInstructions.length} SWIFT settlement instructions.` };
  }, [activeOptimizationRun, userRole, inventory, agreements, counterparties, logAudit]);

  // Execute two-leg substitution
  const executeSubstitution = useCallback((tradeId: string, replacementAssetId: string, quantity: number) => {
    const trade = repoTrades.find(t => t.id === tradeId);
    if (!trade) return { success: false, message: 'Repo trade not found' };

    const currentAsset = assets.find(a => a.id === trade.assetId);
    const replacementAsset = assets.find(a => a.id === replacementAssetId);
    const replacementPos = inventory.find(p => p.assetId === replacementAssetId);

    if (!currentAsset || !replacementAsset || !replacementPos) {
      return { success: false, message: 'Target asset or inventory position not found' };
    }

    // Validate two-leg substitution
    const validation = validateCollateralSubstitution(
      trade,
      currentAsset,
      replacementAsset,
      replacementPos,
      quantity,
      marketData,
      agreements[3] // GMRA agreement
    );

    if (!validation.allowed) {
      logAudit(
        'SUBSTITUTION_REJECTED',
        'REPO',
        tradeId,
        `Collateral substitution REJECTED: ${validation.validationErrors.join('; ')}`
      );
      return { success: false, message: `Substitution Leg 1 Failed: ${validation.validationErrors.join('; ')}` };
    }

    // Atomic execution of Leg 1 (pledge replacement) and Leg 2 (release original)
    const updatedInventory = inventory.map(pos => {
      if (pos.id === replacementPos.id) {
        return {
          ...pos,
          pledgedQuantity: pos.pledgedQuantity + quantity,
          lastUpdated: new Date().toISOString()
        };
      }
      if (pos.assetId === currentAsset.id) {
        return {
          ...pos,
          pledgedQuantity: Math.max(0, pos.pledgedQuantity - trade.collateralNominal),
          lastUpdated: new Date().toISOString()
        };
      }
      return pos;
    });

    setInventory(updatedInventory);

    // Update Repo Trade
    setRepoTrades(prev => prev.map(t => {
      if (t.id === tradeId) {
        return {
          ...t,
          assetId: replacementAsset.id,
          collateralNominal: quantity,
          collateralCoverageRatio: validation.coverageAfterSubstitution || t.collateralCoverageRatio,
          status: 'ACTIVE'
        };
      }
      return t;
    }));

    logAudit(
      'SUBSTITUTION_EXECUTED',
      'REPO',
      tradeId,
      `Two-leg substitution successful. Replaced ${currentAsset.ticker} (${trade.collateralNominal.toLocaleString()}) with ${replacementAsset.ticker} (${quantity.toLocaleString()}).`
    );

    return {
      success: true,
      message: `Two-leg substitution executed! Collateral coverage renewed at ${((validation.coverageAfterSubstitution || 1) * 100).toFixed(1)}%.`
    };
  }, [repoTrades, assets, inventory, marketData, agreements, logAudit]);

  // Run Stress Scenario
  const selectAndRunStressScenario = useCallback((scenario: StressScenario) => {
    setCurrentScenario(scenario);
    const result = runStressScenario(
      scenario,
      assets,
      inventory,
      marketData,
      agreements,
      marginCalls,
      counterparties
    );
    setActiveStressResult(result);
    logAudit(
      'RUN_STRESS_SCENARIO',
      'RULES',
      scenario.id,
      `Executed stress test '${scenario.name}'. Projected collateral value drop: -$${Math.round(result.collateralValueDropUSD).toLocaleString()} (-${(result.collateralValueDropPct * 100).toFixed(1)}%).`
    );
  }, [assets, inventory, marketData, agreements, marginCalls, counterparties, logAudit]);

  // Resolve Exception
  const resolveException = useCallback((recordId: string, resolutionNotes: string) => {
    setReconciliationRecords(prev => prev.map(r => {
      if (r.id === recordId) {
        return {
          ...r,
          resolutionStatus: 'RESOLVED',
          notes: `${r.notes ? r.notes + ' | ' : ''}Resolved: ${resolutionNotes}`
        };
      }
      return r;
    }));

    logAudit(
      'RESOLVE_RECONCILIATION_EXCEPTION',
      'INVENTORY',
      recordId,
      `Reconciliation exception resolved: ${resolutionNotes}`
    );
  }, [logAudit]);

  // Manual Position Adjustment with Invariant Protection
  const addPositionPledgeAdjustment = useCallback((positionId: string, newPledgedQty: number, rationale: string) => {
    const pos = inventory.find(p => p.id === positionId);
    if (!pos) return { success: false, message: 'Position not found' };

    if (newPledgedQty < 0 || newPledgedQty > pos.totalQuantity - pos.pendingDeliveryQuantity - pos.frozenDisputedQuantity) {
      return {
        success: false,
        message: `INVARIANT VIOLATION: Cannot pledge ${newPledgedQty.toLocaleString()} units. Exceeds total unencumbered limit!`
      };
    }

    setInventory(prev => prev.map(p => {
      if (p.id === positionId) {
        return {
          ...p,
          pledgedQuantity: newPledgedQty,
          lastUpdated: new Date().toISOString()
        };
      }
      return p;
    }));

    logAudit(
      'MANUAL_PLEDGE_ADJUSTMENT',
      'INVENTORY',
      positionId,
      `Pledged quantity modified to ${newPledgedQty.toLocaleString()}. Reason: ${rationale}`,
      { pledged: pos.pledgedQuantity },
      { pledged: newPledgedQty }
    );

    return { success: true, message: 'Position pledged quantity updated successfully' };
  }, [inventory, logAudit]);

  // Freeze/Dispute quantity
  const freezePositionDispute = useCallback((positionId: string, frozenAmount: number, reason: string) => {
    const pos = inventory.find(p => p.id === positionId);
    if (!pos) return { success: false, message: 'Position not found' };

    setInventory(prev => prev.map(p => {
      if (p.id === positionId) {
        return {
          ...p,
          frozenDisputedQuantity: frozenAmount,
          notes: reason,
          lastUpdated: new Date().toISOString()
        };
      }
      return p;
    }));

    logAudit(
      'FREEZE_POSITION_DISPUTE',
      'INVENTORY',
      positionId,
      `Locked/frozen ${frozenAmount.toLocaleString()} units due to dispute: ${reason}`
    );

    return { success: true, message: `Position frozen quantity set to ${frozenAmount.toLocaleString()}` };
  }, [inventory, logAudit]);

  // Update Agreement Schedule
  const updateAgreementSchedule = useCallback((agreementId: string, updates: Partial<CollateralAgreement>) => {
    setAgreements(prev => prev.map(a => {
      if (a.id === agreementId) {
        return {
          ...a,
          ...updates,
          version: a.version + 1
        };
      }
      return a;
    }));

    logAudit(
      'UPDATE_AGREEMENT_SCHEDULE',
      'AGREEMENT',
      agreementId,
      `Agreement terms modified; version incremented. Material changes require approver sign-off.`
    );
  }, [logAudit]);

  // Run full EOD cycle
  const runPortfolioEODCycle = useCallback(() => {
    // 1. Re-run reconciliation
    const recon = performCustodyReconciliation(inventory, assets, marketData, EXTERNAL_CUSTODY_STATEMENTS);
    setReconciliationRecords(recon);

    // 2. Re-evaluate repo accrued interest
    setRepoTrades(prev => prev.map(trade => {
      const asset = assets.find(a => a.id === trade.assetId)!;
      const mkt = marketData[asset.id];
      const evalRes = evaluateRepoPosition(trade, asset, mkt);
      return {
        ...trade,
        accruedRepoInterestUSD: evalRes.accruedInterest,
        collateralCoverageRatio: evalRes.collateralCoverageRatio
      };
    }));

    logAudit(
      'PORTFOLIO_EOD_COMPLETE',
      'INVENTORY',
      'GLOBAL_PORTFOLIO',
      'End-of-day valuation, margin calculation, and custody reconciliation cycle completed.'
    );
  }, [inventory, assets, marketData, logAudit]);

  // Reset to initial demo state
  const resetToInitialDemoState = useCallback(() => {
    setCounterparties(INITIAL_COUNTERPARTIES);
    setAssets(INITIAL_ASSETS);
    setMarketData(INITIAL_MARKET_DATA);
    setAgreements(INITIAL_AGREEMENTS);
    setInventory(INITIAL_INVENTORY);
    setMarginCalls(INITIAL_MARGIN_CALLS);
    setRepoTrades(INITIAL_REPO_TRADES);
    setReconciliationRecords(performCustodyReconciliation(INITIAL_INVENTORY, INITIAL_ASSETS, INITIAL_MARKET_DATA, EXTERNAL_CUSTODY_STATEMENTS));
    setActiveOptimizationRun(null);
    logAudit('SYSTEM_RESET', 'INVENTORY', 'DEMO_DATA', 'Reset system to initial demonstration baseline state');
  }, [logAudit]);

  return (
    <CollateralContext.Provider value={{
      counterparties,
      assets,
      marketData,
      agreements,
      inventory,
      marginCalls,
      repoTrades,
      reconciliationRecords,
      settlementInstructions,
      auditEvents,
      activeOptimizationRun,
      activeStressResult,
      currentScenario,
      userRole,
      totalInventoryDirtyUSD,
      totalRecognisedCollateralUSD,
      totalPledgedUSD,
      totalFreeCollateralUSD,
      haircutDragUSD,
      openMarginCallsCount,
      totalOpenMarginCallsUSD,
      unsettledTransfersCount,
      openExceptionsCount,
      setUserRole,
      updateMarginCallStatus,
      runNewMarginCalculation,
      runOptimisationSolver,
      approveOptimisationPlan,
      executeSubstitution,
      selectAndRunStressScenario,
      resolveException,
      runPortfolioEODCycle,
      addPositionPledgeAdjustment,
      freezePositionDispute,
      updateAgreementSchedule,
      resetToInitialDemoState
    }}>
      {children}
    </CollateralContext.Provider>
  );
};

export const useCollateral = () => {
  const context = useContext(CollateralContext);
  if (!context) {
    throw new Error('useCollateral must be used within a CollateralProvider');
  }
  return context;
};
