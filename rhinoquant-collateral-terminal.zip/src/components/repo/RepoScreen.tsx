/**
 * RhinoQuant Collateral Management Platform
 * Repo & Secured Funding Module - Repos, Reverse Repos, Accrual Engine, and Two-Leg Substitution
 */

import React, { useState } from 'react';
import { useCollateral } from '../../context/CollateralContext';
import { RepoTrade, DayCountConvention } from '../../types/models';
import { calculateRepoInterest } from '../../engines/repoEngine';
import { 
  ArrowLeftRight, 
  RotateCw, 
  Calendar, 
  Percent, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  X, 
  ArrowRight,
  TrendingUp,
  FileText
} from 'lucide-react';

export const RepoScreen: React.FC = () => {
  const { 
    repoTrades, 
    counterparties, 
    assets, 
    inventory, 
    executeSubstitution 
  } = useCollateral();

  const [selectedTrade, setSelectedTrade] = useState<RepoTrade | null>(null);
  const [substitutionTrade, setSubstitutionTrade] = useState<RepoTrade | null>(null);
  const [replacementAssetId, setReplacementAssetId] = useState<string>(assets[1]?.id || '');
  const [replacementQuantity, setReplacementQuantity] = useState<number>(10000000);
  const [subFeedback, setSubFeedback] = useState<{ success: boolean; message: string } | null>(null);

  const counterpartyMap = React.useMemo(() => new Map(counterparties.map(c => [c.id, c])), [counterparties]);
  const assetMap = React.useMemo(() => new Map(assets.map(a => [a.id, a])), [assets]);

  // Aggregate stats
  const totalFinancedUSD = repoTrades.reduce((sum, t) => sum + (t.tradeType === 'REPO' ? t.cashPrincipal : 0), 0);
  const totalReverseUSD = repoTrades.reduce((sum, t) => sum + (t.tradeType === 'REVERSE_REPO' ? t.cashPrincipal : 0), 0);
  const totalAccruedInterestUSD = repoTrades.reduce((sum, t) => sum + t.accruedRepoInterestUSD, 0);

  const handleExecuteSubstitution = (e: React.FormEvent) => {
    e.preventDefault();
    if (!substitutionTrade) return;

    const res = executeSubstitution(substitutionTrade.id, replacementAssetId, Number(replacementQuantity));
    setSubFeedback(res);
    if (res.success) {
      setTimeout(() => {
        setSubstitutionTrade(null);
        setSubFeedback(null);
      }, 3000);
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-3">
            <span>Repo & Secured Funding Desk</span>
            <span className="text-xs font-normal text-blue-400 font-mono">
              GMRA 2011 · ACT/360 ACCRUAL ENGINE
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Institutional repo financing analytics, day-count interest calculations, and controlled two-leg collateral substitutions.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              setSubstitutionTrade(repoTrades[0]);
              setReplacementAssetId(assets[1]?.id || '');
              setReplacementQuantity(10000000);
              setSubFeedback(null);
            }}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium bg-blue-600 hover:bg-blue-500 text-white rounded transition-colors cursor-pointer shadow-xs"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>Request Two-Leg Substitution</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs text-slate-400">Total Repo Cash Borrowed</div>
          <div className="text-2xl font-bold font-mono text-white mt-1">
            ${(totalFinancedUSD / 1_000_000).toFixed(1)}M
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Collateral posted to market</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs text-slate-400">Reverse Repo Cash Lent</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            ${(totalReverseUSD / 1_000_000).toFixed(1)}M
          </div>
          <div className="text-[11px] text-slate-500 mt-1">High-quality collateral held</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs text-slate-400">Total Accrued Financing Interest</div>
          <div className="text-2xl font-bold font-mono text-blue-400 mt-1">
            ${Math.round(totalAccruedInterestUSD).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">ACT/360 daily compound</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs text-slate-400">Maturing Next 24h</div>
          <div className="text-2xl font-bold font-mono text-amber-400 mt-1">
            1 Trade ($15.0M)
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Goldman Sachs Reverse Repo</div>
        </div>
      </div>

      {/* Active Trades Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-4 py-3 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between text-xs">
          <span className="font-semibold text-slate-200">Active Repurchase & Reverse Repurchase Agreements</span>
          <span className="font-mono text-slate-500 text-[11px]">{repoTrades.length} Active Positions</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/40 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                <th className="py-2.5 px-3">Trade Ref</th>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">Counterparty</th>
                <th className="py-2.5 px-3 text-right">Principal</th>
                <th className="py-2.5 px-3 text-right">Rate / Day Count</th>
                <th className="py-2.5 px-3 text-right">Accrued Interest</th>
                <th className="py-2.5 px-3">Collateral Asset</th>
                <th className="py-2.5 px-3 text-right">Nominal</th>
                <th className="py-2.5 px-3 text-right">Coverage Ratio</th>
                <th className="py-2.5 px-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px] tabular-nums">
              {repoTrades.map(trade => {
                const cpty = counterpartyMap.get(trade.counterpartyId);
                const asset = assetMap.get(trade.assetId);

                return (
                  <tr key={trade.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-3 font-sans font-semibold text-slate-200">
                      {trade.tradeRef}
                      <div className="text-[10px] font-mono text-slate-500">
                        {trade.startDate} &rarr; {trade.endDate}
                      </div>
                    </td>

                    <td className="py-3 px-3 font-sans">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        trade.tradeType === 'REPO' 
                          ? 'bg-blue-950/60 text-blue-400 border border-blue-900/40' 
                          : 'bg-emerald-950/60 text-emerald-400 border border-emerald-900/40'
                      }`}>
                        {trade.tradeType}
                      </span>
                    </td>

                    <td className="py-3 px-3 font-sans">
                      <div className="text-slate-200 font-semibold">{cpty?.name}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{cpty?.shortCode}</div>
                    </td>

                    <td className="py-3 px-3 text-right text-slate-200 font-bold">
                      ${trade.cashPrincipal.toLocaleString()}
                    </td>

                    <td className="py-3 px-3 text-right text-slate-300">
                      {(trade.repoRate * 100).toFixed(2)}% ({trade.dayCount})
                    </td>

                    <td className="py-3 px-3 text-right text-blue-400 font-semibold">
                      ${trade.accruedRepoInterestUSD.toLocaleString()}
                    </td>

                    <td className="py-3 px-3 font-sans">
                      <div className="text-slate-200 font-semibold">{asset?.ticker || asset?.name}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{asset?.isin}</div>
                    </td>

                    <td className="py-3 px-3 text-right text-slate-300">
                      {trade.collateralNominal.toLocaleString()}
                    </td>

                    <td className="py-3 px-3 text-right">
                      <span className={`font-bold ${
                        trade.collateralCoverageRatio >= trade.marginMaintenanceThreshold
                          ? 'text-emerald-400'
                          : 'text-red-400'
                      }`}>
                        {(trade.collateralCoverageRatio * 100).toFixed(2)}%
                      </span>
                      <div className="text-[10px] text-slate-500">
                        req: {(trade.marginMaintenanceThreshold * 100).toFixed(0)}%
                      </div>
                    </td>

                    <td className="py-3 px-3 text-center font-sans">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setSelectedTrade(trade)}
                          className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-medium transition-colors cursor-pointer"
                          title="Inspect interest accrual & coverage"
                        >
                          Inspect
                        </button>
                        <button
                          onClick={() => {
                            setSubstitutionTrade(trade);
                            setSubFeedback(null);
                          }}
                          className="px-2 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-medium transition-colors cursor-pointer"
                          title="Initiate two-leg substitution"
                        >
                          Substitute
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Trade Inspection Drawer */}
      {selectedTrade && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-end z-50">
          <div className="w-full max-w-lg h-full bg-slate-900 border-l border-slate-800 p-6 overflow-y-auto space-y-5 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <span>Repo Accrual & Coverage Inspector</span>
                </h2>
                <div className="text-xs text-slate-400 font-mono mt-0.5">
                  {selectedTrade.tradeRef} ({selectedTrade.tradeType})
                </div>
              </div>
              <button
                onClick={() => setSelectedTrade(null)}
                className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Accrual Formula Trace */}
            <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-2.5">
              <div className="font-semibold text-slate-200">Contractual Interest Formula Trace ({selectedTrade.dayCount})</div>
              <div className="font-mono text-[11px] text-slate-300 space-y-1.5">
                <div>Formula: <code>Interest = Principal × Rate × (Actual Days / 360)</code></div>
                <div>Principal: ${selectedTrade.cashPrincipal.toLocaleString()}</div>
                <div>Annual Repo Rate: {(selectedTrade.repoRate * 100).toFixed(2)}%</div>
                <div>Start Date: {selectedTrade.startDate}</div>
                <div>As Of Date: 2026-10-24 (14 elapsed days)</div>
                <div className="pt-2 border-t border-slate-800 text-blue-400 font-bold">
                  Accrued Repo Interest = ${selectedTrade.accruedRepoInterestUSD.toLocaleString()}
                </div>
              </div>
            </div>

            {/* Collateral Coverage Calculation */}
            <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-2.5">
              <div className="font-semibold text-slate-200">Collateral Maintenance Margin Check</div>
              <div className="font-mono text-[11px] text-slate-300 space-y-1.5">
                <div>Pledged Dirty MV: ${selectedTrade.currentMarketValueUSD.toLocaleString()}</div>
                <div>Haircut Applied: {(selectedTrade.initialHaircut * 100).toFixed(1)}%</div>
                <div>Recognised Collateral: ${selectedTrade.currentRecognisedValueUSD.toLocaleString()}</div>
                <div>Total Cash Liability: ${(selectedTrade.cashPrincipal + selectedTrade.accruedRepoInterestUSD).toLocaleString()}</div>
                <div className="pt-2 border-t border-slate-800 text-emerald-400 font-bold">
                  Coverage Ratio = {(selectedTrade.collateralCoverageRatio * 100).toFixed(2)}% (Maintenance Threshold: {(selectedTrade.marginMaintenanceThreshold * 100).toFixed(0)}%)
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Two-Leg Substitution Workflow Modal */}
      {substitutionTrade && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <RotateCw className="w-4 h-4 text-blue-400" />
                <span>Controlled Two-Leg Collateral Substitution</span>
              </h3>
              <button onClick={() => setSubstitutionTrade(null)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 rounded bg-blue-950/40 border border-blue-900/60 text-blue-300 space-y-1 text-[11px]">
              <div className="font-semibold">Institutional Governance Protocol:</div>
              <div>Leg 1: Evaluate candidate replacement security for GMRA eligibility, availability, and haircut coverage.</div>
              <div>Leg 2: Only upon successful validation of Leg 1, permit simultaneous release of existing collateral!</div>
            </div>

            {subFeedback && (
              <div className={`p-3 rounded text-xs flex items-center gap-2 ${
                subFeedback.success ? 'bg-emerald-950 border border-emerald-800 text-emerald-200' : 'bg-red-950 border border-red-800 text-red-200'
              }`}>
                {subFeedback.success ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertTriangle className="w-4 h-4 shrink-0" />}
                <span>{subFeedback.message}</span>
              </div>
            )}

            <form onSubmit={handleExecuteSubstitution} className="space-y-4">
              <div>
                <label className="text-slate-300 block mb-1">Target Repo Trade</label>
                <div className="p-2.5 rounded bg-slate-950 border border-slate-800 font-mono text-slate-200">
                  {substitutionTrade.tradeRef} · Current Collateral: {assetMap.get(substitutionTrade.assetId)?.ticker} ({substitutionTrade.collateralNominal.toLocaleString()})
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Proposed Replacement Security (Leg 1)</label>
                <select
                  value={replacementAssetId}
                  onChange={(e) => setReplacementAssetId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 focus:outline-none"
                >
                  {assets.map(a => (
                    <option key={a.id} value={a.id}>
                      {a.name} ({a.isin}) · {a.creditRating} · {a.assetClass}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Replacement Nominal Quantity</label>
                <input
                  type="number"
                  value={replacementQuantity}
                  onChange={(e) => setReplacementQuantity(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 font-mono text-white focus:outline-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSubstitutionTrade(null)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-medium bg-blue-600 hover:bg-blue-500 text-white rounded cursor-pointer"
                >
                  Verify Leg 1 & Execute Substitution
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
