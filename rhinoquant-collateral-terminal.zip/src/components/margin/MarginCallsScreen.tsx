/**
 * RhinoQuant Collateral Management Platform
 * Margin Calls Screen - Lifecycle Queue, Calculation Inspector, and Dispute Management
 */

import React, { useState } from 'react';
import { useCollateral } from '../../context/CollateralContext';
import { MarginCall, MarginCallStatus } from '../../types/models';
import { 
  Scale, 
  Plus, 
  Check, 
  X, 
  AlertTriangle, 
  FileText, 
  Clock, 
  Send, 
  ThumbsUp, 
  Ban, 
  HelpCircle,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2
} from 'lucide-react';

export const MarginCallsScreen: React.FC = () => {
  const { 
    marginCalls, 
    agreements, 
    counterparties, 
    updateMarginCallStatus, 
    runNewMarginCalculation,
    userRole
  } = useCollateral();

  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [selectedCall, setSelectedCall] = useState<MarginCall | null>(null);

  // New calculation modal
  const [showNewCallModal, setShowNewCallModal] = useState(false);
  const [newAgId, setNewAgId] = useState(agreements[0]?.id || '');
  const [exposureUSD, setExposureUSD] = useState(6500000);
  const [imUSD, setImUSD] = useState(0);
  const [vmUSD, setVmUSD] = useState(6500000);

  // Dispute modal
  const [disputingCall, setDisputingCall] = useState<MarginCall | null>(null);
  const [disputeReason, setDisputeReason] = useState('');
  const [disputeAmount, setDisputeAmount] = useState(0);

  // Action status feedback
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  const agreementMap = React.useMemo(() => new Map(agreements.map(a => [a.id, a])), [agreements]);
  const counterpartyMap = React.useMemo(() => new Map(counterparties.map(c => [c.id, c])), [counterparties]);

  const filteredCalls = marginCalls.filter(call => {
    if (statusFilter === 'ACTION_REQUIRED') {
      return ['CALCULATED', 'PENDING_APPROVAL', 'ISSUED', 'DISPUTED'].includes(call.status);
    }
    if (statusFilter === 'DISPUTED') return call.status === 'DISPUTED';
    if (statusFilter === 'SETTLED') return call.status === 'SETTLED';
    if (statusFilter !== 'ALL') return call.status === statusFilter;
    return true;
  });

  const handleStatusChange = (callId: string, targetStatus: MarginCallStatus) => {
    const res = updateMarginCallStatus(callId, targetStatus);
    if (!res.success) {
      setActionFeedback(`ERROR: ${res.message}`);
    } else {
      setActionFeedback(res.message);
      // update inspected call if open
      if (selectedCall?.id === callId) {
        setSelectedCall(prev => prev ? { ...prev, status: targetStatus } : null);
      }
    }
    setTimeout(() => setActionFeedback(null), 4000);
  };

  const handleConfirmDispute = (e: React.FormEvent) => {
    e.preventDefault();
    if (!disputingCall) return;
    const res = updateMarginCallStatus(disputingCall.id, 'DISPUTED', disputeReason, disputeAmount);
    if (res.success) {
      setDisputingCall(null);
      setActionFeedback(`Margin call flagged as DISPUTED ($${disputeAmount.toLocaleString()})`);
    } else {
      setActionFeedback(`ERROR: ${res.message}`);
    }
    setTimeout(() => setActionFeedback(null), 4000);
  };

  const handleCreateNewCall = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const call = runNewMarginCalculation(newAgId, Number(exposureUSD), Number(imUSD), Number(vmUSD));
      setShowNewCallModal(false);
      setSelectedCall(call);
      setActionFeedback(`Calculated margin call ${call.id} ($${call.requiredTransferAmountUSD.toLocaleString()})`);
    } catch (err: any) {
      setActionFeedback(`ERROR: ${err.message}`);
    }
    setTimeout(() => setActionFeedback(null), 4000);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-3">
            <span>Margin Calls & Collateral Lifecycle Queue</span>
            <span className="text-xs font-normal text-slate-400 font-mono">
              {filteredCalls.length} CALLS · 100% IDEMPOTENT NETTING
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Deterministic valuation netting with contractual MTA thresholding and stateful lifecycle governance.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowNewCallModal(true)}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium bg-blue-600 hover:bg-blue-500 text-white rounded transition-colors cursor-pointer shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Calculate New Call</span>
          </button>
        </div>
      </div>

      {/* Action Feedback Banner */}
      {actionFeedback && (
        <div className={`p-3 rounded text-xs flex items-center justify-between ${
          actionFeedback.startsWith('ERROR') 
            ? 'bg-red-950/60 border border-red-800 text-red-200' 
            : 'bg-emerald-950/60 border border-emerald-800 text-emerald-200'
        }`}>
          <span>{actionFeedback}</span>
          <button onClick={() => setActionFeedback(null)} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-1.5 rounded-lg text-xs">
        <button
          onClick={() => setStatusFilter('ALL')}
          className={`px-3 py-1.5 rounded transition-colors cursor-pointer ${
            statusFilter === 'ALL' ? 'bg-slate-800 text-blue-400 font-semibold' : 'text-slate-400 hover:text-white'
          }`}
        >
          All Calls ({marginCalls.length})
        </button>
        <button
          onClick={() => setStatusFilter('ACTION_REQUIRED')}
          className={`px-3 py-1.5 rounded transition-colors cursor-pointer ${
            statusFilter === 'ACTION_REQUIRED' ? 'bg-slate-800 text-blue-400 font-semibold' : 'text-slate-400 hover:text-white'
          }`}
        >
          Action Required ({marginCalls.filter(c => ['CALCULATED', 'PENDING_APPROVAL', 'ISSUED', 'DISPUTED'].includes(c.status)).length})
        </button>
        <button
          onClick={() => setStatusFilter('DISPUTED')}
          className={`px-3 py-1.5 rounded transition-colors cursor-pointer ${
            statusFilter === 'DISPUTED' ? 'bg-slate-800 text-amber-400 font-semibold' : 'text-slate-400 hover:text-white'
          }`}
        >
          Disputed ({marginCalls.filter(c => c.status === 'DISPUTED').length})
        </button>
        <button
          onClick={() => setStatusFilter('SETTLED')}
          className={`px-3 py-1.5 rounded transition-colors cursor-pointer ${
            statusFilter === 'SETTLED' ? 'bg-slate-800 text-emerald-400 font-semibold' : 'text-slate-400 hover:text-white'
          }`}
        >
          Settled ({marginCalls.filter(c => c.status === 'SETTLED').length})
        </button>
      </div>

      {/* Margin Calls Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                <th className="py-2.5 px-3">Call Ref / Date</th>
                <th className="py-2.5 px-3">Counterparty & Agreement</th>
                <th className="py-2.5 px-3">Direction</th>
                <th className="py-2.5 px-3 text-right">Exposure (USD)</th>
                <th className="py-2.5 px-3 text-right">Net Held (USD)</th>
                <th className="py-2.5 px-3 text-right">Required Transfer</th>
                <th className="py-2.5 px-3">Cut-off Deadline</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-center">Lifecycle Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px] tabular-nums">
              {filteredCalls.map(call => {
                const ag = agreementMap.get(call.agreementId);
                const cpty = counterpartyMap.get(call.counterpartyId);

                return (
                  <tr key={call.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-3 font-sans">
                      <div className="font-semibold text-slate-200">{call.id}</div>
                      <div className="text-[10px] font-mono text-slate-500">{call.callDate}</div>
                    </td>

                    <td className="py-3 px-3 font-sans">
                      <div className="font-semibold text-slate-200">{cpty?.name || call.counterpartyId}</div>
                      <div className="text-[10px] text-slate-500 truncate max-w-[220px]">
                        {ag?.name || call.agreementId}
                      </div>
                    </td>

                    <td className="py-3 px-3 font-sans">
                      {call.direction === 'DELIVER_COLLATERAL' ? (
                        <span className="flex items-center gap-1.5 text-blue-400 font-medium">
                          <ArrowDownRight className="w-3.5 h-3.5 text-blue-400" />
                          <span>Deliver</span>
                        </span>
                      ) : call.direction === 'RETURN_COLLATERAL' ? (
                        <span className="flex items-center gap-1.5 text-purple-400 font-medium">
                          <ArrowUpRight className="w-3.5 h-3.5 text-purple-400" />
                          <span>Return</span>
                        </span>
                      ) : (
                        <span className="text-slate-500 font-sans">No Call (0)</span>
                      )}
                    </td>

                    <td className="py-3 px-3 text-right text-slate-300">
                      ${call.totalRequirementUSD.toLocaleString()}
                    </td>

                    <td className="py-3 px-3 text-right text-slate-400">
                      ${call.netCollateralRecognisedUSD.toLocaleString()}
                    </td>

                    <td className="py-3 px-3 text-right font-bold text-white">
                      {call.callCurrency} ${call.requiredTransferAmountUSD.toLocaleString()}
                    </td>

                    <td className="py-3 px-3 font-mono text-[10px] text-slate-400">
                      {call.deadlineTimestamp.slice(11, 16)} UTC
                    </td>

                    <td className="py-3 px-3 font-sans">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold tracking-wide ${
                        call.status === 'SETTLED'
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-900/40'
                          : call.status === 'ISSUED'
                          ? 'bg-blue-950/60 text-blue-400 border border-blue-900/40'
                          : call.status === 'DISPUTED'
                          ? 'bg-red-950/60 text-red-400 border border-red-900/40'
                          : call.status === 'AGREED'
                          ? 'bg-purple-950/60 text-purple-400 border border-purple-900/40'
                          : 'bg-slate-800 text-slate-300'
                      }`}>
                        {call.status.replace(/_/g, ' ')}
                      </span>
                    </td>

                    <td className="py-3 px-3 text-center font-sans">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setSelectedCall(call)}
                          className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-medium transition-colors cursor-pointer flex items-center gap-1"
                          title="Inspect calculation trace"
                        >
                          <FileText className="w-3 h-3 text-blue-400" />
                          <span>Inspect</span>
                        </button>

                        {/* State-specific quick action triggers */}
                        {call.status === 'CALCULATED' && (
                          <button
                            onClick={() => handleStatusChange(call.id, 'PENDING_APPROVAL')}
                            className="px-2 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-medium transition-colors cursor-pointer"
                          >
                            Submit
                          </button>
                        )}

                        {call.status === 'PENDING_APPROVAL' && (
                          <button
                            onClick={() => handleStatusChange(call.id, 'ISSUED')}
                            className="px-2 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-medium transition-colors cursor-pointer"
                          >
                            Approve & Issue
                          </button>
                        )}

                        {call.status === 'ISSUED' && (
                          <>
                            <button
                              onClick={() => handleStatusChange(call.id, 'ACKNOWLEDGED')}
                              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-medium transition-colors cursor-pointer"
                            >
                              Ack
                            </button>
                            <button
                              onClick={() => {
                                setDisputingCall(call);
                                setDisputeAmount(Math.round(call.requiredTransferAmountUSD * 0.15));
                                setDisputeReason('');
                              }}
                              className="px-2 py-1 rounded bg-red-950 hover:bg-red-900 text-red-200 border border-red-800 text-[10px] font-medium transition-colors cursor-pointer"
                            >
                              Dispute
                            </button>
                          </>
                        )}

                        {call.status === 'ACKNOWLEDGED' && (
                          <button
                            onClick={() => handleStatusChange(call.id, 'AGREED')}
                            className="px-2 py-1 rounded bg-purple-600 hover:bg-purple-500 text-white text-[10px] font-medium transition-colors cursor-pointer"
                          >
                            Agree
                          </button>
                        )}

                        {call.status === 'AGREED' && (
                          <button
                            onClick={() => handleStatusChange(call.id, 'SETTLED')}
                            className="px-2 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-medium transition-colors cursor-pointer"
                          >
                            Settle
                          </button>
                        )}

                        {call.status === 'DISPUTED' && (
                          <button
                            onClick={() => handleStatusChange(call.id, 'AGREED')}
                            className="px-2 py-1 rounded bg-purple-600 hover:bg-purple-500 text-white text-[10px] font-medium transition-colors cursor-pointer"
                          >
                            Resolve
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Margin Calculation Inspector Drawer */}
      {selectedCall && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-end z-50">
          <div className="w-full max-w-xl h-full bg-slate-900 border-l border-slate-800 p-6 overflow-y-auto space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <span>Margin Calculation Inspector</span>
                </h2>
                <div className="text-xs text-slate-400 font-mono mt-0.5">
                  Call ID: {selectedCall.id} · Idempotency Key: {selectedCall.idempotencyKey}
                </div>
              </div>
              <button
                onClick={() => setSelectedCall(null)}
                className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Top Metrics */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-950 p-3 rounded border border-slate-800 text-xs">
                <div className="text-slate-400">Total Requirement</div>
                <div className="text-lg font-bold font-mono text-white mt-1">
                  ${selectedCall.totalRequirementUSD.toLocaleString()}
                </div>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-800 text-xs">
                <div className="text-slate-400">Final Required Transfer</div>
                <div className="text-lg font-bold font-mono text-blue-400 mt-1">
                  ${selectedCall.requiredTransferAmountUSD.toLocaleString()}
                </div>
              </div>
            </div>

            {/* Explanation Trace */}
            <div className="bg-slate-950/80 p-4 rounded border border-slate-800 space-y-3 text-xs">
              <div className="font-semibold text-slate-200">Deterministic Mathematical Step-by-Step Log:</div>
              <div className="space-y-2 font-mono text-[11px] text-slate-300">
                {selectedCall.calculationExplanation.map((line, idx) => (
                  <div key={idx} className="p-2 rounded bg-slate-900/60 border border-slate-800/80">
                    {line}
                  </div>
                ))}
              </div>
            </div>

            {/* Contractual Parameters Used */}
            <div className="bg-slate-950/80 p-4 rounded border border-slate-800 space-y-2 text-xs">
              <div className="font-semibold text-slate-200">Governing Agreement Netting Parameters</div>
              <div className="grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-300">
                <div>Threshold: <strong className="text-white">${selectedCall.thresholdUSD.toLocaleString()}</strong></div>
                <div>MTA: <strong className="text-white">${selectedCall.minimumTransferAmountUSD.toLocaleString()}</strong></div>
                <div>Rounding: <strong className="text-white">${selectedCall.roundingIncrementUSD.toLocaleString()}</strong></div>
                <div>Call Currency: <strong className="text-white">{selectedCall.callCurrency}</strong></div>
              </div>
            </div>

            {/* Dispute Details if present */}
            {selectedCall.status === 'DISPUTED' && (
              <div className="bg-red-950/30 p-4 rounded border border-red-900/60 space-y-2 text-xs">
                <div className="font-semibold text-red-200 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                  <span>Active Dispute Record</span>
                </div>
                <div className="text-slate-300 text-[11px]">
                  <div>Disputed Variance: <strong className="text-red-400 font-mono">${selectedCall.disputeAmountUSD?.toLocaleString()}</strong></div>
                  <div className="mt-1">Reason: {selectedCall.disputeReason}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Calculate New Call Modal */}
      {showNewCallModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Calculate Margin Obligation</h3>
              <button onClick={() => setShowNewCallModal(false)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-slate-400">
              Evaluates portfolio MtM against agreement netting terms, thresholds, and minimum transfer amount.
            </p>

            <form onSubmit={handleCreateNewCall} className="space-y-4">
              <div>
                <label className="text-slate-300 block mb-1">Target Agreement</label>
                <select
                  value={newAgId}
                  onChange={(e) => setNewAgId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 focus:outline-none"
                >
                  {agreements.map(a => (
                    <option key={a.id} value={a.id}>
                      {a.name} ({a.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Variation Margin (MtM Exposure USD)</label>
                <input
                  type="number"
                  value={vmUSD}
                  onChange={(e) => setVmUSD(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 font-mono text-white focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Initial Margin Requirement (SIMM / Schedule USD)</label>
                <input
                  type="number"
                  value={imUSD}
                  onChange={(e) => setImUSD(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 font-mono text-white focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewCallModal(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-medium bg-blue-600 hover:bg-blue-500 text-white rounded cursor-pointer"
                >
                  Calculate & Net
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Dispute Modal */}
      {disputingCall && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-400" />
                <span>Issue Margin Dispute Notice</span>
              </h3>
              <button onClick={() => setDisputingCall(null)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-slate-400">
              Flags call for middle-office reconciliation and records formal dispute reason under ISDA dispute resolution provisions.
            </p>

            <form onSubmit={handleConfirmDispute} className="space-y-4">
              <div>
                <label className="text-slate-300 block mb-1">Disputed Variance (USD)</label>
                <input
                  type="number"
                  value={disputeAmount}
                  onChange={(e) => setDisputeAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 font-mono text-white focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Dispute Basis / Pricing Discrepancy</label>
                <textarea
                  value={disputeReason}
                  onChange={(e) => setDisputeReason(e.target.value)}
                  placeholder="e.g. Valuation difference on interest rate swap discounting curve (€STR vs OIS)"
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white h-20 focus:outline-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDisputingCall(null)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-medium bg-red-600 hover:bg-red-500 text-white rounded cursor-pointer"
                >
                  Submit Formal Dispute
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
