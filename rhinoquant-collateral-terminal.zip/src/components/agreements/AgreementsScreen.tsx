/**
 * RhinoQuant Collateral Management Platform
 * Agreements & Eligibility Rules Matrix - CSA Parameters, Versioning, and Live Rule Simulator
 */

import React, { useState } from 'react';
import { useCollateral } from '../../context/CollateralContext';
import { CollateralAgreement, AssetClass } from '../../types/models';
import { evaluateEligibility } from '../../engines/eligibilityEngine';
import { 
  ScrollText, 
  ShieldCheck, 
  AlertCircle, 
  Edit3, 
  CheckCircle2, 
  X, 
  Play, 
  Layers, 
  Building2,
  Clock
} from 'lucide-react';

export const AgreementsScreen: React.FC = () => {
  const { 
    agreements, 
    counterparties, 
    assets, 
    inventory, 
    updateAgreementSchedule,
    userRole
  } = useCollateral();

  const [selectedAgreement, setSelectedAgreement] = useState<CollateralAgreement>(agreements[0]);
  const [editingAgreement, setEditingAgreement] = useState<CollateralAgreement | null>(null);

  // Live Simulator State
  const [simAssetId, setSimAssetId] = useState<string>(assets[0]?.id || '');
  const [simResult, setSimResult] = useState<any | null>(null);

  const counterpartyMap = React.useMemo(() => new Map(counterparties.map(c => [c.id, c])), [counterparties]);
  const assetMap = React.useMemo(() => new Map(assets.map(a => [a.id, a])), [assets]);

  const handleRunSimulator = () => {
    const asset = assetMap.get(simAssetId);
    if (!asset) return;
    const pos = inventory.find(p => p.assetId === asset.id);
    const res = evaluateEligibility(asset, selectedAgreement, pos);
    setSimResult(res);
  };

  const handleSaveTerms = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAgreement) return;

    updateAgreementSchedule(editingAgreement.id, {
      threshold: Number(editingAgreement.threshold),
      minimumTransferAmount: Number(editingAgreement.minimumTransferAmount),
      roundingIncrement: Number(editingAgreement.roundingIncrement),
      callCutOffTimeUtc: editingAgreement.callCutOffTimeUtc
    });

    setSelectedAgreement(editingAgreement);
    setEditingAgreement(null);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-3">
            <span>Collateral Agreements & Eligibility Matrix</span>
            <span className="text-xs font-normal text-blue-400 font-mono">
              {agreements.length} LEGAL SCHEDULES · BCBS-IOSCO COMPLIANT
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Governing ISDA CSAs, GMRAs, and CCP schedules with versioned eligibility rules, concentration caps, and cut-off timelines.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setEditingAgreement({ ...selectedAgreement })}
            disabled={userRole === 'VIEWER' || userRole === 'AUDITOR'}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 text-white rounded transition-colors cursor-pointer"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Edit Agreement Parameters</span>
          </button>
        </div>
      </div>

      {/* Main Split: Agreement Selector + Terms Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Col: Agreement List */}
        <div className="space-y-2.5">
          <div className="text-xs font-semibold text-slate-400 mb-1">Select Agreement:</div>
          {agreements.map(ag => {
            const isSelected = selectedAgreement.id === ag.id;
            const cpty = counterpartyMap.get(ag.counterpartyId);

            return (
              <div
                key={ag.id}
                onClick={() => {
                  setSelectedAgreement(ag);
                  setSimResult(null);
                }}
                className={`p-3 rounded-lg border text-xs cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-blue-950/40 border-blue-600 text-white shadow-xs'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-slate-200">{ag.code}</div>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300">
                    v{ag.version}
                  </span>
                </div>
                <div className="text-slate-300 mt-1 text-[11px] truncate">{ag.name}</div>
                <div className="text-slate-500 text-[10px] mt-2 flex items-center justify-between font-mono">
                  <span>{cpty?.shortCode}</span>
                  <span>MTA: ${ag.minimumTransferAmount.toLocaleString()}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Middle & Right: Agreement Details & Rules */}
        <div className="lg:col-span-2 space-y-6">
          {/* Agreement Contract Details */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white">{selectedAgreement.name}</h3>
                <div className="text-xs text-slate-400 font-mono mt-0.5">
                  Type: {selectedAgreement.type} · Governing Law: {selectedAgreement.governingLaw} · Version: {selectedAgreement.version}
                </div>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                {selectedAgreement.status}
              </span>
            </div>

            {/* Grid of Terms */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                <div className="text-slate-500 text-[10px]">Base Currency</div>
                <div className="text-sm font-bold text-white mt-0.5">{selectedAgreement.baseCurrency}</div>
              </div>
              <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                <div className="text-slate-500 text-[10px]">Contractual Threshold</div>
                <div className="text-sm font-bold text-white mt-0.5">${selectedAgreement.threshold.toLocaleString()}</div>
              </div>
              <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                <div className="text-slate-500 text-[10px]">Minimum Transfer (MTA)</div>
                <div className="text-sm font-bold text-blue-400 mt-0.5">${selectedAgreement.minimumTransferAmount.toLocaleString()}</div>
              </div>
              <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                <div className="text-slate-500 text-[10px]">Rounding Increment</div>
                <div className="text-sm font-bold text-slate-300 mt-0.5">${selectedAgreement.roundingIncrement.toLocaleString()}</div>
              </div>
            </div>

            {/* Timings */}
            <div className="flex items-center gap-4 text-xs font-mono text-slate-400 pt-1">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                <span>Call Cut-off: <strong className="text-slate-200">{selectedAgreement.callCutOffTimeUtc} UTC</strong></span>
              </div>
              <div>·</div>
              <div>Notification: <strong className="text-slate-200">{selectedAgreement.notificationTimeUtc} UTC</strong></div>
              <div>·</div>
              <div>Valuation: <strong className="text-slate-200">{selectedAgreement.valuationFrequency}</strong></div>
            </div>
          </div>

          {/* Collateral Eligibility Matrix */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Collateral Eligibility Schedule & Haircut Parameters</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 rounded bg-slate-950 border border-slate-800 space-y-2">
                <div className="font-semibold text-slate-200">Whitelisted Asset Classes:</div>
                <div className="flex flex-wrap gap-1.5">
                  {selectedAgreement.eligibilityRule.allowedAssetClasses.map(ac => (
                    <span key={ac} className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[10px]">
                      {ac.replace(/_/g, ' ')}
                    </span>
                  ))}
                </div>
              </div>

              <div className="p-3 rounded bg-slate-950 border border-slate-800 space-y-2">
                <div className="font-semibold text-slate-200">Credit & Term Boundaries:</div>
                <div className="font-mono text-[11px] text-slate-300 space-y-1">
                  <div>Minimum Credit Rating: <strong className="text-emerald-400">{selectedAgreement.eligibilityRule.minRating}+</strong></div>
                  <div>Max Remaining Maturity: <strong>{selectedAgreement.eligibilityRule.maxMaturityYears || 'No Cap'} years</strong></div>
                  <div>Prohibited Jurisdictions: <strong>{selectedAgreement.eligibilityRule.prohibitedCountries.join(', ')}</strong></div>
                </div>
              </div>

              <div className="p-3 rounded bg-slate-950 border border-slate-800 space-y-2">
                <div className="font-semibold text-slate-200">Concentration Ceilings:</div>
                <div className="font-mono text-[11px] text-slate-300 space-y-1">
                  <div>Max Single Issuer: <strong>{(selectedAgreement.eligibilityRule.maxIssuerConcentrationPct * 100).toFixed(0)}%</strong></div>
                  <div>Max Asset Class (e.g. Equities): <strong>{(selectedAgreement.eligibilityRule.maxAssetClassConcentrationPct * 100).toFixed(0)}%</strong></div>
                </div>
              </div>

              <div className="p-3 rounded bg-slate-950 border border-slate-800 space-y-2">
                <div className="font-semibold text-slate-200">FX Mismatch Treatment:</div>
                <div className="font-mono text-[11px] text-slate-300 space-y-1">
                  <div>Currency Mismatch Allowed: <strong className="text-white">{selectedAgreement.eligibilityRule.currencyMismatchAllowed ? 'YES' : 'STRICT NO'}</strong></div>
                  <div>Regulatory Surcharge: <strong className="text-amber-400">+{(selectedAgreement.eligibilityRule.currencyMismatchHaircut * 100).toFixed(1)}% (800 bps)</strong></div>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Rule Simulator */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Play className="w-4 h-4 text-blue-400" />
                  <span>Real-Time Eligibility Pre-Trade Simulator</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Test whether an inventory instrument qualifies under <strong className="text-white">{selectedAgreement.name}</strong>.
                </p>
              </div>

              <button
                onClick={handleRunSimulator}
                className="px-3.5 py-1.5 text-xs font-medium bg-blue-600 hover:bg-blue-500 text-white rounded cursor-pointer"
              >
                Evaluate Rules
              </button>
            </div>

            <div className="flex items-center gap-3">
              <select
                value={simAssetId}
                onChange={(e) => setSimAssetId(e.target.value)}
                className="flex-1 bg-slate-950 border border-slate-800 rounded p-2 text-xs text-slate-200 focus:outline-none"
              >
                {assets.map(a => (
                  <option key={a.id} value={a.id}>
                    {a.name} ({a.isin}) · {a.creditRating} · {a.currency} · {a.assetClass}
                  </option>
                ))}
              </select>
            </div>

            {/* Simulator Output */}
            {simResult && (
              <div className={`p-4 rounded border text-xs space-y-2 ${
                simResult.isEligible 
                  ? 'bg-emerald-950/30 border-emerald-800 text-emerald-200' 
                  : 'bg-red-950/30 border-red-800 text-red-200'
              }`}>
                <div className="flex items-center justify-between font-bold">
                  <span className="flex items-center gap-2">
                    {simResult.isEligible ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-red-400" />}
                    <span>STATUS: {simResult.status}</span>
                  </span>
                  <span className="font-mono text-[10px] text-slate-400">{simResult.ruleVersion}</span>
                </div>

                <div className="space-y-1 font-mono text-[11px] text-slate-300 pt-1">
                  {simResult.reasons.map((r: string, idx: number) => (
                    <div key={idx} className="flex items-start gap-1.5">
                      <span className="text-slate-500">•</span>
                      <span>{r}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Edit Terms Modal */}
      {editingAgreement && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Edit Agreement Terms</h3>
              <button onClick={() => setEditingAgreement(null)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-slate-400">
              Modifying terms creates a new version (v{editingAgreement.version + 1}) and logs an immutable audit event.
            </p>

            <form onSubmit={handleSaveTerms} className="space-y-4">
              <div>
                <label className="text-slate-300 block mb-1">Contractual Threshold (USD)</label>
                <input
                  type="number"
                  value={editingAgreement.threshold}
                  onChange={(e) => setEditingAgreement({ ...editingAgreement, threshold: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 font-mono text-white focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Minimum Transfer Amount (MTA USD)</label>
                <input
                  type="number"
                  value={editingAgreement.minimumTransferAmount}
                  onChange={(e) => setEditingAgreement({ ...editingAgreement, minimumTransferAmount: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 font-mono text-white focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Rounding Increment (USD)</label>
                <input
                  type="number"
                  value={editingAgreement.roundingIncrement}
                  onChange={(e) => setEditingAgreement({ ...editingAgreement, roundingIncrement: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 font-mono text-white focus:outline-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingAgreement(null)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-medium bg-blue-600 hover:bg-blue-500 text-white rounded cursor-pointer"
                >
                  Save & Increment Version
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
