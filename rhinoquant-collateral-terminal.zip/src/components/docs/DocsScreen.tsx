/**
 * RhinoQuant Collateral Management Platform
 * Quantitative Methodology, Architecture, and REST API Specification
 */

import React from 'react';
import { BookOpen, Code, Server, Shield, Layers, FileText } from 'lucide-react';

export const DocsScreen: React.FC = () => {
  return (
    <div className="p-6 space-y-8 max-w-5xl mx-auto text-xs text-slate-300">
      {/* Title */}
      <div className="border-b border-slate-800 pb-4">
        <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-3">
          <BookOpen className="w-5 h-5 text-blue-400" />
          <span>RhinoQuant Quantitative Methodology & Architecture Reference</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Mathematical formulations, valuation conventions, netting workflows, and REST API contract.
        </p>
      </div>

      {/* Section 1: Financial Methodology & Formulas */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold text-white flex items-center gap-2">
          <Layers className="w-4 h-4 text-blue-400" />
          <span>1. Core Mathematical Formulations</span>
        </h2>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div>
            <h3 className="text-xs font-bold text-slate-200">A. Collateral Valuation & Accrued Interest</h3>
            <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
              Fixed income securities are valued using dirty market prices incorporating interest accrued up to the calculation date under the security's contractual day count convention:
            </p>
            <div className="p-3 my-2 rounded bg-slate-950 font-mono text-[11px] text-blue-300 border border-slate-800">
              Dirty Price = Clean Price + (Coupon Rate × YearFraction(LastCoupon, AsOf, DayCount) × 100)
            </div>
            <p className="text-[11px] text-slate-400">
              Dirty Market Value (USD) = (Nominal Quantity × Dirty Price / 100) × FX Rate to USD.
            </p>
          </div>

          <div className="pt-3 border-t border-slate-800">
            <h3 className="text-xs font-bold text-slate-200">B. Regulatory Haircut Schedule (BCBS-IOSCO)</h3>
            <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
              Effective haircut is computed as the composite sum of base haircut, foreign currency mismatch add-on (+800 bps), concentration surcharge (+500 bps), and liquidity discounts:
            </p>
            <div className="p-3 my-2 rounded bg-slate-950 font-mono text-[11px] text-amber-300 border border-slate-800">
              Recognised Value = Dirty Market Value (USD) × (1.0 − Effective Haircut)
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800">
            <h3 className="text-xs font-bold text-slate-200">C. ISDA Netting & Margin Call Determination</h3>
            <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
              Margin calls are determined strictly following the contractual sequence:
            </p>
            <div className="p-3 my-2 rounded bg-slate-950 font-mono text-[11px] text-emerald-300 border border-slate-800 space-y-1">
              <div>1. Total Obligation = Variation Margin + Initial Margin + Independent Amount</div>
              <div>2. Gross Variance = Total Obligation − Net Collateral Held</div>
              <div>3. Unhedged Shortfall = Max(0, Gross Variance − Agreement Threshold)</div>
              <div>4. If Unhedged Shortfall &lt; MTA: Required Transfer = $0.00 (Suppressed)</div>
              <div>5. If Unhedged Shortfall &ge; MTA: Required Transfer = Floor(Unhedged Shortfall / Rounding) × Rounding</div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800">
            <h3 className="text-xs font-bold text-slate-200">D. Repo Interest Accrual (ACT/360 Convention)</h3>
            <div className="p-3 my-2 rounded bg-slate-950 font-mono text-[11px] text-purple-300 border border-slate-800">
              Interest = Principal × Annual Rate × (Actual Days / 360)
            </div>
            <p className="text-[11px] text-slate-400">
              Collateral Coverage Ratio = Recognised Value / (Principal + Accrued Repo Interest).
            </p>
          </div>
        </div>
      </div>

      {/* Section 2: Constrained Optimisation Model */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold text-white flex items-center gap-2">
          <Code className="w-4 h-4 text-emerald-400" />
          <span>2. Constrained Mathematical Optimiser Model</span>
        </h2>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-3">
          <p className="text-[11px] text-slate-400 leading-relaxed">
            The platform models the allocation of multi-asset inventory across $M$ agreements as a mixed-integer constrained optimization problem:
          </p>
          <div className="p-3 rounded bg-slate-950 font-mono text-[11px] text-slate-200 border border-slate-800 space-y-1">
            <div className="text-blue-400 font-bold">Minimize Objective:</div>
            <div>&sum;<sub>i,j</sub> [ OpportunityCost(i) + FXDrag(i,j) + LiquidityDrag(i) ] × x<sub>i,j</sub></div>
            <div className="pt-2 text-amber-400 font-bold">Subject To:</div>
            <div>1. Availability Invariant: &sum;<sub>j</sub> x<sub>i,j</sub> &le; AvailableQuantity<sub>i</sub> &forall; i (Zero double-pledging)</div>
            <div>2. Obligation Fulfillment: &sum;<sub>i</sub> RecognisedValue(i, j, x<sub>i,j</sub>) &ge; Requirement<sub>j</sub> &forall; j</div>
            <div>3. Whitelist Eligibility: x<sub>i,j</sub> = 0 if i &notin; EligibleAssets(Agreement<sub>j</sub>)</div>
            <div>4. Concentration Ceilings: Equities &le; 30%, Single Issuer &le; 25%</div>
            <div>5. Lot-Size Granularity: x<sub>i,j</sub> = k × LotSize<sub>i</sub></div>
          </div>
        </div>
      </div>

      {/* Section 3: REST API Specifications */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold text-white flex items-center gap-2">
          <Server className="w-4 h-4 text-purple-400" />
          <span>3. Documented REST API Endpoints (OpenAPI 3.1)</span>
        </h2>

        <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden font-mono text-[11px]">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-950 border-b border-slate-800 text-slate-400 font-sans uppercase text-[10px]">
                <th className="py-2 px-3">Method</th>
                <th className="py-2 px-3">Endpoint</th>
                <th className="py-2 px-3 font-sans">Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              <tr>
                <td className="py-2.5 px-3 text-blue-400 font-bold">GET</td>
                <td className="py-2.5 px-3 text-slate-200">/api/v1/inventory</td>
                <td className="py-2.5 px-3 text-slate-400 font-sans">Retrieve unencumbered & pledged inventory ledger</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 text-emerald-400 font-bold">POST</td>
                <td className="py-2.5 px-3 text-slate-200">/api/v1/valuation/calculate</td>
                <td className="py-2.5 px-3 text-slate-400 font-sans">Calculate dirty prices, haircuts & recognized values</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 text-emerald-400 font-bold">POST</td>
                <td className="py-2.5 px-3 text-slate-200">/api/v1/margin/calculate</td>
                <td className="py-2.5 px-3 text-slate-400 font-sans">Deterministic margin netting with MTA & rounding</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 text-emerald-400 font-bold">POST</td>
                <td className="py-2.5 px-3 text-slate-200">/api/v1/optimisation/run</td>
                <td className="py-2.5 px-3 text-slate-400 font-sans">Execute constrained mathematical allocation solver</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 text-emerald-400 font-bold">POST</td>
                <td className="py-2.5 px-3 text-slate-200">/api/v1/allocations/{'{id}'}/approve</td>
                <td className="py-2.5 px-3 text-slate-400 font-sans">Approve proposal and generate SWIFT settlement instructions</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 text-blue-400 font-bold">GET</td>
                <td className="py-2.5 px-3 text-slate-200">/api/v1/reconciliation/exceptions</td>
                <td className="py-2.5 px-3 text-slate-400 font-sans">Retrieve open custody and settlement variances</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 text-emerald-400 font-bold">POST</td>
                <td className="py-2.5 px-3 text-slate-200">/api/v1/scenarios/run</td>
                <td className="py-2.5 px-3 text-slate-400 font-sans">Execute multi-factor stress scenario simulation</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 text-blue-400 font-bold">GET</td>
                <td className="py-2.5 px-3 text-slate-200">/api/v1/audit/events</td>
                <td className="py-2.5 px-3 text-slate-400 font-sans">Query immutable governance audit event chain</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
