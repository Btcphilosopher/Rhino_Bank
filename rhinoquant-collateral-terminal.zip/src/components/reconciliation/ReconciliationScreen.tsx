/**
 * RhinoQuant Collateral Management Platform
 * Reconciliation & Settlement Console - Custody Ledger Verification & Exception Management
 */

import React, { useState } from 'react';
import { useCollateral } from '../../context/CollateralContext';
import { ReconciliationRecord } from '../../types/models';
import { 
  FileCheck2, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Search, 
  X, 
  ArrowRight,
  ShieldAlert,
  Send,
  Building
} from 'lucide-react';

export const ReconciliationScreen: React.FC = () => {
  const { 
    reconciliationRecords, 
    settlementInstructions, 
    assets, 
    resolveException,
    runPortfolioEODCycle
  } = useCollateral();

  const [resolvingRecord, setResolvingRecord] = useState<ReconciliationRecord | null>(null);
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [activeTab, setActiveTab] = useState<'EXCEPTIONS' | 'SETTLEMENTS'>('EXCEPTIONS');

  const assetMap = React.useMemo(() => new Map(assets.map(a => [a.id, a])), [assets]);

  const openExceptions = reconciliationRecords.filter(r => r.status === 'UNMATCHED' && r.resolutionStatus !== 'RESOLVED');
  const matchedRecords = reconciliationRecords.filter(r => r.status === 'MATCHED');

  const handleConfirmResolve = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resolvingRecord) return;
    resolveException(resolvingRecord.id, resolutionNotes || 'Investigated and matched against unbooked pending transfer.');
    setResolvingRecord(null);
    setResolutionNotes('');
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-3">
            <span>Reconciliation & Settlement Console</span>
            <span className="text-xs font-normal text-amber-400 font-mono">
              {openExceptions.length} OPEN EXCEPTIONS · SIMULATED CUSTODIAN FEEDS
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Reconciles internal position balances against external custody statements from Euroclear, Clearstream, DTCC, and BNY Mellon.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={runPortfolioEODCycle}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium bg-blue-600 hover:bg-blue-500 text-white rounded transition-colors cursor-pointer"
          >
            <FileCheck2 className="w-3.5 h-3.5" />
            <span>Re-run Reconciliation Feed</span>
          </button>
        </div>
      </div>

      {/* Custodian Adapter Status Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded p-3 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building className="w-4 h-4 text-slate-400" />
            <div>
              <div className="font-semibold text-slate-200">DTCC Fedwire</div>
              <div className="text-[10px] text-slate-500 font-mono">Simulated API · 08:00 UTC</div>
            </div>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono">ONLINE</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded p-3 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building className="w-4 h-4 text-slate-400" />
            <div>
              <div className="font-semibold text-slate-200">Euroclear Crest</div>
              <div className="text-[10px] text-slate-500 font-mono">Simulated API · 08:00 UTC</div>
            </div>
          </div>
          <span className="text-[10px] text-amber-400 font-mono">1 VARIANCE</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded p-3 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building className="w-4 h-4 text-slate-400" />
            <div>
              <div className="font-semibold text-slate-200">Clearstream Banking</div>
              <div className="text-[10px] text-slate-500 font-mono">Simulated API · 08:00 UTC</div>
            </div>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono">ONLINE</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded p-3 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building className="w-4 h-4 text-slate-400" />
            <div>
              <div className="font-semibold text-slate-200">BNY Mellon Tri-Party</div>
              <div className="text-[10px] text-slate-500 font-mono">Simulated API · 08:00 UTC</div>
            </div>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono">ONLINE</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-1 rounded-lg text-xs">
        <button
          onClick={() => setActiveTab('EXCEPTIONS')}
          className={`px-3 py-1.5 rounded transition-colors cursor-pointer ${
            activeTab === 'EXCEPTIONS' ? 'bg-slate-800 text-blue-400 font-semibold' : 'text-slate-400 hover:text-white'
          }`}
        >
          Custody Discrepancies & Exceptions ({openExceptions.length})
        </button>
        <button
          onClick={() => setActiveTab('SETTLEMENTS')}
          className={`px-3 py-1.5 rounded transition-colors cursor-pointer ${
            activeTab === 'SETTLEMENTS' ? 'bg-slate-800 text-blue-400 font-semibold' : 'text-slate-400 hover:text-white'
          }`}
        >
          Transmitted Settlement Instructions ({settlementInstructions.length})
        </button>
      </div>

      {activeTab === 'EXCEPTIONS' ? (
        /* Exceptions Table */
        <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                  <th className="py-2.5 px-3">Exception ID / Date</th>
                  <th className="py-2.5 px-3">Custodian</th>
                  <th className="py-2.5 px-3">Asset</th>
                  <th className="py-2.5 px-3 text-right">Internal Ledger</th>
                  <th className="py-2.5 px-3 text-right">Custodian Stmt</th>
                  <th className="py-2.5 px-3 text-right">Variance (Units)</th>
                  <th className="py-2.5 px-3 text-right">Exposure (USD)</th>
                  <th className="py-2.5 px-3">Severity / Age</th>
                  <th className="py-2.5 px-3">Resolution Status</th>
                  <th className="py-2.5 px-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-[11px] tabular-nums">
                {reconciliationRecords.map(rec => {
                  const asset = assetMap.get(rec.assetId);

                  return (
                    <tr key={rec.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-3 font-sans">
                        <div className="font-semibold text-slate-200">{rec.id}</div>
                        <div className="text-[10px] font-mono text-slate-500">{rec.reconciliationDate}</div>
                      </td>

                      <td className="py-3 px-3 font-sans font-semibold text-slate-300">
                        {rec.targetSystem}
                      </td>

                      <td className="py-3 px-3 font-sans">
                        <div className="text-slate-200 font-semibold">{asset?.ticker || asset?.name}</div>
                        <div className="text-[10px] text-slate-500 font-mono">{asset?.isin}</div>
                      </td>

                      <td className="py-3 px-3 text-right text-slate-300">
                        {rec.internalQuantity.toLocaleString()}
                      </td>

                      <td className="py-3 px-3 text-right text-slate-300">
                        {rec.externalQuantity.toLocaleString()}
                      </td>

                      <td className="py-3 px-3 text-right font-bold text-amber-400">
                        {rec.differenceQuantity > 0 ? `+${rec.differenceQuantity.toLocaleString()}` : rec.differenceQuantity.toLocaleString()}
                      </td>

                      <td className="py-3 px-3 text-right font-bold text-white">
                        ${Math.round(rec.differenceMarketValueUSD).toLocaleString()}
                      </td>

                      <td className="py-3 px-3 font-sans">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          rec.severity === 'CRITICAL' ? 'bg-red-950/60 text-red-400 border border-red-900/60' :
                          rec.severity === 'HIGH' ? 'bg-amber-950/60 text-amber-400 border border-amber-900/60' :
                          'bg-slate-800 text-slate-400'
                        }`}>
                          {rec.severity} · {rec.ageDays}d
                        </span>
                      </td>

                      <td className="py-3 px-3 font-sans">
                        <span className={`text-[10px] font-semibold ${
                          rec.resolutionStatus === 'RESOLVED' ? 'text-emerald-400' : 'text-amber-400'
                        }`}>
                          {rec.resolutionStatus}
                        </span>
                      </td>

                      <td className="py-3 px-3 text-center font-sans">
                        {rec.resolutionStatus !== 'RESOLVED' ? (
                          <button
                            onClick={() => setResolvingRecord(rec)}
                            className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-medium transition-colors cursor-pointer"
                          >
                            Resolve
                          </button>
                        ) : (
                          <span className="text-[10px] text-slate-500">Resolved</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Settlements Queue */
        <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                  <th className="py-2.5 px-3">Instruction Ref</th>
                  <th className="py-2.5 px-3">Direction</th>
                  <th className="py-2.5 px-3">Asset ISIN</th>
                  <th className="py-2.5 px-3 text-right">Quantity</th>
                  <th className="py-2.5 px-3">Custodian</th>
                  <th className="py-2.5 px-3">Counterparty BIC</th>
                  <th className="py-2.5 px-3">Intended Settle Date</th>
                  <th className="py-2.5 px-3">SWIFT Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-[11px] tabular-nums">
                {settlementInstructions.map(settle => {
                  const asset = assetMap.get(settle.assetId);
                  return (
                    <tr key={settle.id} className="hover:bg-slate-800/40">
                      <td className="py-3 px-3 font-sans font-semibold text-slate-200">
                        {settle.instructionRef}
                      </td>
                      <td className="py-3 px-3 font-sans text-slate-300">
                        {settle.direction.replace(/_/g, ' ')}
                      </td>
                      <td className="py-3 px-3 font-sans">
                        <div className="text-slate-200 font-semibold">{asset?.ticker || asset?.name}</div>
                        <div className="text-[10px] text-slate-500 font-mono">{asset?.isin}</div>
                      </td>
                      <td className="py-3 px-3 text-right text-white font-bold">
                        {settle.quantity.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 font-sans text-slate-400">
                        {settle.custodian}
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-300">
                        {settle.counterpartyBic}
                      </td>
                      <td className="py-3 px-3 text-slate-400">
                        {settle.intendedSettlementDate}
                      </td>
                      <td className="py-3 px-3 font-sans">
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-950 text-blue-400 border border-blue-900/60">
                          {settle.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Resolve Exception Modal */}
      {resolvingRecord && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Resolve Custody Discrepancy</h3>
              <button onClick={() => setResolvingRecord(null)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 rounded bg-slate-950 border border-slate-800 space-y-1 font-mono text-[11px]">
              <div>Target: {resolvingRecord.targetSystem}</div>
              <div>Internal: {resolvingRecord.internalQuantity.toLocaleString()} vs External: {resolvingRecord.externalQuantity.toLocaleString()}</div>
              <div>Variance Exposure: ${Math.round(resolvingRecord.differenceMarketValueUSD).toLocaleString()}</div>
            </div>

            <form onSubmit={handleConfirmResolve} className="space-y-4">
              <div>
                <label className="text-slate-300 block mb-1">Resolution Explanation & Audit Rationale</label>
                <textarea
                  value={resolutionNotes}
                  onChange={(e) => setResolutionNotes(e.target.value)}
                  placeholder="e.g. Confirmed unbooked incoming pledge transfer from DTCC; ledger reconciled."
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white h-20 focus:outline-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setResolvingRecord(null)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-medium bg-blue-600 hover:bg-blue-500 text-white rounded cursor-pointer"
                >
                  Confirm & Mark Resolved
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
