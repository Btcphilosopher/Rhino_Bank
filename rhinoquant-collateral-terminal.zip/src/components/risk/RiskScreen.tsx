/**
 * RhinoQuant Collateral Management Platform
 * Stress Testing & Scenario Analysis - Deterministic Market & Haircut Shocks
 */

import React, { useState, useEffect } from 'react';
import { useCollateral } from '../../context/CollateralContext';
import { PRESET_SCENARIOS } from '../../engines/scenarioEngine';
import { StressScenario } from '../../types/models';
import { 
  Activity, 
  TrendingDown, 
  AlertOctagon, 
  Flame, 
  DollarSign, 
  ShieldAlert, 
  Play, 
  Layers,
  ArrowRight
} from 'lucide-react';

export const RiskScreen: React.FC = () => {
  const { 
    currentScenario, 
    activeStressResult, 
    selectAndRunStressScenario 
  } = useCollateral();

  const [selectedScen, setSelectedScen] = useState<StressScenario>(currentScenario);

  // Run on mount if no stress result
  useEffect(() => {
    if (!activeStressResult) {
      selectAndRunStressScenario(selectedScen);
    }
  }, [activeStressResult, selectAndRunStressScenario, selectedScen]);

  const handleRun = (scen: StressScenario) => {
    setSelectedScen(scen);
    selectAndRunStressScenario(scen);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-3">
            <span>Deterministic Stress Testing & Scenario Simulator</span>
            <span className="text-xs font-normal text-amber-400 font-mono">
              MULTI-FACTOR RISK ENGINE
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Simulates instantaneous asset price, yield curve, credit spread, FX, and regulatory haircut shocks across all counterparties.
          </p>
        </div>

        <div className="text-xs text-slate-500 font-mono">
          Model: DETERMINISTIC_SHOCK_V3 · Not calibrated as statistical VaR
        </div>
      </div>

      {/* Scenario Chooser Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {PRESET_SCENARIOS.map(scen => {
          const isSelected = selectedScen.id === scen.id;
          return (
            <button
              key={scen.id}
              onClick={() => handleRun(scen)}
              className={`p-3 rounded-lg border text-left transition-all cursor-pointer flex flex-col justify-between ${
                isSelected
                  ? 'bg-blue-950/50 border-blue-600 text-white shadow-xs'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <div>
                <div className="font-semibold text-xs text-slate-200">{scen.name}</div>
                <div className="text-[11px] text-slate-500 line-clamp-2 mt-1">
                  {scen.description}
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between text-[10px] font-mono text-slate-400 border-t border-slate-800/80 pt-2">
                <span>Shocks: {scen.sovereignYieldShockBps > 0 ? `+${scen.sovereignYieldShockBps}bp` : `${scen.sovereignYieldShockBps}bp`}</span>
                <Play className="w-3 h-3 text-blue-400" />
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Scenario Parameters Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
        <div className="flex items-center justify-between mb-3 text-xs">
          <span className="font-semibold text-slate-200">Active Shock Parameters: {selectedScen.name}</span>
          <span className="text-[11px] text-slate-400 font-mono">Instantaneous Market Move</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs font-mono">
          <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
            <div className="text-slate-500 text-[10px]">Sovereign Yields</div>
            <div className="text-sm font-bold text-white mt-0.5">
              {selectedScen.sovereignYieldShockBps > 0 ? `+${selectedScen.sovereignYieldShockBps}` : selectedScen.sovereignYieldShockBps} bps
            </div>
          </div>

          <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
            <div className="text-slate-500 text-[10px]">Corporate Spreads</div>
            <div className="text-sm font-bold text-white mt-0.5">
              +{selectedScen.corpSpreadShockBps} bps
            </div>
          </div>

          <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
            <div className="text-slate-500 text-[10px]">Equity Valuation</div>
            <div className="text-sm font-bold text-red-400 mt-0.5">
              {(selectedScen.equityShockPct * 100).toFixed(0)}%
            </div>
          </div>

          <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
            <div className="text-slate-500 text-[10px]">Non-USD FX Shock</div>
            <div className="text-sm font-bold text-amber-400 mt-0.5">
              {(selectedScen.fxShockUSDDepreciationPct * 100).toFixed(0)}%
            </div>
          </div>

          <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
            <div className="text-slate-500 text-[10px]">Haircut Add-on</div>
            <div className="text-sm font-bold text-amber-400 mt-0.5">
              +{(selectedScen.haircutShockAddOnPct * 100).toFixed(1)}%
            </div>
          </div>

          <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
            <div className="text-slate-500 text-[10px]">BBB Downgrade</div>
            <div className="text-sm font-bold text-white mt-0.5">
              {selectedScen.downgradeBBBToHY ? 'BBB &rarr; HY (BB)' : 'None'}
            </div>
          </div>
        </div>
      </div>

      {/* Stress Results Display */}
      {activeStressResult && (
        <div className="space-y-6">
          {/* Summary KPIs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Collateral Value Impact</div>
              <div className="text-2xl font-bold font-mono text-red-400 mt-1">
                -${(activeStressResult.collateralValueDropUSD / 1_000_000).toFixed(2)}M
              </div>
              <div className="text-[11px] text-slate-500 mt-1 font-mono">
                -{(activeStressResult.collateralValueDropPct * 100).toFixed(1)}% drop in recognised value
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Additional Margin Required</div>
              <div className="text-2xl font-bold font-mono text-amber-400 mt-1">
                +${(activeStressResult.additionalLiquidityRequiredUSD / 1_000_000).toFixed(2)}M
              </div>
              <div className="text-[11px] text-slate-500 mt-1">Immediate liquidity draw</div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Stressed Margin Deficit</div>
              <div className="text-2xl font-bold font-mono text-white mt-1">
                ${(activeStressResult.stressedMarginDeficitUSD / 1_000_000).toFixed(2)}M
              </div>
              <div className="text-[11px] text-slate-500 mt-1 font-mono">
                Base deficit: ${(activeStressResult.baseMarginDeficitUSD / 1_000_000).toFixed(2)}M
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Trapped / Ineligible Inventory</div>
              <div className="text-2xl font-bold font-mono text-red-400 mt-1">
                ${(activeStressResult.trappedInventoryValueUSD / 1_000_000).toFixed(1)}M
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                {activeStressResult.ineligiblePositionsCount} positions downgraded
              </div>
            </div>
          </div>

          {/* Counterparty-level Impact Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
            <div className="px-4 py-3 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-200">Counterparty Stressed Margin Vulnerability Matrix</span>
              <span className="text-slate-500 font-mono text-[11px]">Bilateral & Cleared Netting</span>
            </div>

            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950/40 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px]">
                  <th className="py-2.5 px-3">Counterparty Name</th>
                  <th className="py-2.5 px-3 text-right">Additional Margin Required (USD)</th>
                  <th className="py-2.5 px-3">Stress Risk Threshold Flag</th>
                  <th className="py-2.5 px-3">Mitigation Recommendation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-[11px] tabular-nums">
                {activeStressResult.counterpartyImpacts.map(impact => (
                  <tr key={impact.counterpartyId} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3 font-sans font-semibold text-slate-200">
                      {impact.counterpartyName}
                    </td>

                    <td className="py-2.5 px-3 text-right font-bold text-white">
                      +${impact.additionalCallRequiredUSD.toLocaleString()}
                    </td>

                    <td className="py-2.5 px-3 font-sans">
                      {impact.breachFlag ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-950/60 text-red-400 border border-red-900/60">
                          MATERIAL BREACH (&gt;$5M)
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-emerald-950/60 text-emerald-400 border border-emerald-900/40">
                          CONTAINED
                        </span>
                      )}
                    </td>

                    <td className="py-2.5 px-3 font-sans text-slate-400 text-[11px]">
                      {impact.breachFlag 
                        ? 'Pre-fund settlement account with USD cash or pre-pledge Treasury Bills.' 
                        : 'Covered by existing unencumbered sovereign buffer.'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
