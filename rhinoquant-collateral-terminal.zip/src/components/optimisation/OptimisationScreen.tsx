/**
 * RhinoQuant Collateral Management Platform
 * Collateral Optimisation Workbench - Multi-Agreement Mathematical Allocation Solver
 */

import React, { useState } from 'react';
import { useCollateral } from '../../context/CollateralContext';
import { 
  SlidersHorizontal, 
  Play, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  DollarSign, 
  ShieldAlert, 
  Layers, 
  Sparkles,
  TrendingUp,
  FileCheck2,
  Lock
} from 'lucide-react';

export const OptimisationScreen: React.FC = () => {
  const { 
    agreements, 
    inventory, 
    assets, 
    marginCalls, 
    activeOptimizationRun, 
    runOptimisationSolver, 
    approveOptimisationPlan,
    userRole
  } = useCollateral();

  // Selection states
  const [selectedAgreements, setSelectedAgreements] = useState<string[]>(() => 
    agreements.slice(0, 3).map(a => a.id)
  );
  const [objective, setObjective] = useState<'MINIMIZE_FUNDING_COST' | 'PRESERVE_LIQUIDITY' | 'MINIMIZE_FX_FRICTION'>('MINIMIZE_FUNDING_COST');
  const [maxEquityCap, setMaxEquityCap] = useState(30);
  const [maxIssuerCap, setMaxIssuerCap] = useState(25);
  const [isSolving, setIsSolving] = useState(false);
  const [approvalMessage, setApprovalMessage] = useState<string | null>(null);

  const assetMap = React.useMemo(() => new Map(assets.map(a => [a.id, a])), [assets]);
  const agreementMap = React.useMemo(() => new Map(agreements.map(a => [a.id, a])), [agreements]);

  const toggleAgreement = (id: string) => {
    if (selectedAgreements.includes(id)) {
      if (selectedAgreements.length > 1) {
        setSelectedAgreements(prev => prev.filter(a => a !== id));
      }
    } else {
      setSelectedAgreements(prev => [...prev, id]);
    }
  };

  const handleRunSolver = () => {
    setIsSolving(true);
    setApprovalMessage(null);
    setTimeout(() => {
      runOptimisationSolver(selectedAgreements, objective);
      setIsSolving(false);
    }, 400);
  };

  const handleApprove = () => {
    if (!activeOptimizationRun) return;
    const res = approveOptimisationPlan(activeOptimizationRun.id);
    setApprovalMessage(res.message);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-3">
            <span>Collateral Optimisation Workbench</span>
            <span className="text-xs font-normal text-blue-400 font-mono">
              CONSTRAINED LINEAR SOLVER · MULTI-AGREEMENT
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Simultaneously allocates inventory across bilateral and cleared obligations to minimize funding drag and preserve cash liquidity.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleRunSolver}
            disabled={isSolving}
            className="flex items-center gap-2 px-4 py-2 text-xs font-medium bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 text-white rounded transition-colors cursor-pointer shadow-xs"
          >
            <Play className={`w-3.5 h-3.5 ${isSolving ? 'animate-spin' : ''}`} />
            <span>{isSolving ? 'Solving Constraints...' : 'Run Optimisation Solver'}</span>
          </button>
        </div>
      </div>

      {/* Configuration Strip */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Col 1: Agreement Obligations Selection */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold text-slate-200">1. Target Margin Obligations</h3>
            <span className="text-[11px] text-slate-500 font-mono">{selectedAgreements.length} Selected</span>
          </div>

          <div className="space-y-2">
            {agreements.map(ag => {
              const call = marginCalls.find(c => c.agreementId === ag.id && c.status !== 'SETTLED');
              const reqUSD = call ? call.requiredTransferAmountUSD : 2500000;
              const isSelected = selectedAgreements.includes(ag.id);

              return (
                <div
                  key={ag.id}
                  onClick={() => toggleAgreement(ag.id)}
                  className={`p-2.5 rounded border text-xs cursor-pointer transition-all flex items-center justify-between ${
                    isSelected 
                      ? 'bg-blue-950/40 border-blue-700/60 text-white' 
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div>
                    <div className="font-semibold">{ag.name}</div>
                    <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                      Base: {ag.baseCurrency} · MTA: ${ag.minimumTransferAmount.toLocaleString()}
                    </div>
                  </div>
                  <div className="text-right font-mono text-[11px]">
                    <div className="text-slate-300 font-bold">${reqUSD.toLocaleString()}</div>
                    <div className="text-[10px] text-blue-400">Required</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Col 2: Objective Function */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
          <h3 className="text-xs font-semibold text-slate-200">2. Objective Function</h3>

          <div className="space-y-2.5">
            <div
              onClick={() => setObjective('MINIMIZE_FUNDING_COST')}
              className={`p-3 rounded border text-xs cursor-pointer transition-all ${
                objective === 'MINIMIZE_FUNDING_COST'
                  ? 'bg-blue-950/40 border-blue-600 text-white'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              <div className="font-semibold flex items-center justify-between">
                <span>Minimise Funding Drag (Cheapest to Deliver)</span>
                {objective === 'MINIMIZE_FUNDING_COST' && <CheckCircle2 className="w-4 h-4 text-blue-400" />}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Allocates lowest opportunity cost bonds & non-cash assets first, preserving high-yielding cash.
              </p>
            </div>

            <div
              onClick={() => setObjective('PRESERVE_LIQUIDITY')}
              className={`p-3 rounded border text-xs cursor-pointer transition-all ${
                objective === 'PRESERVE_LIQUIDITY'
                  ? 'bg-blue-950/40 border-blue-600 text-white'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              <div className="font-semibold flex items-center justify-between">
                <span>Preserve High-Velocity Liquidity</span>
                {objective === 'PRESERVE_LIQUIDITY' && <CheckCircle2 className="w-4 h-4 text-blue-400" />}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Heavily penalizes posting cash and on-the-run benchmark Treasuries to retain intraday buffer.
              </p>
            </div>

            <div
              onClick={() => setObjective('MINIMIZE_FX_FRICTION')}
              className={`p-3 rounded border text-xs cursor-pointer transition-all ${
                objective === 'MINIMIZE_FX_FRICTION'
                  ? 'bg-blue-950/40 border-blue-600 text-white'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              <div className="font-semibold flex items-center justify-between">
                <span>Minimise FX Mismatch & Friction</span>
                {objective === 'MINIMIZE_FX_FRICTION' && <CheckCircle2 className="w-4 h-4 text-blue-400" />}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Matches collateral currency directly to agreement base currency to bypass the +8% regulatory haircut.
              </p>
            </div>
          </div>
        </div>

        {/* Col 3: Mathematical Constraints */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
          <h3 className="text-xs font-semibold text-slate-200">3. Solvency & Concentration Limits</h3>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-slate-300">Max Equity Concentration</span>
                <span className="font-mono text-blue-400 font-bold">{maxEquityCap}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="50"
                step="5"
                value={maxEquityCap}
                onChange={(e) => setMaxEquityCap(Number(e.target.value))}
                className="w-full accent-blue-600"
              />
              <span className="text-[10px] text-slate-500">Cap on equity/ETF collateral per portfolio</span>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-slate-300">Max Single-Issuer Limit</span>
                <span className="font-mono text-blue-400 font-bold">{maxIssuerCap}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="40"
                step="5"
                value={maxIssuerCap}
                onChange={(e) => setMaxIssuerCap(Number(e.target.value))}
                className="w-full accent-blue-600"
              />
              <span className="text-[10px] text-slate-500">Excludes domestic sovereign treasuries</span>
            </div>

            <div className="p-3 rounded bg-slate-950/80 border border-slate-800 space-y-1 text-[11px]">
              <div className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                <span>Hard Invariants Enforced:</span>
              </div>
              <ul className="text-slate-400 space-y-0.5 list-disc pl-4 text-[10px]">
                <li>Zero double-pledging across agreements</li>
                <li>Strict ISDA/GMRA eligibility whitelist</li>
                <li>Lot size and minimum denomination rounding</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Solver Results Section */}
      {activeOptimizationRun ? (
        <div className="space-y-6">
          {/* Top Solver Outcome Banner */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400 font-bold font-mono">
                  OPT
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>Optimal Allocation Plan Proposed</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800">
                      STATUS: {activeOptimizationRun.status}
                    </span>
                  </h3>
                  <div className="text-xs text-slate-400 font-mono mt-0.5">
                    Plan Ref: {activeOptimizationRun.id} · Timestamp: {activeOptimizationRun.timestamp}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                {activeOptimizationRun.approved ? (
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded bg-emerald-950/60 border border-emerald-800 text-xs font-semibold text-emerald-300 font-mono">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>APPROVED ({activeOptimizationRun.approvedBy})</span>
                  </div>
                ) : (
                  <button
                    onClick={handleApprove}
                    className="flex items-center gap-2 px-4 py-2 text-xs font-medium bg-emerald-600 hover:bg-emerald-500 text-white rounded transition-colors cursor-pointer shadow-xs"
                  >
                    <FileCheck2 className="w-4 h-4" />
                    <span>Approve & Generate Settlement Instructions</span>
                  </button>
                )}
              </div>
            </div>

            {approvalMessage && (
              <div className="mt-4 p-3 rounded bg-blue-950/60 border border-blue-800 text-xs text-blue-200">
                {approvalMessage}
              </div>
            )}

            {/* Metrics Delta Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-4">
              <div className="p-3 rounded bg-slate-950 border border-slate-800 text-xs">
                <div className="text-slate-400">Total Recognised Collateral Allocated</div>
                <div className="text-xl font-bold font-mono text-white mt-1">
                  ${Math.round(activeOptimizationRun.totalAllocatedRecognisedUSD).toLocaleString()}
                </div>
                <div className="text-[10px] text-slate-500 mt-1">
                  Target: ${activeOptimizationRun.totalRequirementUSD.toLocaleString()} (100% satisfied)
                </div>
              </div>

              <div className="p-3 rounded bg-slate-950 border border-slate-800 text-xs">
                <div className="text-slate-400">Estimated Annualised Funding Savings</div>
                <div className="text-xl font-bold font-mono text-emerald-400 mt-1">
                  +${Math.round(activeOptimizationRun.estimatedSavingsUSD).toLocaleString()} / yr
                </div>
                <div className="text-[10px] text-emerald-500/80 mt-1">
                  ~${Math.round(activeOptimizationRun.estimatedSavingsUSD / 360).toLocaleString()} per day saved vs cash
                </div>
              </div>

              <div className="p-3 rounded bg-slate-950 border border-slate-800 text-xs">
                <div className="text-slate-400">Blended Funding Cost</div>
                <div className="text-xl font-bold font-mono text-blue-400 mt-1">
                  {(activeOptimizationRun.totalAllocatedRecognisedUSD > 0 
                    ? (activeOptimizationRun.totalOpportunityCostUSD / activeOptimizationRun.totalAllocatedRecognisedUSD) * 10000 
                    : 0).toFixed(0)} bps
                </div>
                <div className="text-[10px] text-slate-500 mt-1">
                  Baseline cash cost: 525 bps
                </div>
              </div>
            </div>
          </div>

          {/* Allocation Breakdown by Agreement */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-white">Recommended Allocation Schedule by Agreement</h3>

            {activeOptimizationRun.allocatedItems.map(agAlloc => {
              const ag = agreementMap.get(agAlloc.agreementId);
              const subtotalRecUSD = agAlloc.items.reduce((s, it) => s + it.recognisedValueUSD, 0);

              return (
                <div key={agAlloc.agreementId} className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
                  <div className="px-4 py-3 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-bold text-slate-200">{ag?.name}</span>
                      <span className="text-slate-500 font-mono ml-2">({ag?.code})</span>
                    </div>
                    <div className="font-mono text-slate-300">
                      Subtotal Recognised: <strong className="text-emerald-400">${Math.round(subtotalRecUSD).toLocaleString()}</strong>
                    </div>
                  </div>

                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-950/40 border-b border-slate-800/80 text-slate-400 font-semibold uppercase text-[10px]">
                        <th className="py-2 px-3">Selected Instrument</th>
                        <th className="py-2 px-3 text-right">Allocated Nominal</th>
                        <th className="py-2 px-3 text-right">Dirty MV USD</th>
                        <th className="py-2 px-3 text-right">Haircut</th>
                        <th className="py-2 px-3 text-right">Recognised Collateral</th>
                        <th className="py-2 px-3 text-right">Funding Drag</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-mono text-[11px] tabular-nums">
                      {agAlloc.items.map((item, idx) => {
                        const asset = assetMap.get(item.assetId);
                        return (
                          <tr key={idx} className="hover:bg-slate-800/40">
                            <td className="py-2.5 px-3 font-sans">
                              <div className="font-semibold text-slate-200">{asset?.ticker || asset?.name}</div>
                              <div className="text-[10px] font-mono text-slate-500">{asset?.isin} · {asset?.assetClass}</div>
                            </td>
                            <td className="py-2.5 px-3 text-right text-slate-300">
                              {item.allocatedNominal.toLocaleString()}
                            </td>
                            <td className="py-2.5 px-3 text-right text-slate-400">
                              ${Math.round(item.dirtyMarketValueUSD).toLocaleString()}
                            </td>
                            <td className="py-2.5 px-3 text-right text-amber-400">
                              {(item.effectiveHaircut * 100).toFixed(1)}%
                            </td>
                            <td className="py-2.5 px-3 text-right font-bold text-white">
                              ${Math.round(item.recognisedValueUSD).toLocaleString()}
                            </td>
                            <td className="py-2.5 px-3 text-right text-slate-400">
                              {item.fundingCostBps} bps (${Math.round(item.costUSD).toLocaleString()})
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              );
            })}
          </div>

          {/* Constraints and Rejected Alternatives */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Binding Constraints */}
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2.5 text-xs">
              <h4 className="font-semibold text-slate-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-blue-400" />
                <span>Binding Model Constraints</span>
              </h4>
              {activeOptimizationRun.bindingConstraints.length > 0 ? (
                <ul className="space-y-1.5 text-slate-300 font-mono text-[11px]">
                  {activeOptimizationRun.bindingConstraints.map((bc, i) => (
                    <li key={i} className="p-2 rounded bg-slate-950/60 border border-slate-800">
                      {bc}
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="text-slate-500 italic font-mono text-[11px]">
                  All inventory unconstrained; global minimum attained.
                </div>
              )}
            </div>

            {/* Rejected Alternatives */}
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2.5 text-xs">
              <h4 className="font-semibold text-slate-200 flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-amber-400" />
                <span>Rejected Inventory Alternatives & Reasons</span>
              </h4>
              <div className="space-y-1.5 text-slate-300 font-mono text-[11px]">
                {activeOptimizationRun.rejectedInventoryReasons.slice(0, 4).map((rej, i) => {
                  const asset = assetMap.get(rej.assetId);
                  return (
                    <div key={i} className="p-2 rounded bg-slate-950/60 border border-slate-800">
                      <span className="text-slate-400">{asset?.ticker || rej.assetId}: </span>
                      <span className="text-amber-300/90">{rej.reason}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Empty State */
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center mx-auto text-blue-400">
            <SlidersHorizontal className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-white">No Optimisation Plan Generated Yet</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Select target agreements and objective above, then click <strong className="text-blue-400">Run Optimisation Solver</strong> to calculate the lowest-cost constrained allocation.
          </p>
        </div>
      )}
    </div>
  );
};
