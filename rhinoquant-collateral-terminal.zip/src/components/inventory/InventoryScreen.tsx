/**
 * RhinoQuant Collateral Management Platform
 * Inventory Screen - Complete Asset Master & Position Management
 */

import React, { useState, useMemo } from 'react';
import { useCollateral } from '../../context/CollateralContext';
import { AssetClass, Currency, CustodyLocation, InventoryPosition, AssetMaster } from '../../types/models';
import { calculateValuation } from '../../engines/valuationEngine';
import { 
  Search, 
  Filter, 
  Download, 
  Lock, 
  Unlock, 
  Info, 
  Layers, 
  ChevronRight, 
  X, 
  CheckCircle2, 
  AlertCircle,
  Edit3
} from 'lucide-react';

export const InventoryScreen: React.FC = () => {
  const { 
    inventory, 
    assets, 
    marketData, 
    addPositionPledgeAdjustment, 
    freezePositionDispute,
    userRole
  } = useCollateral();

  // Search & filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAssetClass, setSelectedAssetClass] = useState<string>('ALL');
  const [selectedCurrency, setSelectedCurrency] = useState<string>('ALL');
  const [selectedCustodian, setSelectedCustodian] = useState<string>('ALL');
  const [onlyAvailable, setOnlyAvailable] = useState(false);

  // Modal / Drawer states
  const [inspectingPosition, setInspectingPosition] = useState<{ pos: InventoryPosition; asset: AssetMaster } | null>(null);
  const [editingPledgePos, setEditingPledgePos] = useState<InventoryPosition | null>(null);
  const [newPledgeQty, setNewPledgeQty] = useState<number>(0);
  const [pledgeRationale, setPledgeRationale] = useState('');
  const [pledgeError, setPledgeError] = useState<string | null>(null);

  // Position locking modal
  const [lockingPos, setLockingPos] = useState<InventoryPosition | null>(null);
  const [lockAmount, setLockAmount] = useState<number>(0);
  const [lockReason, setLockReason] = useState('');

  const assetMap = useMemo(() => new Map(assets.map(a => [a.id, a])), [assets]);

  // Filtered rows
  const filteredPositions = useMemo(() => {
    return inventory.filter(pos => {
      const asset = assetMap.get(pos.assetId);
      if (!asset) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match = 
          asset.name.toLowerCase().includes(q) ||
          asset.isin.toLowerCase().includes(q) ||
          (asset.ticker && asset.ticker.toLowerCase().includes(q)) ||
          asset.issuer.toLowerCase().includes(q) ||
          pos.accountNumber.toLowerCase().includes(q);
        if (!match) return false;
      }

      // Filters
      if (selectedAssetClass !== 'ALL' && asset.assetClass !== selectedAssetClass) return false;
      if (selectedCurrency !== 'ALL' && asset.currency !== selectedCurrency) return false;
      if (selectedCustodian !== 'ALL' && pos.custodian !== selectedCustodian) return false;

      const avail = pos.totalQuantity - pos.pledgedQuantity - pos.pendingDeliveryQuantity - pos.frozenDisputedQuantity;
      if (onlyAvailable && avail <= 0) return false;

      return true;
    });
  }, [inventory, assetMap, searchQuery, selectedAssetClass, selectedCurrency, selectedCustodian, onlyAvailable]);

  // Export CSV
  const handleExportCSV = () => {
    const headers = [
      'Position ID', 'ISIN', 'Ticker', 'Asset Name', 'Asset Class', 'Currency', 
      'Rating', 'Custodian', 'Total Quantity', 'Pledged Quantity', 'Pending Delivery', 
      'Pending Return', 'Frozen Quantity', 'Available Quantity', 'Clean Price', 
      'Dirty Price', 'Dirty Market Value USD', 'Effective Haircut %', 'Recognised Collateral USD'
    ];

    const rows = filteredPositions.map(pos => {
      const asset = assetMap.get(pos.assetId)!;
      const mkt = marketData[asset.id];
      const val = calculateValuation(pos.id, asset, mkt, pos.totalQuantity);
      const avail = pos.totalQuantity - pos.pledgedQuantity - pos.pendingDeliveryQuantity - pos.frozenDisputedQuantity;

      return [
        pos.id, asset.isin, asset.ticker || '', `"${asset.name}"`, asset.assetClass, 
        asset.currency, asset.creditRating, pos.custodian, pos.totalQuantity, 
        pos.pledgedQuantity, pos.pendingDeliveryQuantity, pos.pendingReturnQuantity, 
        pos.frozenDisputedQuantity, avail, val.cleanPrice, val.dirtyPrice.toFixed(2), 
        Math.round(val.dirtyMarketValueUSD), (val.effectiveHaircut * 100).toFixed(1), 
        Math.round(val.recognisedCollateralValueUSD)
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `RhinoQuant_Collateral_Inventory_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSavePledge = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPledgePos) return;

    const res = addPositionPledgeAdjustment(editingPledgePos.id, Number(newPledgeQty), pledgeRationale || 'Operational adjustment');
    if (!res.success) {
      setPledgeError(res.message);
    } else {
      setEditingPledgePos(null);
      setPledgeError(null);
    }
  };

  const handleSaveLock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lockingPos) return;

    freezePositionDispute(lockingPos.id, Number(lockAmount), lockReason || 'Disputed position review');
    setLockingPos(null);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-3">
            <span>Collateral Inventory & Asset Master</span>
            <span className="text-xs font-normal text-slate-400 font-mono">
              {filteredPositions.length} POSITIONS · {assets.length} INSTRUMENTS
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time unencumbered balance tracking with transaction-level double-pledge prevention.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3 flex-1 min-w-[280px]">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search ISIN, Ticker, Asset Name, Account..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={selectedAssetClass}
            onChange={(e) => setSelectedAssetClass(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none"
          >
            <option value="ALL">All Asset Classes</option>
            <option value="SOVEREIGN_BOND">Sovereign Bonds</option>
            <option value="TREASURY_BILL">Treasury Bills</option>
            <option value="CORP_INVESTMENT_GRADE">Corporate IG</option>
            <option value="CORP_HIGH_YIELD">Corporate HY</option>
            <option value="EQUITY">Equities</option>
            <option value="ETF">ETFs</option>
            <option value="CASH">Cash</option>
          </select>

          <select
            value={selectedCurrency}
            onChange={(e) => setSelectedCurrency(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none"
          >
            <option value="ALL">All Currencies</option>
            <option value="USD">USD</option>
            <option value="EUR">EUR</option>
            <option value="GBP">GBP</option>
          </select>

          <select
            value={selectedCustodian}
            onChange={(e) => setSelectedCustodian(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none"
          >
            <option value="ALL">All Custodians</option>
            <option value="DTCC">DTCC</option>
            <option value="EUROCLEAR">Euroclear</option>
            <option value="CLEARSTREAM">Clearstream</option>
            <option value="BNY_MELLON">BNY Mellon</option>
            <option value="INTERNAL_VAULT">Internal Vault</option>
          </select>

          <label className="flex items-center gap-1.5 text-slate-400 cursor-pointer ml-1">
            <input
              type="checkbox"
              checked={onlyAvailable}
              onChange={(e) => setOnlyAvailable(e.target.checked)}
              className="rounded bg-slate-950 border-slate-800 text-blue-600 focus:ring-0"
            />
            <span>Available Only</span>
          </label>
        </div>
      </div>

      {/* High-Density Inventory Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                <th className="py-2.5 px-3">Asset / Identifier</th>
                <th className="py-2.5 px-2">Class</th>
                <th className="py-2.5 px-2">Rating</th>
                <th className="py-2.5 px-2">Custodian</th>
                <th className="py-2.5 px-3 text-right">Total Pos</th>
                <th className="py-2.5 px-3 text-right">Pledged</th>
                <th className="py-2.5 px-3 text-right">Locked/Pending</th>
                <th className="py-2.5 px-3 text-right text-emerald-400">Available</th>
                <th className="py-2.5 px-3 text-right">Dirty Price</th>
                <th className="py-2.5 px-3 text-right">Dirty MV (USD)</th>
                <th className="py-2.5 px-2 text-right">Haircut</th>
                <th className="py-2.5 px-3 text-right">Recognised USD</th>
                <th className="py-2.5 px-2 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px] tabular-nums">
              {filteredPositions.map(pos => {
                const asset = assetMap.get(pos.assetId)!;
                const mkt = marketData[asset.id];
                const val = calculateValuation(pos.id, asset, mkt, pos.totalQuantity);
                const available = Math.max(0, pos.totalQuantity - pos.pledgedQuantity - pos.pendingDeliveryQuantity - pos.frozenDisputedQuantity);

                return (
                  <tr key={pos.id} className="hover:bg-slate-800/40 transition-colors group">
                    <td className="py-2.5 px-3 font-sans">
                      <div className="font-semibold text-slate-200">{asset.ticker || asset.name}</div>
                      <div className="text-[10px] font-mono text-slate-500 flex items-center gap-1.5">
                        <span>{asset.isin}</span>
                        <span>·</span>
                        <span>{asset.currency}</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-2 font-sans text-slate-300 text-[10px]">
                      {asset.assetClass.replace(/_/g, ' ')}
                    </td>
                    <td className="py-2.5 px-2">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                        asset.creditRating === 'AAA' || asset.creditRating === 'AA'
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-900/40'
                          : asset.creditRating === 'A' || asset.creditRating === 'BBB'
                          ? 'bg-blue-950/60 text-blue-400 border border-blue-900/40'
                          : 'bg-red-950/60 text-red-400 border border-red-900/40'
                      }`}>
                        {asset.creditRating}
                      </span>
                    </td>
                    <td className="py-2.5 px-2 font-sans text-slate-400 text-[11px]">
                      {pos.custodian}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-200">
                      {pos.totalQuantity.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right text-amber-300">
                      {pos.pledgedQuantity.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-400">
                      {(pos.pendingDeliveryQuantity + pos.frozenDisputedQuantity).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-emerald-400">
                      {available.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {asset.assetClass === 'EQUITY' || asset.assetClass === 'ETF' 
                        ? `$${val.dirtyPrice.toFixed(2)}`
                        : `${val.dirtyPrice.toFixed(2)}%`}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-200">
                      ${Math.round(val.dirtyMarketValueUSD).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-2 text-right text-amber-400">
                      {(val.effectiveHaircut * 100).toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-white">
                      ${Math.round(val.recognisedCollateralValueUSD).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-2 text-center font-sans">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => setInspectingPosition({ pos, asset })}
                          className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-blue-400 transition-colors cursor-pointer"
                          title="Inspect valuation breakdown"
                        >
                          <Info className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            setEditingPledgePos(pos);
                            setNewPledgeQty(pos.pledgedQuantity);
                            setPledgeError(null);
                          }}
                          className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-amber-400 transition-colors cursor-pointer"
                          title="Adjust pledged quantity"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            setLockingPos(pos);
                            setLockAmount(pos.frozenDisputedQuantity);
                            setLockReason(pos.notes || '');
                          }}
                          className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
                          title="Lock / dispute position"
                        >
                          <Lock className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Valuation Inspector Drawer */}
      {inspectingPosition && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-end z-50">
          <div className="w-full max-w-xl h-full bg-slate-900 border-l border-slate-800 p-6 overflow-y-auto space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <span>Valuation Breakdown Inspector</span>
                </h2>
                <div className="text-xs text-slate-400 font-mono mt-0.5">
                  {inspectingPosition.asset.name} ({inspectingPosition.asset.isin})
                </div>
              </div>
              <button
                onClick={() => setInspectingPosition(null)}
                className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Calculations Engine Details */}
            {(() => {
              const pos = inspectingPosition.pos;
              const asset = inspectingPosition.asset;
              const mkt = marketData[asset.id];
              const val = calculateValuation(pos.id, asset, mkt, pos.totalQuantity);

              return (
                <div className="space-y-4 text-xs">
                  {/* Summary Cards */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-slate-950 p-3 rounded border border-slate-800">
                      <div className="text-slate-400">Dirty Market Value (USD)</div>
                      <div className="text-lg font-bold font-mono text-white mt-1">
                        ${Math.round(val.dirtyMarketValueUSD).toLocaleString()}
                      </div>
                    </div>
                    <div className="bg-slate-950 p-3 rounded border border-slate-800">
                      <div className="text-slate-400">Recognised Collateral (USD)</div>
                      <div className="text-lg font-bold font-mono text-emerald-400 mt-1">
                        ${Math.round(val.recognisedCollateralValueUSD).toLocaleString()}
                      </div>
                    </div>
                  </div>

                  {/* Formula Trace */}
                  <div className="bg-slate-950/80 p-4 rounded border border-slate-800 space-y-2.5">
                    <div className="font-semibold text-slate-200">Mathematical Valuation Walkthrough:</div>
                    <div className="space-y-1.5 font-mono text-[11px] text-slate-300">
                      <div>1. Nominal Quantity: {val.nominalQuantity.toLocaleString()} {asset.currency}</div>
                      <div>2. Clean Price: {val.cleanPrice.toFixed(2)}%</div>
                      <div>3. Accrued Interest: {val.accruedInterest.toFixed(3)}% ({asset.dayCount} convention)</div>
                      <div>4. Dirty Price = Clean + Accrued = {val.dirtyPrice.toFixed(3)}%</div>
                      <div>5. Local Dirty MV = {val.dirtyMarketValueLocal.toLocaleString()} {asset.currency}</div>
                      <div>6. FX Rate to USD = {val.fxRateToUSD.toFixed(4)}</div>
                      <div>7. Dirty MV USD = ${Math.round(val.dirtyMarketValueUSD).toLocaleString()}</div>
                    </div>
                  </div>

                  {/* Haircut Schedule Ladder */}
                  <div className="bg-slate-950/80 p-4 rounded border border-slate-800 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-200">Regulatory Haircut Schedule</span>
                      <span className="font-mono text-amber-400 font-bold">
                        Effective: {(val.effectiveHaircut * 100).toFixed(1)}%
                      </span>
                    </div>

                    <div className="divide-y divide-slate-800/80 text-[11px]">
                      <div className="py-2 flex items-center justify-between">
                        <span className="text-slate-400">Base Haircut ({asset.assetClass})</span>
                        <span className="font-mono text-slate-200">{(val.baseHaircut * 100).toFixed(1)}%</span>
                      </div>
                      {val.adjustments.map((adj, i) => (
                        <div key={i} className="py-2 flex items-center justify-between">
                          <div>
                            <div className="text-slate-300 font-medium">{adj.name}</div>
                            <div className="text-[10px] text-slate-500 font-sans">{adj.reason}</div>
                          </div>
                          <span className="font-mono text-amber-400">+{(adj.bps / 100).toFixed(1)}%</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Quantity Invariants Breakdown */}
                  <div className="bg-slate-950/80 p-4 rounded border border-slate-800 space-y-2">
                    <div className="font-semibold text-slate-200">Quantity Invariant Ledger</div>
                    <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                      <div>Total Position: <strong className="text-white">{pos.totalQuantity.toLocaleString()}</strong></div>
                      <div>Pledged: <strong className="text-amber-400">{pos.pledgedQuantity.toLocaleString()}</strong></div>
                      <div>Pending Delivery: <strong className="text-slate-400">{pos.pendingDeliveryQuantity.toLocaleString()}</strong></div>
                      <div>Disputed / Frozen: <strong className="text-red-400">{pos.frozenDisputedQuantity.toLocaleString()}</strong></div>
                    </div>
                    <div className="pt-2 border-t border-slate-800 font-mono text-[11px] text-emerald-400">
                      Available to Allocate: {(pos.totalQuantity - pos.pledgedQuantity - pos.pendingDeliveryQuantity - pos.frozenDisputedQuantity).toLocaleString()}
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {/* Adjust Pledge Modal */}
      {editingPledgePos && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Adjust Collateral Pledge</h3>
              <button onClick={() => setEditingPledgePos(null)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Modifying pledged quantity enforces the transactional invariant: <code className="text-blue-400">pledged + pending + frozen &le; total</code>.
            </p>

            <form onSubmit={handleSavePledge} className="space-y-4">
              <div>
                <label className="text-xs text-slate-300 block mb-1">New Pledged Quantity</label>
                <input
                  type="number"
                  value={newPledgeQty}
                  onChange={(e) => setNewPledgeQty(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                />
                <div className="text-[11px] text-slate-500 mt-1">
                  Max allowable: {editingPledgePos.totalQuantity - editingPledgePos.pendingDeliveryQuantity - editingPledgePos.frozenDisputedQuantity}
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">Audit Rationale</label>
                <input
                  type="text"
                  placeholder="e.g., Margin pledge to GS CSA 2016"
                  value={pledgeRationale}
                  onChange={(e) => setPledgeRationale(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-xs text-white focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              {pledgeError && (
                <div className="p-2.5 rounded bg-red-950/40 border border-red-900 text-xs text-red-300 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{pledgeError}</span>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingPledgePos(null)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-medium bg-blue-600 hover:bg-blue-500 text-white rounded cursor-pointer"
                >
                  Confirm & Update
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Lock / Dispute Modal */}
      {lockingPos && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Lock className="w-4 h-4 text-red-400" />
                <span>Freeze / Dispute Collateral Quantity</span>
              </h3>
              <button onClick={() => setLockingPos(null)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Frozen quantities are instantly deducted from available-to-allocate inventory and excluded from all automated optimisation runs.
            </p>

            <form onSubmit={handleSaveLock} className="space-y-4">
              <div>
                <label className="text-xs text-slate-300 block mb-1">Frozen / Disputed Amount (Nominal)</label>
                <input
                  type="number"
                  value={lockAmount}
                  onChange={(e) => setLockAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-xs font-mono text-white focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">Dispute / Freeze Reason</label>
                <input
                  type="text"
                  placeholder="e.g., Rating downgrade watch / Custody lien notice"
                  value={lockReason}
                  onChange={(e) => setLockReason(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-xs text-white focus:outline-none focus:border-red-500"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setLockingPos(null)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-medium bg-red-600 hover:bg-red-500 text-white rounded cursor-pointer"
                >
                  Lock Quantity
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
