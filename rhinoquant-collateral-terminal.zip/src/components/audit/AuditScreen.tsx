/**
 * RhinoQuant Collateral Management Platform
 * Immutable Audit Trail & Financial Governance
 */

import React, { useState } from 'react';
import { useCollateral } from '../../context/CollateralContext';
import { AuditEvent } from '../../types/models';
import { 
  History, 
  Search, 
  Filter, 
  Lock, 
  CheckCircle2, 
  Eye, 
  X, 
  ShieldCheck,
  FileCode
} from 'lucide-react';

export const AuditScreen: React.FC = () => {
  const { auditEvents } = useCollateral();
  const [searchQuery, setSearchQuery] = useState('');
  const [entityFilter, setEntityFilter] = useState('ALL');
  const [inspectedEvent, setInspectedEvent] = useState<AuditEvent | null>(null);

  const filteredEvents = auditEvents.filter(event => {
    if (entityFilter !== 'ALL' && event.entityType !== entityFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        event.actor.toLowerCase().includes(q) ||
        event.action.toLowerCase().includes(q) ||
        event.entityId.toLowerCase().includes(q) ||
        event.rationale.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-3">
            <span>Immutable Financial Audit Trail</span>
            <span className="text-xs font-normal text-emerald-400 font-mono">
              TAMPER-EVIDENT HASH CHAIN
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Complete append-only governance log of every financially material transaction, state change, and calculation version.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Integrity: VERIFIED · SHA-256</span>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3 flex-1 min-w-[280px]">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search actor, action, entity ID, or rationale..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={entityFilter}
            onChange={(e) => setEntityFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none"
          >
            <option value="ALL">All Entity Types</option>
            <option value="MARGIN_CALL">Margin Calls</option>
            <option value="OPTIMISATION">Optimisation</option>
            <option value="INVENTORY">Inventory</option>
            <option value="REPO">Repo Desk</option>
            <option value="AGREEMENT">Agreements</option>
            <option value="RULES">Rules & Risk</option>
          </select>
        </div>
      </div>

      {/* Events Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                <th className="py-2.5 px-3">Timestamp (UTC)</th>
                <th className="py-2.5 px-3">Actor</th>
                <th className="py-2.5 px-3">Action</th>
                <th className="py-2.5 px-2">Entity</th>
                <th className="py-2.5 px-3">Entity ID</th>
                <th className="py-2.5 px-3">Operational Rationale</th>
                <th className="py-2.5 px-2">Hash Chain</th>
                <th className="py-2.5 px-2 text-center">Diff</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px] tabular-nums">
              {filteredEvents.map(event => (
                <tr key={event.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 text-slate-400 font-mono text-[10px]">
                    {event.timestamp.replace('T', ' ').slice(0, 19)}
                  </td>

                  <td className="py-2.5 px-3 font-sans text-slate-300">
                    {event.actor}
                  </td>

                  <td className="py-2.5 px-3 font-mono font-bold text-blue-400 text-[10px]">
                    {event.action}
                  </td>

                  <td className="py-2.5 px-2 font-sans">
                    <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 font-mono">
                      {event.entityType}
                    </span>
                  </td>

                  <td className="py-2.5 px-3 font-mono text-slate-400 text-[10px]">
                    {event.entityId}
                  </td>

                  <td className="py-2.5 px-3 font-sans text-slate-300 max-w-sm truncate text-[11px]">
                    {event.rationale}
                  </td>

                  <td className="py-2.5 px-2 font-mono text-slate-500 text-[10px]">
                    {event.hash.slice(0, 14)}...
                  </td>

                  <td className="py-2.5 px-2 text-center font-sans">
                    <button
                      onClick={() => setInspectedEvent(event)}
                      className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
                      title="Inspect state diff"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* State Diff Drawer */}
      {inspectedEvent && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-end z-50">
          <div className="w-full max-w-lg h-full bg-slate-900 border-l border-slate-800 p-6 overflow-y-auto space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h2 className="text-base font-bold text-white">Audit Event Details</h2>
                <div className="text-xs text-slate-400 font-mono mt-0.5">{inspectedEvent.id}</div>
              </div>
              <button
                onClick={() => setInspectedEvent(null)}
                className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 rounded bg-slate-950 border border-slate-800 space-y-1.5 font-mono text-[11px]">
              <div>Action: <strong className="text-blue-400">{inspectedEvent.action}</strong></div>
              <div>Actor: {inspectedEvent.actor}</div>
              <div>Timestamp: {inspectedEvent.timestamp}</div>
              <div>Entity: {inspectedEvent.entityType} ({inspectedEvent.entityId})</div>
              <div>Integrity Hash: {inspectedEvent.hash}</div>
            </div>

            <div>
              <div className="font-semibold text-slate-200 mb-1">Audit Rationale:</div>
              <p className="p-2.5 rounded bg-slate-950 border border-slate-800 text-slate-300">
                {inspectedEvent.rationale}
              </p>
            </div>

            {inspectedEvent.previousState && (
              <div>
                <div className="font-semibold text-slate-200 mb-1">Previous State:</div>
                <pre className="p-3 rounded bg-slate-950 border border-slate-800 text-[10px] text-red-300 font-mono overflow-x-auto">
                  {JSON.stringify(inspectedEvent.previousState, null, 2)}
                </pre>
              </div>
            )}

            {inspectedEvent.newState && (
              <div>
                <div className="font-semibold text-slate-200 mb-1">New Transitioned State:</div>
                <pre className="p-3 rounded bg-slate-950 border border-slate-800 text-[10px] text-emerald-300 font-mono overflow-x-auto">
                  {JSON.stringify(inspectedEvent.newState, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
