/**
 * RhinoQuant Collateral Management Platform
 * Overview Screen - Institutional Command Center
 */

import React from 'react';
import { useCollateral } from '../../context/CollateralContext';
import { 
  ShieldCheck, 
  AlertTriangle, 
  Scale, 
  Layers, 
  ArrowUpRight, 
  Clock, 
  ArrowRight,
  TrendingDown,
  Building2,
  FileSpreadsheet
} from 'lucide-react';

interface OverviewScreenProps {
  onNavigate: (tab: string) => void;
}

export const OverviewScreen: React.FC<OverviewScreenProps> = ({ onNavigate }) => {
  const {
    totalInventoryDirtyUSD,
    totalRecognisedCollateralUSD,
    totalPledgedUSD,
    totalFreeCollateralUSD,
    haircutDragUSD,
    openMarginCallsCount,
    totalOpenMarginCallsUSD,
    unsettledTransfersCount,
    openExceptionsCount,
    marginCalls,
    repoTrades,
    reconciliationRecords,
    inventory,
    assets,
    marketData
  } = useCollateral();

  const haircutPct = totalInventoryDirtyUSD > 0 ? (haircutDragUSD / totalInventoryDirtyUSD) * 100 : 0;
  const pledgedPct = totalInventoryDirtyUSD > 0 ? (totalPledgedUSD / totalRecognisedCollateralUSD) * 100 : 0;

  // Asset class breakdown
  const assetClassAgg = React.useMemo(() => {
    const map: Record<string, { dirtyUSD: number; recognisedUSD: number }> = {};
    const assetMap = new Map(assets.map(a => [a.id, a]));

    for (const pos of inventory) {
      const asset = assetMap.get(pos.assetId);
      if (!asset) continue;
      const mkt = marketData[asset.id];
      if (!mkt) continue;

      const price = mkt.cleanPrice + (mkt.accruedInterestRate || 0);
      const isEq = asset.assetClass === 'EQUITY' || asset.assetClass === 'ETF';
      const dirtyUSD = (pos.totalQuantity * price / (isEq ? 1 : 100)) * mkt.fxRateToUSD;
      const recUSD = isEq ? dirtyUSD * 0.85 : dirtyUSD * (1 - (asset.assetClass === 'SOVEREIGN_BOND' ? 0.04 : 0.08));

      const cls = asset.assetClass;
      if (!map[cls]) map[cls] = { dirtyUSD: 0, recognisedUSD: 0 };
      map[cls].dirtyUSD += dirtyUSD;
      map[cls].recognisedUSD += recUSD;
    }
    return Object.entries(map).sort((a, b) => b[1].dirtyUSD - a[1].dirtyUSD);
  }, [assets, inventory, marketData]);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner Context */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-3">
            <span>Global Collateral & Margin Overview</span>
            <span className="text-xs font-normal text-slate-400 font-mono">
              AS OF 2026-10-24 08:30 UTC · BASE: USD
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time multi-asset collateral ledger, exposure coverage, and cleared/bilateral netting.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('optimisation')}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium bg-blue-600 hover:bg-blue-500 text-white rounded transition-colors cursor-pointer shadow-xs"
          >
            <span>Launch Optimiser</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onNavigate('margin')}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded transition-colors cursor-pointer"
          >
            <span>Margin Queue ({openMarginCallsCount})</span>
          </button>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Total Collateral Inventory */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Total Inventory (Dirty MV)</span>
            <Layers className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-white mt-2">
            ${(totalInventoryDirtyUSD / 1_000_000).toFixed(2)}M
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
            <span>Recognised:</span>
            <span className="text-slate-200 font-mono tabular-nums font-semibold">
              ${(totalRecognisedCollateralUSD / 1_000_000).toFixed(2)}M
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-amber-400 font-mono">
              -{haircutPct.toFixed(1)}% haircut
            </span>
          </div>
        </div>

        {/* KPI 2: Free & Unencumbered Collateral */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Available to Allocate</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-emerald-400 mt-2">
            ${(totalFreeCollateralUSD / 1_000_000).toFixed(2)}M
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
            <span>Pledged:</span>
            <span className="text-slate-200 font-mono tabular-nums font-semibold">
              ${(totalPledgedUSD / 1_000_000).toFixed(2)}M
            </span>
            <span className="text-slate-600">·</span>
            <span className="font-mono text-slate-300">
              {pledgedPct.toFixed(1)}% encumbered
            </span>
          </div>
        </div>

        {/* KPI 3: Open Margin Calls */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Open Margin Calls</span>
            <Scale className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-amber-300 mt-2">
            ${(totalOpenMarginCallsUSD / 1_000_000).toFixed(2)}M
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
            <span className="text-slate-200 font-semibold">{openMarginCallsCount} active calls</span>
            <span className="text-slate-600">·</span>
            <span className="text-amber-400">1 in dispute</span>
          </div>
        </div>

        {/* KPI 4: Operational Integrity */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Operational Pipeline</span>
            <Clock className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-white mt-2">
            {unsettledTransfersCount} Transfers
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
            <span className="text-slate-200">Reconciliation:</span>
            <span className={`${openExceptionsCount > 0 ? 'text-amber-400 font-semibold' : 'text-emerald-400'}`}>
              {openExceptionsCount} Unmatched
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-slate-400">SWIFT MT542 live</span>
          </div>
        </div>
      </div>

      {/* Main Split: Inventory Breakdown + Active Alerts & Deadlines */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Asset Allocation & Coverage Breakdown */}
        <div className="lg:col-span-2 space-y-6">
          {/* Asset Class Distribution */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-white">Collateral Composition by Asset Class</h3>
                <p className="text-xs text-slate-400 mt-0.5">Nominal dirty market value vs post-haircut recognised collateral value</p>
              </div>
              <button
                onClick={() => onNavigate('inventory')}
                className="text-xs text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1 cursor-pointer"
              >
                <span>Inspect All Assets</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-3.5">
              {assetClassAgg.map(([cls, val]) => {
                const pctOfTotal = (val.dirtyUSD / totalInventoryDirtyUSD) * 100;
                const classHaircutPct = ((val.dirtyUSD - val.recognisedUSD) / val.dirtyUSD) * 100;
                return (
                  <div key={cls} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-slate-200">
                          {cls.replace(/_/g, ' ')}
                        </span>
                        <span className="text-slate-500 font-mono text-[11px]">
                          ({pctOfTotal.toFixed(1)}%)
                        </span>
                      </div>
                      <div className="flex items-center gap-3 font-mono tabular-nums text-[11px]">
                        <span className="text-slate-400">MV: ${(val.dirtyUSD / 1_000_000).toFixed(2)}M</span>
                        <span className="text-slate-600">/</span>
                        <span className="text-slate-200 font-semibold">Recognised: ${(val.recognisedUSD / 1_000_000).toFixed(2)}M</span>
                        <span className="text-amber-400 text-[10px]">(-{classHaircutPct.toFixed(1)}%)</span>
                      </div>
                    </div>
                    {/* Progress Bar */}
                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden flex">
                      <div 
                        className="bg-blue-500 h-full transition-all duration-300" 
                        style={{ width: `${pctOfTotal}%` }} 
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Active Repo & Secured Financing Strip */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-white">Active Secured Financing & Repo Book</h3>
                <p className="text-xs text-slate-400 mt-0.5">Bi-party and tri-party repo trades with margin maintenance ratios</p>
              </div>
              <button
                onClick={() => onNavigate('repo')}
                className="text-xs text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1 cursor-pointer"
              >
                <span>Repo Workbench</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="divide-y divide-slate-800/80">
              {repoTrades.map(trade => (
                <div key={trade.id} className="py-3 first:pt-0 last:pb-0 flex items-center justify-between text-xs">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-200">{trade.tradeRef}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                        {trade.tradeType}
                      </span>
                      <span className="text-slate-500 font-mono text-[11px]">
                        End: {trade.endDate}
                      </span>
                    </div>
                    <div className="text-slate-400 mt-1 flex items-center gap-3 text-[11px]">
                      <span>Principal: <strong className="text-slate-200 font-mono">${(trade.cashPrincipal / 1_000_000).toFixed(1)}M</strong></span>
                      <span>·</span>
                      <span>Rate: <strong className="text-slate-200 font-mono">{(trade.repoRate * 100).toFixed(2)}% ({trade.dayCount})</strong></span>
                      <span>·</span>
                      <span>Accrued: <strong className="text-slate-300 font-mono">${trade.accruedRepoInterestUSD.toLocaleString()}</strong></span>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-[11px] text-slate-400">Coverage Ratio</div>
                    <div className={`font-mono font-bold text-sm tabular-nums ${
                      trade.collateralCoverageRatio >= trade.marginMaintenanceThreshold ? 'text-emerald-400' : 'text-red-400'
                    }`}>
                      {(trade.collateralCoverageRatio * 100).toFixed(2)}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Priority Settlement Cutoffs & Operational Alerts */}
        <div className="space-y-6">
          {/* Settlement Cutoffs */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2 mb-3">
              <Clock className="w-4 h-4 text-blue-400" />
              <span>Upcoming Settlement Cut-offs (Today)</span>
            </h3>

            <div className="space-y-3">
              <div className="p-3 rounded bg-slate-950/60 border border-slate-800 text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-200">DTCC Fedwire Cutoff (USD)</span>
                  <span className="font-mono text-amber-400 font-bold">14:00 UTC</span>
                </div>
                <div className="text-slate-400 text-[11px]">
                  $400,000 pending delivery to Citadel Securities. Instruction transmitted.
                </div>
              </div>

              <div className="p-3 rounded bg-slate-950/60 border border-slate-800 text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-200">Euroclear Target2 Cutoff (EUR)</span>
                  <span className="font-mono text-slate-300">16:00 UTC</span>
                </div>
                <div className="text-slate-400 text-[11px]">
                  €368,663 call from Eurex Clearing. Under valuation dispute on Bund curve.
                </div>
              </div>

              <div className="p-3 rounded bg-slate-950/60 border border-slate-800 text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-200">Clearstream Frankfurt (EUR)</span>
                  <span className="font-mono text-slate-300">17:00 UTC</span>
                </div>
                <div className="text-slate-400 text-[11px]">
                  €14.0M Bund collateral held for Goldman Sachs reverse repo maturing tomorrow.
                </div>
              </div>
            </div>
          </div>

          {/* Operational Risk Exceptions */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>High-Priority Risk Exceptions</span>
              </h3>
              <button
                onClick={() => onNavigate('reconciliation')}
                className="text-xs text-blue-400 hover:text-blue-300 cursor-pointer"
              >
                View ({openExceptionsCount})
              </button>
            </div>

            <div className="space-y-3">
              {reconciliationRecords.filter(r => r.status === 'UNMATCHED').map(exc => (
                <div key={exc.id} className="p-3 rounded bg-amber-950/20 border border-amber-900/40 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-amber-200">{exc.targetSystem} Discrepancy</span>
                    <span className="text-[10px] font-mono text-amber-400 font-bold px-1.5 py-0.5 rounded bg-amber-950/50">
                      {exc.severity}
                    </span>
                  </div>
                  <div className="text-slate-300 text-[11px]">
                    Internal: <span className="font-mono">{exc.internalQuantity.toLocaleString()}</span> vs External: <span className="font-mono">{exc.externalQuantity.toLocaleString()}</span>
                  </div>
                  <div className="text-amber-400/80 text-[11px]">
                    Variance: ${Math.round(exc.differenceMarketValueUSD).toLocaleString()} · Age: {exc.ageDays}d
                  </div>
                </div>
              ))}

              <div className="p-3 rounded bg-slate-950/60 border border-slate-800 text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-200">Sub-IG Rating Watch</span>
                  <span className="text-[10px] font-mono text-slate-400">MEDIUM</span>
                </div>
                <div className="text-slate-400 text-[11px]">
                  $1.0M Ford Motor Credit position (BB) frozen in dispute queue. Ineligible for ISDA CSA schedules.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
