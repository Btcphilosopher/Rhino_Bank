/**
 * RhinoQuant Collateral Management Platform
 * Top Navigation Bar - Conforms strictly to Top Bar Contract (3 Zones, no wrap)
 */

import React from 'react';
import { useCollateral, UserRole } from '../../context/CollateralContext';
import { ShieldCheck, RefreshCw, UserCheck } from 'lucide-react';

interface TopBarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const TopBar: React.FC<TopBarProps> = ({ activeTab, setActiveTab }) => {
  const { userRole, setUserRole, runPortfolioEODCycle, unsettledTransfersCount, openExceptionsCount } = useCollateral();

  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-slate-900 border-b border-slate-800 shrink-0">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <a 
          href="#overview" 
          onClick={(e) => { e.preventDefault(); setActiveTab('overview'); }}
          className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 flex items-center gap-2.5"
        >
          <div className="w-7 h-7 rounded bg-blue-600 flex items-center justify-center font-mono font-bold text-sm text-white shadow-sm shadow-blue-500/20">
            RQ
          </div>
          <span className="font-semibold text-slate-100">RHINOQUANT</span>
          <span className="text-slate-400 font-light text-sm">COLLATERAL</span>
        </a>
      </div>

      {/* Zone 2: 4-5 clean single-line text navigation links */}
      <nav className="hidden xl:flex items-center gap-6 text-xs font-medium text-slate-400">
        <button
          onClick={() => setActiveTab('overview')}
          className={`whitespace-nowrap shrink-0 transition-colors py-1 cursor-pointer ${
            activeTab === 'overview' ? 'text-blue-400 font-semibold border-b-2 border-blue-500' : 'hover:text-slate-200'
          }`}
        >
          Overview
        </button>
        <button
          onClick={() => setActiveTab('inventory')}
          className={`whitespace-nowrap shrink-0 transition-colors py-1 cursor-pointer ${
            activeTab === 'inventory' ? 'text-blue-400 font-semibold border-b-2 border-blue-500' : 'hover:text-slate-200'
          }`}
        >
          Inventory
        </button>
        <button
          onClick={() => setActiveTab('margin')}
          className={`whitespace-nowrap shrink-0 transition-colors py-1 cursor-pointer ${
            activeTab === 'margin' ? 'text-blue-400 font-semibold border-b-2 border-blue-500' : 'hover:text-slate-200'
          }`}
        >
          Margin Calls
        </button>
        <button
          onClick={() => setActiveTab('optimisation')}
          className={`whitespace-nowrap shrink-0 transition-colors py-1 cursor-pointer ${
            activeTab === 'optimisation' ? 'text-blue-400 font-semibold border-b-2 border-blue-500' : 'hover:text-slate-200'
          }`}
        >
          Optimisation
        </button>
        <button
          onClick={() => setActiveTab('repo')}
          className={`whitespace-nowrap shrink-0 transition-colors py-1 cursor-pointer ${
            activeTab === 'repo' ? 'text-blue-400 font-semibold border-b-2 border-blue-500' : 'hover:text-slate-200'
          }`}
        >
          Repo & Funding
        </button>
        <button
          onClick={() => setActiveTab('risk')}
          className={`whitespace-nowrap shrink-0 transition-colors py-1 cursor-pointer ${
            activeTab === 'risk' ? 'text-blue-400 font-semibold border-b-2 border-blue-500' : 'hover:text-slate-200'
          }`}
        >
          Risk & Stress
        </button>
        <button
          onClick={() => setActiveTab('reconciliation')}
          className={`whitespace-nowrap shrink-0 transition-colors py-1 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'reconciliation' ? 'text-blue-400 font-semibold border-b-2 border-blue-500' : 'hover:text-slate-200'
          }`}
        >
          Reconciliation
          {openExceptionsCount > 0 && (
            <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-mono">
              {openExceptionsCount}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('tests')}
          className={`whitespace-nowrap shrink-0 transition-colors py-1 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'tests' ? 'text-emerald-400 font-semibold border-b-2 border-emerald-500' : 'hover:text-slate-200'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          Test Suite (15)
        </button>
      </nav>

      {/* Zone 3: 1 primary action button + User Role Selector */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Role Selector */}
        <div className="flex items-center gap-1.5 text-xs text-slate-400 bg-slate-800/80 px-2.5 py-1 rounded border border-slate-700">
          <UserCheck className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <select 
            value={userRole} 
            onChange={(e) => setUserRole(e.target.value as UserRole)}
            className="bg-transparent text-slate-200 font-mono text-[11px] focus:outline-none cursor-pointer"
          >
            <option value="VIEWER" className="bg-slate-900 text-slate-200">Viewer (Read-Only)</option>
            <option value="COLLATERAL_OPERATOR" className="bg-slate-900 text-slate-200">Collateral Operator</option>
            <option value="RISK_ANALYST" className="bg-slate-900 text-slate-200">Risk Analyst</option>
            <option value="APPROVER" className="bg-slate-900 text-slate-200">Approver (VP)</option>
            <option value="AUDITOR" className="bg-slate-900 text-slate-200">Auditor (Read-Only)</option>
            <option value="ADMIN" className="bg-slate-900 text-slate-200">System Admin</option>
          </select>
        </div>

        {/* Primary Action Button */}
        <button
          onClick={runPortfolioEODCycle}
          className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium text-white bg-blue-600 rounded hover:bg-blue-500 transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-sm shadow-blue-600/30 active:scale-[0.99]"
          title="Revalue positions, reconcile custody statements, and calculate margin"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Run Portfolio EOD</span>
        </button>
      </div>
    </header>
  );
};
