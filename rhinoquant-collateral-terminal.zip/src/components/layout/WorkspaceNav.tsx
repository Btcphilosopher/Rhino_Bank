/**
 * RhinoQuant Collateral Management Platform
 * Workspace Secondary Navigation Strip
 */

import React from 'react';
import { 
  LayoutDashboard, 
  Layers, 
  Scale, 
  SlidersHorizontal, 
  ArrowLeftRight, 
  Activity, 
  FileCheck2, 
  ScrollText, 
  History, 
  CheckCircle2, 
  BookOpen 
} from 'lucide-react';

interface WorkspaceNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const WorkspaceNav: React.FC<WorkspaceNavProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'overview', label: 'Collateral Overview', icon: LayoutDashboard },
    { id: 'inventory', label: 'Asset Inventory', icon: Layers },
    { id: 'margin', label: 'Margin Calls Queue', icon: Scale },
    { id: 'optimisation', label: 'Optimisation Workbench', icon: SlidersHorizontal },
    { id: 'repo', label: 'Repo & Secured Funding', icon: ArrowLeftRight },
    { id: 'risk', label: 'Risk & Stress Scenarios', icon: Activity },
    { id: 'reconciliation', label: 'Reconciliation Console', icon: FileCheck2 },
    { id: 'agreements', label: 'Agreements & Rules', icon: ScrollText },
    { id: 'audit', label: 'Audit Trail', icon: History },
    { id: 'tests', label: 'Invariant Test Runner (15)', icon: CheckCircle2 },
    { id: 'docs', label: 'Methodology & API', icon: BookOpen },
  ];

  return (
    <div className="bg-slate-900/60 border-b border-slate-800 px-6 py-1.5 flex items-center gap-1 overflow-x-auto text-xs font-medium text-slate-400">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded transition-all whitespace-nowrap shrink-0 cursor-pointer ${
              isActive 
                ? 'bg-slate-800 text-blue-400 font-semibold shadow-xs border border-slate-700/60' 
                : 'hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-blue-400' : 'text-slate-400'}`} />
            <span>{tab.label}</span>
          </button>
        );
      })}
    </div>
  );
};
