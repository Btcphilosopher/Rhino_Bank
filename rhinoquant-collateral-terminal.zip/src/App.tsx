/**
 * RhinoQuant Collateral Management Platform
 * Main Application Shell & Workspace Router
 */

import React, { useState } from 'react';
import { CollateralProvider } from './context/CollateralContext';
import { TopBar } from './components/layout/TopBar';
import { WorkspaceNav } from './components/layout/WorkspaceNav';
import { OverviewScreen } from './components/overview/OverviewScreen';
import { InventoryScreen } from './components/inventory/InventoryScreen';
import { MarginCallsScreen } from './components/margin/MarginCallsScreen';
import { OptimisationScreen } from './components/optimisation/OptimisationScreen';
import { RepoScreen } from './components/repo/RepoScreen';
import { RiskScreen } from './components/risk/RiskScreen';
import { ReconciliationScreen } from './components/reconciliation/ReconciliationScreen';
import { AgreementsScreen } from './components/agreements/AgreementsScreen';
import { AuditScreen } from './components/audit/AuditScreen';
import { TestSuiteScreen } from './components/tests/TestSuiteScreen';
import { DocsScreen } from './components/docs/DocsScreen';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');

  return (
    <CollateralProvider>
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
        {/* Institutional Top Bar (Strict 3-zone contract) */}
        <TopBar activeTab={activeTab} setActiveTab={setActiveTab} />

        {/* Secondary Workspace Navigation Strip */}
        <WorkspaceNav activeTab={activeTab} setActiveTab={setActiveTab} />

        {/* Main Content Viewport */}
        <main className="flex-1 overflow-y-auto">
          {activeTab === 'overview' && <OverviewScreen onNavigate={setActiveTab} />}
          {activeTab === 'inventory' && <InventoryScreen />}
          {activeTab === 'margin' && <MarginCallsScreen />}
          {activeTab === 'optimisation' && <OptimisationScreen />}
          {activeTab === 'repo' && <RepoScreen />}
          {activeTab === 'risk' && <RiskScreen />}
          {activeTab === 'reconciliation' && <ReconciliationScreen />}
          {activeTab === 'agreements' && <AgreementsScreen />}
          {activeTab === 'audit' && <AuditScreen />}
          {activeTab === 'tests' && <TestSuiteScreen />}
          {activeTab === 'docs' && <DocsScreen />}
        </main>

        {/* Quiet Institutional Footer */}
        <footer className="bg-slate-950 border-t border-slate-900 px-6 py-2.5 text-[11px] text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-3 font-mono">
            <span>Rhino Bank PLC (London)</span>
            <span>·</span>
            <span>LEI: 549300RHINO00000018</span>
            <span>·</span>
            <span>RhinoQuant Collateral v2026.4-PROD</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span className="text-emerald-400 font-mono">● All Invariants Operational</span>
            <span>·</span>
            <span>BCBS-IOSCO Netting Standards</span>
          </div>
        </footer>
      </div>
    </CollateralProvider>
  );
}
