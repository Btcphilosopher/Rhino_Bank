/**
 * RhinoQuant Collateral Management Platform
 * Institutional Data Models and Type Definitions
 */

export type AssetClass = 
  | 'SOVEREIGN_BOND'
  | 'TREASURY_BILL'
  | 'AGENCY_BOND'
  | 'CORP_INVESTMENT_GRADE'
  | 'CORP_HIGH_YIELD'
  | 'EQUITY'
  | 'ETF'
  | 'CASH'
  | 'MONEY_MARKET';

export type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'CHF';

export type CreditRating = 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'B' | 'CCC' | 'NR';

export type DayCountConvention = 'ACT/ACT' | 'ACT/360' | 'ACT/365' | '30/360';

export type CustodyLocation = 'EUROCLEAR' | 'CLEARSTREAM' | 'DTCC' | 'BNY_MELLON' | 'STATE_STREET' | 'INTERNAL_VAULT';

export type SettlementStatus = 'SETTLED' | 'PENDING_DELIVERY' | 'PENDING_RECEIPT' | 'FAILED' | 'DISPUTED';

export interface AssetMaster {
  id: string;
  isin: string;
  cusip?: string;
  ticker?: string;
  name: string;
  assetClass: AssetClass;
  issuer: string;
  issuerCountry: string;
  currency: Currency;
  creditRating: CreditRating;
  maturityDate?: string; // YYYY-MM-DD or undefined for Perpetual / Equities / Cash
  issueDate?: string;
  couponRate?: number; // annual coupon e.g. 0.0425 for 4.25%
  couponFrequency?: number; // coupons per year (e.g. 2 for semi-annual)
  dayCount: DayCountConvention;
  minDenomination: number;
  lotSize: number;
  repoEligible: boolean;
  centralBankEligible: boolean;
  benchmarkSecurity: boolean;
}

export interface MarketDataSnapshot {
  assetId: string;
  cleanPrice: number; // percentage of par e.g. 101.25 or equity price e.g. 420.50
  accruedInterestRate?: number; // accrued percentage e.g. 0.0125 (1.25%)
  fxRateToUSD: number; // exchange rate to USD
  spreadBps?: number; // credit spread in bps
  yieldToMaturity?: number; // YTM e.g. 0.045
  timestamp: string;
  source: 'REUTERS' | 'BLOOMBERG' | 'ICE' | 'SIMULATED_INTERNAL';
}

export interface InventoryPosition {
  id: string;
  assetId: string;
  custodian: CustodyLocation;
  accountNumber: string;
  totalQuantity: number;
  pledgedQuantity: number;
  pendingDeliveryQuantity: number;
  pendingReturnQuantity: number;
  frozenDisputedQuantity: number;
  // Available to allocate = total - pledged - pendingDelivery - frozenDisputed + pendingReturn (if recognized)
  // strictly invariant: pledgedQuantity + pendingDeliveryQuantity + frozenDisputedQuantity <= totalQuantity
  lastUpdated: string;
  subAccountId?: string;
  notes?: string;
}

export interface HaircutAdjustment {
  name: string;
  bps: number; // basis points or percentage points (e.g. 8% = 0.08)
  reason: string;
}

export interface PositionValuation {
  positionId: string;
  assetId: string;
  nominalQuantity: number;
  cleanPrice: number;
  accruedInterest: number;
  dirtyPrice: number;
  cleanMarketValueLocal: number;
  dirtyMarketValueLocal: number;
  fxRateToUSD: number;
  dirtyMarketValueUSD: number;
  baseHaircut: number; // e.g. 0.02 for 2%
  adjustments: HaircutAdjustment[];
  effectiveHaircut: number; // baseHaircut + sum(adjustments), capped/floored
  concentrationHaircutAddOn: number;
  liquidityAdjustment: number;
  recognisedCollateralValueUSD: number;
  calculationTimestamp: string;
  ruleVersion: string;
}

export type AgreementType = 'ISDA_VM_CSA' | 'ISDA_1995_NY' | 'GMRA_REPO' | 'GMSLA_SECLEND' | 'CLEARING_BROKER';

export interface AgreementEligibilityRule {
  id: string;
  allowedAssetClasses: AssetClass[];
  minRating: CreditRating;
  prohibitedCountries: string[];
  maxMaturityYears?: number;
  maxIssuerConcentrationPct: number; // e.g. 0.20 for 20%
  maxAssetClassConcentrationPct: number; // e.g. 0.30 for 30% equities
  currencyMismatchAllowed: boolean;
  currencyMismatchHaircut: number; // e.g. 0.08 (8%)
  minimumLotSize: number;
}

export interface CollateralAgreement {
  id: string;
  code: string;
  name: string;
  type: AgreementType;
  counterpartyId: string;
  legalEntityId: string;
  baseCurrency: Currency;
  threshold: number; // e.g. 0 for regulatory VM CSA
  minimumTransferAmount: number; // MTA e.g. $250,000 (ISDA standard or regulatory $500k)
  roundingIncrement: number; // e.g. $10,000
  independentAmount: number; // e.g. $0 or specific IM
  governingLaw: 'ENGLISH_LAW' | 'NEW_YORK_LAW' | 'LUXEMBOURG_LAW' | 'GERMAN_LAW';
  valuationFrequency: 'DAILY' | 'WEEKLY';
  callCutOffTimeUtc: string; // e.g. "13:00"
  notificationTimeUtc: string;
  eligibilityRule: AgreementEligibilityRule;
  status: 'ACTIVE' | 'UNDER_REVIEW' | 'TERMINATED';
  effectiveDate: string;
  version: number;
}

export interface Counterparty {
  id: string;
  lei: string; // Legal Entity Identifier
  name: string;
  shortCode: string;
  domicile: string;
  creditRating: CreditRating;
  contactEmail: string;
  settlementBic: string;
  nettingEligible: boolean;
  tier: 'TIER_1_DEALER' | 'TIER_2_BANK' | 'HEDGE_FUND' | 'CLEARING_HOUSE' | 'ASSET_MANAGER';
}

export type MarginCallDirection = 'DELIVER_COLLATERAL' | 'RETURN_COLLATERAL' | 'NO_CALL';

export type MarginCallStatus = 
  | 'DRAFT'
  | 'CALCULATED'
  | 'PENDING_APPROVAL'
  | 'ISSUED'
  | 'ACKNOWLEDGED'
  | 'DISPUTED'
  | 'AGREED'
  | 'PARTIALLY_SETTLED'
  | 'SETTLED'
  | 'CANCELLED'
  | 'FAILED';

export interface MarginCall {
  id: string;
  idempotencyKey: string;
  agreementId: string;
  counterpartyId: string;
  callDate: string;
  currentExposureUSD: number; // MtM exposure
  initialMarginRequirementUSD: number;
  variationMarginRequirementUSD: number;
  totalRequirementUSD: number;
  collateralHeldRecognisedUSD: number;
  collateralDeliveredRecognisedUSD: number;
  netCollateralRecognisedUSD: number;
  grossExcessShortfallUSD: number;
  thresholdUSD: number;
  minimumTransferAmountUSD: number;
  roundingIncrementUSD: number;
  requiredTransferAmountUSD: number;
  direction: MarginCallDirection;
  callCurrency: Currency;
  requiredTransferAmountInCallCurrency: number;
  status: MarginCallStatus;
  deadlineTimestamp: string;
  calculationExplanation: string[];
  disputeReason?: string;
  disputeAmountUSD?: number;
  createdAt: string;
  updatedAt: string;
  version: number;
}

export interface AllocationItem {
  positionId: string;
  assetId: string;
  allocatedNominal: number;
  dirtyMarketValueUSD: number;
  effectiveHaircut: number;
  recognisedValueUSD: number;
  fundingCostBps: number;
  costUSD: number;
}

export interface OptimizationRun {
  id: string;
  timestamp: string;
  targetAgreementIds: string[];
  totalRequirementUSD: number;
  objectiveFunction: 'MINIMIZE_FUNDING_COST' | 'PRESERVE_LIQUIDITY' | 'MINIMIZE_FX_FRICTION';
  status: 'OPTIMAL' | 'INFEASIBLE' | 'SUB_OPTIMAL';
  totalAllocatedRecognisedUSD: number;
  allocatedItems: {
    agreementId: string;
    items: AllocationItem[];
  }[];
  totalOpportunityCostUSD: number;
  estimatedSavingsUSD: number; // compared to baseline cash/random allocation
  bindingConstraints: string[];
  rejectedInventoryReasons: {
    assetId: string;
    reason: string;
  }[];
  approved: boolean;
  approvedBy?: string;
  approvedAt?: string;
}

export interface RepoTrade {
  id: string;
  tradeRef: string;
  counterpartyId: string;
  tradeType: 'REPO' | 'REVERSE_REPO'; // REPO = borrow cash, lend collateral; REVERSE_REPO = lend cash, receive collateral
  cashPrincipal: number;
  currency: Currency;
  repoRate: number; // annual rate e.g. 0.0525 (5.25%)
  startDate: string;
  endDate: string;
  dayCount: DayCountConvention;
  assetId: string;
  collateralNominal: number;
  collateralDirtyPrice: number;
  initialHaircut: number; // e.g. 0.02
  currentMarketValueUSD: number;
  currentRecognisedValueUSD: number;
  accruedRepoInterestUSD: number;
  settlementStatus: SettlementStatus;
  marginMaintenanceThreshold: number; // e.g. 1.00 (100% coverage required)
  collateralCoverageRatio: number; // recognised collateral / (cashPrincipal + accruedInterest)
  status: 'ACTIVE' | 'MATURED' | 'SUBSTITUTION_PENDING' | 'TERMINATED';
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  sovereignYieldShockBps: number; // e.g. +150
  corpSpreadShockBps: number; // e.g. +250
  equityShockPct: number; // e.g. -0.25 (-25%)
  fxShockUSDDepreciationPct: number; // USD strength vs others
  haircutShockAddOnPct: number; // e.g. +0.05 (+5% haircut across all non-cash)
  downgradeBBBToHY: boolean;
}

export interface StressScenarioResult {
  scenarioId: string;
  scenarioName: string;
  baseRecognisedCollateralUSD: number;
  stressedRecognisedCollateralUSD: number;
  collateralValueDropUSD: number;
  collateralValueDropPct: number;
  baseMarginDeficitUSD: number;
  stressedMarginDeficitUSD: number;
  additionalLiquidityRequiredUSD: number;
  ineligiblePositionsCount: number;
  trappedInventoryValueUSD: number;
  counterpartyImpacts: {
    counterpartyId: string;
    counterpartyName: string;
    additionalCallRequiredUSD: number;
    breachFlag: boolean;
  }[];
}

export interface ReconciliationRecord {
  id: string;
  reconciliationDate: string;
  sourceSystem: 'RHINO_INTERNAL_LEDGER';
  targetSystem: CustodyLocation | 'COUNTERPARTY_STATEMENT';
  assetId: string;
  internalQuantity: number;
  externalQuantity: number;
  differenceQuantity: number;
  internalMarketValueUSD: number;
  externalMarketValueUSD: number;
  differenceMarketValueUSD: number;
  status: 'MATCHED' | 'UNMATCHED' | 'DISPUTED';
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  ageDays: number;
  assignedAnalyst?: string;
  resolutionStatus: 'OPEN' | 'INVESTIGATING' | 'ESCALATED' | 'RESOLVED' | 'WAIVED';
  notes?: string;
}

export interface SettlementInstruction {
  id: string;
  instructionRef: string; // e.g. SWIFT SEMT/SESE ref
  marginCallId?: string;
  allocationId?: string;
  repoTradeId?: string;
  direction: 'DELIVERY_VERSUS_PAYMENT' | 'FREE_OF_PAYMENT_DELIVERY' | 'FREE_OF_PAYMENT_RECEIPT';
  assetId: string;
  quantity: number;
  cashAmount?: number;
  currency: Currency;
  custodian: CustodyLocation;
  counterpartyId: string;
  counterpartyBic: string;
  intendedSettlementDate: string;
  status: 'PENDING_AUTHORIZATION' | 'TRANSMITTED' | 'MATCHED' | 'SETTLED' | 'REJECTED' | 'CANCELLED';
  createdTimestamp: string;
  executedTimestamp?: string;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  entityType: 'INVENTORY' | 'MARGIN_CALL' | 'OPTIMISATION' | 'AGREEMENT' | 'REPO' | 'SETTLEMENT' | 'RULES';
  entityId: string;
  previousState?: any;
  newState?: any;
  rationale: string;
  hash: string;
}

export interface TestResult {
  id: number;
  title: string;
  description: string;
  passed: boolean;
  details: string;
  executionTimeMs: number;
  invariantsVerified: string[];
}
