/**
 * RhinoQuant Collateral Management Platform
 * Eligibility Rules Engine - Deterministic Evaluation and Explainable Decisions
 */

import { AssetMaster, CollateralAgreement, InventoryPosition, CreditRating } from '../types/models';
import { getRemainingMaturityYears } from './valuationEngine';

export interface EligibilityResult {
  assetId: string;
  agreementId: string;
  isEligible: boolean;
  status: 'ELIGIBLE' | 'INELIGIBLE' | 'RESTRICTED';
  ruleIds: string[];
  reasons: string[];
  rejectionCriteria: string[];
  inputValues: {
    assetClass: string;
    creditRating: CreditRating;
    currency: string;
    issuerCountry: string;
    remainingMaturityYears: number;
    availableQuantity: number;
    custodian: string;
  };
  ruleVersion: string;
  evaluatedAt: string;
}

const RATING_HIERARCHY: Record<CreditRating, number> = {
  AAA: 7,
  AA: 6,
  A: 5,
  BBB: 4,
  BB: 3,
  B: 2,
  CCC: 1,
  NR: 0
};

export function evaluateEligibility(
  asset: AssetMaster,
  agreement: CollateralAgreement,
  position?: InventoryPosition
): EligibilityResult {
  const rule = agreement.eligibilityRule;
  const ruleIds: string[] = [];
  const reasons: string[] = [];
  const rejectionCriteria: string[] = [];

  const maturityYears = getRemainingMaturityYears(asset.maturityDate);
  const availableQty = position 
    ? Math.max(0, position.totalQuantity - position.pledgedQuantity - position.pendingDeliveryQuantity - position.frozenDisputedQuantity)
    : 0;

  const inputValues = {
    assetClass: asset.assetClass,
    creditRating: asset.creditRating,
    currency: asset.currency,
    issuerCountry: asset.issuerCountry,
    remainingMaturityYears: Math.round(maturityYears * 10) / 10,
    availableQuantity: availableQty,
    custodian: position ? position.custodian : 'N/A'
  };

  // 1. Asset Class check
  if (!rule.allowedAssetClasses.includes(asset.assetClass)) {
    rejectionCriteria.push(`Asset class ${asset.assetClass} is prohibited under ${agreement.name}`);
  } else {
    ruleIds.push(`RULE-${agreement.code}-AC01`);
    reasons.push(`Asset class ${asset.assetClass} is approved on collateral schedule.`);
  }

  // 2. Minimum Credit Rating
  const assetRatingScore = RATING_HIERARCHY[asset.creditRating] || 0;
  const minRatingScore = RATING_HIERARCHY[rule.minRating] || 0;
  if (assetRatingScore < minRatingScore && asset.assetClass !== 'CASH') {
    rejectionCriteria.push(`Credit rating ${asset.creditRating} fails minimum rating threshold ${rule.minRating}`);
  } else {
    ruleIds.push(`RULE-${agreement.code}-CR02`);
    reasons.push(`Credit rating ${asset.creditRating} satisfies minimum credit standard (${rule.minRating}+).`);
  }

  // 3. Prohibited Countries / Jurisdictions
  if (rule.prohibitedCountries.includes(asset.issuerCountry)) {
    rejectionCriteria.push(`Issuer country ${asset.issuerCountry} is on sanction/prohibited jurisdiction list`);
  } else {
    ruleIds.push(`RULE-${agreement.code}-JUR03`);
    reasons.push(`Issuer country (${asset.issuerCountry}) is in approved jurisdiction whitelist.`);
  }

  // 4. Maturity constraints
  if (rule.maxMaturityYears && maturityYears > rule.maxMaturityYears) {
    rejectionCriteria.push(`Remaining maturity (${maturityYears.toFixed(1)}y) exceeds agreement limit (${rule.maxMaturityYears}y)`);
  } else if (rule.maxMaturityYears) {
    ruleIds.push(`RULE-${agreement.code}-MAT04`);
    reasons.push(`Maturity within allowable term cap of ${rule.maxMaturityYears} years.`);
  }

  // 5. Currency Mismatch
  if (!rule.currencyMismatchAllowed && asset.currency !== agreement.baseCurrency) {
    rejectionCriteria.push(`Currency ${asset.currency} not permitted; agreement requires strict ${agreement.baseCurrency}`);
  } else if (asset.currency !== agreement.baseCurrency) {
    reasons.push(`Currency mismatch permitted with standard ${((rule.currencyMismatchHaircut || 0.08) * 100).toFixed(0)}% regulatory haircut.`);
  }

  // 6. Availability and encumbrance check
  if (position && availableQty <= 0) {
    rejectionCriteria.push(`Zero unencumbered position available (Total: ${position.totalQuantity}, Pledged: ${position.pledgedQuantity}, Locked: ${position.frozenDisputedQuantity})`);
  }

  const isEligible = rejectionCriteria.length === 0;

  return {
    assetId: asset.id,
    agreementId: agreement.id,
    isEligible,
    status: isEligible ? 'ELIGIBLE' : 'INELIGIBLE',
    ruleIds,
    reasons: isEligible ? reasons : reasons.concat(rejectionCriteria),
    rejectionCriteria,
    inputValues,
    ruleVersion: `v${agreement.version}.2-LEGAL-APPROVED`,
    evaluatedAt: new Date().toISOString()
  };
}
