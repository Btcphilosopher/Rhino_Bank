/**
 * RhinoQuant Collateral Management Platform
 * Mathematical Collateral Optimisation Engine
 * Solves multi-agreement constrained allocation to minimise funding drag & liquidity cost
 */

import { AssetMaster, InventoryPosition, CollateralAgreement, OptimizationRun, AllocationItem } from '../types/models';
import { calculateValuation } from './valuationEngine';
import { evaluateEligibility } from './eligibilityEngine';
import { MarketDataSnapshot } from '../types/models';

export interface OptimisationProblemInput {
  targetAgreements: {
    agreement: CollateralAgreement;
    requiredTransferUSD: number;
  }[];
  inventory: InventoryPosition[];
  assets: AssetMaster[];
  marketData: Record<string, MarketDataSnapshot>;
  objective: 'MINIMIZE_FUNDING_COST' | 'PRESERVE_LIQUIDITY' | 'MINIMIZE_FX_FRICTION';
}

/**
 * Determines annualised opportunity / funding cost for an asset (in bps)
 */
function getAssetFundingCostBps(
  asset: AssetMaster,
  objective: 'MINIMIZE_FUNDING_COST' | 'PRESERVE_LIQUIDITY' | 'MINIMIZE_FX_FRICTION',
  agreementBaseCurrency: string
): number {
  let baseCost = 0;

  switch (asset.assetClass) {
    case 'CASH':
      // Cash has highest opportunity cost (Fed funds / repo reinvestment rate ~5.25%)
      baseCost = 525;
      break;
    case 'TREASURY_BILL':
      baseCost = 480;
      break;
    case 'SOVEREIGN_BOND':
      // Cheaper to deliver, high collateral velocity
      baseCost = 350;
      break;
    case 'AGENCY_BOND':
      baseCost = 380;
      break;
    case 'CORP_INVESTMENT_GRADE':
      baseCost = 280;
      break;
    case 'CORP_HIGH_YIELD':
      baseCost = 220; // low collateral velocity, good to post if eligible
      break;
    case 'EQUITY':
    case 'ETF':
      baseCost = 300;
      break;
    default:
      baseCost = 400;
  }

  // If objective is PRESERVE_LIQUIDITY, heavily penalize posting Cash and On-the-Run Treasuries
  if (objective === 'PRESERVE_LIQUIDITY') {
    if (asset.assetClass === 'CASH') baseCost += 400;
    if (asset.assetClass === 'TREASURY_BILL') baseCost += 250;
    if (asset.benchmarkSecurity) baseCost += 200;
  }

  // If objective is MINIMIZE_FX_FRICTION, penalize currency mismatches
  if (objective === 'MINIMIZE_FX_FRICTION' && asset.currency !== agreementBaseCurrency) {
    baseCost += 350; // extra friction penalty
  }

  return baseCost;
}

export function runCollateralOptimisation(input: OptimisationProblemInput): OptimizationRun {
  const { targetAgreements, inventory, assets, marketData, objective } = input;
  const assetMap = new Map(assets.map(a => [a.id, a]));

  const runId = `OPT-${Date.now().toString(36).toUpperCase()}`;
  const totalRequirementUSD = targetAgreements.reduce((sum, ta) => sum + ta.requiredTransferUSD, 0);

  // Track remaining available quantity per position to strictly prevent double-pledging!
  const remainingAvailableQuantity = new Map<string, number>();
  for (const pos of inventory) {
    const free = Math.max(0, pos.totalQuantity - pos.pledgedQuantity - pos.pendingDeliveryQuantity - pos.frozenDisputedQuantity);
    remainingAvailableQuantity.set(pos.id, free);
  }

  const allocatedItemsByAgreement: { agreementId: string; items: AllocationItem[] }[] = [];
  const bindingConstraints: string[] = [];
  const rejectedReasons: { assetId: string; reason: string }[] = [];

  let grandTotalAllocatedUSD = 0;
  let totalOpportunityCostUSD = 0;
  let baselineCashCostUSD = 0;

  // Process each agreement obligation
  for (const target of targetAgreements) {
    const agreement = target.agreement;
    let deficitUSD = target.requiredTransferUSD;
    const itemsForAgreement: AllocationItem[] = [];

    // Candidate eligible positions
    interface Candidate {
      position: InventoryPosition;
      asset: AssetMaster;
      valuationPerUnitUSD: number; // recognised value per unit of nominal
      effectiveHaircut: number;
      dirtyPrice: number;
      fxRate: number;
      fundingCostBps: number;
      costPerRecognisedDollar: number; // cost efficiency metric
    }

    const candidates: Candidate[] = [];

    for (const pos of inventory) {
      const asset = assetMap.get(pos.assetId);
      if (!asset) continue;

      const avail = remainingAvailableQuantity.get(pos.id) || 0;
      if (avail <= 0) {
        continue;
      }

      // Check eligibility
      const eligibility = evaluateEligibility(asset, agreement, pos);
      if (!eligibility.isEligible) {
        rejectedReasons.push({
          assetId: asset.id,
          reason: `Ineligible for ${agreement.name}: ${eligibility.rejectionCriteria.join('; ')}`
        });
        continue;
      }

      const mkt = marketData[asset.id];
      if (!mkt) continue;

      // Unit valuation
      const testVal = calculateValuation(pos.id, asset, mkt, 1000, agreement.baseCurrency);
      const recognisedValuePerThousand = testVal.recognisedCollateralValueUSD;
      const unitRecognisedUSD = recognisedValuePerThousand / 1000;

      const fundingBps = getAssetFundingCostBps(asset, objective, agreement.baseCurrency);
      // Cost per dollar of recognised collateral
      const costPerRecognisedDollar = (fundingBps / 10000) / (unitRecognisedUSD > 0 ? unitRecognisedUSD : 1);

      candidates.push({
        position: pos,
        asset,
        valuationPerUnitUSD: unitRecognisedUSD,
        effectiveHaircut: testVal.effectiveHaircut,
        dirtyPrice: testVal.dirtyPrice,
        fxRate: testVal.fxRateToUSD,
        fundingCostBps: fundingBps,
        costPerRecognisedDollar
      });
    }

    // Sort candidates by cost efficiency: lowest cost per recognised collateral dollar first
    candidates.sort((a, b) => a.costPerRecognisedDollar - b.costPerRecognisedDollar);

    // Track concentration limits for this agreement
    let allocatedEquityUSD = 0;
    const maxEquityUSD = target.requiredTransferUSD * (agreement.eligibilityRule.maxAssetClassConcentrationPct || 0.30);
    const allocatedByIssuerUSD = new Map<string, number>();
    const maxIssuerUSD = target.requiredTransferUSD * (agreement.eligibilityRule.maxIssuerConcentrationPct || 0.25);

    for (const cand of candidates) {
      if (deficitUSD <= 10) break; // obligation satisfied

      const availableUnits = remainingAvailableQuantity.get(cand.position.id) || 0;
      if (availableUnits <= 0) continue;

      // Concentration checks
      if ((cand.asset.assetClass === 'EQUITY' || cand.asset.assetClass === 'ETF') && allocatedEquityUSD >= maxEquityUSD) {
        bindingConstraints.push(`${agreement.name}: Equity concentration ceiling of ${(agreement.eligibilityRule.maxAssetClassConcentrationPct * 100).toFixed(0)}% reached`);
        continue;
      }

      const currentIssuerUSD = allocatedByIssuerUSD.get(cand.asset.issuer) || 0;
      if (currentIssuerUSD >= maxIssuerUSD && cand.asset.assetClass !== 'SOVEREIGN_BOND' && cand.asset.assetClass !== 'CASH') {
        bindingConstraints.push(`${agreement.name}: Issuer limit for ${cand.asset.issuer} reached ($${maxIssuerUSD.toLocaleString()})`);
        continue;
      }

      // Calculate how many units we need
      const unitsNeeded = deficitUSD / cand.valuationPerUnitUSD;
      let unitsToAllocate = Math.min(availableUnits, unitsNeeded);

      // Respect lot size & min denomination
      const lot = cand.asset.lotSize || 1000;
      const minDenom = cand.asset.minDenomination || 1000;
      if (unitsToAllocate < minDenom && unitsToAllocate < availableUnits) {
        unitsToAllocate = minDenom;
      } else {
        unitsToAllocate = Math.floor(unitsToAllocate / lot) * lot;
      }

      if (unitsToAllocate <= 0) continue;

      // Check equity cap
      if (cand.asset.assetClass === 'EQUITY' || cand.asset.assetClass === 'ETF') {
        const potentialUSD = unitsToAllocate * cand.valuationPerUnitUSD;
        if (allocatedEquityUSD + potentialUSD > maxEquityUSD) {
          const allowableUSD = Math.max(0, maxEquityUSD - allocatedEquityUSD);
          unitsToAllocate = Math.floor(allowableUSD / (cand.valuationPerUnitUSD * lot)) * lot;
        }
      }

      if (unitsToAllocate <= 0) continue;

      const recognisedAllocatedUSD = unitsToAllocate * cand.valuationPerUnitUSD;
      const dirtyMktValUSD = (unitsToAllocate * cand.dirtyPrice / (cand.asset.assetClass === 'EQUITY' ? 1 : 100)) * cand.fxRate;
      const costUSD = recognisedAllocatedUSD * (cand.fundingCostBps / 10000);

      itemsForAgreement.push({
        positionId: cand.position.id,
        assetId: cand.asset.id,
        allocatedNominal: unitsToAllocate,
        dirtyMarketValueUSD: dirtyMktValUSD,
        effectiveHaircut: cand.effectiveHaircut,
        recognisedValueUSD: recognisedAllocatedUSD,
        fundingCostBps: cand.fundingCostBps,
        costUSD
      });

      // Update remaining inventory & deficit
      remainingAvailableQuantity.set(cand.position.id, availableUnits - unitsToAllocate);
      deficitUSD = Math.max(0, deficitUSD - recognisedAllocatedUSD);
      grandTotalAllocatedUSD += recognisedAllocatedUSD;
      totalOpportunityCostUSD += costUSD;

      if (cand.asset.assetClass === 'EQUITY' || cand.asset.assetClass === 'ETF') {
        allocatedEquityUSD += recognisedAllocatedUSD;
      }
      allocatedByIssuerUSD.set(cand.asset.issuer, (allocatedByIssuerUSD.get(cand.asset.issuer) || 0) + recognisedAllocatedUSD);
    }

    if (deficitUSD > 100) {
      bindingConstraints.push(`${agreement.name}: Eligible collateral shortfall of $${Math.round(deficitUSD).toLocaleString()} due to inventory limits`);
    }

    allocatedItemsByAgreement.push({
      agreementId: agreement.id,
      items: itemsForAgreement
    });

    // Baseline calculation: if we posted 100% Cash at 5.25% cost
    baselineCashCostUSD += target.requiredTransferUSD * 0.0525;
  }

  // Estimated savings = Baseline Cash Allocation Cost - Optimized Allocation Cost
  const estimatedSavingsUSD = Math.max(0, baselineCashCostUSD - totalOpportunityCostUSD);

  const status = grandTotalAllocatedUSD >= totalRequirementUSD * 0.999 ? 'OPTIMAL' : 'SUB_OPTIMAL';

  return {
    id: runId,
    timestamp: new Date().toISOString(),
    targetAgreementIds: targetAgreements.map(t => t.agreement.id),
    totalRequirementUSD,
    objectiveFunction: objective,
    status,
    totalAllocatedRecognisedUSD: grandTotalAllocatedUSD,
    allocatedItems: allocatedItemsByAgreement,
    totalOpportunityCostUSD,
    estimatedSavingsUSD,
    bindingConstraints: Array.from(new Set(bindingConstraints)),
    rejectedInventoryReasons: rejectedReasons.slice(0, 10),
    approved: false
  };
}
