/**
 * RhinoQuant Collateral Management Platform
 * Deterministic Scenario & Stress Testing Engine
 */

import { StressScenario, StressScenarioResult, AssetMaster, InventoryPosition, MarketDataSnapshot, CollateralAgreement, MarginCall, Counterparty } from '../types/models';
import { calculateValuation } from './valuationEngine';
import { evaluateEligibility } from './eligibilityEngine';

export const PRESET_SCENARIOS: StressScenario[] = [
  {
    id: 'SCEN-SOV-YIELD-SPIKE',
    name: 'Sovereign Yield Spike (+150 bps)',
    description: 'Aggressive central bank rate hike cycle. Global sovereign bond yields jump 150bps, impacting duration-heavy Treasuries, Bunds, and Gilts.',
    sovereignYieldShockBps: 150,
    corpSpreadShockBps: 50,
    equityShockPct: -0.05,
    fxShockUSDDepreciationPct: 0.0,
    haircutShockAddOnPct: 0.01,
    downgradeBBBToHY: false
  },
  {
    id: 'SCEN-CREDIT-SPREAD-WIDENING',
    name: 'Corporate Spread Dislocation (+300 bps)',
    description: 'Corporate credit crisis: investment grade spreads widen +300bps, high yield spreads widen +600bps, triggering liquidity haircuts.',
    sovereignYieldShockBps: -25, // flight to quality
    corpSpreadShockBps: 300,
    equityShockPct: -0.18,
    fxShockUSDDepreciationPct: 0.0,
    haircutShockAddOnPct: 0.04,
    downgradeBBBToHY: true
  },
  {
    id: 'SCEN-GLOBAL-EQUITY-MELTDOWN',
    name: 'Equity Market Crash (-35%)',
    description: 'Severe equity bear market shock. Equities and equity ETFs plunge 35% with secondary margin calls across hedge fund counterparties.',
    sovereignYieldShockBps: -50,
    corpSpreadShockBps: 120,
    equityShockPct: -0.35,
    fxShockUSDDepreciationPct: -0.05,
    haircutShockAddOnPct: 0.05,
    downgradeBBBToHY: false
  },
  {
    id: 'SCEN-FX-DOLLAR-CRUNCH',
    name: 'US Dollar Shortage & FX Devaluation',
    description: 'EUR, GBP, and JPY depreciate 12% against USD. 8% currency mismatch haircuts surge, causing collateral coverage deficits.',
    sovereignYieldShockBps: 20,
    corpSpreadShockBps: 80,
    equityShockPct: -0.08,
    fxShockUSDDepreciationPct: -0.12,
    haircutShockAddOnPct: 0.02,
    downgradeBBBToHY: false
  },
  {
    id: 'SCEN-COMPOUND-LIQUIDITY-STORM',
    name: '2026 Severe Compound Liquidity Crisis',
    description: 'Simultaneous market dislocation: yields +180bps, corporate spreads +350bps, equities -30%, haircuts spiked +6%, BBB debt downgraded to HY.',
    sovereignYieldShockBps: 180,
    corpSpreadShockBps: 350,
    equityShockPct: -0.30,
    fxShockUSDDepreciationPct: -0.08,
    haircutShockAddOnPct: 0.06,
    downgradeBBBToHY: true
  }
];

export function runStressScenario(
  scenario: StressScenario,
  assets: AssetMaster[],
  inventory: InventoryPosition[],
  marketData: Record<string, MarketDataSnapshot>,
  agreements: CollateralAgreement[],
  marginCalls: MarginCall[],
  counterparties: Counterparty[]
): StressScenarioResult {
  const assetMap = new Map(assets.map(a => [a.id, a]));
  const cptyMap = new Map(counterparties.map(c => [c.id, c]));

  let baseRecognisedCollateralUSD = 0;
  let stressedRecognisedCollateralUSD = 0;
  let trappedInventoryUSD = 0;
  let ineligiblePositionsCount = 0;

  // 1. Revalue inventory under baseline vs stressed
  for (const pos of inventory) {
    const asset = assetMap.get(pos.assetId);
    if (!asset) continue;

    const mkt = marketData[asset.id];
    if (!mkt) continue;

    // Baseline valuation
    const baseVal = calculateValuation(pos.id, asset, mkt, pos.totalQuantity);
    baseRecognisedCollateralUSD += baseVal.recognisedCollateralValueUSD;

    // Apply stress shocks to asset market data
    let stressedCleanPrice = mkt.cleanPrice;
    let stressedFxRate = mkt.fxRateToUSD;
    let stressedRating = asset.creditRating;

    // Rating downgrade shock
    if (scenario.downgradeBBBToHY && asset.creditRating === 'BBB') {
      stressedRating = 'BB';
    }

    // Price shock based on duration / spread
    if (asset.assetClass === 'SOVEREIGN_BOND' || asset.assetClass === 'TREASURY_BILL' || asset.assetClass === 'AGENCY_BOND') {
      // Duration estimate ~ 6.5 years for 10Y bonds, 2.5 for 5Y
      const duration = asset.maturityDate?.includes('2034') ? 7.2 : 3.5;
      const yieldChange = scenario.sovereignYieldShockBps / 10000;
      const priceDeltaPct = -duration * yieldChange;
      stressedCleanPrice = Math.max(10, mkt.cleanPrice * (1 + priceDeltaPct));
    } else if (asset.assetClass === 'CORP_INVESTMENT_GRADE' || asset.assetClass === 'CORP_HIGH_YIELD') {
      const spreadChange = scenario.corpSpreadShockBps / 10000;
      const spreadDuration = 4.8;
      const priceDeltaPct = -spreadDuration * spreadChange;
      stressedCleanPrice = Math.max(10, mkt.cleanPrice * (1 + priceDeltaPct));
    } else if (asset.assetClass === 'EQUITY' || asset.assetClass === 'ETF') {
      stressedCleanPrice = Math.max(1, mkt.cleanPrice * (1 + scenario.equityShockPct));
    }

    // FX Shock for non-USD assets
    if (asset.currency !== 'USD') {
      stressedFxRate = mkt.fxRateToUSD * (1 + scenario.fxShockUSDDepreciationPct);
    }

    const stressedMkt: MarketDataSnapshot = {
      ...mkt,
      cleanPrice: stressedCleanPrice,
      fxRateToUSD: stressedFxRate
    };

    const stressedAsset: AssetMaster = {
      ...asset,
      creditRating: stressedRating
    };

    // Stressed valuation with haircut add-on shock
    const stressedVal = calculateValuation(pos.id, stressedAsset, stressedMkt, pos.totalQuantity);
    // Apply extra haircut shock
    const stressedHaircut = Math.min(0.95, stressedVal.effectiveHaircut + scenario.haircutShockAddOnPct);
    const finalStressedRecognisedUSD = stressedVal.dirtyMarketValueUSD * (1.0 - stressedHaircut);

    stressedRecognisedCollateralUSD += finalStressedRecognisedUSD;

    // Ineligible checks under stress
    if (stressedRating === 'BB' && asset.assetClass === 'CORP_INVESTMENT_GRADE') {
      ineligiblePositionsCount++;
      trappedInventoryUSD += stressedVal.dirtyMarketValueUSD;
    }
  }

  const collateralValueDropUSD = Math.max(0, baseRecognisedCollateralUSD - stressedRecognisedCollateralUSD);
  const collateralValueDropPct = baseRecognisedCollateralUSD > 0 ? (collateralValueDropUSD / baseRecognisedCollateralUSD) : 0;

  // 2. Counterparty margin call impact
  const counterpartyImpacts: StressScenarioResult['counterpartyImpacts'] = [];
  let totalAdditionalLiquidityRequiredUSD = 0;
  let baseMarginDeficitUSD = 0;
  let stressedMarginDeficitUSD = 0;

  for (const call of marginCalls) {
    const agreement = agreements.find(a => a.id === call.agreementId);
    const cpty = counterparties.find(c => c.id === call.counterpartyId);
    if (!agreement || !cpty) continue;

    baseMarginDeficitUSD += Math.max(0, call.requiredTransferAmountUSD);

    // Stressed exposure jumps: derivatives MtM often moves under yield/equity shocks
    const exposureJumpPct = Math.abs(scenario.equityShockPct) * 0.4 + (Math.abs(scenario.sovereignYieldShockBps) / 2000);
    const stressedExposureUSD = call.currentExposureUSD * (1 + exposureJumpPct);
    const stressedHeldUSD = call.collateralHeldRecognisedUSD * (1 - collateralValueDropPct);

    const stressedShortfall = Math.max(0, stressedExposureUSD - stressedHeldUSD - agreement.threshold);
    const additionalCall = Math.max(0, stressedShortfall - call.requiredTransferAmountUSD);

    totalAdditionalLiquidityRequiredUSD += additionalCall;
    stressedMarginDeficitUSD += stressedShortfall;

    counterpartyImpacts.push({
      counterpartyId: cpty.id,
      counterpartyName: cpty.name,
      additionalCallRequiredUSD: Math.round(additionalCall),
      breachFlag: additionalCall > 5_000_000 // Flag if excess call > $5M
    });
  }

  return {
    scenarioId: scenario.id,
    scenarioName: scenario.name,
    baseRecognisedCollateralUSD,
    stressedRecognisedCollateralUSD,
    collateralValueDropUSD,
    collateralValueDropPct,
    baseMarginDeficitUSD,
    stressedMarginDeficitUSD,
    additionalLiquidityRequiredUSD: totalAdditionalLiquidityRequiredUSD,
    ineligiblePositionsCount,
    trappedInventoryValueUSD: trappedInventoryUSD,
    counterpartyImpacts
  };
}
