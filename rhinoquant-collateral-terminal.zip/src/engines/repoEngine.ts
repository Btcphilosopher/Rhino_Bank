/**
 * RhinoQuant Collateral Management Platform
 * Repo Engine - Secured Funding Analytics, Interest Accrual, and Controlled Two-Leg Substitution
 */

import { RepoTrade, DayCountConvention, AssetMaster, InventoryPosition, CollateralAgreement } from '../types/models';
import { calculateValuation } from './valuationEngine';
import { evaluateEligibility } from './eligibilityEngine';
import { MarketDataSnapshot } from '../types/models';

/**
 * Calculates repo interest accrual using contractual day-count convention
 */
export function calculateRepoInterest(
  principal: number,
  annualRate: number,
  startDateStr: string,
  asOfDateStr: string,
  dayCount: DayCountConvention
): { interest: number; actualDays: number; yearFraction: number } {
  const start = new Date(startDateStr);
  const asOf = new Date(asOfDateStr);
  const diffTime = Math.max(0, asOf.getTime() - start.getTime());
  const actualDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

  let divisor = 360;
  if (dayCount === 'ACT/365') divisor = 365;
  if (dayCount === 'ACT/ACT') {
    const year = asOf.getFullYear();
    divisor = ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0) ? 366 : 365;
  }

  const yearFraction = actualDays / divisor;
  const interest = principal * annualRate * yearFraction;

  return { interest, actualDays, yearFraction };
}

/**
 * Calculates current repo position coverage and margin maintenance status
 */
export function evaluateRepoPosition(
  trade: RepoTrade,
  asset: AssetMaster,
  marketData: MarketDataSnapshot,
  asOfDate: string = '2026-10-24'
): {
  accruedInterest: number;
  totalLiabilityUSD: number;
  currentDirtyMarketValueUSD: number;
  currentRecognisedValueUSD: number;
  collateralCoverageRatio: number;
  marginDeficitOrSurplusUSD: number;
  isBreached: boolean;
} {
  const { interest } = calculateRepoInterest(
    trade.cashPrincipal,
    trade.repoRate,
    trade.startDate,
    asOfDate,
    trade.dayCount
  );

  const totalLiabilityUSD = trade.cashPrincipal + interest;

  const valuation = calculateValuation(
    `REPO-POS-${trade.id}`,
    asset,
    marketData,
    trade.collateralNominal,
    trade.currency
  );

  const currentDirtyMarketValueUSD = valuation.dirtyMarketValueUSD;
  const currentRecognisedValueUSD = valuation.recognisedCollateralValueUSD;
  const collateralCoverageRatio = totalLiabilityUSD > 0 ? (currentRecognisedValueUSD / totalLiabilityUSD) : 1.0;
  
  // Margin deficit if recognized collateral < liability * maintenance threshold
  const requiredCollateralUSD = totalLiabilityUSD * trade.marginMaintenanceThreshold;
  const marginDeficitOrSurplusUSD = currentRecognisedValueUSD - requiredCollateralUSD;
  const isBreached = marginDeficitOrSurplusUSD < 0;

  return {
    accruedInterest: interest,
    totalLiabilityUSD,
    currentDirtyMarketValueUSD,
    currentRecognisedValueUSD,
    collateralCoverageRatio,
    marginDeficitOrSurplusUSD,
    isBreached
  };
}

export interface SubstitutionValidationResult {
  allowed: boolean;
  validationErrors: string[];
  proposedReplacementValuation?: {
    dirtyMarketValueUSD: number;
    effectiveHaircut: number;
    recognisedValueUSD: number;
  };
  coverageAfterSubstitution?: number;
}

/**
 * Two-Leg Substitution Validation:
 * Leg 1: Validate replacement collateral eligibility, availability, and haircut coverage
 * Leg 2: Release existing collateral ONLY if Leg 1 passes!
 */
export function validateCollateralSubstitution(
  trade: RepoTrade,
  currentAsset: AssetMaster,
  replacementAsset: AssetMaster,
  replacementPosition: InventoryPosition,
  replacementQuantity: number,
  marketData: Record<string, MarketDataSnapshot>,
  syntheticAgreement: CollateralAgreement
): SubstitutionValidationResult {
  const errors: string[] = [];

  // 1. Availability check of replacement asset
  const freeQty = Math.max(0, replacementPosition.totalQuantity - replacementPosition.pledgedQuantity - replacementPosition.pendingDeliveryQuantity - replacementPosition.frozenDisputedQuantity);
  if (replacementQuantity > freeQty) {
    errors.push(`Requested replacement quantity (${replacementQuantity.toLocaleString()}) exceeds free inventory (${freeQty.toLocaleString()})`);
  }

  // 2. Eligibility of replacement security under trade/GMRA agreement
  const eligibility = evaluateEligibility(replacementAsset, syntheticAgreement, replacementPosition);
  if (!eligibility.isEligible) {
    errors.push(`Replacement asset ${replacementAsset.isin} (${replacementAsset.name}) is INELIGIBLE: ${eligibility.rejectionCriteria.join('; ')}`);
  }

  // 3. Check valuation and coverage sufficiency
  const repMkt = marketData[replacementAsset.id];
  if (!repMkt) {
    errors.push(`Market data unavailable for replacement asset ${replacementAsset.isin}`);
    return { allowed: false, validationErrors: errors };
  }

  const replacementVal = calculateValuation(
    replacementPosition.id,
    replacementAsset,
    repMkt,
    replacementQuantity,
    trade.currency
  );

  const { totalLiabilityUSD } = evaluateRepoPosition(trade, currentAsset, marketData[currentAsset.id]);
  const newCoverage = replacementVal.recognisedCollateralValueUSD / (totalLiabilityUSD > 0 ? totalLiabilityUSD : 1);

  if (newCoverage < trade.marginMaintenanceThreshold) {
    errors.push(`Replacement recognised value ($${Math.round(replacementVal.recognisedCollateralValueUSD).toLocaleString()}) yields coverage ratio of ${(newCoverage * 100).toFixed(1)}%, below required ${(trade.marginMaintenanceThreshold * 100).toFixed(1)}%`);
  }

  const allowed = errors.length === 0;

  return {
    allowed,
    validationErrors: errors,
    proposedReplacementValuation: {
      dirtyMarketValueUSD: replacementVal.dirtyMarketValueUSD,
      effectiveHaircut: replacementVal.effectiveHaircut,
      recognisedValueUSD: replacementVal.recognisedCollateralValueUSD
    },
    coverageAfterSubstitution: newCoverage
  };
}
