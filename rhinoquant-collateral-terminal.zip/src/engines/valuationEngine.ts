/**
 * RhinoQuant Collateral Management Platform
 * Valuation Engine - Deterministic Pricing, Accrued Interest, FX, and Haircuts
 */

import { AssetMaster, MarketDataSnapshot, PositionValuation, HaircutAdjustment, DayCountConvention } from '../types/models';

/**
 * Calculates accrued interest factor for fixed income instruments based on day count convention
 */
export function calculateAccruedInterest(
  couponRate: number,
  couponFrequency: number,
  dayCount: DayCountConvention,
  issueOrLastCouponDate: string,
  valuationDate: string
): number {
  if (couponRate <= 0) return 0;

  const d1 = new Date(issueOrLastCouponDate);
  const d2 = new Date(valuationDate);
  const diffMs = Math.max(0, d2.getTime() - d1.getTime());
  const actualDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  let yearFraction = 0;
  switch (dayCount) {
    case 'ACT/360':
      yearFraction = actualDays / 360;
      break;
    case 'ACT/365':
      yearFraction = actualDays / 365;
      break;
    case '30/360': {
      const y1 = d1.getFullYear();
      const m1 = d1.getMonth() + 1;
      const day1 = Math.min(30, d1.getDate());
      const y2 = d2.getFullYear();
      const m2 = d2.getMonth() + 1;
      const day2 = day1 === 30 ? Math.min(30, d2.getDate()) : d2.getDate();
      const days360 = (y2 - y1) * 360 + (m2 - m1) * 30 + (day2 - day1);
      yearFraction = days360 / 360;
      break;
    }
    case 'ACT/ACT':
    default: {
      const year = d2.getFullYear();
      const isLeap = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
      yearFraction = actualDays / (isLeap ? 366 : 365);
      break;
    }
  }

  // Accrued interest as a percentage of par (e.g. 0.0125 = 1.25% of par)
  return couponRate * yearFraction;
}

/**
 * Base Haircut Schedule based on Basel / BCBS-IOSCO non-cleared margin standards
 */
export function getBaseHaircut(asset: AssetMaster): number {
  if (asset.assetClass === 'CASH') {
    return 0.0;
  }

  if (asset.assetClass === 'TREASURY_BILL') {
    return 0.005; // 0.5%
  }

  if (asset.assetClass === 'SOVEREIGN_BOND' || asset.assetClass === 'AGENCY_BOND') {
    // Maturity bucket calculation
    const yearsToMaturity = getRemainingMaturityYears(asset.maturityDate);
    if (yearsToMaturity <= 1) return 0.005; // 0.5%
    if (yearsToMaturity <= 5) return 0.02;  // 2.0%
    if (yearsToMaturity <= 10) return 0.04; // 4.0%
    return 0.06; // >10Y: 6.0%
  }

  if (asset.assetClass === 'CORP_INVESTMENT_GRADE') {
    const yearsToMaturity = getRemainingMaturityYears(asset.maturityDate);
    if (asset.creditRating === 'AAA' || asset.creditRating === 'AA') {
      return yearsToMaturity <= 5 ? 0.04 : 0.08;
    }
    if (asset.creditRating === 'A' || asset.creditRating === 'BBB') {
      return yearsToMaturity <= 5 ? 0.06 : 0.12;
    }
    return 0.15;
  }

  if (asset.assetClass === 'CORP_HIGH_YIELD') {
    return 0.25; // 25% for high yield
  }

  if (asset.assetClass === 'EQUITY' || asset.assetClass === 'ETF') {
    return 0.15; // 15% standard equity haircut (main index)
  }

  if (asset.assetClass === 'MONEY_MARKET') {
    return 0.01; // 1%
  }

  return 0.20; // Default conservative haircut
}

export function getRemainingMaturityYears(maturityDate?: string): number {
  if (!maturityDate) return 0;
  const today = new Date('2026-10-24');
  const mat = new Date(maturityDate);
  const diffDays = (mat.getTime() - today.getTime()) / (1000 * 60 * 60 * 24);
  return Math.max(0, diffDays / 365.25);
}

/**
 * Calculates complete position valuation with full haircut breakdown
 */
export function calculateValuation(
  positionId: string,
  asset: AssetMaster,
  marketData: MarketDataSnapshot,
  nominalQuantity: number,
  agreementBaseCurrency: string = 'USD',
  issuerConcentrationRatio: number = 0.05
): PositionValuation {
  let cleanPrice = marketData.cleanPrice;
  let accruedInterest = 0;
  let dirtyPrice = cleanPrice;
  let cleanMarketValueLocal = 0;
  let dirtyMarketValueLocal = 0;

  if (asset.assetClass === 'CASH') {
    cleanPrice = 1.0;
    accruedInterest = 0;
    dirtyPrice = 1.0;
    cleanMarketValueLocal = nominalQuantity;
    dirtyMarketValueLocal = nominalQuantity;
  } else if (asset.assetClass === 'EQUITY' || asset.assetClass === 'ETF') {
    // Equities: price is per share
    accruedInterest = 0;
    dirtyPrice = cleanPrice;
    cleanMarketValueLocal = nominalQuantity * cleanPrice;
    dirtyMarketValueLocal = cleanMarketValueLocal;
  } else {
    // Fixed Income / Bonds: Clean price is quote in % of par (e.g. 99.50)
    // Accrued interest is added to dirty price
    accruedInterest = marketData.accruedInterestRate ?? (
      asset.couponRate ? calculateAccruedInterest(
        asset.couponRate,
        asset.couponFrequency || 2,
        asset.dayCount,
        asset.issueDate || '2026-01-01',
        '2026-10-24'
      ) * 100 : 0
    );

    dirtyPrice = cleanPrice + accruedInterest;
    cleanMarketValueLocal = (nominalQuantity * cleanPrice) / 100;
    dirtyMarketValueLocal = (nominalQuantity * dirtyPrice) / 100;
  }

  const fxRateToUSD = marketData.fxRateToUSD;
  const dirtyMarketValueUSD = dirtyMarketValueLocal * fxRateToUSD;

  // Base haircut
  const baseHaircut = getBaseHaircut(asset);
  const adjustments: HaircutAdjustment[] = [];

  // Currency mismatch adjustment: +8% if collateral currency differs from agreement base currency
  if (asset.currency !== agreementBaseCurrency && asset.assetClass !== 'CASH') {
    adjustments.push({
      name: 'FX Mismatch Surcharge',
      bps: 800, // 8.0%
      reason: `Collateral currency (${asset.currency}) does not match Agreement base currency (${agreementBaseCurrency})`
    });
  } else if (asset.currency !== agreementBaseCurrency && asset.assetClass === 'CASH') {
    // Cash in foreign currency also suffers 8% regulatory FX haircut under BCBS-IOSCO
    adjustments.push({
      name: 'Cash FX Mismatch',
      bps: 800,
      reason: `Foreign currency cash (${asset.currency}) held against ${agreementBaseCurrency} exposure`
    });
  }

  // Concentration add-on if single issuer exceeds threshold
  let concentrationHaircutAddOn = 0;
  if (issuerConcentrationRatio > 0.20 && asset.assetClass !== 'SOVEREIGN_BOND' && asset.assetClass !== 'CASH') {
    const addOn = 0.05; // +5%
    concentrationHaircutAddOn = addOn;
    adjustments.push({
      name: 'Issuer Concentration Surcharge',
      bps: 500,
      reason: `Issuer allocation (${(issuerConcentrationRatio * 100).toFixed(1)}%) exceeds 20% concentration ceiling`
    });
  }

  // Liquidity adjustment for non-benchmark high yield or lower rating
  let liquidityAdjustment = 0;
  if (asset.assetClass === 'CORP_HIGH_YIELD' || asset.creditRating === 'BB' || asset.creditRating === 'B') {
    liquidityAdjustment = 0.03; // +3%
    adjustments.push({
      name: 'Liquidity & Spread Premium',
      bps: 300,
      reason: 'Sub-investment grade secondary market liquidity discount'
    });
  }

  const totalAdjustmentRate = adjustments.reduce((acc, curr) => acc + (curr.bps / 10000), 0);
  const effectiveHaircut = Math.min(1.0, Math.max(0.0, baseHaircut + totalAdjustmentRate));

  // Recognised Collateral Value:
  // Recognised Value = Dirty MV USD * (1 - Effective Haircut)
  const recognisedCollateralValueUSD = Math.max(0, dirtyMarketValueUSD * (1.0 - effectiveHaircut));

  return {
    positionId,
    assetId: asset.id,
    nominalQuantity,
    cleanPrice,
    accruedInterest,
    dirtyPrice,
    cleanMarketValueLocal,
    dirtyMarketValueLocal,
    fxRateToUSD,
    dirtyMarketValueUSD,
    baseHaircut,
    adjustments,
    effectiveHaircut,
    concentrationHaircutAddOn,
    liquidityAdjustment,
    recognisedCollateralValueUSD,
    calculationTimestamp: new Date().toISOString(),
    ruleVersion: '2026.4-BCBS-IOSCO'
  };
}
