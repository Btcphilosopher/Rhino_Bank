/**
 * RhinoQuant Collateral Management Platform
 * Reconciliation & Settlement Engine
 */

import { InventoryPosition, AssetMaster, CustodyLocation, ReconciliationRecord, SettlementInstruction } from '../types/models';
import { MarketDataSnapshot } from '../types/models';

export interface ExternalCustodyStatementLine {
  custodian: CustodyLocation;
  accountNumber: string;
  isin: string;
  statementQuantity: number;
  statementDirtyPrice?: number;
  statementMarketValueUSD: number;
  statementDate: string;
}

export function performCustodyReconciliation(
  internalPositions: InventoryPosition[],
  assets: AssetMaster[],
  marketData: Record<string, MarketDataSnapshot>,
  externalStatements: ExternalCustodyStatementLine[]
): ReconciliationRecord[] {
  const assetByIsin = new Map(assets.map(a => [a.isin, a]));
  const results: ReconciliationRecord[] = [];

  // Group internal positions by isin + custodian
  const internalMap = new Map<string, { totalQty: number; asset: AssetMaster }>();
  for (const pos of internalPositions) {
    const asset = assets.find(a => a.id === pos.assetId);
    if (!asset) continue;
    const key = `${asset.isin}-${pos.custodian}`;
    const existing = internalMap.get(key) || { totalQty: 0, asset };
    existing.totalQty += pos.totalQuantity;
    internalMap.set(key, existing);
  }

  // Compare against external statements
  const seenKeys = new Set<string>();

  for (const stmt of externalStatements) {
    const key = `${stmt.isin}-${stmt.custodian}`;
    seenKeys.add(key);
    const internal = internalMap.get(key);
    const asset = assetByIsin.get(stmt.isin);
    const assetId = asset?.id || 'UNKNOWN';

    const internalQty = internal ? internal.totalQty : 0;
    const diffQty = internalQty - stmt.statementQuantity;

    const mkt = asset ? marketData[asset.id] : undefined;
    const price = mkt ? mkt.cleanPrice : 100;
    const fx = mkt ? mkt.fxRateToUSD : 1.0;
    const internalMV = (internalQty * price / (asset?.assetClass === 'EQUITY' ? 1 : 100)) * fx;
    const diffMV = Math.abs(internalMV - stmt.statementMarketValueUSD);

    if (diffQty === 0 && diffMV < 100) {
      results.push({
        id: `REC-${stmt.isin}-${stmt.custodian}`,
        reconciliationDate: stmt.statementDate,
        sourceSystem: 'RHINO_INTERNAL_LEDGER',
        targetSystem: stmt.custodian,
        assetId,
        internalQuantity: internalQty,
        externalQuantity: stmt.statementQuantity,
        differenceQuantity: 0,
        internalMarketValueUSD: internalMV,
        externalMarketValueUSD: stmt.statementMarketValueUSD,
        differenceMarketValueUSD: 0,
        status: 'MATCHED',
        severity: 'LOW',
        ageDays: 0,
        resolutionStatus: 'RESOLVED',
        notes: 'Positions fully reconciled within tolerance.'
      });
    } else {
      const severity = diffMV > 5_000_000 ? 'CRITICAL' : diffMV > 1_000_000 ? 'HIGH' : 'MEDIUM';
      results.push({
        id: `REC-${stmt.isin}-${stmt.custodian}`,
        reconciliationDate: stmt.statementDate,
        sourceSystem: 'RHINO_INTERNAL_LEDGER',
        targetSystem: stmt.custodian,
        assetId,
        internalQuantity: internalQty,
        externalQuantity: stmt.statementQuantity,
        differenceQuantity: diffQty,
        internalMarketValueUSD: internalMV,
        externalMarketValueUSD: stmt.statementMarketValueUSD,
        differenceMarketValueUSD: diffMV,
        status: 'UNMATCHED',
        severity,
        ageDays: diffMV > 5_000_000 ? 3 : 1,
        assignedAnalyst: 'J. Henderson (Custody Ops)',
        resolutionStatus: 'OPEN',
        notes: diffQty > 0 
          ? `Internal ledger shows ${diffQty.toLocaleString()} units surplus vs ${stmt.custodian} statement; likely unsettled pending delivery.`
          : `External statement shows ${Math.abs(diffQty).toLocaleString()} more units; potential unbooked incoming pledge.`
      });
    }
  }

  return results;
}

export function createSettlementInstructionFromMarginCall(
  marginCallId: string,
  assetId: string,
  quantity: number,
  currency: any,
  custodian: CustodyLocation,
  counterpartyId: string,
  counterpartyBic: string
): SettlementInstruction {
  const ref = `SWIFT-MT542-${Date.now().toString().slice(-6)}`;
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);

  return {
    id: `SETTLE-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    instructionRef: ref,
    marginCallId,
    direction: 'FREE_OF_PAYMENT_DELIVERY',
    assetId,
    quantity,
    currency,
    custodian,
    counterpartyId,
    counterpartyBic,
    intendedSettlementDate: tomorrow.toISOString().slice(0, 10),
    status: 'TRANSMITTED',
    createdTimestamp: new Date().toISOString()
  };
}
