/**
 * RhinoQuant Collateral Management Platform
 * Margin Engine - Exposure Netting, Thresholds, MTA, Rounding, and Lifecycle
 */

import { CollateralAgreement, MarginCall, MarginCallDirection, MarginCallStatus } from '../types/models';

export interface ExposureSnapshot {
  agreementId: string;
  counterpartyId: string;
  valuationDate: string;
  currentMarkToMarketUSD: number;
  initialMarginUSD: number;
  variationMarginUSD: number;
  collateralHeldRecognisedUSD: number;
  collateralDeliveredRecognisedUSD: number;
  disputedAmountUSD?: number;
  pendingTransfersUSD?: number;
}

/**
 * Calculates deterministic margin call based on ISDA / GMRA contractual netting rules
 */
export function calculateMarginCall(
  snapshot: ExposureSnapshot,
  agreement: CollateralAgreement,
  existingCallsForDay: MarginCall[] = []
): { call: MarginCall; isDuplicate: boolean } {
  const dateStr = snapshot.valuationDate.slice(0, 10);
  const idempotencyKey = `MC-${agreement.code}-${dateStr}-V${agreement.version}`;

  // Check for duplicate call
  const duplicate = existingCallsForDay.find(c => c.idempotencyKey === idempotencyKey);
  if (duplicate) {
    return { call: duplicate, isDuplicate: true };
  }

  const explanations: string[] = [];

  // Step 1: Gross exposure calculation
  // Total obligation = Current MtM + IM requirement + Independent Amount
  const totalRequirementUSD = snapshot.variationMarginUSD + snapshot.initialMarginUSD + agreement.independentAmount;
  explanations.push(`1. Portfolio MtM & Exposure: Variation Margin = $${snapshot.variationMarginUSD.toLocaleString()}, Initial Margin = $${snapshot.initialMarginUSD.toLocaleString()}, Independent Amount = $${agreement.independentAmount.toLocaleString()} -> Total Obligation = $${totalRequirementUSD.toLocaleString()}`);

  // Step 2: Recognised Collateral on Hand
  // Net collateral = Collateral Held - Collateral Delivered + Pending
  const netCollateralRecognisedUSD = snapshot.collateralHeldRecognisedUSD - snapshot.collateralDeliveredRecognisedUSD;
  explanations.push(`2. Available Collateral: Recognised Collateral Held = $${snapshot.collateralHeldRecognisedUSD.toLocaleString()}, Collateral Delivered = $${snapshot.collateralDeliveredRecognisedUSD.toLocaleString()} -> Net Recognized Balance = $${netCollateralRecognisedUSD.toLocaleString()}`);

  // Step 3: Uncollateralized Exposure / Deficit
  // Deficit = Total Requirement - Net Collateral
  const grossExcessShortfallUSD = totalRequirementUSD - netCollateralRecognisedUSD;
  explanations.push(`3. Gross Margin Variance: Total Requirement ($${totalRequirementUSD.toLocaleString()}) - Net Held ($${netCollateralRecognisedUSD.toLocaleString()}) = ${grossExcessShortfallUSD >= 0 ? 'Shortfall' : 'Excess'} of $${Math.abs(grossExcessShortfallUSD).toLocaleString()}`);

  // Step 4: Threshold application
  // If shortfall > threshold, only excess over threshold is callable
  // If excess (return call), threshold usually does not buffer unless specified
  let netCallableAmountUSD = 0;
  let direction: MarginCallDirection = 'NO_CALL';

  if (grossExcessShortfallUSD > 0) {
    // Delivery required from counterparty
    const unhedgedAboveThreshold = Math.max(0, grossExcessShortfallUSD - agreement.threshold);
    explanations.push(`4. Threshold Check: Shortfall ($${grossExcessShortfallUSD.toLocaleString()}) vs Agreement Threshold ($${agreement.threshold.toLocaleString()}) -> Net Callable = $${unhedgedAboveThreshold.toLocaleString()}`);
    netCallableAmountUSD = unhedgedAboveThreshold;
    direction = 'DELIVER_COLLATERAL';
  } else if (grossExcessShortfallUSD < 0) {
    // Excess collateral held by us; counterparty entitled to return
    netCallableAmountUSD = Math.abs(grossExcessShortfallUSD);
    explanations.push(`4. Excess Collateral Return: Excess ($${netCallableAmountUSD.toLocaleString()}) held eligible for return`);
    direction = 'RETURN_COLLATERAL';
  } else {
    explanations.push(`4. Balanced Position: Exposure exactly matches recognized collateral.`);
    direction = 'NO_CALL';
  }

  // Step 5: Minimum Transfer Amount (MTA) check
  let roundedTransferAmountUSD = 0;
  if (netCallableAmountUSD < agreement.minimumTransferAmount) {
    explanations.push(`5. MTA Test: Net callable amount ($${netCallableAmountUSD.toLocaleString()}) is below contractual MTA ($${agreement.minimumTransferAmount.toLocaleString()}) -> Call SUPPRESSED to $0.00.`);
    roundedTransferAmountUSD = 0;
    direction = 'NO_CALL';
  } else {
    explanations.push(`5. MTA Test: Net callable amount ($${netCallableAmountUSD.toLocaleString()}) exceeds MTA ($${agreement.minimumTransferAmount.toLocaleString()}) -> Transfer approved.`);

    // Step 6: Rounding increment
    const increment = agreement.roundingIncrement > 0 ? agreement.roundingIncrement : 1;
    // Standard ISDA rounding: round down or to nearest increment
    roundedTransferAmountUSD = Math.floor(netCallableAmountUSD / increment) * increment;
    explanations.push(`6. Contractual Rounding: Rounding to increment of $${increment.toLocaleString()} -> Final Transfer Obligation = $${roundedTransferAmountUSD.toLocaleString()}`);
  }

  // Step 7: FX conversion if call currency != USD
  // For simplicity, 1:1 or direct FX
  const callCurrency = agreement.baseCurrency;
  const requiredTransferAmountInCallCurrency = roundedTransferAmountUSD; // base currency match

  const deadline = new Date();
  deadline.setHours(deadline.getHours() + 6); // 6 hours settlement cutoff

  const call: MarginCall = {
    id: `MC-${Date.now().toString(36).toUpperCase()}-${Math.floor(Math.random() * 900 + 100)}`,
    idempotencyKey,
    agreementId: agreement.id,
    counterpartyId: agreement.counterpartyId,
    callDate: dateStr,
    currentExposureUSD: snapshot.currentMarkToMarketUSD,
    initialMarginRequirementUSD: snapshot.initialMarginUSD,
    variationMarginRequirementUSD: snapshot.variationMarginUSD,
    totalRequirementUSD,
    collateralHeldRecognisedUSD: snapshot.collateralHeldRecognisedUSD,
    collateralDeliveredRecognisedUSD: snapshot.collateralDeliveredRecognisedUSD,
    netCollateralRecognisedUSD,
    grossExcessShortfallUSD,
    thresholdUSD: agreement.threshold,
    minimumTransferAmountUSD: agreement.minimumTransferAmount,
    roundingIncrementUSD: agreement.roundingIncrement,
    requiredTransferAmountUSD: roundedTransferAmountUSD,
    direction,
    callCurrency,
    requiredTransferAmountInCallCurrency,
    status: roundedTransferAmountUSD > 0 ? 'CALCULATED' : 'SETTLED',
    deadlineTimestamp: deadline.toISOString(),
    calculationExplanation: explanations,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1
  };

  return { call, isDuplicate: false };
}

/**
 * Validates state transition according to financial controls
 */
export function validateMarginCallTransition(
  currentStatus: MarginCallStatus,
  targetStatus: MarginCallStatus
): { valid: boolean; reason?: string } {
  const allowedTransitions: Record<MarginCallStatus, MarginCallStatus[]> = {
    DRAFT: ['CALCULATED', 'CANCELLED'],
    CALCULATED: ['PENDING_APPROVAL', 'CANCELLED'],
    PENDING_APPROVAL: ['ISSUED', 'CANCELLED'],
    ISSUED: ['ACKNOWLEDGED', 'DISPUTED', 'CANCELLED'],
    ACKNOWLEDGED: ['AGREED', 'DISPUTED'],
    DISPUTED: ['AGREED', 'CANCELLED'],
    AGREED: ['PARTIALLY_SETTLED', 'SETTLED', 'FAILED'],
    PARTIALLY_SETTLED: ['SETTLED', 'FAILED'],
    SETTLED: [],
    CANCELLED: [],
    FAILED: ['PENDING_APPROVAL', 'CANCELLED']
  };

  const allowed = allowedTransitions[currentStatus] || [];
  if (!allowed.includes(targetStatus)) {
    return {
      valid: false,
      reason: `Illegal state transition from ${currentStatus} to ${targetStatus}. Must follow operational governance workflow.`
    };
  }

  return { valid: true };
}
