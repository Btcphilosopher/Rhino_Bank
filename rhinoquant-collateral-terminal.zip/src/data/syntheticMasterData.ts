/**
 * RhinoQuant Collateral Management Platform
 * Realistic Institutional Demonstration Master Data
 * Counterparties, Assets, Agreements, Inventory, and Custody Statements
 */

import { 
  AssetMaster, 
  MarketDataSnapshot, 
  InventoryPosition, 
  CollateralAgreement, 
  Counterparty, 
  RepoTrade,
  MarginCall
} from '../types/models';
import { ExternalCustodyStatementLine } from '../engines/reconciliationEngine';

export const INITIAL_COUNTERPARTIES: Counterparty[] = [
  {
    id: 'CP-RHINO-GM',
    lei: '549300RHINO00000018',
    name: 'Rhino Global Markets Ltd',
    shortCode: 'RHINO-GM',
    domicile: 'United Kingdom',
    creditRating: 'AA',
    contactEmail: 'collateral.ops@rhinobank.com',
    settlementBic: 'RHINOGB2L',
    nettingEligible: true,
    tier: 'TIER_1_DEALER'
  },
  {
    id: 'CP-BNP',
    lei: '645084812KS58BNP0012',
    name: 'BNP Paribas Arbitrage SNC',
    shortCode: 'BNP-ARB',
    domicile: 'France',
    creditRating: 'A',
    contactEmail: 'collateral-paris@bnpparibas.com',
    settlementBic: 'BNPAFRPP',
    nettingEligible: true,
    tier: 'TIER_1_DEALER'
  },
  {
    id: 'CP-GS',
    lei: 'W22LROWP2IHZNBB6K528',
    name: 'Goldman Sachs International',
    shortCode: 'GSI-LDN',
    domicile: 'United Kingdom',
    creditRating: 'A',
    contactEmail: 'gsi-margin-ops@gs.com',
    settlementBic: 'GSIBLONN',
    nettingEligible: true,
    tier: 'TIER_1_DEALER'
  },
  {
    id: 'CP-CITADEL',
    lei: '549300E4F3CITADEL019',
    name: 'Citadel Securities (Europe) Ltd',
    shortCode: 'CITADEL',
    domicile: 'United Kingdom',
    creditRating: 'AA',
    contactEmail: 'collateral@citadelsecurities.com',
    settlementBic: 'CITDGB22',
    nettingEligible: true,
    tier: 'HEDGE_FUND'
  },
  {
    id: 'CP-MILLENNIUM',
    lei: '213800MILLENNIUM0182',
    name: 'Millennium Capital Partners LLP',
    shortCode: 'MLM-CAP',
    domicile: 'United Kingdom',
    creditRating: 'A',
    contactEmail: 'treasury@mlp.com',
    settlementBic: 'MLCPGB2L',
    nettingEligible: true,
    tier: 'HEDGE_FUND'
  },
  {
    id: 'CP-EUREX',
    lei: '529900EUREX000000010',
    name: 'Eurex Clearing AG',
    shortCode: 'EUREX-CCP',
    domicile: 'Germany',
    creditRating: 'AAA',
    contactEmail: 'risk-clearing@eurex.com',
    settlementBic: 'ECAGDEFF',
    nettingEligible: true,
    tier: 'CLEARING_HOUSE'
  }
];

export const INITIAL_ASSETS: AssetMaster[] = [
  {
    id: 'AST-UST-10Y',
    isin: 'US91282CKL71',
    cusip: '91282CKL7',
    ticker: 'T 4.25 11/15/34',
    name: 'US Treasury Note 4.250% 15-Nov-2034',
    assetClass: 'SOVEREIGN_BOND',
    issuer: 'US Department of the Treasury',
    issuerCountry: 'United States',
    currency: 'USD',
    creditRating: 'AAA',
    maturityDate: '2034-11-15',
    issueDate: '2024-11-15',
    couponRate: 0.0425,
    couponFrequency: 2,
    dayCount: 'ACT/ACT',
    minDenomination: 1000,
    lotSize: 1000,
    repoEligible: true,
    centralBankEligible: true,
    benchmarkSecurity: true
  },
  {
    id: 'AST-UST-2Y',
    isin: 'US91282CKM54',
    cusip: '91282CKM5',
    ticker: 'T 4.75 10/31/26',
    name: 'US Treasury Note 4.750% 31-Oct-2026',
    assetClass: 'SOVEREIGN_BOND',
    issuer: 'US Department of the Treasury',
    issuerCountry: 'United States',
    currency: 'USD',
    creditRating: 'AAA',
    maturityDate: '2026-10-31',
    issueDate: '2024-10-31',
    couponRate: 0.0475,
    couponFrequency: 2,
    dayCount: 'ACT/ACT',
    minDenomination: 1000,
    lotSize: 1000,
    repoEligible: true,
    centralBankEligible: true,
    benchmarkSecurity: true
  },
  {
    id: 'AST-UST-BILL-3M',
    isin: 'US912797HC82',
    cusip: '912797HC8',
    ticker: 'B 01/22/27',
    name: 'US Treasury Bill 3M 22-Jan-2027',
    assetClass: 'TREASURY_BILL',
    issuer: 'US Department of the Treasury',
    issuerCountry: 'United States',
    currency: 'USD',
    creditRating: 'AAA',
    maturityDate: '2027-01-22',
    issueDate: '2026-10-22',
    couponRate: 0.0,
    couponFrequency: 0,
    dayCount: 'ACT/360',
    minDenomination: 1000,
    lotSize: 1000,
    repoEligible: true,
    centralBankEligible: true,
    benchmarkSecurity: true
  },
  {
    id: 'AST-GER-BUND-10Y',
    isin: 'DE0001102614',
    ticker: 'DBR 2.60 08/15/33',
    name: 'Bundesrepublik Deutschland 2.600% 15-Aug-2033',
    assetClass: 'SOVEREIGN_BOND',
    issuer: 'Federal Republic of Germany',
    issuerCountry: 'Germany',
    currency: 'EUR',
    creditRating: 'AAA',
    maturityDate: '2033-08-15',
    issueDate: '2023-08-15',
    couponRate: 0.026,
    couponFrequency: 1,
    dayCount: 'ACT/ACT',
    minDenomination: 1000,
    lotSize: 1000,
    repoEligible: true,
    centralBankEligible: true,
    benchmarkSecurity: true
  },
  {
    id: 'AST-UK-GILT-5Y',
    isin: 'GB00BM8Z2T38',
    ticker: 'UKT 3.75 10/22/30',
    name: 'United Kingdom Gilt 3.750% 22-Oct-2030',
    assetClass: 'SOVEREIGN_BOND',
    issuer: 'United Kingdom Debt Management Office',
    issuerCountry: 'United Kingdom',
    currency: 'GBP',
    creditRating: 'AA',
    maturityDate: '2030-10-22',
    issueDate: '2023-10-22',
    couponRate: 0.0375,
    couponFrequency: 2,
    dayCount: 'ACT/ACT',
    minDenomination: 1000,
    lotSize: 1000,
    repoEligible: true,
    centralBankEligible: true,
    benchmarkSecurity: true
  },
  {
    id: 'AST-FR-OAT-10Y',
    isin: 'FR001400F561',
    ticker: 'OAT 3.00 05/25/35',
    name: 'French Republic OAT 3.000% 25-May-2035',
    assetClass: 'SOVEREIGN_BOND',
    issuer: 'Republic of France',
    issuerCountry: 'France',
    currency: 'EUR',
    creditRating: 'AA',
    maturityDate: '2035-05-25',
    issueDate: '2024-05-25',
    couponRate: 0.03,
    couponFrequency: 1,
    dayCount: 'ACT/ACT',
    minDenomination: 1000,
    lotSize: 1000,
    repoEligible: true,
    centralBankEligible: true,
    benchmarkSecurity: false
  },
  {
    id: 'AST-CORP-AAPL',
    isin: 'US037833DW96',
    cusip: '037833DW9',
    ticker: 'AAPL 3.85 05/04/30',
    name: 'Apple Inc 3.850% 04-May-2030',
    assetClass: 'CORP_INVESTMENT_GRADE',
    issuer: 'Apple Inc',
    issuerCountry: 'United States',
    currency: 'USD',
    creditRating: 'AAA',
    maturityDate: '2030-05-04',
    issueDate: '2020-05-04',
    couponRate: 0.0385,
    couponFrequency: 2,
    dayCount: '30/360',
    minDenomination: 2000,
    lotSize: 1000,
    repoEligible: true,
    centralBankEligible: false,
    benchmarkSecurity: false
  },
  {
    id: 'AST-CORP-SHELL',
    isin: 'US822582BW32',
    ticker: 'SHEL 4.00 09/12/28',
    name: 'Shell International Finance 4.000% 12-Sep-2028',
    assetClass: 'CORP_INVESTMENT_GRADE',
    issuer: 'Shell International Finance BV',
    issuerCountry: 'Netherlands',
    currency: 'USD',
    creditRating: 'AA',
    maturityDate: '2028-09-12',
    issueDate: '2018-09-12',
    couponRate: 0.04,
    couponFrequency: 2,
    dayCount: '30/360',
    minDenomination: 2000,
    lotSize: 1000,
    repoEligible: true,
    centralBankEligible: false,
    benchmarkSecurity: false
  },
  {
    id: 'AST-CORP-SIEMENS',
    isin: 'DE000A3828G7',
    ticker: 'SIE 3.25 06/15/29',
    name: 'Siemens Financieringsmaatschappij 3.250% 15-Jun-2029',
    assetClass: 'CORP_INVESTMENT_GRADE',
    issuer: 'Siemens AG',
    issuerCountry: 'Germany',
    currency: 'EUR',
    creditRating: 'A',
    maturityDate: '2029-06-15',
    issueDate: '2022-06-15',
    couponRate: 0.0325,
    couponFrequency: 1,
    dayCount: 'ACT/ACT',
    minDenomination: 100000,
    lotSize: 1000,
    repoEligible: true,
    centralBankEligible: true,
    benchmarkSecurity: false
  },
  {
    id: 'AST-CORP-FORD-HY',
    isin: 'US345397ZF41',
    ticker: 'F 6.125 08/15/28',
    name: 'Ford Motor Credit Co LLC 6.125% 15-Aug-2028',
    assetClass: 'CORP_HIGH_YIELD',
    issuer: 'Ford Motor Credit Co LLC',
    issuerCountry: 'United States',
    currency: 'USD',
    creditRating: 'BB',
    maturityDate: '2028-08-15',
    issueDate: '2021-08-15',
    couponRate: 0.06125,
    couponFrequency: 2,
    dayCount: '30/360',
    minDenomination: 2000,
    lotSize: 1000,
    repoEligible: false,
    centralBankEligible: false,
    benchmarkSecurity: false
  },
  {
    id: 'AST-EQ-MSFT',
    isin: 'US5949181045',
    ticker: 'MSFT',
    name: 'Microsoft Corporation Common Stock',
    assetClass: 'EQUITY',
    issuer: 'Microsoft Corporation',
    issuerCountry: 'United States',
    currency: 'USD',
    creditRating: 'AAA',
    dayCount: 'ACT/360',
    minDenomination: 1,
    lotSize: 100,
    repoEligible: true,
    centralBankEligible: false,
    benchmarkSecurity: true
  },
  {
    id: 'AST-EQ-ASML',
    isin: 'NL0010273215',
    ticker: 'ASML.AS',
    name: 'ASML Holding NV Ordinary Shares',
    assetClass: 'EQUITY',
    issuer: 'ASML Holding NV',
    issuerCountry: 'Netherlands',
    currency: 'EUR',
    creditRating: 'AA',
    dayCount: 'ACT/360',
    minDenomination: 1,
    lotSize: 100,
    repoEligible: true,
    centralBankEligible: false,
    benchmarkSecurity: true
  },
  {
    id: 'AST-ETF-SPY',
    isin: 'US78462F1030',
    ticker: 'SPY',
    name: 'SPDR S&P 500 ETF Trust',
    assetClass: 'ETF',
    issuer: 'State Street Global Advisors',
    issuerCountry: 'United States',
    currency: 'USD',
    creditRating: 'AAA',
    dayCount: 'ACT/360',
    minDenomination: 1,
    lotSize: 100,
    repoEligible: true,
    centralBankEligible: false,
    benchmarkSecurity: true
  },
  {
    id: 'AST-CASH-USD',
    isin: 'XCASHUSD0001',
    ticker: 'USD CASH',
    name: 'USD Unallocated Cash Collateral Deposit',
    assetClass: 'CASH',
    issuer: 'Federal Reserve Bank of New York (Segregated)',
    issuerCountry: 'United States',
    currency: 'USD',
    creditRating: 'AAA',
    dayCount: 'ACT/360',
    minDenomination: 1,
    lotSize: 1,
    repoEligible: true,
    centralBankEligible: true,
    benchmarkSecurity: true
  },
  {
    id: 'AST-CASH-EUR',
    isin: 'XCASHEUR0001',
    ticker: 'EUR CASH',
    name: 'EUR Unallocated Cash Collateral Deposit',
    assetClass: 'CASH',
    issuer: 'European Central Bank / Bundesbank (Segregated)',
    issuerCountry: 'Germany',
    currency: 'EUR',
    creditRating: 'AAA',
    dayCount: 'ACT/360',
    minDenomination: 1,
    lotSize: 1,
    repoEligible: true,
    centralBankEligible: true,
    benchmarkSecurity: true
  },
  {
    id: 'AST-CASH-GBP',
    isin: 'XCASHGBP0001',
    ticker: 'GBP CASH',
    name: 'GBP Unallocated Cash Collateral Deposit',
    assetClass: 'CASH',
    issuer: 'Bank of England (Segregated)',
    issuerCountry: 'United Kingdom',
    currency: 'GBP',
    creditRating: 'AA',
    dayCount: 'ACT/365',
    minDenomination: 1,
    lotSize: 1,
    repoEligible: true,
    centralBankEligible: true,
    benchmarkSecurity: true
  }
];

export const INITIAL_MARKET_DATA: Record<string, MarketDataSnapshot> = {
  'AST-UST-10Y': {
    assetId: 'AST-UST-10Y',
    cleanPrice: 99.45,
    accruedInterestRate: 0.82,
    fxRateToUSD: 1.0,
    yieldToMaturity: 0.0432,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'ICE'
  },
  'AST-UST-2Y': {
    assetId: 'AST-UST-2Y',
    cleanPrice: 100.15,
    accruedInterestRate: 0.35,
    fxRateToUSD: 1.0,
    yieldToMaturity: 0.0468,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'ICE'
  },
  'AST-UST-BILL-3M': {
    assetId: 'AST-UST-BILL-3M',
    cleanPrice: 98.78,
    accruedInterestRate: 0.0,
    fxRateToUSD: 1.0,
    yieldToMaturity: 0.0495,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'ICE'
  },
  'AST-GER-BUND-10Y': {
    assetId: 'AST-GER-BUND-10Y',
    cleanPrice: 101.30,
    accruedInterestRate: 0.51,
    fxRateToUSD: 1.085, // 1 EUR = 1.085 USD
    yieldToMaturity: 0.0245,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'BLOOMBERG'
  },
  'AST-UK-GILT-5Y': {
    assetId: 'AST-UK-GILT-5Y',
    cleanPrice: 97.80,
    accruedInterestRate: 0.94,
    fxRateToUSD: 1.285, // 1 GBP = 1.285 USD
    yieldToMaturity: 0.0415,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'REUTERS'
  },
  'AST-FR-OAT-10Y': {
    assetId: 'AST-FR-OAT-10Y',
    cleanPrice: 98.20,
    accruedInterestRate: 0.65,
    fxRateToUSD: 1.085,
    yieldToMaturity: 0.0322,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'BLOOMBERG'
  },
  'AST-CORP-AAPL': {
    assetId: 'AST-CORP-AAPL',
    cleanPrice: 97.40,
    accruedInterestRate: 1.78,
    fxRateToUSD: 1.0,
    spreadBps: 85,
    yieldToMaturity: 0.0485,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'ICE'
  },
  'AST-CORP-SHELL': {
    assetId: 'AST-CORP-SHELL',
    cleanPrice: 99.10,
    accruedInterestRate: 0.45,
    fxRateToUSD: 1.0,
    spreadBps: 105,
    yieldToMaturity: 0.0495,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'ICE'
  },
  'AST-CORP-SIEMENS': {
    assetId: 'AST-CORP-SIEMENS',
    cleanPrice: 98.90,
    accruedInterestRate: 1.15,
    fxRateToUSD: 1.085,
    spreadBps: 92,
    yieldToMaturity: 0.0360,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'BLOOMBERG'
  },
  'AST-CORP-FORD-HY': {
    assetId: 'AST-CORP-FORD-HY',
    cleanPrice: 96.25,
    accruedInterestRate: 1.20,
    fxRateToUSD: 1.0,
    spreadBps: 340,
    yieldToMaturity: 0.0780,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'ICE'
  },
  'AST-EQ-MSFT': {
    assetId: 'AST-EQ-MSFT',
    cleanPrice: 428.50,
    accruedInterestRate: 0.0,
    fxRateToUSD: 1.0,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'BLOOMBERG'
  },
  'AST-EQ-ASML': {
    assetId: 'AST-EQ-ASML',
    cleanPrice: 792.00,
    accruedInterestRate: 0.0,
    fxRateToUSD: 1.085,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'BLOOMBERG'
  },
  'AST-ETF-SPY': {
    assetId: 'AST-ETF-SPY',
    cleanPrice: 585.20,
    accruedInterestRate: 0.0,
    fxRateToUSD: 1.0,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'REUTERS'
  },
  'AST-CASH-USD': {
    assetId: 'AST-CASH-USD',
    cleanPrice: 1.0,
    accruedInterestRate: 0.0,
    fxRateToUSD: 1.0,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'ICE'
  },
  'AST-CASH-EUR': {
    assetId: 'AST-CASH-EUR',
    cleanPrice: 1.0,
    accruedInterestRate: 0.0,
    fxRateToUSD: 1.085,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'ICE'
  },
  'AST-CASH-GBP': {
    assetId: 'AST-CASH-GBP',
    cleanPrice: 1.0,
    accruedInterestRate: 0.0,
    fxRateToUSD: 1.285,
    timestamp: '2026-10-24T08:00:00Z',
    source: 'ICE'
  }
};

export const INITIAL_AGREEMENTS: CollateralAgreement[] = [
  {
    id: 'AGR-BNP-VM-CSA',
    code: 'BNP-CSA-2016',
    name: 'BNP Paribas Arbitrage - ISDA 2016 VM CSA',
    type: 'ISDA_VM_CSA',
    counterpartyId: 'CP-BNP',
    legalEntityId: 'LE-RHINO-UK',
    baseCurrency: 'USD',
    threshold: 0,
    minimumTransferAmount: 250000,
    roundingIncrement: 10000,
    independentAmount: 0,
    governingLaw: 'ENGLISH_LAW',
    valuationFrequency: 'DAILY',
    callCutOffTimeUtc: '13:00',
    notificationTimeUtc: '10:00',
    eligibilityRule: {
      id: 'RULE-BNP-2026',
      allowedAssetClasses: ['SOVEREIGN_BOND', 'TREASURY_BILL', 'CASH', 'CORP_INVESTMENT_GRADE'],
      minRating: 'BBB',
      prohibitedCountries: ['RU', 'IR', 'KP'],
      maxMaturityYears: 30,
      maxIssuerConcentrationPct: 0.25,
      maxAssetClassConcentrationPct: 0.40,
      currencyMismatchAllowed: true,
      currencyMismatchHaircut: 0.08,
      minimumLotSize: 1000
    },
    status: 'ACTIVE',
    effectiveDate: '2021-03-01',
    version: 3
  },
  {
    id: 'AGR-GS-VM-CSA',
    code: 'GS-CSA-2016',
    name: 'Goldman Sachs International - ISDA 2016 VM CSA',
    type: 'ISDA_VM_CSA',
    counterpartyId: 'CP-GS',
    legalEntityId: 'LE-RHINO-UK',
    baseCurrency: 'USD',
    threshold: 0,
    minimumTransferAmount: 500000,
    roundingIncrement: 25000,
    independentAmount: 0,
    governingLaw: 'NEW_YORK_LAW',
    valuationFrequency: 'DAILY',
    callCutOffTimeUtc: '14:00',
    notificationTimeUtc: '11:00',
    eligibilityRule: {
      id: 'RULE-GS-2026',
      allowedAssetClasses: ['SOVEREIGN_BOND', 'TREASURY_BILL', 'CASH'],
      minRating: 'AA',
      prohibitedCountries: ['RU', 'IR', 'KP'],
      maxMaturityYears: 15,
      maxIssuerConcentrationPct: 0.30,
      maxAssetClassConcentrationPct: 0.50,
      currencyMismatchAllowed: true,
      currencyMismatchHaircut: 0.08,
      minimumLotSize: 1000
    },
    status: 'ACTIVE',
    effectiveDate: '2020-06-15',
    version: 2
  },
  {
    id: 'AGR-CITADEL-PRIME',
    code: 'CITADEL-PBA',
    name: 'Citadel Securities - Prime Collateral Facility',
    type: 'ISDA_1995_NY',
    counterpartyId: 'CP-CITADEL',
    legalEntityId: 'LE-RHINO-UK',
    baseCurrency: 'USD',
    threshold: 1000000, // $1M threshold
    minimumTransferAmount: 100000,
    roundingIncrement: 10000,
    independentAmount: 2500000, // $2.5M IM requirement
    governingLaw: 'NEW_YORK_LAW',
    valuationFrequency: 'DAILY',
    callCutOffTimeUtc: '12:00',
    notificationTimeUtc: '09:30',
    eligibilityRule: {
      id: 'RULE-CITADEL-2026',
      allowedAssetClasses: ['SOVEREIGN_BOND', 'TREASURY_BILL', 'CORP_INVESTMENT_GRADE', 'EQUITY', 'ETF', 'CASH'],
      minRating: 'BBB',
      prohibitedCountries: ['RU', 'IR', 'KP'],
      maxMaturityYears: 30,
      maxIssuerConcentrationPct: 0.20,
      maxAssetClassConcentrationPct: 0.35,
      currencyMismatchAllowed: true,
      currencyMismatchHaircut: 0.08,
      minimumLotSize: 100
    },
    status: 'ACTIVE',
    effectiveDate: '2023-01-10',
    version: 1
  },
  {
    id: 'AGR-MILLENNIUM-GMRA',
    code: 'MLM-GMRA-2011',
    name: 'Millennium Capital - Global Master Repo Agreement',
    type: 'GMRA_REPO',
    counterpartyId: 'CP-MILLENNIUM',
    legalEntityId: 'LE-RHINO-UK',
    baseCurrency: 'USD',
    threshold: 0,
    minimumTransferAmount: 100000,
    roundingIncrement: 10000,
    independentAmount: 0,
    governingLaw: 'ENGLISH_LAW',
    valuationFrequency: 'DAILY',
    callCutOffTimeUtc: '13:30',
    notificationTimeUtc: '10:30',
    eligibilityRule: {
      id: 'RULE-MLM-GMRA',
      allowedAssetClasses: ['SOVEREIGN_BOND', 'TREASURY_BILL', 'CORP_INVESTMENT_GRADE', 'CASH'],
      minRating: 'A',
      prohibitedCountries: ['RU', 'IR', 'KP'],
      maxMaturityYears: 10,
      maxIssuerConcentrationPct: 0.25,
      maxAssetClassConcentrationPct: 0.50,
      currencyMismatchAllowed: true,
      currencyMismatchHaircut: 0.08,
      minimumLotSize: 1000
    },
    status: 'ACTIVE',
    effectiveDate: '2022-11-01',
    version: 4
  },
  {
    id: 'AGR-EUREX-CLEAR',
    code: 'EUREX-CLEAR-2024',
    name: 'Eurex Clearing - Clearing Member Agreement',
    type: 'CLEARING_BROKER',
    counterpartyId: 'CP-EUREX',
    legalEntityId: 'LE-RHINO-GER',
    baseCurrency: 'EUR',
    threshold: 0,
    minimumTransferAmount: 50000,
    roundingIncrement: 10000,
    independentAmount: 5000000, // €5M IM
    governingLaw: 'GERMAN_LAW',
    valuationFrequency: 'DAILY',
    callCutOffTimeUtc: '16:00',
    notificationTimeUtc: '12:00',
    eligibilityRule: {
      id: 'RULE-EUREX-STRICT',
      allowedAssetClasses: ['SOVEREIGN_BOND', 'TREASURY_BILL', 'CASH'],
      minRating: 'AA',
      prohibitedCountries: ['RU', 'IR', 'KP', 'CN'],
      maxMaturityYears: 10,
      maxIssuerConcentrationPct: 0.30,
      maxAssetClassConcentrationPct: 1.0,
      currencyMismatchAllowed: false, // Eurex requires strict EUR or central bank cash
      currencyMismatchHaircut: 0.08,
      minimumLotSize: 1000
    },
    status: 'ACTIVE',
    effectiveDate: '2024-01-01',
    version: 2
  }
];

export const INITIAL_INVENTORY: InventoryPosition[] = [
  {
    id: 'POS-001',
    assetId: 'AST-UST-10Y',
    custodian: 'DTCC',
    accountNumber: 'DTC-882194-MAIN',
    totalQuantity: 25000000, // $25M nominal
    pledgedQuantity: 10000000,
    pendingDeliveryQuantity: 2000000,
    pendingReturnQuantity: 0,
    frozenDisputedQuantity: 0,
    lastUpdated: '2026-10-24T06:00:00Z',
    notes: 'Primary US Treasury reserve buffer'
  },
  {
    id: 'POS-002',
    assetId: 'AST-UST-2Y',
    custodian: 'DTCC',
    accountNumber: 'DTC-882194-MAIN',
    totalQuantity: 18000000,
    pledgedQuantity: 4000000,
    pendingDeliveryQuantity: 0,
    pendingReturnQuantity: 1000000,
    frozenDisputedQuantity: 0,
    lastUpdated: '2026-10-24T06:00:00Z'
  },
  {
    id: 'POS-003',
    assetId: 'AST-UST-BILL-3M',
    custodian: 'DTCC',
    accountNumber: 'DTC-882194-MAIN',
    totalQuantity: 30000000, // $30M T-Bills
    pledgedQuantity: 5000000,
    pendingDeliveryQuantity: 0,
    pendingReturnQuantity: 0,
    frozenDisputedQuantity: 0,
    lastUpdated: '2026-10-24T06:00:00Z'
  },
  {
    id: 'POS-004',
    assetId: 'AST-GER-BUND-10Y',
    custodian: 'CLEARSTREAM',
    accountNumber: 'CBL-94021-FRANKFURT',
    totalQuantity: 20000000, // €20M Bunds
    pledgedQuantity: 8000000,
    pendingDeliveryQuantity: 1000000,
    pendingReturnQuantity: 0,
    frozenDisputedQuantity: 0,
    lastUpdated: '2026-10-24T06:00:00Z'
  },
  {
    id: 'POS-005',
    assetId: 'AST-UK-GILT-5Y',
    custodian: 'EUROCLEAR',
    accountNumber: 'ECL-10482-CREST',
    totalQuantity: 15000000, // £15M Gilts
    pledgedQuantity: 3000000,
    pendingDeliveryQuantity: 0,
    pendingReturnQuantity: 0,
    frozenDisputedQuantity: 0,
    lastUpdated: '2026-10-24T06:00:00Z'
  },
  {
    id: 'POS-006',
    assetId: 'AST-FR-OAT-10Y',
    custodian: 'EUROCLEAR',
    accountNumber: 'ECL-10482-PARIS',
    totalQuantity: 12000000,
    pledgedQuantity: 0,
    pendingDeliveryQuantity: 0,
    pendingReturnQuantity: 0,
    frozenDisputedQuantity: 0,
    lastUpdated: '2026-10-24T06:00:00Z'
  },
  {
    id: 'POS-007',
    assetId: 'AST-CORP-AAPL',
    custodian: 'BNY_MELLON',
    accountNumber: 'BNY-55102-TRI',
    totalQuantity: 8000000, // $8M Apple bond
    pledgedQuantity: 2000000,
    pendingDeliveryQuantity: 0,
    pendingReturnQuantity: 0,
    frozenDisputedQuantity: 0,
    lastUpdated: '2026-10-24T06:00:00Z'
  },
  {
    id: 'POS-008',
    assetId: 'AST-CORP-SHELL',
    custodian: 'BNY_MELLON',
    accountNumber: 'BNY-55102-TRI',
    totalQuantity: 6000000,
    pledgedQuantity: 1000000,
    pendingDeliveryQuantity: 0,
    pendingReturnQuantity: 0,
    frozenDisputedQuantity: 0,
    lastUpdated: '2026-10-24T06:00:00Z'
  },
  {
    id: 'POS-009',
    assetId: 'AST-CORP-SIEMENS',
    custodian: 'CLEARSTREAM',
    accountNumber: 'CBL-94021-FRANKFURT',
    totalQuantity: 5000000,
    pledgedQuantity: 0,
    pendingDeliveryQuantity: 0,
    pendingReturnQuantity: 0,
    frozenDisputedQuantity: 0,
    lastUpdated: '2026-10-24T06:00:00Z'
  },
  {
    id: 'POS-010',
    assetId: 'AST-CORP-FORD-HY',
    custodian: 'BNY_MELLON',
    accountNumber: 'BNY-55102-TRI',
    totalQuantity: 4000000,
    pledgedQuantity: 0,
    pendingDeliveryQuantity: 0,
    pendingReturnQuantity: 0,
    frozenDisputedQuantity: 1000000, // $1M disputed/frozen
    lastUpdated: '2026-10-24T06:00:00Z',
    notes: 'Sub-investment grade tranche subject to rating review'
  },
  {
    id: 'POS-011',
    assetId: 'AST-EQ-MSFT',
    custodian: 'DTCC',
    accountNumber: 'DTC-882194-EQUITIES',
    totalQuantity: 20000, // 20k shares @ ~$428 = ~$8.5M
    pledgedQuantity: 5000,
    pendingDeliveryQuantity: 0,
    pendingReturnQuantity: 0,
    frozenDisputedQuantity: 0,
    lastUpdated: '2026-10-24T06:00:00Z'
  },
  {
    id: 'AST-ETF-SPY',
    assetId: 'AST-ETF-SPY',
    custodian: 'DTCC',
    accountNumber: 'DTC-882194-EQUITIES',
    totalQuantity: 15000, // 15k shares @ ~$585 = ~$8.7M
    pledgedQuantity: 3000,
    pendingDeliveryQuantity: 0,
    pendingReturnQuantity: 0,
    frozenDisputedQuantity: 0,
    lastUpdated: '2026-10-24T06:00:00Z'
  },
  {
    id: 'POS-012',
    assetId: 'AST-CASH-USD',
    custodian: 'INTERNAL_VAULT',
    accountNumber: 'RHINO-FED-NY-SEG',
    totalQuantity: 15000000, // $15M cash
    pledgedQuantity: 3000000,
    pendingDeliveryQuantity: 1000000,
    pendingReturnQuantity: 0,
    frozenDisputedQuantity: 0,
    lastUpdated: '2026-10-24T06:00:00Z'
  },
  {
    id: 'POS-013',
    assetId: 'AST-CASH-EUR',
    custodian: 'INTERNAL_VAULT',
    accountNumber: 'RHINO-ECB-BUBA-SEG',
    totalQuantity: 10000000, // €10M cash
    pledgedQuantity: 2000000,
    pendingDeliveryQuantity: 0,
    pendingReturnQuantity: 0,
    frozenDisputedQuantity: 0,
    lastUpdated: '2026-10-24T06:00:00Z'
  }
];

export const INITIAL_MARGIN_CALLS: MarginCall[] = [
  {
    id: 'MC-20261024-001',
    idempotencyKey: 'MC-BNP-CSA-2016-2026-10-24-V3',
    agreementId: 'AGR-BNP-VM-CSA',
    counterpartyId: 'CP-BNP',
    callDate: '2026-10-24',
    currentExposureUSD: 8450000,
    initialMarginRequirementUSD: 0,
    variationMarginRequirementUSD: 8450000,
    totalRequirementUSD: 8450000,
    collateralHeldRecognisedUSD: 6000000,
    collateralDeliveredRecognisedUSD: 0,
    netCollateralRecognisedUSD: 6000000,
    grossExcessShortfallUSD: 2450000,
    thresholdUSD: 0,
    minimumTransferAmountUSD: 250000,
    roundingIncrementUSD: 10000,
    requiredTransferAmountUSD: 2450000,
    direction: 'DELIVER_COLLATERAL',
    callCurrency: 'USD',
    requiredTransferAmountInCallCurrency: 2450000,
    status: 'ISSUED',
    deadlineTimestamp: '2026-10-24T13:00:00Z',
    calculationExplanation: [
      'Variation Margin obligation calculated at $8,450,000 based on interest rate swap MtM.',
      'Net recognised collateral held is $6,000,000.',
      'Gross shortfall is $2,450,000, exceeding contractual MTA ($250,000).',
      'Delivery call issued to BNP Paribas Arbitrage.'
    ],
    createdAt: '2026-10-24T07:15:00Z',
    updatedAt: '2026-10-24T07:30:00Z',
    version: 1
  },
  {
    id: 'MC-20261024-002',
    idempotencyKey: 'MC-GS-CSA-2016-2026-10-24-V2',
    agreementId: 'AGR-GS-VM-CSA',
    counterpartyId: 'CP-GS',
    callDate: '2026-10-24',
    currentExposureUSD: 12200000,
    initialMarginRequirementUSD: 0,
    variationMarginRequirementUSD: 12200000,
    totalRequirementUSD: 12200000,
    collateralHeldRecognisedUSD: 14000000,
    collateralDeliveredRecognisedUSD: 0,
    netCollateralRecognisedUSD: 14000000,
    grossExcessShortfallUSD: -1800000,
    thresholdUSD: 0,
    minimumTransferAmountUSD: 500000,
    roundingIncrementUSD: 25000,
    requiredTransferAmountUSD: 1800000,
    direction: 'RETURN_COLLATERAL',
    callCurrency: 'USD',
    requiredTransferAmountInCallCurrency: 1800000,
    status: 'PENDING_APPROVAL',
    deadlineTimestamp: '2026-10-24T14:00:00Z',
    calculationExplanation: [
      'Portfolio exposure dropped to $12,200,000.',
      'Recognised collateral held is $14,000,000, leaving excess of $1,800,000.',
      'Return call calculated, awaiting collateral manager sign-off.'
    ],
    createdAt: '2026-10-24T08:00:00Z',
    updatedAt: '2026-10-24T08:00:00Z',
    version: 1
  },
  {
    id: 'MC-20261024-003',
    idempotencyKey: 'MC-CITADEL-PBA-2026-10-24-V1',
    agreementId: 'AGR-CITADEL-PRIME',
    counterpartyId: 'CP-CITADEL',
    callDate: '2026-10-24',
    currentExposureUSD: 5200000,
    initialMarginRequirementUSD: 2500000,
    variationMarginRequirementUSD: 2700000,
    totalRequirementUSD: 5200000,
    collateralHeldRecognisedUSD: 3800000,
    collateralDeliveredRecognisedUSD: 0,
    netCollateralRecognisedUSD: 3800000,
    grossExcessShortfallUSD: 1400000,
    thresholdUSD: 1000000,
    minimumTransferAmountUSD: 100000,
    roundingIncrementUSD: 10000,
    requiredTransferAmountUSD: 400000, // $1.4M shortfall - $1.0M threshold = $400k
    direction: 'DELIVER_COLLATERAL',
    callCurrency: 'USD',
    requiredTransferAmountInCallCurrency: 400000,
    status: 'AGREED',
    deadlineTimestamp: '2026-10-24T12:00:00Z',
    calculationExplanation: [
      'Gross shortfall is $1,400,000.',
      'Applied contractual credit threshold buffer of $1,000,000.',
      'Net callable amount is $400,000 (exceeds MTA of $100,000).',
      'Counterparty agreed; settlement instruction pending dispatch.'
    ],
    createdAt: '2026-10-24T07:45:00Z',
    updatedAt: '2026-10-24T08:20:00Z',
    version: 1
  },
  {
    id: 'MC-20261024-004',
    idempotencyKey: 'MC-EUREX-CLEAR-2026-10-24-V2',
    agreementId: 'AGR-EUREX-CLEAR',
    counterpartyId: 'CP-EUREX',
    callDate: '2026-10-24',
    currentExposureUSD: 7200000,
    initialMarginRequirementUSD: 5425000, // €5M = ~$5.425M
    variationMarginRequirementUSD: 1775000,
    totalRequirementUSD: 7200000,
    collateralHeldRecognisedUSD: 6800000,
    collateralDeliveredRecognisedUSD: 0,
    netCollateralRecognisedUSD: 6800000,
    grossExcessShortfallUSD: 400000,
    thresholdUSD: 0,
    minimumTransferAmountUSD: 54250, // €50k
    roundingIncrementUSD: 10850,
    requiredTransferAmountUSD: 400000,
    direction: 'DELIVER_COLLATERAL',
    callCurrency: 'EUR',
    requiredTransferAmountInCallCurrency: 368663,
    status: 'DISPUTED',
    disputeAmountUSD: 180000,
    disputeReason: 'Difference in interest rate swap curve discounting (€STR vs simulated fed funds basis).',
    deadlineTimestamp: '2026-10-24T16:00:00Z',
    calculationExplanation: [
      'CCP initial margin requirement increased overnight.',
      'Counterparty disputing €165,000 valuation difference on Bund curve basis.',
      'Escalated to RhinoQuant Middle Office & Risk Operations.'
    ],
    createdAt: '2026-10-24T06:50:00Z',
    updatedAt: '2026-10-24T08:10:00Z',
    version: 2
  }
];

export const INITIAL_REPO_TRADES: RepoTrade[] = [
  {
    id: 'REPO-TRD-101',
    tradeRef: 'REP-2026-MLM-0941',
    counterpartyId: 'CP-MILLENNIUM',
    tradeType: 'REPO', // We borrow cash, lend collateral
    cashPrincipal: 10000000, // $10M cash received
    currency: 'USD',
    repoRate: 0.0515, // 5.15%
    startDate: '2026-10-10',
    endDate: '2026-11-10', // 1 month repo
    dayCount: 'ACT/360',
    assetId: 'AST-UST-10Y',
    collateralNominal: 10500000,
    collateralDirtyPrice: 100.27,
    initialHaircut: 0.02,
    currentMarketValueUSD: 10528350,
    currentRecognisedValueUSD: 10317783,
    accruedRepoInterestUSD: 20027.78, // 14 days @ 5.15%
    settlementStatus: 'SETTLED',
    marginMaintenanceThreshold: 1.0,
    collateralCoverageRatio: 1.0297, // 10,317,783 / 10,020,028
    status: 'ACTIVE'
  },
  {
    id: 'REPO-TRD-102',
    tradeRef: 'REP-2026-GS-0822',
    counterpartyId: 'CP-GS',
    tradeType: 'REVERSE_REPO', // We lend cash, receive collateral
    cashPrincipal: 15000000,
    currency: 'USD',
    repoRate: 0.0520,
    startDate: '2026-10-18',
    endDate: '2026-10-25', // 1 week repo (due tomorrow!)
    dayCount: 'ACT/360',
    assetId: 'AST-GER-BUND-10Y',
    collateralNominal: 14000000,
    collateralDirtyPrice: 101.81,
    initialHaircut: 0.04,
    currentMarketValueUSD: 15465000,
    currentRecognisedValueUSD: 14846400,
    accruedRepoInterestUSD: 13000.00,
    settlementStatus: 'SETTLED',
    marginMaintenanceThreshold: 0.98,
    collateralCoverageRatio: 0.9889,
    status: 'ACTIVE'
  }
];

export const EXTERNAL_CUSTODY_STATEMENTS: ExternalCustodyStatementLine[] = [
  {
    custodian: 'DTCC',
    accountNumber: 'DTC-882194-MAIN',
    isin: 'US91282CKL71', // UST 10Y
    statementQuantity: 25000000,
    statementMarketValueUSD: 25067500,
    statementDate: '2026-10-24'
  },
  {
    custodian: 'DTCC',
    accountNumber: 'DTC-882194-MAIN',
    isin: 'US91282CKM54', // UST 2Y
    statementQuantity: 18000000,
    statementMarketValueUSD: 18090000,
    statementDate: '2026-10-24'
  },
  {
    custodian: 'CLEARSTREAM',
    accountNumber: 'CBL-94021-FRANKFURT',
    isin: 'DE0001102614', // Bund 10Y
    statementQuantity: 20000000,
    statementMarketValueUSD: 21975000,
    statementDate: '2026-10-24'
  },
  {
    custodian: 'EUROCLEAR',
    accountNumber: 'ECL-10482-CREST',
    isin: 'GB00BM8Z2T38', // Gilt 5Y
    // Variance introduced for realistic testing: external statement reports 14,000,000 vs 15,000,000 in internal ledger!
    statementQuantity: 14000000,
    statementMarketValueUSD: 17615000,
    statementDate: '2026-10-24'
  },
  {
    custodian: 'BNY_MELLON',
    accountNumber: 'BNY-55102-TRI',
    isin: 'US037833DW96', // Apple
    statementQuantity: 8000000,
    statementMarketValueUSD: 7934400,
    statementDate: '2026-10-24'
  }
];
