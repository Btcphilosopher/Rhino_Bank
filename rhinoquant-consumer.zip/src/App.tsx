/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { AuditLog, MacroScenario } from "./types";
import { generateYorkshireHistory, YCSI_INDICATORS, MACRO_SCENARIOS } from "./data/mockYorkshireData";
import { calculateCompositeSeries, seasonallyAdjustSeries } from "./utils/indexEngine";

// Components
import YorkshireFuturistUI from "./components/YorkshireFuturistUI";
import OverviewModule from "./components/OverviewModule";
import CsiConfigurator from "./components/CsiConfigurator";
import RegionalHotspots from "./components/RegionalHotspots";
import SectorAnalysis from "./components/SectorAnalysis";
import ForecastCentre from "./components/ForecastCentre";
import ScenarioAnalysis from "./components/ScenarioAnalysis";
import BankingAnalytics from "./components/BankingAnalytics";
import ReportGenerator from "./components/ReportGenerator";

export default function App() {
  const [activeModule, setActiveModule] = useState<string>("overview");

  // Initial weights setup from metadata
  const [weights, setWeights] = useState<{ [indicatorId: string]: number }>(() => {
    const init: { [id: string]: number } = {};
    YCSI_INDICATORS.forEach((ind) => {
      init[ind.id] = ind.baselineWeight;
    });
    return init;
  });

  const [activeMethodology, setActiveMethodology] = useState<string>("baseline");
  const [selectedScenario, setSelectedScenario] = useState<MacroScenario>(MACRO_SCENARIOS[0]);

  // Dynamic audit logs state
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => [
    {
      id: "1",
      timestamp: new Date().toLocaleTimeString(),
      user: "System Core",
      role: "REPRODUCIBILITY",
      action: "Model Initialized",
      details: "Yorkshire Consumer Spending Index (YCSI) model compiled successfully with 10 core indicators."
    },
    {
      id: "2",
      timestamp: new Date().toLocaleTimeString(),
      user: "System Core",
      role: "GEOSPATIAL",
      action: "GIS Map Loaded",
      details: "Compiled boundaries for 4 Yorkshire counties and 22 secondary local authorities."
    }
  ]);

  const addAuditLog = (action: string, details: string) => {
    const newLog: AuditLog = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleTimeString(),
      user: "Analyst",
      role: "TACTICAL",
      action,
      details
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Generate original simulated records (Jan 2021 to July 2026)
  const baseHistoryRecords = useMemo(() => {
    return generateYorkshireHistory();
  }, []);

  // Recalculate historical records based on the active macroeconomic scenario multipliers
  const historyRecords = useMemo(() => {
    if (selectedScenario.id === "baseline") {
      return baseHistoryRecords;
    }

    // Multiply records by scenario parameters
    return baseHistoryRecords.map((rec) => {
      const cloned = JSON.parse(JSON.stringify(rec));
      
      // Apply general spending impact to indicators
      Object.keys(cloned.indicatorValues).forEach((key) => {
        if (key !== "savings_rates") {
          cloned.indicatorValues[key] = cloned.indicatorValues[key] * (1.0 + selectedScenario.spendingImpact);
        } else {
          // Savings rise during inflation squeeze
          if (selectedScenario.id === "inflation_squeeze") {
            cloned.indicatorValues[key] = cloned.indicatorValues[key] * 1.15;
          }
        }
      });

      // Apply impact specifically to target sectors
      selectedScenario.impactedSectors.forEach((secId) => {
        if (cloned.sectorValues[secId]) {
          cloned.sectorValues[secId] = cloned.sectorValues[secId] * (1.0 + selectedScenario.spendingImpact * 1.5);
        }
      });

      // Adjust banking metrics as a consequence of scenario
      if (selectedScenario.id === "inflation_squeeze") {
        cloned.bankingMetrics.creditQualityIndex = Math.max(60, cloned.bankingMetrics.creditQualityIndex - 8);
        cloned.bankingMetrics.lendingDemand = cloned.bankingMetrics.lendingDemand * 1.1; // credit stress borrowing
        cloned.bankingMetrics.mortgageApprovals = cloned.bankingMetrics.mortgageApprovals * 0.75; // mortgage freeze
      } else if (selectedScenario.id === "tourism_boom") {
        cloned.bankingMetrics.creditQualityIndex = Math.min(98, cloned.bankingMetrics.creditQualityIndex + 4);
        cloned.bankingMetrics.lendingDemand = cloned.bankingMetrics.lendingDemand * 0.95;
      }

      return cloned;
    });
  }, [baseHistoryRecords, selectedScenario]);

  // Compute composite YCSI series
  const computedSeries = useMemo(() => {
    return calculateCompositeSeries(historyRecords, weights);
  }, [historyRecords, weights]);

  // Compute seasonally adjusted index
  const seasonallyAdjusted = useMemo(() => {
    return seasonallyAdjustSeries(computedSeries);
  }, [computedSeries]);

  const latestRecord = computedSeries[computedSeries.length - 1];

  // Callback when analyst switches methodology profiles
  const handleMethodologySelect = (methodId: string) => {
    setActiveMethodology(methodId);
    let newWeights: { [id: string]: number } = {};

    if (methodId === "baseline") {
      YCSI_INDICATORS.forEach((ind) => {
        newWeights[ind.id] = ind.baselineWeight;
      });
      addAuditLog("Methodology Reset", "Reverted back to standard balanced Rhino Baseline Index weights.");
    } else if (methodId === "equal_weighted") {
      YCSI_INDICATORS.forEach((ind) => {
        newWeights[ind.id] = 10;
      });
      addAuditLog("Methodology Shift", "Applied Equal Weighted Index profile. All 10 indicators set to 10%.");
    } else if (methodId === "high_street_heavy") {
      YCSI_INDICATORS.forEach((ind) => {
        if (["high_street_footfall", "card_payments", "hospitality_spend"].includes(ind.id)) {
          newWeights[ind.id] = 25;
        } else {
          newWeights[ind.id] = 5;
        }
      });
      addAuditLog("Methodology Shift", "Applied High Street & Tourism Heavy profile. Footfall & hospitality elevated.");
    } else if (methodId === "real_power") {
      YCSI_INDICATORS.forEach((ind) => {
        if (["disposable_income_est", "savings_rates", "retail_sales"].includes(ind.id)) {
          newWeights[ind.id] = 25;
        } else {
          newWeights[ind.id] = 5;
        }
      });
      addAuditLog("Methodology Shift", "Applied Purchasing Power Real Index profile. Income & savings parameters prioritized.");
    }

    setWeights(newWeights);
  };

  // Callback when custom weights are slided manually
  const handleWeightsChange = (newWeights: { [indicatorId: string]: number }) => {
    setWeights(newWeights);
    setActiveMethodology("custom");
    addAuditLog("Weights Calibrated", "Custom analyst index weights updated dynamically.");
  };

  const handleScenarioChange = (scenario: MacroScenario) => {
    setSelectedScenario(scenario);
    addAuditLog("Macro Stress Applied", `Economic trajectory adjusted to: "${scenario.name}"`);
  };

  return (
    <YorkshireFuturistUI
      activeModule={activeModule}
      setActiveModule={setActiveModule}
      auditLogs={auditLogs}
      onAddAuditLog={addAuditLog}
    >
      {/* Overview Module */}
      {activeModule === "overview" && (
        <OverviewModule
          series={computedSeries}
          seasonallyAdjusted={seasonallyAdjusted}
          latestRecord={latestRecord}
        />
      )}

      {/* Weights Configurator */}
      {activeModule === "config" && (
        <CsiConfigurator
          weights={weights}
          onWeightsChange={handleWeightsChange}
          onMethodologySelect={handleMethodologySelect}
          activeMethodology={activeMethodology}
        />
      )}

      {/* GIS Mapping */}
      {activeModule === "gis" && (
        <RegionalHotspots latestRecord={latestRecord.rawRecord} />
      )}

      {/* Sector spending details */}
      {activeModule === "sectors" && (
        <SectorAnalysis latestRecord={latestRecord.rawRecord} />
      )}

      {/* Forecasting Models */}
      {activeModule === "forecasting" && (
        <ForecastCentre
          historicalSeries={computedSeries}
          scenarioMultiplier={selectedScenario.spendingImpact}
          volatilityMultiplier={selectedScenario.volatilityMultiplier}
        />
      )}

      {/* Scenario Stress Tests */}
      {activeModule === "scenarios" && (
        <ScenarioAnalysis
          selectedScenario={selectedScenario}
          onScenarioSelect={handleScenarioChange}
        />
      )}

      {/* Banking Specifics */}
      {activeModule === "banking" && (
        <BankingAnalytics latestRecord={latestRecord.rawRecord} />
      )}

      {/* Report Compilation */}
      {activeModule === "reports" && (
        <ReportGenerator
          weights={weights}
          latestRecord={latestRecord}
          selectedScenario={selectedScenario}
          selectedCounties={["West Yorkshire", "South Yorkshire", "North Yorkshire", "East Riding & Humber"]}
          forecastModel="Seasonal ARIMA (SARIMA)"
        />
      )}
    </YorkshireFuturistUI>
  );
}

