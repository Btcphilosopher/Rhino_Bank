/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { County, District, SpendingIndicator, MacroScenario, SectorMetric, MonthlyRecord } from "../types";

export const YORKSHIRE_COUNTIES: County[] = [
  "West Yorkshire",
  "South Yorkshire",
  "North Yorkshire",
  "East Riding & Humber"
];

export const YORKSHIRE_DISTRICTS: District[] = [
  // West Yorkshire
  { name: "Leeds", county: "West Yorkshire", population: 812000, baseSpendWeight: 0.28, description: "Major retail, finance and corporate core. Yorkshire's primary digital consumer hub." },
  { name: "Bradford", county: "West Yorkshire", population: 546000, baseSpendWeight: 0.12, description: "Diverse industrial base. Strong food retail footprint, high family budget density." },
  { name: "Wakefield", county: "West Yorkshire", population: 353000, baseSpendWeight: 0.08, description: "Logistics corridor. Solid household goods demand and mixed retail development." },
  { name: "Kirklees", county: "West Yorkshire", population: 433000, baseSpendWeight: 0.09, description: "Manufacturing and textiles heritage. Steady community-centric high street activity." },
  { name: "Calderdale", county: "West Yorkshire", population: 211000, baseSpendWeight: 0.05, description: "Creative valleys and independent retail sector centered around Halifax and Hebden Bridge." },

  // South Yorkshire
  { name: "Sheffield", county: "South Yorkshire", population: 584000, baseSpendWeight: 0.16, description: "Advanced engineering, research and student core. Mixed high street and digital spending." },
  { name: "Barnsley", county: "South Yorkshire", population: 244000, baseSpendWeight: 0.05, description: "Post-industrial revival. Expanding local retail corridors and personal credit demand." },
  { name: "Doncaster", county: "South Yorkshire", population: 312000, baseSpendWeight: 0.07, description: "Logistics and transport hub with high logistics worker disposable income." },
  { name: "Rotherham", county: "South Yorkshire", population: 265000, baseSpendWeight: 0.05, description: "Manufacturing center with expanding retail parks and moderate household spend." },

  // North Yorkshire
  { name: "York", county: "North Yorkshire", population: 210000, baseSpendWeight: 0.08, description: "Historic tourism, education, and tech. High-spend, premium luxury retail core." },
  { name: "Harrogate", county: "North Yorkshire", population: 160000, baseSpendWeight: 0.06, description: "Conference and affluent residential center. Premium food, fashion, and lifestyle spend." },
  { name: "Selby", county: "North Yorkshire", population: 92000, baseSpendWeight: 0.03, description: "Agricultural and power generation corridor. High rate of mortgage commitments." },
  { name: "Scarborough", county: "North Yorkshire", population: 108000, baseSpendWeight: 0.03, description: "Coastal resort. High seasonal summer volatility in hospitality and leisure." },
  { name: "Whitby", county: "North Yorkshire", population: 13000, baseSpendWeight: 0.01, description: "Tourism hotspot with heavy reliance on seasonal holiday and seafood trade." },
  { name: "Richmondshire", county: "North Yorkshire", population: 53000, baseSpendWeight: 0.02, description: "Rural and military spender base (Catterick). Highly resilient non-discretionary demand." },
  { name: "Skipton", county: "North Yorkshire", population: 15000, baseSpendWeight: 0.01, description: "Market town, gateway to the Dales. Dominant older, high-wealth, stable saver segment." },
  { name: "North York Moors", county: "North Yorkshire", population: 25000, baseSpendWeight: 0.01, description: "National park community. High-value seasonal tourism cottage rentals." },
  { name: "Middlesbrough", county: "North Yorkshire", population: 143000, baseSpendWeight: 0.04, description: "Industrial and chemical port hub. High utility-spend density and value-seeking retail." },

  // East Riding & Humber
  { name: "Hull", county: "East Riding & Humber", population: 267000, baseSpendWeight: 0.07, description: "Port city, renewable energy and commerce. Major urban retail draw for Humber." },
  { name: "Beverley", county: "East Riding & Humber", population: 30000, baseSpendWeight: 0.02, description: "Historic market town. Affluent commuter base, strong boutique clothing/food spend." },
  { name: "Goole", county: "East Riding & Humber", population: 20000, baseSpendWeight: 0.01, description: "Inland port. Resilient logistics employment supporting daily household spending." },
  { name: "Bridlington", county: "East Riding & Humber", population: 35000, baseSpendWeight: 0.01, description: "Coastal destination. Vulnerable to seasonal swings and maritime sector dynamics." },
  { name: "Humber industrial corridor", county: "East Riding & Humber", population: 50000, baseSpendWeight: 0.02, description: "Heavy petrochemical and green hydrogen hubs. Resilient blue-collar disposable incomes." }
];

export const YCSI_INDICATORS: SpendingIndicator[] = [
  { id: "card_payments", name: "Card Payment Activity", category: "Retail", baselineWeight: 15, description: "Aggregated Rhino debit/credit transaction volume processed via retail checkout endpoints.", source: "Rhino Bank Internal Ledger" },
  { id: "retail_sales", name: "Retail Sales Volume Index", category: "Retail", baselineWeight: 15, description: "Monthly regional retail sales indexes tracking volume, adjusted for seasonal inflation.", source: "ONS Regional Accounts" },
  { id: "high_street_footfall", name: "High Street Footfall", category: "Activity", baselineWeight: 10, description: "Local authority electronic pedestrian counters in primary high streets and shopping plazas.", source: "Local Authority Open Data" },
  { id: "hospitality_spend", name: "Hospitality & Restaurant Spend", category: "Retail", baselineWeight: 10, description: "Rhino clearing card logs in cafes, bars, hotels, pubs and fast-food channels.", source: "Rhino Merchant Clearing" },
  { id: "supermarket_spend", name: "Supermarket Expenditure", category: "Retail", baselineWeight: 10, description: "Grocery and supermarket payment totals, proxying baseline non-discretionary spending.", source: "Rhino Merchant Clearing" },
  { id: "consumer_credit_growth", name: "Consumer Credit Drawdown", category: "Financial", baselineWeight: 8, description: "Net monthly expansion of credit cards, personal lines, and point-of-sale finance products.", source: "Bank of England / Rhino Credit" },
  { id: "disposable_income_est", name: "Est. Household Disposable Income", category: "Confidence", baselineWeight: 10, description: "Estimated average real wages after taxes and mortgage/rent payments across Yorkshire.", source: "Rhino Economics Research" },
  { id: "consumer_confidence", name: "Consumer Confidence Index", category: "Confidence", baselineWeight: 8, description: "Monthly index gauging household financial optimism, job security, and major purchase intent.", source: "Rhino Research Panels" },
  { id: "savings_rates", name: "Retail Savings Growth Rate", category: "Financial", baselineWeight: 5, description: "Rate of monthly accumulation in personal instant-access accounts (negative correlation to index).", source: "Rhino Treasury" },
  { id: "vehicle_registrations", name: "New Vehicle Registrations", category: "Activity", baselineWeight: 5, description: "New passenger vehicle registrations, proxying large-scale discretionary consumer spend.", source: "DVLA Regional Reports" }
];

export const SPENDING_SECTORS: SectorMetric[] = [
  { id: "food_retail", name: "Food & Groceries", baseShare: 0.22, growthRate: 0.015, volatility: 0.02 },
  { id: "hospitality", name: "Hospitality & Dining", baseShare: 0.12, growthRate: 0.035, volatility: 0.08 },
  { id: "tourism", name: "Tourism & Travel", baseShare: 0.08, growthRate: 0.04, volatility: 0.15 },
  { id: "leisure", name: "Leisure & Entertainment", baseShare: 0.07, growthRate: 0.03, volatility: 0.07 },
  { id: "clothing", name: "Clothing & Fashion", baseShare: 0.09, growthRate: 0.02, volatility: 0.06 },
  { id: "electronics", name: "Consumer Electronics", baseShare: 0.06, growthRate: 0.045, volatility: 0.10 },
  { id: "automotive", name: "Automotive & Transport", baseShare: 0.10, growthRate: 0.025, volatility: 0.12 },
  { id: "furniture", name: "Furniture & Homewares", baseShare: 0.06, growthRate: 0.01, volatility: 0.09 },
  { id: "diy", name: "Construction & DIY", baseShare: 0.05, growthRate: 0.015, volatility: 0.08 },
  { id: "healthcare", name: "Healthcare & Wellness", baseShare: 0.04, growthRate: 0.02, volatility: 0.03 },
  { id: "education", name: "Education & Services", baseShare: 0.05, growthRate: 0.012, volatility: 0.015 },
  { id: "entertainment", name: "Media & Streaming", baseShare: 0.06, growthRate: 0.05, volatility: 0.04 }
];

export const MACRO_SCENARIOS: MacroScenario[] = [
  {
    id: "baseline",
    name: "Baseline Economic Recovery",
    description: "Stable, moderate economic growth. Moderate wage increases and steady interest rates with normal credit drawdowns.",
    spendingImpact: 0,
    volatilityMultiplier: 1.0,
    impactedSectors: []
  },
  {
    id: "inflation_squeeze",
    name: "Cost of Living & Energy Squeeze",
    description: "High core inflation forces interest rate hikes. Disposable income contracts, squeezing leisure and tourism while food prices rise.",
    spendingImpact: -0.075,
    volatilityMultiplier: 1.6,
    impactedSectors: ["hospitality", "tourism", "electronics", "automotive", "furniture"]
  },
  {
    id: "tourism_boom",
    name: "Yorkshire Dales & Coast Tourism Boom",
    description: "Domestic holiday staycations surge, bringing tourists to York, Whitby, Scarborough, and the Moors. Exceptional boost for hospitality.",
    spendingImpact: 0.045,
    volatilityMultiplier: 1.2,
    impactedSectors: ["hospitality", "tourism", "leisure", "food_retail"]
  },
  {
    id: "manufacturing_surge",
    name: "Advanced Manufacturing & Port Corridor Expansion",
    description: "Industrial expansion across South Yorkshire engineering hubs and East Riding ports triggers a blue-collar earnings and automotive surge.",
    spendingImpact: 0.055,
    volatilityMultiplier: 1.1,
    impactedSectors: ["automotive", "diy", "furniture", "clothing"]
  },
  {
    id: "credit_tightening",
    name: "Rhino Bank Credit Squeeze",
    description: "Strict macroprudential credit limits restrict mortgage and personal loans, suppressing high-value durable consumer goods.",
    spendingImpact: -0.035,
    volatilityMultiplier: 1.3,
    impactedSectors: ["automotive", "furniture", "diy", "electronics"]
  }
];

/**
 * Generates highly realistic historical economic data for Yorkshire.
 * Starting base: Jan 2021 = 100
 */
export function generateYorkshireHistory(): MonthlyRecord[] {
  const records: MonthlyRecord[] = [];
  const startYear = 2021;
  const startMonth = 1; // January
  const endYear = 2026;
  const endMonth = 7; // July (current local date is July 2026)

  // Define some timeline factors to match real economic history:
  // 2021: Post-COVID reopening surge in mid-2021.
  // 2022: High inflation begins, hitting peaks in late 2022/early 2023.
  // 2023: Consumer squeeze, purchasing power slides.
  // 2024: Recovery begins, real wages slowly turn positive.
  // 2025: Stronger expansion, especially in digital and hospitality services.
  // 2026: Consolidation, modest growth.

  let year = startYear;
  let month = startMonth;

  while (year < endYear || (year === endYear && month <= endMonth)) {
    const dateStr = `${year}-${month.toString().padStart(2, "0")}`;

    // Timeline macroeconomic growth multiplier
    let macroTrend = 100;
    let inflationFactor = 1.0;
    
    if (year === 2021) {
      // Steady recovery from COVID lockdown lows in Jan to summer boom
      macroTrend = 95 + (month * 1.5) + (month > 4 ? 4 : 0);
      inflationFactor = 1.01;
    } else if (year === 2022) {
      // Reached normal levels, but energy crisis hits in H2
      macroTrend = 113 + (month < 8 ? month * 0.4 : -((month - 7) * 0.8));
      inflationFactor = 1.05 + (month * 0.005);
    } else if (year === 2023) {
      // The heavy cost of living squeeze, flat spending in nominal, contraction in real
      macroTrend = 109 + (month * 0.15); // flat index
      inflationFactor = 1.10 - (month * 0.003); // cooling inflation but high level
    } else if (year === 2024) {
      // Stabilization and slow bounce
      macroTrend = 111 + (month * 0.45);
      inflationFactor = 1.07;
    } else if (year === 2025) {
      // Decent industrial & retail bounce
      macroTrend = 116.4 + (month * 0.55);
      inflationFactor = 1.04;
    } else if (year === 2026) {
      // Continuing robust expansion
      macroTrend = 123 + (month * 0.5);
      inflationFactor = 1.03;
    }

    // Seasonal spending factor: Christmas spike in Dec (+24%), retail dip in Jan (-12%), tourism bounce in Jul/Aug (+8%)
    let seasonFactor = 1.0;
    if (month === 12) {
      seasonFactor = 1.25; // Christmas peak
    } else if (month === 11) {
      seasonFactor = 1.12; // Black Friday prepping
    } else if (month === 1) {
      seasonFactor = 0.86; // Post-holiday trough
    } else if (month === 2) {
      seasonFactor = 0.89; // Short cold month
    } else if (month === 7 || month === 8) {
      seasonFactor = 1.06; // Summer tourism
    } else if (month === 4 || month === 5) {
      seasonFactor = 1.02; // Spring easter activity
    }

    // Generate indicator values (all normalized around base macroTrend * seasonFactor)
    const indicatorValues: { [id: string]: number } = {};
    
    // Each indicator has small idiosyncratic deviations
    // 1. card_payments: Highly seasonal, correlates heavily with retail
    indicatorValues["card_payments"] = macroTrend * seasonFactor * 1.02 + Math.sin(month) * 1.5;
    // 2. retail_sales: Classic retail volume, slightly lower growth than card payments due to online shifting
    indicatorValues["retail_sales"] = macroTrend * seasonFactor * 0.98 + Math.cos(month) * 1.2;
    // 3. high_street_footfall: Decelerates slightly long-term relative to other digital spending indicators
    indicatorValues["high_street_footfall"] = (macroTrend * 0.92) * seasonFactor * 0.99 + Math.sin(month * 1.5) * 2.5;
    // 4. hospitality_spend: Massive summer and December seasonal spikes
    const hospSeason = month === 12 ? 1.35 : (month === 7 || month === 8 ? 1.18 : (month === 1 || month === 2 ? 0.76 : 0.98));
    indicatorValues["hospitality_spend"] = macroTrend * hospSeason * 1.04 + Math.sin(month * 2) * 2.0;
    // 5. supermarket_spend: Non-discretionary, low seasonal variance (small Christmas lift, otherwise steady)
    const superSeason = month === 12 ? 1.15 : 1.0;
    indicatorValues["supermarket_spend"] = macroTrend * superSeason * 0.95 + Math.cos(month * 0.5) * 0.8;
    // 6. consumer_credit_growth: Spikes in high spending months and when disposable incomes contract (cost of living borrowing)
    const creditSqueezeBoost = year === 2022 || year === 2023 ? 3.5 : 0;
    indicatorValues["consumer_credit_growth"] = (macroTrend * 0.9) * (month === 11 || month === 12 ? 1.1 : 1.0) + creditSqueezeBoost + Math.sin(month * 1.2) * 1.8;
    // 7. disposable_income_est: Dragged down by high inflation factor in 2022-2023
    const realWageSqueeze = year === 2022 ? -4.5 : (year === 2023 ? -8.0 : (year === 2024 ? -2.0 : 1.0));
    indicatorValues["disposable_income_est"] = (macroTrend * 1.02) + realWageSqueeze + Math.cos(month * 0.6) * 1.5;
    // 8. consumer_confidence: Volatile, hits bottom during the 2023 squeeze, recovers in 2025
    const confidenceIndex = year === 2021 ? 98 : (year === 2022 ? 84 - month : (year === 2023 ? 72 + month * 0.4 : (year === 2024 ? 82 + month * 0.8 : 94 + month * 0.4)));
    indicatorValues["consumer_confidence"] = confidenceIndex + Math.sin(month * 0.8) * 3.0;
    // 9. savings_rates: High savings during lockdowns/reopening (2021), drops as households use savings to survive (2022-2023)
    const savingsBase = year === 2021 ? 12.5 : (year === 2022 ? 9.5 : (year === 2023 ? 6.2 : (year === 2024 ? 7.5 : 8.6)));
    indicatorValues["savings_rates"] = savingsBase + Math.cos(month) * 0.8;
    // 10. vehicle_registrations: Spikes in March (new plates) and September, long-term luxury spending
    const vehicleSeason = month === 3 ? 1.45 : (month === 9 ? 1.30 : 0.85);
    indicatorValues["vehicle_registrations"] = macroTrend * vehicleSeason * 0.91 + Math.sin(month * 0.5) * 2.0;

    // Generate Sector spending values
    const sectorValues: { [id: string]: number } = {};
    for (const sector of SPENDING_SECTORS) {
      let sectorFactor = 1.0;
      // Add sector-specific seasonal profiles
      if (sector.id === "tourism" || sector.id === "hospitality") {
        sectorFactor = (month === 7 || month === 8) ? 1.25 : ((month === 12) ? 1.15 : 0.85);
      } else if (sector.id === "clothing") {
        sectorFactor = (month === 12 || month === 11 || month === 9) ? 1.2 : 0.85;
      } else if (sector.id === "diy") {
        sectorFactor = (month >= 4 && month <= 6) ? 1.3 : 0.75; // spring cleaning/DIY
      } else if (sector.id === "food_retail") {
        sectorFactor = month === 12 ? 1.15 : 0.98;
      } else if (sector.id === "automotive") {
        sectorFactor = (month === 3 || month === 9) ? 1.35 : 0.92;
      }
      
      // Squeeze effect in 2022/2023 on discretionary items
      let squeezeRatio = 1.0;
      if (year === 2022 || year === 2023) {
        if (["automotive", "furniture", "electronics", "tourism"].includes(sector.id)) {
          squeezeRatio = 0.88;
        } else if (sector.id === "food_retail" || sector.id === "healthcare") {
          squeezeRatio = 1.04; // inflationary cost expansion
        }
      }

      sectorValues[sector.id] = macroTrend * sectorFactor * squeezeRatio + (Math.sin(month * 1.5) * sector.volatility * 10);
    }

    // Generate District values (regional differences)
    // Leeds (financial boom/bust), Sheffield (steel resilience), York (tourist-dependent), Scarborough (highly seasonal)
    const districtValues: { [name: string]: number } = {};
    YORKSHIRE_DISTRICTS.forEach((dist) => {
      let regionalShift = 1.0;
      let seasonalVol = 1.0;

      if (dist.name === "Leeds" || dist.name === "Harrogate" || dist.name === "Beverley") {
        // High-income, professional resilience, stronger growth in 2024-2026
        regionalShift = year >= 2024 ? 1.04 : 1.01;
      } else if (dist.name === "Scarborough" || dist.name === "Whitby" || dist.name === "Bridlington") {
        // Coastal tourism, high seasonal spikes in Jul/Aug, lower winter spends
        seasonalVol = (month === 7 || month === 8) ? 1.38 : 0.72;
        regionalShift = 0.95;
      } else if (dist.name === "Hull" || dist.name === "Middlesbrough" || dist.name === "Sheffield") {
        // Industrial corridors, resilient blue collar, hit harder by energy spike in 2022 but recovers strongly in 2025/2026
        const energyHit = (year === 2022 || year === 2023) ? 0.96 : 1.03;
        regionalShift = energyHit;
      } else if (dist.name === "Skipton" || dist.name === "North York Moors" || dist.name === "Richmondshire") {
        // Affluent, rural, older demographic, highly stable, lower volatility
        regionalShift = 1.0;
        seasonalVol = (month === 12) ? 1.10 : ((month === 1) ? 0.94 : 1.0);
      }

      districtValues[dist.name] = macroTrend * seasonalVol * regionalShift + (Math.cos(dist.population / 10000 + month) * 1.5);
    });

    // Compute County Values as weighted average of districts
    const countyValues: { [countyName in County]: number } = {
      "West Yorkshire": 0,
      "South Yorkshire": 0,
      "North Yorkshire": 0,
      "East Riding & Humber": 0
    };

    YORKSHIRE_COUNTIES.forEach((county) => {
      const countyDists = YORKSHIRE_DISTRICTS.filter((d) => d.county === county);
      const totalWeight = countyDists.reduce((acc, d) => acc + d.baseSpendWeight, 0);
      let sumVals = 0;
      countyDists.forEach((d) => {
        sumVals += districtValues[d.name] * d.baseSpendWeight;
      });
      countyValues[county] = sumVals / totalWeight;
    });

    // Generate Banking Specific metrics (Rhino Bank exclusive indicators)
    const lendingDemand = 70 + Math.sin(month * 0.7) * 12 + (year === 2023 ? -10 : (year === 2025 ? 8 : 0));
    // Credit quality: drops during inflation squeeze, rises during stable times
    const creditQualityIndex = year === 2023 ? 74 + Math.sin(month) * 3 : 88 + Math.cos(month) * 4;
    // savings rate: tracks the Bank of England interest rates (surged 2022-2024, steady in 2025-2026)
    const savingsRateIndex = year === 2021 ? 0.75 : (year === 2022 ? 2.5 : (year === 2023 ? 4.85 : (year === 2024 ? 5.25 : 4.75)));
    // mortgage activity: high in 2021, drops severely in 2023 with rate hikes, stabilizes in 2025
    const mortgageApprovals = year === 2021 ? 120 : (year === 2022 ? 104 : (year === 2023 ? 64 + Math.sin(month)*5 : (year === 2024 ? 82 : 98 + Math.cos(month)*3)));
    const depositVolatility = year === 2022 || year === 2023 ? 3.8 + Math.sin(month)*0.8 : 1.5 + Math.cos(month)*0.5;

    records.push({
      date: dateStr,
      indicatorValues,
      sectorValues,
      districtValues,
      countyValues,
      bankingMetrics: {
        lendingDemand,
        creditQualityIndex,
        savingsRateIndex,
        mortgageApprovals,
        depositVolatility
      }
    });

    // Advance month
    month++;
    if (month > 12) {
      month = 1;
      year++;
    }
  }

  return records;
}
