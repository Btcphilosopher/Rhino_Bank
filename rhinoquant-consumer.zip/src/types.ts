/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type County = 
  | "West Yorkshire"
  | "South Yorkshire"
  | "North Yorkshire"
  | "East Riding & Humber";

export interface District {
  name: string;
  county: County;
  population: number;
  baseSpendWeight: number; // Regional contribution to Yorkshire overall spending
  description: string;
}

export interface SpendingIndicator {
  id: string;
  name: string;
  category: "Retail" | "Financial" | "Confidence" | "Activity";
  baselineWeight: number; // default percentage
  description: string;
  source: string;
}

export type ForecastModelType = 
  | "Seasonal ARIMA (SARIMA)"
  | "ETS (Exponential Smoothing)"
  | "Random Forest Regressor"
  | "XGBoost spend predictor";

export interface MacroScenario {
  id: string;
  name: string;
  description: string;
  spendingImpact: number; // multiplier e.g. -0.08 for high-inflation squeeze
  volatilityMultiplier: number; // multiplier e.g. 1.5 for uncertain environments
  impactedSectors: string[]; // sectors most hit
}

export interface SectorMetric {
  id: string;
  name: string;
  baseShare: number; // % of total wallet spend
  growthRate: number; // base growth rate
  volatility: number;
}

export interface MonthlyRecord {
  date: string; // YYYY-MM
  // Raw metrics for the indicators (normalized to 100 on Jan 2021)
  indicatorValues: { [indicatorId: string]: number };
  // Sector indices (normalized to 100 on Jan 2021)
  sectorValues: { [sectorId: string]: number };
  // Regional spending index values by district
  districtValues: { [districtName: string]: number };
  // Regional spending index values by county
  countyValues: { [countyName in County]: number };
  // Banking metrics (Rhino Bank specific metrics)
  bankingMetrics: {
    lendingDemand: number; // 0-100 scale index
    creditQualityIndex: number; // 0-100 (higher is better, lower indicates defaults rising)
    savingsRateIndex: number; // savings rate %
    mortgageApprovals: number; // normalized count index
    depositVolatility: number; // deviation %
  };
}

export interface ComputedIndexSeries {
  date: string;
  compositeValue: number; // Weighted composite value
  momChange: number;
  yoyChange: number;
  rawRecord: MonthlyRecord;
}

export interface ForecastPoint {
  date: string;
  predictedValue: number;
  lowerConfidence: number; // 95% CI
  upperConfidence: number; // 95% CI
  isHistorical: boolean;
}

export interface PCAOutput {
  component: string;
  eigenvalue: number;
  varianceExplained: number; // percentage
  loadings: { [indicatorId: string]: number };
}

export interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  role: string;
  action: string;
  details: string;
}
