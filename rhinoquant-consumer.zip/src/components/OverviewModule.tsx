/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { ComputedIndexSeries, SpendingIndicator } from "../types";
import { TrendingUp, ArrowUpRight, ArrowDownRight, Compass, Calendar, Layers, Activity } from "lucide-react";
import { YCSI_INDICATORS } from "../data/mockYorkshireData";

interface OverviewModuleProps {
  series: ComputedIndexSeries[];
  seasonallyAdjusted: number[];
  latestRecord: ComputedIndexSeries;
}

export default function OverviewModule({ series, seasonallyAdjusted, latestRecord }: OverviewModuleProps) {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  const rawValues = series.map((s) => s.compositeValue);
  const minVal = Math.min(...rawValues, ...seasonallyAdjusted) - 2;
  const maxVal = Math.max(...rawValues, ...seasonallyAdjusted) + 2;
  const range = maxVal - minVal;

  const pointsCount = series.length;
  const width = 800;
  const height = 300;
  const paddingLeft = 50;
  const paddingRight = 20;
  const paddingTop = 20;
  const paddingBottom = 40;

  // Coordinate mapping helper
  const getCoordinates = (index: number, value: number) => {
    const x = paddingLeft + (index / (pointsCount - 1)) * (width - paddingLeft - paddingRight);
    const y = height - paddingBottom - ((value - minVal) / range) * (height - paddingTop - paddingBottom);
    return { x, y };
  };

  // Generate SVG path strings
  const getPathD = (values: number[]) => {
    return values.reduce((path, val, idx) => {
      const { x, y } = getCoordinates(idx, val);
      return idx === 0 ? `M ${x} ${y}` : `${path} L ${x} ${y}`;
    }, "");
  };

  const rawPath = getPathD(rawValues);
  const adjustedPath = getPathD(seasonallyAdjusted);

  // Formatting values
  const latestVal = latestRecord.compositeValue;
  const latestAdjustedVal = seasonallyAdjusted[seasonallyAdjusted.length - 1];
  const mom = latestRecord.momChange;
  const yoy = latestRecord.yoyChange;

  return (
    <div id="overview-module" className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Card 1: Composite Index */}
        <div id="kpi-ycsi" className="bg-[#242629] border border-[#4A4E52] border-t-2 border-t-[#B87333] p-5 rounded-sm shadow-lg relative overflow-hidden">
          <div className="absolute top-2 right-2 text-[#71797E]">
            <Compass className="w-5 h-5" />
          </div>
          <span className="text-xs uppercase tracking-wider text-[#71797E]">Yorkshire Spend Index (YCSI)</span>
          <div className="flex items-baseline gap-2 mt-2">
            <h3 className="text-3xl font-bold text-white">{latestVal.toFixed(1)}</h3>
            <span className="text-xs text-[#71797E]">pts</span>
          </div>
          <p className="text-xs text-[#71797E] mt-1">Base 100 (Jan 2021)</p>
          <div className="flex gap-4 mt-3 border-t border-[#4A4E52] pt-3 text-xs">
            <div className="flex items-center gap-1">
              {mom >= 0 ? (
                <ArrowUpRight className="w-4 h-4 text-green-400" />
              ) : (
                <ArrowDownRight className="w-4 h-4 text-rose-400" />
              )}
              <span className={mom >= 0 ? "text-green-500 font-semibold" : "text-rose-400 font-semibold"}>
                {mom >= 0 ? "+" : ""}{mom.toFixed(2)}% MoM
              </span>
            </div>
            <div className="flex items-center gap-1">
              {yoy >= 0 ? (
                <ArrowUpRight className="w-4 h-4 text-green-400" />
              ) : (
                <ArrowDownRight className="w-4 h-4 text-rose-400" />
              )}
              <span className={yoy >= 0 ? "text-green-500 font-semibold" : "text-rose-400 font-semibold"}>
                {yoy >= 0 ? "+" : ""}{yoy.toFixed(2)}% YoY
              </span>
            </div>
          </div>
        </div>

        {/* Card 2: Seasonally Adjusted */}
        <div id="kpi-adjusted" className="bg-[#242629] border border-[#4A4E52] border-t-2 border-t-[#71797E] p-5 rounded-sm shadow-lg relative overflow-hidden">
          <div className="absolute top-2 right-2 text-[#71797E]">
            <Layers className="w-5 h-5" />
          </div>
          <span className="text-xs uppercase tracking-wider text-[#71797E]">Seasonally Adjusted Index</span>
          <div className="flex items-baseline gap-2 mt-2">
            <h3 className="text-3xl font-bold text-white">{latestAdjustedVal.toFixed(1)}</h3>
            <span className="text-xs text-[#71797E]">pts</span>
          </div>
          <p className="text-xs text-[#71797E] mt-1">Removing winter & tourist cycles</p>
          <div className="flex items-center gap-1 mt-3 border-t border-[#4A4E52] pt-3 text-xs">
            <TrendingUp className="w-4 h-4 text-[#71797E]" />
            <span className="text-[#71797E] font-semibold">Classical CMA Decomposition</span>
          </div>
        </div>

        {/* Card 3: Spending Velocity */}
        <div id="kpi-velocity" className="bg-[#242629] border border-[#4A4E52] border-t-2 border-t-[#B87333] p-5 rounded-sm shadow-lg relative overflow-hidden">
          <div className="absolute top-2 right-2 text-[#71797E]">
            <Activity className="w-5 h-5" />
          </div>
          <span className="text-xs uppercase tracking-wider text-[#71797E]">Monthly Spend Velocity</span>
          <div className="flex items-baseline gap-2 mt-2">
            <h3 className="text-3xl font-bold text-white">
              {latestRecord.rawRecord.indicatorValues["card_payments"].toFixed(1)}
            </h3>
            <span className="text-xs text-[#71797E]">pts</span>
          </div>
          <p className="text-xs text-[#71797E] mt-1">Card clearing volume index</p>
          <div className="flex items-center gap-1 mt-3 border-t border-[#4A4E52] pt-3 text-xs text-green-400 font-semibold">
            <span className="bg-[#B87333] text-black px-1.5 py-0.5 rounded-sm text-[10px] font-bold">REAL-TIME</span>
            <span className="text-[#B87333]">Rhino Clearing Core</span>
          </div>
        </div>

        {/* Card 4: Savings Rate */}
        <div id="kpi-savings" className="bg-[#242629] border border-[#4A4E52] border-t-2 border-t-[#71797E] p-5 rounded-sm shadow-lg relative overflow-hidden">
          <div className="absolute top-2 right-2 text-[#71797E]">
            <Calendar className="w-5 h-5" />
          </div>
          <span className="text-xs uppercase tracking-wider text-[#71797E]">Household Savings Rate</span>
          <div className="flex items-baseline gap-2 mt-2">
            <h3 className="text-3xl font-bold text-white">
              {latestRecord.rawRecord.indicatorValues["savings_rates"].toFixed(2)}%
            </h3>
          </div>
          <p className="text-xs text-[#71797E] mt-1">Rhino Retail Instant-Access</p>
          <div className="flex items-center gap-1 mt-3 border-t border-[#4A4E52] pt-3 text-xs text-[#71797E]">
            <span>Volatility Factor: {latestRecord.rawRecord.bankingMetrics.depositVolatility.toFixed(2)}%</span>
          </div>
        </div>
      </div>

      {/* Main Historical Chart */}
      <div className="bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-xl">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-2">
          <div>
            <h4 className="text-lg font-light serif italic text-[#D1C7B7]">Yorkshire Consumer Spending Index (YCSI) Timeline</h4>
            <p className="text-xs text-[#71797E]">Comparison of raw composite spend against seasonally adjusted core trend line</p>
          </div>
          {/* Legend */}
          <div className="flex gap-4 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-[#B87333] inline-block"></span>
              <span className="text-white font-medium">Raw YCSI Composite</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-[#71797E] inline-block"></span>
              <span className="text-white font-medium">Seasonally Adjusted Core</span>
            </div>
          </div>
        </div>

        {/* SVG Drawing Area */}
        <div className="relative">
          <svg
            viewBox={`0 0 ${width} ${height}`}
            className="w-full h-auto overflow-visible select-none"
            onMouseLeave={() => setHoverIndex(null)}
          >
            {/* Gridlines */}
            {Array.from({ length: 5 }).map((_, idx) => {
              const val = minVal + (idx / 4) * range;
              const { y } = getCoordinates(0, val);
              return (
                <g key={idx}>
                  <line
                    x1={paddingLeft}
                    y1={y}
                    x2={width - paddingRight}
                    y2={y}
                    stroke="#4A4E52"
                    strokeDasharray="4,4"
                  />
                  <text
                    x={paddingLeft - 8}
                    y={y + 4}
                    fill="#71797E"
                    fontSize="10"
                    textAnchor="end"
                  >
                    {val.toFixed(0)}
                  </text>
                </g>
              );
            })}

            {/* X Axis labels (Dates) */}
            {series.map((s, idx) => {
              // Label every 6th month
              if (idx % 6 === 0) {
                const { x, y } = getCoordinates(idx, minVal);
                const isJan = s.date.endsWith("-01");
                const label = isJan ? s.date.split("-")[0] : s.date.split("-")[1] + "/" + s.date.split("-")[0].substring(2);
                return (
                  <g key={idx}>
                    <line
                      x1={x}
                      y1={height - paddingBottom}
                      x2={x}
                      y2={height - paddingBottom + 5}
                      stroke="#4A4E52"
                    />
                    <text
                      x={x}
                      y={height - paddingBottom + 18}
                      fill={isJan ? "#ffffff" : "#71797E"}
                      fontWeight={isJan ? "bold" : "normal"}
                      fontSize="9"
                      textAnchor="middle"
                    >
                      {label}
                    </text>
                  </g>
                );
              }
              return null;
            })}

            {/* Raw Spend Path */}
            <path
              d={rawPath}
              fill="none"
              stroke="#B87333"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Seasonally Adjusted Path */}
            <path
              d={adjustedPath}
              fill="none"
              stroke="#71797E"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Interactive hover guides */}
            {series.map((s, idx) => {
              const { x } = getCoordinates(idx, minVal);
              return (
                <rect
                  key={idx}
                  x={x - (width - paddingLeft - paddingRight) / (pointsCount * 2)}
                  y={paddingTop}
                  width={(width - paddingLeft - paddingRight) / pointsCount}
                  height={height - paddingBottom - paddingTop}
                  fill="transparent"
                  className="cursor-crosshair"
                  onMouseEnter={() => setHoverIndex(idx)}
                />
              );
            })}

            {/* Hover Indicator Crosshair */}
            {hoverIndex !== null && (
              <g>
                {(() => {
                  const s = series[hoverIndex];
                  const rawVal = s.compositeValue;
                  const adjVal = seasonallyAdjusted[hoverIndex];
                  const { x, y: yRaw } = getCoordinates(hoverIndex, rawVal);
                  const { y: yAdj } = getCoordinates(hoverIndex, adjVal);
 
                  return (
                    <>
                      {/* Vertical line */}
                      <line
                        x1={x}
                        y1={paddingTop}
                        x2={x}
                        y2={height - paddingBottom}
                        stroke="#71797E"
                        strokeWidth="1"
                        strokeDasharray="2,2"
                      />
 
                      {/* Raw value dot */}
                      <circle
                        cx={x}
                        cy={yRaw}
                        r="5"
                        fill="#B87333"
                        stroke="#ffffff"
                        strokeWidth="1.5"
                      />
 
                      {/* Adjusted value dot */}
                      <circle
                        cx={x}
                        cy={yAdj}
                        r="4"
                        fill="#71797E"
                        stroke="#ffffff"
                        strokeWidth="1.5"
                      />
                    </>
                  );
                })()}
              </g>
            )}
          </svg>
 
          {/* Dynamic Tooltip Popover */}
          {hoverIndex !== null && (
            <div
              className="absolute bg-[#0F1115] text-[#E4E3E0] p-3 rounded-sm border border-[#4A4E52] shadow-2xl text-xs pointer-events-none space-y-1 z-10"
              style={{
                left: `${getCoordinates(hoverIndex, 100).x + 10}px`,
                top: "10px"
              }}
            >
              <div className="font-semibold text-white border-b border-[#4A4E52] pb-1 mb-1">
                {new Date(series[hoverIndex].date + "-02").toLocaleString("default", {
                  month: "long",
                  year: "numeric"
                })}
              </div>
              <div className="flex justify-between gap-6">
                <span className="text-[#71797E]">Raw Composite Spend:</span>
                <span className="font-bold text-[#B87333]">
                  {series[hoverIndex].compositeValue.toFixed(1)}
                </span>
              </div>
              <div className="flex justify-between gap-6">
                <span className="text-[#71797E]">Seasonally Adjusted:</span>
                <span className="font-bold text-white">
                  {seasonallyAdjusted[hoverIndex].toFixed(1)}
                </span>
              </div>
              <div className="flex justify-between gap-6">
                <span className="text-[#71797E]">MoM Change:</span>
                <span
                  className={`font-semibold ${
                    series[hoverIndex].momChange >= 0 ? "text-green-400" : "text-rose-400"
                  }`}
                >
                  {series[hoverIndex].momChange >= 0 ? "+" : ""}
                  {series[hoverIndex].momChange.toFixed(2)}%
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
 
      {/* Underpinning Economic Indicators */}
      <div className="bg-[#242629] p-6 rounded-sm border border-[#4A4E52]">
        <h4 className="text-lg font-light serif italic text-[#D1C7B7] mb-4 flex items-center gap-2">
          <Layers className="w-5 h-5 text-[#B87333]" />
          YCSI Underpinning Macroeconomic Indicators
        </h4>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-[#4A4E52] text-[#71797E] uppercase tracking-wider">
                <th className="pb-3 pl-2">Indicator</th>
                <th className="pb-3">Category</th>
                <th className="pb-3 text-right">Latest Value</th>
                <th className="pb-3 text-right">Methodology Contribution</th>
                <th className="pb-3 pl-4">Data Source</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#4A4E52] text-[#E4E3E0]">
              {YCSI_INDICATORS.map((indicator) => {
                const latestVal = latestRecord.rawRecord.indicatorValues[indicator.id];
                return (
                  <tr key={indicator.id} className="hover:bg-[#1A1A1B] transition">
                    <td className="py-3 pl-2 font-medium text-white">
                      {indicator.name}
                      <p className="text-[10px] text-[#71797E] font-normal">{indicator.description}</p>
                    </td>
                    <td className="py-3">
                      <span className={`px-2 py-0.5 rounded-sm text-[10px] font-semibold ${
                        indicator.category === "Retail" ? "bg-amber-950 text-amber-300 border border-amber-800" :
                        indicator.category === "Financial" ? "bg-violet-950 text-violet-300 border border-violet-800" :
                        indicator.category === "Confidence" ? "bg-sky-950 text-sky-300 border border-sky-800" :
                        "bg-emerald-950 text-emerald-300 border border-emerald-800"
                      }`}>
                        {indicator.category}
                      </span>
                    </td>
                    <td className="py-3 text-right font-semibold text-white">
                      {indicator.id === "savings_rates" ? `${latestVal.toFixed(2)}%` : latestVal.toFixed(1)}
                    </td>
                    <td className="py-3 text-right text-[#B87333] font-bold">
                      {indicator.baselineWeight}%
                    </td>
                    <td className="py-3 pl-4 text-[#71797E]">
                      {indicator.source}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
