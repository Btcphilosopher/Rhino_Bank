/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Compass, Shield, HelpCircle, User, Landmark, Layers, Calendar, Terminal } from "lucide-react";
import { AuditLog } from "../types";

interface YorkshireFuturistUIProps {
  children: React.ReactNode;
  activeModule: string;
  setActiveModule: (mod: string) => void;
  auditLogs: AuditLog[];
  onAddAuditLog: (action: string, details: string) => void;
}

export default function YorkshireFuturistUI({
  children,
  activeModule,
  setActiveModule,
  auditLogs,
  onAddAuditLog
}: YorkshireFuturistUIProps) {
  const [role, setRole] = useState<string>("Principal Quantitative Economist");
  const [showConsole, setShowConsole] = useState<boolean>(true);

  // Trigger audit log on role change
  const handleRoleChange = (newRole: string) => {
    setRole(newRole);
    onAddAuditLog("User Role Shifted", `User changed active role session to ${newRole}`);
  };

  const menuItems = [
    { id: "overview", name: "Executive Overview" },
    { id: "config", name: "Index formulation" },
    { id: "gis", name: "Regional GIS Map" },
    { id: "sectors", name: "Sector Performance" },
    { id: "forecasting", name: "Forecast Centre" },
    { id: "scenarios", name: "Scenario Testing" },
    { id: "banking", name: "Banking Analytics" },
    { id: "reports", name: "Executive Reports" }
  ];

  return (
    <div className="min-h-screen bg-[#1A1A1B] text-[#E4E3E0] flex flex-col font-sans selection:bg-[#B87333] selection:text-black">
      {/* Header Bar */}
      <header className="bg-[#0F1115] border-b border-[#4A4E52] py-4 px-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-xl shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-sm bg-[#B87333] flex items-center justify-center shadow-lg border border-[#B87333]">
            <Landmark className="w-5 h-5 text-black" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-white tracking-tight uppercase">
              RhinoQuant <span className="text-[#B87333]">Consumer</span>
            </h1>
            <p className="text-[10px] text-[#B87333] tracking-widest uppercase font-bold">
              Yorkshire Consumer Spending Intelligence Platform
            </p>
          </div>
        </div>

        {/* User Role simulation selector */}
        <div className="flex flex-wrap items-center gap-4 text-xs">
          <div className="flex items-center gap-2 bg-[#242629] px-3 py-1.5 rounded-sm border border-[#4A4E52]">
            <User className="w-4 h-4 text-[#B87333]" />
            <span className="text-[#71797E]">Active Analyst:</span>
            <select
              value={role}
              onChange={(e) => handleRoleChange(e.target.value)}
              className="bg-transparent text-[#E4E3E0] font-bold outline-none cursor-pointer text-xs"
            >
              <option value="Principal Quantitative Economist" className="bg-[#242629]">Principal Quantitative Economist</option>
              <option value="CRO & Risk Planning Director" className="bg-[#242629]">CRO & Risk Planning Director</option>
              <option value="Executive Vice President" className="bg-[#242629]">Executive Vice President</option>
            </select>
          </div>
          <div className="text-[10px] text-[#71797E] bg-[#0F1115] border border-[#4A4E52] px-2 py-1 rounded font-mono">
            INTERNAL USE ONLY // v2.41-SARIMA
          </div>
        </div>
      </header>

      {/* Primary Workspace */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Navigation Sidebar */}
        <nav className="lg:w-60 bg-[#0F1115] lg:border-r border-[#4A4E52] p-4 flex flex-col gap-1 shrink-0 overflow-y-auto">
          <div className="text-[11px] text-[#71797E] uppercase font-bold tracking-widest mb-2 px-2">
            Intelligence Modules
          </div>
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveModule(item.id);
                onAddAuditLog("Workspace Tab Changed", `Switched main dashboard view to ${item.name}`);
              }}
              className={`w-full text-left px-3 py-2 text-sm font-semibold uppercase tracking-wider transition-colors duration-150 ${
                activeModule === item.id
                  ? "bg-[#242629] text-white border-l-2 border-[#B87333]"
                  : "text-[#71797E] hover:text-white"
              }`}
            >
              {item.name}
            </button>
          ))}

          {/* Console trigger button */}
          <button
            onClick={() => setShowConsole(!showConsole)}
            className="w-full text-left mt-8 px-3 py-2 text-[10px] uppercase font-bold text-[#71797E] hover:text-white transition flex items-center gap-1.5 border-t border-[#4A4E52] pt-4"
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>{showConsole ? "Hide Audit Console" : "Show Audit Console"}</span>
          </button>
        </nav>

        {/* Content canvas */}
        <main className="flex-1 overflow-y-auto p-8 space-y-6 bg-[#1A1A1B]">
          {children}

          {/* Audit Logging Console */}
          {showConsole && (
            <div id="audit-log-console" className="bg-[#0F1115] border border-[#4A4E52] rounded-sm p-4 shadow-inner mt-6">
              <div className="flex justify-between items-center mb-2 border-b border-[#4A4E52] pb-1">
                <span className="text-[10px] font-bold text-[#B87333] uppercase tracking-wider flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5" />
                  RhinoQuant Live Reproducibility Console
                </span>
                <span className="text-[9px] text-[#71797E] font-mono">STABILITY VERIFIED // BASEL III COMPLIANT</span>
              </div>
              <div className="font-mono text-[9px] text-emerald-400 space-y-1.5 max-h-[100px] overflow-y-auto pr-2">
                {auditLogs.map((log) => (
                  <div key={log.id} className="flex gap-4">
                    <span className="text-[#71797E] shrink-0">{log.timestamp}</span>
                    <span className="text-[#B87333] shrink-0">[{log.role}]</span>
                    <span className="text-white shrink-0 font-bold">{log.action}:</span>
                    <span className="text-slate-400">{log.details}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Footer bar */}
      <footer className="bg-[#0F1115] border-t border-[#4A4E52] py-3 px-8 flex justify-between text-[10px] text-[#71797E] tracking-wider shrink-0 uppercase font-semibold">
        <div className="flex gap-4">
          <span>DATA SOURCE: ONS / RHINO INTERNAL PAYMENTS</span>
          <span>LAST SYNC: 2026-07-27 GMT</span>
        </div>
        <div className="font-bold text-[#B87333]">INTERNAL USE ONLY // PROPRIETARY ECONOMETRIC MODEL v4.2</div>
      </footer>
    </div>
  );
}
