/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { County, District, MonthlyRecord } from "../types";
import { YORKSHIRE_DISTRICTS } from "../data/mockYorkshireData";
import { Map, Pin, Compass, Info, TrendingUp, HelpCircle } from "lucide-react";

interface RegionalHotspotsProps {
  latestRecord: MonthlyRecord;
}

export default function RegionalHotspots({ latestRecord }: RegionalHotspotsProps) {
  const [selectedCounty, setSelectedCounty] = useState<County | "All">("All");
  const [hoveredCounty, setHoveredCounty] = useState<County | null>(null);

  // Filter districts
  const districts = YORKSHIRE_DISTRICTS.filter((d) => 
    selectedCounty === "All" ? true : d.county === selectedCounty
  );

  // Sort districts by spend index
  const sortedDistricts = [...districts].sort((a, b) => {
    const valA = latestRecord.districtValues[a.name] || 100;
    const valB = latestRecord.districtValues[b.name] || 100;
    return valB - valA; // descending order
  });

  // Calculate county score averages
  const getCountyAverage = (county: County) => {
    return latestRecord.countyValues[county] || 100;
  };

  const getCountyColor = (county: County, isHovered: boolean) => {
    const avg = getCountyAverage(county);
    // Average spans e.g. 110 - 130
    // We map this to color intensity
    let opacity = 0.4;
    if (avg > 125) opacity = 0.9;
    else if (avg > 120) opacity = 0.75;
    else if (avg > 115) opacity = 0.6;
    
    if (isHovered) {
      return "rgba(184, 115, 51, 0.95)"; // bright copper hover
    }
    
    // Default copper tones based on spending intensity
    return `rgba(184, 115, 51, ${opacity})`;
  };

  // Static layout of Yorkshire Map Polygons (custom abstract coordinates)
  const mapPolygons = [
    {
      county: "North Yorkshire" as County,
      points: "150,10 400,10 450,110 320,180 180,180 100,120",
      center: { x: 270, y: 90 },
      occupancy: "91.8%",
      catchmentType: "Rural & Tourism Gateway"
    },
    {
      county: "West Yorkshire" as County,
      points: "90,140 180,180 250,180 220,260 130,260 80,210",
      center: { x: 160, y: 210 },
      occupancy: "94.5%",
      catchmentType: "Metropolitan Retail Core"
    },
    {
      county: "South Yorkshire" as County,
      points: "220,260 300,240 350,280 280,330 180,310",
      center: { x: 260, y: 285 },
      occupancy: "88.2%",
      catchmentType: "Advanced Manufacturing Core"
    },
    {
      county: "East Riding & Humber" as County,
      points: "320,180 450,110 520,180 430,270 340,240",
      center: { x: 410, y: 195 },
      occupancy: "89.6%",
      catchmentType: "Port & Logistics Catchment"
    }
  ];

  return (
    <div id="regional-hotspots" className="grid grid-cols-1 xl:grid-cols-12 gap-6">
      {/* Interactive GIS Map Block */}
      <div className="xl:col-span-6 bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-lg flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-center mb-4">
            <div>
              <h4 className="text-lg font-light serif italic text-[#D1C7B7] flex items-center gap-2">
                <Map className="w-5 h-5 text-[#B87333]" />
                Yorkshire GIS Spend Hotspots Map
              </h4>
              <p className="text-xs text-[#71797E]">Click counties to filter analytical list. Color intensity represents spending strength.</p>
            </div>
            <button
              onClick={() => setSelectedCounty("All")}
              className={`text-xs px-3 py-1 rounded-sm border transition ${
                selectedCounty === "All"
                  ? "bg-[#0F1115] text-[#B87333] border-[#B87333]"
                  : "bg-[#0F1115] text-[#E4E3E0] border-[#4A4E52] hover:bg-[#1A1A1B]"
              }`}
            >
              Reset Filter
            </button>
          </div>

          {/* SVG MAP */}
          <div className="bg-[#0F1115] p-4 rounded-sm border border-[#4A4E52] flex justify-center items-center min-h-[340px] relative overflow-hidden">
            <svg viewBox="0 0 540 350" className="w-full max-w-[480px] h-auto overflow-visible">
              <g stroke="#0F1115" strokeWidth="2.5" strokeLinejoin="round" className="cursor-pointer">
                {mapPolygons.map((p) => {
                  const isSelected = selectedCounty === p.county;
                  const isHovered = hoveredCounty === p.county;
                  const fillCol = getCountyColor(p.county, isHovered || isSelected);

                  return (
                    <g
                      key={p.county}
                      onMouseEnter={() => setHoveredCounty(p.county)}
                      onMouseLeave={() => setHoveredCounty(null)}
                      onClick={() => setSelectedCounty(p.county)}
                    >
                      <polygon
                        points={p.points}
                        fill={fillCol}
                        className="transition-colors duration-200"
                      />
                      {/* Name Label */}
                      <text
                        x={p.center.x}
                        y={p.center.y}
                        fill="#ffffff"
                        fontSize="11"
                        fontWeight="bold"
                        textAnchor="middle"
                        className="pointer-events-none drop-shadow-md font-sans"
                      >
                        {p.county}
                      </text>
                      {/* Value Label */}
                      <text
                        x={p.center.x}
                        y={p.center.y + 14}
                        fill="#ffedd5"
                        fontSize="10"
                        textAnchor="middle"
                        className="pointer-events-none opacity-90 font-mono"
                      >
                        {getCountyAverage(p.county).toFixed(1)} pts
                      </text>
                    </g>
                  );
                })}
              </g>

              {/* Major city pins */}
              <g className="pointer-events-none">
                <g transform="translate(180, 210)">
                  <circle cx="0" cy="0" r="3" fill="#ffffff" />
                  <text x="5" y="3" fill="#ffffff" fontSize="9" fontWeight="bold">Leeds</text>
                </g>
                <g transform="translate(260, 290)">
                  <circle cx="0" cy="0" r="3" fill="#ffffff" />
                  <text x="5" y="3" fill="#ffffff" fontSize="9" fontWeight="bold">Sheffield</text>
                </g>
                <g transform="translate(290, 110)">
                  <circle cx="0" cy="0" r="3" fill="#ffffff" />
                  <text x="5" y="3" fill="#ffffff" fontSize="9" fontWeight="bold">York</text>
                </g>
                <g transform="translate(420, 220)">
                  <circle cx="0" cy="0" r="3" fill="#ffffff" />
                  <text x="5" y="3" fill="#ffffff" fontSize="9" fontWeight="bold">Hull</text>
                </g>
              </g>
            </svg>
          </div>
        </div>

        {/* GIS Metadata details */}
        <div className="grid grid-cols-2 gap-4 mt-4 border-t border-[#4A4E52] pt-4 text-xs">
          <div>
            <span className="text-[#71797E] block">Focus Region:</span>
            <span className="font-bold text-white">{selectedCounty === "All" ? "Combined Yorkshire & Humber" : selectedCounty}</span>
          </div>
          <div>
            <span className="text-[#71797E] block">County Average:</span>
            <span className="font-bold text-[#B87333]">
              {selectedCounty === "All" 
                ? (Object.values(latestRecord.countyValues).reduce((a, b) => a + b, 0) / 4).toFixed(1)
                : getCountyAverage(selectedCounty).toFixed(1)
              } pts
            </span>
          </div>
        </div>
      </div>

      {/* District Ranking & Economic Catchment Table */}
      <div className="xl:col-span-6 bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-lg flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-center mb-4">
            <div>
              <h4 className="text-lg font-light serif italic text-[#D1C7B7] flex items-center gap-2">
                <Pin className="w-5 h-5 text-[#B87333]" />
                Regional Consumer Index Rankings
              </h4>
              <p className="text-xs text-[#71797E]">Ranked spending activity by individual district under selected scope.</p>
            </div>
            <span className="text-xs text-[#71797E] bg-[#0F1115] border border-[#4A4E52] px-2.5 py-1 rounded-sm font-medium">
              Showing {sortedDistricts.length} / {YORKSHIRE_DISTRICTS.length} Districts
            </span>
          </div>

          <div className="overflow-y-auto max-h-[340px] pr-2 space-y-2.5">
            {sortedDistricts.map((d, index) => {
              const val = latestRecord.districtValues[d.name] || 100;
              // Map static shopping centre occupancy rates for visual interest
              let occupancy = "92.4%";
              let catchment = "Core Metropolitan Hub";
              if (d.county === "North Yorkshire") {
                occupancy = d.name === "York" ? "95.2%" : "89.4%";
                catchment = "High-Spend Tourism Corridor";
              } else if (d.county === "South Yorkshire") {
                occupancy = d.name === "Sheffield" ? "91.8%" : "87.5%";
                catchment = "Advanced Manufacturing";
              } else if (d.county === "East Riding & Humber") {
                occupancy = d.name === "Hull" ? "90.1%" : "88.9%";
                catchment = "Port & Port Corridor";
              }

              return (
                <div key={d.name} className="bg-[#0F1115]/60 p-3 rounded-sm border border-[#4A4E52] hover:border-[#B87333]/60 transition flex justify-between items-center text-xs">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#1A1A1B] border border-[#4A4E52] flex items-center justify-center font-bold text-[#71797E] text-[10px]">
                        {index + 1}
                      </span>
                      <span className="font-bold text-white text-sm">{d.name}</span>
                      <span className="text-[10px] text-[#71797E] bg-[#1A1A1B] border border-[#4A4E52] px-1.5 py-0.25 rounded-sm">
                        {d.county}
                      </span>
                    </div>
                    <p className="text-[10px] text-[#71797E] max-w-sm line-clamp-1">{d.description}</p>
                    <div className="flex gap-4 pt-1 text-[10px] text-[#71797E]">
                      <span>Pop: {(d.population / 1000).toFixed(0)}k</span>
                      <span>•</span>
                      <span>Occupancy: <strong className="text-[#E4E3E0]">{occupancy}</strong></span>
                      <span>•</span>
                      <span className="text-[#B87333] font-medium">{catchment}</span>
                    </div>
                  </div>
                  <div className="text-right pl-4">
                    <div className="text-base font-bold text-white">{val.toFixed(1)}</div>
                    <div className="text-[9px] text-[#71797E] uppercase tracking-wider font-mono">Spend Index</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-[#0F1115] p-3 rounded-sm border border-[#4A4E52] text-[10px] text-[#71797E] mt-4 flex gap-2 items-start">
          <Info className="w-4 h-4 text-[#B87333] shrink-0 mt-0.5" />
          <span>Shopping centre occupancy rates and catchment categorization are calibrated on Rhino Merchant Acquiring and local open-source property registers. Hover over maps to benchmark real-time district performance metrics.</span>
        </div>
      </div>
    </div>
  );
}
