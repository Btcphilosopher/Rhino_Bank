/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { ComputedIndexSeries, MacroScenario } from "../types";
import { FileText, Download, Sparkles, RefreshCw, Loader2, AlertCircle } from "lucide-react";

interface ReportGeneratorProps {
  weights: { [indicatorId: string]: number };
  latestRecord: ComputedIndexSeries;
  selectedScenario: MacroScenario;
  selectedCounties: string[];
  forecastModel: string;
}

export default function ReportGenerator({
  weights,
  latestRecord,
  selectedScenario,
  selectedCounties,
  forecastModel
}: ReportGeneratorProps) {
  const [reportText, setReportText] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>("");
  const [activeReportType, setActiveReportType] = useState<string>("monthly");

  const generateAiReport = async () => {
    setIsLoading(true);
    setErrorMsg("");
    setReportText("");

    try {
      const response = await fetch("/api/reports/ai-insight", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          weights,
          currentMetrics: {
            latestValue: latestRecord.compositeValue,
            momChange: latestRecord.momChange,
            yoyChange: latestRecord.yoyChange,
            weakestSector: "Automotive & Transport",
            strongestSector: "Hospitality & Dining"
          },
          selectedScenario,
          selectedCounties,
          forecastModel
        })
      });

      const data = await response.json();
      if (data.success) {
        setReportText(data.report);
      } else {
        setErrorMsg(data.error || "Failed to generate report.");
      }
    } catch (error: any) {
      console.error("Failed to fetch report from API:", error);
      setErrorMsg("Network error. Make sure the server-side Gemini API is fully configured or your key is active.");
    } finally {
      setIsLoading(false);
    }
  };

  // Safe markdown line renderer
  const renderMarkdown = (text: string) => {
    return text.split("\n").map((line, idx) => {
      const trimmed = line.trim();
      if (trimmed.startsWith("## ")) {
        return (
          <h4 key={idx} className="text-sm font-semibold text-[#B87333] mt-4 mb-2 border-b border-[#4A4E52] pb-1 uppercase tracking-wider">
            {trimmed.substring(3)}
          </h4>
        );
      }
      if (trimmed.startsWith("### ")) {
        return (
          <h5 key={idx} className="text-xs font-bold text-white mt-3 mb-1">
            {trimmed.substring(4)}
          </h5>
        );
      }
      if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
        return (
          <li key={idx} className="ml-4 list-disc text-[#E4E3E0] text-xs mb-1">
            {parseBoldTags(trimmed.substring(2))}
          </li>
        );
      }
      if (trimmed === "") {
        return <div key={idx} className="h-2"></div>;
      }
      return (
        <p key={idx} className="text-xs text-[#E4E3E0] leading-relaxed mb-2">
          {parseBoldTags(trimmed)}
        </p>
      );
    });
  };

  const parseBoldTags = (line: string) => {
    const parts = line.split("**");
    return parts.map((part, i) => (i % 2 === 1 ? <strong key={i} className="font-bold text-white">{part}</strong> : part));
  };

  const handleDownloadCsv = () => {
    const csvContent = "data:text/csv;charset=utf-8,Date,WeightConfig,Value,Scenario\n" +
      `${latestRecord.date},Custom,${latestRecord.compositeValue.toFixed(1)},${selectedScenario.name}`;
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `RhinoQuant_YCSI_Report_${latestRecord.date}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const reportOptions = [
    { id: "monthly", title: "Monthly Yorkshire Consumer Spending Report", meta: "Core YCSI performance, momentum markers and sector shifts." },
    { id: "quarterly", title: "Quarterly Consumer Outlook Briefing", meta: "Aggregated 3-month macro demand tracking, inflation correlations." },
    { id: "banking", title: "Retail Lending & Treasury Opportunity Review", meta: "Rhino Bank mortgage, loan demand, and asset quality scorecards." }
  ];

  return (
    <div id="report-generator" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Report Template Selector */}
      <div className="lg:col-span-5 bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-lg flex flex-col justify-between">
        <div>
          <h4 className="text-lg font-light serif italic text-[#D1C7B7] mb-2 flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#B87333]" />
            Rhino Bank Report Catalog
          </h4>
          <p className="text-xs text-[#71797E] mb-4">Select a report archetype and synthesize with AI context-aware economic commentary.</p>

          <div className="space-y-3">
            {reportOptions.map((opt) => (
              <button
                key={opt.id}
                onClick={() => setActiveReportType(opt.id)}
                className={`w-full text-left p-3.5 rounded-sm border transition text-xs ${
                  activeReportType === opt.id
                    ? "bg-[#1A1A1B] border-[#B87333]"
                    : "bg-[#0F1115]/60 border-[#4A4E52] hover:border-[#71797E]"
                }`}
              >
                <div className="font-bold text-white mb-1">{opt.title}</div>
                <p className="text-[#71797E] text-[11px] leading-relaxed">{opt.meta}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-6 pt-6 border-t border-[#4A4E52] space-y-3">
          <button
            onClick={generateAiReport}
            disabled={isLoading}
            className="w-full bg-[#B87333] hover:bg-[#a06228] text-[#E4E3E0] font-semibold py-2.5 rounded-sm transition text-xs flex items-center justify-center gap-2 cursor-pointer"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Generating Economic Commentary...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-white" />
                <span>Synthesize Report with Gemini AI</span>
              </>
            )}
          </button>

          <button
            onClick={handleDownloadCsv}
            className="w-full bg-[#0F1115] hover:bg-[#1A1A1B] text-[#E4E3E0] border border-[#4A4E52] font-semibold py-2 rounded-sm transition text-xs flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Download className="w-4 h-4 text-[#B87333]" />
            <span>Export Raw Data CSV</span>
          </button>
        </div>
      </div>

      {/* Report Preview scroll box */}
      <div className="lg:col-span-7 bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-lg flex flex-col justify-between">
        <div className="flex-1">
          <div className="flex justify-between items-center mb-4 border-b border-[#4A4E52] pb-2">
            <h5 className="text-sm font-semibold text-white uppercase tracking-wider">Report Preview Board</h5>
            <span className="text-[10px] text-[#71797E] font-mono">CONFIDENTIAL // INTERNAL USE</span>
          </div>

          <div className="bg-[#0F1115] p-5 rounded-sm border border-[#4A4E52] max-h-[380px] overflow-y-auto font-sans leading-relaxed">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-20 space-y-4">
                <Loader2 className="w-8 h-8 text-[#B87333] animate-spin" />
                <div className="text-center space-y-1">
                  <p className="text-xs text-white font-semibold">Running classical econometric models...</p>
                  <p className="text-[10px] text-[#71797E]">Decomposing seasonality and parsing local authority index weights...</p>
                </div>
              </div>
            ) : errorMsg ? (
              <div className="flex gap-2.5 items-start bg-rose-950/20 p-4 rounded-sm border border-rose-900/50 text-xs text-rose-300">
                <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                <div>
                  <h6 className="font-bold text-white">Gemini Synthesis Blocked</h6>
                  <p className="text-[11px] mt-0.5">{errorMsg}</p>
                </div>
              </div>
            ) : reportText ? (
              <div className="space-y-3">{renderMarkdown(reportText)}</div>
            ) : (
              <div className="text-center py-16 text-[#71797E] space-y-2 text-xs">
                <Sparkles className="w-8 h-8 text-[#71797E]/60 mx-auto" />
                <div>
                  <p className="text-white font-medium">No report generated yet.</p>
                  <p className="text-[#71797E]">Click the "Synthesize" button to compile weights, scenario stresses, and forecasting models into a customized econ analysis briefing using the Gemini API.</p>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="text-[9px] text-[#71797E] mt-4 pt-4 border-t border-[#4A4E52]">
          Executive reports generated via RhinoQuant AI Synthesis are optimized for PDF-ready compliance logs and do not constitute authorized investment advice. All forecasts are models only.
        </div>
      </div>
    </div>
  );
}
