/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { SectorMetric, MonthlyRecord } from "../types";
import { SPENDING_SECTORS } from "../data/mockYorkshireData";
import { ShoppingCart, Coffee, MapPin, Award, Layers, Sparkles, TrendingUp, HelpCircle } from "lucide-react";

interface SectorAnalysisProps {
  latestRecord: MonthlyRecord;
}

export default function SectorAnalysis({ latestRecord }: SectorAnalysisProps) {
  const [hoveredSector, setHoveredSector] = useState<string | null>(null);

  // Find max value for drawing comparison bars
  const sectorValues = Object.values(latestRecord.sectorValues);
  const maxVal = Math.max(...sectorValues, 100);

  // Helper to choose nice color profiles
  const getSectorIcon = (id: string) => {
    switch (id) {
      case "food_retail": return <ShoppingCart className="w-4 h-4 text-emerald-400" />;
      case "hospitality": return <Coffee className="w-4 h-4 text-amber-400" />;
      case "tourism": return <MapPin className="w-4 h-4 text-blue-400" />;
      default: return <Award className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div id="sector-analysis" className="space-y-6">
      {/* Intro and summary metrics */}
      <div className="bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-lg">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h4 className="text-lg font-light serif italic text-[#D1C7B7] flex items-center gap-2">
              <Layers className="w-5 h-5 text-[#B87333]" />
              Sectoral Spending Profile
            </h4>
            <p className="text-xs text-[#71797E]">Breakdown of Yorkshire household expenditure index across primary spend sectors.</p>
          </div>
          <div className="flex gap-4 text-xs bg-[#0F1115] px-4 py-2.5 rounded-sm border border-[#4A4E52]">
            <div>
              <span className="text-[#71797E] block">Highest Performer:</span>
              <span className="font-bold text-green-400">Hospitality & Dining</span>
            </div>
            <div className="w-px bg-[#4A4E52]"></div>
            <div>
              <span className="text-[#71797E] block">Weakest Performer:</span>
              <span className="font-bold text-rose-400">Automotive & Transport</span>
            </div>
          </div>
        </div>

        {/* Dynamic Horizontal bar comparison chart */}
        <div className="space-y-3 mt-4">
          {SPENDING_SECTORS.map((sector) => {
            const indexVal = latestRecord.sectorValues[sector.id] || 100;
            const percentageWidth = (indexVal / maxVal) * 100;
            const isHovered = hoveredSector === sector.id;

            return (
              <div
                key={sector.id}
                className={`p-3 rounded-sm transition ${
                  isHovered ? "bg-[#1A1A1B]/80" : "bg-[#0F1115]/40"
                }`}
                onMouseEnter={() => setHoveredSector(sector.id)}
                onMouseLeave={() => setHoveredSector(null)}
              >
                <div className="grid grid-cols-12 items-center gap-4">
                  {/* Name and Share */}
                  <div className="col-span-12 md:col-span-4 flex items-center gap-2.5 text-xs">
                    {getSectorIcon(sector.id)}
                    <div>
                      <span className="font-semibold text-white block">{sector.name}</span>
                      <span className="text-[10px] text-[#71797E]">
                        Household share: <strong className="text-[#E4E3E0]">{(sector.baseShare * 100).toFixed(0)}%</strong>
                      </span>
                    </div>
                  </div>

                  {/* Horizontal visual bar */}
                  <div className="col-span-8 md:col-span-6 relative bg-[#0F1115] h-6 rounded-sm overflow-hidden border border-[#4A4E52]">
                    <div
                      className="absolute top-0 left-0 h-full bg-[#B87333] rounded-sm transition-all duration-300"
                      style={{ width: `${percentageWidth}%` }}
                    />
                    {/* Tick mark at 100 baseline */}
                    <div
                      className="absolute top-0 h-full w-0.5 bg-[#71797E]/80 z-10"
                      style={{ left: `${(100 / maxVal) * 100}%` }}
                      title="Jan 2021 baseline (100)"
                    />
                  </div>

                  {/* Index Value */}
                  <div className="col-span-4 md:col-span-2 text-right">
                    <span className="text-sm font-bold text-white">{indexVal.toFixed(1)}</span>
                    <span className="text-[10px] text-[#71797E] block font-mono">pts</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sector characteristics cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#242629] p-5 rounded-sm border border-[#4A4E52] shadow-lg relative overflow-hidden">
          <span className="text-xs uppercase tracking-wider text-[#71797E] block font-semibold mb-2">Essential/Non-Discretionary</span>
          <h5 className="text-white font-bold text-sm mb-1">Food & Groceries</h5>
          <p className="text-xs text-[#71797E]">High stability index under economic duress. Spending grows in line with raw inflation index inputs.</p>
          <div className="flex justify-between items-center mt-4 pt-4 border-t border-[#4A4E52] text-xs">
            <span className="text-[#71797E]">Typical Volatility:</span>
            <span className="font-bold text-green-400">Low (±2%)</span>
          </div>
        </div>

        <div className="bg-[#242629] p-5 rounded-sm border border-[#4A4E52] shadow-lg relative overflow-hidden">
          <span className="text-xs uppercase tracking-wider text-[#71797E] block font-semibold mb-2">Highly Cyclical / Discretionary</span>
          <h5 className="text-white font-bold text-sm mb-1">Automotive & Durables</h5>
          <p className="text-xs text-[#71797E]">Very sensitive to high-street bank personal credit tightening and BOE interest rate hikes.</p>
          <div className="flex justify-between items-center mt-4 pt-4 border-t border-[#4A4E52] text-xs">
            <span className="text-[#71797E]">Typical Volatility:</span>
            <span className="font-bold text-[#B87333]">High (±12%)</span>
          </div>
        </div>

        <div className="bg-[#242629] p-5 rounded-sm border border-[#4A4E52] shadow-lg relative overflow-hidden">
          <span className="text-xs uppercase tracking-wider text-[#71797E] block font-semibold mb-2">Seasonal / Tourist Corridor</span>
          <h5 className="text-white font-bold text-sm mb-1">Tourism & Hospitality</h5>
          <p className="text-xs text-[#71797E]">Massive double peaks in July/August and December. Heavily localized in coastal & historic centers.</p>
          <div className="flex justify-between items-center mt-4 pt-4 border-t border-[#4A4E52] text-xs">
            <span className="text-[#71797E]">Typical Volatility:</span>
            <span className="font-bold text-[#B87333]/90">Seasonal (±15%)</span>
          </div>
        </div>
      </div>
    </div>
  );
}
