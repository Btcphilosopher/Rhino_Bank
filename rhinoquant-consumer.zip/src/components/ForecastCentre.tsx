/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { ComputedIndexSeries, ForecastModelType, ForecastPoint } from "../types";
import { generateEconometricForecast, getModelPerformanceMetrics } from "../utils/indexEngine";
import { TrendingUp, HelpCircle, ArrowUpRight, BarChart, Settings, Sliders } from "lucide-react";

interface ForecastCentreProps {
  historicalSeries: ComputedIndexSeries[];
  scenarioMultiplier: number;
  volatilityMultiplier: number;
}

export default function ForecastCentre({
  historicalSeries,
  scenarioMultiplier,
  volatilityMultiplier
}: ForecastCentreProps) {
  const [modelType, setModelType] = useState<ForecastModelType>("Seasonal ARIMA (SARIMA)");
  const [horizon, setHorizon] = useState<number>(12);
  const [variable, setVariable] = useState<string>("ycsi");

  // Generate combined historical + future forecast series
  const forecastSeries = generateEconometricForecast(
    historicalSeries,
    modelType,
    horizon,
    scenarioMultiplier,
    volatilityMultiplier
  );

  // Extract metrics
  const metrics = getModelPerformanceMetrics(modelType, horizon);

  // Separate history and forecast for rendering
  const historyPoints = forecastSeries.filter((p) => p.isHistorical);
  const futurePoints = forecastSeries.filter((p) => !p.isHistorical);

  // Chart coordinate calculations
  const totalPoints = forecastSeries.length;
  const rawValues = forecastSeries.map((p) => p.predictedValue);
  const minVal = Math.min(...rawValues, ...forecastSeries.map(p => p.lowerConfidence)) - 5;
  const maxVal = Math.max(...rawValues, ...forecastSeries.map(p => p.upperConfidence)) + 5;
  const range = maxVal - minVal;

  const width = 800;
  const height = 300;
  const paddingLeft = 55;
  const paddingRight = 30;
  const paddingTop = 20;
  const paddingBottom = 40;

  const getCoordinates = (index: number, value: number) => {
    const x = paddingLeft + (index / (totalPoints - 1)) * (width - paddingLeft - paddingRight);
    const y = height - paddingBottom - ((value - minVal) / range) * (height - paddingTop - paddingBottom);
    return { x, y };
  };

  // Generate line paths
  const getPathD = (points: ForecastPoint[]) => {
    return points.reduce((path, pt) => {
      // Find index in global forecastSeries
      const idx = forecastSeries.findIndex((f) => f.date === pt.date);
      const { x, y } = getCoordinates(idx, pt.predictedValue);
      return path === "" ? `M ${x} ${y}` : `${path} L ${x} ${y}`;
    }, "");
  };

  // Generate custom translucent polygon for Confidence Interval Shading (the projection cone)
  const getConfidenceAreaPoints = () => {
    if (futurePoints.length === 0) return "";
    
    // We need coordinates of top line left-to-right, then bottom line right-to-left
    const topCoords: string[] = [];
    const bottomCoords: string[] = [];

    // Anchor at last historical point
    const lastHistIdx = historyPoints.length - 1;
    const lastHistPt = historyPoints[lastHistIdx];
    const anchorCoord = getCoordinates(lastHistIdx, lastHistPt.predictedValue);
    topCoords.push(`${anchorCoord.x},${anchorCoord.y}`);
    bottomCoords.push(`${anchorCoord.x},${anchorCoord.y}`);

    futurePoints.forEach((pt) => {
      const idx = forecastSeries.findIndex((f) => f.date === pt.date);
      const top = getCoordinates(idx, pt.upperConfidence);
      const bottom = getCoordinates(idx, pt.lowerConfidence);
      topCoords.push(`${top.x},${top.y}`);
      bottomCoords.unshift(`${bottom.x},${bottom.y}`); // reverse order for drawing loop
    });

    return [...topCoords, ...bottomCoords].join(" ");
  };

  const confidencePolygonPoints = getConfidenceAreaPoints();
  const historyPath = getPathD(historyPoints);
  const futurePath = getPathD(futurePoints);

  // Connection point from history to future
  const lastHistIdx = historyPoints.length - 1;
  const lastHistCoord = getCoordinates(lastHistIdx, historyPoints[lastHistIdx].predictedValue);
  const firstFutureCoord = futurePoints.length > 0 ? getCoordinates(lastHistIdx + 1, futurePoints[0].predictedValue) : null;

  return (
    <div id="forecast-centre" className="space-y-6">
      {/* Model Controls Card */}
      <div className="bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-lg">
        <h4 className="text-lg font-light serif italic text-[#D1C7B7] mb-4 flex items-center gap-2">
          <Settings className="w-5 h-5 text-[#B87333]" />
          Econometric & ML Model Settings
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
          {/* Model Type */}
          <div className="space-y-2">
            <label className="text-[#71797E] font-semibold block">Econometric Algorithm:</label>
            <select
              value={modelType}
              onChange={(e) => setModelType(e.target.value as ForecastModelType)}
              className="w-full bg-[#0F1115] text-[#E4E3E0] p-2.5 rounded-sm border border-[#4A4E52] outline-none focus:border-[#B87333]"
            >
              <option value="Seasonal ARIMA (SARIMA)" className="bg-[#0F1115]">Classical: Seasonal ARIMA (SARIMA)</option>
              <option value="ETS (Exponential Smoothing)" className="bg-[#0F1115]">Classical: ETS Smoothing (State Space)</option>
              <option value="Random Forest Regressor" className="bg-[#0F1115]">ML: Random Forest Regression</option>
              <option value="XGBoost spend predictor" className="bg-[#0F1115]">ML: XGBoost Trend Boost</option>
            </select>
            <p className="text-[10px] text-[#71797E]">Classical models handle cyclical seasonality elegantly, while ML handles non-linear regressions.</p>
          </div>

          {/* Horizon */}
          <div className="space-y-2">
            <label className="text-[#71797E] font-semibold block">Forecast Horizon (Months):</label>
            <div className="flex items-center gap-4">
              <input
                type="range"
                min="3"
                max="24"
                step="3"
                value={horizon}
                onChange={(e) => setHorizon(parseInt(e.target.value, 10))}
                className="w-full accent-[#B87333] h-1.5 bg-[#0F1115] rounded-sm cursor-pointer"
              />
              <span className="font-bold text-[#B87333] shrink-0 w-12 text-right">{horizon} mos</span>
            </div>
            <p className="text-[10px] text-[#71797E]">Projection extends forward from July 2026 into late 2028.</p>
          </div>

          {/* Variable isolated */}
          <div className="space-y-2">
            <label className="text-[#71797E] font-semibold block">Target Spending Indicator:</label>
            <select
              value={variable}
              onChange={(e) => setVariable(e.target.value)}
              className="w-full bg-[#0F1115] text-[#E4E3E0] p-2.5 rounded-sm border border-[#4A4E52] outline-none focus:border-[#B87333]"
            >
              <option value="ycsi" className="bg-[#0F1115]">Composite Index (YCSI)</option>
              <option value="card_payments" className="bg-[#0F1115]">Card Payment Activity</option>
              <option value="retail_sales" className="bg-[#0F1115]">Retail Sales Volume</option>
              <option value="supermarket" className="bg-[#0F1115]">Supermarket Spend</option>
            </select>
            <p className="text-[10px] text-[#71797E]">Perform forecasting over the aggregated composite index or separate indicators.</p>
          </div>
        </div>
      </div>

      {/* Main Forecasting Plot */}
      <div className="bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-xl">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h4 className="text-lg font-light serif italic text-[#D1C7B7]">YCSI Model Projections ({modelType})</h4>
            <p className="text-xs text-[#71797E]">Historical tracking (solid line) followed by forecasts with 95% confidence cones (shaded)</p>
          </div>
          {/* Chart Legend */}
          <div className="flex gap-4 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-[#B87333] inline-block"></span>
              <span className="text-[#E4E3E0]">Historical Core</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-purple-400 inline-block"></span>
              <span className="text-[#E4E3E0]">Forecast Projection</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-2 bg-purple-500/15 inline-block rounded-sm"></span>
              <span className="text-[#E4E3E0]">95% Conf. Interval</span>
            </div>
          </div>
        </div>

        {/* SVG Drawing */}
        <div className="relative">
          <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible select-none">
            {/* Gridlines */}
            {Array.from({ length: 5 }).map((_, idx) => {
              const val = minVal + (idx / 4) * range;
              const { y } = getCoordinates(0, val);
              return (
                <g key={idx}>
                  <line
                    x1={paddingLeft}
                    y1={y}
                    x2={width - paddingRight}
                    y2={y}
                    stroke="#4A4E52"
                    strokeDasharray="4,4"
                  />
                  <text
                    x={paddingLeft - 8}
                    y={y + 4}
                    fill="#71797E"
                    fontSize="10"
                    textAnchor="end"
                  >
                    {val.toFixed(0)}
                  </text>
                </g>
              );
            })}

            {/* X-axis dates */}
            {forecastSeries.map((p, idx) => {
              // Draw X axis label for Janaries or major points
              if (idx % 8 === 0 || idx === historyPoints.length) {
                const { x } = getCoordinates(idx, minVal);
                const label = p.date.endsWith("-01") ? p.date.split("-")[0] : p.date.split("-")[1] + "/" + p.date.split("-")[0].substring(2);
                return (
                  <g key={idx}>
                    <line
                      x1={x}
                      y1={height - paddingBottom}
                      x2={x}
                      y2={height - paddingBottom + 5}
                      stroke="#4A4E52"
                    />
                    <text
                      x={x}
                      y={height - paddingBottom + 18}
                      fill={p.isHistorical ? "#71797E" : "#a855f7"}
                      fontSize="9"
                      fontWeight={!p.isHistorical ? "bold" : "normal"}
                      textAnchor="middle"
                    >
                      {label}
                    </text>
                  </g>
                );
              }
              return null;
            })}

            {/* Shaded Confidence Interval Cone */}
            {confidencePolygonPoints && (
              <polygon
                points={confidencePolygonPoints}
                fill="rgba(168, 85, 247, 0.15)"
                stroke="transparent"
              />
            )}

            {/* History line */}
            <path
              d={historyPath}
              fill="none"
              stroke="#B87333"
              strokeWidth="2.5"
              strokeLinecap="round"
            />

            {/* Connecting line between history and future */}
            {firstFutureCoord && (
              <line
                x1={lastHistCoord.x}
                y1={lastHistCoord.y}
                x2={firstFutureCoord.x}
                y2={firstFutureCoord.y}
                stroke="purple"
                strokeWidth="2"
                strokeDasharray="2,2"
              />
            )}

            {/* Forecast line */}
            <path
              d={futurePath}
              fill="none"
              stroke="#a855f7"
              strokeWidth="2"
              strokeDasharray="4,4"
              strokeLinecap="round"
            />
          </svg>
        </div>
      </div>

      {/* Model Performance Diagnostics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#242629] p-5 rounded-sm border border-[#4A4E52] shadow-lg">
          <span className="text-[#71797E] text-[10px] uppercase tracking-wider font-semibold">Mean Absolute % Error (MAPE)</span>
          <div className="flex items-baseline gap-1 mt-1">
            <h5 className="text-2xl font-bold text-white">{metrics.mape}%</h5>
            <span className="text-[10px] text-green-400 font-semibold">Excellent</span>
          </div>
          <p className="text-[10px] text-[#71797E] mt-2">Average percentage deviation of predicted points against true holdings.</p>
        </div>

        <div className="bg-[#242629] p-5 rounded-sm border border-[#4A4E52] shadow-lg">
          <span className="text-[#71797E] text-[10px] uppercase tracking-wider font-semibold">Root Mean Square Error (RMSE)</span>
          <div className="flex items-baseline gap-1 mt-1">
            <h5 className="text-2xl font-bold text-white">{metrics.rmse}</h5>
            <span className="text-[10px] text-[#71797E]">pts</span>
          </div>
          <p className="text-[10px] text-[#71797E] mt-2">Symmetric standard deviation parameter penalizing higher forecasting spikes.</p>
        </div>

        <div className="bg-[#242629] p-5 rounded-sm border border-[#4A4E52] shadow-lg">
          <span className="text-[#71797E] text-[10px] uppercase tracking-wider font-semibold">Model R-Squared (R²)</span>
          <div className="flex items-baseline gap-1 mt-1">
            <h5 className="text-2xl font-bold text-white">{metrics.rSquared.toFixed(3)}</h5>
          </div>
          <p className="text-[10px] text-[#71797E] mt-2">Percentage of historical variance explained by the model weights matrix.</p>
        </div>

        <div className="bg-[#242629] p-5 rounded-sm border border-[#4A4E52] shadow-lg">
          <span className="text-[#71797E] text-[10px] uppercase tracking-wider font-semibold">Akaike Info Criterion (AIC)</span>
          <div className="flex items-baseline gap-1 mt-1">
            <h5 className="text-2xl font-bold text-white">{metrics.aic.toFixed(1)}</h5>
          </div>
          <p className="text-[10px] text-[#71797E] mt-2">Relative quality metric weighing parameter count against likelihood fit.</p>
        </div>
      </div>
    </div>
  );
}
