/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { MonthlyRecord, County } from "../types";
import { Shield, Coins, Home, Landmark, AlertTriangle, TrendingUp, Sparkles, CheckCircle } from "lucide-react";

interface BankingAnalyticsProps {
  latestRecord: MonthlyRecord;
}

export default function BankingAnalytics({ latestRecord }: BankingAnalyticsProps) {
  const m = latestRecord.bankingMetrics;

  const resilienceDetails = [
    {
      county: "West Yorkshire" as County,
      resilience: "HIGH",
      depositStability: "Very Stable",
      creditRisk: "Moderate",
      comment: "Leeds financial hub provides highly robust services employment anchoring consumer spending."
    },
    {
      county: "South Yorkshire" as County,
      resilience: "MODERATE",
      depositStability: "Stable",
      creditRisk: "Moderate-Low",
      comment: "Sheffield medical-tech clusters cushion declines in older heavy manufacturing industries."
    },
    {
      county: "North Yorkshire" as County,
      resilience: "HIGH-EXCEPTIONAL",
      depositStability: "Exceptional",
      creditRisk: "Very Low",
      comment: "Affluent saver segments (Harrogate, York, Skipton) carry huge liquid savings reserves."
    },
    {
      county: "East Riding & Humber" as County,
      resilience: "MODERATE-LOW",
      depositStability: "Volatile",
      creditRisk: "High",
      comment: "Coastal holiday dependencies see extreme offseason savings drawdowns. Port sectors remain solid."
    }
  ];

  return (
    <div id="banking-analytics" className="space-y-6">
      {/* Treasury & Risk KPI Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Metric 1: Credit Quality */}
        <div className="bg-[#242629] p-5 rounded-sm border-l-4 border-green-500 border-t border-r border-b border-[#4A4E52] shadow-lg flex items-start gap-4">
          <div className="p-3 bg-[#0F1115] border border-[#4A4E52] rounded-sm">
            <Shield className="w-6 h-6 text-green-400" />
          </div>
          <div className="space-y-1">
            <span className="text-xs uppercase tracking-wider text-[#71797E] block font-semibold">Credit Quality Index</span>
            <div className="flex items-baseline gap-1.5">
              <h4 className="text-2xl font-bold text-white">{m.creditQualityIndex.toFixed(1)}</h4>
              <span className="text-[10px] text-green-400 font-semibold bg-[#0F1115] border border-green-900/50 px-1.5 py-0.25 rounded-sm">HEALTHY</span>
            </div>
            <p className="text-[10px] text-[#71797E]">Default probability is low; robust underwriting.</p>
          </div>
        </div>

        {/* Metric 2: Lending & Loan Demand */}
        <div className="bg-[#242629] p-5 rounded-sm border-l-4 border-[#B87333] border-t border-r border-b border-[#4A4E52] shadow-lg flex items-start gap-4">
          <div className="p-3 bg-[#0F1115] border border-[#4A4E52] rounded-sm">
            <Coins className="w-6 h-6 text-[#B87333]" />
          </div>
          <div className="space-y-1">
            <span className="text-xs uppercase tracking-wider text-[#71797E] block font-semibold">Personal Loan Demand</span>
            <div className="flex items-baseline gap-1.5">
              <h4 className="text-2xl font-bold text-white">{m.lendingDemand.toFixed(1)}</h4>
              <span className="text-[10px] text-[#B87333] font-semibold bg-[#0F1115] border border-[#B87333]/40 px-1.5 py-0.25 rounded-sm">EXPANDING</span>
            </div>
            <p className="text-[10px] text-[#71797E]">Demand for credit card drawdowns & POS lines is up.</p>
          </div>
        </div>

        {/* Metric 3: Mortgage Approvals */}
        <div className="bg-[#242629] p-5 rounded-sm border-l-4 border-blue-500 border-t border-r border-b border-[#4A4E52] shadow-lg flex items-start gap-4">
          <div className="p-3 bg-[#0F1115] border border-[#4A4E52] rounded-sm">
            <Home className="w-6 h-6 text-blue-400" />
          </div>
          <div className="space-y-1">
            <span className="text-xs uppercase tracking-wider text-[#71797E] block font-semibold">Mortgage Approvals Count</span>
            <div className="flex items-baseline gap-1.5">
              <h4 className="text-2xl font-bold text-white">{m.mortgageApprovals.toFixed(0)}</h4>
              <span className="text-[10px] text-blue-400 font-semibold bg-[#0F1115] border border-blue-900/50 px-1.5 py-0.25 rounded-sm">STEADY</span>
            </div>
            <p className="text-[10px] text-[#71797E]">New buyer mortgage activity remains resilient.</p>
          </div>
        </div>
      </div>

      {/* Main Resilience and Savings Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Resilience Table */}
        <div className="lg:col-span-7 bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-lg">
          <h4 className="text-lg font-light serif italic text-[#D1C7B7] mb-2 flex items-center gap-2">
            <Landmark className="w-5 h-5 text-[#B87333]" />
            Rhino Bank Regional Resilience Audit
          </h4>
          <p className="text-xs text-[#71797E] mb-4">Underwriting sensitivity and savings rate margins sorted by sub-county jurisdictions.</p>
          
          <div className="space-y-3">
            {resilienceDetails.map((item) => (
              <div key={item.county} className="bg-[#0F1115]/40 p-4 rounded-sm border border-[#4A4E52] space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-white text-sm">{item.county}</span>
                  <span className={`px-2 py-0.5 rounded-sm text-[10px] font-bold ${
                    item.resilience.includes("HIGH") ? "bg-green-950/40 text-green-300 border border-green-900/40" : "bg-amber-950/40 text-amber-300 border border-amber-900/40"
                  }`}>
                    RESILIENCE: {item.resilience}
                  </span>
                </div>
                <p className="text-[11px] text-[#E4E3E0] font-light leading-relaxed">{item.comment}</p>
                <div className="grid grid-cols-3 gap-2 text-[10px] text-[#71797E] pt-2 border-t border-[#4A4E52]">
                  <div>
                    <span>Deposits: </span>
                    <strong className="text-white">{item.depositStability}</strong>
                  </div>
                  <div>
                    <span>Credit Risk: </span>
                    <strong className="text-white">{item.creditRisk}</strong>
                  </div>
                  <div>
                    <span>Deposit Volatility: </span>
                    <strong className="text-rose-400">{m.depositVolatility.toFixed(2)}%</strong>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Opportunity generator panel */}
        <div className="lg:col-span-5 bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-lg flex flex-col justify-between">
          <div>
            <h4 className="text-lg font-light serif italic text-[#D1C7B7] mb-2 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#B87333]" />
              Lending & Investment Scorecard
            </h4>
            <p className="text-xs text-[#71797E] mb-4">Rhino Bank retail placement suggestions computed from YCSI trends.</p>

            <div className="space-y-3 text-xs">
              <div className="flex gap-2.5 items-start bg-green-950/20 p-3 rounded-sm border border-green-900/30">
                <CheckCircle className="w-4.5 h-4.5 text-green-400 shrink-0 mt-0.5" />
                <div>
                  <h6 className="font-bold text-white">Aggressive Cash ISA Promotion</h6>
                  <p className="text-[11px] text-[#E4E3E0] mt-0.5">Focus high-yield retail cash products in York, Harrogate and Skipton to lock in high-net-worth liquidity.</p>
                </div>
              </div>

              <div className="flex gap-2.5 items-start bg-blue-950/20 p-3 rounded-sm border border-blue-900/30">
                <CheckCircle className="w-4.5 h-4.5 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <h6 className="font-bold text-white">Leeds Digital Card Credit Expansions</h6>
                  <p className="text-[11px] text-[#E4E3E0] mt-0.5">Raise credit card limit offers for pre-screened salaried client segments in central Leeds by 15% due to robust velocity.</p>
                </div>
              </div>

              <div className="flex gap-2.5 items-start bg-rose-950/20 p-3 rounded-sm border border-rose-900/30">
                <AlertTriangle className="w-4.5 h-4.5 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <h6 className="font-bold text-white">Squeeze-Risk Mitigation</h6>
                  <p className="text-[11px] text-[#E4E3E0] mt-0.5">Tighten point-of-sale consumer finance parameters in Scarborough and Bridlington to cushion seasonal maritime credit slides.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-[#0F1115] border border-[#4A4E52] p-2.5 rounded-sm text-[10px] text-[#71797E] mt-4">
            Analysis is updated every Friday morning. Refer to the monthly Yorkshire Consumer Spending Report for underwriting compliance limits.
          </div>
        </div>
      </div>
    </div>
  );
}
