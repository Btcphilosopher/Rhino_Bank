/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { SpendingIndicator, PCAOutput } from "../types";
import { YCSI_INDICATORS } from "../data/mockYorkshireData";
import { performPCASimulation } from "../utils/indexEngine";
import { Sliders, RefreshCw, Layers, Sparkles, Check, Info } from "lucide-react";

interface CsiConfiguratorProps {
  weights: { [indicatorId: string]: number };
  onWeightsChange: (newWeights: { [indicatorId: string]: number }) => void;
  onMethodologySelect: (methodologyId: string) => void;
  activeMethodology: string;
}

export default function CsiConfigurator({
  weights,
  onWeightsChange,
  onMethodologySelect,
  activeMethodology
}: CsiConfiguratorProps) {
  const [pcaResult, setPcaResult] = useState<PCAOutput[]>(() => performPCASimulation(weights));
  const [activePc, setActivePc] = useState<number>(0);

  const sumWeights = Object.values(weights).reduce((a, b) => a + b, 0);

  const handleWeightSlider = (id: string, val: number) => {
    const newWeights = { ...weights, [id]: val };
    onWeightsChange(newWeights);
  };

  const handleNormalize = () => {
    if (sumWeights === 0) return;
    const factor = 100 / sumWeights;
    const normalized: { [id: string]: number } = {};
    Object.entries(weights).forEach(([k, v]) => {
      normalized[k] = Math.round(v * factor);
    });
    // Ensure it sums perfectly to 100 due to rounding
    let normSum = Object.values(normalized).reduce((a, b) => a + b, 0);
    if (normSum !== 100) {
      const keys = Object.keys(normalized);
      normalized[keys[0]] += (100 - normSum);
    }
    onWeightsChange(normalized);
  };

  const reRunPca = () => {
    setPcaResult(performPCASimulation(weights));
  };

  const methodologies = [
    {
      id: "baseline",
      name: "Rhino Baseline Index",
      desc: "Rhino Bank's standard balanced portfolio measuring core retail, financial, and confidence vectors.",
    },
    {
      id: "equal_weighted",
      name: "Equal Weighted Index",
      desc: "Simplistic model assigning exactly 10% to each indicator. Transparent and direct.",
    },
    {
      id: "high_street_heavy",
      name: "High Street & Tourism Index",
      desc: "Heavily weights local footfall, hospitality spends, and physical retail. Useful for urban councils.",
    },
    {
      id: "real_power",
      name: "Purchasing Power Real Index",
      desc: "Focuses on disposable incomes, savings drawdowns, and credit expansion relative to retail sales.",
    }
  ];

  return (
    <div id="csi-configurator" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Weight Sliders Block */}
      <div className="lg:col-span-7 bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-lg flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-center mb-4">
            <div>
              <h4 className="text-lg font-light serif italic text-[#D1C7B7] flex items-center gap-2">
                <Sliders className="w-5 h-5 text-[#B87333]" />
                Composite Index Weights Configurator
              </h4>
              <p className="text-xs text-[#71797E]">Adjust indicator percentages. Composite sum must ideally equal 100%.</p>
            </div>
            <button
              onClick={handleNormalize}
              className="bg-[#0F1115] text-[#E4E3E0] hover:bg-[#1A1A1B] text-[11px] px-2.5 py-1.5 rounded-sm transition font-medium flex items-center gap-1 border border-[#4A4E52]"
            >
              <RefreshCw className="w-3.5 h-3.5 text-[#B87333]" />
              Auto-Normalize (100%)
            </button>
          </div>

          <div className="space-y-4 max-h-[380px] overflow-y-auto pr-2 mt-4">
            {YCSI_INDICATORS.map((ind) => {
              const weightVal = weights[ind.id] || 0;
              return (
                <div key={ind.id} className="bg-[#0F1115] p-3 rounded-sm border border-[#4A4E52] hover:border-[#B87333]/40 transition">
                  <div className="flex justify-between items-center mb-1 text-xs">
                    <span className="font-semibold text-white">{ind.name}</span>
                    <span className="font-bold text-[#B87333]">{weightVal}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="50"
                    step="1"
                    value={weightVal}
                    onChange={(e) => handleWeightSlider(ind.id, parseInt(e.target.value, 10))}
                    className="w-full accent-[#B87333] h-1.5 bg-[#1A1A1B] rounded-sm cursor-pointer"
                  />
                  <p className="text-[10px] text-[#71797E] mt-1">{ind.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Status indicator */}
        <div className="mt-4 pt-4 border-t border-[#4A4E52] flex justify-between items-center">
          <span className="text-xs text-[#71797E]">
            Total Combined Weight:{" "}
            <span className={sumWeights === 100 ? "text-green-400 font-bold" : "text-[#B87333] font-bold"}>
              {sumWeights}%
            </span>
          </span>
          {sumWeights !== 100 && (
            <span className="text-[10px] text-[#B87333] bg-[#0F1115] px-2 py-0.5 rounded-sm border border-[#B87333]/55">
              Weights total {sumWeights}%. Index calculations will self-normalize.
            </span>
          )}
        </div>
      </div>

      {/* Methodology Comparison & PCA Block */}
      <div className="lg:col-span-5 space-y-6">
        {/* Methodologies */}
        <div className="bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-lg">
          <h4 className="text-lg font-light serif italic text-[#D1C7B7] mb-4 flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#B87333]" />
            Comparison Methodologies
          </h4>
          <div className="space-y-3">
            {methodologies.map((m) => (
              <button
                key={m.id}
                onClick={() => onMethodologySelect(m.id)}
                className={`w-full text-left p-3 rounded-sm transition text-xs border ${
                  activeMethodology === m.id
                    ? "bg-[#0F1115] border-[#B87333]"
                    : "bg-[#0F1115]/50 border-[#4A4E52] hover:border-[#71797E]"
                }`}
              >
                <div className="flex justify-between items-center font-bold text-white mb-1">
                  <span>{m.name}</span>
                  {activeMethodology === m.id && <Check className="w-4 h-4 text-[#B87333]" />}
                </div>
                <p className="text-[#71797E] text-[11px]">{m.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* PCA Analysis */}
        <div className="bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-lg">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h4 className="text-lg font-light serif italic text-[#D1C7B7] flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#B87333]" />
                Principal Component Analysis (PCA)
              </h4>
              <p className="text-xs text-[#71797E]">Simulated latent vectors based on weight matrix</p>
            </div>
            <button
              onClick={reRunPca}
              title="Re-estimate eigenvectors based on current weight matrix"
              className="p-1.5 rounded-sm bg-[#0F1115] hover:bg-[#1A1A1B] border border-[#4A4E52] transition"
            >
              <RefreshCw className="w-3.5 h-3.5 text-[#E4E3E0]" />
            </button>
          </div>

          {/* PC Selector tabs */}
          <div className="flex gap-2 mb-4">
            {pcaResult.map((pca, idx) => (
              <button
                key={idx}
                onClick={() => setActivePc(idx)}
                className={`flex-1 text-center py-1.5 rounded-sm text-[10px] uppercase tracking-wider font-semibold transition ${
                  activePc === idx ? "bg-[#0F1115] text-[#B87333] border border-[#B87333]" : "bg-[#1A1A1B] text-[#71797E]"
                }`}
              >
                PC{idx + 1} ({pca.varianceExplained.toFixed(0)}%)
              </button>
            ))}
          </div>

          <div className="space-y-2.5">
            <div className="bg-[#0F1115] p-3 rounded-sm text-xs space-y-1">
              <div className="flex justify-between text-[#71797E]">
                <span>Component Focus:</span>
                <span className="text-white font-medium">{pcaResult[activePc].component}</span>
              </div>
              <div className="flex justify-between text-[#71797E]">
                <span>Eigenvalue:</span>
                <span className="text-white font-medium">{pcaResult[activePc].eigenvalue.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[#71797E]">
                <span>Variance Explained:</span>
                <span className="text-[#B87333] font-bold">{pcaResult[activePc].varianceExplained}%</span>
              </div>
            </div>

            {/* Loading items */}
            <div className="space-y-1.5 text-[11px] max-h-[140px] overflow-y-auto pr-1">
              <div className="grid grid-cols-12 text-[#71797E] px-1 pb-1 uppercase tracking-wider">
                <span className="col-span-8">Indicator</span>
                <span className="col-span-4 text-right">Eigen-loading</span>
              </div>
              {YCSI_INDICATORS.map((ind) => {
                const loading = pcaResult[activePc].loadings[ind.id] || 0;
                return (
                  <div key={ind.id} className="grid grid-cols-12 py-1 border-b border-[#4A4E52] px-1 text-[#E4E3E0]">
                    <span className="col-span-8 truncate font-medium text-white">{ind.name}</span>
                    <span className={`col-span-4 text-right font-mono font-bold ${
                      loading >= 0.3 ? "text-green-400" : loading <= -0.1 ? "text-rose-400" : "text-[#71797E]"
                    }`}>
                      {loading >= 0 ? "+" : ""}{loading.toFixed(3)}
                    </span>
                  </div>
                );
              })}
            </div>
            <p className="text-[9px] text-[#71797E] flex gap-1 items-start bg-[#0F1115] p-2 rounded-sm border border-[#4A4E52]">
              <Info className="w-3 h-3 text-[#B87333] shrink-0 mt-0.5" />
              <span>High positive eigen-loadings (closer to +1) signify strong positive correlation with the latent economic factor.</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
