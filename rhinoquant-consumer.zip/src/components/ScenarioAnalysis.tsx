/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { MacroScenario } from "../types";
import { MACRO_SCENARIOS } from "../data/mockYorkshireData";
import { Sliders, AlertCircle, Info, Check, Sparkles } from "lucide-react";

interface ScenarioAnalysisProps {
  selectedScenario: MacroScenario;
  onScenarioSelect: (scenario: MacroScenario) => void;
}

export default function ScenarioAnalysis({ selectedScenario, onScenarioSelect }: ScenarioAnalysisProps) {
  return (
    <div id="scenario-analysis" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Scenario Selection list */}
      <div className="lg:col-span-6 bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-lg flex flex-col justify-between">
        <div>
          <h4 className="text-lg font-light serif italic text-[#D1C7B7] mb-2 flex items-center gap-2">
            <Sliders className="w-5 h-5 text-[#B87333]" />
            Select Macroeconomic Stress Scenario
          </h4>
          <p className="text-xs text-[#71797E] mb-4">Choose a scenario to alter the econometric trajectory of the index forecasts.</p>

          <div className="space-y-3">
            {MACRO_SCENARIOS.map((scenario) => {
              const isSelected = selectedScenario.id === scenario.id;
              return (
                <button
                  key={scenario.id}
                  onClick={() => onScenarioSelect(scenario)}
                  className={`w-full text-left p-4 rounded-sm border transition text-xs flex justify-between items-start gap-4 ${
                    isSelected
                      ? "bg-[#1A1A1B] border-[#B87333]"
                      : "bg-[#0F1115]/60 border-[#4A4E52] hover:border-[#71797E]"
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 font-bold text-white text-sm">
                      <span>{scenario.name}</span>
                      {isSelected && (
                        <span className="bg-[#B87333]/20 text-[#B87333] border border-[#B87333] text-[9px] px-1.5 py-0.25 rounded-sm font-normal uppercase">
                          ACTIVE STRESS
                        </span>
                      )}
                    </div>
                    <p className="text-[#71797E] text-xs leading-relaxed">{scenario.description}</p>
                  </div>
                  {isSelected && <Check className="w-5 h-5 text-[#B87333] shrink-0 mt-1" />}
                </button>
              );
            })}
          </div>
        </div>

        <div className="bg-[#0F1115] p-3 rounded-sm border border-[#4A4E52] text-[10px] text-[#71797E] mt-4 flex gap-2 items-start">
          <Info className="w-4 h-4 text-[#B87333] shrink-0 mt-0.5" />
          <span>Active stress multipliers apply directly to the econometric forecasting engine's rolling mean projections and forecast volatility cones.</span>
        </div>
      </div>

      {/* Scenario Impact details */}
      <div className="lg:col-span-6 bg-[#242629] p-6 rounded-sm border border-[#4A4E52] shadow-lg flex flex-col justify-between">
        <div>
          <h4 className="text-lg font-light serif italic text-[#D1C7B7] mb-4 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-[#B87333]" />
            Vulnerability & Credit Implication Index
          </h4>

          <div className="space-y-4">
            {/* Impact Metric block */}
            <div className="bg-[#0F1115] p-4 rounded-sm border border-[#4A4E52] grid grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-[#71797E] block">Immediate Spend Multiplier:</span>
                <span className={`text-xl font-extrabold ${
                  selectedScenario.spendingImpact >= 0 ? "text-green-400" : "text-rose-400"
                }`}>
                  {selectedScenario.spendingImpact >= 0 ? "+" : ""}{(selectedScenario.spendingImpact * 100).toFixed(1)}%
                </span>
              </div>
              <div>
                <span className="text-[#71797E] block">Forecast Volatility Delta:</span>
                <span className="text-xl font-extrabold text-white">
                  x{selectedScenario.volatilityMultiplier.toFixed(1)}
                </span>
              </div>
            </div>

            {/* Impacted Sectors */}
            <div>
              <span className="text-xs text-[#71797E] font-semibold block mb-2">Primary Impacted Sectors:</span>
              {selectedScenario.impactedSectors.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {selectedScenario.impactedSectors.map((sectorId) => (
                    <span
                      key={sectorId}
                      className="bg-rose-950/40 text-rose-300 border border-rose-900/80 rounded-sm px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider"
                    >
                      {sectorId.replace("_", " ")}
                    </span>
                  ))}
                </div>
              ) : (
                <span className="text-xs text-[#71797E] italic bg-[#0F1115] border border-[#4A4E52] px-3 py-1 rounded-sm">No sector-specific stress targeted. Core baseline trajectory.</span>
              )}
            </div>

            {/* Actionable bank recommendations under stress */}
            <div className="space-y-3 pt-2">
              <span className="text-xs text-[#71797E] font-semibold block">Rhino Bank Treasury Risk Advisory:</span>
              
              <div className="bg-[#0F1115] p-3 rounded-sm text-xs space-y-2 border border-[#4A4E52]">
                <div className="flex gap-2 items-start">
                  <Sparkles className="w-4 h-4 text-[#B87333] shrink-0 mt-0.5" />
                  <div>
                    <h6 className="font-bold text-white">
                      {selectedScenario.id === "baseline" ? "Maintain Standard Lending Caps" :
                       selectedScenario.id === "inflation_squeeze" ? "Hedge Unsecured Credit Drawdowns" :
                       selectedScenario.id === "tourism_boom" ? "Deploy High Street Merchant POS Terminals" :
                       selectedScenario.id === "manufacturing_surge" ? "Promote Equipment Leasing Lines" :
                       "Expand Savings Margin Buffers"}
                    </h6>
                    <p className="text-[11px] text-[#71797E] mt-0.5">
                      {selectedScenario.id === "baseline" ? "Standard macroprudential limits remain appropriate. No tactical adjustments needed." :
                       selectedScenario.id === "inflation_squeeze" ? "Unsecured loan credit score bars should be raised by 15 points. Expand provisions by £15m." :
                       selectedScenario.id === "tourism_boom" ? "Deploy mobile merchant services terminal kits along coastal Whitby & Scarborough corridors immediately." :
                       selectedScenario.id === "manufacturing_surge" ? "Direct commercial bankers to solicit credit lines with heavy machinery fabricators in Rotherham/Sheffield." :
                       "Optimize core liability deposits. Cut funding cost margins on savings accounts by 25 bps."}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-[#0F1115] border border-[#4A4E52] p-2.5 rounded-sm text-[10px] text-[#71797E] mt-4">
          All stress scenarios are computed deterministically on top of classical VAR lag parameters. Data is simulated under standard Basel III compliance constraints.
        </div>
      </div>
    </div>
  );
}
