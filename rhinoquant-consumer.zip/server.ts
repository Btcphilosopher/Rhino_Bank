import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialize Gemini client to avoid startup crashes if API key is missing
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
      throw new Error("GEMINI_API_KEY environment variable is not configured. Please add your key in Settings > Secrets.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// API endpoint for health check
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    apiKeyConfigured: !!(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY"),
  });
});

// API endpoint to generate economist-grade economic briefings using Gemini 3.6 Flash
app.post("/api/reports/ai-insight", async (req, res) => {
  try {
    const {
      weights,
      currentMetrics,
      selectedScenario,
      selectedCounties,
      forecastModel,
    } = req.body;

    const ai = getGeminiClient();

    const systemInstruction = `You are a Senior Principal Economist and Econometrician at Rhino Bank.
Your task is to write an executive-grade Yorkshire Consumer Spending Index (YCSI) Economic Briefing.
Write with professional, academic, yet practical banking vocabulary. 
Use precise economic indicators (e.g., inflation-adjusted purchasing power, retail footfall, card payment liquidity).
Emphasize Yorkshire's industrial heritage (steel, textiles, coal-to-green energy transitions, high-tech manufacturing, tourism corridors) and local geography.
Your target audience is Rhino Bank's Executive Committee, Chief Risk Officer, and Treasury Directors.
Do not use generic fluff. Make it look like a highly customized research report.`;

    const prompt = `Develop a detailed Yorkshire Consumer Spending Index (YCSI) briefing with the following context:

1. COMPOSITE INDEX DESIGN & WEIGHTS:
${Object.entries(weights || {})
  .map(([k, v]) => `   - ${k}: ${v}%`)
  .join("\n")}

2. CURRENT INDEX STATUS & PERFORMANCE:
   - Latest Composite Index Value: ${currentMetrics?.latestValue?.toFixed(1) || "105.4"} (Baseline: 100 in Jan 2021)
   - Month-on-Month Growth: ${currentMetrics?.momChange?.toFixed(2) || "+0.45"}%
   - Year-on-Year Growth: ${currentMetrics?.yoyChange?.toFixed(2) || "+2.3"}%
   - Key Underperforming Area: ${currentMetrics?.weakestSector || "Automotive & Durables"}
   - Key Growth Driver: ${currentMetrics?.strongestSector || "Leisure & Hospitality"}

3. GEO-POLITICAL / ECONOMETRIC SCENARIO:
   - Selected Macro Scenario: "${selectedScenario?.name || "Baseline Outlook"}"
   - Scenario Influence: "${selectedScenario?.description || "Stable moderate recovery under standard baseline interest rate projections."}"

4. GEOGRAPHIC SCOPE:
   - Regions under review: ${selectedCounties?.join(", ") || "All Yorkshire & Humber districts"}

5. ECONOMETRIC MODEL USED FOR FORECASTING:
   - Forecasting Model: "${forecastModel || "Seasonal ARIMA (SARIMA)"}"

Structure your report into the following 5 distinct, highly-polished sections:
- **1. Executive Summary**: A sharp, high-level summary of Yorkshire consumer demand strength, purchasing power resilient features, and immediate credit impact.
- **2. Index Formulation Critique & Sensitivity**: Critique how the selected weights (${weights ? "custom customized weights" : "baseline weights"}) capture true purchasing power under the active "${selectedScenario?.name || "Baseline"}" scenario.
- **3. Yorkshire Regional Hotspots Review**: Dive into Leeds' retail core, Sheffield's steel-to-medical tech resilience, West Yorkshire's industrial valleys (Bradford, Calderdale), and East Riding's industrial ports (Hull). Highlight differences in consumer credit drawdowns.
- **4. Econometric Forecasting & Volatility**: Assess the stability and projections of the "${forecastModel || "ARIMA"}" model under the selected scenario. Warn of potential structural breaks.
- **5. Rhino Bank Strategic Implications**: Concrete banking suggestions. Should Rhino Bank expand consumer lending, tighten mortgage approvals in specific postcodes, or capture corporate deposits in retail segments?

Keep the report clean, detailed, professional, and do not use markdown links or generic SaaS terms. Use bold highlights.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({
      success: true,
      report: response.text,
      modelUsed: "gemini-3.6-flash",
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("Gemini report generation error:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to generate economic insight.",
    });
  }
});

// Configure Vite middleware and static files
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting server in DEVELOPMENT mode with Vite Middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting server in PRODUCTION mode...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`RhinoQuant Consumer server listening on port ${PORT}`);
  });
}

startServer();
