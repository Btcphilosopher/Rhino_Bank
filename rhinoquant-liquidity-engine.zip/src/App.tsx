/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * RhinoQuant Liquidity Engine - Main Terminal Application
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  Activity,
  AlertTriangle,
  BookOpen,
  Calendar,
  CheckCircle2,
  Clock,
  Compass,
  FileCheck,
  FileText,
  HelpCircle,
  Keyboard,
  Layers,
  Pause,
  Play,
  RotateCcw,
  Scale,
  Server,
  Shield,
  ShieldAlert,
  Sparkles,
  Terminal,
  Zap
} from 'lucide-react';

import {
  AllocationStrategy,
  CollateralAsset,
  Counterparty,
  Currency,
  EngineTelemetry,
  Facility,
  FundingRequest,
  LedgerJournalEntry,
  LiquidityPoolStatus,
  MakerCheckerItem,
  ProductType,
  UserRole
} from './types';

import {
  INITIAL_COLLATERAL,
  INITIAL_COUNTERPARTIES,
  INITIAL_FACILITIES,
  INITIAL_JOURNAL_ENTRIES,
  INITIAL_LIQUIDITY_POOL,
  INITIAL_MAKER_CHECKER,
  INITIAL_REQUESTS,
  INITIAL_TELEMETRY
} from './data/seedData';

import { evaluateFundingRequest } from './engine/limits';
import { calculateQuote } from './engine/pricing';
import { makeDisbursementEntry, makeRepaymentEntry, makeOverdueEntry } from './engine/ledger';
import { allocateCollateralForLoan, releaseCollateralAllocations } from './engine/collateral';
import { AllocationRunResult } from './engine/allocator';
import { ScenarioRunResult } from './engine/simulation';

import { Header } from './components/Header';
import { CommandCentre } from './components/CommandCentre';
import { LendingQueue } from './components/LendingQueue';
import { FacilitiesView } from './components/FacilitiesView';
import { FundingAllocationView } from './components/FundingAllocationView';
import { PricingEngineView } from './components/PricingEngineView';
import { CollateralView } from './components/CollateralView';
import { RiskAnalyticsView } from './components/RiskAnalyticsView';
import { LedgerView } from './components/LedgerView';
import { SimulationLabView } from './components/SimulationLabView';
import { AuditControlsView } from './components/AuditControlsView';
import { RequestDetailModal } from './components/RequestDetailModal';
import { NewRequestModal } from './components/NewRequestModal';
import { ArchitectureDocsModal } from './components/ArchitectureDocsModal';

const SCREENS = [
  { id: 'COMMAND_CENTRE', label: 'Command Centre', shortcut: '1' },
  { id: 'LENDING_QUEUE', label: 'Lending Queue', shortcut: '2' },
  { id: 'FACILITIES', label: 'Facilities', shortcut: '3' },
  { id: 'FUNDING', label: 'Funding', shortcut: '4' },
  { id: 'PRICING', label: 'Pricing', shortcut: '5' },
  { id: 'COLLATERAL', label: 'Collateral', shortcut: '6' },
  { id: 'RISK', label: 'Risk', shortcut: '7' },
  { id: 'LEDGER', label: 'Ledger', shortcut: '8' },
  { id: 'SIMULATION', label: 'Simulation', shortcut: '9' },
  { id: 'AUDIT', label: 'Audit & Controls', shortcut: '0' }
];

export default function App() {
  // Persistent State with LocalStorage Caching
  const [activeScreen, setActiveScreen] = useState<string>('COMMAND_CENTRE');
  const [currentRole, setCurrentRole] = useState<UserRole>('HEAD_OF_LIQUIDITY');

  const [counterparties, setCounterparties] = useState<Counterparty[]>(() => {
    const cached = localStorage.getItem('rq_counterparties');
    return cached ? JSON.parse(cached) : INITIAL_COUNTERPARTIES;
  });

  const [facilities, setFacilities] = useState<Facility[]>(() => {
    const cached = localStorage.getItem('rq_facilities');
    return cached ? JSON.parse(cached) : INITIAL_FACILITIES;
  });

  const [collateral, setCollateral] = useState<CollateralAsset[]>(() => {
    const cached = localStorage.getItem('rq_collateral');
    return cached ? JSON.parse(cached) : INITIAL_COLLATERAL;
  });

  const [requests, setRequests] = useState<FundingRequest[]>(() => {
    const cached = localStorage.getItem('rq_requests');
    return cached ? JSON.parse(cached) : INITIAL_REQUESTS;
  });

  const [liquidityPool, setLiquidityPool] = useState<LiquidityPoolStatus>(() => {
    const cached = localStorage.getItem('rq_liquidity_pool');
    return cached ? JSON.parse(cached) : INITIAL_LIQUIDITY_POOL;
  });

  const [ledgerEntries, setLedgerEntries] = useState<LedgerJournalEntry[]>(() => {
    const cached = localStorage.getItem('rq_ledger_entries');
    return cached ? JSON.parse(cached) : INITIAL_JOURNAL_ENTRIES;
  });

  const [telemetry, setTelemetry] = useState<EngineTelemetry>(INITIAL_TELEMETRY);
  const [makerCheckerItems, setMakerCheckerItems] = useState<MakerCheckerItem[]>(INITIAL_MAKER_CHECKER);

  // Modals
  const [inspectingRequest, setInspectingRequest] = useState<FundingRequest | null>(null);
  const [isNewRequestOpen, setIsNewRequestOpen] = useState<boolean>(false);
  const [isDocsOpen, setIsDocsOpen] = useState<boolean>(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState<boolean>(false);
  const [isLiveStreamActive, setIsLiveStreamActive] = useState<boolean>(true);

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem('rq_counterparties', JSON.stringify(counterparties));
    localStorage.setItem('rq_facilities', JSON.stringify(facilities));
    localStorage.setItem('rq_collateral', JSON.stringify(collateral));
    localStorage.setItem('rq_requests', JSON.stringify(requests));
    localStorage.setItem('rq_liquidity_pool', JSON.stringify(liquidityPool));
    localStorage.setItem('rq_ledger_entries', JSON.stringify(ledgerEntries));
  }, [counterparties, facilities, collateral, requests, liquidityPool, ledgerEntries]);

  // Subtle real-time event simulation ticker (adjusts events/sec and queue depth)
  useEffect(() => {
    if (!isLiveStreamActive || telemetry.isCircuitBreakerActive) return;

    const interval = setInterval(() => {
      setTelemetry((prev) => {
        const delta = (Math.random() - 0.48) * 12;
        const newRate = Number(Math.max(120, Math.min(480, prev.eventsPerSecond + delta)).toFixed(1));
        const newDepth = Math.max(1, Math.min(18, Math.round(prev.activeQueueDepth + (Math.random() > 0.6 ? 1 : -1))));
        return {
          ...prev,
          eventsPerSecond: newRate,
          activeQueueDepth: newDepth,
          decisionLatencyP50Ms: Number((2.1 + Math.random() * 0.4).toFixed(1)),
          decisionLatencyP95Ms: Number((4.6 + Math.random() * 0.8).toFixed(1))
        };
      });
    }, 2500);

    return () => clearInterval(interval);
  }, [isLiveStreamActive, telemetry.isCircuitBreakerActive]);

  // Keyboard Shortcuts Listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if typing inside an input or select
      if (['INPUT', 'SELECT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) {
        return;
      }

      if (e.key >= '1' && e.key <= '9') {
        const idx = parseInt(e.key, 10) - 1;
        if (SCREENS[idx]) setActiveScreen(SCREENS[idx].id);
      } else if (e.key === '0') {
        setActiveScreen('AUDIT');
      } else if (e.key === '?') {
        setIsShortcutsOpen((prev) => !prev);
      } else if (e.key === 'n' || e.key === 'N') {
        setIsNewRequestOpen(true);
      } else if (e.key === 'd' || e.key === 'D') {
        setIsDocsOpen(true);
      } else if (e.code === 'Space') {
        e.preventDefault();
        setIsLiveStreamActive((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Reset to pristine seed data
  const handleResetToSeed = useCallback(() => {
    localStorage.clear();
    setCounterparties(INITIAL_COUNTERPARTIES);
    setFacilities(INITIAL_FACILITIES);
    setCollateral(INITIAL_COLLATERAL);
    setRequests(INITIAL_REQUESTS);
    setLiquidityPool(INITIAL_LIQUIDITY_POOL);
    setLedgerEntries(INITIAL_JOURNAL_ENTRIES);
    setTelemetry(INITIAL_TELEMETRY);
    setMakerCheckerItems(INITIAL_MAKER_CHECKER);
  }, []);

  // Action: Accept Terms (Counterparty digital signature)
  const handleAcceptTerms = useCallback((requestId: string) => {
    const now = new Date().toISOString();
    setRequests((prev) =>
      prev.map((r) => {
        if (r.id !== requestId) return r;
        return {
          ...r,
          status: 'FUNDING_RESERVED',
          termsAcceptedAt: now,
          reservationExpiryAt: new Date(Date.now() + 60 * 60 * 1000).toISOString()
        };
      })
    );

    // Reserve liquidity
    const targetReq = requests.find((r) => r.id === requestId);
    if (targetReq) {
      const amount = targetReq.approvedAmount || targetReq.requestedAmount;
      setLiquidityPool((p) => ({
        ...p,
        reservedCash: p.reservedCash + amount,
        availableForAllocation: Math.max(0, p.uncommittedCash - p.reservedCash - amount - p.minimumLiquidityBuffer)
      }));

      // Update facility reserved
      setFacilities((facs) =>
        facs.map((f) => (f.id === targetReq.facilityId ? { ...f, currentReserved: f.currentReserved + amount } : f))
      );
    }
  }, [requests]);

  // Action: Disburse Loan (Atomic cash commitment & double-entry posting)
  const handleDisburseLoan = useCallback((requestId: string) => {
    const targetReq = requests.find((r) => r.id === requestId);
    if (!targetReq) return;

    const cp = counterparties.find((c) => c.id === targetReq.borrowerId);
    const principal = targetReq.approvedAmount || targetReq.requestedAmount;
    const fee = targetReq.pricingQuote?.facilityDrawdownFee || 0;
    const now = new Date().toISOString();

    // 1. Post Balanced Double-Entry Journal Entry
    const jrnEntry = makeDisbursementEntry({
      loanId: targetReq.id,
      counterpartyName: cp?.name || targetReq.borrowerId,
      principal,
      upfrontFee: fee
    });

    setLedgerEntries((prev) => [jrnEntry, ...prev]);

    // 2. Update Loan State
    const maturityTime = new Date(Date.now() + targetReq.tenorHours * 3600 * 1000).toISOString();
    setRequests((prev) =>
      prev.map((r) => {
        if (r.id !== requestId) return r;
        return {
          ...r,
          status: 'OUTSTANDING',
          disbursedAt: now,
          maturityAt: maturityTime,
          paymentReference: `WIRE-${Date.now().toString().slice(-8)}`
        };
      })
    );

    // 3. Update Liquidity Pool & Headrooms
    setLiquidityPool((p) => {
      const uncommitted = Math.max(0, p.uncommittedCash - principal);
      const reserved = Math.max(0, p.reservedCash - principal);
      return {
        ...p,
        uncommittedCash: uncommitted,
        reservedCash: reserved,
        disbursedPrincipal: p.disbursedPrincipal + principal,
        availableForAllocation: Math.max(0, uncommitted - p.minimumLiquidityBuffer)
      };
    });

    setFacilities((facs) =>
      facs.map((f) => {
        if (f.id !== targetReq.facilityId) return f;
        return {
          ...f,
          currentReserved: Math.max(0, f.currentReserved - principal),
          currentDrawn: f.currentDrawn + principal
        };
      })
    );
  }, [requests, counterparties]);

  // Action: Repay Loan (Settles principal & interest, releases collateral)
  const handleRepayLoan = useCallback((requestId: string) => {
    const targetReq = requests.find((r) => r.id === requestId);
    if (!targetReq) return;

    const cp = counterparties.find((c) => c.id === targetReq.borrowerId);
    const principal = targetReq.approvedAmount || targetReq.requestedAmount;
    const interest = targetReq.accruedInterest || (targetReq.pricingQuote?.estimatedInterestAmount || 3500);
    const now = new Date().toISOString();

    // 1. Post Balanced Double-Entry Repayment Journal Entry
    const repayEntry = makeRepaymentEntry({
      loanId: targetReq.id,
      counterpartyName: cp?.name || targetReq.borrowerId,
      principal,
      interest
    });

    setLedgerEntries((prev) => [repayEntry, ...prev]);

    // 2. Release Collateral allocations
    if (targetReq.collateralAllocated && targetReq.collateralAllocated.length > 0) {
      setCollateral((curCol) => releaseCollateralAllocations(curCol, targetReq.collateralAllocated!));
    }

    // 3. Update Loan State
    setRequests((prev) =>
      prev.map((r) => {
        if (r.id !== requestId) return r;
        return {
          ...r,
          status: 'REPAID',
          repaidAt: now,
          repaymentAmount: principal + interest
        };
      })
    );

    // 4. Update Liquidity Pool
    setLiquidityPool((p) => {
      const uncommitted = p.uncommittedCash + principal;
      return {
        ...p,
        uncommittedCash: uncommitted,
        disbursedPrincipal: Math.max(0, p.disbursedPrincipal - principal),
        availableForAllocation: Math.max(0, uncommitted - p.minimumLiquidityBuffer)
      };
    });

    setFacilities((facs) =>
      facs.map((f) => {
        if (f.id !== targetReq.facilityId) return f;
        return {
          ...f,
          currentDrawn: Math.max(0, f.currentDrawn - principal)
        };
      })
    );
  }, [requests, counterparties]);

  // Action: Maker-Checker Manual Approval
  const handleManualApprove = useCallback((requestId: string) => {
    setRequests((prev) =>
      prev.map((r) => {
        if (r.id !== requestId) return r;
        return {
          ...r,
          decisionStatus: 'APPROVED',
          status: 'QUOTED',
          approvedAmount: r.requestedAmount,
          decisionReasons: [
            ...r.decisionReasons,
            'Authorized by Credit Analyst & Senior Risk Officer via Maker-Checker override.'
          ]
        };
      })
    );
  }, []);

  // Action: Submit New Request (Client API or manual trigger)
  const handleSubmitRequest = useCallback((params: {
    borrowerId: string;
    facilityId: string;
    productType: ProductType;
    currency: Currency;
    requestedAmount: number;
    tenorHours: number;
    idempotencyKey?: string;
  }) => {
    const cp = counterparties.find((c) => c.id === params.borrowerId)!;
    const fac = facilities.find((f) => f.id === params.facilityId)!;
    const idempotencyKey = params.idempotencyKey || `IDEMP-${cp.name.substring(0, 4).toUpperCase()}-${Date.now()}`;
    const id = `REQ-${Date.now().toString().slice(-5)}`;

    const newReq: FundingRequest = {
      id,
      idempotencyKey,
      borrowerId: params.borrowerId,
      facilityId: params.facilityId,
      productType: params.productType,
      currency: params.currency,
      requestedAmount: params.requestedAmount,
      tenorHours: params.tenorHours,
      submittedAt: new Date().toISOString(),
      status: 'REQUESTED',
      decisionStatus: 'QUEUED',
      decisionReasons: [],
      policyVersion: 'RQ-POL-2026.4.1',
      accruedInterest: 0
    };

    // Run limits & policy engine
    const evalResult = evaluateFundingRequest({
      request: newReq,
      existingRequests: requests,
      facility: fac,
      counterparty: cp,
      allCounterparties: counterparties,
      allFacilities: facilities,
      collateralAssets: collateral,
      liquidityPool,
      isCircuitBreakerActive: telemetry.isCircuitBreakerActive,
      pausedProducts: telemetry.pausedProducts
    });

    newReq.decisionStatus = evalResult.decision;
    newReq.approvedAmount = evalResult.approvedAmount;
    newReq.decisionReasons = evalResult.reasons;

    if (evalResult.decision === 'APPROVED' || evalResult.decision === 'PARTIALLY_APPROVED') {
      newReq.pricingQuote = calculateQuote({
        counterparty: cp,
        productType: newReq.productType,
        currency: newReq.currency,
        principal: newReq.approvedAmount || newReq.requestedAmount,
        tenorHours: newReq.tenorHours,
        poolUtilizationPct:
          (liquidityPool.disbursedPrincipal + liquidityPool.reservedCash) / liquidityPool.totalCapacity
      });
      newReq.status = 'QUOTED';
    } else {
      newReq.status = evalResult.decision;
    }

    setRequests((prev) => [newReq, ...prev]);
  }, [counterparties, facilities, requests, collateral, liquidityPool, telemetry]);

  // Action: Toggle Circuit Breaker
  const handleToggleCircuitBreaker = useCallback(() => {
    setTelemetry((prev) => ({
      ...prev,
      isCircuitBreakerActive: !prev.isCircuitBreakerActive,
      circuitBreakerReason: !prev.isCircuitBreakerActive
        ? 'MANUAL_EMERGENCY_STOP: Authorized by Senior Risk Officer.'
        : undefined
    }));
  }, []);

  // Action: Toggle Individual Product Pause
  const handleToggleProductPause = useCallback((product: ProductType) => {
    setTelemetry((prev) => {
      const isPaused = prev.pausedProducts.includes(product);
      return {
        ...prev,
        pausedProducts: isPaused
          ? prev.pausedProducts.filter((p) => p !== product)
          : [...prev.pausedProducts, product]
      };
    });
  }, []);

  // Action: Apply Scenario Result
  const handleApplyScenarioResult = useCallback((result: ScenarioRunResult) => {
    setRequests(result.updatedRequests);
    setFacilities(result.updatedFacilities);
    setCollateral(result.updatedCollateral);
    setLiquidityPool(result.updatedLiquidityPool);
    setLedgerEntries(result.updatedLedgerEntries);
    if (result.circuitBreakerActive) {
      setTelemetry((prev) => ({
        ...prev,
        isCircuitBreakerActive: true,
        circuitBreakerReason: result.circuitBreakerReason
      }));
    }
  }, []);

  // Action: Apply Allocation Commitments
  const handleApplyAllocation = useCallback((result: AllocationRunResult) => {
    const allocatedMap = new Map(
      result.allocatedRequests
        .filter((i) => i.status === 'ALLOCATED' || i.status === 'PARTIALLY_ALLOCATED')
        .map((i) => [i.requestId, i.allocatedAmount])
    );

    setRequests((prev) =>
      prev.map((r) => {
        const amt = allocatedMap.get(r.id);
        if (amt === undefined) return r;
        return {
          ...r,
          status: 'FUNDING_RESERVED',
          approvedAmount: amt,
          allocatedByStrategy: result.strategy,
          allocationReason: `Reserved $${amt.toLocaleString()} under ${result.strategy}`
        };
      })
    );

    setLiquidityPool((p) => {
      const newlyReserved = result.totalAllocated;
      return {
        ...p,
        reservedCash: p.reservedCash + newlyReserved,
        availableForAllocation: Math.max(0, p.uncommittedCash - p.reservedCash - newlyReserved - p.minimumLiquidityBuffer)
      };
    });
  }, []);

  // Action: Maker-Checker Approve Item
  const handleApproveMakerChecker = useCallback((itemId: string) => {
    setMakerCheckerItems((prev) =>
      prev.map((i) =>
        i.id === itemId
          ? {
              ...i,
              status: 'APPROVED',
              approvedBy: `${currentRole.replace(/_/g, ' ')}`,
              approvedAt: new Date().toISOString()
            }
          : i
      )
    );
  }, [currentRole]);

  // Action: Maker-Checker Reject Item
  const handleRejectMakerChecker = useCallback((itemId: string) => {
    setMakerCheckerItems((prev) =>
      prev.map((i) =>
        i.id === itemId
          ? {
              ...i,
              status: 'REJECTED',
              approvedBy: `${currentRole.replace(/_/g, ' ')}`,
              approvedAt: new Date().toISOString()
            }
          : i
      )
    );
  }, [currentRole]);

  return (
    <div className="min-h-screen bg-[#070a0f] text-[#f2f4f8] flex flex-col font-sans select-none antialiased">
      {/* Institutional Top Bar (Strict 3-Zone Contract) */}
      <Header
        activeScreen={activeScreen}
        onNavigate={setActiveScreen}
        onOpenNewRequest={() => setIsNewRequestOpen(true)}
        onOpenDocs={() => setIsDocsOpen(true)}
        currentRole={currentRole}
        onRoleChange={setCurrentRole}
        isCircuitBreakerActive={telemetry.isCircuitBreakerActive}
        onToggleCircuitBreaker={handleToggleCircuitBreaker}
      />

      {/* Sub-Header Workspace Mode Toolbar */}
      <div className="px-6 py-2 bg-[#090d14] border-b border-white/5 flex flex-wrap items-center justify-between gap-4 text-xs">
        {/* Screen Switcher Buttons */}
        <div className="flex items-center gap-1 overflow-x-auto py-0.5">
          {SCREENS.map((s) => (
            <button
              key={s.id}
              onClick={() => setActiveScreen(s.id)}
              className={`px-3 py-1 rounded text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeScreen === s.id
                  ? 'bg-white/10 text-white font-semibold border border-white/15'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>{s.label}</span>
              <span className="ml-1 text-[10px] text-white/30 font-mono">[{s.shortcut}]</span>
            </button>
          ))}
        </div>

        {/* Quick Utility Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setIsDocsOpen(true)}
            className="flex items-center gap-1 px-2.5 py-1 text-white/70 hover:text-white hover:bg-white/5 rounded border border-white/10 text-[11px] cursor-pointer"
            title="Inspect Python/FastAPI, PostgreSQL DDL and Docker Compose"
          >
            <Server className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Architecture & DDL</span>
          </button>

          <button
            onClick={() => setIsShortcutsOpen(true)}
            className="p-1.5 text-white/60 hover:text-white hover:bg-white/5 rounded border border-white/10 cursor-pointer"
            title="Keyboard Shortcuts (?)"
          >
            <Keyboard className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handleResetToSeed}
            className="flex items-center gap-1 px-2 py-1 text-white/50 hover:text-white text-[11px] rounded hover:bg-white/5 cursor-pointer"
            title="Reset to clean baseline seed data"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Main Viewport Content Area */}
      <main className="flex-1 p-6 max-w-[1720px] w-full mx-auto">
        {activeScreen === 'COMMAND_CENTRE' && (
          <CommandCentre
            liquidityPool={liquidityPool}
            telemetry={telemetry}
            requests={requests}
            facilities={facilities}
            counterparties={counterparties}
            isCircuitBreakerActive={telemetry.isCircuitBreakerActive}
            onToggleCircuitBreaker={handleToggleCircuitBreaker}
            onToggleProductPause={handleToggleProductPause}
            onSelectRequest={setInspectingRequest}
            onNavigate={setActiveScreen}
          />
        )}

        {activeScreen === 'LENDING_QUEUE' && (
          <LendingQueue
            requests={requests}
            counterparties={counterparties}
            facilities={facilities}
            onSelectRequest={setInspectingRequest}
            onAcceptTerms={handleAcceptTerms}
            onDisburseLoan={handleDisburseLoan}
            onRepayLoan={handleRepayLoan}
            onManualApprove={handleManualApprove}
          />
        )}

        {activeScreen === 'FACILITIES' && (
          <FacilitiesView counterparties={counterparties} facilities={facilities} />
        )}

        {activeScreen === 'FUNDING' && (
          <FundingAllocationView
            liquidityPool={liquidityPool}
            requests={requests}
            counterparties={counterparties}
            facilities={facilities}
            onApplyAllocation={handleApplyAllocation}
          />
        )}

        {activeScreen === 'PRICING' && (
          <PricingEngineView counterparties={counterparties} />
        )}

        {activeScreen === 'COLLATERAL' && (
          <CollateralView collateral={collateral} counterparties={counterparties} />
        )}

        {activeScreen === 'RISK' && (
          <RiskAnalyticsView
            counterparties={counterparties}
            facilities={facilities}
            collateral={collateral}
            requests={requests}
            liquidityPool={liquidityPool}
          />
        )}

        {activeScreen === 'LEDGER' && (
          <LedgerView entries={ledgerEntries} />
        )}

        {activeScreen === 'SIMULATION' && (
          <SimulationLabView
            requests={requests}
            facilities={facilities}
            counterparties={counterparties}
            collateral={collateral}
            liquidityPool={liquidityPool}
            ledgerEntries={ledgerEntries}
            onApplyScenarioResult={handleApplyScenarioResult}
            onResetToSeed={handleResetToSeed}
          />
        )}

        {activeScreen === 'AUDIT' && (
          <AuditControlsView
            currentRole={currentRole}
            isCircuitBreakerActive={telemetry.isCircuitBreakerActive}
            onToggleCircuitBreaker={handleToggleCircuitBreaker}
            pausedProducts={telemetry.pausedProducts}
            onToggleProductPause={handleToggleProductPause}
            makerCheckerItems={makerCheckerItems}
            onApproveMakerChecker={handleApproveMakerChecker}
            onRejectMakerChecker={handleRejectMakerChecker}
          />
        )}
      </main>

      {/* Modals */}
      <RequestDetailModal
        request={inspectingRequest}
        counterparty={counterparties.find((c) => c.id === inspectingRequest?.borrowerId)}
        facility={facilities.find((f) => f.id === inspectingRequest?.facilityId)}
        onClose={() => setInspectingRequest(null)}
        onAcceptTerms={handleAcceptTerms}
        onDisburseLoan={handleDisburseLoan}
        onRepayLoan={handleRepayLoan}
      />

      <NewRequestModal
        isOpen={isNewRequestOpen}
        onClose={() => setIsNewRequestOpen(false)}
        counterparties={counterparties}
        facilities={facilities}
        onSubmitRequest={handleSubmitRequest}
      />

      <ArchitectureDocsModal
        isOpen={isDocsOpen}
        onClose={() => setIsDocsOpen(false)}
      />

      {/* Keyboard Shortcuts Modal */}
      {isShortcutsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-[#0b0f17] border border-white/20 rounded-xl max-w-md w-full shadow-2xl overflow-hidden text-xs text-white p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <span className="font-bold text-sm text-white flex items-center gap-2">
                <Keyboard className="w-4 h-4 text-[#d4af37]" />
                Terminal Keyboard Shortcuts
              </span>
              <button
                onClick={() => setIsShortcutsOpen(false)}
                className="text-white/60 hover:text-white text-xs cursor-pointer"
              >
                ✕
              </button>
            </div>
            <div className="space-y-2 font-mono text-[11px]">
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-white/60">Switch Screens</span>
                <span className="text-[#d4af37] font-bold">Key 1 – 9, 0</span>
              </div>
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-white/60">New Drawdown Request</span>
                <span className="text-[#d4af37] font-bold">Key N</span>
              </div>
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-white/60">Architecture & DDL Modal</span>
                <span className="text-[#d4af37] font-bold">Key D</span>
              </div>
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-white/60">Pause/Resume Event Stream</span>
                <span className="text-[#d4af37] font-bold">Spacebar</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-white/60">Toggle Shortcuts Cheatsheet</span>
                <span className="text-[#d4af37] font-bold">Key ?</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
