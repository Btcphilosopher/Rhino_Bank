/**
 * Realistic Institutional Seed Data for RhinoQuant Liquidity Engine
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 */

import {
  Counterparty,
  Facility,
  CollateralAsset,
  FundingRequest,
  LedgerJournalEntry,
  LiquidityPoolStatus,
  EngineTelemetry,
  MakerCheckerItem
} from '../types';

export const INITIAL_COUNTERPARTIES: Counterparty[] = [
  {
    id: 'CP-APEX-01',
    name: 'Apex Clearing AG',
    legalEntity: 'Apex European Clearing & Settlement AG',
    lei: '5493006MHB84DD0Z4519',
    corporateGroupId: 'GRP-APEX',
    corporateGroupName: 'Apex Financial Holdings Corp',
    creditRating: 'AA-',
    sector: 'CLEARING_BROKER',
    country: 'DEU',
    isInternal: false,
    minLiquidityRatioCovenant: 1.25,
    maxLeverageCovenant: 3.5,
    currentLiquidityRatio: 1.42,
    currentLeverage: 2.8,
    covenantBreached: false,
    documentationStatus: 'EXECUTED_CURRENT',
    paymentInstructions: {
      system: 'TARGET2',
      accountIdentifier: 'DEUTDEDBFXX / 8801948201',
      cutoffTimeUtc: '17:00'
    },
    reviewDate: '2027-04-15'
  },
  {
    id: 'CP-MERID-02',
    name: 'Meridian Global Trust',
    legalEntity: 'Meridian Institutional Trust & Custody NA',
    lei: '213800K1DY7U4W2X8G31',
    corporateGroupId: 'GRP-MERIDIAN',
    corporateGroupName: 'Meridian Capital Partners',
    creditRating: 'A+',
    sector: 'ASSET_MANAGER',
    country: 'USA',
    isInternal: false,
    minLiquidityRatioCovenant: 1.30,
    maxLeverageCovenant: 2.8,
    currentLiquidityRatio: 1.65,
    currentLeverage: 1.9,
    covenantBreached: false,
    documentationStatus: 'EXECUTED_CURRENT',
    paymentInstructions: {
      system: 'FEDWIRE',
      accountIdentifier: '021000021 / 44928100234',
      cutoffTimeUtc: '21:30'
    },
    reviewDate: '2027-02-28'
  },
  {
    id: 'CP-HELIOS-03',
    name: 'Helios Commodities Ltd',
    legalEntity: 'Helios International Commodities & Energy UK Ltd',
    lei: '98450098FA32C6E11082',
    corporateGroupId: 'GRP-HELIOS',
    corporateGroupName: 'Helios Energy & Natural Resources Group',
    creditRating: 'A',
    sector: 'COMMODITIES_TRADER',
    country: 'GBR',
    isInternal: false,
    minLiquidityRatioCovenant: 1.15,
    maxLeverageCovenant: 4.0,
    currentLiquidityRatio: 1.22,
    currentLeverage: 3.4,
    covenantBreached: false,
    documentationStatus: 'EXECUTED_CURRENT',
    paymentInstructions: {
      system: 'CHAPS',
      accountIdentifier: 'BARCGB22 / 99201482',
      cutoffTimeUtc: '16:00'
    },
    reviewDate: '2026-12-31'
  },
  {
    id: 'CP-VALO-04',
    name: 'Valo Arbitrage S.A.',
    legalEntity: 'Valo Quantitative Arbitrage Fund SICAV-RAIF',
    lei: '529900T948JDLWPQ2811',
    corporateGroupId: 'GRP-VALO',
    corporateGroupName: 'Valo Investment Group Luxembourg',
    creditRating: 'BBB+',
    sector: 'ARBITRAGE_FUND',
    country: 'CHE',
    isInternal: false,
    minLiquidityRatioCovenant: 1.35,
    maxLeverageCovenant: 4.5,
    currentLiquidityRatio: 1.38,
    currentLeverage: 4.1,
    covenantBreached: false,
    documentationStatus: 'UNDER_ANNUAL_REVIEW',
    paymentInstructions: {
      system: 'FEDWIRE',
      accountIdentifier: '026009593 / 771029341',
      cutoffTimeUtc: '21:30'
    },
    reviewDate: '2026-11-30'
  },
  {
    id: 'CP-SOV-05',
    name: 'Sovereign Reserve Facility',
    legalEntity: 'European Central Reserve & Repo Counterparty Agency',
    lei: '549300SUPRA991048201',
    corporateGroupId: 'GRP-SUPRA',
    corporateGroupName: 'Supranational Reserve Group',
    creditRating: 'AAA',
    sector: 'CENTRAL_BANK',
    country: 'DEU',
    isInternal: false,
    minLiquidityRatioCovenant: 2.0,
    maxLeverageCovenant: 1.5,
    currentLiquidityRatio: 3.8,
    currentLeverage: 0.9,
    covenantBreached: false,
    documentationStatus: 'EXECUTED_CURRENT',
    paymentInstructions: {
      system: 'TARGET2',
      accountIdentifier: 'BKAUDEFF / 001099238',
      cutoffTimeUtc: '17:00'
    },
    reviewDate: '2028-01-01'
  },
  {
    id: 'CP-INTERNAL-06',
    name: 'Rhino Treasury Trading Desk',
    legalEntity: 'RhinoBank Group Treasury & ALM Desk',
    lei: '549300RHINO908123049',
    corporateGroupId: 'GRP-RHINO',
    corporateGroupName: 'RhinoBank AG Group',
    creditRating: 'AA',
    sector: 'INTERNAL_TREASURY',
    country: 'USA',
    isInternal: true,
    minLiquidityRatioCovenant: 1.5,
    maxLeverageCovenant: 3.0,
    currentLiquidityRatio: 2.1,
    currentLeverage: 1.8,
    covenantBreached: false,
    documentationStatus: 'EXECUTED_CURRENT',
    paymentInstructions: {
      system: 'INTERNAL_BOOK',
      accountIdentifier: 'INTERNAL-LEDGER-9901-TR',
      cutoffTimeUtc: '23:59'
    },
    reviewDate: '2027-12-31'
  }
];

export const INITIAL_FACILITIES: Facility[] = [
  {
    id: 'FAC-APEX-ID01',
    facilityCode: 'FAC-APEX-INTRADAY',
    borrowerId: 'CP-APEX-01',
    productType: 'INTRADAY_ADVANCE',
    currency: 'EUR',
    approvedLimit: 75_000_000,
    currentDrawn: 20_000_000,
    currentReserved: 10_000_000,
    permittedTenorsHours: [2, 4, 8],
    referenceBenchmark: 'ESTR',
    baseCreditSpreadBps: 35,
    requiresCollateral: true,
    minCollateralCoverageRatio: 1.05,
    expiryDate: '2027-03-31',
    isActive: true
  },
  {
    id: 'FAC-MERID-ON02',
    facilityCode: 'FAC-MERID-OVERNIGHT',
    borrowerId: 'CP-MERID-02',
    productType: 'OVERNIGHT_LOAN',
    currency: 'USD',
    approvedLimit: 120_000_000,
    currentDrawn: 45_000_000,
    currentReserved: 0,
    permittedTenorsHours: [24],
    referenceBenchmark: 'SOFR',
    baseCreditSpreadBps: 45,
    requiresCollateral: true,
    minCollateralCoverageRatio: 1.10,
    expiryDate: '2027-06-30',
    isActive: true
  },
  {
    id: 'FAC-HELIOS-WC03',
    facilityCode: 'FAC-HELIOS-SEC-WC',
    borrowerId: 'CP-HELIOS-03',
    productType: 'SECURED_WORKING_CAPITAL',
    currency: 'GBP',
    approvedLimit: 50_000_000,
    currentDrawn: 15_000_000,
    currentReserved: 5_000_000,
    permittedTenorsHours: [24, 168, 336], // up to 14 days
    referenceBenchmark: 'SONIA',
    baseCreditSpreadBps: 85,
    requiresCollateral: true,
    minCollateralCoverageRatio: 1.20,
    expiryDate: '2026-12-31',
    isActive: true
  },
  {
    id: 'FAC-VALO-REV04',
    facilityCode: 'FAC-VALO-REVOLVER',
    borrowerId: 'CP-VALO-04',
    productType: 'SHORT_TERM_REVOLVER',
    currency: 'USD',
    approvedLimit: 40_000_000,
    currentDrawn: 28_000_000,
    currentReserved: 0,
    permittedTenorsHours: [24, 72, 168],
    referenceBenchmark: 'SOFR',
    baseCreditSpreadBps: 115,
    requiresCollateral: true,
    minCollateralCoverageRatio: 1.25,
    expiryDate: '2026-11-30',
    isActive: true
  },
  {
    id: 'FAC-SOV-IB05',
    facilityCode: 'FAC-SOV-INTERBANK',
    borrowerId: 'CP-SOV-05',
    productType: 'INTERBANK_LENDING',
    currency: 'EUR',
    approvedLimit: 200_000_000,
    currentDrawn: 50_000_000,
    currentReserved: 0,
    permittedTenorsHours: [24, 48, 168],
    referenceBenchmark: 'ESTR',
    baseCreditSpreadBps: 18,
    requiresCollateral: true,
    minCollateralCoverageRatio: 1.02,
    expiryDate: '2028-01-01',
    isActive: true
  },
  {
    id: 'FAC-INT-ALM06',
    facilityCode: 'FAC-INTERNAL-TREASURY',
    borrowerId: 'CP-INTERNAL-06',
    productType: 'INTERNAL_TREASURY_ALLOCATION',
    currency: 'USD',
    approvedLimit: 150_000_000,
    currentDrawn: 30_000_000,
    currentReserved: 0,
    permittedTenorsHours: [4, 8, 24, 168],
    referenceBenchmark: 'INTERNAL_TRANSFER_RATE',
    baseCreditSpreadBps: 0,
    requiresCollateral: false,
    minCollateralCoverageRatio: 0,
    expiryDate: '2027-12-31',
    isActive: true
  }
];

export const INITIAL_COLLATERAL: CollateralAsset[] = [
  {
    id: 'COL-UST-01',
    counterpartyId: 'CP-MERID-02',
    assetClass: 'US_TREASURY',
    identifier: 'US91282CDJ71',
    description: 'US Treasury Bill 4.95% due 2027',
    faceValue: 80_000_000,
    marketValue: 79_400_000,
    currency: 'USD',
    valuationSource: 'Bloomberg BVAL Mid 08:30 EST',
    valuationTimestamp: '2026-11-10T06:15:00Z',
    haircutPercent: 2.0,
    priorEncumbranceAmount: 0,
    currentlyAllocatedAmount: 49_500_000,
    eligibleBorrowingBase: 28_312_000,
    custodian: 'Euroclear Triparty Bank',
    controlStatus: 'TRI_PARTY_SEGREGATED'
  },
  {
    id: 'COL-BUND-02',
    counterpartyId: 'CP-APEX-01',
    assetClass: 'GERMAN_BUND',
    identifier: 'DE0001102580',
    description: 'Federal Republic of Germany Bund 2.60% due 2033',
    faceValue: 50_000_000,
    marketValue: 51_200_000,
    currency: 'EUR',
    valuationSource: 'Markit EOD / ECB Fixing',
    valuationTimestamp: '2026-11-10T06:10:00Z',
    haircutPercent: 2.5,
    priorEncumbranceAmount: 5_000_000,
    currentlyAllocatedAmount: 31_500_000,
    eligibleBorrowingBase: 13_420_000,
    custodian: 'Clearstream Banking Frankfurt',
    controlStatus: 'TRI_PARTY_SEGREGATED'
  },
  {
    id: 'COL-GILT-03',
    counterpartyId: 'CP-HELIOS-03',
    assetClass: 'UK_GILT',
    identifier: 'GB00B16NNR78',
    description: 'UK Treasury Gilt 4.25% due 2029',
    faceValue: 35_000_000,
    marketValue: 34_800_000,
    currency: 'GBP',
    valuationSource: 'Tradeweb ICMA 08:00 GMT',
    valuationTimestamp: '2026-11-10T06:05:00Z',
    haircutPercent: 3.5,
    priorEncumbranceAmount: 0,
    currentlyAllocatedAmount: 24_000_000,
    eligibleBorrowingBase: 9_582_000,
    custodian: 'CREST Depository UK',
    controlStatus: 'DIRECT_PLEDGE'
  },
  {
    id: 'COL-CP-04',
    counterpartyId: 'CP-VALO-04',
    assetClass: 'AAA_COMMERCIAL_PAPER',
    identifier: 'US037833DW21',
    description: 'Apple Inc. A-1+/P-1 Commercial Paper 30D',
    faceValue: 30_000_000,
    marketValue: 29_750_000,
    currency: 'USD',
    valuationSource: 'DTC Matrix Pricing',
    valuationTimestamp: '2026-11-10T05:55:00Z',
    haircutPercent: 12.0,
    priorEncumbranceAmount: 0,
    currentlyAllocatedAmount: 26_180_000,
    eligibleBorrowingBase: 0,
    custodian: 'BNY Mellon Global Custody',
    controlStatus: 'ACCOUNT_CONTROL_AGREEMENT'
  },
  {
    id: 'COL-REC-05',
    counterpartyId: 'CP-HELIOS-03',
    assetClass: 'TRADE_RECEIVABLES',
    identifier: 'REC-POOL-HELIOS-Q4',
    description: 'Insured Energy Supply Receivables Portfolio (Investment Grade Counterparties)',
    faceValue: 25_000_000,
    marketValue: 24_200_000,
    currency: 'GBP',
    valuationSource: 'Euler Hermes Risk Assessed Net Face',
    valuationTimestamp: '2026-11-10T04:00:00Z',
    haircutPercent: 25.0,
    priorEncumbranceAmount: 2_000_000,
    currentlyAllocatedAmount: 0,
    eligibleBorrowingBase: 16_150_000,
    custodian: 'RhinoBank Security Trustee Ltd',
    controlStatus: 'DIRECT_PLEDGE'
  }
];

export const INITIAL_LIQUIDITY_POOL: LiquidityPoolStatus = {
  totalCapacity: 500_000_000,
  uncommittedCash: 312_000_000,
  reservedCash: 15_000_000,
  disbursedPrincipal: 173_000_000,
  minimumLiquidityBuffer: 60_000_000, // Regulatory LCR / buffer threshold
  availableForAllocation: 252_000_000, // uncommitted - minimum buffer
  currency: 'USD',
  lastUpdated: '2026-11-10T06:35:00Z'
};

export const INITIAL_TELEMETRY: EngineTelemetry = {
  eventsPerSecond: 284.6,
  activeQueueDepth: 4,
  decisionLatencyP50Ms: 2.1,
  decisionLatencyP95Ms: 4.8,
  decisionLatencyP99Ms: 8.4,
  dbContentionLockCount: 0,
  reservationFailureRatePct: 0.04,
  paymentAdapterLatencyMs: 142.0, // Simulated Fedwire / Target2 ACK
  reconciliationLagSec: 0.45,
  isCircuitBreakerActive: false,
  pausedProducts: []
};

export const INITIAL_REQUESTS: FundingRequest[] = [
  {
    id: 'REQ-2026-10492',
    idempotencyKey: 'IDEMP-APEX-EUR-20261110-001',
    borrowerId: 'CP-APEX-01',
    facilityId: 'FAC-APEX-ID01',
    productType: 'INTRADAY_ADVANCE',
    currency: 'EUR',
    requestedAmount: 15_000_000,
    approvedAmount: 15_000_000,
    tenorHours: 4,
    submittedAt: '2026-11-10T06:30:12Z',
    status: 'FUNDING_RESERVED',
    decisionStatus: 'APPROVED',
    decisionReasons: [
      'Facility capacity verified: €45.0M headroom remaining',
      'Eligible collateral borrowing base coverage: 118% (exceeds required 105%)',
      'Target2 clearing window open until 17:00 UTC',
      'Economic group limit within approved envelope'
    ],
    policyVersion: 'RQ-POL-2026.4.1',
    pricingQuote: {
      referenceFundingRate: 0.0365,
      referenceSource: 'ECB €STR Fixing 07:00 CET',
      referenceAgeMinutes: 30,
      tenorAdjustmentBps: -8,
      creditSpreadBps: 35,
      liquidityAdjustmentBps: 6,
      capitalCostAllocationBps: 12,
      operatingCostAllocationBps: 4,
      targetMarginBps: 15,
      totalQuotedAnnualizedRate: 0.0424,
      dayCountConvention: 'ACT/360',
      tenorHours: 4,
      estimatedInterestAmount: 706.67,
      facilityDrawdownFee: 750.00,
      effectiveCostRateAnnualized: 0.0448,
      quoteExpiryTimestamp: '2026-11-10T07:00:12Z',
      policyVersion: 'RQ-POL-2026.4.1'
    },
    termsAcceptedAt: '2026-11-10T06:31:00Z',
    reservationExpiryAt: '2026-11-10T07:01:00Z',
    accruedInterest: 0,
    allocatedByStrategy: 'CONSTRAINED_OPTIMIZATION',
    allocationReason: 'Optimal net contribution under EUR buffer constraint'
  },
  {
    id: 'REQ-2026-10493',
    idempotencyKey: 'IDEMP-MERID-USD-20261110-002',
    borrowerId: 'CP-MERID-02',
    facilityId: 'FAC-MERID-ON02',
    productType: 'OVERNIGHT_LOAN',
    currency: 'USD',
    requestedAmount: 25_000_000,
    approvedAmount: 25_000_000,
    tenorHours: 24,
    submittedAt: '2026-11-10T06:32:45Z',
    status: 'OUTSTANDING',
    decisionStatus: 'APPROVED',
    decisionReasons: [
      'Contractual facility capacity: $75.0M unutilized',
      'US Treasury collateral pledged via Euroclear Triparty',
      'Covenant compliance: Liquidity ratio 1.65x vs 1.30x min covenant'
    ],
    policyVersion: 'RQ-POL-2026.4.1',
    pricingQuote: {
      referenceFundingRate: 0.0482,
      referenceSource: 'NY Fed SOFR 08:00 EST',
      referenceAgeMinutes: 45,
      tenorAdjustmentBps: 0,
      creditSpreadBps: 45,
      liquidityAdjustmentBps: 10,
      capitalCostAllocationBps: 14,
      operatingCostAllocationBps: 5,
      targetMarginBps: 20,
      totalQuotedAnnualizedRate: 0.0576,
      dayCountConvention: 'ACT/360',
      tenorHours: 24,
      estimatedInterestAmount: 4000.00,
      facilityDrawdownFee: 1250.00,
      effectiveCostRateAnnualized: 0.0594,
      quoteExpiryTimestamp: '2026-11-10T07:02:45Z',
      policyVersion: 'RQ-POL-2026.4.1'
    },
    termsAcceptedAt: '2026-11-10T06:33:05Z',
    paymentSubmittedAt: '2026-11-10T06:33:10Z',
    paymentReference: 'FEDWIRE-20261110-09841289',
    disbursedAt: '2026-11-10T06:33:15Z',
    maturityAt: '2026-11-11T06:33:15Z',
    accruedInterest: 4000.00,
    allocatedByStrategy: 'PRIORITY_WEIGHTED'
  },
  {
    id: 'REQ-2026-10494',
    idempotencyKey: 'IDEMP-VALO-USD-20261110-003',
    borrowerId: 'CP-VALO-04',
    facilityId: 'FAC-VALO-REV04',
    productType: 'SHORT_TERM_REVOLVER',
    currency: 'USD',
    requestedAmount: 18_000_000,
    tenorHours: 72,
    submittedAt: '2026-11-10T06:34:20Z',
    status: 'QUEUED',
    decisionStatus: 'QUEUED',
    decisionReasons: [
      'Facility capacity limit: Approved $40M, Current Drawn $28M -> Only $12M headroom available',
      'Collateral borrowing base exhausted for CP-VALO-04',
      'Referred to credit analyst for haircut or limit review'
    ],
    policyVersion: 'RQ-POL-2026.4.1',
    accruedInterest: 0
  },
  {
    id: 'REQ-2026-10495',
    idempotencyKey: 'IDEMP-INTERNAL-USD-20261110-004',
    borrowerId: 'CP-INTERNAL-06',
    facilityId: 'FAC-INT-ALM06',
    productType: 'INTERNAL_TREASURY_ALLOCATION',
    currency: 'USD',
    requestedAmount: 30_000_000,
    approvedAmount: 30_000_000,
    tenorHours: 8,
    submittedAt: '2026-11-10T06:35:00Z',
    status: 'QUOTED',
    decisionStatus: 'APPROVED',
    decisionReasons: [
      'Internal treasury transfer: distinct from external lending',
      'No third-party credit risk spread applied',
      'Internal book settlement enabled'
    ],
    policyVersion: 'RQ-POL-2026.4.1',
    pricingQuote: {
      referenceFundingRate: 0.0470,
      referenceSource: 'RhinoBank Internal Transfer Curve',
      referenceAgeMinutes: 10,
      tenorAdjustmentBps: -4,
      creditSpreadBps: 0,
      liquidityAdjustmentBps: 4,
      capitalCostAllocationBps: 0,
      operatingCostAllocationBps: 2,
      targetMarginBps: 0,
      totalQuotedAnnualizedRate: 0.0472,
      dayCountConvention: 'ACT/360',
      tenorHours: 8,
      estimatedInterestAmount: 1573.33,
      facilityDrawdownFee: 0,
      effectiveCostRateAnnualized: 0.0472,
      quoteExpiryTimestamp: '2026-11-10T07:35:00Z',
      policyVersion: 'RQ-POL-2026.4.1'
    },
    accruedInterest: 0,
    allocatedByStrategy: 'FIFO_BASELINE'
  }
];

export const INITIAL_JOURNAL_ENTRIES: LedgerJournalEntry[] = [
  {
    id: 'JRN-2026-0001',
    timestamp: '2026-11-10T06:00:00Z',
    referenceId: 'CAP-SEED-INITIAL',
    eventType: 'CAPITAL_ALLOCATION',
    narrative: 'Initial central bank nostro funding and equity capital allocation',
    lines: [
      { accountNumber: '1010', accountName: 'Nostro / Central Bank Reserve Cash', debit: 500_000_000, credit: 0 },
      { accountNumber: '3000', accountName: 'Capital & Retained Reserves', debit: 0, credit: 500_000_000 }
    ],
    isBalanced: true,
    checksum: 'SHA256:d8a9e01f5c3a28b02931818c7e990182'
  },
  {
    id: 'JRN-2026-0002',
    timestamp: '2026-11-10T06:15:00Z',
    referenceId: 'LOAN-MERID-SEED',
    eventType: 'LOAN_DISBURSEMENT',
    narrative: 'Disbursement of $45M Overnight loan to Meridian Global Trust via Fedwire',
    lines: [
      { accountNumber: '1200', accountName: 'Loans Outstanding - Institutional Principal', debit: 45_000_000, credit: 0 },
      { accountNumber: '1010', accountName: 'Nostro / Central Bank Reserve Cash', debit: 0, credit: 45_000_000 }
    ],
    isBalanced: true,
    checksum: 'SHA256:7b8192a01948cb1209e847123aa1289c'
  },
  {
    id: 'JRN-2026-0003',
    timestamp: '2026-11-10T06:20:00Z',
    referenceId: 'LOAN-APEX-SEED',
    eventType: 'LOAN_DISBURSEMENT',
    narrative: 'Disbursement of €20M Intraday advance to Apex Clearing AG via Target2 (USD equivalent $21.8M)',
    lines: [
      { accountNumber: '1200', accountName: 'Loans Outstanding - Institutional Principal', debit: 21_800_000, credit: 0 },
      { accountNumber: '1010', accountName: 'Nostro / Central Bank Reserve Cash', debit: 0, credit: 21_800_000 }
    ],
    isBalanced: true,
    checksum: 'SHA256:39ac2019b884d90182ecab0918482cfa'
  },
  {
    id: 'JRN-2026-0004',
    timestamp: '2026-11-10T06:33:15Z',
    referenceId: 'REQ-2026-10493',
    eventType: 'LOAN_DISBURSEMENT',
    narrative: 'Disbursement of $25M Overnight facility to Meridian Global Trust and upfront fee recognition',
    lines: [
      { accountNumber: '1200', accountName: 'Loans Outstanding - Institutional Principal', debit: 25_000_000, credit: 0 },
      { accountNumber: '1010', accountName: 'Nostro / Central Bank Reserve Cash', debit: 0, credit: 25_000_000 },
      { accountNumber: '1220', accountName: 'Accrued Fees Receivable', debit: 1250, credit: 0 },
      { accountNumber: '4020', accountName: 'Facility & Drawdown Fee Income', debit: 0, credit: 1250 }
    ],
    isBalanced: true,
    checksum: 'SHA256:91ca0298be34018281928019ab921938'
  }
];

export const INITIAL_MAKER_CHECKER: MakerCheckerItem[] = [
  {
    id: 'MC-2026-001',
    changeType: 'LIMIT_OVERRIDE',
    details: 'Temporary +$10M facility headroom authorization for Apex Clearing AG Intraday Facility',
    initiatedBy: 'Credit Analyst (Marcus Vance)',
    initiatedAt: '2026-11-10T05:45:00Z',
    status: 'APPROVED',
    approvedBy: 'Senior Risk Officer (Elena Rostova)',
    approvedAt: '2026-11-10T06:05:00Z'
  },
  {
    id: 'MC-2026-002',
    changeType: 'POLICY_UPDATE',
    details: 'Increase minimum collateral haircut for Commercial Paper from 10% to 12% following credit committee update',
    initiatedBy: 'Quantitative Strategist (Dr. Aris Thorne)',
    initiatedAt: '2026-11-10T06:20:00Z',
    status: 'PENDING_APPROVAL'
  }
];
