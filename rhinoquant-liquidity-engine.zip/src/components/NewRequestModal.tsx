/**
 * RhinoQuant New Drawdown Request Submission Modal
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Allows institutional users or quantitative API simulators to dispatch
 * new funding requests with custom amounts, tenors, and idempotency keys.
 */

import React, { useState } from 'react';
import { Clock, DollarSign, Layers, ShieldCheck, X, Zap } from 'lucide-react';
import { Counterparty, Currency, Facility, ProductType } from '../types';

interface NewRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  counterparties: Counterparty[];
  facilities: Facility[];
  onSubmitRequest: (params: {
    borrowerId: string;
    facilityId: string;
    productType: ProductType;
    currency: Currency;
    requestedAmount: number;
    tenorHours: number;
    idempotencyKey?: string;
  }) => void;
}

export const NewRequestModal: React.FC<NewRequestModalProps> = ({
  isOpen,
  onClose,
  counterparties,
  facilities,
  onSubmitRequest
}) => {
  if (!isOpen) return null;

  const [selectedBorrowerId, setSelectedBorrowerId] = useState<string>(counterparties[0]?.id || '');
  const [currency, setCurrency] = useState<Currency>('USD');
  const [requestedAmount, setRequestedAmount] = useState<number>(15_000_000);
  const [tenorHours, setTenorHours] = useState<number>(24);
  const [customIdempotency, setCustomIdempotency] = useState<string>('');

  const borrowerFacilities = facilities.filter((f) => f.borrowerId === selectedBorrowerId);
  const selectedFacility = borrowerFacilities[0] || facilities[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFacility) return;

    onSubmitRequest({
      borrowerId: selectedBorrowerId,
      facilityId: selectedFacility.id,
      productType: selectedFacility.productType,
      currency,
      requestedAmount,
      tenorHours,
      idempotencyKey: customIdempotency.trim() || undefined
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-[#0b0f17] border border-white/20 rounded-xl max-w-lg w-full shadow-2xl overflow-hidden text-xs text-white">
        {/* Header */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between bg-[#0e1420]">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-[#d4af37]" />
            <span className="font-bold text-sm text-white">Submit Institutional Funding Request</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-white/10 text-white/60 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Borrower */}
          <div>
            <label className="text-white/60 block mb-1">Approved Institutional Counterparty</label>
            <select
              value={selectedBorrowerId}
              onChange={(e) => setSelectedBorrowerId(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white outline-none cursor-pointer"
            >
              {counterparties.map((cp) => (
                <option key={cp.id} value={cp.id} className="bg-[#0f141c]">
                  {cp.name} ({cp.creditRating}) {cp.isInternal ? '[INTERNAL TREASURY]' : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Facility Preview */}
          {selectedFacility && (
            <div className="p-3 bg-white/5 rounded border border-white/5 space-y-1">
              <span className="text-[10px] text-white/40 uppercase block">Associated Facility Code</span>
              <div className="font-semibold text-[#d4af37]">{selectedFacility.facilityCode}</div>
              <div className="text-[10px] text-white/60 flex justify-between">
                <span>Product: {selectedFacility.productType.replace(/_/g, ' ')}</span>
                <span>Limit: ${((selectedFacility.approvedLimit || 0) / 1_000_000).toFixed(0)}M</span>
              </div>
            </div>
          )}

          {/* Amount & Currency */}
          <div>
            <label className="text-white/60 block mb-1">Requested Draw Amount</label>
            <div className="flex items-center gap-2">
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as Currency)}
                className="bg-white/5 border border-white/10 rounded px-2.5 py-2 text-[#d4af37] font-mono outline-none cursor-pointer"
              >
                <option value="USD" className="bg-[#0f141c]">USD</option>
                <option value="EUR" className="bg-[#0f141c]">EUR</option>
                <option value="GBP" className="bg-[#0f141c]">GBP</option>
              </select>
              <input
                type="number"
                value={requestedAmount}
                step={1_000_000}
                onChange={(e) => setRequestedAmount(Math.max(100_000, Number(e.target.value)))}
                className="flex-1 bg-white/5 border border-white/10 rounded px-3 py-2 text-white font-mono font-bold outline-none tabular-nums"
              />
            </div>
            <div className="flex gap-2 mt-1.5">
              {[5_000_000, 10_000_000, 20_000_000, 50_000_000].map((amt) => (
                <button
                  type="button"
                  key={amt}
                  onClick={() => setRequestedAmount(amt)}
                  className="px-2 py-0.5 bg-white/5 hover:bg-white/10 rounded text-[10px] text-white/70 font-mono cursor-pointer"
                >
                  ${amt / 1_000_000}M
                </button>
              ))}
            </div>
          </div>

          {/* Tenor Hours */}
          <div>
            <div className="flex justify-between mb-1">
              <label className="text-white/60">Requested Tenor: {tenorHours} Hours</label>
              <span className="font-mono text-white/50">
                {tenorHours <= 24 ? `${tenorHours}h` : `${(tenorHours / 24).toFixed(0)} days`}
              </span>
            </div>
            <select
              value={tenorHours}
              onChange={(e) => setTenorHours(Number(e.target.value))}
              className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white outline-none cursor-pointer"
            >
              <option value={2} className="bg-[#0f141c]">2 Hours (Intraday Liquidity Advance)</option>
              <option value={4} className="bg-[#0f141c]">4 Hours (Intraday Settlement Window)</option>
              <option value={8} className="bg-[#0f141c]">8 Hours (Full Business Day Advance)</option>
              <option value={24} className="bg-[#0f141c]">24 Hours (Overnight Loan Facility)</option>
              <option value={72} className="bg-[#0f141c]">72 Hours (Weekend / 3-Day Buffer)</option>
              <option value={168} className="bg-[#0f141c]">168 Hours (7-Day Short-Term Revolver)</option>
              <option value={336} className="bg-[#0f141c]">336 Hours (14-Day Working Capital)</option>
              <option value={720} className="bg-[#0f141c]">720 Hours (30-Day Term Liquidity)</option>
            </select>
          </div>

          {/* Idempotency Key (Optional manual test) */}
          <div>
            <label className="text-white/60 block mb-1">Client Idempotency Key (Optional)</label>
            <input
              type="text"
              placeholder="Auto-generated if blank (e.g. IDEMP-MERID-20261110-XYZ)"
              value={customIdempotency}
              onChange={(e) => setCustomIdempotency(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white placeholder-white/30 font-mono text-[11px] outline-none"
            />
            <span className="text-[10px] text-white/40 block mt-0.5">
              Enter an existing key to test duplicate event protection.
            </span>
          </div>

          {/* Buttons */}
          <div className="pt-3 border-t border-white/10 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white rounded cursor-pointer transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#d4af37] hover:bg-[#e5c158] text-[#090d14] font-bold rounded cursor-pointer transition-colors shadow-sm"
            >
              Evaluate & Dispatch
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
