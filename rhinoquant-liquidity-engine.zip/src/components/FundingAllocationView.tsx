/**
 * RhinoQuant Automated Liquidity Allocation View
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Implements FIFO, Priority-Weighted, and Constrained Optimization solvers
 * with traceable allocation rationales and side-by-side policy benchmarks.
 */

import React, { useState } from 'react';
import {
  CheckCircle2,
  Clock,
  Cpu,
  Layers,
  Play,
  Scale,
  Sparkles,
  TrendingUp,
  XCircle
} from 'lucide-react';
import {
  AllocationStrategy,
  Counterparty,
  Facility,
  FundingRequest,
  LiquidityPoolStatus
} from '../types';
import { runAllocation, AllocationRunResult } from '../engine/allocator';

interface FundingAllocationViewProps {
  liquidityPool: LiquidityPoolStatus;
  requests: FundingRequest[];
  counterparties: Counterparty[];
  facilities: Facility[];
  onApplyAllocation: (result: AllocationRunResult) => void;
}

export const FundingAllocationView: React.FC<FundingAllocationViewProps> = ({
  liquidityPool,
  requests,
  counterparties,
  facilities,
  onApplyAllocation
}) => {
  const [selectedStrategy, setSelectedStrategy] = useState<AllocationStrategy>('CONSTRAINED_OPTIMIZATION');
  const [lastRunResult, setLastRunResult] = useState<AllocationRunResult | null>(() =>
    runAllocation({
      strategy: 'CONSTRAINED_OPTIMIZATION',
      requests,
      counterparties,
      facilities,
      liquidityPool
    })
  );

  // Run benchmark comparison across all 3 strategies simultaneously
  const fifoResult = runAllocation({
    strategy: 'FIFO_BASELINE',
    requests,
    counterparties,
    facilities,
    liquidityPool
  });

  const priorityResult = runAllocation({
    strategy: 'PRIORITY_WEIGHTED',
    requests,
    counterparties,
    facilities,
    liquidityPool
  });

  const optResult = runAllocation({
    strategy: 'CONSTRAINED_OPTIMIZATION',
    requests,
    counterparties,
    facilities,
    liquidityPool
  });

  const handleRunStrategy = (strat: AllocationStrategy) => {
    setSelectedStrategy(strat);
    const res = runAllocation({
      strategy: strat,
      requests,
      counterparties,
      facilities,
      liquidityPool
    });
    setLastRunResult(res);
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-white tracking-wide">Automated Liquidity Allocation Engine</h1>
          <p className="text-xs text-white/50">
            Multi-objective allocation algorithms preserving regulatory buffer floors and credit concentration envelopes
          </p>
        </div>

        <div className="flex items-center gap-2">
          {(['FIFO_BASELINE', 'PRIORITY_WEIGHTED', 'CONSTRAINED_OPTIMIZATION'] as AllocationStrategy[]).map((strat) => (
            <button
              key={strat}
              onClick={() => handleRunStrategy(strat)}
              className={`px-3 py-1.5 text-xs font-semibold rounded cursor-pointer transition-colors ${
                selectedStrategy === strat
                  ? 'bg-[#d4af37] text-[#090d14]'
                  : 'bg-white/5 hover:bg-white/10 text-white border border-white/10'
              }`}
            >
              {strat.replace(/_/g, ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Side-by-Side Policy Comparison Table */}
      <div className="bg-[#0d121c] border border-white/10 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <Scale className="w-4 h-4 text-[#d4af37]" />
            <h2 className="text-sm font-bold text-white">Side-by-Side Policy Benchmark (Identical Requests)</h2>
          </div>
          <span className="text-[11px] font-mono text-white/40">Seeded Queue Evaluation</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { name: 'FIFO Baseline', result: fifoResult, desc: 'Temporal ordering by submission timestamp. Does not optimize margin or ratings.' },
            { name: 'Priority-Weighted', result: priorityResult, desc: 'Heuristic scoring based on counterparty credit rating, relationship tier, and tenor velocity.' },
            { name: 'Constrained Optimisation', result: optResult, desc: 'Linear knapsack solver maximizing Net Financing Contribution (NFC) under regulatory buffer constraints.' }
          ].map((item) => (
            <div
              key={item.name}
              className={`p-4 rounded-lg border transition-all ${
                selectedStrategy === item.result.strategy
                  ? 'bg-white/10 border-[#d4af37]'
                  : 'bg-white/5 border-white/5'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-white">{item.name}</span>
                {selectedStrategy === item.result.strategy && (
                  <span className="text-[9px] font-mono text-[#d4af37] bg-[#d4af37]/20 px-1.5 py-0.5 rounded">
                    ACTIVE
                  </span>
                )}
              </div>
              <p className="text-[10px] text-white/50 mt-1 min-h-[30px]">{item.desc}</p>

              <div className="mt-3 space-y-1.5 text-xs pt-2 border-t border-white/10">
                <div className="flex justify-between">
                  <span className="text-white/60">Total Allocated</span>
                  <span className="font-mono font-bold text-white tabular-nums">
                    ${(item.result.totalAllocated / 1_000_000).toFixed(1)}M
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/60">Expected Net Income</span>
                  <span className="font-mono font-bold text-emerald-400 tabular-nums">
                    ${item.result.objectiveMetrics.totalExpectedNetIncome.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/60">Average Margin Spread</span>
                  <span className="font-mono text-[#d4af37] tabular-nums">
                    +{item.result.objectiveMetrics.averageSpreadBps} bps
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/60">Preserved Buffer</span>
                  <span className="font-mono text-white/70 tabular-nums">
                    ${(item.result.objectiveMetrics.liquidityBufferPreserved / 1_000_000).toFixed(0)}M
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Traceable Allocation Outcomes Table */}
      {lastRunResult && (
        <div className="bg-[#0d121c] border border-white/10 rounded-lg overflow-hidden">
          <div className="p-4 bg-white/5 border-b border-white/10 flex items-center justify-between">
            <div>
              <span className="font-bold text-xs text-white">
                Detailed Allocation Breakdown ({lastRunResult.strategy.replace(/_/g, ' ')})
              </span>
              <p className="text-[11px] text-white/50">
                Execution trace: Why each request received or was denied cash allocation
              </p>
            </div>
            <button
              onClick={() => onApplyAllocation(lastRunResult)}
              className="px-3 py-1.5 bg-[#d4af37] hover:bg-[#e5c158] text-[#090d14] text-xs font-bold rounded cursor-pointer transition-colors"
            >
              Commit Reservations
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-[10px] text-white/40 uppercase bg-white/5 border-b border-white/10">
                <tr>
                  <th className="py-2.5 px-3">Request ID</th>
                  <th className="py-2.5 px-3">Borrower</th>
                  <th className="py-2.5 px-3 text-right">Requested</th>
                  <th className="py-2.5 px-3 text-right">Allocated</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Objective Score</th>
                  <th className="py-2.5 px-3">Mathematical Rationale / Explanation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {lastRunResult.allocatedRequests.map((item) => {
                  const req = requests.find((r) => r.id === item.requestId);
                  const cp = counterparties.find((c) => c.id === req?.borrowerId);

                  return (
                    <tr key={item.requestId} className="hover:bg-white/5 transition-colors">
                      <td className="py-3 px-3 font-mono font-medium text-white">{item.requestId}</td>
                      <td className="py-3 px-3 font-semibold text-white/90">{cp?.name || 'Unknown'}</td>
                      <td className="py-3 px-3 text-right font-mono text-white/70 tabular-nums">
                        ${((req?.requestedAmount || 0) / 1_000_000).toFixed(1)}M
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold text-emerald-400 tabular-nums">
                        ${(item.allocatedAmount / 1_000_000).toFixed(1)}M
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`font-mono text-[10px] font-semibold px-2 py-0.5 rounded border ${
                            item.status === 'ALLOCATED'
                              ? 'text-emerald-300 bg-emerald-950/40 border-emerald-500/30'
                              : item.status === 'PARTIALLY_ALLOCATED'
                              ? 'text-amber-300 bg-amber-950/40 border-amber-500/30'
                              : 'text-red-300 bg-red-950/40 border-red-500/30'
                          }`}
                        >
                          {item.status}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-mono text-white/80 tabular-nums">
                        {item.allocationScore} pts
                      </td>
                      <td className="py-3 px-3 text-white/70 max-w-md">
                        {item.explanation}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
