/**
 * RhinoQuant Credit Risk & Liquidity Analytics View
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Implements Wrong-Way Risk modeling, Expected Credit Loss (ECL = PD * LGD * EAD),
 * 24-hour cash flow projections, and calibrated repayment-delay predictions.
 */

import React from 'react';
import {
  AlertOctagon,
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  Clock,
  LineChart,
  ShieldAlert,
  TrendingDown,
  TrendingUp,
  Zap
} from 'lucide-react';
import { CollateralAsset, Counterparty, Facility, FundingRequest, LiquidityPoolStatus } from '../types';
import {
  calculatePortfolioECL,
  evaluateWrongWayRisk,
  generate24HourCashFlowForecast,
  predictRepaymentDelays
} from '../engine/analytics';

interface RiskAnalyticsViewProps {
  counterparties: Counterparty[];
  facilities: Facility[];
  collateral: CollateralAsset[];
  requests: FundingRequest[];
  liquidityPool: LiquidityPoolStatus;
}

export const RiskAnalyticsView: React.FC<RiskAnalyticsViewProps> = ({
  counterparties,
  facilities,
  collateral,
  requests,
  liquidityPool
}) => {
  const eclData = calculatePortfolioECL(facilities, counterparties, collateral);
  const wrongWayRisks = evaluateWrongWayRisk(counterparties, collateral);
  const cashFlowSlots = generate24HourCashFlowForecast(liquidityPool, requests);
  const delayPredictions = predictRepaymentDelays(requests, counterparties);

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-white tracking-wide">
            Quantitative Credit & Liquidity Risk Surveillance
          </h1>
          <p className="text-xs text-white/50">
            Wrong-way correlation profiles, Expected Credit Loss (IFRS 9 / CECL), and forward liquidity run-off
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs">
          <span className="font-mono text-emerald-400 bg-emerald-950/50 border border-emerald-500/30 px-2.5 py-1 rounded">
            Portfolio ECL: ${(eclData.totalECL / 1_000).toFixed(1)}k ({((eclData.totalECL / Math.max(1, eclData.totalEAD)) * 100).toFixed(3)}%)
          </span>
        </div>
      </div>

      {/* Top 4 Risk Overview Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg">
          <span className="text-[10px] text-white/40 uppercase block">Total Exposure at Default (EAD)</span>
          <div className="text-2xl font-bold font-mono text-white mt-1 tabular-nums">
            ${(eclData.totalEAD / 1_000_000).toFixed(1)}M
          </div>
          <span className="text-[10px] text-white/50 mt-1 block">Active drawn loans subject to credit risk</span>
        </div>

        <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg">
          <span className="text-[10px] text-white/40 uppercase block">Weighted Average 1-Year PD</span>
          <div className="text-2xl font-bold font-mono text-[#d4af37] mt-1 tabular-nums">
            {eclData.weightedPD.toFixed(3)}%
          </div>
          <span className="text-[10px] text-white/50 mt-1 block">Institutional rating-mapped probability</span>
        </div>

        <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg">
          <span className="text-[10px] text-white/40 uppercase block">Weighted Average Secured LGD</span>
          <div className="text-2xl font-bold font-mono text-cyan-400 mt-1 tabular-nums">
            {eclData.weightedLGD.toFixed(1)}%
          </div>
          <span className="text-[10px] text-white/50 mt-1 block">Discounted recovery net of haircuts</span>
        </div>

        <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg">
          <span className="text-[10px] text-white/40 uppercase block">Total ECL Allowance</span>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            ${(eclData.totalECL / 1_000).toFixed(1)}k
          </div>
          <span className="text-[10px] text-emerald-400/80 mt-1 block">Provisioned in subledger Account 5020</span>
        </div>
      </div>

      {/* Wrong-Way Risk Surveillance Table */}
      <div className="bg-[#0d121c] border border-white/10 rounded-lg overflow-hidden">
        <div className="p-4 bg-white/5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertOctagon className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-bold text-white">Wrong-Way Risk Correlation Matrix</h2>
          </div>
          <span className="text-[11px] text-white/50">
            Joint probability of borrower credit degradation and collateral asset illiquidity
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-[10px] text-white/40 uppercase bg-white/5 border-b border-white/10 select-none">
              <tr>
                <th className="py-2.5 px-3">Borrower Entity</th>
                <th className="py-2.5 px-3">Pledged Collateral Asset</th>
                <th className="py-2.5 px-3 text-center">Correlation Factor (ρ)</th>
                <th className="py-2.5 px-3">Risk Tier</th>
                <th className="py-2.5 px-3">Quantitative Vulnerability Assessment</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {wrongWayRisks.map((wwr, i) => (
                <tr key={i} className="hover:bg-white/5 transition-colors">
                  <td className="py-3 px-3 font-semibold text-white">{wwr.counterpartyName}</td>
                  <td className="py-3 px-3 font-mono text-[#d4af37]">{wwr.assetDescription}</td>
                  <td className="py-3 px-3 text-center font-mono font-bold text-white tabular-nums">
                    {wwr.correlationFactor.toFixed(2)}
                  </td>
                  <td className="py-3 px-3">
                    <span
                      className={`font-semibold text-[10px] px-2 py-0.5 rounded border inline-block ${
                        wwr.riskTier === 'CRITICAL'
                          ? 'text-red-300 bg-red-950/60 border-red-500/40'
                          : wwr.riskTier === 'HIGH'
                          ? 'text-amber-300 bg-amber-950/60 border-amber-500/40'
                          : 'text-emerald-300 bg-emerald-950/60 border-emerald-500/40'
                      }`}
                    >
                      {wwr.riskTier} RISK
                    </span>
                  </td>
                  <td className="py-3 px-3 text-white/70 text-[11px] max-w-lg leading-relaxed">
                    {wwr.vulnerabilityAssessment}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Two Column Grid: 24H Forward Cashflow Forecast & Calibrated Repayment Delay Model */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 24-Hour Forward Cash-Flow Projections */}
        <div className="p-5 bg-[#0d121c] border border-white/10 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">24-Hour Forward Cash-Flow Projection</h2>
              <p className="text-[11px] text-white/50">Expected maturities vs scheduled intraday commitments</p>
            </div>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>

          <div className="space-y-2 text-xs">
            {cashFlowSlots.map((slot) => {
              const isPositive = slot.netLiquidityPositionUsd >= 0;
              return (
                <div
                  key={slot.timeLabel}
                  className="p-2.5 bg-white/5 rounded border border-white/5 flex items-center justify-between"
                >
                  <div className="font-mono text-white/80 w-16">{slot.timeLabel}</div>
                  <div className="flex items-center gap-4 font-mono text-[11px]">
                    <span className="text-emerald-400 tabular-nums">
                      +${(slot.expectedInflowsUsd / 1_000_000).toFixed(2)}M
                    </span>
                    <span className="text-red-400 tabular-nums">
                      -${(slot.scheduledOutflowsUsd / 1_000_000).toFixed(2)}M
                    </span>
                    <span
                      className={`font-bold tabular-nums w-20 text-right ${
                        isPositive ? 'text-emerald-300' : 'text-red-300'
                      }`}
                    >
                      {isPositive ? '+' : ''}${(slot.netLiquidityPositionUsd / 1_000_000).toFixed(2)}M
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Repayment Delay Prediction Model */}
        <div className="p-5 bg-[#0d121c] border border-white/10 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">Calibrated Repayment Delay Model</h2>
              <p className="text-[11px] text-white/50">Interpretable logistic baseline predicting settlement slippage</p>
            </div>
            <Zap className="w-4 h-4 text-[#d4af37]" />
          </div>

          <div className="space-y-3">
            {delayPredictions.length === 0 ? (
              <div className="text-center py-8 text-white/40 text-xs">
                No active loans currently in monitoring horizon.
              </div>
            ) : (
              delayPredictions.map((pred) => (
                <div
                  key={pred.requestId}
                  className="p-3 bg-white/5 rounded border border-white/5 space-y-1.5 text-xs"
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="font-semibold text-white">{pred.counterpartyName}</span>
                      <span className="font-mono text-[10px] text-white/40 ml-2">({pred.requestId})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${
                          pred.riskCategory === 'HIGH_ALERT'
                            ? 'text-red-300 bg-red-950/50 border-red-500/40'
                            : pred.riskCategory === 'ELEVATED'
                            ? 'text-amber-300 bg-amber-950/50 border-amber-500/40'
                            : 'text-emerald-300 bg-emerald-950/50 border-emerald-500/40'
                        }`}
                      >
                        {pred.riskCategory}
                      </span>
                      <span className="font-mono font-bold text-white tabular-nums">
                        {(pred.predictedDelayProbability * 100).toFixed(1)}% prob
                      </span>
                    </div>
                  </div>
                  <ul className="text-[11px] text-white/60 space-y-0.5 pl-2 border-l border-white/10">
                    {pred.primaryDrivers.map((driver, dIdx) => (
                      <li key={dIdx}>· {driver}</li>
                    ))}
                  </ul>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
