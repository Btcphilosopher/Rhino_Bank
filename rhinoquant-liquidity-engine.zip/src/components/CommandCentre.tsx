/**
 * RhinoQuant Command Centre View
 * Real-time macro liquidity, exposure ladder, telemetry, and operational controls
 */

import React from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  CheckCircle2,
  Clock,
  DollarSign,
  Layers,
  Pause,
  Play,
  ShieldAlert,
  TrendingUp,
  Zap
} from 'lucide-react';
import {
  Counterparty,
  EngineTelemetry,
  Facility,
  FundingRequest,
  LiquidityPoolStatus,
  ProductType
} from '../types';
import { calculateMaturityConcentration } from '../engine/analytics';

interface CommandCentreProps {
  liquidityPool: LiquidityPoolStatus;
  telemetry: EngineTelemetry;
  requests: FundingRequest[];
  facilities: Facility[];
  counterparties: Counterparty[];
  isCircuitBreakerActive: boolean;
  onToggleCircuitBreaker: () => void;
  onToggleProductPause: (product: ProductType) => void;
  onSelectRequest: (request: FundingRequest) => void;
  onNavigate: (screen: string) => void;
}

export const CommandCentre: React.FC<CommandCentreProps> = ({
  liquidityPool,
  telemetry,
  requests,
  facilities,
  counterparties,
  isCircuitBreakerActive,
  onToggleCircuitBreaker,
  onToggleProductPause,
  onSelectRequest,
  onNavigate
}) => {
  const maturityBuckets = calculateMaturityConcentration(requests);

  // Separate metrics as required by prompt: requested, approved, reserved, disbursed, repaid
  const totalRequested = requests.reduce((sum, r) => sum + r.requestedAmount, 0);
  const totalApproved = requests
    .filter((r) => ['APPROVED', 'PARTIALLY_APPROVED', 'FUNDING_RESERVED', 'OUTSTANDING', 'REPAID'].includes(r.status))
    .reduce((sum, r) => sum + (r.approvedAmount || r.requestedAmount), 0);
  const totalReserved = liquidityPool.reservedCash;
  const totalDisbursed = liquidityPool.disbursedPrincipal;
  const totalRepaid = requests
    .filter((r) => r.status === 'REPAID')
    .reduce((sum, r) => sum + (r.repaymentAmount || r.approvedAmount || r.requestedAmount), 0);

  // Group exposures
  const groupExposures = [
    { name: 'Apex Financial Holdings (DEU/CHE)', drawn: 41_800_000, cap: 150_000_000, rating: 'AA-' },
    { name: 'Meridian Capital Partners (USA)', drawn: 70_000_000, cap: 150_000_000, rating: 'A+' },
    { name: 'Helios Energy Group (GBR)', drawn: 20_000_000, cap: 150_000_000, rating: 'A' },
    { name: 'Valo Investment Group (LUX)', drawn: 28_000_000, cap: 150_000_000, rating: 'BBB+' },
    { name: 'Supranational Reserve (DEU)', drawn: 50_000_000, cap: 250_000_000, rating: 'AAA' }
  ];

  return (
    <div className="space-y-6">
      {/* Circuit Breaker Alert Banner if Active */}
      {isCircuitBreakerActive && (
        <div className="p-4 bg-red-950/70 border border-red-500/80 rounded-lg flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShieldAlert className="w-6 h-6 text-red-400 shrink-0" />
            <div>
              <div className="font-bold text-red-200 text-sm tracking-wide">
                GLOBAL LIQUIDITY CIRCUIT BREAKER ACTIVE · NEW LENDING SUSPENDED
              </div>
              <div className="text-xs text-red-300/80 mt-0.5">
                {telemetry.circuitBreakerReason || 'Emergency stop triggered. Cash availability below mandatory regulatory liquidity coverage floor.'}
              </div>
            </div>
          </div>
          <button
            onClick={onToggleCircuitBreaker}
            className="px-3.5 py-1.5 bg-red-800 hover:bg-red-700 text-white text-xs font-semibold rounded cursor-pointer transition-colors"
          >
            Reset Circuit Breaker (Maker-Checker)
          </button>
        </div>
      )}

      {/* Top 5 Distinct Metrics Strip (Requested, Approved, Reserved, Disbursed, Repaid) */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div className="p-3.5 bg-[#0d121c] border border-white/10 rounded-lg">
          <div className="text-[11px] font-medium text-white/50 uppercase tracking-wider">Total Requested</div>
          <div className="text-xl font-bold font-mono text-[#f5f5f7] mt-1 tabular-nums">
            ${(totalRequested / 1_000_000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-white/40 mt-1 flex items-center gap-1">
            <span>{requests.length} requests in lifecycle</span>
          </div>
        </div>

        <div className="p-3.5 bg-[#0d121c] border border-white/10 rounded-lg">
          <div className="text-[11px] font-medium text-white/50 uppercase tracking-wider">Total Approved</div>
          <div className="text-xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            ${(totalApproved / 1_000_000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-emerald-400/80 mt-1">Policy verified (RQ-POL-2026.4.1)</div>
        </div>

        <div className="p-3.5 bg-[#0d121c] border border-white/10 rounded-lg">
          <div className="text-[11px] font-medium text-white/50 uppercase tracking-wider">Funding Reserved</div>
          <div className="text-xl font-bold font-mono text-[#d4af37] mt-1 tabular-nums">
            ${(totalReserved / 1_000_000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-amber-400/80 mt-1">Pending payment disbursement</div>
        </div>

        <div className="p-3.5 bg-[#0d121c] border border-white/10 rounded-lg">
          <div className="text-[11px] font-medium text-white/50 uppercase tracking-wider">Active Disbursed</div>
          <div className="text-xl font-bold font-mono text-cyan-400 mt-1 tabular-nums">
            ${(totalDisbursed / 1_000_000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-white/40 mt-1">Live principal on subledger</div>
        </div>

        <div className="p-3.5 bg-[#0d121c] border border-white/10 rounded-lg">
          <div className="text-[11px] font-medium text-white/50 uppercase tracking-wider">Settled & Repaid</div>
          <div className="text-xl font-bold font-mono text-indigo-300 mt-1 tabular-nums">
            ${(totalRepaid / 1_000_000).toFixed(2)}M
          </div>
          <div className="text-[10px] text-indigo-300/80 mt-1">Principal + interest collected</div>
        </div>
      </div>

      {/* Main Grid: Liquidity Pool Architecture + High Frequency Telemetry */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Liquidity Pool State */}
        <div className="p-5 bg-[#0d121c] border border-white/10 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">Liquidity Pool Solvency</h2>
              <p className="text-[11px] text-white/50">Total Central Bank Cash & Committed Headroom</p>
            </div>
            <span className="font-mono text-xs text-[#d4af37] bg-[#d4af37]/10 px-2 py-0.5 rounded border border-[#d4af37]/20">
              USD 500M POOL
            </span>
          </div>

          <div className="space-y-3">
            {/* Visual Bar of Pool */}
            <div className="h-4 w-full bg-white/5 rounded-sm overflow-hidden flex">
              <div
                style={{ width: `${(liquidityPool.disbursedPrincipal / liquidityPool.totalCapacity) * 100}%` }}
                className="bg-cyan-500/80 h-full"
                title="Disbursed Principal"
              />
              <div
                style={{ width: `${(liquidityPool.reservedCash / liquidityPool.totalCapacity) * 100}%` }}
                className="bg-[#d4af37] h-full"
                title="Reserved Cash"
              />
              <div
                style={{ width: `${(liquidityPool.availableForAllocation / liquidityPool.totalCapacity) * 100}%` }}
                className="bg-emerald-500/70 h-full"
                title="Available for Allocation"
              />
              <div
                style={{ width: `${(liquidityPool.minimumLiquidityBuffer / liquidityPool.totalCapacity) * 100}%` }}
                className="bg-red-500/60 h-full"
                title="Mandatory Buffer Floor"
              />
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs pt-1">
              <div className="p-2 bg-white/5 rounded border border-white/5">
                <span className="text-white/40 block text-[10px]">Uncommitted Cash</span>
                <span className="font-mono font-bold text-sm text-white tabular-nums">
                  ${(liquidityPool.uncommittedCash / 1_000_000).toFixed(2)}M
                </span>
              </div>
              <div className="p-2 bg-white/5 rounded border border-white/5">
                <span className="text-white/40 block text-[10px]">Available To Allocate</span>
                <span className="font-mono font-bold text-sm text-emerald-400 tabular-nums">
                  ${(liquidityPool.availableForAllocation / 1_000_000).toFixed(2)}M
                </span>
              </div>
              <div className="p-2 bg-white/5 rounded border border-white/5">
                <span className="text-white/40 block text-[10px]">Regulatory Buffer Floor</span>
                <span className="font-mono font-bold text-sm text-red-300 tabular-nums">
                  ${(liquidityPool.minimumLiquidityBuffer / 1_000_000).toFixed(2)}M
                </span>
              </div>
              <div className="p-2 bg-white/5 rounded border border-white/5">
                <span className="text-white/40 block text-[10px]">Pool Utilization</span>
                <span className="font-mono font-bold text-sm text-white tabular-nums">
                  {(((liquidityPool.disbursedPrincipal + liquidityPool.reservedCash) / liquidityPool.totalCapacity) * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          </div>

          <div className="border-t border-white/10 pt-3 flex items-center justify-between text-[11px] text-white/50">
            <span>Source: Nostro Fed/ECB Real-Time</span>
            <span className="font-mono">{liquidityPool.lastUpdated}</span>
          </div>
        </div>

        {/* High Frequency Telemetry Box */}
        <div className="p-5 bg-[#0d121c] border border-white/10 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">High-Frequency Telemetry</h2>
              <p className="text-[11px] text-white/50">Measured Engine Latencies & Contention</p>
            </div>
            <Zap className="w-4 h-4 text-[#d4af37]" />
          </div>

          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-2 bg-white/5 rounded border border-white/5">
              <span className="text-[10px] text-white/40 block">P50 Decision</span>
              <span className="font-mono font-bold text-emerald-400 text-sm tabular-nums">
                {telemetry.decisionLatencyP50Ms} ms
              </span>
            </div>
            <div className="p-2 bg-white/5 rounded border border-white/5">
              <span className="text-[10px] text-white/40 block">P95 Decision</span>
              <span className="font-mono font-bold text-[#d4af37] text-sm tabular-nums">
                {telemetry.decisionLatencyP95Ms} ms
              </span>
            </div>
            <div className="p-2 bg-white/5 rounded border border-white/5">
              <span className="text-[10px] text-white/40 block">P99 Decision</span>
              <span className="font-mono font-bold text-amber-400 text-sm tabular-nums">
                {telemetry.decisionLatencyP99Ms} ms
              </span>
            </div>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1 border-b border-white/5">
              <span className="text-white/60">Event Arrival Rate</span>
              <span className="font-mono text-white tabular-nums">{telemetry.eventsPerSecond} events/sec</span>
            </div>
            <div className="flex justify-between py-1 border-b border-white/5">
              <span className="text-white/60">Active Queue Depth</span>
              <span className="font-mono text-white tabular-nums">{telemetry.activeQueueDepth} in transit</span>
            </div>
            <div className="flex justify-between py-1 border-b border-white/5">
              <span className="text-white/60">Payment Adapter Latency</span>
              <span className="font-mono text-white tabular-nums">{telemetry.paymentAdapterLatencyMs} ms (Fedwire/Target2)</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-white/60">Reconciliation Lag</span>
              <span className="font-mono text-emerald-400 tabular-nums">{telemetry.reconciliationLagSec}s lag</span>
            </div>
          </div>

          <div className="text-[10px] text-white/40 text-right">
            Deterministic zero-lock reservation guarantee
          </div>
        </div>

        {/* Maturity Concentration Ladder */}
        <div className="p-5 bg-[#0d121c] border border-white/10 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">Maturity Concentration Ladder</h2>
              <p className="text-[11px] text-white/50">Run-Off Profile Across Tenor Horizons</p>
            </div>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>

          <div className="space-y-3">
            {maturityBuckets.map((bucket) => (
              <div key={bucket.bucket} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-white/80 font-medium">{bucket.label}</span>
                  <span className="font-mono text-white tabular-nums">
                    ${(bucket.totalCommittedUsd / 1_000_000).toFixed(1)}M ({bucket.percentageOfPortfolio}%)
                  </span>
                </div>
                <div className="h-2 w-full bg-white/5 rounded overflow-hidden">
                  <div
                    style={{ width: `${Math.min(100, bucket.percentageOfPortfolio)}%` }}
                    className="h-full bg-gradient-to-r from-[#d4af37]/60 to-[#d4af37]"
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="pt-2 text-[11px] text-white/50 flex justify-between">
            <span>High-frequency velocity focus</span>
            <span>&gt;70% matures &lt;24 hours</span>
          </div>
        </div>
      </div>

      {/* Middle Grid: Corporate Group Exposure Caps + Product Line Circuit Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Economic Group Concentration */}
        <div className="p-5 bg-[#0d121c] border border-white/10 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">Economic Group Concentration Limits</h2>
              <p className="text-[11px] text-white/50">Aggregation across affiliated legal borrower entities (Cap $150M)</p>
            </div>
            <span className="text-[11px] font-mono text-white/40">SINGLE RISK UNIT</span>
          </div>

          <div className="space-y-3">
            {groupExposures.map((grp) => {
              const utilPct = (grp.drawn / grp.cap) * 100;
              return (
                <div key={grp.name} className="p-2.5 bg-white/5 rounded border border-white/5 space-y-1.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-white/90">{grp.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-white/40 text-[10px]">Rating: {grp.rating}</span>
                      <span className="font-mono font-bold text-white tabular-nums">
                        ${(grp.drawn / 1_000_000).toFixed(1)}M / ${(grp.cap / 1_000_000).toFixed(0)}M
                      </span>
                    </div>
                  </div>
                  <div className="h-1.5 w-full bg-white/10 rounded overflow-hidden">
                    <div
                      style={{ width: `${utilPct}%` }}
                      className={`h-full ${
                        utilPct > 80 ? 'bg-red-500' : utilPct > 60 ? 'bg-amber-400' : 'bg-emerald-500'
                      }`}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Product Line Pause & Operating Controls */}
        <div className="p-5 bg-[#0d121c] border border-white/10 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">Product Line Execution Controls</h2>
              <p className="text-[11px] text-white/50">Maker-Checker pause controls by financing product</p>
            </div>
            <button
              onClick={onToggleCircuitBreaker}
              className={`px-2.5 py-1 text-xs font-semibold rounded cursor-pointer transition-colors ${
                isCircuitBreakerActive
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  : 'bg-red-950/80 hover:bg-red-900 border border-red-500/60 text-red-300'
              }`}
            >
              {isCircuitBreakerActive ? 'Resume Engine' : 'Trip Circuit Breaker'}
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            {[
              { type: 'INTRADAY_ADVANCE' as ProductType, label: 'Intraday Liquidity Advance' },
              { type: 'OVERNIGHT_LOAN' as ProductType, label: 'Overnight Loan Facility' },
              { type: 'SHORT_TERM_REVOLVER' as ProductType, label: 'Short-Term Revolver' },
              { type: 'RECEIVABLES_BACKED' as ProductType, label: 'Receivables-Backed Advance' },
              { type: 'SECURED_WORKING_CAPITAL' as ProductType, label: 'Secured Working Capital' },
              { type: 'INTERBANK_LENDING' as ProductType, label: 'Interbank Repo / Lending' },
              { type: 'INTERNAL_TREASURY_ALLOCATION' as ProductType, label: 'Internal Treasury Desk' }
            ].map((p) => {
              const isPaused = telemetry.pausedProducts.includes(p.type);
              return (
                <div
                  key={p.type}
                  className="p-2.5 bg-white/5 rounded border border-white/5 flex items-center justify-between"
                >
                  <div className="truncate mr-2">
                    <span className="font-medium text-white/90 block truncate">{p.label}</span>
                    <span className="text-[10px] text-white/40">{isPaused ? 'Paused' : 'Active Automated'}</span>
                  </div>
                  <button
                    onClick={() => onToggleProductPause(p.type)}
                    className={`p-1.5 rounded cursor-pointer transition-colors ${
                      isPaused ? 'bg-red-500/20 text-red-300 hover:bg-red-500/30' : 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30'
                    }`}
                    title={isPaused ? 'Resume product' : 'Pause product'}
                  >
                    {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Recent Live Events & Queue Strip */}
      <div className="p-5 bg-[#0d121c] border border-white/10 rounded-lg space-y-3">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#d4af37]" />
            <h2 className="text-sm font-bold text-white tracking-wide">Live High-Frequency Lending Events</h2>
          </div>
          <button
            onClick={() => onNavigate('LENDING_QUEUE')}
            className="text-xs text-[#d4af37] hover:underline cursor-pointer flex items-center gap-1 font-medium"
          >
            Open Full Lending Queue <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-[10px] text-white/40 uppercase border-b border-white/10">
              <tr>
                <th className="py-2 px-3">Request ID</th>
                <th className="py-2 px-3">Counterparty</th>
                <th className="py-2 px-3">Product</th>
                <th className="py-2 px-3 text-right">Amount</th>
                <th className="py-2 px-3">Tenor</th>
                <th className="py-2 px-3">Decision</th>
                <th className="py-2 px-3">Status</th>
                <th className="py-2 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {requests.slice(0, 6).map((req) => {
                const cp = counterparties.find((c) => c.id === req.borrowerId);
                return (
                  <tr key={req.id} className="hover:bg-white/5 transition-colors">
                    <td className="py-2.5 px-3 font-mono text-white/80">{req.id}</td>
                    <td className="py-2.5 px-3 font-medium text-white">{cp?.name || req.borrowerId}</td>
                    <td className="py-2.5 px-3 text-white/60 text-[11px]">{req.productType.replace(/_/g, ' ')}</td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-white tabular-nums">
                      {req.currency} {(req.requestedAmount / 1_000_000).toFixed(2)}M
                    </td>
                    <td className="py-2.5 px-3 font-mono text-white/70">{req.tenorHours}h</td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`text-[11px] font-semibold ${
                          req.decisionStatus === 'APPROVED'
                            ? 'text-emerald-400'
                            : req.decisionStatus === 'PARTIALLY_APPROVED'
                            ? 'text-amber-400'
                            : req.decisionStatus === 'QUEUED'
                            ? 'text-cyan-400'
                            : 'text-red-400'
                        }`}
                      >
                        {req.decisionStatus}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="font-mono text-[10px] text-white/50">{req.status}</span>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={() => onSelectRequest(req)}
                        className="px-2 py-1 bg-white/10 hover:bg-[#d4af37] hover:text-[#090d14] text-white text-[11px] rounded transition-all cursor-pointer font-medium"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
