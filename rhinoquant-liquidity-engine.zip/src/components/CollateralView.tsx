/**
 * RhinoQuant Collateral & Borrowing Base Management View
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Tracks pledged collateral inventory, valuation timestamps, haircuts,
 * contractual borrowing bases, and interactive collateral substitution simulations.
 */

import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowRightLeft,
  CheckCircle2,
  Clock,
  Coins,
  FileText,
  Lock,
  Scale,
  Shield,
  Sparkles
} from 'lucide-react';
import { CollateralAsset, Counterparty } from '../types';
import {
  calculateCounterpartyBorrowingBase,
  COLLATERAL_LEGAL_DISCLAIMER,
  simulateCollateralSubstitution
} from '../engine/collateral';

interface CollateralViewProps {
  collateral: CollateralAsset[];
  counterparties: Counterparty[];
}

export const CollateralView: React.FC<CollateralViewProps> = ({ collateral, counterparties }) => {
  const [selectedCpId, setSelectedCpId] = useState<string>('CP-MERID-02');
  const [substitutionRetiringId, setSubstitutionRetiringId] = useState<string>(collateral[0]?.id || 'COL-UST-01');
  const [substituteClass, setSubstituteClass] = useState<CollateralAsset['assetClass']>('GERMAN_BUND');
  const [substituteMarketValue, setSubstituteMarketValue] = useState<number>(85_000_000);
  const [substitutionResult, setSubstitutionResult] = useState<any>(null);

  const cpMap = new Map(counterparties.map((c) => [c.id, c]));
  const evaluatedBase = calculateCounterpartyBorrowingBase(collateral, selectedCpId);
  const selectedCp = cpMap.get(selectedCpId);

  const handleSimulateSubstitution = () => {
    const res = simulateCollateralSubstitution(collateral, substitutionRetiringId, {
      assetClass: substituteClass,
      marketValue: substituteMarketValue,
      priorEncumbrance: 0,
      description: `Substitute ${substituteClass.replace(/_/g, ' ')} portfolio`
    });
    setSubstitutionResult(res);
  };

  return (
    <div className="space-y-6">
      {/* Legal Disclaimer Callout (Mandatory per Section 8) */}
      <div className="p-3.5 bg-[#12161f] border border-amber-500/30 rounded-lg flex items-start gap-3 text-xs text-amber-200/90">
        <Shield className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <div className="leading-relaxed font-sans">{COLLATERAL_LEGAL_DISCLAIMER}</div>
      </div>

      {/* Header & Counterparty Selector */}
      <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-white tracking-wide">
            Collateral Inventory & Borrowing Base Ledgers
          </h1>
          <p className="text-xs text-white/50">
            Real-time haircut application, prior lien encumbrance deductions, and triparty custody tracking
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-white/60">Select Counterparty:</span>
          <select
            value={selectedCpId}
            onChange={(e) => {
              setSelectedCpId(e.target.value);
              setSubstitutionResult(null);
            }}
            className="bg-white/5 border border-white/10 rounded px-3 py-1.5 text-white font-medium outline-none cursor-pointer"
          >
            {counterparties.filter((c) => !c.isInternal).map((cp) => (
              <option key={cp.id} value={cp.id} className="bg-[#0f141c]">
                {cp.name} ({cp.creditRating})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Borrowing Base Summary Strip */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg">
          <span className="text-[10px] text-white/40 uppercase block">Total Pledged Market Value</span>
          <div className="text-2xl font-bold font-mono text-white mt-1 tabular-nums">
            ${(evaluatedBase.totalMarketValue / 1_000_000).toFixed(2)}M
          </div>
          <span className="text-[10px] text-white/50 mt-1 block">Live pricing feed evaluation</span>
        </div>

        <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg">
          <span className="text-[10px] text-white/40 uppercase block">Post-Haircut Eligible Value</span>
          <div className="text-2xl font-bold font-mono text-[#d4af37] mt-1 tabular-nums">
            ${(evaluatedBase.totalPostHaircutValue / 1_000_000).toFixed(2)}M
          </div>
          <span className="text-[10px] text-white/50 mt-1 block">Weighted avg haircut applied</span>
        </div>

        <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg">
          <span className="text-[10px] text-white/40 uppercase block">Allocated / Encumbered Debt</span>
          <div className="text-2xl font-bold font-mono text-cyan-400 mt-1 tabular-nums">
            ${((evaluatedBase.totalPriorEncumbrance + evaluatedBase.totalCurrentlyAllocated) / 1_000_000).toFixed(2)}M
          </div>
          <span className="text-[10px] text-white/50 mt-1 block">Prior liens + active loan backing</span>
        </div>

        <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg">
          <span className="text-[10px] text-white/40 uppercase block">Net Available Borrowing Base</span>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            ${(evaluatedBase.netAvailableBorrowingBase / 1_000_000).toFixed(2)}M
          </div>
          <span className="text-[10px] text-emerald-400/80 mt-1 block">Contractual capacity for new draw</span>
        </div>
      </div>

      {/* Collateral Asset Table */}
      <div className="bg-[#0d121c] border border-white/10 rounded-lg overflow-hidden">
        <div className="p-3 bg-white/5 border-b border-white/10 flex items-center justify-between">
          <span className="font-bold text-xs text-white">
            Pledged Collateral Asset Register ({selectedCp?.name})
          </span>
          <span className="text-[11px] text-white/50 font-mono">
            Tri-Party Custodial Verification Active
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-[10px] text-white/40 uppercase bg-white/5 border-b border-white/10 select-none">
              <tr>
                <th className="py-2.5 px-3">Asset ID / ISIN</th>
                <th className="py-2.5 px-3">Asset Description</th>
                <th className="py-2.5 px-3">Class</th>
                <th className="py-2.5 px-3 text-right">Market Value</th>
                <th className="py-2.5 px-3 text-right">Haircut %</th>
                <th className="py-2.5 px-3 text-right">Post-Haircut</th>
                <th className="py-2.5 px-3 text-right">Allocated</th>
                <th className="py-2.5 px-3 text-right">Eligible Base</th>
                <th className="py-2.5 px-3">Custodian & Control</th>
                <th className="py-2.5 px-3">Valuation Source</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {evaluatedBase.assets.map((asset) => {
                const postHaircut = asset.marketValue * (1 - asset.haircutPercent / 100);
                return (
                  <tr key={asset.id} className="hover:bg-white/5 transition-colors">
                    <td className="py-3 px-3 font-mono font-medium text-[#d4af37]">
                      {asset.identifier}
                      <div className="text-[10px] text-white/40 font-normal">{asset.id}</div>
                    </td>

                    <td className="py-3 px-3 font-medium text-white max-w-[200px]">
                      {asset.description}
                    </td>

                    <td className="py-3 px-3 text-white/80 text-[11px]">
                      {asset.assetClass.replace(/_/g, ' ')}
                    </td>

                    <td className="py-3 px-3 text-right font-mono font-bold text-white tabular-nums">
                      ${(asset.marketValue / 1_000_000).toFixed(2)}M
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-amber-400 tabular-nums">
                      {asset.haircutPercent.toFixed(1)}%
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-white/90 tabular-nums">
                      ${(postHaircut / 1_000_000).toFixed(2)}M
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-cyan-400 tabular-nums">
                      ${(asset.currentlyAllocatedAmount / 1_000_000).toFixed(2)}M
                    </td>

                    <td className="py-3 px-3 text-right font-mono font-bold text-emerald-400 tabular-nums">
                      ${(asset.eligibleBorrowingBase / 1_000_000).toFixed(2)}M
                    </td>

                    <td className="py-3 px-3 text-[11px]">
                      <div className="text-white/90 font-medium">{asset.custodian}</div>
                      <div className="text-[10px] text-white/40 font-mono">{asset.controlStatus}</div>
                    </td>

                    <td className="py-3 px-3 text-[10px] font-mono text-white/50">
                      <div>{asset.valuationSource}</div>
                      <div>{asset.valuationTimestamp.replace('T', ' ').substring(11, 19)} UTC</div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Interactive Collateral Substitution Simulator (Section 8 requirement) */}
      <div className="p-5 bg-[#0d121c] border border-white/10 rounded-lg space-y-4">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4 text-[#d4af37]" />
            <h2 className="text-sm font-bold text-white">Collateral Substitution Simulator</h2>
          </div>
          <span className="text-[11px] text-white/50">Verify Borrowing Base Integrity Prior to Pledge Exchange</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
          <div>
            <label className="text-white/60 block mb-1">Asset To Retire / Release</label>
            <select
              value={substitutionRetiringId}
              onChange={(e) => setSubstitutionRetiringId(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white outline-none cursor-pointer"
            >
              {collateral.map((a) => (
                <option key={a.id} value={a.id} className="bg-[#0f141c]">
                  {a.identifier} - {a.description.substring(0, 30)}...
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-white/60 block mb-1">Proposed Substitute Asset Class</label>
            <select
              value={substituteClass}
              onChange={(e) => setSubstituteClass(e.target.value as CollateralAsset['assetClass'])}
              className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white outline-none cursor-pointer"
            >
              <option value="US_TREASURY" className="bg-[#0f141c]">US Treasury (2.0% Haircut)</option>
              <option value="GERMAN_BUND" className="bg-[#0f141c]">German Bund (2.5% Haircut)</option>
              <option value="UK_GILT" className="bg-[#0f141c]">UK Gilt (3.5% Haircut)</option>
              <option value="AAA_COMMERCIAL_PAPER" className="bg-[#0f141c]">AAA Commercial Paper (12.0% Haircut)</option>
              <option value="CORP_BOND_IG" className="bg-[#0f141c]">IG Corporate Bond (15.0% Haircut)</option>
              <option value="TRADE_RECEIVABLES" className="bg-[#0f141c]">Trade Receivables (25.0% Haircut)</option>
            </select>
          </div>

          <div>
            <label className="text-white/60 block mb-1">Substitute Market Value ($)</label>
            <input
              type="number"
              value={substituteMarketValue}
              step={1_000_000}
              onChange={(e) => setSubstituteMarketValue(Number(e.target.value))}
              className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white font-mono outline-none tabular-nums"
            />
          </div>

          <div className="flex items-end">
            <button
              onClick={handleSimulateSubstitution}
              className="w-full px-4 py-2 bg-[#d4af37] hover:bg-[#e5c158] text-[#090d14] font-bold rounded cursor-pointer transition-colors"
            >
              Run Substitution Test
            </button>
          </div>
        </div>

        {/* Substitution Simulation Result */}
        {substitutionResult && (
          <div
            className={`p-4 rounded-lg border text-xs space-y-1 ${
              substitutionResult.isPermitted
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                : 'bg-red-950/40 border-red-500/40 text-red-200'
            }`}
          >
            <div className="font-bold text-sm flex items-center gap-2">
              {substitutionResult.isPermitted ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-red-400" />
              )}
              <span>{substitutionResult.isPermitted ? 'Substitution Permitted' : 'Substitution Denied'}</span>
            </div>
            <p className="mt-1">{substitutionResult.reason}</p>
          </div>
        )}
      </div>
    </div>
  );
};
