/**
 * RhinoQuant Terminal Top Bar
 * Adheres to the 3-Zone Top Bar Contract from the Frontend Design Constitution
 */

import React, { useState, useEffect } from 'react';
import { Shield, Activity, Clock, Terminal, AlertTriangle, Key } from 'lucide-react';
import { UserRole } from '../types';

interface HeaderProps {
  activeScreen: string;
  onNavigate: (screen: string) => void;
  onOpenNewRequest: () => void;
  onOpenDocs: () => void;
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  isCircuitBreakerActive: boolean;
  onToggleCircuitBreaker: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeScreen,
  onNavigate,
  onOpenNewRequest,
  onOpenDocs,
  currentRole,
  onRoleChange,
  isCircuitBreakerActive,
  onToggleCircuitBreaker
}) => {
  const [timeStr, setTimeStr] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toISOString().replace('T', ' ').substring(0, 19) + ' UTC'
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3 bg-[#080b10] border-b border-white/10 text-xs select-none">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3 whitespace-nowrap shrink-0">
        <div className="w-2.5 h-2.5 bg-[#d4af37] rotate-45 shrink-0" />
        <span className="font-bold tracking-wider text-base text-[#f5f5f7] uppercase">
          RhinoQuant <span className="text-[#d4af37] font-normal text-xs ml-1">Liquidity Engine</span>
        </span>
        <span className="text-white/40 hidden xl:inline">· Aureom.AI</span>
      </div>

      {/* Zone 2: 4-5 concise single-line text navigation links */}
      <nav className="hidden lg:flex items-center gap-6 text-[#9ca3af] font-medium">
        <button
          onClick={() => onNavigate('COMMAND_CENTRE')}
          className={`whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer ${
            activeScreen === 'COMMAND_CENTRE' ? 'text-[#d4af37] font-semibold border-b border-[#d4af37]' : ''
          }`}
        >
          Command Centre
        </button>
        <button
          onClick={() => onNavigate('LENDING_QUEUE')}
          className={`whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer ${
            activeScreen === 'LENDING_QUEUE' ? 'text-[#d4af37] font-semibold border-b border-[#d4af37]' : ''
          }`}
        >
          Lending Queue
        </button>
        <button
          onClick={() => onNavigate('FUNDING')}
          className={`whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer ${
            activeScreen === 'FUNDING' ? 'text-[#d4af37] font-semibold border-b border-[#d4af37]' : ''
          }`}
        >
          Funding & Allocations
        </button>
        <button
          onClick={() => onNavigate('PRICING')}
          className={`whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer ${
            activeScreen === 'PRICING' ? 'text-[#d4af37] font-semibold border-b border-[#d4af37]' : ''
          }`}
        >
          Pricing Engine
        </button>
        <button
          onClick={() => onNavigate('LEDGER')}
          className={`whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer ${
            activeScreen === 'LEDGER' ? 'text-[#d4af37] font-semibold border-b border-[#d4af37]' : ''
          }`}
        >
          Subledger
        </button>
        <button
          onClick={() => onNavigate('SIMULATION')}
          className={`whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer ${
            activeScreen === 'SIMULATION' ? 'text-[#d4af37] font-semibold border-b border-[#d4af37]' : ''
          }`}
        >
          Simulation Lab
        </button>
      </nav>

      {/* Zone 3: 1 primary action + institutional status */}
      <div className="flex items-center gap-4 shrink-0">
        {/* System Clock & Feed Status */}
        <div className="hidden sm:flex items-center gap-2 font-mono text-[11px] text-white/60">
          <Clock className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>{timeStr || '2026-11-10 06:40:00 UTC'}</span>
        </div>

        {/* Circuit Breaker Pill Indicator & Switch */}
        {isCircuitBreakerActive ? (
          <button
            onClick={onToggleCircuitBreaker}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-red-950/80 border border-red-500/60 text-red-300 font-semibold text-[11px] rounded transition-all hover:bg-red-900 cursor-pointer"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
            <span>CIRCUIT BREAKER ENGAGED</span>
          </button>
        ) : (
          <div className="hidden md:flex items-center gap-1 text-[11px] text-emerald-400 font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            <span>LCR NOMINAL</span>
          </div>
        )}

        {/* Role Selector */}
        <div className="flex items-center gap-1.5 bg-white/5 border border-white/10 px-2 py-1 rounded text-[11px]">
          <Shield className="w-3 h-3 text-[#d4af37]" />
          <select
            value={currentRole}
            onChange={(e) => onRoleChange(e.target.value as UserRole)}
            className="bg-transparent text-white/90 outline-none cursor-pointer"
          >
            <option value="HEAD_OF_LIQUIDITY" className="bg-[#0f141c]">Head of Liquidity</option>
            <option value="QUANTITATIVE_STRATEGIST" className="bg-[#0f141c]">Quant Strategist</option>
            <option value="SENIOR_RISK_OFFICER" className="bg-[#0f141c]">Senior Risk Officer</option>
            <option value="CREDIT_ANALYST" className="bg-[#0f141c]">Credit Analyst</option>
            <option value="COMPLIANCE_AUDITOR" className="bg-[#0f141c]">Compliance Auditor</option>
          </select>
        </div>

        {/* Primary Action Button */}
        <button
          onClick={onOpenNewRequest}
          className="px-3.5 py-1.5 text-xs font-semibold text-[#090d14] bg-[#d4af37] hover:bg-[#e5c158] rounded transition-all whitespace-nowrap shrink-0 shadow-sm cursor-pointer"
        >
          + Drawdown Request
        </button>
      </div>
    </header>
  );
};
