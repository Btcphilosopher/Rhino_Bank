/**
 * RhinoQuant Lending Queue & Decision Review
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Implements high-frequency lending decision inspection, explicit terms acceptance,
 * reservation management, disbursement triggering, and repayment simulation.
 */

import React, { useState } from 'react';
import {
  CheckCircle,
  Clock,
  ExternalLink,
  FileText,
  Filter,
  Play,
  Search,
  ShieldCheck,
  XCircle,
  AlertCircle
} from 'lucide-react';
import {
  Counterparty,
  Facility,
  FundingRequest,
  LoanLifecycleStatus,
  ProductType
} from '../types';

interface LendingQueueProps {
  requests: FundingRequest[];
  counterparties: Counterparty[];
  facilities: Facility[];
  onSelectRequest: (request: FundingRequest) => void;
  onAcceptTerms: (requestId: string) => void;
  onDisburseLoan: (requestId: string) => void;
  onRepayLoan: (requestId: string) => void;
  onManualApprove: (requestId: string) => void;
}

export const LendingQueue: React.FC<LendingQueueProps> = ({
  requests,
  counterparties,
  facilities,
  onSelectRequest,
  onAcceptTerms,
  onDisburseLoan,
  onRepayLoan,
  onManualApprove
}) => {
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterProduct, setFilterProduct] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const cpMap = new Map(counterparties.map((c) => [c.id, c]));
  const facMap = new Map(facilities.map((f) => [f.id, f]));

  const filteredRequests = requests.filter((r) => {
    if (filterStatus !== 'ALL' && r.status !== filterStatus && r.decisionStatus !== filterStatus) return false;
    if (filterProduct !== 'ALL' && r.productType !== filterProduct) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const cp = cpMap.get(r.borrowerId);
      const matchId = r.id.toLowerCase().includes(q);
      const matchName = cp?.name.toLowerCase().includes(q) || false;
      const matchIdemp = r.idempotencyKey.toLowerCase().includes(q);
      if (!matchId && !matchName && !matchIdemp) return false;
    }
    return true;
  });

  return (
    <div className="space-y-5">
      {/* View Header with Filters and Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 bg-[#0d121c] border border-white/10 rounded-lg">
        <div>
          <h1 className="text-base font-bold text-white tracking-wide">High-Frequency Lending Queue</h1>
          <p className="text-xs text-white/50">
            Real-time event evaluation, transparent policy enforcement, and execution controls
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-white/40" />
            <input
              type="text"
              placeholder="Search request, CP, or idempotency..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-white/5 border border-white/10 rounded pl-8 pr-3 py-1.5 text-white placeholder-white/30 text-xs outline-none focus:border-[#d4af37]"
            />
          </div>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-white/5 border border-white/10 rounded px-2.5 py-1.5 text-white text-xs outline-none cursor-pointer"
          >
            <option value="ALL" className="bg-[#0f141c]">All Decisions / States</option>
            <option value="APPROVED" className="bg-[#0f141c]">Approved</option>
            <option value="QUOTED" className="bg-[#0f141c]">Quoted</option>
            <option value="FUNDING_RESERVED" className="bg-[#0f141c]">Funding Reserved</option>
            <option value="OUTSTANDING" className="bg-[#0f141c]">Outstanding</option>
            <option value="REPAID" className="bg-[#0f141c]">Repaid</option>
            <option value="QUEUED" className="bg-[#0f141c]">Queued</option>
            <option value="REFERRED" className="bg-[#0f141c]">Referred</option>
            <option value="DISPUTED" className="bg-[#0f141c]">Disputed</option>
            <option value="OVERDUE" className="bg-[#0f141c]">Overdue</option>
          </select>

          {/* Product Filter */}
          <select
            value={filterProduct}
            onChange={(e) => setFilterProduct(e.target.value)}
            className="bg-white/5 border border-white/10 rounded px-2.5 py-1.5 text-white text-xs outline-none cursor-pointer"
          >
            <option value="ALL" className="bg-[#0f141c]">All Products</option>
            <option value="INTRADAY_ADVANCE" className="bg-[#0f141c]">Intraday Advance</option>
            <option value="OVERNIGHT_LOAN" className="bg-[#0f141c]">Overnight Loan</option>
            <option value="SHORT_TERM_REVOLVER" className="bg-[#0f141c]">Short-Term Revolver</option>
            <option value="RECEIVABLES_BACKED" className="bg-[#0f141c]">Receivables-Backed</option>
            <option value="SECURED_WORKING_CAPITAL" className="bg-[#0f141c]">Secured Working Capital</option>
            <option value="INTERBANK_LENDING" className="bg-[#0f141c]">Interbank Lending</option>
            <option value="INTERNAL_TREASURY_ALLOCATION" className="bg-[#0f141c]">Internal Treasury</option>
          </select>
        </div>
      </div>

      {/* Main High-Density Table */}
      <div className="bg-[#0d121c] border border-white/10 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-[10px] text-white/40 uppercase bg-white/5 border-b border-white/10 select-none">
              <tr>
                <th className="py-2.5 px-3">Request ID & Timestamp</th>
                <th className="py-2.5 px-3">Borrower & LEI</th>
                <th className="py-2.5 px-3">Product / Currency</th>
                <th className="py-2.5 px-3 text-right">Requested / Approved</th>
                <th className="py-2.5 px-3">Tenor</th>
                <th className="py-2.5 px-3">Automated Decision</th>
                <th className="py-2.5 px-3">Lifecycle State</th>
                <th className="py-2.5 px-3">Quoted APR</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredRequests.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-white/40">
                    No funding requests match the selected filters.
                  </td>
                </tr>
              ) : (
                filteredRequests.map((req) => {
                  const cp = cpMap.get(req.borrowerId);
                  const fac = facMap.get(req.facilityId);
                  const isApproved = req.decisionStatus === 'APPROVED' || req.decisionStatus === 'PARTIALLY_APPROVED';

                  return (
                    <tr key={req.id} className="hover:bg-white/5 transition-colors group">
                      {/* Request ID & Timestamp */}
                      <td className="py-3 px-3">
                        <div className="font-mono font-medium text-white">{req.id}</div>
                        <div className="text-[10px] font-mono text-white/40 mt-0.5">
                          {req.submittedAt.replace('T', ' ').substring(11, 19)} UTC · {req.policyVersion}
                        </div>
                      </td>

                      {/* Borrower & Group */}
                      <td className="py-3 px-3">
                        <div className="font-semibold text-white/90">{cp?.name || req.borrowerId}</div>
                        <div className="text-[10px] text-white/40 truncate max-w-[140px]">
                          {cp?.corporateGroupName}
                        </div>
                      </td>

                      {/* Product */}
                      <td className="py-3 px-3">
                        <div className="text-white/80">{req.productType.replace(/_/g, ' ')}</div>
                        <div className="text-[10px] font-mono text-[#d4af37]">{req.currency}</div>
                      </td>

                      {/* Amounts */}
                      <td className="py-3 px-3 text-right">
                        <div className="font-mono font-bold text-white tabular-nums">
                          {req.currency} {(req.requestedAmount / 1_000_000).toFixed(2)}M
                        </div>
                        {req.approvedAmount && req.approvedAmount !== req.requestedAmount && (
                          <div className="text-[10px] font-mono text-amber-400 tabular-nums">
                            Appr: {req.currency} {(req.approvedAmount / 1_000_000).toFixed(2)}M
                          </div>
                        )}
                      </td>

                      {/* Tenor */}
                      <td className="py-3 px-3 font-mono text-white/70">
                        {req.tenorHours}h
                      </td>

                      {/* Decision */}
                      <td className="py-3 px-3">
                        <span
                          className={`font-semibold text-[11px] px-2 py-0.5 rounded border inline-block ${
                            req.decisionStatus === 'APPROVED'
                              ? 'text-emerald-300 bg-emerald-950/50 border-emerald-500/30'
                              : req.decisionStatus === 'PARTIALLY_APPROVED'
                              ? 'text-amber-300 bg-amber-950/50 border-amber-500/30'
                              : req.decisionStatus === 'QUEUED'
                              ? 'text-cyan-300 bg-cyan-950/50 border-cyan-500/30'
                              : req.decisionStatus === 'REFERRED'
                              ? 'text-purple-300 bg-purple-950/50 border-purple-500/30'
                              : 'text-red-300 bg-red-950/50 border-red-500/30'
                          }`}
                        >
                          {req.decisionStatus}
                        </span>
                      </td>

                      {/* Lifecycle State */}
                      <td className="py-3 px-3">
                        <div className="font-mono text-[11px] text-white/90 font-medium">
                          {req.status}
                        </div>
                        {req.allocatedByStrategy && (
                          <div className="text-[9px] text-[#d4af37]/80">
                            {req.allocatedByStrategy.replace(/_/g, ' ')}
                          </div>
                        )}
                      </td>

                      {/* Quoted Rate */}
                      <td className="py-3 px-3">
                        {req.pricingQuote ? (
                          <div>
                            <span className="font-mono font-bold text-emerald-400 tabular-nums">
                              {(req.pricingQuote.totalQuotedAnnualizedRate * 100).toFixed(2)}%
                            </span>
                            <div className="text-[10px] text-white/40 font-mono">
                              {req.pricingQuote.referenceSource.split(' ')[0]} + {req.pricingQuote.creditSpreadBps + req.pricingQuote.targetMarginBps}bps
                            </div>
                          </div>
                        ) : (
                          <span className="text-white/30 text-[11px]">—</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Terms Acceptance Action */}
                          {req.status === 'QUOTED' && (
                            <button
                              onClick={() => onAcceptTerms(req.id)}
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-semibold rounded cursor-pointer transition-colors"
                              title="Counterparty executes digital acceptance of quoted rate and covenants"
                            >
                              Accept Terms
                            </button>
                          )}

                          {/* Disbursement Action (after terms accepted or funding reserved) */}
                          {(req.status === 'ACCEPTED' || req.status === 'FUNDING_RESERVED') && (
                            <button
                              onClick={() => onDisburseLoan(req.id)}
                              className="px-2 py-1 bg-[#d4af37] hover:bg-[#e5c158] text-[#090d14] text-[11px] font-bold rounded cursor-pointer transition-colors"
                              title="Commit cash via Fedwire/Target2 and post balanced journal entries"
                            >
                              Disburse
                            </button>
                          )}

                          {/* Repayment Action (if outstanding or overdue) */}
                          {(req.status === 'OUTSTANDING' || req.status === 'OVERDUE') && (
                            <button
                              onClick={() => onRepayLoan(req.id)}
                              className="px-2 py-1 bg-cyan-600/80 hover:bg-cyan-500 text-white text-[11px] font-semibold rounded cursor-pointer transition-colors"
                              title="Simulate incoming settlement wire and reconcile double-entry subledger"
                            >
                              Repay Wire
                            </button>
                          )}

                          {/* Manual Referral Action */}
                          {req.decisionStatus === 'REFERRED' && (
                            <button
                              onClick={() => onManualApprove(req.id)}
                              className="px-2 py-1 bg-purple-700 hover:bg-purple-600 text-white text-[11px] font-semibold rounded cursor-pointer transition-colors"
                              title="Credit Analyst manual override approval"
                            >
                              Maker Approve
                            </button>
                          )}

                          {/* Inspect Button */}
                          <button
                            onClick={() => onSelectRequest(req)}
                            className="px-2 py-1 bg-white/10 hover:bg-white/20 text-white text-[11px] rounded cursor-pointer transition-colors"
                          >
                            Inspect
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
