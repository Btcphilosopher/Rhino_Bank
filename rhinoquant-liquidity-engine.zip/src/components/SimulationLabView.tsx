/**
 * RhinoQuant Simulation Lab & Scenario Runner View
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Implements 1-click execution for all 10 prompt-required institutional simulation scenarios,
 * an interactive execution terminal, and automated policy stress comparisons.
 */

import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Clock,
  Cpu,
  Layers,
  Play,
  RefreshCw,
  Sliders,
  Terminal,
  Zap
} from 'lucide-react';
import {
  CollateralAsset,
  Counterparty,
  Facility,
  FundingRequest,
  LedgerJournalEntry,
  LiquidityPoolStatus
} from '../types';
import { executeScenario, SIMULATION_SCENARIOS, ScenarioRunResult } from '../engine/simulation';

interface SimulationLabViewProps {
  requests: FundingRequest[];
  facilities: Facility[];
  counterparties: Counterparty[];
  collateral: CollateralAsset[];
  liquidityPool: LiquidityPoolStatus;
  ledgerEntries: LedgerJournalEntry[];
  onApplyScenarioResult: (result: ScenarioRunResult) => void;
  onResetToSeed: () => void;
}

export const SimulationLabView: React.FC<SimulationLabViewProps> = ({
  requests,
  facilities,
  counterparties,
  collateral,
  liquidityPool,
  ledgerEntries,
  onApplyScenarioResult,
  onResetToSeed
}) => {
  const [activeScenarioId, setActiveScenarioId] = useState<string>('SCENARIO-01');
  const [executionLogs, setExecutionLogs] = useState<string[]>([
    `[${new Date().toISOString().substring(11, 19)} UTC] Simulation Lab initialized. Ready to execute 10 institutional scenarios.`,
    `[${new Date().toISOString().substring(11, 19)} UTC] Authoritative balanced subledger and real-time limits engine mounted.`
  ]);
  const [isExecuting, setIsExecuting] = useState<boolean>(false);

  const handleRunScenario = (scenId: string) => {
    setActiveScenarioId(scenId);
    setIsExecuting(true);

    setTimeout(() => {
      const result = executeScenario({
        scenarioId: scenId,
        requests,
        facilities,
        counterparties,
        collateral,
        liquidityPool,
        ledgerEntries
      });

      setExecutionLogs((prev) => [...result.logs, ...prev]);
      onApplyScenarioResult(result);
      setIsExecuting(false);
    }, 250);
  };

  const handleRunAllBatch = () => {
    setIsExecuting(true);
    let curReqs = requests;
    let curFacs = facilities;
    let curCol = collateral;
    let curPool = liquidityPool;
    let curEntries = ledgerEntries;

    const allLogs: string[] = [`[${new Date().toISOString().substring(11, 19)} UTC] Starting full batch execution of all 10 scenarios...`];

    SIMULATION_SCENARIOS.forEach((scen) => {
      const res = executeScenario({
        scenarioId: scen.id,
        requests: curReqs,
        facilities: curFacs,
        counterparties,
        collateral: curCol,
        liquidityPool: curPool,
        ledgerEntries: curEntries
      });
      curReqs = res.updatedRequests;
      curFacs = res.updatedFacilities;
      curCol = res.updatedCollateral;
      curPool = res.updatedLiquidityPool;
      curEntries = res.updatedLedgerEntries;
      allLogs.push(...res.logs);
      onApplyScenarioResult(res);
    });

    setExecutionLogs((prev) => [...allLogs, ...prev]);
    setIsExecuting(false);
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-white tracking-wide">
            Institutional Simulation Lab (10 Mandatory Scenarios)
          </h1>
          <p className="text-xs text-white/50">
            Automated test harness for concurrency, collateral limits, quote timeouts, and payment settlement exceptions
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onResetToSeed}
            className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-white border border-white/10 rounded text-xs cursor-pointer transition-colors"
          >
            Reset Seed State
          </button>
          <button
            onClick={handleRunAllBatch}
            disabled={isExecuting}
            className="px-4 py-1.5 bg-[#d4af37] hover:bg-[#e5c158] text-[#090d14] font-bold rounded text-xs cursor-pointer transition-colors shadow-sm disabled:opacity-50"
          >
            {isExecuting ? 'Simulating...' : '▶ Run All 10 Scenarios (Batch)'}
          </button>
        </div>
      </div>

      {/* Grid: 10 Scenarios Selector (Left) + Real-Time Execution Console (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Scenarios List (7 Cols) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between text-xs text-white/60 px-1">
            <span>Institutional Test Scenarios</span>
            <span>1-Click Trigger</span>
          </div>

          <div className="space-y-2">
            {SIMULATION_SCENARIOS.map((scen) => {
              const isActive = activeScenarioId === scen.id;
              return (
                <div
                  key={scen.id}
                  className={`p-3.5 rounded-lg border transition-all text-xs ${
                    isActive
                      ? 'bg-white/10 border-[#d4af37]'
                      : 'bg-[#0d121c] border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-[#d4af37]">
                        #{scen.scenarioNumber.toString().padStart(2, '0')}
                      </span>
                      <span className="font-semibold text-white">{scen.title}</span>
                      <span className="text-[9px] font-mono bg-white/5 text-white/50 px-1.5 py-0.5 rounded">
                        {scen.category}
                      </span>
                    </div>

                    <button
                      onClick={() => handleRunScenario(scen.id)}
                      disabled={isExecuting}
                      className="px-2.5 py-1 bg-white/10 hover:bg-[#d4af37] hover:text-[#090d14] text-white font-medium rounded text-[11px] cursor-pointer transition-colors"
                    >
                      Execute
                    </button>
                  </div>

                  <p className="text-white/70 text-[11px] mt-1.5">{scen.summary}</p>
                  <div className="text-[10px] text-emerald-400/90 font-mono mt-1">
                    Expected: {scen.expectedOutcome}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Real-Time Execution Terminal (5 Cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between text-xs text-white/60 px-1">
            <span className="flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-[#d4af37]" />
              Simulation Engine Audit Terminal
            </span>
            <button
              onClick={() => setExecutionLogs([])}
              className="text-[10px] text-white/40 hover:text-white cursor-pointer"
            >
              Clear Logs
            </button>
          </div>

          <div className="p-4 bg-[#070a0f] border border-white/15 rounded-lg h-[640px] overflow-y-auto font-mono text-[11px] space-y-1.5 text-white/80 select-text">
            {executionLogs.map((log, index) => {
              const isHighlight = log.includes('>>>') || log.includes('BALANCED');
              const isAlert = log.includes('CIRCUIT') || log.includes('timeout') || log.includes('DECLINED');

              return (
                <div
                  key={index}
                  className={`leading-relaxed ${
                    isAlert
                      ? 'text-red-400 font-semibold'
                      : isHighlight
                      ? 'text-[#d4af37] font-semibold'
                      : 'text-white/80'
                  }`}
                >
                  {log}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
