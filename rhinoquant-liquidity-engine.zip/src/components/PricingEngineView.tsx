/**
 * RhinoQuant Transparent Pricing Engine View
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Implements interactive component pricing explorer, live benchmark curves,
 * day-count convention calculators (ACT/360 & ACT/365), and cashflow schedules.
 */

import React, { useState } from 'react';
import {
  Calculator,
  Clock,
  DollarSign,
  HelpCircle,
  Percent,
  RefreshCw,
  Sparkles,
  TrendingUp
} from 'lucide-react';
import { Counterparty, Currency, ProductType } from '../types';
import { calculateQuote, CURRENT_PRICING_BENCHMARKS } from '../engine/pricing';

interface PricingEngineViewProps {
  counterparties: Counterparty[];
}

export const PricingEngineView: React.FC<PricingEngineViewProps> = ({ counterparties }) => {
  const [selectedCpId, setSelectedCpId] = useState<string>(counterparties[0]?.id || 'CP-APEX-01');
  const [principal, setPrincipal] = useState<number>(20_000_000);
  const [currency, setCurrency] = useState<Currency>('USD');
  const [tenorHours, setTenorHours] = useState<number>(24);
  const [productType, setProductType] = useState<ProductType>('OVERNIGHT_LOAN');
  const [simulatedPoolUtil, setSimulatedPoolUtil] = useState<number>(0.55);

  const selectedCp = counterparties.find((c) => c.id === selectedCpId) || counterparties[0];

  const quote = calculateQuote({
    counterparty: selectedCp,
    productType,
    currency,
    principal,
    tenorHours,
    poolUtilizationPct: simulatedPoolUtil
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-white tracking-wide">
            Quantitative Pricing Engine & Curve Benchmarks
          </h1>
          <p className="text-xs text-white/50">
            Decomposed 7-component institutional quote framework with cash-flow schedule verification
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-[11px] text-white/60">
          <Clock className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>Policy RQ-POL-2026.4.1 · Updated Real-Time</span>
        </div>
      </div>

      {/* Live Benchmark Curves Card Strip */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { name: 'NY Fed SOFR', rate: '4.82%', src: 'NY Fed 08:00 EST', age: '12m ago', ccy: 'USD' },
          { name: 'ECB €STR', rate: '3.65%', src: 'ECB Fixing 07:00 CET', age: '28m ago', ccy: 'EUR' },
          { name: 'BoE SONIA', rate: '5.15%', src: 'Bank of England 09:00 GMT', age: '15m ago', ccy: 'GBP' },
          { name: 'Internal ALM Curve', rate: '4.70%', src: 'RhinoBank Treasury Desk', age: '5m ago', ccy: 'USD' }
        ].map((bench) => (
          <div key={bench.name} className="p-4 bg-[#0d121c] border border-white/10 rounded-lg space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-white/90">{bench.name}</span>
              <span className="font-mono text-[10px] text-[#d4af37] bg-[#d4af37]/10 px-1.5 py-0.5 rounded">
                {bench.ccy}
              </span>
            </div>
            <div className="text-2xl font-bold font-mono text-white tabular-nums">{bench.rate}</div>
            <div className="flex justify-between text-[10px] text-white/40 font-mono pt-1 border-t border-white/5">
              <span>{bench.src}</span>
              <span>{bench.age}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Interactive Pricing Workbench */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Interactive Input Controls */}
        <div className="p-5 bg-[#0d121c] border border-white/10 rounded-lg space-y-4">
          <div className="flex items-center gap-2 border-b border-white/10 pb-3">
            <Calculator className="w-4 h-4 text-[#d4af37]" />
            <h2 className="text-sm font-bold text-white">Interactive Quote Calculator</h2>
          </div>

          <div className="space-y-3 text-xs">
            {/* Borrower Selection */}
            <div>
              <label className="text-white/60 block mb-1">Counterparty Borrower</label>
              <select
                value={selectedCpId}
                onChange={(e) => setSelectedCpId(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white outline-none cursor-pointer"
              >
                {counterparties.map((cp) => (
                  <option key={cp.id} value={cp.id} className="bg-[#0f141c]">
                    {cp.name} ({cp.creditRating}) {cp.isInternal ? '[INTERNAL]' : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Principal Input */}
            <div>
              <label className="text-white/60 block mb-1">Loan Principal Amount</label>
              <div className="flex items-center gap-2">
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as Currency)}
                  className="bg-white/5 border border-white/10 rounded px-2.5 py-2 text-[#d4af37] font-mono outline-none cursor-pointer"
                >
                  <option value="USD" className="bg-[#0f141c]">USD</option>
                  <option value="EUR" className="bg-[#0f141c]">EUR</option>
                  <option value="GBP" className="bg-[#0f141c]">GBP</option>
                </select>
                <input
                  type="number"
                  value={principal}
                  step={1_000_000}
                  onChange={(e) => setPrincipal(Math.max(100_000, Number(e.target.value)))}
                  className="flex-1 bg-white/5 border border-white/10 rounded px-3 py-2 text-white font-mono font-bold outline-none tabular-nums"
                />
              </div>
            </div>

            {/* Product Type */}
            <div>
              <label className="text-white/60 block mb-1">Financing Product</label>
              <select
                value={productType}
                onChange={(e) => setProductType(e.target.value as ProductType)}
                className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white outline-none cursor-pointer"
              >
                <option value="INTRADAY_ADVANCE" className="bg-[#0f141c]">Intraday Liquidity Advance</option>
                <option value="OVERNIGHT_LOAN" className="bg-[#0f141c]">Overnight Loan Facility</option>
                <option value="SHORT_TERM_REVOLVER" className="bg-[#0f141c]">Short-Term Revolver</option>
                <option value="RECEIVABLES_BACKED" className="bg-[#0f141c]">Receivables-Backed Advance</option>
                <option value="SECURED_WORKING_CAPITAL" className="bg-[#0f141c]">Secured Working Capital</option>
                <option value="INTERBANK_LENDING" className="bg-[#0f141c]">Interbank Lending</option>
                <option value="INTERNAL_TREASURY_ALLOCATION" className="bg-[#0f141c]">Internal Treasury Allocation</option>
              </select>
            </div>

            {/* Tenor Hours */}
            <div>
              <div className="flex justify-between mb-1">
                <label className="text-white/60">Duration / Tenor: {tenorHours} Hours</label>
                <span className="font-mono text-white/40">
                  {tenorHours <= 24 ? `${tenorHours}h` : `${(tenorHours / 24).toFixed(1)} days`}
                </span>
              </div>
              <input
                type="range"
                min="2"
                max="720"
                step="2"
                value={tenorHours}
                onChange={(e) => setTenorHours(Number(e.target.value))}
                className="w-full accent-[#d4af37] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-white/30 font-mono mt-1">
                <span>2h (Intraday)</span>
                <span>24h (Overnight)</span>
                <span>168h (7d)</span>
                <span>720h (30d)</span>
              </div>
            </div>

            {/* Pool Scarcity Slider */}
            <div>
              <div className="flex justify-between mb-1">
                <label className="text-white/60">Simulated Pool Scarcity: {(simulatedPoolUtil * 100).toFixed(0)}%</label>
                <span className="font-mono text-[#d4af37]">+{quote.liquidityAdjustmentBps} bps</span>
              </div>
              <input
                type="range"
                min="0.10"
                max="0.95"
                step="0.05"
                value={simulatedPoolUtil}
                onChange={(e) => setSimulatedPoolUtil(Number(e.target.value))}
                className="w-full accent-[#d4af37] cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Right 2 Columns: Transparent 7-Component Decomposed Rate & Cash Flow */}
        <div className="lg:col-span-2 p-5 bg-[#0d121c] border border-white/10 rounded-lg space-y-5">
          {/* Top Result Banner */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-white/5 rounded-lg border border-white/10 gap-3">
            <div>
              <span className="text-[10px] text-white/40 uppercase tracking-wider block">Quoted Annualised Rate</span>
              <div className="text-3xl font-mono font-bold text-emerald-400 tabular-nums">
                {(quote.totalQuotedAnnualizedRate * 100).toFixed(2)}% <span className="text-xs text-white/40 font-normal">APR</span>
              </div>
              <span className="text-[11px] text-white/60 font-mono">
                Convention: {quote.dayCountConvention} · Day Divisor: {quote.dayCountConvention === 'ACT/365' ? '365' : '360'}
              </span>
            </div>

            <div className="sm:text-right border-t sm:border-t-0 pt-2 sm:pt-0 border-white/10">
              <span className="text-[10px] text-white/40 uppercase tracking-wider block">Actual Term Interest</span>
              <div className="text-xl font-mono font-bold text-white tabular-nums">
                {currency} {quote.estimatedInterestAmount.toLocaleString()}
              </div>
              <span className="text-[11px] font-mono text-[#d4af37]">
                + {currency} {quote.facilityDrawdownFee.toLocaleString()} Drawdown Fee
              </span>
            </div>
          </div>

          {/* 7 Component Step-by-Step Waterfall */}
          <div className="space-y-2 text-xs">
            <span className="font-bold text-white tracking-wide text-xs block">
              Transparent Pricing Component Waterfall:
            </span>

            <div className="space-y-1.5 font-mono">
              <div className="flex justify-between p-2 bg-white/5 rounded">
                <span className="text-white/80">1. Reference Funding Rate ({quote.referenceSource})</span>
                <span className="text-white tabular-nums">{(quote.referenceFundingRate * 100).toFixed(2)}%</span>
              </div>

              <div className="flex justify-between p-2 bg-white/5 rounded">
                <span className="text-white/80">2. Tenor Adjustment ({quote.tenorHours}h duration)</span>
                <span className="text-white tabular-nums">{quote.tenorAdjustmentBps >= 0 ? '+' : ''}{quote.tenorAdjustmentBps} bps</span>
              </div>

              <div className="flex justify-between p-2 bg-white/5 rounded">
                <span className="text-white/80">3. Counterparty Credit Spread (Rating: {selectedCp.creditRating})</span>
                <span className="text-white tabular-nums">+{quote.creditSpreadBps} bps</span>
              </div>

              <div className="flex justify-between p-2 bg-white/5 rounded">
                <span className="text-white/80">4. Dynamic Liquidity Scarcity Adjustment ({(simulatedPoolUtil * 100).toFixed(0)}% utilized)</span>
                <span className="text-white tabular-nums">+{quote.liquidityAdjustmentBps} bps</span>
              </div>

              <div className="flex justify-between p-2 bg-white/5 rounded">
                <span className="text-white/80">5. Capital-Cost Allocation (Basel Standardized RWA)</span>
                <span className="text-white tabular-nums">+{quote.capitalCostAllocationBps} bps</span>
              </div>

              <div className="flex justify-between p-2 bg-white/5 rounded">
                <span className="text-white/80">6. Operating & Clearing Cost Allocation</span>
                <span className="text-white tabular-nums">+{quote.operatingCostAllocationBps} bps</span>
              </div>

              <div className="flex justify-between p-2 bg-white/5 rounded border border-[#d4af37]/30">
                <span className="text-[#d4af37] font-semibold">7. Target Hurdle Margin (RhinoQuant Spread)</span>
                <span className="text-[#d4af37] font-bold tabular-nums">+{quote.targetMarginBps} bps</span>
              </div>
            </div>
          </div>

          {/* Cashflow Schedule Table */}
          <div className="border-t border-white/10 pt-4 space-y-2">
            <span className="font-bold text-white text-xs block">Contractual Cashflow Schedule</span>
            <div className="grid grid-cols-3 gap-2 text-xs font-mono">
              <div className="p-2.5 bg-white/5 rounded">
                <span className="text-[10px] text-white/40 block">T+0 Disbursement</span>
                <span className="text-emerald-400 font-bold">
                  +{currency} {principal.toLocaleString()}
                </span>
              </div>
              <div className="p-2.5 bg-white/5 rounded">
                <span className="text-[10px] text-white/40 block">T+0 Upfront Fee</span>
                <span className="text-amber-400 font-bold">
                  -{currency} {quote.facilityDrawdownFee.toLocaleString()}
                </span>
              </div>
              <div className="p-2.5 bg-white/5 rounded">
                <span className="text-[10px] text-white/40 block">T+{tenorHours}h Final Maturity</span>
                <span className="text-white font-bold">
                  -{currency} {(principal + quote.estimatedInterestAmount).toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
