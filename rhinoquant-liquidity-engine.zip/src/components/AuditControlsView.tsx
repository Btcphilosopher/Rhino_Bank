/**
 * RhinoQuant Security, Operating Controls & Maker-Checker Queue
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Implements dual-authorization (Maker-Checker), role-based privilege checks,
 * global and product-level circuit breakers, and immutable audit logs.
 */

import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  FileCheck,
  Lock,
  Pause,
  Play,
  Shield,
  ShieldAlert,
  UserCheck,
  XCircle
} from 'lucide-react';
import { MakerCheckerItem, ProductType, UserRole } from '../types';

interface AuditControlsViewProps {
  currentRole: UserRole;
  isCircuitBreakerActive: boolean;
  onToggleCircuitBreaker: () => void;
  pausedProducts: ProductType[];
  onToggleProductPause: (product: ProductType) => void;
  makerCheckerItems: MakerCheckerItem[];
  onApproveMakerChecker: (itemId: string) => void;
  onRejectMakerChecker: (itemId: string) => void;
}

export const AuditControlsView: React.FC<AuditControlsViewProps> = ({
  currentRole,
  isCircuitBreakerActive,
  onToggleCircuitBreaker,
  pausedProducts,
  onToggleProductPause,
  makerCheckerItems,
  onApproveMakerChecker,
  onRejectMakerChecker
}) => {
  // Pre-seeded cryptographic audit logs
  const auditLogs = [
    {
      id: 'AUD-009182',
      timestamp: '2026-11-10 06:33:15 UTC',
      actor: 'System / Automated Engine (Aureom.AI)',
      action: 'LOAN_EXECUTION_DISBURSEMENT',
      details: 'Disbursed $25M Overnight loan to Meridian Global Trust following terms acceptance',
      hash: 'SHA256:91ca0298be34018281928019ab921938'
    },
    {
      id: 'AUD-009181',
      timestamp: '2026-11-10 06:31:00 UTC',
      actor: 'Counterparty (Apex Clearing AG)',
      action: 'DIGITAL_TERMS_ACCEPTANCE',
      details: 'Executed cryptographic acceptance of 4.24% APR quote on €15M Intraday advance',
      hash: 'SHA256:39ac2019b884d90182ecab0918482cfa'
    },
    {
      id: 'AUD-009180',
      timestamp: '2026-11-10 06:05:00 UTC',
      actor: 'Senior Risk Officer (Elena Rostova)',
      action: 'MAKER_CHECKER_APPROVAL',
      details: 'Approved temporary +$10M facility headroom override for Apex Clearing AG',
      hash: 'SHA256:7b8192a01948cb1209e847123aa1289c'
    },
    {
      id: 'AUD-009179',
      timestamp: '2026-11-10 06:00:00 UTC',
      actor: 'Head of Liquidity (Julian Thorne)',
      action: 'CAPITAL_ALLOCATION_AUTHORIZED',
      details: 'Mounted $500M central bank nostro liquidity pool and $60M regulatory LCR floor',
      hash: 'SHA256:d8a9e01f5c3a28b02931818c7e990182'
    }
  ];

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-white tracking-wide">
            Operating Controls, Maker-Checker & Governance
          </h1>
          <p className="text-xs text-white/50">
            Dual-authorization governance, role-based overrides, and immutable compliance audit trail
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-white/60">Current Session Identity:</span>
          <span className="text-xs font-mono font-bold text-[#d4af37] bg-[#d4af37]/10 px-2 py-1 rounded border border-[#d4af37]/20">
            {currentRole.replace(/_/g, ' ')}
          </span>
        </div>
      </div>

      {/* Maker-Checker Approval Queue */}
      <div className="bg-[#0d121c] border border-white/10 rounded-lg overflow-hidden">
        <div className="p-4 bg-white/5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <UserCheck className="w-4 h-4 text-[#d4af37]" />
            <h2 className="text-sm font-bold text-white">Dual-Authorization (Maker-Checker) Queue</h2>
          </div>
          <span className="text-[11px] text-white/50 font-mono">
            Requires 2 Distinct Authorized Officers for Material Changes
          </span>
        </div>

        <div className="divide-y divide-white/5 p-4 space-y-3">
          {makerCheckerItems.map((item) => (
            <div
              key={item.id}
              className="p-3.5 bg-white/5 rounded-lg border border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
            >
              <div className="space-y-1 max-w-xl">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-white">{item.id}</span>
                  <span className="text-[10px] font-mono text-[#d4af37] bg-[#d4af37]/10 px-1.5 py-0.5 rounded">
                    {item.changeType}
                  </span>
                  <span
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                      item.status === 'APPROVED'
                        ? 'text-emerald-300 bg-emerald-950/60'
                        : 'text-amber-300 bg-amber-950/60'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>
                <p className="text-white/90 font-medium">{item.details}</p>
                <div className="text-[10px] text-white/40 font-mono">
                  Initiated by: {item.initiatedBy} · {item.initiatedAt.replace('T', ' ').substring(0, 19)} UTC
                  {item.approvedBy && ` · Approved by: ${item.approvedBy}`}
                </div>
              </div>

              {item.status === 'PENDING_APPROVAL' && (
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => onApproveMakerChecker(item.id)}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded cursor-pointer transition-colors"
                  >
                    Authorize (Checker)
                  </button>
                  <button
                    onClick={() => onRejectMakerChecker(item.id)}
                    className="px-3 py-1.5 bg-red-800 hover:bg-red-700 text-white font-semibold text-xs rounded cursor-pointer transition-colors"
                  >
                    Reject
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Circuit Breakers & Product Pauses */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Global Circuit Breaker Panel */}
        <div className="p-5 bg-[#0d121c] border border-white/10 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-red-400" />
              <h2 className="text-sm font-bold text-white">Global Emergency Liquidity Breaker</h2>
            </div>
            <span
              className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                isCircuitBreakerActive ? 'bg-red-950 text-red-300 border border-red-500/50' : 'bg-emerald-950 text-emerald-300'
              }`}
            >
              {isCircuitBreakerActive ? 'TRIPPED' : 'ARMED / NOMINAL'}
            </span>
          </div>

          <p className="text-xs text-white/70 leading-relaxed">
            Immediately halts automated drawdowns, freezes pending reservations, and blocks new quotes across all counterparties. Triggered automatically if uncommitted cash drops below the $60M regulatory LCR floor.
          </p>

          <button
            onClick={onToggleCircuitBreaker}
            className={`w-full py-2.5 rounded font-bold text-xs cursor-pointer transition-colors ${
              isCircuitBreakerActive
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                : 'bg-red-900/80 hover:bg-red-800 text-white border border-red-500/50'
            }`}
          >
            {isCircuitBreakerActive ? 'Authorize Emergency Breaker Reset' : 'Engage Emergency Circuit Breaker'}
          </button>
        </div>

        {/* Product Line Controls */}
        <div className="p-5 bg-[#0d121c] border border-white/10 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <h2 className="text-sm font-bold text-white">Granular Product Suspensions</h2>
            <span className="text-[11px] text-white/40">Selective Product Freeze</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            {[
              { type: 'INTRADAY_ADVANCE' as ProductType, label: 'Intraday Advances' },
              { type: 'OVERNIGHT_LOAN' as ProductType, label: 'Overnight Facilities' },
              { type: 'SHORT_TERM_REVOLVER' as ProductType, label: 'Short-Term Revolver' },
              { type: 'RECEIVABLES_BACKED' as ProductType, label: 'Receivables Advances' },
              { type: 'SECURED_WORKING_CAPITAL' as ProductType, label: 'Secured Working Capital' },
              { type: 'INTERBANK_LENDING' as ProductType, label: 'Interbank Repo' },
              { type: 'INTERNAL_TREASURY_ALLOCATION' as ProductType, label: 'Internal Treasury' }
            ].map((p) => {
              const isPaused = pausedProducts.includes(p.type);
              return (
                <button
                  key={p.type}
                  onClick={() => onToggleProductPause(p.type)}
                  className={`p-2 rounded border text-left cursor-pointer transition-colors ${
                    isPaused
                      ? 'bg-red-950/40 border-red-500/40 text-red-300'
                      : 'bg-white/5 border-white/5 text-white/80 hover:bg-white/10'
                  }`}
                >
                  <span className="font-semibold block truncate">{p.label}</span>
                  <span className="text-[10px] text-white/40">{isPaused ? '● Suspended' : '✓ Active'}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Cryptographic Audit Trail */}
      <div className="bg-[#0d121c] border border-white/10 rounded-lg overflow-hidden">
        <div className="p-4 bg-white/5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-[#d4af37]" />
            <h2 className="text-sm font-bold text-white">Immutable Cryptographic Audit Trail</h2>
          </div>
          <span className="text-[11px] text-white/50 font-mono">WORM Storage Compliant</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-[10px] text-white/40 uppercase bg-white/5 border-b border-white/10 select-none">
              <tr>
                <th className="py-2.5 px-3">Audit Event ID</th>
                <th className="py-2.5 px-3">Timestamp (UTC)</th>
                <th className="py-2.5 px-3">Actor / Principal</th>
                <th className="py-2.5 px-3">Action Type</th>
                <th className="py-2.5 px-3">Narrative Description</th>
                <th className="py-2.5 px-3">Cryptographic Digest</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {auditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-white/5 transition-colors">
                  <td className="py-3 px-3 font-mono font-medium text-white">{log.id}</td>
                  <td className="py-3 px-3 font-mono text-white/60 text-[11px]">{log.timestamp}</td>
                  <td className="py-3 px-3 font-medium text-white/90">{log.actor}</td>
                  <td className="py-3 px-3 font-mono text-[#d4af37] text-[11px]">{log.action}</td>
                  <td className="py-3 px-3 text-white/80">{log.details}</td>
                  <td className="py-3 px-3 font-mono text-white/40 text-[10px]">{log.hash}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
