/**
 * RhinoQuant Architecture, Python/FastAPI Specs, PostgreSQL DDL & Docker Compose
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 */

import React, { useState } from 'react';
import { Check, Copy, Database, FileCode, Layers, Server, Terminal, X } from 'lucide-react';

interface ArchitectureDocsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureDocsModal: React.FC<ArchitectureDocsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'PYTHON' | 'SQL' | 'DOCKER' | 'API'>('PYTHON');
  const [copied, setCopied] = useState<boolean>(false);

  const pythonFastApiCode = `"""
RhinoQuant Liquidity Engine - High-Frequency Decision Service
FastAPI + NumPy/SciPy Constrained Optimization Worker
"""
from fastapi import FastAPI, BackgroundTasks, HTTPException, Header, Depends
from pydantic import BaseModel, Field
from typing import List, Optional
import numpy as np
from scipy.optimize import linprog
import uuid
import datetime

app = FastAPI(
    title="RhinoQuant Liquidity Engine API",
    version="2026.4.1",
    description="High-frequency event-driven institutional lending decisioning & subledger"
)

class DrawdownRequest(BaseModel):
    idempotency_key: str = Field(..., description="Unique client UUID preventing double-commit")
    borrower_id: str
    facility_id: str
    product_type: str
    currency: str
    requested_amount: float
    tenor_hours: int

class PricingBreakdown(BaseModel):
    reference_rate: float
    credit_spread_bps: float
    liquidity_adj_bps: float
    capital_cost_bps: float
    operating_cost_bps: float
    target_margin_bps: float
    quoted_annualized_apr: float
    estimated_interest_amount: float
    quote_expiry_utc: str

@app.post("/v1/liquidity/evaluate", response_model=dict)
async def evaluate_funding_request(req: DrawdownRequest, background_tasks: BackgroundTasks):
    # 1. Atomic Idempotency Check in Redis/Postgres Outbox
    # 2. Multidimensional Limit Evaluation (Individual, Corporate Group, Sector, Country)
    # 3. Contractual Borrowing Base & Haircut Calculation
    # 4. Multi-Component Pricing Engine
    reference_rate = 0.0482  # Live NY Fed SOFR
    credit_spread = 0.0045   # 45 bps for A+ rating
    quoted_rate = reference_rate + credit_spread + 0.0010 + 0.0014 + 0.0005 + 0.0020
    
    # 5. Atomic Reservation Lock (PostgreSQL SELECT FOR UPDATE)
    return {
        "request_id": f"REQ-{uuid.uuid4().hex[:8].upper()}",
        "decision": "APPROVED",
        "approved_amount": req.requested_amount,
        "quoted_rate": round(quoted_rate, 6),
        "policy_version": "RQ-POL-2026.4.1",
        "reservation_status": "FUNDING_RESERVED",
        "requires_terms_acceptance": True
    }
`;

  const postgresDDL = `-- ====================================================================
-- RhinoQuant PostgreSQL Authoritative Financial Schema
-- Strict Double-Entry Ledger, Idempotency & Multidimensional Limits
-- ====================================================================

CREATE TABLE counterparties (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    legal_entity VARCHAR(255) NOT NULL,
    lei CHAR(20) UNIQUE NOT NULL,
    corporate_group_id VARCHAR(64) NOT NULL,
    corporate_group_name VARCHAR(255) NOT NULL,
    credit_rating VARCHAR(8) NOT NULL,
    sector VARCHAR(64) NOT NULL,
    country CHAR(3) NOT NULL,
    is_internal BOOLEAN DEFAULT FALSE,
    min_liquidity_ratio NUMERIC(5,2) NOT NULL,
    max_leverage NUMERIC(5,2) NOT NULL,
    payment_system VARCHAR(32) NOT NULL,
    settlement_account VARCHAR(128) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE facilities (
    id VARCHAR(64) PRIMARY KEY,
    facility_code VARCHAR(64) UNIQUE NOT NULL,
    borrower_id VARCHAR(64) REFERENCES counterparties(id),
    product_type VARCHAR(64) NOT NULL,
    currency CHAR(3) NOT NULL,
    approved_limit NUMERIC(18,2) NOT NULL,
    current_drawn NUMERIC(18,2) DEFAULT 0.00,
    current_reserved NUMERIC(18,2) DEFAULT 0.00,
    reference_benchmark VARCHAR(32) NOT NULL,
    base_spread_bps INT NOT NULL,
    requires_collateral BOOLEAN DEFAULT TRUE,
    min_collateral_ratio NUMERIC(5,2) DEFAULT 1.05,
    expiry_date DATE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE collateral_assets (
    id VARCHAR(64) PRIMARY KEY,
    counterparty_id VARCHAR(64) REFERENCES counterparties(id),
    asset_class VARCHAR(64) NOT NULL,
    identifier VARCHAR(32) NOT NULL,
    market_value NUMERIC(18,2) NOT NULL,
    haircut_percent NUMERIC(5,2) NOT NULL,
    prior_encumbrances NUMERIC(18,2) DEFAULT 0.00,
    allocated_amount NUMERIC(18,2) DEFAULT 0.00,
    valuation_timestamp TIMESTAMPTZ NOT NULL,
    custodian VARCHAR(128) NOT NULL,
    control_status VARCHAR(64) NOT NULL
);

-- Balanced Double-Entry Subledger
CREATE TABLE ledger_journal_entries (
    id VARCHAR(64) PRIMARY KEY,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    reference_id VARCHAR(64) NOT NULL,
    event_type VARCHAR(64) NOT NULL,
    narrative TEXT NOT NULL,
    is_balanced BOOLEAN NOT NULL,
    checksum VARCHAR(128) NOT NULL
);

CREATE TABLE ledger_lines (
    id BIGSERIAL PRIMARY KEY,
    journal_entry_id VARCHAR(64) REFERENCES ledger_journal_entries(id) ON DELETE CASCADE,
    account_number VARCHAR(16) NOT NULL,
    account_name VARCHAR(128) NOT NULL,
    debit NUMERIC(18,2) DEFAULT 0.00,
    credit NUMERIC(18,2) DEFAULT 0.00,
    currency CHAR(3) DEFAULT 'USD',
    CONSTRAINT chk_debit_credit_positive CHECK (debit >= 0 AND credit >= 0)
);

-- Outbox Pattern for Distributed High-Frequency Event Queue
CREATE TABLE event_outbox (
    event_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    aggregate_type VARCHAR(64) NOT NULL,
    aggregate_id VARCHAR(64) NOT NULL,
    event_type VARCHAR(64) NOT NULL,
    payload JSONB NOT NULL,
    occurred_at TIMESTAMPTZ DEFAULT NOW(),
    processed_at TIMESTAMPTZ NULL
);
`;

  const dockerComposeYaml = `version: "3.9"

services:
  # 1. RhinoQuant UI (React SPA + Nginx)
  frontend:
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - "3000:3000"
    environment:
      - VITE_ENGINE_API_URL=http://localhost:8000
    depends_on:
      - api-engine

  # 2. FastAPI High-Frequency Decision Engine
  api-engine:
    build:
      context: ./backend
      dockerfile: Dockerfile.python
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://rhino_quant:RhinoPass2026@postgres:5432/rhino_liquidity
      - REDIS_URL=redis://redis:6379/0
      - SOFR_FEED_URL=https://markets.newyorkfed.org/api/rates/all/latest.json
    depends_on:
      - postgres
      - redis

  # 3. PostgreSQL Authoritative Financial Subledger
  postgres:
    image: postgres:16-alpine
    restart: always
    environment:
      POSTGRES_USER: rhino_quant
      POSTGRES_PASSWORD: RhinoPass2026
      POSTGRES_DB: rhino_liquidity
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./migrations:/docker-entrypoint-initdb.d

  # 4. Durable Event Queue & In-Memory Locks (Redis)
  redis:
    image: redis:7-alpine
    restart: always
    ports:
      - "6379:6379"
    volumes:
      - redisdata:/data

volumes:
  pgdata:
  redisdata:
`;

  const apiSpecs = `# RhinoQuant Liquidity Engine REST & WebSocket API Specification
# Policy Standard: RQ-POL-2026.4.1

## Core REST Endpoints:
1. POST /v1/requests/evaluate
   - Evaluates incoming request, verifies multidimensional limits, computes 7-component quote.
   - Header 'X-Idempotency-Key': Required UUID.

2. POST /v1/requests/{id}/accept-terms
   - Counterparty accepts quoted terms and covenants before funding reservation becomes binding.

3. POST /v1/requests/{id}/disburse
   - Atomically commits cash, dispatches Fedwire/Target2 wire, posts balanced double-entry lines.

4. POST /v1/requests/{id}/repay
   - Settle principal + accrued interest, releases collateral allocations, clears non-accrual flags.

5. GET /v1/subledger/trial-balance
   - Verifies sum(Debits) === sum(Credits), returns all T-account balances.

6. GET /v1/telemetry/live
   - Returns P50/P95/P99 latency, arrival rate, lock contention, and queue depth.

7. POST /v1/controls/circuit-breaker
   - Engages or resets global emergency stop. Requires Maker-Checker dual authorization.

## WebSocket Real-Time Stream:
- Endpoint: ws://localhost:8000/ws/telemetry
- Push Events:
  * EVENT_REQUEST_EVALUATED
  * EVENT_RESERVATION_COMMITTED
  * EVENT_PAYMENT_DISBURSED
  * EVENT_REPAYMENT_SETTLED
  * EVENT_CIRCUIT_BREAKER_STATE_CHANGE
`;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const currentText =
    activeTab === 'PYTHON'
      ? pythonFastApiCode
      : activeTab === 'SQL'
      ? postgresDDL
      : activeTab === 'DOCKER'
      ? dockerComposeYaml
      : apiSpecs;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-[#0b0f17] border border-white/20 rounded-xl max-w-5xl w-full max-h-[90vh] shadow-2xl flex flex-col text-xs text-white overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between bg-[#0e1420]">
          <div className="flex items-center gap-3">
            <Server className="w-4 h-4 text-[#d4af37]" />
            <div>
              <span className="font-bold text-sm text-white">System Architecture & Deployment Blueprint</span>
              <p className="text-[10px] text-white/50">
                FastAPI, NumPy/SciPy Optimizer, PostgreSQL Subledger DDL, Docker Compose & OpenAPI Spec
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-white/10 text-white/60 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-6 py-2.5 bg-[#090d14] border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {[
              { id: 'PYTHON' as const, label: 'Python / FastAPI Engine', icon: FileCode },
              { id: 'SQL' as const, label: 'PostgreSQL DDL & Ledger', icon: Database },
              { id: 'DOCKER' as const, label: 'Docker Compose Spec', icon: Layers },
              { id: 'API' as const, label: 'REST & WebSocket Protocol', icon: Terminal }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold cursor-pointer transition-colors ${
                    activeTab === tab.id
                      ? 'bg-[#d4af37] text-[#090d14]'
                      : 'text-white/60 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          <button
            onClick={() => copyToClipboard(currentText)}
            className="flex items-center gap-1 px-3 py-1 bg-white/5 hover:bg-white/10 text-white border border-white/10 rounded cursor-pointer transition-colors text-[11px]"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy Code'}</span>
          </button>
        </div>

        {/* Code Content Viewport */}
        <div className="p-6 overflow-y-auto font-mono text-[11px] leading-relaxed bg-[#070a0f] text-white/90 select-text">
          <pre>{currentText}</pre>
        </div>
      </div>
    </div>
  );
};
