/**
 * RhinoQuant Request Inspection & Audit Modal
 * Comprehensive mathematical and legal trace of lending decisions
 */

import React from 'react';
import {
  CheckCircle2,
  Clock,
  DollarSign,
  FileText,
  Lock,
  Shield,
  X,
  Zap,
  ArrowRight
} from 'lucide-react';
import { Counterparty, Facility, FundingRequest } from '../types';

interface RequestDetailModalProps {
  request: FundingRequest | null;
  counterparty?: Counterparty;
  facility?: Facility;
  onClose: () => void;
  onAcceptTerms: (requestId: string) => void;
  onDisburseLoan: (requestId: string) => void;
  onRepayLoan: (requestId: string) => void;
}

export const RequestDetailModal: React.FC<RequestDetailModalProps> = ({
  request,
  counterparty,
  facility,
  onClose,
  onAcceptTerms,
  onDisburseLoan,
  onRepayLoan
}) => {
  if (!request) return null;

  const quote = request.pricingQuote;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-[#0b0f17] border border-white/20 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl flex flex-col text-xs text-white">
        {/* Header */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between bg-[#0e1420]">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 bg-[#d4af37] rotate-45 shrink-0" />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-base text-white">{request.id}</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                    request.decisionStatus === 'APPROVED'
                      ? 'text-emerald-300 bg-emerald-950/60 border-emerald-500/40'
                      : request.decisionStatus === 'PARTIALLY_APPROVED'
                      ? 'text-amber-300 bg-amber-950/60 border-amber-500/40'
                      : 'text-cyan-300 bg-cyan-950/60 border-cyan-500/40'
                  }`}
                >
                  {request.decisionStatus}
                </span>
                <span className="font-mono text-white/50 text-[11px]">
                  State: <strong className="text-white">{request.status}</strong>
                </span>
              </div>
              <p className="text-[11px] text-white/50 mt-0.5">
                Idempotency Key: <span className="font-mono text-white/70">{request.idempotencyKey}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-white/10 text-white/60 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6">
          {/* Top Info Banner: Counterparty & Facility */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3 bg-white/5 rounded border border-white/5">
              <span className="text-[10px] text-white/40 uppercase block">Institutional Borrower</span>
              <span className="font-bold text-sm text-white block mt-0.5">
                {counterparty?.name || request.borrowerId}
              </span>
              <span className="text-[10px] text-white/60 font-mono">
                LEI: {counterparty?.lei || 'N/A'} · Rating: {counterparty?.creditRating}
              </span>
            </div>

            <div className="p-3 bg-white/5 rounded border border-white/5">
              <span className="text-[10px] text-white/40 uppercase block">Corporate Economic Group</span>
              <span className="font-semibold text-sm text-white block mt-0.5">
                {counterparty?.corporateGroupName || 'Independent Group'}
              </span>
              <span className="text-[10px] text-white/60">
                Single Risk Unit Cap: $150.0M
              </span>
            </div>

            <div className="p-3 bg-white/5 rounded border border-white/5">
              <span className="text-[10px] text-white/40 uppercase block">Financing Facility</span>
              <span className="font-semibold text-sm text-[#d4af37] block mt-0.5">
                {facility?.facilityCode || request.facilityId}
              </span>
              <span className="text-[10px] text-white/60">
                Limit: {facility?.currency} {((facility?.approvedLimit || 0) / 1_000_000).toFixed(1)}M
              </span>
            </div>
          </div>

          {/* Policy Evaluation Reasons (Section 5 requirement) */}
          <div className="p-4 bg-white/5 rounded-lg border border-white/10 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white tracking-wide text-xs flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-[#d4af37]" />
                Automated Policy Evaluation Audit
              </span>
              <span className="font-mono text-[10px] text-white/50">Policy: {request.policyVersion}</span>
            </div>
            <ul className="space-y-1.5 text-xs text-white/80">
              {request.decisionReasons.map((reason, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{reason}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Pricing Engine Breakdown (Section 6 requirement) */}
          {quote && (
            <div className="p-4 bg-white/5 rounded-lg border border-white/10 space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <div>
                  <span className="font-bold text-white text-xs">Transparent Multi-Component Pricing Quote</span>
                  <p className="text-[10px] text-white/50">
                    Day-Count: {quote.dayCountConvention} · Actual Tenor: {quote.tenorHours} Hours
                  </p>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold text-base text-emerald-400 tabular-nums">
                    {(quote.totalQuotedAnnualizedRate * 100).toFixed(2)}% APR
                  </span>
                  <span className="block text-[10px] font-mono text-white/40">
                    Effective Cost: {(quote.effectiveCostRateAnnualized * 100).toFixed(2)}%
                  </span>
                </div>
              </div>

              {/* 7 Component Matrix */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                <div className="p-2 bg-white/5 rounded border border-white/5">
                  <span className="text-[10px] text-white/40 block">1. Reference Rate</span>
                  <span className="font-mono font-bold text-white">{(quote.referenceFundingRate * 100).toFixed(2)}%</span>
                  <span className="text-[9px] text-white/40 block truncate">{quote.referenceSource}</span>
                </div>

                <div className="p-2 bg-white/5 rounded border border-white/5">
                  <span className="text-[10px] text-white/40 block">2. Tenor Adjustment</span>
                  <span className="font-mono font-bold text-white">{quote.tenorAdjustmentBps >= 0 ? '+' : ''}{quote.tenorAdjustmentBps} bps</span>
                  <span className="text-[9px] text-white/40 block">{quote.tenorHours}h term structure</span>
                </div>

                <div className="p-2 bg-white/5 rounded border border-white/5">
                  <span className="text-[10px] text-white/40 block">3. Credit Spread</span>
                  <span className="font-mono font-bold text-white">+{quote.creditSpreadBps} bps</span>
                  <span className="text-[9px] text-white/40 block">Rating: {counterparty?.creditRating}</span>
                </div>

                <div className="p-2 bg-white/5 rounded border border-white/5">
                  <span className="text-[10px] text-white/40 block">4. Liquidity Adjustment</span>
                  <span className="font-mono font-bold text-white">+{quote.liquidityAdjustmentBps} bps</span>
                  <span className="text-[9px] text-white/40 block">Pool scarcity spread</span>
                </div>

                <div className="p-2 bg-white/5 rounded border border-white/5">
                  <span className="text-[10px] text-white/40 block">5. Capital Cost</span>
                  <span className="font-mono font-bold text-white">+{quote.capitalCostAllocationBps} bps</span>
                  <span className="text-[9px] text-white/40 block">Basel III/IV RWA</span>
                </div>

                <div className="p-2 bg-white/5 rounded border border-white/5">
                  <span className="text-[10px] text-white/40 block">6. Operating Cost</span>
                  <span className="font-mono font-bold text-white">+{quote.operatingCostAllocationBps} bps</span>
                  <span className="text-[9px] text-white/40 block">Clearing overhead</span>
                </div>

                <div className="p-2 bg-white/5 rounded border border-white/5">
                  <span className="text-[10px] text-white/40 block">7. Target Margin</span>
                  <span className="font-mono font-bold text-[#d4af37]">+{quote.targetMarginBps} bps</span>
                  <span className="text-[9px] text-[#d4af37]/60 block">RhinoQuant hurdle</span>
                </div>

                <div className="p-2 bg-emerald-950/40 rounded border border-emerald-500/30">
                  <span className="text-[10px] text-emerald-300 block">Estimated Interest Cash</span>
                  <span className="font-mono font-bold text-emerald-300 tabular-nums">
                    ${quote.estimatedInterestAmount.toLocaleString()}
                  </span>
                  <span className="text-[9px] text-emerald-400/60 block">Fee: ${quote.facilityDrawdownFee}</span>
                </div>
              </div>
            </div>
          )}

          {/* Payment Instructions & Settlement Architecture */}
          <div className="p-4 bg-white/5 rounded-lg border border-white/10 space-y-2">
            <span className="font-bold text-white tracking-wide text-xs">Contractual Payment & Settlement Route</span>
            <div className="grid grid-cols-3 gap-3 text-xs pt-1">
              <div>
                <span className="text-white/40 text-[10px] block">Clearing Network</span>
                <span className="font-mono font-bold text-white">{counterparty?.paymentInstructions.system || 'FEDWIRE'}</span>
              </div>
              <div>
                <span className="text-white/40 text-[10px] block">Settlement Account</span>
                <span className="font-mono font-bold text-white">{counterparty?.paymentInstructions.accountIdentifier || 'N/A'}</span>
              </div>
              <div>
                <span className="text-white/40 text-[10px] block">Daily Window Cutoff</span>
                <span className="font-mono font-bold text-amber-300">{counterparty?.paymentInstructions.cutoffTimeUtc || '21:30'} UTC</span>
              </div>
            </div>
          </div>

          {/* Lifecycle Action Triggers */}
          <div className="p-4 bg-[#0e1420] rounded-lg border border-white/10 flex flex-wrap items-center justify-between gap-4">
            <div>
              <span className="font-bold text-white text-xs block">Execution Control Panel</span>
              <span className="text-[11px] text-white/50">
                Rule: A pricing quote does not automatically execute without explicit terms acceptance.
              </span>
            </div>

            <div className="flex items-center gap-2">
              {request.status === 'QUOTED' && (
                <button
                  onClick={() => {
                    onAcceptTerms(request.id);
                    onClose();
                  }}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded text-xs cursor-pointer transition-colors"
                >
                  Accept Terms & Reserve
                </button>
              )}

              {(request.status === 'ACCEPTED' || request.status === 'FUNDING_RESERVED') && (
                <button
                  onClick={() => {
                    onDisburseLoan(request.id);
                    onClose();
                  }}
                  className="px-4 py-2 bg-[#d4af37] hover:bg-[#e5c158] text-[#090d14] font-bold rounded text-xs cursor-pointer transition-colors"
                >
                  Confirm Disbursement Wire
                </button>
              )}

              {(request.status === 'OUTSTANDING' || request.status === 'OVERDUE') && (
                <button
                  onClick={() => {
                    onRepayLoan(request.id);
                    onClose();
                  }}
                  className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold rounded text-xs cursor-pointer transition-colors"
                >
                  Process Repayment Settlement
                </button>
              )}

              <button
                onClick={onClose}
                className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white rounded text-xs cursor-pointer transition-colors"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
