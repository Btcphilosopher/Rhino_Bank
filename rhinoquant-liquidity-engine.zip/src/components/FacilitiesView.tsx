/**
 * RhinoQuant Facilities & Institutional Counterparties View
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Models legal entities, parent corporate groups, contractual facilities,
 * covenants, payment instructions, and group-wide concentration limits.
 */

import React, { useState } from 'react';
import {
  Building2,
  FileCheck,
  Globe,
  Layers,
  Search,
  Shield,
  TrendingDown,
  AlertTriangle
} from 'lucide-react';
import { Counterparty, Facility } from '../types';

interface FacilitiesViewProps {
  counterparties: Counterparty[];
  facilities: Facility[];
}

export const FacilitiesView: React.FC<FacilitiesViewProps> = ({ counterparties, facilities }) => {
  const [selectedGroupId, setSelectedGroupId] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const cpMap = new Map(counterparties.map((c) => [c.id, c]));

  // Corporate Group summary
  const groupStats = [
    { id: 'GRP-APEX', name: 'Apex Financial Holdings Corp', country: 'DEU/CHE', cap: 150_000_000 },
    { id: 'GRP-MERIDIAN', name: 'Meridian Capital Partners', country: 'USA', cap: 150_000_000 },
    { id: 'GRP-HELIOS', name: 'Helios Energy & Natural Resources', country: 'GBR', cap: 150_000_000 },
    { id: 'GRP-VALO', name: 'Valo Investment Group Luxembourg', country: 'CHE/LUX', cap: 150_000_000 },
    { id: 'GRP-SUPRA', name: 'Supranational Reserve Group', country: 'DEU', cap: 250_000_000 },
    { id: 'GRP-RHINO', name: 'RhinoBank AG Group (Internal)', country: 'USA', cap: 200_000_000 }
  ];

  const filteredFacilities = facilities.filter((fac) => {
    const cp = cpMap.get(fac.borrowerId);
    if (!cp) return false;
    if (selectedGroupId !== 'ALL' && cp.corporateGroupId !== selectedGroupId) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchCode = fac.facilityCode.toLowerCase().includes(q);
      const matchName = cp.name.toLowerCase().includes(q);
      const matchGroup = cp.corporateGroupName.toLowerCase().includes(q);
      if (!matchCode && !matchName && !matchGroup) return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-4 bg-[#0d121c] border border-white/10 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-white tracking-wide">
            Institutional Counterparties & Contractual Facilities
          </h1>
          <p className="text-xs text-white/50">
            Approved master facilities, legal group concentrations, financial covenants, and settlement routing
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-white/40" />
            <input
              type="text"
              placeholder="Filter counterparties or codes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-white/5 border border-white/10 rounded pl-8 pr-3 py-1.5 text-white placeholder-white/30 text-xs outline-none focus:border-[#d4af37]"
            />
          </div>

          <select
            value={selectedGroupId}
            onChange={(e) => setSelectedGroupId(e.target.value)}
            className="bg-white/5 border border-white/10 rounded px-2.5 py-1.5 text-white text-xs outline-none cursor-pointer"
          >
            <option value="ALL" className="bg-[#0f141c]">All Corporate Groups</option>
            {groupStats.map((g) => (
              <option key={g.id} value={g.id} className="bg-[#0f141c]">
                {g.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Corporate Group Concentration Risk Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {groupStats.map((g) => {
          const groupBorrowers = counterparties.filter((cp) => cp.corporateGroupId === g.id).map((c) => c.id);
          const groupFacs = facilities.filter((f) => groupBorrowers.includes(f.borrowerId));
          const totalDrawn = groupFacs.reduce((sum, f) => sum + f.currentDrawn, 0);
          const totalReserved = groupFacs.reduce((sum, f) => sum + f.currentReserved, 0);
          const totalExposure = totalDrawn + totalReserved;
          const utilPct = (totalExposure / g.cap) * 100;

          return (
            <div key={g.id} className="p-4 bg-[#0d121c] border border-white/10 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <div className="font-semibold text-white text-xs truncate max-w-[200px]" title={g.name}>
                  {g.name}
                </div>
                <span className="font-mono text-[10px] text-white/50">{g.country}</span>
              </div>
              <div className="flex justify-between items-end text-xs">
                <div>
                  <span className="text-[10px] text-white/40 block">Group Exposure</span>
                  <span className="font-mono font-bold text-white tabular-nums">
                    ${(totalExposure / 1_000_000).toFixed(1)}M
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-white/40 block">Group Cap</span>
                  <span className="font-mono text-white/70 tabular-nums">
                    ${(g.cap / 1_000_000).toFixed(0)}M
                  </span>
                </div>
              </div>
              <div className="h-1.5 w-full bg-white/10 rounded overflow-hidden">
                <div
                  style={{ width: `${Math.min(100, utilPct)}%` }}
                  className={`h-full ${
                    utilPct > 80 ? 'bg-red-500' : utilPct > 50 ? 'bg-amber-400' : 'bg-emerald-500'
                  }`}
                />
              </div>
              <div className="flex justify-between text-[10px] text-white/40 pt-1">
                <span>Headroom: ${((g.cap - totalExposure) / 1_000_000).toFixed(1)}M</span>
                <span>{utilPct.toFixed(1)}% utilized</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Facilities Table */}
      <div className="bg-[#0d121c] border border-white/10 rounded-lg overflow-hidden">
        <div className="p-3 bg-white/5 border-b border-white/10 flex items-center justify-between">
          <span className="font-bold text-xs text-white">Active Approved Financing Facilities</span>
          <span className="text-[11px] text-white/50 font-mono">
            {filteredFacilities.length} Contractual Agreements Active
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-[10px] text-white/40 uppercase bg-white/5 border-b border-white/10 select-none">
              <tr>
                <th className="py-2.5 px-3">Facility Code</th>
                <th className="py-2.5 px-3">Borrower / LEI</th>
                <th className="py-2.5 px-3">Product Type</th>
                <th className="py-2.5 px-3 text-right">Limit</th>
                <th className="py-2.5 px-3 text-right">Drawn</th>
                <th className="py-2.5 px-3 text-right">Available</th>
                <th className="py-2.5 px-3">Benchmark & Spread</th>
                <th className="py-2.5 px-3">Covenants</th>
                <th className="py-2.5 px-3">Permitted Tenors</th>
                <th className="py-2.5 px-3">Payment Instruction</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredFacilities.map((fac) => {
                const cp = cpMap.get(fac.borrowerId);
                const headroom = Math.max(0, fac.approvedLimit - fac.currentDrawn - fac.currentReserved);
                const utilPct = ((fac.currentDrawn + fac.currentReserved) / fac.approvedLimit) * 100;

                return (
                  <tr key={fac.id} className="hover:bg-white/5 transition-colors">
                    {/* Facility Code */}
                    <td className="py-3 px-3 font-mono font-semibold text-[#d4af37]">
                      {fac.facilityCode}
                      <div className="text-[10px] text-white/40 font-normal">Exp: {fac.expiryDate}</div>
                    </td>

                    {/* Borrower */}
                    <td className="py-3 px-3">
                      <div className="font-medium text-white">{cp?.name}</div>
                      <div className="text-[10px] font-mono text-white/40">{cp?.lei}</div>
                    </td>

                    {/* Product */}
                    <td className="py-3 px-3">
                      <div className="text-white/90">{fac.productType.replace(/_/g, ' ')}</div>
                      <div className="text-[10px] text-white/50">
                        {fac.requiresCollateral ? `Secured (Min ${((fac.minCollateralCoverageRatio || 1) * 100).toFixed(0)}%)` : 'Unsecured'}
                      </div>
                    </td>

                    {/* Limit */}
                    <td className="py-3 px-3 text-right font-mono font-bold text-white tabular-nums">
                      {fac.currency} {(fac.approvedLimit / 1_000_000).toFixed(1)}M
                    </td>

                    {/* Drawn */}
                    <td className="py-3 px-3 text-right font-mono text-cyan-400 tabular-nums">
                      {fac.currency} {(fac.currentDrawn / 1_000_000).toFixed(1)}M
                    </td>

                    {/* Available */}
                    <td className="py-3 px-3 text-right font-mono font-bold text-emerald-400 tabular-nums">
                      {fac.currency} {(headroom / 1_000_000).toFixed(1)}M
                    </td>

                    {/* Benchmark */}
                    <td className="py-3 px-3">
                      <div className="font-mono text-white/90">{fac.referenceBenchmark}</div>
                      <div className="text-[10px] text-white/40 font-mono">+{fac.baseCreditSpreadBps} bps spread</div>
                    </td>

                    {/* Covenants */}
                    <td className="py-3 px-3">
                      {cp && (
                        <div className="text-[11px] space-y-0.5">
                          <div className={cp.currentLiquidityRatio < cp.minLiquidityRatioCovenant ? 'text-red-400 font-bold' : 'text-white/70'}>
                            LCR: {cp.currentLiquidityRatio}x (≥{cp.minLiquidityRatioCovenant}x)
                          </div>
                          <div className={cp.currentLeverage > cp.maxLeverageCovenant ? 'text-red-400 font-bold' : 'text-white/50'}>
                            Lev: {cp.currentLeverage}x (≤{cp.maxLeverageCovenant}x)
                          </div>
                        </div>
                      )}
                    </td>

                    {/* Tenors */}
                    <td className="py-3 px-3 font-mono text-[11px] text-white/70">
                      {fac.permittedTenorsHours.map((h) => `${h}h`).join(', ')}
                    </td>

                    {/* Payment Instruction */}
                    <td className="py-3 px-3 font-mono text-[10px] text-white/60">
                      <div>{cp?.paymentInstructions.system}</div>
                      <div className="text-white/40 truncate max-w-[120px]" title={cp?.paymentInstructions.accountIdentifier}>
                        {cp?.paymentInstructions.accountIdentifier}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
