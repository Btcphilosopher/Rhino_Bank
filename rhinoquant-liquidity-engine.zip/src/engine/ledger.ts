/**
 * RhinoQuant Balanced Double-Entry Subledger
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Implements strict double-entry accounting where Sum(Debits) === Sum(Credits).
 * Tracks loan disbursements, reservations, interest accruals, repayments, fees, and ECL provisions.
 */

import { DoubleEntryLine, LedgerAccountBalance, LedgerJournalEntry } from '../types';

export const CHART_OF_ACCOUNTS: Record<string, { name: string; category: LedgerAccountBalance['category'] }> = {
  '1010': { name: 'Nostro / Central Bank Reserve Cash', category: 'ASSET' },
  '1020': { name: 'Cash Committed / In Transit', category: 'ASSET' },
  '1200': { name: 'Loans Outstanding - Institutional Principal', category: 'ASSET' },
  '1210': { name: 'Accrued Interest Receivable', category: 'ASSET' },
  '1220': { name: 'Accrued Fees Receivable', category: 'ASSET' },
  '1290': { name: 'Overdue Balances / Non-Accrual Loans', category: 'ASSET' },
  '2010': { name: 'Liquidity Reservations Pending Disbursement', category: 'LIABILITY' },
  '3000': { name: 'Capital & Retained Reserves', category: 'EQUITY' },
  '4010': { name: 'Financing Interest Income', category: 'REVENUE' },
  '4020': { name: 'Facility & Drawdown Fee Income', category: 'REVENUE' },
  '5010': { name: 'Cost of Funds / Funding Expense', category: 'EXPENSE' },
  '5020': { name: 'Expected Credit Loss (ECL) Provisions', category: 'EXPENSE' }
};

/**
 * Creates an immutable balanced journal entry
 */
export function createJournalEntry(params: {
  referenceId: string;
  eventType: string;
  narrative: string;
  lines: DoubleEntryLine[];
  timestamp?: string;
}): LedgerJournalEntry {
  const timestamp = params.timestamp || new Date().toISOString();
  const totalDebit = params.lines.reduce((sum, l) => sum + l.debit, 0);
  const totalCredit = params.lines.reduce((sum, l) => sum + l.credit, 0);

  // Strict double-entry balance check with 2 decimal precision
  const isBalanced = Math.abs(Number(totalDebit.toFixed(2)) - Number(totalCredit.toFixed(2))) < 0.001;

  if (!isBalanced) {
    throw new Error(
      `Double-Entry Balance Failure: Debits ($${totalDebit.toFixed(2)}) !== Credits ($${totalCredit.toFixed(2)}) for ref ${params.referenceId}`
    );
  }

  // Generate deterministic checksum
  const rawString = `${params.referenceId}-${timestamp}-${totalDebit.toFixed(2)}-${params.lines.map((l) => `${l.accountNumber}:${l.debit}/${l.credit}`).join(';')}`;
  let hash = 0;
  for (let i = 0; i < rawString.length; i++) {
    hash = (hash << 5) - hash + rawString.charCodeAt(i);
    hash |= 0;
  }
  const checksum = `SHA256:${Math.abs(hash).toString(16).padStart(8, '0')}${Date.now().toString(16)}`;

  const id = `JRN-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 900 + 100)}`;

  return {
    id,
    timestamp,
    referenceId: params.referenceId,
    eventType: params.eventType,
    narrative: params.narrative,
    lines: params.lines.map((l) => ({
      ...l,
      debit: Number(l.debit.toFixed(2)),
      credit: Number(l.credit.toFixed(2))
    })),
    isBalanced,
    checksum
  };
}

/**
 * Calculates trial balance and current account balances across all journal entries
 */
export function calculateAccountBalances(entries: LedgerJournalEntry[]): {
  balances: LedgerAccountBalance[];
  totalDebits: number;
  totalCredits: number;
  isTrialBalanceValid: boolean;
} {
  const accountTotals = new Map<string, { debits: number; credits: number }>();

  // Initialize all chart accounts
  for (const accNum of Object.keys(CHART_OF_ACCOUNTS)) {
    accountTotals.set(accNum, { debits: 0, credits: 0 });
  }

  let totalDebits = 0;
  let totalCredits = 0;

  for (const entry of entries) {
    for (const line of entry.lines) {
      const cur = accountTotals.get(line.accountNumber) || { debits: 0, credits: 0 };
      cur.debits += line.debit;
      cur.credits += line.credit;
      accountTotals.set(line.accountNumber, cur);

      totalDebits += line.debit;
      totalCredits += line.credit;
    }
  }

  const balances: LedgerAccountBalance[] = [];

  for (const [accNum, totals] of accountTotals.entries()) {
    const meta = CHART_OF_ACCOUNTS[accNum];
    let netBalance = 0;

    // Normal debit balances: ASSETS, EXPENSES
    if (meta.category === 'ASSET' || meta.category === 'EXPENSE') {
      netBalance = totals.debits - totals.credits;
    } else {
      // Normal credit balances: LIABILITIES, EQUITY, REVENUE
      netBalance = totals.credits - totals.debits;
    }

    balances.push({
      accountNumber: accNum,
      accountName: meta.name,
      category: meta.category,
      balance: Number(netBalance.toFixed(2)),
      currency: 'USD'
    });
  }

  balances.sort((a, b) => a.accountNumber.localeCompare(b.accountNumber));

  const isTrialBalanceValid = Math.abs(Number(totalDebits.toFixed(2)) - Number(totalCredits.toFixed(2))) < 0.01;

  return {
    balances,
    totalDebits: Number(totalDebits.toFixed(2)),
    totalCredits: Number(totalCredits.toFixed(2)),
    isTrialBalanceValid
  };
}

/**
 * Journal Entry Generator for Loan Disbursement
 */
export function makeDisbursementEntry(params: {
  loanId: string;
  counterpartyName: string;
  principal: number;
  upfrontFee?: number;
}): LedgerJournalEntry {
  const { loanId, counterpartyName, principal, upfrontFee = 0 } = params;
  const lines: DoubleEntryLine[] = [
    {
      accountNumber: '1200',
      accountName: 'Loans Outstanding - Institutional Principal',
      debit: principal,
      credit: 0
    },
    {
      accountNumber: '1010',
      accountName: 'Nostro / Central Bank Reserve Cash',
      debit: 0,
      credit: principal
    }
  ];

  if (upfrontFee > 0) {
    lines.push(
      {
        accountNumber: '1220',
        accountName: 'Accrued Fees Receivable',
        debit: upfrontFee,
        credit: 0
      },
      {
        accountNumber: '4020',
        accountName: 'Facility & Drawdown Fee Income',
        debit: 0,
        credit: upfrontFee
      }
    );
  }

  return createJournalEntry({
    referenceId: loanId,
    eventType: 'LOAN_DISBURSEMENT',
    narrative: `Disbursement of $${principal.toLocaleString()} to ${counterpartyName}${upfrontFee > 0 ? ` + $${upfrontFee} fee recognition` : ''}`,
    lines
  });
}

/**
 * Journal Entry Generator for Repayment
 */
export function makeRepaymentEntry(params: {
  loanId: string;
  counterpartyName: string;
  principal: number;
  interest: number;
  fees?: number;
}): LedgerJournalEntry {
  const { loanId, counterpartyName, principal, interest, fees = 0 } = params;
  const totalCashReceived = principal + interest + fees;

  const lines: DoubleEntryLine[] = [
    {
      accountNumber: '1010',
      accountName: 'Nostro / Central Bank Reserve Cash',
      debit: totalCashReceived,
      credit: 0
    },
    {
      accountNumber: '1200',
      accountName: 'Loans Outstanding - Institutional Principal',
      debit: 0,
      credit: principal
    },
    {
      accountNumber: '4010',
      accountName: 'Financing Interest Income',
      debit: 0,
      credit: interest
    }
  ];

  if (fees > 0) {
    lines.push({
      accountNumber: '1220',
      accountName: 'Accrued Fees Receivable',
      debit: 0,
      credit: fees
    });
  }

  return createJournalEntry({
    referenceId: loanId,
    eventType: 'LOAN_REPAYMENT',
    narrative: `Full settlement of $${principal.toLocaleString()} principal + $${interest.toLocaleString()} interest from ${counterpartyName}`,
    lines
  });
}

/**
 * Journal Entry Generator for Loan Overdue / Delinquency & ECL Provision
 */
export function makeOverdueEntry(params: {
  loanId: string;
  counterpartyName: string;
  principal: number;
  eclProvisionAmount: number;
}): LedgerJournalEntry {
  const { loanId, counterpartyName, principal, eclProvisionAmount } = params;

  const lines: DoubleEntryLine[] = [
    // Reclassify principal to overdue
    {
      accountNumber: '1290',
      accountName: 'Overdue Balances / Non-Accrual Loans',
      debit: principal,
      credit: 0
    },
    {
      accountNumber: '1200',
      accountName: 'Loans Outstanding - Institutional Principal',
      debit: 0,
      credit: principal
    },
    // ECL Provision
    {
      accountNumber: '5020',
      accountName: 'Expected Credit Loss (ECL) Provisions',
      debit: eclProvisionAmount,
      credit: 0
    },
    {
      accountNumber: '3000',
      accountName: 'Capital & Retained Reserves',
      debit: 0,
      credit: eclProvisionAmount
    }
  ];

  return createJournalEntry({
    referenceId: loanId,
    eventType: 'LOAN_DELINQUENCY_ESCALATION',
    narrative: `Reclassification of $${principal.toLocaleString()} to non-accrual for ${counterpartyName} with $${eclProvisionAmount.toLocaleString()} ECL allowance`,
    lines
  });
}
