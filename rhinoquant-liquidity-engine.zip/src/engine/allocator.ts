/**
 * RhinoQuant Automated Funding Allocation Engine
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Implements 4 allocation regimes:
 * 1. FIFO_BASELINE
 * 2. PRIORITY_WEIGHTED
 * 3. CONSTRAINED_OPTIMIZATION (Knapsack / Net Financing Contribution maximizer)
 * 4. MANUAL_REVIEW
 */

import {
  AllocationStrategy,
  Counterparty,
  Facility,
  FundingRequest,
  LiquidityPoolStatus
} from '../types';

export interface AllocationRunResult {
  strategy: AllocationStrategy;
  timestamp: string;
  totalAllocated: number;
  unallocatedAmount: number;
  remainingPoolCash: number;
  allocatedRequests: {
    requestId: string;
    allocatedAmount: number;
    allocationScore: number;
    explanation: string;
    status: 'ALLOCATED' | 'PARTIALLY_ALLOCATED' | 'REJECTED_CAPACITY' | 'DEFERRED';
  }[];
  objectiveMetrics: {
    totalExpectedNetIncome: number;
    averageSpreadBps: number;
    liquidityBufferPreserved: number;
    capitalEfficiencyScore: number;
  };
}

/**
 * Score request for priority-weighted allocation
 */
function calculatePriorityScore(
  req: FundingRequest,
  counterparty: Counterparty,
  facility: Facility
): number {
  let score = 50;

  // Credit rating weight
  const ratingWeights: Record<Counterparty['creditRating'], number> = {
    AAA: 30, 'AA+': 27, AA: 25, 'AA-': 22, 'A+': 18, A: 15, 'BBB+': 10, BBB: 5, 'BB+': 0
  };
  score += ratingWeights[counterparty.creditRating] || 10;

  // Internal treasury desk priority
  if (counterparty.isInternal) score += 20;

  // Spread / margin contribution
  if (req.pricingQuote) {
    score += Math.min(25, (req.pricingQuote.targetMarginBps + req.pricingQuote.creditSpreadBps) / 4);
  }

  // Tenor efficiency (shorter tenors preserve liquidity velocity)
  if (req.tenorHours <= 4) score += 15;
  else if (req.tenorHours <= 24) score += 10;
  else score += 2;

  return Number(score.toFixed(1));
}

/**
 * Executes liquidity allocation under a specified strategy
 */
export function runAllocation(params: {
  strategy: AllocationStrategy;
  requests: FundingRequest[];
  counterparties: Counterparty[];
  facilities: Facility[];
  liquidityPool: LiquidityPoolStatus;
}): AllocationRunResult {
  const { strategy, requests, counterparties, facilities, liquidityPool } = params;

  // Eligible pool cash for allocation (strictly respecting minimum liquidity buffer)
  let availableCash = Math.max(0, liquidityPool.availableForAllocation);
  const cpMap = new Map(counterparties.map((c) => [c.id, c]));
  const facMap = new Map(facilities.map((f) => [f.id, f]));

  // Filter requests that are eligible for allocation (e.g. Approved or Quoted or Queued)
  const candidateRequests = requests.filter(
    (r) => ['APPROVED', 'QUOTED', 'QUEUED', 'PARTIALLY_APPROVED'].includes(r.status) ||
           ['APPROVED', 'PARTIALLY_APPROVED', 'QUEUED'].includes(r.decisionStatus)
  );

  let sortedRequests = [...candidateRequests];

  if (strategy === 'FIFO_BASELINE') {
    // Sort strictly by submitted timestamp
    sortedRequests.sort((a, b) => new Date(a.submittedAt).getTime() - new Date(b.submittedAt).getTime());
  } else if (strategy === 'PRIORITY_WEIGHTED') {
    // Sort by priority score
    sortedRequests.sort((a, b) => {
      const cpA = cpMap.get(a.borrowerId);
      const cpB = cpMap.get(b.borrowerId);
      const facA = facMap.get(a.facilityId);
      const facB = facMap.get(b.facilityId);
      const scoreA = cpA && facA ? calculatePriorityScore(a, cpA, facA) : 0;
      const scoreB = cpB && facB ? calculatePriorityScore(b, cpB, facB) : 0;
      return scoreB - scoreA;
    });
  } else if (strategy === 'CONSTRAINED_OPTIMIZATION') {
    // Multi-objective knapsack: maximize Net Financing Contribution per unit of cash committed
    // NFC = Expected Interest Income + Fees - Cost of Funds - Capital Charge
    sortedRequests.sort((a, b) => {
      const quoteA = a.pricingQuote;
      const quoteB = b.pricingQuote;
      const nfcRateA = quoteA ? (quoteA.totalQuotedAnnualizedRate - quoteA.referenceFundingRate) : 0.005;
      const nfcRateB = quoteB ? (quoteB.totalQuotedAnnualizedRate - quoteB.referenceFundingRate) : 0.005;

      // Density ratio: NFC / duration
      const densityA = nfcRateA * (1 / Math.max(1, a.tenorHours / 24));
      const densityB = nfcRateB * (1 / Math.max(1, b.tenorHours / 24));
      return densityB - densityA;
    });
  }

  const allocatedItems: AllocationRunResult['allocatedRequests'] = [];
  let totalAllocated = 0;
  let totalNetIncome = 0;
  let weightedSpreadSum = 0;

  for (const req of sortedRequests) {
    const cp = cpMap.get(req.borrowerId);
    const fac = facMap.get(req.facilityId);
    const score = cp && fac ? calculatePriorityScore(req, cp, fac) : 50;

    const targetAmount = req.approvedAmount || req.requestedAmount;

    if (availableCash >= targetAmount) {
      availableCash -= targetAmount;
      totalAllocated += targetAmount;

      const spreadBps = req.pricingQuote ? (req.pricingQuote.creditSpreadBps + req.pricingQuote.targetMarginBps) : 50;
      weightedSpreadSum += spreadBps * targetAmount;
      totalNetIncome += req.pricingQuote ? req.pricingQuote.estimatedInterestAmount : 0;

      allocatedItems.push({
        requestId: req.id,
        allocatedAmount: targetAmount,
        allocationScore: score,
        explanation: `${strategy} allocation: Full allocation of $${targetAmount.toLocaleString()}. Met all counterparty, facility, and liquidity buffer constraints.`,
        status: 'ALLOCATED'
      });
    } else if (availableCash > 0 && availableCash >= targetAmount * 0.4) {
      // Partial allocation under capacity boundary
      const partial = Number(availableCash.toFixed(2));
      totalAllocated += partial;
      availableCash = 0;

      allocatedItems.push({
        requestId: req.id,
        allocatedAmount: partial,
        allocationScore: score,
        explanation: `${strategy} allocation: Partial allocation ($${partial.toLocaleString()} of $${targetAmount.toLocaleString()}) due to pool liquidity limit. Preserved $${liquidityPool.minimumLiquidityBuffer.toLocaleString()} regulatory buffer.`,
        status: 'PARTIALLY_ALLOCATED'
      });
    } else {
      allocatedItems.push({
        requestId: req.id,
        allocatedAmount: 0,
        allocationScore: score,
        explanation: `${strategy} allocation: Deferred due to liquidity buffer preservation. Required $${targetAmount.toLocaleString()}, but pool availability reached zero headroom.`,
        status: 'REJECTED_CAPACITY'
      });
    }
  }

  const unallocatedAmount = candidateRequests.reduce((sum, r) => sum + (r.approvedAmount || r.requestedAmount), 0) - totalAllocated;
  const avgSpreadBps = totalAllocated > 0 ? Number((weightedSpreadSum / totalAllocated).toFixed(1)) : 0;

  return {
    strategy,
    timestamp: new Date().toISOString(),
    totalAllocated: Number(totalAllocated.toFixed(2)),
    unallocatedAmount: Math.max(0, Number(unallocatedAmount.toFixed(2))),
    remainingPoolCash: Number(availableCash.toFixed(2)),
    allocatedRequests: allocatedItems,
    objectiveMetrics: {
      totalExpectedNetIncome: Number(totalNetIncome.toFixed(2)),
      averageSpreadBps: avgSpreadBps,
      liquidityBufferPreserved: liquidityPool.minimumLiquidityBuffer,
      capitalEfficiencyScore: Number((totalAllocated / Math.max(1, liquidityPool.totalCapacity) * 100).toFixed(1))
    }
  };
}
