/**
 * RhinoQuant Collateral & Borrowing Base Engine
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Implements borrowing base calculations, haircut adjustments, encumbrance tracking,
 * asset allocation, and substitution simulations.
 */

import { CollateralAsset } from '../types';

export const COLLATERAL_LEGAL_DISCLAIMER =
  'LEGAL NOTICE: The collateral valuations and borrowing-base capacities recorded herein reflect internal quantitative risk-monitoring metrics. They do not constitute legal proof of perfection, priority, or enforceable security interest under applicable commercial law (e.g., UCC Article 9, UK Financial Collateral Arrangements Regulations, or German BGB Pfandrecht). Perfection requires executed security deeds, control agreements, and registration.';

/**
 * Standard haircut guidelines by asset class
 */
export const ASSET_CLASS_HAIRCUTS: Record<CollateralAsset['assetClass'], number> = {
  US_TREASURY: 2.0,
  GERMAN_BUND: 2.5,
  UK_GILT: 3.5,
  AAA_COMMERCIAL_PAPER: 12.0,
  CORP_BOND_IG: 15.0,
  TRADE_RECEIVABLES: 25.0
};

/**
 * Calculates net borrowing base contribution for an individual collateral asset
 */
export function calculateAssetBorrowingBase(asset: CollateralAsset): number {
  const postHaircutValue = asset.marketValue * (1 - asset.haircutPercent / 100);
  const availableBase = postHaircutValue - asset.priorEncumbranceAmount - asset.currentlyAllocatedAmount;
  return Math.max(0, Number(availableBase.toFixed(2)));
}

/**
 * Calculates total available borrowing base across all assets pledged by a counterparty
 */
export function calculateCounterpartyBorrowingBase(
  assets: CollateralAsset[],
  counterpartyId: string
): {
  totalMarketValue: number;
  totalPostHaircutValue: number;
  totalPriorEncumbrance: number;
  totalCurrentlyAllocated: number;
  netAvailableBorrowingBase: number;
  assets: CollateralAsset[];
} {
  const cpAssets = assets.filter((a) => a.counterpartyId === counterpartyId);

  let totalMarketValue = 0;
  let totalPostHaircutValue = 0;
  let totalPriorEncumbrance = 0;
  let totalCurrentlyAllocated = 0;

  const evaluatedAssets = cpAssets.map((asset) => {
    const postHaircut = asset.marketValue * (1 - asset.haircutPercent / 100);
    const available = Math.max(0, postHaircut - asset.priorEncumbranceAmount - asset.currentlyAllocatedAmount);

    totalMarketValue += asset.marketValue;
    totalPostHaircutValue += postHaircut;
    totalPriorEncumbrance += asset.priorEncumbranceAmount;
    totalCurrentlyAllocated += asset.currentlyAllocatedAmount;

    return {
      ...asset,
      eligibleBorrowingBase: Number(available.toFixed(2))
    };
  });

  const netAvailableBorrowingBase = Math.max(
    0,
    totalPostHaircutValue - totalPriorEncumbrance - totalCurrentlyAllocated
  );

  return {
    totalMarketValue: Number(totalMarketValue.toFixed(2)),
    totalPostHaircutValue: Number(totalPostHaircutValue.toFixed(2)),
    totalPriorEncumbrance: Number(totalPriorEncumbrance.toFixed(2)),
    totalCurrentlyAllocated: Number(totalCurrentlyAllocated.toFixed(2)),
    netAvailableBorrowingBase: Number(netAvailableBorrowingBase.toFixed(2)),
    assets: evaluatedAssets
  };
}

/**
 * Allocates collateral to back a new funding reservation or disbursement
 */
export function allocateCollateralForLoan(
  assets: CollateralAsset[],
  counterpartyId: string,
  requiredCollateralAmount: number
): {
  success: boolean;
  allocations: { assetId: string; amount: number }[];
  updatedAssets: CollateralAsset[];
  shortfall: number;
} {
  let remainingRequired = requiredCollateralAmount;
  const allocations: { assetId: string; amount: number }[] = [];
  const updatedAssets = assets.map((a) => ({ ...a }));

  for (const asset of updatedAssets) {
    if (asset.counterpartyId !== counterpartyId) continue;
    if (remainingRequired <= 0) break;

    const available = calculateAssetBorrowingBase(asset);
    if (available > 0) {
      const allocateThis = Math.min(available, remainingRequired);
      asset.currentlyAllocatedAmount += allocateThis;
      asset.eligibleBorrowingBase = calculateAssetBorrowingBase(asset);
      allocations.push({ assetId: asset.id, amount: allocateThis });
      remainingRequired -= allocateThis;
    }
  }

  return {
    success: remainingRequired <= 0.01,
    allocations,
    updatedAssets,
    shortfall: Math.max(0, Number(remainingRequired.toFixed(2)))
  };
}

/**
 * Releases collateral when a loan is repaid or reservation cancelled
 */
export function releaseCollateralAllocations(
  assets: CollateralAsset[],
  allocations: { assetId: string; amount: number }[]
): CollateralAsset[] {
  const allocationMap = new Map<string, number>();
  for (const item of allocations) {
    allocationMap.set(item.assetId, (allocationMap.get(item.assetId) || 0) + item.amount);
  }

  return assets.map((asset) => {
    const releaseAmt = allocationMap.get(asset.id);
    if (!releaseAmt) return asset;

    const newAllocated = Math.max(0, asset.currentlyAllocatedAmount - releaseAmt);
    const updated = {
      ...asset,
      currentlyAllocatedAmount: newAllocated
    };
    updated.eligibleBorrowingBase = calculateAssetBorrowingBase(updated);
    return updated;
  });
}

/**
 * Simulates collateral substitution (e.g., releasing existing asset and pledging substitute)
 */
export function simulateCollateralSubstitution(
  currentAssets: CollateralAsset[],
  retiringAssetId: string,
  substituteAsset: {
    assetClass: CollateralAsset['assetClass'];
    marketValue: number;
    priorEncumbrance: number;
    description: string;
  }
): {
  isPermitted: boolean;
  borrowingBaseDelta: number;
  reason: string;
  simulatedNewBase: number;
} {
  const target = currentAssets.find((a) => a.id === retiringAssetId);
  if (!target) {
    return {
      isPermitted: false,
      borrowingBaseDelta: 0,
      reason: 'Asset to substitute not found in inventory',
      simulatedNewBase: 0
    };
  }

  // Current post-haircut value of retiring asset
  const currentPostHaircut = target.marketValue * (1 - target.haircutPercent / 100) - target.priorEncumbranceAmount;

  // Substitute asset post-haircut value
  const subHaircut = ASSET_CLASS_HAIRCUTS[substituteAsset.assetClass] || 15;
  const subPostHaircut = substituteAsset.marketValue * (1 - subHaircut / 100) - substituteAsset.priorEncumbrance;

  const borrowingBaseDelta = Number((subPostHaircut - currentPostHaircut).toFixed(2));

  // Must cover existing allocations
  if (subPostHaircut < target.currentlyAllocatedAmount) {
    return {
      isPermitted: false,
      borrowingBaseDelta,
      reason: `Substitute asset post-haircut value ($${subPostHaircut.toLocaleString()}) cannot cover currently allocated debt commitments ($${target.currentlyAllocatedAmount.toLocaleString()}).`,
      simulatedNewBase: subPostHaircut
    };
  }

  return {
    isPermitted: true,
    borrowingBaseDelta,
    reason: `Substitution approved. Meets or exceeds minimum coverage ratio. Borrowing base delta: ${borrowingBaseDelta >= 0 ? '+' : ''}$${borrowingBaseDelta.toLocaleString()}.`,
    simulatedNewBase: subPostHaircut
  };
}
