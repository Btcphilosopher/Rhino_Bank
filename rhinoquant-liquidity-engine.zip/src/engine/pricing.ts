/**
 * RhinoQuant Quantitative Pricing Engine
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Implements the institutional multi-component pricing framework:
 * Quoted rate = Reference rate + Tenor adjustment + Credit spread + Liquidity adjustment
 *             + Capital-cost allocation + Operating-cost allocation + Target margin
 */

import { Counterparty, Currency, PricingBreakdown, ProductType } from '../types';

export interface PricingParameters {
  referenceRates: {
    SOFR: { rate: number; source: string; ageMinutes: number };
    ESTR: { rate: number; source: string; ageMinutes: number };
    SONIA: { rate: number; source: string; ageMinutes: number };
    INTERNAL_TRANSFER_RATE: { rate: number; source: string; ageMinutes: number };
  };
  policyVersion: string;
}

export const CURRENT_PRICING_BENCHMARKS: PricingParameters = {
  referenceRates: {
    SOFR: { rate: 0.0482, source: 'NY Fed SOFR 08:00 EST', ageMinutes: 12 },
    ESTR: { rate: 0.0365, source: 'ECB €STR Fixing 07:00 CET', ageMinutes: 28 },
    SONIA: { rate: 0.0515, source: 'Bank of England SONIA 09:00 GMT', ageMinutes: 15 },
    INTERNAL_TRANSFER_RATE: { rate: 0.0470, source: 'RhinoBank Internal ALM Transfer Desk', ageMinutes: 5 }
  },
  policyVersion: 'RQ-POL-2026.4.1'
};

/**
 * Maps credit rating to basis points credit spread
 */
export function getRatingCreditSpreadBps(rating: Counterparty['creditRating'], isInternal: boolean): number {
  if (isInternal) return 0;
  switch (rating) {
    case 'AAA': return 15;
    case 'AA+': return 25;
    case 'AA': return 30;
    case 'AA-': return 35;
    case 'A+': return 45;
    case 'A': return 60;
    case 'BBB+': return 95;
    case 'BBB': return 135;
    case 'BB+': return 210;
    default: return 150;
  }
}

/**
 * Calculates tenor adjustment based on loan duration in hours
 */
export function getTenorAdjustmentBps(tenorHours: number, productType: ProductType): number {
  if (productType === 'INTRADAY_ADVANCE') {
    if (tenorHours <= 2) return -12;
    if (tenorHours <= 4) return -8;
    return -4;
  }
  if (tenorHours <= 24) return 0; // Overnight flat
  if (tenorHours <= 72) return 5;
  if (tenorHours <= 168) return 12; // 7 days
  if (tenorHours <= 336) return 18; // 14 days
  return 25; // 30 days
}

/**
 * Calculates dynamic liquidity adjustment based on current pool utilization
 */
export function getLiquidityAdjustmentBps(utilizationPct: number): number {
  if (utilizationPct < 0.40) return 2;
  if (utilizationPct < 0.60) return 6;
  if (utilizationPct < 0.75) return 12;
  if (utilizationPct < 0.85) return 22;
  return 45; // High scarcity premium
}

/**
 * Capital cost allocation (Basel III/IV standardized RWA charge)
 */
export function getCapitalCostBps(productType: ProductType, isInternal: boolean): number {
  if (isInternal) return 0;
  if (productType === 'INTRADAY_ADVANCE') return 8;
  if (productType === 'OVERNIGHT_LOAN') return 14;
  if (productType === 'INTERBANK_LENDING') return 10;
  if (productType === 'SECURED_WORKING_CAPITAL') return 22;
  if (productType === 'RECEIVABLES_BACKED') return 25;
  return 20;
}

/**
 * Calculates comprehensive pricing breakdown for a funding request
 */
export function calculateQuote(params: {
  counterparty: Counterparty;
  productType: ProductType;
  currency: Currency;
  principal: number;
  tenorHours: number;
  poolUtilizationPct: number;
  benchmarks?: PricingParameters;
}): PricingBreakdown {
  const {
    counterparty,
    productType,
    currency,
    principal,
    tenorHours,
    poolUtilizationPct,
    benchmarks = CURRENT_PRICING_BENCHMARKS
  } = params;

  // 1. Reference rate selection
  let refKey: 'SOFR' | 'ESTR' | 'SONIA' | 'INTERNAL_TRANSFER_RATE' = 'SOFR';
  if (counterparty.isInternal || productType === 'INTERNAL_TREASURY_ALLOCATION') {
    refKey = 'INTERNAL_TRANSFER_RATE';
  } else if (currency === 'EUR') {
    refKey = 'ESTR';
  } else if (currency === 'GBP') {
    refKey = 'SONIA';
  } else {
    refKey = 'SOFR';
  }

  const refRateData = benchmarks.referenceRates[refKey];
  const referenceRate = refRateData.rate;

  // 2. Component calculations in basis points
  const tenorAdjBps = getTenorAdjustmentBps(tenorHours, productType);
  const creditSpreadBps = getRatingCreditSpreadBps(counterparty.creditRating, counterparty.isInternal);
  const liquidityAdjBps = getLiquidityAdjustmentBps(poolUtilizationPct);
  const capitalCostBps = getCapitalCostBps(productType, counterparty.isInternal);
  const operatingCostBps = counterparty.isInternal ? 2 : 5;
  const targetMarginBps = counterparty.isInternal ? 0 : 18;

  // Total spread in bps converted to decimal
  const totalSpreadBps = tenorAdjBps + creditSpreadBps + liquidityAdjBps + capitalCostBps + operatingCostBps + targetMarginBps;
  const totalQuotedAnnualizedRate = Number((referenceRate + (totalSpreadBps / 10000)).toFixed(6));

  // Day-count convention: ACT/360 for USD/EUR, ACT/365 for GBP
  const dayCountConvention: 'ACT/360' | 'ACT/365' = currency === 'GBP' ? 'ACT/365' : 'ACT/360';
  const dayCountDivisor = dayCountConvention === 'ACT/365' ? 365 : 360;

  // Actual cash-flow interest amount for tenor
  const timeFraction = tenorHours / (24 * dayCountDivisor);
  const estimatedInterestAmount = Number((principal * totalQuotedAnnualizedRate * timeFraction).toFixed(2));

  // Facility Drawdown fee: 0.5 bps flat for external, 0 for internal
  const feeRate = counterparty.isInternal ? 0 : 0.00005;
  const facilityDrawdownFee = Number((principal * feeRate).toFixed(2));

  // Cashflow-based effective annualized cost
  const totalFinancingCost = estimatedInterestAmount + facilityDrawdownFee;
  const effectiveCostRateAnnualized = Number(
    (timeFraction > 0 ? (totalFinancingCost / principal) / timeFraction : totalQuotedAnnualizedRate).toFixed(6)
  );

  // Quote expiration: exactly 30 minutes from now
  const now = new Date();
  const quoteExpiryTimestamp = new Date(now.getTime() + 30 * 60 * 1000).toISOString();

  return {
    referenceFundingRate: referenceRate,
    referenceSource: refRateData.source,
    referenceAgeMinutes: refRateData.ageMinutes,
    tenorAdjustmentBps: tenorAdjBps,
    creditSpreadBps,
    liquidityAdjustmentBps: liquidityAdjBps,
    capitalCostAllocationBps: capitalCostBps,
    operatingCostAllocationBps: operatingCostBps,
    targetMarginBps,
    totalQuotedAnnualizedRate,
    dayCountConvention,
    tenorHours,
    estimatedInterestAmount,
    facilityDrawdownFee,
    effectiveCostRateAnnualized,
    quoteExpiryTimestamp,
    policyVersion: benchmarks.policyVersion
  };
}
