/**
 * RhinoQuant Multidimensional Limits & Policy Verification Engine
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Enforces hierarchical limit constraints:
 * Individual Counterparty -> Economic Corporate Group -> Sector -> Country -> Currency -> Product
 */

import {
  CollateralAsset,
  Counterparty,
  DecisionStatus,
  Facility,
  FundingRequest,
  LiquidityPoolStatus,
  ProductType
} from '../types';
import { calculateCounterpartyBorrowingBase } from './collateral';

// Institutional Portfolio Concentration Limits
export const PORTFOLIO_CONCENTRATION_LIMITS = {
  maxGroupExposureUsd: 150_000_000,
  maxSectorExposureUsd: {
    CLEARING_BROKER: 180_000_000,
    ASSET_MANAGER: 160_000_000,
    COMMODITIES_TRADER: 90_000_000,
    ARBITRAGE_FUND: 60_000_000,
    CENTRAL_BANK: 250_000_000,
    INTERNAL_TREASURY: 200_000_000
  },
  maxCountryExposureUsd: {
    USA: 300_000_000,
    DEU: 250_000_000,
    GBR: 120_000_000,
    CHE: 80_000_000,
    SGP: 60_000_000
  }
};

export interface PolicyEvaluationResult {
  decision: DecisionStatus;
  approvedAmount: number;
  reasons: string[];
  policyVersion: string;
  isIdempotentDuplicate: boolean;
  requiresMakerChecker: boolean;
}

/**
 * Validates a funding request against all hierarchical institutional policies
 */
export function evaluateFundingRequest(params: {
  request: FundingRequest;
  existingRequests: FundingRequest[];
  facility: Facility;
  counterparty: Counterparty;
  allCounterparties: Counterparty[];
  allFacilities: Facility[];
  collateralAssets: CollateralAsset[];
  liquidityPool: LiquidityPoolStatus;
  isCircuitBreakerActive: boolean;
  pausedProducts: ProductType[];
  policyVersion?: string;
}): PolicyEvaluationResult {
  const {
    request,
    existingRequests,
    facility,
    counterparty,
    allCounterparties,
    allFacilities,
    collateralAssets,
    liquidityPool,
    isCircuitBreakerActive,
    pausedProducts,
    policyVersion = 'RQ-POL-2026.4.1'
  } = params;

  const reasons: string[] = [];

  // 1. Idempotency Check: prevent duplicate event processing
  const duplicate = existingRequests.find(
    (r) => r.idempotencyKey === request.idempotencyKey && r.id !== request.id
  );
  if (duplicate) {
    return {
      decision: duplicate.decisionStatus,
      approvedAmount: duplicate.approvedAmount || 0,
      reasons: [`Duplicate request detected with Idempotency Key: ${request.idempotencyKey}. Returned prior authoritative decision.`],
      policyVersion,
      isIdempotentDuplicate: true,
      requiresMakerChecker: false
    };
  }

  // 2. Circuit Breaker & Paused Products Check
  if (isCircuitBreakerActive) {
    return {
      decision: 'DECLINED',
      approvedAmount: 0,
      reasons: ['Global Liquidity Circuit Breaker is active. All new funding commitments are paused.'],
      policyVersion,
      isIdempotentDuplicate: false,
      requiresMakerChecker: false
    };
  }

  if (pausedProducts.includes(request.productType)) {
    return {
      decision: 'DECLINED',
      approvedAmount: 0,
      reasons: [`Product line [${request.productType}] has been paused by the Senior Risk Officer.`],
      policyVersion,
      isIdempotentDuplicate: false,
      requiresMakerChecker: false
    };
  }

  // 3. Counterparty Documentation & Covenant Status
  if (counterparty.documentationStatus !== 'EXECUTED_CURRENT') {
    return {
      decision: 'REFERRED',
      approvedAmount: 0,
      reasons: [`Counterparty documentation status is '${counterparty.documentationStatus}'. Requires Compliance Maker-Checker renewal.`],
      policyVersion,
      isIdempotentDuplicate: false,
      requiresMakerChecker: true
    };
  }

  if (counterparty.covenantBreached) {
    return {
      decision: 'DECLINED',
      approvedAmount: 0,
      reasons: [
        `Counterparty is in covenant breach (Current Liquidity Ratio: ${counterparty.currentLiquidityRatio}x vs min ${counterparty.minLiquidityRatioCovenant}x).`
      ],
      policyVersion,
      isIdempotentDuplicate: false,
      requiresMakerChecker: false
    };
  }

  // 4. Facility Status & Permitted Tenors
  if (!facility.isActive) {
    return {
      decision: 'DECLINED',
      approvedAmount: 0,
      reasons: [`Facility [${facility.facilityCode}] is inactive or revoked.`],
      policyVersion,
      isIdempotentDuplicate: false,
      requiresMakerChecker: false
    };
  }

  const facilityExpiry = new Date(facility.expiryDate);
  if (facilityExpiry.getTime() < Date.now()) {
    return {
      decision: 'DECLINED',
      approvedAmount: 0,
      reasons: [`Facility [${facility.facilityCode}] expired on ${facility.expiryDate}.`],
      policyVersion,
      isIdempotentDuplicate: false,
      requiresMakerChecker: false
    };
  }

  if (!facility.permittedTenorsHours.includes(request.tenorHours)) {
    return {
      decision: 'DECLINED',
      approvedAmount: 0,
      reasons: [
        `Requested tenor ${request.tenorHours}h is not permitted for facility ${facility.facilityCode}. Permitted: [${facility.permittedTenorsHours.join(', ')}h].`
      ],
      policyVersion,
      isIdempotentDuplicate: false,
      requiresMakerChecker: false
    };
  }

  // 5. Facility Headroom Availability
  const facilityHeadroom = Math.max(0, facility.approvedLimit - facility.currentDrawn - facility.currentReserved);
  if (facilityHeadroom <= 0) {
    return {
      decision: 'DECLINED',
      approvedAmount: 0,
      reasons: [`Facility capacity exhausted (Limit: $${facility.approvedLimit.toLocaleString()}, Drawn: $${facility.currentDrawn.toLocaleString()}, Reserved: $${facility.currentReserved.toLocaleString()}).`],
      policyVersion,
      isIdempotentDuplicate: false,
      requiresMakerChecker: false
    };
  }

  // 6. Economic Group Exposure Limits
  const groupBorrowerIds = allCounterparties
    .filter((cp) => cp.corporateGroupId === counterparty.corporateGroupId)
    .map((cp) => cp.id);

  const groupFacilities = allFacilities.filter((f) => groupBorrowerIds.includes(f.borrowerId));
  const currentGroupExposure = groupFacilities.reduce((sum, f) => sum + f.currentDrawn + f.currentReserved, 0);
  const maxGroupLimit = PORTFOLIO_CONCENTRATION_LIMITS.maxGroupExposureUsd;
  const groupHeadroom = Math.max(0, maxGroupLimit - currentGroupExposure);

  if (groupHeadroom <= 0) {
    return {
      decision: 'REFERRED',
      approvedAmount: 0,
      reasons: [
        `Economic group [${counterparty.corporateGroupName}] exposure cap of $${maxGroupLimit.toLocaleString()} reached. Current exposure: $${currentGroupExposure.toLocaleString()}.`
      ],
      policyVersion,
      isIdempotentDuplicate: false,
      requiresMakerChecker: true
    };
  }

  // 7. Lender Liquidity Pool Availability (preserving minimum liquidity buffer)
  const availableLenderCash = Math.max(0, liquidityPool.availableForAllocation);
  if (availableLenderCash <= 0) {
    return {
      decision: 'QUEUED',
      approvedAmount: 0,
      reasons: [
        `Lender uncommitted cash is at or below the minimum regulatory liquidity buffer ($${liquidityPool.minimumLiquidityBuffer.toLocaleString()}). Request queued.`
      ],
      policyVersion,
      isIdempotentDuplicate: false,
      requiresMakerChecker: false
    };
  }

  // 8. Collateral Coverage Verification (for secured facilities)
  let maxAmountAllowedByCollateral = request.requestedAmount;
  if (facility.requiresCollateral) {
    const cpBorrowingBase = calculateCounterpartyBorrowingBase(collateralAssets, counterparty.id);
    const requiredCoverageMultiplier = facility.minCollateralCoverageRatio || 1.05;
    const maxCapacityFromCollateral = cpBorrowingBase.netAvailableBorrowingBase / requiredCoverageMultiplier;

    if (maxCapacityFromCollateral <= 0) {
      return {
        decision: 'QUEUED',
        approvedAmount: 0,
        reasons: [
          `Pledged collateral borrowing base exhausted. Net available borrowing base: $${cpBorrowingBase.netAvailableBorrowingBase.toLocaleString()}.`
        ],
        policyVersion,
        isIdempotentDuplicate: false,
        requiresMakerChecker: false
      };
    }

    maxAmountAllowedByCollateral = maxCapacityFromCollateral;
  }

  // Determine feasible approved amount
  const feasibleAmount = Math.min(
    request.requestedAmount,
    facilityHeadroom,
    groupHeadroom,
    availableLenderCash,
    maxAmountAllowedByCollateral
  );

  // Check if fully approved, partially approved, or queued
  if (feasibleAmount >= request.requestedAmount) {
    reasons.push(
      `Facility capacity verified ($${facilityHeadroom.toLocaleString()} headroom)`,
      `Group exposure within limits ($${groupHeadroom.toLocaleString()} headroom)`,
      `Lender liquidity reserved from uncommitted cash`,
      facility.requiresCollateral ? 'Collateral borrowing base verified' : 'Unsecured facility terms verified'
    );
    return {
      decision: 'APPROVED',
      approvedAmount: request.requestedAmount,
      reasons,
      policyVersion,
      isIdempotentDuplicate: false,
      requiresMakerChecker: false
    };
  } else if (feasibleAmount > 0 && feasibleAmount >= request.requestedAmount * 0.4) {
    // Partial approval if at least 40% can be funded
    reasons.push(
      `Partially approved for $${feasibleAmount.toLocaleString()} of requested $${request.requestedAmount.toLocaleString()}`,
      `Binding constraint: ${
        feasibleAmount === facilityHeadroom
          ? 'Facility Headroom'
          : feasibleAmount === groupHeadroom
          ? 'Economic Group Cap'
          : feasibleAmount === availableLenderCash
          ? 'Lender Available Liquidity'
          : 'Collateral Borrowing Base'
      }`
    );
    return {
      decision: 'PARTIALLY_APPROVED',
      approvedAmount: Number(feasibleAmount.toFixed(2)),
      reasons,
      policyVersion,
      isIdempotentDuplicate: false,
      requiresMakerChecker: false
    };
  } else {
    // Cannot fund sufficiently
    return {
      decision: 'QUEUED',
      approvedAmount: 0,
      reasons: [
        `Insufficient capacity to meet minimum draw threshold. Feasible: $${feasibleAmount.toLocaleString()} vs Requested: $${request.requestedAmount.toLocaleString()}.`
      ],
      policyVersion,
      isIdempotentDuplicate: false,
      requiresMakerChecker: false
    };
  }
}
