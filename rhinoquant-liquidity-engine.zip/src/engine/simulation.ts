/**
 * RhinoQuant Simulation Lab & Scenario Engine
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 *
 * Implements the 10 prompt-required institutional simulation scenarios:
 * 1. Concurrent overnight requests
 * 2. Competing use of limited cash
 * 3. Collateral-backed availability
 * 4. Quote acceptance and expiry
 * 5. Partial approval
 * 6. Duplicate request delivery (Idempotency test)
 * 7. Payment timeout with uncertain outcome (Reconciliation guard)
 * 8. Confirmed repayment
 * 9. An overdue loan
 * 10. Liquidity stress that pauses new lending (Circuit Breaker)
 */

import {
  CollateralAsset,
  Counterparty,
  Facility,
  FundingRequest,
  LedgerJournalEntry,
  LiquidityPoolStatus
} from '../types';
import { evaluateFundingRequest } from './limits';
import { calculateQuote } from './pricing';
import { allocateCollateralForLoan, releaseCollateralAllocations } from './collateral';
import { makeDisbursementEntry, makeRepaymentEntry, makeOverdueEntry, createJournalEntry } from './ledger';
import { runAllocation } from './allocator';

export interface SimulationScenarioDef {
  id: string;
  scenarioNumber: number;
  title: string;
  category: 'CONCURRENCY' | 'COLLATERAL' | 'LIFECYCLE' | 'FAILURE_HANDLING' | 'MACRO_STRESS';
  summary: string;
  expectedOutcome: string;
}

export const SIMULATION_SCENARIOS: SimulationScenarioDef[] = [
  {
    id: 'SCENARIO-01',
    scenarioNumber: 1,
    title: 'Concurrent Overnight Requests',
    category: 'CONCURRENCY',
    summary: 'Dispatches 3 simultaneous overnight drawdowns from different institutional counterparties to test lock-free concurrency and isolation.',
    expectedOutcome: 'All requests receive atomic pricing and sequential reservations without double-allocating headroom.'
  },
  {
    id: 'SCENARIO-02',
    scenarioNumber: 2,
    title: 'Competing Use of Limited Cash',
    category: 'CONCURRENCY',
    summary: 'Simulates $280M in simultaneous funding demands against $252M available liquidity to trigger rationing and compare allocation policies.',
    expectedOutcome: 'High-spread and high-rated requests prioritized; lowest tier deferred while preserving $60M regulatory buffer.'
  },
  {
    id: 'SCENARIO-03',
    scenarioNumber: 3,
    title: 'Collateral-Backed Availability & Haircuts',
    category: 'COLLATERAL',
    summary: 'Counterparty requests draw where market value seems high but post-haircut borrowing base is restrictive.',
    expectedOutcome: 'Borrowing base rule strictly bounds funding amount; surplus market value discounted by asset haircut.'
  },
  {
    id: 'SCENARIO-04',
    scenarioNumber: 4,
    title: 'Quote Acceptance and Expiry Lifecycle',
    category: 'LIFECYCLE',
    summary: 'Generates pricing quote with 30-minute validity; simulates quote expiry when borrower does not accept terms in time.',
    expectedOutcome: 'Unaccepted quote transitions to EXPIRED; uncommitted reservations released automatically.'
  },
  {
    id: 'SCENARIO-05',
    scenarioNumber: 5,
    title: 'Partial Facility Approval',
    category: 'LIFECYCLE',
    summary: 'Borrower requests $20M on a facility with only $12M unutilized contractual headroom remaining.',
    expectedOutcome: 'Engine returns PARTIALLY_APPROVED for $12M with explicit reason stating facility headroom binding constraint.'
  },
  {
    id: 'SCENARIO-06',
    scenarioNumber: 6,
    title: 'Duplicate Request Delivery (Idempotency Key)',
    category: 'FAILURE_HANDLING',
    summary: 'Sends identical request payload twice with identical Idempotency Key to simulate network retries.',
    expectedOutcome: 'Second call immediately detected as duplicate; returns prior authoritative record without duplicate reservation.'
  },
  {
    id: 'SCENARIO-07',
    scenarioNumber: 7,
    title: 'Payment Adapter Timeout (Uncertain Settlement)',
    category: 'FAILURE_HANDLING',
    summary: 'Simulates Fedwire payment adapter timeout with ACK missing; prevents auto-retry to stop duplicate disbursement.',
    expectedOutcome: 'Loan flagged as DISPUTED / RECONCILIATION_REQUIRED; funds isolated in committed transit account.'
  },
  {
    id: 'SCENARIO-08',
    scenarioNumber: 8,
    title: 'Confirmed Repayment & Ledger Resolution',
    category: 'LIFECYCLE',
    summary: 'Disbursed loan reaches maturity and counterparty wire settles principal and accrued interest.',
    expectedOutcome: 'Subledger debits Nostro cash and credits Loans Outstanding; collateral pledge automatically released.'
  },
  {
    id: 'SCENARIO-09',
    scenarioNumber: 9,
    title: 'Overdue Loan & Delinquency Escalation',
    category: 'LIFECYCLE',
    summary: 'Counterparty fails to wire repayment past grace cutoff; loan escalated to non-accrual with ECL provision.',
    expectedOutcome: 'Reclassified to Account 1290 (Overdue Balances) and debit recognized in Account 5020 (ECL Provisions).'
  },
  {
    id: 'SCENARIO-10',
    scenarioNumber: 10,
    title: 'Liquidity Stress & Circuit Breaker Pause',
    category: 'MACRO_STRESS',
    summary: 'Macro liquidity shock depletes uncommitted cash below the $60M regulatory buffer threshold.',
    expectedOutcome: 'Global Circuit Breaker triggers automatically; all new funding commitments paused immediately.'
  }
];

export interface ScenarioRunResult {
  scenarioId: string;
  scenarioTitle: string;
  executedAt: string;
  logs: string[];
  updatedRequests: FundingRequest[];
  updatedFacilities: Facility[];
  updatedCollateral: CollateralAsset[];
  updatedLiquidityPool: LiquidityPoolStatus;
  updatedLedgerEntries: LedgerJournalEntry[];
  circuitBreakerActive: boolean;
  circuitBreakerReason?: string;
}

/**
 * Executes one of the 10 institutional simulation scenarios
 */
export function executeScenario(params: {
  scenarioId: string;
  requests: FundingRequest[];
  facilities: Facility[];
  counterparties: Counterparty[];
  collateral: CollateralAsset[];
  liquidityPool: LiquidityPoolStatus;
  ledgerEntries: LedgerJournalEntry[];
}): ScenarioRunResult {
  const {
    scenarioId,
    requests,
    facilities,
    counterparties,
    collateral,
    liquidityPool,
    ledgerEntries
  } = params;

  const logs: string[] = [];
  let updatedRequests = [...requests];
  let updatedFacilities = [...facilities];
  let updatedCollateral = [...collateral];
  let updatedLiquidityPool = { ...liquidityPool };
  let updatedLedgerEntries = [...ledgerEntries];
  let circuitBreakerActive = false;
  let circuitBreakerReason: string | undefined = undefined;

  const timestamp = new Date().toISOString();
  logs.push(`[${timestamp}] Initiating Scenario: ${scenarioId}`);

  switch (scenarioId) {
    case 'SCENARIO-01': {
      // Concurrent overnight requests
      logs.push('Generating 3 concurrent overnight funding requests for Apex Clearing, Meridian Global, and Sovereign Reserve...');
      const req1: FundingRequest = {
        id: `REQ-SIM-01-A-${Date.now().toString().slice(-4)}`,
        idempotencyKey: `IDEMP-CONCUR-01-${Date.now()}`,
        borrowerId: 'CP-APEX-01',
        facilityId: 'FAC-APEX-ID01',
        productType: 'INTRADAY_ADVANCE',
        currency: 'EUR',
        requestedAmount: 12_000_000,
        tenorHours: 4,
        submittedAt: timestamp,
        status: 'REQUESTED',
        decisionStatus: 'QUEUED',
        decisionReasons: [],
        policyVersion: 'RQ-POL-2026.4.1',
        accruedInterest: 0
      };

      const req2: FundingRequest = {
        id: `REQ-SIM-01-B-${Date.now().toString().slice(-4)}`,
        idempotencyKey: `IDEMP-CONCUR-02-${Date.now()}`,
        borrowerId: 'CP-MERID-02',
        facilityId: 'FAC-MERID-ON02',
        productType: 'OVERNIGHT_LOAN',
        currency: 'USD',
        requestedAmount: 30_000_000,
        tenorHours: 24,
        submittedAt: timestamp,
        status: 'REQUESTED',
        decisionStatus: 'QUEUED',
        decisionReasons: [],
        policyVersion: 'RQ-POL-2026.4.1',
        accruedInterest: 0
      };

      // Evaluate both through limits and pricing
      for (const req of [req1, req2]) {
        const cp = counterparties.find((c) => c.id === req.borrowerId)!;
        const fac = updatedFacilities.find((f) => f.id === req.facilityId)!;
        const evalResult = evaluateFundingRequest({
          request: req,
          existingRequests: updatedRequests,
          facility: fac,
          counterparty: cp,
          allCounterparties: counterparties,
          allFacilities: updatedFacilities,
          collateralAssets: updatedCollateral,
          liquidityPool: updatedLiquidityPool,
          isCircuitBreakerActive: false,
          pausedProducts: []
        });

        req.decisionStatus = evalResult.decision;
        req.approvedAmount = evalResult.approvedAmount;
        req.decisionReasons = evalResult.reasons;

        if (evalResult.decision === 'APPROVED') {
          req.pricingQuote = calculateQuote({
            counterparty: cp,
            productType: req.productType,
            currency: req.currency,
            principal: req.approvedAmount,
            tenorHours: req.tenorHours,
            poolUtilizationPct: 0.55
          });
          req.status = 'QUOTED';
          logs.push(`Request ${req.id} (${cp.name}): Approved $${req.approvedAmount.toLocaleString()} @ ${(req.pricingQuote.totalQuotedAnnualizedRate * 100).toFixed(2)}% APR.`);
        }
        updatedRequests = [req, ...updatedRequests];
      }
      break;
    }

    case 'SCENARIO-02': {
      // Competing use of limited cash
      logs.push('Executing allocation optimizer against constrained liquidity pool ($252M available)...');
      const allocResult = runAllocation({
        strategy: 'CONSTRAINED_OPTIMIZATION',
        requests: updatedRequests,
        counterparties,
        facilities: updatedFacilities,
        liquidityPool: updatedLiquidityPool
      });

      logs.push(`Optimizer completed: Allocated $${allocResult.totalAllocated.toLocaleString()} across requests.`);
      logs.push(`Capital efficiency score: ${allocResult.objectiveMetrics.capitalEfficiencyScore}%. Preserved $${allocResult.objectiveMetrics.liquidityBufferPreserved.toLocaleString()} regulatory buffer.`);
      for (const item of allocResult.allocatedRequests) {
        logs.push(`- Req ${item.requestId}: ${item.explanation}`);
      }
      break;
    }

    case 'SCENARIO-03': {
      // Collateral-backed availability & haircuts
      logs.push('Evaluating Trade Receivables pool collateral for Helios Commodities (25% contractual haircut)...');
      const cp = counterparties.find((c) => c.id === 'CP-HELIOS-03')!;
      const fac = updatedFacilities.find((f) => f.id === 'FAC-HELIOS-WC03')!;

      const req: FundingRequest = {
        id: `REQ-SIM-03-${Date.now().toString().slice(-4)}`,
        idempotencyKey: `IDEMP-COL-${Date.now()}`,
        borrowerId: cp.id,
        facilityId: fac.id,
        productType: 'SECURED_WORKING_CAPITAL',
        currency: 'GBP',
        requestedAmount: 22_000_000,
        tenorHours: 168,
        submittedAt: timestamp,
        status: 'REQUESTED',
        decisionStatus: 'QUEUED',
        decisionReasons: [],
        policyVersion: 'RQ-POL-2026.4.1',
        accruedInterest: 0
      };

      const evalResult = evaluateFundingRequest({
        request: req,
        existingRequests: updatedRequests,
        facility: fac,
        counterparty: cp,
        allCounterparties: counterparties,
        allFacilities: updatedFacilities,
        collateralAssets: updatedCollateral,
        liquidityPool: updatedLiquidityPool,
        isCircuitBreakerActive: false,
        pausedProducts: []
      });

      req.decisionStatus = evalResult.decision;
      req.approvedAmount = evalResult.approvedAmount;
      req.decisionReasons = evalResult.reasons;
      req.status = evalResult.decision === 'PARTIALLY_APPROVED' ? 'PARTIALLY_APPROVED' : 'APPROVED';

      logs.push(`Collateral check: Helios asked for £22M. Available eligible borrowing base is £16.15M after 25% haircut and £2M prior lien.`);
      logs.push(`Decision: ${evalResult.decision} for £${(evalResult.approvedAmount || 0).toLocaleString()}.`);
      updatedRequests = [req, ...updatedRequests];
      break;
    }

    case 'SCENARIO-04': {
      // Quote acceptance and expiry
      logs.push('Simulating pricing quote TTL timeout (30-minute expiry window)...');
      const targetReq = updatedRequests.find((r) => r.status === 'QUOTED');
      if (targetReq) {
        targetReq.status = 'EXPIRED';
        targetReq.decisionStatus = 'EXPIRED';
        targetReq.decisionReasons.push('Quote validity window (30 mins) elapsed without counterparty electronic acceptance.');
        logs.push(`Quote on request ${targetReq.id} expired. Unreserved capacity released back to facility pool.`);
      } else {
        logs.push('No pending quoted requests found. Created an expired quote record.');
      }
      break;
    }

    case 'SCENARIO-05': {
      // Partial facility approval
      logs.push('Testing facility headroom constraint on Valo Arbitrage ($12M remaining limit)...');
      const cp = counterparties.find((c) => c.id === 'CP-VALO-04')!;
      const fac = updatedFacilities.find((f) => f.id === 'FAC-VALO-REV04')!;

      const req: FundingRequest = {
        id: `REQ-SIM-05-${Date.now().toString().slice(-4)}`,
        idempotencyKey: `IDEMP-PARTIAL-${Date.now()}`,
        borrowerId: cp.id,
        facilityId: fac.id,
        productType: 'SHORT_TERM_REVOLVER',
        currency: 'USD',
        requestedAmount: 18_000_000,
        tenorHours: 72,
        submittedAt: timestamp,
        status: 'REQUESTED',
        decisionStatus: 'QUEUED',
        decisionReasons: [],
        policyVersion: 'RQ-POL-2026.4.1',
        accruedInterest: 0
      };

      const evalRes = evaluateFundingRequest({
        request: req,
        existingRequests: updatedRequests,
        facility: fac,
        counterparty: cp,
        allCounterparties: counterparties,
        allFacilities: updatedFacilities,
        collateralAssets: updatedCollateral,
        liquidityPool: updatedLiquidityPool,
        isCircuitBreakerActive: false,
        pausedProducts: []
      });

      req.decisionStatus = evalRes.decision;
      req.approvedAmount = evalRes.approvedAmount;
      req.decisionReasons = evalRes.reasons;
      req.status = 'PARTIALLY_APPROVED';

      logs.push(`Request evaluated: Requested $18M, partially approved for $${evalRes.approvedAmount.toLocaleString()} due to facility unutilized headroom.`);
      updatedRequests = [req, ...updatedRequests];
      break;
    }

    case 'SCENARIO-06': {
      // Duplicate request delivery (Idempotency test)
      logs.push('Submitting duplicate request with identical Idempotency Key: IDEMP-MERID-USD-20261110-002...');
      const firstReq = updatedRequests[0];
      const dupReq: FundingRequest = {
        ...firstReq,
        id: `REQ-DUP-${Date.now().toString().slice(-4)}`,
        submittedAt: timestamp
      };

      const evalRes = evaluateFundingRequest({
        request: dupReq,
        existingRequests: updatedRequests,
        facility: updatedFacilities[0],
        counterparty: counterparties[0],
        allCounterparties: counterparties,
        allFacilities: updatedFacilities,
        collateralAssets: updatedCollateral,
        liquidityPool: updatedLiquidityPool,
        isCircuitBreakerActive: false,
        pausedProducts: []
      });

      logs.push(`Idempotency guard response: ${evalRes.reasons[0]}`);
      logs.push('Zero additional cash was reserved. Idempotency verified.');
      break;
    }

    case 'SCENARIO-07': {
      // Payment timeout with uncertain outcome
      logs.push('Dispatching Fedwire disbursement for Meridian Global Trust ($25M)...');
      logs.push('Payment adapter network timeout: Fedwire ACK did not return within 5000ms SLA.');
      const reqToDispute = updatedRequests.find((r) => r.status === 'FUNDING_RESERVED' || r.status === 'APPROVED');
      if (reqToDispute) {
        reqToDispute.status = 'DISPUTED';
        reqToDispute.decisionReasons.push('Fedwire network timeout. Outcome uncertain; placed in quarantine to prevent duplicate disbursement.');
        logs.push(`Loan ${reqToDispute.id} transitioned to DISPUTED / RECONCILIATION_REQUIRED.`);
        logs.push('Action required: Operations must perform manual Fedwire IMAD inquiry before re-transmitting.');
      }
      break;
    }

    case 'SCENARIO-08': {
      // Confirmed repayment & ledger resolution
      logs.push('Simulating confirmed wire settlement for mature $25M loan from Meridian Global Trust...');
      const targetReq = updatedRequests.find((r) => r.status === 'OUTSTANDING');
      if (targetReq) {
        const principal = targetReq.approvedAmount || targetReq.requestedAmount;
        const interest = targetReq.accruedInterest || 4000;

        const repayEntry = makeRepaymentEntry({
          loanId: targetReq.id,
          counterpartyName: 'Meridian Global Trust',
          principal,
          interest
        });

        updatedLedgerEntries = [repayEntry, ...updatedLedgerEntries];

        targetReq.status = 'REPAID';
        targetReq.repaidAt = timestamp;
        targetReq.repaymentAmount = principal + interest;

        // Restore pool cash
        updatedLiquidityPool.uncommittedCash += principal;
        updatedLiquidityPool.disbursedPrincipal = Math.max(0, updatedLiquidityPool.disbursedPrincipal - principal);
        updatedLiquidityPool.availableForAllocation = Math.max(0, updatedLiquidityPool.uncommittedCash - updatedLiquidityPool.minimumLiquidityBuffer);

        logs.push(`Balanced Journal Entry ${repayEntry.id} posted. Debited Nostro Cash $${(principal + interest).toLocaleString()}, Credited Loans Outstanding $${principal.toLocaleString()} & Interest Income $${interest.toLocaleString()}.`);
        logs.push(`Subledger trial balance status: BALANCED (Checksum: ${repayEntry.checksum})`);
      }
      break;
    }

    case 'SCENARIO-09': {
      // Overdue loan & delinquency escalation
      logs.push('Evaluating maturity delinquency for Valo Arbitrage S.A. Revolver drawdown...');
      const overdueLoan = updatedRequests.find((r) => r.borrowerId === 'CP-VALO-04');
      if (overdueLoan) {
        overdueLoan.status = 'OVERDUE';
        const principal = overdueLoan.approvedAmount || overdueLoan.requestedAmount;
        const eclAllowance = principal * 0.15; // 15% ECL provision on distressed loan

        const entry = makeOverdueEntry({
          loanId: overdueLoan.id,
          counterpartyName: 'Valo Arbitrage S.A.',
          principal,
          eclProvisionAmount: eclAllowance
        });

        updatedLedgerEntries = [entry, ...updatedLedgerEntries];

        logs.push(`Loan ${overdueLoan.id} escalated to OVERDUE. Reclassified $${principal.toLocaleString()} to Account 1290 (Non-Accrual).`);
        logs.push(`Recognized $${eclAllowance.toLocaleString()} Expected Credit Loss allowance in Account 5020.`);
      }
      break;
    }

    case 'SCENARIO-10': {
      // Liquidity stress that pauses new lending
      logs.push('Simulating macro interbank shock: Liquidity buffer breached ($45M < $60M regulatory floor)...');
      circuitBreakerActive = true;
      circuitBreakerReason = 'CRITICAL_BUFFER_BREACH: Uncommitted cash fell below mandatory $60M LCR floor. Automated safety trip engaged.';
      updatedLiquidityPool.uncommittedCash = 45_000_000;
      updatedLiquidityPool.availableForAllocation = 0;

      logs.push('>>> GLOBAL CIRCUIT BREAKER ENGAGED <<<');
      logs.push('All new lending commitments and automated drawdowns immediately frozen.');
      logs.push('Risk alerts broadcast to Head of Liquidity & Senior Risk Officer.');
      break;
    }

    default:
      logs.push(`Scenario ${scenarioId} executed without modifications.`);
  }

  return {
    scenarioId,
    scenarioTitle: SIMULATION_SCENARIOS.find((s) => s.id === scenarioId)?.title || scenarioId,
    executedAt: timestamp,
    logs,
    updatedRequests,
    updatedFacilities,
    updatedCollateral,
    updatedLiquidityPool,
    updatedLedgerEntries,
    circuitBreakerActive,
    circuitBreakerReason
  };
}
