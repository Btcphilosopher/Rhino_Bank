/**
 * RhinoQuant Liquidity Engine - Domain Types
 * Brand: RhinoBank | Division: RhinoQuant | Technology: Aureom.AI
 */

export type ProductType =
  | 'INTRADAY_ADVANCE'
  | 'OVERNIGHT_LOAN'
  | 'SHORT_TERM_REVOLVER'
  | 'RECEIVABLES_BACKED'
  | 'SECURED_WORKING_CAPITAL'
  | 'INTERBANK_LENDING'
  | 'INTERNAL_TREASURY_ALLOCATION';

export type Currency = 'USD' | 'EUR' | 'GBP';

export type DecisionStatus =
  | 'APPROVED'
  | 'PARTIALLY_APPROVED'
  | 'QUEUED'
  | 'REFERRED'
  | 'DECLINED'
  | 'EXPIRED';

export type LoanLifecycleStatus =
  | 'REQUESTED'
  | 'QUEUED'
  | 'REFERRED'
  | 'DECLINED'
  | 'PARTIALLY_APPROVED'
  | 'QUOTED'
  | 'ACCEPTED'
  | 'APPROVED'
  | 'FUNDING_RESERVED'
  | 'PAYMENT_SUBMITTED'
  | 'DISBURSED'
  | 'OUTSTANDING'
  | 'REPAID'
  | 'CANCELLED'
  | 'EXPIRED'
  | 'FAILED'
  | 'DISPUTED'
  | 'OVERDUE'
  | 'DEFAULTED'
  | 'REVERSED'
  | 'WRITTEN_OFF';

export type AllocationStrategy =
  | 'FIFO_BASELINE'
  | 'PRIORITY_WEIGHTED'
  | 'CONSTRAINED_OPTIMIZATION'
  | 'MANUAL_REVIEW';

export type UserRole =
  | 'HEAD_OF_LIQUIDITY'
  | 'QUANTITATIVE_STRATEGIST'
  | 'SENIOR_RISK_OFFICER'
  | 'CREDIT_ANALYST'
  | 'COMPLIANCE_AUDITOR';

export interface Counterparty {
  id: string;
  name: string;
  legalEntity: string;
  lei: string;
  corporateGroupId: string;
  corporateGroupName: string;
  creditRating: 'AAA' | 'AA+' | 'AA' | 'AA-' | 'A+' | 'A' | 'BBB+' | 'BBB' | 'BB+';
  sector: 'CLEARING_BROKER' | 'ASSET_MANAGER' | 'COMMODITIES_TRADER' | 'ARBITRAGE_FUND' | 'CENTRAL_BANK' | 'INTERNAL_TREASURY';
  country: 'USA' | 'GBR' | 'DEU' | 'CHE' | 'SGP';
  isInternal: boolean;
  minLiquidityRatioCovenant: number; // e.g. 1.25x
  maxLeverageCovenant: number; // e.g. 3.5x
  currentLiquidityRatio: number;
  currentLeverage: number;
  covenantBreached: boolean;
  documentationStatus: 'EXECUTED_CURRENT' | 'UNDER_ANNUAL_REVIEW' | 'PENDING_AMENDMENT';
  paymentInstructions: {
    system: 'FEDWIRE' | 'TARGET2' | 'CHAPS' | 'INTERNAL_BOOK';
    accountIdentifier: string; // BIC or ABA or internal ledger
    cutoffTimeUtc: string; // e.g. '21:30'
  };
  reviewDate: string;
}

export interface Facility {
  id: string;
  facilityCode: string;
  borrowerId: string;
  productType: ProductType;
  currency: Currency;
  approvedLimit: number;
  currentDrawn: number;
  currentReserved: number;
  permittedTenorsHours: number[]; // e.g. [2, 4, 8, 24, 168, 720]
  referenceBenchmark: 'SOFR' | 'ESTR' | 'SONIA' | 'INTERNAL_TRANSFER_RATE';
  baseCreditSpreadBps: number;
  requiresCollateral: boolean;
  minCollateralCoverageRatio: number; // e.g. 1.05 = 105%
  expiryDate: string;
  isActive: boolean;
}

export interface CollateralAsset {
  id: string;
  counterpartyId: string;
  assetClass: 'US_TREASURY' | 'UK_GILT' | 'GERMAN_BUND' | 'AAA_COMMERCIAL_PAPER' | 'CORP_BOND_IG' | 'TRADE_RECEIVABLES';
  identifier: string; // CUSIP/ISIN
  description: string;
  faceValue: number;
  marketValue: number;
  currency: Currency;
  valuationSource: string;
  valuationTimestamp: string;
  haircutPercent: number; // e.g. 2% for UST, 15% for Commercial Paper, 25% for Receivables
  priorEncumbranceAmount: number;
  currentlyAllocatedAmount: number;
  eligibleBorrowingBase: number;
  custodian: string;
  controlStatus: 'TRI_PARTY_SEGREGATED' | 'DIRECT_PLEDGE' | 'ACCOUNT_CONTROL_AGREEMENT';
}

export interface PricingBreakdown {
  referenceFundingRate: number; // e.g. 0.0482 (4.82%)
  referenceSource: string; // e.g. "NY Fed SOFR 08:00 EST"
  referenceAgeMinutes: number;
  tenorAdjustmentBps: number;
  creditSpreadBps: number;
  liquidityAdjustmentBps: number;
  capitalCostAllocationBps: number;
  operatingCostAllocationBps: number;
  targetMarginBps: number;
  totalQuotedAnnualizedRate: number; // Sum in decimal (e.g. 0.0545 = 5.45%)
  dayCountConvention: 'ACT/360' | 'ACT/365';
  tenorHours: number;
  estimatedInterestAmount: number; // Actual dollar/eur interest for tenor
  facilityDrawdownFee: number;
  effectiveCostRateAnnualized: number; // Cashflow-based
  quoteExpiryTimestamp: string;
  policyVersion: string;
}

export interface FundingRequest {
  id: string;
  idempotencyKey: string;
  borrowerId: string;
  facilityId: string;
  productType: ProductType;
  currency: Currency;
  requestedAmount: number;
  approvedAmount?: number;
  tenorHours: number;
  submittedAt: string;
  status: LoanLifecycleStatus;
  decisionStatus: DecisionStatus;
  decisionReasons: string[];
  policyVersion: string;
  pricingQuote?: PricingBreakdown;
  termsAcceptedAt?: string;
  reservationExpiryAt?: string;
  paymentSubmittedAt?: string;
  paymentReference?: string;
  disbursedAt?: string;
  maturityAt?: string;
  repaidAt?: string;
  repaymentAmount?: number;
  accruedInterest: number;
  allocatedByStrategy?: AllocationStrategy;
  allocationReason?: string;
  collateralAllocated?: { assetId: string; amount: number }[];
}

export interface DoubleEntryLine {
  accountNumber: string;
  accountName: string;
  debit: number;
  credit: number;
}

export interface LedgerJournalEntry {
  id: string;
  timestamp: string;
  referenceId: string; // Loan ID or Transfer ID
  eventType: string;
  narrative: string;
  lines: DoubleEntryLine[];
  isBalanced: boolean;
  checksum: string;
}

export interface LedgerAccountBalance {
  accountNumber: string;
  accountName: string;
  category: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';
  balance: number;
  currency: Currency;
}

export interface LimitExposure {
  category: 'BORROWER' | 'GROUP' | 'SECTOR' | 'COUNTRY' | 'CURRENCY' | 'PRODUCT';
  name: string;
  limitAmount: number;
  drawnAmount: number;
  reservedAmount: number;
  utilizationPercent: number;
  isBreached: boolean;
}

export interface LiquidityPoolStatus {
  totalCapacity: number;
  uncommittedCash: number;
  reservedCash: number;
  disbursedPrincipal: number;
  minimumLiquidityBuffer: number;
  availableForAllocation: number;
  currency: Currency;
  lastUpdated: string;
}

export interface EngineTelemetry {
  eventsPerSecond: number;
  activeQueueDepth: number;
  decisionLatencyP50Ms: number;
  decisionLatencyP95Ms: number;
  decisionLatencyP99Ms: number;
  dbContentionLockCount: number;
  reservationFailureRatePct: number;
  paymentAdapterLatencyMs: number;
  reconciliationLagSec: number;
  isCircuitBreakerActive: boolean;
  circuitBreakerReason?: string;
  pausedProducts: ProductType[];
}

export interface MakerCheckerItem {
  id: string;
  changeType: 'LIMIT_OVERRIDE' | 'POLICY_UPDATE' | 'CIRCUIT_BREAKER_CHANGE' | 'MANUAL_DISBURSEMENT_RETRY';
  details: string;
  initiatedBy: string;
  initiatedAt: string;
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED';
  approvedBy?: string;
  approvedAt?: string;
}
