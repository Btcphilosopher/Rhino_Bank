/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { MessageSquare, Heart, ThumbsUp, Send, BookOpen, Video, Plus, Sparkles, User, Calendar, ExternalLink } from 'lucide-react';
import { ForumPost, Article } from '../types';
import { mockForumPosts, mockArticles } from '../mockData';

export default function Community() {
  const [activeSubTab, setActiveSubTab] = useState<'forum' | 'articles' | 'webinars'>('forum');
  const [forumPosts, setForumPosts] = useState<ForumPost[]>(mockForumPosts);
  const [activeStreamId, setActiveStreamId] = useState<number | null>(null);
  const [streamMessage, setStreamMessage] = useState<string>('');

  // New forum post states
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState('Software Development');

  // New read article detail state
  const [viewingArticle, setViewingArticle] = useState<Article | null>(null);

  // Handle upvoting
  const handleLikePost = (postId: string) => {
    setForumPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          return { ...post, likes: post.likes + 1 };
        }
        return post;
      })
    );
  };

  // Submit forum post
  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    const postObj: ForumPost = {
      id: `post-user-${Date.now()}`,
      title: newTitle,
      content: newContent,
      category: newCategory,
      authorName: 'Verified Gotham Client',
      authorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&h=100&q=80',
      authorRole: 'Platform Participant',
      likes: 0,
      commentsCount: 0,
      date: new Date().toISOString().split('T')[0],
    };

    setForumPosts([postObj, ...forumPosts]);
    setNewTitle('');
    setNewContent('');
  };

  // Tutorials clips
  const tutorialsList = [
    { id: 1, title: 'Compiling Rust Axum for Multi-Platform Docker Containers', duration: '18 min', instructor: 'Silicon Alley Labs', level: 'Advanced' },
    { id: 2, title: 'Drafting Volatility Surface Interpolations in JavaScript WebAssembly', duration: '24 min', instructor: 'Marcus Vance, PhD', level: 'Expert' },
    { id: 3, title: 'Optimizing high-density Tailwind layouts for Bloomberg screens', duration: '12 min', instructor: 'Brooklyn Pixel Foundry', level: 'Intermediate' },
  ];

  return (
    <section className="bg-neutral-950 text-white min-h-screen py-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Banner */}
        <div className="border-b border-neutral-900 pb-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold font-sans tracking-tight uppercase">
              Gotham Community & Knowledge Hub
            </h2>
            <p className="text-neutral-500 text-xs font-mono uppercase mt-1">
              Participate in advanced discussion groups, read research publications, or watch masterclasses.
            </p>
          </div>

          <div className="flex bg-neutral-900 p-1 rounded-lg border border-neutral-800">
            <button
              onClick={() => { setActiveSubTab('forum'); setViewingArticle(null); }}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeSubTab === 'forum' ? 'bg-blue-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" /> Discussion Forum
            </button>
            <button
              onClick={() => { setActiveSubTab('articles'); setViewingArticle(null); }}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeSubTab === 'articles' ? 'bg-blue-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" /> Technical Publications
            </button>
            <button
              onClick={() => { setActiveSubTab('webinars'); setViewingArticle(null); }}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeSubTab === 'webinars' ? 'bg-blue-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Video className="w-3.5 h-3.5" /> GDX Tutorials
            </button>
          </div>
        </div>

        {/* Community contents */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Main workspace */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* Tab: Forum */}
            {activeSubTab === 'forum' && (
              <div className="space-y-6">
                
                {/* Submit forum post */}
                <form onSubmit={handlePostSubmit} className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4 shadow-lg">
                  <h4 className="text-xs font-bold text-white uppercase font-mono tracking-widest border-b border-neutral-900 pb-2">
                    Submit New Discussion Post
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-mono text-neutral-400 block mb-1">Post Title / Topic</label>
                      <input
                        type="text"
                        required
                        value={newTitle}
                        onChange={(e) => setNewTitle(e.target.value)}
                        placeholder="e.g. gRPC thread pool constraints in Node v22"
                        className="w-full bg-neutral-900 border border-neutral-800 rounded p-2 text-xs text-white focus:outline-none focus:border-blue-500 font-sans"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-mono text-neutral-400 block mb-1">Sector Forum</label>
                      <select
                        value={newCategory}
                        onChange={(e) => setNewCategory(e.target.value)}
                        className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500"
                      >
                        <option>Software Development</option>
                        <option>Financial Modeling</option>
                        <option>UI/UX Design</option>
                        <option>Cybersecurity & Defense</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-neutral-400 block mb-1">Description / Question Details</label>
                    <textarea
                      rows={3}
                      required
                      value={newContent}
                      onChange={(e) => setNewContent(e.target.value)}
                      placeholder="Details of your development, infrastructure benchmarks, or layout ratios..."
                      className="w-full bg-neutral-900 border border-neutral-800 rounded p-2 text-xs text-white focus:outline-none focus:border-blue-500 font-sans"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold tracking-wide"
                  >
                    Broadcast Post
                  </button>
                </form>

                {/* Forum list */}
                <div className="space-y-4">
                  {forumPosts.map((post) => (
                    <div
                      key={post.id}
                      className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 hover:border-neutral-850 transition-all space-y-3"
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-2.5">
                          <img src={post.authorAvatar} alt={post.authorName} className="w-8 h-8 rounded-full object-cover" />
                          <div>
                            <span className="text-xs font-bold text-white block">{post.authorName}</span>
                            <span className="text-[9px] font-mono text-neutral-500 uppercase">{post.authorRole} • Released {post.date}</span>
                          </div>
                        </div>
                        <span className="bg-neutral-900 text-neutral-400 border border-neutral-800 text-[9px] font-mono px-2 py-0.5 rounded">
                          {post.category}
                        </span>
                      </div>

                      <h4 className="text-sm font-bold text-white leading-snug">{post.title}</h4>
                      <p className="text-xs text-neutral-400 leading-relaxed font-sans">{post.content}</p>

                      <div className="flex items-center space-x-4 pt-2 border-t border-neutral-900 text-xs font-mono text-neutral-500">
                        <button
                          onClick={() => handleLikePost(post.id)}
                          className="flex items-center gap-1.5 hover:text-blue-400 transition-colors focus:outline-none group"
                        >
                          <ThumbsUp className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
                          <span>{post.likes} Approved</span>
                        </button>
                        <span>•</span>
                        <div className="flex items-center gap-1.5">
                          <MessageSquare className="w-3.5 h-3.5 text-neutral-600" />
                          <span>{post.commentsCount} comments</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

              </div>
            )}

            {/* Tab: Articles / Publications */}
            {activeSubTab === 'articles' && (
              <div className="space-y-6">
                
                {viewingArticle ? (
                  // Article Detailed view
                  <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-6 space-y-5">
                    <button
                      onClick={() => setViewingArticle(null)}
                      className="text-xs font-mono text-neutral-400 hover:text-white uppercase flex items-center gap-1"
                    >
                      ← Back to Publications
                    </button>

                    <div className="relative h-64 rounded-xl overflow-hidden bg-neutral-900">
                      <img src={viewingArticle.image} alt={viewingArticle.title} className="w-full h-full object-cover" />
                    </div>

                    <div className="space-y-2">
                      <span className="text-xs text-blue-400 font-mono font-bold uppercase tracking-wider">
                        {viewingArticle.category} • {viewingArticle.readTime}
                      </span>
                      <h3 className="text-xl md:text-2xl font-bold text-white tracking-tight">
                        {viewingArticle.title}
                      </h3>
                      <p className="text-[10px] font-mono text-neutral-500 uppercase">
                        Published by {viewingArticle.authorName} on {viewingArticle.date}
                      </p>
                    </div>

                    <p className="text-sm text-neutral-300 leading-relaxed whitespace-pre-line border-t border-neutral-900 pt-4 font-sans">
                      {viewingArticle.content}
                    </p>
                  </div>
                ) : (
                  // Publications grid
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {mockArticles.map((art) => (
                      <div
                        key={art.id}
                        className="bg-neutral-950 border border-neutral-900 rounded-xl overflow-hidden hover:border-neutral-800 transition-all flex flex-col group shadow-md"
                      >
                        <div className="h-44 bg-neutral-900 overflow-hidden relative">
                          <img src={art.image} alt={art.title} className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500" />
                          <span className="absolute top-3 left-3 bg-neutral-950/80 backdrop-blur-md px-2 py-0.5 rounded text-[10px] font-mono text-neutral-300 border border-neutral-800">
                            {art.category}
                          </span>
                        </div>

                        <div className="p-4 flex-1 flex flex-col space-y-3 font-sans">
                          <span className="text-[10px] font-mono text-neutral-500 uppercase">{art.readTime}</span>
                          <h4 className="text-sm font-bold text-white group-hover:text-blue-400 transition-colors line-clamp-1">
                            {art.title}
                          </h4>
                          <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed flex-1">
                            {art.summary}
                          </p>

                          <button
                            onClick={() => setViewingArticle(art)}
                            className="w-full bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 py-1.5 rounded text-xs font-semibold tracking-wide transition-all flex items-center justify-center gap-1"
                          >
                            Read Publication <ExternalLink className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

              </div>
            )}

            {/* Tab: Webinars / Tutorials */}
            {activeSubTab === 'webinars' && (
              <div className="space-y-4">
                {streamMessage && (
                  <div className="bg-neutral-900 border border-blue-500/20 text-blue-400 p-4 rounded-xl text-xs font-mono flex items-center justify-between">
                    <span>{streamMessage}</span>
                    <button
                      onClick={() => { setStreamMessage(''); setActiveStreamId(null); }}
                      className="text-[10px] text-neutral-500 hover:text-white uppercase font-bold pl-3"
                    >
                      Clear
                    </button>
                  </div>
                )}
                {tutorialsList.map((clip) => (
                  <div
                    key={clip.id}
                    className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 hover:border-neutral-850 transition-all flex flex-col md:flex-row md:items-center justify-between gap-6"
                  >
                    <div className="flex items-start gap-4 flex-1 min-w-0">
                      <div className="w-12 h-12 rounded bg-neutral-900 border border-neutral-800 shrink-0 flex items-center justify-center text-blue-500">
                        <Video className="w-6 h-6" />
                      </div>
                      <div className="min-w-0">
                        <span className="text-[9px] font-mono text-neutral-500 uppercase">
                          INSTRUCTOR: {clip.instructor} • {clip.level}
                        </span>
                        <h4 className="text-xs font-bold text-white truncate mt-0.5">{clip.title}</h4>
                        <p className="text-[10px] font-mono text-neutral-400 mt-1">
                          Estimated Duration: {clip.duration}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setActiveStreamId(clip.id);
                        setStreamMessage(`Preparing satellite relay stream for "${clip.title}"...`);
                        setTimeout(() => {
                          setStreamMessage(`Live Stream Connected. Buffering complete! Enjoy your masterclass with ${clip.instructor}.`);
                        }, 1200);
                      }}
                      className="bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-bold uppercase tracking-wider px-4 py-1.5 rounded transition-colors shrink-0"
                    >
                      {activeStreamId === clip.id ? 'Buffering...' : 'Stream Video'}
                    </button>
                  </div>
                ))}
              </div>
            )}

          </div>

          {/* Right sidebar help desk */}
          <div className="lg:col-span-1 space-y-6">
            
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4 shadow-lg">
              <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest block font-bold">COMMUNITY CODE</span>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Gotham Digital Exchange fosters advanced, professional collaborations. Share code templates, post performance profiles, or network with elite quant strategy directors.
              </p>
            </div>

            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-3">
              <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest block">FORUM SECTIONS</span>
              <div className="space-y-1.5 text-xs text-neutral-400 font-mono">
                <div className="flex justify-between">
                  <span>#rust-axum</span>
                  <span className="text-neutral-600">42 active</span>
                </div>
                <div className="flex justify-between">
                  <span>#greeks-quant</span>
                  <span className="text-neutral-600">18 active</span>
                </div>
                <div className="flex justify-between">
                  <span>#fintech-density</span>
                  <span className="text-neutral-600">29 active</span>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
