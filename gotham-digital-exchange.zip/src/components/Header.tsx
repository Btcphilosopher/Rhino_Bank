/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Shield, Sparkles, ShoppingCart, Search, User, Globe, ArrowUpRight, TrendingUp, Menu, X, Landmark, Compass, FolderKanban, Cpu, BookOpen, Layers } from 'lucide-react';
import { CartItem } from '../types';

interface HeaderProps {
  currentView: string;
  setView: (view: string) => void;
  userRole: 'buyer' | 'creator' | 'enterprise' | 'docs';
  setRole: (role: 'buyer' | 'creator' | 'enterprise' | 'docs') => void;
  cart: CartItem[];
  removeFromCart: (id: string) => void;
  checkout: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export default function Header({
  currentView,
  setView,
  userRole,
  setRole,
  cart,
  removeFromCart,
  checkout,
  searchQuery,
  setSearchQuery,
}: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState('');

  // Ticker items simulating NYSE/Nasdaq for GDX digital assets
  const tickerItems = [
    { name: 'GDX-INDEX', value: '4,892.40', change: '+2.41%', up: true },
    { name: 'NEXT-SaaS', value: '$299.00', change: '+1.8%', up: true },
    { name: 'MHTN-UI', value: '$149.00', change: '-0.4%', up: false },
    { name: 'GTHM-OPT', value: '$499.00', change: '+4.9%', up: true },
    { name: 'ETH-GAS', value: '18 Gwei', change: '-12.4%', up: false },
    { name: 'CYBER-SEC', value: '$199.00', change: '+0.5%', up: true },
    { name: 'QUANT-HR', value: '$250/hr', change: 'Steady', up: true },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);

    const updateTime = () => {
      const options: Intl.DateTimeFormatOptions = {
        timeZone: 'America/New_York',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      };
      const formatter = new Intl.DateTimeFormat('en-US', options);
      setCurrentTime(formatter.format(new Date()));
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      clearInterval(interval);
    };
  }, []);

  const totalCartPrice = cart.reduce((sum, item) => sum + item.price, 0);

  const handleRoleChange = (newRole: 'buyer' | 'creator' | 'enterprise' | 'docs') => {
    setRole(newRole);
    if (newRole === 'buyer') {
      setView('homepage');
    } else if (newRole === 'creator') {
      setView('creator-dashboard');
    } else if (newRole === 'enterprise') {
      setView('enterprise-hub');
    } else if (newRole === 'docs') {
      setView('docs');
    }
  };

  return (
    <header className="w-full z-50 transition-all duration-300">
      {/* 1. Real-time Wall Street Financial Ticker */}
      <div className="bg-neutral-950 border-b border-neutral-800 py-1.5 px-4 text-xs font-mono text-neutral-400 overflow-hidden select-none">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
          {/* Ticker values */}
          <div className="flex items-center space-x-6 overflow-x-auto scrollbar-none w-full md:w-auto">
            <span className="text-amber-500 font-bold flex items-center gap-1 shrink-0 uppercase tracking-widest text-[10px]">
              <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse inline-block"></span>
              GDX Live Index:
            </span>
            <div className="flex items-center space-x-6 animate-marquee shrink-0">
              {tickerItems.map((item, idx) => (
                <div key={idx} className="flex items-center space-x-1.5 shrink-0">
                  <span className="text-neutral-200 font-semibold">{item.name}</span>
                  <span className="text-neutral-400">{item.value}</span>
                  <span className={`text-[10px] font-bold ${item.up ? 'text-emerald-500' : 'text-rose-500'}`}>
                    {item.change}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* New York Live Metadata */}
          <div className="flex items-center space-x-4 text-[11px] text-neutral-500 font-mono shrink-0">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full inline-block"></span>
              EST: {currentTime || '10:52 AM'}
            </span>
            <span>SECURE DRM: 256-BIT</span>
            <span>GDX: HQ NY</span>
          </div>
        </div>
      </div>

      {/* 2. Primary Navigation Bar */}
      <nav
        className={`w-full border-b transition-all duration-300 ${
          isScrolled
            ? 'bg-neutral-950/95 backdrop-blur-md border-neutral-800 shadow-xl'
            : 'bg-neutral-950 border-neutral-900'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Logo */}
            <div className="flex items-center gap-8 shrink-0">
              <button
                onClick={() => { setView('homepage'); setRole('buyer'); }}
                className="flex items-center gap-2.5 focus:outline-none group text-left"
              >
                <div className="w-8 h-8 rounded-md bg-gradient-to-br from-blue-600 to-indigo-900 flex items-center justify-center border border-blue-400/30 shadow-md group-hover:border-blue-400 transition-all">
                  <span className="text-white font-bold font-mono text-sm tracking-tighter">GDX</span>
                </div>
                <div>
                  <h1 className="text-white font-bold font-sans tracking-tight text-base leading-tight group-hover:text-blue-400 transition-colors">
                    GOTHAM <span className="font-light text-neutral-400 text-xs tracking-wider block">DIGITAL EXCHANGE</span>
                  </h1>
                </div>
              </button>

              {/* Desktop Global View Links (when user is in standard buyer/explore mode) */}
              {userRole === 'buyer' && (
                <div className="hidden lg:flex items-center space-x-6 text-sm font-medium text-neutral-400">
                  <button
                    onClick={() => setView('homepage')}
                    className={`hover:text-white transition-colors flex items-center gap-1 ${currentView === 'homepage' ? 'text-white border-b-2 border-blue-500 py-1' : ''}`}
                  >
                    Home
                  </button>
                  <button
                    onClick={() => setView('marketplace')}
                    className={`hover:text-white transition-colors flex items-center gap-1 ${currentView === 'marketplace' ? 'text-white border-b-2 border-blue-500 py-1' : ''}`}
                  >
                    Browse Core
                  </button>
                  <button
                    onClick={() => setView('services')}
                    className={`hover:text-white transition-colors flex items-center gap-1 ${currentView === 'services' ? 'text-white border-b-2 border-blue-500 py-1' : ''}`}
                  >
                    Hiring Portal
                  </button>
                  <button
                    onClick={() => setView('community')}
                    className={`hover:text-white transition-colors flex items-center gap-1 ${currentView === 'community' ? 'text-white border-b-2 border-blue-500 py-1' : ''}`}
                  >
                    Community
                  </button>
                  <button
                    onClick={() => setView('customer-dashboard')}
                    className={`hover:text-white transition-colors flex items-center gap-1 ${currentView === 'customer-dashboard' ? 'text-white border-b-2 border-blue-500 py-1' : ''}`}
                  >
                    My Downloads
                  </button>
                </div>
              )}
            </div>

            {/* Global Search Bar (Only visible in desktop/buyer/market views) */}
            {userRole === 'buyer' && (
              <div className="hidden md:flex flex-1 max-w-sm mx-6">
                <div className="relative w-full">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-4 w-4 text-neutral-500" />
                  </div>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      if (currentView !== 'marketplace') {
                        setView('marketplace');
                      }
                    }}
                    placeholder="Search software, APIs, experts..."
                    className="block w-full pl-9 pr-3 py-1.5 text-xs font-mono bg-neutral-900 border border-neutral-800 rounded-md text-white placeholder-neutral-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                  />
                </div>
              </div>
            )}

            {/* Action Area: Switcher + Cart + Profile */}
            <div className="flex items-center space-x-4">
              
              {/* Role / Workspace Selection Tabs (Wall-Street segmented buttons) */}
              <div className="hidden md:flex bg-neutral-900 border border-neutral-800 p-1 rounded-lg">
                <button
                  onClick={() => handleRoleChange('buyer')}
                  className={`px-3 py-1 rounded-md text-xs font-medium font-sans transition-all ${
                    userRole === 'buyer'
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Marketplace
                </button>
                <button
                  onClick={() => handleRoleChange('creator')}
                  className={`px-3 py-1 rounded-md text-xs font-medium font-sans transition-all ${
                    userRole === 'creator'
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Creator Studio
                </button>
                <button
                  onClick={() => handleRoleChange('enterprise')}
                  className={`px-3 py-1 rounded-md text-xs font-medium font-sans transition-all ${
                    userRole === 'enterprise'
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Enterprise Hub
                </button>
                <button
                  onClick={() => handleRoleChange('docs')}
                  className={`px-3 py-1 rounded-md text-xs font-medium font-sans transition-all ${
                    userRole === 'docs'
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Developer Docs
                </button>
              </div>

              {/* Shopping Cart Button */}
              {userRole === 'buyer' && (
                <div className="relative">
                  <button
                    onClick={() => setIsCartOpen(!isCartOpen)}
                    className="p-2 rounded-md border border-neutral-800 hover:bg-neutral-900 text-neutral-300 hover:text-white transition-all relative"
                    id="cart-button"
                  >
                    <ShoppingCart className="w-4 w-4" />
                    {cart.length > 0 && (
                      <span className="absolute -top-1 -right-1 bg-blue-600 text-white font-sans text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                        {cart.length}
                      </span>
                    )}
                  </button>

                  {/* Cart Dropdown */}
                  {isCartOpen && (
                    <div className="absolute right-0 mt-3 w-80 bg-neutral-950 border border-neutral-800 rounded-lg shadow-2xl p-4 z-50 font-sans">
                      <div className="flex items-center justify-between border-b border-neutral-800 pb-2 mb-3">
                        <h3 className="text-sm font-semibold text-white">Your Order Details</h3>
                        <span className="text-xs text-neutral-500 font-mono">{cart.length} items</span>
                      </div>
                      {cart.length === 0 ? (
                        <div className="text-center py-6">
                          <p className="text-xs text-neutral-400">Cart is empty.</p>
                          <button
                            onClick={() => { setIsCartOpen(false); setView('marketplace'); }}
                            className="mt-3 text-xs text-blue-500 font-medium hover:underline"
                          >
                            Explore Marketplace
                          </button>
                        </div>
                      ) : (
                        <div>
                          <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
                            {cart.map((item) => (
                              <div key={item.id} className="flex justify-between items-start gap-2 text-xs">
                                <div className="flex-1 min-w-0">
                                  <p className="text-white font-medium truncate">{item.title}</p>
                                  <p className="text-[10px] text-neutral-500 font-mono capitalize">
                                    {item.type} {item.selectedPackage ? `(${item.selectedPackage})` : ''}
                                  </p>
                                </div>
                                <div className="flex items-center gap-2 shrink-0">
                                  <span className="font-mono text-white font-bold">${item.price}</span>
                                  <button
                                    onClick={() => removeFromCart(item.id)}
                                    className="text-neutral-500 hover:text-red-400"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                          <div className="border-t border-neutral-800 pt-3 mt-3">
                            <div className="flex justify-between items-center text-xs text-neutral-400 mb-3">
                              <span>Subtotal</span>
                              <span className="font-mono text-white text-sm font-semibold">${totalCartPrice}</span>
                            </div>
                            <button
                              onClick={() => {
                                checkout();
                                setIsCartOpen(false);
                              }}
                              className="w-full bg-blue-600 hover:bg-blue-500 text-white py-2 rounded-md text-xs font-semibold tracking-wide transition-all shadow-md flex items-center justify-center gap-1.5"
                            >
                              Confirm Purchase & License Key <ArrowUpRight className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Profile Balance Indicator */}
              <div className="hidden lg:flex items-center gap-2.5 pl-2 border-l border-neutral-800">
                <div className="text-right">
                  <p className="text-[10px] text-neutral-500 font-mono uppercase tracking-wider">Account Balance</p>
                  <p className="text-xs font-mono font-bold text-white">
                    {userRole === 'enterprise' ? '$24,500.00' : userRole === 'creator' ? '$142,820.00' : '$2,480.00'}
                  </p>
                </div>
                <div className="w-8 h-8 rounded-full border border-neutral-700 bg-neutral-900 flex items-center justify-center text-neutral-400 text-xs font-bold font-sans">
                  {userRole === 'enterprise' ? 'EP' : userRole === 'creator' ? 'CS' : 'NY'}
                </div>
              </div>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-2 rounded-md border border-neutral-800 text-neutral-400 hover:text-white"
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>

            </div>
          </div>
        </div>

        {/* 3. Mobile Navigation Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t border-neutral-900 bg-neutral-950 px-4 py-4 space-y-4 font-sans">
            {/* Direct Views */}
            <div className="flex flex-col space-y-2">
              <button
                onClick={() => { setView('homepage'); setRole('buyer'); setIsMobileMenuOpen(false); }}
                className="text-left py-2 px-3 hover:bg-neutral-900 rounded-md text-sm font-medium text-neutral-300 hover:text-white"
              >
                Homepage
              </button>
              <button
                onClick={() => { setView('marketplace'); setRole('buyer'); setIsMobileMenuOpen(false); }}
                className="text-left py-2 px-3 hover:bg-neutral-900 rounded-md text-sm font-medium text-neutral-300 hover:text-white"
              >
                Browse Marketplace
              </button>
              <button
                onClick={() => { setView('services'); setRole('buyer'); setIsMobileMenuOpen(false); }}
                className="text-left py-2 px-3 hover:bg-neutral-900 rounded-md text-sm font-medium text-neutral-300 hover:text-white"
              >
                Expert Services
              </button>
              <button
                onClick={() => { setView('community'); setRole('buyer'); setIsMobileMenuOpen(false); }}
                className="text-left py-2 px-3 hover:bg-neutral-900 rounded-md text-sm font-medium text-neutral-300 hover:text-white"
              >
                Community discussion
              </button>
              <button
                onClick={() => { setView('customer-dashboard'); setRole('buyer'); setIsMobileMenuOpen(false); }}
                className="text-left py-2 px-3 hover:bg-neutral-900 rounded-md text-sm font-medium text-neutral-300 hover:text-white"
              >
                My Customer Portal
              </button>
            </div>

            {/* Role select */}
            <div className="border-t border-neutral-900 pt-3">
              <p className="text-xs font-mono uppercase text-neutral-500 mb-2 px-3">Switch Workspace</p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => { handleRoleChange('buyer'); setIsMobileMenuOpen(false); }}
                  className={`py-2 px-3 text-center rounded-md text-xs font-medium ${userRole === 'buyer' ? 'bg-blue-600 text-white' : 'bg-neutral-900 text-neutral-400'}`}
                >
                  Marketplace
                </button>
                <button
                  onClick={() => { handleRoleChange('creator'); setIsMobileMenuOpen(false); }}
                  className={`py-2 px-3 text-center rounded-md text-xs font-medium ${userRole === 'creator' ? 'bg-blue-600 text-white' : 'bg-neutral-900 text-neutral-400'}`}
                >
                  Creator Studio
                </button>
                <button
                  onClick={() => { handleRoleChange('enterprise'); setIsMobileMenuOpen(false); }}
                  className={`py-2 px-3 text-center rounded-md text-xs font-medium ${userRole === 'enterprise' ? 'bg-blue-600 text-white' : 'bg-neutral-900 text-neutral-400'}`}
                >
                  Enterprise Hub
                </button>
                <button
                  onClick={() => { handleRoleChange('docs'); setIsMobileMenuOpen(false); }}
                  className={`py-2 px-3 text-center rounded-md text-xs font-medium ${userRole === 'docs' ? 'bg-blue-600 text-white' : 'bg-neutral-900 text-neutral-400'}`}
                >
                  Developer Docs
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
