/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ArrowLeft, Star, Clock, ShieldCheck, Calendar, DollarSign, CheckCircle, ChevronRight, MessageSquare, Briefcase } from 'lucide-react';
import { Service, CartItem } from '../types';

interface ServicePageProps {
  service: Service;
  goBack: () => void;
  addToCart: (item: CartItem) => void;
  cart: CartItem[];
  submitConsultingProposal: (service: Service, packageName: string, finalPrice: number, customBrief: string) => void;
}

export default function ServicePage({
  service,
  goBack,
  addToCart,
  cart,
  submitConsultingProposal,
}: ServicePageProps) {
  const [selectedPackageTier, setSelectedPackageTier] = useState<'standard' | 'professional' | 'executive'>('standard');
  const [customBrief, setCustomBrief] = useState('');
  const [selectedDate, setSelectedDate] = useState('2026-08-10');
  const [selectedTime, setSelectedTime] = useState('10:00 AM');
  const [proposalSubmitted, setProposalSubmitted] = useState(false);

  const activePackage = service.packages[selectedPackageTier];

  const handleHireSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitConsultingProposal(
      service,
      activePackage.name,
      activePackage.price,
      customBrief || `Standard engagement for: ${activePackage.name}`
    );
    setProposalSubmitted(true);
    setTimeout(() => {
      setProposalSubmitted(false);
      setCustomBrief('');
      goBack();
    }, 2000);
  };

  // Mock available calendar dates for active NYC timeslots
  const availableDates = [
    { day: 'Mon', date: '10', fullDate: '2026-08-10' },
    { day: 'Tue', date: '11', fullDate: '2026-08-11' },
    { day: 'Wed', date: '12', fullDate: '2026-08-12' },
    { day: 'Thu', date: '13', fullDate: '2026-08-13' },
    { day: 'Fri', date: '14', fullDate: '2026-08-14' },
  ];

  const availableTimes = ['09:00 AM', '10:30 AM', '01:00 PM', '03:30 PM', '05:00 PM'];

  return (
    <section className="bg-neutral-950 text-white py-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Back Button */}
        <button
          onClick={goBack}
          className="flex items-center gap-2 text-xs font-mono text-neutral-400 hover:text-white mb-6 uppercase transition-colors"
        >
          <ArrowLeft className="w-4 h-4 text-blue-500" /> Back to Hiring Portal
        </button>

        {/* Primary Page Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* A. Left Side Content: Biography, Packages details, Milestones */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* Header info */}
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <img
                    src={service.creatorAvatar}
                    alt={service.creatorName}
                    className="w-14 h-14 rounded-full border border-neutral-800 object-cover"
                  />
                  <div>
                    <span className="text-xs text-blue-400 font-mono font-bold uppercase tracking-wider block">
                      ELITE CONSULTANT
                    </span>
                    <h2 className="text-xl font-bold text-white tracking-tight">{service.creatorName}</h2>
                  </div>
                </div>

                <div className="flex gap-2">
                  <span className="bg-neutral-900 text-neutral-400 border border-neutral-800 text-xs font-mono px-3 py-1 rounded-md">
                    Rate: ${service.hourlyRate}/hr
                  </span>
                  <span className="bg-emerald-950 text-emerald-400 border border-emerald-500/20 text-xs font-mono px-3 py-1 rounded-md">
                    {service.availability}
                  </span>
                </div>
              </div>

              <h1 className="text-xl md:text-2xl font-bold text-white leading-tight pt-2">{service.title}</h1>
              <p className="text-sm text-neutral-300 leading-relaxed">{service.description}</p>

              <div className="flex flex-wrap items-center gap-4 text-xs text-neutral-400 font-mono border-t border-neutral-900 pt-3">
                <div className="flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                  <span className="text-white font-bold">{service.rating}</span>
                  <span>({service.reviewsCount} reviews)</span>
                </div>
                <span>•</span>
                <span>Response SLA: {service.responseTime}</span>
                <span>•</span>
                <span>HQ: Manhattan, NY</span>
              </div>
            </div>

            {/* Package Selector Core */}
            <div className="space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-widest font-mono text-neutral-400">
                Project Deliverable Modules
              </h3>

              {/* Selection Tabs */}
              <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-1.5 flex gap-2 overflow-x-auto">
                <button
                  onClick={() => setSelectedPackageTier('standard')}
                  className={`flex-1 py-2.5 px-3 text-xs font-semibold uppercase tracking-wider rounded-md text-center whitespace-nowrap transition-all ${
                    selectedPackageTier === 'standard' ? 'bg-blue-600 text-white shadow' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Standard Module
                </button>
                <button
                  onClick={() => setSelectedPackageTier('professional')}
                  className={`flex-1 py-2.5 px-3 text-xs font-semibold uppercase tracking-wider rounded-md text-center whitespace-nowrap transition-all ${
                    selectedPackageTier === 'professional' ? 'bg-blue-600 text-white shadow' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Professional HA
                </button>
                <button
                  onClick={() => setSelectedPackageTier('executive')}
                  className={`flex-1 py-2.5 px-3 text-xs font-semibold uppercase tracking-wider rounded-md text-center whitespace-nowrap transition-all ${
                    selectedPackageTier === 'executive' ? 'bg-blue-600 text-white shadow' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Executive Sovereign
                </button>
              </div>

              {/* Package Details display */}
              <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-6 space-y-5">
                <div className="flex justify-between items-start border-b border-neutral-900 pb-4">
                  <div>
                    <h4 className="text-base font-bold text-white">{activePackage.name}</h4>
                    <span className="text-xs text-neutral-500 font-mono uppercase block mt-1">
                      Expected Timeline: {activePackage.deliveryTime}
                    </span>
                  </div>
                  <span className="text-2xl font-extrabold font-mono text-blue-400">${activePackage.price}</span>
                </div>

                <p className="text-xs text-neutral-300 leading-relaxed">{activePackage.description}</p>

                {/* Features Checklist */}
                <div className="space-y-2">
                  <p className="text-xs font-bold text-white uppercase tracking-wider font-mono">Scope of Work Included:</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {activePackage.features.map((feat) => (
                      <div key={feat} className="flex items-start gap-2 text-xs text-neutral-400">
                        <CheckCircle className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Project Milestones Ledger */}
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-6 space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-widest font-mono text-neutral-400">
                Payment & Execution Milestones (Standard Escrow Ratios)
              </h3>
              <p className="text-xs text-neutral-500">
                Payments are held securely in GDX Escrow ledger and released automatically to the creator only upon client milestone clearance verification.
              </p>

              {/* Horizontal / Vertical Stepper */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 pt-2">
                {service.milestones.map((mil, idx) => {
                  const milestoneAmount = Math.round((activePackage.price * mil.percentage) / 100);
                  return (
                    <div key={idx} className="bg-neutral-900 p-3.5 rounded-lg border border-neutral-800 space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-mono text-neutral-500">PHASE 0{idx + 1}</span>
                        <span className="text-[10px] font-mono font-bold text-blue-400">{mil.percentage}%</span>
                      </div>
                      <h5 className="text-xs font-semibold text-white leading-tight truncate">{mil.title}</h5>
                      <p className="text-[11px] font-mono text-neutral-400">${milestoneAmount}</p>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>

          {/* B. Right Side Content: Calendar Booking & Proposal Escalator */}
          <div className="space-y-6">
            
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-6 shadow-lg">
              <div className="border-b border-neutral-900 pb-3">
                <span className="text-xs font-bold font-mono uppercase tracking-widest text-neutral-400 flex items-center gap-1.5">
                  <Briefcase className="w-4 h-4 text-blue-500" /> ESCROW PROPOSAL DESK
                </span>
              </div>

              {proposalSubmitted ? (
                <div className="py-12 text-center space-y-3">
                  <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto animate-bounce" />
                  <h4 className="text-sm font-semibold text-white">Smart Contract Drafted</h4>
                  <p className="text-xs text-neutral-500">Generating GDX cryptographic wallet transaction key. Initiating team alignment channel...</p>
                </div>
              ) : (
                <form onSubmit={handleHireSubmit} className="space-y-5">
                  
                  {/* Calendar picker */}
                  <div className="space-y-2.5">
                    <label className="text-[10px] font-bold uppercase tracking-widest font-mono text-neutral-500 block">
                      Select Kick-Off Date (EST)
                    </label>
                    <div className="flex gap-2">
                      {availableDates.map((d) => (
                        <button
                          type="button"
                          key={d.date}
                          onClick={() => setSelectedDate(d.fullDate)}
                          className={`flex-1 p-2 rounded text-center border transition-all ${
                            selectedDate === d.fullDate
                              ? 'bg-blue-600 text-white border-blue-600 font-bold'
                              : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                          }`}
                        >
                          <span className="text-[10px] uppercase block font-mono leading-none">{d.day}</span>
                          <span className="text-xs font-bold block mt-1 leading-none">{d.date}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Time slot picker */}
                  <div className="space-y-2.5">
                    <label className="text-[10px] font-bold uppercase tracking-widest font-mono text-neutral-500 block">
                      Kick-Off Call Slot
                    </label>
                    <div className="grid grid-cols-2 gap-1.5">
                      {availableTimes.map((time) => (
                        <button
                          type="button"
                          key={time}
                          onClick={() => setSelectedTime(time)}
                          className={`py-1.5 px-2 rounded border text-center text-xs font-mono transition-all ${
                            selectedTime === time
                              ? 'bg-white text-neutral-950 border-white font-bold'
                              : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                          }`}
                        >
                          {time}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Project brief */}
                  <div className="space-y-2.5">
                    <label className="text-[10px] font-bold uppercase tracking-widest font-mono text-neutral-500 block">
                      Custom Brief & Scope Notes
                    </label>
                    <textarea
                      rows={4}
                      value={customBrief}
                      onChange={(e) => setCustomBrief(e.target.value)}
                      placeholder="Specify your architecture requirements, existing stack details, and enterprise compliance metrics..."
                      className="w-full bg-neutral-950 border border-neutral-850 rounded p-2 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-blue-500 font-sans"
                    />
                  </div>

                  {/* Price calculations */}
                  <div className="bg-neutral-900 rounded-lg p-4 border border-neutral-800 space-y-2.5 font-mono text-xs text-neutral-400">
                    <div className="flex justify-between">
                      <span>Module Package</span>
                      <span className="text-white">${activePackage.price}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>GDX Escrow Fee (2%)</span>
                      <span className="text-white">${Math.round(activePackage.price * 0.02)}</span>
                    </div>
                    <div className="border-t border-neutral-800 pt-2.5 flex justify-between text-white font-bold text-sm">
                      <span>Total Invoice</span>
                      <span>${activePackage.price + Math.round(activePackage.price * 0.02)}</span>
                    </div>
                  </div>

                  {/* Hire Button */}
                  <button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-500 text-white py-2.5 rounded text-xs font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-2 shadow-md shadow-blue-900/10"
                  >
                    Submit Escrow Proposal <ChevronRight className="w-4 h-4" />
                  </button>

                </form>
              )}
            </div>

            {/* Certifications and Experience */}
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-3.5">
              <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest block">
                CREATOR CERTIFICATION SHIELD
              </span>
              <p className="text-xs text-neutral-400">
                This participant has completed GDX institutional reviews and holds verified credentials in New York business systems:
              </p>
              <div className="space-y-2.5 pt-1.5">
                <div className="flex items-start gap-2 text-xs text-neutral-300">
                  <ShieldCheck className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                  <span>Verified 48 Wall Street HQ participant</span>
                </div>
                <div className="flex items-start gap-2 text-xs text-neutral-300">
                  <ShieldCheck className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                  <span>Sovereign security penetration approved</span>
                </div>
                <div className="flex items-start gap-2 text-xs text-neutral-300">
                  <ShieldCheck className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                  <span>Capital safety standards fully verified</span>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
