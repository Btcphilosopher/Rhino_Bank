/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Plus, Trash, CheckCircle, TrendingUp, DollarSign, Upload, Percent, ShieldCheck, RefreshCw, BarChart, FileText, Settings, Heart, AlertCircle, ShoppingBag } from 'lucide-react';
import { Product, Service, Order } from '../types';

interface CreatorDashboardProps {
  products: Product[];
  services: Service[];
  addNewProduct: (prod: Product) => void;
  addNewService: (srv: Service) => void;
  orders: Order[];
  processRefund: (orderId: string) => void;
  creatorEarnings: number;
}

export default function CreatorDashboard({
  products,
  services,
  addNewProduct,
  addNewService,
  orders,
  processRefund,
  creatorEarnings,
}: CreatorDashboardProps) {
  const [activeTab, setActiveTab] = useState<'analytics' | 'products' | 'orders' | 'discounts'>('analytics');
  const [analyticsTime, setAnalyticsTime] = useState<'30' | '90' | 'all'>('30');

  // New product upload form states
  const [prodTitle, setProdTitle] = useState('');
  const [prodPrice, setProdPrice] = useState('199');
  const [prodCategory, setProdCategory] = useState('Software');
  const [prodDesc, setProdDesc] = useState('');
  const [prodLongDesc, setProdLongDesc] = useState('');
  const [prodSize, setProdSize] = useState('24.5 MB');
  const [prodTags, setProdTags] = useState('SaaS, NextJS, Postgres');
  const [prodComp, setProdComp] = useState('React 19, TypeScript, Node');
  const [formSuccess, setFormSuccess] = useState(false);

  // Discount campaign states
  const [discounts, setDiscounts] = useState([
    { code: 'WALLSTREET20', rate: 20, status: 'Active', usageCount: 48 },
    { code: 'SILICONALLEY', rate: 15, status: 'Active', usageCount: 112 },
    { code: 'SUMMER_BETA', rate: 30, status: 'Expired', usageCount: 15 },
  ]);
  const [newCode, setNewCode] = useState('');
  const [newRate, setNewRate] = useState('20');

  const handleProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodTitle.trim()) return;

    const newProd: Product = {
      id: `prod-user-${Date.now()}`,
      title: prodTitle,
      description: prodDesc,
      longDescription: prodLongDesc || prodDesc,
      category: prodCategory,
      price: parseFloat(prodPrice) || 99,
      creatorId: 'creator-user',
      creatorName: 'My Gotham Studio',
      creatorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&h=100&q=80',
      rating: 5.0,
      reviewsCount: 0,
      compatibility: prodComp.split(',').map((c) => c.trim()),
      tags: prodTags.split(',').map((t) => t.trim()),
      downloadSize: prodSize,
      version: 'v1.0.0',
      licenseType: 'Commercial Standard',
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&h=450&q=80',
      downloadsCount: 0,
      enterpriseReady: true,
      changelog: [
        {
          version: 'v1.0.0',
          date: new Date().toISOString().split('T')[0],
          changes: ['Initial release in Gotham Digital Exchange Spot Market.'],
        },
      ],
      faqs: [
        {
          question: 'Are future updates included?',
          answer: 'Yes, buying this digital asset grants lifetime updates access.',
        },
      ],
    };

    addNewProduct(newProd);
    setFormSuccess(true);
    setProdTitle('');
    setProdDesc('');
    setProdLongDesc('');

    setTimeout(() => {
      setFormSuccess(false);
      setActiveTab('products');
    }, 1500);
  };

  const handleCreateDiscount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCode.trim()) return;

    const promo = {
      code: newCode.trim().toUpperCase(),
      rate: parseInt(newRate) || 10,
      status: 'Active',
      usageCount: 0,
    };

    setDiscounts([promo, ...discounts]);
    setNewCode('');
  };

  // Calculations for analytics overview cards
  const totalSalesCount = orders.filter((o) => o.status === 'completed').length;
  const refundCount = orders.filter((o) => o.status === 'refunded').length;

  return (
    <section className="bg-neutral-950 text-white min-h-screen py-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Banner */}
        <div className="border-b border-neutral-900 pb-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold font-sans tracking-tight uppercase">
              Creator Studio Workspace
            </h2>
            <p className="text-neutral-500 text-xs font-mono uppercase mt-1">
              Configure products, process financial refunds, and analyze Wall Street conversion ratios.
            </p>
          </div>

          <div className="flex bg-neutral-900 p-1 rounded-lg border border-neutral-800">
            <button
              onClick={() => setActiveTab('analytics')}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeTab === 'analytics' ? 'bg-blue-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <BarChart className="w-3.5 h-3.5" /> Live Analytics
            </button>
            <button
              onClick={() => setActiveTab('products')}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeTab === 'products' ? 'bg-blue-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Plus className="w-3.5 h-3.5" /> Upload Asset
            </button>
            <button
              onClick={() => setActiveTab('orders')}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeTab === 'orders' ? 'bg-blue-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5" /> Orders Ledger
            </button>
            <button
              onClick={() => setActiveTab('discounts')}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeTab === 'discounts' ? 'bg-blue-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Percent className="w-3.5 h-3.5" /> Discount Codes
            </button>
          </div>
        </div>

        {/* Studio Content */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Main Content Workspace */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* Tab: Live Analytics & Financial Charts */}
            {activeTab === 'analytics' && (
              <div className="space-y-6">
                
                {/* Executive Scorecard */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5">
                    <span className="text-[10px] font-mono text-neutral-500 uppercase">Gross Revenue (EST)</span>
                    <h3 className="text-xl font-bold font-mono text-white mt-1">${creatorEarnings.toLocaleString()}</h3>
                    <span className="text-[9px] font-mono text-emerald-500 mt-1 block">+12.4% vs last Q</span>
                  </div>
                  <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5">
                    <span className="text-[10px] font-mono text-neutral-500 uppercase">Settled Orders</span>
                    <h3 className="text-xl font-bold font-mono text-white mt-1">{totalSalesCount}</h3>
                    <span className="text-[9px] font-mono text-neutral-600 mt-1 block">DRM key-validated</span>
                  </div>
                  <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5">
                    <span className="text-[10px] font-mono text-neutral-500 uppercase">Refund Ratios</span>
                    <h3 className="text-xl font-bold font-mono text-white mt-1">{refundCount}</h3>
                    <span className="text-[9px] font-mono text-neutral-500 mt-1 block">Conversion rate: 98.4%</span>
                  </div>
                  <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5">
                    <span className="text-[10px] font-mono text-neutral-500 uppercase">Platform Status</span>
                    <h3 className="text-xl font-bold font-sans text-emerald-400 mt-1">Excellent</h3>
                    <span className="text-[9px] font-mono text-neutral-500 mt-1 block">SEC & SOC2 compliant</span>
                  </div>
                </div>

                {/* Live Revenue Area Chart (Polished Custom SVG) */}
                <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-6">
                  <div className="flex justify-between items-center mb-6">
                    <div>
                      <h4 className="text-sm font-bold text-white uppercase font-mono">Continuous Revenue Analytics Ledger</h4>
                      <p className="text-xs text-neutral-500 mt-0.5">Sovereign settlement values tracked in USD decimals</p>
                    </div>
                    <div className="flex bg-neutral-900 p-1 rounded border border-neutral-800 text-xs">
                      <button onClick={() => setAnalyticsTime('30')} className={`px-2 py-0.5 rounded ${analyticsTime === '30' ? 'bg-white text-neutral-950 font-bold' : 'text-neutral-400'}`}>30D</button>
                      <button onClick={() => setAnalyticsTime('90')} className={`px-2 py-0.5 rounded ${analyticsTime === '90' ? 'bg-white text-neutral-950 font-bold' : 'text-neutral-400'}`}>90D</button>
                    </div>
                  </div>

                  {/* CUSTOM AREA CHART IN RESPONSIVE SVG */}
                  <div className="h-64 w-full relative">
                    <svg className="w-full h-full" viewBox="0 0 600 200" preserveAspectRatio="none">
                      <defs>
                        <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#2563eb" stopOpacity="0.4" />
                          <stop offset="100%" stopColor="#2563eb" stopOpacity="0.0" />
                        </linearGradient>
                      </defs>
                      {/* Gridlines */}
                      <line x1="0" y1="50" x2="600" y2="50" stroke="#1f2937" strokeWidth="1" strokeDasharray="3" />
                      <line x1="0" y1="100" x2="600" y2="100" stroke="#1f2937" strokeWidth="1" strokeDasharray="3" />
                      <line x1="0" y1="150" x2="600" y2="150" stroke="#1f2937" strokeWidth="1" strokeDasharray="3" />

                      {/* Area path */}
                      <path
                        d="M 0 170 C 100 130, 200 160, 300 110 C 400 60, 500 80, 600 40 L 600 200 L 0 200 Z"
                        fill="url(#areaGrad)"
                      />

                      {/* Line path */}
                      <path
                        d="M 0 170 C 100 130, 200 160, 300 110 C 400 60, 500 80, 600 40"
                        fill="none"
                        stroke="#3b82f6"
                        strokeWidth="2.5"
                      />

                      {/* Tooltip hover dots */}
                      <circle cx="300" cy="110" r="4" fill="#60a5fa" stroke="#ffffff" strokeWidth="1.5" />
                      <circle cx="600" cy="40" r="4" fill="#60a5fa" stroke="#ffffff" strokeWidth="1.5" />
                    </svg>

                    {/* Chart legends */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-neutral-950/80 border border-neutral-800 px-3 py-1.5 rounded-lg backdrop-blur-md text-center">
                      <p className="text-[10px] font-mono text-neutral-400 uppercase">Mid-Month High</p>
                      <p className="text-xs font-mono font-bold text-emerald-400">$18,450.00 settlement</p>
                    </div>

                    <div className="flex justify-between text-[10px] font-mono text-neutral-500 mt-2">
                      <span>Jul 05</span>
                      <span>Jul 15</span>
                      <span>Jul 25</span>
                      <span>Aug 05 (Today)</span>
                    </div>
                  </div>
                </div>

                {/* Secondary analytics: Donut Distribution & Search Trends */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Donut Chart: Asset categories share */}
                  <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4">
                    <h5 className="text-xs font-bold text-white uppercase font-mono">Digital Asset Segment Share</h5>
                    <div className="flex items-center justify-around gap-4 h-48">
                      {/* Donut drawing */}
                      <div className="relative w-32 h-32 shrink-0">
                        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                          {/* Background ring */}
                          <circle cx="18" cy="18" r="15.915" fill="none" stroke="#1f2937" strokeWidth="3" />
                          {/* Segment 1: Software 60% */}
                          <circle cx="18" cy="18" r="15.915" fill="none" stroke="#2563eb" strokeWidth="3" strokeDasharray="60 100" strokeDashoffset="0" />
                          {/* Segment 2: APIs 25% */}
                          <circle cx="18" cy="18" r="15.915" fill="none" stroke="#3b82f6" strokeWidth="3" strokeDasharray="25 100" strokeDashoffset="-60" />
                          {/* Segment 3: UI kits 15% */}
                          <circle cx="18" cy="18" r="15.915" fill="none" stroke="#10b981" strokeWidth="3" strokeDasharray="15 100" strokeDashoffset="-85" />
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                          <span className="text-[10px] text-neutral-400 font-mono uppercase">Top Line</span>
                          <span className="text-xs font-bold font-mono">Software</span>
                        </div>
                      </div>

                      {/* Legend details */}
                      <div className="text-xs space-y-2.5 font-mono">
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 bg-blue-600 rounded"></span>
                          <span className="text-neutral-400">Software (60%)</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 bg-blue-400 rounded"></span>
                          <span className="text-neutral-400">APIs & gRPC (25%)</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 bg-emerald-500 rounded"></span>
                          <span className="text-neutral-400">UI Kits (15%)</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Search Queries trends (Horizontal Bar chart) */}
                  <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4">
                    <h5 className="text-xs font-bold text-white uppercase font-mono">Trending Search Query Terms</h5>
                    <div className="space-y-3.5 h-48 justify-center flex flex-col">
                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] font-mono text-neutral-400">
                          <span>Rust Axum / High Latency</span>
                          <span className="text-white font-bold">420 hits</span>
                        </div>
                        <div className="w-full bg-neutral-900 h-2 rounded overflow-hidden border border-neutral-850">
                          <div className="bg-blue-600 h-full rounded" style={{ width: '85%' }}></div>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] font-mono text-neutral-400">
                          <span>Options Greeks API Connectors</span>
                          <span className="text-white font-bold">310 hits</span>
                        </div>
                        <div className="w-full bg-neutral-900 h-2 rounded overflow-hidden border border-neutral-850">
                          <div className="bg-blue-500 h-full rounded" style={{ width: '65%' }}></div>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] font-mono text-neutral-400">
                          <span>Fintech High-Density System</span>
                          <span className="text-white font-bold">180 hits</span>
                        </div>
                        <div className="w-full bg-neutral-900 h-2 rounded overflow-hidden border border-neutral-850">
                          <div className="bg-emerald-500 h-full rounded" style={{ width: '40%' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>

              </div>
            )}

            {/* Tab: Upload Products */}
            {activeTab === 'products' && (
              <form onSubmit={handleProductSubmit} className="bg-neutral-950 border border-neutral-900 rounded-xl p-6 space-y-5">
                <h4 className="text-xs font-bold text-white uppercase font-mono tracking-widest border-b border-neutral-900 pb-2">
                  Draft New Digital Asset Configuration
                </h4>

                {formSuccess && (
                  <div className="bg-emerald-950 text-emerald-400 border border-emerald-500/20 p-3.5 rounded-lg text-xs font-semibold">
                    Digital Asset uploaded successfully! Regenerating spot market catalog listings...
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-mono text-neutral-400 block mb-1">Spot Product Title</label>
                    <input
                      type="text"
                      required
                      value={prodTitle}
                      onChange={(e) => setProdTitle(e.target.value)}
                      placeholder="e.g. Gotham Options Option Volatility Server"
                      className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500 font-sans"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-neutral-400 block mb-1">Category Sector</label>
                    <select
                      value={prodCategory}
                      onChange={(e) => setProdCategory(e.target.value)}
                      className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500"
                    >
                      <option>Software</option>
                      <option>UI Kits</option>
                      <option>APIs</option>
                      <option>Cybersecurity</option>
                      <option>Fonts</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="text-[10px] font-mono text-neutral-400 block mb-1">Default Market Price ($)</label>
                    <input
                      type="number"
                      required
                      value={prodPrice}
                      onChange={(e) => setProdPrice(e.target.value)}
                      className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-neutral-400 block mb-1">File Archive Size</label>
                    <input
                      type="text"
                      required
                      value={prodSize}
                      onChange={(e) => setProdSize(e.target.value)}
                      className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-neutral-400 block mb-1">Compatibility Tags (comma separated)</label>
                    <input
                      type="text"
                      required
                      value={prodComp}
                      onChange={(e) => setProdComp(e.target.value)}
                      className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-mono text-neutral-400 block mb-1">Search Engine Meta Tags (comma separated)</label>
                  <input
                    type="text"
                    required
                    value={prodTags}
                    onChange={(e) => setProdTags(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-mono text-neutral-400 block mb-1">Short Elevator Pitch Description</label>
                  <textarea
                    rows={2}
                    required
                    value={prodDesc}
                    onChange={(e) => setProdDesc(e.target.value)}
                    placeholder="Provide a quick 2-line summary..."
                    className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500 font-sans"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-mono text-neutral-400 block mb-1">Comprehensive Specifications (Markdown supported)</label>
                  <textarea
                    rows={4}
                    value={prodLongDesc}
                    onChange={(e) => setProdLongDesc(e.target.value)}
                    placeholder="Provide extensive installation, database schemas, and microsecond parameters..."
                    className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500 font-sans"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-500 text-white py-2 rounded text-xs font-bold uppercase tracking-widest transition-all"
                >
                  Publish Asset to GDX Exchange
                </button>
              </form>
            )}

            {/* Tab: Orders Ledger */}
            {activeTab === 'orders' && (
              <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-6 space-y-4">
                <p className="text-xs font-mono uppercase text-neutral-500">Corporate Transaction Ledger</p>
                <div className="overflow-x-auto scrollbar-none">
                  <table className="w-full text-left font-sans border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-neutral-900 text-neutral-500 font-mono text-[10px] uppercase">
                        <th className="pb-3">Order Id</th>
                        <th className="pb-3">Digital Asset</th>
                        <th className="pb-3 text-right">Settled Price</th>
                        <th className="pb-3 text-right">SLA Date</th>
                        <th className="pb-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-900">
                      {orders.map((ord) => (
                        <tr key={ord.id} className="hover:bg-neutral-900/50">
                          <td className="py-3 font-mono text-neutral-400">{ord.id}</td>
                          <td className="py-3 text-white font-semibold">
                            {ord.itemTitle}{' '}
                            <span className="text-[10px] font-mono text-neutral-500 uppercase">
                              ({ord.type})
                            </span>
                          </td>
                          <td className="py-3 text-right font-mono text-white font-bold">${ord.price}</td>
                          <td className="py-3 text-right text-neutral-400">{ord.purchaseDate}</td>
                          <td className="py-3 text-right">
                            {ord.status === 'refunded' ? (
                              <span className="text-red-400 text-[10px] font-mono bg-red-950 px-2 py-0.5 rounded border border-red-500/10">
                                Refunded
                              </span>
                            ) : (
                              <button
                                onClick={() => processRefund(ord.id)}
                                className="text-[10px] font-mono text-red-500 hover:text-red-400 hover:underline uppercase"
                              >
                                Process Refund
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Tab: Discount Campaigns */}
            {activeTab === 'discounts' && (
              <div className="space-y-6">
                
                {/* Add coupon */}
                <form onSubmit={handleCreateDiscount} className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold text-white uppercase font-mono tracking-widest border-b border-neutral-900 pb-2">
                    Inject Coupon Code Campaign
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-mono text-neutral-400 block mb-1">Coupon code (Alphanumeric)</label>
                      <input
                        type="text"
                        required
                        value={newCode}
                        onChange={(e) => setNewCode(e.target.value)}
                        placeholder="e.g. HUDSON_BETA"
                        className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500 font-mono uppercase"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-mono text-neutral-400 block mb-1">Discount rate (%)</label>
                      <input
                        type="number"
                        min="5"
                        max="80"
                        required
                        value={newRate}
                        onChange={(e) => setNewRate(e.target.value)}
                        className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500 font-mono"
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold tracking-wide"
                  >
                    Deploy Campaign
                  </button>
                </form>

                {/* Active discounts table */}
                <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold text-white uppercase font-mono tracking-widest border-b border-neutral-900 pb-2">
                    Active Campaigns Grid
                  </h4>
                  {discounts.map((disc) => (
                    <div key={disc.code} className="flex justify-between items-center border-b border-neutral-900 pb-3 last:border-0 last:pb-0 text-xs">
                      <div>
                        <span className="font-mono text-white font-bold bg-neutral-900 px-2 py-1 rounded border border-neutral-800">
                          {disc.code}
                        </span>
                        <p className="text-[10px] text-neutral-500 font-mono mt-2">Usage: {disc.usageCount} checkouts</p>
                      </div>
                      <div className="text-right">
                        <span className="text-sm font-bold font-mono text-emerald-400">-{disc.rate}% Off</span>
                        <span className="text-[9px] font-mono text-neutral-500 uppercase block mt-1">{disc.status}</span>
                      </div>
                    </div>
                  ))}
                </div>

              </div>
            )}

          </div>

          {/* Right sidebar help desk */}
          <div className="lg:col-span-1 space-y-6">
            
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4 shadow-lg">
              <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest block">GDX SELLER TERMS</span>
              <p className="text-xs text-neutral-400 leading-relaxed">
                As a Gotham Digital Exchange creator, you retain **80%** of settled revenues on spot assets and **95%** of hourly professional consulting fees. Payments are settled in USD via institutional bank wire.
              </p>
            </div>

            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-3">
              <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest block">SYSTEM SHIELD PROV</span>
              <div className="flex items-center gap-2 text-xs text-neutral-300">
                <ShieldCheck className="w-4 h-4 text-blue-500" />
                <span>Encrypted delivery channels</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-neutral-300">
                <ShieldCheck className="w-4 h-4 text-blue-500" />
                <span>Anti-fraud chargeback defense</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
