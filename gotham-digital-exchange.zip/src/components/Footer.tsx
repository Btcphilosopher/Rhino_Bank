/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Shield, Sparkles, Send, Globe, Landmark, MapPin } from 'lucide-react';

interface FooterProps {
  setView: (view: string) => void;
  setRole: (role: 'buyer' | 'creator' | 'enterprise' | 'docs') => void;
}

export default function Footer({ setView, setRole }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-neutral-950 border-t border-neutral-900 font-sans text-neutral-400 text-xs mt-auto">
      {/* 1. Primary Editorial Directory Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          
          {/* Brand block */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded bg-blue-600 flex items-center justify-center border border-blue-400/30">
                <span className="text-white font-bold font-mono text-[10px]">GDX</span>
              </div>
              <span className="text-white font-bold font-sans tracking-tight text-sm uppercase">
                Gotham Digital Exchange
              </span>
            </div>
            <p className="text-neutral-500 max-w-sm leading-relaxed text-[11px]">
              Headquartered at 48 Wall Street, NYC. Gotham Digital Exchange represents the premium commercial gateway for institutional-grade digital assets, verified technical products, and on-demand elite consulting.
            </p>
            <div className="flex flex-col space-y-1.5 text-neutral-500 font-mono text-[11px]">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-blue-500" />
                <span>48 Wall Street, 18th Floor, New York, NY 10005</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-blue-500" />
                <span>Silicon Alley Annex, Flatiron, NY 10010</span>
              </div>
            </div>
          </div>

          {/* Column 1: Core Exchange */}
          <div className="space-y-3">
            <h4 className="text-white font-bold uppercase tracking-wider text-[11px] font-mono">Marketplace</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => { setView('marketplace'); setRole('buyer'); }} className="hover:text-white transition-colors">
                  Software Boilerplates
                </button>
              </li>
              <li>
                <button onClick={() => { setView('marketplace'); setRole('buyer'); }} className="hover:text-white transition-colors">
                  FinTech Design Systems
                </button>
              </li>
              <li>
                <button onClick={() => { setView('marketplace'); setRole('buyer'); }} className="hover:text-white transition-colors">
                  API Connectors & gRPC
                </button>
              </li>
              <li>
                <button onClick={() => { setView('marketplace'); setRole('buyer'); }} className="hover:text-white transition-colors">
                  Cybersecurity Solidity Kits
                </button>
              </li>
              <li>
                <button onClick={() => { setView('marketplace'); setRole('buyer'); }} className="hover:text-white transition-colors">
                  Bespoke Font Families
                </button>
              </li>
            </ul>
          </div>

          {/* Column 2: Expert Services */}
          <div className="space-y-3">
            <h4 className="text-white font-bold uppercase tracking-wider text-[11px] font-mono">Consulting Services</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => { setView('services'); setRole('buyer'); }} className="hover:text-white transition-colors">
                  Cloud Infrastructure & K8s
                </button>
              </li>
              <li>
                <button onClick={() => { setView('services'); setRole('buyer'); }} className="hover:text-white transition-colors">
                  Quantitative Strategy Labs
                </button>
              </li>
              <li>
                <button onClick={() => { setView('services'); setRole('buyer'); }} className="hover:text-white transition-colors">
                  Fintech UI/UX Sprints
                </button>
              </li>
              <li>
                <button onClick={() => { setView('services'); setRole('buyer'); }} className="hover:text-white transition-colors">
                  Penetration Testing & Audits
                </button>
              </li>
              <li>
                <button onClick={() => { setView('services'); setRole('buyer'); }} className="hover:text-white transition-colors">
                  Custom AI Implementations
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Professional Hubs */}
          <div className="space-y-3">
            <h4 className="text-white font-bold uppercase tracking-wider text-[11px] font-mono">Organization</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => { setView('enterprise-hub'); setRole('enterprise'); }} className="hover:text-white transition-colors text-blue-400 font-semibold">
                  Enterprise Procurement
                </button>
              </li>
              <li>
                <button onClick={() => { setView('creator-dashboard'); setRole('creator'); }} className="hover:text-white transition-colors">
                  Creator Studio Portal
                </button>
              </li>
              <li>
                <button onClick={() => { setView('community'); setRole('buyer'); }} className="hover:text-white transition-colors">
                  Gotham Forum & Articles
                </button>
              </li>
              <li>
                <button onClick={() => { setView('docs'); setRole('docs'); }} className="hover:text-white transition-colors text-amber-500 font-mono">
                  GDX API Documentation
                </button>
              </li>
            </ul>
          </div>

        </div>
      </div>

      {/* 2. Secondary Compliance & Operations Status Bar */}
      <div className="bg-neutral-950 border-t border-neutral-900 py-6 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] text-neutral-500 font-mono">
          <div>
            <p>&copy; {currentYear} Gotham Digital Exchange, Inc. (GDX). All rights reserved.</p>
            <p className="mt-1 text-neutral-600">
              Approved licenses subject to cryptographic validation hashes. Downloads and APIs protected by Gotham DRM Security v3.12.
            </p>
          </div>
          <div className="flex flex-wrap gap-4 text-neutral-500">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full inline-block"></span>
              Sovereign Nodes Active
            </span>
            <span>SEC Regulatory Standards Met</span>
            <span>SOC2 Type II Compliant</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
