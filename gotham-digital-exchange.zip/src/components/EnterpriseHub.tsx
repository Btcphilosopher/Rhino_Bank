/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ShieldCheck, UserPlus, Users, FileText, CheckCircle, Landmark, Building, Mail, AlertTriangle, ArrowRight, DollarSign } from 'lucide-react';
import { EnterpriseSeat, Invoice, Order } from '../types';

interface EnterpriseHubProps {
  seats: EnterpriseSeat[];
  addSeat: (email: string, role: 'Developer' | 'Manager' | 'Billing') => void;
  revokeSeat: (email: string) => void;
  invoices: Invoice[];
  pendingApprovals: { id: string; requestedBy: string; itemName: string; price: number; date: string }[];
  approveProcurement: (reqId: string, itemName: string, price: number) => void;
  orders: Order[];
}

export default function EnterpriseHub({
  seats,
  addSeat,
  revokeSeat,
  invoices,
  pendingApprovals,
  approveProcurement,
  orders,
}: EnterpriseHubProps) {
  const [activeTab, setActiveTab] = useState<'seats' | 'procurement' | 'org' | 'contracts'>('seats');
  
  // Seat provision inputs
  const [seatEmail, setSeatEmail] = useState('');
  const [seatRole, setSeatRole] = useState<'Developer' | 'Manager' | 'Billing'>('Developer');
  const [provisionSuccess, setProvisionSuccess] = useState(false);

  // Corporate profile fields
  const [orgProfile, setOrgProfile] = useState({
    companyName: 'Manhattan Capital Group, LLC',
    billingEmail: 'billing@manhattancapital.com',
    sector: 'Investment Banking & Quant Management',
    duns: '09-112-8401',
    taxId: 'US-891024-C',
  });

  const handleSeatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!seatEmail.trim()) return;
    addSeat(seatEmail.trim(), seatRole);
    setProvisionSuccess(true);
    setSeatEmail('');
    setTimeout(() => setProvisionSuccess(false), 2000);
  };

  const completedPurchasesCount = orders.filter((o) => o.type === 'product').length;

  return (
    <section className="bg-neutral-950 text-white min-h-screen py-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Banner */}
        <div className="border-b border-neutral-900 pb-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs text-blue-400 font-mono font-bold uppercase tracking-widest block">
              GDX Business Portal
            </span>
            <h2 className="text-2xl font-bold font-sans tracking-tight uppercase mt-1">
              Enterprise Hub & Procurement
            </h2>
          </div>

          <div className="flex bg-neutral-900 p-1 rounded-lg border border-neutral-800">
            <button
              onClick={() => setActiveTab('seats')}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeTab === 'seats' ? 'bg-blue-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5" /> Team Seats ({seats.length})
            </button>
            <button
              onClick={() => setActiveTab('procurement')}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeTab === 'procurement' ? 'bg-blue-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5" /> Approvals Ledger ({pendingApprovals.length})
            </button>
            <button
              onClick={() => setActiveTab('org')}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeTab === 'org' ? 'bg-blue-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Building className="w-3.5 h-3.5" /> Corporate Profile
            </button>
          </div>
        </div>

        {/* Content Tabs */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Main workspace */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* Tab: Seat management */}
            {activeTab === 'seats' && (
              <div className="space-y-6">
                
                {/* Provision Seat form */}
                <form onSubmit={handleSeatSubmit} className="bg-neutral-950 border border-neutral-900 rounded-xl p-6 space-y-4 shadow-lg">
                  <h4 className="text-xs font-bold text-white uppercase font-mono tracking-widest border-b border-neutral-900 pb-2">
                    Allocate Corporate Seat & Key Rights
                  </h4>

                  {provisionSuccess && (
                    <div className="bg-emerald-950 text-emerald-400 border border-emerald-500/20 p-3 rounded text-xs font-semibold">
                      Seat allocated successfully! Dispatching encryption tokens...
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-mono text-neutral-400 block mb-1">Developer Corporate Email</label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Mail className="h-4 w-4 text-neutral-500" />
                        </div>
                        <input
                          type="email"
                          required
                          value={seatEmail}
                          onChange={(e) => setSeatEmail(e.target.value)}
                          placeholder="developer@manhattancapital.com"
                          className="w-full bg-neutral-900 border border-neutral-800 rounded pl-9 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 font-sans"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] font-mono text-neutral-400 block mb-1">Assigned Role Rights</label>
                      <select
                        value={seatRole}
                        onChange={(e) => setSeatRole(e.target.value as any)}
                        className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-1.5 text-white focus:outline-none focus:border-blue-500"
                      >
                        <option>Developer</option>
                        <option>Manager</option>
                        <option>Billing</option>
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold tracking-wide"
                  >
                    Authorize Seat Rights
                  </button>
                </form>

                {/* Team seats table */}
                <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold text-white uppercase font-mono tracking-widest border-b border-neutral-900 pb-2">
                    Active Assigned Seats Grid
                  </h4>
                  <div className="overflow-x-auto scrollbar-none">
                    <table className="w-full text-left font-sans border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-neutral-900 text-neutral-500 font-mono text-[10px] uppercase">
                          <th className="pb-3">Developer Seat</th>
                          <th className="pb-3">Role Rights</th>
                          <th className="pb-3">Assigned Date</th>
                          <th className="pb-3">Status</th>
                          <th className="pb-3 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-neutral-900">
                        {seats.map((seat) => (
                          <tr key={seat.email} className="hover:bg-neutral-900/50">
                            <td className="py-3 font-mono font-medium text-white">{seat.email}</td>
                            <td className="py-3 text-neutral-400 font-mono">{seat.role}</td>
                            <td className="py-3 text-neutral-400">{seat.assignedAt}</td>
                            <td className="py-3">
                              <span className="bg-emerald-950 text-emerald-400 border border-emerald-500/10 px-2 py-0.5 rounded text-[9px] font-mono">
                                {seat.status}
                              </span>
                            </td>
                            <td className="py-3 text-right">
                              <button
                                onClick={() => revokeSeat(seat.email)}
                                className="text-red-500 hover:text-red-400 font-mono text-[10px] uppercase hover:underline"
                              >
                                Revoke Rights
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            )}

            {/* Tab: Procurement Approvals Ledger */}
            {activeTab === 'procurement' && (
              <div className="space-y-6">
                
                {/* Approvals ledger list */}
                <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold text-white uppercase font-mono tracking-widest border-b border-neutral-900 pb-2 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-500" /> Procurement Approvals Awaiting Authorization
                  </h4>
                  {pendingApprovals.length === 0 ? (
                    <div className="text-center py-12">
                      <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                      <p className="text-xs text-neutral-300 font-semibold">No pending procurement purchase requests.</p>
                      <p className="text-[10px] text-neutral-500 font-mono uppercase mt-1">All developer seat requirements satisfied</p>
                    </div>
                  ) : (
                    pendingApprovals.map((req) => (
                      <div
                        key={req.id}
                        className="bg-neutral-900/50 border border-neutral-850 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
                      >
                        <div>
                          <span className="text-[9px] font-mono text-neutral-500 uppercase">
                            REQUESTED BY {req.requestedBy} ON {req.date}
                          </span>
                          <h4 className="text-xs font-bold text-white mt-1">
                            Purchase: <span className="text-blue-400 font-semibold">{req.itemName}</span>
                          </h4>
                          <p className="text-[10px] text-neutral-400 font-mono mt-1">
                            Allocation: Enterprise Multi-Seat Licenses
                          </p>
                        </div>

                        <div className="flex items-center gap-4 shrink-0 justify-between md:justify-end">
                          <span className="font-mono text-sm font-extrabold text-white">${req.price}</span>
                          <button
                            onClick={() => approveProcurement(req.id, req.itemName, req.price)}
                            className="bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-bold uppercase tracking-wider px-3.5 py-1.5 rounded transition-colors"
                          >
                            Authorize & Pay
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                {/* Historic invoices */}
                <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold text-white uppercase font-mono tracking-widest border-b border-neutral-900 pb-2">
                    Tax Receipt & Corporate Invoices
                  </h4>
                  <div className="overflow-x-auto scrollbar-none">
                    <table className="w-full text-left font-sans border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-neutral-900 text-neutral-500 font-mono text-[10px] uppercase">
                          <th className="pb-3">Invoice ID</th>
                          <th className="pb-3">Settlement Date</th>
                          <th className="pb-3">Organization Client</th>
                          <th className="pb-3">Digital Asset</th>
                          <th className="pb-3 text-right">Tax Rates</th>
                          <th className="pb-3 text-right">Total Invoice</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-neutral-900">
                        {invoices.map((inv) => (
                          <tr key={inv.id} className="hover:bg-neutral-900/50">
                            <td className="py-3 font-mono text-neutral-400">{inv.id}</td>
                            <td className="py-3 text-neutral-400">{inv.purchaseDate}</td>
                            <td className="py-3 text-neutral-400">{inv.companyName}</td>
                            <td className="py-3 text-white font-semibold">{inv.itemName}</td>
                            <td className="py-3 text-right font-mono text-neutral-500">NY STATE (8.875%)</td>
                            <td className="py-3 text-right font-mono text-white font-bold">${inv.total}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            )}

            {/* Tab: Corporate Settings profile */}
            {activeTab === 'org' && (
              <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-6 space-y-5 shadow-lg">
                <h4 className="text-xs font-bold text-white uppercase font-mono tracking-widest border-b border-neutral-900 pb-2">
                  Configure Corporate Organization Entity
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-mono text-neutral-400 block mb-1">DUNS Identifier (Global Credit)</label>
                    <input
                      type="text"
                      disabled
                      value={orgProfile.duns}
                      className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-neutral-400 font-mono cursor-not-allowed"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-neutral-400 block mb-1">Federal Tax / EIN Identifier</label>
                    <input
                      type="text"
                      disabled
                      value={orgProfile.taxId}
                      className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-neutral-400 font-mono cursor-not-allowed"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-mono text-neutral-400 block mb-1">Company Entity Name</label>
                    <input
                      type="text"
                      value={orgProfile.companyName}
                      onChange={(e) => setOrgProfile({ ...orgProfile, companyName: e.target.value })}
                      className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500 font-sans"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-neutral-400 block mb-1">Central Billing Email</label>
                    <input
                      type="email"
                      value={orgProfile.billingEmail}
                      onChange={(e) => setOrgProfile({ ...orgProfile, billingEmail: e.target.value })}
                      className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-mono text-neutral-400 block mb-1">Corporate Industry Sector</label>
                  <input
                    type="text"
                    value={orgProfile.sector}
                    onChange={(e) => setOrgProfile({ ...orgProfile, sector: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500 font-sans"
                  />
                </div>
              </div>
            )}

          </div>

          {/* Right scorecard help desk */}
          <div className="lg:col-span-1 space-y-6">
            
            {/* Procurement stats */}
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4 shadow-lg">
              <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest block font-bold">PROCURMENT METRICS</span>
              <div className="space-y-3 font-mono text-xs text-neutral-400">
                <div className="flex justify-between">
                  <span>Assigned Seats</span>
                  <span className="text-white font-bold">{seats.length} / 10</span>
                </div>
                <div className="flex justify-between">
                  <span>Authorized Assets</span>
                  <span className="text-white font-bold">{completedPurchasesCount}</span>
                </div>
                <div className="flex justify-between">
                  <span>SLA Coverage</span>
                  <span className="text-emerald-400 font-bold">ACTIVE</span>
                </div>
              </div>
            </div>

            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4">
              <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest block">GDX GLOBAL ESCROW</span>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                As a corporate entity, all digital assets purchased on GDX are guaranteed against downtime or repository loss via our central New York server backups registry.
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
