/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Layers, Database, Code, ShieldCheck, ChevronRight, CheckCircle, Terminal } from 'lucide-react';

export default function GDXDocs() {
  const [activeSubView, setActiveSubView] = useState<'architecture' | 'schema' | 'api'>('architecture');
  const [selectedTable, setSelectedTable] = useState<string>('products');

  // Database Schema specifications
  const dbSchema = {
    users: {
      description: 'System-wide accounts tracking balance, roles, and encryption tokens.',
      columns: [
        { name: 'id', type: 'UUID', key: 'PK', desc: 'Unique account identifier.' },
        { name: 'email', type: 'VARCHAR(255)', key: 'UQ', desc: 'Secure institutional email.' },
        { name: 'balance', type: 'DECIMAL(12,2)', key: '', desc: 'Settled cash balance in USD.' },
        { name: 'role_rights', type: 'VARCHAR(64)', key: '', desc: 'User capabilities role.' },
        { name: 'created_at', type: 'TIMESTAMP', key: '', desc: 'Account provision date.' },
      ],
    },
    products: {
      description: 'Spot digital products uploaded by creators and available for download.',
      columns: [
        { name: 'id', type: 'VARCHAR(64)', key: 'PK', desc: 'Unique asset identifier.' },
        { name: 'title', type: 'VARCHAR(255)', key: '', desc: 'Display name of spot asset.' },
        { name: 'price', type: 'DECIMAL(10,2)', key: '', desc: 'Asset market standard price.' },
        { name: 'creator_id', type: 'VARCHAR(64)', key: 'FK -> creators.id', desc: 'Responsible developer studio.' },
        { name: 'version', type: 'VARCHAR(16)', key: '', desc: 'Active deployment version.' },
        { name: 'download_size', type: 'VARCHAR(32)', key: '', desc: 'ZIP archive storage size.' },
        { name: 'enterprise_ready', type: 'BOOLEAN', key: '', desc: 'SOC2 & bulk license capability status.' },
      ],
    },
    orders: {
      description: 'Chronological transaction logs representing cash swaps and DRM authorization hashes.',
      columns: [
        { name: 'id', type: 'VARCHAR(64)', key: 'PK', desc: 'Cryptographic ledger receipt key.' },
        { name: 'item_id', type: 'VARCHAR(64)', key: 'FK', desc: 'Acquired asset or service id.' },
        { name: 'price', type: 'DECIMAL(10,2)', key: '', desc: 'Settled transaction price.' },
        { name: 'status', type: 'VARCHAR(32)', key: '', desc: 'Completed, active, or refunded status.' },
        { name: 'purchase_date', type: 'VARCHAR(32)', key: '', desc: 'Execution timestamp.' },
        { name: 'license_key', type: 'VARCHAR(255)', key: '', desc: 'Secure cryptographic license key.' },
      ],
    },
    milestones: {
      description: 'Escrow release steps allocated to consulting engagements.',
      columns: [
        { name: 'id', type: 'UUID', key: 'PK', desc: 'Milestone task key.' },
        { name: 'order_id', type: 'VARCHAR(64)', key: 'FK -> orders.id', desc: 'Hiring contract envelope.' },
        { name: 'title', type: 'VARCHAR(255)', key: '', desc: 'Deliverable module scope description.' },
        { name: 'amount', type: 'DECIMAL(10,2)', key: '', desc: 'Escrow cash allocated.' },
        { name: 'status', type: 'VARCHAR(32)', key: '', desc: 'Pending, in_progress, or completed.' },
      ],
    },
  };

  // API endpoint configurations
  const apiEndpoints = [
    {
      method: 'GET',
      path: '/api/v1/spot/assets',
      desc: 'Retrieve spot marketplace digital assets with detailed compatibility matrices.',
      response: `{
  "status": "success",
  "data": [
    {
      "id": "prod-1",
      "title": "Nouveau-SaaS Boilerplate",
      "price": 299.00,
      "version": "v2.4.1",
      "downloadSize": "42.8 MB"
    }
  ]
}`,
    },
    {
      method: 'POST',
      path: '/api/v1/escrow/proposal',
      desc: 'Submit custom contract proposal and lock milestone payments inside GDX Escrow ledger.',
      request: `{
  "serviceId": "srv-1",
  "packageName": "High Availability Multi-Tenant Stack",
  "price": 6500.00,
  "kickoffDate": "2026-08-10"
}`,
      response: `{
  "status": "success",
  "contractId": "ORD-user-891024",
  "escrowLocked": 6630.00,
  "milestonesCreated": 4
}`,
    },
    {
      method: 'GET',
      path: '/api/v1/drm/verify',
      desc: 'Validate client license keys and generate cryptographically signed secure download links.',
      request: `?license_key=GDX-LIC-0x92f8a1`,
      response: `{
  "status": "authorized",
  "licenseValidity": "active",
  "secureLink": "https://gotham-drm.s3.nyc.gotham.gdx/archives/DL-921.zip?token=xyz",
  "checksumSHA256": "4a82fb8130..."
}`,
    },
  ];

  return (
    <section className="bg-neutral-950 text-white min-h-screen py-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Banner */}
        <div className="border-b border-neutral-900 pb-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold font-sans tracking-tight uppercase">
              GDX Developer & Architecture Desk
            </h2>
            <p className="text-neutral-500 text-xs font-mono uppercase mt-1">
              Read technical specifications, inspect interactive database schemas, and view REST/gRPC models.
            </p>
          </div>

          <div className="flex bg-neutral-900 p-1 rounded-lg border border-neutral-800">
            <button
              onClick={() => setActiveSubView('architecture')}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeSubView === 'architecture' ? 'bg-blue-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" /> Architecture
            </button>
            <button
              onClick={() => setActiveSubView('schema')}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeSubView === 'schema' ? 'bg-blue-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Database className="w-3.5 h-3.5" /> DB Schema
            </button>
            <button
              onClick={() => setActiveSubView('api')}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeSubView === 'api' ? 'bg-blue-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Code className="w-3.5 h-3.5" /> OpenAPI Reference
            </button>
          </div>
        </div>

        {/* Documentation Content */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Main workspace */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* View: System Architecture */}
            {activeSubView === 'architecture' && (
              <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-6 space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-white uppercase font-mono tracking-widest border-b border-neutral-900 pb-2">
                    Gotham Digital Exchange Core Architecture
                  </h3>
                  <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
                    GDX is engineered around microsecond transaction boundaries, using an isolated double runtime stack.
                  </p>
                </div>

                {/* Architecture block flow diagram */}
                <div className="bg-neutral-900 p-6 rounded-xl border border-neutral-850 space-y-4">
                  <p className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest block font-bold">
                    System Data Flow Mechanics
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center text-xs font-mono">
                    <div className="bg-neutral-950 border border-neutral-800 p-4 rounded-lg">
                      <span className="text-blue-400 font-bold block mb-1">CLIENT ROUTER</span>
                      <p className="text-[10px] text-neutral-500 leading-snug">
                        Next.js & React 19 visual portal managing DRM keys and escrow custom contracts.
                      </p>
                    </div>
                    <div className="bg-neutral-950 border border-neutral-800 p-4 rounded-lg">
                      <span className="text-emerald-400 font-bold block mb-1">API SERVER (RUST)</span>
                      <p className="text-[10px] text-neutral-500 leading-snug">
                        Axum multi-threaded calculation micro-services performing option greeks algorithms.
                      </p>
                    </div>
                    <div className="bg-neutral-950 border border-neutral-800 p-4 rounded-lg">
                      <span className="text-purple-400 font-bold block mb-1">DATABASE CLUSTER</span>
                      <p className="text-[10px] text-neutral-500 leading-snug">
                        PostgreSQL instance persisting users balance ledger, team seats, and settlement invoices.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Operations details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                  <div className="space-y-2">
                    <h5 className="text-xs font-bold text-white uppercase font-mono">Docker Containerization</h5>
                    <p className="text-xs text-neutral-400 leading-relaxed">
                      All assets compile to alpine-based container wrappers to eliminate host OS inconsistencies. Build configurations leverage dual-stage builds to shrink memory footprint down to 18MB.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h5 className="text-xs font-bold text-white uppercase font-mono">Sovereign DRM Shield</h5>
                    <p className="text-xs text-neutral-400 leading-relaxed">
                      GDX enforces Digital Rights Management (DRM) using randomized 256-bit hash validation keys. Each download archives standard metadata identifiers to trace leak vectors.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* View: Database Schema Table Visualizer */}
            {activeSubView === 'schema' && (
              <div className="space-y-6">
                
                {/* Table Picker */}
                <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-1.5 flex gap-2 overflow-x-auto">
                  {Object.keys(dbSchema).map((tbl) => (
                    <button
                      key={tbl}
                      onClick={() => setSelectedTable(tbl)}
                      className={`flex-1 py-1.5 px-3 text-xs font-mono uppercase tracking-wider rounded transition-all ${
                        selectedTable === tbl ? 'bg-blue-600 text-white shadow' : 'text-neutral-400 hover:text-white'
                      }`}
                    >
                      {tbl}
                    </button>
                  ))}
                </div>

                {/* Table details display */}
                <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-6 space-y-4">
                  <div>
                    <h4 className="text-sm font-bold text-white uppercase font-mono">
                      Table: {selectedTable}
                    </h4>
                    <p className="text-xs text-neutral-400 mt-1">
                      {dbSchema[selectedTable as keyof typeof dbSchema].description}
                    </p>
                  </div>

                  {/* Schema table columns */}
                  <div className="overflow-x-auto scrollbar-none pt-2">
                    <table className="w-full text-left font-mono text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-neutral-900 text-neutral-500 uppercase text-[10px]">
                          <th className="pb-2">Field name</th>
                          <th className="pb-2">Type</th>
                          <th className="pb-2">Key specs</th>
                          <th className="pb-2">Description</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-neutral-900 text-neutral-300">
                        {dbSchema[selectedTable as keyof typeof dbSchema].columns.map((col: any) => (
                          <tr key={col.name}>
                            <td className="py-2.5 font-bold text-white">{col.name}</td>
                            <td className="py-2.5 text-neutral-400">{col.type}</td>
                            <td className="py-2.5 text-blue-400 font-semibold text-[10px]">{col.key}</td>
                            <td className="py-2.5 text-neutral-400 text-[11px]">{col.desc}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            )}

            {/* View: OpenAPI Specs reference */}
            {activeSubView === 'api' && (
              <div className="space-y-6">
                {apiEndpoints.map((ep, idx) => (
                  <div key={idx} className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-900 pb-3">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded font-mono text-[10px] font-bold ${
                          ep.method === 'GET' ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/20' : 'bg-blue-950 text-blue-400 border border-blue-500/20'
                        }`}>
                          {ep.method}
                        </span>
                        <span className="text-xs font-mono font-bold text-white">{ep.path}</span>
                      </div>
                      <p className="text-xs text-neutral-400 italic font-sans">{ep.desc}</p>
                    </div>

                    {/* Payloads */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {ep.request && (
                        <div className="space-y-1.5">
                          <p className="text-[9px] font-mono text-neutral-500 uppercase">Request Params / JSON</p>
                          <pre className="bg-neutral-900 border border-neutral-850 p-3 rounded-lg font-mono text-[10px] text-blue-300 overflow-x-auto">
                            {ep.request}
                          </pre>
                        </div>
                      )}
                      <div className="space-y-1.5 md:col-span-1">
                        <p className="text-[9px] font-mono text-neutral-500 uppercase">JSON Response (200 OK)</p>
                        <pre className="bg-neutral-900 border border-neutral-850 p-3 rounded-lg font-mono text-[10px] text-emerald-300 overflow-x-auto">
                          {ep.response}
                        </pre>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

          </div>

          {/* Right sidebar help desk */}
          <div className="lg:col-span-1 space-y-6">
            
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4 shadow-lg">
              <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest block font-bold">API COMPLIANCE</span>
              <p className="text-xs text-neutral-400 leading-relaxed">
                All requests to Gotham Digital Exchange APIs require standard HTTP Bearer token headers verified against GDX corporate accounts keys. Rate limit: 2,500 req/min per key.
              </p>
            </div>

            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-3">
              <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest block">SECURITY PROTOCOL</span>
              <div className="flex items-center gap-2 text-xs text-neutral-300">
                <ShieldCheck className="w-4 h-4 text-blue-500" />
                <span>Oauth 2.0 authorization code flow</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-neutral-300">
                <ShieldCheck className="w-4 h-4 text-blue-500" />
                <span>Stateful HTTP-only session keys</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
