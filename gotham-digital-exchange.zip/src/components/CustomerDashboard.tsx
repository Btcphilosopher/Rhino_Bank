/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Download, ShieldCheck, FileText, CheckCircle, Clock, Trash, Heart, MessageSquare, AlertTriangle, Send, ChevronRight, Bookmark } from 'lucide-react';
import { Order, CartItem, Invoice } from '../types';

interface CustomerDashboardProps {
  orders: Order[];
  savedItems: CartItem[];
  removeSavedItem: (id: string) => void;
  approveProjectMilestone: (orderId: string, milestoneId: string) => void;
  invoices: Invoice[];
}

export default function CustomerDashboard({
  orders,
  savedItems,
  removeSavedItem,
  approveProjectMilestone,
  invoices,
}: CustomerDashboardProps) {
  const [activeTab, setActiveTab] = useState<'purchases' | 'projects' | 'invoices' | 'saved' | 'messages' | 'support'>('purchases');
  const [downloadProgress, setDownloadProgress] = useState<{ [key: string]: number }>({});
  const [downloadLog, setDownloadLog] = useState<string[]>(['GDX DRM Security active.', 'Awaiting secure link requests...']);

  // Support tickets state
  const [tickets, setTickets] = useState([
    { id: 'TKT-1082', subject: 'NextJS hydration warnings', category: 'Technical Support', status: 'In Review', date: '2026-08-01' },
    { id: 'TKT-1044', subject: 'gRPC node client configurations', category: 'API / Development', status: 'Resolved', date: '2026-07-20' },
  ]);
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketCategory, setTicketCategory] = useState('Technical Support');

  // Messages state
  const [chatMessages, setChatMessages] = useState([
    { id: 1, sender: 'Silicon Alley Labs', text: 'Hey there! We just updated our Next.js client to support React 19 native tags. Check out the changelog.', time: '09:30 AM' },
    { id: 2, sender: 'You', text: 'Awesome, thanks! I am downloading the new version now. Does it resolve the Drizzle connection pooling bug?', time: '10:00 AM' },
    { id: 3, sender: 'Silicon Alley Labs', text: 'Yes, absolutely. We added a client-level keepAlive threshold which limits connection exhaustion.', time: '10:02 AM' },
  ]);
  const [chatInput, setChatInput] = useState('');

  // Handle support ticket submit
  const handleTicketSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject.trim()) return;
    const newTkt = {
      id: `TKT-${Math.floor(1000 + Math.random() * 9000)}`,
      subject: ticketSubject,
      category: ticketCategory,
      status: 'Awaiting SLA assignment',
      date: new Date().toISOString().split('T')[0],
    };
    setTickets([newTkt, ...tickets]);
    setTicketSubject('');
  };

  // Handle mock chat sending
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    const msg = {
      id: chatMessages.length + 1,
      sender: 'You',
      text: chatInput,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setChatMessages([...chatMessages, msg]);
    setChatInput('');

    // Simulate response
    setTimeout(() => {
      const resp = {
        id: chatMessages.length + 2,
        sender: 'Silicon Alley Labs',
        text: 'Understood. Let me pass this scope update to our New York developer squad. We will correspond within the hour.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setChatMessages((prev) => [...prev, resp]);
    }, 1500);
  };

  // Simulate Cryptographic Secure Download
  const triggerSecureDownload = (orderId: string, title: string) => {
    if (downloadProgress[orderId] !== undefined) return;
    
    setDownloadProgress((prev) => ({ ...prev, [orderId]: 0 }));
    setDownloadLog((prev) => [...prev, `>> Requesting Secure Download Link for: "${title}"`, 'Verifying purchase license validity...', 'Performing hand-off cryptograph...']);

    const interval = setInterval(() => {
      setDownloadProgress((prev) => {
        const current = prev[orderId];
        if (current >= 100) {
          clearInterval(interval);
          setDownloadLog((log) => [...log, `>> SECURE FILE DOWNLOAD COMPLETED: GDX_SEC_ARCHIVE_${orderId.slice(0, 8)}.zip`, 'Checksum SHA-256 confirmed.']);
          return prev;
        }
        return { ...prev, [orderId]: current + 20 };
      });
    }, 400);
  };

  const productOrders = orders.filter((o) => o.type === 'product');
  const serviceOrders = orders.filter((o) => o.type === 'service');

  return (
    <section className="bg-neutral-950 text-white min-h-screen py-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Banner */}
        <div className="border-b border-neutral-900 pb-6 mb-8">
          <h2 className="text-2xl font-bold font-sans tracking-tight uppercase">
            Client Trading & Download Desk
          </h2>
          <p className="text-neutral-500 text-xs font-mono uppercase mt-1">
            Manage your digital assets, expert projects, licenses, and legal invoices.
          </p>
        </div>

        {/* Tab selection */}
        <div className="grid grid-cols-3 md:grid-cols-6 gap-2 mb-8 bg-neutral-900 p-1.5 border border-neutral-850 rounded-xl">
          <button
            onClick={() => setActiveTab('purchases')}
            className={`py-2 px-1 text-center rounded text-xs font-semibold uppercase tracking-wider transition-all ${
              activeTab === 'purchases' ? 'bg-blue-600 text-white shadow' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Downloads ({productOrders.length})
          </button>
          <button
            onClick={() => setActiveTab('projects')}
            className={`py-2 px-1 text-center rounded text-xs font-semibold uppercase tracking-wider transition-all ${
              activeTab === 'projects' ? 'bg-blue-600 text-white shadow' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Hired Experts ({serviceOrders.length})
          </button>
          <button
            onClick={() => setActiveTab('invoices')}
            className={`py-2 px-1 text-center rounded text-xs font-semibold uppercase tracking-wider transition-all ${
              activeTab === 'invoices' ? 'bg-blue-600 text-white shadow' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Tax Invoices
          </button>
          <button
            onClick={() => setActiveTab('saved')}
            className={`py-2 px-1 text-center rounded text-xs font-semibold uppercase tracking-wider transition-all ${
              activeTab === 'saved' ? 'bg-blue-600 text-white shadow' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Saved ({savedItems.length})
          </button>
          <button
            onClick={() => setActiveTab('messages')}
            className={`py-2 px-1 text-center rounded text-xs font-semibold uppercase tracking-wider transition-all ${
              activeTab === 'messages' ? 'bg-blue-600 text-white shadow' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Messages
          </button>
          <button
            onClick={() => setActiveTab('support')}
            className={`py-2 px-1 text-center rounded text-xs font-semibold uppercase tracking-wider transition-all ${
              activeTab === 'support' ? 'bg-blue-600 text-white shadow' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Support Tickets
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Main Workspace Column */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* Tab: Digital Downloads & Licenses */}
            {activeTab === 'purchases' && (
              <div className="space-y-4">
                {productOrders.length === 0 ? (
                  <div className="text-center py-16 bg-neutral-950 border border-neutral-900 rounded-xl">
                    <Download className="w-8 h-8 text-neutral-600 mx-auto mb-2" />
                    <p className="text-sm font-semibold">No digital purchases listed in your portfolio yet.</p>
                    <p className="text-xs text-neutral-500 mt-1">Acquire digital assets from the Spot Market to generate secure licenses.</p>
                  </div>
                ) : (
                  productOrders.map((ord) => (
                    <div
                      key={ord.id}
                      className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 hover:border-neutral-800 transition-all flex flex-col md:flex-row md:items-center justify-between gap-6"
                    >
                      <div className="flex items-start gap-4 flex-1 min-w-0">
                        <div className="w-16 h-16 rounded overflow-hidden bg-neutral-900 border border-neutral-800 shrink-0">
                          <img src={ord.itemImage} alt={ord.itemTitle} className="w-full h-full object-cover" />
                        </div>
                        <div className="min-w-0">
                          <span className="text-[9px] font-mono text-neutral-500 uppercase">
                            PURCHASED ON {ord.purchaseDate}
                          </span>
                          <h4 className="text-sm font-bold text-white truncate mt-0.5">{ord.itemTitle}</h4>
                          <p className="text-[10px] font-mono text-blue-400 truncate mt-1">
                            License: {ord.licenseKey}
                          </p>
                        </div>
                      </div>

                      {/* Download interaction */}
                      <div className="flex flex-col md:items-end gap-3 shrink-0">
                        <span className="font-mono text-xs text-white font-bold">${ord.price}</span>
                        {downloadProgress[ord.id] === undefined ? (
                          <button
                            onClick={() => triggerSecureDownload(ord.id, ord.itemTitle)}
                            className="bg-blue-600 hover:bg-blue-500 text-white text-xs px-4 py-1.5 rounded font-semibold tracking-wide flex items-center justify-center gap-1.5"
                          >
                            <Download className="w-3.5 h-3.5" /> Request Secure DL
                          </button>
                        ) : (
                          <div className="w-40 bg-neutral-900 rounded-full h-1.5 overflow-hidden">
                            <div
                              className="bg-blue-500 h-1.5 rounded-full transition-all duration-300"
                              style={{ width: `${downloadProgress[ord.id]}%` }}
                            ></div>
                            {downloadProgress[ord.id] >= 100 && (
                              <span className="text-[9px] font-mono text-emerald-400 block mt-1 text-right">
                                ARCHIVE READY
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Tab: Hired Experts & Projects */}
            {activeTab === 'projects' && (
              <div className="space-y-6">
                {serviceOrders.length === 0 ? (
                  <div className="text-center py-16 bg-neutral-950 border border-neutral-900 rounded-xl">
                    <CheckCircle className="w-8 h-8 text-neutral-600 mx-auto mb-2" />
                    <p className="text-sm font-semibold">No active consultant contracts found.</p>
                    <p className="text-xs text-neutral-500 mt-1">Hire developers, designers, or quant specialists through our Hiring Portal.</p>
                  </div>
                ) : (
                  serviceOrders.map((ord) => {
                    const completedCount = ord.milestones?.filter((m) => m.status === 'completed').length || 0;
                    const totalMilestones = ord.milestones?.length || 1;
                    const progressPercentage = Math.round((completedCount / totalMilestones) * 100);

                    return (
                      <div key={ord.id} className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4">
                        <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-neutral-900 pb-3 gap-3">
                          <div>
                            <span className="text-[9px] font-mono text-neutral-500 uppercase">ACTIVE CONTRACT</span>
                            <h4 className="text-sm font-bold text-white mt-0.5">{ord.itemTitle}</h4>
                            <p className="text-[10px] text-neutral-400 font-mono">
                              Total Budget: <span className="text-white font-bold">${ord.price}</span> (held in Escrow)
                            </p>
                          </div>
                          <span className="bg-blue-950 text-blue-400 border border-blue-900/30 text-[10px] font-mono px-3 py-1 rounded">
                            PROGRESS: {progressPercentage}%
                          </span>
                        </div>

                        {/* Milestones list with Approve triggers */}
                        <div className="space-y-3">
                          <p className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider font-mono">Milestone Payments Breakdown:</p>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {ord.milestones?.map((mil) => (
                              <div
                                key={mil.id}
                                className="bg-neutral-900 p-3.5 rounded-lg border border-neutral-850 flex items-start justify-between gap-4"
                              >
                                <div>
                                  <h5 className="text-xs font-semibold text-white leading-tight truncate">{mil.title}</h5>
                                  <p className="text-[10px] font-mono text-neutral-400 mt-1">Escrow Allocation: ${mil.amount}</p>
                                  <p className="text-[9px] text-neutral-500 font-mono mt-0.5">Due date: {mil.dueDate}</p>
                                </div>

                                <div className="shrink-0">
                                  {mil.status === 'completed' ? (
                                    <span className="bg-emerald-950 text-emerald-400 text-[10px] font-mono px-2 py-0.5 rounded border border-emerald-500/20 flex items-center gap-1">
                                      <CheckCircle className="w-3.5 h-3.5" /> Released
                                    </span>
                                  ) : (
                                    <button
                                      onClick={() => approveProjectMilestone(ord.id, mil.id)}
                                      className="bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-semibold px-2.5 py-1 rounded tracking-wide transition-all uppercase"
                                    >
                                      Verify & Pay
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            )}

            {/* Tab: Tax Invoices */}
            {activeTab === 'invoices' && (
              <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-6 space-y-4">
                <p className="text-xs font-mono uppercase text-neutral-500">Corporate Procurement Receipts Ledger</p>
                <div className="overflow-x-auto scrollbar-none">
                  <table className="w-full text-left font-sans border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-neutral-900 text-neutral-500 font-mono text-[10px] uppercase">
                        <th className="pb-3">Invoice Id</th>
                        <th className="pb-3">Purchase Date</th>
                        <th className="pb-3">Digital Asset</th>
                        <th className="pb-3 text-right">Tax ID</th>
                        <th className="pb-3 text-right">Total Invoice</th>
                        <th className="pb-3 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-900">
                      {invoices.map((inv) => (
                        <tr key={inv.id} className="hover:bg-neutral-900/50">
                          <td className="py-3 font-mono text-neutral-400">{inv.id}</td>
                          <td className="py-3 text-neutral-400">{inv.purchaseDate}</td>
                          <td className="py-3 text-white font-semibold">{inv.itemName}</td>
                          <td className="py-3 text-right font-mono text-neutral-500">NY-89102-S</td>
                          <td className="py-3 text-right font-mono text-white font-bold">${inv.total}</td>
                          <td className="py-3 text-right">
                            <span className="bg-emerald-950 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded text-[10px] font-mono">
                              {inv.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Tab: Saved Favorites */}
            {activeTab === 'saved' && (
              <div className="space-y-4">
                {savedItems.length === 0 ? (
                  <div className="text-center py-16 bg-neutral-950 border border-neutral-900 rounded-xl">
                    <Heart className="w-8 h-8 text-neutral-600 mx-auto mb-2" />
                    <p className="text-sm font-semibold">Saved list is clear.</p>
                    <p className="text-xs text-neutral-500 mt-1">Bookmark high priority assets inside GDX core to reference here.</p>
                  </div>
                ) : (
                  savedItems.map((item) => (
                    <div
                      key={item.id}
                      className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 hover:border-neutral-800 transition-all flex items-center justify-between gap-4"
                    >
                      <div className="flex items-center gap-4 min-w-0">
                        <div className="w-12 h-12 rounded overflow-hidden bg-neutral-900 border border-neutral-800 shrink-0">
                          <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-xs font-bold text-white truncate">{item.title}</h4>
                          <span className="text-[10px] font-mono text-neutral-500 uppercase">{item.type}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 shrink-0 font-mono text-xs">
                        <span className="text-white font-bold">${item.price}</span>
                        <button
                          onClick={() => removeSavedItem(item.id)}
                          className="p-1.5 rounded border border-neutral-800 hover:bg-neutral-900 text-neutral-500 hover:text-red-400 transition-all"
                        >
                          <Trash className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Tab: Messages Inbox */}
            {activeTab === 'messages' && (
              <div className="bg-neutral-950 border border-neutral-900 rounded-xl overflow-hidden flex flex-col h-112 shadow-lg">
                <div className="bg-neutral-900 p-4 border-b border-neutral-850 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-white uppercase font-mono">Secured Channel</h4>
                    <p className="text-[10px] text-neutral-500">Direct encrypted thread with GDX Participants</p>
                  </div>
                  <span className="bg-emerald-950 text-emerald-400 text-[10px] font-mono border border-emerald-500/30 px-2 py-0.5 rounded">
                    Sovereign Channel Active
                  </span>
                </div>

                {/* Messages scroll */}
                <div className="flex-1 p-4 overflow-y-auto space-y-4">
                  {chatMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex flex-col max-w-sm ${msg.sender === 'You' ? 'ml-auto items-end' : 'mr-auto items-start'}`}
                    >
                      <span className="text-[10px] font-mono text-neutral-500 mb-1">{msg.sender} • {msg.time}</span>
                      <div
                        className={`p-3 rounded-lg text-xs leading-relaxed ${
                          msg.sender === 'You' ? 'bg-blue-600 text-white rounded-tr-none' : 'bg-neutral-900 text-neutral-300 rounded-tl-none'
                        }`}
                      >
                        {msg.text}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Chat input form */}
                <form onSubmit={handleSendMessage} className="p-3 border-t border-neutral-900 bg-neutral-950 flex gap-2">
                  <input
                    type="text"
                    required
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Provide additional scope criteria..."
                    className="flex-1 bg-neutral-900 border border-neutral-800 rounded px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 font-sans"
                  />
                  <button
                    type="submit"
                    className="p-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded transition-colors shrink-0"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </div>
            )}

            {/* Tab: Support tickets desk */}
            {activeTab === 'support' && (
              <div className="space-y-6">
                
                {/* Submit ticket form */}
                <form onSubmit={handleTicketSubmit} className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold text-white uppercase font-mono tracking-widest border-b border-neutral-900 pb-2">
                    Submit New SLA Support Case
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-mono text-neutral-400 block mb-1">Issue Category</label>
                      <select
                        value={ticketCategory}
                        onChange={(e) => setTicketCategory(e.target.value)}
                        className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500"
                      >
                        <option>Technical Support</option>
                        <option>API / Development</option>
                        <option>Billing & Invoices</option>
                        <option>License Reset Request</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] font-mono text-neutral-400 block mb-1">Brief Description</label>
                      <input
                        type="text"
                        required
                        value={ticketSubject}
                        onChange={(e) => setTicketSubject(e.target.value)}
                        placeholder="Specify environment and file error logs..."
                        className="w-full bg-neutral-900 border border-neutral-800 text-xs rounded p-2 text-white focus:outline-none focus:border-blue-500 font-sans"
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold tracking-wide"
                  >
                    Initiate Ticket
                  </button>
                </form>

                {/* Tickets list */}
                <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold text-white uppercase font-mono tracking-widest border-b border-neutral-900 pb-2">
                    Active Support Log
                  </h4>
                  {tickets.map((t) => (
                    <div key={t.id} className="flex justify-between items-center border-b border-neutral-900 pb-3 last:border-0 last:pb-0 text-xs">
                      <div>
                        <span className="text-[9px] font-mono text-neutral-500 uppercase">{t.id} • {t.category}</span>
                        <h5 className="font-semibold text-white mt-0.5">{t.subject}</h5>
                        <p className="text-[10px] text-neutral-500 font-mono mt-0.5">Submitted: {t.date}</p>
                      </div>
                      <span className={`px-2.5 py-0.5 rounded text-[10px] font-mono border ${
                        t.status === 'Resolved' ? 'bg-emerald-950 text-emerald-400 border-emerald-500/20' : 'bg-amber-950 text-amber-400 border-amber-500/20'
                      }`}>
                        {t.status}
                      </span>
                    </div>
                  ))}
                </div>

              </div>
            )}

          </div>

          {/* Right Download Log Terminal Panel */}
          <div className="lg:col-span-1 space-y-6">
            
            {/* DRM Download terminal logger */}
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-4 space-y-3.5 shadow-lg">
              <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest block">GDX DRM EXCLUSIVE CHANNEL</span>
              <p className="text-[11px] text-neutral-400">
                Live cryptographic hand-off ledger. Trigger a secure download on the left to verify active license keys.
              </p>

              <div className="bg-neutral-950 rounded border border-neutral-850 p-3 font-mono text-[10px] text-emerald-400 h-56 overflow-y-auto space-y-1 text-left select-none">
                {downloadLog.map((log, idx) => (
                  <div key={idx} className="leading-tight">
                    <span className="text-neutral-700">[{idx}]</span> {log}
                  </div>
                ))}
              </div>
            </div>

            {/* Quick stats panel */}
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-3 font-sans">
              <h5 className="text-xs font-bold text-white uppercase font-mono">Secured Legal Terms</h5>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                All software assets and digital documents purchased via Gotham Digital Exchange are covered under the **GDX Standard Corporate commercial license**. Reverse-engineering is legally prohibited.
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
