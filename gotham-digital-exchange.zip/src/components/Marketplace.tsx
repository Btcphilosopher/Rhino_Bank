/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Search, Filter, ArrowUpDown, Star, Download, ShieldCheck, ShoppingCart, Eye, User, Sparkles, Clock, MapPin, Code, Tag, ChevronRight } from 'lucide-react';
import { Product, Service, CartItem } from '../types';
import { mockProducts, mockServices } from '../mockData';

interface MarketplaceProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  addToCart: (item: CartItem) => void;
  cart: CartItem[];
  viewProduct: (product: Product) => void;
  viewService: (service: Service) => void;
}

export default function Marketplace({
  searchQuery,
  setSearchQuery,
  addToCart,
  cart,
  viewProduct,
  viewService,
}: MarketplaceProps) {
  // Toggle between Spot Products and Consulting Services
  const [marketType, setMarketType] = useState<'products' | 'services'>('products');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [sortBy, setSortBy] = useState<string>('popular');
  const [priceRange, setPriceRange] = useState<number>(600);
  const [ratingFilter, setRatingFilter] = useState<number>(0);
  const [enterpriseOnly, setEnterpriseOnly] = useState<boolean>(false);
  const [selectedLanguage, setSelectedLanguage] = useState<string>('All');

  // Unified Categories based on mock data
  const productCategories = ['All', 'Software', 'UI Kits', 'APIs', 'Cybersecurity', 'Fonts', 'Research'];
  const serviceCategories = ['All', 'Cloud Services', 'Finance', 'UI Kits'];

  const categories = marketType === 'products' ? productCategories : serviceCategories;

  // Language/Compatibility lists
  const languages = ['All', 'React', 'Rust', 'TypeScript', 'Solidity', 'C++', 'Python', 'Next.js', 'Figma'];

  // Handle Cart Status
  const isItemInCart = (id: string) => cart.some((item) => item.id === id);

  // Filter and Sort Logic for Products
  const filteredProducts = useMemo(() => {
    return mockProducts
      .filter((p) => {
        const matchesSearch =
          p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
        
        const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
        const matchesPrice = p.price <= priceRange;
        const matchesRating = p.rating >= ratingFilter;
        const matchesEnterprise = !enterpriseOnly || p.enterpriseReady;
        
        const matchesLanguage =
          selectedLanguage === 'All' ||
          p.compatibility.some((c) => c.toLowerCase().includes(selectedLanguage.toLowerCase())) ||
          p.tags.some((t) => t.toLowerCase().includes(selectedLanguage.toLowerCase()));

        return matchesSearch && matchesCategory && matchesPrice && matchesRating && matchesEnterprise && matchesLanguage;
      })
      .sort((a, b) => {
        if (sortBy === 'popular') return b.downloadsCount - a.downloadsCount;
        if (sortBy === 'price-asc') return a.price - b.price;
        if (sortBy === 'price-desc') return b.price - a.price;
        if (sortBy === 'rating') return b.rating - a.rating;
        return 0;
      });
  }, [searchQuery, selectedCategory, priceRange, ratingFilter, enterpriseOnly, selectedLanguage, sortBy]);

  // Filter and Sort Logic for Services
  const filteredServices = useMemo(() => {
    return mockServices
      .filter((s) => {
        const matchesSearch =
          s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.category.toLowerCase().includes(searchQuery.toLowerCase());

        const matchesCategory = selectedCategory === 'All' || s.category === selectedCategory;
        const matchesPrice = s.startingPrice <= priceRange;
        const matchesRating = s.rating >= ratingFilter;
        
        const matchesLanguage =
          selectedLanguage === 'All' ||
          s.title.toLowerCase().includes(selectedLanguage.toLowerCase()) ||
          s.description.toLowerCase().includes(selectedLanguage.toLowerCase());

        return matchesSearch && matchesCategory && matchesPrice && matchesRating && matchesLanguage;
      })
      .sort((a, b) => {
        if (sortBy === 'popular') return b.reviewsCount - a.reviewsCount;
        if (sortBy === 'price-asc') return a.startingPrice - b.startingPrice;
        if (sortBy === 'price-desc') return b.startingPrice - a.startingPrice;
        if (sortBy === 'rating') return b.rating - a.rating;
        return 0;
      });
  }, [searchQuery, selectedCategory, priceRange, ratingFilter, selectedLanguage, sortBy]);

  const handleResetFilters = () => {
    setSelectedCategory('All');
    setPriceRange(600);
    setRatingFilter(0);
    setEnterpriseOnly(false);
    setSelectedLanguage('All');
    setSearchQuery('');
  };

  return (
    <section className="bg-neutral-950 text-white min-h-screen py-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* 1. Header & Spot/Consulting Switcher */}
        <div className="border-b border-neutral-900 pb-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold font-sans tracking-tight text-white uppercase">
              Gotham Digital Index Exchange
            </h2>
            <p className="text-neutral-500 text-xs font-mono uppercase mt-1">
              Select Spot Digital Assets or Hired Experts
            </p>
          </div>

          <div className="flex bg-neutral-900 p-1 rounded-lg border border-neutral-800">
            <button
              onClick={() => {
                setMarketType('products');
                setSelectedCategory('All');
              }}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                marketType === 'products'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Download className="w-3.5 h-3.5" /> Spot Assets
            </button>
            <button
              onClick={() => {
                setMarketType('services');
                setSelectedCategory('All');
              }}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                marketType === 'services'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <User className="w-3.5 h-3.5" /> Expert Consulting
            </button>
          </div>
        </div>

        {/* 2. Unified Category Fast Filter Pills */}
        <div className="flex items-center space-x-2 overflow-x-auto scrollbar-none pb-4 mb-6">
          <span className="text-[10px] font-mono uppercase tracking-wider text-neutral-500 mr-2">Categories:</span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-full text-xs font-medium border whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-white text-neutral-950 border-white font-semibold'
                  : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* 3. Primary Grid: Sidebar Filters + Main Product Results */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* A. Left Sidebar Filter Panel */}
          <div className="lg:col-span-1 bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-6 self-start">
            <div className="flex justify-between items-center border-b border-neutral-900 pb-3">
              <h3 className="text-xs font-bold uppercase tracking-widest font-mono text-neutral-400 flex items-center gap-2">
                <Filter className="w-3.5 h-3.5 text-blue-500" /> Filter Desk
              </h3>
              <button
                onClick={handleResetFilters}
                className="text-[10px] font-mono text-neutral-500 hover:text-white hover:underline uppercase"
              >
                Reset All
              </button>
            </div>

            {/* Filter: Price Range */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-mono text-neutral-400">
                <span>Max Budget / Price</span>
                <span className="text-white font-bold">${priceRange}</span>
              </div>
              <input
                type="range"
                min="50"
                max="1000"
                step="25"
                value={priceRange}
                onChange={(e) => setPriceRange(Number(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
              <div className="flex justify-between text-[10px] font-mono text-neutral-600">
                <span>$50</span>
                <span>$1000+</span>
              </div>
            </div>

            {/* Filter: Software Compatibility / Languages */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest font-mono text-neutral-500 block">
                Framework / Technology
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {languages.map((lang) => (
                  <button
                    key={lang}
                    onClick={() => setSelectedLanguage(lang)}
                    className={`px-2 py-1 text-left rounded text-xs truncate transition-all ${
                      selectedLanguage === lang
                        ? 'bg-blue-600 text-white font-semibold'
                        : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {lang}
                  </button>
                ))}
              </div>
            </div>

            {/* Filter: Minimum Rating */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest font-mono text-neutral-500 block">
                Minimum Rating
              </label>
              <div className="flex items-center space-x-2">
                {[0, 4, 4.5, 4.9].map((rating) => (
                  <button
                    key={rating}
                    onClick={() => setRatingFilter(rating)}
                    className={`flex-1 py-1 rounded border text-center text-xs font-mono transition-all ${
                      ratingFilter === rating
                        ? 'bg-white text-neutral-950 border-white font-semibold'
                        : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {rating === 0 ? 'Any' : `${rating}★`}
                  </button>
                ))}
              </div>
            </div>

            {/* Filter: Enterprise Only Spot Toggles (only applicable to spot assets) */}
            {marketType === 'products' && (
              <div className="pt-3 border-t border-neutral-900 flex items-center justify-between">
                <div>
                  <span className="text-xs text-neutral-300 font-semibold block">Enterprise-Ready Only</span>
                  <span className="text-[9px] font-mono text-neutral-500 uppercase block">Bulk licenses & SOC2 compliant</span>
                </div>
                <input
                  type="checkbox"
                  checked={enterpriseOnly}
                  onChange={(e) => setEnterpriseOnly(e.target.checked)}
                  className="w-4 h-4 rounded bg-neutral-900 border-neutral-800 text-blue-600 focus:ring-blue-500 focus:ring-offset-neutral-950"
                />
              </div>
            )}
          </div>

          {/* B. Right Main Contents Panel */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* Sort & Stats Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border border-neutral-900 bg-neutral-950 p-4 rounded-xl gap-4">
              <span className="text-xs font-mono text-neutral-400 uppercase">
                Showing{' '}
                <span className="text-white font-bold">
                  {marketType === 'products' ? filteredProducts.length : filteredServices.length}
                </span>{' '}
                {marketType === 'products' ? 'digital products' : 'consulting services'} matches
              </span>

              <div className="flex items-center space-x-3 text-xs">
                <span className="text-neutral-500 font-mono flex items-center gap-1">
                  <ArrowUpDown className="w-3.5 h-3.5" /> Sort Order:
                </span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="bg-neutral-900 border border-neutral-800 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="popular">Most Popular</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="price-desc">Price: High to Low</option>
                  <option value="rating">Top Rated</option>
                </select>
              </div>
            </div>

            {/* No items fallback */}
            {marketType === 'products' && filteredProducts.length === 0 && (
              <div className="text-center py-16 border border-neutral-900 bg-neutral-950 rounded-xl">
                <Sparkles className="w-8 h-8 text-neutral-600 mx-auto mb-2" />
                <p className="text-sm font-semibold text-white">No spot assets matched your constraints.</p>
                <p className="text-xs text-neutral-500 mt-1">Try relaxing filters or adjusting search queries.</p>
                <button
                  onClick={handleResetFilters}
                  className="mt-4 px-4 py-1.5 bg-blue-600 hover:bg-blue-500 rounded text-xs font-semibold"
                >
                  Reset Filtering Desk
                </button>
              </div>
            )}

            {marketType === 'services' && filteredServices.length === 0 && (
              <div className="text-center py-16 border border-neutral-900 bg-neutral-950 rounded-xl">
                <Sparkles className="w-8 h-8 text-neutral-600 mx-auto mb-2" />
                <p className="text-sm font-semibold text-white">No consulting agencies matched your constraints.</p>
                <p className="text-xs text-neutral-500 mt-1">Try relaxing filters or adjusting search queries.</p>
                <button
                  onClick={handleResetFilters}
                  className="mt-4 px-4 py-1.5 bg-blue-600 hover:bg-blue-500 rounded text-xs font-semibold"
                >
                  Reset Filtering Desk
                </button>
              </div>
            )}

            {/* Main Listings Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Product render list */}
              {marketType === 'products' &&
                filteredProducts.map((prod) => (
                  <div
                    key={prod.id}
                    className="bg-neutral-950 border border-neutral-900 rounded-xl overflow-hidden hover:border-neutral-800 transition-all flex flex-col group shadow-md"
                  >
                    {/* Cover image */}
                    <div className="relative h-44 overflow-hidden bg-neutral-900">
                      <img
                        src={prod.image}
                        alt={prod.title}
                        className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <span className="absolute top-3 left-3 bg-neutral-950/80 backdrop-blur-md px-2 py-0.5 rounded text-[10px] font-mono text-neutral-300 border border-neutral-800">
                        {prod.category}
                      </span>
                      {prod.enterpriseReady && (
                        <span className="absolute top-3 right-3 bg-blue-900/80 backdrop-blur-md px-2.5 py-0.5 rounded text-[9px] font-mono font-bold text-blue-300 border border-blue-500/30 flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3" /> SOC2 Compliant
                        </span>
                      )}
                    </div>

                    {/* Body */}
                    <div className="p-4 flex-1 flex flex-col space-y-3 font-sans">
                      <div className="flex justify-between items-start gap-2">
                        <h4 className="text-sm font-semibold text-white group-hover:text-blue-400 transition-colors line-clamp-1">
                          {prod.title}
                        </h4>
                        <span className="font-mono text-sm font-bold text-white shrink-0">${prod.price}</span>
                      </div>

                      <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed flex-1">
                        {prod.description}
                      </p>

                      {/* Details block */}
                      <div className="flex items-center justify-between text-[11px] text-neutral-500 border-t border-b border-neutral-900 py-2">
                        <div className="flex items-center space-x-1.5">
                          <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                          <span className="text-white font-bold">{prod.rating}</span>
                          <span className="text-neutral-600">({prod.reviewsCount})</span>
                        </div>
                        <div className="flex items-center space-x-1 font-mono">
                          <Download className="w-3 h-3 text-neutral-600" />
                          <span>{prod.downloadsCount} DLs</span>
                        </div>
                        <div className="text-[10px] font-mono bg-neutral-900 px-1.5 py-0.5 rounded text-neutral-400 border border-neutral-800">
                          {prod.version}
                        </div>
                      </div>

                      {/* Compatibility Chips */}
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {prod.compatibility.slice(0, 3).map((comp) => (
                          <span key={comp} className="text-[10px] bg-neutral-900 text-neutral-400 font-mono px-2 py-0.5 rounded border border-neutral-800">
                            {comp}
                          </span>
                        ))}
                        {prod.compatibility.length > 3 && (
                          <span className="text-[10px] text-neutral-500 font-mono px-1 py-0.5">
                            +{prod.compatibility.length - 3} more
                          </span>
                        )}
                      </div>

                      {/* Action Triggers */}
                      <div className="flex gap-2 pt-2">
                        <button
                          onClick={() => viewProduct(prod)}
                          className="flex-1 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-200 py-1.5 rounded text-xs font-semibold transition-all flex items-center justify-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5" /> Inspect Product
                        </button>
                        <button
                          onClick={() => addToCart({ id: prod.id, title: prod.title, price: prod.price, image: prod.image, type: 'product' })}
                          disabled={isItemInCart(prod.id)}
                          className={`px-3 py-1.5 rounded text-xs font-semibold transition-all ${
                            isItemInCart(prod.id)
                              ? 'bg-neutral-800 text-neutral-500 border border-neutral-800 cursor-not-allowed'
                              : 'bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center gap-1 shadow-md shadow-blue-900/10'
                          }`}
                        >
                          <ShoppingCart className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

              {/* Service render list */}
              {marketType === 'services' &&
                filteredServices.map((srv) => (
                  <div
                    key={srv.id}
                    className="bg-neutral-950 border border-neutral-900 rounded-xl overflow-hidden hover:border-neutral-800 transition-all flex flex-col group shadow-md"
                  >
                    {/* Header */}
                    <div className="p-4 border-b border-neutral-900 flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full overflow-hidden bg-neutral-800 border border-neutral-800 shrink-0">
                        <img src={srv.creatorAvatar} alt={srv.creatorName} className="w-full h-full object-cover" />
                      </div>
                      <div className="min-w-0">
                        <h5 className="text-xs text-neutral-400 font-semibold truncate uppercase tracking-wider">
                          {srv.creatorName}
                        </h5>
                        <p className="text-[10px] text-neutral-500 font-mono flex items-center gap-1 mt-0.5">
                          <Clock className="w-3 h-3 text-blue-500" /> Response: {srv.responseTime}
                        </p>
                      </div>
                      <span className="ml-auto bg-emerald-950 text-emerald-400 text-[9px] font-mono border border-emerald-500/30 px-2 py-0.5 rounded">
                        Active
                      </span>
                    </div>

                    {/* Cover/Card body */}
                    <div className="p-4 flex-1 flex flex-col space-y-3 font-sans">
                      <h4 className="text-sm font-semibold text-white group-hover:text-blue-400 transition-colors line-clamp-1">
                        {srv.title}
                      </h4>

                      <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed flex-1">
                        {srv.description}
                      </p>

                      {/* Pricing matrix brief */}
                      <div className="bg-neutral-900/50 rounded-lg p-3 border border-neutral-900 space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] font-mono text-neutral-500 uppercase">Consulting Tariff</span>
                          <span className="text-xs text-white font-mono font-bold">${srv.hourlyRate}/hr</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] font-mono text-neutral-500 uppercase">Starting Workpackage</span>
                          <span className="text-sm text-blue-400 font-mono font-bold">${srv.startingPrice}</span>
                        </div>
                      </div>

                      {/* Ratings and Category */}
                      <div className="flex justify-between items-center text-[11px] text-neutral-500 border-t border-neutral-900 pt-3">
                        <div className="flex items-center space-x-1.5">
                          <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                          <span className="text-white font-bold">{srv.rating}</span>
                          <span className="text-neutral-600">({srv.reviewsCount})</span>
                        </div>
                        <span className="text-[10px] font-mono uppercase bg-neutral-900 text-neutral-400 border border-neutral-800 px-2 py-0.5 rounded">
                          {srv.category}
                        </span>
                      </div>

                      {/* Service features bullet highlight */}
                      <div className="space-y-1 pt-1">
                        <p className="text-[10px] font-mono uppercase text-neutral-600">Standard deliverables:</p>
                        {srv.packages.standard.features.slice(0, 2).map((feat, idx) => (
                          <div key={idx} className="flex items-start gap-1.5 text-[10px] text-neutral-400">
                            <span className="text-blue-500 font-semibold">•</span>
                            <span className="truncate">{feat}</span>
                          </div>
                        ))}
                      </div>

                      {/* Inspection / Booking Action */}
                      <button
                        onClick={() => viewService(srv)}
                        className="w-full bg-blue-600 hover:bg-blue-500 text-white py-1.5 rounded text-xs font-semibold transition-all flex items-center justify-center gap-1.5 shadow-md shadow-blue-900/10 mt-2"
                      >
                        Inspect Packages & Hire <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
