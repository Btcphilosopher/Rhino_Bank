/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ArrowLeft, Star, Download, ShieldCheck, ShoppingCart, Terminal, Calendar, Code, CheckCircle, Tag, MessageSquare, Plus, FileText, Globe } from 'lucide-react';
import { Product, CartItem, Review } from '../types';
import { mockReviews, mockProducts } from '../mockData';

interface ProductPageProps {
  product: Product;
  goBack: () => void;
  addToCart: (item: CartItem) => void;
  cart: CartItem[];
}

export default function ProductPage({ product, goBack, addToCart, cart }: ProductPageProps) {
  const [activeTab, setActiveTab] = useState<'details' | 'sandbox' | 'changelog' | 'faqs'>('details');
  const [licenseOption, setLicenseOption] = useState<'standard' | 'enterprise'>('standard');
  const [localReviews, setLocalReviews] = useState<Review[]>(
    mockReviews.filter((r) => r.itemId === product.id)
  );

  // Live Sandbox Simulation states
  const [terminalOutput, setTerminalOutput] = useState<string[]>(['GDX Core Console initialized.', 'Ready to execute. Press "Run Sandbox Module" below.']);
  const [isRunningSandbox, setIsRunningSandbox] = useState(false);
  const [sandboxInputs, setSandboxInputs] = useState({
    strike: '105.00',
    underlying: '103.50',
    expiry: '45',
    vol: '0.28',
    rate: '0.0525',
    dbSeeding: 'users, organizations, payments_ledger',
  });

  // Review Form states
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' });

  const isItemInCart = cart.some((item) => item.id === product.id);

  const getPrice = () => {
    return licenseOption === 'enterprise' ? Math.round(product.price * 2.5) : product.price;
  };

  const handleAddCart = () => {
    addToCart({
      id: product.id,
      title: product.title,
      price: getPrice(),
      image: product.image,
      type: 'product',
      selectedPackage: licenseOption === 'enterprise' ? 'Enterprise License' : 'Commercial Standard',
    });
  };

  // Run the sandbox simulation for the product
  const executeSandbox = () => {
    setIsRunningSandbox(true);
    setTerminalOutput((prev) => [...prev, '>> Executing sandbox process...', 'Linking secure dependencies...', 'Initiating thread pool...']);

    setTimeout(() => {
      if (product.id === 'prod-3') {
        // Options Greeks calculator simulator
        const s = parseFloat(sandboxInputs.underlying);
        const k = parseFloat(sandboxInputs.strike);
        const t = parseFloat(sandboxInputs.expiry) / 365;
        const v = parseFloat(sandboxInputs.vol);
        const r = parseFloat(sandboxInputs.rate);

        // Simple BS approximation for delta/gamma
        const d1 = (Math.log(s / k) + (r + (v * v) / 2) * t) / (v * Math.sqrt(t));
        const deltaCall = 0.5 + 0.5 * Math.tanh(0.7 * d1); // simple sigmoid approximation
        const deltaPut = deltaCall - 1;
        const gamma = Math.exp(-0.5 * d1 * d1) / (s * v * Math.sqrt(2 * Math.PI * t));

        setTerminalOutput([
          'GOTHAM OPTIONS CALCULATOR v3.12 (EST)',
          `>> Inputs: Underlying=${s}, Strike=${k}, Volatility=${(v * 100).toFixed(1)}%, Expiry=${sandboxInputs.expiry} days`,
          '>> Formulating Black-Scholes equations...',
          '========================================',
          `CALL DELTA : ${deltaCall.toFixed(4)}  (Long skew protection)`,
          `PUT DELTA  : ${deltaPut.toFixed(4)}   (Short hedge protective)`,
          `GAMMA      : ${gamma.toFixed(6)}`,
          'IMPLIED VOL: 28.14% (Local splines coverage)',
          '========================================',
          'Calculation vector completed in 2.1 microseconds.',
          'SUCCESS.'
        ]);
      } else if (product.id === 'prod-1') {
        // SaaS boilerplate simulator
        setTerminalOutput([
          'Nouveau-SaaS Startup Core Boot Sequence',
          '>> Mounting client React 19 router...',
          '>> Linking Axum 0.7 server threads (TCP Host 0.0.0.0:3000)...',
          '>> Connecting to local PostgreSQL cluster...',
          `>> Running schema seeding for: [${sandboxInputs.dbSeeding}]`,
          '========================================',
          'TABLE SEED LOGS:',
          ' - Created table "users": 1,200 entities loaded.',
          ' - Created table "organizations": 50 seats provisioned.',
          ' - Created table "payments_ledger": Stripe webhooks verified.',
          '========================================',
          'SERVER STATUS: STANDBY (Ready to receive requests)',
          'SUCCESS.'
        ]);
      } else {
        // Generic asset simulation
        setTerminalOutput([
          `GOTHAM SANDBOX DEMO for: ${product.title}`,
          '>> Decompressing dynamic assets bundle...',
          '>> Reading manifest records...',
          '>> Checking rendering compatibility ratios...',
          '========================================',
          'RENDER METRICS:',
          ` - Resource Version: ${product.version}`,
          ` - Download size: ${product.downloadSize}`,
          ' - Compilation Check: Passed (0 warnings)',
          '========================================',
          'All assets checked successfully. Package standard is fully active.',
          'SUCCESS.'
        ]);
      }
      setIsRunningSandbox(false);
    }, 1500);
  };

  // Handle Review submission
  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.comment.trim()) return;

    const reviewObj: Review = {
      id: `rev-local-${Date.now()}`,
      itemId: product.id,
      authorName: 'Verified Gotham Client',
      authorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&h=100&q=80',
      rating: newReview.rating,
      comment: newReview.comment,
      date: new Date().toISOString().split('T')[0],
      verified: true,
    };

    setLocalReviews([reviewObj, ...localReviews]);
    setNewReview({ rating: 5, comment: '' });
  };

  // Find other products for "related products"
  const relatedProducts = mockProducts.filter((p) => p.id !== product.id).slice(0, 2);

  return (
    <section className="bg-neutral-950 text-white py-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Back Button */}
        <button
          onClick={goBack}
          className="flex items-center gap-2 text-xs font-mono text-neutral-400 hover:text-white mb-6 uppercase transition-colors"
        >
          <ArrowLeft className="w-4 h-4 text-blue-500" /> Back to Market Exchange
        </button>

        {/* Primary Page Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* A. Left side columns: Image, Tabs, and Reviews */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* Visual Header card */}
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl overflow-hidden shadow-lg">
              <div className="relative h-96 w-full bg-neutral-900">
                <img src={product.image} alt={product.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                <span className="absolute bottom-4 left-4 bg-neutral-950/80 backdrop-blur-md px-3 py-1 rounded text-xs font-mono text-blue-400 border border-neutral-800">
                  {product.category}
                </span>
              </div>
              <div className="p-6">
                <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight">{product.title}</h2>
                <div className="flex flex-wrap items-center gap-4 mt-3 text-xs text-neutral-400 font-mono">
                  <div className="flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                    <span className="text-white font-bold">{product.rating}</span>
                    <span>({product.reviewsCount} reviews)</span>
                  </div>
                  <span>•</span>
                  <span>Size: {product.downloadSize}</span>
                  <span>•</span>
                  <span>Ver: {product.version}</span>
                  <span>•</span>
                  <span>License: {product.licenseType}</span>
                </div>
              </div>
            </div>

            {/* Tab selection bar */}
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-1.5 flex gap-2 overflow-x-auto">
              <button
                onClick={() => setActiveTab('details')}
                className={`flex-1 py-2 px-3 text-xs font-semibold uppercase tracking-wider rounded-md text-center whitespace-nowrap transition-all ${
                  activeTab === 'details' ? 'bg-blue-600 text-white shadow' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Detailed Specs
              </button>
              <button
                onClick={() => setActiveTab('sandbox')}
                className={`flex-1 py-2 px-3 text-xs font-semibold uppercase tracking-wider rounded-md text-center whitespace-nowrap transition-all flex items-center justify-center gap-1.5 ${
                  activeTab === 'sandbox' ? 'bg-blue-600 text-white shadow' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Terminal className="w-3.5 h-3.5" /> Interactive Sandbox
              </button>
              <button
                onClick={() => setActiveTab('changelog')}
                className={`flex-1 py-2 px-3 text-xs font-semibold uppercase tracking-wider rounded-md text-center whitespace-nowrap transition-all ${
                  activeTab === 'changelog' ? 'bg-blue-600 text-white shadow' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Changelog ({product.changelog.length})
              </button>
              <button
                onClick={() => setActiveTab('faqs')}
                className={`flex-1 py-2 px-3 text-xs font-semibold uppercase tracking-wider rounded-md text-center whitespace-nowrap transition-all ${
                  activeTab === 'faqs' ? 'bg-blue-600 text-white shadow' : 'text-neutral-400 hover:text-white'
                }`}
              >
                FAQs
              </button>
            </div>

            {/* Tab Contents */}
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-6">
              
              {/* Tab: Details */}
              {activeTab === 'details' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-widest font-mono text-neutral-400 mb-2">
                      Functional Description
                    </h3>
                    <p className="text-sm text-neutral-300 leading-relaxed whitespace-pre-line">
                      {product.longDescription}
                    </p>
                  </div>

                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-widest font-mono text-neutral-400 mb-3">
                      Compatibility Matrix & Infrastructure Requirements
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {product.compatibility.map((item) => (
                        <span key={item} className="text-xs bg-neutral-900 text-neutral-300 px-3 py-1 rounded-md border border-neutral-800 font-mono">
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-widest font-mono text-neutral-400 mb-3">
                      Tags
                    </h3>
                    <div className="flex flex-wrap gap-1.5">
                      {product.tags.map((tag) => (
                        <span key={tag} className="text-[10px] bg-blue-950/40 text-blue-400 px-2 py-0.5 rounded border border-blue-900/30 font-mono">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Tab: Interactive Sandbox Simulator */}
              {activeTab === 'sandbox' && (
                <div className="space-y-6">
                  <div>
                    <h4 className="text-sm font-semibold text-white">Dynamic Asset Execution Simulation</h4>
                    <p className="text-xs text-neutral-500 mt-1 leading-relaxed">
                      Test compiling and executing this asset live from our sandboxed New York server block. Alter inputs below to dynamically recalculate output states in the microsecond ledger.
                    </p>
                  </div>

                  {/* Sandbox Parameter Inputs */}
                  {product.id === 'prod-3' && (
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-neutral-900 p-4 rounded-xl border border-neutral-800">
                      <div>
                        <label className="text-[10px] font-mono text-neutral-400 block mb-1 uppercase">Underlying Spot ($)</label>
                        <input
                          type="text"
                          value={sandboxInputs.underlying}
                          onChange={(e) => setSandboxInputs({ ...sandboxInputs, underlying: e.target.value })}
                          className="w-full bg-neutral-950 border border-neutral-800 text-xs font-mono rounded p-1.5 focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-mono text-neutral-400 block mb-1 uppercase">Strike Price ($)</label>
                        <input
                          type="text"
                          value={sandboxInputs.strike}
                          onChange={(e) => setSandboxInputs({ ...sandboxInputs, strike: e.target.value })}
                          className="w-full bg-neutral-950 border border-neutral-800 text-xs font-mono rounded p-1.5 focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-mono text-neutral-400 block mb-1 uppercase">Expiry (Days)</label>
                        <input
                          type="text"
                          value={sandboxInputs.expiry}
                          onChange={(e) => setSandboxInputs({ ...sandboxInputs, expiry: e.target.value })}
                          className="w-full bg-neutral-950 border border-neutral-800 text-xs font-mono rounded p-1.5 focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-mono text-neutral-400 block mb-1 uppercase">Implied Vol (Ratio)</label>
                        <input
                          type="text"
                          value={sandboxInputs.vol}
                          onChange={(e) => setSandboxInputs({ ...sandboxInputs, vol: e.target.value })}
                          className="w-full bg-neutral-950 border border-neutral-800 text-xs font-mono rounded p-1.5 focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-mono text-neutral-400 block mb-1 uppercase">Risk-Free Rate (Ratio)</label>
                        <input
                          type="text"
                          value={sandboxInputs.rate}
                          onChange={(e) => setSandboxInputs({ ...sandboxInputs, rate: e.target.value })}
                          className="w-full bg-neutral-950 border border-neutral-800 text-xs font-mono rounded p-1.5 focus:border-blue-500"
                        />
                      </div>
                    </div>
                  )}

                  {product.id === 'prod-1' && (
                    <div className="bg-neutral-900 p-4 rounded-xl border border-neutral-800 space-y-3">
                      <div>
                        <label className="text-[10px] font-mono text-neutral-400 block mb-1 uppercase">Database Tables To Seeding</label>
                        <input
                          type="text"
                          value={sandboxInputs.dbSeeding}
                          onChange={(e) => setSandboxInputs({ ...sandboxInputs, dbSeeding: e.target.value })}
                          placeholder="e.g. users, projects, orders"
                          className="w-full bg-neutral-950 border border-neutral-800 text-xs font-mono rounded p-1.5 focus:border-blue-500"
                        />
                      </div>
                    </div>
                  )}

                  {product.id !== 'prod-3' && product.id !== 'prod-1' && (
                    <p className="text-xs text-neutral-400 italic">This asset does not require complex pricing variables. Standard environment validation checks are pre-mapped.</p>
                  )}

                  {/* Terminal emulator */}
                  <div className="bg-neutral-950 rounded-xl border border-neutral-800 p-4 font-mono text-xs text-emerald-400 space-y-1.5 h-64 overflow-y-auto shadow-inner select-none">
                    {terminalOutput.map((line, idx) => (
                      <div key={idx} className="flex gap-2">
                        <span className="text-neutral-600 shrink-0">[{idx}]</span>
                        <span>{line}</span>
                      </div>
                    ))}
                    {isRunningSandbox && (
                      <div className="animate-pulse inline-block text-blue-400">Executing machine compilation instructions...</div>
                    )}
                  </div>

                  <button
                    onClick={executeSandbox}
                    disabled={isRunningSandbox}
                    className="w-full bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-white font-mono py-2 rounded text-xs font-bold transition-all flex items-center justify-center gap-2 uppercase tracking-wide disabled:opacity-50"
                  >
                    <Terminal className="w-4 h-4 text-emerald-400" /> Run Sandbox Module
                  </button>
                </div>
              )}

              {/* Tab: Changelog */}
              {activeTab === 'changelog' && (
                <div className="space-y-6">
                  {product.changelog.map((entry, idx) => (
                    <div key={idx} className="border-l-2 border-blue-500 pl-4 py-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-sm font-bold text-white font-mono">{entry.version}</span>
                        <span className="text-xs text-neutral-500 font-mono">Released {entry.date}</span>
                      </div>
                      <ul className="space-y-1.5 text-xs text-neutral-400 list-disc list-inside">
                        {entry.changes.map((change, cIdx) => (
                          <li key={cIdx}>{change}</li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              )}

              {/* Tab: FAQs */}
              {activeTab === 'faqs' && (
                <div className="space-y-4">
                  {product.faqs.map((faq, idx) => (
                    <div key={idx} className="bg-neutral-900/50 border border-neutral-900 rounded-lg p-4">
                      <h4 className="text-xs font-bold uppercase tracking-wider font-mono text-neutral-200">
                        {faq.question}
                      </h4>
                      <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
                        {faq.answer}
                      </p>
                    </div>
                  ))}
                </div>
              )}

            </div>

            {/* Product Reviews Panel */}
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-6 space-y-6">
              <h3 className="text-sm font-bold uppercase tracking-widest font-mono text-white flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-blue-500" /> Client Reviews & Attestations
              </h3>

              {/* Leave a review form */}
              <form onSubmit={handleSubmitReview} className="space-y-4 bg-neutral-900 p-4 rounded-xl border border-neutral-800">
                <p className="text-xs font-bold text-white uppercase tracking-wider">Leave an Attestation</p>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-neutral-400 font-mono">Rating:</span>
                  <div className="flex space-x-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setNewReview({ ...newReview, rating: star })}
                        className="focus:outline-none"
                      >
                        <Star
                          className={`w-4 h-4 ${
                            star <= newReview.rating ? 'text-amber-500 fill-amber-500' : 'text-neutral-600'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <textarea
                    rows={3}
                    required
                    value={newReview.comment}
                    onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                    placeholder="Provide professional feedback on compatibility, code quality, and integration speed..."
                    className="w-full bg-neutral-950 border border-neutral-800 rounded p-2 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-blue-500"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold tracking-wide"
                >
                  Post Review
                </button>
              </form>

              {/* Reviews list */}
              <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
                {localReviews.length === 0 ? (
                  <p className="text-xs text-neutral-500 italic">No reviews posted yet.</p>
                ) : (
                  localReviews.map((rev) => (
                    <div key={rev.id} className="border-b border-neutral-900 pb-4 last:border-0 last:pb-0">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-2.5">
                          <img src={rev.authorAvatar} alt={rev.authorName} className="w-8 h-8 rounded-full object-cover" />
                          <div>
                            <span className="text-xs font-semibold text-white block">{rev.authorName}</span>
                            <span className="text-[9px] font-mono text-neutral-500 uppercase">{rev.date}</span>
                          </div>
                        </div>
                        {rev.verified && (
                          <span className="bg-emerald-950 text-emerald-400 border border-emerald-500/20 text-[9px] font-mono px-2 py-0.5 rounded">
                            VERIFIED CLIENT
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1 my-1.5">
                        {Array.from({ length: 5 }).map((_, idx) => (
                          <Star
                            key={idx}
                            className={`w-3 h-3 ${
                              idx < rev.rating ? 'text-amber-500 fill-amber-500' : 'text-neutral-800'
                            }`}
                          />
                        ))}
                      </div>
                      <p className="text-xs text-neutral-400 leading-relaxed italic">
                        "{rev.comment}"
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>

          </div>

          {/* B. Right side column: Transaction panel & metadata */}
          <div className="space-y-6">
            
            {/* Purchase Desk */}
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-5 shadow-lg">
              <div className="flex justify-between items-center">
                <span className="text-xs font-mono uppercase text-neutral-500">Commercial Standard License</span>
                <span className="text-emerald-500 font-mono text-[10px] font-bold">INSTANT DOWNLOAD</span>
              </div>

              <div className="flex items-baseline space-x-1 border-b border-neutral-900 pb-4">
                <span className="text-3xl font-extrabold text-white font-mono">${getPrice()}</span>
                <span className="text-xs text-neutral-500 font-mono">USD</span>
              </div>

              {/* License Choice Segmented Control */}
              <div className="bg-neutral-900 p-1 rounded-lg border border-neutral-800 flex">
                <button
                  onClick={() => setLicenseOption('standard')}
                  className={`flex-1 py-1 text-center rounded text-xs font-semibold transition-all ${
                    licenseOption === 'standard' ? 'bg-white text-neutral-950' : 'text-neutral-400'
                  }`}
                >
                  Single User
                </button>
                <button
                  onClick={() => setLicenseOption('enterprise')}
                  className={`flex-1 py-1 text-center rounded text-xs font-semibold transition-all ${
                    licenseOption === 'enterprise' ? 'bg-white text-neutral-950' : 'text-neutral-400'
                  }`}
                >
                  Multi-Seat (2.5x)
                </button>
              </div>

              {/* Feature bullet list */}
              <div className="space-y-2.5 py-1">
                <div className="flex items-start gap-2 text-xs text-neutral-300">
                  <CheckCircle className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                  <span>Secure 256-bit cryptographic link</span>
                </div>
                <div className="flex items-start gap-2 text-xs text-neutral-300">
                  <CheckCircle className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                  <span>Lifetime access & free minor updates</span>
                </div>
                <div className="flex items-start gap-2 text-xs text-neutral-300">
                  <CheckCircle className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                  <span>Full source code access and offline archives</span>
                </div>
                {licenseOption === 'enterprise' && (
                  <div className="flex items-start gap-2 text-xs text-neutral-300">
                    <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    <span className="font-semibold text-emerald-400">Enterprise support SLA SLA-A included</span>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={handleAddCart}
                  disabled={isItemInCart}
                  className={`w-full py-2.5 rounded text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
                    isItemInCart
                      ? 'bg-neutral-800 text-neutral-500 border border-neutral-800 cursor-not-allowed'
                      : 'bg-blue-600 hover:bg-blue-500 text-white shadow-md shadow-blue-900/10'
                  }`}
                >
                  <ShoppingCart className="w-4 h-4" />{' '}
                  {isItemInCart ? 'Allocated in Order Details' : 'Allocate to Order'}
                </button>
              </div>
            </div>

            {/* Creator Profile Summary card */}
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4">
              <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest block">DEVELOPED BY</span>
              <div className="flex items-center gap-3">
                <img src={product.creatorAvatar} alt={product.creatorName} className="w-10 h-10 rounded-full object-cover" />
                <div>
                  <h5 className="text-xs font-bold text-white uppercase">{product.creatorName}</h5>
                  <p className="text-[10px] text-neutral-500 font-mono">Expert Exchange Participant</p>
                </div>
              </div>
              <p className="text-xs text-neutral-400 leading-relaxed italic">
                "We build high-grade digital software systems conforming to strict Wall Street constraints and low-latency metrics."
              </p>
            </div>

            {/* Related products card */}
            <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 space-y-4">
              <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest block">RELATED DIGITAL ASSETS</span>
              <div className="space-y-3">
                {relatedProducts.map((rel) => (
                  <button
                    key={rel.id}
                    onClick={() => {
                      product.id = rel.id; // simulate transition
                      setActiveTab('details');
                      window.scrollTo(0, 0);
                    }}
                    className="w-full flex items-center gap-3 bg-neutral-900/40 hover:bg-neutral-900 p-2 rounded-lg text-left border border-neutral-900 transition-all group"
                  >
                    <div className="w-12 h-12 rounded bg-neutral-800 overflow-hidden shrink-0">
                      <img src={rel.image} alt={rel.title} className="w-full h-full object-cover" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h6 className="text-xs font-semibold text-white group-hover:text-blue-400 transition-colors truncate">
                        {rel.title}
                      </h6>
                      <span className="text-[10px] text-neutral-500 font-mono">${rel.price}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
