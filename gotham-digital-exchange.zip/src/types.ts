/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface FAQ {
  question: string;
  answer: string;
}

export interface ChangelogEntry {
  version: string;
  date: string;
  changes: string[];
}

export interface Product {
  id: string;
  title: string;
  description: string;
  longDescription: string;
  category: string;
  price: number;
  creatorId: string;
  creatorName: string;
  creatorAvatar: string;
  rating: number;
  reviewsCount: number;
  compatibility: string[];
  tags: string[];
  downloadSize: string;
  version: string;
  licenseType: string;
  demoUrl?: string;
  image: string;
  changelog: ChangelogEntry[];
  faqs: FAQ[];
  downloadsCount: number;
  enterpriseReady: boolean;
}

export interface ServicePackage {
  name: string;
  price: number;
  deliveryTime: string;
  description: string;
  features: string[];
}

export interface Service {
  id: string;
  title: string;
  description: string;
  category: string;
  creatorId: string;
  creatorName: string;
  creatorAvatar: string;
  rating: number;
  reviewsCount: number;
  responseTime: string;
  availability: string; // e.g. "Available Immediately"
  startingPrice: number;
  hourlyRate: number;
  packages: {
    standard: ServicePackage;
    professional: ServicePackage;
    executive: ServicePackage;
  };
  milestones: {
    title: string;
    percentage: number;
  }[];
}

export interface Creator {
  id: string;
  name: string;
  avatar: string;
  role: string;
  bio: string;
  followers: number;
  rating: number;
  reviewsCount: number;
  responseTime: string;
  availability: string;
  experience: string;
  certifications: string[];
  revenue: number;
  salesCount: number;
  viewsCount: number;
}

export interface CartItem {
  id: string;
  title: string;
  price: number;
  image: string;
  type: 'product' | 'service';
  selectedPackage?: string; // 'standard' | 'professional' | 'executive'
}

export interface Order {
  id: string;
  itemId: string;
  itemTitle: string;
  itemImage: string;
  price: number;
  purchaseDate: string;
  type: 'product' | 'service';
  status: 'completed' | 'active' | 'disputed' | 'refunded';
  licenseKey?: string;
  downloadUrl?: string;
  selectedPackage?: string;
  milestones?: {
    id: string;
    title: string;
    amount: number;
    status: 'pending' | 'in_progress' | 'completed';
    dueDate: string;
  }[];
}

export interface Review {
  id: string;
  itemId: string;
  authorName: string;
  authorAvatar: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
}

export interface ForumPost {
  id: string;
  title: string;
  content: string;
  category: string;
  authorName: string;
  authorAvatar: string;
  authorRole: string;
  likes: number;
  commentsCount: number;
  date: string;
}

export interface Article {
  id: string;
  title: string;
  summary: string;
  content: string;
  category: string;
  authorName: string;
  readTime: string;
  date: string;
  image: string;
}

export interface EnterpriseSeat {
  email: string;
  role: 'Developer' | 'Manager' | 'Billing';
  status: 'Active' | 'Pending';
  assignedAt: string;
}

export interface Invoice {
  id: string;
  purchaseDate: string;
  companyName: string;
  itemName: string;
  amount: number;
  tax: number;
  total: number;
  status: 'Paid' | 'Pending';
}
