/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Product, Service, Creator, ForumPost, Article, Review } from './types';

export const mockCreators: Creator[] = [
  {
    id: 'creator-1',
    name: 'Silicon Alley Labs',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&h=200&q=80',
    role: 'SaaS & API Architects',
    bio: 'Premier engineering studio based in Flatiron District, crafting robust multi-tenant SaaS systems, developer SDKs, and performance-tuned backend services.',
    followers: 2410,
    rating: 4.9,
    reviewsCount: 312,
    responseTime: '< 15 minutes',
    availability: 'Available for Custom Contracts',
    experience: '12+ Years Enterprise Dev',
    certifications: ['AWS Certified Solutions Architect', 'Google Cloud Professional Cloud Architect', 'Kubernetes Administrator (CKA)'],
    revenue: 412500,
    salesCount: 1850,
    viewsCount: 34200
  },
  {
    id: 'creator-2',
    name: 'Marcus Vance, PhD',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&h=200&q=80',
    role: 'Quant & Financial Modeler',
    bio: 'Former VP of Quantitative Strategy at a top-tier investment bank in the Financial District. Specializes in advanced options pricing, algorithmic trading systems, and high-performance financial simulation.',
    followers: 1280,
    rating: 5.0,
    reviewsCount: 94,
    responseTime: '< 2 hours',
    availability: 'Part-time Availability',
    experience: '15+ Years Wall Street',
    certifications: ['Financial Risk Manager (FRM)', 'Chartered Financial Analyst (CFA)'],
    revenue: 298000,
    salesCount: 340,
    viewsCount: 18900
  },
  {
    id: 'creator-3',
    name: 'Brooklyn Pixel Foundry',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=200&h=200&q=80',
    role: 'Fintech & SaaS UI Design',
    bio: 'An award-winning creative collective in DUMBO, Brooklyn. We build gorgeous, highly interactive dashboards, design systems, and custom templates for elite digital products.',
    followers: 4350,
    rating: 4.8,
    reviewsCount: 520,
    responseTime: '< 1 hour',
    availability: 'Accepting Selected Projects',
    experience: '8+ Years Product Design',
    certifications: ['Figma Certified Professional', 'Nielsen Norman UX Master'],
    revenue: 520000,
    salesCount: 2940,
    viewsCount: 59000
  },
  {
    id: 'creator-4',
    name: 'Gotham Cyber Guard',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&h=200&q=80',
    role: 'Cybersecurity & Audit Partners',
    bio: 'Elite penetration testing and smart contract auditing firm representing leading NYC financial institutions, insurance conglomerates, and scaling Web3 startups.',
    followers: 1890,
    rating: 4.95,
    reviewsCount: 148,
    responseTime: '< 30 minutes',
    availability: 'Emergency Response Ready',
    experience: '10+ Years SecOps & Defense',
    certifications: ['Certified Information Systems Security Professional (CISSP)', 'Offensive Security Certified Professional (OSCP)'],
    revenue: 384000,
    salesCount: 420,
    viewsCount: 22100
  }
];

export const mockProducts: Product[] = [
  {
    id: 'prod-1',
    title: 'Nouveau-SaaS Boilerplate (Next.js & Rust)',
    description: 'Enterprise-grade, multi-tenant boilerplate featuring secure auth, subscriptions, high-concurrency rate limiters, and a clean Rust backend.',
    longDescription: `Nouveau-SaaS is the ultimate starter toolkit for ambitious founders building high-scale SaaS products. Engineered in collaboration with Wall Street tech leads, this template bridges client-side elegance with hyper-fast, safe backend execution.

### Architectural Features
* **Dual Runtime Architecture**: Next.js 14 client with React 19 combined with a robust Axum-based Rust backend.
* **Database Agnostic**: Pre-configured Drizzle ORM and Diesel support for PostgreSQL, Supabase, and Neon.
* **Pre-integrated Billing**: Full Stripe Billing engine supporting metered usage, dynamic tiers, and real-time invoicing.
* **Security Shield**: OAuth 2.0, stateful HTTP-only cookie sessions, multi-factor authentication triggers, and rate-limiting middleware.
* **Global Optimization**: Fully optimized Dockerfiles, Github Actions workflows, and Kubernetes manifests for automated zero-downtime scaling.`,
    category: 'Software',
    price: 299,
    creatorId: 'creator-1',
    creatorName: 'Silicon Alley Labs',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&h=200&q=80',
    rating: 4.9,
    reviewsCount: 124,
    compatibility: ['Next.js 14/15', 'React 18/19', 'Rust Axum', 'PostgreSQL'],
    tags: ['SaaS', 'Boilerplate', 'Rust', 'NextJS', 'Postgres', 'Auth', 'Stripe'],
    downloadSize: '42.8 MB',
    version: 'v2.4.1',
    licenseType: 'Commercial / Unlimited Projects',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&h=450&q=80',
    downloadsCount: 1420,
    enterpriseReady: true,
    changelog: [
      {
        version: 'v2.4.1',
        date: '2026-07-20',
        changes: [
          'Upgraded client modules to React 19 and Next.js 15 preview compatibility',
          'Enhanced Axum server performance by caching JWT validation keys in-memory',
          'Resolved Postgres connection pooling exhaustion under spikes'
        ]
      },
      {
        version: 'v2.3.0',
        date: '2026-05-12',
        changes: [
          'Added complete Stripe Webhook idempotency ledger',
          'Integrated automated OpenAPI v3 document generator',
          'Added dual-factor SMS authentication backup flow'
        ]
      }
    ],
    faqs: [
      {
        question: 'Does this purchase include lifetime updates?',
        answer: 'Yes! All GDX purchases of Nouveau-SaaS grant you lifetime access to all future major releases, security patches, and database migrations.'
      },
      {
        question: 'Is a Rust background strictly required to use this?',
        answer: 'While the backend is written in Rust, we provide extensive, beginner-friendly instructions, a pre-configured Docker stack, and standard JSON REST APIs. If you prefer, you can use only the Next.js client side with your own backend.'
      }
    ]
  },
  {
    id: 'prod-2',
    title: 'Manhattan-UI FinTech Design System',
    description: 'Ultra-premium, high-density dashboard design system crafted specifically for financial data, charting, and wealth management UI.',
    longDescription: `Manhattan-UI is an editorial-grade Figma design system and React tailwind component library tailored for institutional investment apps, trading terminals, and high-end digital wallets.

Designed around the constraints of extreme density and perfect mathematical alignment, this system avoids the "AI-generated slop" of oversized margins and generic blue cards, introducing a rich, high-contrast, professional aesthetic.

### System Highlights
* **High Density Architecture**: Crafted specifically to display massive amounts of information without feeling cluttered.
* **Premium Typography Systems**: Explicit typography hierarchies using custom tracking and optimal reading scales.
* **140+ Interactive Components**: Inputs, filters, tables, tabs, contextual menus, tooltips, and responsive modals.
* **Interactive Charting Assets**: Pre-designed components for candlestick, line, multi-axis, and area visualizations.
* **State Engine Integrations**: Fully documented responsive grid layouts and dark-mode tokens that pass AAA accessibility ratios.`,
    category: 'UI Kits',
    price: 149,
    creatorId: 'creator-3',
    creatorName: 'Brooklyn Pixel Foundry',
    creatorAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=200&h=200&q=80',
    rating: 4.8,
    reviewsCount: 215,
    compatibility: ['Figma Pro', 'Tailwind CSS v4', 'React 18/19', 'TypeScript'],
    tags: ['Design System', 'Figma', 'Fintech', 'React', 'Dashboard', 'Luxury', 'Tailwind'],
    downloadSize: '114.5 MB',
    version: 'v1.8.0',
    licenseType: 'Commercial Team Use',
    image: 'https://images.unsplash.com/photo-1542744094-3a31f103e35f?auto=format&fit=crop&w=800&h=450&q=80',
    downloadsCount: 2200,
    enterpriseReady: true,
    changelog: [
      {
        version: 'v1.8.0',
        date: '2026-06-18',
        changes: [
          'Introduced full Figma Variables Support for instantaneous dark/light switching',
          'Added 25 new premium financial chart layouts including Depth Charts and Orderbooks',
          'Complete optimization of tailwind theme tokens for Tailwind CSS v4'
        ]
      }
    ],
    faqs: [
      {
        question: 'Are the React components included alongside the Figma library?',
        answer: 'Absolutely. Buying Manhattan-UI gives you both the raw design Figma files and a clean, modular React Tailwind NPM package with interactive component code.'
      }
    ]
  },
  {
    id: 'prod-3',
    title: 'Gotham Options Greeks API Server (REST/gRPC)',
    description: 'High-throughput Options Greeks pricing and implied volatility calculator engine with live WebSockets, built in native C++ and Rust wrappers.',
    longDescription: `Gotham-Core is a highly optimized API and calculation server that computes real-time Options Greeks (Delta, Gamma, Theta, Vega, Rho) and Implied Volatility using Black-Scholes-Merton and binomial pricing trees.

Built to sustain millions of requests per second with microsecond latency, it is an essential plugin for digital investment desks, algo traders, and financial brokerages.

### Technical Performance
* **Latency Guarantee**: Average calculation speed under 2.5 microseconds.
* **Streaming Capability**: Fully supported WebSockets feed streaming real-time surface curves.
* **Calculations Supported**: European/American options, dividend-yield adjustments, discrete cash dividend vectors.
* **Interfaces Available**: REST JSON endpoints, lightning-fast gRPC, and standard C/C++ shared library files.`,
    category: 'APIs',
    price: 499,
    creatorId: 'creator-2',
    creatorName: 'Marcus Vance, PhD',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&h=200&q=80',
    rating: 5.0,
    reviewsCount: 42,
    compatibility: ['gRPC / Protobuf', 'Rust / C++', 'Linux / Docker', 'NodeJS / Python'],
    tags: ['API', 'Options Greeks', 'Quant', 'Finance', 'WebSockets', 'gRPC', 'HFT'],
    downloadSize: '18.4 MB',
    version: 'v3.1.2',
    licenseType: 'Single Server Deployment License',
    image: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=800&h=450&q=80',
    downloadsCount: 180,
    enterpriseReady: true,
    changelog: [
      {
        version: 'v3.1.2',
        date: '2026-07-30',
        changes: [
          'Added optimized vectorized Black-Scholes execution via AVX-512 instructions',
          'Added support for custom dividend calendars in American pricing model',
          'Implemented sub-microsecond token authentication layer'
        ]
      }
    ],
    faqs: [
      {
        question: 'Does this API require a live data source subscription?',
        answer: 'Gotham Options Greeks calculates values based on parameters you feed into it (underlying, strike, risk-free rate, volatility, time to expiry). It does not include a proprietary live stock data feed itself, but is designed to sit downstream from any feed provider like Bloomberg, Polygon.io, or Alpaca.'
      }
    ]
  },
  {
    id: 'prod-4',
    title: 'Solidity Smart Contract Security Kit',
    description: 'Pre-audited, secure, gas-optimized Solidity templates for modern Web3 protocols. Includes advanced ERC-20, ERC-721, and multisig governance rules.',
    longDescription: `A gold-standard suite of pre-compiled smart contract templates designed to eliminate common Solidity vulnerabilities (reentrancy, overflow, gas exhaust, oracle manipulation). 

Approved and stamped by Gotham Cyber Guard security architects, this bundle allows developers to deploy robust tokens, multi-signature corporate vaults, and custom staking hubs without the multi-week delay and cost of traditional reviews.

### Codebases Included:
* **GDX-Standard Token (ERC-20 & ERC-2612)**: Gas-optimized ERC-20 with built-in metatransactions (permit) and pause-safes.
* **Corporate Treasury Vault (Multisig)**: High-security threshold-based multi-signature release vault with time-locks and emergency circuit breakers.
* **Dynamic NFT Collection (ERC-721A)**: Ultra-efficient batch minting contract that dramatically reduces deployment and transfer gas overhead.
* **Security Checklists & Hardhat Configs**: Pre-configured Slither, Mythril, and Echidna security analysis runbooks.`,
    category: 'Cybersecurity',
    price: 199,
    creatorId: 'creator-4',
    creatorName: 'Gotham Cyber Guard',
    creatorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&h=200&q=80',
    rating: 4.95,
    reviewsCount: 68,
    compatibility: ['Solidity 0.8.20+', 'Hardhat / Foundry', 'EVM Chains'],
    tags: ['Smart Contracts', 'Web3', 'Solidity', 'Security', 'Ethereum', 'Blockchain'],
    downloadSize: '12.2 MB',
    version: 'v1.2.0',
    licenseType: 'Commercial Project Licensing',
    image: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=800&h=450&q=80',
    downloadsCount: 510,
    enterpriseReady: true,
    changelog: [
      {
        version: 'v1.2.0',
        date: '2026-04-10',
        changes: [
          'Upgraded compilers to Solidity 0.8.24 and enabled EVM Cancun-opcode support',
          'Integrated native ERC-4337 Account Abstraction hooks for wallet interoperability',
          'Halved deployment gas on Treasury Vault through structural assembly optimizations'
        ]
      }
    ],
    faqs: [
      {
        question: 'Are these contracts guaranteed to be hack-proof?',
        answer: 'While these templates adhere strictly to the absolute highest tier of smart contract security standards and have passed extensive audits, security is an active process. Changing the code or nesting external calls can introduce new threat vectors. These contracts serve as an extremely safe foundation, but we always advise scheduling a final code review prior to mainnet deployment.'
      }
    ]
  },
  {
    id: 'prod-5',
    title: 'Manhattan Core Typography & Typeface Bundle',
    description: 'A striking editorial font family built for luxury brands, premium SaaS applications, and terminal dashboards. Includes 9 weights + web variables.',
    longDescription: `A bespoke display and text typeface designed to convey New York\'s architectural majesty, editorial confidence, and fintech precision. 

With sharp geometry, humanist terminals, and strict optical balance, this bundle includes:
* **Manhattan Display**: A robust, high-contrast serif font family tailored for display headings, luxury advertisements, and high-status titles.
* **Silicon Mono**: A clean, highly legible monospace typeface perfect for terminal dashboards, syntax highlighters, and data dense lists.
* **Variable Weights**: Variable-enabled WOFF2 web formats, TrueType (.ttf), and OpenType (.otf) variables spanning Thin to Ultra-Bold.`,
    category: 'Fonts',
    price: 89,
    creatorId: 'creator-3',
    creatorName: 'Brooklyn Pixel Foundry',
    creatorAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=200&h=200&q=80',
    rating: 4.7,
    reviewsCount: 88,
    compatibility: ['WOFF2 / WebFonts', 'OTF / TTF', 'CSS Integration'],
    tags: ['Typography', 'Typeface', 'Font', 'Design', 'Fintech font', 'Variable Font'],
    downloadSize: '8.4 MB',
    version: 'v1.0.3',
    licenseType: 'Commercial Desktop + Web App License',
    image: 'https://images.unsplash.com/photo-1561070791-26c113006238?auto=format&fit=crop&w=800&h=450&q=80',
    downloadsCount: 780,
    enterpriseReady: false,
    changelog: [
      {
        version: 'v1.0.3',
        date: '2026-03-01',
        changes: [
          'Improved kerning tables for fractional financial numbers',
          'Added custom symbols for global currencies including Crypto (BTC, ETH, SOL)',
          'Added alternate single-story lowercase "a" glyph'
        ]
      }
    ],
    faqs: [
      {
        question: 'Is there a page-view limitation on the web font license?',
        answer: 'Unlike traditional registries, GDX license terms for this bundle grant you unlimited page-views on up to 5 commercial domains owned by your organization.'
      }
    ]
  },
  {
    id: 'prod-6',
    title: 'Institutional Alpha & Crypto Research Report',
    description: 'Deep-dive analytical research report analyzing global digital asset trends, quantitative macro hedging, and on-chain liquidity indicators.',
    longDescription: `A premium, institutional-grade research document written by Dr. Marcus Vance. This is a comprehensive 120-page macroeconomic study providing proprietary predictive insights into digital asset trends, decentralized liquidity maps, and automated order-book patterns.

### What is covered:
* **Macro On-Chain Capital Flow**: Analysis of global liquidity injections and stablecoin velocities across top layer-1 systems.
* **Market Microstructure & Order Book Skew**: High-frequency analysis of options market-maker delta hedging and Gamma imbalances.
* **Quantitative Backtests**: Performance of options-skews, volatility-arbitrage, and momentum factor-models over the last 18 months.
* **Full Python Jupyter Notebook**: Includes clean, documented, and fully reusable Python source code to reproduce the data visualizations and pull on-chain metrics directly from public nodes.`,
    category: 'Research',
    price: 120,
    creatorId: 'creator-2',
    creatorName: 'Marcus Vance, PhD',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&h=200&q=80',
    rating: 4.9,
    reviewsCount: 34,
    compatibility: ['PDF / Interactive Doc', 'Jupyter Notebook (Python 3.10+)'],
    tags: ['Research', 'Financial modeling', 'Alpha Report', 'Macro', 'Crypto', 'Quant Book'],
    downloadSize: '15.6 MB',
    version: 'v2026.Q3',
    licenseType: 'Single User / Internal Institutional Use Only',
    image: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?auto=format&fit=crop&w=800&h=450&q=80',
    downloadsCount: 220,
    enterpriseReady: true,
    changelog: [
      {
        version: 'v2026.Q3',
        date: '2026-07-01',
        changes: [
          'First release for Q3 2026 featuring the impact of macro global rate adjustments and on-chain capital rotations'
        ]
      }
    ],
    faqs: [
      {
        question: 'Can this report be shared with our team members?',
        answer: 'This license covers single-user reading. For multi-seat corporate sharing, please select the GDX Enterprise licensing option at checkout, or contact the creator.'
      }
    ]
  }
];

export const mockServices: Service[] = [
  {
    id: 'srv-1',
    title: 'Enterprise Multi-Tenant Cloud Migration & Setup',
    description: 'Transform your legacy infrastructure. We architect, migrate, and secure your workflows on high-concurrency cloud clusters.',
    category: 'Cloud Services',
    creatorId: 'creator-1',
    creatorName: 'Silicon Alley Labs',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&h=200&q=80',
    rating: 4.95,
    reviewsCount: 74,
    responseTime: '< 30 minutes',
    availability: 'Available Immediately',
    startingPrice: 3500,
    hourlyRate: 180,
    packages: {
      standard: {
        name: 'Single Node Cluster Migration',
        price: 3500,
        deliveryTime: '10 Days',
        description: 'Ideal for scaling startups needing automated docker container setups and robust PostgreSQL cloud hosting configurations.',
        features: [
          'Terraform setup for AWS or GCP',
          'Single VPC deployment with 2 subnets',
          'Docker container configuration',
          'Automated database backups setup',
          '3 Days support and hand-off'
        ]
      },
      professional: {
        name: 'High Availability Multi-Tenant Stack',
        price: 6500,
        deliveryTime: '21 Days',
        description: 'Full-scale enterprise production cloud architecture. Designed for 99.99% uptime with dynamic node scaling and complete security shields.',
        features: [
          'Terraform multi-region infrastructure',
          'Kubernetes (EKS/GKE) cluster orchestration',
          'CI/CD GitHub Actions build pipeline',
          'Redis cluster integration for lightning-fast caching',
          'End-to-end HTTPS/SSL & WAF Web Application Firewalls',
          '14 Days intensive hyper-support'
        ]
      },
      executive: {
        name: 'Wall-Street Compliant Sovereign Cloud',
        price: 12000,
        deliveryTime: '45 Days',
        description: 'Elite architecture adhering to SEC, HIPAA, SOC2, and GDPR compliant standards. Includes custom audits and cryptographic protections.',
        features: [
          'All Professional features included',
          'SEC/SOC2/HIPAA compliance policy enforcement',
          'Fully encrypted database-at-rest and in-transit secrets vault',
          'Intrusion Detection Systems (IDS) & DDoS mitigation shields',
          'Dedicated quant-speed node configurations',
          '30 Days 24/7 priority emergency support lines'
        ]
      }
    },
    milestones: [
      { title: 'Discovery, Threat Modeling & Architecture Design', percentage: 20 },
      { title: 'VPC, DB Instance & Infrastructure Deployment', percentage: 30 },
      { title: 'App Containerization & CI/CD Pipeline Setup', percentage: 30 },
      { title: 'Penetration Testing, Compliance Hand-off & Live Go', percentage: 20 }
    ]
  },
  {
    id: 'srv-2',
    title: 'Advanced Algorithmic Strategy & Pricing Engine Design',
    description: 'Bespoke design of quantitative pricing algorithms, neural-network predictors, or lightning fast portfolio backtesters.',
    category: 'Finance',
    creatorId: 'creator-2',
    creatorName: 'Marcus Vance, PhD',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&h=200&q=80',
    rating: 5.0,
    reviewsCount: 38,
    responseTime: '< 4 hours',
    availability: 'Limited Openings',
    startingPrice: 5000,
    hourlyRate: 250,
    packages: {
      standard: {
        name: 'Pricing Model Proof-of-Concept',
        price: 5000,
        deliveryTime: '14 Days',
        description: 'A complete mathematical proof-of-concept for custom options, exotic assets, or predictive indicators including Python reference scripts.',
        features: [
          'Advanced mathematical derivation documentation',
          'Python Pandas & NumPy prototyping notebook',
          'Performance backtest metrics (Sharpe, Max Drawdown)',
          '3-hour technical hand-off webinar'
        ]
      },
      professional: {
        name: 'Production C++ / Rust Calculation Library',
        price: 9500,
        deliveryTime: '30 Days',
        description: 'A highly optimized, multi-threaded, compiled pricing library or high-speed data parser built in Rust or C++ and ready for terminal integrations.',
        features: [
          'Fully compiled Rust or C++ crate/static library',
          'SIMD vectorized computations for millions of concurrent updates',
          'Thorough unit tests & performance benchmarks (microsecond metrics)',
          'Complete C/NodeJS/Python bindings',
          '10 Hours developer training call'
        ]
      },
      executive: {
        name: 'Custom High Frequency Execution Algo Stack',
        price: 18000,
        deliveryTime: '60 Days',
        description: 'The absolute pinnacle of quantitative engineering. An end-to-end trading model coupled with instant market connectors, custom order buffers, and low-latency safety controls.',
        features: [
          'Full-scale execution algorithm with broker integration (Ibkr/Web3)',
          'Ultra-low-latency memory structures',
          'Real-time circuit breakers and compliance guardrails',
          'Full security keys vault configuration',
          '3 months algorithm support and dynamic tuning updates'
        ]
      }
    },
    milestones: [
      { title: 'Mathematical Specification & Alpha Modeling', percentage: 25 },
      { title: 'High-Performance Engine Development (Rust/C++)', percentage: 40 },
      { title: 'Simulation, Backtesting & Integration Tests', percentage: 20 },
      { title: 'Production Live Deploy & Optimization', percentage: 15 }
    ]
  },
  {
    id: 'srv-3',
    title: 'High-Density Fintech Dashboard & UI Design Audit',
    description: 'Transform complex database tables into elegant, intuitive, and luxury-tier Manhattan-styled UI dashboards. Figma files and custom Tailwind components included.',
    category: 'UI Kits',
    creatorId: 'creator-3',
    creatorName: 'Brooklyn Pixel Foundry',
    creatorAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=200&h=200&q=80',
    rating: 4.85,
    reviewsCount: 112,
    responseTime: '< 1 hour',
    availability: 'Accepting Selective Projects',
    startingPrice: 2000,
    hourlyRate: 150,
    packages: {
      standard: {
        name: 'Single Dashboard Redesign & Audit',
        price: 2000,
        deliveryTime: '7 Days',
        description: 'A deep design review of your main user dashboard. We rewrite layouts to optimize density, readability, and financial chart layouts.',
        features: [
          'Comprehensive UX Audit report (PDF)',
          '1 Custom Figma master mockup of your main screen',
          'Custom Typography scale token definition',
          '3 Interactive React Tailwind components of the screen'
        ]
      },
      professional: {
        name: 'Full Product Core Layout & Figma Tokens',
        price: 4500,
        deliveryTime: '20 Days',
        description: 'We restructure your entire fintech application or complex SaaS product. Complete Figma variables and React template files provided.',
        features: [
          'Mockups for up to 5 critical views (Main, Portfolio, Checkout, Settings, Table Views)',
          'Full Figma interactive design system with global light/dark variables',
          'Responsive grid layout configurations for high-density monitors',
          '15 custom React Tailwind components',
          'Complete design handbook detailing layout choices'
        ]
      },
      executive: {
        name: 'The DUMBO Studio Master Design Suite',
        price: 9000,
        deliveryTime: '45 Days',
        description: 'The ultimate design treatment. We partner as your fractional VP of Design, building an elite custom aesthetic, branding guidelines, high-end motion guidelines, and pristine UI components.',
        features: [
          'Full UI/UX layout design for up to 12 application screens',
          'Interactive, realistic web prototype for investor pitches',
          'Motion design tokens (framer-motion code guides)',
          'Custom vector logo assets and complete brand styling manual',
          '30 Hours face-to-face (or remote) design sprints with your engineers',
          '3 months priority design iteration support'
        ]
      }
    },
    milestones: [
      { title: 'UX Audit, Typography & Style Direction Discovery', percentage: 20 },
      { title: 'Core Mockups & Variables Definition in Figma', percentage: 35 },
      { title: 'Component Library & Tailwind Conversion', percentage: 30 },
      { title: 'Prototyping, Usability Hand-off & Final Iterations', percentage: 15 }
    ]
  }
];

export const mockForumPosts: ForumPost[] = [
  {
    id: 'post-1',
    title: 'Optimal Rust Axum middleware for JWT validation in high concurrency setups',
    content: 'We have been benchmarking Rust Axum for the backend of a financial dashboard and noticed some interesting CPU cycles spike under 10k requests/second during JWT decryption on every request. Is anyone caching JWK public keys locally, or using localized state models?',
    category: 'Software Development',
    authorName: 'Alex Mercer',
    authorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&h=100&q=80',
    authorRole: 'Senior Platform Engineer',
    likes: 34,
    commentsCount: 12,
    date: '2026-08-01'
  },
  {
    id: 'post-2',
    title: 'The math behind options skew: why standard Black-Scholes breaks during extreme volatility',
    content: 'An elegant writeup exploring how standard Black-Scholes assumes constant volatility, whereas actual options markets display deep smiles and smirks. This explains the importance of our custom vol surface grids and cubic splines calculations.',
    category: 'Financial Modeling',
    authorName: 'Marcus Vance, PhD',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&h=200&q=80',
    authorRole: 'Creator / Quant Strategy',
    likes: 89,
    commentsCount: 24,
    date: '2026-07-28'
  },
  {
    id: 'post-3',
    title: 'Fintech dashboard density ratios: why padding-rich mobile UX fails on active trading desks',
    content: 'Discussing the psychological and operational needs of institutional operators. They prefer dense grid systems over bloated white-space cards because it maximizes situational awareness. Let\'s look at some mathematical ratios.',
    category: 'UI/UX Design',
    authorName: 'Sarah Jenkins',
    authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&h=100&q=80',
    authorRole: 'Lead UX Architect',
    likes: 56,
    commentsCount: 15,
    date: '2026-07-25'
  }
];

export const mockArticles: Article[] = [
  {
    id: 'art-1',
    title: 'Sovereign Fintech Stacks: Moving Back to Native Servers in NYC Finance',
    summary: 'An inside look at why NYC finance startups are shifting away from bloated serverless paradigms back to bare-metal Rust and C++ micro-clusters to reduce latency spikes.',
    content: 'Over the last five years, serverless functions were hailed as the ultimate scaling tool. However, in low-latency environments where every microsecond represents slippage, cold-starts are an absolute dealbreaker. Teams across Silicon Alley are migrating back to lightweight native runtime servers, optimizing memory buffers, and utilizing Docker orchestration with direct port routing. This article analyzes the architecture and presents the performance benchmarks of modern native APIs.',
    category: 'Architecture',
    authorName: 'Silicon Alley Labs Editorial',
    readTime: '6 Min Read',
    date: '2026-08-02',
    image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&h=450&q=80'
  },
  {
    id: 'art-2',
    title: 'Demystifying Option Greek Calculation Vectors for Modern Trading Terminals',
    summary: 'A step-by-step mathematical guide to calculating real-time implied volatility and option delta surfaces inside browser applications.',
    content: 'With WebAssembly and high-performance JS engines, modern browser applications are fully capable of executing complex quantitative calculations in real-time. This guide maps out the formulas for Black-Scholes, explains the Newton-Raphson method for calculating Implied Volatility, and provides source code to build a real-time responsive Greeks calculator on the client side.',
    category: 'Quant Guide',
    authorName: 'Marcus Vance, PhD',
    readTime: '12 Min Read',
    date: '2026-07-15',
    image: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=800&h=450&q=80'
  }
];

export const mockReviews: Review[] = [
  {
    id: 'rev-1',
    itemId: 'prod-1',
    authorName: 'David K., CTO',
    authorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=100&h=100&q=80',
    rating: 5,
    comment: 'Saved our engineering team at least two months of boilerplate work. The Rust Axum backend is beautiful, type-safe, and incredibly fast. High-scale tests handled 8,000 requests/sec flawlessly on single-node AWS setups.',
    date: '2026-07-28',
    verified: true
  },
  {
    id: 'rev-2',
    itemId: 'prod-1',
    authorName: 'Elena Rostova',
    authorAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=100&h=100&q=80',
    rating: 4,
    comment: 'Exceptional codebase layout. Very easy to follow directory structure. My only request is to add more pre-built templates for billing history on the client side, but other than that, it is perfect.',
    date: '2026-07-15',
    verified: true
  },
  {
    id: 'rev-3',
    itemId: 'prod-2',
    authorName: 'Jonah Vance',
    authorAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=100&h=100&q=80',
    rating: 5,
    comment: 'Pure editorial luxury. Every typography token and grid spacing feels deliberate and highly professional. Standard design systems are usually bloated, but Manhattan-UI is beautifully dense, perfect for fintech apps.',
    date: '2026-07-01',
    verified: true
  }
];
