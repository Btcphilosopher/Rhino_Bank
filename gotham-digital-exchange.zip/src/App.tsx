/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Marketplace from './components/Marketplace';
import ProductPage from './components/ProductPage';
import ServicePage from './components/ServicePage';
import CustomerDashboard from './components/CustomerDashboard';
import CreatorDashboard from './components/CreatorDashboard';
import EnterpriseHub from './components/EnterpriseHub';
import Community from './components/Community';
import GDXDocs from './components/GDXDocs';

import { Product, Service, Creator, CartItem, Order, EnterpriseSeat, Invoice } from './types';
import { mockProducts, mockServices, mockCreators } from './mockData';
import { ShieldCheck, ArrowUpRight, Award, Compass, Landmark, Cpu, BarChart, Users, Star, ArrowRight, Zap, Play } from 'lucide-react';

export default function App() {
  const [currentView, setView] = useState<string>('homepage');
  const [userRole, setRole] = useState<'buyer' | 'creator' | 'enterprise' | 'docs'>('buyer');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Lists in mutable state so uploads append instantly!
  const [productsList, setProductsList] = useState<Product[]>(mockProducts);
  const [servicesList, setServicesList] = useState<Service[]>(mockServices);

  // Selected details targets
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedService, setSelectedService] = useState<Service | null>(null);

  // Cart state
  const [cart, setCart] = useState<CartItem[]>([]);

  // Bookmark / saved list
  const [savedItems, setSavedItems] = useState<CartItem[]>([
    {
      id: 'prod-2',
      title: 'Manhattan-UI FinTech Design System',
      price: 149,
      image: 'https://images.unsplash.com/photo-1542744094-3a31f103e35f?auto=format&fit=crop&w=800&h=450&q=80',
      type: 'product',
    }
  ]);

  // Customer Purchases Ledger (Pre-populated to demonstrate download module instantly)
  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'ORD-NY-108204',
      itemId: 'prod-1',
      itemTitle: 'Nouveau-SaaS Boilerplate (Next.js & Rust)',
      itemImage: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&h=450&q=80',
      price: 299,
      purchaseDate: '2026-07-28',
      type: 'product',
      status: 'completed',
      licenseKey: 'GDX-LIC-0x92F8A1B02C4D',
    }
  ]);

  // Invoices list
  const [invoices, setInvoices] = useState<Invoice[]>([
    {
      id: 'INV-10820',
      purchaseDate: '2026-07-28',
      companyName: 'Individual Developer Account',
      itemName: 'Nouveau-SaaS Boilerplate (Next.js & Rust)',
      amount: 299,
      tax: 26.54,
      total: 325.54,
      status: 'Paid',
    }
  ]);

  // Enterprise seats provisioned
  const [enterpriseSeats, setEnterpriseSeats] = useState<EnterpriseSeat[]>([
    { email: 'director.quant@manhattancapital.com', role: 'Manager', status: 'Active', assignedAt: '2026-06-12' },
    { email: 'architect.dev@manhattancapital.com', role: 'Developer', status: 'Active', assignedAt: '2026-06-18' },
    { email: 'operations.sec@manhattancapital.com', role: 'Developer', status: 'Active', assignedAt: '2026-07-02' },
  ]);

  // Enterprise pending procurement approvals
  const [pendingProcurements, setPendingProcurements] = useState([
    {
      id: 'REQ-8910',
      requestedBy: 'architect.dev@manhattancapital.com',
      itemName: 'Gotham Options Greeks API Server (REST/gRPC)',
      price: 499,
      date: '2026-08-04',
    }
  ]);

  // Creator total earnings simulation
  const [creatorEarnings, setCreatorEarnings] = useState<number>(142820);

  // Cart operations
  const addToCart = (item: CartItem) => {
    if (!cart.some((ci) => ci.id === item.id)) {
      setCart([...cart, item]);
    }
  };

  const removeFromCart = (id: string) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  const removeSavedItem = (id: string) => {
    setSavedItems(savedItems.filter((i) => i.id !== id));
  };

  // Perform checkout on cart contents
  const checkout = () => {
    if (cart.length === 0) return;

    const newOrders: Order[] = cart.map((item) => {
      const orderId = `ORD-NY-${Math.floor(100000 + Math.random() * 900000)}`;
      const licKey = `GDX-LIC-0x${Math.random().toString(16).slice(2, 14).toUpperCase()}`;

      // If hiring service, generate mock milestone deliverables
      let serviceMilestones: any[] = [];
      if (item.type === 'service') {
        const selectedSrv = servicesList.find((s) => s.id === item.id);
        serviceMilestones = selectedSrv?.milestones.map((m, idx) => ({
          id: `mil-${idx}-${Date.now()}`,
          title: m.title,
          amount: Math.round((item.price * m.percentage) / 100),
          status: 'in_progress',
          dueDate: `2026-08-${15 + idx * 7}`,
        })) || [];
      }

      return {
        id: orderId,
        itemId: item.id,
        itemTitle: item.title,
        itemImage: item.image,
        price: item.price,
        purchaseDate: new Date().toISOString().split('T')[0],
        type: item.type,
        status: 'completed',
        licenseKey: item.type === 'product' ? licKey : undefined,
        milestones: item.type === 'service' ? serviceMilestones : undefined,
      };
    });

    // Generate receipts
    const newInvoices: Invoice[] = cart.map((item) => ({
      id: `INV-${Math.floor(10000 + Math.random() * 90000)}`,
      purchaseDate: new Date().toISOString().split('T')[0],
      companyName: userRole === 'enterprise' ? 'Manhattan Capital Group, LLC' : 'Individual Client Account',
      itemName: item.title,
      amount: item.price,
      tax: Math.round(item.price * 0.08875),
      total: item.price + Math.round(item.price * 0.08875),
      status: 'Paid',
    }));

    setOrders([...newOrders, ...orders]);
    setInvoices([...newInvoices, ...invoices]);
    setCart([]);
    
    // Redirect to customer dashboard
    setView('customer-dashboard');
    setRole('buyer');
  };

  // Submit direct consulting contract proposal (creates an immediate project order in customer portal)
  const submitConsultingProposal = (service: Service, packageName: string, finalPrice: number, customBrief: string) => {
    const orderId = `ORD-NY-${Math.floor(100000 + Math.random() * 900000)}`;
    const customMilestones = service.milestones.map((m, idx) => ({
      id: `mil-${idx}-${Date.now()}`,
      title: m.title,
      amount: Math.round((finalPrice * m.percentage) / 100),
      status: idx === 0 ? 'in_progress' : 'pending' as any,
      dueDate: `2026-08-${15 + idx * 7}`,
    }));

    const srvOrder: Order = {
      id: orderId,
      itemId: service.id,
      itemTitle: `${service.title} (${packageName})`,
      itemImage: service.creatorAvatar,
      price: finalPrice,
      purchaseDate: new Date().toISOString().split('T')[0],
      type: 'service',
      status: 'completed',
      milestones: customMilestones,
    };

    setOrders([srvOrder, ...orders]);
    setView('customer-dashboard');
    setRole('buyer');
  };

  // Creator studio: publish new digital asset
  const addNewProduct = (prod: Product) => {
    setProductsList([prod, ...productsList]);
  };

  const addNewService = (srv: Service) => {
    setServicesList([srv, ...servicesList]);
  };

  // Hired projects: customer approves milestone releases cash to creator
  const approveProjectMilestone = (orderId: string, milestoneId: string) => {
    setOrders((prevOrders) =>
      prevOrders.map((ord) => {
        if (ord.id === orderId && ord.milestones) {
          const updatedMilestones = ord.milestones.map((m) => {
            if (m.id === milestoneId) {
              // Add released money to creator earnings log!
              setCreatorEarnings((prev) => prev + m.amount);
              return { ...m, status: 'completed' as const };
            }
            return m;
          });
          return { ...ord, milestones: updatedMilestones };
        }
        return ord;
      })
    );
  };

  // Creator Studio: process payment refund
  const processRefund = (orderId: string) => {
    setOrders((prevOrders) =>
      prevOrders.map((ord) => {
        if (ord.id === orderId) {
          // Subtract from earnings
          setCreatorEarnings((prev) => Math.max(0, prev - ord.price));
          return { ...ord, status: 'refunded' as const };
        }
        return ord;
      })
    );
  };

  // Enterprise Hub: Add developer seats
  const addSeat = (email: string, role: 'Developer' | 'Manager' | 'Billing') => {
    const seat: EnterpriseSeat = {
      email,
      role,
      status: 'Active',
      assignedAt: new Date().toISOString().split('T')[0],
    };
    setEnterpriseSeats([seat, ...enterpriseSeats]);
  };

  const revokeSeat = (email: string) => {
    setEnterpriseSeats(enterpriseSeats.filter((s) => s.email !== email));
  };

  // Enterprise Hub: Approve Procurement Request
  const approveProcurement = (reqId: string, itemName: string, price: number) => {
    const orderId = `ORD-NY-${Math.floor(100000 + Math.random() * 900000)}`;
    const licKey = `GDX-LIC-0x${Math.random().toString(16).slice(2, 14).toUpperCase()}`;

    const newOrder: Order = {
      id: orderId,
      itemId: 'prod-3', // mock Greeks options id as reference
      itemTitle: itemName,
      itemImage: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=800&h=450&q=80',
      price: price,
      purchaseDate: new Date().toISOString().split('T')[0],
      type: 'product',
      status: 'completed',
      licenseKey: licKey,
    };

    const newInvoice: Invoice = {
      id: `INV-${Math.floor(10000 + Math.random() * 90000)}`,
      purchaseDate: new Date().toISOString().split('T')[0],
      companyName: 'Manhattan Capital Group, LLC',
      itemName: itemName,
      amount: price,
      tax: Math.round(price * 0.08875),
      total: price + Math.round(price * 0.08875),
      status: 'Paid',
    };

    setOrders([newOrder, ...orders]);
    setInvoices([newInvoice, ...invoices]);
    setPendingProcurements(pendingProcurements.filter((p) => p.id !== reqId));
  };

  // Helper selectors to navigate to item details pages
  const viewProductDetails = (product: Product) => {
    setSelectedProduct(product);
    setView('product-page');
    setRole('buyer');
  };

  const viewServiceDetails = (service: Service) => {
    setSelectedService(service);
    setView('service-page');
    setRole('buyer');
  };

  // Spotlight lists on Homepage
  const featuredCreators = mockCreators.slice(0, 3);
  const trendingProducts = productsList.slice(0, 3);
  const topServices = servicesList.slice(0, 3);

  return (
    <div className="bg-neutral-950 min-h-screen text-white flex flex-col font-sans antialiased">
      
      {/* Dynamic Header */}
      <Header
        currentView={currentView}
        setView={setView}
        userRole={userRole}
        setRole={setRole}
        cart={cart}
        removeFromCart={removeFromCart}
        checkout={checkout}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      {/* Primary Container */}
      <main className="flex-grow">
        
        {/* VIEW 1: Homepage (Modern Manhattan Wall Street styling) */}
        {currentView === 'homepage' && userRole === 'buyer' && (
          <div className="space-y-16 py-12">
            
            {/* Elegant Hero Section with negative space */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-900/10 via-neutral-950 to-neutral-950 rounded-3xl -z-10 border border-neutral-900"></div>
              
              <div className="py-20 px-8 md:px-12 max-w-4xl space-y-6 text-left">
                <span className="text-xs font-mono font-bold text-blue-400 tracking-widest uppercase flex items-center gap-1.5">
                  <span className="w-2 h-2 bg-blue-500 rounded-full inline-block animate-pulse"></span>
                  Corporate Headquarters: Wall Street, NYC
                </span>
                
                <h1 className="text-4xl md:text-6xl font-extrabold text-white tracking-tight leading-none uppercase font-sans">
                  The Marketplace <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-300">
                    For The Digital Economy
                  </span>
                </h1>

                <p className="text-sm md:text-base text-neutral-400 leading-relaxed max-w-2xl font-light">
                  Gotham Digital Exchange (GDX) provides the institutional commercial pipeline for verified software modules, financial calculation interfaces, high-density dashboard kits, and on-demand quantitative consultants.
                </p>

                {/* Taglines block */}
                <div className="flex flex-wrap gap-x-6 gap-y-2 text-xs font-mono text-neutral-500 uppercase pt-2 border-t border-neutral-900">
                  <span>• Where Digital Business Happens</span>
                  <span>• Ideas. Software. Services. Delivered Instantly</span>
                  <span>• SOC2 Compliant Ledger</span>
                </div>

                <div className="flex flex-wrap gap-4 pt-4">
                  <button
                    onClick={() => setView('marketplace')}
                    className="bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs py-3 px-6 rounded-md uppercase tracking-wider transition-all shadow-lg flex items-center gap-2"
                  >
                    Browse Spot Assets <ArrowRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setView('services')}
                    className="bg-neutral-900 hover:bg-neutral-850 text-neutral-200 border border-neutral-800 font-semibold text-xs py-3 px-6 rounded-md uppercase tracking-wider transition-all flex items-center gap-2"
                  >
                    Hire Quantitative Experts <ArrowRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => { setRole('creator'); setView('creator-dashboard'); }}
                    className="bg-neutral-950 hover:bg-neutral-900 border border-neutral-800 text-amber-500 font-semibold text-xs py-3 px-6 rounded-md uppercase tracking-wider transition-all flex items-center gap-2"
                  >
                    Sell Digital Products <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </section>

            {/* Spotlight 1: Trending Digital Spot Products */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
              <div className="flex justify-between items-end border-b border-neutral-900 pb-4">
                <div>
                  <h3 className="text-lg font-bold uppercase tracking-wide font-sans text-white">Trending Digital Spot Products</h3>
                  <p className="text-neutral-500 text-xs font-mono uppercase mt-0.5">Instant secure download with license validation keys</p>
                </div>
                <button
                  onClick={() => setView('marketplace')}
                  className="text-xs font-mono text-neutral-400 hover:text-white hover:underline uppercase flex items-center gap-1"
                >
                  View full exchange catalog <ArrowUpRight className="w-4 h-4 text-blue-500" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {trendingProducts.map((prod) => (
                  <div
                    key={prod.id}
                    onClick={() => viewProductDetails(prod)}
                    className="bg-neutral-950 border border-neutral-900 rounded-xl overflow-hidden hover:border-neutral-800 transition-all flex flex-col group cursor-pointer shadow-md"
                  >
                    <div className="relative h-44 bg-neutral-900 overflow-hidden">
                      <img src={prod.image} alt={prod.title} className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500" />
                      <span className="absolute top-3 left-3 bg-neutral-950/80 backdrop-blur-md px-2 py-0.5 rounded text-[10px] font-mono text-neutral-300 border border-neutral-800">
                        {prod.category}
                      </span>
                    </div>
                    <div className="p-4 flex-grow flex flex-col space-y-2 font-sans">
                      <div className="flex justify-between items-start gap-2">
                        <h4 className="text-xs font-bold text-white group-hover:text-blue-400 transition-colors line-clamp-1">{prod.title}</h4>
                        <span className="font-mono text-xs font-bold text-white">${prod.price}</span>
                      </div>
                      <p className="text-[11px] text-neutral-400 line-clamp-2 leading-relaxed flex-grow">{prod.description}</p>
                      <div className="flex items-center gap-1.5 text-[11px] text-neutral-500 pt-2 border-t border-neutral-900">
                        <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                        <span className="text-white font-bold">{prod.rating}</span>
                        <span>({prod.reviewsCount} DLs)</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Spotlight 2: Expert Consultants Spotlight */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
              <div className="flex justify-between items-end border-b border-neutral-900 pb-4">
                <div>
                  <h3 className="text-lg font-bold uppercase tracking-wide font-sans text-white">Top Quantitative & Tech Consultants</h3>
                  <p className="text-neutral-500 text-xs font-mono uppercase mt-0.5">On-demand professional hours backed by GDX Escrow security</p>
                </div>
                <button
                  onClick={() => setView('services')}
                  className="text-xs font-mono text-neutral-400 hover:text-white hover:underline uppercase flex items-center gap-1"
                >
                  Inspect experts list <ArrowUpRight className="w-4 h-4 text-blue-500" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {topServices.map((srv) => (
                  <div
                    key={srv.id}
                    onClick={() => viewServiceDetails(srv)}
                    className="bg-neutral-950 border border-neutral-900 rounded-xl p-5 hover:border-neutral-850 transition-all flex flex-col space-y-4 cursor-pointer shadow-md"
                  >
                    <div className="flex items-center gap-3">
                      <img src={srv.creatorAvatar} alt={srv.creatorName} className="w-10 h-10 rounded-full object-cover border border-neutral-800" />
                      <div>
                        <h4 className="text-xs font-bold text-white uppercase">{srv.creatorName}</h4>
                        <p className="text-[10px] text-neutral-500 font-mono">Response Time: {srv.responseTime}</p>
                      </div>
                    </div>
                    <h5 className="text-xs font-bold text-white line-clamp-1">{srv.title}</h5>
                    <p className="text-[11px] text-neutral-400 line-clamp-2 leading-relaxed flex-grow">{srv.description}</p>
                    <div className="flex justify-between items-center text-[10px] font-mono text-neutral-500 pt-2 border-t border-neutral-900">
                      <span>Starting Price: <span className="text-white font-bold">${srv.startingPrice}</span></span>
                      <span>SLA: Verified</span>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Spotlight 3: Today's Promotions / Campaign Banner */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="bg-gradient-to-r from-blue-950/40 via-neutral-950 to-blue-950/40 border border-blue-900/20 rounded-2xl p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
                <div className="space-y-2 max-w-2xl text-left">
                  <span className="bg-blue-900/50 border border-blue-500/20 text-blue-300 text-[10px] font-mono font-bold px-2.5 py-0.5 rounded uppercase">
                    Platform Promo Alert
                  </span>
                  <h4 className="text-lg font-bold text-white uppercase font-sans">
                    Wall Street Q3 Financial Solutions campaign
                  </h4>
                  <p className="text-xs text-neutral-400 leading-relaxed font-light">
                    Apply code <span className="font-mono text-white font-bold bg-neutral-900 px-1.5 py-0.5 rounded border border-neutral-800">WALLSTREET20</span> at checkout to receive **20%** off all digital Spot digital assets, NextJS templates, and verified gRPC options servers.
                  </p>
                </div>
                <button
                  onClick={() => setView('marketplace')}
                  className="bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs py-2.5 px-5 rounded uppercase tracking-wider transition-all shrink-0 shadow-md"
                >
                  Acquire spot assets
                </button>
              </div>
            </section>

          </div>
        )}

        {/* VIEW 2: Spot Assets Marketplace */}
        {currentView === 'marketplace' && (
          <Marketplace
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            addToCart={addToCart}
            cart={cart}
            viewProduct={viewProductDetails}
            viewService={viewServiceDetails}
          />
        )}

        {/* VIEW 3: Consulting Services Marketplace */}
        {currentView === 'services' && (
          <Marketplace
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            addToCart={addToCart}
            cart={cart}
            viewProduct={viewProductDetails}
            viewService={viewServiceDetails}
          />
        )}

        {/* VIEW 4: Product Detail Page */}
        {currentView === 'product-page' && selectedProduct && (
          <ProductPage
            product={selectedProduct}
            goBack={() => setView('marketplace')}
            addToCart={addToCart}
            cart={cart}
          />
        )}

        {/* VIEW 5: Service Detail Page */}
        {currentView === 'service-page' && selectedService && (
          <ServicePage
            service={selectedService}
            goBack={() => setView('services')}
            addToCart={addToCart}
            cart={cart}
            submitConsultingProposal={submitConsultingProposal}
          />
        )}

        {/* VIEW 6: Customer Downloads Dashboard */}
        {currentView === 'customer-dashboard' && (
          <CustomerDashboard
            orders={orders}
            savedItems={savedItems}
            removeSavedItem={removeSavedItem}
            approveProjectMilestone={approveProjectMilestone}
            invoices={invoices}
          />
        )}

        {/* VIEW 7: Creator Dashboard Studio */}
        {currentView === 'creator-dashboard' && (
          <CreatorDashboard
            products={productsList}
            services={servicesList}
            addNewProduct={addNewProduct}
            addNewService={addNewService}
            orders={orders}
            processRefund={processRefund}
            creatorEarnings={creatorEarnings}
          />
        )}

        {/* VIEW 8: Enterprise Procurement Hub */}
        {currentView === 'enterprise-hub' && (
          <EnterpriseHub
            seats={enterpriseSeats}
            addSeat={addSeat}
            revokeSeat={revokeSeat}
            invoices={invoices}
            pendingApprovals={pendingProcurements}
            approveProcurement={approveProcurement}
            orders={orders}
          />
        )}

        {/* VIEW 9: Community Forums */}
        {currentView === 'community' && (
          <Community />
        )}

        {/* VIEW 10: Architectural GDX Docs */}
        {currentView === 'docs' && (
          <GDXDocs />
        )}

      </main>

      {/* Dynamic Footer */}
      <Footer setView={setView} setRole={setRole} />

    </div>
  );
}
