import React from "react";
import { 
  INITIAL_CAPITAL, 
  BASE_REGULATORY_REQUIREMENTS, 
  INITIAL_PORTFOLIOS, 
  DEFAULT_AUDIT_LOGS,
  DEFAULT_USER
} from "./data/defaultData";
import { 
  CapitalMetrics, 
  PortfolioSegment, 
  RegulatoryRequirements, 
  EngineAuditLog, 
  SecurityUser, 
  SecurityRole 
} from "./types";

// Import all subcomponents
import ExecutiveOverview from "./components/ExecutiveOverview";
import CapitalPosition from "./components/CapitalPosition";
import PortfolioAnalytics from "./components/PortfolioAnalytics";
import ForecastCentre from "./components/ForecastCentre";
import StressTesting from "./components/StressTesting";
import ScenarioLaboratory from "./components/ScenarioLaboratory";
import RegionalAnalysis from "./components/RegionalAnalysis";
import DataImport from "./components/DataImport";
import ReportsCentre from "./components/ReportsCentre";
import RustRConsole from "./components/RustRConsole";

import { 
  LayoutDashboard, 
  Coins, 
  FolderLock, 
  TrendingUp, 
  Flame, 
  Sliders, 
  Map, 
  DatabaseBackup, 
  FileText, 
  Terminal,
  Shield, 
  UserCheck, 
  Settings, 
  BellRing,
  Volume2
} from "lucide-react";

export default function App() {
  
  // Platform financial & configuration states
  const [metrics, setMetrics] = React.useState<CapitalMetrics>(INITIAL_CAPITAL);
  const [portfolios, setPortfolios] = React.useState<PortfolioSegment[]>(INITIAL_PORTFOLIOS);
  const [requirements, setRequirements] = React.useState<RegulatoryRequirements>(BASE_REGULATORY_REQUIREMENTS);
  const [auditLogs, setAuditLogs] = React.useState<EngineAuditLog[]>(DEFAULT_AUDIT_LOGS);
  
  // Security & active UI states
  const [user, setUser] = React.useState<SecurityUser>(DEFAULT_USER);
  const [activeTab, setActiveTab] = React.useState<string>("overview");
  const [showSecurityConfig, setShowSecurityConfig] = React.useState<boolean>(false);
  const [tickerMessage, setTickerMessage] = React.useState<string>(
    "Bank of England FPC maintains Countercyclical Capital Buffer (CCyB) at 1.0% | Basel IV transitional rules fully loaded"
  );

  // Append new audit log helper
  const addAuditLog = (action: string, details: string) => {
    const newLog: EngineAuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      user: user.email,
      system: "Regulatory Rules",
      action,
      status: "Success",
      executionTimeMs: parseFloat((Math.random() * 5 + 1).toFixed(1)),
      details
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  const handleUpdateMetrics = (newMetrics: Partial<CapitalMetrics>) => {
    setMetrics(prev => ({ ...prev, ...newMetrics }));
  };

  const handleUpdatePortfolios = (newPorts: PortfolioSegment[]) => {
    setPortfolios(newPorts);
  };

  // Automated rotating BoE advisory ticker tape
  React.useEffect(() => {
    const alerts = [
      "Bank of England FPC maintains Countercyclical Capital Buffer (CCyB) at 1.0% | Basel IV transitional rules fully loaded",
      "PRA Advisory: Real estate risk factors closely monitored under stagflation stress vectors.",
      "Prudential Audit: Capital reconciliation verified at 0.00% ledger variance.",
      "Rhino Capital Engine: Compiled Rust binary reports average execution latency under 320µs."
    ];
    let idx = 0;
    const interval = setInterval(() => {
      idx = (idx + 1) % alerts.length;
      setTickerMessage(alerts[idx]);
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#e5e1d8] flex flex-col font-sans selection:bg-[#c08267]/30">
      
      {/* Top Navigation Banner */}
      <header className="bg-[#0d0d0d] border-b border-[#333] px-6 py-4 flex justify-between items-center shrink-0 print:hidden" id="main-header">
        
        {/* Brand identity */}
        <div className="flex items-center gap-3">
          <div className="bg-[#c08267] text-[#0a0a0a] p-1.5 font-black text-sm tracking-tighter uppercase font-serif select-none">
            RC
          </div>
          <div>
            <div className="font-serif text-lg tracking-tight font-extrabold text-[#e5e1d8] flex items-center gap-2">
              <span className="italic font-light text-[#c08267] tracking-tighter">RHINOCAPITAL</span>
              <span className="text-[10px] font-mono bg-[#1a1a1a] text-[#c08267] border border-[#333] px-1.5 py-0.5 rounded uppercase font-semibold">PRUDENTIAL SYSTEM</span>
            </div>
            <div className="text-[10px] text-[#8e887e] uppercase tracking-[0.2em] font-semibold mt-0.5">Enterprise Prudential Systems</div>
          </div>
        </div>

        {/* Action Controls & Security indicators */}
        <div className="flex items-center gap-4">
          
          {/* Security status block */}
          <div 
            onClick={() => setShowSecurityConfig(!showSecurityConfig)}
            className="bg-[#1C1F22] border border-[#2D3339] rounded px-3.5 py-1.5 flex items-center gap-2.5 cursor-pointer hover:border-[#D97706]/40 transition"
          >
            <Shield className="w-4 h-4 text-[#D97706]" />
            <div className="text-left">
              <div className="text-[9px] text-[#A9A397] uppercase tracking-wider font-semibold">User Role: {user.role}</div>
              <div className="text-xs font-mono text-[#EFECE6] flex items-center gap-1.5">
                {user.email}
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              </div>
            </div>
          </div>

          <button 
            onClick={() => setShowSecurityConfig(!showSecurityConfig)}
            className="p-2 text-[#A9A397] hover:text-[#EFECE6] transition"
            title="System Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>

      </header>

      {/* Main Layout Workspace with responsive sidebar */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        
        {/* Desktop Sidebar Navigation - hidden in print */}
        <aside className="w-full md:w-64 bg-[#0d0d0d] border-r border-[#333] flex flex-col justify-between shrink-0 print:hidden" id="sidebar-navigation">
          <div className="py-4 space-y-1">
            <span className="px-5 text-[9px] text-[#8E887E] uppercase tracking-widest block mb-2 font-bold">Main Dashboard</span>
            
            {/* Nav 1: Overview */}
            <button
              onClick={() => { setActiveTab("overview"); setShowSecurityConfig(false); }}
              className={`w-full text-left px-5 py-2.5 text-xs font-semibold flex items-center gap-3 transition ${
                activeTab === "overview" && !showSecurityConfig
                  ? "bg-[#1C1F22] text-[#EFECE6] border-l-2 border-[#D97706]"
                  : "text-[#A9A397] hover:text-[#EFECE6] hover:bg-[#1C1F22]/40"
              }`}
            >
              <LayoutDashboard className="w-4 h-4 text-[#D97706]" /> Executive Overview
            </button>

            {/* Nav 2: Capital Tiers */}
            <button
              onClick={() => { setActiveTab("capital"); setShowSecurityConfig(false); }}
              className={`w-full text-left px-5 py-2.5 text-xs font-semibold flex items-center gap-3 transition ${
                activeTab === "capital" && !showSecurityConfig
                  ? "bg-[#1C1F22] text-[#EFECE6] border-l-2 border-[#D97706]"
                  : "text-[#A9A397] hover:text-[#EFECE6] hover:bg-[#1C1F22]/40"
              }`}
            >
              <Coins className="w-4 h-4 text-[#6F7F91]" /> Capital Positions
            </button>

            {/* Nav 3: Portfolio Weights */}
            <button
              onClick={() => { setActiveTab("portfolio"); setShowSecurityConfig(false); }}
              className={`w-full text-left px-5 py-2.5 text-xs font-semibold flex items-center gap-3 transition ${
                activeTab === "portfolio" && !showSecurityConfig
                  ? "bg-[#1C1F22] text-[#EFECE6] border-l-2 border-[#D97706]"
                  : "text-[#A9A397] hover:text-[#EFECE6] hover:bg-[#1C1F22]/40"
              }`}
            >
              <FolderLock className="w-4 h-4 text-[#6F7F91]" /> Risk Weight Engine
            </button>

            <span className="px-5 text-[9px] text-[#8E887E] uppercase tracking-widest block pt-4 mb-2 font-bold">Predictive Models</span>

            {/* Nav 4: Forecast Centre */}
            <button
              onClick={() => { setActiveTab("forecast"); setShowSecurityConfig(false); }}
              className={`w-full text-left px-5 py-2.5 text-xs font-semibold flex items-center gap-3 transition ${
                activeTab === "forecast" && !showSecurityConfig
                  ? "bg-[#1C1F22] text-[#EFECE6] border-l-2 border-[#D97706]"
                  : "text-[#A9A397] hover:text-[#EFECE6] hover:bg-[#1C1F22]/40"
              }`}
            >
              <TrendingUp className="w-4 h-4 text-[#D97706]" /> Capital Forecasting
            </button>

            {/* Nav 5: Stress Testing */}
            <button
              onClick={() => { setActiveTab("stress"); setShowSecurityConfig(false); }}
              className={`w-full text-left px-5 py-2.5 text-xs font-semibold flex items-center gap-3 transition ${
                activeTab === "stress" && !showSecurityConfig
                  ? "bg-[#1C1F22] text-[#EFECE6] border-l-2 border-[#D97706]"
                  : "text-[#A9A397] hover:text-[#EFECE6] hover:bg-[#1C1F22]/40"
              }`}
            >
              <Flame className="w-4 h-4 text-[#D97706]" /> Stress Testing
            </button>

            {/* Nav 6: Scenario Laboratory */}
            <button
              onClick={() => { setActiveTab("laboratory"); setShowSecurityConfig(false); }}
              className={`w-full text-left px-5 py-2.5 text-xs font-semibold flex items-center gap-3 transition ${
                activeTab === "laboratory" && !showSecurityConfig
                  ? "bg-[#1C1F22] text-[#EFECE6] border-l-2 border-[#D97706]"
                  : "text-[#A9A397] hover:text-[#EFECE6] hover:bg-[#1C1F22]/40"
              }`}
            >
              <Sliders className="w-4 h-4 text-[#6F7F91]" /> Scenario Laboratory
            </button>

            <span className="px-5 text-[9px] text-[#8E887E] uppercase tracking-widest block pt-4 mb-2 font-bold">Data & Reporting</span>

            {/* Nav 7: Regional Concentr */}
            <button
              onClick={() => { setActiveTab("regional"); setShowSecurityConfig(false); }}
              className={`w-full text-left px-5 py-2.5 text-xs font-semibold flex items-center gap-3 transition ${
                activeTab === "regional" && !showSecurityConfig
                  ? "bg-[#1C1F22] text-[#EFECE6] border-l-2 border-[#D97706]"
                  : "text-[#A9A397] hover:text-[#EFECE6] hover:bg-[#1C1F22]/40"
              }`}
            >
              <Map className="w-4 h-4 text-[#6F7F91]" /> Regional Credit
            </button>

            {/* Nav 8: Data Gateway */}
            <button
              onClick={() => { setActiveTab("import"); setShowSecurityConfig(false); }}
              className={`w-full text-left px-5 py-2.5 text-xs font-semibold flex items-center gap-3 transition ${
                activeTab === "import" && !showSecurityConfig
                  ? "bg-[#1C1F22] text-[#EFECE6] border-l-2 border-[#D97706]"
                  : "text-[#A9A397] hover:text-[#EFECE6] hover:bg-[#1C1F22]/40"
              }`}
            >
              <DatabaseBackup className="w-4 h-4 text-[#D97706]" /> Data Gateway
            </button>

            {/* Nav 9: Reports Centre */}
            <button
              onClick={() => { setActiveTab("reports"); setShowSecurityConfig(false); }}
              className={`w-full text-left px-5 py-2.5 text-xs font-semibold flex items-center gap-3 transition ${
                activeTab === "reports" && !showSecurityConfig
                  ? "bg-[#1C1F22] text-[#EFECE6] border-l-2 border-[#D97706]"
                  : "text-[#A9A397] hover:text-[#EFECE6] hover:bg-[#1C1F22]/40"
              }`}
            >
              <FileText className="w-4 h-4 text-[#D97706]" /> Reports Archive
            </button>

            {/* Nav 10: R/Rust Developer console */}
            <button
              onClick={() => { setActiveTab("developer"); setShowSecurityConfig(false); }}
              className={`w-full text-left px-5 py-2.5 text-xs font-semibold flex items-center gap-3 transition ${
                activeTab === "developer" && !showSecurityConfig
                  ? "bg-[#1C1F22] text-[#EFECE6] border-l-2 border-[#D97706]"
                  : "text-[#A9A397] hover:text-[#EFECE6] hover:bg-[#1C1F22]/40"
              }`}
            >
              <Terminal className="w-4 h-4 text-[#6F7F91]" /> Developer Console
            </button>
          </div>

          {/* Quick status footprint */}
          <div className="p-4 border-t border-[#2D3339] bg-[#121416]/40 text-[10px] text-[#8E887E] space-y-1 font-mono">
            <div>Engine Status: Running</div>
            <div>Latest Ledger: 2026-07-28</div>
            <div>PRA Guideline: Basel IV</div>
          </div>
        </aside>

        {/* Content Workspace */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8 bg-[#111315]">
          
          {/* Security & Access Management panel */}
          {showSecurityConfig ? (
            <div className="space-y-6" id="security-panel">
              <div className="border-b border-[#2D3339] pb-4">
                <span className="text-xs uppercase tracking-widest text-[#D97706] font-semibold">SECURITY ACCESS</span>
                <h2 className="text-2xl font-serif text-[#EFECE6] mt-1 tracking-tight">Identity & Multi-Factor Access</h2>
                <p className="text-[#A9A397] text-xs mt-1">Configure role levels, MFA locks, and examine platform access audit ledger logs.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Switch roles panel */}
                <div className="bg-[#181B1E] border border-[#2D3339] p-5 space-y-4">
                  <h3 className="font-serif text-[#EFECE6] text-base">Select Active Role Profile</h3>
                  
                  <div className="space-y-3.5">
                    {[
                      { 
                        role: SecurityRole.TreasuryDirector, 
                        desc: "Full portfolio write clearance, debt/equity issuance capability, and regulatory report sign-off.",
                        tag: "Director Level"
                      },
                      { 
                        role: SecurityRole.RiskQuantitativeAnalyst, 
                        desc: "Adjust and tune risk-weight coefficients, execute R forecasting scripts, and review stress models.",
                        tag: "Quant Officer"
                      },
                      { 
                        role: SecurityRole.Executive, 
                        desc: "Read-only access to board-level capital dashboards and generated PDF-ready reports.",
                        tag: "Board Member"
                      }
                    ].map(prof => (
                      <div 
                        key={prof.role}
                        onClick={() => {
                          setUser(prev => ({ ...prev, role: prof.role }));
                          addAuditLog("Security Role Switched", `Active identity upgraded to ${prof.role} class.`);
                        }}
                        className={`p-4 border cursor-pointer transition rounded ${
                          user.role === prof.role 
                            ? "bg-[#1C1F22] border-[#D97706]" 
                            : "bg-[#121416]/40 border-[#2D3339] hover:border-[#D97706]/30"
                        }`}
                      >
                        <div className="flex justify-between items-center">
                          <span className="text-xs font-bold text-[#EFECE6]">{prof.role}</span>
                          <span className="text-[10px] font-mono text-[#D97706] bg-[#D97706]/10 px-1.5 py-0.5 rounded">{prof.tag}</span>
                        </div>
                        <p className="text-[11px] text-[#8E887E] mt-1.5 leading-relaxed">{prof.desc}</p>
                      </div>
                    ))}
                  </div>

                  {/* Toggle MFA */}
                  <div className="pt-4 border-t border-[#2D3339] flex justify-between items-center">
                    <div className="space-y-0.5">
                      <span className="text-xs font-semibold text-[#EFECE6]">Enforce Multi-Factor (MFA) Lock</span>
                      <p className="text-[10px] text-[#8E887E]">Prompts secure hardware key confirmation during high-value capital releases.</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const mfa = !user.mfaEnabled;
                        setUser(prev => ({ ...prev, mfaEnabled: mfa }));
                        addAuditLog("MFA Configuration Shifted", `Multi-factor authorization constraints set to ${mfa ? 'ENFORCED' : 'BYPASSED'}.`);
                      }}
                      className={`w-12 h-6 rounded-full p-1 transition-colors ${
                        user.mfaEnabled ? "bg-[#D97706]" : "bg-[#121416] border border-[#2D3339]"
                      }`}
                    >
                      <div className={`w-4 h-4 rounded-full bg-[#1C1F22] transition-transform ${user.mfaEnabled ? "translate-x-6 bg-[#EFECE6]" : "translate-x-0"}`} />
                    </button>
                  </div>
                </div>

                {/* Audit logging stack */}
                <div className="bg-[#181B1E] border border-[#2D3339] p-5 flex flex-col justify-between">
                  <div>
                    <h3 className="font-serif text-[#EFECE6] text-base mb-3 flex items-center gap-2">
                      <UserCheck className="w-5 h-5 text-[#D97706]" /> Immutable Security Log
                    </h3>
                    
                    <div className="space-y-3.5 max-h-[340px] overflow-y-auto pr-1">
                      {auditLogs.map((log) => (
                        <div key={log.id} className="p-2.5 bg-[#121416] border border-[#2D3339]/60 rounded text-[11px]">
                          <div className="flex justify-between font-mono text-[9px] text-[#8E887E] mb-1">
                            <span>{log.timestamp}</span>
                            <span className="text-[#D97706] font-bold">{log.system}</span>
                          </div>
                          <div className="font-semibold text-[#EFECE6]">{log.action}</div>
                          <p className="text-[#8E887E] mt-0.5 leading-relaxed">{log.details}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

              </div>
            </div>
          ) : (
            <>
              {/* Tab Content Router */}
              {activeTab === "overview" && (
                <ExecutiveOverview 
                  metrics={metrics} 
                  requirements={requirements} 
                  portfolios={portfolios} 
                  onNavigate={setActiveTab} 
                />
              )}
              
              {activeTab === "capital" && (
                <CapitalPosition 
                  metrics={metrics} 
                  requirements={requirements} 
                  onUpdateMetrics={handleUpdateMetrics} 
                  onAddAuditLog={addAuditLog}
                />
              )}

              {activeTab === "portfolio" && (
                <PortfolioAnalytics 
                  portfolios={portfolios} 
                  metrics={metrics} 
                  onUpdatePortfolios={handleUpdatePortfolios} 
                  onUpdateMetrics={handleUpdateMetrics} 
                  onAddAuditLog={addAuditLog}
                />
              )}

              {activeTab === "forecast" && (
                <ForecastCentre 
                  metrics={metrics} 
                  onAddAuditLog={addAuditLog} 
                />
              )}

              {activeTab === "stress" && (
                <StressTesting 
                  metrics={metrics} 
                  portfolios={portfolios} 
                  onAddAuditLog={addAuditLog} 
                />
              )}

              {activeTab === "laboratory" && (
                <ScenarioLaboratory 
                  metrics={metrics} 
                  requirements={requirements} 
                  onAddAuditLog={addAuditLog} 
                />
              )}

              {activeTab === "regional" && (
                <RegionalAnalysis 
                  onAddAuditLog={addAuditLog} 
                />
              )}

              {activeTab === "import" && (
                <DataImport 
                  portfolios={portfolios} 
                  metrics={metrics} 
                  onUpdatePortfolios={handleUpdatePortfolios} 
                  onUpdateMetrics={handleUpdateMetrics} 
                  onAddAuditLog={addAuditLog} 
                />
              )}

              {activeTab === "reports" && (
                <ReportsCentre 
                  metrics={metrics} 
                  requirements={requirements} 
                  portfolios={portfolios} 
                  onAddAuditLog={addAuditLog} 
                />
              )}

              {activeTab === "developer" && (
                <RustRConsole 
                  onAddAuditLog={addAuditLog} 
                />
              )}
            </>
          )}

        </main>
      </div>

      {/* Ticker tape warning advisory - hidden in print */}
      <footer className="bg-[#16191C] border-t border-[#2D3339] h-10 px-6 flex items-center justify-between overflow-hidden text-[11px] shrink-0 print:hidden">
        <div className="flex items-center gap-2 text-[#D97706] shrink-0 font-bold uppercase tracking-wider select-none">
          <BellRing className="w-3.5 h-3.5 animate-bounce" />
          <span>PRA Advisory:</span>
        </div>
        
        {/* Scrolling tape */}
        <div className="flex-1 mx-4 overflow-hidden relative">
          <span className="inline-block text-[#A9A397] font-mono whitespace-nowrap animate-[marquee_25s_linear_infinite]">
            {tickerMessage}
          </span>
        </div>

        <div className="shrink-0 text-[#8E887E] font-mono text-[10px]">
          UTC Clock: 2026-07-28
        </div>
      </footer>

    </div>
  );
}
