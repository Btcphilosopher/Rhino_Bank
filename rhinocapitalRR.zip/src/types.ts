export enum SecurityRole {
  Executive = "Executive",
  RiskQuantitativeAnalyst = "Risk Quantitative Analyst",
  TreasuryDirector = "Treasury Director"
}

export interface SecurityUser {
  email: string;
  role: SecurityRole;
  mfaEnabled: boolean;
  sessionToken: string;
}

export interface CapitalMetrics {
  cet1Capital: number;       // Common Equity Tier 1
  at1Capital: number;        // Additional Tier 1
  tier2Capital: number;      // Tier 2
  rwa: number;               // Total Risk-Weighted Assets
  ead: number;               // Total Exposure at Default
  expectedLoss: number;      // Expected Loss
}

export interface RegulatoryRequirements {
  minCet1: number;           // Basel III Minimum CET1 (4.5%)
  ccbRequirement: number;    // Capital Conservation Buffer (2.5%)
  ccybRequirement: number;   // Countercyclical Capital Buffer (varies, e.g. 1.0%)
  sifiRequirement: number;    // Systemically Important Financial Institution Buffer (e.g. 1.0%)
}

export interface PortfolioSegment {
  id: string;
  name: string;
  category: "Corporate" | "CRE" | "Mortgages" | "SME" | "Treasury" | "Securities" | "Other";
  exposure: number;          // Exposure at Default (EAD) in GBP
  riskWeightDefault: number; // Default Risk Weight (e.g. 0.75 for 75%)
  riskWeightCurrent: number; // Configured Risk Weight for simulation
  pd: number;                // Probability of Default (%)
  lgd: number;               // Loss Given Default (%)
  region: string;            // Region (e.g. Yorkshire, North West, London, Scotland, Midlands)
  sector?: string;           // Industry sector
}

export interface StressScenario {
  id: string;
  name: string;
  type: "Baseline" | "Adverse" | "Severe";
  description: string;
  gdpImpact: string;
  housePriceIndexChange: number; // % change
  creIndexChange: number;        // % change
  defaultRateMultiplier: number;  // PD multiplier
  lgdMultiplier: number;          // LGD multiplier
  interestRateShockBps: number;  // basis points
  fundingCostPremiumBps: number; // basis points
}

export interface ForecastParameters {
  years: number;
  annualAssetGrowth: number;     // % per year
  netInterestMargin: number;     // % of assets
  creditLossRate: number;        // % of total exposure
  dividendPayoutRatio: number;   // % of net income paid as dividend
  additionalCapitalRaised: number; // GBP in millions
}

export interface ScenarioLaboratoryAction {
  id: string;
  name: string;
  description: string;
  active: boolean;
  impactEAD: number;            // EAD change in GBP millions
  impactRW: number;             // Risk Weight delta (absolute e.g. -0.10)
  impactCET1: number;           // Capital change in GBP millions
}

export interface EngineAuditLog {
  id: string;
  timestamp: string;
  user: string;
  system: "Rust Core" | "R Shiny" | "Data Gateway" | "Regulatory Rules";
  action: string;
  status: "Success" | "Warning" | "Error";
  executionTimeMs: number;
  details: string;
}
