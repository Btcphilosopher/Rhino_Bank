import { 
  PortfolioSegment, 
  CapitalMetrics, 
  RegulatoryRequirements, 
  StressScenario, 
  ScenarioLaboratoryAction, 
  EngineAuditLog,
  SecurityUser,
  SecurityRole
} from "../types";

export const DEFAULT_USER: SecurityUser = {
  email: "tom@ahyx.org",
  role: SecurityRole.TreasuryDirector,
  mfaEnabled: true,
  sessionToken: "RC-8794-X8B9"
};

export const INITIAL_CAPITAL: CapitalMetrics = {
  cet1Capital: 2950,       // GBP Millions
  at1Capital: 450,         // GBP Millions
  tier2Capital: 600,       // GBP Millions
  rwa: 18450,              // GBP Millions
  ead: 47000,              // GBP Millions
  expectedLoss: 218.4      // GBP Millions
};

export const BASE_REGULATORY_REQUIREMENTS: RegulatoryRequirements = {
  minCet1: 0.045,          // 4.5%
  ccbRequirement: 0.025,   // 2.5%
  ccybRequirement: 0.010,  // 1.0%
  sifiRequirement: 0.010   // 1.0% (Rhino Bank is a domestically systemic retail/commercial anchor)
};

export const INITIAL_PORTFOLIOS: PortfolioSegment[] = [
  {
    id: "port-corp-01",
    name: "UK Large Corporates",
    category: "Corporate",
    exposure: 10500,
    riskWeightDefault: 0.85,
    riskWeightCurrent: 0.85,
    pd: 1.8,
    lgd: 45,
    region: "Yorkshire",
    sector: "Manufacturing & Infrastructure"
  },
  {
    id: "port-corp-02",
    name: "London Real Estate Corporate Loans",
    category: "Corporate",
    exposure: 3500,
    riskWeightDefault: 0.90,
    riskWeightCurrent: 0.90,
    pd: 2.2,
    lgd: 40,
    region: "London",
    sector: "Commercial Real Estate Finance"
  },
  {
    id: "port-cre-01",
    name: "Northern Powerhouse CRE Portfolio",
    category: "CRE",
    exposure: 4800,
    riskWeightDefault: 1.00,
    riskWeightCurrent: 1.00,
    pd: 2.5,
    lgd: 55,
    region: "Yorkshire",
    sector: "Logistics & Retail Warehousing"
  },
  {
    id: "port-cre-02",
    name: "Southern Regional CRE",
    category: "CRE",
    exposure: 3400,
    riskWeightDefault: 1.10,
    riskWeightCurrent: 1.10,
    pd: 2.9,
    lgd: 50,
    region: "Midlands",
    sector: "Offices & Mixed-Use Development"
  },
  {
    id: "port-mort-01",
    name: "Yorkshire Residential Mortgages",
    category: "Mortgages",
    exposure: 10200,
    riskWeightDefault: 0.35,
    riskWeightCurrent: 0.35,
    pd: 0.5,
    lgd: 15,
    region: "Yorkshire",
    sector: "Owner-Occupied Residential"
  },
  {
    id: "port-mort-02",
    name: "London & South Prime Mortgages",
    category: "Mortgages",
    exposure: 6600,
    riskWeightDefault: 0.32,
    riskWeightCurrent: 0.32,
    pd: 0.4,
    lgd: 12,
    region: "London",
    sector: "Owner-Occupied Prime Residential"
  },
  {
    id: "port-sme-01",
    name: "Yorkshire SME Business Line",
    category: "SME",
    exposure: 2800,
    riskWeightDefault: 0.75,
    riskWeightCurrent: 0.75,
    pd: 3.2,
    lgd: 40,
    region: "Yorkshire",
    sector: "Local Commerce & Engineering"
  },
  {
    id: "port-sme-02",
    name: "North West SME Lending",
    category: "SME",
    exposure: 1700,
    riskWeightDefault: 0.75,
    riskWeightCurrent: 0.75,
    pd: 3.5,
    lgd: 40,
    region: "North West",
    sector: "Services & Tech Startups"
  },
  {
    id: "port-treas-01",
    name: "HQLA Treasury Gilts",
    category: "Treasury",
    exposure: 3800,
    riskWeightDefault: 0.00,
    riskWeightCurrent: 0.00,
    pd: 0.01,
    lgd: 5,
    region: "Yorkshire",
    sector: "Sovereign Debt (UK Gilts)"
  },
  {
    id: "port-sec-01",
    name: "High-Grade Liquid Securities",
    category: "Securities",
    exposure: 1200,
    riskWeightDefault: 0.20,
    riskWeightCurrent: 0.20,
    pd: 0.15,
    lgd: 25,
    region: "London",
    sector: "Multilateral Dev Banks & RMBS"
  },
  {
    id: "port-oth-01",
    name: "Fixed Assets & Residual Banking Book",
    category: "Other",
    exposure: 1000,
    riskWeightDefault: 1.00,
    riskWeightCurrent: 1.00,
    pd: 1.5,
    lgd: 50,
    region: "Yorkshire",
    sector: "Infrastructure & Physical Estates"
  }
];

export const STRESS_SCENARIOS: StressScenario[] = [
  {
    id: "scen-base",
    name: "Baseline Projection",
    type: "Baseline",
    description: "Stable regional growth, gradual inflation cooling, and standard BoE base rate normalization. Credit spreads remain tightly bounded.",
    gdpImpact: "GDP +1.8% / year",
    housePriceIndexChange: 2.5,
    creIndexChange: 1.0,
    defaultRateMultiplier: 1.0,
    lgdMultiplier: 1.0,
    interestRateShockBps: 0,
    fundingCostPremiumBps: 0
  },
  {
    id: "scen-adv",
    name: "Adverse Stagflation",
    type: "Adverse",
    description: "Macroeconomic stagnation driven by a secondary energy price shock, forcing the BoE to raise rates despite negative growth. Credit parameters degrade moderately.",
    gdpImpact: "GDP -1.5% in Year 1",
    housePriceIndexChange: -12.0,
    creIndexChange: -18.0,
    defaultRateMultiplier: 1.6,
    lgdMultiplier: 1.15,
    interestRateShockBps: 200,
    fundingCostPremiumBps: 120
  },
  {
    id: "scen-sev",
    name: "Severe 'Yorkshire Winter'",
    type: "Severe",
    description: "A catastrophic systemic stress event. Sharp collapse in Northern manufacturing and real estate. Liquidity freeze in sterling funding markets. Default rates surge, and property collaterals collapse.",
    gdpImpact: "GDP -4.5% in Year 1",
    housePriceIndexChange: -28.0,
    creIndexChange: -42.0,
    defaultRateMultiplier: 2.8,
    lgdMultiplier: 1.35,
    interestRateShockBps: 400,
    fundingCostPremiumBps: 320
  }
];

export const INITIAL_SCENARIO_ACTIONS: ScenarioLaboratoryAction[] = [
  {
    id: "act-01",
    name: "Lending Pivot: Yorkshire SME Focus",
    description: "Reallocate £800M from London corporate loans to Yorkshire SME commercial loans. Capitalizes on the SME supporting factor discount of 0.76x risk-weight, promoting local growth.",
    active: false,
    impactEAD: 0,         // Overall EAD neutral
    impactRW: -0.05,      // Modest RWA reduction due to supporting factor
    impactCET1: 0
  },
  {
    id: "act-02",
    name: "Green Mortgage Risk-Weight Relief",
    description: "Incentivize borrowers with energy-efficient properties. Refinance £2,500M of mortgages into 'Green Mortgage' structures. Reduces regulatory risk weight from 35% to 28% due to lower empirical default probability.",
    active: false,
    impactEAD: 0,
    impactRW: -0.07,
    impactCET1: 0
  },
  {
    id: "act-03",
    name: "Ordinary Equity Issuance Program",
    description: "Execute a targeted capital raise of £350M through institutional equity issuance in the City and local Yorkshire syndicates. Direct boost to CET1 Capital.",
    active: false,
    impactEAD: 0,
    impactRW: 0,
    impactCET1: 350
  },
  {
    id: "act-04",
    name: "Conservative Dividend Retrenchment",
    description: "Reduce dividend payout ratio from 40% to 15%. Retains an extra £180M of annual net earnings directly within Common Equity Tier 1 capital rather than distributing it.",
    active: false,
    impactEAD: 0,
    impactRW: 0,
    impactCET1: 180
  },
  {
    id: "act-05",
    name: "Commercial Real Estate (CRE) De-Risking",
    description: "Run off £1,500M of high-exposure commercial property mortgages and reinvest proceeds in 0%-risk high-quality UK Treasury Gilts. Drops overall portfolio risk exposure rapidly.",
    active: false,
    impactEAD: 0,
    impactRW: -0.22,
    impactCET1: 0
  }
];

export const DEFAULT_AUDIT_LOGS: EngineAuditLog[] = [
  {
    id: "log-01",
    timestamp: "2026-07-28 10:15:22",
    user: "tom@ahyx.org",
    system: "Rust Core",
    action: "Portfolio Asset Re-aggregation",
    status: "Success",
    executionTimeMs: 4.2,
    details: "Aggregated 142,500 individual credit facilities across 11 exposure buckets. Calculated weighted PD/LGD vectors."
  },
  {
    id: "log-02",
    timestamp: "2026-07-28 10:15:23",
    user: "tom@ahyx.org",
    system: "Regulatory Rules",
    action: "Basel IV Risk Weight Calculation",
    status: "Success",
    executionTimeMs: 1.8,
    details: "Computed RWAs using standard credit risk framework. Total RWA: £18,450.00M. Threshold compliance is positive (CET1 15.99%)."
  },
  {
    id: "log-03",
    timestamp: "2026-07-28 10:15:30",
    user: "tom@ahyx.org",
    system: "R Shiny",
    action: "Stress Testing Monte Carlo Engine",
    status: "Success",
    executionTimeMs: 420.5,
    details: "Generated 10,000 credit portfolio loss distributions under Adverse and Severe scenarios. Extracted 99.9% VaR and credit impairment projections."
  },
  {
    id: "log-04",
    timestamp: "2026-07-28 10:15:31",
    user: "System Daemon",
    system: "Data Gateway",
    action: "Daily Treasury Feed Reconciliation",
    status: "Success",
    executionTimeMs: 12.4,
    details: "Reconciled available capital figures with general ledger system. Variance of 0.00% detected. CET1 matches exactly £2,950M."
  }
];

export const HISTORICAL_CET1_TREND = [
  { quarter: "2025-Q1", cet1: 14.2, minReq: 9.0, availableCapital: 2600, rwa: 18310 },
  { quarter: "2025-Q2", cet1: 14.5, minReq: 9.0, availableCapital: 2680, rwa: 18480 },
  { quarter: "2025-Q3", cet1: 14.9, minReq: 9.0, availableCapital: 2750, rwa: 18450 },
  { quarter: "2025-Q4", cet1: 15.3, minReq: 9.0, availableCapital: 2820, rwa: 18430 },
  { quarter: "2026-Q1", cet1: 15.7, minReq: 9.0, availableCapital: 2900, rwa: 18470 },
  { quarter: "2026-Q2", cet1: 15.99, minReq: 9.0, availableCapital: 2950, rwa: 18450 }
];

export const REGIONAL_LENDING_DISTRIBUTION = [
  { region: "Yorkshire", exposure: 28000, percentage: 59.5, color: "#D97706" }, // Copper Accent / local heartland
  { region: "London", exposure: 13300, percentage: 28.3, color: "#162E44" },
  { region: "North West", exposure: 2900, percentage: 6.2, color: "#264B6C" },
  { region: "Midlands", exposure: 1800, percentage: 3.8, color: "#6F7F91" },
  { region: "Scotland", exposure: 1000, percentage: 2.2, color: "#4A5866" }
];
