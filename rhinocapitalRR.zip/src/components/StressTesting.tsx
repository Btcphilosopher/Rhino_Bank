import React from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  ReferenceLine 
} from "recharts";
import { 
  AlertTriangle, 
  Flame, 
  ChevronRight, 
  TrendingDown, 
  CheckCircle2, 
  XOctagon, 
  Gauge 
} from "lucide-react";
import { CapitalMetrics, StressScenario, PortfolioSegment } from "../types";
import { STRESS_SCENARIOS } from "../data/defaultData";

interface StressTestingProps {
  metrics: CapitalMetrics;
  portfolios: PortfolioSegment[];
  onAddAuditLog: (action: string, details: string) => void;
}

export default function StressTesting({ metrics, portfolios, onAddAuditLog }: StressTestingProps) {
  
  // Interactive global stress shock multiplier (allows amplifying or dampening shocks)
  const [shockMultiplier, setShockMultiplier] = React.useState<number>(1.0);
  const [selectedScenarioId, setSelectedScenarioId] = React.useState<string>("scen-sev");

  // Calculate stress effects
  const calculateScenarioImpacts = React.useMemo(() => {
    return STRESS_SCENARIOS.map(scen => {
      // Scale variables based on our interactive shock multiplier (only for non-baseline)
      const multiplier = scen.type === "Baseline" ? 1.0 : shockMultiplier;
      const effectivePDMult = 1.0 + (scen.defaultRateMultiplier - 1.0) * multiplier;
      const effectiveLGDMult = 1.0 + (scen.lgdMultiplier - 1.0) * multiplier;
      const hpiLoss = scen.housePriceIndexChange * multiplier;
      const creLoss = scen.creIndexChange * multiplier;
      
      let stressedLosses = 0;
      let stressedRWA = 0;

      portfolios.forEach(p => {
        // Compute segment-level expected loss under stress
        const basePD = p.pd / 100;
        const baseLGD = p.lgd / 100;
        const stressedPD = Math.min(basePD * effectivePDMult, 0.40); // cap PD at 40%
        const stressedLGD = Math.min(baseLGD * effectiveLGDMult, 0.85); // cap LGD at 85%
        
        const segmentLoss = p.exposure * stressedPD * stressedLGD;
        stressedLosses += segmentLoss;

        // In stress, assets degrade. Low credit-quality assets inflate in risk-weight.
        // We model risk-weight inflation: default risk weight inflates as credit risk spikes
        const rwaInflationFactor = scen.type === "Baseline" ? 1.0 : (1.0 + 0.12 * effectivePDMult);
        const segmentStressedRwa = p.exposure * Math.min(p.riskWeightCurrent * rwaInflationFactor, 1.50);
        stressedRWA += segmentStressedRwa;
      });

      // Capital depletion: Stressed losses are deducted directly from CET1 (and Tier 1)
      const stressedCET1 = Math.max(metrics.cet1Capital - stressedLosses, 200); // floor of £200M
      const stressedCET1Ratio = (stressedCET1 / stressedRWA) * 100;
      
      const totalCapital = stressedCET1 + metrics.at1Capital + metrics.tier2Capital;
      const stressedTotalCapitalRatio = (totalCapital / stressedRWA) * 100;

      return {
        ...scen,
        hpiLoss,
        creLoss,
        stressedLosses: Math.round(stressedLosses),
        stressedRWA: Math.round(stressedRWA),
        stressedCET1: Math.round(stressedCET1),
        stressedCET1Ratio: parseFloat(stressedCET1Ratio.toFixed(2)),
        stressedTotalCapitalRatio: parseFloat(stressedTotalCapitalRatio.toFixed(2)),
      };
    });
  }, [portfolios, metrics, shockMultiplier]);

  const selectedScenario = calculateScenarioImpacts.find(s => s.id === selectedScenarioId) || calculateScenarioImpacts[2];

  // Prepare chart data
  const chartData = calculateScenarioImpacts.map(s => ({
    name: s.name,
    "CET1 Ratio (%)": s.stressedCET1Ratio,
    "Total Capital Ratio (%)": s.stressedTotalCapitalRatio
  }));

  const handleApplyShockMultiplier = (val: number) => {
    setShockMultiplier(val);
    onAddAuditLog(
      "Stress Shock Adjusted",
      `Adjusted global credit downturn shock multiplier to ${val.toFixed(1)}x. Stress losses recalculated.`
    );
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#2D3339] pb-5 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#D97706] font-semibold">PRUDENTIAL VULNERABILITY</span>
          <h1 className="text-3xl font-serif text-[#EFECE6] mt-1 tracking-tight">Macro Stress Testing Framework</h1>
          <p className="text-[#A9A397] text-sm mt-1 max-w-xl">
            Evaluate the structural resilience of Rhino Bank under adverse credit and inflation downturns. Model the impact of residential and CRE asset price shocks.
          </p>
        </div>
      </div>

      {/* Shock Multiplier Adjustment Console */}
      <div className="bg-[#181B1E] border border-[#2D3339] p-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h3 className="text-[#EFECE6] font-serif text-base flex items-center gap-1.5">
            <Flame className="w-5 h-5 text-[#D97706]" />
            Downturn Severity Regulator
          </h3>
          <p className="text-xs text-[#A9A397] mt-1">Magnify or soften the historical parameters of the macro recession scenarios.</p>
        </div>

        <div className="w-full md:w-80 flex items-center gap-4">
          <input
            type="range"
            min="0.5"
            max="2.0"
            step="0.1"
            value={shockMultiplier}
            onChange={(e) => handleApplyShockMultiplier(parseFloat(e.target.value))}
            className="w-full accent-[#D97706] cursor-pointer"
          />
          <div className="font-mono text-center shrink-0">
            <span className="text-[10px] text-[#A9A397] uppercase block">Multiplier</span>
            <span className="text-lg font-bold text-[#D97706]">{shockMultiplier.toFixed(1)}x</span>
          </div>
        </div>
      </div>

      {/* Side-by-side layout: Stress comparisons & parameters */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Scenario Selectors (takes 5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <h3 className="font-serif text-[#EFECE6] text-lg mb-2">Macroeconomic Stress Scenarios</h3>
          
          {calculateScenarioImpacts.map((scen) => {
            const isSelected = scen.id === selectedScenarioId;
            const ratio = scen.stressedCET1Ratio;
            
            let statusBadge = (
              <span className="text-[9px] bg-emerald-950/40 text-emerald-400 font-mono font-bold px-1.5 py-0.5 rounded border border-emerald-900/40">SAFE</span>
            );
            if (ratio < 4.5) {
              statusBadge = (
                <span className="text-[9px] bg-red-950/40 text-red-400 font-mono font-bold px-1.5 py-0.5 rounded border border-red-900/40">BREACHED</span>
              );
            } else if (ratio < 9.0) {
              statusBadge = (
                <span className="text-[9px] bg-amber-950/40 text-amber-500 font-mono font-bold px-1.5 py-0.5 rounded border border-amber-900/40">BUFFER DEPLETION</span>
              );
            }

            return (
              <div
                key={scen.id}
                onClick={() => setSelectedScenarioId(scen.id)}
                className={`p-4 border transition cursor-pointer flex flex-col justify-between h-40 ${
                  isSelected 
                    ? "bg-[#1C1F22] border-[#D97706]" 
                    : "bg-[#181B1E] border-[#2D3339] hover:bg-[#1C1F22]/70"
                }`}
              >
                <div>
                  <div className="flex justify-between items-start">
                    <span className="text-xs uppercase tracking-wider text-[#A9A397] font-semibold">{scen.type} Scenario</span>
                    {statusBadge}
                  </div>
                  <h4 className="font-serif text-[#EFECE6] text-base mt-1.5 font-bold">{scen.name}</h4>
                  <p className="text-[11px] text-[#8E887E] mt-1 line-clamp-2">{scen.description}</p>
                </div>

                <div className="flex justify-between items-end border-t border-[#2D3339]/50 pt-2.5 mt-2">
                  <div className="text-left">
                    <span className="text-[9px] text-[#8E887E] block uppercase">Post-Stress CET1</span>
                    <span className="font-mono text-sm text-[#EFECE6] font-bold">{ratio}%</span>
                  </div>
                  <ChevronRight className={`w-4 h-4 text-[#8E887E] ${isSelected ? 'text-[#D97706]' : ''}`} />
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Scenario Stress Audit Board (takes 7 cols) */}
        <div className="lg:col-span-7 bg-[#181B1E] border border-[#2D3339] p-6 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start border-b border-[#2D3339] pb-3 mb-4">
              <div>
                <h3 className="font-serif text-[#EFECE6] text-lg">Stress Projection Audit</h3>
                <p className="text-xs text-[#A9A397]">Showing calculated capital depletion metrics for: <span className="text-[#EFECE6] font-bold">{selectedScenario.name}</span></p>
              </div>
            </div>

            {/* Parameter blocks */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 text-xs">
              <div className="bg-[#121416] p-3 border border-[#2D3339] rounded">
                <span className="text-[#A9A397] block uppercase text-[10px]">GDP Growth</span>
                <span className="text-[#EFECE6] font-mono font-bold block mt-1">{selectedScenario.gdpImpact}</span>
              </div>
              <div className="bg-[#121416] p-3 border border-[#2D3339] rounded">
                <span className="text-[#A9A397] block uppercase text-[10px]">Real Estate Shocks</span>
                <span className="text-[#EFECE6] font-mono font-bold block mt-1">
                  HPI: {selectedScenario.hpiLoss.toFixed(1)}% | CRE: {selectedScenario.creLoss.toFixed(1)}%
                </span>
              </div>
              <div className="bg-[#121416] p-3 border border-[#2D3339] rounded">
                <span className="text-[#A9A397] block uppercase text-[10px]">PD Multiplier</span>
                <span className="text-[#EFECE6] font-mono font-bold block mt-1">
                  {(1.0 + (selectedScenario.defaultRateMultiplier - 1.0) * (selectedScenario.type === "Baseline" ? 1.0 : shockMultiplier)).toFixed(2)}x
                </span>
              </div>
              <div className="bg-[#121416] p-3 border border-[#2D3339] rounded">
                <span className="text-[#A9A397] block uppercase text-[10px]">Interest Shock</span>
                <span className="text-[#EFECE6] font-mono font-bold block mt-1">
                  +{selectedScenario.interestRateShockBps * (selectedScenario.type === "Baseline" ? 1.0 : shockMultiplier)} bps
                </span>
              </div>
            </div>

            {/* Calculations metrics */}
            <div className="space-y-4">
              <div className="flex justify-between items-center py-2 border-b border-[#2D3339]/50">
                <span className="text-xs text-[#A9A397]">Baseline CET1 Capital</span>
                <span className="font-mono text-xs text-[#EFECE6]">£{metrics.cet1Capital}M</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-[#2D3339]/50 text-red-400 font-semibold">
                <span>Calculated credit stress impairment losses</span>
                <span className="font-mono">-£{selectedScenario.stressedLosses}M</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-[#2D3339]/50">
                <span className="text-xs text-[#A9A397]">Post-Stress CET1 Available</span>
                <span className="font-mono text-xs text-[#EFECE6]">£{selectedScenario.stressedCET1}M</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-[#2D3339]/50">
                <span className="text-xs text-[#A9A397]">Post-Stress Inflated RWA</span>
                <span className="font-mono text-xs text-[#EFECE6]">£{selectedScenario.stressedRWA.toLocaleString()}M</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-[#2D3339]/50 text-amber-500 font-bold text-sm">
                <span>Stress-Scenario CET1 Ratio (%)</span>
                <span className="font-mono">{selectedScenario.stressedCET1Ratio}%</span>
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-[#121416] border border-[#2D3339] rounded flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-[#A9A397]">
              <Gauge className="w-5 h-5 text-[#D97706]" />
              <div>
                <span className="text-[#EFECE6] font-semibold block">Basel Minimum Regulatory Check</span>
                {selectedScenario.stressedCET1Ratio >= 9.0 ? (
                  <span className="text-emerald-400 font-semibold flex items-center gap-1 mt-0.5"><CheckCircle2 className="w-3.5 h-3.5" /> Compliant with CCB+SIFI</span>
                ) : selectedScenario.stressedCET1Ratio >= 4.5 ? (
                  <span className="text-amber-500 font-semibold flex items-center gap-1 mt-0.5"><AlertTriangle className="w-3.5 h-3.5" /> Buffer breached, restructures triggered</span>
                ) : (
                  <span className="text-red-500 font-semibold flex items-center gap-1 mt-0.5"><XOctagon className="w-3.5 h-3.5" /> CORE SOLVENCY BREACH - Action required</span>
                )}
              </div>
            </div>
            
            {selectedScenario.stressedCET1Ratio < 9.0 && (
              <span className="text-[10px] uppercase font-bold text-[#D97706] animate-pulse">Alert Active</span>
            )}
          </div>
        </div>

      </div>

      {/* Chart: Bar plot comparing ratios under Stress */}
      <div className="bg-[#181B1E] border border-[#2D3339] p-6">
        <h3 className="font-serif text-[#EFECE6] text-lg mb-4">Capital Ratio Comparison Across Scenarios</h3>
        
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#2D3339" />
              <XAxis dataKey="name" stroke="#8E887E" fontSize={11} />
              <YAxis domain={[0, 24]} stroke="#8E887E" fontSize={11} tickFormatter={(val) => `${val}%`} />
              <Tooltip 
                contentStyle={{ backgroundColor: "#1C1F22", border: "1px solid #3A3F45", borderRadius: "4px" }}
              />
              <ReferenceLine y={9.0} stroke="red" strokeDasharray="3 3" label={{ value: 'Regulatory Hurdle (9.0%)', position: 'top', fill: 'red', fontSize: 10 }} />
              <Bar dataKey="CET1 Ratio (%)" fill="#D97706" name="CET1 Ratio (%)" maxBarSize={45} />
              <Bar dataKey="Total Capital Ratio (%)" fill="#162E44" name="Total Capital Ratio (%)" maxBarSize={45} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

    </div>
  );
}
