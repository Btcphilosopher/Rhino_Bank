import React from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend 
} from "recharts";
import { 
  Sliders, 
  Layers, 
  TrendingDown, 
  Info, 
  DollarSign, 
  Percent, 
  RefreshCw 
} from "lucide-react";
import { PortfolioSegment, CapitalMetrics } from "../types";

interface PortfolioAnalyticsProps {
  portfolios: PortfolioSegment[];
  metrics: CapitalMetrics;
  onUpdatePortfolios: (updated: PortfolioSegment[]) => void;
  onUpdateMetrics: (newMetrics: Partial<CapitalMetrics>) => void;
  onAddAuditLog: (action: string, details: string) => void;
}

export default function PortfolioAnalytics({
  portfolios,
  metrics,
  onUpdatePortfolios,
  onUpdateMetrics,
  onAddAuditLog
}: PortfolioAnalyticsProps) {
  
  const [selectedCategory, setSelectedCategory] = React.useState<string>("All");
  
  // Recalculate global metrics when portfolios edit
  const recalculateGlobalMetrics = (updatedPorts: PortfolioSegment[]) => {
    let totalRWA = 0;
    let totalEAD = 0;
    let totalEL = 0;

    updatedPorts.forEach(p => {
      const segmentRwa = p.exposure * p.riskWeightCurrent;
      const expectedLoss = p.exposure * (p.pd / 100) * (p.lgd / 100);
      totalRWA += segmentRwa;
      totalEAD += p.exposure;
      totalEL += expectedLoss;
    });

    onUpdateMetrics({
      rwa: totalRWA,
      ead: totalEAD,
      expectedLoss: totalEL
    });
  };

  const handleRiskWeightChange = (id: string, newWeight: number) => {
    const updated = portfolios.map(p => {
      if (p.id === id) {
        return { ...p, riskWeightCurrent: newWeight };
      }
      return p;
    });
    onUpdatePortfolios(updated);
    recalculateGlobalMetrics(updated);
  };

  const handleResetWeights = () => {
    const reset = portfolios.map(p => ({
      ...p,
      riskWeightCurrent: p.riskWeightDefault
    }));
    onUpdatePortfolios(reset);
    recalculateGlobalMetrics(reset);
    onAddAuditLog("Portfolio Weights Reset", "All asset risk weights reset to Basel default standardised values.");
  };

  // Filtered portfolios
  const filteredPortfolios = React.useMemo(() => {
    if (selectedCategory === "All") return portfolios;
    return portfolios.filter(p => p.category === selectedCategory);
  }, [portfolios, selectedCategory]);

  // Aggregate Category Data for charts
  const chartData = React.useMemo(() => {
    const categories = ["Corporate", "CRE", "Mortgages", "SME", "Treasury", "Securities", "Other"];
    return categories.map(cat => {
      let exposure = 0;
      let rwa = 0;
      let count = 0;

      portfolios.forEach(p => {
        if (p.category === cat) {
          exposure += p.exposure;
          rwa += p.exposure * p.riskWeightCurrent;
          count++;
        }
      });

      return {
        name: cat,
        "Exposure (EAD)": exposure,
        "Risk Weighted Assets (RWA)": Math.round(rwa),
        "Density (%)": exposure > 0 ? Math.round((rwa / exposure) * 100) : 0
      };
    }).filter(d => d["Exposure (EAD)"] > 0);
  }, [portfolios]);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#2D3339] pb-5 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#D97706] font-semibold">ASSET BASE & DENSITY</span>
          <h1 className="text-3xl font-serif text-[#EFECE6] mt-1 tracking-tight">Portfolio Risk Weight Engine</h1>
          <p className="text-[#A9A397] text-sm mt-1 max-w-xl">
            Aggregate exposures across credit categories. Tunable risk-weight coefficients support direct testing of Basel IV regulatory impact.
          </p>
        </div>
        
        <div className="flex gap-2">
          <button 
            onClick={handleResetWeights}
            className="text-xs border border-[#2D3339] text-[#A9A397] hover:text-[#EFECE6] hover:bg-[#1C1F22] px-3 py-1.5 rounded transition flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5 text-[#D97706]" /> Reset Risk Weights
          </button>
        </div>
      </div>

      {/* Exposure vs RWA Side-by-Side Chart */}
      <div className="bg-[#181B1E] border border-[#2D3339] p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="font-serif text-[#EFECE6] text-lg">Portfolio Exposure Density</h3>
            <p className="text-xs text-[#A9A397]">Comparison of total balance-sheet Exposure at Default (EAD) vs Risk-Weighted Assets (RWA) by booking category.</p>
          </div>
          
          <div className="flex gap-1 bg-[#121416] p-0.5 rounded border border-[#2D3339] text-xs">
            {["All", "Corporate", "CRE", "Mortgages", "SME", "Treasury"].map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded text-xs transition ${
                  selectedCategory === cat 
                    ? "bg-[#162E44] text-[#EFECE6] font-semibold" 
                    : "text-[#A9A397] hover:text-[#EFECE6]"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="h-72 mt-4">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#2D3339" />
              <XAxis dataKey="name" stroke="#8E887E" fontSize={11} />
              <YAxis stroke="#8E887E" fontSize={11} tickFormatter={(val) => `£${val/1000}B`} />
              <Tooltip 
                contentStyle={{ backgroundColor: "#1C1F22", border: "1px solid #3A3F45", borderRadius: "4px" }}
                labelStyle={{ color: "#EFECE6", fontWeight: "bold" }}
                itemStyle={{ color: "#D97706" }}
              />
              <Legend verticalAlign="bottom" height={36} wrapperStyle={{ fontSize: '11px', color: '#A9A397' }} />
              <Bar dataKey="Exposure (EAD)" fill="#162E44" name="Exposure (EAD)" maxBarSize={45} />
              <Bar dataKey="Risk Weighted Assets (RWA)" fill="#D97706" name="Risk Weighted Assets (RWA)" maxBarSize={45} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Portfolio Granular Table & Slider Controls */}
      <div className="bg-[#181B1E] border border-[#2D3339] p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-serif text-[#EFECE6] text-lg">Exposure Segmentation & Stress Coefficients</h3>
          <span className="text-xs text-[#A9A397]">Adjust risk-weights to evaluate the mathematical sensitivity of CET1 ratios.</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#2D3339] text-[#A9A397] uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">Portfolio Segment / Booking Book</th>
                <th className="py-3 px-2">EAD (£M)</th>
                <th className="py-3 px-2 text-center">PD (%)</th>
                <th className="py-3 px-2 text-center">LGD (%)</th>
                <th className="py-3 px-2 text-center">Expected Loss (£M)</th>
                <th className="py-3 px-4 text-center w-64">Regulatory Risk Weight</th>
                <th className="py-3 px-4 text-right">RWA (£M)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2D3339]/50">
              {filteredPortfolios.map((p) => {
                const segmentRwa = p.exposure * p.riskWeightCurrent;
                const expectedLoss = p.exposure * (p.pd / 100) * (p.lgd / 100);
                
                return (
                  <tr key={p.id} className="hover:bg-[#121416]/50 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-[#EFECE6]">{p.name}</div>
                      <div className="text-[10px] text-[#8E887E] flex items-center gap-2 mt-0.5">
                        <span className="bg-[#121416] px-1 py-0.5 rounded border border-[#2D3339]">{p.category}</span>
                        <span>{p.sector}</span>
                        <span>&middot;</span>
                        <span>{p.region}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-2 font-mono text-[#EFECE6] font-semibold">
                      £{p.exposure.toLocaleString()}M
                    </td>
                    <td className="py-3.5 px-2 text-center font-mono text-[#A9A397]">
                      {p.pd.toFixed(2)}%
                    </td>
                    <td className="py-3.5 px-2 text-center font-mono text-[#A9A397]">
                      {p.lgd.toFixed(1)}%
                    </td>
                    <td className="py-3.5 px-2 text-center font-mono text-red-400 font-semibold">
                      £{expectedLoss.toFixed(2)}M
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center gap-3 justify-center">
                        <input
                          type="range"
                          min="0.00"
                          max="1.50"
                          step="0.05"
                          value={p.riskWeightCurrent}
                          onChange={(e) => handleRiskWeightChange(p.id, parseFloat(e.target.value))}
                          className="w-32 accent-[#D97706] cursor-pointer"
                        />
                        <span className="font-mono text-[#EFECE6] font-bold w-12 text-right">
                          {(p.riskWeightCurrent * 100).toFixed(0)}%
                        </span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-[#D97706] font-bold text-sm">
                      £{Math.round(segmentRwa).toLocaleString()}M
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="bg-[#121416] border-t border-[#2D3339] font-semibold">
                <td className="py-4 px-4 text-[#EFECE6]">Aggregate Bank Portfolio Summary</td>
                <td className="py-4 px-2 font-mono text-[#EFECE6] text-sm">
                  £{portfolios.reduce((sum, p) => sum + p.exposure, 0).toLocaleString()}M
                </td>
                <td className="py-4 px-2 text-center font-mono text-[#8E887E]">
                  {(portfolios.reduce((sum, p) => sum + p.pd, 0) / portfolios.length).toFixed(2)}% (avg)
                </td>
                <td className="py-4 px-2 text-center font-mono text-[#8E887E]">
                  {(portfolios.reduce((sum, p) => sum + p.lgd, 0) / portfolios.length).toFixed(1)}% (avg)
                </td>
                <td className="py-4 px-2 text-center font-mono text-red-400 font-bold">
                  £{metrics.expectedLoss.toFixed(1)}M
                </td>
                <td className="py-4 px-4 text-center font-mono text-[#8E887E]">
                  Avg Risk Weight: <span className="text-[#EFECE6] font-bold">{((metrics.rwa / metrics.ead) * 100).toFixed(1)}%</span>
                </td>
                <td className="py-4 px-4 text-right font-mono text-[#D97706] text-base font-bold">
                  £{Math.round(metrics.rwa).toLocaleString()}M
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="mt-4 p-4 bg-[#121416] border border-[#2D3339] rounded text-xs flex items-start gap-2.5 text-[#A9A397]">
          <Info className="w-4 h-4 text-[#D97706] shrink-0 mt-0.5" />
          <div>
            <span className="text-[#EFECE6] font-semibold">Regulatory Method Note:</span> Average RWA Density indicates the efficiency of capital usage. Retail mortgage portfolios have a density around 32-35% because residential real estate collateral reduces default hair-cuts. Commercial property (CRE) is higher risk, standardizing at 100-110% under Basel III regulations.
          </div>
        </div>
      </div>

    </div>
  );
}
