import React from "react";
import { FileText, Printer, Download, CheckCircle, Award, Calendar } from "lucide-react";
import { CapitalMetrics, RegulatoryRequirements, PortfolioSegment } from "../types";

interface ReportsCentreProps {
  metrics: CapitalMetrics;
  requirements: RegulatoryRequirements;
  portfolios: PortfolioSegment[];
  onAddAuditLog: (action: string, details: string) => void;
}

type ReportType = "board" | "treasury" | "stress" | "sme";

export default function ReportsCentre({
  metrics,
  requirements,
  portfolios,
  onAddAuditLog
}: ReportsCentreProps) {
  
  const [activeReport, setActiveReport] = React.useState<ReportType>("board");
  const [isSignOff, setIsSignOff] = React.useState<boolean>(false);

  const cet1Ratio = (metrics.cet1Capital / metrics.rwa) * 100;
  const tier1Ratio = ((metrics.cet1Capital + metrics.at1Capital) / metrics.rwa) * 100;
  const totalCapitalRatio = ((metrics.cet1Capital + metrics.at1Capital + metrics.tier2Capital) / metrics.rwa) * 100;
  const totalMinRequired = (requirements.minCet1 + requirements.ccbRequirement + requirements.ccybRequirement + requirements.sifiRequirement) * 100;

  const handlePrint = () => {
    onAddAuditLog(
      "Report Print Initiated",
      `Rendered printable layout for "${activeReport === "board" ? 'Board Capital Report' : activeReport === "treasury" ? 'Treasury Review' : 'Stress Projections'}" document.`
    );
    window.print();
  };

  const handleSignOff = () => {
    setIsSignOff(true);
    onAddAuditLog(
      "Report Signed Off",
      `Prudential Capital report sign-off executed by tom@ahyx.org (Treasury Director, Rhino Bank).`
    );
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#2D3339] pb-5 flex flex-col md:flex-row justify-between items-start md:items-end gap-4 print:hidden">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#c08267] font-semibold">FORMAL BOARDROOM ARCHIVE</span>
          <h1 className="text-3xl font-serif text-[#EFECE6] mt-1 tracking-tight">Board & Treasury Reports</h1>
          <p className="text-[#A9A397] text-sm mt-1 max-w-xl">
            Generate and export board-quality, print-ready, high-fidelity regulatory reviews. Live values synchronize directly with the computational models.
          </p>
        </div>
        
        <div className="flex gap-2">
          <button 
            onClick={handlePrint}
            className="text-xs bg-[#162E44] hover:bg-[#264B6C] border border-[#264B6C] text-[#EFECE6] px-3.5 py-1.5 rounded transition flex items-center gap-1.5 font-semibold"
          >
            <Printer className="w-3.5 h-3.5 text-[#c08267]" /> Export / Print Report
          </button>
        </div>
      </div>

      {/* Selector and Main report container */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Sidebar report selectors (takes 4 cols) - hidden in print */}
        <div className="lg:col-span-4 space-y-3 print:hidden">
          <h3 className="font-serif text-[#EFECE6] text-lg mb-2">Available Documents</h3>

          {/* Report 1: Board Capital Report */}
          <div 
            onClick={() => { setActiveReport("board"); setIsSignOff(false); }}
            className={`p-4 border cursor-pointer transition rounded ${
              activeReport === "board" 
                ? "bg-[#1C1F22] border-[#c08267]" 
                : "bg-[#181B1E] border-[#2D3339] hover:bg-[#1C1F22]/40"
            }`}
          >
            <div className="flex items-start gap-3">
              <FileText className="w-5 h-5 text-[#c08267] shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-xs text-[#EFECE6]">Board Capital Adequacy Report</h4>
                <p className="text-[10px] text-[#8E887E] mt-1 leading-relaxed">
                  High-level executive overview designed for the Risk Committee and Board Directors. Covers total solvency ratios and compliance checks.
                </p>
              </div>
            </div>
          </div>

          {/* Report 2: Treasury Capital Review */}
          <div 
            onClick={() => { setActiveReport("treasury"); setIsSignOff(false); }}
            className={`p-4 border cursor-pointer transition rounded ${
              activeReport === "treasury" 
                ? "bg-[#1C1F22] border-[#c08267]" 
                : "bg-[#181B1E] border-[#2D3339] hover:bg-[#1C1F22]/40"
            }`}
          >
            <div className="flex items-start gap-3">
              <FileText className="w-5 h-5 text-[#c08267] shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-xs text-[#EFECE6]">Treasury Capital & Liquidity Review</h4>
                <p className="text-[10px] text-[#8E887E] mt-1 leading-relaxed">
                  Detailed technical breakdown of capital resources tiers (CET1, AT1, Tier 2) and distance-to-trigger metrics.
                </p>
              </div>
            </div>
          </div>

          {/* Report 3: Stress Test Results */}
          <div 
            onClick={() => { setActiveReport("stress"); setIsSignOff(false); }}
            className={`p-4 border cursor-pointer transition rounded ${
              activeReport === "stress" 
                ? "bg-[#1C1F22] border-[#c08267]" 
                : "bg-[#181B1E] border-[#2D3339] hover:bg-[#1C1F22]/40"
            }`}
          >
            <div className="flex items-start gap-3">
              <FileText className="w-5 h-5 text-[#c08267] shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-xs text-[#EFECE6]">PRA Stress Testing Outturns</h4>
                <p className="text-[10px] text-[#8E887E] mt-1 leading-relaxed">
                  Vulnerability summary detailing credit losses and capital depletion levels under Adverse and Severe Stagflation.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Paper Report Sheet - occupies remaining space (takes 8 cols, full width in print) */}
        <div className="lg:col-span-8 bg-[#F5F2EB] text-[#121416] p-10 border border-[#DFDAD0] font-sans shadow-lg flex flex-col justify-between min-h-[750px] relative">
          
          {/* Watermark of Rhino Bank */}
          <div className="absolute right-10 top-10 select-none opacity-10 pointer-events-none">
            <span className="font-serif text-5xl font-extrabold tracking-tight">RHINO BANK</span>
          </div>

          {/* Board Capital Adequacy Layout */}
          {activeReport === "board" && (
            <div className="space-y-6">
              {/* Document Header */}
              <div className="border-b-2 border-[#121416] pb-4 flex justify-between items-end">
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-[#c08267] font-bold">Rhino Bank Plc &middot; Internal Audit</span>
                  <h2 className="text-2xl font-serif font-extrabold text-[#121416] mt-1">Prudential Capital Adequacy Report</h2>
                  <div className="text-xs text-[#8E887E] mt-1 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" /> Dated: July 28, 2026 | Document Ref: RB-CAR-2026-Q2
                  </div>
                </div>
                <div className="text-right text-xs font-mono">
                  <span className="text-[#8E887E] block uppercase">Security level</span>
                  <span className="bg-red-950/20 text-red-800 font-bold px-1.5 py-0.5 rounded border border-red-900/10 uppercase text-[9px]">Strictly Confidential</span>
                </div>
              </div>

              {/* Text overview */}
              <div className="space-y-3 text-xs leading-relaxed text-[#2D3339]">
                <h3 className="text-sm font-serif font-bold text-[#121416] uppercase tracking-wider border-b border-[#2D3339]/20 pb-1">1. Executive Overview</h3>
                <p>
                  This report has been compiled under the direction of the Treasury and Financial Planning divisions of Rhino Bank Plc for submission to the Board of Directors. It details the capital resources, risk-weighted assets, and regulatory safety margins under current operating conditions, adhering strictly to Basel III/IV standards and relevant UK Prudential Regulation Authority (PRA) guidelines.
                </p>
                <p>
                  As of the reporting date, Rhino Bank maintains a highly resilient available capital position, comfortably exceeding all combined Pillar 1 and Pillar 2 hurdle thresholds.
                </p>
              </div>

              {/* Live calculations table */}
              <div className="space-y-3">
                <h3 className="text-sm font-serif font-bold text-[#121416] uppercase tracking-wider border-b border-[#2D3339]/20 pb-1">2. Solvency Ratio Audit Table</h3>
                
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-[#121416] text-[#2D3339] font-bold uppercase text-[9px]">
                      <th className="py-2">Metric Description</th>
                      <th className="py-2 text-right">Basel Min Hurdle</th>
                      <th className="py-2 text-right">Rhino Bank Current</th>
                      <th className="py-2 text-right">Surplus Position</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#2D3339]/20 font-mono">
                    <tr>
                      <td className="py-2 font-sans font-medium">Common Equity Tier 1 (CET1) Ratio</td>
                      <td className="py-2 text-right">{(totalMinRequired).toFixed(2)}%</td>
                      <td className="py-2 text-right font-bold text-[#c08267]">{cet1Ratio.toFixed(2)}%</td>
                      <td className="py-2 text-right text-emerald-700 font-bold">+{(cet1Ratio - totalMinRequired).toFixed(2)}%</td>
                    </tr>
                    <tr>
                      <td className="py-2 font-sans font-medium">Total Tier 1 Ratio</td>
                      <td className="py-2 text-right">{(totalMinRequired + 1.5).toFixed(2)}%</td>
                      <td className="py-2 text-right font-bold text-[#162E44]">{tier1Ratio.toFixed(2)}%</td>
                      <td className="py-2 text-right text-emerald-700 font-bold">+{(tier1Ratio - (totalMinRequired + 1.5)).toFixed(2)}%</td>
                    </tr>
                    <tr>
                      <td className="py-2 font-sans font-medium">Total Capital Adequacy Ratio</td>
                      <td className="py-2 text-right">{(totalMinRequired + 3.5).toFixed(2)}%</td>
                      <td className="py-2 text-right font-bold">{totalCapitalRatio.toFixed(2)}%</td>
                      <td className="py-2 text-right text-emerald-700 font-bold">+{(totalCapitalRatio - (totalMinRequired + 3.5)).toFixed(2)}%</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Capital assets review */}
              <div className="space-y-2 text-xs leading-relaxed text-[#2D3339]">
                <h3 className="text-sm font-serif font-bold text-[#121416] uppercase tracking-wider border-b border-[#2D3339]/20 pb-1">3. Capital Distribution Overview</h3>
                <p>
                  Total Risk Weighted Assets (RWA) are registered at <strong className="text-[#121416]">£{Math.round(metrics.rwa).toLocaleString()}M</strong> representing an overall portfolio density coefficient of <strong className="text-[#121416]">{((metrics.rwa / metrics.ead) * 100).toFixed(1)}%</strong> on total lending exposure of <strong className="text-[#121416]">£{Math.round(metrics.ead).toLocaleString()}M</strong>. Common Equity Tier 1 capital resources stand at <strong className="text-[#121416]">£{metrics.cet1Capital}M</strong>, bolstered by strong Q1 audited retained earnings.
                </p>
              </div>
            </div>
          )}

          {/* Treasury Capital Review Layout */}
          {activeReport === "treasury" && (
            <div className="space-y-6">
              {/* Document Header */}
              <div className="border-b-2 border-[#121416] pb-4 flex justify-between items-end">
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-[#c08267] font-bold">Rhino Bank Plc &middot; Treasury Desk</span>
                  <h2 className="text-2xl font-serif font-extrabold text-[#121416] mt-1">Treasury Capital & Funding Review</h2>
                  <div className="text-xs text-[#8E887E] mt-1 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" /> Dated: July 28, 2026 | Document Ref: RB-TR-2026-Q2
                  </div>
                </div>
                <div className="text-right text-xs font-mono">
                  <span className="text-[#8E887E] block uppercase">Security level</span>
                  <span className="bg-red-950/20 text-red-800 font-bold px-1.5 py-0.5 rounded border border-red-900/10 uppercase text-[9px]">Strictly Confidential</span>
                </div>
              </div>

              <div className="space-y-3 text-xs leading-relaxed text-[#2D3339]">
                <h3 className="text-sm font-serif font-bold text-[#121416] uppercase tracking-wider border-b border-[#2D3339]/20 pb-1">1. Capital Instrument Tiers Review</h3>
                <p>
                  This review evaluates the quality and loss-absorbency margins of individual capital liabilities. Common Equity Tier 1 (CET1) capital remains the primary anchor of our solvency frame, representing <strong className="text-[#121416]">{((metrics.cet1Capital / (metrics.cet1Capital + metrics.at1Capital + metrics.tier2Capital)) * 100).toFixed(1)}%</strong> of total capital reserves.
                </p>
                
                <table className="w-full text-left text-xs border-collapse mt-2">
                  <thead>
                    <tr className="border-b border-[#121416] text-[#2D3339] font-bold uppercase text-[9px]">
                      <th className="py-2">Capital Class</th>
                      <th className="py-2">Instrument Type</th>
                      <th className="py-2 text-right">Nominal Value</th>
                      <th className="py-2 text-right">Percentage of Reserves</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#2D3339]/20 font-mono">
                    <tr>
                      <td className="py-2 font-sans font-medium">Common Equity (CET1)</td>
                      <td className="py-2">Ordinary Shares & RetEarnings</td>
                      <td className="py-2 text-right font-bold">£{metrics.cet1Capital.toLocaleString()}M</td>
                      <td className="py-2 text-right">{((metrics.cet1Capital / (metrics.cet1Capital + metrics.at1Capital + metrics.tier2Capital)) * 100).toFixed(1)}%</td>
                    </tr>
                    <tr>
                      <td className="py-2 font-sans font-medium">Additional Tier 1 (AT1)</td>
                      <td className="py-2">Perpetual CoCo Bonds (7% Trigger)</td>
                      <td className="py-2 text-right font-bold">£{metrics.at1Capital.toLocaleString()}M</td>
                      <td className="py-2 text-right">{((metrics.at1Capital / (metrics.cet1Capital + metrics.at1Capital + metrics.tier2Capital)) * 100).toFixed(1)}%</td>
                    </tr>
                    <tr>
                      <td className="py-2 font-sans font-medium">Tier 2 Capital</td>
                      <td className="py-2">Subordinated Term Debt (5Y+ Maturity)</td>
                      <td className="py-2 text-right font-bold">£{metrics.tier2Capital.toLocaleString()}M</td>
                      <td className="py-2 text-right">{((metrics.tier2Capital / (metrics.cet1Capital + metrics.at1Capital + metrics.tier2Capital)) * 100).toFixed(1)}%</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="space-y-2 text-xs leading-relaxed text-[#2D3339]">
                <h3 className="text-sm font-serif font-bold text-[#121416] uppercase tracking-wider border-b border-[#2D3339]/20 pb-1">2. Distance to AT1 CoCo Trigger</h3>
                <p>
                  As of the reporting date, the distance to the Contingent Convertible (AT1) contract trigger threshold of <strong className="text-[#121416]">7.00% CET1</strong> stands at a highly comfortable <strong className="text-emerald-700">+{(cet1Ratio - 7).toFixed(2)}%</strong>. This indicates an organic asset buffer cushion of <strong className="text-emerald-700">£{Math.round(metrics.cet1Capital - (metrics.rwa * 0.07)).toLocaleString()}M</strong> in asset impairments before CoCo debt-to-equity conversion programs are triggered.
                </p>
              </div>
            </div>
          )}

          {/* Stress Test Results Layout */}
          {activeReport === "stress" && (
            <div className="space-y-6">
              {/* Document Header */}
              <div className="border-b-2 border-[#121416] pb-4 flex justify-between items-end">
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-[#c08267] font-bold">Rhino Bank Plc &middot; Risk Quantitative Analytics</span>
                  <h2 className="text-2xl font-serif font-extrabold text-[#121416] mt-1">Prudential Stress Testing Outturns</h2>
                  <div className="text-xs text-[#8E887E] mt-1 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" /> Dated: July 28, 2026 | Document Ref: RB-STR-2026-Q2
                  </div>
                </div>
                <div className="text-right text-xs font-mono">
                  <span className="text-[#8E887E] block uppercase">Security level</span>
                  <span className="bg-red-950/20 text-red-800 font-bold px-1.5 py-0.5 rounded border border-red-900/10 uppercase text-[9px]">Strictly Confidential</span>
                </div>
              </div>

              <div className="space-y-3 text-xs leading-relaxed text-[#2D3339]">
                <h3 className="text-sm font-serif font-bold text-[#121416] uppercase tracking-wider border-b border-[#2D3339]/20 pb-1">1. Downturn Resilience Outturns</h3>
                <p>
                  The Risk Analytics Desk has simulated the financial resilience of Rhino Bank against adverse stagflation and a severe regional credit default downturn ("Yorkshire Winter"). Credit default rates and property price declines are modelled via Monte Carlo distributions.
                </p>
                <p>
                  Under the Adverse Scenario, total expected losses stand at £321M, depleting the CET1 ratio slightly but keeping the bank safe. Under the Severe Downturn, severe losses trigger a significant depletion of available capital.
                </p>

                <table className="w-full text-left text-xs border-collapse mt-2">
                  <thead>
                    <tr className="border-b border-[#121416] text-[#2D3339] font-bold uppercase text-[9px]">
                      <th className="py-2">Downturn Scenario</th>
                      <th className="py-2 text-right">Impairment Losses</th>
                      <th className="py-2 text-right">Post-Stress CET1 Ratio</th>
                      <th className="py-2 text-right">Regulatory Compliance Check</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#2D3339]/20 font-mono">
                    <tr>
                      <td className="py-2 font-sans font-medium">Baseline Projection</td>
                      <td className="py-2 text-right">£{metrics.expectedLoss.toFixed(0)}M</td>
                      <td className="py-2 text-right font-bold text-emerald-700">{cet1Ratio.toFixed(2)}%</td>
                      <td className="py-2 text-right text-emerald-700 font-semibold">Fully Compliant</td>
                    </tr>
                    <tr>
                      <td className="py-2 font-sans font-medium">Adverse Stagflation</td>
                      <td className="py-2 text-right">£{Math.round(metrics.expectedLoss * 1.6).toLocaleString()}M</td>
                      <td className="py-2 text-right font-bold text-amber-600">{(cet1Ratio - 2.1).toFixed(2)}%</td>
                      <td className="py-2 text-right text-amber-600 font-semibold">CCB Buffer Utilized</td>
                    </tr>
                    <tr>
                      <td className="py-2 font-sans font-medium">Severe "Yorkshire Winter"</td>
                      <td className="py-2 text-right">£{Math.round(metrics.expectedLoss * 2.8).toLocaleString()}M</td>
                      <td className="py-2 text-right font-bold text-red-600">{(cet1Ratio - 5.4).toFixed(2)}%</td>
                      <td className="py-2 text-right text-red-600 font-semibold">Restructures Activated</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="space-y-2 text-xs leading-relaxed text-[#2D3339]">
                <h3 className="text-sm font-serif font-bold text-[#121416] uppercase tracking-wider border-b border-[#2D3339]/20 pb-1">2. Contingent Capital Mitigations</h3>
                <p>
                  To mitigate severe credit defaults, the Treasury committee recommends maintaining active contingency channels, including ordinary equity placement facilities and orderly roll-off of high-LGD commercial assets into sovereign liquid gilts.
                </p>
              </div>
            </div>
          )}

          {/* Footer of the Paper Report (Sign-off and paging) */}
          <div className="border-t border-[#2D3339]/20 pt-6 mt-8 flex justify-between items-center text-xs">
            <div>
              <span className="text-[9px] text-[#8E887E] uppercase block">Primary Executive Sign-off</span>
              {isSignOff ? (
                <span className="text-emerald-700 font-bold flex items-center gap-1 mt-0.5">
                  <Award className="w-4 h-4 text-emerald-600" /> Signed & Approved (Tom, Treasury Director)
                </span>
              ) : (
                <button 
                  onClick={handleSignOff}
                  className="bg-[#121416] text-[#F5F2EB] font-semibold py-1 px-3 rounded hover:bg-[#22262B] transition uppercase text-[10px] print:hidden"
                >
                  Approve and Sign Document
                </button>
              )}
            </div>
            <div className="text-right text-[10px] text-[#8E887E] font-mono">
              Page 1 of 1 | Rhino Bank Plc
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
