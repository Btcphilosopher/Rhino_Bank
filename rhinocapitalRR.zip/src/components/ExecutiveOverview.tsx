import React from "react";
import { 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  Legend
} from "recharts";
import { 
  Shield, 
  TrendingUp, 
  Percent, 
  Building2, 
  AlertTriangle, 
  FileCheck2, 
  Cpu, 
  CircleDot
} from "lucide-react";
import { CapitalMetrics, PortfolioSegment, RegulatoryRequirements } from "../types";
import { HISTORICAL_CET1_TREND } from "../data/defaultData";

interface ExecutiveOverviewProps {
  metrics: CapitalMetrics;
  requirements: RegulatoryRequirements;
  portfolios: PortfolioSegment[];
  onNavigate: (tab: string) => void;
}

export default function ExecutiveOverview({ 
  metrics, 
  requirements, 
  portfolios, 
  onNavigate 
}: ExecutiveOverviewProps) {
  
  // Calculate aggregate values
  const cet1Ratio = (metrics.cet1Capital / metrics.rwa) * 100;
  const tier1Ratio = ((metrics.cet1Capital + metrics.at1Capital) / metrics.rwa) * 100;
  const totalCapitalRatio = ((metrics.cet1Capital + metrics.at1Capital + metrics.tier2Capital) / metrics.rwa) * 100;
  
  // Requirement bounds
  const totalMinRequired = (requirements.minCet1 + requirements.ccbRequirement + requirements.ccybRequirement + requirements.sifiRequirement) * 100;
  const bufferOverRequirement = cet1Ratio - totalMinRequired;

  // Portfolio categories aggregate
  const categoryData = React.useMemo(() => {
    const counts: Record<string, { name: string; rwa: number; exposure: number; color: string }> = {
      Corporate: { name: "Corporate", rwa: 0, exposure: 0, color: "#162E44" },
      CRE: { name: "CRE (Property)", rwa: 0, exposure: 0, color: "#E07A25" },
      Mortgages: { name: "Mortgages", rwa: 0, exposure: 0, color: "#264B6C" },
      SME: { name: "SME Lending", rwa: 0, exposure: 0, color: "#c08267" },
      Treasury: { name: "Treasury Gilts", rwa: 0, exposure: 0, color: "#6F7F91" },
      Securities: { name: "Securities", rwa: 0, exposure: 0, color: "#4A5866" },
      Other: { name: "Other Assets", rwa: 0, exposure: 0, color: "#8E887E" }
    };

    portfolios.forEach(p => {
      if (counts[p.category]) {
        counts[p.category].exposure += p.exposure;
        counts[p.category].rwa += p.exposure * p.riskWeightCurrent;
      }
    });

    return Object.values(counts).filter(c => c.exposure > 0);
  }, [portfolios]);

  return (
    <div className="space-y-6" id="overview-dashboard">
      
      {/* Header section with editorial styling */}
      <div className="border-b border-[#2D3339] pb-5 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#c08267] font-semibold">PRUDENTIAL CONTEXT</span>
          <h1 className="text-3xl font-serif text-[#EFECE6] mt-1 tracking-tight">Rhino Bank Prudential Position</h1>
          <p className="text-[#A9A397] text-sm mt-1 max-w-xl">
            Real-time regulatory capital calculations, risk weighted asset distributions and Basel III/IV buffer compliance dashboard.
          </p>
        </div>
        
        {/* Sync Status Badge */}
        <div className="bg-[#181B1E] border border-[#2D3339] rounded px-3 py-2 flex items-center gap-2">
          <Cpu className="w-4 h-4 text-[#c08267] animate-pulse" />
          <div className="text-left">
            <div className="text-[10px] text-[#A9A397] uppercase tracking-wider">Engine Pipeline</div>
            <div className="text-xs font-mono text-[#EFECE6] flex items-center gap-1.5">
              <CircleDot className="w-2.5 h-2.5 text-emerald-500 fill-emerald-500" />
              R + Rust Synced (Basel IV)
            </div>
          </div>
        </div>
      </div>

      {/* Top Level Metric Cards (No purple gradients, clean grids) */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4" id="kpi-grid">
        
        {/* CET1 Ratio Card */}
        <div className="bg-[#181B1E] border border-[#2D3339] p-5 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start">
              <span className="text-xs uppercase tracking-wider text-[#A9A397]">CET1 Ratio</span>
              <Shield className="w-4 h-4 text-[#c08267]" />
            </div>
            <div className="text-4xl font-serif text-[#EFECE6] mt-3 font-semibold">
              {cet1Ratio.toFixed(2)}%
            </div>
            <div className="text-xs text-[#A9A397] mt-2">
              Req: <span className="font-mono text-[#EFECE6] font-semibold">{totalMinRequired.toFixed(1)}%</span> | Surplus: <span className="font-mono text-[#EFECE6] font-semibold">+{bufferOverRequirement.toFixed(2)}%</span>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-[#2D3339] flex items-center justify-between">
            <span className="text-[10px] bg-emerald-950/40 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-900/30">Compliant</span>
            <span className="text-xs text-[#D97706] hover:underline cursor-pointer" onClick={() => onNavigate("capital")}>Details &rarr;</span>
          </div>
        </div>

        {/* Total Capital Ratio Card */}
        <div className="bg-[#181B1E] border border-[#2D3339] p-5 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start">
              <span className="text-xs uppercase tracking-wider text-[#A9A397]">Total Capital Ratio</span>
              <Percent className="w-4 h-4 text-[#6F7F91]" />
            </div>
            <div className="text-4xl font-serif text-[#EFECE6] mt-3 font-semibold">
              {totalCapitalRatio.toFixed(2)}%
            </div>
            <div className="text-xs text-[#A9A397] mt-2">
              Total Capital Resources: <span className="font-mono text-[#EFECE6] font-semibold">£{(metrics.cet1Capital + metrics.at1Capital + metrics.tier2Capital).toLocaleString()}M</span>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-[#2D3339] flex items-center justify-between">
            <span className="text-[10px] bg-emerald-950/40 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-900/30">Strong Coverage</span>
            <span className="text-xs text-[#D97706] hover:underline cursor-pointer" onClick={() => onNavigate("capital")}>Tiers &rarr;</span>
          </div>
        </div>

        {/* Risk Weighted Assets Card */}
        <div className="bg-[#181B1E] border border-[#2D3339] p-5 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start">
              <span className="text-xs uppercase tracking-wider text-[#A9A397]">Total RWA</span>
              <Building2 className="w-4 h-4 text-[#6F7F91]" />
            </div>
            <div className="text-4xl font-serif text-[#EFECE6] mt-3 font-semibold">
              £{metrics.rwa.toLocaleString()}M
            </div>
            <div className="text-xs text-[#A9A397] mt-2">
              Density: <span className="font-mono text-[#EFECE6] font-semibold">{((metrics.rwa / metrics.ead) * 100).toFixed(1)}%</span> of £{(metrics.ead / 1000).toFixed(1)}B EAD
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-[#2D3339] flex items-center justify-between">
            <span className="text-[10px] text-[#A9A397]">Basel IV Standardised</span>
            <span className="text-xs text-[#D97706] hover:underline cursor-pointer" onClick={() => onNavigate("portfolio")}>Portfolio &rarr;</span>
          </div>
        </div>

        {/* Expected Loss / Buffer Capacity */}
        <div className="bg-[#181B1E] border border-[#2D3339] p-5 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start">
              <span className="text-xs uppercase tracking-wider text-[#A9A397]">Expected Loss (EL)</span>
              <AlertTriangle className="w-4 h-4 text-[#D97706]" />
            </div>
            <div className="text-4xl font-serif text-[#EFECE6] mt-3 font-semibold">
              £{metrics.expectedLoss.toFixed(1)}M
            </div>
            <div className="text-xs text-[#A9A397] mt-2">
              Coverage: <span className="font-mono text-[#EFECE6] font-semibold">{((metrics.expectedLoss / metrics.ead) * 100).toFixed(3)}%</span> of total exposure
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-[#2D3339] flex items-center justify-between">
            <span className="text-[10px] text-[#A9A397]">Provisioned (IFRS 9)</span>
            <span className="text-xs text-[#D97706] hover:underline cursor-pointer" onClick={() => onNavigate("stress")}>Stress Test &rarr;</span>
          </div>
        </div>
      </div>

      {/* Main charts layout: Historical Trend (Line/Area) & Assets (Bar/Donut) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Historical CET1 Trend Line Chart - taking 7 cols */}
        <div className="lg:col-span-8 bg-[#181B1E] border border-[#2D3339] p-6 flex flex-col justify-between">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="font-serif text-[#EFECE6] text-lg">Prudential Capital Trajectory</h3>
              <p className="text-xs text-[#A9A397]">Historical quarterly Common Equity Tier 1 (CET1) ratio against systemic regulatory hurdle rate.</p>
            </div>
            <div className="flex items-center gap-3 text-xs text-[#A9A397]">
              <span className="flex items-center gap-1"><span className="w-3 h-3 bg-[#c08267] inline-block rounded-sm"></span> CET1 Ratio</span>
              <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-red-500 inline-block"></span> Min Hurdle (9.0%)</span>
            </div>
          </div>
          
          <div className="h-64 mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={HISTORICAL_CET1_TREND}
                margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="colorCet1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#c08267" stopOpacity={0.25}/>
                    <stop offset="95%" stopColor="#c08267" stopOpacity={0.00}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#2D3339" />
                <XAxis 
                  dataKey="quarter" 
                  stroke="#8E887E" 
                  fontSize={11}
                  tickLine={false}
                />
                <YAxis 
                  domain={[6, 18]} 
                  stroke="#8E887E" 
                  fontSize={11} 
                  tickFormatter={(val) => `${val}%`}
                  tickLine={false}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#1C1F22", border: "1px solid #3A3F45", borderRadius: "4px" }}
                  labelStyle={{ color: "#EFECE6", fontWeight: "bold" }}
                  itemStyle={{ color: "#c08267" }}
                  formatter={(value: any) => [`${parseFloat(value).toFixed(2)}%`, "CET1 Ratio"]}
                />
                <Area 
                  type="monotone" 
                  dataKey="cet1" 
                  stroke="#c08267" 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#colorCet1)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-3 gap-4 pt-4 mt-4 border-t border-[#2D3339] text-center text-xs">
            <div className="border-r border-[#2D3339]">
              <div className="text-[#A9A397]">6-Quarter High</div>
              <div className="font-mono text-base text-[#EFECE6] font-semibold">15.99%</div>
            </div>
            <div className="border-r border-[#2D3339]">
              <div className="text-[#A9A397]">Average Surplus</div>
              <div className="font-mono text-base text-[#EFECE6] font-semibold">+6.10%</div>
            </div>
            <div>
              <div className="text-[#A9A397]">RWA Drift</div>
              <div className="font-mono text-base text-emerald-400 font-semibold">-0.7% (Stable)</div>
            </div>
          </div>
        </div>

        {/* Portfolio RWA Composition Donut Chart - taking 4 cols */}
        <div className="lg:col-span-4 bg-[#181B1E] border border-[#2D3339] p-6 flex flex-col justify-between">
          <div>
            <h3 className="font-serif text-[#EFECE6] text-lg">RWA Allocation</h3>
            <p className="text-xs text-[#A9A397]">Risk Weighted Assets split across distinct banking books under current framework.</p>
          </div>

          <div className="h-48 my-4 relative flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={3}
                  dataKey="rwa"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: "#1C1F22", border: "1px solid #3A3F45", borderRadius: "4px" }}
                  formatter={(value: any) => [`£${Math.round(value).toLocaleString()}M`, "RWA"]}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute flex flex-col items-center">
              <span className="text-[10px] uppercase tracking-widest text-[#A9A397]">Total RWA</span>
              <span className="text-xl font-serif font-bold text-[#EFECE6]">£{(metrics.rwa / 1000).toFixed(2)}B</span>
            </div>
          </div>

          <div className="space-y-1.5 text-xs max-h-40 overflow-y-auto pr-1">
            {categoryData.map((item, idx) => (
              <div key={idx} className="flex justify-between items-center py-1 border-b border-[#2D3339]/50 last:border-0">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: item.color }} />
                  <span className="text-[#A9A397]">{item.name}</span>
                </div>
                <div className="font-mono text-[#EFECE6] font-semibold">
                  £{Math.round(item.rwa).toLocaleString()}M <span className="text-xs text-[#8E887E] font-normal">({((item.rwa / metrics.rwa) * 100).toFixed(0)}%)</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Regulatory Buffers Compliance Section */}
      <div className="bg-[#181B1E] border border-[#2D3339] p-6">
        <h3 className="font-serif text-[#EFECE6] text-lg mb-4 flex items-center gap-2">
          <FileCheck2 className="w-5 h-5 text-[#c08267]" />
          Basel III / IV Capital Buffers Audit
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          
          {/* Buffer 1: Minimum CET1 */}
          <div className="bg-[#121416] p-4 border border-[#2D3339] flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-[#A9A397] uppercase tracking-wider">1. Pillar 1 Minimum CET1</span>
              <div className="text-2xl font-mono text-[#EFECE6] mt-1">4.50%</div>
              <p className="text-[10px] text-[#8E887E] mt-1.5 leading-relaxed">
                Mandated basic requirement under standard international banking law for credit, market and operational risk.
              </p>
            </div>
            <div className="mt-4 pt-2 border-t border-[#2D3339]/50 flex justify-between items-center">
              <span className="text-[9px] uppercase tracking-wider text-emerald-400 font-bold bg-emerald-950/20 px-1 rounded">Fulfilled</span>
              <span className="font-mono text-xs text-[#A9A397]">Def: 4.5%</span>
            </div>
          </div>

          {/* Buffer 2: CCB */}
          <div className="bg-[#121416] p-4 border border-[#2D3339] flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-[#A9A397] uppercase tracking-wider">2. Capital Conservation</span>
              <div className="text-2xl font-mono text-[#EFECE6] mt-1">2.50%</div>
              <p className="text-[10px] text-[#8E887E] mt-1.5 leading-relaxed">
                Designed to absorb credit losses during periods of severe financial distress without breaching baseline survival ratios.
              </p>
            </div>
            <div className="mt-4 pt-2 border-t border-[#2D3339]/50 flex justify-between items-center">
              <span className="text-[9px] uppercase tracking-wider text-emerald-400 font-bold bg-emerald-950/20 px-1 rounded">Fulfilled</span>
              <span className="font-mono text-xs text-[#A9A397]">Def: 2.5%</span>
            </div>
          </div>

          {/* Buffer 3: CCyB */}
          <div className="bg-[#121416] p-4 border border-[#2D3339] flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-[#A9A397] uppercase tracking-wider">3. Countercyclical (CCyB)</span>
              <div className="text-2xl font-mono text-[#EFECE6] mt-1">{(requirements.ccybRequirement * 100).toFixed(2)}%</div>
              <p className="text-[10px] text-[#8E887E] mt-1.5 leading-relaxed">
                Variable buffer deployed by the Bank of England Financial Policy Committee (FPC) during credit booms.
              </p>
            </div>
            <div className="mt-4 pt-2 border-t border-[#2D3339]/50 flex justify-between items-center">
              <span className="text-[9px] uppercase tracking-wider text-emerald-400 font-bold bg-emerald-950/20 px-1 rounded">Fulfilled</span>
              <span className="font-mono text-xs text-[#A9A397]">BoE set: 1.0%</span>
            </div>
          </div>

          {/* Buffer 4: SIFI */}
          <div className="bg-[#121416] p-4 border border-[#2D3339] flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-[#A9A397] uppercase tracking-wider">4. Systemic Anchor (SIFI)</span>
              <div className="text-2xl font-mono text-[#EFECE6] mt-1">{(requirements.sifiRequirement * 100).toFixed(2)}%</div>
              <p className="text-[10px] text-[#8E887E] mt-1.5 leading-relaxed">
                Reflects Rhino Bank's critical anchor role in Yorkshire SME lending and northern credit infrastructure.
              </p>
            </div>
            <div className="mt-4 pt-2 border-t border-[#2D3339]/50 flex justify-between items-center">
              <span className="text-[9px] uppercase tracking-wider text-emerald-400 font-bold bg-emerald-950/20 px-1 rounded">Fulfilled</span>
              <span className="font-mono text-xs text-[#A9A397]">Anchor: 1.0%</span>
            </div>
          </div>

          {/* Buffer 5: Combined Hurdle & Capital Surplus */}
          <div className="bg-[#1A1812] p-4 border border-[#523A1F] flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-[#c08267] uppercase tracking-wider font-semibold">5. Combined Requirement</span>
              <div className="text-2xl font-mono text-[#c08267] font-bold mt-1">{totalMinRequired.toFixed(2)}%</div>
              <p className="text-[10px] text-[#A9A397] mt-1.5 leading-relaxed">
                Your current CET1 ratio is <span className="text-[#EFECE6] font-mono font-bold">{cet1Ratio.toFixed(2)}%</span>, representing an organic capital buffer cushion of <span className="text-emerald-400 font-mono font-semibold">+{bufferOverRequirement.toFixed(2)}%</span>.
              </p>
            </div>
            <div className="mt-4 pt-2 border-t border-[#523A1F] flex justify-between items-center">
              <span className="text-[9px] uppercase tracking-wider text-[#c08267] font-bold">EXCELLENT</span>
              <span className="font-mono text-xs text-[#EFECE6]">Hurdle: {totalMinRequired.toFixed(1)}%</span>
            </div>
          </div>

        </div>
      </div>
      
    </div>
  );
}
