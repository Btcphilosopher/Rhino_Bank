import React from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell 
} from "recharts";
import { MapPin, Building2, TrendingUp, Compass, ShieldCheck } from "lucide-react";
import { REGIONAL_LENDING_DISTRIBUTION } from "../data/defaultData";

interface RegionalAnalysisProps {
  onAddAuditLog: (action: string, details: string) => void;
}

export default function RegionalAnalysis({ onAddAuditLog }: RegionalAnalysisProps) {
  
  const [selectedRegion, setSelectedRegion] = React.useState<string>("Yorkshire");

  const regionalDetails: Record<string, {
    offices: string[];
    dominantSectors: string[];
    averageRW: number;
    delinquencyRate: number;
    description: string;
  }> = {
    Yorkshire: {
      offices: ["Leeds HQ", "Sheffield Commercial Hub", "Hull Port Finance", "York Agricultural Office"],
      dominantSectors: ["SME Commerce", "Residential Housing Development", "Precision Manufacturing", "Agriculture"],
      averageRW: 48,
      delinquencyRate: 0.35,
      description: "The primary historical heartland of Rhino Bank. High density of retail mortgages and local engineering commercial accounts. Displays highly resilient credit performance."
    },
    London: {
      offices: ["City Office (Capital Markets)", "West End Real Estate Desk"],
      dominantSectors: ["Corporate Real Estate Finance", "Investment Securities", "Fintech Lending Syndications"],
      averageRW: 82,
      delinquencyRate: 0.65,
      description: "Mainly corporate credit facilities, large multi-family syndications and treasury operations. High average risk weight due to institutional real estate concentrations."
    },
    "North West": {
      offices: ["Manchester Spinners commercial office"],
      dominantSectors: ["Services & Tech Startups", "Logistics & Warehouse Real Estate"],
      averageRW: 64,
      delinquencyRate: 0.48,
      description: "Steady SME account growth, focusing on digital service companies and modern logistics parks."
    },
    Midlands: {
      offices: ["Birmingham Midlands commercial branch"],
      dominantSectors: ["Automotive Engineering", "Logistics Warehousing", "Mixed-Use Property development"],
      averageRW: 72,
      delinquencyRate: 0.52,
      description: "Credit book has moderate manufacturing exposures and retail developments. Risk weighting stable."
    },
    Scotland: {
      offices: ["Edinburgh Edinburgh Hub"],
      dominantSectors: ["High-Grade Securities", "Whisky Logistics", "Forestry Infrastructure"],
      averageRW: 38,
      delinquencyRate: 0.28,
      description: "Low delinquency rates, dominated by conservative residential portfolios and secured logistics paper."
    }
  };

  const handleRegionClick = (regionName: string) => {
    setSelectedRegion(regionName);
    onAddAuditLog(
      "Regional Query Execute",
      `Queried regional credit portfolio concentration details for: "${regionName}" class.`
    );
  };

  const activeDetails = regionalDetails[selectedRegion];

  // Map charts data
  const chartData = REGIONAL_LENDING_DISTRIBUTION.map(r => ({
    name: r.region,
    "Exposure (£M)": r.exposure,
    "Average Risk Weight (%)": regionalDetails[r.region]?.averageRW || 50,
    color: r.color
  }));

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#2D3339] pb-5">
        <span className="text-xs uppercase tracking-widest text-[#D97706] font-semibold">GEOGRAPHIC CONCENTRATION</span>
        <h1 className="text-3xl font-serif text-[#EFECE6] mt-1 tracking-tight">Regional Credit Concentrations</h1>
        <p className="text-[#A9A397] text-sm mt-1 max-w-xl">
          Analyse Rhino Bank's loan exposure by geographical region. Yorkshire remains our primary anchor market, supporting local economic growth.
        </p>
      </div>

      {/* Main Bento Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: Regional list (takes 5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <h3 className="font-serif text-[#EFECE6] text-lg mb-2 flex items-center gap-1.5">
            <Compass className="w-5 h-5 text-[#D97706]" />
            Regional Allocation
          </h3>
          
          <div className="space-y-3">
            {REGIONAL_LENDING_DISTRIBUTION.map((item) => {
              const isSelected = item.region === selectedRegion;
              return (
                <div
                  key={item.region}
                  onClick={() => handleRegionClick(item.region)}
                  className={`p-4 border transition cursor-pointer rounded flex justify-between items-center ${
                    isSelected 
                      ? "bg-[#1C1F22] border-[#D97706]" 
                      : "bg-[#181B1E] border-[#2D3339] hover:bg-[#1C1F22]/50"
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5" style={{ color: item.color }} />
                      <h4 className="font-semibold text-sm text-[#EFECE6]">{item.region} Book</h4>
                    </div>
                    <p className="text-[10px] text-[#8E887E]">Lending Share: <span className="text-[#EFECE6] font-semibold">{item.percentage}%</span></p>
                  </div>

                  <div className="text-right font-mono">
                    <span className="text-[#A9A397] text-[10px] uppercase block">Exposure</span>
                    <span className="text-sm font-bold text-[#EFECE6]">£{item.exposure.toLocaleString()}M</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Side: Localized Sector Breakdown & Stats (takes 7 cols) */}
        <div className="lg:col-span-7 bg-[#181B1E] border border-[#2D3339] p-6 flex flex-col justify-between">
          <div>
            <div className="border-b border-[#2D3339] pb-3 mb-4 flex justify-between items-center">
              <div>
                <span className="text-[10px] uppercase text-[#D97706] font-semibold tracking-wider">Localized Profile</span>
                <h3 className="font-serif text-[#EFECE6] text-xl mt-0.5">{selectedRegion} Segment Profile</h3>
              </div>
              <span className="text-xs font-mono text-[#A9A397]">Compliance Stable</span>
            </div>

            <p className="text-xs text-[#A9A397] leading-relaxed mb-6">
              {activeDetails.description}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Offices list */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-[#EFECE6] uppercase tracking-wider flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5 text-[#D97706]" /> Active Regional Offices
                </h4>
                <ul className="space-y-1.5 text-xs text-[#A9A397]">
                  {activeDetails.offices.map((office, idx) => (
                    <li key={idx} className="flex items-center gap-1.5 font-mono">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#D97706]" />
                      {office}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Sectors list */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-[#EFECE6] uppercase tracking-wider flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5 text-[#D97706]" /> Primary Sectors Funded
                </h4>
                <ul className="space-y-1.5 text-xs text-[#A9A397]">
                  {activeDetails.dominantSectors.map((sector, idx) => (
                    <li key={idx} className="flex items-center gap-1.5 font-mono">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#162E44]" />
                      {sector}
                    </li>
                  ))}
                </ul>
              </div>

            </div>

            {/* Metrics block */}
            <div className="grid grid-cols-2 gap-4 mt-8 pt-4 border-t border-[#2D3339]/50 text-xs">
              <div className="bg-[#121416] p-3 border border-[#2D3339] rounded">
                <span className="text-[#A9A397]">Average Risk Weight</span>
                <p className="text-xl font-mono font-bold text-[#D97706] mt-0.5">{activeDetails.averageRW}%</p>
              </div>
              <div className="bg-[#121416] p-3 border border-[#2D3339] rounded">
                <span className="text-[#A9A397]">Avg Delinquency Rate</span>
                <p className="text-xl font-mono font-bold text-[#EFECE6] mt-0.5">{activeDetails.delinquencyRate.toFixed(2)}%</p>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-[#2D3339] flex items-center gap-2 text-xs text-emerald-400 font-mono">
            <ShieldCheck className="w-4 h-4" />
            <span>Meets PRA regional concentration constraints limit (Max: 70%)</span>
          </div>
        </div>

      </div>

      {/* Chart representing Risk-Weight Densities across regions */}
      <div className="bg-[#181B1E] border border-[#2D3339] p-6">
        <h3 className="font-serif text-[#EFECE6] text-lg mb-4">Risk Density Density Comparison by Region</h3>
        
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#2D3339" />
              <XAxis dataKey="name" stroke="#8E887E" fontSize={11} />
              <YAxis domain={[0, 100]} stroke="#8E887E" fontSize={11} tickFormatter={(val) => `${val}%`} />
              <Tooltip 
                contentStyle={{ backgroundColor: "#1C1F22", border: "1px solid #3A3F45", borderRadius: "4px" }}
              />
              <Bar dataKey="Average Risk Weight (%)" fill="#D97706" maxBarSize={45}>
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

    </div>
  );
}
