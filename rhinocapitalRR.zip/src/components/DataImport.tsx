import React from "react";
import { 
  FileSpreadsheet, 
  Upload, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  FileCode, 
  RefreshCcw, 
  Check, 
  Sliders 
} from "lucide-react";
import { PortfolioSegment, CapitalMetrics } from "../types";

interface DataImportProps {
  portfolios: PortfolioSegment[];
  metrics: CapitalMetrics;
  onUpdatePortfolios: (updated: PortfolioSegment[]) => void;
  onUpdateMetrics: (newMetrics: Partial<CapitalMetrics>) => void;
  onAddAuditLog: (action: string, details: string) => void;
}

export default function DataImport({
  portfolios,
  metrics,
  onUpdatePortfolios,
  onUpdateMetrics,
  onAddAuditLog
}: DataImportProps) {
  
  const [dragActive, setDragActive] = React.useState<boolean>(false);
  const [selectedFormat, setSelectedFormat] = React.useState<"CSV" | "JSON" | "Parquet">("CSV");
  const [uploadStatus, setUploadStatus] = React.useState<"idle" | "uploading" | "success" | "error">("idle");
  const [report, setReport] = React.useState<{
    rowsProcessed: number;
    validatedExposure: number;
    reconciledRWA: number;
    warnings: string[];
  } | null>(null);

  // Predefined templates that can be simulated imported
  const templates = [
    {
      name: "Q2 Yorkshire Residential Mortgage Update",
      filename: "yorkshire_mortgages_q2_2026.csv",
      rows: 8500,
      exposure: 1250, // Increase mortgage exposure in Yorkshire
      category: "Mortgages" as const,
      riskWeight: 0.35,
      pd: 0.52,
      lgd: 15
    },
    {
      name: "SME Commercial Lending Expansion Feed",
      filename: "sme_growth_july_2026.json",
      rows: 1420,
      exposure: 450, // SME growth in North West / Yorkshire
      category: "SME" as const,
      riskWeight: 0.75,
      pd: 3.1,
      lgd: 40
    }
  ];

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      triggerUploadSimulation(e.dataTransfer.files[0].name, 4500, 850, "Mortgages");
    }
  };

  const handleManualSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      triggerUploadSimulation(e.target.files[0].name, 3200, 620, "Corporate");
    }
  };

  const triggerUploadSimulation = (
    filename: string, 
    rows: number, 
    exposureChange: number, 
    category: "Mortgages" | "SME" | "Corporate"
  ) => {
    setUploadStatus("uploading");
    setReport(null);

    setTimeout(() => {
      // Create a simulated record append
      const newSegment: PortfolioSegment = {
        id: `port-import-${Date.now()}`,
        name: `Imported feed: ${filename.slice(0, 30)}`,
        category: category,
        exposure: exposureChange,
        riskWeightDefault: category === "Mortgages" ? 0.35 : category === "SME" ? 0.75 : 0.85,
        riskWeightCurrent: category === "Mortgages" ? 0.35 : category === "SME" ? 0.75 : 0.85,
        pd: category === "Mortgages" ? 0.5 : category === "SME" ? 3.3 : 1.9,
        lgd: category === "Mortgages" ? 15 : category === "SME" ? 40 : 45,
        region: "Yorkshire",
        sector: "Retail Finance Aggregations"
      };

      const updatedPortfolios = [...portfolios, newSegment];
      onUpdatePortfolios(updatedPortfolios);

      // Recalculate global metrics
      let totalRWA = 0;
      let totalEAD = 0;
      let totalEL = 0;

      updatedPortfolios.forEach(p => {
        totalRWA += p.exposure * p.riskWeightCurrent;
        totalEAD += p.exposure;
        totalEL += p.exposure * (p.pd / 100) * (p.lgd / 100);
      });

      onUpdateMetrics({
        rwa: totalRWA,
        ead: totalEAD,
        expectedLoss: totalEL
      });

      setUploadStatus("success");
      setReport({
        rowsProcessed: rows,
        validatedExposure: exposureChange,
        reconciledRWA: Math.round(exposureChange * (category === "Mortgages" ? 0.35 : category === "SME" ? 0.75 : 0.85)),
        warnings: [
          "IFRS9 staging attributes missing. Automatically set standard Stage 1 provisions.",
          "Postcode geographic tags mapped directly to main Leeds hub."
        ]
      });

      onAddAuditLog(
        "Portfolio Feed Imported",
        `Parsed portfolio file "${filename}" (${selectedFormat}). Processed ${rows} facilities. Ingested +£${exposureChange}M in regulatory exposure. Reconciled RWA matches.`
      );
    }, 1500);
  };

  const handleLoadTemplate = (temp: typeof templates[0]) => {
    triggerUploadSimulation(temp.filename, temp.rows, temp.exposure, temp.category);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#2D3339] pb-5">
        <span className="text-xs uppercase tracking-widest text-[#D97706] font-semibold">DATA INGESTION</span>
        <h1 className="text-3xl font-serif text-[#EFECE6] mt-1 tracking-tight">Data Gateway & Reconciliation</h1>
        <p className="text-[#A9A397] text-sm mt-1 max-w-xl">
          Ingest raw banking asset files. The gateway automatically reconciles loan facility data, validates exposure schema tags, and maps RWA metrics.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Drag/Drop and selector (takes 7 cols) */}
        <div className="lg:col-span-7 bg-[#181B1E] border border-[#2D3339] p-6 space-y-6">
          <div>
            <h3 className="font-serif text-[#EFECE6] text-lg mb-1">Upload Portfolio Feed</h3>
            <p className="text-xs text-[#A9A397]">Select target regulatory ingestion format and drag your CSV, JSON or Excel ledger file below.</p>
          </div>

          {/* Ingestion format buttons */}
          <div className="grid grid-cols-3 gap-2 bg-[#121416] p-1 border border-[#2D3339] rounded">
            {["CSV", "JSON", "Parquet"].map(f => (
              <button
                key={f}
                type="button"
                onClick={() => setSelectedFormat(f as any)}
                className={`py-1.5 text-xs font-mono rounded transition font-bold ${
                  selectedFormat === f 
                    ? "bg-[#D97706] text-[#121416]" 
                    : "text-[#A9A397] hover:text-[#EFECE6]"
                }`}
              >
                {f} Standard
              </button>
            ))}
          </div>

          {/* Drag & Drop Zone */}
          <div 
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-lg p-10 text-center transition flex flex-col items-center justify-center min-h-64 cursor-pointer relative ${
              dragActive 
                ? "border-[#D97706] bg-[#D97706]/5" 
                : "border-[#2D3339] hover:border-[#D97706]/40"
            }`}
          >
            {uploadStatus === "idle" && (
              <div className="space-y-3">
                <div className="p-3 bg-[#121416] rounded-full border border-[#2D3339] inline-block text-[#D97706]">
                  <Upload className="w-8 h-8" />
                </div>
                <div className="text-sm font-semibold text-[#EFECE6]">Drag and drop your credit feed here</div>
                <p className="text-xs text-[#8E887E] max-w-sm mx-auto">
                  Supports .csv, .json and standard database extract templates containing columns for EAD, PD and LGD parameters.
                </p>
                <div className="pt-2">
                  <label className="bg-[#162E44] hover:bg-[#264B6C] border border-[#264B6C] text-[#EFECE6] font-semibold text-xs py-2 px-4 rounded cursor-pointer transition">
                    Browse File System
                    <input 
                      type="file"
                      onChange={handleManualSelect}
                      accept=".csv, .json, .xlsx"
                      className="hidden" 
                    />
                  </label>
                </div>
              </div>
            )}

            {uploadStatus === "uploading" && (
              <div className="space-y-4 text-center">
                <RefreshCcw className="w-10 h-10 text-[#D97706] animate-spin mx-auto" />
                <div className="text-sm text-[#EFECE6] font-medium">Validating credit exposures against Basel IV templates...</div>
                <div className="text-xs text-[#8E887E]">Reconciling total assets with ledger registers. Please wait.</div>
              </div>
            )}

            {uploadStatus === "success" && (
              <div className="space-y-4 text-center">
                <Check className="w-12 h-12 text-emerald-500 bg-emerald-950/20 border border-emerald-900/40 rounded-full p-2.5 mx-auto" />
                <div className="text-sm font-bold text-[#EFECE6]">Ingestion Pipeline Executed Successfully</div>
                <p className="text-xs text-[#A9A397]">Parsed, audited and injected into the active RWA engine memory safely.</p>
                <button 
                  onClick={() => setUploadStatus("idle")}
                  className="text-xs text-[#D97706] hover:underline"
                >
                  Upload another file
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Templates & Validation Report (takes 5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Predefined Templates */}
          <div className="bg-[#181B1E] border border-[#2D3339] p-6">
            <h3 className="font-serif text-[#EFECE6] text-base mb-2">Simulated Sandbox Ingestions</h3>
            <p className="text-xs text-[#A9A397] mb-4">Click to simulate parsing structured datasets to test platform calculations instantly.</p>

            <div className="space-y-3">
              {templates.map((temp, idx) => (
                <div 
                  key={idx}
                  onClick={() => handleLoadTemplate(temp)}
                  disabled={uploadStatus === "uploading"}
                  className="p-3 bg-[#121416] border border-[#2D3339] hover:border-[#D97706] transition rounded text-xs cursor-pointer flex justify-between items-center"
                >
                  <div className="space-y-1">
                    <span className="text-[9px] uppercase tracking-wider text-[#A9A397] font-semibold">{temp.category} Update</span>
                    <h4 className="font-semibold text-[#EFECE6]">{temp.name}</h4>
                    <span className="font-mono text-[10px] text-[#8E887E]">{temp.filename}</span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-[#D97706]" />
                </div>
              ))}
            </div>
          </div>

          {/* Validation Report */}
          {report && (
            <div className="bg-[#181B1E] border border-emerald-900/40 p-6 space-y-4 animate-fade-in">
              <h3 className="font-serif text-[#EFECE6] text-base flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                Reconciliation Audit Report
              </h3>
              
              <div className="space-y-3 text-xs font-mono">
                <div className="flex justify-between py-1.5 border-b border-[#2D3339]">
                  <span className="text-[#A9A397]">Total facilities processed</span>
                  <span className="text-[#EFECE6] font-bold">{report.rowsProcessed.toLocaleString()}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-[#2D3339]">
                  <span className="text-[#A9A397]">Exposure at Default parsed</span>
                  <span className="text-emerald-400 font-bold">+£{report.validatedExposure}M</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-[#2D3339]">
                  <span className="text-[#A9A397]">Calculated RWA increment</span>
                  <span className="text-[#D97706] font-bold">+£{report.reconciledRWA}M</span>
                </div>
              </div>

              {report.warnings.length > 0 && (
                <div className="space-y-1.5 pt-2">
                  <span className="text-[10px] uppercase text-[#D97706] font-bold tracking-wider block">Compliance Warnings</span>
                  {report.warnings.map((warn, i) => (
                    <div key={i} className="flex gap-2 text-[10px] text-[#A9A397] leading-relaxed">
                      <AlertCircle className="w-3.5 h-3.5 text-[#D97706] shrink-0" />
                      <span>{warn}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
