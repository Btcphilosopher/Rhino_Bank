import React from "react";
import { Sliders, HelpCircle, Shield, Sparkles, TrendingUp, RefreshCw, Layers } from "lucide-react";
import { CapitalMetrics, ScenarioLaboratoryAction, RegulatoryRequirements } from "../types";
import { INITIAL_SCENARIO_ACTIONS } from "../data/defaultData";

interface ScenarioLaboratoryProps {
  metrics: CapitalMetrics;
  requirements: RegulatoryRequirements;
  onAddAuditLog: (action: string, details: string) => void;
}

export default function ScenarioLaboratory({ 
  metrics, 
  requirements, 
  onAddAuditLog 
}: ScenarioLaboratoryProps) {
  
  // Local state for actions
  const [actions, setActions] = React.useState<ScenarioLaboratoryAction[]>(INITIAL_SCENARIO_ACTIONS);

  const toggleAction = (id: string) => {
    const updated = actions.map(act => {
      if (act.id === id) {
        const nextState = !act.active;
        onAddAuditLog(
          `Strategic Action ${nextState ? 'Enabled' : 'Disabled'}`,
          `Simulated scenario toggled: "${act.name}". Calculations re-run on available capital and portfolio RWA metrics.`
        );
        return { ...act, active: nextState };
      }
      return act;
    });
    setActions(updated);
  };

  const handleResetActions = () => {
    const reset = actions.map(act => ({ ...act, active: false }));
    setActions(reset);
    onAddAuditLog("Scenario Lab Reset", "All strategic sandbox actions disabled. Restored standard portfolio baseline ratios.");
  };

  // Calculate sandbox totals
  const sandboxImpact = React.useMemo(() => {
    let extraCET1 = 0;
    let rwaMultiplier = 1.0;

    actions.forEach(act => {
      if (act.active) {
        extraCET1 += act.impactCET1;
        // Risk weight changes sum together as modifiers to RWA
        rwaMultiplier += act.impactRW;
      }
    });

    const baseCET1 = metrics.cet1Capital;
    const baseRWA = metrics.rwa;

    const modifiedCET1 = baseCET1 + extraCET1;
    const modifiedRWA = Math.round(baseRWA * rwaMultiplier);
    
    const baseRatio = (baseCET1 / baseRWA) * 100;
    const modifiedRatio = (modifiedCET1 / modifiedRWA) * 100;

    const baseMinRequired = (requirements.minCet1 + requirements.ccbRequirement + requirements.ccybRequirement + requirements.sifiRequirement) * 100;

    return {
      baseCET1,
      baseRWA,
      baseRatio,
      modifiedCET1,
      modifiedRWA,
      modifiedRatio,
      extraCET1,
      rwaMultiplier,
      baseMinRequired
    };
  }, [actions, metrics, requirements]);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#2D3339] pb-5 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#D97706] font-semibold">STRATEGIC SANDBOX</span>
          <h1 className="text-3xl font-serif text-[#EFECE6] mt-1 tracking-tight">Strategic Scenario Laboratory</h1>
          <p className="text-[#A9A397] text-sm mt-1 max-w-xl">
            Simulate credit asset pivots, capital raises, and regulatory risk reliefs. Toggle programs to observe instant impacts on total CET1 adequacy metrics.
          </p>
        </div>

        <button 
          onClick={handleResetActions}
          className="text-xs border border-[#2D3339] text-[#A9A397] hover:text-[#EFECE6] hover:bg-[#1C1F22] px-3.5 py-1.5 rounded transition flex items-center gap-1.5 font-semibold"
        >
          <RefreshCw className="w-3.5 h-3.5 text-[#D97706]" /> Reset Sandbox
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Actions Toggles (takes 7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <h3 className="font-serif text-[#EFECE6] text-lg mb-2">Configurable Strategic Actions</h3>
          
          <div className="space-y-3">
            {actions.map((act) => (
              <div 
                key={act.id} 
                className={`p-4 border transition flex justify-between items-center gap-4 ${
                  act.active 
                    ? "bg-[#1C1F22] border-[#D97706]/70" 
                    : "bg-[#181B1E] border-[#2D3339] hover:bg-[#1C1F22]/40"
                }`}
              >
                <div className="space-y-1 max-w-md">
                  <div className="flex items-center gap-2">
                    <span className={`w-1.5 h-1.5 rounded-full ${act.active ? 'bg-[#D97706] animate-pulse' : 'bg-transparent'}`} />
                    <h4 className="font-semibold text-sm text-[#EFECE6]">{act.name}</h4>
                  </div>
                  <p className="text-[11px] text-[#8E887E] leading-relaxed">{act.description}</p>
                  
                  {/* Action impact indicators */}
                  <div className="flex gap-3 text-[10px] font-mono pt-1.5">
                    {act.impactCET1 > 0 && (
                      <span className="text-emerald-400 font-bold">CET1: +£{act.impactCET1}M</span>
                    )}
                    {act.impactRW !== 0 && (
                      <span className="text-amber-500 font-bold">RWA Modifier: {act.impactRW > 0 ? '+' : ''}{(act.impactRW * 100).toFixed(0)}%</span>
                    )}
                  </div>
                </div>

                {/* Big Toggle Switch */}
                <button
                  type="button"
                  onClick={() => toggleAction(act.id)}
                  className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 focus:outline-none ${
                    act.active ? "bg-[#D97706]" : "bg-[#121416] border border-[#2D3339]"
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-[#1C1F22] transition-transform duration-200 transform ${
                      act.active ? "translate-x-6 bg-[#EFECE6]" : "translate-x-0 bg-[#8E887E]"
                    }`}
                  />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Real-time Sandbox Impact Panel (takes 5 cols) */}
        <div className="lg:col-span-5 bg-[#181B1E] border border-[#2D3339] p-6 flex flex-col justify-between">
          <div>
            <h3 className="font-serif text-[#EFECE6] text-lg mb-2 flex items-center gap-1.5">
              <Sparkles className="w-5 h-5 text-[#D97706]" />
              Sandbox Capital Position
            </h3>
            <p className="text-xs text-[#A9A397] mb-6">Reconciling simulated available capital and RWA metrics compared to baseline.</p>

            <div className="space-y-4">
              {/* CET1 Ratio Comparison */}
              <div className="bg-[#121416] p-4 border border-[#2D3339] rounded">
                <span className="text-[10px] text-[#A9A397] uppercase tracking-wider block">Common Equity Tier 1 (CET1) Ratio</span>
                <div className="flex items-baseline gap-4 mt-1.5">
                  <div className="text-3xl font-mono text-[#D97706] font-bold">
                    {sandboxImpact.modifiedRatio.toFixed(2)}%
                  </div>
                  {sandboxImpact.modifiedRatio !== sandboxImpact.baseRatio && (
                    <div className="text-xs font-mono font-semibold text-emerald-400">
                      (Was: {sandboxImpact.baseRatio.toFixed(2)}% | delta: +{(sandboxImpact.modifiedRatio - sandboxImpact.baseRatio).toFixed(2)}%)
                    </div>
                  )}
                </div>
              </div>

              {/* Cash capital resource details */}
              <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                <div className="bg-[#121416]/50 p-3 border border-[#2D3339] rounded">
                  <span className="text-[#A9A397] text-[10px] block uppercase">CET1 Available</span>
                  <span className="text-[#EFECE6] text-base font-bold block mt-1">£{sandboxImpact.modifiedCET1.toLocaleString()}M</span>
                  {sandboxImpact.extraCET1 > 0 && (
                    <span className="text-[10px] text-emerald-400 font-bold block mt-0.5">+£{sandboxImpact.extraCET1}M delta</span>
                  )}
                </div>
                <div className="bg-[#121416]/50 p-3 border border-[#2D3339] rounded">
                  <span className="text-[#A9A397] text-[10px] block uppercase">Total RWA</span>
                  <span className="text-[#EFECE6] text-base font-bold block mt-1">£{sandboxImpact.modifiedRWA.toLocaleString()}M</span>
                  {sandboxImpact.modifiedRWA !== sandboxImpact.baseRWA && (
                    <span className="text-[10px] text-emerald-400 font-bold block mt-0.5">
                      {sandboxImpact.modifiedRWA < sandboxImpact.baseRWA ? '-' : '+'}
                      £{Math.abs(sandboxImpact.modifiedRWA - sandboxImpact.baseRWA).toLocaleString()}M delta
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Sandbox Summary / Compliance Assessment */}
          <div className="mt-6 pt-4 border-t border-[#2D3339]">
            <h4 className="text-xs text-[#EFECE6] font-semibold uppercase tracking-wider mb-2 flex items-center gap-1">
              <Shield className="w-4 h-4 text-[#D97706]" /> Sandbox Assessment
            </h4>
            
            <p className="text-xs text-[#A9A397] leading-relaxed">
              {sandboxImpact.modifiedRatio >= 16.5 ? (
                <span>Strategic maneuvers place Rhino Bank in an <strong className="text-emerald-400">extremely highly capitalized position</strong>. Capital buffers exceed Bank of England FPC baseline targets, offering significant headroom to pursue aggressive lending growth in Yorkshire.</span>
              ) : sandboxImpact.modifiedRatio >= 15.0 ? (
                <span>Simulated actions maintain a <strong className="text-emerald-400">robust and stable</strong> capital cushion. Sufficiently handles standard stress buffers and supports steady organic lending expansion plans.</span>
              ) : (
                <span>Actions suggest tight headroom. Keep monitoring portfolio credit default levels. Capital cushion is thin but compliant with regulatory minimum of <strong className="text-[#EFECE6]">{sandboxImpact.baseMinRequired.toFixed(1)}%</strong>.</span>
              )}
            </p>
          </div>
        </div>

      </div>

    </div>
  );
}
