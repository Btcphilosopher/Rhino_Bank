import React from "react";
import { Terminal, Code, Cpu, FileText, CheckCircle, Play, Sparkles } from "lucide-react";

interface RustRConsoleProps {
  onAddAuditLog: (action: string, details: string) => void;
}

export default function RustRConsole({ onAddAuditLog }: RustRConsoleProps) {
  const [activeRuntime, setActiveRuntime] = React.useState<"rust" | "r">("rust");
  const [consoleLogs, setConsoleLogs] = React.useState<string[]>([
    "System initialized. Dual-runtime IPC socket connection listening on localhost:4040.",
    "Rust Portfolio Aggregator initialized in 4.2ms. Core loaded.",
    "R forecasting engine attached. ARIMA model environment loaded successfully.",
    "Ready for regulatory portfolio calculation queries."
  ]);
  const [isExecuting, setIsExecuting] = React.useState<boolean>(false);

  const rustCodeSnippet = `/// Calculates Basel IV Standardised Credit Risk Weighted Assets (RWA)
///
/// # Arguments
/// * \`exposure\` - Exposure at Default (EAD) in Millions of GBP.
/// * \`risk_weight\` - The regulatory risk weight percentage as a coefficient (e.g. 0.35).
/// * \`supporting_factor\` - SME regional discount factor if applicable.
///
/// # Returns
/// The risk-weighted asset value.
///
/// # Assumptions
/// Under Basel IV, SME loans are eligible for a 0.7612 supporting factor.
///
/// # Example
/// \`\`\`
/// let rwa = calculate_rwa(100.0, 0.75, Some(0.7612));
/// assert_eq!(rwa, 57.09);
/// \`\`\`
pub fn calculate_rwa(
    exposure: f64, 
    risk_weight: f64, 
    supporting_factor: Option<f64>
) -> f64 {
    let base_rwa = exposure * risk_weight;
    match supporting_factor {
        Some(sf) => base_rwa * sf,
        None => base_rwa
    }
}`;

  const rCodeSnippet = `#' Forecasting Banking Capital Ratios via Monte Carlo & Auto-ARIMA
#'
#' @param capital_history Numeric vector of historical CET1 ratios.
#' @param rwa_projections Projections of future RWA values.
#' @param n_simulations Number of paths to run for Monte Carlo bounds.
#' @return A list containing forecast matrices and prediction intervals.
#' @export
#' @examples
#' forecast_capital(c(14.2, 14.5, 14.9), c(18400, 18500), 5000)
forecast_capital <- function(capital_history, rwa_projections, n_simulations = 10000) {
  require(forecast)
  require(stats)
  
  # Fit local ARIMA model
  fit <- auto.arima(ts(capital_history, frequency = 4))
  point_fc <- forecast(fit, h = length(rwa_projections))
  
  # Run Monte Carlo paths for volatility distribution
  sim_paths <- matrix(NA, nrow = n_simulations, ncol = length(rwa_projections))
  for(i in 1:n_simulations) {
    sim_paths[i, ] <- simulate(fit, nsim = length(rwa_projections))
  }
  
  # Extract prediction intervals
  lower_bounds <- apply(sim_paths, 2, quantile, probs = 0.05)
  upper_bounds <- apply(sim_paths, 2, quantile, probs = 0.95)
  
  return(list(
    mean = point_fc$mean,
    lower_95 = lower_bounds,
    upper_95 = upper_bounds
  ))
}`;

  const executePipeline = (type: "rust_aggregate" | "r_forecast" | "reconcile") => {
    setIsExecuting(true);
    let newLogs: string[] = [];

    if (type === "rust_aggregate") {
      newLogs = [
        `[${new Date().toISOString().split('T')[1].slice(0, 8)}] [INFO] rhino_core::pipeline: Triggering full risk weight calculation pipeline...`,
        `[${new Date().toISOString().split('T')[1].slice(0, 8)}] [DEBUG] rhino_core::portfolio: Aggregating 11 credit booking classes.`,
        `[${new Date().toISOString().split('T')[1].slice(0, 8)}] [INFO] rhino_core::risk_weight: Running standard Credit Risk Weights according to PRA regulations.`,
        `[${new Date().toISOString().split('T')[1].slice(0, 8)}] [SUCCESS] rhino_core::pipeline: Basel IV RWA calculations completed successfully.`,
        `[${new Date().toISOString().split('T')[1].slice(0, 8)}] [SUCCESS] rhino_core::metrics: Calculated RWA: £18,450M in 241 microseconds. Memory allocated: 48 bytes.`
      ];
      onAddAuditLog("Rust Core Aggregator", "Re-aggregated and matched credit segments against Basel IV risk weight rules.");
    } else if (type === "r_forecast") {
      newLogs = [
        `[${new Date().toISOString().split('T')[1].slice(0, 8)}] > library(forecast)`,
        `[${new Date().toISOString().split('T')[1].slice(0, 8)}] > fit <- auto.arima(ts(historical_cet1_ratio))`,
        `[${new Date().toISOString().split('T')[1].slice(0, 8)}] [INFO] Fitting ARIMA(1,1,0) drift coefficient...`,
        `[${new Date().toISOString().split('T')[1].slice(0, 8)}] > sim_paths <- forecast_capital(historical_cet1_ratio, projected_rwa, n_simulations = 10000)`,
        `[${new Date().toISOString().split('T')[1].slice(0, 8)}] [SUCCESS] R forecasting completed. Extracted confidence bounds: Lower 14.85%, Upper 17.12%`
      ];
      onAddAuditLog("R Forecasting Engine", "Generated auto-ARIMA capital ratio projections with 10,000 Monte Carlo paths.");
    } else {
      newLogs = [
        `[${new Date().toISOString().split('T')[1].slice(0, 8)}] [INFO] rhino_core::audit: Starting balance sheet available capital reconciliation...`,
        `[${new Date().toISOString().split('T')[1].slice(0, 8)}] [DEBUG] rhino_core::reconcile: Verifying ledger entries against general ledger API.`,
        `[${new Date().toISOString().split('T')[1].slice(0, 8)}] [SUCCESS] rhino_core::reconcile: Zero mismatch detected. Common Equity Tier 1 capital verified at exactly £2,950M.`
      ];
      onAddAuditLog("Prudential Ledger Audit", "Reconciled available capital metrics against active ledger entries.");
    }

    // Print logs progressively
    let index = 0;
    const interval = setInterval(() => {
      if (index < newLogs.length) {
        setConsoleLogs(prev => [...prev, newLogs[index]]);
        index++;
      } else {
        clearInterval(interval);
        setIsExecuting(false);
      }
    }, 200);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#2D3339] pb-5">
        <span className="text-xs uppercase tracking-widest text-[#D97706] font-semibold">QUANTITATIVE INFRASTRUCTURE</span>
        <h1 className="text-3xl font-serif text-[#EFECE6] mt-1 tracking-tight">Dual-Runtime Engine Console</h1>
        <p className="text-[#A9A397] text-sm mt-1 max-w-xl">
          Visual interface for the underlying computational stack. Execute high-performance credit aggregation compiled in Rust and statistical forecasting run in R.
        </p>
      </div>

      {/* Grid of CLI Executers & Code Viewers */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* CLI Terminal (takes 6 cols) */}
        <div className="lg:col-span-6 bg-[#0E1012] border border-[#2D3339] p-5 flex flex-col justify-between h-[520px]">
          <div>
            <div className="flex justify-between items-center border-b border-[#2D3339] pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-[#D97706]" />
                <span className="text-xs font-bold text-[#EFECE6] uppercase tracking-wider font-mono">Core Execution Pipeline</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/30 px-1.5 py-0.5 rounded border border-emerald-900/30">ONLINE</span>
            </div>

            {/* Simulated interactive run triggers */}
            <div className="grid grid-cols-3 gap-2 mb-4">
              <button
                type="button"
                disabled={isExecuting}
                onClick={() => executePipeline("rust_aggregate")}
                className="bg-[#181B1E] border border-[#2D3339] hover:border-[#D97706] text-left p-2.5 rounded transition text-[#EFECE6]"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[9px] uppercase text-[#A9A397] font-semibold">Rust Pipeline</span>
                  <Play className="w-3 h-3 text-emerald-400" />
                </div>
                <div className="text-xs font-semibold mt-1 font-mono">Calculate RWAs</div>
              </button>
              
              <button
                type="button"
                disabled={isExecuting}
                onClick={() => executePipeline("r_forecast")}
                className="bg-[#181B1E] border border-[#2D3339] hover:border-[#D97706] text-left p-2.5 rounded transition text-[#EFECE6]"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[9px] uppercase text-[#A9A397] font-semibold">R Analytics</span>
                  <Play className="w-3 h-3 text-emerald-400" />
                </div>
                <div className="text-xs font-semibold mt-1 font-mono">Forecast ARIMA</div>
              </button>

              <button
                type="button"
                disabled={isExecuting}
                onClick={() => executePipeline("reconcile")}
                className="bg-[#181B1E] border border-[#2D3339] hover:border-[#D97706] text-left p-2.5 rounded transition text-[#EFECE6]"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[9px] uppercase text-[#A9A397] font-semibold">Audit Engine</span>
                  <Play className="w-3 h-3 text-emerald-400" />
                </div>
                <div className="text-xs font-semibold mt-1 font-mono">Verify Capital</div>
              </button>
            </div>

            {/* Log terminal */}
            <div className="bg-[#0A0C0E] p-4 rounded border border-[#2D3339] h-72 overflow-y-auto font-mono text-[11px] text-[#A9A397] space-y-2">
              {consoleLogs.map((log, index) => (
                <div key={index} className="leading-relaxed">
                  {log.includes("[SUCCESS]") ? (
                    <span className="text-emerald-400 font-semibold">{log}</span>
                  ) : log.includes("[INFO]") ? (
                    <span className="text-sky-400">{log}</span>
                  ) : log.includes("[DEBUG]") ? (
                    <span className="text-indigo-400">{log}</span>
                  ) : log.startsWith(">") ? (
                    <span className="text-[#D97706] font-bold">{log}</span>
                  ) : (
                    <span>{log}</span>
                  )}
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => setConsoleLogs(["Console cleared. Listening..."])}
            className="text-[10px] text-right text-[#8E887E] hover:text-[#EFECE6] font-mono mt-2"
          >
            Clear Terminal Output
          </button>
        </div>

        {/* Code Snippet Viewer (takes 6 cols) */}
        <div className="lg:col-span-6 bg-[#181B1E] border border-[#2D3339] p-5 flex flex-col justify-between h-[520px]">
          <div>
            <div className="flex justify-between items-center border-b border-[#2D3339] pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Code className="w-4 h-4 text-[#D97706]" />
                <h3 className="text-xs font-bold text-[#EFECE6] uppercase tracking-wider font-mono">Module Source Viewer</h3>
              </div>
              
              <div className="flex gap-1 bg-[#121416] p-0.5 rounded border border-[#2D3339]">
                <button
                  onClick={() => setActiveRuntime("rust")}
                  className={`px-2.5 py-0.5 rounded text-[10px] font-mono transition ${
                    activeRuntime === "rust" 
                      ? "bg-[#D97706] text-[#121416] font-bold" 
                      : "text-[#A9A397] hover:text-[#EFECE6]"
                  }`}
                >
                  rhino_core.rs
                </button>
                <button
                  onClick={() => setActiveRuntime("r")}
                  className={`px-2.5 py-0.5 rounded text-[10px] font-mono transition ${
                    activeRuntime === "r" 
                      ? "bg-[#D97706] text-[#121416] font-bold" 
                      : "text-[#A9A397] hover:text-[#EFECE6]"
                  }`}
                >
                  forecast_engine.R
                </button>
              </div>
            </div>

            {/* Actual code representation */}
            <div className="bg-[#121416] p-4 rounded border border-[#2D3339] h-80 overflow-y-auto font-mono text-[11px] text-[#A9A397] leading-relaxed select-all">
              <pre className="whitespace-pre-wrap">
                {activeRuntime === "rust" ? rustCodeSnippet : rCodeSnippet}
              </pre>
            </div>
          </div>

          <div className="mt-4 p-3.5 bg-[#121416] border border-[#2D3339] rounded flex items-center gap-2 text-xs text-[#A9A397]">
            <Cpu className="w-4 h-4 text-[#D97706] shrink-0" />
            <div>
              <span className="text-[#EFECE6] font-semibold font-mono text-[10px] block uppercase">Runtime Architecture Node</span>
              Underlying code runs compiled in LLVM Rust release binary, feeding the output matrix directly to the R stats package for automated Monte Carlo risk bounds.
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
