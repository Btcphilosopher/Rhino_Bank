import React from "react";
import { CapitalMetrics, RegulatoryRequirements } from "../types";
import { ShieldCheck, Plus, ListFilter, ArrowUpRight, HelpCircle } from "lucide-react";

interface CapitalPositionProps {
  metrics: CapitalMetrics;
  requirements: RegulatoryRequirements;
  onUpdateMetrics: (newMetrics: Partial<CapitalMetrics>) => void;
  onAddAuditLog: (action: string, details: string) => void;
}

export default function CapitalPosition({
  metrics,
  requirements,
  onUpdateMetrics,
  onAddAuditLog
}: CapitalPositionProps) {
  
  // Local states for inputs
  const [injectAmount, setInjectAmount] = React.useState<string>("");
  const [injectType, setInjectType] = React.useState<"CET1" | "AT1" | "Tier2">("CET1");
  const [showExplanation, setShowExplanation] = React.useState<boolean>(false);

  // Capital structure items
  const cet1Breakdown = {
    shareCapital: 950,
    retainedEarnings: 1950,
    reservesAoci: 150,
    deductions: -100 // Goodwill/Intangible deductions
  };

  const handleCapitalInjection = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(injectAmount);
    if (isNaN(amount) || amount <= 0) return;

    let updatedMetrics: Partial<CapitalMetrics> = {};
    if (injectType === "CET1") {
      updatedMetrics.cet1Capital = metrics.cet1Capital + amount;
      onAddAuditLog(
        "Capital Injection (CET1)",
        `Successfully injected £${amount}M of Common Equity Tier 1 capital. Retained Earnings / Share Capital boosted.`
      );
    } else if (injectType === "AT1") {
      updatedMetrics.at1Capital = metrics.at1Capital + amount;
      onAddAuditLog(
        "Capital Issuance (AT1)",
        `Issued £${amount}M in Perpetual Contingent Convertible (CoCo) Tier 1 bonds.`
      );
    } else {
      updatedMetrics.tier2Capital = metrics.tier2Capital + amount;
      onAddAuditLog(
        "Debt Issuance (Tier 2)",
        `Issued £${amount}M in subordinated Tier 2 term debt facilities.`
      );
    }

    onUpdateMetrics(updatedMetrics);
    setInjectAmount("");
  };

  const handleResetCapital = () => {
    onUpdateMetrics({
      cet1Capital: 2950,
      at1Capital: 450,
      tier2Capital: 600
    });
    onAddAuditLog("Capital Reset", "Prudential available capital reset to baseline values (£4,000M total capital resources).");
  };

  const cet1Ratio = (metrics.cet1Capital / metrics.rwa) * 100;
  const tier1Ratio = ((metrics.cet1Capital + metrics.at1Capital) / metrics.rwa) * 100;
  const totalCapitalRatio = ((metrics.cet1Capital + metrics.at1Capital + metrics.tier2Capital) / metrics.rwa) * 100;
  const totalMinRequired = (requirements.minCet1 + requirements.ccbRequirement + requirements.ccybRequirement + requirements.sifiRequirement) * 100;

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#2D3339] pb-5 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#D97706] font-semibold">AVAILABLE RESOURCES</span>
          <h1 className="text-3xl font-serif text-[#EFECE6] mt-1 tracking-tight">Regulatory Capital Resources</h1>
          <p className="text-[#A9A397] text-sm mt-1 max-w-xl">
            Detailed view of Rhino Bank's capital tiers. Direct tracking of high-loss-absorbing Common Equity Tier 1 against hybrid instruments and subordinated debt.
          </p>
        </div>
        
        <button 
          onClick={handleResetCapital}
          className="text-xs border border-[#2D3339] text-[#A9A397] hover:text-[#EFECE6] hover:bg-[#1C1F22] px-3 py-1.5 rounded transition"
        >
          Reset to Baseline
        </button>
      </div>

      {/* Grid of Capital Tiers & Ratios */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Tier 1 - Common Equity (CET1) */}
        <div className="bg-[#181B1E] border border-[#2D3339] p-6 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-3">
              <span className="text-xs uppercase tracking-wider text-[#A9A397] font-semibold">Tier 1: CET1 Capital</span>
              <span className="text-xs font-mono text-[#D97706] bg-[#D97706]/10 px-2 py-0.5 rounded">Highest Quality</span>
            </div>
            
            <div className="text-4xl font-serif font-semibold text-[#EFECE6] mt-2">
              £{metrics.cet1Capital.toLocaleString()}M
            </div>
            
            <div className="text-xs text-[#A9A397] mt-1">
              Current Ratio: <span className="font-mono text-[#EFECE6] font-bold">{cet1Ratio.toFixed(2)}%</span>
            </div>

            <p className="text-xs text-[#8E887E] mt-4 leading-relaxed">
              Consists of fully paid common shares, audited retained earnings, and accumulated other comprehensive income, less regulatory deductibles (goodwill, deferred tax assets).
            </p>

            <div className="mt-6 space-y-2 border-t border-[#2D3339]/60 pt-4">
              <div className="flex justify-between text-xs py-1">
                <span className="text-[#A9A397]">Ordinary Share Capital</span>
                <span className="font-mono text-[#EFECE6]">£{cet1Breakdown.shareCapital}M</span>
              </div>
              <div className="flex justify-between text-xs py-1">
                <span className="text-[#A9A397]">Retained Earnings (Audited)</span>
                <span className="font-mono text-[#EFECE6]">£{(metrics.cet1Capital - cet1Breakdown.shareCapital - cet1Breakdown.reservesAoci - cet1Breakdown.deductions).toLocaleString()}M</span>
              </div>
              <div className="flex justify-between text-xs py-1">
                <span className="text-[#A9A397]">AOCI & Other Reserves</span>
                <span className="font-mono text-[#EFECE6]">£{cet1Breakdown.reservesAoci}M</span>
              </div>
              <div className="flex justify-between text-xs py-1 text-red-400">
                <span>Regulatory Goodwill Deductions</span>
                <span className="font-mono">£{cet1Breakdown.deductions}M</span>
              </div>
            </div>
          </div>
          
          <div className="mt-6 pt-4 border-t border-[#2D3339] flex items-center gap-1.5 text-xs text-[#D97706]">
            <ShieldCheck className="w-4 h-4" />
            <span>Pillar 1 minimum coverage: 450% of requirement</span>
          </div>
        </div>

        {/* Tier 1 - Additional (AT1) */}
        <div className="bg-[#181B1E] border border-[#2D3339] p-6 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-3">
              <span className="text-xs uppercase tracking-wider text-[#A9A397] font-semibold">Tier 1: AT1 Capital</span>
              <span className="text-xs font-mono text-[#6F7F91] bg-slate-800 px-2 py-0.5 rounded">Hybrid Instruments</span>
            </div>
            
            <div className="text-4xl font-serif font-semibold text-[#EFECE6] mt-2">
              £{metrics.at1Capital.toLocaleString()}M
            </div>
            
            <div className="text-xs text-[#A9A397] mt-1">
              Combined Tier 1: <span className="font-mono text-[#EFECE6] font-bold">{tier1Ratio.toFixed(2)}%</span>
            </div>

            <p className="text-xs text-[#8E887E] mt-4 leading-relaxed">
              Consists of deeply subordinated securities (e.g., Contingent Convertible Bonds, or "CoCos") with no fixed maturity, featuring discretionary coupons and mandatory write-down trigger thresholds if CET1 falls below 7.00%.
            </p>

            <div className="mt-6 space-y-2 border-t border-[#2D3339]/60 pt-4">
              <div className="flex justify-between text-xs py-1">
                <span className="text-[#A9A397]">Contingent Convertibles (CoCos)</span>
                <span className="font-mono text-[#EFECE6]">£{metrics.at1Capital}M</span>
              </div>
              <div className="flex justify-between text-xs py-1">
                <span className="text-[#A9A397]">Trigger Event Threshold</span>
                <span className="font-mono text-[#D97706] font-semibold">7.00% CET1</span>
              </div>
              <div className="flex justify-between text-xs py-1">
                <span className="text-[#A9A397]">Average Coupon Rate</span>
                <span className="font-mono text-[#EFECE6]">6.85% (GBP)</span>
              </div>
              <div className="flex justify-between text-xs py-1 text-emerald-400">
                <span>Distance to Trigger</span>
                <span className="font-mono font-semibold">+{ (cet1Ratio - 7).toFixed(2) }%</span>
              </div>
            </div>
          </div>
          
          <div className="mt-6 pt-4 border-t border-[#2D3339] flex items-center gap-1.5 text-xs text-[#A9A397]">
            <HelpCircle 
              className="w-4 h-4 cursor-pointer text-[#D97706]" 
              onClick={() => setShowExplanation(!showExplanation)}
            />
            <span>AT1 instruments can absorb ongoing losses</span>
          </div>
        </div>

        {/* Tier 2 Capital */}
        <div className="bg-[#181B1E] border border-[#2D3339] p-6 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-3">
              <span className="text-xs uppercase tracking-wider text-[#A9A397] font-semibold">Tier 2 Capital</span>
              <span className="text-xs font-mono text-[#6F7F91] bg-slate-800 px-2 py-0.5 rounded">Supplementary Debt</span>
            </div>
            
            <div className="text-4xl font-serif font-semibold text-[#EFECE6] mt-2">
              £{metrics.tier2Capital.toLocaleString()}M
            </div>
            
            <div className="text-xs text-[#A9A397] mt-1">
              Total Capital Ratio: <span className="font-mono text-[#EFECE6] font-bold">{totalCapitalRatio.toFixed(2)}%</span>
            </div>

            <p className="text-xs text-[#8E887E] mt-4 leading-relaxed">
              Consists of subordinated term debt instruments and general credit risk provisions. Less loss-absorbent than Tier 1 capital, but eligible as regulatory cushion under Basel metrics.
            </p>

            <div className="mt-6 space-y-2 border-t border-[#2D3339]/60 pt-4">
              <div className="flex justify-between text-xs py-1">
                <span className="text-[#A9A397]">Subordinated Sub-Debt Bonds</span>
                <span className="font-mono text-[#EFECE6]">£{(metrics.tier2Capital - 80).toLocaleString()}M</span>
              </div>
              <div className="flex justify-between text-xs py-1">
                <span className="text-[#A9A397]">Eligible IFRS9 Stage 1 Provisions</span>
                <span className="font-mono text-[#EFECE6]">£80M</span>
              </div>
              <div className="flex justify-between text-xs py-1">
                <span className="text-[#A9A397]">Minimum Original Maturity</span>
                <span className="font-mono text-[#EFECE6]">5 Years</span>
              </div>
              <div className="flex justify-between text-xs py-1 text-emerald-400">
                <span>Amortization Factor</span>
                <span className="font-mono">100.0% (Stable)</span>
              </div>
            </div>
          </div>
          
          <div className="mt-6 pt-4 border-t border-[#2D3339] flex items-center gap-1.5 text-xs text-[#A9A397]">
            <HelpCircle className="w-4 h-4 text-[#D97706]" />
            <span>Eligible up to 2.0% of total RWA</span>
          </div>
        </div>

      </div>

      {showExplanation && (
        <div className="bg-[#121416] border border-[#D97706]/40 p-4 rounded text-xs text-[#A9A397] space-y-2">
          <h4 className="font-bold text-[#EFECE6] flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#D97706]" /> Understanding AT1 Contingent Convertibles ("CoCos")
          </h4>
          <p>
            Contingent Convertibles (CoCos) are debt instruments designed to protect a bank's capital position when distress hits. If Rhino Bank's CET1 ratio slips below 7.00% (the contractual conversion point), these bonds are automatically written down or converted into standard voting ordinary equity, immediately boosting CET1 available capital resources. This prevents insolvency without requiring taxpayer-funded bailouts.
          </p>
        </div>
      )}

      {/* Interactive Capital Injection Laboratory */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Simulation form - takes 5 columns */}
        <div className="lg:col-span-5 bg-[#181B1E] border border-[#2D3339] p-6">
          <h3 className="font-serif text-[#EFECE6] text-lg mb-2">Simulate Capital Issuance</h3>
          <p className="text-xs text-[#A9A397] mb-4">Inject funds or issue hybrid debt securities to test impact on capital buffer ratios instantly.</p>
          
          <form onSubmit={handleCapitalInjection} className="space-y-4">
            <div>
              <label className="block text-xs uppercase text-[#A9A397] mb-1.5 font-semibold">Asset Tier to Inject</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setInjectType("CET1")}
                  className={`py-2 text-xs border rounded transition text-center font-mono font-bold ${
                    injectType === "CET1"
                      ? "bg-[#D97706] text-[#121416] border-[#D97706]"
                      : "bg-[#121416] text-[#A9A397] border-[#2D3339] hover:bg-[#1C1F22]"
                  }`}
                >
                  CET1 (Equity)
                </button>
                <button
                  type="button"
                  onClick={() => setInjectType("AT1")}
                  className={`py-2 text-xs border rounded transition text-center font-mono font-bold ${
                    injectType === "AT1"
                      ? "bg-[#D97706] text-[#121416] border-[#D97706]"
                      : "bg-[#121416] text-[#A9A397] border-[#2D3339] hover:bg-[#1C1F22]"
                  }`}
                >
                  AT1 (Hybrid)
                </button>
                <button
                  type="button"
                  onClick={() => setInjectType("Tier2")}
                  className={`py-2 text-xs border rounded transition text-center font-mono font-bold ${
                    injectType === "Tier2"
                      ? "bg-[#D97706] text-[#121416] border-[#D97706]"
                      : "bg-[#121416] text-[#A9A397] border-[#2D3339] hover:bg-[#1C1F22]"
                  }`}
                >
                  Tier 2 (Sub)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase text-[#A9A397] mb-1.5 font-semibold">Issuance Amount (£M)</label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-[#8E887E] text-sm font-mono">£</span>
                <input
                  type="number"
                  value={injectAmount}
                  onChange={(e) => setInjectAmount(e.target.value)}
                  placeholder="e.g. 200"
                  className="w-full bg-[#121416] border border-[#2D3339] rounded pl-8 pr-12 py-2 text-sm text-[#EFECE6] font-mono focus:outline-none focus:border-[#D97706]"
                />
                <span className="absolute right-3 top-2.5 text-[#8E887E] text-xs font-mono">Million</span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-[#162E44] border border-[#264B6C] hover:bg-[#264B6C] text-[#EFECE6] text-xs font-semibold uppercase py-2.5 rounded transition flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4 text-[#D97706]" /> Execute Issuance Pipeline
            </button>
          </form>
        </div>

        {/* Dynamic calculation board - takes 7 columns */}
        <div className="lg:col-span-7 bg-[#181B1E] border border-[#2D3339] p-6 flex flex-col justify-between">
          <div>
            <h3 className="font-serif text-[#EFECE6] text-lg mb-1">Prudential Ratio Reconciliation</h3>
            <p className="text-xs text-[#A9A397] mb-4">Comparison of current metrics against Basel III regulatory thresholds and systemic buffers.</p>

            <div className="space-y-3 mt-4">
              {/* CET1 Bar */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-[#A9A397] font-semibold">Common Equity Tier 1 (CET1)</span>
                  <span className="font-mono text-[#EFECE6] font-bold">{cet1Ratio.toFixed(2)}% <span className="text-[10px] text-[#8E887E] font-normal">(Min Required: {totalMinRequired.toFixed(1)}%)</span></span>
                </div>
                <div className="w-full bg-[#121416] h-3 rounded-full overflow-hidden border border-[#2D3339]">
                  <div 
                    className="h-full bg-gradient-to-r from-[#D97706] to-[#E07A25] transition-all duration-500" 
                    style={{ width: `${Math.min((cet1Ratio / 18) * 100, 100)}%` }}
                  />
                </div>
              </div>

              {/* Tier 1 Bar */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-[#A9A397] font-semibold">Tier 1 Ratio (CET1 + AT1)</span>
                  <span className="font-mono text-[#EFECE6] font-bold">{tier1Ratio.toFixed(2)}% <span className="text-[10px] text-[#8E887E] font-normal">(Min Required: {(totalMinRequired + 1.5).toFixed(1)}%)</span></span>
                </div>
                <div className="w-full bg-[#121416] h-3 rounded-full overflow-hidden border border-[#2D3339]">
                  <div 
                    className="h-full bg-gradient-to-r from-[#162E44] to-[#264B6C] transition-all duration-500" 
                    style={{ width: `${Math.min((tier1Ratio / 20) * 100, 100)}%` }}
                  />
                </div>
              </div>

              {/* Total Capital Bar */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-[#A9A397] font-semibold">Total Capital Adequacy Ratio</span>
                  <span className="font-mono text-[#EFECE6] font-bold">{totalCapitalRatio.toFixed(2)}% <span className="text-[10px] text-[#8E887E] font-normal">(Min Required: {(totalMinRequired + 3.5).toFixed(1)}%)</span></span>
                </div>
                <div className="w-full bg-[#121416] h-3 rounded-full overflow-hidden border border-[#2D3339]">
                  <div 
                    className="h-full bg-gradient-to-r from-teal-800 to-emerald-600 transition-all duration-500" 
                    style={{ width: `${Math.min((totalCapitalRatio / 24) * 100, 100)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-[#121416] border border-[#2D3339] rounded">
            <h4 className="text-xs text-[#EFECE6] font-semibold uppercase tracking-wider mb-2">Calculated Capital Cushion</h4>
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-[#A9A397]">CET1 Buffer Cash Value</span>
                <p className="text-lg font-serif font-bold text-[#EFECE6] mt-0.5">
                  £{Math.round(metrics.cet1Capital - (metrics.rwa * requirements.minCet1)).toLocaleString()}M
                </p>
              </div>
              <div>
                <span className="text-[#A9A397]">Systemic Excess Capital</span>
                <p className="text-lg font-serif font-bold text-[#EFECE6] mt-0.5">
                  £{Math.round(metrics.cet1Capital - (metrics.rwa * (totalMinRequired / 100))).toLocaleString()}M
                </p>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
