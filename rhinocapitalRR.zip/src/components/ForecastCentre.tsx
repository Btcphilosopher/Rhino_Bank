import React from "react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart,
  Area,
  Legend
} from "recharts";
import { 
  TrendingUp, 
  Sparkles, 
  SlidersHorizontal, 
  Download, 
  PlusCircle, 
  AlertCircle 
} from "lucide-react";
import { CapitalMetrics, ForecastParameters } from "../types";

interface ForecastCentreProps {
  metrics: CapitalMetrics;
  onAddAuditLog: (action: string, details: string) => void;
}

export default function ForecastCentre({ metrics, onAddAuditLog }: ForecastCentreProps) {
  
  // Dynamic forecast state parameters
  const [years, setYears] = React.useState<number>(5);
  const [assetGrowth, setAssetGrowth] = React.useState<number>(4.5); // % annual growth
  const [nim, setNim] = React.useState<number>(2.4);                // % NIM
  const [creditLoss, setCreditLoss] = React.useState<number>(0.45);   // % Credit Loss
  const [dividendPayout, setDividendPayout] = React.useState<number>(35); // % payout
  const [capitalRaised, setCapitalRaised] = React.useState<number>(0);   // GBP millions
  
  // Run capital projection over years
  const projections = React.useMemo(() => {
    const list = [];
    let currentExposure = metrics.ead;
    let currentRWA = metrics.rwa;
    let currentCET1 = metrics.cet1Capital;
    
    // Average asset density
    const density = currentRWA / currentExposure;
    
    // Base starting state (Year 0)
    list.push({
      year: "Year 0 (Current)",
      exposure: Math.round(currentExposure),
      rwa: Math.round(currentRWA),
      cet1Capital: Math.round(currentCET1),
      cet1Ratio: parseFloat(((currentCET1 / currentRWA) * 100).toFixed(2)),
      netIncome: 0,
      retainedEarnings: 0,
      cet1LowerBound: parseFloat(((currentCET1 / currentRWA) * 100).toFixed(2)),
      cet1UpperBound: parseFloat(((currentCET1 / currentRWA) * 100).toFixed(2)),
    });

    for (let i = 1; i <= years; i++) {
      // 1. Balance sheet grows
      currentExposure = currentExposure * (1 + assetGrowth / 100);
      currentRWA = currentExposure * density; // assumes risk density remains stable

      // 2. Earnings and Credit Losses
      const averageExposure = (currentExposure + currentExposure / (1 + assetGrowth / 100)) / 2;
      const interestIncome = averageExposure * (nim / 100);
      const impairmentLosses = averageExposure * (creditLoss / 100);
      
      const netIncome = interestIncome - impairmentLosses;
      const dividendPaid = netIncome * (dividendPayout / 100);
      const retainedInYear = netIncome - dividendPaid;

      // Add fresh capital if configured in Year 1
      const capitalInjected = i === 1 ? capitalRaised : 0;
      
      // 3. Update Available CET1
      currentCET1 = currentCET1 + retainedInYear + capitalInjected;
      const calculatedRatio = (currentCET1 / currentRWA) * 100;

      // Simulate confidence interval bounds representing statistical R forecasting ARIMA uncertainty
      // Bounds widen as projection horizon extends
      const uncertaintyFactor = i * 0.45;
      const lowerRatio = calculatedRatio - uncertaintyFactor;
      const upperRatio = calculatedRatio + uncertaintyFactor;

      list.push({
        year: `Year ${i}`,
        exposure: Math.round(currentExposure),
        rwa: Math.round(currentRWA),
        cet1Capital: Math.round(currentCET1),
        cet1Ratio: parseFloat(calculatedRatio.toFixed(2)),
        netIncome: Math.round(netIncome),
        retainedEarnings: Math.round(retainedInYear),
        cet1LowerBound: parseFloat(Math.max(lowerRatio, 4.5).toFixed(2)),
        cet1UpperBound: parseFloat(upperRatio.toFixed(2)),
      });
    }

    return list;
  }, [years, assetGrowth, nim, creditLoss, dividendPayout, capitalRaised, metrics]);

  const handleExportCSV = () => {
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Year,Exposure (EAD),Risk-Weighted Assets,CET1 Capital,CET1 Ratio (%),Net Income,Retained Earnings,95% Conf Lower,95% Conf Upper\n";
    
    projections.forEach(p => {
      csvContent += `${p.year},£${p.exposure}M,£${p.rwa}M,£${p.cet1Capital}M,${p.cet1Ratio}%,£${p.netIncome}M,£${p.retainedEarnings}M,${p.cet1LowerBound}%,${p.cet1UpperBound}%\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `RhinoCapital_Prudential_Forecast_${years}Y.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    onAddAuditLog(
      "Forecast Export",
      `Exported ${years}-year capital requirements projection sheet to local CSV format.`
    );
  };

  const currentEndingRatio = projections[projections.length - 1].cet1Ratio;

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#2D3339] pb-5 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#D97706] font-semibold">PREDICTIVE ANALYTICS</span>
          <h1 className="text-3xl font-serif text-[#EFECE6] mt-1 tracking-tight">Prudential Forecast Centre</h1>
          <p className="text-[#A9A397] text-sm mt-1 max-w-xl">
            Simulate credit asset expansion rates, NIM interest income, write-offs, and capital retention policy. R-style prediction intervals model statistical uncertainty.
          </p>
        </div>
        
        <button 
          onClick={handleExportCSV}
          className="text-xs bg-[#162E44] hover:bg-[#264B6C] border border-[#264B6C] text-[#EFECE6] px-3.5 py-1.5 rounded transition flex items-center gap-1.5 font-semibold"
        >
          <Download className="w-3.5 h-3.5 text-[#D97706]" /> Export Forecast Table
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Forecast Controls (takes 4 cols) */}
        <div className="lg:col-span-4 bg-[#181B1E] border border-[#2D3339] p-6 space-y-5">
          <div className="flex items-center gap-2 border-b border-[#2D3339] pb-3">
            <SlidersHorizontal className="w-4 h-4 text-[#D97706]" />
            <h3 className="font-serif text-[#EFECE6] text-base">Model Parameters</h3>
          </div>

          {/* Projection Horizon */}
          <div>
            <label className="block text-[11px] uppercase text-[#A9A397] mb-1.5 font-semibold">Projection Horizon</label>
            <div className="grid grid-cols-3 gap-2">
              {[3, 5, 7].map(yr => (
                <button
                  key={yr}
                  type="button"
                  onClick={() => setYears(yr)}
                  className={`py-1.5 text-xs font-mono border rounded transition ${
                    years === yr 
                      ? "bg-[#D97706] text-[#121416] border-[#D97706] font-bold" 
                      : "bg-[#121416] text-[#A9A397] border-[#2D3339] hover:bg-[#1C1F22]"
                  }`}
                >
                  {yr} Years
                </button>
              ))}
            </div>
          </div>

          {/* Asset Growth Rate */}
          <div>
            <div className="flex justify-between text-[11px] uppercase text-[#A9A397] mb-1 font-semibold">
              <span>Annual Asset Growth</span>
              <span className="font-mono text-[#EFECE6]">{assetGrowth.toFixed(1)}%</span>
            </div>
            <input 
              type="range"
              min="0.0"
              max="15.0"
              step="0.5"
              value={assetGrowth}
              onChange={(e) => setAssetGrowth(parseFloat(e.target.value))}
              className="w-full accent-[#D97706] cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-[#8E887E] mt-0.5 font-mono">
              <span>0% (Flat)</span>
              <span>15% (Aggressive)</span>
            </div>
          </div>

          {/* NIM Margin */}
          <div>
            <div className="flex justify-between text-[11px] uppercase text-[#A9A397] mb-1 font-semibold">
              <span>Net Interest Margin (NIM)</span>
              <span className="font-mono text-[#EFECE6]">{nim.toFixed(2)}%</span>
            </div>
            <input 
              type="range"
              min="1.00"
              max="4.00"
              step="0.05"
              value={nim}
              onChange={(e) => setNim(parseFloat(e.target.value))}
              className="w-full accent-[#D97706] cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-[#8E887E] mt-0.5 font-mono">
              <span>1.0% (Squeezed)</span>
              <span>4.0% (Highly Profitable)</span>
            </div>
          </div>

          {/* Impairment Credit Losses */}
          <div>
            <div className="flex justify-between text-[11px] uppercase text-[#A9A397] mb-1 font-semibold">
              <span>Annual Credit Loss Rate</span>
              <span className="font-mono text-[#EFECE6]">{creditLoss.toFixed(2)}%</span>
            </div>
            <input 
              type="range"
              min="0.05"
              max="2.50"
              step="0.05"
              value={creditLoss}
              onChange={(e) => setCreditLoss(parseFloat(e.target.value))}
              className="w-full accent-[#D97706] cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-[#8E887E] mt-0.5 font-mono">
              <span>0.05% (Stellar Credit)</span>
              <span>2.50% (High Loss Run)</span>
            </div>
          </div>

          {/* Dividend Payout */}
          <div>
            <div className="flex justify-between text-[11px] uppercase text-[#A9A397] mb-1 font-semibold">
              <span>Dividend Payout Ratio</span>
              <span className="font-mono text-[#EFECE6]">{dividendPayout}%</span>
            </div>
            <input 
              type="range"
              min="0"
              max="100"
              step="5"
              value={dividendPayout}
              onChange={(e) => setDividendPayout(parseInt(e.target.value))}
              className="w-full accent-[#D97706] cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-[#8E887E] mt-0.5 font-mono">
              <span>0% (Retain All)</span>
              <span>100% (Distribute All)</span>
            </div>
          </div>

          {/* Fresh Equity Issued */}
          <div>
            <div className="flex justify-between text-[11px] uppercase text-[#A9A397] mb-1 font-semibold">
              <span>Fresh CET1 Capital Raised</span>
              <span className="font-mono text-[#EFECE6]">£{capitalRaised}M</span>
            </div>
            <input 
              type="range"
              min="0"
              max="800"
              step="50"
              value={capitalRaised}
              onChange={(e) => setCapitalRaised(parseInt(e.target.value))}
              className="w-full accent-[#D97706] cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-[#8E887E] mt-0.5 font-mono">
              <span>£0M</span>
              <span>£800M (Large Raise)</span>
            </div>
          </div>
        </div>

        {/* Right Column: Visualization & Shaded Prediction Bounds (takes 8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Shaded Area chart for CET1 projection with confidence interval */}
          <div className="bg-[#181B1E] border border-[#2D3339] p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-serif text-[#EFECE6] text-lg">CET1 Capital Adequacy Projection</h3>
                <p className="text-xs text-[#A9A397]">Projected CET1 ratio over a {years}-year horizon with R-model 95% statistical confidence bounds.</p>
              </div>
              <div className="text-right">
                <span className="text-[10px] uppercase text-[#A9A397] tracking-wider">Year {years} Ratio</span>
                <p className={`text-2xl font-mono font-bold ${currentEndingRatio >= 9.0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {currentEndingRatio.toFixed(2)}%
                </p>
              </div>
            </div>

            <div className="h-64 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={projections}
                  margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="colorConfidence" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#162E44" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="#162E44" stopOpacity={0.0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2D3339" />
                  <XAxis dataKey="year" stroke="#8E887E" fontSize={11} />
                  <YAxis 
                    domain={[6, 22]} 
                    stroke="#8E887E" 
                    fontSize={11} 
                    tickFormatter={(val) => `${val}%`}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#1C1F22", border: "1px solid #3A3F45", borderRadius: "4px" }}
                    labelStyle={{ color: "#EFECE6", fontWeight: "bold" }}
                  />
                  <Legend verticalAlign="bottom" height={36} wrapperStyle={{ fontSize: '11px', color: '#A9A397' }} />
                  {/* Shaded Area representing predicting bounds */}
                  <Area 
                    type="monotone" 
                    dataKey="cet1UpperBound" 
                    stroke="transparent"
                    fill="url(#colorConfidence)" 
                    name="95% Confidence Upper Interval"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="cet1LowerBound" 
                    stroke="transparent"
                    fill="#1C1F22" 
                    name="95% Confidence Lower Interval"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="cet1Ratio" 
                    stroke="#D97706" 
                    strokeWidth={3} 
                    dot={{ r: 4 }} 
                    name="Target Projection CET1" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {currentEndingRatio < 9.0 && (
              <div className="mt-4 p-3 bg-red-950/30 border border-red-900/50 rounded flex items-start gap-2 text-xs text-red-400">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <p>
                  <span className="font-bold">Prudential Warning:</span> Your configured parameters drive the CET1 capital ratio to <span className="font-bold">{currentEndingRatio}%</span> in Year {years}, breaching the combined buffer requirements of <span className="font-bold">9.0%</span>. Consider lowering asset growth, reducing dividend pay-out ratios, or launching an equity issuance.
                </p>
              </div>
            )}
          </div>

          {/* Granular forecast numbers */}
          <div className="bg-[#181B1E] border border-[#2D3339] p-6">
            <h3 className="font-serif text-[#EFECE6] text-base mb-3">Model Recurrent Projections</h3>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-[#2D3339] text-[#A9A397] uppercase tracking-wider text-[10px]">
                    <th className="py-2 px-2">Projected Period</th>
                    <th className="py-2 px-2">Total Exposure (£M)</th>
                    <th className="py-2 px-2">Total RWA (£M)</th>
                    <th className="py-2 px-2">CET1 Capital (£M)</th>
                    <th className="py-2 px-2">Estimated Income (£M)</th>
                    <th className="py-2 px-2">Retained (£M)</th>
                    <th className="py-2 px-2 text-right">Projected CET1 (%)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#2D3339]/50 font-mono">
                  {projections.map((p, idx) => (
                    <tr key={idx} className="hover:bg-[#121416]/40 transition-colors">
                      <td className="py-2.5 px-2 text-[#EFECE6] font-sans font-medium">{p.year}</td>
                      <td className="py-2.5 px-2">£{p.exposure.toLocaleString()}M</td>
                      <td className="py-2.5 px-2">£{p.rwa.toLocaleString()}M</td>
                      <td className="py-2.5 px-2">£{p.cet1Capital.toLocaleString()}M</td>
                      <td className="py-2.5 px-2 text-[#A9A397]">£{p.netIncome}M</td>
                      <td className="py-2.5 px-2 text-[#A9A397]">£{p.retainedEarnings}M</td>
                      <td className="py-2.5 px-2 text-right text-[#D97706] font-bold text-sm">
                        {p.cet1Ratio.toFixed(2)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
