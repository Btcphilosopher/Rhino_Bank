/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Institutional Quantitative Data Types
 */

export type UserRole =
  | 'Originator'
  | 'Credit Analyst'
  | 'Structurer'
  | 'Treasury'
  | 'Risk Officer'
  | 'Auditor';

export type Currency = 'USD' | 'EUR' | 'JPY' | 'TWD';

export type ValuationBasis =
  | 'Contractual cash flow'
  | 'Management scenario'
  | 'Credit estimate'
  | 'Market-calibrated value';

export type ProjectType =
  | 'New Green-field Fab'
  | 'Capacity Expansion'
  | 'Advanced Packaging (2.5D/3D TSV)'
  | 'Specialty & Mature Node'
  | 'Leading-Edge Logic (Sub-3nm)'
  | 'Memory Production (HBM3e/3D NAND)'
  | 'Fabless Capacity Reservation';

export type InstrumentCategory = 'Funding' | 'Risk-Transfer';

export type ComponentType =
  | 'Equipment Loan'
  | 'Equipment Lease'
  | 'Receivables Purchase (ABL)'
  | 'Inventory / WIP Borrowing Base'
  | 'Customer Prepayment / Take-or-Pay'
  | 'Structured Senior Notes'
  | 'Mezzanine Subordinated Debt'
  | 'Sponsor First-Loss Equity'
  | 'Interest Rate Swap (Overlay)'
  | 'FX Forward (Overlay)'
  | 'Sovereign / Export Credit Guarantee (Overlay)'
  | 'Synthetic Credit Protection / CRT (Overlay)';

export interface EquipmentItem {
  id: string;
  name: string;
  vendor: string; // e.g. ASML, Applied Materials, Tokyo Electron, Besi
  category: 'Lithography' | 'Etch & Clean' | 'Bonding & Packaging' | 'Metrology & Test';
  cost: number; // in USD millions
  deliveryMonth: number;
  qualificationMonth: number;
  haircut: number; // e.g. 0.25 (25%)
  maintenanceAnnualPct: number; // e.g. 0.06
  residualValuePct5Yr: number; // e.g. 0.35
}

export interface ProductionMilestone {
  month: number;
  name: string;
  targetWafersPerMonth: number;
  targetYieldPct: number;
  capexOutflow: number;
}

export interface SemiconductorProject {
  id: string;
  name: string;
  sponsor: string;
  facilityLocation: string;
  projectType: ProjectType;
  currency: Currency;
  modelHorizonMonths: number; // e.g. 36 or 60
  cleanroomAreaSqM: number;
  totalCapexRequired: number; // in millions
  constructionDurationMonths: number;
  equipmentSchedule: EquipmentItem[];
  // Physical parameters
  maxWaferCapacityPerMonth: number; // 300mm wafer equivalent
  waferDiameterMm: number; // 300mm
  dieAreaSqMm: number; // e.g. 120 mm²
  defectDensityPerSqCm: number; // Murphy / Poisson defect density model
  waferBaseCostUSD: number; // Raw manufacturing cost per wafer start
  packagingCostPerUnitUSD: number; // Backend advanced substrate & bump cost
  testCostPerUnitUSD: number; // High-coverage ATE test cost
  // Cycle times & inventory
  fabCycleTimeDays: number; // e.g. 75 days
  packagingCycleTimeDays: number; // e.g. 21 days
  testCycleTimeDays: number; // e.g. 7 days
  customerPaymentTermsDays: number; // DSO e.g. 60 days
  scrapRatePct: number; // e.g. 1.8%
  reworkRatePct: number; // e.g. 3.2%
}

export interface CustomerContract {
  id: string;
  customerName: string;
  creditRating: 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'Unrated';
  productName: string;
  salesModel: 'Wafer Sales' | 'Packaged Device Sales';
  committedMonthlyVolume: number; // wafers or packaged dies
  unitPriceUSD: number; // $/wafer or $/device
  takeOrPayPenaltyPct: number; // e.g. 70% if customer under-draws
  prepaymentAmountUSD: number; // Customer advance financing
  prepaymentAmortisationPctPerUnit: number; // $/unit credit against advance
  dilutionReservePct: number; // e.g. 2.5% for RMA/warranty/disputes
  paymentDays: number; // DSO
}

export interface FinancingComponent {
  id: string;
  name: string;
  category: InstrumentCategory;
  type: ComponentType;
  provider: string; // Counterparty or Investor
  principalOrNotional: number; // in millions
  initialCashInflow: number; // actual cash provided to borrower at t0 (0 for overlays)
  interestRateSpreadBps: number; // over benchmark (e.g. 225 bps)
  benchmarkRatePct: number; // e.g. 4.25% SOFR
  fixedRatePct?: number; // for swaps / fixed bonds
  dayCount: 'Act/360' | '30/360' | 'Act/Act';
  tenorMonths: number;
  gracePeriodMonths: number;
  amortisationType: 'Linear' | 'Sculptured DSCR' | 'Bullet' | 'Custom';
  upfrontFeePct: number; // e.g. 1.0%
  commitmentFeePct: number; // e.g. 0.40% on undrawn
  advanceRatePct?: number; // for ABL / AR / WIP e.g. 85%
  collateralPledged: string; // e.g. "Specific EUV Tool", "Eligible Invoices Pool", "WIP Stage 3"
  haircutPct: number;
  priority: 1 | 2 | 3 | 4; // 1 = Senior Secured, 2 = Mezzanine, 3 = First-Loss Equity, 4 = Overlay
  retainedRisks: string[]; // e.g. "Process yield underperformance", "Customer demand volatility"
  transferredRisks: string[]; // e.g. "Equipment residual value", "Interest rate fluctuations"
  contingentObligations: string; // e.g. "Collateral top-up margin if valuation drops > 15%"
}

export interface FinancingStructure {
  id: string;
  name: string;
  description: string;
  components: FinancingComponent[];
  version: string;
  status: 'Draft' | 'Submitted' | 'Approved' | 'Rejected';
  createdByRole: UserRole;
  approvedByRole?: UserRole;
  approvalTimestamp?: string;
  sourcesAndUsesValid: boolean;
  validationErrors: string[];
}

export interface CashFlowPeriod {
  periodMonth: number;
  // Physical Production
  waferStarts: number;
  completedWafers: number;
  grossDies: number;
  processYieldPct: number;
  goodDies: number;
  packagingYieldPct: number;
  goodPackagedUnits: number;
  // Revenue & Collections
  grossInvoicedUSD: number;
  dilutionReservesUSD: number;
  netInvoicedUSD: number;
  cashCollectionsUSD: number;
  customerPrepaymentDrawnUSD: number;
  // Costs
  physicalRawCostUSD: number;
  operatingOpexUSD: number;
  equipmentMaintenanceUSD: number;
  totalManufacturingCostUSD: number;
  // Free Cash Flow before Debt Service
  ebitdaUSD: number;
  capexPaymentsUSD: number;
  freeOperatingCashFlowUSD: number;
  // Debt Service Waterfall
  seniorInterestUSD: number;
  seniorPrincipalUSD: number;
  mezzanineInterestUSD: number;
  mezzaninePrincipalUSD: number;
  feesAndCommitmentUSD: number;
  overlayCashSettlementUSD: number; // net swap or FX forward payout / receipt
  totalFinancingOutflowUSD: number;
  // Reserve and Balances
  reserveReplenishmentUSD: number;
  firstLossEquityDistributionUSD: number;
  endingCashBalanceUSD: number;
  // Ratios
  dscr: number;
  borrowingBaseAvailabilityUSD: number;
  collateralValueUSD: number;
}

export interface PricingMetrics {
  totalFundingRaisedUSD: number;
  totalFinancingExpenseUSD: number;
  weightedAverageCostOfCapitalPct: number;
  projectNPVUSD: number;
  sponsorIRRPct: number;
  sponsorIRRWarning?: string;
  seniorLenderIRRPct: number;
  mezzanineIRRPct: number;
  minDSCR: number;
  avgDSCR: number;
  loanLifeCoverageRatio: number;
  breakEvenUtilisationPct: number;
  breakEvenSellingPriceUSD: number;
  // Unit Cost Dissection
  physicalCostPerUnitUSD: number;
  allocatedDepreciationPerUnitUSD: number;
  incrementalCashCostPerUnitUSD: number;
  financingExpensePerUnitUSD: number;
  totalDeliveredCashCostUSD: number;
}

export interface MonteCarloSummary {
  iterationCount: number;
  randomSeed: number;
  fundingShortfallProbabilityPct: number;
  debtServiceShortfallProbabilityPct: number;
  expectedLossBps: number;
  seniorExpectedLossBps: number;
  mezzanineExpectedLossBps: number;
  equityLossProbabilityPct: number;
  liquidityAtRisk95PctUSD: number; // 95% 1-year LaR
  liquidityAtRisk99PctUSD: number; // 99% 1-year LaR
  monteCarloStandardErrorUSD: number;
  percentiles: {
    p5: number;
    p25: number;
    p50: number; // Median NPV
    p75: number;
    p95: number;
  };
  distributionBuckets: { min: number; max: number; count: number }[];
  parameterSensitivities: {
    parameter: string;
    impactOnNPVUSD: number; // Tornado chart data
    direction: 'positive' | 'negative';
  }[];
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  yieldShockPct: number; // e.g. -15%
  utilisationShockPct: number; // e.g. -25%
  priceShockPct: number; // e.g. -20%
  delayMonths: number; // e.g. 6 months construction/ramp delay
  customerDefaultPct: number; // e.g. 30% of receivables defaulted
  interestRateShockBps: number; // e.g. +200 bps
  fxDevaluationPct: number; // e.g. -15% TWD/USD
}

export interface CollateralAsset {
  id: string;
  name: string;
  assetType: 'Manufacturing Equipment' | 'Eligible Accounts Receivable' | 'WIP Stage Inventory' | 'Finished Goods';
  grossNominalValueUSD: number;
  valuationDate: string;
  haircutPct: number;
  netBorrowingBaseValueUSD: number;
  pledgedToComponentId: string;
  encumbranceStatus: 'Pledged Senior' | 'Pledged Junior' | 'Unencumbered';
  concentrationLimitPct: number;
}

export interface GovernanceLog {
  id: string;
  timestamp: string;
  role: UserRole;
  action: string;
  structureId: string;
  details: string;
  rationale?: string;
  hash: string;
}

export interface PricingOverride {
  id: string;
  timestamp: string;
  authorRole: UserRole;
  componentId: string;
  field: string;
  originalValue: number;
  overrideValue: number;
  justification: string;
  status: 'Pending Auditor Review' | 'Approved' | 'Rejected';
}
