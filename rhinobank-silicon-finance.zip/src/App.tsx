/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Main Enterprise Platform
 * Technology: Aureom.AI | Division: RhinoQuant
 */

import React, { useState, useMemo } from 'react';
import {
  UserRole,
  Currency,
  SemiconductorProject,
  CustomerContract,
  FinancingStructure,
  MonteCarloSummary,
  GovernanceLog,
  PricingOverride
} from './types';
import {
  DEMO_PROJECT,
  DEMO_CONTRACTS,
  DEMO_STRUCTURES,
  DEMO_STRESS_SCENARIOS,
  INITIAL_GOVERNANCE_LOGS,
  INITIAL_PRICING_OVERRIDES
} from './data/demonstrationData';
import {
  simulateProjectCashFlows,
  runMonteCarloSimulation
} from './math/quantitativeEngine';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { ProjectsView } from './components/views/ProjectsView';
import { ProductionView } from './components/views/ProductionView';
import { ContractsView } from './components/views/ContractsView';
import { StructureBuilderView } from './components/views/StructureBuilderView';
import { DemonstrationComparisonView } from './components/views/DemonstrationComparisonView';
import { PricingView } from './components/views/PricingView';
import { CashFlowWaterfallView } from './components/views/CashFlowWaterfallView';
import { RiskSimulationView } from './components/views/RiskSimulationView';
import { CollateralTreasuryView } from './components/views/CollateralTreasuryView';
import { GovernanceReviewView } from './components/views/GovernanceReviewView';
import { AuditTestsView } from './components/views/AuditTestsView';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('projects');
  const [currentRole, setCurrentRole] = useState<UserRole>('Structurer');
  const [modelVersion, setModelVersion] = useState<string>('v1.2');
  const [currency, setCurrency] = useState<Currency>('USD');

  // Core mutable state
  const [project, setProject] = useState<SemiconductorProject>(DEMO_PROJECT);
  const [contracts, setContracts] = useState<CustomerContract[]>(DEMO_CONTRACTS);
  const [structures, setStructures] = useState<FinancingStructure[]>(DEMO_STRUCTURES);
  const [selectedStructureId, setSelectedStructureId] = useState<string>('struct-5-overlays');

  // Governance and overrides
  const [governanceLogs, setGovernanceLogs] = useState<GovernanceLog[]>(INITIAL_GOVERNANCE_LOGS);
  const [pricingOverrides, setPricingOverrides] = useState<PricingOverride[]>(INITIAL_PRICING_OVERRIDES);

  // Active structure
  const activeStructure = useMemo(() => {
    return (
      structures.find(s => s.id === selectedStructureId) ||
      structures[structures.length - 1]
    );
  }, [structures, selectedStructureId]);

  // Model version overrides:
  // v1.0 = Baseline (1.0x multipliers)
  // v1.1 = Stress Downcycle (utilization -20%, prices -15%)
  // v1.2 = Accelerated Scale (yield +5%, util +5%)
  const versionOverrides = useMemo(() => {
    if (modelVersion === 'v1.1') {
      return { utilisationMultiplier: 0.80, priceMultiplier: 0.85 };
    }
    if (modelVersion === 'v1.2') {
      return { utilisationMultiplier: 1.05, yieldMultiplier: 1.05 };
    }
    return {};
  }, [modelVersion]);

  // Dynamic simulation calculations
  const simulationResults = useMemo(() => {
    return simulateProjectCashFlows(project, contracts, activeStructure, versionOverrides);
  }, [project, contracts, activeStructure, versionOverrides]);

  // Monte Carlo simulation state
  const [monteCarloSummary, setMonteCarloSummary] = useState<MonteCarloSummary>(() =>
    runMonteCarloSimulation(project, contracts, activeStructure, 1000, 42)
  );

  // Handler when user updates active structure
  const handleUpdateActiveStructure = (updated: FinancingStructure) => {
    setStructures(prev => prev.map(s => (s.id === updated.id ? updated : s)));
  };

  const handleSelectStructure = (struct: FinancingStructure) => {
    setSelectedStructureId(struct.id);
  };

  const handleAddGovernanceLog = (newLog: GovernanceLog) => {
    setGovernanceLogs(prev => [newLog, ...prev]);
  };

  return (
    <div className="min-h-screen bg-[#0b0e14] text-slate-100 flex flex-col font-sans">
      {/* 3-Zone Top Bar Contract */}
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        currentRole={currentRole}
        onSelectRole={setCurrentRole}
        onExportReviewPack={() => setActiveTab('governance')}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Navigation */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          modelVersion={modelVersion}
          onSelectModelVersion={setModelVersion}
          currency={currency}
          onSelectCurrency={c => setCurrency(c as Currency)}
        />

        {/* Content Viewport */}
        <main className="flex-1 overflow-y-auto p-6 bg-[#0b0e14] text-slate-100">
          <div className="max-w-[1440px] mx-auto space-y-6">
            {/* View Switching */}
            {activeTab === 'projects' && (
              <ProjectsView project={project} onUpdateProject={setProject} />
            )}

            {activeTab === 'production' && (
              <ProductionView
                project={project}
                onUpdateProject={setProject}
                periods={simulationResults.periods}
              />
            )}

            {activeTab === 'contracts' && (
              <ContractsView
                contracts={contracts}
                onUpdateContracts={setContracts}
              />
            )}

            {activeTab === 'structures' && (
              <StructureBuilderView
                structure={activeStructure}
                onUpdateStructure={handleUpdateActiveStructure}
                project={project}
                contracts={contracts}
              />
            )}

            {activeTab === 'comparison' && (
              <DemonstrationComparisonView
                structures={structures}
                project={project}
                contracts={contracts}
                selectedStructureId={selectedStructureId}
                onSelectStructure={handleSelectStructure}
                currency={currency}
              />
            )}

            {activeTab === 'pricing' && (
              <PricingView
                metrics={simulationResults.metrics}
                periods={simulationResults.periods}
                structure={activeStructure}
                currency={currency}
              />
            )}

            {activeTab === 'waterfall' && (
              <CashFlowWaterfallView
                periods={simulationResults.periods}
                currency={currency}
              />
            )}

            {activeTab === 'risk' && (
              <RiskSimulationView
                monteCarlo={monteCarloSummary}
                onUpdateMonteCarlo={setMonteCarloSummary}
                stressScenarios={DEMO_STRESS_SCENARIOS}
                project={project}
                contracts={contracts}
                structure={activeStructure}
                currency={currency}
              />
            )}

            {activeTab === 'collateral' && (
              <CollateralTreasuryView
                collateral={simulationResults.collateral}
                structure={activeStructure}
                currency={currency}
              />
            )}

            {activeTab === 'governance' && (
              <GovernanceReviewView
                structure={activeStructure}
                onUpdateStructure={handleUpdateActiveStructure}
                currentRole={currentRole}
                project={project}
                governanceLogs={governanceLogs}
                onAddLog={handleAddGovernanceLog}
                pricingOverrides={pricingOverrides}
                currency={currency}
              />
            )}

            {activeTab === 'tests' && (
              <AuditTestsView
                project={project}
                contracts={contracts}
                structure={activeStructure}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
