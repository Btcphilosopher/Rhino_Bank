/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Institutional Demonstration Dataset
 * Fictional advanced-packaging and semiconductor manufacturing transaction
 */

import {
  SemiconductorProject,
  CustomerContract,
  FinancingStructure,
  StressScenario,
  GovernanceLog,
  PricingOverride
} from '../types';

export const DEMO_PROJECT: SemiconductorProject = {
  id: 'proj-aureom-fab7',
  name: 'Aureom Microelectronics Fab-7 (Advanced 3D Chiplet & Substrate Packaging)',
  sponsor: 'Aureom Semiconductor Group Ltd.',
  facilityLocation: 'Tainan Science Park, Phase III',
  projectType: 'Advanced Packaging (2.5D/3D TSV)',
  currency: 'USD',
  modelHorizonMonths: 36,
  cleanroomAreaSqM: 32000,
  totalCapexRequired: 420.0, // $420M total CapEx
  constructionDurationMonths: 12,
  maxWaferCapacityPerMonth: 22000, // 300mm wafers
  waferDiameterMm: 300,
  dieAreaSqMm: 125, // 125 mm² chiplet
  defectDensityPerSqCm: 0.085, // Murphy defect model
  waferBaseCostUSD: 2400, // Silicon substrate + front-end wafer start cost
  packagingCostPerUnitUSD: 18.5, // 2.5D interposer & micro-bump bonding
  testCostPerUnitUSD: 7.2, // High-coverage system-level test
  fabCycleTimeDays: 75,
  packagingCycleTimeDays: 21,
  testCycleTimeDays: 7,
  customerPaymentTermsDays: 60, // DSO 60 days
  scrapRatePct: 1.8,
  reworkRatePct: 2.9,
  equipmentSchedule: [
    {
      id: 'eq-101',
      name: 'High-NA EUV & DUV Stepper Lithography Systems (2 Units)',
      vendor: 'ASML Holding N.V.',
      category: 'Lithography',
      cost: 160.0,
      deliveryMonth: 3,
      qualificationMonth: 7,
      haircut: 0.25,
      maintenanceAnnualPct: 0.055,
      residualValuePct5Yr: 0.45
    },
    {
      id: 'eq-102',
      name: 'Sub-Micron Hybrid Direct Wafer-to-Wafer Bonders (6 Units)',
      vendor: 'Besi / EV Group',
      category: 'Bonding & Packaging',
      cost: 85.0,
      deliveryMonth: 6,
      qualificationMonth: 9,
      haircut: 0.30,
      maintenanceAnnualPct: 0.065,
      residualValuePct5Yr: 0.38
    },
    {
      id: 'eq-103',
      name: 'Deep Reactive-Ion Through-Silicon-Via (TSV) Etch Chambers',
      vendor: 'Tokyo Electron Ltd. (TEL)',
      category: 'Etch & Clean',
      cost: 95.0,
      deliveryMonth: 5,
      qualificationMonth: 8,
      haircut: 0.28,
      maintenanceAnnualPct: 0.060,
      residualValuePct5Yr: 0.40
    },
    {
      id: 'eq-104',
      name: 'Automated Laser Dicing & Acoustic Micro-Crack Inspection Tools',
      vendor: 'Disco Corp / KLA',
      category: 'Metrology & Test',
      cost: 45.0,
      deliveryMonth: 8,
      qualificationMonth: 11,
      haircut: 0.35,
      maintenanceAnnualPct: 0.050,
      residualValuePct5Yr: 0.32
    },
    {
      id: 'eq-105',
      name: 'Ultra-High Density Automated Test Equipment (ATE) Platforms',
      vendor: 'Advantest Corp',
      category: 'Metrology & Test',
      cost: 35.0,
      deliveryMonth: 9,
      qualificationMonth: 12,
      haircut: 0.35,
      maintenanceAnnualPct: 0.070,
      residualValuePct5Yr: 0.30
    }
  ]
};

export const DEMO_CONTRACTS: CustomerContract[] = [
  {
    id: 'ct-hyperion',
    customerName: 'Hyperion Silicon Systems Inc.',
    creditRating: 'AAA',
    productName: 'Hyperion H1000 AI Accelerator Interposer Module',
    salesModel: 'Packaged Device Sales',
    committedMonthlyVolume: 65000,
    unitPriceUSD: 145.0, // $145 per packaged unit
    takeOrPayPenaltyPct: 75,
    prepaymentAmountUSD: 45000000, // $45M customer advance
    prepaymentAmortisationPctPerUnit: 12.0,
    dilutionReservePct: 2.0,
    paymentDays: 60
  },
  {
    id: 'ct-aether',
    customerName: 'Aether Compute Automatics (Tier-1 ADAS)',
    creditRating: 'AA',
    productName: 'AetherDrive Level-4 Autonomous Vision Substrate',
    salesModel: 'Packaged Device Sales',
    committedMonthlyVolume: 40000,
    unitPriceUSD: 115.0,
    takeOrPayPenaltyPct: 80,
    prepaymentAmountUSD: 25000000, // $25M customer advance
    prepaymentAmortisationPctPerUnit: 10.0,
    dilutionReservePct: 3.0,
    paymentDays: 45
  },
  {
    id: 'ct-omnilogic',
    customerName: 'OmniLogic Labs (Mobile SoC & Edge AI)',
    creditRating: 'A',
    productName: '300mm Bonded Multi-Die Carrier Wafers',
    salesModel: 'Wafer Sales',
    committedMonthlyVolume: 3500, // Wafers
    unitPriceUSD: 6800.0, // $6,800 per wafer
    takeOrPayPenaltyPct: 65,
    prepaymentAmountUSD: 15000000, // $15M customer advance
    prepaymentAmortisationPctPerUnit: 350.0,
    dilutionReservePct: 2.5,
    paymentDays: 60
  }
];

// ============================================================================
// 5 DEMONSTRATION STRUCTURES FOR RIGOROUS COMPARISON
// ============================================================================

export const DEMO_STRUCTURES: FinancingStructure[] = [
  // 1. Conventional Corporate Term Loan Package
  {
    id: 'struct-1-conventional',
    name: '1. Conventional Corporate Term Loan Package',
    description: 'Traditional senior syndicated term loan with corporate guarantees and rigid DSCR covenants. All residual and market risks remain with the manufacturer.',
    version: 'v1.0',
    status: 'Approved',
    createdByRole: 'Originator',
    approvedByRole: 'Credit Analyst',
    approvalTimestamp: '2026-10-18T14:32:00Z',
    sourcesAndUsesValid: true,
    validationErrors: [],
    components: [
      {
        id: 'comp-101',
        name: 'Senior Secured Syndicated Term Loan (Facility A)',
        category: 'Funding',
        type: 'Structured Senior Notes',
        provider: 'RhinoBank Commercial Syndicate',
        principalOrNotional: 320.0,
        initialCashInflow: 320.0,
        interestRateSpreadBps: 275,
        benchmarkRatePct: 4.5,
        dayCount: 'Act/360',
        tenorMonths: 36,
        gracePeriodMonths: 12,
        amortisationType: 'Linear',
        upfrontFeePct: 1.25,
        commitmentFeePct: 0.50,
        collateralPledged: 'All Fab Assets & Real Estate',
        haircutPct: 30,
        priority: 1,
        retainedRisks: [
          'Full wafer process & packaging yield risk',
          'Semiconductor cycle price volatility',
          'Floating benchmark interest rate risk (unhedged)',
          'Customer collection delay & default risk'
        ],
        transferredRisks: ['Lender bears catastrophic bankruptcy credit default risk only'],
        contingentObligations: 'Mandatory debt prepayment if DSCR drops below 1.20x; corporate cross-default.'
      },
      {
        id: 'comp-102',
        name: 'Sponsor Equity Contribution',
        category: 'Funding',
        type: 'Sponsor First-Loss Equity',
        provider: 'Aureom Semiconductor Group',
        principalOrNotional: 161.4,
        initialCashInflow: 161.4,
        interestRateSpreadBps: 0,
        benchmarkRatePct: 0,
        dayCount: '30/360',
        tenorMonths: 36,
        gracePeriodMonths: 0,
        amortisationType: 'Bullet',
        upfrontFeePct: 0,
        commitmentFeePct: 0,
        collateralPledged: 'Subordinated Equity Position',
        haircutPct: 0,
        priority: 3,
        retainedRisks: ['First-loss equity absorption of all cost overruns and cash shortfalls'],
        transferredRisks: [],
        contingentObligations: 'Cash equity call obligation if cleanroom CapEx overruns exceed 10%.'
      }
    ]
  },

  // 2. Equipment Finance + Receivables ABL Facility
  {
    id: 'struct-2-equipment-abl',
    name: '2. Equipment Milestone Finance + Receivables ABL',
    description: 'Bespoke asset-backed equipment facility with milestone drawdowns aligned to ASML & Besi tool deliveries, paired with off-balance-sheet invoice discounting.',
    version: 'v1.0',
    status: 'Approved',
    createdByRole: 'Structurer',
    approvedByRole: 'Risk Officer',
    approvalTimestamp: '2026-10-22T09:15:00Z',
    sourcesAndUsesValid: true,
    validationErrors: [],
    components: [
      {
        id: 'comp-201',
        name: 'ASML / Besi Equipment Milestone Acquisition Facility',
        category: 'Funding',
        type: 'Equipment Loan',
        provider: 'RhinoBank Industrial Asset Finance',
        principalOrNotional: 245.0,
        initialCashInflow: 245.0,
        interestRateSpreadBps: 210,
        benchmarkRatePct: 4.5,
        dayCount: 'Act/360',
        tenorMonths: 36,
        gracePeriodMonths: 10,
        amortisationType: 'Sculptured DSCR',
        upfrontFeePct: 0.90,
        commitmentFeePct: 0.35,
        collateralPledged: 'Lithography & Bonding Equipment Pool',
        haircutPct: 25,
        priority: 1,
        retainedRisks: ['Operational machine maintenance & tool uptime targets'],
        transferredRisks: ['Equipment residual value risk partially borne by equipment lessor syndicate'],
        contingentObligations: 'Mandatory remarketing covenant if tool qualification fails at Month 9.'
      },
      {
        id: 'comp-202',
        name: 'Tier-1 Customer Receivables Purchase Facility (ABL)',
        category: 'Funding',
        type: 'Receivables Purchase (ABL)',
        provider: 'RhinoBank Working Capital Solutions',
        principalOrNotional: 85.0,
        initialCashInflow: 85.0,
        interestRateSpreadBps: 185,
        benchmarkRatePct: 4.5,
        advanceRatePct: 85,
        dayCount: 'Act/360',
        tenorMonths: 36,
        gracePeriodMonths: 6,
        amortisationType: 'Linear',
        upfrontFeePct: 0.75,
        commitmentFeePct: 0.25,
        collateralPledged: 'Eligible Invoices (Hyperion & Aether)',
        haircutPct: 15,
        priority: 1,
        retainedRisks: ['Product warranty dilution & RMA dispute reserves above 3.5%'],
        transferredRisks: ['Customer credit risk & insolvency transferred without recourse to factor'],
        contingentObligations: 'Factor may reduce advance rate from 85% to 70% if customer credit rating is downgraded.'
      },
      {
        id: 'comp-203',
        name: 'Sponsor Equity Contribution',
        category: 'Funding',
        type: 'Sponsor First-Loss Equity',
        provider: 'Aureom Semiconductor Group',
        principalOrNotional: 150.9,
        initialCashInflow: 150.9,
        interestRateSpreadBps: 0,
        benchmarkRatePct: 0,
        dayCount: '30/360',
        tenorMonths: 36,
        gracePeriodMonths: 0,
        amortisationType: 'Bullet',
        upfrontFeePct: 0,
        commitmentFeePct: 0,
        collateralPledged: 'Subordinated Equity Position',
        haircutPct: 0,
        priority: 3,
        retainedRisks: ['First-loss equity absorption of ramp delays'],
        transferredRisks: [],
        contingentObligations: 'Subordinated to equipment lenders and factor.'
      }
    ]
  },

  // 3. Customer Prepayments + Working Capital Facility
  {
    id: 'struct-3-customer-prepay',
    name: '3. Customer Prepayments + Working Capital Facility',
    description: 'Offtake-backed capacity reservation advances from AI and automotive customers, reducing upfront bank debt requirements and locking in demand.',
    version: 'v1.0',
    status: 'Approved',
    createdByRole: 'Originator',
    approvedByRole: 'Credit Analyst',
    approvalTimestamp: '2026-10-25T11:40:00Z',
    sourcesAndUsesValid: true,
    validationErrors: [],
    components: [
      {
        id: 'comp-301',
        name: 'Customer Capacity Advance Prepayments (Offtake Funded)',
        category: 'Funding',
        type: 'Customer Prepayment / Take-or-Pay',
        provider: 'Hyperion Silicon & Aether Automatics',
        principalOrNotional: 85.0,
        initialCashInflow: 85.0,
        interestRateSpreadBps: 0, // Zero coupon, amortised as unit shipment discount
        benchmarkRatePct: 0,
        dayCount: '30/360',
        tenorMonths: 36,
        gracePeriodMonths: 12,
        amortisationType: 'Linear',
        upfrontFeePct: 0.20,
        commitmentFeePct: 0.10,
        collateralPledged: 'Dedicated Cleanroom Bay 3 & Reserved Capacity',
        haircutPct: 0,
        priority: 2,
        retainedRisks: [
          'Delivery SLA guarantee: $5,000/day penalty for late wafer deliveries',
          'Minimum packaging yield warranty (≥ 91%)'
        ],
        transferredRisks: [
          'Demand cycle volume risk: 75% take-or-pay liquidated damages if customer cuts orders'
        ],
        contingentObligations: 'Refund of remaining prepayment balance if fab shut down for > 90 days.'
      },
      {
        id: 'comp-302',
        name: 'Working Capital & Inventory Borrowing Base Facility',
        category: 'Funding',
        type: 'Inventory / WIP Borrowing Base',
        provider: 'RhinoBank Corporate Banking',
        principalOrNotional: 175.0,
        initialCashInflow: 175.0,
        interestRateSpreadBps: 225,
        benchmarkRatePct: 4.5,
        dayCount: 'Act/360',
        tenorMonths: 36,
        gracePeriodMonths: 6,
        amortisationType: 'Linear',
        upfrontFeePct: 0.80,
        commitmentFeePct: 0.30,
        collateralPledged: 'Silicon Wafers, Chemicals & Packaged Inventory',
        haircutPct: 40,
        priority: 1,
        retainedRisks: ['Inventory obsolescence for custom ASIC wafer patterns'],
        transferredRisks: ['Short-term liquidity funding risk'],
        contingentObligations: 'Monthly borrowing base certificate with auditor verification.'
      },
      {
        id: 'comp-303',
        name: 'Sponsor Equity Contribution',
        category: 'Funding',
        type: 'Sponsor First-Loss Equity',
        provider: 'Aureom Semiconductor Group',
        principalOrNotional: 220.6,
        initialCashInflow: 220.6,
        interestRateSpreadBps: 0,
        benchmarkRatePct: 0,
        dayCount: '30/360',
        tenorMonths: 36,
        gracePeriodMonths: 0,
        amortisationType: 'Bullet',
        upfrontFeePct: 0,
        commitmentFeePct: 0,
        collateralPledged: 'Subordinated Equity Position',
        haircutPct: 0,
        priority: 3,
        retainedRisks: ['Operational yield & tool integration risk'],
        transferredRisks: [],
        contingentObligations: 'Provides sponsor completion guarantee.'
      }
    ]
  },

  // 4. Funded Structured Vehicle (Bankruptcy-Remote SPV)
  {
    id: 'struct-4-spv',
    name: '4. Funded Structured Vehicle (SPV: Senior A, Mezz B, First-Loss)',
    description: 'Institutional securitisation SPV with multi-tranche notes, strict cash waterfall priorities, automated reserve triggers, and bankruptcy remoteness.',
    version: 'v1.1',
    status: 'Approved',
    createdByRole: 'Structurer',
    approvedByRole: 'Risk Officer',
    approvalTimestamp: '2026-10-28T16:20:00Z',
    sourcesAndUsesValid: true,
    validationErrors: [],
    components: [
      {
        id: 'comp-401',
        name: 'SPV Class A Senior Secured Notes (AAA/AA Rated)',
        category: 'Funding',
        type: 'Structured Senior Notes',
        provider: 'Institutional Debt Funds & Sovereign Wealth',
        principalOrNotional: 260.0,
        initialCashInflow: 260.0,
        interestRateSpreadBps: 175, // Lower spread due to structural seniority
        benchmarkRatePct: 4.5,
        dayCount: 'Act/360',
        tenorMonths: 36,
        gracePeriodMonths: 12,
        amortisationType: 'Sculptured DSCR',
        upfrontFeePct: 1.10,
        commitmentFeePct: 0.30,
        collateralPledged: 'SPV Perfected Asset Security & First Charge on Cash Waterfall',
        haircutPct: 20,
        priority: 1,
        retainedRisks: [],
        transferredRisks: ['Ultimate credit default risk cushioned by Mezzanine and First-Loss Equity'],
        contingentObligations: 'Cash sweep trigger: 100% of excess cash trapped if DSCR < 1.35x.'
      },
      {
        id: 'comp-402',
        name: 'SPV Class B Mezzanine Subordinated Notes (BBB/BB Rated)',
        category: 'Funding',
        type: 'Mezzanine Subordinated Debt',
        provider: 'RhinoQuant Private Credit Fund & Co-Investors',
        principalOrNotional: 95.0,
        initialCashInflow: 95.0,
        interestRateSpreadBps: 520, // 9.70% all-in return
        benchmarkRatePct: 4.5,
        dayCount: '30/360',
        tenorMonths: 36,
        gracePeriodMonths: 18,
        amortisationType: 'Bullet',
        upfrontFeePct: 1.80,
        commitmentFeePct: 0.50,
        collateralPledged: 'Second Lien on SPV Tool Pool & Revenue Rights',
        haircutPct: 40,
        priority: 2,
        retainedRisks: ['Mezzanine loss absorption prior to Senior Class A default'],
        transferredRisks: ['Mezzanine investors absorb moderate demand cycle down-turns'],
        contingentObligations: 'Payment-in-Kind (PIK) toggle if free cash flow is insufficient.'
      },
      {
        id: 'comp-403',
        name: 'Sponsor First-Loss Equity Tranche',
        category: 'Funding',
        type: 'Sponsor First-Loss Equity',
        provider: 'Aureom Semiconductor Group',
        principalOrNotional: 125.7,
        initialCashInflow: 125.7,
        interestRateSpreadBps: 0,
        benchmarkRatePct: 0,
        dayCount: '30/360',
        tenorMonths: 36,
        gracePeriodMonths: 0,
        amortisationType: 'Bullet',
        upfrontFeePct: 0,
        commitmentFeePct: 0,
        collateralPledged: 'First-Loss SPV Equity Certificates',
        haircutPct: 0,
        priority: 3,
        retainedRisks: ['Full first-loss equity subordination: 100% loss absorption before Mezzanine'],
        transferredRisks: [],
        contingentObligations: 'Locked in SPV until Class A debt amortised by ≥ 50%.'
      }
    ]
  },

  // 5. Selected Package with Risk-Transfer Overlays
  {
    id: 'struct-5-overlays',
    name: '5. Optimized Structure with Synthetic Risk Overlays (Recommended)',
    description: 'Comprehensive hybrid architecture pairing Equipment & Receivables funding with derivative overlays (SOFR Interest Rate Swap + USD/TWD FX Forward + Sovereign CapEx Guarantee).',
    version: 'v1.2',
    status: 'Approved',
    createdByRole: 'Structurer',
    approvedByRole: 'Risk Officer',
    approvalTimestamp: '2026-11-01T10:00:00Z',
    sourcesAndUsesValid: true,
    validationErrors: [],
    components: [
      {
        id: 'comp-501',
        name: 'SPV Class A Senior Secured Equipment Notes',
        category: 'Funding',
        type: 'Structured Senior Notes',
        provider: 'Institutional Debt Syndicate',
        principalOrNotional: 250.0,
        initialCashInflow: 250.0,
        interestRateSpreadBps: 185,
        benchmarkRatePct: 4.5,
        dayCount: 'Act/360',
        tenorMonths: 36,
        gracePeriodMonths: 12,
        amortisationType: 'Sculptured DSCR',
        upfrontFeePct: 1.00,
        commitmentFeePct: 0.30,
        collateralPledged: 'ASML & Besi Equipment Asset Pool',
        haircutPct: 25,
        priority: 1,
        retainedRisks: [],
        transferredRisks: ['Catastrophic default cushioned by First-Loss Equity & Guarantee'],
        contingentObligations: 'Covenant compliance verification quarterly.'
      },
      {
        id: 'comp-502',
        name: 'Receivables & WIP Working Capital Facility',
        category: 'Funding',
        type: 'Receivables Purchase (ABL)',
        provider: 'RhinoBank Commercial Banking',
        principalOrNotional: 80.0,
        initialCashInflow: 80.0,
        interestRateSpreadBps: 195,
        benchmarkRatePct: 4.5,
        dayCount: 'Act/360',
        tenorMonths: 36,
        gracePeriodMonths: 6,
        amortisationType: 'Linear',
        upfrontFeePct: 0.70,
        commitmentFeePct: 0.25,
        collateralPledged: 'Tier-1 Customer Accounts Receivable',
        haircutPct: 20,
        priority: 1,
        retainedRisks: ['RMA warranty reserve'],
        transferredRisks: ['Customer credit risk'],
        contingentObligations: 'Monthly borrowing base recalculation.'
      },
      {
        id: 'comp-503',
        name: 'Sponsor First-Loss Equity Tranche',
        category: 'Funding',
        type: 'Sponsor First-Loss Equity',
        provider: 'Aureom Semiconductor Group',
        principalOrNotional: 150.5,
        initialCashInflow: 150.5,
        interestRateSpreadBps: 0,
        benchmarkRatePct: 0,
        dayCount: '30/360',
        tenorMonths: 36,
        gracePeriodMonths: 0,
        amortisationType: 'Bullet',
        upfrontFeePct: 0,
        commitmentFeePct: 0,
        collateralPledged: 'Equity Junior Position',
        haircutPct: 0,
        priority: 3,
        retainedRisks: ['Junior equity risk'],
        transferredRisks: [],
        contingentObligations: 'Subordinated equity position.'
      },
      // RISK-TRANSFER OVERLAYS (No initial cash inflow, pure risk redistribution)
      {
        id: 'comp-504',
        name: 'SOFR Interest Rate Swap (Overlay: Pay Fixed 4.10% / Receive Floating)',
        category: 'Risk-Transfer',
        type: 'Interest Rate Swap (Overlay)',
        provider: 'RhinoBank Markets & Treasury Division',
        principalOrNotional: 220.0, // $220M notional swapped
        initialCashInflow: 0.0, // Risk-transfer overlay provides NO upfront funding cash
        interestRateSpreadBps: 0,
        benchmarkRatePct: 4.5,
        fixedRatePct: 4.10,
        dayCount: 'Act/360',
        tenorMonths: 36,
        gracePeriodMonths: 0,
        amortisationType: 'Custom',
        upfrontFeePct: 0.15,
        commitmentFeePct: 0,
        collateralPledged: 'Bilateral CSA Margin Account',
        haircutPct: 10,
        priority: 4,
        retainedRisks: ['Basis risk between 1-Month and 3-Month SOFR fixings'],
        transferredRisks: ['Full protection against macroeconomic SOFR interest rate spikes'],
        contingentObligations: 'Bilateral daily CSA mark-to-market variation margin threshold: $5.0M.'
      },
      {
        id: 'comp-505',
        name: 'USD / TWD Forward & Cross-Currency Hedge (Overlay)',
        category: 'Risk-Transfer',
        type: 'FX Forward (Overlay)',
        provider: 'RhinoBank FX Solutions Desk',
        principalOrNotional: 140.0, // Hedging TWD fab cleanroom & local labor costs
        initialCashInflow: 0.0,
        interestRateSpreadBps: 0,
        benchmarkRatePct: 0,
        dayCount: 'Act/360',
        tenorMonths: 24,
        gracePeriodMonths: 0,
        amortisationType: 'Custom',
        upfrontFeePct: 0.20,
        commitmentFeePct: 0,
        collateralPledged: 'Treasury FX Margin Facility',
        haircutPct: 15,
        priority: 4,
        retainedRisks: ['FX liquidity rollover risk at month 24'],
        transferredRisks: ['TWD appreciation risk against USD revenue contracts fully locked at 31.85'],
        contingentObligations: 'Collateral top-up if TWD moves > 7.5% against forward rate.'
      },
      {
        id: 'comp-506',
        name: 'National Semiconductor Strategic CapEx Guarantee (Overlay)',
        category: 'Risk-Transfer',
        type: 'Sovereign / Export Credit Guarantee (Overlay)',
        provider: 'National Science & Technology Development Agency / ECA',
        principalOrNotional: 180.0,
        initialCashInflow: 0.0,
        interestRateSpreadBps: 0,
        benchmarkRatePct: 0,
        dayCount: 'Act/360',
        tenorMonths: 36,
        gracePeriodMonths: 0,
        amortisationType: 'Custom',
        upfrontFeePct: 0.35, // Annual guarantee premium
        commitmentFeePct: 0,
        collateralPledged: 'Sovereign Backing Instrument',
        haircutPct: 0,
        priority: 4,
        retainedRisks: ['Eligibility covenants: fab must maintain domestic packaging capacity ratio'],
        transferredRisks: ['50% loss-sharing on Class A senior notes transferred to sovereign agency'],
        contingentObligations: 'Annual compliance reporting on cleanroom employment and green power.'
      }
    ]
  }
];

export const DEMO_STRESS_SCENARIOS: StressScenario[] = [
  {
    id: 'stress-cycle-winter',
    name: 'Severe Semiconductor Cyclical Down-Cycle',
    description: 'Macro slowdown: AI accelerator demand drops 25%, wafer ASP erodes 20%, customer payment delays extend to 90 days.',
    yieldShockPct: 0,
    utilisationShockPct: -25,
    priceShockPct: -20,
    delayMonths: 0,
    customerDefaultPct: 0.08,
    interestRateShockBps: 150,
    fxDevaluationPct: 0
  },
  {
    id: 'stress-ramp-delay',
    name: 'Tool Installation & Ramp Delay (+6 Months)',
    description: 'Supply chain bottleneck on Besi hybrid bonders delays fab qualification by 6 months, extending burn rate without cash revenue.',
    yieldShockPct: -10,
    utilisationShockPct: -15,
    priceShockPct: -5,
    delayMonths: 6,
    customerDefaultPct: 0.02,
    interestRateShockBps: 50,
    fxDevaluationPct: 0
  },
  {
    id: 'stress-packaging-qual-fail',
    name: 'Advanced Packaging 3D TSV Qualification Defect',
    description: 'Thermal expansion mismatch causes micro-bump delamination. Process yield collapses 30%, rework rates surge 4x.',
    yieldShockPct: -30,
    utilisationShockPct: -10,
    priceShockPct: -12,
    delayMonths: 3,
    customerDefaultPct: 0.05,
    interestRateShockBps: 0,
    fxDevaluationPct: 0
  },
  {
    id: 'stress-geopolitical-sanction',
    name: 'Geopolitical Export Restriction & Cross-Strait Tension',
    description: 'Export controls freeze shipments to 30% of end-customers, TWD depreciates 15%, freight insurance surges.',
    yieldShockPct: 0,
    utilisationShockPct: -35,
    priceShockPct: -15,
    delayMonths: 2,
    customerDefaultPct: 0.15,
    interestRateShockBps: 250,
    fxDevaluationPct: -15
  }
];

export const INITIAL_GOVERNANCE_LOGS: GovernanceLog[] = [
  {
    id: 'gov-001',
    timestamp: '2026-10-15T08:30:00Z',
    role: 'Originator',
    action: 'Project Baseline Created',
    structureId: 'struct-1-conventional',
    details: 'Initial transaction intake: Aureom Fab-7 3D advanced packaging $420M financing request.',
    hash: '8f92a11b0e3c88d1'
  },
  {
    id: 'gov-002',
    timestamp: '2026-10-22T10:14:00Z',
    role: 'Structurer',
    action: 'Structure Assembly',
    structureId: 'struct-2-equipment-abl',
    details: 'Assembled Equipment Milestone Facility + Receivables ABL discounting package.',
    hash: '3e41b99a8c1f0d22'
  },
  {
    id: 'gov-003',
    timestamp: '2026-10-28T14:45:00Z',
    role: 'Risk Officer',
    action: 'Stress Engine Validation',
    structureId: 'struct-4-spv',
    details: 'Executed 1,000-iteration Monte Carlo simulation. Confirmed P50 NPV $44.2M and LaR95 within risk limits.',
    hash: 'a718cc4399e155bc'
  },
  {
    id: 'gov-004',
    timestamp: '2026-11-01T11:20:00Z',
    role: 'Auditor',
    action: 'Model Invariant Certification',
    structureId: 'struct-5-overlays',
    details: 'Verified cash flow conservation across 36 periods; sources and uses zero imbalance certified.',
    hash: 'd667ef882109aa34'
  }
];

export const INITIAL_PRICING_OVERRIDES: PricingOverride[] = [
  {
    id: 'ovr-101',
    timestamp: '2026-10-26T15:10:00Z',
    authorRole: 'Credit Analyst',
    componentId: 'comp-201',
    field: 'Equipment Haircut Pct',
    originalValue: 20,
    overrideValue: 25,
    justification: 'Adjusted haircut higher due to ASML High-NA tool remarketing concentration in Asia-Pacific.',
    status: 'Approved'
  },
  {
    id: 'ovr-102',
    timestamp: '2026-10-29T16:40:00Z',
    authorRole: 'Structurer',
    componentId: 'comp-401',
    field: 'Class A Spread Bps',
    originalValue: 195,
    overrideValue: 175,
    justification: 'Over-subscribed orderbook from sovereign wealth co-investors reduced clearing spread by 20 bps.',
    status: 'Approved'
  }
];
