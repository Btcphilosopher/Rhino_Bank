/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Institutional Sidebar Navigation
 */

import React from 'react';
import {
  Cpu,
  Factory,
  FileText,
  Layers,
  BarChart3,
  GitCompare,
  TrendingDown,
  ShieldCheck,
  Coins,
  FileCheck2,
  CheckCircle2
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onSelectTab: (tabId: string) => void;
  modelVersion: string;
  onSelectModelVersion: (version: string) => void;
  currency: string;
  onSelectCurrency: (currency: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  modelVersion,
  onSelectModelVersion,
  currency,
  onSelectCurrency
}) => {
  const navSections = [
    {
      group: 'Manufacturing Domain',
      items: [
        { id: 'projects', label: 'Fab & Equipment', icon: Cpu, count: '5 Tools' },
        { id: 'production', label: 'Production-to-Cash', icon: Factory, count: 'Yield Model' },
        { id: 'contracts', label: 'Contracts & Offtake', icon: FileText, count: '3 Offtakers' }
      ]
    },
    {
      group: 'Financing & Pricing',
      items: [
        { id: 'structures', label: 'Structure Builder', icon: Layers, count: 'Components' },
        { id: 'comparison', label: 'Compare 5 Packages', icon: GitCompare, count: 'Demonstration' },
        { id: 'pricing', label: 'Pricing & Schedules', icon: BarChart3, count: 'DCF & Debt' },
        { id: 'waterfall', label: 'Cash Flow Waterfall', icon: Coins, count: '36 Months' }
      ]
    },
    {
      group: 'Risk, Treasury & Governance',
      items: [
        { id: 'risk', label: 'Risk & Monte Carlo', icon: TrendingDown, count: '1k Paths' },
        { id: 'collateral', label: 'Collateral & Treasury', icon: ShieldCheck, count: 'Borrowing Base' },
        { id: 'governance', label: 'Governance & Packs', icon: FileCheck2, count: 'Audit Log' },
        { id: 'tests', label: 'Invariant Test Suite', icon: CheckCircle2, count: '5 Passing' }
      ]
    }
  ];

  return (
    <aside className="w-64 bg-[#0e121a] border-r border-slate-800/80 flex flex-col justify-between shrink-0 h-[calc(100vh-53px)] select-none">
      <div className="p-3.5 space-y-5 overflow-y-auto">
        {/* Project Context & Meta Ribbon */}
        <div className="bg-[#141a24] p-2.5 rounded border border-slate-800 text-xs">
          <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
            <span>Model Version:</span>
            <select
              value={modelVersion}
              onChange={e => onSelectModelVersion(e.target.value)}
              aria-label="Model Version"
              className="bg-slate-900 border border-slate-700/80 rounded px-1.5 py-0.5 text-amber-300 font-mono text-[11px]"
            >
              <option value="v1.0">v1.0 Baseline</option>
              <option value="v1.1">v1.1 Stress Downcycle</option>
              <option value="v1.2">v1.2 Accelerated Scale</option>
            </select>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
            <span>Base Currency:</span>
            <select
              value={currency}
              onChange={e => onSelectCurrency(e.target.value)}
              aria-label="Base Currency"
              className="bg-slate-900 border border-slate-700/80 rounded px-1.5 py-0.5 text-slate-200 font-mono text-[11px]"
            >
              <option value="USD">USD ($)</option>
              <option value="EUR">EUR (€)</option>
              <option value="JPY">JPY (¥)</option>
              <option value="TWD">TWD (NT$)</option>
            </select>
          </div>
        </div>

        {/* Navigation Sections */}
        {navSections.map((section, sIdx) => (
          <div key={sIdx} className="space-y-1">
            <div className="px-2 text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
              {section.group}
            </div>
            {section.items.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`w-full flex items-center justify-between px-2.5 py-2 rounded text-xs transition-colors group ${
                    isActive
                      ? 'bg-amber-500/10 text-amber-300 font-semibold border-l-2 border-amber-400'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-500 group-hover:text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {item.count}
                  </span>
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Institutional Metadata Footer */}
      <div className="p-3 border-t border-slate-800/80 bg-[#090c12] text-[11px] text-slate-400 space-y-1">
        <div className="flex justify-between font-mono">
          <span>Engine:</span>
          <span className="text-slate-300">RhinoQuant 3.8</span>
        </div>
        <div className="flex justify-between font-mono">
          <span>Tech:</span>
          <span className="text-slate-300">Aureom.AI Synthetic</span>
        </div>
      </div>
    </aside>
  );
};
