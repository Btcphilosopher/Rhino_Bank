/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Top Navigation Bar (Three-Zone Contract)
 */

import React from 'react';
import { UserRole } from '../../types';

interface HeaderProps {
  activeTab: string;
  onSelectTab: (tabId: string) => void;
  currentRole: UserRole;
  onSelectRole: (role: UserRole) => void;
  onExportReviewPack: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  currentRole,
  onSelectRole,
  onExportReviewPack
}) => {
  const roles: UserRole[] = [
    'Originator',
    'Credit Analyst',
    'Structurer',
    'Treasury',
    'Risk Officer',
    'Auditor'
  ];

  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-[#0b0e14] border-b border-slate-800/90 sticky top-0 z-40">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-7 h-7 rounded bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center font-bold text-slate-950 text-sm shadow-sm">
          R
        </div>
        <span className="text-base font-bold tracking-tight text-slate-100 whitespace-nowrap">
          RhinoBank Silicon Finance
        </span>
      </div>

      {/* Zone 2: 4-5 clean single-line text navigation links */}
      <nav className="hidden lg:flex items-center gap-6 text-xs font-medium text-slate-400">
        <button
          onClick={() => onSelectTab('projects')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'projects' || activeTab === 'production' ? 'text-amber-400 font-semibold' : ''
          }`}
        >
          Fab & Production
        </button>
        <button
          onClick={() => onSelectTab('structures')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'structures' ? 'text-amber-400 font-semibold' : ''
          }`}
        >
          Structure Builder
        </button>
        <button
          onClick={() => onSelectTab('comparison')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'comparison' ? 'text-amber-400 font-semibold' : ''
          }`}
        >
          Compare 5 Packages
        </button>
        <button
          onClick={() => onSelectTab('pricing')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'pricing' || activeTab === 'waterfall' ? 'text-amber-400 font-semibold' : ''
          }`}
        >
          Pricing & Waterfalls
        </button>
        <button
          onClick={() => onSelectTab('risk')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'risk' || activeTab === 'collateral' ? 'text-amber-400 font-semibold' : ''
          }`}
        >
          Risk & Collateral
        </button>
        <button
          onClick={() => onSelectTab('governance')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'governance' || activeTab === 'tests' ? 'text-amber-400 font-semibold' : ''
          }`}
        >
          Audit & Invariants
        </button>
      </nav>

      {/* Zone 3: 1 primary action + role selector */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="flex items-center gap-1.5 text-xs text-slate-400 bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5">
          <span className="text-slate-400">Role:</span>
          <select
            value={currentRole}
            onChange={e => onSelectRole(e.target.value as UserRole)}
            aria-label="User Workspace Role"
            className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
          >
            {roles.map(r => (
              <option key={r} value={r} className="bg-slate-900 text-slate-200">
                {r}
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={onExportReviewPack}
          className="px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 rounded hover:from-amber-300 hover:to-amber-400 transition-colors whitespace-nowrap shrink-0 shadow-sm"
        >
          Export Review Pack
        </button>
      </div>
    </header>
  );
};
