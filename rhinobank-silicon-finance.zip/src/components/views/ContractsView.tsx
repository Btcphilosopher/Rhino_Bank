/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Customer Offtake Contracts & Prepayments View
 */

import React, { useState } from 'react';
import { CustomerContract } from '../../types';
import { FileText, Plus, ShieldAlert, Award } from 'lucide-react';

interface ContractsViewProps {
  contracts: CustomerContract[];
  onUpdateContracts: (updated: CustomerContract[]) => void;
}

export const ContractsView: React.FC<ContractsViewProps> = ({
  contracts,
  onUpdateContracts
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newContract, setNewContract] = useState<Partial<CustomerContract>>({
    customerName: '',
    creditRating: 'A',
    productName: '',
    salesModel: 'Packaged Device Sales',
    committedMonthlyVolume: 25000,
    unitPriceUSD: 120.0,
    takeOrPayPenaltyPct: 70,
    prepaymentAmountUSD: 20000000,
    prepaymentAmortisationPctPerUnit: 10.0,
    dilutionReservePct: 2.5,
    paymentDays: 60
  });

  const handleAddContract = () => {
    if (!newContract.customerName || !newContract.productName) return;
    const added: CustomerContract = {
      id: `ct-${Date.now()}`,
      customerName: newContract.customerName,
      creditRating: newContract.creditRating || 'A',
      productName: newContract.productName,
      salesModel: newContract.salesModel || 'Packaged Device Sales',
      committedMonthlyVolume: Number(newContract.committedMonthlyVolume) || 10000,
      unitPriceUSD: Number(newContract.unitPriceUSD) || 100,
      takeOrPayPenaltyPct: Number(newContract.takeOrPayPenaltyPct) || 70,
      prepaymentAmountUSD: Number(newContract.prepaymentAmountUSD) || 10000000,
      prepaymentAmortisationPctPerUnit: Number(newContract.prepaymentAmortisationPctPerUnit) || 10,
      dilutionReservePct: Number(newContract.dilutionReservePct) || 2.5,
      paymentDays: Number(newContract.paymentDays) || 60
    };
    onUpdateContracts([...contracts, added]);
    setShowAddModal(false);
  };

  const handleRemoveContract = (id: string) => {
    onUpdateContracts(contracts.filter(c => c.id !== id));
  };

  const totalPrepayments = contracts.reduce((acc, c) => acc + c.prepaymentAmountUSD, 0) / 1e6;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Customer Commitments</span>
            <span>·</span>
            <span>Take-or-Pay Agreements</span>
            <span>·</span>
            <span className="text-amber-400 font-mono">Offtake Repository</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            Customer Offtake Contracts & Prepayment Facility
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-[11px] text-slate-400">Total Prepayments Funded</div>
            <div className="text-lg font-mono font-bold text-emerald-400 tabular-nums">
              ${totalPrepayments.toFixed(1)}M
            </div>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded transition-colors"
          >
            <Plus className="w-3.5 h-3.5" /> Add Offtake Contract
          </button>
        </div>
      </div>

      {/* Contract Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {contracts.map(contract => (
          <div
            key={contract.id}
            className="bg-[#10141d] p-4 rounded border border-slate-800 flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[10px] text-slate-400 font-mono block">
                    Customer & Rating
                  </span>
                  <h2 className="text-sm font-bold text-slate-100 mt-0.5">
                    {contract.customerName}
                  </h2>
                </div>
                <div className="px-2 py-0.5 bg-slate-900 border border-slate-700 rounded text-xs font-mono font-bold text-amber-400">
                  {contract.creditRating}
                </div>
              </div>

              <div className="mt-3 text-xs text-slate-300">
                <span className="text-slate-400 block text-[11px]">Product Contracted</span>
                <span className="font-medium text-slate-200 block">{contract.productName}</span>
              </div>
            </div>

            <div className="space-y-2 text-xs font-mono border-t border-slate-800/80 pt-3">
              <div className="flex justify-between">
                <span className="text-slate-400 font-sans">Sales Model:</span>
                <span className="text-slate-200">{contract.salesModel}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-sans">Monthly Volume:</span>
                <span className="text-amber-400 font-semibold tabular-nums">
                  {contract.committedMonthlyVolume.toLocaleString()}{' '}
                  {contract.salesModel === 'Wafer Sales' ? 'wafers' : 'devices'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-sans">Unit Selling Price:</span>
                <span className="text-emerald-400 font-semibold tabular-nums">
                  ${contract.unitPriceUSD.toLocaleString()} / unit
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-sans">Take-or-Pay Penalty:</span>
                <span className="text-cyan-300 font-semibold tabular-nums">
                  {contract.takeOrPayPenaltyPct}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-sans">Prepayment Advance:</span>
                <span className="text-amber-300 font-bold tabular-nums">
                  ${(contract.prepaymentAmountUSD / 1e6).toFixed(1)}M
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-sans">Dilution Reserve:</span>
                <span className="text-rose-400 font-semibold tabular-nums">
                  {contract.dilutionReservePct}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-sans">Payment Terms:</span>
                <span className="text-slate-300 tabular-nums">{contract.paymentDays} Days DSO</span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-xs">
              <span className="text-[11px] text-slate-400">
                Amort: ${contract.prepaymentAmortisationPctPerUnit}/unit credit
              </span>
              <button
                onClick={() => handleRemoveContract(contract.id)}
                className="text-slate-400 hover:text-rose-400 text-[11px]"
              >
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Offtake Risk & Concentration Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="bg-[#10141d] p-4 rounded border border-slate-800 space-y-3 text-xs">
          <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <Award className="w-4 h-4 text-emerald-400" /> Prepayment Synthetic Financing Mechanics
          </h2>
          <p className="text-slate-400 text-[12px] leading-relaxed">
            Customer prepayments provide non-dilutive, zero-interest funding cash at inception in exchange for priority capacity reservation. Unlike bank debt, repayment occurs synthetically as unit shipments amortize the advance balance over the contract tenor.
          </p>
          <div className="p-3 bg-slate-900/60 rounded border border-slate-800 font-mono text-[11px] space-y-1">
            <div className="text-amber-400 font-semibold">Total Advance Pool: ${totalPrepayments.toFixed(1)}M</div>
            <div className="text-slate-300">
              Contracted Delivery Obligation: ~105,000 packaged chiplets/mo + 3,500 300mm carrier wafers/mo.
            </div>
          </div>
        </div>

        <div className="bg-[#10141d] p-4 rounded border border-slate-800 space-y-3 text-xs">
          <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" /> Dilution & Dispute Risk Mitigation
          </h2>
          <p className="text-slate-400 text-[12px] leading-relaxed">
            Semiconductor customers routinely hold back invoice payments for RMA returns, test yield failures, or specification deviations. RhinoBank requires explicit dilution reserves (2.0% – 3.0%) when structuring receivables purchases.
          </p>
          <div className="p-3 bg-slate-900/60 rounded border border-slate-800 font-mono text-[11px] space-y-1">
            <div className="text-rose-400 font-semibold">Weighted Dilution Reserve: 2.38%</div>
            <div className="text-slate-300">
              Customer Concentration: Hyperion (52%), Aether (28%), OmniLogic (20%).
            </div>
          </div>
        </div>
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-[#121722] border border-slate-700 rounded-lg p-5 max-w-md w-full space-y-4">
            <h3 className="text-sm font-bold text-slate-100">Add Customer Offtake Contract</h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Customer Name</label>
                <input
                  type="text"
                  value={newContract.customerName}
                  onChange={e => setNewContract({ ...newContract, customerName: e.target.value })}
                  placeholder="e.g. Cerulean AI Compute Corp"
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Credit Rating</label>
                  <select
                    value={newContract.creditRating}
                    onChange={e => setNewContract({ ...newContract, creditRating: e.target.value as any })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
                  >
                    <option value="AAA">AAA</option>
                    <option value="AA">AA</option>
                    <option value="A">A</option>
                    <option value="BBB">BBB</option>
                    <option value="BB">BB</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Sales Model</label>
                  <select
                    value={newContract.salesModel}
                    onChange={e => setNewContract({ ...newContract, salesModel: e.target.value as any })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
                  >
                    <option value="Packaged Device Sales">Packaged Device Sales</option>
                    <option value="Wafer Sales">Wafer Sales</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Product Description</label>
                <input
                  type="text"
                  value={newContract.productName}
                  onChange={e => setNewContract({ ...newContract, productName: e.target.value })}
                  placeholder="e.g. 2.5D AI CoWoS Chiplet"
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Monthly Volume</label>
                  <input
                    type="number"
                    value={newContract.committedMonthlyVolume}
                    onChange={e => setNewContract({ ...newContract, committedMonthlyVolume: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Unit Price ($)</label>
                  <input
                    type="number"
                    value={newContract.unitPriceUSD}
                    onChange={e => setNewContract({ ...newContract, unitPriceUSD: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 font-mono"
                  />
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200"
              >
                Cancel
              </button>
              <button
                onClick={handleAddContract}
                className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 rounded hover:bg-amber-300"
              >
                Save Offtake
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
