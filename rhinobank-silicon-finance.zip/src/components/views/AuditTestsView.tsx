/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Invariant Audit & Mathematical Test Runner View
 */

import React, { useState } from 'react';
import {
  SemiconductorProject,
  CustomerContract,
  FinancingStructure
} from '../../types';
import { runInvariantTestSuite, InvariantTestResult } from '../../math/quantitativeEngine';
import { CheckCircle2, XCircle, Play, ShieldCheck, RefreshCw } from 'lucide-react';

interface AuditTestsViewProps {
  project: SemiconductorProject;
  contracts: CustomerContract[];
  structure: FinancingStructure;
}

export const AuditTestsView: React.FC<AuditTestsViewProps> = ({
  project,
  contracts,
  structure
}) => {
  const [testResults, setTestResults] = useState<InvariantTestResult[]>(() =>
    runInvariantTestSuite(project, contracts, structure)
  );
  const [isRunning, setIsRunning] = useState(false);

  const handleRunTests = () => {
    setIsRunning(true);
    setTimeout(() => {
      const results = runInvariantTestSuite(project, contracts, structure);
      setTestResults(results);
      setIsRunning(false);
    }, 150);
  };

  const allPassed = testResults.every(t => t.passed);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Quantitative Integrity</span>
            <span>·</span>
            <span>Mathematical Invariants</span>
            <span>·</span>
            <span className="text-emerald-400 font-mono">Formal Verification</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            Automated Invariant Test Suite & Mathematical Audit
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-xs font-mono">
            <span
              className={`px-2.5 py-1 rounded font-bold ${
                allPassed
                  ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-700/80'
                  : 'bg-rose-950/80 text-rose-400 border border-rose-700/80'
              }`}
            >
              {allPassed ? 'ALL INVARIANTS CERTIFIED' : 'TEST FAILURES DETECTED'}
            </span>
          </div>

          <button
            onClick={handleRunTests}
            disabled={isRunning}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded transition-colors disabled:opacity-50"
          >
            {isRunning ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Play className="w-3.5 h-3.5 fill-current" />
            )}
            Run Audit Suite
          </button>
        </div>
      </div>

      {/* Overview Card */}
      <div className="bg-[#10141d] p-4 rounded border border-slate-800 space-y-3">
        <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" /> Formal Audit Scope
        </h2>
        <p className="text-xs text-slate-400 leading-relaxed">
          The RhinoQuant audit test suite executes deterministic verification over the financial model to prove conservation of cash flows, strict waterfall priority ordering, non-negative collateral borrowing base bounds, physical yield stage bounds (no loss double counting), and bit-for-bit Monte Carlo seed reproducibility.
        </p>
      </div>

      {/* Tests Grid */}
      <div className="space-y-3">
        {testResults.map((test, idx) => (
          <div
            key={idx}
            className="p-4 bg-[#10141d] rounded border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4"
          >
            <div className="space-y-1.5 max-w-2xl">
              <div className="flex items-center gap-2">
                {test.passed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                )}
                <span className="font-semibold text-slate-100 text-xs">
                  {test.testName}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  [{test.category}]
                </span>
              </div>
              <p className="text-xs text-slate-400 pl-6 leading-relaxed">
                {test.details}
              </p>
              <div className="pl-6 grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] font-mono text-slate-400 pt-1">
                <div>
                  <span className="text-slate-400 font-sans">Requirement: </span>
                  <span className="text-slate-300">{test.expected}</span>
                </div>
                <div>
                  <span className="text-slate-400 font-sans">Observed: </span>
                  <span className="text-amber-300 font-semibold">{test.actual}</span>
                </div>
              </div>
            </div>

            <div className="shrink-0 text-right">
              <span
                className={`px-3 py-1 rounded text-xs font-mono font-bold ${
                  test.passed
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : 'bg-rose-950 text-rose-300 border border-rose-800'
                }`}
              >
                {test.passed ? 'PASS' : 'FAIL'}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
