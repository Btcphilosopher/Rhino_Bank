/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Production-to-Cash Quantitative Pipeline View
 */

import React from 'react';
import { SemiconductorProject, CashFlowPeriod } from '../../types';
import { calculateGrossDiesPerWafer, calculateMurphyProcessYield } from '../../math/quantitativeEngine';
import { Sliders, Layers, ArrowRight } from 'lucide-react';

interface ProductionViewProps {
  project: SemiconductorProject;
  onUpdateProject: (p: SemiconductorProject) => void;
  periods: CashFlowPeriod[];
}

export const ProductionView: React.FC<ProductionViewProps> = ({
  project,
  onUpdateProject,
  periods
}) => {
  const grossDies = calculateGrossDiesPerWafer(project.waferDiameterMm, project.dieAreaSqMm);
  const murphyYield = calculateMurphyProcessYield(project.dieAreaSqMm, project.defectDensityPerSqCm);

  // Take Month 24 as mature production baseline snapshot
  const maturePeriod = periods.find(p => p.periodMonth === 24) || periods[periods.length - 1];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Physical Manufacturing</span>
            <span>·</span>
            <span>Physics-to-Finance Pipeline</span>
            <span>·</span>
            <span className="text-emerald-400 font-mono">Murphy Defect Model</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            Production-to-Cash Physical Pipeline
          </h1>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="bg-[#10141d] px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Gross Dies / Wafer</span>
            <span className="text-amber-400 font-bold tabular-nums">{grossDies} dies</span>
          </div>
          <div className="bg-[#10141d] px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Baseline Process Yield</span>
            <span className="text-emerald-400 font-bold tabular-nums">
              {(murphyYield * 100).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>

      {/* Traceable Physical Pipeline Sequence */}
      <div className="bg-[#10141d] p-4 rounded border border-slate-800 space-y-3">
        <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <Layers className="w-4 h-4 text-amber-400" /> Transparent Stage-by-Stage Manufacturing Waterfall
        </h2>
        <p className="text-xs text-slate-400">
          Traceable transformation from cleanroom wafer starts down to realized cash collections. Every loss stage is isolated to prevent double-counting.
        </p>

        {/* Horizontal Flow Steps */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 pt-2 text-xs">
          {/* Step 1: Capacity */}
          <div className="p-3 bg-slate-900/80 rounded border border-slate-800 flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-mono block">Stage 1</span>
              <span className="font-semibold text-slate-200">Installed Capacity</span>
            </div>
            <div className="mt-3">
              <span className="font-mono text-base font-bold text-slate-100 tabular-nums">
                {project.maxWaferCapacityPerMonth.toLocaleString()}
              </span>
              <span className="text-[10px] text-slate-400 block">wafers / month</span>
            </div>
          </div>

          {/* Step 2: Starts */}
          <div className="p-3 bg-slate-900/80 rounded border border-slate-800 flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-mono block">Stage 2</span>
              <span className="font-semibold text-slate-200">Wafer Starts (M24)</span>
            </div>
            <div className="mt-3">
              <span className="font-mono text-base font-bold text-amber-400 tabular-nums">
                {maturePeriod?.waferStarts.toLocaleString()}
              </span>
              <span className="text-[10px] text-slate-400 block">starts (92% util)</span>
            </div>
          </div>

          {/* Step 3: Completed Wafers */}
          <div className="p-3 bg-slate-900/80 rounded border border-slate-800 flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-mono block">Stage 3</span>
              <span className="font-semibold text-slate-200">Completed Wafers</span>
            </div>
            <div className="mt-3">
              <span className="font-mono text-base font-bold text-slate-200 tabular-nums">
                {maturePeriod?.completedWafers.toLocaleString()}
              </span>
              <span className="text-[10px] text-rose-400 block">-{project.scrapRatePct}% scrap</span>
            </div>
          </div>

          {/* Step 4: Good Dies */}
          <div className="p-3 bg-slate-900/80 rounded border border-slate-800 flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-mono block">Stage 4</span>
              <span className="font-semibold text-slate-200">Good Dies</span>
            </div>
            <div className="mt-3">
              <span className="font-mono text-base font-bold text-emerald-400 tabular-nums">
                {((maturePeriod?.goodDies || 0) / 1000).toFixed(0)}k
              </span>
              <span className="text-[10px] text-emerald-300 block">
                {((maturePeriod?.processYieldPct || 0) * 100).toFixed(1)}% yield
              </span>
            </div>
          </div>

          {/* Step 5: Packaged Units */}
          <div className="p-3 bg-slate-900/80 rounded border border-slate-800 flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-mono block">Stage 5</span>
              <span className="font-semibold text-slate-200">Packaged Units</span>
            </div>
            <div className="mt-3">
              <span className="font-mono text-base font-bold text-cyan-400 tabular-nums">
                {((maturePeriod?.goodPackagedUnits || 0) / 1000).toFixed(0)}k
              </span>
              <span className="text-[10px] text-cyan-300 block">
                {((maturePeriod?.packagingYieldPct || 0) * 100).toFixed(1)}% pkg yield
              </span>
            </div>
          </div>

          {/* Step 6: Invoices */}
          <div className="p-3 bg-slate-900/80 rounded border border-slate-800 flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-mono block">Stage 6</span>
              <span className="font-semibold text-slate-200">Net Invoiced</span>
            </div>
            <div className="mt-3">
              <span className="font-mono text-base font-bold text-slate-100 tabular-nums">
                ${maturePeriod?.netInvoicedUSD.toFixed(1)}M
              </span>
              <span className="text-[10px] text-slate-400 block">gross - dilution</span>
            </div>
          </div>

          {/* Step 7: Collections */}
          <div className="p-3 bg-slate-900/80 rounded border border-slate-800 flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-mono block">Stage 7</span>
              <span className="font-semibold text-slate-200">Cash Collected</span>
            </div>
            <div className="mt-3">
              <span className="font-mono text-base font-bold text-emerald-400 tabular-nums">
                ${maturePeriod?.cashCollectionsUSD.toFixed(1)}M
              </span>
              <span className="text-[10px] text-emerald-300 block">{project.customerPaymentTermsDays}d DSO cycle</span>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Manufacturing & Financial Assumptions Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 bg-[#10141d] p-4 rounded border border-slate-800 space-y-4">
          <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" /> Interactive Yield, Geometry & Timing Parameters
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {/* Defect Density Slider */}
            <div className="p-3 bg-slate-900/80 rounded border border-slate-800/80 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-300">Cleanroom Defect Density (D)</span>
                <span className="font-mono text-amber-400 font-semibold">
                  {project.defectDensityPerSqCm} / cm²
                </span>
              </div>
              <input
                type="range"
                min="0.02"
                max="0.25"
                step="0.005"
                value={project.defectDensityPerSqCm}
                onChange={e => onUpdateProject({ ...project, defectDensityPerSqCm: Number(e.target.value) })}
                className="w-full accent-amber-400 cursor-pointer"
              />
              <span className="text-[11px] text-slate-400 block">
                Calculates Murphy process yield based on 125 mm² chiplet area.
              </span>
            </div>

            {/* Scrap Rate Slider */}
            <div className="p-3 bg-slate-900/80 rounded border border-slate-800/80 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-300">Wafer Fab Scrap Rate (%)</span>
                <span className="font-mono text-rose-400 font-semibold">
                  {project.scrapRatePct}%
                </span>
              </div>
              <input
                type="range"
                min="0.5"
                max="8.0"
                step="0.1"
                value={project.scrapRatePct}
                onChange={e => onUpdateProject({ ...project, scrapRatePct: Number(e.target.value) })}
                className="w-full accent-rose-400 cursor-pointer"
              />
              <span className="text-[11px] text-slate-400 block">
                Physical breakage, thermal slip, and cleanroom handling loss.
              </span>
            </div>

            {/* Customer DSO Terms Slider */}
            <div className="p-3 bg-slate-900/80 rounded border border-slate-800/80 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-300">Customer Payment Terms (DSO)</span>
                <span className="font-mono text-cyan-400 font-semibold">
                  {project.customerPaymentTermsDays} Days
                </span>
              </div>
              <input
                type="range"
                min="30"
                max="120"
                step="15"
                value={project.customerPaymentTermsDays}
                onChange={e => onUpdateProject({ ...project, customerPaymentTermsDays: Number(e.target.value) })}
                className="w-full accent-cyan-400 cursor-pointer"
              />
              <span className="text-[11px] text-slate-400 block">
                Invoice generation to cash bank settlement latency.
              </span>
            </div>

            {/* Packaging & Test Cycle Time */}
            <div className="p-3 bg-slate-900/80 rounded border border-slate-800/80 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-300">Backend Packaging Cycle Time</span>
                <span className="font-mono text-emerald-400 font-semibold">
                  {project.packagingCycleTimeDays} Days
                </span>
              </div>
              <input
                type="range"
                min="7"
                max="45"
                step="2"
                value={project.packagingCycleTimeDays}
                onChange={e => onUpdateProject({ ...project, packagingCycleTimeDays: Number(e.target.value) })}
                className="w-full accent-emerald-400 cursor-pointer"
              />
              <span className="text-[11px] text-slate-400 block">
                Substrate dicing, micro-bump bonding, and ATE test queue.
              </span>
            </div>
          </div>
        </div>

        {/* Unit Distinction Box */}
        <div className="bg-[#10141d] p-4 rounded border border-slate-800 space-y-3 text-xs">
          <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <ArrowRight className="w-4 h-4 text-emerald-400" /> Explicit Unit Standards
          </h2>
          <p className="text-slate-400 text-[11px]">
            To prevent pricing errors, RhinoBank Silicon Finance enforces strict unit differentiation across contracts:
          </p>
          <div className="space-y-1.5 text-[11px] font-mono">
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Wafers/Month:</span>
              <span className="text-slate-200">300mm Raw Silicon Starts</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Dies/Wafer:</span>
              <span className="text-slate-200">Gross Uncut Silicon Reticles</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Good Units:</span>
              <span className="text-slate-200">Post-Process Yield Filtered</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Packaged Units:</span>
              <span className="text-slate-200">Delivered System Modules</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Currency / Wafer:</span>
              <span className="text-amber-400">$6,800 USD (OmniLogic)</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Currency / Device:</span>
              <span className="text-amber-400">$145 USD (Hyperion H1000)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
