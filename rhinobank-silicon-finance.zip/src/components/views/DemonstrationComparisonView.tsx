/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — 5 Demonstration Financing Packages Comparison Matrix
 */

import React, { useState } from 'react';
import {
  FinancingStructure,
  SemiconductorProject,
  CustomerContract
} from '../../types';
import {
  simulateProjectCashFlows,
  runMonteCarloSimulation
} from '../../math/quantitativeEngine';
import { GitCompare, Award, CheckCircle2, ChevronRight, Layers } from 'lucide-react';

interface DemonstrationComparisonViewProps {
  structures: FinancingStructure[];
  project: SemiconductorProject;
  contracts: CustomerContract[];
  onSelectStructure: (structure: FinancingStructure) => void;
  selectedStructureId: string;
  currency: string;
}

export const DemonstrationComparisonView: React.FC<DemonstrationComparisonViewProps> = ({
  structures,
  project,
  contracts,
  onSelectStructure,
  selectedStructureId,
  currency
}) => {
  const [selectedObjective, setSelectedObjective] = useState<
    'wacc' | 'liquidity' | 'risk-transfer' | 'unit-cost'
  >('wacc');

  const currSymbol = currency === 'USD' ? '$' : currency === 'EUR' ? '€' : currency === 'JPY' ? '¥' : 'NT$';

  // Compute metrics for all 5 structures
  const comparisonResults = structures.map(struct => {
    const sim = simulateProjectCashFlows(project, contracts, struct);
    const mc = runMonteCarloSimulation(project, contracts, struct, 350, 42);
    return {
      structure: struct,
      metrics: sim.metrics,
      mc: mc
    };
  });

  // Calculate dynamic objective scores
  const ranked = [...comparisonResults].sort((a, b) => {
    if (selectedObjective === 'wacc') {
      return a.metrics.weightedAverageCostOfCapitalPct - b.metrics.weightedAverageCostOfCapitalPct;
    }
    if (selectedObjective === 'liquidity') {
      return b.metrics.minDSCR - a.metrics.minDSCR;
    }
    if (selectedObjective === 'risk-transfer') {
      // Structure with lowest funding shortfall prob and lower expected loss
      return a.mc.fundingShortfallProbabilityPct - b.mc.fundingShortfallProbabilityPct;
    }
    if (selectedObjective === 'unit-cost') {
      return a.metrics.totalDeliveredCashCostUSD - b.metrics.totalDeliveredCashCostUSD;
    }
    return 0;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Demonstration Benchmark</span>
            <span>·</span>
            <span>Aureom Fab-7 3D Packaging</span>
            <span>·</span>
            <span className="text-amber-400 font-mono">5 Package Comparative Matrix</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            Side-by-Side Financing Package Comparison & Multi-Objective Ranking
          </h1>
        </div>

        {/* Dynamic Objective Filter */}
        <div className="flex items-center gap-2 text-xs bg-slate-900 border border-slate-800 rounded p-1">
          <span className="text-slate-400 pl-2">Optimization Objective:</span>
          <button
            onClick={() => setSelectedObjective('wacc')}
            className={`px-2.5 py-1 rounded text-xs transition-colors whitespace-nowrap ${
              selectedObjective === 'wacc'
                ? 'bg-amber-400 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Lowest WACC
          </button>
          <button
            onClick={() => setSelectedObjective('liquidity')}
            className={`px-2.5 py-1 rounded text-xs transition-colors whitespace-nowrap ${
              selectedObjective === 'liquidity'
                ? 'bg-amber-400 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Max Liquidity Headroom
          </button>
          <button
            onClick={() => setSelectedObjective('risk-transfer')}
            className={`px-2.5 py-1 rounded text-xs transition-colors whitespace-nowrap ${
              selectedObjective === 'risk-transfer'
                ? 'bg-amber-400 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Max Risk Redistribution
          </button>
          <button
            onClick={() => setSelectedObjective('unit-cost')}
            className={`px-2.5 py-1 rounded text-xs transition-colors whitespace-nowrap ${
              selectedObjective === 'unit-cost'
                ? 'bg-amber-400 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Lowest Unit Delivered Cost
          </button>
        </div>
      </div>

      {/* Multi-Objective Evaluation Ranking Ribbon */}
      <div className="p-4 bg-[#10141d] rounded border border-slate-800 space-y-2">
        <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
          <Award className="w-4 h-4 text-amber-400" />
          <span>
            Current Objective Ranking: {selectedObjective === 'wacc' && 'Cost of Capital Minimization'}
            {selectedObjective === 'liquidity' && 'Downside Debt Service Cushion'}
            {selectedObjective === 'risk-transfer' && 'Comprehensive Risk Transfer to Institutional Counterparties'}
            {selectedObjective === 'unit-cost' && 'Lowest Delivered Cash Cost per Packaged Die'}
          </span>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          RhinoBank Silicon Finance does not artificially preselect a winner. Structures are ranked purely against your explicit strategic objective. Top ranked: <strong className="text-slate-200">{ranked[0]?.structure.name}</strong>.
        </p>
      </div>

      {/* 5-Column Side-by-Side Comparison Matrix */}
      <div className="bg-[#10141d] rounded border border-slate-800 overflow-hidden">
        <div className="p-3.5 bg-slate-900/80 border-b border-slate-800">
          <h2 className="text-sm font-semibold text-slate-200">
            Institutional Structure Comparison Matrix
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Compare funding raised, investor returns, unit cost implications, and risk allocation
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0b0e14] text-slate-400 uppercase font-mono text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-3 w-56">Metric / Dimension</th>
                {comparisonResults.map(item => (
                  <th
                    key={item.structure.id}
                    className={`py-3 px-3 text-right ${
                      item.structure.id === selectedStructureId
                        ? 'bg-amber-950/20 text-amber-300 border-b-2 border-amber-400'
                        : 'text-slate-200'
                    }`}
                  >
                    <div className="font-sans font-bold text-xs truncate max-w-[170px] ml-auto">
                      {item.structure.name.split('.')[1] || item.structure.name}
                    </div>
                    <div className="text-[10px] font-mono text-slate-400 mt-0.5">
                      {item.structure.version}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {/* Row 1: Funding Raised */}
              <tr className="hover:bg-slate-900/40">
                <td className="py-2.5 px-3 font-sans font-medium text-slate-300">
                  Total Funding Raised
                </td>
                {comparisonResults.map(item => (
                  <td key={item.structure.id} className="py-2.5 px-3 text-right font-bold text-slate-100 tabular-nums">
                    {currSymbol}{item.metrics.totalFundingRaisedUSD.toFixed(1)}M
                  </td>
                ))}
              </tr>

              {/* Row 2: WACC */}
              <tr className="hover:bg-slate-900/40 bg-slate-900/20">
                <td className="py-2.5 px-3 font-sans font-medium text-slate-300">
                  Weighted Avg Cost of Capital (WACC)
                </td>
                {comparisonResults.map(item => (
                  <td
                    key={item.structure.id}
                    className={`py-2.5 px-3 text-right font-bold tabular-nums ${
                      item.metrics.weightedAverageCostOfCapitalPct <= 7.5 ? 'text-emerald-400' : 'text-slate-200'
                    }`}
                  >
                    {item.metrics.weightedAverageCostOfCapitalPct.toFixed(1)}%
                  </td>
                ))}
              </tr>

              {/* Row 3: Sponsor Equity IRR */}
              <tr className="hover:bg-slate-900/40">
                <td className="py-2.5 px-3 font-sans font-medium text-slate-300">
                  Sponsor Equity IRR
                </td>
                {comparisonResults.map(item => (
                  <td key={item.structure.id} className="py-2.5 px-3 text-right font-semibold text-amber-300 tabular-nums">
                    {item.metrics.sponsorIRRPct.toFixed(1)}%
                  </td>
                ))}
              </tr>

              {/* Row 4: Minimum DSCR */}
              <tr className="hover:bg-slate-900/40">
                <td className="py-2.5 px-3 font-sans font-medium text-slate-300">
                  Minimum DSCR
                </td>
                {comparisonResults.map(item => (
                  <td
                    key={item.structure.id}
                    className={`py-2.5 px-3 text-right font-bold tabular-nums ${
                      item.metrics.minDSCR >= 1.35 ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {item.metrics.minDSCR.toFixed(2)}x
                  </td>
                ))}
              </tr>

              {/* Row 5: Total Financing Expense */}
              <tr className="hover:bg-slate-900/40">
                <td className="py-2.5 px-3 font-sans font-medium text-slate-300">
                  Total Financing Expense (36 Mo)
                </td>
                {comparisonResults.map(item => (
                  <td key={item.structure.id} className="py-2.5 px-3 text-right text-purple-300 tabular-nums">
                    {currSymbol}{item.metrics.totalFinancingExpenseUSD.toFixed(1)}M
                  </td>
                ))}
              </tr>

              {/* Row 6: Delivered Unit Cost */}
              <tr className="hover:bg-slate-900/40 bg-slate-900/30">
                <td className="py-2.5 px-3 font-sans font-medium text-slate-300">
                  Total Delivered Cost / Unit
                </td>
                {comparisonResults.map(item => (
                  <td
                    key={item.structure.id}
                    className={`py-2.5 px-3 text-right font-bold tabular-nums ${
                      item.metrics.totalDeliveredCashCostUSD <= 48 ? 'text-emerald-400' : 'text-slate-200'
                    }`}
                  >
                    {currSymbol}{item.metrics.totalDeliveredCashCostUSD.toFixed(2)}
                  </td>
                ))}
              </tr>

              {/* Row 7: Funding Shortfall Probability (Monte Carlo) */}
              <tr className="hover:bg-slate-900/40">
                <td className="py-2.5 px-3 font-sans font-medium text-slate-300">
                  Funding Shortfall Probability (MC)
                </td>
                {comparisonResults.map(item => (
                  <td
                    key={item.structure.id}
                    className={`py-2.5 px-3 text-right font-semibold tabular-nums ${
                      item.mc.fundingShortfallProbabilityPct <= 3.0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {item.mc.fundingShortfallProbabilityPct.toFixed(1)}%
                  </td>
                ))}
              </tr>

              {/* Row 8: P5 Downside Outcome */}
              <tr className="hover:bg-slate-900/40">
                <td className="py-2.5 px-3 font-sans font-medium text-slate-300">
                  P5 Downside Project NPV
                </td>
                {comparisonResults.map(item => (
                  <td
                    key={item.structure.id}
                    className={`py-2.5 px-3 text-right tabular-nums ${
                      item.mc.percentiles.p5 >= 0 ? 'text-slate-200' : 'text-rose-400'
                    }`}
                  >
                    {currSymbol}{item.mc.percentiles.p5}M
                  </td>
                ))}
              </tr>

              {/* Row 9: Primary Risk Retained by Manufacturer */}
              <tr className="hover:bg-slate-900/40 font-sans">
                <td className="py-2.5 px-3 font-medium text-slate-300">
                  Retained Manufacturer Exposure
                </td>
                {comparisonResults.map(item => (
                  <td key={item.structure.id} className="py-2.5 px-3 text-right text-[11px] text-slate-400">
                    {item.structure.id === 'struct-1-conventional' && '100% Market, Yield, Delay & Rates'}
                    {item.structure.id === 'struct-2-equipment-abl' && 'Tool uptime & RMA dispute reserves'}
                    {item.structure.id === 'struct-3-customer-prepay' && 'Delivery SLAs & yield guarantees'}
                    {item.structure.id === 'struct-4-spv' && 'First-loss SPV equity absorption'}
                    {item.structure.id === 'struct-5-overlays' && 'Basis spread & cleanroom quotas'}
                  </td>
                ))}
              </tr>

              {/* Row 10: Select & Activate Action */}
              <tr className="font-sans">
                <td className="py-3 px-3 font-semibold text-slate-200">
                  Workbench Active Selection
                </td>
                {comparisonResults.map(item => (
                  <td key={item.structure.id} className="py-3 px-3 text-right">
                    {item.structure.id === selectedStructureId ? (
                      <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-400">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Active in Workbench
                      </span>
                    ) : (
                      <button
                        onClick={() => onSelectStructure(item.structure)}
                        className="px-2.5 py-1 text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                      >
                        Select Package
                      </button>
                    )}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
