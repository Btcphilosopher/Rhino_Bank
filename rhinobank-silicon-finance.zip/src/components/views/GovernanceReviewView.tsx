/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Governance, Maker-Checker Approvals & Review Pack
 */

import React, { useState } from 'react';
import {
  FinancingStructure,
  UserRole,
  GovernanceLog,
  PricingOverride,
  SemiconductorProject
} from '../../types';
import { FileCheck2, ShieldCheck, CheckCircle2, XCircle, FileText, Download, Award } from 'lucide-react';

interface GovernanceReviewViewProps {
  structure: FinancingStructure;
  onUpdateStructure: (updated: FinancingStructure) => void;
  currentRole: UserRole;
  project: SemiconductorProject;
  governanceLogs: GovernanceLog[];
  onAddLog: (log: GovernanceLog) => void;
  pricingOverrides: PricingOverride[];
  currency: string;
}

export const GovernanceReviewView: React.FC<GovernanceReviewViewProps> = ({
  structure,
  onUpdateStructure,
  currentRole,
  project,
  governanceLogs,
  onAddLog,
  pricingOverrides,
  currency
}) => {
  const [showTermSheetModal, setShowTermSheetModal] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [showRejectionInput, setShowRejectionInput] = useState(false);

  // Maker-checker permission validation:
  // Originators and Structurers are "Makers" (submit)
  // Credit Analysts, Risk Officers, and Auditors are "Checkers" (approve/reject)
  const canSubmit = (currentRole === 'Originator' || currentRole === 'Structurer') && structure.status === 'Draft';
  const canApprove =
    (currentRole === 'Credit Analyst' || currentRole === 'Risk Officer' || currentRole === 'Auditor') &&
    structure.status === 'Submitted';

  const handleSubmitForReview = () => {
    const updated: FinancingStructure = {
      ...structure,
      status: 'Submitted'
    };
    onUpdateStructure(updated);
    onAddLog({
      id: `gov-${Date.now()}`,
      timestamp: new Date().toISOString(),
      role: currentRole,
      action: 'Submitted for Maker-Checker Approval',
      structureId: structure.id,
      details: `Structure ${structure.name} submitted for independent risk & credit review.`,
      hash: Math.random().toString(16).substring(2, 10) + Math.random().toString(16).substring(2, 10)
    });
  };

  const handleApprove = () => {
    const updated: FinancingStructure = {
      ...structure,
      status: 'Approved',
      approvedByRole: currentRole,
      approvalTimestamp: new Date().toISOString()
    };
    onUpdateStructure(updated);
    onAddLog({
      id: `gov-${Date.now()}`,
      timestamp: new Date().toISOString(),
      role: currentRole,
      action: 'Institutional Credit Approval Executed',
      structureId: structure.id,
      details: `Approved by ${currentRole}. Verified against capital adequacy and DSCR requirements.`,
      hash: Math.random().toString(16).substring(2, 10) + Math.random().toString(16).substring(2, 10)
    });
  };

  const handleReject = () => {
    if (!rejectionReason) return;
    const updated: FinancingStructure = {
      ...structure,
      status: 'Rejected'
    };
    onUpdateStructure(updated);
    onAddLog({
      id: `gov-${Date.now()}`,
      timestamp: new Date().toISOString(),
      role: currentRole,
      action: 'Structure Rejected by Checker',
      structureId: structure.id,
      details: `Rejected by ${currentRole}: ${rejectionReason}`,
      rationale: rejectionReason,
      hash: Math.random().toString(16).substring(2, 10) + Math.random().toString(16).substring(2, 10)
    });
    setShowRejectionInput(false);
    setRejectionReason('');
  };

  const handleExportTermSheetText = () => {
    const termSheetText = `
================================================================================
                    RHINOBANK SILICON FINANCE — DRAFT REVIEW TERM SHEET
                         CONFIDENTIAL INSTITUTIONAL DRAFT
================================================================================

TRANSACTION IDENTIFIERS:
Project: ${project.name}
Sponsor: ${project.sponsor}
Facility Location: ${project.facilityLocation}
Financing Structure: ${structure.name}
Model Version: ${structure.version}
Date of Generation: ${new Date().toUTCString()}
Status: ${structure.status.toUpperCase()} (Approved By: ${structure.approvedByRole || 'Pending Review'})

1. FACILITY SUMMARY & SOURCES OF CAPITAL:
${structure.components
  .map(
    (c, i) =>
      `  1.${i + 1} ${c.name} (${c.category})
      - Provider: ${c.provider}
      - Principal / Notional: $${c.principalOrNotional.toFixed(1)}M
      - Initial Cash Inflow: $${c.initialCashInflow.toFixed(1)}M
      - Spread: +${c.interestRateSpreadBps} bps over SOFR (Benchmark: 4.50%)
      - Tenor: ${c.tenorMonths} Months (${c.gracePeriodMonths} Mo Grace)
      - Pledged Collateral: ${c.collateralPledged} (Haircut: ${c.haircutPct}%)
      - Transferred Risks: ${c.transferredRisks.join('; ') || 'None'}
      - Retained Risks: ${c.retainedRisks.join('; ') || 'None'}
`
  )
  .join('\n')}

2. SOURCES AND USES CAPITAL RECONCILIATION:
- Project Total CapEx: $${project.totalCapexRequired.toFixed(1)}M
- Cleanroom & Civil: $${(project.totalCapexRequired * 0.35).toFixed(1)}M
- Tool Procurement: $${(project.totalCapexRequired * 0.65).toFixed(1)}M
- Initial Working Capital & DSRA: $38.4M

3. KEY COVENANTS & GOVERNANCE:
- Minimum Historical DSCR: 1.25x
- Required Debt Service Reserve Account (DSRA): 6-Month Senior Debt Service
- Maker-Checker Validation: Certified by RhinoQuant Quantitative Audit

LEGAL DISCLAIMER:
This document is a synthetic financing review draft generated by RhinoBank Silicon Finance.
Live execution and legal eligibility require binding definitive documentation.
================================================================================
`;

    const blob = new Blob([termSheetText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `RhinoBank_TermSheet_${structure.version}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Governance & Audit</span>
            <span>·</span>
            <span>Maker-Checker Controls</span>
            <span>·</span>
            <span className="text-amber-400 font-mono">Role: {currentRole}</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            Governance, Maker-Checker Approvals & Draft Term Sheet
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowTermSheetModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded transition-colors"
          >
            <FileText className="w-3.5 h-3.5" /> Preview Term Sheet
          </button>
          <button
            onClick={handleExportTermSheetText}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded transition-colors"
          >
            <Download className="w-3.5 h-3.5" /> Download Review Pack
          </button>
        </div>
      </div>

      {/* Maker-Checker Workflow Card */}
      <div className="bg-[#10141d] p-4 rounded border border-slate-800 space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> Maker-Checker Approval Protocol
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Independent separation of origination and risk verification under RhinoBank Credit Policy
            </p>
          </div>

          {/* Current Status Badge */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Approval State:</span>
            <span
              className={`px-2.5 py-1 rounded text-xs font-bold font-mono ${
                structure.status === 'Approved'
                  ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-700/80'
                  : structure.status === 'Submitted'
                  ? 'bg-amber-950/80 text-amber-300 border border-amber-700/80'
                  : structure.status === 'Rejected'
                  ? 'bg-rose-950/80 text-rose-400 border border-rose-700/80'
                  : 'bg-slate-900 text-slate-300 border border-slate-700'
              }`}
            >
              {structure.status.toUpperCase()}
            </span>
          </div>
        </div>

        <div className="p-3 bg-slate-900/60 rounded border border-slate-800/80 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
          <div>
            <span className="text-slate-300 font-medium block">
              Logged Workspace Role: <strong className="text-amber-300">{currentRole}</strong>
            </span>
            <span className="text-[11px] text-slate-400 block mt-0.5">
              {currentRole === 'Originator' || currentRole === 'Structurer'
                ? 'Authorized as Maker: Can assemble financing structures and submit for credit review.'
                : 'Authorized as Checker: Independent risk authority permitted to grant institutional approval.'}
            </span>
          </div>

          {/* Action buttons based on role & state */}
          <div className="flex items-center gap-2 shrink-0">
            {canSubmit && (
              <button
                onClick={handleSubmitForReview}
                className="px-3 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded transition-colors"
              >
                Submit for Credit Review
              </button>
            )}

            {canApprove && (
              <>
                <button
                  onClick={handleApprove}
                  className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded transition-colors"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" /> Approve Structure
                </button>
                <button
                  onClick={() => setShowRejectionInput(true)}
                  className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-rose-700 hover:bg-rose-600 rounded transition-colors"
                >
                  <XCircle className="w-3.5 h-3.5" /> Reject Structure
                </button>
              </>
            )}

            {!canSubmit && !canApprove && (
              <span className="text-[11px] text-slate-400 font-mono italic">
                {structure.status === 'Approved'
                  ? `Approved by ${structure.approvedByRole || 'Credit Committee'}`
                  : structure.status === 'Submitted'
                  ? 'Awaiting Checker Approval'
                  : 'No action required'}
              </span>
            )}
          </div>
        </div>

        {/* Rejection input prompt */}
        {showRejectionInput && (
          <div className="p-3 bg-rose-950/30 border border-rose-800/80 rounded space-y-2 text-xs">
            <label className="text-rose-200 font-semibold block">
              Specify Material Reason for Rejection:
            </label>
            <input
              type="text"
              value={rejectionReason}
              onChange={e => setRejectionReason(e.target.value)}
              placeholder="e.g. Inadequate DSCR cushion under stress or excessive customer concentration."
              className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowRejectionInput(false)}
                className="px-2.5 py-1 text-slate-400 hover:text-slate-200"
              >
                Cancel
              </button>
              <button
                onClick={handleReject}
                className="px-3 py-1 text-xs font-semibold text-white bg-rose-700 rounded hover:bg-rose-600"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Pricing Overrides Log */}
      <div className="bg-[#10141d] rounded border border-slate-800 overflow-hidden">
        <div className="p-3.5 bg-slate-900/80 border-b border-slate-800 flex justify-between items-center">
          <div>
            <h3 className="text-sm font-semibold text-slate-200">
              Pricing Overrides & Parameter Adjustments Log
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Every discretionary deviation from standard model spreads or haircuts requires documented justification
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {pricingOverrides.length} Logged Overrides
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0b0e14] text-slate-400 uppercase font-mono text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">Role</th>
                <th className="py-2.5 px-3">Parameter Field</th>
                <th className="py-2.5 px-3 text-right">Original Value</th>
                <th className="py-2.5 px-3 text-right">Override Value</th>
                <th className="py-2.5 px-3">Mandatory Justification</th>
                <th className="py-2.5 px-3">Audit Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {pricingOverrides.map(ovr => (
                <tr key={ovr.id} className="hover:bg-slate-900/40">
                  <td className="py-2 px-3 text-slate-400">{ovr.timestamp.split('T')[0]}</td>
                  <td className="py-2 px-3 font-sans text-amber-300 font-semibold">{ovr.authorRole}</td>
                  <td className="py-2 px-3 font-sans text-slate-200">{ovr.field}</td>
                  <td className="py-2 px-3 text-right text-slate-400 tabular-nums">{ovr.originalValue}</td>
                  <td className="py-2 px-3 text-right text-emerald-400 font-bold tabular-nums">{ovr.overrideValue}</td>
                  <td className="py-2 px-3 font-sans text-slate-300 max-w-xs truncate">{ovr.justification}</td>
                  <td className="py-2 px-3 font-sans text-emerald-400 font-semibold">{ovr.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Transaction Cryptographic Audit Trail */}
      <div className="bg-[#10141d] rounded border border-slate-800 overflow-hidden">
        <div className="p-3.5 bg-slate-900/80 border-b border-slate-800 flex justify-between items-center">
          <div>
            <h3 className="text-sm font-semibold text-slate-200">
              Transaction Audit Trail & Hash Verification
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Immutable chronological record of model actions, submissions, and approvals
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {governanceLogs.length} Events
          </span>
        </div>

        <div className="divide-y divide-slate-800/60 text-xs">
          {governanceLogs.map(log => (
            <div key={log.id} className="p-3 hover:bg-slate-900/40 flex justify-between items-start gap-4">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-200">{log.action}</span>
                  <span className="text-[10px] text-amber-300 font-mono">[{log.role}]</span>
                </div>
                <p className="text-slate-400 text-[11px]">{log.details}</p>
                {log.rationale && (
                  <p className="text-rose-400 text-[11px] italic">Rationale: {log.rationale}</p>
                )}
              </div>
              <div className="text-right shrink-0 font-mono text-[11px] text-slate-400">
                <span className="block">{log.timestamp.split('T')[0]} {log.timestamp.split('T')[1]?.substring(0, 5)}</span>
                <span className="text-[10px] text-slate-400">Hash: {log.hash}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Term Sheet Modal Preview */}
      {showTermSheetModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-[#10141d] border border-slate-700 rounded-lg max-w-2xl w-full max-h-[85vh] flex flex-col justify-between overflow-hidden shadow-2xl">
            <div className="p-4 bg-slate-900 border-b border-slate-800 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-amber-400" /> Confidential Draft Term Sheet Preview
                </h3>
                <span className="text-[11px] text-slate-400 font-mono">
                  Review Draft · Not for Live Legal Execution
                </span>
              </div>
              <button
                onClick={() => setShowTermSheetModal(false)}
                className="text-slate-400 hover:text-slate-100 text-sm"
              >
                ✕
              </button>
            </div>

            <div className="p-5 overflow-y-auto font-mono text-xs text-slate-300 space-y-4 leading-relaxed">
              <div className="border-b border-slate-800 pb-3">
                <div className="font-bold text-slate-100 text-sm">RHINOBANK SILICON FINANCE TERM SHEET</div>
                <div className="text-slate-400 text-[11px]">Transaction: {project.name}</div>
                <div className="text-slate-400 text-[11px]">Sponsor: {project.sponsor}</div>
                <div className="text-amber-400 text-[11px]">Structure: {structure.name} ({structure.version})</div>
              </div>

              <div>
                <div className="text-amber-300 font-bold mb-1">1. FINANCING TRANCHES & INSTRUMENTS:</div>
                {structure.components.map((c, i) => (
                  <div key={c.id} className="pl-3 py-1 border-l-2 border-slate-700 my-1 text-[11px]">
                    <div className="font-bold text-slate-200">
                      1.{i + 1} {c.name} — ${c.principalOrNotional}M ({c.category})
                    </div>
                    <div>Provider: {c.provider} · Tenor: {c.tenorMonths} Mo · Priority Tier {c.priority}</div>
                    <div>Pricing: SOFR + {c.interestRateSpreadBps} bps · Upfront Fee: {c.upfrontFeePct}%</div>
                    <div>Collateral: {c.collateralPledged} (Haircut: {c.haircutPct}%)</div>
                  </div>
                ))}
              </div>

              <div>
                <div className="text-amber-300 font-bold mb-1">2. RISK ALLOCATION & RETENTION:</div>
                <div className="text-[11px] space-y-1">
                  <div>• Yield & Fab Ramp Risk: Retained by Manufacturer.</div>
                  <div>• Sovereign Guarantee: 50% loss-sharing protection on Class A senior notes.</div>
                  <div>• Interest Rate Risk: Fixed via bilateral SOFR swap overlay.</div>
                </div>
              </div>

              <div className="p-3 bg-slate-900 rounded border border-slate-800 text-[10px] text-slate-400">
                <strong>LEGAL NOTICE: </strong> This generated draft is an indicative non-binding term sheet for institutional credit structuring. Definitive documentation subject to formal investment committee sign-off.
              </div>
            </div>

            <div className="p-3 bg-slate-900 border-t border-slate-800 flex justify-end gap-3">
              <button
                onClick={() => setShowTermSheetModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200"
              >
                Close Preview
              </button>
              <button
                onClick={handleExportTermSheetText}
                className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 rounded hover:bg-amber-300"
              >
                Download Term Sheet TXT
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
