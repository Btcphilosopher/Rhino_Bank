/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Traceable Cash Flow Waterfall View
 */

import React, { useState } from 'react';
import { CashFlowPeriod } from '../../types';
import { CashFlowPeriodChart } from '../ui/ChartComponents';
import { Coins, Filter, Download } from 'lucide-react';

interface CashFlowWaterfallViewProps {
  periods: CashFlowPeriod[];
  currency: string;
}

export const CashFlowWaterfallView: React.FC<CashFlowWaterfallViewProps> = ({
  periods,
  currency
}) => {
  const [filterQuarter, setFilterQuarter] = useState<'All' | 'Y1' | 'Y2' | 'Y3'>('All');
  const currSymbol = currency === 'USD' ? '$' : currency === 'EUR' ? '€' : currency === 'JPY' ? '¥' : 'NT$';

  const filteredPeriods = periods.filter(p => {
    if (filterQuarter === 'Y1') return p.periodMonth <= 12;
    if (filterQuarter === 'Y2') return p.periodMonth > 12 && p.periodMonth <= 24;
    if (filterQuarter === 'Y3') return p.periodMonth > 24 && p.periodMonth <= 36;
    return true;
  });

  const handleExportCSV = () => {
    const headers = [
      'Month',
      'WaferStarts',
      'CompletedWafers',
      'GoodPackagedUnits',
      'NetInvoicedUSD_M',
      'CashCollectionsUSD_M',
      'ManufacturingCostUSD_M',
      'EBITDA_USD_M',
      'CapExPaymentsUSD_M',
      'SeniorDebtServiceUSD_M',
      'MezzDebtServiceUSD_M',
      'TotalFinancingOutflowUSD_M',
      'EndingCashBalanceUSD_M',
      'DSCR'
    ];

    const rows = periods.map(p => [
      p.periodMonth,
      p.waferStarts,
      p.completedWafers,
      p.goodPackagedUnits,
      p.netInvoicedUSD.toFixed(3),
      p.cashCollectionsUSD.toFixed(3),
      p.totalManufacturingCostUSD.toFixed(3),
      p.ebitdaUSD.toFixed(3),
      p.capexPaymentsUSD.toFixed(3),
      (p.seniorInterestUSD + p.seniorPrincipalUSD).toFixed(3),
      (p.mezzanineInterestUSD + p.mezzaninePrincipalUSD).toFixed(3),
      p.totalFinancingOutflowUSD.toFixed(3),
      p.endingCashBalanceUSD.toFixed(3),
      p.dscr.toFixed(2)
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `RhinoBank_CashFlow_Waterfall_36Mo.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Accounting Waterfall</span>
            <span>·</span>
            <span>Priority of Payments</span>
            <span>·</span>
            <span className="text-amber-400 font-mono">36-Month Horizon</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            Traceable Cash Flow Waterfall & Priority Schedules
          </h1>
        </div>

        <div className="flex items-center gap-3">
          {/* Quarter filter buttons */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded p-1 text-xs">
            {(['All', 'Y1', 'Y2', 'Y3'] as const).map(q => (
              <button
                key={q}
                onClick={() => setFilterQuarter(q)}
                className={`px-2.5 py-1 rounded text-xs transition-colors ${
                  filterQuarter === q
                    ? 'bg-amber-400 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {q === 'All' ? 'Full 36 Mo' : `Year ${q.replace('Y', '')}`}
              </button>
            ))}
          </div>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded transition-colors"
          >
            <Download className="w-3.5 h-3.5" /> Export CSV
          </button>
        </div>
      </div>

      {/* Waterfall Trajectory Visual Chart */}
      <div className="bg-[#10141d] p-4 rounded border border-slate-800">
        <CashFlowPeriodChart periods={periods} />
      </div>

      {/* High-Density Waterfall Table */}
      <div className="bg-[#10141d] rounded border border-slate-800 overflow-hidden">
        <div className="p-3.5 bg-slate-900/80 border-b border-slate-800 flex justify-between items-center">
          <div>
            <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <Coins className="w-4 h-4 text-amber-400" /> Contractual Cash Waterfall Ledger
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Collections → Manufacturing Costs → EBITDA → Senior Debt → Mezzanine → Reserve Fund → Sponsor Equity
            </p>
          </div>
          <span className="text-xs font-mono text-slate-300">
            Showing {filteredPeriods.length} Periods ({filterQuarter})
          </span>
        </div>

        <div className="overflow-x-auto max-h-[460px]">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0b0e14] text-slate-400 uppercase font-mono text-[10px] tracking-wider sticky top-0 border-b border-slate-800 z-10">
              <tr>
                <th className="py-2.5 px-3">Period</th>
                <th className="py-2.5 px-3 text-right">Collections ({currSymbol}M)</th>
                <th className="py-2.5 px-3 text-right">Mfg Costs</th>
                <th className="py-2.5 px-3 text-right">EBITDA</th>
                <th className="py-2.5 px-3 text-right">CapEx Payments</th>
                <th className="py-2.5 px-3 text-right">Senior Svc</th>
                <th className="py-2.5 px-3 text-right">Mezz Svc</th>
                <th className="py-2.5 px-3 text-right">Reserve Replen.</th>
                <th className="py-2.5 px-3 text-right">Equity Distrib.</th>
                <th className="py-2.5 px-3 text-right">Ending Cash</th>
                <th className="py-2.5 px-3 text-right">DSCR</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filteredPeriods.map(p => (
                <tr key={p.periodMonth} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-2 px-3 text-slate-300 font-sans">
                    M{p.periodMonth}
                  </td>
                  <td className="py-2 px-3 text-right font-medium text-emerald-400 tabular-nums">
                    {currSymbol}{p.cashCollectionsUSD.toFixed(2)}M
                  </td>
                  <td className="py-2 px-3 text-right text-slate-400 tabular-nums">
                    ({currSymbol}{p.totalManufacturingCostUSD.toFixed(2)}M)
                  </td>
                  <td
                    className={`py-2 px-3 text-right font-semibold tabular-nums ${
                      p.ebitdaUSD >= 0 ? 'text-slate-200' : 'text-rose-400'
                    }`}
                  >
                    {currSymbol}{p.ebitdaUSD.toFixed(2)}M
                  </td>
                  <td className="py-2 px-3 text-right text-amber-400 tabular-nums">
                    {p.capexPaymentsUSD > 0 ? `(${currSymbol}${p.capexPaymentsUSD.toFixed(1)}M)` : '—'}
                  </td>
                  <td className="py-2 px-3 text-right text-slate-300 tabular-nums">
                    {p.seniorInterestUSD + p.seniorPrincipalUSD > 0
                      ? `${currSymbol}${(p.seniorInterestUSD + p.seniorPrincipalUSD).toFixed(2)}M`
                      : '—'}
                  </td>
                  <td className="py-2 px-3 text-right text-purple-400 tabular-nums">
                    {p.mezzanineInterestUSD + p.mezzaninePrincipalUSD > 0
                      ? `${currSymbol}${(p.mezzanineInterestUSD + p.mezzaninePrincipalUSD).toFixed(2)}M`
                      : '—'}
                  </td>
                  <td className="py-2 px-3 text-right text-cyan-300 tabular-nums">
                    {p.reserveReplenishmentUSD > 0
                      ? `${currSymbol}${p.reserveReplenishmentUSD.toFixed(2)}M`
                      : '—'}
                  </td>
                  <td className="py-2 px-3 text-right text-amber-300 font-bold tabular-nums">
                    {p.firstLossEquityDistributionUSD > 0
                      ? `${currSymbol}${p.firstLossEquityDistributionUSD.toFixed(2)}M`
                      : '—'}
                  </td>
                  <td
                    className={`py-2 px-3 text-right font-bold tabular-nums ${
                      p.endingCashBalanceUSD >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {currSymbol}{p.endingCashBalanceUSD.toFixed(1)}M
                  </td>
                  <td
                    className={`py-2 px-3 text-right font-bold tabular-nums ${
                      p.dscr >= 1.35 ? 'text-emerald-400' : p.dscr >= 1.0 ? 'text-amber-400' : 'text-rose-400'
                    }`}
                  >
                    {p.dscr.toFixed(2)}x
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
