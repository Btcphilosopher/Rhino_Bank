/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Quantitative Risk & Monte Carlo Simulation View
 */

import React, { useState } from 'react';
import {
  MonteCarloSummary,
  StressScenario,
  SemiconductorProject,
  CustomerContract,
  FinancingStructure
} from '../../types';
import {
  runMonteCarloSimulation,
  simulateProjectCashFlows
} from '../../math/quantitativeEngine';
import {
  MonteCarloHistogramChart,
  TornadoSensitivityChart
} from '../ui/ChartComponents';
import { TrendingDown, Play, AlertTriangle, ShieldCheck, RefreshCw } from 'lucide-react';

interface RiskSimulationViewProps {
  monteCarlo: MonteCarloSummary;
  onUpdateMonteCarlo: (summary: MonteCarloSummary) => void;
  stressScenarios: StressScenario[];
  project: SemiconductorProject;
  contracts: CustomerContract[];
  structure: FinancingStructure;
  currency: string;
}

export const RiskSimulationView: React.FC<RiskSimulationViewProps> = ({
  monteCarlo,
  onUpdateMonteCarlo,
  stressScenarios,
  project,
  contracts,
  structure,
  currency
}) => {
  const [iterations, setIterations] = useState(monteCarlo.iterationCount || 1000);
  const [seed, setSeed] = useState(monteCarlo.randomSeed || 42);
  const [isRunning, setIsRunning] = useState(false);
  const [selectedStress, setSelectedStress] = useState<StressScenario | null>(null);
  const [stressResult, setStressResult] = useState<any>(null);

  const currSymbol = currency === 'USD' ? '$' : currency === 'EUR' ? '€' : currency === 'JPY' ? '¥' : 'NT$';

  const handleRunSimulation = () => {
    setIsRunning(true);
    setTimeout(() => {
      const summary = runMonteCarloSimulation(project, contracts, structure, iterations, seed);
      onUpdateMonteCarlo(summary);
      setIsRunning(false);
    }, 100);
  };

  const handleSelectStress = (scenario: StressScenario) => {
    setSelectedStress(scenario);
    const res = simulateProjectCashFlows(project, contracts, structure, {
      yieldMultiplier: 1.0 + scenario.yieldShockPct / 100,
      utilisationMultiplier: 1.0 + scenario.utilisationShockPct / 100,
      priceMultiplier: 1.0 + scenario.priceShockPct / 100,
      capexDelayMonths: scenario.delayMonths,
      customerDefaultRate: scenario.customerDefaultPct,
      sofrShockBps: scenario.interestRateShockBps
    });
    setStressResult(res);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>RhinoQuant Risk Engine</span>
            <span>·</span>
            <span>Correlated Cholesky Distributions</span>
            <span>·</span>
            <span className="text-amber-400 font-mono">Seed: {seed}</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            Reproducible Monte Carlo & Stress-Testing Workbench
          </h1>
        </div>

        {/* Simulation Execution Controls */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-xs bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 font-mono">
            <span className="text-slate-400">Paths:</span>
            <select
              value={iterations}
              onChange={e => setIterations(Number(e.target.value))}
              aria-label="Monte Carlo Paths"
              className="bg-transparent text-amber-300 font-bold focus:outline-none"
            >
              <option value="250" className="bg-slate-900">250</option>
              <option value="500" className="bg-slate-900">500</option>
              <option value="1000" className="bg-slate-900">1,000</option>
              <option value="1500" className="bg-slate-900">1,500</option>
            </select>
          </div>

          <div className="flex items-center gap-2 text-xs bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 font-mono">
            <span className="text-slate-400">Seed:</span>
            <input
              type="number"
              value={seed}
              onChange={e => setSeed(Number(e.target.value))}
              className="w-14 bg-transparent text-slate-200 font-bold focus:outline-none"
            />
          </div>

          <button
            onClick={handleRunSimulation}
            disabled={isRunning}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded transition-colors disabled:opacity-50"
          >
            {isRunning ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Play className="w-3.5 h-3.5 fill-current" />
            )}
            Run Monte Carlo
          </button>
        </div>
      </div>

      {/* Quantitative Risk Summary Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-[#10141d] p-3 rounded border border-slate-800">
          <span className="text-[11px] text-slate-400 block">Funding Shortfall Prob</span>
          <span
            className={`text-lg font-mono font-bold tabular-nums block mt-1 ${
              monteCarlo.fundingShortfallProbabilityPct <= 5.0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {monteCarlo.fundingShortfallProbabilityPct.toFixed(1)}%
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Cash &lt; $0 threshold</span>
        </div>

        <div className="bg-[#10141d] p-3 rounded border border-slate-800">
          <span className="text-[11px] text-slate-400 block">Debt Svc Shortfall Prob</span>
          <span
            className={`text-lg font-mono font-bold tabular-nums block mt-1 ${
              monteCarlo.debtServiceShortfallProbabilityPct <= 8.0 ? 'text-amber-300' : 'text-rose-400'
            }`}
          >
            {monteCarlo.debtServiceShortfallProbabilityPct.toFixed(1)}%
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">DSCR &lt; 1.00x breach</span>
        </div>

        <div className="bg-[#10141d] p-3 rounded border border-slate-800">
          <span className="text-[11px] text-slate-400 block">Expected Loss (EL)</span>
          <span className="text-lg font-mono font-bold text-slate-200 tabular-nums block mt-1">
            {monteCarlo.expectedLossBps} bps
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Senior: {monteCarlo.seniorExpectedLossBps} bps</span>
        </div>

        <div className="bg-[#10141d] p-3 rounded border border-slate-800">
          <span className="text-[11px] text-slate-400 block">Mezzanine Expected Loss</span>
          <span className="text-lg font-mono font-bold text-purple-300 tabular-nums block mt-1">
            {monteCarlo.mezzanineExpectedLossBps} bps
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Subordinated cushion</span>
        </div>

        <div className="bg-[#10141d] p-3 rounded border border-slate-800">
          <span className="text-[11px] text-slate-400 block">Liquidity-at-Risk (95%)</span>
          <span className="text-lg font-mono font-bold text-rose-400 tabular-nums block mt-1">
            {currSymbol}{monteCarlo.liquidityAtRisk95PctUSD.toFixed(1)}M
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">99% LaR: {currSymbol}{monteCarlo.liquidityAtRisk99PctUSD.toFixed(1)}M</span>
        </div>

        <div className="bg-[#10141d] p-3 rounded border border-slate-800">
          <span className="text-[11px] text-slate-400 block">MC Standard Error</span>
          <span className="text-lg font-mono font-bold text-slate-300 tabular-nums block mt-1">
            ±{currSymbol}{monteCarlo.monteCarloStandardErrorUSD.toFixed(2)}M
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">N = {monteCarlo.iterationCount} paths</span>
        </div>
      </div>

      {/* Distribution Chart & Tornado Chart Split */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Histogram of NPV Outcomes */}
        <div className="bg-[#10141d] p-4 rounded border border-slate-800 space-y-4">
          <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <TrendingDown className="w-4 h-4 text-amber-400" /> Correlated Outcome Distribution & Percentiles
          </h2>
          <MonteCarloHistogramChart
            buckets={monteCarlo.distributionBuckets}
            p5={monteCarlo.percentiles.p5}
            p50={monteCarlo.percentiles.p50}
            p95={monteCarlo.percentiles.p95}
            expectedLossBps={monteCarlo.expectedLossBps}
          />
          <div className="grid grid-cols-5 gap-2 text-center text-xs font-mono pt-1 border-t border-slate-800/80">
            <div className="p-1.5 bg-slate-900/60 rounded">
              <span className="text-[10px] text-slate-400 block">P5 (Downside)</span>
              <span className="text-rose-400 font-bold tabular-nums">${monteCarlo.percentiles.p5}M</span>
            </div>
            <div className="p-1.5 bg-slate-900/60 rounded">
              <span className="text-[10px] text-slate-400 block">P25</span>
              <span className="text-slate-300 font-bold tabular-nums">${monteCarlo.percentiles.p25}M</span>
            </div>
            <div className="p-1.5 bg-slate-900/60 rounded border border-amber-500/40">
              <span className="text-[10px] text-amber-400 block">P50 (Median)</span>
              <span className="text-amber-300 font-bold tabular-nums">${monteCarlo.percentiles.p50}M</span>
            </div>
            <div className="p-1.5 bg-slate-900/60 rounded">
              <span className="text-[10px] text-slate-400 block">P75</span>
              <span className="text-slate-300 font-bold tabular-nums">${monteCarlo.percentiles.p75}M</span>
            </div>
            <div className="p-1.5 bg-slate-900/60 rounded">
              <span className="text-[10px] text-slate-400 block">P95 (Upside)</span>
              <span className="text-emerald-400 font-bold tabular-nums">${monteCarlo.percentiles.p95}M</span>
            </div>
          </div>
        </div>

        {/* Tornado Sensitivity Chart */}
        <div className="bg-[#10141d] p-4 rounded border border-slate-800 space-y-4">
          <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" /> Parameter Sensitivity Tornado Analysis
          </h2>
          <p className="text-xs text-slate-400">
            One-at-a-time parameter shocks demonstrating marginal impact on 36-month Project NPV ($M):
          </p>
          <TornadoSensitivityChart sensitivities={monteCarlo.parameterSensitivities} />
        </div>
      </div>

      {/* Deterministic Stress Testing Suite */}
      <div className="bg-[#10141d] rounded border border-slate-800 p-4 space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-cyan-400" /> Deterministic Severe Semiconductor Stress Scenarios
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Select predefined catastrophic events to evaluate liquidity resilience, tranche losses, and covenant breaches:
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {stressScenarios.map(sc => (
            <button
              key={sc.id}
              onClick={() => handleSelectStress(sc)}
              className={`p-3 text-left rounded border transition-all ${
                selectedStress?.id === sc.id
                  ? 'bg-amber-950/30 border-amber-500/80 text-amber-200'
                  : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700'
              }`}
            >
              <span className="font-semibold text-xs block">{sc.name}</span>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                {sc.description}
              </p>
              <div className="mt-3 flex flex-wrap gap-1.5 text-[10px] font-mono text-slate-400">
                {sc.yieldShockPct !== 0 && <span>Yield: {sc.yieldShockPct}% · </span>}
                {sc.utilisationShockPct !== 0 && <span>Util: {sc.utilisationShockPct}% · </span>}
                {sc.delayMonths > 0 && <span>Delay: +{sc.delayMonths}mo · </span>}
                {sc.priceShockPct !== 0 && <span>ASP: {sc.priceShockPct}%</span>}
              </div>
            </button>
          ))}
        </div>

        {/* Stress Result Output Card */}
        {selectedStress && stressResult && (
          <div className="p-4 bg-slate-900/80 border border-slate-700 rounded space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-amber-300">
                Stress Outcome Evaluation: {selectedStress.name}
              </span>
              <span className="font-mono text-slate-400">
                Model: {structure.name}
              </span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-2.5 bg-slate-950/80 rounded border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-sans">Stressed Project NPV:</span>
                <span
                  className={`text-base font-bold tabular-nums block mt-0.5 ${
                    stressResult.metrics.projectNPVUSD >= 0 ? 'text-slate-100' : 'text-rose-400'
                  }`}
                >
                  {currSymbol}{stressResult.metrics.projectNPVUSD.toFixed(1)}M
                </span>
              </div>
              <div className="p-2.5 bg-slate-950/80 rounded border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-sans">Minimum DSCR:</span>
                <span
                  className={`text-base font-bold tabular-nums block mt-0.5 ${
                    stressResult.metrics.minDSCR >= 1.0 ? 'text-amber-300' : 'text-rose-400'
                  }`}
                >
                  {stressResult.metrics.minDSCR.toFixed(2)}x
                </span>
              </div>
              <div className="p-2.5 bg-slate-950/80 rounded border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-sans">Sponsor Stressed IRR:</span>
                <span className="text-base font-bold text-slate-200 tabular-nums block mt-0.5">
                  {stressResult.metrics.sponsorIRRPct.toFixed(1)}%
                </span>
              </div>
              <div className="p-2.5 bg-slate-950/80 rounded border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-sans">Senior Lender Loss:</span>
                <span className="text-base font-bold text-emerald-400 tabular-nums block mt-0.5">
                  {stressResult.metrics.seniorLenderIRRPct >= 3.5 ? 'Full Recovery (0 Loss)' : 'Partial Loss'}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
