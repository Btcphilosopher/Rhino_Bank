/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Financing Structure Builder & Sources & Uses Reconciler
 */

import React, { useState } from 'react';
import {
  FinancingStructure,
  FinancingComponent,
  SemiconductorProject,
  CustomerContract,
  ComponentType,
  InstrumentCategory
} from '../../types';
import { reconcileSourcesAndUses } from '../../math/quantitativeEngine';
import { SourcesAndUsesBar } from '../ui/ChartComponents';
import { Layers, Plus, CheckCircle, AlertTriangle, ShieldCheck, DollarSign } from 'lucide-react';

interface StructureBuilderViewProps {
  structure: FinancingStructure;
  onUpdateStructure: (updated: FinancingStructure) => void;
  project: SemiconductorProject;
  contracts: CustomerContract[];
}

export const StructureBuilderView: React.FC<StructureBuilderViewProps> = ({
  structure,
  onUpdateStructure,
  project,
  contracts
}) => {
  const [showAddComponentModal, setShowAddComponentModal] = useState(false);
  const [newComp, setNewComp] = useState<Partial<FinancingComponent>>({
    name: '',
    category: 'Funding',
    type: 'Structured Senior Notes',
    provider: 'RhinoBank Commercial Syndicate',
    principalOrNotional: 50.0,
    initialCashInflow: 50.0,
    interestRateSpreadBps: 225,
    benchmarkRatePct: 4.5,
    dayCount: 'Act/360',
    tenorMonths: 36,
    gracePeriodMonths: 6,
    amortisationType: 'Linear',
    upfrontFeePct: 1.0,
    commitmentFeePct: 0.35,
    collateralPledged: 'Equipment Secondary Charge',
    haircutPct: 30,
    priority: 1,
    retainedRisks: ['Yield ramp uncertainty'],
    transferredRisks: ['Credit default risk'],
    contingentObligations: 'DSCR covenant ≥ 1.25x'
  });

  const reconciliation = reconcileSourcesAndUses(project, contracts, structure);

  const handleAddComponent = () => {
    if (!newComp.name) return;
    const isFunding = newComp.category === 'Funding';
    const comp: FinancingComponent = {
      id: `comp-${Date.now()}`,
      name: newComp.name,
      category: (newComp.category as InstrumentCategory) || 'Funding',
      type: (newComp.type as ComponentType) || 'Structured Senior Notes',
      provider: newComp.provider || 'Institutional Syndicate',
      principalOrNotional: Number(newComp.principalOrNotional) || 10,
      initialCashInflow: isFunding ? Number(newComp.initialCashInflow || newComp.principalOrNotional) : 0,
      interestRateSpreadBps: Number(newComp.interestRateSpreadBps) || 200,
      benchmarkRatePct: Number(newComp.benchmarkRatePct) || 4.5,
      dayCount: 'Act/360',
      tenorMonths: Number(newComp.tenorMonths) || 36,
      gracePeriodMonths: Number(newComp.gracePeriodMonths) || 6,
      amortisationType: 'Linear',
      upfrontFeePct: Number(newComp.upfrontFeePct) || 1.0,
      commitmentFeePct: Number(newComp.commitmentFeePct) || 0.30,
      collateralPledged: newComp.collateralPledged || 'None',
      haircutPct: Number(newComp.haircutPct) || 25,
      priority: (newComp.priority as any) || (isFunding ? 1 : 4),
      retainedRisks: ['Process yield variability'],
      transferredRisks: ['Market risk'],
      contingentObligations: newComp.contingentObligations || 'Standard institutional covenants'
    };

    onUpdateStructure({
      ...structure,
      components: [...structure.components, comp],
      sourcesAndUsesValid: reconciliation.isValid
    });
    setShowAddComponentModal(false);
  };

  const handleRemoveComponent = (id: string) => {
    onUpdateStructure({
      ...structure,
      components: structure.components.filter(c => c.id !== id)
    });
  };

  const fundingComponents = structure.components.filter(c => c.category === 'Funding');
  const riskTransferComponents = structure.components.filter(c => c.category === 'Risk-Transfer');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Synthetic Structure Workbench</span>
            <span>·</span>
            <span className="text-amber-400 font-mono">{structure.version}</span>
            <span>·</span>
            <span
              className={`font-semibold ${
                reconciliation.isValid ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {reconciliation.isValid ? 'Fully Reconciled' : 'Reconciliation Required'}
            </span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            {structure.name}
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAddComponentModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded transition-colors"
          >
            <Plus className="w-3.5 h-3.5" /> Add Component Instrument
          </button>
        </div>
      </div>

      {/* Sources & Uses Reconciliation Banner */}
      <div className="bg-[#10141d] p-4 rounded border border-slate-800 space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <Layers className="w-4 h-4 text-amber-400" /> Sources and Uses Capital Reconciliation
          </h2>
          <div className="flex items-center gap-3 text-xs font-mono">
            <span>
              Total Sources:{' '}
              <strong className="text-emerald-400 tabular-nums">
                ${reconciliation.totalSourcesUSD.toFixed(1)}M
              </strong>
            </span>
            <span>·</span>
            <span>
              Total Uses:{' '}
              <strong className="text-amber-400 tabular-nums">
                ${reconciliation.totalUsesUSD.toFixed(1)}M
              </strong>
            </span>
          </div>
        </div>

        <SourcesAndUsesBar
          sources={reconciliation.sourcesBreakdown}
          uses={reconciliation.usesBreakdown}
          imbalanceUSD={reconciliation.imbalanceUSD}
        />

        {/* Validation Errors & Alerts */}
        {reconciliation.errors.length > 0 && (
          <div className="p-3 bg-rose-950/40 border border-rose-800/80 rounded text-xs text-rose-300 space-y-1">
            <div className="font-semibold flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" /> Structure Inconsistency Detected
            </div>
            {reconciliation.errors.map((err, idx) => (
              <div key={idx} className="text-[11px] text-rose-200 pl-5">
                • {err}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Distinction Section: Funding Instruments vs Risk-Transfer Overlays */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Funding Instruments (Provide Cash at Inception) */}
        <div className="bg-[#10141d] rounded border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="p-3.5 bg-slate-900/80 border-b border-slate-800 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-emerald-400" /> Funding Instruments (Upfront Cash)
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Debt, leases, notes, and equity that supply liquid funding for CapEx and working capital.
                </p>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-400 tabular-nums">
                ${fundingComponents.reduce((a, b) => a + b.initialCashInflow, 0).toFixed(1)}M
              </span>
            </div>

            <div className="divide-y divide-slate-800/70 p-2 space-y-2">
              {fundingComponents.map(comp => (
                <div key={comp.id} className="p-3 rounded bg-slate-900/50 space-y-2 text-xs">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-semibold text-slate-200 block">{comp.name}</span>
                      <span className="text-[11px] text-slate-400 font-mono">
                        Provider: {comp.provider} · Priority Tier {comp.priority}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-mono font-bold text-emerald-400 block tabular-nums">
                        ${comp.initialCashInflow.toFixed(1)}M
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        +{comp.interestRateSpreadBps} bps spread
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300 pt-1 border-t border-slate-800/60 font-mono">
                    <div>
                      <span className="text-slate-400 font-sans block text-[10px]">Pledged Collateral:</span>
                      <span className="truncate block">{comp.collateralPledged}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 font-sans block text-[10px]">Tenor & Grace:</span>
                      <span>
                        {comp.tenorMonths} Mo ({comp.gracePeriodMonths} Mo grace)
                      </span>
                    </div>
                  </div>

                  <div className="text-[11px] pt-1 text-slate-400">
                    <span className="text-slate-400 font-medium">Contingent Covenants: </span>
                    {comp.contingentObligations}
                  </div>

                  <div className="flex justify-end pt-1">
                    <button
                      onClick={() => handleRemoveComponent(comp.id)}
                      className="text-[10px] text-slate-400 hover:text-rose-400 transition-colors"
                    >
                      Delete Component
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Risk-Transfer Instruments & Overlays (No Upfront Cash) */}
        <div className="bg-[#10141d] rounded border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="p-3.5 bg-slate-900/80 border-b border-slate-800 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" /> Risk-Transfer Overlays (No Upfront Cash)
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Interest rate swaps, FX forwards, credit protection, and sovereign loss-sharing guarantees.
                </p>
              </div>
              <span className="text-xs font-mono font-bold text-cyan-400 tabular-nums">
                ${riskTransferComponents.reduce((a, b) => a + b.principalOrNotional, 0).toFixed(1)}M Notional
              </span>
            </div>

            <div className="divide-y divide-slate-800/70 p-2 space-y-2">
              {riskTransferComponents.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400">
                  No synthetic overlays configured. Structure remains unhedged against interest rate spikes, FX shifts, and sovereign risk.
                </div>
              ) : (
                riskTransferComponents.map(comp => (
                  <div key={comp.id} className="p-3 rounded bg-slate-900/50 space-y-2 text-xs">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="font-semibold text-slate-200 block">{comp.name}</span>
                        <span className="text-[11px] text-slate-400 font-mono">
                          Counterparty: {comp.provider}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-mono font-bold text-cyan-400 block tabular-nums">
                          ${comp.principalOrNotional.toFixed(1)}M Notional
                        </span>
                        <span className="text-[10px] text-amber-400 font-mono">
                          Upfront Cash: $0.0M
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300 pt-1 border-t border-slate-800/60 font-mono">
                      <div>
                        <span className="text-slate-400 font-sans block text-[10px]">Risk Transferred:</span>
                        <span className="text-emerald-400 font-sans truncate block">
                          {comp.transferredRisks.join(', ') || 'Market risk hedge'}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 font-sans block text-[10px]">Retained Risk / Basis:</span>
                        <span className="text-slate-400 font-sans truncate block">
                          {comp.retainedRisks.join(', ') || 'Residual basis'}
                        </span>
                      </div>
                    </div>

                    <div className="text-[11px] pt-1 text-slate-400">
                      <span className="text-slate-400 font-medium">Margin / Collateral Terms: </span>
                      {comp.contingentObligations}
                    </div>

                    <div className="flex justify-end pt-1">
                      <button
                        onClick={() => handleRemoveComponent(comp.id)}
                        className="text-[10px] text-slate-400 hover:text-rose-400 transition-colors"
                      >
                        Delete Component
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Add Component Modal */}
      {showAddComponentModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-[#121722] border border-slate-700 rounded-lg p-5 max-w-lg w-full space-y-4">
            <h3 className="text-sm font-bold text-slate-100">
              Add Synthetic Financing Component
            </h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Component Name</label>
                <input
                  type="text"
                  value={newComp.name}
                  onChange={e => setNewComp({ ...newComp, name: e.target.value })}
                  placeholder="e.g. Cleanroom Equipment Tranche C"
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Instrument Category</label>
                  <select
                    value={newComp.category}
                    onChange={e => {
                      const cat = e.target.value as InstrumentCategory;
                      setNewComp({
                        ...newComp,
                        category: cat,
                        initialCashInflow: cat === 'Funding' ? (newComp.principalOrNotional || 50) : 0
                      });
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
                  >
                    <option value="Funding">Funding Instrument (Provides Cash)</option>
                    <option value="Risk-Transfer">Risk-Transfer Overlay (Zero Cash)</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Component Type</label>
                  <select
                    value={newComp.type}
                    onChange={e => setNewComp({ ...newComp, type: e.target.value as ComponentType })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
                  >
                    <option value="Structured Senior Notes">Structured Senior Notes</option>
                    <option value="Equipment Loan">Equipment Loan</option>
                    <option value="Receivables Purchase (ABL)">Receivables Purchase (ABL)</option>
                    <option value="Inventory / WIP Borrowing Base">Inventory / WIP Borrowing Base</option>
                    <option value="Mezzanine Subordinated Debt">Mezzanine Subordinated Debt</option>
                    <option value="Sponsor First-Loss Equity">Sponsor First-Loss Equity</option>
                    <option value="Interest Rate Swap (Overlay)">Interest Rate Swap (Overlay)</option>
                    <option value="FX Forward (Overlay)">FX Forward (Overlay)</option>
                    <option value="Sovereign / Export Credit Guarantee (Overlay)">Sovereign Guarantee (Overlay)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Principal / Notional ($M)</label>
                  <input
                    type="number"
                    value={newComp.principalOrNotional}
                    onChange={e => setNewComp({ ...newComp, principalOrNotional: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Upfront Cash Inflow ($M)</label>
                  <input
                    type="number"
                    disabled={newComp.category === 'Risk-Transfer'}
                    value={newComp.category === 'Risk-Transfer' ? 0 : newComp.initialCashInflow}
                    onChange={e => setNewComp({ ...newComp, initialCashInflow: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 font-mono disabled:opacity-50"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Spread (bps over SOFR)</label>
                  <input
                    type="number"
                    value={newComp.interestRateSpreadBps}
                    onChange={e => setNewComp({ ...newComp, interestRateSpreadBps: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Tenor (Months)</label>
                  <input
                    type="number"
                    value={newComp.tenorMonths}
                    onChange={e => setNewComp({ ...newComp, tenorMonths: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Collateral Pledged / Reference Asset</label>
                <input
                  type="text"
                  value={newComp.collateralPledged}
                  onChange={e => setNewComp({ ...newComp, collateralPledged: e.target.value })}
                  placeholder="e.g. Specific EUV Tool or AR Receivables Pool"
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowAddComponentModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200"
              >
                Cancel
              </button>
              <button
                onClick={handleAddComponent}
                className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 rounded hover:bg-amber-300"
              >
                Save Instrument
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
