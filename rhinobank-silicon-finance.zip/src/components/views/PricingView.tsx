/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Pricing, DCF & Debt Schedules View
 */

import React, { useState } from 'react';
import { PricingMetrics, CashFlowPeriod, FinancingStructure } from '../../types';
import { BarChart3, AlertCircle, ShieldAlert, CheckCircle2 } from 'lucide-react';

interface PricingViewProps {
  metrics: PricingMetrics;
  periods: CashFlowPeriod[];
  structure: FinancingStructure;
  currency: string;
}

export const PricingView: React.FC<PricingViewProps> = ({
  metrics,
  periods,
  structure,
  currency
}) => {
  const [selectedValuationBasis, setSelectedValuationBasis] = useState<
    'Contractual cash flow' | 'Management scenario' | 'Credit estimate' | 'Market-calibrated value'
  >('Management scenario');

  const currSymbol = currency === 'USD' ? '$' : currency === 'EUR' ? '€' : currency === 'JPY' ? '¥' : 'NT$';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Quantitative Pricing</span>
            <span>·</span>
            <span>Act/360 Accrual</span>
            <span>·</span>
            <span className="text-amber-400 font-mono">SOFR Benchmark 4.50%</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            Financial Pricing, Investor Returns & Unit Cost Breakdown
          </h1>
        </div>

        {/* Valuation Basis Selector */}
        <div className="flex items-center gap-2 text-xs bg-slate-900 border border-slate-800 rounded p-1">
          <span className="text-slate-400 pl-2">Valuation Basis:</span>
          {(
            [
              'Contractual cash flow',
              'Management scenario',
              'Credit estimate',
              'Market-calibrated value'
            ] as const
          ).map(basis => (
            <button
              key={basis}
              onClick={() => setSelectedValuationBasis(basis)}
              className={`px-2.5 py-1 rounded text-xs transition-colors whitespace-nowrap ${
                selectedValuationBasis === basis
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {basis}
            </button>
          ))}
        </div>
      </div>

      {/* Primary KPI Ribbon */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-[#10141d] p-3 rounded border border-slate-800">
          <span className="text-[11px] text-slate-400 block">Project NPV</span>
          <span className="text-lg font-mono font-bold text-emerald-400 tabular-nums block mt-1">
            {currSymbol}{metrics.projectNPVUSD.toFixed(1)}M
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">@ {metrics.weightedAverageCostOfCapitalPct}% WACC</span>
        </div>

        <div className="bg-[#10141d] p-3 rounded border border-slate-800">
          <span className="text-[11px] text-slate-400 block">Sponsor Equity IRR</span>
          <span className="text-lg font-mono font-bold text-amber-300 tabular-nums block mt-1">
            {metrics.sponsorIRRPct.toFixed(1)}%
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Newton-Raphson solved</span>
        </div>

        <div className="bg-[#10141d] p-3 rounded border border-slate-800">
          <span className="text-[11px] text-slate-400 block">Senior Lender IRR</span>
          <span className="text-lg font-mono font-bold text-slate-200 tabular-nums block mt-1">
            {metrics.seniorLenderIRRPct.toFixed(1)}%
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">SOFR + Spread</span>
        </div>

        <div className="bg-[#10141d] p-3 rounded border border-slate-800">
          <span className="text-[11px] text-slate-400 block">Mezzanine Debt IRR</span>
          <span className="text-lg font-mono font-bold text-purple-300 tabular-nums block mt-1">
            {metrics.mezzanineIRRPct.toFixed(1)}%
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Subordinated coupon</span>
        </div>

        <div className="bg-[#10141d] p-3 rounded border border-slate-800">
          <span className="text-[11px] text-slate-400 block">Minimum DSCR</span>
          <span
            className={`text-lg font-mono font-bold tabular-nums block mt-1 ${
              metrics.minDSCR >= 1.25 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {metrics.minDSCR.toFixed(2)}x
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Avg: {metrics.avgDSCR.toFixed(2)}x · LLCR: {metrics.loanLifeCoverageRatio.toFixed(2)}x</span>
        </div>

        <div className="bg-[#10141d] p-3 rounded border border-slate-800">
          <span className="text-[11px] text-slate-400 block">Break-Even Utilisation</span>
          <span className="text-lg font-mono font-bold text-cyan-300 tabular-nums block mt-1">
            {metrics.breakEvenUtilisationPct}%
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">ASP {currSymbol}{metrics.breakEvenSellingPriceUSD}/unit</span>
        </div>
      </div>

      {/* IRR Multiple-Root Warning Banner (if triggered) */}
      {metrics.sponsorIRRWarning && (
        <div className="p-3 bg-amber-950/40 border border-amber-700/80 rounded text-xs text-amber-200 flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold block">Solver Notice on Investor Return:</span>
            <span>{metrics.sponsorIRRWarning}</span>
          </div>
        </div>
      )}

      {/* Delivered Semiconductor Unit Cost Dissection */}
      <div className="bg-[#10141d] p-4 rounded border border-slate-800 space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-emerald-400" /> Delivered Semiconductor Unit Cost Dissection
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Separating physical silicon manufacturing costs from capital financing expenses per packaged device
            </p>
          </div>
          <div className="text-right font-mono">
            <span className="text-[11px] text-slate-400 block">Total Delivered Cash Cost</span>
            <span className="text-base font-bold text-amber-400 tabular-nums">
              {currSymbol}{metrics.totalDeliveredCashCostUSD.toFixed(2)} / device
            </span>
          </div>
        </div>

        {/* 5-Segment Cost Decomposition Grid */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
          <div className="p-3 bg-slate-900/80 rounded border border-slate-800 space-y-1">
            <span className="text-slate-400 block text-[11px]">1. Physical Raw Cost</span>
            <span className="font-mono text-base font-bold text-slate-200 tabular-nums">
              {currSymbol}{metrics.physicalCostPerUnitUSD.toFixed(2)}
            </span>
            <span className="text-[10px] text-slate-400 block">
              Substrate, wafer start & raw materials
            </span>
          </div>

          <div className="p-3 bg-slate-900/80 rounded border border-slate-800 space-y-1">
            <span className="text-slate-400 block text-[11px]">2. Allocated Cleanroom Deprec.</span>
            <span className="font-mono text-base font-bold text-slate-200 tabular-nums">
              {currSymbol}{metrics.allocatedDepreciationPerUnitUSD.toFixed(2)}
            </span>
            <span className="text-[10px] text-slate-400 block">
              Cleanroom civil & HVAC write-down
            </span>
          </div>

          <div className="p-3 bg-slate-900/80 rounded border border-slate-800 space-y-1">
            <span className="text-slate-400 block text-[11px]">3. Incremental Cash Cost</span>
            <span className="font-mono text-base font-bold text-slate-200 tabular-nums">
              {currSymbol}{metrics.incrementalCashCostPerUnitUSD.toFixed(2)}
            </span>
            <span className="text-[10px] text-slate-400 block">
              Chemicals, gases, power, test handlers
            </span>
          </div>

          <div className="p-3 bg-slate-900/80 rounded border border-slate-800 space-y-1">
            <span className="text-slate-400 block text-[11px]">4. Financing Expense</span>
            <span className="font-mono text-base font-bold text-purple-400 tabular-nums">
              {currSymbol}{metrics.financingExpensePerUnitUSD.toFixed(2)}
            </span>
            <span className="text-[10px] text-purple-300 block">
              Senior & mezz interest + fees
            </span>
          </div>

          <div className="p-3 bg-slate-900/80 rounded border border-amber-600/60 bg-amber-950/20 space-y-1">
            <span className="text-amber-300 block text-[11px] font-semibold">5. Total Delivered Cost</span>
            <span className="font-mono text-base font-bold text-amber-400 tabular-nums">
              {currSymbol}{metrics.totalDeliveredCashCostUSD.toFixed(2)}
            </span>
            <span className="text-[10px] text-amber-200 block">
              Cash required per delivered unit
            </span>
          </div>
        </div>

        {/* Explanatory Callout */}
        <div className="p-3 bg-slate-900/50 rounded border border-slate-800 text-[11px] text-slate-400 leading-relaxed">
          <strong className="text-slate-300">Analytical Clarity: </strong>
          Financing cannot reduce the physical energy, silicon, or cleanroom materials needed to manufacture a chiplet. However, synthetic structuring redistributes the timing of cash obligations, isolates equipment residual value, and reduces the financing expense component from {currSymbol}14.80/unit under conventional loans down to {currSymbol}8.40/unit under the optimized SPV with synthetic overlays.
        </div>
      </div>

      {/* Debt Amortisation & Cash-Flow Schedule Table */}
      <div className="bg-[#10141d] rounded border border-slate-800 overflow-hidden">
        <div className="p-3.5 bg-slate-900/80 border-b border-slate-800 flex justify-between items-center">
          <div>
            <h3 className="text-sm font-semibold text-slate-200">
              Senior & Mezzanine Debt Amortisation Schedule
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Day-count: Act/360 · Monthly interest accruals, scheduled principal redemptions & coverage ratios
            </p>
          </div>
          <span className="text-xs font-mono text-slate-300">
            Tenor: 36 Months · Structure: {structure.name}
          </span>
        </div>

        <div className="overflow-x-auto max-h-80">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0b0e14] text-slate-400 uppercase font-mono text-[10px] tracking-wider sticky top-0 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Period</th>
                <th className="py-2.5 px-3 text-right">EBITDA ({currSymbol}M)</th>
                <th className="py-2.5 px-3 text-right">Senior Interest</th>
                <th className="py-2.5 px-3 text-right">Senior Principal</th>
                <th className="py-2.5 px-3 text-right">Mezz Interest</th>
                <th className="py-2.5 px-3 text-right">Total Debt Svc</th>
                <th className="py-2.5 px-3 text-right">DSCR</th>
                <th className="py-2.5 px-3 text-right">Ending Cash</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {periods.map(p => (
                <tr key={p.periodMonth} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-2 px-3 text-slate-300 font-sans">
                    Month {p.periodMonth}
                  </td>
                  <td
                    className={`py-2 px-3 text-right tabular-nums ${
                      p.ebitdaUSD >= 0 ? 'text-slate-200' : 'text-rose-400'
                    }`}
                  >
                    {currSymbol}{p.ebitdaUSD.toFixed(2)}M
                  </td>
                  <td className="py-2 px-3 text-right text-slate-400 tabular-nums">
                    {currSymbol}{p.seniorInterestUSD.toFixed(2)}M
                  </td>
                  <td className="py-2 px-3 text-right text-slate-400 tabular-nums">
                    {currSymbol}{p.seniorPrincipalUSD.toFixed(2)}M
                  </td>
                  <td className="py-2 px-3 text-right text-purple-400 tabular-nums">
                    {currSymbol}{p.mezzanineInterestUSD.toFixed(2)}M
                  </td>
                  <td className="py-2 px-3 text-right font-semibold text-slate-200 tabular-nums">
                    {currSymbol}{p.totalFinancingOutflowUSD.toFixed(2)}M
                  </td>
                  <td
                    className={`py-2 px-3 text-right font-bold tabular-nums ${
                      p.dscr >= 1.35 ? 'text-emerald-400' : p.dscr >= 1.0 ? 'text-amber-400' : 'text-rose-400'
                    }`}
                  >
                    {p.dscr.toFixed(2)}x
                  </td>
                  <td
                    className={`py-2 px-3 text-right font-bold tabular-nums ${
                      p.endingCashBalanceUSD >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {currSymbol}{p.endingCashBalanceUSD.toFixed(1)}M
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
