/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Projects & Semiconductor Manufacturing View
 */

import React, { useState } from 'react';
import { SemiconductorProject, ProjectType, EquipmentItem } from '../../types';
import { Cpu, Plus, Layers } from 'lucide-react';

interface ProjectsViewProps {
  project: SemiconductorProject;
  onUpdateProject: (updated: SemiconductorProject) => void;
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({ project, onUpdateProject }) => {
  const [showAddToolModal, setShowAddToolModal] = useState(false);
  const [newTool, setNewTool] = useState<Partial<EquipmentItem>>({
    name: '',
    vendor: '',
    category: 'Lithography',
    cost: 25.0,
    deliveryMonth: 4,
    qualificationMonth: 8,
    haircut: 0.25,
    maintenanceAnnualPct: 0.05,
    residualValuePct5Yr: 0.40
  });

  const projectTypes: ProjectType[] = [
    'Advanced Packaging (2.5D/3D TSV)',
    'New Green-field Fab',
    'Capacity Expansion',
    'Leading-Edge Logic (Sub-3nm)',
    'Memory Production (HBM3e/3D NAND)',
    'Specialty & Mature Node',
    'Fabless Capacity Reservation'
  ];

  const handleAddEquipment = () => {
    if (!newTool.name || !newTool.vendor) return;
    const tool: EquipmentItem = {
      id: `eq-${Date.now()}`,
      name: newTool.name,
      vendor: newTool.vendor,
      category: (newTool.category as any) || 'Lithography',
      cost: Number(newTool.cost) || 10,
      deliveryMonth: Number(newTool.deliveryMonth) || 3,
      qualificationMonth: Number(newTool.qualificationMonth) || 6,
      haircut: Number(newTool.haircut) || 0.25,
      maintenanceAnnualPct: Number(newTool.maintenanceAnnualPct) || 0.05,
      residualValuePct5Yr: Number(newTool.residualValuePct5Yr) || 0.35
    };

    const updatedTools = [...project.equipmentSchedule, tool];
    const newTotalCapex = updatedTools.reduce((a, b) => a + b.cost, 0) + 120.0;
    onUpdateProject({
      ...project,
      equipmentSchedule: updatedTools,
      totalCapexRequired: newTotalCapex
    });
    setShowAddToolModal(false);
  };

  const handleRemoveEquipment = (id: string) => {
    const updatedTools = project.equipmentSchedule.filter(t => t.id !== id);
    const newTotalCapex = updatedTools.reduce((a, b) => a + b.cost, 0) + 120.0;
    onUpdateProject({
      ...project,
      equipmentSchedule: updatedTools,
      totalCapexRequired: newTotalCapex
    });
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Project Repository</span>
            <span>·</span>
            <span>Semiconductor Assets</span>
            <span>·</span>
            <span className="text-amber-400 font-mono">ID: {project.id}</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            {project.name}
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-[11px] text-slate-400">Total Project CapEx</div>
            <div className="text-lg font-mono font-bold text-amber-400 tabular-nums">
              ${project.totalCapexRequired.toFixed(1)}M
            </div>
          </div>
          <button
            onClick={() => setShowAddToolModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded transition-colors"
          >
            <Plus className="w-3.5 h-3.5" /> Add Tool Schedule
          </button>
        </div>
      </div>

      {/* Fab Profile Card & Architecture Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 bg-[#10141d] p-4 rounded border border-slate-800 space-y-4">
          <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-amber-400" /> Fab Specification & Physical Parameters
          </h2>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            <div className="p-2.5 bg-slate-900/60 rounded border border-slate-800/80">
              <span className="text-slate-400 block text-[11px]">Sponsor Entity</span>
              <span className="font-semibold text-slate-200 truncate block mt-0.5">{project.sponsor}</span>
            </div>
            <div className="p-2.5 bg-slate-900/60 rounded border border-slate-800/80">
              <span className="text-slate-400 block text-[11px]">Facility Location</span>
              <span className="font-semibold text-slate-200 truncate block mt-0.5">{project.facilityLocation}</span>
            </div>
            <div className="p-2.5 bg-slate-900/60 rounded border border-slate-800/80">
              <span className="text-slate-400 block text-[11px]">Cleanroom Area</span>
              <span className="font-semibold font-mono text-slate-200 block mt-0.5">
                {project.cleanroomAreaSqM.toLocaleString()} m²
              </span>
            </div>
            <div className="p-2.5 bg-slate-900/60 rounded border border-slate-800/80">
              <span className="text-slate-400 block text-[11px]">Max Capacity / Month</span>
              <span className="font-semibold font-mono text-emerald-400 block mt-0.5">
                {project.maxWaferCapacityPerMonth.toLocaleString()} wafers
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs pt-1">
            <div className="p-2.5 bg-slate-900/60 rounded border border-slate-800/80">
              <span className="text-slate-400 block text-[11px]">Wafer Diameter</span>
              <span className="font-mono text-slate-200 block mt-0.5">{project.waferDiameterMm} mm (12-inch)</span>
            </div>
            <div className="p-2.5 bg-slate-900/60 rounded border border-slate-800/80">
              <span className="text-slate-400 block text-[11px]">Die Area</span>
              <span className="font-mono text-slate-200 block mt-0.5">{project.dieAreaSqMm} mm²</span>
            </div>
            <div className="p-2.5 bg-slate-900/60 rounded border border-slate-800/80">
              <span className="text-slate-400 block text-[11px]">Defect Density (D)</span>
              <span className="font-mono text-slate-200 block mt-0.5">{project.defectDensityPerSqCm} / cm²</span>
            </div>
            <div className="p-2.5 bg-slate-900/60 rounded border border-slate-800/80">
              <span className="text-slate-400 block text-[11px]">Fab Cycle Time</span>
              <span className="font-mono text-slate-200 block mt-0.5">{project.fabCycleTimeDays} days</span>
            </div>
          </div>

          {/* Project Model Selector */}
          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-400">Semiconductor Architecture Model:</span>
            <select
              value={project.projectType}
              onChange={e => onUpdateProject({ ...project, projectType: e.target.value as ProjectType })}
              aria-label="Semiconductor Architecture Model"
              className="bg-slate-900 text-amber-300 font-semibold border border-slate-700 rounded px-2.5 py-1 text-xs"
            >
              {projectTypes.map(pt => (
                <option key={pt} value={pt}>
                  {pt}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Business Model Distinction Explainer */}
        <div className="bg-[#10141d] p-4 rounded border border-slate-800 space-y-3 text-xs">
          <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-400" /> Business Model Separation
          </h2>
          <p className="text-slate-400 leading-relaxed text-[12px]">
            In the semiconductor value chain, asset ownership and risk exposure vary fundamentally by business model:
          </p>
          <div className="space-y-2 text-[11px]">
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
              <span className="font-semibold text-amber-300">OSAT / Advanced Packaging:</span>
              <p className="text-slate-400 mt-0.5">
                Bears equipment CapEx (hybrid bonders, dicing, TSV), substrate consumable costs, and assembly yield risk. Does not purchase raw poly-silicon.
              </p>
            </div>
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
              <span className="font-semibold text-emerald-300">Pure-Play Foundry (TSMC/GlobalFoundries):</span>
              <p className="text-slate-400 mt-0.5">
                Owns front-end litho cleanrooms ($15B+ CapEx), bears full wafer defect density and cleanroom power/water utility costs.
              </p>
            </div>
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
              <span className="font-semibold text-cyan-300">Fabless Design Firm (Nvidia/Apple):</span>
              <p className="text-slate-400 mt-0.5">
                Zero tool ownership. Capital needs focus on mask-set NRE, tape-outs, and customer prepayments to reserve foundry wafers.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Equipment Acquisition Schedule Table */}
      <div className="bg-[#10141d] rounded border border-slate-800 overflow-hidden">
        <div className="p-3.5 bg-slate-900/80 border-b border-slate-800 flex justify-between items-center">
          <div>
            <h2 className="text-sm font-semibold text-slate-200">
              Manufacturing Equipment Procurement & Milestone Timeline
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Scheduled tool arrivals, qualification periods, financing haircuts, and residual value models
            </p>
          </div>
          <span className="text-xs font-mono text-slate-300">
            {project.equipmentSchedule.length} Tools · $
            {project.equipmentSchedule.reduce((a, b) => a + b.cost, 0).toFixed(1)}M Total
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0b0e14] text-slate-400 uppercase font-mono text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Equipment Tool & Vendor</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3 text-right">Cost ($M)</th>
                <th className="py-2.5 px-3 text-center">Delivery (Mo)</th>
                <th className="py-2.5 px-3 text-center">Qual (Mo)</th>
                <th className="py-2.5 px-3 text-right">Haircut</th>
                <th className="py-2.5 px-3 text-right">Borrowing Base</th>
                <th className="py-2.5 px-3 text-right">5-Yr Residual</th>
                <th className="py-2.5 px-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {project.equipmentSchedule.map(eq => (
                <tr key={eq.id} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-2.5 px-3 font-sans">
                    <span className="font-medium text-slate-200 block">{eq.name}</span>
                    <span className="text-[11px] text-slate-400">Vendor: {eq.vendor}</span>
                  </td>
                  <td className="py-2.5 px-3 font-sans text-slate-400">
                    {eq.category}
                  </td>
                  <td className="py-2.5 px-3 text-right font-semibold text-amber-400 tabular-nums">
                    ${eq.cost.toFixed(1)}M
                  </td>
                  <td className="py-2.5 px-3 text-center text-slate-300">
                    Month {eq.deliveryMonth}
                  </td>
                  <td className="py-2.5 px-3 text-center text-emerald-400">
                    Month {eq.qualificationMonth}
                  </td>
                  <td className="py-2.5 px-3 text-right text-rose-400 tabular-nums">
                    {(eq.haircut * 100).toFixed(0)}%
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-200 tabular-nums font-semibold">
                    ${(eq.cost * (1 - eq.haircut)).toFixed(1)}M
                  </td>
                  <td className="py-2.5 px-3 text-right text-cyan-300 tabular-nums">
                    {(eq.residualValuePct5Yr * 100).toFixed(0)}%
                  </td>
                  <td className="py-2.5 px-3 text-center font-sans">
                    <button
                      onClick={() => handleRemoveEquipment(eq.id)}
                      className="text-slate-400 hover:text-rose-400 transition-colors text-[11px]"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Equipment Modal */}
      {showAddToolModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-[#121722] border border-slate-700 rounded-lg p-5 max-w-md w-full space-y-4">
            <h3 className="text-sm font-bold text-slate-100">
              Add Tool Procurement Schedule
            </h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Tool Description</label>
                <input
                  type="text"
                  value={newTool.name}
                  onChange={e => setNewTool({ ...newTool, name: e.target.value })}
                  placeholder="e.g. Scanning Electron Microscope"
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Equipment Vendor</label>
                  <input
                    type="text"
                    value={newTool.vendor}
                    onChange={e => setNewTool({ ...newTool, vendor: e.target.value })}
                    placeholder="e.g. Applied Materials"
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Cost ($ Millions)</label>
                  <input
                    type="number"
                    value={newTool.cost}
                    onChange={e => setNewTool({ ...newTool, cost: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Delivery Month</label>
                  <input
                    type="number"
                    value={newTool.deliveryMonth}
                    onChange={e => setNewTool({ ...newTool, deliveryMonth: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Qualification Month</label>
                  <input
                    type="number"
                    value={newTool.qualificationMonth}
                    onChange={e => setNewTool({ ...newTool, qualificationMonth: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 font-mono"
                  />
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowAddToolModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200"
              >
                Cancel
              </button>
              <button
                onClick={handleAddEquipment}
                className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 rounded hover:bg-amber-300"
              >
                Save Tool
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
