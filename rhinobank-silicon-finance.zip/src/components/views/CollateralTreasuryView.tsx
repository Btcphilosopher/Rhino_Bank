/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Collateral Pool & Treasury Management View
 */

import React, { useState } from 'react';
import { CollateralAsset, FinancingStructure } from '../../types';
import { ShieldCheck, Layers, AlertCircle, DollarSign } from 'lucide-react';

interface CollateralTreasuryViewProps {
  collateral: CollateralAsset[];
  structure: FinancingStructure;
  currency: string;
}

export const CollateralTreasuryView: React.FC<CollateralTreasuryViewProps> = ({
  collateral,
  structure,
  currency
}) => {
  const [sofrMtmShiftBps, setSofrMtmShiftBps] = useState(150);
  const currSymbol = currency === 'USD' ? '$' : currency === 'EUR' ? '€' : currency === 'JPY' ? '¥' : 'NT$';

  const totalGrossValue = collateral.reduce((a, b) => a + b.grossNominalValueUSD, 0);
  const totalNetBorrowingBase = collateral.reduce((a, b) => a + b.netBorrowingBaseValueUSD, 0);

  // Derivative MTM & Variation Margin Sensitivity Calculation:
  // For a $220M notional swap, a +150 bps rise generates positive MTM of +$3.3M/year;
  // A -150 bps drop requires a collateral variation margin call of $3.3M.
  const swapNotional = 220.0;
  const csaMarginThresholdUSD = 5.0; // $5M uncollateralized threshold
  const mtmExposure = (swapNotional * (sofrMtmShiftBps / 10000) * 1.5);
  const netMarginCallUSD = Math.max(0, -mtmExposure - csaMarginThresholdUSD);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Treasury & Risk Management</span>
            <span>·</span>
            <span>Perfected Security Interest</span>
            <span>·</span>
            <span className="text-emerald-400 font-mono">Borrowing Base Monitor</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            Collateral Pool, Haircuts & Treasury Liquidity Demands
          </h1>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="bg-[#10141d] px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Gross Asset Pool</span>
            <span className="text-slate-200 font-bold tabular-nums">
              {currSymbol}{totalGrossValue.toFixed(1)}M
            </span>
          </div>
          <div className="bg-[#10141d] px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Net Borrowing Base</span>
            <span className="text-emerald-400 font-bold tabular-nums">
              {currSymbol}{totalNetBorrowingBase.toFixed(1)}M
            </span>
          </div>
        </div>
      </div>

      {/* Collateral Pool Table */}
      <div className="bg-[#10141d] rounded border border-slate-800 overflow-hidden">
        <div className="p-3.5 bg-slate-900/80 border-b border-slate-800 flex justify-between items-center">
          <div>
            <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> Perfected Asset Security & Borrowing Base Availability
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Eligible asset classes, regulatory haircuts, valuation dates, and lien encumbrances
            </p>
          </div>
          <span className="text-xs font-mono text-slate-300">
            {collateral.length} Collateral Assets
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0b0e14] text-slate-400 uppercase font-mono text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Asset Description</th>
                <th className="py-2.5 px-3">Collateral Type</th>
                <th className="py-2.5 px-3 text-right">Gross Valuation</th>
                <th className="py-2.5 px-3 text-right">Haircut</th>
                <th className="py-2.5 px-3 text-right">Net Borrowing Base</th>
                <th className="py-2.5 px-3">Lien Status</th>
                <th className="py-2.5 px-3 text-right">Concentration Limit</th>
                <th className="py-2.5 px-3 text-center">Valuation Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {collateral.map(asset => (
                <tr key={asset.id} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-2.5 px-3 font-sans">
                    <span className="font-medium text-slate-200 block">{asset.name}</span>
                    <span className="text-[11px] text-slate-400">ID: {asset.id}</span>
                  </td>
                  <td className="py-2.5 px-3 font-sans text-slate-400">
                    {asset.assetType}
                  </td>
                  <td className="py-2.5 px-3 text-right font-semibold text-slate-200 tabular-nums">
                    {currSymbol}{asset.grossNominalValueUSD.toFixed(1)}M
                  </td>
                  <td className="py-2.5 px-3 text-right text-rose-400 tabular-nums font-bold">
                    {asset.haircutPct}%
                  </td>
                  <td className="py-2.5 px-3 text-right text-emerald-400 font-bold tabular-nums">
                    {currSymbol}{asset.netBorrowingBaseValueUSD.toFixed(1)}M
                  </td>
                  <td className="py-2.5 px-3 font-sans">
                    <span
                      className={`text-[11px] font-semibold ${
                        asset.encumbranceStatus === 'Pledged Senior'
                          ? 'text-amber-400'
                          : 'text-purple-300'
                      }`}
                    >
                      {asset.encumbranceStatus}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-300 tabular-nums">
                    Max {asset.concentrationLimitPct}%
                  </td>
                  <td className="py-2.5 px-3 text-center text-slate-400">
                    {asset.valuationDate}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Derivative Margin Demand Simulator (Two-Sided Liquidity Risk) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 bg-[#10141d] p-4 rounded border border-slate-800 space-y-4">
          <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-amber-400" /> Bilateral CSA Derivative Margin Call Simulator
          </h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            A derivative overlay that eliminates market interest rate risk may create unexpected cash demands if rates shift against the position. Under standard ISDA/CSA credit support annexes, mark-to-market losses beyond the uncollateralized threshold ($5.0M) require instantaneous cash variation margin.
          </p>

          <div className="p-3 bg-slate-900/80 rounded border border-slate-800 space-y-2 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-slate-300 font-medium">SOFR Forward Curve Shift Scenario:</span>
              <span
                className={`font-mono font-bold ${
                  sofrMtmShiftBps >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {sofrMtmShiftBps >= 0 ? '+' : ''}{sofrMtmShiftBps} bps
              </span>
            </div>
            <input
              type="range"
              min="-300"
              max="300"
              step="25"
              value={sofrMtmShiftBps}
              onChange={e => setSofrMtmShiftBps(Number(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />
            <div className="flex justify-between text-[11px] text-slate-400 font-mono">
              <span>-300 bps (Rates Drop)</span>
              <span>0 bps (No Shift)</span>
              <span>+300 bps (Rates Surge)</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 text-xs font-mono">
            <div className="p-2.5 bg-slate-900/60 rounded border border-slate-800">
              <span className="text-[10px] text-slate-400 block font-sans">Swap Mark-to-Market:</span>
              <span
                className={`text-base font-bold tabular-nums block mt-0.5 ${
                  mtmExposure >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {mtmExposure >= 0 ? '+' : ''}{currSymbol}{mtmExposure.toFixed(2)}M
              </span>
            </div>

            <div className="p-2.5 bg-slate-900/60 rounded border border-slate-800">
              <span className="text-[10px] text-slate-400 block font-sans">CSA Margin Call Required:</span>
              <span
                className={`text-base font-bold tabular-nums block mt-0.5 ${
                  netMarginCallUSD > 0 ? 'text-rose-400' : 'text-slate-300'
                }`}
              >
                {currSymbol}{netMarginCallUSD.toFixed(2)}M
              </span>
            </div>

            <div className="p-2.5 bg-slate-900/60 rounded border border-slate-800">
              <span className="text-[10px] text-slate-400 block font-sans">Treasury Headroom Post-Call:</span>
              <span className="text-base font-bold text-amber-300 tabular-nums block mt-0.5">
                {currSymbol}{Math.max(0, 32.5 - netMarginCallUSD).toFixed(1)}M
              </span>
            </div>
          </div>
        </div>

        {/* Operational vs Legal Enforceability Notice */}
        <div className="bg-[#10141d] p-4 rounded border border-slate-800 space-y-3 text-xs">
          <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-cyan-400" /> Operational vs Legal Boundaries
          </h2>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            The platform models operational collateral availability based on advance formulas and hair-cut percentages. This calculation is strictly distinct from legal perfection or cross-border insolvency enforceability.
          </p>
          <div className="p-2.5 rounded bg-slate-900 border border-slate-800 text-[11px] space-y-1.5 font-mono">
            <div className="text-slate-300">
              <strong className="text-amber-400">Jurisdiction: </strong> Taiwan ROC Secured Transactions Act & UCC Article 9.
            </div>
            <div className="text-slate-300">
              <strong className="text-amber-400">Tool Movability: </strong> ASML cleanroom tools require de-installation notice of 120 days.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
