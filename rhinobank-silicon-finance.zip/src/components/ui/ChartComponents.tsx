/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoBank Silicon Finance — Institutional SVG Chart Components
 * High-density obsidian financial terminal charts
 */

import React, { useState } from 'react';

// ============================================================================
// 1. SOURCES AND USES PROPORTIONAL BAR
// ============================================================================

interface SourcesAndUsesBarProps {
  sources: { label: string; amountUSD: number }[];
  uses: { label: string; amountUSD: number }[];
  imbalanceUSD: number;
}

export const SourcesAndUsesBar: React.FC<SourcesAndUsesBarProps> = ({
  sources,
  uses,
  imbalanceUSD
}) => {
  const totalSources = sources.reduce((a, b) => a + b.amountUSD, 0);
  const totalUses = uses.reduce((a, b) => a + b.amountUSD, 0);
  const maxVal = Math.max(totalSources, totalUses, 1);

  const colors = [
    '#d4af37', // Gold
    '#059669', // Emerald
    '#2563eb', // Blue
    '#7c3aed', // Purple
    '#0891b2', // Cyan
    '#d97706'  // Amber
  ];

  return (
    <div className="space-y-4">
      {/* Sources Bar */}
      <div>
        <div className="flex justify-between items-center text-xs mb-1.5 font-medium">
          <span className="text-slate-300">Total Sources of Funding</span>
          <span className="font-mono tabular-nums text-emerald-400 font-semibold">
            ${totalSources.toFixed(1)}M
          </span>
        </div>
        <div className="h-6 w-full bg-slate-900 rounded overflow-hidden flex border border-slate-800">
          {sources.map((s, idx) => {
            const widthPct = (s.amountUSD / maxVal) * 100;
            return (
              <div
                key={idx}
                style={{ width: `${widthPct}%`, backgroundColor: colors[idx % colors.length] }}
                className="h-full relative group transition-all"
                title={`${s.label}: $${s.amountUSD.toFixed(1)}M (${((s.amountUSD / totalSources) * 100).toFixed(1)}%)`}
              />
            );
          })}
        </div>
        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-[11px] text-slate-400">
          {sources.map((s, idx) => (
            <div key={idx} className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm inline-block shrink-0" style={{ backgroundColor: colors[idx % colors.length] }} />
              <span className="truncate max-w-[180px]">{s.label}</span>
              <span className="font-mono tabular-nums text-slate-300 font-medium">
                ${s.amountUSD.toFixed(1)}M
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Uses Bar */}
      <div>
        <div className="flex justify-between items-center text-xs mb-1.5 font-medium">
          <span className="text-slate-300">Total Capital Uses & Reserves</span>
          <span className="font-mono tabular-nums text-amber-400 font-semibold">
            ${totalUses.toFixed(1)}M
          </span>
        </div>
        <div className="h-6 w-full bg-slate-900 rounded overflow-hidden flex border border-slate-800">
          {uses.map((u, idx) => {
            const widthPct = (u.amountUSD / maxVal) * 100;
            const useColors = ['#0284c7', '#3b82f6', '#f59e0b', '#10b981', '#8b5cf6'];
            return (
              <div
                key={idx}
                style={{ width: `${widthPct}%`, backgroundColor: useColors[idx % useColors.length] }}
                className="h-full relative group transition-all"
                title={`${u.label}: $${u.amountUSD.toFixed(1)}M (${((u.amountUSD / totalUses) * 100).toFixed(1)}%)`}
              />
            );
          })}
        </div>
        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-[11px] text-slate-400">
          {uses.map((u, idx) => {
            const useColors = ['#0284c7', '#3b82f6', '#f59e0b', '#10b981', '#8b5cf6'];
            return (
              <div key={idx} className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm inline-block shrink-0" style={{ backgroundColor: useColors[idx % useColors.length] }} />
                <span className="truncate max-w-[180px]">{u.label}</span>
                <span className="font-mono tabular-nums text-slate-300 font-medium">
                  ${u.amountUSD.toFixed(1)}M
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Imbalance alert */}
      <div className="pt-1 flex items-center justify-between text-xs border-t border-slate-800/80">
        <span className="text-slate-400">Net Sources & Uses Reconciliation:</span>
        <span
          className={`font-mono tabular-nums font-semibold ${
            Math.abs(imbalanceUSD) <= 0.05 ? 'text-emerald-400' : 'text-rose-400'
          }`}
        >
          {Math.abs(imbalanceUSD) <= 0.05
            ? 'Fully Balanced ($0.0M Discrepancy)'
            : `Imbalance: ${imbalanceUSD > 0 ? '+' : ''}$${imbalanceUSD.toFixed(1)}M`}
        </span>
      </div>
    </div>
  );
};

// ============================================================================
// 2. MONTE CARLO DISTRIBUTION HISTOGRAM
// ============================================================================

interface MonteCarloHistogramProps {
  buckets: { min: number; max: number; count: number }[];
  p5: number;
  p50: number;
  p95: number;
  expectedLossBps: number;
}

export const MonteCarloHistogramChart: React.FC<MonteCarloHistogramProps> = ({
  buckets,
  p5,
  p50,
  p95
}) => {
  const [hoveredBucket, setHoveredBucket] = useState<{ min: number; max: number; count: number } | null>(null);

  if (!buckets || buckets.length === 0) return null;
  const maxCount = Math.max(...buckets.map(b => b.count), 1);
  const chartHeight = 160;
  const chartWidth = 540;
  const barWidth = (chartWidth - 20) / buckets.length;

  return (
    <div className="w-full">
      <div className="flex justify-between items-center text-xs mb-2">
        <span className="text-slate-400 font-medium">Net Present Value (NPV) Outcome Distribution</span>
        <div className="flex items-center gap-3 font-mono text-[11px]">
          <span className="text-rose-400 font-medium">P5: ${p5}M</span>
          <span className="text-amber-300 font-semibold">P50 (Median): ${p50}M</span>
          <span className="text-emerald-400 font-medium">P95: ${p95}M</span>
        </div>
      </div>

      <div className="relative bg-[#0d1117] p-3 rounded border border-slate-800">
        <svg
          viewBox={`0 0 ${chartWidth} ${chartHeight}`}
          className="w-full h-44 overflow-visible"
        >
          {/* Grid lines */}
          <line x1="10" y1="20" x2={chartWidth - 10} y2="20" stroke="#1f2937" strokeDasharray="3 3" />
          <line x1="10" y1={chartHeight / 2} x2={chartWidth - 10} y2={chartHeight / 2} stroke="#1f2937" strokeDasharray="3 3" />
          <line x1="10" y1={chartHeight - 20} x2={chartWidth - 10} y2={chartHeight - 20} stroke="#374151" />

          {/* Histogram Bars */}
          {buckets.map((b, i) => {
            const h = (b.count / maxCount) * (chartHeight - 40);
            const x = 10 + i * barWidth;
            const y = chartHeight - 20 - h;
            const isNegative = b.max <= 0;
            const fillColor = isNegative ? '#991b1b' : b.min >= p50 ? '#059669' : '#d4af37';

            return (
              <g key={i}>
                <rect
                  x={x + 2}
                  y={y}
                  width={Math.max(2, barWidth - 4)}
                  height={h}
                  fill={fillColor}
                  opacity={hoveredBucket === b ? 1.0 : 0.82}
                  className="transition-all cursor-pointer hover:opacity-100"
                  onMouseEnter={() => setHoveredBucket(b)}
                  onMouseLeave={() => setHoveredBucket(null)}
                />
              </g>
            );
          })}

          {/* Zero boundary line */}
          {buckets[0].min < 0 && buckets[buckets.length - 1].max > 0 && (
            <line
              x1={chartWidth * 0.32}
              y1="10"
              x2={chartWidth * 0.32}
              y2={chartHeight - 20}
              stroke="#ef4444"
              strokeWidth="1.5"
              strokeDasharray="4 2"
            />
          )}
        </svg>

        {hoveredBucket && (
          <div className="absolute top-2 right-4 bg-slate-900 border border-slate-700 px-2.5 py-1.5 rounded text-xs shadow-lg font-mono text-slate-200">
            Range: ${hoveredBucket.min}M – ${hoveredBucket.max}M · Frequency: {hoveredBucket.count} simulations
          </div>
        )}
      </div>

      <div className="flex justify-between items-center text-[11px] text-slate-400 mt-2 font-mono">
        <span>Min: ${buckets[0]?.min}M</span>
        <span className="text-rose-400 font-sans">◀ Downside Shortfall Zone</span>
        <span className="text-emerald-400 font-sans">Expansion Upside ▶</span>
        <span>Max: ${buckets[buckets.length - 1]?.max}M</span>
      </div>
    </div>
  );
};

// ============================================================================
// 3. TORNADO SENSITIVITY CHART
// ============================================================================

interface TornadoChartProps {
  sensitivities: { parameter: string; impactOnNPVUSD: number; direction: 'positive' | 'negative' }[];
}

export const TornadoSensitivityChart: React.FC<TornadoChartProps> = ({ sensitivities }) => {
  const maxImpact = Math.max(...sensitivities.map(s => Math.abs(s.impactOnNPVUSD)), 1);

  return (
    <div className="space-y-2.5">
      <div className="flex justify-between text-xs text-slate-400 font-medium">
        <span>Parameter Shock Scenario</span>
        <span>NPV Sensitivity Impact ($M)</span>
      </div>

      {sensitivities.map((s, idx) => {
        const widthPct = (Math.abs(s.impactOnNPVUSD) / maxImpact) * 48;
        const isPositive = s.impactOnNPVUSD >= 0;

        return (
          <div key={idx} className="flex items-center text-xs group">
            <span className="w-56 truncate text-slate-300 font-medium shrink-0">
              {s.parameter}
            </span>
            <div className="flex-1 flex items-center h-5 relative mx-2">
              {/* Center line */}
              <div className="absolute left-1/2 top-0 bottom-0 w-[1px] bg-slate-700 z-10" />

              {/* Negative impact bar (left) */}
              {!isPositive && (
                <div
                  className="h-3.5 bg-rose-600/80 rounded-l ml-auto transition-all group-hover:bg-rose-500"
                  style={{ width: `${widthPct}%` }}
                />
              )}

              {/* Spacer for positive */}
              {isPositive && <div className="w-1/2" />}

              {/* Positive impact bar (right) */}
              {isPositive && (
                <div
                  className="h-3.5 bg-emerald-600/80 rounded-r mr-auto transition-all group-hover:bg-emerald-500"
                  style={{ width: `${widthPct}%` }}
                />
              )}
            </div>
            <span
              className={`w-16 text-right font-mono tabular-nums font-semibold shrink-0 ${
                isPositive ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {isPositive ? '+' : ''}${s.impactOnNPVUSD.toFixed(1)}M
            </span>
          </div>
        );
      })}
    </div>
  );
};

// ============================================================================
// 4. CASH FLOW WATERFALL GRAPH (PERIOD BAR CHART)
// ============================================================================

interface PeriodBarChartProps {
  periods: {
    periodMonth: number;
    cashCollectionsUSD: number;
    totalManufacturingCostUSD: number;
    totalFinancingOutflowUSD: number;
    endingCashBalanceUSD: number;
  }[];
}

export const CashFlowPeriodChart: React.FC<PeriodBarChartProps> = ({ periods }) => {
  const sampledPeriods = periods.filter(p => p.periodMonth % 3 === 0 || p.periodMonth === 1);
  const maxCollection = Math.max(...periods.map(p => p.cashCollectionsUSD), 40);

  return (
    <div className="w-full">
      <div className="flex justify-between items-center text-xs mb-2">
        <span className="text-slate-400 font-medium">Quarterly Cash Flow Trajectory</span>
        <div className="flex items-center gap-4 text-[11px]">
          <span className="flex items-center gap-1.5 text-slate-300">
            <span className="w-2.5 h-2.5 bg-emerald-500 rounded-sm inline-block" /> Cash Collections
          </span>
          <span className="flex items-center gap-1.5 text-slate-300">
            <span className="w-2.5 h-2.5 bg-amber-500 rounded-sm inline-block" /> Manufacturing Costs
          </span>
          <span className="flex items-center gap-1.5 text-slate-300">
            <span className="w-2.5 h-2.5 bg-purple-500 rounded-sm inline-block" /> Debt Service
          </span>
        </div>
      </div>

      <div className="h-44 bg-[#0d1117] p-3 rounded border border-slate-800 flex items-end justify-between gap-1">
        {sampledPeriods.map(p => {
          const colHeight = (p.cashCollectionsUSD / maxCollection) * 110;
          const costHeight = (p.totalManufacturingCostUSD / maxCollection) * 110;
          const finHeight = (p.totalFinancingOutflowUSD / maxCollection) * 110;

          return (
            <div key={p.periodMonth} className="flex-1 flex flex-col items-center group">
              <div className="flex items-end gap-1 h-32 w-full justify-center">
                {/* Collections bar */}
                <div
                  style={{ height: `${Math.max(2, colHeight)}px` }}
                  className="w-3 bg-emerald-500/80 rounded-t group-hover:bg-emerald-400 transition-all"
                  title={`Month ${p.periodMonth} Collections: $${p.cashCollectionsUSD.toFixed(1)}M`}
                />
                {/* Costs bar */}
                <div
                  style={{ height: `${Math.max(2, costHeight)}px` }}
                  className="w-3 bg-amber-500/80 rounded-t group-hover:bg-amber-400 transition-all"
                  title={`Month ${p.periodMonth} Manufacturing Cost: $${p.totalManufacturingCostUSD.toFixed(1)}M`}
                />
                {/* Financing outflow bar */}
                <div
                  style={{ height: `${Math.max(2, finHeight)}px` }}
                  className="w-3 bg-purple-500/80 rounded-t group-hover:bg-purple-400 transition-all"
                  title={`Month ${p.periodMonth} Debt Service: $${p.totalFinancingOutflowUSD.toFixed(1)}M`}
                />
              </div>
              <span className="text-[10px] text-slate-400 mt-1.5 font-mono">
                M{p.periodMonth}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
