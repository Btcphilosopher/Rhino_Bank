/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import Sidebar from "./components/Sidebar";
import DashboardView from "./components/DashboardView";
import FinancePortalView from "./components/FinancePortalView";
import CommercialLedgerView from "./components/CommercialLedgerView";
import OperationsView from "./components/OperationsView";
import SecurityView from "./components/SecurityView";
import DeveloperSuiteView from "./components/DeveloperSuiteView";
import { 
  Supplier, 
  Buyer, 
  PurchaseOrder, 
  Invoice, 
  InventoryItem, 
  Shipment, 
  FinanceApplication, 
  AuditLog, 
  KafkaMessage, 
  FinanceType 
} from "./types";

export default function App() {
  // Navigation active tab
  const [activeSection, setActiveSection] = useState<string>("dashboard");
  
  // Developer Workspace sub-tab
  const [developerSuiteMode, setDeveloperSuiteMode] = useState<"code" | "loadtest">("code");

  // Core platform states fetched from server
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [buyers, setBuyers] = useState<Buyer[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [shipments, setShipments] = useState<Shipment[]>([]);
  const [financeApplications, setFinanceApplications] = useState<FinanceApplication[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [kafkaMessages, setKafkaMessages] = useState<KafkaMessage[]>([]);
  
  // Benchmarking flag polled from server
  const [isBenchmarking, setIsBenchmarking] = useState<boolean>(false);
  const [apiError, setApiError] = useState<string | null>(null);

  // Sync state from Express backend API
  const syncState = async () => {
    try {
      const res = await fetch("/api/state");
      const data = await res.json();
      if (data) {
        setSuppliers(data.suppliers || []);
        setBuyers(data.buyers || []);
        setPurchaseOrders(data.purchaseOrders || []);
        setInvoices(data.invoices || []);
        setInventory(data.inventory || []);
        setShipments(data.shipments || []);
        setFinanceApplications(data.financeApplications || []);
        setAuditLogs(data.auditLogs || []);
        setKafkaMessages(data.kafkaMessages || []);
      }

      // Check load test state
      const benchRes = await fetch("/api/benchmark/stats");
      const benchData = await benchRes.json();
      setIsBenchmarking(benchData.isBenchmarking);
      setApiError(null);
    } catch (err) {
      console.error("RhinoChain state synchronization failed:", err);
      setApiError("Express Integration Backend Offline. Attempting automatic reconnection...");
    }
  };

  // Poll state periodically
  useEffect(() => {
    syncState();
    const interval = setInterval(syncState, 3500);
    return () => clearInterval(interval);
  }, []);

  // --- ACTIONS WITH BACKEND INTEGRATION ---

  const handleOnboardSupplier = async (data: any) => {
    try {
      const res = await fetch("/api/action/onboard-supplier", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error("Onboarding rejected by bank.");
      await syncState();
    } catch (err: any) {
      alert(err.message || "Failed to onboard supplier.");
    }
  };

  const handleOnboardBuyer = async (data: any) => {
    try {
      const res = await fetch("/api/action/onboard-buyer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error("Onboarding rejected by bank.");
      await syncState();
    } catch (err: any) {
      alert(err.message || "Failed to onboard buyer.");
    }
  };

  const handleCreatePO = async (data: any) => {
    try {
      const res = await fetch("/api/action/create-po", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error("Purchase order creation failed.");
      await syncState();
    } catch (err: any) {
      alert(err.message || "Failed to create purchase order.");
    }
  };

  const handleApprovePO = async (id: string) => {
    try {
      const res = await fetch("/api/action/approve-po", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });
      if (!res.ok) throw new Error("Purchase order approval failed.");
      await syncState();
    } catch (err: any) {
      alert(err.message || "Failed to approve purchase order.");
    }
  };

  const handleCreateInvoice = async (data: any) => {
    try {
      const res = await fetch("/api/action/create-invoice", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error("Invoice digitization failed.");
      await syncState();
    } catch (err: any) {
      alert(err.message || "Failed to digitize invoice.");
    }
  };

  const handleApproveInvoice = async (id: string) => {
    try {
      const res = await fetch("/api/action/approve-invoice", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });
      if (!res.ok) throw new Error("Invoice approval failed.");
      await syncState();
    } catch (err: any) {
      alert(err.message || "Failed to approve invoice.");
    }
  };

  const handleSettleInvoice = async (id: string) => {
    try {
      const res = await fetch("/api/action/settle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });
      if (!res.ok) throw new Error("Invoice settlement failed.");
      await syncState();
    } catch (err: any) {
      alert(err.message || "Failed to settle invoice.");
    }
  };

  const handleShipOrder = async (data: { poId: string; carrier: string }) => {
    try {
      const res = await fetch("/api/action/ship-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error("Cargo routing failed.");
      await syncState();
    } catch (err: any) {
      alert(err.message || "Failed to route cargo.");
    }
  };

  const handleDeliverShipment = async (data: { id: string; signedBy: string }) => {
    try {
      const res = await fetch("/api/action/deliver-shipment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error("Delivery check failed.");
      await syncState();
    } catch (err: any) {
      alert(err.message || "Failed to submit delivery signature.");
    }
  };

  const handleApplyFinancing = async (data: { type: FinanceType; entityId: string; applicantId: string; amount: number; rate: number }) => {
    try {
      const res = await fetch("/api/action/finance-apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error("Financing proposal failed.");
      await syncState();
    } catch (err: any) {
      alert(err.message || "Failed to submit financing proposal.");
    }
  };

  const handleTriggerAudit = async (id: string) => {
    try {
      const res = await fetch("/api/action/finance-audit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });
      if (!res.ok) throw new Error("Compliance check failed.");
      await syncState();
    } catch (err: any) {
      alert(err.message || "Failed to complete AI compliance audit.");
    }
  };

  const handleFundApplication = async (id: string) => {
    try {
      const res = await fetch("/api/action/finance-fund", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });
      if (!res.ok) throw new Error("Capital Release failed.");
      await syncState();
    } catch (err: any) {
      alert(err.message || "Failed to release capital.");
    }
  };

  const handleStartBenchmark = async () => {
    try {
      const res = await fetch("/api/benchmark/start", { method: "POST" });
      if (!res.ok) throw new Error("Could not start benchmark workers.");
      setIsBenchmarking(true);
      setActiveSection("loadtest");
      setDeveloperSuiteMode("loadtest");
      await syncState();
    } catch (err: any) {
      alert(err.message || "Failed to spin up concurrency benchmark.");
    }
  };

  const handleStopBenchmark = async () => {
    try {
      const res = await fetch("/api/benchmark/stop", { method: "POST" });
      setIsBenchmarking(false);
      await syncState();
    } catch (err: any) {
      alert(err.message || "Failed to stop benchmark.");
    }
  };

  return (
    <div id="rhinochain-application" className="flex bg-[#0c0e12] min-h-screen text-white overflow-hidden selection:bg-[#222831]">
      
      {/* Sidebar Component */}
      <Sidebar 
        activeSection={activeSection === "loadtest" ? "loadtest" : activeSection} 
        setActiveSection={(sec) => {
          if (sec === "loadtest") {
            setActiveSection("loadtest");
            setDeveloperSuiteMode("loadtest");
          } else {
            setActiveSection(sec);
          }
        }} 
        isBenchmarking={isBenchmarking}
      />

      {/* Main Workspace Frame */}
      <main id="rhinochain-main" className="flex-1 overflow-y-auto h-screen relative bg-[#0c0e12]">
        
        {/* API Connection Warning alert */}
        {apiError && (
          <div className="bg-[#1f1717] border-b border-[#552323] text-[#ef4444] px-6 py-3 font-mono text-[11px] uppercase tracking-wider flex items-center justify-between z-40">
            <span>{apiError}</span>
            <button onClick={syncState} className="underline font-bold text-white">RETRY</button>
          </div>
        )}

        <div className="p-8 max-w-7xl mx-auto space-y-8">
          
          {/* Executive Header */}
          <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <span className="text-[10px] font-mono uppercase bg-[#1d232c] text-[#88929e] px-2.5 py-1 tracking-widest font-bold">
                Institutional Terminal
              </span>
              <h1 className="text-white text-2xl font-mono font-bold tracking-tight mt-2.5">
                RhinoChain™ Trade Finance
              </h1>
            </div>

            {/* Platform Stats & Controls */}
            <div className="flex gap-4 font-mono text-[11px]">
              <button 
                onClick={handleStartBenchmark}
                disabled={isBenchmarking}
                className="bg-white hover:bg-opacity-90 disabled:opacity-40 text-black px-4 py-2 font-bold uppercase transition"
              >
                {isBenchmarking ? "Running Performance Benchmark..." : "Execute Load Test Benchmark"}
              </button>
            </div>
          </header>

          {/* ACTIVE WORKSPACE RENDER PANEL */}
          <div className="transition-all duration-150">
            {activeSection === "dashboard" && (
              <DashboardView
                suppliers={suppliers}
                buyers={buyers}
                purchaseOrders={purchaseOrders}
                invoices={invoices}
                auditLogs={auditLogs}
                isBenchmarking={isBenchmarking}
              />
            )}

            {activeSection === "finance" && (
              <FinancePortalView
                suppliers={suppliers}
                buyers={buyers}
                invoices={invoices}
                purchaseOrders={purchaseOrders}
                financeApplications={financeApplications}
                onApplyFinancing={handleApplyFinancing}
                onTriggerAudit={handleTriggerAudit}
                onFundApplication={handleFundApplication}
              />
            )}

            {activeSection === "ledger" && (
              <CommercialLedgerView
                suppliers={suppliers}
                buyers={buyers}
                purchaseOrders={purchaseOrders}
                invoices={invoices}
                onOnboardSupplier={handleOnboardSupplier}
                onOnboardBuyer={handleOnboardBuyer}
                onCreatePO={handleCreatePO}
                onApprovePO={handleApprovePO}
                onCreateInvoice={handleCreateInvoice}
                onApproveInvoice={handleApproveInvoice}
                onSettleInvoice={handleSettleInvoice}
              />
            )}

            {activeSection === "operations" && (
              <OperationsView
                inventory={inventory}
                shipments={shipments}
                purchaseOrders={purchaseOrders}
                onShipOrder={handleShipOrder}
                onDeliverShipment={handleDeliverShipment}
              />
            )}

            {activeSection === "security" && (
              <SecurityView 
                auditLogs={auditLogs} 
              />
            )}

            {(activeSection === "code" || activeSection === "loadtest") && (
              <DeveloperSuiteView
                activeViewMode={developerSuiteMode}
                setActiveViewMode={setDeveloperSuiteMode}
                kafkaMessages={kafkaMessages}
                isBenchmarking={isBenchmarking}
                onStartBenchmark={handleStartBenchmark}
                onStopBenchmark={handleStopBenchmark}
              />
            )}
          </div>

        </div>
      </main>

    </div>
  );
}
