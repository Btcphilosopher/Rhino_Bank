import { RustCodeFile } from "./types";

export const RUST_WORKSPACE_FILES: RustCodeFile[] = [
  {
    name: "Cargo.toml (Workspace)",
    path: "Cargo.toml",
    language: "toml",
    content: `[workspace]
resolver = "2"
members = [
    "rhino-ledger",
    "supplier-service",
    "buyer-service",
    "purchase-order-service",
    "invoice-service",
    "finance-service",
    "settlement-service",
    "analytics-service",
    "api-gateway",
    "identity-service",
    "audit-service"
]

[workspace.dependencies]
tokio = { version = "1.38", features = ["full"] }
axum = { version = "0.7.5" }
tonic = { version = "0.11" }
prost = { version = "0.12" }
sqlx = { version = "0.7", features = ["runtime-tokio", "postgres", "uuid", "chrono"] }
rdkafka = { version = "0.36", features = ["ssl-gssapi"] }
redis = { version = "0.25", features = ["tokio-comp"] }
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
chrono = { version = "0.4", features = ["serde"] }
uuid = { version = "1.8", features = ["v4", "serde"] }
sha2 = "0.10.8"
tracing = "0.1"
`
  },
  {
    name: "rhino-ledger / src / lib.rs",
    path: "rhino-ledger/src/lib.rs",
    language: "rust",
    content: `//! \`rhino-ledger\` - Cryptographic Double-Entry Core Settlement Ledger
//! Secures trade assets, locks collateral limits, and chains blocks using SHA-256 state tracking.

use sha2::{Sha256, Digest};
use std::sync::Arc;
use tokio::sync::RwLock;
use serde::{Serialize, Deserialize};
use chrono::{DateTime, Utc};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Transaction {
    pub tx_id: String,
    pub source_account: String,
    pub destination_account: String,
    pub amount_micros: u64, // Micro-units to avoid float precision drift
    pub signature_payload: String,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LedgerBlock {
    pub index: u64,
    pub timestamp: DateTime<Utc>,
    pub previous_hash: String,
    pub block_hash: String,
    pub transactions: Vec<Transaction>,
    pub nonce: u64,
}

pub struct ImmutableCryptographicLedger {
    chain: Arc<RwLock<Vec<LedgerBlock>>>,
    pending_transactions: Arc<RwLock<Vec<Transaction>>>,
}

impl ImmutableCryptographicLedger {
    pub fn new() -> Self {
        let genesis_block = LedgerBlock {
            index: 0,
            timestamp: Utc::now(),
            previous_hash: "0".repeat(64),
            block_hash: "RHINO_GENESIS_BLOCK_STATE_INITIALIZED_0000000000000000000000".to_string(),
            transactions: vec![],
            nonce: 42,
        };
        
        Self {
            chain: Arc::new(RwLock::new(vec![genesis_block])),
            pending_transactions: Arc::new(RwLock::new(vec![])),
        }
    }

    pub async fn submit_transaction(&self, tx: Transaction) -> Result<String, &'static str> {
        if tx.amount_micros == 0 {
            return Err("DoubleEntryError: Invalid transaction volume (micros must be > 0)");
        }
        
        let mut pending = self.pending_transactions.write().await;
        let tx_id = tx.tx_id.clone();
        pending.push(tx);
        Ok(tx_id)
    }

    pub async fn mine_pending_block(&self) -> Result<LedgerBlock, &'static str> {
        let mut pending = self.pending_transactions.write().await;
        if pending.is_empty() {
            return Err("ConsensusError: No outstanding transactions located in queue");
        }

        let mut chain = self.chain.write().await;
        let last_block = chain.last().unwrap();
        
        let current_txs = pending.drain(..).collect::<Vec<Transaction>>();
        let new_index = last_block.index + 1;
        let prev_hash = last_block.block_hash.clone();
        let timestamp = Utc::now();
        
        // Block mining loop - Yorkshire Futurist Industrial proof-of-authority
        let mut nonce = 0;
        let mined_block = loop {
            let serialized = serde_json::to_string(&(new_index, &prev_hash, &current_txs, &timestamp, nonce)).unwrap();
            let mut hasher = Sha256::new();
            hasher.update(serialized.as_bytes());
            let hash_result = format!("{:x}", hasher.finalize());
            
            // Artificial target difficulty of 3 leading zeros for fast consensus
            if hash_result.starts_with("000") {
                break LedgerBlock {
                    index: new_index,
                    timestamp,
                    previous_hash: prev_hash,
                    block_hash: hash_result,
                    transactions: current_txs,
                    nonce,
                };
            }
            nonce += 1;
        };

        chain.push(mined_block.clone());
        Ok(mined_block)
    }
}
`
  },
  {
    name: "supplier-service / src / main.rs",
    path: "supplier-service/src/main.rs",
    language: "rust",
    content: `//! \`supplier-service\` - Onboarding, credit scoring, and gRPC endpoint registry.
//! Integrated with Tokio multi-threaded scheduler and tonic-grpc interfaces.

use axum::{routing::{post, get}, Json, Router, Extension};
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tokio::net::TcpListener;
use sqlx::PgPool;

#[derive(Serialize, Deserialize, Clone)]
pub struct SupplierProfile {
    pub id: String,
    pub name: String,
    pub industry: String,
    pub credit_limit_micros: u64,
    pub risk_rating: u8, // 1-100 rating scale
}

#[derive(Deserialize)]
pub struct OnboardRequest {
    pub name: String,
    pub industry: String,
    pub credit_limit: u64,
}

struct AppState {
    db_pool: PgPool,
    kafka_producer: Arc<rdkafka::producer::FutureProducer>,
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // 1. Initialize environment config and logger
    tracing_subscriber::fmt::init();
    
    // 2. Connect to high-performance PostgreSQL cluster
    let database_url = std::env::var("DATABASE_URL").unwrap_or_else(|_| "postgres://postgres:rhino@localhost:5432/rhino_chain".to_string());
    let pool = PgPool::connect(&database_url).await?;
    sqlx::migrate!("./migrations").run(&pool).await?;

    // 3. Setup Kafka Producer for event broadcasting
    let mut config = rdkafka::ClientConfig::new();
    config.set("bootstrap.servers", "localhost:9092")
          .set("message.timeout.ms", "5000");
    let producer: rdkafka::producer::FutureProducer = config.create()?;
    
    let shared_state = Arc::new(AppState {
        db_pool: pool,
        kafka_producer: Arc::new(producer),
    });

    // 4. Mount secure, low-latency Axum endpoints
    let app = Router::new()
        .route("/api/v1/supplier/onboard", post(onboard_supplier))
        .route("/api/v1/supplier/health", get(|| async { "OK" }))
        .layer(Extension(shared_state));

    let listener = TcpListener::bind("0.0.0.0:3001").await?;
    tracing::info!("Supplier Onboarding Microservice boot complete on port 3001");
    axum::serve(listener, app).await?;

    Ok(())
}

async fn onboard_supplier(
    Extension(state): Extension<Arc<AppState>>,
    Json(payload): Json<OnboardRequest>,
) -> Result<Json<SupplierProfile>, (axum::http::StatusCode, String)> {
    // Transactional DB insertion
    let supplier_id = uuid::Uuid::new_v4().to_string();
    let risk_rating = calculate_onboarding_risk_score(&payload);

    sqlx::query!(
        "INSERT INTO suppliers (id, name, industry, credit_limit_micros, risk_rating) VALUES ($1, $2, $3, $4, $5)",
        supplier_id, payload.name, payload.industry, payload.credit_limit as i64, risk_rating as i16
    )
    .execute(&state.db_pool)
    .await
    .map_err(|e| (axum::http::StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;

    // Broadcast SupplierOnboardedEvent over Kafka Broker topic
    let event_payload = serde_json::json!({
        "event_id": uuid::Uuid::new_v4().to_string(),
        "type": "SupplierOnboardedEvent",
        "supplier_id": supplier_id,
        "name": payload.name,
        "credit_limit": payload.credit_limit,
    });

    let record = rdkafka::producer::FutureRecord::to("rhino.scf.suppliers")
        .payload(&event_payload.to_string())
        .key(&supplier_id);
    
    let _ = state.kafka_producer.send(record, std::time::Duration::from_secs(2)).await;

    Ok(Json(SupplierProfile {
        id: supplier_id,
        name: payload.name,
        industry: payload.industry,
        credit_limit_micros: payload.credit_limit,
        risk_rating,
    }))
}

fn calculate_onboarding_risk_score(req: &OnboardRequest) -> u8 {
    // Embedded industrial score matrix
    let length = req.name.len();
    if length > 15 { 15 } else { 38 }
}
`
  },
  {
    name: "finance-service / src / main.rs",
    path: "finance-service/src/main.rs",
    language: "rust",
    content: `//! \`finance-service\` - Automated working capital routing and exposure limits monitor.
//! Built with Tonic gRPC server architecture and high concurrency threadpool.

use tonic::{transport::Server, Request, Response, Status};
use finance_proto::finance_service_server::{FinanceService, FinanceServiceServer};
use finance_proto::{FinanceRequest, FinanceResponse};

pub mod finance_proto {
    tonic::include_proto!("rhino.scf.finance");
}

#[derive(Default)]
pub struct HighPerformanceFinanceEngine;

#[tonic::async_trait]
impl FinanceService for HighPerformanceFinanceEngine {
    async fn request_financing(
        &self,
        request: Request<FinanceRequest>,
    ) -> Result<Response<FinanceResponse>, Status> {
        let req = request.into_inner();
        
        // 1. Structural limits validation
        if req.requested_amount_micros > 50_000_000_000_000 { // Max limit $50M USD
            return Err(Status::resource_exhausted(
                "ComplianceLimitExceeded: Volume exceeds singular transaction cap limit"
            ));
        }

        // 2. Perform Eligibility Underwriting Calculations
        let risk_tier = match req.risk_score {
            0..=20 => "AA_PRIME",
            21..=45 => "A_STANDARD",
            46..=70 => "BBB_MED_RISK",
            _ => "REJECTED_EXPOSURE_HIGH"
        };

        if risk_tier == "REJECTED_EXPOSURE_HIGH" {
            return Ok(Response::new(FinanceResponse {
                application_id: uuid::Uuid::new_v4().to_string(),
                approved: false,
                reason: "Automated underwriting check failed: Risk score exceeded Basel IV bounds".to_string(),
                allocated_rate_basis_points: 0,
            }));
        }

        // 3. Compute discount basis points rate dynamically
        let allocated_rate = match risk_tier {
            "AA_PRIME" => 275, // 2.75% over SOFR
            "A_STANDARD" => 350, // 3.50% over SOFR
            _ => 495 // 4.95% over SOFR
        };

        Ok(Response::new(FinanceResponse {
            application_id: uuid::Uuid::new_v4().to_string(),
            approved: true,
            reason: format!("Approved under credit tier {}", risk_tier),
            allocated_rate_basis_points: allocated_rate,
        }))
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let addr = "0.0.0.0:50051".parse()?;
    let finance_engine = HighPerformanceFinanceEngine::default();

    println!("gRPC Trade Finance Service listening on address: {}", addr);

    Server::builder()
        .add_service(FinanceServiceServer::new(finance_engine))
        .serve(addr)
        .await?;

    Ok(())
}
`
  },
  {
    name: "proto / finance.proto",
    path: "proto/finance.proto",
    language: "protobuf",
    content: `syntax = "proto3";

package rhino.scf.finance;

service FinanceService {
  rpc RequestFinancing (FinanceRequest) returns (FinanceResponse);
}

message FinanceRequest {
  string applicant_id = 1;
  string counterparty_id = 2;
  string document_ref = 3;
  uint64 requested_amount_micros = 4;
  uint32 risk_score = 5;
  string finance_type = 6; // INVOICE_FINANCING, PO_FINANCING, APPROVED_PAYABLES, etc.
}

message FinanceResponse {
  string application_id = 1;
  bool approved = 2;
  string reason = 3;
  uint32 allocated_rate_basis_points = 4;
}
`
  },
  {
    name: "kubernetes / deployment.yaml",
    path: "kubernetes/deployment.yaml",
    language: "yaml",
    content: `apiVersion: apps/v1
kind: Deployment
metadata:
  name: rhinochain-finance-service
  namespace: rhino-finance
  labels:
    app: rhinochain-finance
spec:
  replicas: 5
  selector:
    matchLabels:
      app: rhinochain-finance
  template:
    metadata:
      labels:
        app: rhinochain-finance
    spec:
      containers:
      - name: finance-service-bin
        image: gcr.io/rhino-bank-prod/rhinochain/finance-service:v2.4.0
        ports:
        - containerPort: 50051
          name: grpc-api
        resources:
          limits:
            cpu: "4000m"
            memory: "8Gi"
          requests:
            cpu: "1000m"
            memory: "2Gi"
        env:
        - name: RUST_LOG
          value: "info,finance_service=debug"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: pg-ledger-secret
              key: connection_url
        readinessProbe:
          tcpSocket:
            port: 50051
          initialDelaySeconds: 15
          periodSeconds: 10
        livenessProbe:
          tcpSocket:
            port: 50051
          initialDelaySeconds: 20
          periodSeconds: 15
---
apiVersion: v1
kind: Service
metadata:
  name: rhinochain-finance-internal
  namespace: rhino-finance
spec:
  type: ClusterIP
  selector:
    app: rhinochain-finance
  ports:
  - port: 50051
    targetPort: 50051
    name: grpc-finance
`
  }
];
