export interface Supplier {
  id: string;
  name: string;
  industry: string;
  creditLimit: number;
  availableCredit: number;
  riskScore: number; // 0-100 (lower is better)
  verificationStatus: 'PENDING' | 'VERIFIED' | 'REJECTED';
  bankAccount: string;
  bankName: string;
  country: string;
  onboardedAt: string;
  activeContracts: number;
}

export interface Buyer {
  id: string;
  name: string;
  creditFacility: number;
  availableFacility: number;
  procurementTeamsCount: number;
  spendingControlLimit: number;
  outstandingBalance: number;
  country: string;
  onboardedAt: string;
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  buyerId: string;
  buyerName: string;
  supplierId: string;
  supplierName: string;
  amount: number;
  items: Array<{ name: string; qty: number; price: number }>;
  status: 'CREATED' | 'APPROVED' | 'IN_TRANSIT' | 'DELIVERED' | 'FULFILLED' | 'CANCELLED';
  createdAt: string;
  shipmentId?: string;
  invoiceId?: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  poId: string;
  poNumber: string;
  buyerId: string;
  buyerName: string;
  supplierId: string;
  supplierName: string;
  amount: number;
  dueDate: string;
  status: 'DRAFT' | 'APPROVED' | 'FINANCED' | 'SETTLED' | 'REJECTED';
  duplicateChecked: boolean;
  createdAt: string;
  financedAmount?: number;
  discountRate?: number;
}

export interface InventoryItem {
  id: string;
  warehouseName: string;
  batchNumber: string;
  serialNumber: string;
  productName: string;
  quantity: number;
  reserved: number;
  available: number;
  lastMovement: string;
}

export interface Shipment {
  id: string;
  poId: string;
  poNumber: string;
  carrier: string;
  dispatchDate: string;
  deliveryDate?: string;
  status: 'DISPATCHED' | 'IN_TRANSIT' | 'DELIVERED';
  proofOfDelivery?: {
    signedBy: string;
    timestamp: string;
    signatureHash: string;
  };
  timeline: Array<{ event: string; timestamp: string; location: string }>;
}

export type FinanceType = 'INVOICE_FINANCING' | 'PO_FINANCING' | 'APPROVED_PAYABLES' | 'INVENTORY_FINANCE' | 'DYNAMIC_DISCOUNTING';

export interface FinanceApplication {
  id: string;
  type: FinanceType;
  entityId: string; // PO or Invoice or Warehouse batch ID
  entityNumber: string; // e.g. PO-1002 or INV-4001
  applicantId: string;
  applicantName: string;
  counterpartyName: string;
  amount: number;
  rate: number; // interest or discount rate in %
  status: 'PENDING' | 'UNDER_AUDIT' | 'APPROVED' | 'FUNDED' | 'REPAID' | 'REJECTED';
  auditedBy?: 'GEMINI_AI' | 'MANUAL';
  riskScore?: number;
  riskAnalysis?: string; // Markdown summary from Gemini
  createdAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  service: string; // e.g. "purchase-order-service", "settlement-service"
  event: string; // e.g. "InvoiceFinancedEvent", "SupplierVerifiedEvent"
  actor: string; // e.g. "Tom (Treasurer)", "System"
  details: string; // JSON or plaintext details
  signature: string; // simulated cryptographic digital signature
  blockHash: string; // ledger block chaining hash
}

export interface KafkaMessage {
  id: string;
  topic: string;
  partition: number;
  offset: number;
  key: string;
  value: string; // JSON string payload
  timestamp: string;
}

export interface RustCodeFile {
  name: string;
  path: string;
  content: string;
  language: 'rust' | 'toml' | 'protobuf' | 'yaml';
}
