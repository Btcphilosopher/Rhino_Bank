import React from "react";
import { 
  Building2, 
  Terminal, 
  ShieldAlert, 
  Layers, 
  TrendingUp, 
  Container, 
  Cpu, 
  Database, 
  Radio 
} from "lucide-react";

interface SidebarProps {
  activeSection: string;
  setActiveSection: (sec: string) => void;
  isBenchmarking: boolean;
}

export default function Sidebar({ activeSection, setActiveSection, isBenchmarking }: SidebarProps) {
  const menuItems = [
    { id: "dashboard", label: "Executive Dashboard", icon: TrendingUp },
    { id: "finance", label: "SCF Finance Portal", icon: Layers },
    { id: "ledger", label: "Commercial Ledger", icon: Building2 },
    { id: "operations", label: "Operations & Logistics", icon: Container },
    { id: "security", label: "Security & Audit Logs", icon: ShieldAlert },
    { id: "code", label: "Rust Code Explorer", icon: Terminal },
    { id: "loadtest", label: "High-Concurrency Suite", icon: Cpu }
  ];

  return (
    <aside 
      id="rhinochain-sidebar" 
      className="w-72 bg-[#111418] border-r border-[#222831] h-screen flex flex-col justify-between"
    >
      {/* Brand Section */}
      <div className="p-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-[#e0e0e0] to-[#888888] flex items-center justify-center font-bold text-black text-xl tracking-tight select-none">
            R
          </div>
          <div>
            <h1 className="text-white font-mono font-bold text-lg tracking-wider">RHINO_CHAIN</h1>
            <p className="text-[#88929e] text-[10px] uppercase font-mono tracking-widest">Supply Chain Finance</p>
          </div>
        </div>
        
        {/* Connection Indicator */}
        <div className="mt-6 bg-[#161a22] border border-[#222831] p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Radio className={`w-3.5 h-3.5 ${isBenchmarking ? "text-emerald-500 animate-pulse" : "text-[#88929e]"}`} />
            <span className="text-[11px] font-mono text-[#88929e] uppercase tracking-wider">
              {isBenchmarking ? "Under Load Test" : "Core System Idle"}
            </span>
          </div>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
        </div>
      </div>

      {/* Navigation Options */}
      <nav className="flex-1 px-4 py-2 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              id={`nav-btn-${item.id}`}
              onClick={() => setActiveSection(item.id)}
              className={`w-full flex items-center gap-3.5 px-4 py-3.5 text-xs font-mono tracking-wider transition-all duration-150 relative ${
                isActive 
                  ? "bg-[#1d232c] text-white font-bold border-l-2 border-white" 
                  : "text-[#88929e] hover:text-white hover:bg-[#161a22]"
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? "text-white" : "text-[#58636e]"}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* System Node Footer */}
      <div className="p-4 border-t border-[#222831] bg-[#0c0e12]">
        <div className="flex items-center justify-between text-[10px] font-mono text-[#58636e] mb-1">
          <span>HOST: RHINO_NODE_01</span>
          <span>v2.4.0-STABLE</span>
        </div>
        <div className="w-full bg-[#161a22] h-1.5 overflow-hidden">
          <div className={`h-full bg-white transition-all duration-300 ${isBenchmarking ? "w-full bg-emerald-500" : "w-1/3"}`}></div>
        </div>
      </div>
    </aside>
  );
}
