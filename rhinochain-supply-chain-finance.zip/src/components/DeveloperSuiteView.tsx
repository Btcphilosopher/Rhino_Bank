import React, { useState, useEffect } from "react";
import { 
  Terminal, 
  Cpu, 
  FileCode, 
  Play, 
  Square, 
  Trash2, 
  CheckCircle, 
  RefreshCw, 
  Loader2, 
  AlertCircle 
} from "lucide-react";
import { RUST_WORKSPACE_FILES } from "../rustCode";
import { KafkaMessage } from "../types";

interface DeveloperSuiteViewProps {
  activeViewMode: "code" | "loadtest";
  setActiveViewMode: (mode: "code" | "loadtest") => void;
  kafkaMessages: KafkaMessage[];
  isBenchmarking: boolean;
  onStartBenchmark: () => Promise<void>;
  onStopBenchmark: () => Promise<void>;
}

export default function DeveloperSuiteView({
  activeViewMode,
  setActiveViewMode,
  kafkaMessages,
  isBenchmarking,
  onStartBenchmark,
  onStopBenchmark
}: DeveloperSuiteViewProps) {
  
  // Code Explorer State
  const [selectedFileIdx, setSelectedFileIdx] = useState(0);
  const selectedFile = RUST_WORKSPACE_FILES[selectedFileIdx];

  // Load-test Stats States (Live Polling Client-side representation or API sync)
  const [liveStats, setLiveStats] = useState({
    durationMs: 0,
    totalTransactions: 0,
    averageTps: 0,
    maxTps: 0,
    memoryUsageMB: 0,
    dbQueryCount: 0,
    kafkaEventsRate: 0,
    cpuUsagePercent: 0,
    latencyP95: 0,
    errorsEncountered: 0,
    runningWorkers: 0
  });

  const [tpsHistory, setTpsHistory] = useState<number[]>([]);

  // Synchronize stats if active benchmarking
  useEffect(() => {
    let timer: any;
    const fetchStats = async () => {
      try {
        const res = await fetch("/api/benchmark/stats");
        const data = await res.json();
        if (data && data.stats) {
          setLiveStats(data.stats);
          if (data.isBenchmarking) {
            setTpsHistory(prev => {
              const next = [...prev, data.stats.averageTps];
              if (next.length > 25) next.shift();
              return next;
            });
          }
        }
      } catch (err) {
        console.error("Failed to poll loadtest stats:", err);
      }
    };

    if (isBenchmarking) {
      fetchStats();
      timer = setInterval(fetchStats, 1000);
    } else {
      // Clear history or reset base stats if idle
      setTpsHistory([]);
    }

    return () => clearInterval(timer);
  }, [isBenchmarking]);

  return (
    <div id="developer-suite-view" className="space-y-6">
      
      {/* View Switcher Top Bar */}
      <div className="flex gap-4 border-b border-[#222831]">
        <button
          onClick={() => setActiveViewMode("code")}
          id="suite-btn-code"
          className={`px-6 py-3 font-mono text-xs uppercase tracking-wider font-bold border-b-2 flex items-center gap-2 ${
            activeViewMode === "code" ? "border-white text-white" : "border-transparent text-[#88929e] hover:text-white"
          }`}
        >
          <FileCode className="w-4 h-4" />
          <span>Rust Microservice Codebase</span>
        </button>
        <button
          onClick={() => setActiveViewMode("loadtest")}
          id="suite-btn-loadtest"
          className={`px-6 py-3 font-mono text-xs uppercase tracking-wider font-bold border-b-2 flex items-center gap-2 ${
            activeViewMode === "loadtest" ? "border-white text-white" : "border-transparent text-[#88929e] hover:text-white"
          }`}
        >
          <Cpu className="w-4 h-4" />
          <span>High-Concurrency Performance Benchmark</span>
        </button>
      </div>

      {/* VIEW PANEL: RUST CODE WORKSPACE EXPLORER */}
      {activeViewMode === "code" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Workspace File Tree Selector (4 cols) */}
          <div className="lg:col-span-4 bg-[#111418] border border-[#222831] p-5 h-[580px] flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 pb-3 border-b border-[#222831] mb-4">
                <Terminal className="w-4 h-4 text-white" />
                <h4 className="text-white text-xs font-mono font-bold uppercase tracking-wider">Cargo Workspace Tree</h4>
              </div>

              <div className="space-y-1 overflow-y-auto max-h-[460px] pr-1">
                {RUST_WORKSPACE_FILES.map((file, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedFileIdx(idx)}
                    className={`w-full text-left font-mono text-[11px] px-3 py-2.5 transition duration-150 flex items-center gap-2.5 ${
                      selectedFileIdx === idx 
                        ? "bg-[#1d232c] text-white font-bold border-l border-white" 
                        : "text-[#88929e] hover:bg-[#161a22] hover:text-white"
                    }`}
                  >
                    <FileCode className="w-4 h-4 text-[#58636e]" />
                    <span className="truncate">{file.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-[#222831] text-[10px] text-[#58636e] font-mono leading-relaxed space-y-1">
              <div>COMPILER: rustc 1.78.0-nightly</div>
              <div>WORKSPACE CARGO ARCH: tokio-tonic-sqlx-rdkafka</div>
            </div>
          </div>

          {/* Interactive Code Viewer (8 cols) */}
          <div className="lg:col-span-8 bg-[#111418] border border-[#222831] p-6 h-[580px] flex flex-col justify-between">
            <div className="flex justify-between items-center pb-3 border-b border-[#222831]">
              <span className="text-white font-mono text-xs">{selectedFile.path}</span>
              <span className="text-[10px] font-mono uppercase bg-[#1d232c] text-[#88929e] px-2 py-0.5">
                {selectedFile.language.toUpperCase()} FORMAT
              </span>
            </div>

            <pre className="flex-1 bg-[#0c0e12] border border-[#222831] p-4 font-mono text-[11px] leading-relaxed overflow-auto text-white mt-4 max-h-[460px] scrollbar-thin">
              <code>{selectedFile.content}</code>
            </pre>
          </div>

        </div>
      )}

      {/* VIEW PANEL: HIGH-CONCURRENCY LOAD SUITE */}
      {activeViewMode === "loadtest" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Controls & Configuration (4 cols) */}
          <div className="lg:col-span-4 bg-[#111418] border border-[#222831] p-6 flex flex-col justify-between h-[580px]">
            <div className="space-y-6">
              <div>
                <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider">Benchmark Orchestrator</h3>
                <p className="text-[#88929e] text-[11px] font-mono leading-relaxed mt-1">
                  Stresses the microservices layers with millions of simulated purchase orders, invoices, and event-driven pipeline messages.
                </p>
              </div>

              {/* Action triggers */}
              <div className="space-y-3.5">
                {!isBenchmarking ? (
                  <button
                    onClick={onStartBenchmark}
                    className="w-full bg-white hover:bg-opacity-90 text-black font-bold font-mono text-xs uppercase p-3 flex items-center justify-center gap-2 transition duration-150"
                  >
                    <Play className="w-4 h-4 fill-black" />
                    <span>Spin Up Load Test Suite</span>
                  </button>
                ) : (
                  <button
                    onClick={onStopBenchmark}
                    className="w-full bg-red-500 hover:bg-red-600 text-white font-bold font-mono text-xs uppercase p-3 flex items-center justify-center gap-2 transition duration-150"
                  >
                    <Square className="w-4 h-4 fill-white" />
                    <span>Halt Active Load Workers</span>
                  </button>
                )}

                <div className="bg-[#161a22] border border-[#222831] p-4 text-[11px] font-mono space-y-2 text-[#88929e]">
                  <div className="text-white border-b border-[#222831] pb-1 font-bold text-[10px] uppercase">
                    Test Specifications
                  </div>
                  <div>ENGINE ARCHITECTURE: <span className="text-white font-bold">Axum Tokio WebServer</span></div>
                  <div>CONCURRENT WORKER PROPS: <span className="text-white">4 Parallel Threads</span></div>
                  <div>DB PIPELINE STRATEGY: <span className="text-white">Drizzle/SQLx Connection Pool</span></div>
                  <div>MESSAGING BROKER STATE: <span className="text-white">Simulated Kafka Broker</span></div>
                </div>
              </div>
            </div>

            <div className="border-t border-[#222831] pt-4 text-[10px] text-[#58636e] font-mono leading-relaxed">
              <div className="flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${isBenchmarking ? "bg-emerald-500 animate-pulse" : "bg-[#58636e]"}`}></span>
                <span>STATUS: {isBenchmarking ? "CONCURRENCY STRESS ACTIVE" : "BENCHMARK SUITE IDLE"}</span>
              </div>
            </div>
          </div>

          {/* Performance Graphs & Kafka Event Terminal Stream (8 cols) */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            
            {/* Live Metrics Row */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-[#111418] border border-[#222831] p-6">
              
              <div className="space-y-1 border-r border-[#222831] pr-4">
                <span className="text-[#88929e] text-[10px] uppercase font-mono">Current Throughput</span>
                <div className="text-xl font-mono text-white tracking-wider">
                  {isBenchmarking ? `${liveStats.averageTps.toLocaleString()} TPS` : "0.0 TPS"}
                </div>
                <span className="text-[10px] text-[#58636e] font-mono">Transactions per second</span>
              </div>

              <div className="space-y-1 border-r border-[#222831] pr-4 pl-4">
                <span className="text-[#88929e] text-[10px] uppercase font-mono">P95 Commit Latency</span>
                <div className="text-xl font-mono text-white tracking-wider">
                  {isBenchmarking ? `${liveStats.latencyP95} ms` : "0.0 ms"}
                </div>
                <span className="text-[10px] text-[#58636e] font-mono">Ultra-low execution speed</span>
              </div>

              <div className="space-y-1 pl-4">
                <span className="text-[#88929e] text-[10px] uppercase font-mono">Aggregate Transactions</span>
                <div className="text-xl font-mono text-white tracking-wider">
                  {liveStats.totalTransactions.toLocaleString()}
                </div>
                <span className="text-[10px] text-[#58636e] font-mono">Database commits compiled</span>
              </div>

            </div>

            {/* Simulated Live Kafka / Event Terminal */}
            <div className="bg-[#111418] border border-[#222831] p-5 flex-1 flex flex-col justify-between h-[360px]">
              <div>
                <div className="flex justify-between items-center border-b border-[#222831] pb-2.5 mb-3">
                  <span className="text-white text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-1.5">
                    <Terminal className="w-4 h-4 text-emerald-400 animate-pulse" /> Live Apache Kafka Topic Stream
                  </span>
                  <span className="text-[9px] font-mono uppercase bg-[#1d232c] text-[#88929e] px-2 py-0.5">
                    Consumer Group: scf-broker-analytics
                  </span>
                </div>

                <div className="font-mono text-[11px] space-y-2 max-h-[250px] overflow-y-auto pr-1 bg-[#0c0e12] border border-[#222831] p-4 rounded text-[#a3b1c2] leading-relaxed scrollbar-thin">
                  {isBenchmarking ? (
                    <div className="space-y-1 text-emerald-400 animate-pulse">
                      <div>[2026-07-27] [KAFKA-CONSUMER] [INFO] Subscribed to topic "rhino.scf.*" successfully.</div>
                      <div>[2026-07-27] [BENCHMARK-WORKER] [INFO] Spawned threadpool of size 4. Injecting workload load profiles...</div>
                      <div>[2026-07-27] [KAFKA-PRODUCER] [INFO] Streaming load test payloads at {liveStats.averageTps} transactions per second.</div>
                      <div className="text-[#88929e] mt-2 italic">--- Streaming events (Terminal buffering active) ---</div>
                    </div>
                  ) : kafkaMessages.length === 0 ? (
                    <div className="text-[#58636e] text-center py-12">
                      Terminal listening. Event pipeline idle. Submit a commercial asset or onboarding action to broadcast messages.
                    </div>
                  ) : (
                    kafkaMessages.map((msg) => (
                      <div key={msg.id} className="border-b border-[#1a1f26] pb-2 text-[10px]">
                        <span className="text-[#58636e] font-bold">[{new Date(msg.timestamp).toLocaleTimeString()}]</span>{" "}
                        <span className="text-emerald-400 font-bold">[{msg.topic.toUpperCase()}]</span>{" "}
                        <span className="text-white">[OFFSET:{msg.offset}/PARTITION:{msg.partition}]</span>{" "}
                        <span className="text-[#a3b1c2] break-all block mt-0.5">{msg.value}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div className="pt-3 border-t border-[#222831] flex justify-between items-center text-[10px] text-[#58636e] font-mono">
                <span>BUFFER STATUS: 100% OK</span>
                <span>Zookeeper Nodes: 3 online</span>
              </div>
            </div>

          </div>

        </div>
      )}

    </div>
  );
}
