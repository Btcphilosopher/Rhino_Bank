import React from "react";
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar,
  PieChart, Pie, Cell 
} from "recharts";
import { 
  TrendingUp, 
  AlertCircle, 
  ShieldCheck, 
  DollarSign, 
  Activity, 
  FileText, 
  Truck 
} from "lucide-react";
import { Supplier, Buyer, PurchaseOrder, Invoice, AuditLog, KafkaMessage } from "../types";

interface DashboardViewProps {
  suppliers: Supplier[];
  buyers: Buyer[];
  purchaseOrders: PurchaseOrder[];
  invoices: Invoice[];
  auditLogs: AuditLog[];
  isBenchmarking: boolean;
}

export default function DashboardView({ 
  suppliers, 
  buyers, 
  purchaseOrders, 
  invoices, 
  auditLogs,
  isBenchmarking 
}: DashboardViewProps) {
  
  // Calculate total outstanding balances, financed amounts
  const totalFacility = buyers.reduce((sum, b) => sum + b.creditFacility, 0);
  const availableFacility = buyers.reduce((sum, b) => sum + b.availableFacility, 0);
  const outstandingExposure = buyers.reduce((sum, b) => sum + b.outstandingBalance, 0);
  const utilizedPercentage = totalFacility > 0 ? ((outstandingExposure / totalFacility) * 100).toFixed(1) : "0";

  const draftInvoicesCount = invoices.filter(i => i.status === "DRAFT").length;
  const approvedInvoicesCount = invoices.filter(i => i.status === "APPROVED").length;
  const financedInvoicesCount = invoices.filter(i => i.status === "FINANCED").length;

  const inTransitShipments = purchaseOrders.filter(p => p.status === "IN_TRANSIT").length;

  // Recharts simulated cash flow forecasting
  const cashFlowData = [
    { date: "Jul 21", Inflow: 4.2, Outflow: 3.1 },
    { date: "Jul 22", Inflow: 5.6, Outflow: 4.2 },
    { date: "Jul 23", Inflow: 6.8, Outflow: 5.0 },
    { date: "Jul 24", Inflow: 5.9, Outflow: 4.8 },
    { date: "Jul 25", Inflow: 7.4, Outflow: 5.5 },
    { date: "Jul 26", Inflow: 8.9, Outflow: 6.2 },
    { date: "Jul 27", Inflow: 9.5, Outflow: 6.8 }
  ];

  // Supplier Concentration Data
  const concentrationData = suppliers.map(s => ({
    name: s.name.substring(0, 10),
    Limit: s.creditLimit / 1000000,
    Available: s.availableCredit / 1000000
  }));

  // Visual Palette - Steel & Graphite Neutral tones
  const COLORS = ["#d1d5db", "#9ca3af", "#6b7280", "#4b5563"];

  // Generate operational alerts dynamically
  const alerts = [];
  if (invoices.some(i => i.status === "DRAFT")) {
    alerts.push({
      id: "alt-1",
      severity: "medium",
      message: `${draftInvoicesCount} invoices require review and approval in Digital Pipeline.`,
      time: "Just now"
    });
  }
  if (purchaseOrders.some(p => p.status === "CREATED")) {
    alerts.push({
      id: "alt-2",
      severity: "low",
      message: "New Purchase Order (PO-1003) submitted by Leeds Automotive.",
      time: "2 mins ago"
    });
  }
  if (suppliers.some(s => s.verificationStatus === "PENDING")) {
    alerts.push({
      id: "alt-3",
      severity: "high",
      message: "Supplier verification pending for Atlas Heavy Machinery.",
      time: "1 hour ago"
    });
  }

  return (
    <div id="executive-dashboard-view" className="space-y-6">
      {/* Head section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-4 border-b border-[#222831]">
        <div>
          <h2 className="text-white text-xl font-mono font-bold tracking-tight">EXECUTIVE_FINANCIAL_DESK</h2>
          <p className="text-[#88929e] text-xs font-mono">Rhino Bank Treasury Risk Management Console</p>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono text-[#88929e]">
          <div>LEDGER INDEX: <span className="text-white font-bold">#{auditLogs.length + 100}</span></div>
          <div className="w-1.5 h-1.5 rounded-full bg-[#58636e]"></div>
          <div>BLOCK STATE: <span className="text-white font-bold">COMMIT_OK</span></div>
        </div>
      </div>

      {/* Core KPI Tiles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* KPI 1 */}
        <div className="bg-[#111418] border border-[#222831] p-5 relative overflow-hidden">
          <div className="flex justify-between items-start">
            <span className="text-[#88929e] text-[10px] uppercase font-mono tracking-wider">Total Facility Capital</span>
            <DollarSign className="w-4 h-4 text-[#58636e]" />
          </div>
          <div className="mt-4">
            <span className="text-2xl font-mono text-white tracking-tight">${(totalFacility / 1000000).toFixed(1)}M</span>
            <span className="text-xs text-[#58636e] block mt-1 font-mono">Approved Facility Pool</span>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="bg-[#111418] border border-[#222831] p-5">
          <div className="flex justify-between items-start">
            <span className="text-[#88929e] text-[10px] uppercase font-mono tracking-wider">Ledger Active Exposure</span>
            <Activity className="w-4 h-4 text-[#88929e]" />
          </div>
          <div className="mt-4">
            <span className="text-2xl font-mono text-white tracking-tight">${(outstandingExposure / 1000000).toFixed(2)}M</span>
            <span className="text-xs text-emerald-500 font-mono block mt-1">
              ↑ {utilizedPercentage}% Utitilization Rate
            </span>
          </div>
        </div>

        {/* KPI 3 */}
        <div className="bg-[#111418] border border-[#222831] p-5">
          <div className="flex justify-between items-start">
            <span className="text-[#88929e] text-[10px] uppercase font-mono tracking-wider">Outstanding Invoices</span>
            <FileText className="w-4 h-4 text-[#58636e]" />
          </div>
          <div className="mt-4">
            <span className="text-2xl font-mono text-white tracking-tight">{invoices.length}</span>
            <span className="text-xs text-[#88929e] block mt-1 font-mono">
              {financedInvoicesCount} Financed / {approvedInvoicesCount} Approved
            </span>
          </div>
        </div>

        {/* KPI 4 */}
        <div className="bg-[#111418] border border-[#222831] p-5">
          <div className="flex justify-between items-start">
            <span className="text-[#88929e] text-[10px] uppercase font-mono tracking-wider">Active Cargo In-Transit</span>
            <Truck className="w-4 h-4 text-[#58636e]" />
          </div>
          <div className="mt-4">
            <span className="text-2xl font-mono text-white tracking-tight">{inTransitShipments}</span>
            <span className="text-xs text-amber-500 font-mono block mt-1">
              Monitoring logistics lanes
            </span>
          </div>
        </div>
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Cash Flow Forecast (8 columns) */}
        <div className="lg:col-span-8 bg-[#111418] border border-[#222831] p-6">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider">RhinoQuant Cash Flow Forecast</h3>
              <p className="text-[#88929e] text-[11px] font-mono">Dynamic multi-currency working capital index (USD Millions)</p>
            </div>
            <div className="flex gap-4 text-[10px] font-mono">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 bg-white"></span>
                <span className="text-white">Capital Inflow</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 bg-[#58636e]"></span>
                <span className="text-[#88929e]">Capital Outflow</span>
              </div>
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={cashFlowData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1d232c" />
                <XAxis dataKey="date" stroke="#58636e" tick={{ fontSize: 10, fontFamily: 'monospace' }} />
                <YAxis stroke="#58636e" tick={{ fontSize: 10, fontFamily: 'monospace' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#111418", border: "1px solid #222831" }}
                  labelStyle={{ color: "#ffffff", fontFamily: 'monospace', fontSize: 11 }}
                  itemStyle={{ fontFamily: 'monospace', fontSize: 11 }}
                />
                <Line type="monotone" dataKey="Inflow" stroke="#ffffff" strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                <Line type="monotone" dataKey="Outflow" stroke="#58636e" strokeWidth={2} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Operational Alerts & Status Panel (4 columns) */}
        <div className="lg:col-span-4 bg-[#111418] border border-[#222831] p-6 flex flex-col justify-between">
          <div>
            <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-4">Operations & Alerts</h3>
            
            {alerts.length > 0 ? (
              <div className="space-y-3">
                {alerts.map((alert) => (
                  <div 
                    key={alert.id}
                    className={`border p-3.5 flex gap-3 items-start ${
                      alert.severity === "high" 
                        ? "bg-[#1f1717] border-[#552323] text-[#ef4444]" 
                        : alert.severity === "medium"
                        ? "bg-[#1f1b13] border-[#554023] text-amber-500"
                        : "bg-[#13161c] border-[#222831] text-white"
                    }`}
                  >
                    <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-[11px] font-mono leading-relaxed">{alert.message}</p>
                      <span className="text-[9px] text-[#58636e] uppercase font-mono block mt-1.5">{alert.time}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 border border-dashed border-[#222831]">
                <ShieldCheck className="w-8 h-8 text-[#58636e] mx-auto mb-2" />
                <p className="text-[#88929e] text-xs font-mono">No risk deviations or warnings registered.</p>
              </div>
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-[#222831] text-[10px] font-mono text-[#58636e] space-y-1.5">
            <div className="flex justify-between">
              <span>SYSTEM LATENCY:</span>
              <span className="text-white font-bold">1.42ms</span>
            </div>
            <div className="flex justify-between">
              <span>DB CLUSTER REPLICAS:</span>
              <span className="text-white">5 ONLINE</span>
            </div>
            <div className="flex justify-between">
              <span>ACTIVE KAFKA TOPICS:</span>
              <span className="text-white">12 PARALLEL</span>
            </div>
          </div>
        </div>
      </div>

      {/* Row 2: Concentration & Supplier Limits */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Supplier Credit Concentration */}
        <div className="lg:col-span-2 bg-[#111418] border border-[#222831] p-6">
          <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-2">Supplier Credit Concentration</h3>
          <p className="text-[#88929e] text-[11px] font-mono mb-6">Aggregate risk profile showing limits vs. utilized credit buffers (USD Millions)</p>
          
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={concentrationData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1d232c" />
                <XAxis dataKey="name" stroke="#58636e" tick={{ fontSize: 9, fontFamily: 'monospace' }} />
                <YAxis stroke="#58636e" tick={{ fontSize: 9, fontFamily: 'monospace' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#111418", border: "1px solid #222831" }}
                  labelStyle={{ color: "#ffffff", fontFamily: 'monospace', fontSize: 11 }}
                  itemStyle={{ fontFamily: 'monospace', fontSize: 11 }}
                />
                <Bar dataKey="Limit" fill="#58636e" name="Assigned Limit" />
                <Bar dataKey="Available" fill="#ffffff" name="Available Limit" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Quick Ledger Watcher */}
        <div className="bg-[#111418] border border-[#222831] p-6">
          <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-4">Secured Platform Log</h3>
          <div className="space-y-4 max-h-[240px] overflow-y-auto pr-1">
            {auditLogs.slice(0, 4).map((log) => (
              <div key={log.id} className="border-b border-[#222831] pb-3 text-[11px] font-mono">
                <div className="flex justify-between text-[#88929e]">
                  <span>{log.service.replace("-service", "").toUpperCase()}</span>
                  <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
                </div>
                <p className="text-white font-bold mt-1 tracking-wider">{log.event}</p>
                <div className="text-[10px] text-[#58636e] font-mono truncate mt-0.5">{log.details}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
