import React, { useState } from "react";
import { 
  Container, 
  MapPin, 
  Truck, 
  CheckCircle, 
  ChevronRight, 
  PenTool, 
  RefreshCw 
} from "lucide-react";
import { InventoryItem, Shipment, PurchaseOrder } from "../types";

interface OperationsViewProps {
  inventory: InventoryItem[];
  shipments: Shipment[];
  purchaseOrders: PurchaseOrder[];
  onShipOrder: (data: { poId: string; carrier: string }) => Promise<void>;
  onDeliverShipment: (data: { id: string; signedBy: string }) => Promise<void>;
}

export default function OperationsView({
  inventory,
  shipments,
  purchaseOrders,
  onShipOrder,
  onDeliverShipment
}: OperationsViewProps) {
  
  // States
  const [selectedPoId, setSelectedPoId] = useState("");
  const [carrier, setCarrier] = useState("DHL Ocean Express");
  const [isShipping, setIsShipping] = useState(false);
  
  // POD modal simulator
  const [podShipmentId, setPodShipmentId] = useState<string | null>(null);
  const [signedBy, setSignedBy] = useState("");

  const handleShip = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPoId || !carrier) return;

    setIsShipping(true);
    try {
      await onShipOrder({ poId: selectedPoId, carrier });
      setSelectedPoId("");
    } catch (err) {
      console.error(err);
    } finally {
      setIsShipping(false);
    }
  };

  const handleDeliver = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!podShipmentId || !signedBy) return;

    try {
      await onDeliverShipment({ id: podShipmentId, signedBy });
      setPodShipmentId(null);
      setSignedBy("");
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div id="operations-view" className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      
      {/* 1. Warehouses & Inventory Health (5 cols) */}
      <div className="lg:col-span-5 space-y-6">
        
        {/* Dispatch Order Form */}
        <div className="bg-[#111418] border border-[#222831] p-5">
          <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-4">Orchestrate Cargo Dispatch</h3>
          <form onSubmit={handleShip} className="space-y-4 font-mono text-xs">
            <div className="space-y-1">
              <label className="text-[#88929e] text-[10px] uppercase">Select Approved PO</label>
              <select
                value={selectedPoId}
                onChange={e => setSelectedPoId(e.target.value)}
                required
                className="w-full bg-[#161a22] border border-[#222831] text-white p-2.5 font-mono"
              >
                <option value="">Select Approved PO...</option>
                {purchaseOrders
                  .filter(p => p.status === "APPROVED")
                  .map(p => (
                    <option key={p.id} value={p.id}>
                      {p.poNumber} - {p.supplierName} (${p.amount.toLocaleString()})
                    </option>
                  ))
                }
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[#88929e] text-[10px] uppercase">Logistics Carrier Network</label>
              <select
                value={carrier}
                onChange={e => setCarrier(e.target.value)}
                className="w-full bg-[#161a22] border border-[#222831] text-white p-2.5 font-mono"
              >
                <option value="DHL Ocean Express">DHL Ocean Express (Intercontinental)</option>
                <option value="Maersk Line Freight">Maersk Line Freight (Container Port)</option>
                <option value="Nordic Cargo Rail">Nordic Cargo Rail (Continental overland)</option>
                <option value="Rhino Bank Treasury Escrow Carriers">Rhino Secured Logistics Fleet</option>
              </select>
            </div>

            <button 
              type="submit" 
              disabled={isShipping || !selectedPoId}
              className="w-full bg-white hover:bg-opacity-90 disabled:opacity-40 text-black p-2.5 font-bold uppercase transition"
            >
              {isShipping ? "Routing Consignment..." : "Dispatch Consignment & Track"}
            </button>
          </form>
        </div>

        {/* Live Inventory Stock Tracker */}
        <div className="bg-[#111418] border border-[#222831] p-5">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider">Live Inventory Stock Registry</h3>
            <span className="text-[9px] font-mono bg-[#1d232c] text-[#88929e] px-2 py-0.5 uppercase">3 Warehouses</span>
          </div>

          <div className="space-y-4 max-h-[300px] overflow-y-auto pr-1">
            {inventory.map((item) => {
              const util = ((item.reserved / item.quantity) * 100).toFixed(0);
              return (
                <div key={item.id} className="border border-[#222831] bg-[#0c0e12] p-3.5 space-y-2 text-xs font-mono">
                  <div className="flex justify-between items-start">
                    <div>
                      <strong className="text-white text-xs block">{item.productName}</strong>
                      <span className="text-[10px] text-[#58636e] block mt-0.5">Warehouse: {item.warehouseName}</span>
                    </div>
                    <span className="text-[10px] text-white bg-[#1d232c] px-2 py-0.5">Batch: {item.batchNumber}</span>
                  </div>

                  <div className="grid grid-cols-3 text-[10px] text-[#88929e] pt-1 border-t border-[#1a1f26]">
                    <div>TOTAL: <span className="text-white">{item.quantity}</span></div>
                    <div>RESERVED: <span className="text-amber-500 font-bold">{item.reserved}</span></div>
                    <div>AVAILABLE: <span className="text-emerald-500 font-bold">{item.available}</span></div>
                  </div>

                  {/* Stock reservation progress bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[9px] text-[#58636e]">
                      <span>RESERVATION EXPOSURE:</span>
                      <span>{util}% Allocated</span>
                    </div>
                    <div className="w-full bg-[#161a22] h-1.5 overflow-hidden">
                      <div className="bg-[#58636e] h-full" style={{ width: `${util}%` }}></div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* 2. Logistics & Carrier Shipments tracking (7 cols) */}
      <div className="lg:col-span-7 space-y-6">
        
        {/* Shipments List */}
        <div className="bg-[#111418] border border-[#222831] p-6">
          <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-4">Active Freight & Cargo Lanes</h3>

          {shipments.length === 0 ? (
            <div className="text-center py-12 border border-dashed border-[#222831]">
              <Truck className="w-8 h-8 text-[#58636e] mx-auto mb-2" />
              <p className="text-[#88929e] text-xs font-mono">No active cargo shipments tracked at present.</p>
            </div>
          ) : (
            <div className="space-y-5">
              {shipments.map((ship) => (
                <div key={ship.id} className="border border-[#222831] bg-[#0c0e12] p-4 space-y-3 font-mono text-xs">
                  <div className="flex justify-between items-start">
                    <div>
                      <strong className="text-white text-sm">{ship.id.toUpperCase()}</strong>
                      <span className="text-[10px] text-[#88929e] block mt-0.5">
                        PO-Ref: <strong className="text-white">{ship.poNumber}</strong> | CARRIER: {ship.carrier}
                      </span>
                    </div>
                    <div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 tracking-wider uppercase border ${
                        ship.status === "DISPATCHED" ? "bg-amber-950 border-amber-800 text-amber-500" :
                        ship.status === "IN_TRANSIT" ? "bg-blue-950 border-blue-800 text-blue-400" :
                        "bg-white text-black"
                      }`}>
                        {ship.status}
                      </span>
                    </div>
                  </div>

                  {/* Active logistics track timeline */}
                  <div className="space-y-2 border-l-2 border-[#1d232c] pl-4 ml-2">
                    {ship.timeline.map((step, idx) => (
                      <div key={idx} className="relative text-[11px] leading-relaxed">
                        <div className="absolute -left-[21px] top-1.5 w-2.5 h-2.5 rounded-full bg-white border border-[#111418]"></div>
                        <span className="text-[#88929e] text-[10px] block font-bold">{new Date(step.timestamp).toLocaleString()}</span>
                        <p className="text-white mt-0.5 font-bold">{step.event}</p>
                        <span className="text-[9px] text-[#58636e] uppercase font-mono flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-[#58636e]" /> {step.location}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Proof of delivery & Actions */}
                  {ship.status !== "DELIVERED" ? (
                    <div className="flex justify-end pt-2 border-t border-[#1a1f26]">
                      <button
                        onClick={() => setPodShipmentId(ship.id)}
                        className="bg-white hover:bg-opacity-90 text-black px-4 py-1 font-bold text-[10px] uppercase flex items-center gap-1"
                      >
                        <PenTool className="w-3.5 h-3.5" />
                        <span>Confirm Delivery & Sign POD</span>
                      </button>
                    </div>
                  ) : (
                    <div className="bg-[#13161c] p-3 border border-[#222831] space-y-1.5 mt-2.5">
                      <div className="flex items-center gap-2 text-emerald-400 font-bold uppercase text-[10px]">
                        <CheckCircle className="w-4 h-4" />
                        <span>Cryptographically verified delivery receipt (POD)</span>
                      </div>
                      <div className="text-[10px] text-[#88929e] grid grid-cols-2">
                        <div>SIGNED BY: <span className="text-white">{ship.proofOfDelivery?.signedBy}</span></div>
                        <div>VERIFIED AT: <span className="text-white">{new Date(ship.proofOfDelivery?.timestamp || "").toLocaleString()}</span></div>
                      </div>
                      <div className="text-[9px] text-[#58636e] font-mono break-all leading-tight mt-1 bg-[#0c0e12] p-1.5 border border-[#1d232c]">
                        SHA-256 SIGNATURE: {ship.proofOfDelivery?.signatureHash}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Proof of Delivery signing modal simulation */}
      {podShipmentId && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#111418] border border-[#222831] p-6 max-w-md w-full font-mono text-xs space-y-4">
            <h3 className="text-white text-sm font-bold uppercase tracking-wider border-b border-[#222831] pb-2">
              Sign Proof of Delivery (POD)
            </h3>
            
            <form onSubmit={handleDeliver} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[#88929e] text-[10px] uppercase font-bold">Authorized Receiver Name</label>
                <input 
                  type="text" 
                  value={signedBy} 
                  onChange={e => setSignedBy(e.target.value)}
                  placeholder="e.g. Inspector Tom Richardson"
                  required
                  className="w-full bg-[#161a22] border border-[#222831] text-white p-3 font-mono"
                />
              </div>

              <p className="text-[10px] text-[#58636e] leading-relaxed">
                Signing will generate an immutable digital signature on the Rhino Ledger using SHA-256 block chaining, closing the trade fulfillment loop.
              </p>

              <div className="flex gap-2.5 justify-end">
                <button
                  type="button"
                  onClick={() => setPodShipmentId(null)}
                  className="border border-[#222831] text-[#88929e] px-4 py-2 hover:bg-[#161a22] font-bold uppercase text-[10px]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-white hover:bg-opacity-90 text-black px-5 py-2 font-bold uppercase text-[10px]"
                >
                  Sign & Commit Block
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
