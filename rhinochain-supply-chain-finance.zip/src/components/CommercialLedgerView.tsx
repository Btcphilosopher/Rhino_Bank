import React, { useState } from "react";
import { 
  Building2, 
  Plus, 
  Trash2, 
  ChevronRight, 
  Check, 
  FileCheck, 
  DollarSign, 
  ArrowRight,
  UserPlus
} from "lucide-react";
import { Supplier, Buyer, PurchaseOrder, Invoice } from "../types";

interface CommercialLedgerViewProps {
  suppliers: Supplier[];
  buyers: Buyer[];
  purchaseOrders: PurchaseOrder[];
  invoices: Invoice[];
  onOnboardSupplier: (data: any) => Promise<void>;
  onOnboardBuyer: (data: any) => Promise<void>;
  onCreatePO: (data: any) => Promise<void>;
  onApprovePO: (id: string) => Promise<void>;
  onCreateInvoice: (data: any) => Promise<void>;
  onApproveInvoice: (id: string) => Promise<void>;
  onSettleInvoice: (id: string) => Promise<void>;
}

export default function CommercialLedgerView({
  suppliers,
  buyers,
  purchaseOrders,
  invoices,
  onOnboardSupplier,
  onOnboardBuyer,
  onCreatePO,
  onApprovePO,
  onCreateInvoice,
  onApproveInvoice,
  onSettleInvoice
}: CommercialLedgerViewProps) {
  
  // Ledger inner tabs
  const [activeSubTab, setActiveSubTab] = useState<"directory" | "pos" | "invoices">("directory");

  // Supplier Form
  const [supName, setSupName] = useState("");
  const [supIndustry, setSupIndustry] = useState("Raw Materials");
  const [supLimit, setSupLimit] = useState("5000000");
  const [supBank, setSupBank] = useState("GB88RHIN8000" + Math.floor(Math.random() * 90000000 + 10000000));
  const [supBankName, setSupBankName] = useState("Rhino Bank UK");
  const [supCountry, setSupCountry] = useState("United Kingdom");
  
  // Buyer Form
  const [buyName, setBuyName] = useState("");
  const [buyFacility, setBuyFacility] = useState("10000000");
  const [buySpending, setBuySpending] = useState("1000000");
  const [buyCountry, setBuyCountry] = useState("United Kingdom");

  // PO Form
  const [poBuyerId, setPoBuyerId] = useState("");
  const [poSupplierId, setPoSupplierId] = useState("");
  const [poAmount, setPoAmount] = useState("");
  const [poItems, setPoItems] = useState<{ name: string; qty: number; price: number }[]>([
    { name: "Raw Heavy Casting Modules", qty: 200, price: 500 }
  ]);

  // Invoice Form
  const [invPoId, setInvPoId] = useState("");
  const [invNum, setInvNum] = useState("");
  const [invDueDate, setInvDueDate] = useState("2026-12-31");

  // Onboard Supplier trigger
  const handleOnboardSupplier = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supName || !supLimit) return;
    await onOnboardSupplier({
      name: supName,
      industry: supIndustry,
      creditLimit: Number(supLimit),
      bankAccount: supBank,
      bankName: supBankName,
      country: supCountry
    });
    setSupName("");
  };

  // Onboard Buyer trigger
  const handleOnboardBuyer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!buyName || !buyFacility) return;
    await onOnboardBuyer({
      name: buyName,
      creditFacility: Number(buyFacility),
      spendingControlLimit: Number(buySpending),
      country: buyCountry
    });
    setBuyName("");
  };

  // PO Item modifier
  const addPoItem = () => {
    setPoItems([...poItems, { name: "", qty: 1, price: 0 }]);
  };

  const removePoItem = (idx: number) => {
    setPoItems(poItems.filter((_, i) => i !== idx));
  };

  const updatePoItem = (idx: number, field: string, val: any) => {
    const updated = [...poItems];
    updated[idx] = { ...updated[idx], [field]: val };
    
    // Auto compute total PO amount
    const tot = updated.reduce((sum, item) => sum + (item.qty * item.price), 0);
    setPoAmount(String(tot));
    setPoItems(updated);
  };

  // Create PO Trigger
  const handleCreatePO = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!poBuyerId || !poSupplierId || poItems.length === 0) return;
    await onCreatePO({
      buyerId: poBuyerId,
      supplierId: poSupplierId,
      amount: Number(poAmount),
      items: poItems
    });
    setPoBuyerId("");
    setPoSupplierId("");
    setPoItems([{ name: "Raw Heavy Casting Modules", qty: 200, price: 500 }]);
    setPoAmount("100000");
  };

  // Create Invoice Trigger
  const handleCreateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!invPoId || !invNum || !invDueDate) return;
    const po = purchaseOrders.find(p => p.id === invPoId);
    if (!po) return;

    await onCreateInvoice({
      poId: invPoId,
      invoiceNumber: invNum,
      amount: po.amount,
      dueDate: new Date(invDueDate).toISOString()
    });
    setInvPoId("");
    setInvNum("");
  };

  return (
    <div id="commercial-ledger-view" className="space-y-6">
      
      {/* Sub-tab Navigation */}
      <div className="flex border-b border-[#222831]">
        <button
          onClick={() => setActiveSubTab("directory")}
          id="subtab-directory"
          className={`px-6 py-3 font-mono text-xs uppercase tracking-wider font-bold border-b-2 ${
            activeSubTab === "directory" ? "border-white text-white" : "border-transparent text-[#88929e] hover:text-white"
          }`}
        >
          Directories & Onboarding
        </button>
        <button
          onClick={() => setActiveSubTab("pos")}
          id="subtab-pos"
          className={`px-6 py-3 font-mono text-xs uppercase tracking-wider font-bold border-b-2 ${
            activeSubTab === "pos" ? "border-white text-white" : "border-transparent text-[#88929e] hover:text-white"
          }`}
        >
          Purchase Orders ({purchaseOrders.length})
        </button>
        <button
          onClick={() => setActiveSubTab("invoices")}
          id="subtab-invoices"
          className={`px-6 py-3 font-mono text-xs uppercase tracking-wider font-bold border-b-2 ${
            activeSubTab === "invoices" ? "border-white text-white" : "border-transparent text-[#88929e] hover:text-white"
          }`}
        >
          Invoices Pipeline ({invoices.length})
        </button>
      </div>

      {/* TABS CONTAINER */}
      {activeSubTab === "directory" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Supplier Directory & Form (6 cols) */}
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-[#111418] border border-[#222831] p-5">
              <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-4">Onboard New Supplier</h3>
              <form onSubmit={handleOnboardSupplier} className="space-y-4 font-mono text-xs">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[#88929e] text-[10px] uppercase">Corporate Name</label>
                    <input 
                      type="text" 
                      value={supName} 
                      onChange={e => setSupName(e.target.value)}
                      placeholder="e.g. Leeds Metals Ltd"
                      required
                      className="w-full bg-[#161a22] border border-[#222831] text-white p-2.5 font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[#88929e] text-[10px] uppercase">Industry vertical</label>
                    <select 
                      value={supIndustry} 
                      onChange={e => setSupIndustry(e.target.value)}
                      className="w-full bg-[#161a22] border border-[#222831] text-white p-2.5 font-mono"
                    >
                      <option value="Raw Materials">Raw Materials</option>
                      <option value="Semiconductors">Semiconductors</option>
                      <option value="Logistics">Logistics</option>
                      <option value="Heavy Equipment">Heavy Equipment</option>
                      <option value="Packaging">Packaging</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[#88929e] text-[10px] uppercase">Requested Credit Limit ($)</label>
                    <input 
                      type="number" 
                      value={supLimit} 
                      onChange={e => setSupLimit(e.target.value)}
                      required
                      className="w-full bg-[#161a22] border border-[#222831] text-white p-2.5 font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[#88929e] text-[10px] uppercase">Incorporation Country</label>
                    <input 
                      type="text" 
                      value={supCountry} 
                      onChange={e => setSupCountry(e.target.value)}
                      required
                      className="w-full bg-[#161a22] border border-[#222831] text-white p-2.5 font-mono"
                    />
                  </div>
                </div>

                <button 
                  type="submit" 
                  className="w-full bg-white hover:bg-opacity-90 text-black p-2.5 font-bold uppercase transition"
                >
                  Onboard & Clear KYC
                </button>
              </form>
            </div>

            {/* Current Onboarded Suppliers Grid */}
            <div className="bg-[#111418] border border-[#222831] p-5">
              <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-3">Onboarded Suppliers Directory</h3>
              <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
                {suppliers.map(s => (
                  <div key={s.id} className="border border-[#222831] bg-[#0c0e12] p-3.5 space-y-2">
                    <div className="flex justify-between">
                      <strong className="text-white font-mono text-xs">{s.name}</strong>
                      <span className="text-[10px] text-emerald-400 border border-emerald-900 bg-emerald-950 px-2 py-0.5 uppercase font-mono font-bold">
                        {s.verificationStatus}
                      </span>
                    </div>
                    <div className="grid grid-cols-3 text-[10px] font-mono text-[#88929e]">
                      <div>INDUSTRY: <span className="text-white">{s.industry}</span></div>
                      <div>RISK INDEX: <span className="text-white">{s.riskScore}/100</span></div>
                      <div>REGION: <span className="text-white">{s.country}</span></div>
                    </div>
                    <div className="flex justify-between text-[10px] font-mono border-t border-[#1a1f26] pt-2 text-[#88929e]">
                      <span>Credit Buffer: <strong>${s.availableCredit.toLocaleString()} / ${s.creditLimit.toLocaleString()}</strong></span>
                      <span>Contracts: <strong className="text-white">{s.activeContracts}</strong></span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Buyer Directory & Form (6 cols) */}
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-[#111418] border border-[#222831] p-5">
              <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-4">Onboard New Buyer Corp</h3>
              <form onSubmit={handleOnboardBuyer} className="space-y-4 font-mono text-xs">
                <div className="space-y-1">
                  <label className="text-[#88929e] text-[10px] uppercase">Corporate Name</label>
                  <input 
                    type="text" 
                    value={buyName} 
                    onChange={e => setBuyName(e.target.value)}
                    placeholder="e.g. Manchester Heavy Engines"
                    required
                    className="w-full bg-[#161a22] border border-[#222831] text-white p-2.5 font-mono"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[#88929e] text-[10px] uppercase">Credit Facility ($)</label>
                    <input 
                      type="number" 
                      value={buyFacility} 
                      onChange={e => setBuyFacility(e.target.value)}
                      required
                      className="w-full bg-[#161a22] border border-[#222831] text-white p-2.5 font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[#88929e] text-[10px] uppercase">Country</label>
                    <input 
                      type="text" 
                      value={buyCountry} 
                      onChange={e => setBuyCountry(e.target.value)}
                      required
                      className="w-full bg-[#161a22] border border-[#222831] text-white p-2.5 font-mono"
                    />
                  </div>
                </div>

                <button 
                  type="submit" 
                  className="w-full bg-white hover:bg-opacity-90 text-black p-2.5 font-bold uppercase transition"
                >
                  Approve Corporate Facility
                </button>
              </form>
            </div>

            {/* Current Onboarded Buyers Grid */}
            <div className="bg-[#111418] border border-[#222831] p-5">
              <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-3">Onboarded Buyers Directory</h3>
              <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
                {buyers.map(b => (
                  <div key={b.id} className="border border-[#222831] bg-[#0c0e12] p-3.5 space-y-2">
                    <div className="flex justify-between">
                      <strong className="text-white font-mono text-xs">{b.name}</strong>
                      <span className="text-[10px] text-white bg-[#1d232c] px-2.5 py-0.5 font-mono">
                        {b.id.toUpperCase()}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 text-[10px] font-mono text-[#88929e]">
                      <div>Procurement Teams: <span className="text-white">{b.procurementTeamsCount}</span></div>
                      <div>Region: <span className="text-white">{b.country}</span></div>
                    </div>
                    <div className="flex justify-between text-[10px] font-mono border-t border-[#1a1f26] pt-2 text-[#88929e]">
                      <span>Available Capital: <strong>${b.availableFacility.toLocaleString()} / ${b.creditFacility.toLocaleString()}</strong></span>
                      <span>Outstanding Debt: <strong className="text-red-400">${b.outstandingBalance.toLocaleString()}</strong></span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      )}

      {/* PURCHASE ORDERS TAB */}
      {activeSubTab === "pos" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Create PO Form (5 cols) */}
          <div className="lg:col-span-5 bg-[#111418] border border-[#222831] p-6 h-fit">
            <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-4">Emit Purchase Order</h3>
            <form onSubmit={handleCreatePO} className="space-y-4 font-mono text-xs">
              
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[#88929e] text-[10px] uppercase">Corporate Buyer</label>
                  <select
                    value={poBuyerId}
                    onChange={e => setPoBuyerId(e.target.value)}
                    required
                    className="w-full bg-[#161a22] border border-[#222831] text-white p-2.5 font-mono"
                  >
                    <option value="">Select Buyer...</option>
                    {buyers.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[#88929e] text-[10px] uppercase">Supplier Asset Source</label>
                  <select
                    value={poSupplierId}
                    onChange={e => setPoSupplierId(e.target.value)}
                    required
                    className="w-full bg-[#161a22] border border-[#222831] text-white p-2.5 font-mono"
                  >
                    <option value="">Select Supplier...</option>
                    {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
              </div>

              {/* Dynamic Items list */}
              <div className="space-y-2">
                <div className="flex justify-between items-center border-b border-[#222831] pb-1.5">
                  <span className="text-[#88929e] text-[10px] uppercase font-bold">Line Items</span>
                  <button 
                    type="button" 
                    onClick={addPoItem}
                    className="text-white border border-[#222831] px-2 py-0.5 hover:bg-[#161a22] text-[10px]"
                  >
                    + Add Item
                  </button>
                </div>
                
                <div className="space-y-2.5 max-h-[160px] overflow-y-auto pr-1">
                  {poItems.map((item, idx) => (
                    <div key={idx} className="flex gap-2 items-center">
                      <input 
                        type="text" 
                        value={item.name} 
                        onChange={e => updatePoItem(idx, "name", e.target.value)}
                        placeholder="Item description..."
                        required
                        className="flex-1 bg-[#161a22] border border-[#222831] text-white p-1.5"
                      />
                      <input 
                        type="number" 
                        value={item.qty} 
                        onChange={e => updatePoItem(idx, "qty", Number(e.target.value))}
                        placeholder="Qty"
                        required
                        className="w-12 bg-[#161a22] border border-[#222831] text-white p-1.5"
                      />
                      <input 
                        type="number" 
                        value={item.price} 
                        onChange={e => updatePoItem(idx, "price", Number(e.target.value))}
                        placeholder="Price"
                        required
                        className="w-16 bg-[#161a22] border border-[#222831] text-white p-1.5"
                      />
                      {poItems.length > 1 && (
                        <button 
                          type="button" 
                          onClick={() => removePoItem(idx)}
                          className="text-red-400 hover:text-red-500 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-[#161a22] p-3 border border-[#222831] flex justify-between font-bold">
                <span className="text-[#88929e]">Calculated PO Value:</span>
                <span className="text-white">${Number(poAmount).toLocaleString()}</span>
              </div>

              <button 
                type="submit" 
                className="w-full bg-white hover:bg-opacity-90 text-black p-3 font-bold uppercase transition"
              >
                Emit Cryptographic Purchase Order
              </button>
            </form>
          </div>

          {/* Active PO List (7 cols) */}
          <div className="lg:col-span-7 bg-[#111418] border border-[#222831] p-6">
            <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-4 font-bold">Purchase Order Registry</h3>
            <div className="space-y-4">
              {purchaseOrders.map(po => (
                <div key={po.id} className="border border-[#222831] bg-[#0c0e12] p-4 space-y-3 text-xs font-mono">
                  <div className="flex justify-between items-start">
                    <div>
                      <strong className="text-white text-sm">{po.poNumber}</strong>
                      <div className="text-[10px] text-[#88929e] mt-1">
                        Buyer: <strong className="text-white">{po.buyerName}</strong> | Supplier: {po.supplierName}
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={`text-[10px] font-bold px-2 py-0.5 tracking-wider uppercase border ${
                        po.status === "CREATED" ? "bg-amber-950 border-amber-800 text-amber-500" :
                        po.status === "APPROVED" ? "bg-emerald-950 border-emerald-800 text-emerald-400" :
                        po.status === "IN_TRANSIT" ? "bg-blue-950 border-blue-800 text-blue-400" :
                        "bg-[#161a22] border-gray-800 text-[#88929e]"
                      }`}>
                        {po.status}
                      </span>
                      <strong className="text-white block mt-1.5">${po.amount.toLocaleString()}</strong>
                    </div>
                  </div>

                  {/* Items list */}
                  <div className="bg-[#13161c] p-2.5 border border-[#1a1f26] space-y-1 text-[11px] text-[#88929e]">
                    {po.items.map((itm, i) => (
                      <div key={i} className="flex justify-between">
                        <span>{itm.name} (x{itm.qty})</span>
                        <span className="text-white">${(itm.qty * itm.price).toLocaleString()}</span>
                      </div>
                    ))}
                  </div>

                  {/* Actions */}
                  {po.status === "CREATED" && (
                    <div className="flex justify-end pt-2 border-t border-[#1a1f26]">
                      <button
                        onClick={() => onApprovePO(po.id)}
                        className="bg-white hover:bg-opacity-90 text-black px-4 py-1 font-bold text-[10px] uppercase flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Approve Purchase Order</span>
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* INVOICES PIPELINE TAB */}
      {activeSubTab === "invoices" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Create Invoice Form (5 cols) */}
          <div className="lg:col-span-5 bg-[#111418] border border-[#222831] p-6 h-fit">
            <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-4">Digitize Trade Invoice</h3>
            <form onSubmit={handleCreateInvoice} className="space-y-4 font-mono text-xs">
              
              <div className="space-y-1">
                <label className="text-[#88929e] text-[10px] uppercase">Select Approved Buyer PO</label>
                <select
                  value={invPoId}
                  onChange={e => setInvPoId(e.target.value)}
                  required
                  className="w-full bg-[#161a22] border border-[#222831] text-white p-2.5 font-mono"
                >
                  <option value="">Select Approved PO...</option>
                  {purchaseOrders
                    .filter(p => p.status === "APPROVED" || p.status === "DELIVERED")
                    .map(p => (
                      <option key={p.id} value={p.id}>
                        {p.poNumber} - {p.supplierName} (${p.amount.toLocaleString()})
                      </option>
                    ))
                  }
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[#88929e] text-[10px] uppercase">Invoice Serial Ref</label>
                  <input 
                    type="text" 
                    value={invNum} 
                    onChange={e => setInvNum(e.target.value)}
                    placeholder="e.g. INV-2026-9901"
                    required
                    className="w-full bg-[#161a22] border border-[#222831] text-white p-2.5 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[#88929e] text-[10px] uppercase">Due Date</label>
                  <input 
                    type="date" 
                    value={invDueDate} 
                    onChange={e => setInvDueDate(e.target.value)}
                    required
                    className="w-full bg-[#161a22] border border-[#222831] text-white p-2.5 font-mono"
                  />
                </div>
              </div>

              {invPoId && (
                <div className="bg-[#161a22] p-3 border border-[#222831] flex justify-between font-bold">
                  <span className="text-[#88929e]">Invoice Amount (PO Locked):</span>
                  <span className="text-white">
                    ${(purchaseOrders.find(p => p.id === invPoId)?.amount || 0).toLocaleString()}
                  </span>
                </div>
              )}

              <button 
                type="submit" 
                className="w-full bg-white hover:bg-opacity-90 text-black p-3 font-bold uppercase transition"
              >
                Incorporate Digital Trade Invoice
              </button>
            </form>
          </div>

          {/* Active Invoices List (7 cols) */}
          <div className="lg:col-span-7 bg-[#111418] border border-[#222831] p-6">
            <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-4 font-bold">Invoices pipeline registry</h3>
            <div className="space-y-4">
              {invoices.map(inv => (
                <div key={inv.id} className="border border-[#222831] bg-[#0c0e12] p-4 space-y-3.5 text-xs font-mono">
                  <div className="flex justify-between items-start">
                    <div>
                      <strong className="text-white text-sm">{inv.invoiceNumber}</strong>
                      <div className="text-[10px] text-[#88929e] mt-1">
                        PO Linked: <strong className="text-white">{inv.poNumber}</strong> | Supplier: {inv.supplierName}
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={`text-[10px] font-bold px-2.5 py-1 tracking-wider uppercase border ${
                        inv.status === "DRAFT" ? "bg-amber-950 border-amber-800 text-amber-500" :
                        inv.status === "APPROVED" ? "bg-emerald-950 border-emerald-800 text-emerald-400" :
                        inv.status === "FINANCED" ? "bg-blue-950 border-blue-800 text-blue-400" :
                        inv.status === "SETTLED" ? "bg-white text-black" :
                        "bg-[#161a22] text-[#88929e]"
                      }`}>
                        {inv.status}
                      </span>
                      <strong className="text-white block mt-1.5">${inv.amount.toLocaleString()}</strong>
                    </div>
                  </div>

                  <div className="flex justify-between text-[11px] font-mono text-[#88929e]">
                    <span>Buyer Client: <strong className="text-white">{inv.buyerName}</strong></span>
                    <span>Payment Due Date: <strong className="text-white">{new Date(inv.dueDate).toLocaleDateString()}</strong></span>
                  </div>

                  {/* Actions based on invoice state */}
                  <div className="flex justify-end gap-2.5 pt-2 border-t border-[#1a1f26]">
                    {inv.status === "DRAFT" && (
                      <button
                        onClick={() => onApproveInvoice(inv.id)}
                        className="bg-white hover:bg-opacity-90 text-black px-4 py-1.5 font-bold text-[10px] uppercase flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Approve Accounts Payable</span>
                      </button>
                    )}

                    {/* Settle Invoice directly */}
                    {(inv.status === "APPROVED" || inv.status === "FINANCED") && (
                      <button
                        onClick={() => onSettleInvoice(inv.id)}
                        className="bg-emerald-500 hover:bg-emerald-600 text-black px-4 py-1.5 font-bold text-[10px] uppercase flex items-center gap-1"
                      >
                        <DollarSign className="w-3.5 h-3.5" />
                        <span>Settle & Execute Payment</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
