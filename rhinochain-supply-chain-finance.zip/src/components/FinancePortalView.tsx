import React, { useState } from "react";
import { 
  Layers, 
  HelpCircle, 
  ShieldAlert, 
  ChevronRight, 
  Loader2, 
  CheckCircle, 
  FileText, 
  AlertCircle,
  TrendingDown
} from "lucide-react";
import { Supplier, Buyer, Invoice, PurchaseOrder, FinanceApplication, FinanceType } from "../types";

interface FinancePortalViewProps {
  suppliers: Supplier[];
  buyers: Buyer[];
  invoices: Invoice[];
  purchaseOrders: PurchaseOrder[];
  financeApplications: FinanceApplication[];
  onApplyFinancing: (data: { type: FinanceType; entityId: string; applicantId: string; amount: number; rate: number }) => Promise<void>;
  onTriggerAudit: (id: string) => Promise<void>;
  onFundApplication: (id: string) => Promise<void>;
}

export default function FinancePortalView({
  suppliers,
  buyers,
  invoices,
  purchaseOrders,
  financeApplications,
  onApplyFinancing,
  onTriggerAudit,
  onFundApplication
}: FinancePortalViewProps) {
  
  // App states
  const [selectedType, setSelectedType] = useState<FinanceType>("INVOICE_FINANCING");
  const [selectedApplicant, setSelectedApplicant] = useState("");
  const [selectedDocument, setSelectedDocument] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [auditingId, setAuditingId] = useState<string | null>(null);
  const [fundingId, setFundingId] = useState<string | null>(null);

  // Filter documents based on financing type
  const getEligibleDocuments = () => {
    if (selectedType === "INVOICE_FINANCING") {
      return invoices.filter(i => i.status === "APPROVED" || i.status === "DRAFT");
    } else if (selectedType === "PO_FINANCING") {
      return purchaseOrders.filter(p => p.status === "APPROVED" || p.status === "CREATED");
    }
    return [];
  };

  const getDocumentAmount = () => {
    if (selectedType === "INVOICE_FINANCING") {
      const inv = invoices.find(i => i.id === selectedDocument);
      return inv ? inv.amount : 0;
    } else if (selectedType === "PO_FINANCING") {
      const po = purchaseOrders.find(p => p.id === selectedDocument);
      return po ? po.amount : 0;
    }
    return 0;
  };

  const calculateProposedRate = () => {
    // Basic dynamic pricing logic based on trade type
    switch (selectedType) {
      case "INVOICE_FINANCING": return 3.75;
      case "PO_FINANCING": return 4.25;
      case "APPROVED_PAYABLES": return 2.95;
      case "INVENTORY_FINANCE": return 5.15;
      case "DYNAMIC_DISCOUNTING": return 2.50;
      default: return 3.50;
    }
  };

  const handleApply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedApplicant || !selectedDocument) return;

    setIsSubmitting(true);
    try {
      const amt = getDocumentAmount();
      const rate = calculateProposedRate();
      await onApplyFinancing({
        type: selectedType,
        entityId: selectedDocument,
        applicantId: selectedApplicant,
        amount: amt,
        rate
      });
      setSelectedDocument("");
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAudit = async (id: string) => {
    setAuditingId(id);
    try {
      await onTriggerAudit(id);
    } catch (err) {
      console.error(err);
    } finally {
      setAuditingId(null);
    }
  };

  const handleFund = async (id: string) => {
    setFundingId(id);
    try {
      await onFundApplication(id);
    } catch (err) {
      console.error(err);
    } finally {
      setFundingId(null);
    }
  };

  return (
    <div id="finance-portal-view" className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      
      {/* Financing Application Desk (5 columns) */}
      <div className="lg:col-span-5 bg-[#111418] border border-[#222831] p-6 h-fit">
        <div className="flex items-center gap-2 mb-6 pb-4 border-b border-[#222831]">
          <Layers className="w-5 h-5 text-white" />
          <h3 className="text-white text-sm font-mono font-bold uppercase tracking-wider">SCF Underwriting Console</h3>
        </div>

        <form onSubmit={handleApply} className="space-y-5 font-mono text-xs">
          
          {/* Workflow selection */}
          <div className="space-y-1.5">
            <label className="text-[#88929e] font-bold text-[10px] uppercase">SCF Financing Structure</label>
            <select
              value={selectedType}
              onChange={(e) => {
                setSelectedType(e.target.value as FinanceType);
                setSelectedDocument("");
              }}
              className="w-full bg-[#161a22] border border-[#222831] text-white p-3 font-mono focus:outline-none focus:border-[#58636e]"
            >
              <option value="INVOICE_FINANCING">Approved Invoice Financing (Receivables)</option>
              <option value="PO_FINANCING">Purchase Order Underwriting (Pre-Shipment)</option>
              <option value="APPROVED_PAYABLES">Reverse Factoring (Approved Payables)</option>
              <option value="INVENTORY_FINANCE">Secured Warehouse Inventory Underwriting</option>
              <option value="DYNAMIC_DISCOUNTING">Dynamic Discount Financing (Early Settled)</option>
            </select>
          </div>

          {/* Applicant Selection */}
          <div className="space-y-1.5">
            <label className="text-[#88929e] font-bold text-[10px] uppercase">Onboarded Corporate Partner</label>
            <select
              value={selectedApplicant}
              onChange={(e) => setSelectedApplicant(e.target.value)}
              required
              className="w-full bg-[#161a22] border border-[#222831] text-white p-3 font-mono focus:outline-none focus:border-[#58636e]"
            >
              <option value="">Select Partner entity...</option>
              {suppliers.map(s => (
                <option key={s.id} value={s.id}>{s.name} ({s.industry} - Risk Rating: {s.riskScore})</option>
              ))}
            </select>
          </div>

          {/* Linked Commercial Asset */}
          <div className="space-y-1.5">
            <label className="text-[#88929e] font-bold text-[10px] uppercase">Select Trade Asset Ledger Ref</label>
            <select
              value={selectedDocument}
              onChange={(e) => setSelectedDocument(e.target.value)}
              required
              disabled={getEligibleDocuments().length === 0}
              className="w-full bg-[#161a22] border border-[#222831] text-white p-3 font-mono focus:outline-none focus:border-[#58636e] disabled:opacity-40"
            >
              <option value="">
                {getEligibleDocuments().length === 0 ? "No open eligible trade assets located" : "Select document reference..."}
              </option>
              {getEligibleDocuments().map(doc => {
                const isInv = selectedType === "INVOICE_FINANCING";
                const num = isInv ? (doc as Invoice).invoiceNumber : (doc as PurchaseOrder).poNumber;
                return (
                  <option key={doc.id} value={doc.id}>
                    {num} - ${doc.amount.toLocaleString()} ({doc.status})
                  </option>
                );
              })}
            </select>
          </div>

          {/* Live Calculated Quote terms */}
          {selectedDocument && (
            <div className="bg-[#161a22] border border-[#222831] p-4 space-y-2.5">
              <div className="text-[10px] text-[#88929e] border-b border-[#222831] pb-1 font-bold uppercase tracking-wider">
                Dynamic Financing terms
              </div>
              <div className="flex justify-between">
                <span className="text-[#88929e]">Asset Principal:</span>
                <span className="text-white font-bold">${getDocumentAmount().toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#88929e]">Interest Rate Indicator:</span>
                <span className="text-emerald-500 font-bold">{calculateProposedRate()}% p.a (SOFR Linked)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#88929e]">Platform Underwriting Fee:</span>
                <span className="text-white">0.25%</span>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting || !selectedApplicant || !selectedDocument}
            className="w-full bg-white hover:bg-opacity-90 disabled:bg-opacity-20 text-black font-bold uppercase p-3 transition duration-150 flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Transmitting Proposal...</span>
              </>
            ) : (
              <span>Submit Financing Application</span>
            )}
          </button>
        </form>
      </div>

      {/* active Applications Workspace (7 columns) */}
      <div className="lg:col-span-7 space-y-6">
        
        {/* Active applications list */}
        <div className="bg-[#111418] border border-[#222831] p-6">
          <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-4">Underwriting Ledger</h3>

          {financeApplications.length === 0 ? (
            <div className="text-center py-12 border border-dashed border-[#222831]">
              <p className="text-[#88929e] text-xs font-mono">No SCF underwriting applications submitted yet.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {financeApplications.map((app) => (
                <div key={app.id} className="border border-[#222831] p-4 bg-[#0c0e12] space-y-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-mono font-bold text-sm">{app.id.toUpperCase()}</span>
                        <span className="text-[10px] font-mono bg-[#1d232c] text-[#88929e] px-2 py-0.5 uppercase">
                          {app.type.replace("_", " ")}
                        </span>
                      </div>
                      <p className="text-xs text-[#88929e] font-mono mt-1">
                        Applicant: <strong className="text-white">{app.applicantName}</strong> | Buyer: {app.counterpartyName}
                      </p>
                    </div>
                    
                    {/* Status badges */}
                    <div className="text-right">
                      <span className={`text-[10px] font-mono font-bold px-2.5 py-1 tracking-wider ${
                        app.status === "PENDING" ? "bg-amber-950 border border-amber-800 text-amber-500" :
                        app.status === "UNDER_AUDIT" ? "bg-blue-950 border border-blue-800 text-blue-400 animate-pulse" :
                        app.status === "APPROVED" ? "bg-emerald-950 border border-emerald-800 text-emerald-400" :
                        app.status === "FUNDED" ? "bg-[#ffffff] text-black" :
                        "bg-[#161a22] text-[#88929e]"
                      }`}>
                        {app.status}
                      </span>
                      <span className="text-[10px] text-[#88929e] block mt-1 font-mono">${app.amount.toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Audit Actions & Risk reports */}
                  <div className="border-t border-[#222831] pt-3.5 space-y-3">
                    
                    {/* Trigger audit checks */}
                    {app.status === "PENDING" && (
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-[#13161c] p-3 border border-[#222831]">
                        <div className="flex items-center gap-2">
                          <ShieldAlert className="w-4 h-4 text-amber-500" />
                          <span className="text-[11px] font-mono text-[#88929e]">Smart compliance analysis & underwriting check required.</span>
                        </div>
                        <button
                          onClick={() => handleAudit(app.id)}
                          disabled={auditingId !== null}
                          className="bg-white hover:bg-opacity-90 text-black px-4 py-1.5 font-bold font-mono text-[11px] uppercase flex items-center gap-1.5"
                        >
                          {auditingId === app.id ? (
                            <>
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              <span>Running Compliance Audit...</span>
                            </>
                          ) : (
                            <span>Run AI Compliance Audit</span>
                          )}
                        </button>
                      </div>
                    )}

                    {/* Pending Release Capital */}
                    {app.status === "APPROVED" && (
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-[#13161c] p-3 border border-[#222831]">
                        <div>
                          <div className="flex items-center gap-2 text-emerald-400">
                            <CheckCircle className="w-4 h-4" />
                            <span className="text-[11px] font-mono font-bold uppercase">Clearance Check Complete</span>
                          </div>
                          <span className="text-[10px] text-[#88929e] block mt-0.5 font-mono">
                            Risk Rating: <strong className="text-white">{app.riskScore}/100</strong> (Audited via {app.auditedBy})
                          </span>
                        </div>
                        <button
                          onClick={() => handleFund(app.id)}
                          disabled={fundingId !== null}
                          className="bg-emerald-500 hover:bg-emerald-600 text-black px-4 py-1.5 font-bold font-mono text-[11px] uppercase flex items-center gap-1.5"
                        >
                          {fundingId === app.id ? (
                            <>
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              <span>Releasing Funds...</span>
                            </>
                          ) : (
                            <span>Release Liquidity Funds</span>
                          )}
                        </button>
                      </div>
                    )}

                    {/* Funded Confirmation */}
                    {app.status === "FUNDED" && (
                      <div className="bg-[#13161c] p-3 border border-[#222831] flex items-center gap-2 text-emerald-400 text-[11px] font-mono">
                        <CheckCircle className="w-4 h-4" />
                        <span>Working capital released. Transacted via RTGS Gateway block #{Math.floor(Math.random() * 1000) + 500}.</span>
                      </div>
                    )}

                    {/* Repaid Confirmation */}
                    {app.status === "REPAID" && (
                      <div className="bg-[#13161c] p-3 border border-[#222831] flex items-center gap-2 text-[#88929e] text-[11px] font-mono">
                        <CheckCircle className="w-4 h-4" />
                        <span>Financing loan fully repaid. Collateral boundaries restored.</span>
                      </div>
                    )}

                    {/* Show Audit Risk Breakdown (Gemini Markdown) */}
                    {app.riskAnalysis && (
                      <div className="bg-[#111418] border border-[#222831] p-4 text-[11px] font-mono text-[#a3b1c2] leading-relaxed max-h-60 overflow-y-auto space-y-2.5">
                        <div className="text-white font-bold border-b border-[#222831] pb-1 text-[10px] uppercase tracking-wider">
                          Compliance Risk Analysis & Credit Underwriting Report
                        </div>
                        <div className="whitespace-pre-line text-xs font-mono markdown-body">
                          {app.riskAnalysis}
                        </div>
                      </div>
                    )}

                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
