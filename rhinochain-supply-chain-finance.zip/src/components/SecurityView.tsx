import React, { useState } from "react";
import { 
  ShieldAlert, 
  Key, 
  Lock, 
  Server, 
  Hash, 
  RefreshCw, 
  CheckCircle2, 
  Info 
} from "lucide-react";
import { AuditLog } from "../types";

interface SecurityViewProps {
  auditLogs: AuditLog[];
}

export default function SecurityView({ auditLogs }: SecurityViewProps) {
  
  // States
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);

  return (
    <div id="security-view" className="space-y-6">
      
      {/* Platform Security Badges */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        <div className="bg-[#111418] border border-[#222831] p-5 flex gap-4 items-start">
          <div className="p-2.5 bg-[#161a22] border border-[#222831] text-emerald-400">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-white text-xs font-mono font-bold uppercase tracking-wider">AES-256 GCM Storage</h4>
            <p className="text-[#88929e] text-[11px] font-mono leading-relaxed mt-1">
              Platform transaction records, bank profiles, and invoices are encrypted at rest with keys rotated via envelope KMS.
            </p>
          </div>
        </div>

        <div className="bg-[#111418] border border-[#222831] p-5 flex gap-4 items-start">
          <div className="p-2.5 bg-[#161a22] border border-[#222831] text-emerald-400">
            <Key className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-white text-xs font-mono font-bold uppercase tracking-wider">MFA & RBAC Mandate</h4>
            <p className="text-[#88929e] text-[11px] font-mono leading-relaxed mt-1">
              Role-based authorization limits treasury access. Digital signature verification enforced via client-side keys.
            </p>
          </div>
        </div>

        <div className="bg-[#111418] border border-[#222831] p-5 flex gap-4 items-start">
          <div className="p-2.5 bg-[#161a22] border border-[#222831] text-emerald-400">
            <Hash className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-white text-xs font-mono font-bold uppercase tracking-wider">Cryptographic Chaining</h4>
            <p className="text-[#88929e] text-[11px] font-mono leading-relaxed mt-1">
              Every system state mutation computes a cryptographic checksum hash chained directly to the preceding block.
            </p>
          </div>
        </div>

      </div>

      {/* Immutable Ledger Block Explorer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Logs Listing (8 columns) */}
        <div className="lg:col-span-8 bg-[#111418] border border-[#222831] p-6">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider">Immutable Transaction Ledger</h3>
              <p className="text-[#88929e] text-[11px] font-mono mt-0.5">SHA-256 chained transaction blocks verified via decentralized nodes</p>
            </div>
            <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> SECURED_STATE
            </span>
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {auditLogs.map((log) => (
              <div 
                key={log.id} 
                onClick={() => setSelectedLog(log)}
                className={`border p-3.5 transition cursor-pointer flex justify-between items-center ${
                  selectedLog?.id === log.id 
                    ? "bg-[#1d232c] border-white text-white" 
                    : "bg-[#0c0e12] border-[#222831] text-[#88929e] hover:bg-[#13161c]"
                }`}
              >
                <div className="font-mono text-xs space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[#88929e] font-bold">Block ID:</span>
                    <span className="text-white font-mono font-bold">{log.id}</span>
                    <span className="text-[9px] bg-[#161a22] text-[#88929e] px-1.5 py-0.5 uppercase">
                      {log.service.replace("-service", "")}
                    </span>
                  </div>
                  <div className="text-[11px]">
                    EVENT: <strong className="text-white">{log.event}</strong>
                  </div>
                  <div className="text-[10px] text-[#58636e] font-mono truncate max-w-lg">
                    Chaining Hash: {log.blockHash}
                  </div>
                </div>
                
                <span className="text-[10px] font-mono text-[#58636e]">
                  {new Date(log.timestamp).toLocaleTimeString()}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Cryptographic Verification Panel (4 columns) */}
        <div className="lg:col-span-4 bg-[#111418] border border-[#222831] p-6 flex flex-col justify-between">
          <div>
            <h3 className="text-white text-xs font-mono font-bold uppercase tracking-wider mb-4">Cryptographic Proofs</h3>

            {selectedLog ? (
              <div className="space-y-4 font-mono text-xs">
                
                <div className="space-y-1">
                  <span className="text-[#88929e] text-[10px] uppercase font-bold">Transaction Reference</span>
                  <div className="bg-[#161a22] border border-[#222831] p-2 text-white">
                    {selectedLog.id}
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[#88929e] text-[10px] uppercase font-bold">Trigger Actor</span>
                  <div className="bg-[#161a22] border border-[#222831] p-2 text-white">
                    {selectedLog.actor}
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[#88929e] text-[10px] uppercase font-bold">Chaining Ledger Hash (Block Link)</span>
                  <div className="bg-[#161a22] border border-[#222831] p-2 text-white break-all text-[11px] leading-relaxed">
                    {selectedLog.blockHash}
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[#88929e] text-[10px] uppercase font-bold">HMAC Signature</span>
                  <div className="bg-[#161a22] border border-[#222831] p-2 text-white break-all text-[10px] leading-tight font-bold text-emerald-400">
                    {selectedLog.signature}
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[#88929e] text-[10px] uppercase font-bold">Emitted Data Payload</span>
                  <pre className="bg-[#0c0e12] border border-[#222831] p-2.5 text-[10px] text-white overflow-x-auto whitespace-pre-wrap max-h-36 leading-relaxed">
                    {JSON.stringify(JSON.parse(selectedLog.details), null, 2)}
                  </pre>
                </div>

              </div>
            ) : (
              <div className="text-center py-20 border border-dashed border-[#222831] flex flex-col items-center justify-center">
                <Info className="w-8 h-8 text-[#58636e] mb-2" />
                <p className="text-[#88929e] text-xs font-mono max-w-[180px] mx-auto leading-relaxed">
                  Select a ledger transaction block to verify cryptographic proofs.
                </p>
              </div>
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-[#222831] text-[10px] font-mono text-[#58636e] space-y-1">
            <div>CONSENSUS PROTOCOL: PoA (Proof of Authority)</div>
            <div>SIGNING STANDARD: HMAC-SHA256</div>
            <div>BLOCK BLOCKING TIME: Instantaneous / Event-driven</div>
          </div>
        </div>

      </div>

    </div>
  );
}
