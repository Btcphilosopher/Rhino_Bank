/**
 * RhinoQuant DERIVATIVE/Securities PACKAGING .OS
 * Core Domain Types & Quantitative Specifications
 */

export type AssetClass = 'RATES' | 'EQUITY' | 'ENERGY' | 'METALS' | 'FX' | 'AGS';

export interface FuturesContract {
  symbol: string;
  name: string;
  assetClass: AssetClass;
  exchange: string;
  currency: string;
  multiplier: number; // e.g. 2500 for SOFR (1M/100*2500), 1000 for WTI, 50 for S&P
  tickSize: number;
  tickValue: number;
  price: number;
  change24h: number;
  changePct24h: number;
  impliedVol: number; // e.g., 0.18 for 18%
  dv01PerContract: number; // $ per 1bp move
  expirationDate: string;
  volume: number;
  openInterest: number;
  bid: number;
  ask: number;
}

export type LegSide = 'BUY' | 'SELL';

export interface PackageLeg {
  legId: string;
  contractSymbol: string;
  contractName: string;
  assetClass: AssetClass;
  side: LegSide;
  quantity: number;
  weight: number; // Normalized weight (-1.0 to +1.0)
  ratio: number;
  notional: number; // Calculated USD Notional
  currency: string;
  expiry: string;
  isNestedPackage?: boolean;
  nestedPackageId?: string;
}

export interface Layer {
  layerId: string;
  name: string;
  inputs: string[]; // contract symbols or lower layer IDs
  transformation: 'IDENTITY' | 'SPREAD' | 'BUTTERFLY' | 'WEIGHTED_BASKET' | 'STRIP' | 'CUSTOM';
  weight: number;
  outputFormula: string;
  riskContributionPct: number;
}

export interface Stack {
  stackId: string;
  name: string;
  assetClass: AssetClass;
  contracts: string[]; // e.g. ['SR3_Z6', 'SR3_H7', 'SR3_M7', 'SR3_U7']
  weights: number[];
  totalNotional: number;
  rollProfile: 'CALENDAR' | 'VOLUME' | 'OPEN_INTEREST' | 'LIQUIDITY';
}

export type WeightingMethod =
  | 'EQUAL_WEIGHT'
  | 'NOTIONAL_WEIGHT'
  | 'VOLATILITY_WEIGHT'
  | 'INVERSE_VOLATILITY'
  | 'RISK_PARITY'
  | 'DV01_NEUTRAL'
  | 'DELTA_NEUTRAL'
  | 'CUSTOM';

export type PayoffType =
  | 'LINEAR'
  | 'PARTICIPATION'
  | 'CAPPED'
  | 'FLOORED'
  | 'COLLAR'
  | 'DIGITAL'
  | 'BARRIER'
  | 'RANGE_ACCURAL'
  | 'CUSTOM_DSL';

export interface PayoffDefinition {
  type: PayoffType;
  participationRate: number; // e.g. 1.0 (100%)
  cap?: number; // e.g. 0.15 (+15%)
  floor?: number; // e.g. -0.05 (-5%)
  barrierLevel?: number; // e.g. 80.0
  barrierType?: 'KNOCK_OUT' | 'KNOCK_IN';
  couponRate?: number; // e.g. 0.08 (8% p.a.)
  dslCode: string; // Payoff DSL snippet
  description: string;
}

export type ValuationMethod = 'MARK_TO_MARKET' | 'MONTE_CARLO' | 'BLACK_SCHOLES' | 'DISCOUNTED_CASH_FLOW';

export type HedgePolicy = 'DELTA_NEUTRAL' | 'DV01_NEUTRAL' | 'VEGA_HEDGE' | 'DYNAMIC_THRESHOLD' | 'CUSTOM';

export type ProductLifecycle =
  | 'DRAFT'
  | 'VALIDATED'
  | 'PRICED'
  | 'RISK_APPROVED'
  | 'DOCUMENTED'
  | 'ISSUABLE'
  | 'ISSUED'
  | 'ACTIVE'
  | 'REBALANCING'
  | 'MATURING'
  | 'REDEEMED'
  | 'CLOSED';

export interface RebalanceRule {
  frequency: 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'QUARTERLY' | 'THRESHOLD' | 'MANUAL';
  thresholdPct?: number; // e.g. 5%
  lastRebalanceDate?: string;
}

export interface RollSchedule {
  rollMethod: 'CALENDAR' | 'VOLUME' | 'OPEN_INTEREST' | 'LIQUIDITY';
  rollWindowDays: number;
  rollDate: string;
  estimatedRollCostUsd: number;
}

export interface DerivativePackage {
  packageId: string;
  name: string;
  description: string;
  currency: string;
  legs: PackageLeg[];
  layers: Layer[];
  stacks: Stack[];
  weightingMethod: WeightingMethod;
  payoff: PayoffDefinition;
  valuationMethod: ValuationMethod;
  hedgePolicy: HedgePolicy;
  lifecycle: ProductLifecycle;
  rebalanceRule: RebalanceRule;
  rollSchedule: RollSchedule;
  canonicalHash: string;
  createdAt: string;
  updatedAt: string;
}

export interface IssuerCredit {
  issuerName: string;
  rating: 'AAA' | 'AA+' | 'AA' | 'A+' | 'A' | 'BBB+' | 'BBB';
  creditSpreadBps: number;
  defaultProbabilityPct: number;
  recoveryRatePct: number;
  fundingCurveRatePct: number;
}

export interface CashFlow {
  id: string;
  date: string;
  type: 'COUPON' | 'PRINCIPAL' | 'REDEMPTION' | 'FEE' | 'MARGIN';
  amount: number;
  currency: string;
  condition: string;
  status: 'PENDING' | 'SETTLED' | 'CANCELLED';
}

export type ProductClassification =
  | 'DERIVATIVE'
  | 'FUTURES_STRATEGY'
  | 'INDEX'
  | 'STRUCTURED_SECURITY'
  | 'STRUCTURED_NOTE'
  | 'CERTIFICATE'
  | 'OTC_DERIVATIVE'
  | 'EXCHANGE_TRADED_PRODUCT';

export interface StructuredSecurity {
  productId: string;
  version: string;
  name: string;
  currency: string;
  issueDate: string;
  maturityDate: string;
  denominationUsd: number;
  totalNotionalIssuedUsd: number;
  outstandingNotionalUsd: number;
  referencePackageId: string;
  referencePackageName: string;
  payoff: PayoffDefinition;
  coupon: {
    type: 'FIXED' | 'FLOATING' | 'PERFORMANCE' | 'BARRIER' | 'DIGITAL';
    ratePct: number;
    frequency: 'QUARTERLY' | 'SEMI_ANNUAL' | 'ANNUAL' | 'AT_MATURITY';
  };
  principalProtectionPct: number; // e.g. 100 for 100% principal protected
  issuerCredit: IssuerCredit;
  classification: ProductClassification;
  lifecycleStatus: ProductLifecycle;
  feesPct: number;
  canonicalHash: string;
  payoffHash: string;
  packageHash: string;
  createdAt: string;
  history: Array<{
    version: string;
    changedAt: string;
    changedBy: string;
    reason: string;
    changesSummary: string;
  }>;
}

export interface RiskMetrics {
  deltaUsd: number;
  gammaUsd: number;
  vegaUsd: number;
  thetaUsd: number;
  dv01Usd: number;
  durationYears: number;
  grossNotionalUsd: number;
  netNotionalUsd: number;
  leverageRatio: number;
  marginRequirementUsd: number;
  liquidityScore: number; // 0-100
  assetClassExposures: Record<AssetClass, number>;
}

export interface ScenarioResult {
  scenarioName: string;
  ratesShiftBps: number;
  equityShiftPct: number;
  commodityShiftPct: number;
  fxShiftPct: number;
  volShiftPts: number;
  currentValueUsd: number;
  scenarioValueUsd: number;
  pnlUsd: number;
  pnlPct: number;
}

export interface CalculationStep {
  stepId: string;
  label: string;
  formula: string;
  inputs: Record<string, number | string>;
  resultValue: number;
  explanation: string;
  subSteps?: CalculationStep[];
}

export interface ValuationBreakdown {
  packageId: string;
  timestamp: string;
  theoreticalValueUsd: number;
  fairValueUsd: number;
  bidPriceUsd: number;
  askPriceUsd: number;
  executionCostUsd: number;
  hedgingCostUsd: number;
  fundingCostUsd: number;
  navPerUnitUsd: number;
  calculationTree: CalculationStep;
}

export interface HedgeOrder {
  orderId: string;
  contractSymbol: string;
  side: LegSide;
  quantity: number;
  targetRatio: number;
  limitPrice: number;
  expectedCostUsd: number;
  status: 'PROPOSED' | 'SUBMITTED' | 'FILLED' | 'CANCELLED';
  filledQuantity?: number;
  avgFillPrice?: number;
}

export interface HedgeBook {
  productId: string;
  generatedAt: string;
  policy: HedgePolicy;
  orders: HedgeOrder[];
  totalHedgeCostUsd: number;
  residualDeltaUsd: number;
  residualDv01Usd: number;
  hedgedRatioPct: number;
}

export interface RFQRequest {
  rfqId: string;
  clientName: string;
  productId?: string;
  packageId?: string;
  notionalUsd: number;
  side: 'BUY' | 'SELL';
  currency: string;
  requestedMaturity: string;
  status: 'PENDING' | 'QUOTED' | 'ACCEPTED' | 'EXPIRED' | 'REJECTED';
  createdAt: string;
  quoteExpirySeconds: number;
  quotedPrice?: number;
  fairValue?: number;
  quoteId?: string;
}

export interface EventLogItem {
  id: string;
  timestamp: string;
  type:
    | 'PackageCreated'
    | 'PackageModified'
    | 'PackageValidated'
    | 'PackagePriced'
    | 'ProductCreated'
    | 'ProductIssued'
    | 'ProductRebalanced'
    | 'ProductHedged'
    | 'ProductRedeemed'
    | 'ModelValidated';
  entityId: string;
  entityName: string;
  operator: string;
  details: string;
  hash: string;
}
