import React, { useState, useEffect } from 'react';
import { Navbar, TabType } from './components/Navbar';
import { MarketTerminal } from './components/MarketTerminal';
import { StructuringWorkbench } from './components/StructuringWorkbench';
import { PackagesView } from './components/PackagesView';
import { ProductsView } from './components/ProductsView';
import { PricingNavView } from './components/PricingNavView';
import { RiskScenarioView } from './components/RiskScenarioView';
import { HedgeExecutionView } from './components/HedgeExecutionView';
import { RfqMarketMakerView } from './components/RfqMarketMakerView';
import { AuditGovernanceView } from './components/AuditGovernanceView';
import { CalculationExplorerModal } from './components/CalculationExplorerModal';

import {
  INITIAL_FUTURES_CONTRACTS,
  SIGNATURE_PACKAGES,
  SIGNATURE_PRODUCTS,
  INITIAL_AUDIT_LOGS,
} from './services/marketData';
import { buildValuationBreakdown } from './services/quantEngine';
import {
  FuturesContract,
  DerivativePackage,
  StructuredSecurity,
  EventLogItem,
  CalculationStep,
} from './types/rhino';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('STRUCTURE');
  const [isStreaming, setIsStreaming] = useState<boolean>(true);

  // Core Data Stores
  const [contracts, setContracts] = useState<FuturesContract[]>(INITIAL_FUTURES_CONTRACTS);
  const [packages, setPackages] = useState<DerivativePackage[]>(SIGNATURE_PACKAGES);
  const [products, setProducts] = useState<StructuredSecurity[]>(SIGNATURE_PRODUCTS);
  const [auditLogs, setAuditLogs] = useState<EventLogItem[]>(INITIAL_AUDIT_LOGS);

  // Calculation Explorer Modal State
  const [isExplorerOpen, setIsExplorerOpen] = useState<boolean>(false);
  const [explorerRootStep, setExplorerRootStep] = useState<CalculationStep | null>(null);

  // Map derived state for performance
  const contractsMap: Record<string, FuturesContract> = {};
  contracts.forEach((c) => (contractsMap[c.symbol] = c));

  const allPackagesMap: Record<string, DerivativePackage> = {};
  packages.forEach((p) => (allPackagesMap[p.packageId] = p));

  // Live market streaming simulation
  useEffect(() => {
    if (!isStreaming) return;
    const interval = setInterval(() => {
      setContracts((prev) =>
        prev.map((c) => {
          const delta = (Math.random() - 0.495) * (c.tickSize * 4);
          const newPrice = Math.max(0.01, c.price + delta);
          const change = newPrice - (c.price - c.change24h);
          return {
            ...c,
            price: newPrice,
            bid: newPrice - c.tickSize,
            ask: newPrice + c.tickSize,
            change24h: change,
            changePct24h: (change / newPrice) * 100,
          };
        })
      );
    }, 2500);

    return () => clearInterval(interval);
  }, [isStreaming]);

  // Handle Save Package
  const handleSavePackage = (newPkg: DerivativePackage) => {
    setPackages((prev) => {
      const idx = prev.findIndex((p) => p.packageId === newPkg.packageId);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = newPkg;
        return copy;
      }
      return [newPkg, ...prev];
    });

    setAuditLogs((prev) => [
      {
        id: `LOG-${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: 'PackageCreated',
        entityId: newPkg.packageId,
        entityName: newPkg.name,
        operator: 'Quant Structurer',
        details: `Saved derivative package specification with ${newPkg.legs.length} legs.`,
        hash: `SHA256:${Math.random().toString(16).substring(2, 10).toUpperCase()}`,
      },
      ...prev,
    ]);
  };

  // Handle Issue Product
  const handleIssueProduct = (newProduct: StructuredSecurity) => {
    setProducts((prev) => [newProduct, ...prev]);

    setAuditLogs((prev) => [
      {
        id: `LOG-${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: 'ProductIssued',
        entityId: newProduct.productId,
        entityName: newProduct.name,
        operator: 'Issuer Desk Head',
        details: `Issued $${(newProduct.totalNotionalIssuedUsd / 1000000).toFixed(1)}M notional structured security under canonical hash ${newProduct.canonicalHash}`,
        hash: `SHA256:${Math.random().toString(16).substring(2, 10).toUpperCase()}`,
      },
      ...prev,
    ]);
  };

  // Open Calculation Explorer
  const handleOpenCalculationExplorer = (pkg: DerivativePackage) => {
    const valuation = buildValuationBreakdown(pkg, contractsMap);
    setExplorerRootStep(valuation.calculationTree);
    setIsExplorerOpen(true);
  };

  // Select Contract for Structuring Workbench
  const handleSelectContractForStructuring = (symbol: string) => {
    setActiveTab('STRUCTURE');
  };

  return (
    <div className="min-h-screen bg-[#080b11] text-slate-100 flex flex-col font-mono selection:bg-amber-500 selection:text-slate-950">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isStreaming={isStreaming}
        setIsStreaming={setIsStreaming}
        activeProductCount={products.length}
      />

      {/* Main Content View Switcher */}
      <main className="flex-1">
        {activeTab === 'MARKET' && (
          <MarketTerminal
            contracts={contracts}
            onSelectContractForStructuring={handleSelectContractForStructuring}
          />
        )}

        {activeTab === 'STRUCTURE' && (
          <StructuringWorkbench
            contractsMap={contractsMap}
            allPackages={packages}
            onSavePackage={handleSavePackage}
            onIssueProduct={handleIssueProduct}
            onOpenCalculationExplorer={handleOpenCalculationExplorer}
          />
        )}

        {activeTab === 'PACKAGES' && (
          <PackagesView
            packages={packages}
            allPackagesMap={allPackagesMap}
            contractsMap={contractsMap}
            onSelectPackageForWorkbench={(pkg) => setActiveTab('STRUCTURE')}
            onOpenCalculationExplorer={handleOpenCalculationExplorer}
          />
        )}

        {activeTab === 'PRODUCTS' && (
          <ProductsView
            products={products}
            onRedeemProduct={(id) => {
              setProducts((prev) =>
                prev.map((p) => (p.productId === id ? { ...p, lifecycleStatus: 'REDEEMED' } : p))
              );
            }}
          />
        )}

        {activeTab === 'PRICING' && (
          <PricingNavView
            packages={packages}
            contractsMap={contractsMap}
            onOpenCalculationExplorer={handleOpenCalculationExplorer}
          />
        )}

        {activeTab === 'RISK' && (
          <RiskScenarioView
            packages={packages}
            allPackagesMap={allPackagesMap}
            contractsMap={contractsMap}
          />
        )}

        {activeTab === 'HEDGE' && (
          <HedgeExecutionView
            products={products}
            packagesMap={allPackagesMap}
            contractsMap={contractsMap}
          />
        )}

        {activeTab === 'RFQ' && <RfqMarketMakerView products={products} />}

        {activeTab === 'AUDIT' && <AuditGovernanceView logs={auditLogs} />}
      </main>

      {/* Calculation Explorer Drill-down Modal */}
      {explorerRootStep && (
        <CalculationExplorerModal
          isOpen={isExplorerOpen}
          onClose={() => setIsExplorerOpen(false)}
          rootStep={explorerRootStep}
        />
      )}
    </div>
  );
}
