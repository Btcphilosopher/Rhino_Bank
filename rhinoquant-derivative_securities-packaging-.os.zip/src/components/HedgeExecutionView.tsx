import React, { useState } from 'react';
import { DerivativePackage, FuturesContract, StructuredSecurity, HedgeBook } from '../types/rhino';
import { calculateLookThroughRisk, generateHedgeBook } from '../services/quantEngine';
import { Repeat, CheckCircle, Zap, Activity, ArrowUpRight } from 'lucide-react';

interface HedgeExecutionViewProps {
  products: StructuredSecurity[];
  packagesMap: Record<string, DerivativePackage>;
  contractsMap: Record<string, FuturesContract>;
}

export const HedgeExecutionView: React.FC<HedgeExecutionViewProps> = ({
  products,
  packagesMap,
  contractsMap,
}) => {
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.productId || '');
  const activeProduct = products.find((p) => p.productId === selectedProductId) || products[0];

  const activePackage = activeProduct ? packagesMap[activeProduct.referencePackageId] : null;
  const risk = activePackage ? calculateLookThroughRisk(activePackage, packagesMap, contractsMap) : null;

  const initialHedgeBook: HedgeBook | null =
    activeProduct && activePackage && risk
      ? generateHedgeBook(activeProduct, activePackage, risk)
      : null;

  const [hedgeOrders, setHedgeOrders] = useState(initialHedgeBook?.orders || []);

  const handleExecuteOrder = (orderId: string) => {
    setHedgeOrders((prev) =>
      prev.map((o) =>
        o.orderId === orderId ? { ...o, status: 'FILLED', filledQuantity: o.quantity, avgFillPrice: o.limitPrice } : o
      )
    );
  };

  return (
    <div className="p-4 space-y-4 font-mono text-xs">
      {/* Banner */}
      <div className="flex items-center justify-between bg-[#0f141d] p-3 rounded-lg border border-slate-800">
        <div className="flex items-center gap-2">
          <Repeat className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-100 text-sm">RHINOQUANT EXECUTION.OS & DYNAMIC HEDGE DESK</span>
        </div>
        <div className="flex items-center gap-2">
          {products.map((p) => (
            <button
              key={p.productId}
              onClick={() => setSelectedProductId(p.productId)}
              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                selectedProductId === p.productId
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-900 text-slate-400 border border-slate-800'
              }`}
            >
              {p.productId}
            </button>
          ))}
        </div>
      </div>

      {activeProduct && initialHedgeBook && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Left Col: Hedge Requirement Summary */}
          <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-4 space-y-3">
            <span className="font-bold text-amber-400 text-xs block border-b border-slate-800 pb-2">
              HEDGE POLICY & RESIDUAL RISK MONITOR
            </span>

            <div className="space-y-2 text-xs">
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">PRODUCT TARGET</span>
                <span className="font-bold text-slate-200">{activeProduct.name}</span>
              </div>
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">DYNAMIC HEDGE POLICY</span>
                <span className="font-bold text-amber-400">{initialHedgeBook.policy}</span>
              </div>
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">ESTIMATED HEDGE EFFICIENCY</span>
                <span className="font-bold text-emerald-400">{initialHedgeBook.hedgedRatioPct}%</span>
              </div>
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">RESIDUAL UNHEDGED DV01</span>
                <span className="font-bold text-rose-300">${initialHedgeBook.residualDv01Usd.toFixed(2)} / bp</span>
              </div>
            </div>
          </div>

          {/* Right 2 Cols: EXECUTION.OS Order Book & Fill Monitor */}
          <div className="lg:col-span-2 bg-[#0f141d] border border-slate-800 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="font-bold text-amber-400 text-xs">ACTIONABLE FUTURES HEDGE ORDERS</span>
              <span className="text-[10px] text-slate-500">Connected to CME / ICE Execution Gateway</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono">
                <thead className="bg-slate-900 text-slate-400 text-[10px] uppercase border-b border-slate-800">
                  <tr>
                    <th className="p-2">Order ID</th>
                    <th className="p-2">Contract</th>
                    <th className="p-2">Side</th>
                    <th className="p-2 text-right">Quantity</th>
                    <th className="p-2 text-right">Limit Price</th>
                    <th className="p-2 text-center">Status</th>
                    <th className="p-2 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-200">
                  {hedgeOrders.map((ord) => (
                    <tr key={ord.orderId} className="hover:bg-slate-900/50">
                      <td className="p-2 font-bold text-amber-300">{ord.orderId}</td>
                      <td className="p-2 font-bold">{ord.contractSymbol}</td>
                      <td className="p-2">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            ord.side === 'BUY'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : 'bg-rose-950 text-rose-400 border border-rose-800'
                          }`}
                        >
                          {ord.side}
                        </span>
                      </td>
                      <td className="p-2 text-right tabular-nums">{ord.quantity}x</td>
                      <td className="p-2 text-right tabular-nums font-mono text-slate-300">${ord.limitPrice.toFixed(2)}</td>
                      <td className="p-2 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            ord.status === 'FILLED'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : 'bg-amber-950 text-amber-300 border border-amber-800'
                          }`}
                        >
                          {ord.status}
                        </span>
                      </td>
                      <td className="p-2 text-center">
                        {ord.status !== 'FILLED' ? (
                          <button
                            onClick={() => handleExecuteOrder(ord.orderId)}
                            className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-[10px] transition-colors"
                          >
                            TRANSMIT ORDER
                          </button>
                        ) : (
                          <span className="text-emerald-400 flex items-center justify-center gap-1 text-[10px]">
                            <CheckCircle className="w-3 h-3" /> FILLED
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
