import React from 'react';
import { CalculationStep } from '../types/rhino';
import { Calculator, ChevronRight, X, Info } from 'lucide-react';

interface CalculationExplorerModalProps {
  isOpen: boolean;
  onClose: () => void;
  rootStep: CalculationStep;
}

export const CalculationExplorerModal: React.FC<CalculationExplorerModalProps> = ({
  isOpen,
  onClose,
  rootStep,
}) => {
  if (!isOpen) return null;

  const renderStep = (step: CalculationStep, depth: number = 0) => {
    return (
      <div
        key={step.stepId}
        className={`border-l-2 ${
          depth === 0 ? 'border-amber-500' : depth === 1 ? 'border-cyan-500' : 'border-slate-700'
        } pl-3 my-2 font-mono text-xs`}
      >
        <div className="bg-slate-900 border border-slate-800 rounded p-3 hover:border-slate-700 transition-colors">
          <div className="flex items-center justify-between mb-1">
            <span className="font-bold text-amber-300 text-xs">{step.label}</span>
            <span className="bg-slate-950 border border-slate-800 px-2 py-0.5 rounded text-emerald-400 font-bold">
              = {typeof step.resultValue === 'number' ? step.resultValue.toLocaleString(undefined, { maximumFractionDigits: 4 }) : step.resultValue}
            </span>
          </div>

          <div className="text-[11px] text-slate-400 bg-slate-950 p-2 rounded border border-slate-800/80 my-1 font-mono">
            <span className="text-slate-500">FORMULA: </span>
            <span className="text-slate-200">{step.formula}</span>
          </div>

          {step.inputs && Object.keys(step.inputs).length > 0 && (
            <div className="flex flex-wrap gap-2 my-1.5">
              {Object.entries(step.inputs).map(([k, v]) => (
                <div key={k} className="bg-slate-950/80 border border-slate-800 px-2 py-0.5 rounded text-[10px]">
                  <span className="text-slate-500">{k}: </span>
                  <span className="text-cyan-300 font-semibold">{v}</span>
                </div>
              ))}
            </div>
          )}

          <div className="text-[10px] text-slate-500 italic mt-1 flex items-center gap-1">
            <Info className="w-3 h-3 text-slate-600 shrink-0" />
            <span>{step.explanation}</span>
          </div>
        </div>

        {step.subSteps && step.subSteps.length > 0 && (
          <div className="ml-3 mt-2 space-y-2">
            {step.subSteps.map((sub) => renderStep(sub, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#0c1017] border border-amber-500/50 rounded-xl max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl animate-in fade-in zoom-in-95">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900/80">
          <div className="flex items-center gap-2 text-amber-400 font-mono font-bold text-sm">
            <Calculator className="w-4 h-4" />
            <span>RHINOQUANT CALCULATION EXPLORER (NO BLACK BOX)</span>
          </div>
          <button onClick={onClose} className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1 font-mono text-xs">
          <div className="bg-amber-950/20 border border-amber-500/30 p-2.5 rounded text-amber-300 text-[11px] leading-relaxed">
            Every quantitative result in RhinoQuant is mechanically explainable and mathematically auditable down to individual constituent market prices, multipliers, and adjustments.
          </div>

          {renderStep(rootStep, 0)}
        </div>

        {/* Modal Footer */}
        <div className="p-3 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between font-mono text-[11px] text-slate-500">
          <span>Calculation ID: CALC-{Math.random().toString(36).substring(2, 9).toUpperCase()}</span>
          <span>Model Version: RHINO-QUANT-v3.6</span>
        </div>
      </div>
    </div>
  );
};
