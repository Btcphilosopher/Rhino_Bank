import React, { useState } from 'react';
import { StructuredSecurity } from '../types/rhino';
import { FileText, Download, ShieldCheck, History, Eye, ArrowRight, Zap, CheckCircle2 } from 'lucide-react';

interface ProductsViewProps {
  products: StructuredSecurity[];
  onRedeemProduct: (productId: string) => void;
}

export const ProductsView: React.FC<ProductsViewProps> = ({ products, onRedeemProduct }) => {
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.productId || '');
  const [showTermSheet, setShowTermSheet] = useState<boolean>(false);
  const [showDiff, setShowDiff] = useState<boolean>(false);

  const activeProduct = products.find((p) => p.productId === selectedProductId) || products[0];

  const handleExportRqsp = (product: StructuredSecurity) => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(product, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${product.productId}.rqsp`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="p-4 space-y-4 font-mono text-xs">
      {/* Header Banner */}
      <div className="flex items-center justify-between bg-[#0f141d] p-3 rounded-lg border border-slate-800">
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-amber-400" />
          <span className="font-bold text-slate-100 text-sm">ISSUED STRUCTURED SECURITIES CATALOG & TERM SHEETS</span>
        </div>
        <span className="text-[10px] text-slate-500">{products.length} Active Securities Issued</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Col: Securities Inventory */}
        <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-3 space-y-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase block border-b border-slate-800 pb-2">
            ISSUED SECURITIES REGISTER
          </span>

          <div className="space-y-2">
            {products.map((prod) => {
              const isSelected = prod.productId === activeProduct?.productId;
              return (
                <div
                  key={prod.productId}
                  onClick={() => setSelectedProductId(prod.productId)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-800/90 border-amber-500/80 shadow-md'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-amber-300 text-xs">{prod.productId}</span>
                    <span className="text-[10px] bg-amber-950 text-amber-300 border border-amber-800 px-2 py-0.5 rounded">
                      v{prod.version}
                    </span>
                  </div>
                  <div className="font-semibold text-slate-200 text-xs truncate mb-1">{prod.name}</div>
                  <div className="flex items-center justify-between text-[10px] text-slate-500">
                    <span>${(prod.outstandingNotionalUsd / 1000000).toFixed(1)}M Outstanding</span>
                    <span className="text-emerald-400 font-bold">{prod.lifecycleStatus}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 2 Cols: Product Passport & Term Sheet Viewer */}
        {activeProduct && (
          <div className="lg:col-span-2 space-y-4">
            {/* Product Passport Box */}
            <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-4 space-y-3">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-amber-400 text-sm">{activeProduct.name}</span>
                    <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                      {activeProduct.classification}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 block font-mono">
                    CANONICAL HASH: {activeProduct.canonicalHash}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowTermSheet(!showTermSheet)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/40 rounded font-bold transition-colors"
                  >
                    {showTermSheet ? 'HIDE TERM SHEET' : 'VIEW TERM SHEET'}
                  </button>
                  <button
                    onClick={() => handleExportRqsp(activeProduct)}
                    className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded flex items-center gap-1 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>EXPORT .RQSP</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">ISSUED NOTIONAL</span>
                  <span className="font-bold text-slate-100 font-mono">
                    ${activeProduct.totalNotionalIssuedUsd.toLocaleString()} {activeProduct.currency}
                  </span>
                </div>
                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">PRINCIPAL PROTECTION</span>
                  <span className="font-bold text-emerald-400 font-mono">
                    {activeProduct.principalProtectionPct}%
                  </span>
                </div>
                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">ISSUER CREDIT RATING</span>
                  <span className="font-bold text-cyan-300 font-mono">
                    {activeProduct.issuerCredit.issuerName} ({activeProduct.issuerCredit.rating})
                  </span>
                </div>
                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">MATURITY DATE</span>
                  <span className="font-bold text-slate-200 font-mono">{activeProduct.maturityDate}</span>
                </div>
              </div>

              {/* Version History & Immutability */}
              <div className="pt-2 border-t border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-300 text-xs flex items-center gap-1.5">
                    <History className="w-3.5 h-3.5 text-amber-400" />
                    <span>IMMUTABLE VERSION AUDIT LOG ({activeProduct.history.length} VERSIONS)</span>
                  </span>
                  <button
                    onClick={() => setShowDiff(!showDiff)}
                    className="text-[10px] text-amber-400 hover:underline"
                  >
                    {showDiff ? 'Hide Version Diff' : 'Compare Version Diff'}
                  </button>
                </div>

                <div className="space-y-1">
                  {activeProduct.history.map((h, i) => (
                    <div key={i} className="p-2 bg-slate-900 border border-slate-800 rounded flex justify-between items-center text-[11px]">
                      <div>
                        <span className="font-bold text-amber-300">v{h.version}</span>
                        <span className="text-slate-400 ml-2">{h.reason}</span>
                        <span className="text-slate-500 block text-[10px]">{h.changesSummary}</span>
                      </div>
                      <span className="text-[10px] text-slate-500">{h.changedAt.split('T')[0]}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Printable Human-Readable Term Sheet Drawer */}
            {showTermSheet && (
              <div className="bg-slate-900 border border-amber-500/50 rounded-lg p-5 space-y-4 text-slate-200 animate-in fade-in">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="font-bold text-sm text-amber-400 uppercase tracking-wide">
                      RHINOQUANT OFFICIAL INDICATIVE TERM SHEET
                    </h3>
                    <p className="text-[10px] text-slate-400">NON-BINDING COMPUTATIONAL PRODUCT SUMMARY</p>
                  </div>
                  <span className="font-mono text-xs bg-slate-950 px-3 py-1 rounded border border-slate-800 text-amber-300">
                    {activeProduct.productId}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                  <div className="space-y-1 bg-slate-950 p-3 rounded border border-slate-800">
                    <div className="font-bold text-amber-300 mb-1 border-b border-slate-800 pb-1">PRODUCT OVERVIEW</div>
                    <div>
                      <span className="text-slate-500">Issuer: </span>
                      <span>{activeProduct.issuerCredit.issuerName}</span>
                    </div>
                    <div>
                      <span className="text-slate-500">Issue Date: </span>
                      <span>{activeProduct.issueDate}</span>
                    </div>
                    <div>
                      <span className="text-slate-500">Maturity Date: </span>
                      <span>{activeProduct.maturityDate}</span>
                    </div>
                    <div>
                      <span className="text-slate-500">Denomination: </span>
                      <span>
                        ${activeProduct.denominationUsd} {activeProduct.currency}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-1 bg-slate-950 p-3 rounded border border-slate-800">
                    <div className="font-bold text-amber-300 mb-1 border-b border-slate-800 pb-1">PAYOFF & COUPON STRUCTURE</div>
                    <div>
                      <span className="text-slate-500">Payoff Type: </span>
                      <span>{activeProduct.payoff.type}</span>
                    </div>
                    <div>
                      <span className="text-slate-500">Principal Protection: </span>
                      <span className="text-emerald-400 font-bold">{activeProduct.principalProtectionPct}%</span>
                    </div>
                    <div>
                      <span className="text-slate-500">Coupon Rate: </span>
                      <span>
                        {activeProduct.coupon.ratePct}% p.a. ({activeProduct.coupon.type})
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500">Management Fee: </span>
                      <span>{activeProduct.feesPct}% p.a.</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-950 p-3 rounded border border-slate-800 text-[11px] font-mono leading-relaxed text-slate-400">
                  <span className="font-bold text-slate-300 block mb-1">RISK DISCLOSURES & MODELLED LIMITATIONS:</span>
                  1. <strong className="text-slate-200">Reference Asset Risk:</strong> Investors are exposed to the market performance of underlying futures package {activeProduct.referencePackageId}.<br />
                  2. <strong className="text-slate-200">Issuer Credit Risk:</strong> Payments are subject to creditworthiness of {activeProduct.issuerCredit.issuerName} (Rating: {activeProduct.issuerCredit.rating}, Default Prob: {activeProduct.issuerCredit.defaultProbabilityPct}%).<br />
                  3. <strong className="text-slate-200">Liquidity Risk:</strong> Secondary market valuations are indicative simulated quotes.
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
