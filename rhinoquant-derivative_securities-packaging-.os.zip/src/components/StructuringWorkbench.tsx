import React, { useState } from 'react';
import {
  DerivativePackage,
  PackageLeg,
  FuturesContract,
  StructuredSecurity,
  WeightingMethod,
  PayoffType,
  ProductLifecycle,
} from '../types/rhino';
import { VisualPackageGraph } from './VisualPackageGraph';
import {
  Layers,
  Plus,
  Trash2,
  Play,
  CheckCircle,
  AlertTriangle,
  FileCheck,
  Zap,
  Calculator,
  Repeat,
  DollarSign,
  Send,
} from 'lucide-react';

interface StructuringWorkbenchProps {
  contractsMap: Record<string, FuturesContract>;
  allPackages: DerivativePackage[];
  onSavePackage: (pkg: DerivativePackage) => void;
  onIssueProduct: (product: StructuredSecurity) => void;
  onOpenCalculationExplorer: (pkg: DerivativePackage) => void;
}

export const StructuringWorkbench: React.FC<StructuringWorkbenchProps> = ({
  contractsMap,
  allPackages,
  onSavePackage,
  onIssueProduct,
  onOpenCalculationExplorer,
}) => {
  // Current Package Draft State
  const [packageId, setPackageId] = useState<string>(`PKG-SOFR-CURVE-01`);
  const [packageName, setPackageName] = useState<string>('SOFR 1Y Curve Spread Package');
  const [packageDescription, setPackageDescription] = useState<string>(
    '4-leg SOFR futures strip spread capturing 2026-2027 short-term rate expectations.'
  );
  const [currency, setCurrency] = useState<string>('USD');
  const [weightingMethod, setWeightingMethod] = useState<WeightingMethod>('DV01_NEUTRAL');
  const [payoffType, setPayoffType] = useState<PayoffType>('CAPPED');
  const [participationRate, setParticipationRate] = useState<number>(1.0);
  const [cap, setCap] = useState<number>(0.12);
  const [floor, setFloor] = useState<number>(-0.05);
  const [dslCode, setDslCode] = useState<string>(
    'spread(SR3_Z6, SR3_H7) + 0.5 * spread(SR3_M7, SR3_U7)'
  );

  // Legs state
  const [legs, setLegs] = useState<PackageLeg[]>([
    {
      legId: 'LEG-1',
      contractSymbol: 'SR3_Z6',
      contractName: '3-Month SOFR Dec 26',
      assetClass: 'RATES',
      side: 'BUY',
      quantity: 100,
      weight: 1.0,
      ratio: 1.0,
      notional: 23956250,
      currency: 'USD',
      expiry: '2026-12-15',
    },
    {
      legId: 'LEG-2',
      contractSymbol: 'SR3_H7',
      contractName: '3-Month SOFR Mar 27',
      assetClass: 'RATES',
      side: 'SELL',
      quantity: 100,
      weight: -1.0,
      ratio: 1.0,
      notional: 24012500,
      currency: 'USD',
      expiry: '2027-03-16',
    },
    {
      legId: 'LEG-3',
      contractSymbol: 'SR3_M7',
      contractName: '3-Month SOFR Jun 27',
      assetClass: 'RATES',
      side: 'BUY',
      quantity: 50,
      weight: 0.5,
      ratio: 0.5,
      notional: 12027500,
      currency: 'USD',
      expiry: '2027-06-15',
    },
    {
      legId: 'LEG-4',
      contractSymbol: 'SR3_U7',
      contractName: '3-Month SOFR Sep 27',
      assetClass: 'RATES',
      side: 'SELL',
      quantity: 50,
      weight: -0.5,
      ratio: 0.5,
      notional: 12042500,
      currency: 'USD',
      expiry: '2027-09-21',
    },
  ]);

  // Validation output state
  const [validationResult, setValidationResult] = useState<{
    valid: boolean;
    messages: string[];
  } | null>(null);

  // Load existing package template
  const handleLoadPackageTemplate = (pkg: DerivativePackage) => {
    setPackageId(pkg.packageId);
    setPackageName(pkg.name);
    setPackageDescription(pkg.description);
    setCurrency(pkg.currency);
    setWeightingMethod(pkg.weightingMethod);
    setPayoffType(pkg.payoff.type);
    setParticipationRate(pkg.payoff.participationRate || 1.0);
    setCap(pkg.payoff.cap || 0.12);
    setFloor(pkg.payoff.floor || -0.05);
    setDslCode(pkg.payoff.dslCode || '');
    setLegs([...pkg.legs]);
    setValidationResult(null);
  };

  // Add Leg
  const handleAddLeg = (symbol: string) => {
    const contract = contractsMap[symbol] || Object.values(contractsMap)[0];
    const newLeg: PackageLeg = {
      legId: `LEG-${legs.length + 1}`,
      contractSymbol: contract.symbol,
      contractName: contract.name,
      assetClass: contract.assetClass,
      side: 'BUY',
      quantity: 10,
      weight: 1.0,
      ratio: 1.0,
      notional: 10 * contract.price * contract.multiplier,
      currency: contract.currency,
      expiry: contract.expirationDate,
    };
    setLegs([...legs, newLeg]);
  };

  // Add Nested Package Leg (Recursive Package!)
  const handleAddNestedPackageLeg = (nestedPkg: DerivativePackage) => {
    const newLeg: PackageLeg = {
      legId: `LEG-PKG-${legs.length + 1}`,
      contractSymbol: nestedPkg.packageId,
      contractName: `[NESTED PACKAGE] ${nestedPkg.name}`,
      assetClass: 'RATES',
      side: 'BUY',
      quantity: 1,
      weight: 1.0,
      ratio: 1.0,
      notional: 10000000,
      currency: nestedPkg.currency,
      expiry: 'N/A',
      isNestedPackage: true,
      nestedPackageId: nestedPkg.packageId,
    };
    setLegs([...legs, newLeg]);
  };

  // Remove Leg
  const handleRemoveLeg = (idx: number) => {
    const updated = legs.filter((_, i) => i !== idx);
    setLegs(updated);
  };

  // Update Leg Field
  const handleUpdateLeg = (idx: number, field: keyof PackageLeg, value: any) => {
    const updated = [...legs];
    updated[idx] = { ...updated[idx], [field]: value };

    // recalculate notional
    const contract = contractsMap[updated[idx].contractSymbol];
    if (contract) {
      updated[idx].notional = updated[idx].quantity * contract.price * contract.multiplier;
    }
    setLegs(updated);
  };

  // Build current package object
  const currentPackage: DerivativePackage = {
    packageId,
    name: packageName,
    description: packageDescription,
    currency,
    legs,
    layers: [],
    stacks: [],
    weightingMethod,
    payoff: {
      type: payoffType,
      participationRate,
      cap,
      floor,
      dslCode,
      description: `${payoffType} Payoff transformation on constituent legs.`,
    },
    valuationMethod: 'MARK_TO_MARKET',
    hedgePolicy: 'DV01_NEUTRAL',
    lifecycle: 'VALIDATED',
    rebalanceRule: { frequency: 'MONTHLY', thresholdPct: 5 },
    rollSchedule: { rollMethod: 'LIQUIDITY', rollWindowDays: 5, rollDate: '2026-12-10', estimatedRollCostUsd: 1200 },
    canonicalHash: `${Math.random().toString(16).substring(2, 10).toUpperCase()}`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  // Validate Package
  const handleValidate = () => {
    const messages: string[] = [];
    if (legs.length === 0) {
      messages.push('Error: Package must have at least 1 leg.');
    }
    legs.forEach((leg, i) => {
      if (leg.quantity <= 0) {
        messages.push(`Warning: Leg ${i + 1} (${leg.contractSymbol}) has quantity <= 0.`);
      }
    });

    setValidationResult({
      valid: messages.filter((m) => m.startsWith('Error')).length === 0,
      messages: messages.length === 0 ? ['Validation Passed! Structure is mathematically sound and executable.'] : messages,
    });
  };

  // Issue as Structured Security
  const handleIssueSecurity = () => {
    const newSecurity: StructuredSecurity = {
      productId: `RHINO-STRUCT-${Math.floor(100000 + Math.random() * 900000)}`,
      version: '1.0',
      name: `Structured Security on ${packageName}`,
      currency,
      issueDate: new Date().toISOString().split('T')[0],
      maturityDate: '2027-12-31',
      denominationUsd: 1000,
      totalNotionalIssuedUsd: 25000000,
      outstandingNotionalUsd: 25000000,
      referencePackageId: packageId,
      referencePackageName: packageName,
      payoff: currentPackage.payoff,
      coupon: { type: 'PERFORMANCE', ratePct: 6.0, frequency: 'ANNUAL' },
      principalProtectionPct: 100,
      issuerCredit: {
        issuerName: 'RhinoQuant Financial SA',
        rating: 'AA',
        creditSpreadBps: 50,
        defaultProbabilityPct: 0.1,
        recoveryRatePct: 40,
        fundingCurveRatePct: 4.85,
      },
      classification: 'STRUCTURED_NOTE',
      lifecycleStatus: 'ISSUED',
      feesPct: 0.35,
      canonicalHash: `E48A${Math.random().toString(16).substring(2, 8).toUpperCase()}`,
      payoffHash: `8A92${Math.random().toString(16).substring(2, 6).toUpperCase()}`,
      packageHash: `F2C1${Math.random().toString(16).substring(2, 6).toUpperCase()}`,
      createdAt: new Date().toISOString(),
      history: [
        {
          version: '1.0',
          changedAt: '2026-09-24T04:16:00Z',
          changedBy: 'Desk Head',
          reason: 'Initial Issuance',
          changesSummary: 'Issued $25M notional under canonical hash.',
        },
      ],
    };

    onSavePackage(currentPackage);
    onIssueProduct(newSecurity);
    alert(`Success! Product ${newSecurity.productId} issued and published to Securities Catalog.`);
  };

  return (
    <div className="p-4 space-y-4 font-mono text-xs">
      {/* Workbench Header & Presets */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-[#0f141d] p-3 rounded-lg border border-slate-800">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-amber-400" />
          <span className="font-bold text-slate-100 text-sm">RHINOQUANT STRUCTURING WORKBENCH</span>
        </div>

        {/* Quick Load Template Dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-500 uppercase">LOAD TEMPLATE:</span>
          {allPackages.map((pkg) => (
            <button
              key={pkg.packageId}
              onClick={() => handleLoadPackageTemplate(pkg)}
              className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded text-[10px] transition-colors truncate max-w-[160px]"
            >
              {pkg.name}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column: Underlyings Selector & Leg Constructor */}
        <div className="space-y-4">
          <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-3 space-y-3">
            <div className="font-bold text-amber-400 text-xs flex items-center justify-between border-b border-slate-800 pb-2">
              <span>PACKAGE SPECIFICATION</span>
              <span className="text-[10px] text-slate-500">{packageId}</span>
            </div>

            <div>
              <label className="text-[10px] text-slate-500 block mb-1">PACKAGE NAME</label>
              <input
                type="text"
                value={packageName}
                onChange={(e) => setPackageName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 p-1.5 rounded text-slate-200 text-xs focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-500 block mb-1">WEIGHTING METHOD</label>
                <select
                  value={weightingMethod}
                  onChange={(e) => setWeightingMethod(e.target.value as WeightingMethod)}
                  className="w-full bg-slate-950 border border-slate-800 p-1.5 rounded text-slate-200 text-[11px] focus:outline-none font-mono"
                >
                  <option value="DV01_NEUTRAL">DV01 Neutral</option>
                  <option value="EQUAL_WEIGHT">Equal Weight</option>
                  <option value="RISK_PARITY">Risk Parity</option>
                  <option value="INVERSE_VOLATILITY">Inverse Volatility</option>
                  <option value="NOTIONAL_WEIGHT">Notional Weight</option>
                  <option value="DELTA_NEUTRAL">Delta Neutral</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-slate-500 block mb-1">CURRENCY</label>
                <input
                  type="text"
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 p-1.5 rounded text-slate-200 text-[11px] focus:outline-none font-mono"
                />
              </div>
            </div>
          </div>

          {/* Add Underlying Contract Quick Panel */}
          <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-3 space-y-2">
            <span className="font-bold text-slate-200 text-xs block border-b border-slate-800 pb-1.5">
              + ADD UNDERLYING CONTRACT / NESTED PACKAGE
            </span>

            <div className="grid grid-cols-2 gap-1.5 max-h-48 overflow-y-auto pr-1">
              {Object.values(contractsMap).map((c) => (
                <button
                  key={c.symbol}
                  onClick={() => handleAddLeg(c.symbol)}
                  className="flex items-center justify-between p-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded text-left transition-colors"
                >
                  <span className="font-bold text-amber-300 text-[11px]">{c.symbol}</span>
                  <span className="text-[10px] text-slate-400 tabular-nums">${c.price.toFixed(1)}</span>
                </button>
              ))}
            </div>

            {/* Nested Recursive Package Selector */}
            {allPackages.length > 0 && (
              <div className="pt-2 border-t border-slate-800">
                <span className="text-[10px] text-slate-500 block mb-1">ADD RECURSIVE NESTED PACKAGE:</span>
                <div className="space-y-1">
                  {allPackages.map((p) => (
                    <button
                      key={p.packageId}
                      onClick={() => handleAddNestedPackageLeg(p)}
                      className="w-full flex items-center justify-between p-1.5 bg-slate-950 hover:bg-slate-900 border border-amber-500/30 rounded text-left text-amber-200 text-[10px]"
                    >
                      <span>+ {p.name}</span>
                      <span className="text-slate-500">{p.legs.length} legs</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Center & Right Column: Legs Table & Payoff DSL */}
        <div className="lg:col-span-2 space-y-4">
          {/* Active Legs Builder Table */}
          <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-3">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
              <span className="font-bold text-amber-400 text-xs">PACKAGE LEGS CONSTRUCTOR ({legs.length} LEGS)</span>
              <span className="text-[10px] text-slate-500">Side, Quantity, and Weight Exposure Controls</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono">
                <thead className="bg-slate-900 text-slate-400 text-[10px] uppercase border-b border-slate-800">
                  <tr>
                    <th className="p-2">Contract</th>
                    <th className="p-2">Side</th>
                    <th className="p-2">Quantity</th>
                    <th className="p-2">Weight</th>
                    <th className="p-2 text-right">Notional</th>
                    <th className="p-2 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {legs.map((leg, idx) => (
                    <tr key={leg.legId || idx} className="hover:bg-slate-900/50">
                      <td className="p-2 font-bold text-slate-200">
                        {leg.contractSymbol}
                        <span className="block text-[10px] font-normal text-slate-500 truncate max-w-[160px]">
                          {leg.contractName}
                        </span>
                      </td>

                      <td className="p-2">
                        <select
                          value={leg.side}
                          onChange={(e) => handleUpdateLeg(idx, 'side', e.target.value)}
                          className={`p-1 rounded text-[10px] font-bold border focus:outline-none ${
                            leg.side === 'BUY'
                              ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                              : 'bg-rose-950 text-rose-400 border-rose-800'
                          }`}
                        >
                          <option value="BUY">BUY</option>
                          <option value="SELL">SELL</option>
                        </select>
                      </td>

                      <td className="p-2">
                        <input
                          type="number"
                          value={leg.quantity}
                          onChange={(e) => handleUpdateLeg(idx, 'quantity', parseFloat(e.target.value) || 0)}
                          className="w-16 bg-slate-950 border border-slate-800 p-1 rounded text-slate-200 text-xs tabular-nums focus:outline-none"
                        />
                      </td>

                      <td className="p-2">
                        <input
                          type="number"
                          step="0.1"
                          value={leg.weight}
                          onChange={(e) => handleUpdateLeg(idx, 'weight', parseFloat(e.target.value) || 0)}
                          className="w-16 bg-slate-950 border border-slate-800 p-1 rounded text-slate-200 text-xs tabular-nums focus:outline-none"
                        />
                      </td>

                      <td className="p-2 text-right font-mono text-slate-300 tabular-nums">
                        ${leg.notional.toLocaleString()}
                      </td>

                      <td className="p-2 text-center">
                        <button
                          onClick={() => handleRemoveLeg(idx)}
                          className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Payoff DSL & Transformation Engine */}
          <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-3 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="font-bold text-amber-400 text-xs">PAYOFF TRANSFORMATION DSL EDITOR</span>
              <div className="flex items-center gap-1">
                {(['CAPPED', 'PARTICIPATION', 'COLLAR', 'BARRIER'] as PayoffType[]).map((t) => (
                  <button
                    key={t}
                    onClick={() => setPayoffType(t)}
                    className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                      payoffType === t ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-900 text-slate-400'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-xs">
              <div>
                <label className="text-[10px] text-slate-500 block mb-1">PARTICIPATION RATE</label>
                <input
                  type="number"
                  step="0.05"
                  value={participationRate}
                  onChange={(e) => setParticipationRate(parseFloat(e.target.value) || 1.0)}
                  className="w-full bg-slate-950 border border-slate-800 p-1.5 rounded text-slate-200 tabular-nums focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-500 block mb-1">CAP LEVEL (+%)</label>
                <input
                  type="number"
                  step="0.01"
                  value={cap}
                  onChange={(e) => setCap(parseFloat(e.target.value) || 0.12)}
                  className="w-full bg-slate-950 border border-slate-800 p-1.5 rounded text-slate-200 tabular-nums focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-500 block mb-1">FLOOR LEVEL (-%)</label>
                <input
                  type="number"
                  step="0.01"
                  value={floor}
                  onChange={(e) => setFloor(parseFloat(e.target.value) || -0.05)}
                  className="w-full bg-slate-950 border border-slate-800 p-1.5 rounded text-slate-200 tabular-nums focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] text-slate-500 block mb-1">PAYOFF DSL FORMULA CODE</label>
              <textarea
                rows={2}
                value={dslCode}
                onChange={(e) => setDslCode(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-emerald-400 font-mono text-xs focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Validation Result Box */}
          {validationResult && (
            <div
              className={`p-3 rounded-lg border font-mono text-xs animate-in fade-in ${
                validationResult.valid
                  ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
                  : 'bg-rose-950/30 border-rose-500/40 text-rose-300'
              }`}
            >
              <div className="flex items-center gap-2 font-bold mb-1">
                {validationResult.valid ? (
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                )}
                <span>{validationResult.valid ? 'VALIDATION PASSED' : 'VALIDATION ISSUES DETECTED'}</span>
              </div>
              <ul className="list-disc list-inside space-y-0.5 text-[11px] opacity-90">
                {validationResult.messages.map((m, i) => (
                  <li key={i}>{m}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Action Buttons Toolbar */}
          <div className="flex flex-wrap items-center gap-2 bg-[#0f141d] p-3 rounded-lg border border-slate-800">
            <button
              onClick={handleValidate}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded border border-slate-700 transition-colors"
            >
              <FileCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>[VALIDATE]</span>
            </button>

            <button
              onClick={() => onOpenCalculationExplorer(currentPackage)}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold rounded border border-amber-500/40 transition-colors"
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>[PRICE & EXPLORE]</span>
            </button>

            <button
              onClick={handleIssueSecurity}
              className="ml-auto flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded shadow-md transition-colors"
            >
              <Zap className="w-3.5 h-3.5 fill-slate-950" />
              <span>[ISSUE STRUCTURED SECURITY]</span>
            </button>
          </div>

          {/* Visual Package Graph Component */}
          <VisualPackageGraph packageData={currentPackage} contractsMap={contractsMap} />
        </div>
      </div>
    </div>
  );
};
