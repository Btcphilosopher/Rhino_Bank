import React, { useState } from 'react';
import { FuturesContract, AssetClass } from '../types/rhino';
import { Activity, TrendingUp, TrendingDown, Layers, Search, Filter } from 'lucide-react';

interface MarketTerminalProps {
  contracts: FuturesContract[];
  onSelectContractForStructuring: (symbol: string) => void;
}

export const MarketTerminal: React.FC<MarketTerminalProps> = ({
  contracts,
  onSelectContractForStructuring,
}) => {
  const [selectedAssetClass, setSelectedAssetClass] = useState<AssetClass | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeContractSymbol, setActiveContractSymbol] = useState<string>(contracts[0]?.symbol || 'SR3_Z6');

  const assetClasses: Array<AssetClass | 'ALL'> = ['ALL', 'RATES', 'EQUITY', 'ENERGY', 'METALS', 'FX', 'AGS'];

  const filteredContracts = contracts.filter((c) => {
    const matchesCategory = selectedAssetClass === 'ALL' || c.assetClass === selectedAssetClass;
    const matchesSearch =
      c.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const selectedContract = contracts.find((c) => c.symbol === activeContractSymbol) || contracts[0];

  return (
    <div className="p-4 space-y-4 font-mono text-xs">
      {/* Header bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-[#0f141d] p-3 rounded-lg border border-slate-800">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-400" />
          <span className="font-bold text-slate-100 text-sm">SYNTHETIC DETERMINISTIC MARKET TERMINAL</span>
          <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono">LIVE FEED</span>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {assetClasses.map((ac) => (
            <button
              key={ac}
              onClick={() => setSelectedAssetClass(ac)}
              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                selectedAssetClass === ac
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {ac}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Cols: Futures Quotes Table */}
        <div className="lg:col-span-2 bg-[#0f141d] border border-slate-800 rounded-lg overflow-hidden flex flex-col">
          <div className="p-2.5 border-b border-slate-800 bg-slate-900/60 flex items-center justify-between">
            <div className="flex items-center gap-2 bg-slate-950 px-2.5 py-1 rounded border border-slate-800 w-64">
              <Search className="w-3.5 h-3.5 text-slate-500" />
              <input
                type="text"
                placeholder="Search contract or symbol..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent text-slate-200 text-xs focus:outline-none w-full"
              />
            </div>
            <span className="text-[10px] text-slate-500">{filteredContracts.length} Contracts Available</span>
          </div>

          <div className="overflow-x-auto max-h-[580px]">
            <table className="w-full text-left font-mono">
              <thead className="bg-slate-900 text-slate-400 text-[10px] sticky top-0 border-b border-slate-800 uppercase">
                <tr>
                  <th className="py-2 px-3">Symbol</th>
                  <th className="py-2 px-3">Contract Name</th>
                  <th className="py-2 px-3 text-right">Price</th>
                  <th className="py-2 px-3 text-right">Change</th>
                  <th className="py-2 px-3 text-right">Bid / Ask</th>
                  <th className="py-2 px-3 text-right">Impl Vol</th>
                  <th className="py-2 px-3 text-right">DV01</th>
                  <th className="py-2 px-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {filteredContracts.map((c) => {
                  const isUp = c.change24h >= 0;
                  const isSelected = c.symbol === activeContractSymbol;
                  return (
                    <tr
                      key={c.symbol}
                      onClick={() => setActiveContractSymbol(c.symbol)}
                      className={`hover:bg-slate-800/50 cursor-pointer transition-colors ${
                        isSelected ? 'bg-slate-800/80 border-l-2 border-amber-400' : ''
                      }`}
                    >
                      <td className="py-2.5 px-3 font-bold text-amber-400">{c.symbol}</td>
                      <td className="py-2.5 px-3 truncate max-w-[180px] text-slate-200">{c.name}</td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-100 tabular-nums">
                        {c.price.toFixed(c.tickSize < 0.01 ? 4 : 2)}
                      </td>
                      <td className={`py-2.5 px-3 text-right tabular-nums ${isUp ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {isUp ? '+' : ''}
                        {c.change24h.toFixed(2)} ({isUp ? '+' : ''}
                        {c.changePct24h.toFixed(2)}%)
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-400 text-[11px] tabular-nums">
                        {c.bid.toFixed(2)} / {c.ask.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right text-cyan-300 tabular-nums font-semibold">
                        {(c.impliedVol * 100).toFixed(1)}%
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-300 tabular-nums">${c.dv01PerContract.toFixed(1)}</td>
                      <td className="py-2.5 px-3 text-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectContractForStructuring(c.symbol);
                          }}
                          className="px-2 py-0.5 bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-slate-950 border border-amber-500/40 rounded text-[10px] font-bold transition-all"
                        >
                          + STRUCTURE
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Col: Contract Deep-Dive & Level 2 Orderbook */}
        <div className="space-y-4">
          {/* Active Contract Info Box */}
          <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-3">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
              <span className="font-bold text-amber-400 text-sm">{selectedContract.symbol}</span>
              <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-300">{selectedContract.exchange}</span>
            </div>

            <div className="text-xs font-semibold text-slate-200 mb-3">{selectedContract.name}</div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="bg-slate-900 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px]">CONTRACT MULTIPLIER</span>
                <span className="font-mono text-slate-200 font-bold">{selectedContract.multiplier}x {selectedContract.currency}</span>
              </div>
              <div className="bg-slate-900 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px]">TICK VALUE</span>
                <span className="font-mono text-emerald-400 font-bold">${selectedContract.tickValue.toFixed(2)}</span>
              </div>
              <div className="bg-slate-900 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px]">DAILY VOLUME</span>
                <span className="font-mono text-slate-200 font-bold">{selectedContract.volume.toLocaleString()}</span>
              </div>
              <div className="bg-slate-900 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px]">OPEN INTEREST</span>
                <span className="font-mono text-slate-200 font-bold">{selectedContract.openInterest.toLocaleString()}</span>
              </div>
            </div>

            <button
              onClick={() => onSelectContractForStructuring(selectedContract.symbol)}
              className="w-full mt-3 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded flex items-center justify-center gap-2 transition-colors shadow-sm"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>SEND TO STRUCTURING WORKBENCH</span>
            </button>
          </div>

          {/* Level 2 Orderbook Mock */}
          <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-3">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-[10px] font-bold text-slate-400">
              <span>L2 ORDERBOOK DEPTH</span>
              <span>{selectedContract.symbol}</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[10px]">
              {/* Asks (Sells) */}
              <div className="space-y-1">
                <div className="text-rose-400 font-bold border-b border-slate-800 pb-0.5">ASK DEPTH (SELL)</div>
                {[0.03, 0.02, 0.01].map((offset, i) => (
                  <div key={i} className="flex justify-between text-rose-300 font-mono bg-rose-950/20 px-1.5 py-0.5 rounded">
                    <span>{(selectedContract.ask + offset).toFixed(3)}</span>
                    <span className="text-slate-500">{120 + i * 45}</span>
                  </div>
                ))}
              </div>

              {/* Bids (Buys) */}
              <div className="space-y-1">
                <div className="text-emerald-400 font-bold border-b border-slate-800 pb-0.5">BID DEPTH (BUY)</div>
                {[0.0, -0.01, -0.02].map((offset, i) => (
                  <div key={i} className="flex justify-between text-emerald-300 font-mono bg-emerald-950/20 px-1.5 py-0.5 rounded">
                    <span>{(selectedContract.bid + offset).toFixed(3)}</span>
                    <span className="text-slate-500">{180 + i * 60}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
