import React, { useState } from 'react';
import { DerivativePackage, FuturesContract } from '../types/rhino';
import { calculateLookThroughRisk, runPackageCompression } from '../services/quantEngine';
import { Box, Layers, Zap, ArrowRight, ShieldCheck, RefreshCw } from 'lucide-react';

interface PackagesViewProps {
  packages: DerivativePackage[];
  allPackagesMap: Record<string, DerivativePackage>;
  contractsMap: Record<string, FuturesContract>;
  onSelectPackageForWorkbench: (pkg: DerivativePackage) => void;
  onOpenCalculationExplorer: (pkg: DerivativePackage) => void;
}

export const PackagesView: React.FC<PackagesViewProps> = ({
  packages,
  allPackagesMap,
  contractsMap,
  onSelectPackageForWorkbench,
  onOpenCalculationExplorer,
}) => {
  const [selectedPackageId, setSelectedPackageId] = useState<string>(packages[0]?.packageId || '');
  const activePackage = packages.find((p) => p.packageId === selectedPackageId) || packages[0];

  const risk = activePackage
    ? calculateLookThroughRisk(activePackage, allPackagesMap, contractsMap)
    : null;

  const compression = activePackage ? runPackageCompression(activePackage) : null;

  return (
    <div className="p-4 space-y-4 font-mono text-xs">
      {/* Top Banner */}
      <div className="flex items-center justify-between bg-[#0f141d] p-3 rounded-lg border border-slate-800">
        <div className="flex items-center gap-2">
          <Box className="w-4 h-4 text-amber-400" />
          <span className="font-bold text-slate-100 text-sm">DERIVATIVE PACKAGE LIBRARY & COMPRESSION ENGINE</span>
        </div>
        <span className="text-[10px] text-slate-500">{packages.length} Active Packages in Repository</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column: Package Selector List */}
        <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-3 space-y-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase block border-b border-slate-800 pb-2">
            REPOSITORY PACKAGES
          </span>

          <div className="space-y-2">
            {packages.map((pkg) => {
              const isSelected = pkg.packageId === activePackage?.packageId;
              return (
                <div
                  key={pkg.packageId}
                  onClick={() => setSelectedPackageId(pkg.packageId)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-800/90 border-amber-500/80 shadow-md'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-amber-300 text-xs">{pkg.packageId}</span>
                    <span className="text-[10px] bg-slate-950 px-2 py-0.5 rounded text-slate-400">
                      {pkg.legs.length} LEGS
                    </span>
                  </div>
                  <div className="font-semibold text-slate-200 text-xs truncate mb-1">{pkg.name}</div>
                  <div className="text-[10px] text-slate-500 truncate">{pkg.description}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 2 Cols: Package Deep Dive, Look-Through & Compression */}
        {activePackage && risk && compression && (
          <div className="lg:col-span-2 space-y-4">
            {/* Active Package Summary Box */}
            <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div>
                  <span className="font-bold text-amber-400 text-sm">{activePackage.name}</span>
                  <span className="block text-[11px] text-slate-400">{activePackage.description}</span>
                </div>
                <button
                  onClick={() => onSelectPackageForWorkbench(activePackage)}
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs transition-colors"
                >
                  EDIT IN WORKBENCH
                </button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">GROSS NOTIONAL</span>
                  <span className="font-bold text-slate-100 font-mono">${risk.grossNotionalUsd.toLocaleString()}</span>
                </div>
                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">NET DV01</span>
                  <span className="font-bold text-amber-400 font-mono">${risk.dv01Usd.toFixed(1)} / bp</span>
                </div>
                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">MARGIN REQUIREMENT</span>
                  <span className="font-bold text-cyan-300 font-mono">${risk.marginRequirementUsd.toLocaleString()}</span>
                </div>
                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">LEVERAGE RATIO</span>
                  <span className="font-bold text-emerald-400 font-mono">{risk.leverageRatio.toFixed(1)}x</span>
                </div>
              </div>
            </div>

            {/* Package Compression Engine Box */}
            <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2 text-emerald-400 font-bold">
                  <RefreshCw className="w-4 h-4" />
                  <span>PACKAGE COMPRESSION & NETTING ENGINE</span>
                </div>
                <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded">
                  +{compression.capitalEfficiencyBoostPct.toFixed(1)}% CAPITAL BOOST
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="bg-slate-900 p-3 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">ORIGINAL LEGS</span>
                  <span className="font-bold text-slate-200 text-sm font-mono">{compression.originalLegCount} Legs</span>
                </div>
                <div className="bg-slate-900 p-3 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">NET COMPRESSED LEGS</span>
                  <span className="font-bold text-emerald-400 text-sm font-mono">{compression.compressedLegCount} Net Legs</span>
                </div>
              </div>

              {compression.offsetLegsFound.length > 0 ? (
                <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                  <span className="text-[10px] text-amber-400 font-bold block">OFFSETTING LEGS IDENTIFIED FOR NETTING:</span>
                  {compression.offsetLegsFound.map((off, i) => (
                    <div key={i} className="flex items-center justify-between text-[11px] text-slate-300 font-mono">
                      <span>{off.buyLeg}</span>
                      <ArrowRight className="w-3 h-3 text-slate-600" />
                      <span>{off.sellLeg}</span>
                      <span className="text-emerald-400 font-bold">Net Offset</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-[11px] text-slate-500 italic">No duplicate or direct opposing legs found. Package is already compressed.</div>
              )}
            </div>

            {/* Look-Through Risk Exposures */}
            <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-4 space-y-3">
              <span className="font-bold text-amber-400 text-xs block border-b border-slate-800 pb-2">
                LOOK-THROUGH ASSET CLASS EXPOSURES
              </span>

              <div className="grid grid-cols-3 md:grid-cols-6 gap-2 font-mono text-center">
                {Object.entries(risk.assetClassExposures).map(([ac, exp]) => (
                  <div key={ac} className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block uppercase">{ac}</span>
                    <span className="text-slate-200 font-bold text-[11px]">
                      ${(exp / 1000000).toFixed(2)}M
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
