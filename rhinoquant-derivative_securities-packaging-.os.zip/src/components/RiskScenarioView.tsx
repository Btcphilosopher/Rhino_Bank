import React, { useState } from 'react';
import { DerivativePackage, FuturesContract } from '../types/rhino';
import { calculateLookThroughRisk, runScenarioAnalysis, runMonteCarloSimulation } from '../services/quantEngine';
import { ShieldAlert, TrendingDown, Activity, RefreshCw, BarChart } from 'lucide-react';

interface RiskScenarioViewProps {
  packages: DerivativePackage[];
  allPackagesMap: Record<string, DerivativePackage>;
  contractsMap: Record<string, FuturesContract>;
}

export const RiskScenarioView: React.FC<RiskScenarioViewProps> = ({
  packages,
  allPackagesMap,
  contractsMap,
}) => {
  const [selectedPackageId, setSelectedPackageId] = useState<string>(packages[0]?.packageId || '');
  const activePackage = packages.find((p) => p.packageId === selectedPackageId) || packages[0];

  const risk = activePackage ? calculateLookThroughRisk(activePackage, allPackagesMap, contractsMap) : null;
  const scenarios = activePackage ? runScenarioAnalysis(activePackage, contractsMap) : [];
  const mcResults = activePackage ? runMonteCarloSimulation(activePackage, 1000, 30) : null;

  return (
    <div className="p-4 space-y-4 font-mono text-xs">
      {/* Banner */}
      <div className="flex items-center justify-between bg-[#0f141d] p-3 rounded-lg border border-slate-800">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-400" />
          <span className="font-bold text-slate-100 text-sm">LOOK-THROUGH RISK & MONTE CARLO SCENARIO ENGINE</span>
        </div>
        <div className="flex items-center gap-2">
          {packages.map((pkg) => (
            <button
              key={pkg.packageId}
              onClick={() => setSelectedPackageId(pkg.packageId)}
              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                selectedPackageId === pkg.packageId
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-900 text-slate-400 border border-slate-800'
              }`}
            >
              {pkg.packageId}
            </button>
          ))}
        </div>
      </div>

      {activePackage && risk && mcResults && (
        <div className="space-y-4">
          {/* Look-Through Risk Matrix */}
          <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-4 space-y-3">
            <span className="font-bold text-amber-400 text-xs block border-b border-slate-800 pb-2">
              LOOK-THROUGH RISK MATRIX ({activePackage.name})
            </span>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2 text-xs font-mono">
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">DELTA (USD)</span>
                <span className="font-bold text-slate-100">${risk.deltaUsd.toLocaleString()}</span>
              </div>
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">DV01 (USD / BP)</span>
                <span className="font-bold text-amber-400">${risk.dv01Usd.toFixed(1)}</span>
              </div>
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">VEGA (USD / VOL PT)</span>
                <span className="font-bold text-cyan-300">${risk.vegaUsd.toFixed(0)}</span>
              </div>
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">GROSS NOTIONAL</span>
                <span className="font-bold text-slate-200">${risk.grossNotionalUsd.toLocaleString()}</span>
              </div>
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">MARGIN REQUIREMENT</span>
                <span className="font-bold text-rose-300">${risk.marginRequirementUsd.toLocaleString()}</span>
              </div>
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">LIQUIDITY SCORE</span>
                <span className="font-bold text-emerald-400">{risk.liquidityScore} / 100</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Scenario Stress Engine Matrix */}
            <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-4 space-y-3">
              <span className="font-bold text-amber-400 text-xs block border-b border-slate-800 pb-2">
                SCENARIO STRESS MATRIX
              </span>

              <div className="overflow-x-auto max-h-[320px]">
                <table className="w-full text-left font-mono text-[11px]">
                  <thead className="bg-slate-900 text-slate-400 text-[10px] border-b border-slate-800 uppercase">
                    <tr>
                      <th className="p-2">Scenario</th>
                      <th className="p-2 text-right">Value</th>
                      <th className="p-2 text-right">P&L ($)</th>
                      <th className="p-2 text-right">Change (%)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {scenarios.map((scen, idx) => {
                      const isUp = scen.pnlUsd >= 0;
                      return (
                        <tr key={idx} className="hover:bg-slate-900/50">
                          <td className="p-2 font-bold text-slate-200">{scen.scenarioName}</td>
                          <td className="p-2 text-right font-mono text-slate-300">${scen.scenarioValueUsd.toFixed(2)}</td>
                          <td className={`p-2 text-right font-bold tabular-nums ${isUp ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {isUp ? '+' : ''}${scen.pnlUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                          </td>
                          <td className={`p-2 text-right font-bold tabular-nums ${isUp ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {isUp ? '+' : ''}{scen.pnlPct.toFixed(2)}%
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Monte Carlo Stochastic Simulation */}
            <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-amber-400 text-xs">MONTE CARLO STOCHASTIC SIMULATION (1,000 PATHS)</span>
                <span className="text-[10px] bg-slate-900 text-slate-400 px-2 py-0.5 rounded font-mono">30-DAY HORIZON</span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">MEAN NAV</span>
                  <span className="font-bold text-emerald-400">${mcResults.meanValue.toFixed(2)}</span>
                </div>
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">95% VaR (30D)</span>
                  <span className="font-bold text-rose-400">-${mcResults.var95.toFixed(2)}</span>
                </div>
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">EXPECTED SHORTFALL (95%)</span>
                  <span className="font-bold text-rose-300">-${mcResults.expectedShortfall95.toFixed(2)}</span>
                </div>
              </div>

              {/* Sample Path Visual Container */}
              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-500 block mb-1">SAMPLED STOCHASTIC PATH TRAJECTORIES:</span>
                <div className="h-32 flex items-end gap-1.5 pt-2 border-b border-slate-800">
                  {mcResults.paths.map((path, pathIdx) => {
                    const finalVal = path[path.length - 1];
                    const heightPct = Math.min(100, Math.max(10, ((finalVal - 80) / 40) * 100));
                    return (
                      <div
                        key={pathIdx}
                        style={{ height: `${heightPct}%` }}
                        className={`flex-1 rounded-t transition-all ${
                          finalVal >= 100 ? 'bg-emerald-500/60' : 'bg-rose-500/60'
                        }`}
                        title={`Path #${pathIdx + 1}: NAV $${finalVal.toFixed(2)}`}
                      />
                    );
                  })}
                </div>
                <div className="flex justify-between text-[10px] text-slate-500 pt-1">
                  <span>Day 0 (NAV 100.0)</span>
                  <span>Day 30 Horizon</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
