import React, { useState } from 'react';
import { RFQRequest, StructuredSecurity } from '../types/rhino';
import { Send, CheckCircle, Clock, Zap, ArrowRight, DollarSign } from 'lucide-react';

interface RfqMarketMakerViewProps {
  products: StructuredSecurity[];
}

export const RfqMarketMakerView: React.FC<RfqMarketMakerViewProps> = ({ products }) => {
  const [rfqList, setRfqList] = useState<RFQRequest[]>([
    {
      rfqId: 'RFQ-8821',
      clientName: 'BlackRock Systematic Macro Fund',
      productId: products[0]?.productId || 'RHINO-SOFR-CURVE-001',
      notionalUsd: 15000000,
      side: 'BUY',
      currency: 'USD',
      requestedMaturity: '2027-12-31',
      status: 'QUOTED',
      createdAt: new Date().toISOString(),
      quoteExpirySeconds: 120,
      quotedPrice: 103.85,
      fairValue: 103.50,
      quoteId: 'QUO-9910',
    },
    {
      rfqId: 'RFQ-8822',
      clientName: 'Brevan Howard Alpha Desk',
      productId: products[1]?.productId || 'RHINO-GLOBAL-MACRO-002',
      notionalUsd: 25000000,
      side: 'BUY',
      currency: 'USD',
      requestedMaturity: '2028-06-30',
      status: 'PENDING',
      createdAt: new Date().toISOString(),
      quoteExpirySeconds: 180,
    },
  ]);

  const [clientName, setClientName] = useState('Bridgewater Associates');
  const [selectedProductId, setSelectedProductId] = useState(products[0]?.productId || '');
  const [notionalUsd, setNotionalUsd] = useState(10000000);

  const handleCreateRfq = () => {
    const newRfq: RFQRequest = {
      rfqId: `RFQ-${Math.floor(8820 + Math.random() * 1000)}`,
      clientName,
      productId: selectedProductId,
      notionalUsd,
      side: 'BUY',
      currency: 'USD',
      requestedMaturity: '2027-12-31',
      status: 'QUOTED',
      createdAt: new Date().toISOString(),
      quoteExpirySeconds: 120,
      quotedPrice: 102.75,
      fairValue: 102.40,
      quoteId: `QUO-${Math.floor(9900 + Math.random() * 1000)}`,
    };
    setRfqList([newRfq, ...rfqList]);
  };

  const handleAcceptQuote = (rfqId: string) => {
    setRfqList((prev) =>
      prev.map((r) => (r.rfqId === rfqId ? { ...r, status: 'EXECUTED' } : r))
    );
  };

  return (
    <div className="p-4 space-y-4 font-mono text-xs">
      {/* Banner */}
      <div className="flex items-center justify-between bg-[#0f141d] p-3 rounded-lg border border-slate-800">
        <div className="flex items-center gap-2">
          <Send className="w-4 h-4 text-amber-400" />
          <span className="font-bold text-slate-100 text-sm">INSTITUTIONAL RFQ & MARKET MAKER QUOTING DESK</span>
        </div>
        <span className="text-[10px] text-slate-500">Automated Fair Value + Spread Quoting Engine</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Col: New RFQ Form */}
        <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-4 space-y-3">
          <span className="font-bold text-amber-400 text-xs block border-b border-slate-800 pb-2">
            SUBMIT INSTITUTIONAL CLIENT RFQ
          </span>

          <div className="space-y-2">
            <div>
              <label className="text-[10px] text-slate-500 block mb-1">CLIENT INSTITUTION</label>
              <input
                type="text"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 p-1.5 rounded text-slate-200 text-xs focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-500 block mb-1">TARGET STRUCTURED PRODUCT</label>
              <select
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 p-1.5 rounded text-slate-200 text-xs focus:outline-none font-mono"
              >
                {products.map((p) => (
                  <option key={p.productId} value={p.productId}>
                    {p.name} ({p.productId})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] text-slate-500 block mb-1">NOTIONAL AMOUNT (USD)</label>
              <input
                type="number"
                step="1000000"
                value={notionalUsd}
                onChange={(e) => setNotionalUsd(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-800 p-1.5 rounded text-slate-200 text-xs focus:outline-none font-mono tabular-nums"
              />
            </div>

            <button
              onClick={handleCreateRfq}
              className="w-full mt-2 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded flex items-center justify-center gap-2 transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>REQUEST AUTOMATED MARKET MAKER QUOTE</span>
            </button>
          </div>
        </div>

        {/* Right 2 Cols: Active RFQ Tickets */}
        <div className="lg:col-span-2 bg-[#0f141d] border border-slate-800 rounded-lg p-4 space-y-3">
          <span className="font-bold text-amber-400 text-xs block border-b border-slate-800 pb-2">
            ACTIVE RFQ STREAM & DESK QUOTES ({rfqList.length})
          </span>

          <div className="space-y-2">
            {rfqList.map((rfq) => (
              <div
                key={rfq.rfqId}
                className="p-3 bg-slate-900 border border-slate-800 rounded-lg space-y-2 font-mono text-xs"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-amber-300">{rfq.rfqId}</span>
                    <span className="text-slate-300 font-bold">{rfq.clientName}</span>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      rfq.status === 'EXECUTED'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : rfq.status === 'QUOTED'
                        ? 'bg-amber-950 text-amber-300 border border-amber-800'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {rfq.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px] bg-slate-950 p-2 rounded border border-slate-800/80">
                  <div>
                    <span className="text-slate-500 block text-[10px]">PRODUCT</span>
                    <span className="text-slate-200 font-bold">{rfq.productId}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">NOTIONAL</span>
                    <span className="text-slate-200 font-bold">${(rfq.notionalUsd / 1000000).toFixed(1)}M USD</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">DESK FAIR VALUE</span>
                    <span className="text-slate-300">${rfq.fairValue?.toFixed(2) || 'Calculating...'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">QUOTED OFFER</span>
                    <span className="text-emerald-400 font-bold">${rfq.quotedPrice?.toFixed(2) || 'N/A'}</span>
                  </div>
                </div>

                {rfq.status === 'QUOTED' && (
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[10px] text-slate-500 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-amber-400 animate-pulse" /> Quote expires in {rfq.quoteExpirySeconds}s
                    </span>

                    <button
                      onClick={() => handleAcceptQuote(rfq.rfqId)}
                      className="px-3 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded text-xs transition-colors flex items-center gap-1"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>ACCEPT QUOTE & EXECUTE TRADE</span>
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
