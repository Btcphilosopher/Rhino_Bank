import React from 'react';
import {
  Layers,
  Activity,
  Box,
  FileText,
  DollarSign,
  ShieldAlert,
  Repeat,
  Send,
  Lock,
  Radio,
  Zap,
} from 'lucide-react';

export type TabType =
  | 'MARKET'
  | 'STRUCTURE'
  | 'PACKAGES'
  | 'PRODUCTS'
  | 'PRICING'
  | 'RISK'
  | 'HEDGE'
  | 'RFQ'
  | 'AUDIT';

interface NavbarProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  isStreaming: boolean;
  setIsStreaming: (streaming: boolean) => void;
  activeProductCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  isStreaming,
  setIsStreaming,
  activeProductCount,
}) => {
  const navItems: Array<{ id: TabType; label: string; icon: React.ReactNode }> = [
    { id: 'MARKET', label: 'MARKET', icon: <Activity className="w-3.5 h-3.5" /> },
    { id: 'STRUCTURE', label: 'WORKBENCH', icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'PACKAGES', label: 'PACKAGES', icon: <Box className="w-3.5 h-3.5" /> },
    { id: 'PRODUCTS', label: 'SECURITIES', icon: <FileText className="w-3.5 h-3.5" /> },
    { id: 'PRICING', label: 'VALUATION', icon: <DollarSign className="w-3.5 h-3.5" /> },
    { id: 'RISK', label: 'RISK & SCENARIO', icon: <ShieldAlert className="w-3.5 h-3.5" /> },
    { id: 'HEDGE', label: 'EXECUTION.OS', icon: <Repeat className="w-3.5 h-3.5" /> },
    { id: 'RFQ', label: 'RFQ & DESK', icon: <Send className="w-3.5 h-3.5" /> },
    { id: 'AUDIT', label: 'GOVERNANCE', icon: <Lock className="w-3.5 h-3.5" /> },
  ];

  return (
    <header className="border-b border-slate-800 bg-[#0c1017] sticky top-0 z-40 select-none">
      <div className="flex items-center justify-between px-4 py-2.5">
        {/* Brand Zone */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-900 border border-amber-500/30 px-2.5 py-1 rounded text-amber-400 font-mono text-xs font-bold tracking-wider">
            <Zap className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span>RHINOQUANT</span>
            <span className="text-slate-500 font-normal">.OS</span>
          </div>
          <span className="text-xs font-semibold text-slate-300 hidden xl:inline">
            DERIVATIVE & SECURITIES PACKAGING PLATFORM
          </span>
        </div>

        {/* Center Nav Navigation Contract */}
        <nav className="flex items-center gap-1 bg-[#121824] p-1 rounded-lg border border-slate-800/80">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium font-mono transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-amber-500/10 text-amber-300 border border-amber-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Actions Zone */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsStreaming(!isStreaming)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-mono border transition-all ${
              isStreaming
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-400'
                : 'bg-slate-900 border-slate-800 text-slate-400'
            }`}
          >
            <Radio className={`w-3 h-3 ${isStreaming ? 'animate-pulse text-emerald-400' : ''}`} />
            <span>{isStreaming ? 'STREAM: LIVE' : 'STREAM: PAUSED'}</span>
          </button>

          <div className="text-xs font-mono bg-slate-900 border border-slate-800 px-2.5 py-1 rounded text-slate-400">
            ACTIVE ISSUED: <span className="text-slate-200 font-semibold">{activeProductCount}</span>
          </div>
        </div>
      </div>
    </header>
  );
};
