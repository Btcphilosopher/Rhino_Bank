import React, { useState } from 'react';
import { DerivativePackage, StructuredSecurity, FuturesContract } from '../types/rhino';
import { Box, Layers, ArrowDownRight, Info, CheckCircle2 } from 'lucide-react';

interface VisualPackageGraphProps {
  packageData: DerivativePackage;
  productData?: StructuredSecurity;
  contractsMap: Record<string, FuturesContract>;
}

interface NodeDetails {
  title: string;
  type: 'PRODUCT' | 'PAYOFF' | 'PACKAGE' | 'LAYER' | 'LEG' | 'HEDGE';
  details: Record<string, string | number>;
}

export const VisualPackageGraph: React.FC<VisualPackageGraphProps> = ({
  packageData,
  productData,
  contractsMap,
}) => {
  const [selectedNode, setSelectedNode] = useState<NodeDetails | null>(null);

  const handleNodeClick = (node: NodeDetails) => {
    setSelectedNode(node);
  };

  return (
    <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-4 font-mono text-xs">
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-800">
        <div className="flex items-center gap-2 text-amber-400 font-semibold">
          <Layers className="w-4 h-4" />
          <span>COMPUTATIONAL PRODUCT GRAPH (INTERACTIVE DAG)</span>
        </div>
        <span className="text-slate-500 text-[11px]">Click any node to inspect parameters & calculation provenance</span>
      </div>

      <div className="relative overflow-x-auto py-6 flex flex-col items-center gap-6 min-w-[650px]">
        {/* Top Node: Structured Security / Product */}
        <div className="flex flex-col items-center">
          <button
            onClick={() =>
              handleNodeClick({
                title: productData?.name || packageData.name,
                type: 'PRODUCT',
                details: {
                  'Product ID': productData?.productId || 'DRAFT-PACKAGE-01',
                  Version: productData?.version || '1.0',
                  Classification: productData?.classification || 'DERIVATIVE_PACKAGE',
                  Currency: packageData.currency,
                  'Canonical Hash': productData?.canonicalHash || packageData.canonicalHash,
                  'Outstanding Notional': productData
                    ? `$${productData.outstandingNotionalUsd.toLocaleString()} USD`
                    : 'N/A (Unissued)',
                },
              })
            }
            className="group flex flex-col items-center bg-slate-900 border-2 border-amber-500/60 hover:border-amber-400 px-6 py-2.5 rounded-lg shadow-lg transition-all"
          >
            <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider">
              {productData ? 'ISSUED SECURITY' : 'DERIVATIVE PACKAGE'}
            </span>
            <span className="text-sm font-bold text-slate-100 group-hover:text-amber-200">
              {productData?.productId || packageData.packageId}
            </span>
            <span className="text-[11px] text-slate-400 mt-0.5">{packageData.name}</span>
          </button>
        </div>

        {/* Connector Line 1 */}
        <div className="w-0.5 h-6 bg-slate-700"></div>

        {/* Mid Row: Payoff Engine & Hedge Book */}
        <div className="grid grid-cols-2 gap-12 w-full max-w-2xl px-4">
          {/* Payoff Node */}
          <div className="flex flex-col items-center">
            <button
              onClick={() =>
                handleNodeClick({
                  title: `Payoff Engine (${packageData.payoff.type})`,
                  type: 'PAYOFF',
                  details: {
                    'Payoff Type': packageData.payoff.type,
                    'Participation Rate': `${((packageData.payoff.participationRate || 1) * 100).toFixed(0)}%`,
                    Cap: packageData.payoff.cap ? `${(packageData.payoff.cap * 100).toFixed(2)}%` : 'Uncapped',
                    Floor: packageData.payoff.floor ? `${(packageData.payoff.floor * 100).toFixed(2)}%` : 'Unfloored',
                    'DSL Code': packageData.payoff.dslCode || 'N/A',
                    Description: packageData.payoff.description,
                  },
                })
              }
              className="w-full flex flex-col items-center bg-slate-900/90 border border-emerald-500/50 hover:border-emerald-400 p-3 rounded-lg text-center transition-all"
            >
              <span className="text-[10px] text-emerald-400 font-bold uppercase">PAYOFF TRANSFORMATION</span>
              <span className="text-xs font-semibold text-slate-200 mt-1">{packageData.payoff.type}</span>
              <span className="text-[10px] text-slate-400 truncate max-w-[200px] mt-0.5">
                {packageData.payoff.dslCode || packageData.payoff.description}
              </span>
            </button>
          </div>

          {/* Hedge Node */}
          <div className="flex flex-col items-center">
            <button
              onClick={() =>
                handleNodeClick({
                  title: 'Hedge Book & Execution Policy',
                  type: 'HEDGE',
                  details: {
                    Policy: packageData.hedgePolicy,
                    'Target Efficiency': '98.5%',
                    'Hedge Instrument': 'CME Futures Order Book',
                    'Execution Venue': 'EXECUTION.OS',
                    Status: 'ACTIVE_DYNAMIC_HEDGE',
                  },
                })
              }
              className="w-full flex flex-col items-center bg-slate-900/90 border border-cyan-500/50 hover:border-cyan-400 p-3 rounded-lg text-center transition-all"
            >
              <span className="text-[10px] text-cyan-400 font-bold uppercase">HEDGE BOOK REQUIREMENT</span>
              <span className="text-xs font-semibold text-slate-200 mt-1">{packageData.hedgePolicy}</span>
              <span className="text-[10px] text-slate-400 mt-0.5">Dynamic Futures Rebalance</span>
            </button>
          </div>
        </div>

        {/* Connector Line 2 */}
        <div className="w-0.5 h-6 bg-slate-700"></div>

        {/* Package / Layer Container Node */}
        <div className="w-full max-w-3xl bg-slate-950/80 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
            <button
              onClick={() =>
                handleNodeClick({
                  title: `Package Node: ${packageData.packageId}`,
                  type: 'PACKAGE',
                  details: {
                    'Package ID': packageData.packageId,
                    'Leg Count': packageData.legs.length,
                    'Weighting Method': packageData.weightingMethod,
                    'Valuation Method': packageData.valuationMethod,
                    'Rebalance Schedule': packageData.rebalanceRule.frequency,
                    'Roll Method': packageData.rollSchedule.rollMethod,
                  },
                })
              }
              className="flex items-center gap-2 text-slate-200 font-bold hover:text-amber-300"
            >
              <Box className="w-4 h-4 text-amber-400" />
              <span>UNDERLYING PACKAGE LEGS ({packageData.legs.length})</span>
            </button>
            <span className="text-[10px] text-slate-500 font-mono">Weighting: {packageData.weightingMethod}</span>
          </div>

          {/* Leg Nodes */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
            {packageData.legs.map((leg, idx) => {
              const contract = contractsMap[leg.contractSymbol];
              return (
                <button
                  key={leg.legId || idx}
                  onClick={() =>
                    handleNodeClick({
                      title: `Leg ${idx + 1}: ${leg.side} ${leg.quantity}x ${leg.contractSymbol}`,
                      type: 'LEG',
                      details: {
                        'Leg ID': leg.legId || `LEG-${idx + 1}`,
                        Contract: leg.contractSymbol,
                        'Contract Name': leg.contractName,
                        Side: leg.side,
                        Quantity: leg.quantity,
                        Weight: leg.weight.toFixed(2),
                        'Market Price': contract ? contract.price.toFixed(3) : '100.00',
                        Multiplier: contract ? contract.multiplier : 1,
                        'Calculated Notional': `$${(
                          leg.quantity *
                          (contract ? contract.price : 100) *
                          (contract ? contract.multiplier : 1)
                        ).toLocaleString()} USD`,
                        Expiry: leg.expiry,
                      },
                    })
                  }
                  className="flex flex-col p-2.5 bg-slate-900 border border-slate-800 hover:border-amber-500/50 rounded text-left transition-all"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span
                      className={`font-bold text-[10px] px-1 py-0.5 rounded ${
                        leg.side === 'BUY'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}
                    >
                      {leg.side} {leg.quantity}x
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">w: {leg.weight > 0 ? `+${leg.weight}` : leg.weight}</span>
                  </div>
                  <span className="font-bold text-slate-200 truncate">{leg.contractSymbol}</span>
                  <span className="text-[10px] text-slate-500 truncate">{leg.contractName}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Selected Node Drawer / Detail Modal */}
      {selectedNode && (
        <div className="mt-4 p-4 bg-slate-900 border border-amber-500/40 rounded-lg animate-in fade-in">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              <span className="font-bold text-slate-100 text-xs">{selectedNode.title}</span>
            </div>
            <button
              onClick={() => setSelectedNode(null)}
              className="text-slate-400 hover:text-slate-200 text-xs px-2 py-0.5 bg-slate-800 rounded"
            >
              Close
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {Object.entries(selectedNode.details).map(([key, val]) => (
              <div key={key} className="bg-slate-950 p-2 rounded border border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase">{key}</div>
                <div className="text-xs font-semibold text-slate-200 font-mono mt-0.5 truncate">{val}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
