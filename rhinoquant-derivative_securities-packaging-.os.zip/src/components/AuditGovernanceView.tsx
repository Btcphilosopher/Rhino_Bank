import React from 'react';
import { EventLogItem } from '../types/rhino';
import { Lock, ShieldCheck, FileCode2, Key, CheckCircle2 } from 'lucide-react';

interface AuditGovernanceViewProps {
  logs: EventLogItem[];
}

export const AuditGovernanceView: React.FC<AuditGovernanceViewProps> = ({ logs }) => {
  return (
    <div className="p-4 space-y-4 font-mono text-xs">
      {/* Banner */}
      <div className="flex items-center justify-between bg-[#0f141d] p-3 rounded-lg border border-slate-800">
        <div className="flex items-center gap-2">
          <Lock className="w-4 h-4 text-amber-400" />
          <span className="font-bold text-slate-100 text-sm">CRYPTOGRAPHIC GOVERNANCE & EVENT-SOURCED AUDIT LEDGER</span>
        </div>
        <span className="text-[10px] text-slate-500">Immutable SHA256 Cryptographic Chain Active</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Col: Model Registry & Validation Status */}
        <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-4 space-y-3">
          <span className="font-bold text-amber-400 text-xs block border-b border-slate-800 pb-2">
            MODEL REGISTRY & GOVERNANCE RULES
          </span>

          <div className="space-y-2 text-xs">
            <div className="bg-slate-900 p-2.5 rounded border border-slate-800 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200">SOFR Yield Curve Engine</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1 text-[10px]">
                  <CheckCircle2 className="w-3 h-3" /> VERIFIED
                </span>
              </div>
              <span className="text-[10px] text-slate-500 block">Version: v3.6.1 | Model ID: RHINO-CURVE-01</span>
            </div>

            <div className="bg-slate-900 p-2.5 rounded border border-slate-800 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200">Look-Through Risk Compiler</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1 text-[10px]">
                  <CheckCircle2 className="w-3 h-3" /> VERIFIED
                </span>
              </div>
              <span className="text-[10px] text-slate-500 block">Version: v3.6.0 | Model ID: RHINO-RISK-02</span>
            </div>

            <div className="bg-slate-900 p-2.5 rounded border border-slate-800 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200">Payoff DSL Interpreter</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1 text-[10px]">
                  <CheckCircle2 className="w-3 h-3" /> VERIFIED
                </span>
              </div>
              <span className="text-[10px] text-slate-500 block">Version: v3.6.2 | Model ID: RHINO-DSL-03</span>
            </div>
          </div>
        </div>

        {/* Right 2 Cols: Audit Log */}
        <div className="lg:col-span-2 bg-[#0f141d] border border-slate-800 rounded-lg p-4 space-y-3">
          <span className="font-bold text-amber-400 text-xs block border-b border-slate-800 pb-2">
            EVENT-SOURCED CRYPTOGRAPHIC AUDIT LOG ({logs.length} EVENTS)
          </span>

          <div className="overflow-x-auto max-h-[500px]">
            <table className="w-full text-left font-mono text-[11px]">
              <thead className="bg-slate-900 text-slate-400 text-[10px] border-b border-slate-800 uppercase sticky top-0">
                <tr>
                  <th className="p-2">Timestamp</th>
                  <th className="p-2">Event Type</th>
                  <th className="p-2">Entity ID</th>
                  <th className="p-2">Operator</th>
                  <th className="p-2">Details</th>
                  <th className="p-2 text-right">Cryptographic Hash</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {logs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-900/50">
                    <td className="p-2 text-slate-500 whitespace-nowrap">{log.timestamp.replace('T', ' ').substring(0, 19)}</td>
                    <td className="p-2 font-bold text-amber-300">{log.type}</td>
                    <td className="p-2 font-bold text-slate-200">{log.entityId}</td>
                    <td className="p-2 text-slate-400">{log.operator}</td>
                    <td className="p-2 text-slate-300 truncate max-w-[200px]">{log.details}</td>
                    <td className="p-2 text-right text-slate-500 font-mono text-[10px]">{log.hash}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
