import React, { useState } from 'react';
import { DerivativePackage, FuturesContract } from '../types/rhino';
import { buildValuationBreakdown } from '../services/quantEngine';
import { DollarSign, Calculator, TrendingUp, Shield, BarChart2 } from 'lucide-react';

interface PricingNavViewProps {
  packages: DerivativePackage[];
  contractsMap: Record<string, FuturesContract>;
  onOpenCalculationExplorer: (pkg: DerivativePackage) => void;
}

export const PricingNavView: React.FC<PricingNavViewProps> = ({
  packages,
  contractsMap,
  onOpenCalculationExplorer,
}) => {
  const [selectedPackageId, setSelectedPackageId] = useState<string>(packages[0]?.packageId || '');
  const activePackage = packages.find((p) => p.packageId === selectedPackageId) || packages[0];

  const breakdown = activePackage ? buildValuationBreakdown(activePackage, contractsMap) : null;

  return (
    <div className="p-4 space-y-4 font-mono text-xs">
      {/* Banner */}
      <div className="flex items-center justify-between bg-[#0f141d] p-3 rounded-lg border border-slate-800">
        <div className="flex items-center gap-2">
          <DollarSign className="w-4 h-4 text-emerald-400" />
          <span className="font-bold text-slate-100 text-sm">MARK-TO-MARKET VALUATION & NAV MONITOR</span>
        </div>
        <span className="text-[10px] text-slate-500">Continuous Pricing Engine Active</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column: Package Selectors */}
        <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-3 space-y-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase block border-b border-slate-800 pb-2">
            VALUATION TARGETS
          </span>

          <div className="space-y-2">
            {packages.map((pkg) => {
              const val = buildValuationBreakdown(pkg, contractsMap);
              const isSelected = pkg.packageId === activePackage?.packageId;
              return (
                <div
                  key={pkg.packageId}
                  onClick={() => setSelectedPackageId(pkg.packageId)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-800/90 border-emerald-500/80 shadow-md'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-amber-300 text-xs">{pkg.packageId}</span>
                    <span className="font-bold font-mono text-emerald-400 text-xs">
                      ${val.fairValueUsd.toFixed(2)}
                    </span>
                  </div>
                  <div className="font-semibold text-slate-200 text-xs truncate">{pkg.name}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 2 Cols: Valuation Breakdown & Calculation Explorer Trigger */}
        {activePackage && breakdown && (
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-[#0f141d] border border-slate-800 rounded-lg p-4 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <span className="font-bold text-amber-400 text-sm">{activePackage.name}</span>
                  <span className="text-[10px] text-slate-500 block">Valuation Snapshot: {breakdown.timestamp}</span>
                </div>

                <button
                  onClick={() => onOpenCalculationExplorer(activePackage)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs transition-colors shadow-sm"
                >
                  <Calculator className="w-3.5 h-3.5" />
                  <span>EXPLORE MATHEMATICAL DRILL-DOWN</span>
                </button>
              </div>

              {/* NAV Stat Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
                <div className="bg-slate-900 p-3 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">THEORETICAL NAV</span>
                  <span className="font-bold text-slate-100 text-sm">${breakdown.theoreticalValueUsd.toFixed(2)}</span>
                </div>
                <div className="bg-slate-900 p-3 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">CLEAN FAIR VALUE</span>
                  <span className="font-bold text-emerald-400 text-sm">${breakdown.fairValueUsd.toFixed(2)}</span>
                </div>
                <div className="bg-slate-900 p-3 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">BID / ASK SPREAD</span>
                  <span className="font-bold text-slate-300 text-xs">
                    ${breakdown.bidPriceUsd.toFixed(2)} / ${breakdown.askPriceUsd.toFixed(2)}
                  </span>
                </div>
                <div className="bg-slate-900 p-3 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">TOTAL FRICTION</span>
                  <span className="font-bold text-rose-400 text-xs">
                    -${(breakdown.executionCostUsd + breakdown.hedgingCostUsd + breakdown.fundingCostUsd).toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Frictional Adjustment Component Matrix */}
              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
                <span className="font-bold text-slate-300 text-xs block border-b border-slate-800 pb-1.5">
                  MARKET FRICTION & FUNDING BREAKDOWN
                </span>

                <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">EXECUTION COST (2BPS)</span>
                    <span className="text-slate-300 font-bold">${breakdown.executionCostUsd.toFixed(2)}</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">HEDGING FRICTION (3BPS)</span>
                    <span className="text-slate-300 font-bold">${breakdown.hedgingCostUsd.toFixed(2)}</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">ISSUER FUNDING SPREAD</span>
                    <span className="text-slate-300 font-bold">${breakdown.fundingCostUsd.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
