/**
 * RhinoQuant Quantitative Financial Engineering Engine
 * High-precision financial modeling, DSL payoff evaluation, look-through risk, and calculation explorer.
 */

import {
  FuturesContract,
  DerivativePackage,
  PackageLeg,
  StructuredSecurity,
  RiskMetrics,
  ScenarioResult,
  ValuationBreakdown,
  CalculationStep,
  HedgeBook,
  HedgeOrder,
  AssetClass,
} from '../types/rhino';

/**
 * Normalises a package leg into standard USD Notional, DV01, and Exposure
 */
export function normaliseLeg(leg: PackageLeg, contractsMap: Record<string, FuturesContract>) {
  const contract = contractsMap[leg.contractSymbol];
  const price = contract ? contract.price : 100;
  const multiplier = contract ? contract.multiplier : 1;
  const dv01PerContract = contract ? contract.dv01PerContract : 25;

  const rawNotional = leg.quantity * price * multiplier;
  const signedNotional = leg.side === 'BUY' ? rawNotional : -rawNotional;
  const dv01 = leg.quantity * dv01PerContract * (leg.side === 'BUY' ? 1 : -1);

  return {
    price,
    multiplier,
    rawNotional,
    signedNotional,
    dv01,
  };
}

/**
 * Look-through Risk Engine: Recursively resolves package legs (including nested packages)
 * to accumulate net exposures down to underlying futures contracts.
 */
export function calculateLookThroughRisk(
  pkg: DerivativePackage,
  allPackagesMap: Record<string, DerivativePackage>,
  contractsMap: Record<string, FuturesContract>
): RiskMetrics {
  const underlyingExposures: Record<string, { quantity: number; netNotional: number; dv01: number }> = {};
  const assetClassExposures: Record<AssetClass, number> = {
    RATES: 0,
    EQUITY: 0,
    ENERGY: 0,
    METALS: 0,
    FX: 0,
    AGS: 0,
  };

  let totalGrossNotional = 0;
  let totalNetNotional = 0;
  let totalDv01 = 0;
  let totalDeltaUsd = 0;
  let totalGammaUsd = 0;
  let totalVegaUsd = 0;

  function traversePackage(currentPkg: DerivativePackage, multiplierScale: number, visitedSet: Set<string>) {
    if (visitedSet.has(currentPkg.packageId)) {
      console.warn(`Circular reference detected in package dependency graph: ${currentPkg.packageId}`);
      return;
    }
    visitedSet.add(currentPkg.packageId);

    for (const leg of currentPkg.legs) {
      if (leg.isNestedPackage && leg.nestedPackageId && allPackagesMap[leg.nestedPackageId]) {
        const nested = allPackagesMap[leg.nestedPackageId];
        const sideSign = leg.side === 'BUY' ? 1 : -1;
        traversePackage(nested, multiplierScale * leg.quantity * sideSign, new Set(visitedSet));
      } else {
        const contract = contractsMap[leg.contractSymbol];
        const price = contract ? contract.price : 100;
        const multiplier = contract ? contract.multiplier : 1;
        const assetClass = contract ? contract.assetClass : 'RATES';

        const legQty = leg.quantity * multiplierScale * (leg.side === 'BUY' ? 1 : -1);
        const legNotional = Math.abs(legQty) * price * multiplier;
        const legSignedNotional = legQty * price * multiplier;
        const legDv01 = (contract ? contract.dv01PerContract : 25) * legQty;

        totalGrossNotional += legNotional;
        totalNetNotional += legSignedNotional;
        totalDv01 += legDv01;

        if (assetClass) {
          assetClassExposures[assetClass] = (assetClassExposures[assetClass] || 0) + legSignedNotional;
        }

        // Greeks calculation
        if (assetClass === 'RATES') {
          totalDeltaUsd += legSignedNotional * 0.05;
          totalGammaUsd += legNotional * 0.002;
        } else if (assetClass === 'EQUITY') {
          totalDeltaUsd += legSignedNotional * 1.0;
          totalGammaUsd += legNotional * 0.015;
          totalVegaUsd += legNotional * (contract ? contract.impliedVol : 0.2) * 0.1;
        } else {
          totalDeltaUsd += legSignedNotional * 0.8;
          totalVegaUsd += legNotional * (contract ? contract.impliedVol : 0.25) * 0.15;
        }

        if (!underlyingExposures[leg.contractSymbol]) {
          underlyingExposures[leg.contractSymbol] = { quantity: 0, netNotional: 0, dv01: 0 };
        }
        underlyingExposures[leg.contractSymbol].quantity += legQty;
        underlyingExposures[leg.contractSymbol].netNotional += legSignedNotional;
        underlyingExposures[leg.contractSymbol].dv01 += legDv01;
      }
    }
  }

  traversePackage(pkg, 1.0, new Set());

  const marginRequirementUsd = totalGrossNotional * 0.065; // ~6.5% initial margin requirement
  const leverageRatio = totalGrossNotional / Math.max(100000, totalGrossNotional - marginRequirementUsd);
  const durationYears = totalDv01 !== 0 ? Math.abs(totalDv01 / (totalGrossNotional * 0.0001 || 1)) : 0.5;

  return {
    deltaUsd: totalDeltaUsd,
    gammaUsd: totalGammaUsd,
    vegaUsd: totalVegaUsd,
    thetaUsd: -totalGrossNotional * 0.0001, // daily decay approximation
    dv01Usd: totalDv01,
    durationYears: Math.min(30, durationYears),
    grossNotionalUsd: totalGrossNotional,
    netNotionalUsd: totalNetNotional,
    leverageRatio: Math.min(25, Math.max(1, leverageRatio)),
    marginRequirementUsd,
    liquidityScore: 92, // High institutional liquidity score
    assetClassExposures,
  };
}

/**
 * Payoff Engine & DSL Interpreter
 * Evaluates payoff formulas under current or modified market states.
 */
export function evaluatePayoff(
  payoff: DerivativePackage['payoff'],
  basketReturn: number,
  spreadValue: number = 0.02
): { payoffReturn: number; explanation: string } {
  const { type, participationRate, cap, floor, barrierLevel, couponRate } = payoff;

  let payoffReturn = basketReturn * (participationRate || 1.0);
  let explanation = `Base return (${(basketReturn * 100).toFixed(2)}%) * Participation (${(
    (participationRate || 1.0) * 100
  ).toFixed(0)}%)`;

  if (type === 'CAPPED') {
    const capVal = cap !== undefined ? cap : 0.15;
    if (payoffReturn > capVal) {
      explanation += ` → Capped at ${(capVal * 100).toFixed(2)}%`;
      payoffReturn = capVal;
    }
  } else if (type === 'FLOORED') {
    const floorVal = floor !== undefined ? floor : 0.0;
    if (payoffReturn < floorVal) {
      explanation += ` → Floored at ${(floorVal * 100).toFixed(2)}%`;
      payoffReturn = floorVal;
    }
  } else if (type === 'COLLAR') {
    const capVal = cap !== undefined ? cap : 0.15;
    const floorVal = floor !== undefined ? floor : -0.05;
    if (payoffReturn > capVal) {
      payoffReturn = capVal;
      explanation += ` → Collar upper cap applied (${(capVal * 100).toFixed(2)}%)`;
    } else if (payoffReturn < floorVal) {
      payoffReturn = floorVal;
      explanation += ` → Collar lower floor applied (${(floorVal * 100).toFixed(2)}%)`;
    }
  } else if (type === 'BARRIER') {
    const barrier = barrierLevel || 80.0;
    if (basketReturn * 100 < -barrier) {
      payoffReturn = basketReturn; // Knock-in downside exposure
      explanation += ` → Barrier breached (${barrier}% downside). Unprotected exposure active.`;
    } else {
      payoffReturn = Math.max(0, payoffReturn) + (couponRate || 0.05);
      explanation += ` → Barrier intact. Protected payout + coupon active.`;
    }
  }

  return { payoffReturn, explanation };
}

/**
 * Calculation Explorer: Builds a step-by-step mathematical explanation tree
 * for complete "No Black Box" transparency.
 */
export function buildValuationBreakdown(
  pkg: DerivativePackage,
  contractsMap: Record<string, FuturesContract>
): ValuationBreakdown {
  let grossLegValue = 0;
  const legSteps: CalculationStep[] = [];

  pkg.legs.forEach((leg, index) => {
    const norm = normaliseLeg(leg, contractsMap);
    grossLegValue += norm.signedNotional;

    legSteps.push({
      stepId: `LEG-${index + 1}`,
      label: `Leg ${index + 1}: ${leg.side} ${leg.quantity}x ${leg.contractSymbol}`,
      formula: `Price (${norm.price.toFixed(3)}) × Multiplier (${norm.multiplier}) × Qty (${leg.quantity}) × Side (${
        leg.side === 'BUY' ? '+1' : '-1'
      })`,
      inputs: {
        contractPrice: norm.price,
        contractMultiplier: norm.multiplier,
        quantity: leg.quantity,
        side: leg.side,
      },
      resultValue: norm.signedNotional,
      explanation: `Calculated USD notional exposure for ${leg.contractName}`,
    });
  });

  const baseBasketReturn = 0.0342; // +3.42% simulated market basket return
  const { payoffReturn, explanation: payoffExplanation } = evaluatePayoff(pkg.payoff, baseBasketReturn);

  const theoreticalValueUsd = Math.max(100, 100 * (1 + payoffReturn));
  const executionCostUsd = Math.abs(grossLegValue) * 0.0002; // 2bps execution fee
  const hedgingCostUsd = Math.abs(grossLegValue) * 0.0003; // 3bps hedging cost
  const fundingCostUsd = 100 * 0.0045; // 45bps funding cost

  const fairValueUsd = theoreticalValueUsd - (executionCostUsd + hedgingCostUsd + fundingCostUsd) / 100000;
  const bidPriceUsd = fairValueUsd * 0.9985;
  const askPriceUsd = fairValueUsd * 1.0015;

  const calculationTree: CalculationStep = {
    stepId: 'ROOT-VALUATION',
    label: `Product Fair Value (${pkg.name})`,
    formula: 'Theoretical Value + Payoff Adjustment - Execution Cost - Hedging Cost - Funding Cost',
    inputs: {
      grossNotional: grossLegValue,
      theoreticalValue: theoreticalValueUsd,
      executionCost: executionCostUsd,
      hedgingCost: hedgingCostUsd,
      fundingCost: fundingCostUsd,
    },
    resultValue: fairValueUsd,
    explanation: 'Final composite fair value per 100 USD nominal.',
    subSteps: [
      {
        stepId: 'SUB-LEGS',
        label: 'Constituent Legs Value',
        formula: 'Sum of all individual leg signed notionals',
        inputs: { legCount: pkg.legs.length },
        resultValue: grossLegValue,
        explanation: 'Sum of underlying market contract positions.',
        subSteps: legSteps,
      },
      {
        stepId: 'SUB-PAYOFF',
        label: `Payoff Transformation (${pkg.payoff.type})`,
        formula: pkg.payoff.dslCode || 'evaluatePayoff(market_return)',
        inputs: {
          basketReturnPct: baseBasketReturn * 100,
          participation: pkg.payoff.participationRate || 1.0,
          cap: pkg.payoff.cap || 'None',
          floor: pkg.payoff.floor || 'None',
        },
        resultValue: theoreticalValueUsd,
        explanation: payoffExplanation,
      },
      {
        stepId: 'SUB-ADJUSTMENTS',
        label: 'Market & Frictional Adjustments',
        formula: 'Execution Fees + Hedging Friction + Issuer Funding Spread',
        inputs: {
          executionCostUsd,
          hedgingCostUsd,
          fundingCostUsd,
        },
        resultValue: -(executionCostUsd + hedgingCostUsd + fundingCostUsd),
        explanation: 'Frictional costs subtracted to reach clean institutional bid/ask mid pricing.',
      },
    ],
  };

  return {
    packageId: pkg.packageId,
    timestamp: new Date().toISOString(),
    theoreticalValueUsd,
    fairValueUsd,
    bidPriceUsd,
    askPriceUsd,
    executionCostUsd,
    hedgingCostUsd,
    fundingCostUsd,
    navPerUnitUsd: fairValueUsd,
    calculationTree,
  };
}

/**
 * Scenario Analysis & Stress Engine
 */
export function runScenarioAnalysis(
  pkg: DerivativePackage,
  contractsMap: Record<string, FuturesContract>
): ScenarioResult[] {
  const baseValuation = buildValuationBreakdown(pkg, contractsMap);
  const baseValue = baseValuation.fairValueUsd;

  const scenarios = [
    { name: 'Rates +100bps Shock', ratesShiftBps: 100, equityShiftPct: 0, commodityShiftPct: 0, fxShiftPct: 0, volShiftPts: 0 },
    { name: 'Rates -100bps Shock', ratesShiftBps: -100, equityShiftPct: 0, commodityShiftPct: 0, fxShiftPct: 0, volShiftPts: 0 },
    { name: 'Equity Rally (+10%)', ratesShiftBps: 0, equityShiftPct: 0.10, commodityShiftPct: 0, fxShiftPct: 0, volShiftPts: -2 },
    { name: 'Equity Crash (-10%)', ratesShiftBps: 0, equityShiftPct: -0.10, commodityShiftPct: 0, fxShiftPct: 0, volShiftPts: 8 },
    { name: 'Oil Spike (+20%)', ratesShiftBps: 15, equityShiftPct: -0.03, commodityShiftPct: 0.20, fxShiftPct: -0.01, volShiftPts: 5 },
    { name: 'USD Rally (+5%)', ratesShiftBps: 20, equityShiftPct: -0.02, commodityShiftPct: -0.05, fxShiftPct: -0.05, volShiftPts: 1 },
    { name: 'Curve Steepening (+50bps 2s10s)', ratesShiftBps: 50, equityShiftPct: 0.01, commodityShiftPct: 0.02, fxShiftPct: 0, volShiftPts: 0 },
    { name: 'Vol Spike (+10 Vol Pts)', ratesShiftBps: 0, equityShiftPct: -0.05, commodityShiftPct: 0.05, fxShiftPct: 0, volShiftPts: 10 },
  ];

  return scenarios.map((scen) => {
    // Calculate P&L delta based on package asset class exposures
    let pnlDeltaUsd = 0;

    pkg.legs.forEach((leg) => {
      const contract = contractsMap[leg.contractSymbol];
      if (!contract) return;

      const norm = normaliseLeg(leg, contractsMap);

      if (contract.assetClass === 'RATES') {
        pnlDeltaUsd += norm.dv01 * (scen.ratesShiftBps * -1); // Price increases when rates fall
      } else if (contract.assetClass === 'EQUITY') {
        pnlDeltaUsd += norm.signedNotional * scen.equityShiftPct;
      } else if (contract.assetClass === 'ENERGY' || contract.assetClass === 'METALS') {
        pnlDeltaUsd += norm.signedNotional * scen.commodityShiftPct;
      } else if (contract.assetClass === 'FX') {
        pnlDeltaUsd += norm.signedNotional * scen.fxShiftPct;
      }
    });

    const scenarioValue = baseValue + pnlDeltaUsd / 10000;
    const pnlUsd = pnlDeltaUsd / 100;
    const pnlPct = (pnlUsd / (baseValue * 10000)) * 100;

    return {
      scenarioName: scen.name,
      ratesShiftBps: scen.ratesShiftBps,
      equityShiftPct: scen.equityShiftPct,
      commodityShiftPct: scen.commodityShiftPct,
      fxShiftPct: scen.fxShiftPct,
      volShiftPts: scen.volShiftPts,
      currentValueUsd: baseValue,
      scenarioValueUsd: scenarioValue,
      pnlUsd,
      pnlPct,
    };
  });
}

/**
 * Monte Carlo Engine
 * Generates N stochastic path simulations for risk confidence bands.
 */
export function runMonteCarloSimulation(
  pkg: DerivativePackage,
  numPaths: number = 1000,
  horizonDays: number = 30
): {
  paths: number[][];
  meanValue: number;
  var95: number;
  var99: number;
  expectedShortfall95: number;
} {
  const dt = 1 / 252;
  const initialNav = 100.0;
  const mu = 0.05; // 5% expected annual return
  const sigma = 0.14; // 14% annual volatility

  const sampledPaths: number[][] = [];
  const finalValues: number[] = [];

  // Generate paths (record 10 sampled paths for UI visual graph)
  for (let i = 0; i < numPaths; i++) {
    let currentVal = initialNav;
    const path: number[] = [currentVal];

    for (let day = 1; day <= horizonDays; day++) {
      const z = (Math.random() + Math.random() + Math.random() + Math.random() - 2) * 1.732; // Normal approx
      currentVal *= Math.exp((mu - 0.5 * sigma * sigma) * dt + sigma * Math.sqrt(dt) * z);
      if (i < 10) {
        path.push(currentVal);
      }
    }

    if (i < 10) {
      sampledPaths.push(path);
    }
    finalValues.push(currentVal);
  }

  finalValues.sort((a, b) => a - b);
  const meanValue = finalValues.reduce((s, v) => s + v, 0) / numPaths;
  const var95Idx = Math.floor(numPaths * 0.05);
  const var99Idx = Math.floor(numPaths * 0.01);

  const var95 = initialNav - finalValues[var95Idx];
  const var99 = initialNav - finalValues[var99Idx];
  const tailValues = finalValues.slice(0, var95Idx);
  const expectedShortfall95 = initialNav - tailValues.reduce((s, v) => s + v, 0) / (tailValues.length || 1);

  return {
    paths: sampledPaths,
    meanValue,
    var95,
    var99,
    expectedShortfall95,
  };
}

/**
 * Hedge Generator: Creates actionable futures hedge orders based on package risk exposures
 */
export function generateHedgeBook(
  product: StructuredSecurity,
  pkg: DerivativePackage,
  risk: RiskMetrics
): HedgeBook {
  const orders: HedgeOrder[] = [];

  pkg.legs.forEach((leg, idx) => {
    const hedgeSide = leg.side === 'BUY' ? 'SELL' : 'BUY';
    orders.push({
      orderId: `HEDGE-ORD-${idx + 1}`,
      contractSymbol: leg.contractSymbol,
      side: hedgeSide,
      quantity: leg.quantity,
      targetRatio: 1.0,
      limitPrice: 95.82,
      expectedCostUsd: leg.quantity * 12.50,
      status: 'PROPOSED',
    });
  });

  return {
    productId: product.productId,
    generatedAt: new Date().toISOString(),
    policy: pkg.hedgePolicy,
    orders,
    totalHedgeCostUsd: orders.reduce((s, o) => s + o.expectedCostUsd, 0),
    residualDeltaUsd: risk.deltaUsd * 0.02, // 98% hedge efficiency
    residualDv01Usd: risk.dv01Usd * 0.01,
    hedgedRatioPct: 98.5,
  };
}

/**
 * Package Compression & Netting Engine
 */
export function runPackageCompression(pkg: DerivativePackage): {
  originalLegCount: number;
  compressedLegCount: number;
  offsetLegsFound: Array<{ buyLeg: string; sellLeg: string; contractSymbol: string }>;
  capitalEfficiencyBoostPct: number;
} {
  const legMap: Record<string, { buyQty: number; sellQty: number }> = {};

  pkg.legs.forEach((leg) => {
    if (!legMap[leg.contractSymbol]) {
      legMap[leg.contractSymbol] = { buyQty: 0, sellQty: 0 };
    }
    if (leg.side === 'BUY') {
      legMap[leg.contractSymbol].buyQty += leg.quantity;
    } else {
      legMap[leg.contractSymbol].sellQty += leg.quantity;
    }
  });

  const offsetLegsFound: Array<{ buyLeg: string; sellLeg: string; contractSymbol: string }> = [];
  let compressedCount = 0;

  Object.entries(legMap).forEach(([symbol, counts]) => {
    if (counts.buyQty > 0 && counts.sellQty > 0) {
      offsetLegsFound.push({
        buyLeg: `BUY ${counts.buyQty} ${symbol}`,
        sellLeg: `SELL ${counts.sellQty} ${symbol}`,
        contractSymbol: symbol,
      });
      compressedCount++;
    } else {
      compressedCount++;
    }
  });

  const efficiencyBoost = offsetLegsFound.length > 0 ? (offsetLegsFound.length / pkg.legs.length) * 100 : 0;

  return {
    originalLegCount: pkg.legs.length,
    compressedLegCount: Math.max(1, compressedCount),
    offsetLegsFound,
    capitalEfficiencyBoostPct: efficiencyBoost,
  };
}
