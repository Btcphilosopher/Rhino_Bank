import express from 'express';
import { createServer as createViteServer } from 'vite';
import {
  INITIAL_FUTURES_CONTRACTS,
  SIGNATURE_PACKAGES,
  SIGNATURE_PRODUCTS,
  INITIAL_AUDIT_LOGS,
} from './src/services/marketData.js';
import {
  calculateLookThroughRisk,
  buildValuationBreakdown,
  runScenarioAnalysis,
  generateHedgeBook,
} from './src/services/quantEngine.js';
import {
  DerivativePackage,
  StructuredSecurity,
  FuturesContract,
  EventLogItem,
  RFQRequest,
} from './src/types/rhino.js';

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  app.use(express.json());

  // In-memory data store for server-side persistence
  const contractsMap: Record<string, FuturesContract> = {};
  INITIAL_FUTURES_CONTRACTS.forEach((c) => (contractsMap[c.symbol] = { ...c }));

  const packagesMap: Record<string, DerivativePackage> = {};
  SIGNATURE_PACKAGES.forEach((p) => (packagesMap[p.packageId] = { ...p }));

  const productsMap: Record<string, StructuredSecurity> = {};
  SIGNATURE_PRODUCTS.forEach((p) => (productsMap[p.productId] = { ...p }));

  const auditLogs: EventLogItem[] = [...INITIAL_AUDIT_LOGS];
  const rfqList: RFQRequest[] = [
    {
      rfqId: 'RFQ-8821',
      clientName: 'BlackRock Systematic Macro',
      productId: 'RHINO-SOFR-CURVE-001',
      notionalUsd: 10000000,
      side: 'BUY',
      currency: 'USD',
      requestedMaturity: '2027-09-24',
      status: 'QUOTED',
      createdAt: new Date().toISOString(),
      quoteExpirySeconds: 120,
      quotedPrice: 103.85,
      fairValue: 103.50,
      quoteId: 'QUO-9910',
    },
  ];

  // API Router: /api/v1
  const api = express.Router();

  // Market snapshot
  api.get('/market/snapshot', (req, res) => {
    res.json({
      timestamp: new Date().toISOString(),
      contracts: Object.values(contractsMap),
    });
  });

  // Packages API
  api.get('/packages', (req, res) => {
    res.json(Object.values(packagesMap));
  });

  api.get('/packages/:id', (req, res) => {
    const pkg = packagesMap[req.params.id];
    if (!pkg) return res.status(404).json({ error: 'Package not found' });
    res.json(pkg);
  });

  api.post('/packages', (req, res) => {
    const newPkg = req.body as DerivativePackage;
    if (!newPkg.packageId) {
      newPkg.packageId = `PKG-CUSTOM-${Date.now().toString(36).toUpperCase()}`;
    }
    newPkg.createdAt = new Date().toISOString();
    newPkg.updatedAt = new Date().toISOString();
    packagesMap[newPkg.packageId] = newPkg;

    auditLogs.unshift({
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: 'PackageCreated',
      entityId: newPkg.packageId,
      entityName: newPkg.name,
      operator: 'Quant Structurer',
      details: `Created derivative package with ${newPkg.legs.length} legs.`,
      hash: `SHA256:${Math.random().toString(16).substring(2, 10)}`,
    });

    res.status(201).json(newPkg);
  });

  api.post('/packages/:id/validate', (req, res) => {
    const pkg = packagesMap[req.params.id] || req.body;
    if (!pkg) return res.status(404).json({ error: 'Package not found' });

    const errors: string[] = [];
    const warnings: string[] = [];

    if (!pkg.legs || pkg.legs.length === 0) {
      errors.push('Package must contain at least one leg.');
    }

    let zeroQtyCount = 0;
    pkg.legs?.forEach((leg: any, idx: number) => {
      if (leg.quantity <= 0) zeroQtyCount++;
      if (!contractsMap[leg.contractSymbol] && !leg.isNestedPackage) {
        warnings.push(`Leg ${idx + 1} references unmapped underlying contract: ${leg.contractSymbol}`);
      }
    });

    if (zeroQtyCount > 0) {
      warnings.push(`${zeroQtyCount} leg(s) have zero quantity and will contribute zero risk/value.`);
    }

    res.json({
      valid: errors.length === 0,
      packageId: pkg.packageId,
      errors,
      warnings,
      checkedAt: new Date().toISOString(),
    });
  });

  api.post('/packages/:id/price', (req, res) => {
    const pkg = packagesMap[req.params.id];
    if (!pkg) return res.status(404).json({ error: 'Package not found' });
    const breakdown = buildValuationBreakdown(pkg, contractsMap);
    res.json(breakdown);
  });

  api.post('/packages/:id/risk', (req, res) => {
    const pkg = packagesMap[req.params.id];
    if (!pkg) return res.status(404).json({ error: 'Package not found' });
    const risk = calculateLookThroughRisk(pkg, packagesMap, contractsMap);
    res.json(risk);
  });

  api.post('/packages/:id/stress', (req, res) => {
    const pkg = packagesMap[req.params.id];
    if (!pkg) return res.status(404).json({ error: 'Package not found' });
    const scenarios = runScenarioAnalysis(pkg, contractsMap);
    res.json(scenarios);
  });

  api.post('/packages/:id/hedge', (req, res) => {
    const pkg = packagesMap[req.params.id];
    if (!pkg) return res.status(404).json({ error: 'Package not found' });
    const dummyProduct: StructuredSecurity = {
      productId: `PROD-${pkg.packageId}`,
      version: '1.0',
      name: pkg.name,
      currency: pkg.currency,
      issueDate: new Date().toISOString(),
      maturityDate: '2027-12-31',
      denominationUsd: 1000,
      totalNotionalIssuedUsd: 10000000,
      outstandingNotionalUsd: 10000000,
      referencePackageId: pkg.packageId,
      referencePackageName: pkg.name,
      payoff: pkg.payoff,
      coupon: { type: 'FIXED', ratePct: 5.0, frequency: 'ANNUAL' },
      principalProtectionPct: 100,
      issuerCredit: {
        issuerName: 'RhinoQuant SA',
        rating: 'AA',
        creditSpreadBps: 50,
        defaultProbabilityPct: 0.1,
        recoveryRatePct: 40,
        fundingCurveRatePct: 5.0,
      },
      classification: 'STRUCTURED_NOTE',
      lifecycleStatus: 'ISSUED',
      feesPct: 0.3,
      canonicalHash: 'HASH123',
      payoffHash: 'PAYOFF123',
      packageHash: 'PKG123',
      createdAt: new Date().toISOString(),
      history: [],
    };

    const risk = calculateLookThroughRisk(pkg, packagesMap, contractsMap);
    const hedgeBook = generateHedgeBook(dummyProduct, pkg, risk);
    res.json(hedgeBook);
  });

  // Products API
  api.get('/products', (req, res) => {
    res.json(Object.values(productsMap));
  });

  api.get('/products/:id', (req, res) => {
    const prod = productsMap[req.params.id];
    if (!prod) return res.status(404).json({ error: 'Product not found' });
    res.json(prod);
  });

  api.post('/products', (req, res) => {
    const newProd = req.body as StructuredSecurity;
    if (!newProd.productId) {
      newProd.productId = `RHINO-STRUCT-${Math.floor(100000 + Math.random() * 900000)}`;
    }
    newProd.createdAt = new Date().toISOString();
    productsMap[newProd.productId] = newProd;

    auditLogs.unshift({
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: 'ProductCreated',
      entityId: newProd.productId,
      entityName: newProd.name,
      operator: 'Product Desk',
      details: `Created structured security linked to package ${newProd.referencePackageId}`,
      hash: `SHA256:${Math.random().toString(16).substring(2, 10)}`,
    });

    res.status(201).json(newProd);
  });

  api.post('/products/:id/issue', (req, res) => {
    const prod = productsMap[req.params.id];
    if (!prod) return res.status(404).json({ error: 'Product not found' });
    prod.lifecycleStatus = 'ISSUED';

    auditLogs.unshift({
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: 'ProductIssued',
      entityId: prod.productId,
      entityName: prod.name,
      operator: 'Issuer Desk',
      details: `Issued $${prod.totalNotionalIssuedUsd.toLocaleString()} USD under version ${prod.version}`,
      hash: `SHA256:${Math.random().toString(16).substring(2, 10)}`,
    });

    res.json({ message: 'Product issued successfully', product: prod });
  });

  api.post('/products/:id/redeem', (req, res) => {
    const prod = productsMap[req.params.id];
    if (!prod) return res.status(404).json({ error: 'Product not found' });
    prod.lifecycleStatus = 'REDEEMED';
    prod.outstandingNotionalUsd = 0;

    auditLogs.unshift({
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: 'ProductRedeemed',
      entityId: prod.productId,
      entityName: prod.name,
      operator: 'Calculation Agent',
      details: 'Product matured and redeemed at par plus performance coupon.',
      hash: `SHA256:${Math.random().toString(16).substring(2, 10)}`,
    });

    res.json({ message: 'Product redeemed successfully', product: prod });
  });

  api.get('/products/:id/valuation', (req, res) => {
    const prod = productsMap[req.params.id];
    if (!prod) return res.status(404).json({ error: 'Product not found' });
    const pkg = packagesMap[prod.referencePackageId];
    if (!pkg) return res.status(400).json({ error: 'Reference package missing' });

    const breakdown = buildValuationBreakdown(pkg, contractsMap);
    res.json(breakdown);
  });

  api.get('/products/:id/risk', (req, res) => {
    const prod = productsMap[req.params.id];
    if (!prod) return res.status(404).json({ error: 'Product not found' });
    const pkg = packagesMap[prod.referencePackageId];
    if (!pkg) return res.status(400).json({ error: 'Reference package missing' });

    const risk = calculateLookThroughRisk(pkg, packagesMap, contractsMap);
    res.json(risk);
  });

  api.get('/products/:id/cashflows', (req, res) => {
    const prod = productsMap[req.params.id];
    if (!prod) return res.status(404).json({ error: 'Product not found' });

    const cashflows = [
      {
        id: 'CF-1',
        date: '2026-12-24',
        type: 'COUPON',
        amount: (prod.denominationUsd * prod.coupon.ratePct) / 100 / 4,
        currency: prod.currency,
        condition: 'SOFR Spread > 0',
        status: 'PENDING',
      },
      {
        id: 'CF-2',
        date: '2027-03-24',
        type: 'COUPON',
        amount: (prod.denominationUsd * prod.coupon.ratePct) / 100 / 4,
        currency: prod.currency,
        condition: 'SOFR Spread > 0',
        status: 'PENDING',
      },
      {
        id: 'CF-3',
        date: '2027-09-24',
        type: 'PRINCIPAL',
        amount: prod.denominationUsd,
        currency: prod.currency,
        condition: 'Maturity Principal Protection (100%)',
        status: 'PENDING',
      },
    ];

    res.json(cashflows);
  });

  api.get('/products/:id/hedge', (req, res) => {
    const prod = productsMap[req.params.id];
    if (!prod) return res.status(404).json({ error: 'Product not found' });
    const pkg = packagesMap[prod.referencePackageId];
    if (!pkg) return res.status(400).json({ error: 'Reference package missing' });

    const risk = calculateLookThroughRisk(pkg, packagesMap, contractsMap);
    const hedgeBook = generateHedgeBook(prod, pkg, risk);
    res.json(hedgeBook);
  });

  api.get('/products/:id/audit', (req, res) => {
    const filtered = auditLogs.filter((l) => l.entityId === req.params.id);
    res.json(filtered.length > 0 ? filtered : auditLogs);
  });

  // RFQ API
  api.post('/rfq', (req, res) => {
    const { clientName, productId, notionalUsd, side } = req.body;
    const prod = productsMap[productId] || Object.values(productsMap)[0];

    const newRfq: RFQRequest = {
      rfqId: `RFQ-${Math.floor(1000 + Math.random() * 9000)}`,
      clientName: clientName || 'Institutional Client',
      productId: prod?.productId,
      notionalUsd: notionalUsd || 5000000,
      side: side || 'BUY',
      currency: 'USD',
      requestedMaturity: prod?.maturityDate || '2027-09-24',
      status: 'QUOTED',
      createdAt: new Date().toISOString(),
      quoteExpirySeconds: 120,
      quotedPrice: 103.75,
      fairValue: 103.42,
      quoteId: `QUO-${Math.floor(1000 + Math.random() * 9000)}`,
    };

    rfqList.unshift(newRfq);
    res.status(201).json(newRfq);
  });

  // RQSP Import/Export
  api.get('/rqsp/export/:id', (req, res) => {
    const prod = productsMap[req.params.id];
    if (!prod) return res.status(404).json({ error: 'Product not found' });
    const pkg = packagesMap[prod.referencePackageId];

    const rqspData = {
      format: 'RHINOQUANT_STRUCTURED_PRODUCT_SPECIFICATION_v1',
      productId: prod.productId,
      version: prod.version,
      name: prod.name,
      currency: prod.currency,
      package: pkg,
      payoff: prod.payoff,
      securityWrapper: {
        issuer: prod.issuerCredit,
        principalProtectionPct: prod.principalProtectionPct,
        coupon: prod.coupon,
        denominationUsd: prod.denominationUsd,
      },
      provenanceHashes: {
        canonicalHash: prod.canonicalHash,
        payoffHash: prod.payoffHash,
        packageHash: prod.packageHash,
      },
      exportedAt: new Date().toISOString(),
    };

    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="${prod.productId}.rqsp"`);
    res.json(rqspData);
  });

  app.use('/api/v1', api);

  // Setup Vite dev middleware or static serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RhinoQuant DERIVATIVE/Securities PACKAGING .OS running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start RhinoQuant server:', err);
});
