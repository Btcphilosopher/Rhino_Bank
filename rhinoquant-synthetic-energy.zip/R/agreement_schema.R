# RhinoQuant Synthetic Energy - Quantitative Finance Engine in R
# File: R/agreement_schema.R
# Author: RhinoQuant Quantitative Engineering, Rhino Bank

#' Define agreement schema and validation rules
#' @export
create_synthetic_agreement <- function(
  id,
  name,
  buyer_id,
  seller_id,
  agreement_type = c("FIXED_VOLUME_SYNTHETIC", "DEMAND_DEPENDENT_HEDGE", "FINANCIAL_CFD",
                     "VPPA", "OPTIONAL_ELECTRICITY_PURCHASE", "CAPACITY_AVAILABILITY",
                     "ENERGY_AND_CAPACITY_COMBINED", "GENERATION_REVENUE_LINKED",
                     "STRUCTURED_ENERGY_FINANCE"),
  currency = c("GBP", "USD", "EUR"),
  market_region = c("UK_N2EX", "ERCOT", "PJM", "CAISO", "NORD_POOL", "EPEX_SPOT_DE", "EPEX_SPOT_FR"),
  settlement_reference = "UK N2EX Day-Ahead Baseload",
  strike_price,
  start_date,
  end_date,
  tenor_years = 5,
  settlement_interval = c("ANNUAL", "QUARTERLY", "MONTHLY", "HOURLY", "HALF_HOURLY"),
  volume_mode = c("FIXED_VOLUME", "ACTUAL_METERED", "PERCENTAGE_OF_DEMAND", "OPTIONAL_VOLUME"),
  base_contracted_volume_mwh,
  demand_percentage = 80,
  min_volume_mwh = NULL,
  max_volume_mwh = NULL,
  take_or_pay_floor_mwh = NULL,
  price_floor = NULL,
  price_cap = NULL,
  option_premium_per_mwh = 0,
  exercise_hurdle_spread = 0,
  transaction_fee_per_mwh = 0,
  settlement_direction = c("BUYER_PROTECTIVE", "GENERATOR_PROTECTIVE"),
  has_linked_capacity = FALSE,
  linked_capacity_id = NULL,
  has_linked_financing = FALSE,
  linked_financing_id = NULL
) {
  agreement_type <- match.arg(agreement_type)
  currency <- match.arg(currency)
  market_region <- match.arg(market_region)
  settlement_interval <- match.arg(settlement_interval)
  volume_mode <- match.arg(volume_mode)
  settlement_direction <- match.arg(settlement_direction)

  stopifnot(is.numeric(strike_price), strike_price > 0)
  stopifnot(is.numeric(base_contracted_volume_mwh), base_contracted_volume_mwh >= 0)

  structure(
    list(
      id = id,
      name = name,
      buyer_id = buyer_id,
      seller_id = seller_id,
      agreement_type = agreement_type,
      currency = currency,
      market_region = market_region,
      settlement_reference = settlement_reference,
      strike_price = strike_price,
      start_date = as.Date(start_date),
      end_date = as.Date(end_date),
      tenor_years = tenor_years,
      settlement_interval = settlement_interval,
      volume_mode = volume_mode,
      base_contracted_volume_mwh = base_contracted_volume_mwh,
      demand_percentage = demand_percentage,
      min_volume_mwh = min_volume_mwh,
      max_volume_mwh = max_volume_mwh,
      take_or_pay_floor_mwh = take_or_pay_floor_mwh,
      price_floor = price_floor,
      price_cap = price_cap,
      option_premium_per_mwh = option_premium_per_mwh,
      exercise_hurdle_spread = exercise_hurdle_spread,
      transaction_fee_per_mwh = transaction_fee_per_mwh,
      settlement_direction = settlement_direction,
      has_linked_capacity = has_linked_capacity,
      linked_capacity_id = linked_capacity_id,
      has_linked_financing = has_linked_financing,
      linked_financing_id = linked_financing_id,
      status = "ACTIVE",
      version = 1,
      created_at = Sys.time()
    ),
    class = "synthetic_electricity_agreement"
  )
}
