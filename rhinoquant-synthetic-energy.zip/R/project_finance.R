# RhinoQuant Synthetic Energy - Project Finance & Debt Modeling in R
# File: R/project_finance.R
# Author: RhinoQuant Quantitative Engineering, Rhino Bank

#' Model Project Finance, CFADS, and Debt Service Coverage Ratios
#' @export
model_project_finance <- function(
  nameplate_capacity_mw = 50,
  total_capex = 65000000,
  construction_months = 24,
  operational_life_years = 25,
  gross_capacity_factor_pct = 43.5,
  availability_pct = 96.5,
  curtailment_pct = 2.0,
  fixed_opex_per_year = 1650000,
  variable_opex_per_mwh = 2.25,
  debt_pct = 70,
  senior_debt_rate = 0.0585,
  debt_tenor_years = 15,
  strike_price = 75.0,
  contracted_volume_mwh = 80000,
  merchant_price = 65.0,
  capacity_revenue_per_year = 3000000
) {
  construction_years <- ceiling(construction_months / 12)
  senior_principal <- total_capex * (debt_pct / 100)
  sponsor_equity <- total_capex * ((100 - debt_pct) / 100)

  # Annuity payment for debt service
  r <- senior_debt_rate
  n <- debt_tenor_years
  annuity_payment <- (senior_principal * (r * (1 + r)^n)) / ((1 + r)^n - 1)

  # Operational generation
  cf <- gross_capacity_factor_pct / 100
  avail <- availability_pct / 100
  curt <- curtailment_pct / 100
  annual_generation_mwh <- nameplate_capacity_mw * 8760 * cf * avail * (1 - curt)

  hedged_mwh <- min(annual_generation_mwh, contracted_volume_mwh)
  merchant_mwh <- max(0, annual_generation_mwh - hedged_mwh)

  hedged_rev <- hedged_mwh * strike_price
  merchant_rev <- merchant_mwh * merchant_price
  total_rev <- hedged_rev + merchant_rev + capacity_revenue_per_year

  opex <- fixed_opex_per_year + variable_opex_per_mwh * annual_generation_mwh
  ebitda <- total_rev - opex
  cfads <- max(0, ebitda * 0.90) # tax and reserve buffer

  dscr <- cfads / annuity_payment

  list(
    total_capex = total_capex,
    senior_debt_principal = senior_principal,
    sponsor_equity = sponsor_equity,
    annual_generation_mwh = annual_generation_mwh,
    hedged_revenue = hedged_rev,
    merchant_revenue = merchant_rev,
    capacity_revenue = capacity_revenue_per_year,
    total_revenue = total_rev,
    ebitda = ebitda,
    cfads = cfads,
    annual_debt_service = annuity_payment,
    dscr = dscr,
    is_covenant_compliant = dscr >= 1.25
  )
}
