# RhinoQuant Synthetic Energy - Strike Price & Settlement Engine
# File: R/strike_price_engine.R
# Author: RhinoQuant Quantitative Engineering, Rhino Bank

#' Calculate Strike-Price Settlement
#'
#' Under Buyer-Protective financial contract:
#' Buyer Settlement = (Reference Price - Strike Price) * Settled MWh
#' Under Generator-Protective financial contract:
#' Generator Settlement = (Strike Price - Reference Price) * Settled MWh
#'
#' @param reference_price Numeric. Market reference price in currency/MWh.
#' @param strike_price Numeric. Contract strike price in currency/MWh.
#' @param volume_mwh Numeric. Eligible energy volume in MWh.
#' @param settlement_direction Character. 'BUYER_PROTECTIVE' or 'GENERATOR_PROTECTIVE'.
#' @param price_cap Numeric or NULL. Maximum price ceiling for settlement.
#' @param price_floor Numeric or NULL. Minimum price floor for settlement.
#' @param transaction_fee_per_mwh Numeric. Transaction fees per MWh.
#' @param option_premium_per_mwh Numeric. Option premium per MWh.
#' @return A list with effective price, price spread, gross and net settlements.
#' @export
calculate_strike_settlement <- function(
  reference_price,
  strike_price,
  volume_mwh,
  settlement_direction = c("BUYER_PROTECTIVE", "GENERATOR_PROTECTIVE"),
  price_cap = NULL,
  price_floor = NULL,
  transaction_fee_per_mwh = 0,
  option_premium_per_mwh = 0,
  is_exercised = TRUE
) {
  settlement_direction <- match.arg(settlement_direction)

  if (volume_mwh <= 0 || !is_exercised) {
    opt_prem <- option_premium_per_mwh * max(0, volume_mwh)
    return(list(
      effective_price = reference_price,
      price_spread = 0,
      gross_settlement = 0,
      option_premium = opt_prem,
      fees = 0,
      net_settlement = -opt_prem
    ))
  }

  eff_ref <- reference_price
  if (!is.null(price_floor) && eff_ref < price_floor) eff_ref <- price_floor
  if (!is.null(price_cap) && eff_ref > price_cap) eff_ref <- price_cap

  if (settlement_direction == "BUYER_PROTECTIVE") {
    spread <- eff_ref - strike_price
  } else {
    spread <- strike_price - eff_ref
  }

  gross <- spread * volume_mwh
  opt_prem <- option_premium_per_mwh * volume_mwh
  fees <- transaction_fee_per_mwh * volume_mwh
  net <- gross - opt_prem - fees

  list(
    effective_price = eff_ref,
    price_spread = spread,
    gross_settlement = gross,
    option_premium = opt_prem,
    fees = fees,
    net_settlement = net
  )
}
