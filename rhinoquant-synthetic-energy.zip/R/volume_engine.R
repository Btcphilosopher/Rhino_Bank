# RhinoQuant Synthetic Energy - Volume & Capacity Engines in R
# File: R/volume_engine.R
# Author: RhinoQuant Quantitative Engineering, Rhino Bank

#' Calculate eligible contracted volume according to contract volume mode
#' @export
calculate_contracted_volume <- function(
  agreement,
  metered_demand_mwh,
  market_reference_price,
  curtailment_percent = 0
) {
  mode <- agreement$volume_mode
  raw_vol <- 0
  is_exercised <- TRUE

  if (mode == "FIXED_VOLUME") {
    raw_vol <- agreement$base_contracted_volume_mwh
  } else if (mode == "ACTUAL_METERED") {
    raw_vol <- metered_demand_mwh
  } else if (mode == "PERCENTAGE_OF_DEMAND") {
    pct <- ifelse(is.null(agreement$demand_percentage), 1.0, agreement$demand_percentage / 100)
    raw_vol <- metered_demand_mwh * pct
  } else if (mode == "OPTIONAL_VOLUME") {
    hurdle <- ifelse(is.null(agreement$exercise_hurdle_spread), 0, agreement$exercise_hurdle_spread)
    is_exercised <- market_reference_price > (agreement$strike_price + hurdle)
    raw_vol <- ifelse(is_exercised, agreement$base_contracted_volume_mwh, 0)
  }

  curtailment_deduction <- (curtailment_percent / 100) * raw_vol
  vol_after_curtail <- max(0, raw_vol - curtailment_deduction)

  if (!is.null(agreement$max_volume_mwh) && vol_after_curtail > agreement$max_volume_mwh) {
    vol_after_curtail <- agreement$max_volume_mwh
  }
  if (!is.null(agreement$min_volume_mwh) && vol_after_curtail < agreement$min_volume_mwh && is_exercised) {
    vol_after_curtail <- agreement$min_volume_mwh
  }

  list(
    mode = mode,
    metered_demand_mwh = metered_demand_mwh,
    raw_contracted_volume_mwh = raw_vol,
    eligible_settlement_volume_mwh = vol_after_curtail,
    is_option_exercised = is_exercised,
    curtailment_deduction_mwh = curtailment_deduction,
    unhedged_residual_demand_mwh = max(0, metered_demand_mwh - vol_after_curtail)
  )
}
