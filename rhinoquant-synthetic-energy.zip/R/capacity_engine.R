# RhinoQuant Synthetic Energy - Capacity & Project Finance in R
# File: R/capacity_engine.R
# Author: RhinoQuant Quantitative Engineering, Rhino Bank

#' Calculate installed capacity settlement and availability penalties
#' @export
calculate_capacity_settlement <- function(
  contracted_capacity_mw,
  capacity_price_per_mw_year,
  target_availability_pct = 95.0,
  actual_availability_pct = 95.0,
  penalty_multiplier = 1.5,
  year_index = 1,
  is_storage = FALSE,
  storage_capacity_mwh = NULL,
  annual_degradation_pct = 2.0
) {
  base_payment <- contracted_capacity_mw * capacity_price_per_mw_year
  shortfall <- max(0, target_availability_pct - actual_availability_pct)
  penalty <- 0

  if (shortfall > 0) {
    penalty <- base_payment * (shortfall / 100) * penalty_multiplier
  }

  net_payment <- max(0, base_payment - penalty)

  effective_storage_mwh <- NULL
  if (is_storage && !is.null(storage_capacity_mwh)) {
    degradation_factor <- (1 - annual_degradation_pct / 100)^(year_index - 1)
    effective_storage_mwh <- storage_capacity_mwh * degradation_factor * (actual_availability_pct / 100)
  }

  list(
    contracted_capacity_mw = contracted_capacity_mw,
    capacity_price_per_mw_year = capacity_price_per_mw_year,
    base_capacity_payment = base_payment,
    target_availability_pct = target_availability_pct,
    actual_availability_pct = actual_availability_pct,
    penalty_amount = penalty,
    net_adjusted_capacity_payment = net_payment,
    monthly_payment = net_payment / 12,
    effective_storage_mwh = effective_storage_mwh
  )
}
