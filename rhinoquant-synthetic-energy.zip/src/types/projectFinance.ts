/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Synthetic Energy - Project Finance & Generation Installation Types
 */

import { Currency, GenerationTechnology } from './agreement';

export type DebtStructure = 'SENIOR_TERM_LOAN' | 'MEZZANINE_SUBORDINATED' | 'PROJECT_BOND' | 'HYBRID_FACILITY';
export type AmortizationProfile = 'SCULPTED_DSCR' | 'ANNUITY_EQUAL_INSTALLMENTS' | 'STRAIGHT_LINE' | 'BULLET';

export interface PowerInstallationProject {
  id: string;
  name: string;
  technology: GenerationTechnology;
  location: string;
  nameplateCapacityMW: number;
  currency: Currency;
  
  // Timeline
  developmentStart: string;
  constructionMonths: number;
  commercialOperationDate: string; // COD
  operationalLifeYears: number;
  
  // CAPEX & OPEX
  totalCapex: number; // e.g. £65,000,000
  developmentCosts: number; // e.g. £3,500,000
  gridConnectionCosts: number; // e.g. £4,000,000
  fixedOpexPerYear: number; // e.g. £1,800,000
  variableOpexPerMWh: number; // e.g. £2.5/MWh
  annualDegradationPercent: number; // e.g. 0.5%
  decommissioningReservePerYear: number;
  
  // Generation & Yield Assumptions
  grossCapacityFactorPercent: number; // e.g. 42% for offshore wind
  availabilityPercent: number; // e.g. 96%
  curtailmentLossPercent: number; // e.g. 2.5%
  p50AnnualGenerationMWh: number;
  p90AnnualGenerationMWh: number;
  
  // Storage specific (if BESS or Hybrid)
  storageMWh?: number;
  roundTripEfficiency?: number;
  cyclesPerDay?: number;
  
  // Capital Structure
  debtPercentage: number; // e.g. 70%
  equityPercentage: number; // e.g. 30%
  seniorDebtInterestRate: number; // e.g. 0.0585 (5.85%)
  debtTenorYears: number; // e.g. 15 years
  gracePeriodYears: number; // e.g. 2 years (during construction)
  amortizationProfile: AmortizationProfile;
  targetMinimumDSCR: number; // e.g. 1.25x
  debtServiceReserveMonths: number; // e.g. 6 months
  taxRatePercent: number; // e.g. 25%
}

export interface ProjectAnnualCashFlow {
  year: number;
  phase: 'CONSTRUCTION' | 'OPERATIONAL' | 'DECOMMISSIONING';
  expectedGenerationMWh: number;
  
  // Revenues
  hedgedElectricityRevenue: number;
  merchantElectricityRevenue: number;
  capacityMarketRevenue: number;
  totalRevenue: number;
  
  // Costs
  operatingCosts: number;
  ebitda: number;
  depreciation: number;
  ebit: number;
  taxPaid: number;
  maintenanceReserve: number;
  
  // CFADS
  cfads: number; // Cash Flow Available for Debt Service
  
  // Debt Service
  openingDebtBalance: number;
  interestPaid: number;
  principalRepayment: number;
  totalDebtService: number;
  closingDebtBalance: number;
  
  // Equity Cash Flow
  freeCashFlowToEquity: number;
  
  // Coverage Ratios
  dscr: number; // CFADS / Debt Service
  llcr: number; // Loan Life Coverage Ratio
  plcr: number; // Project Life Coverage Ratio
}

export interface ProjectFinancialSummary {
  totalProjectCost: number;
  seniorDebtPrincipal: number;
  sponsorEquity: number;
  interestDuringConstruction: number;
  
  projectIRR: number; // Unlevered Project IRR
  equityIRR: number; // Levered Equity IRR
  projectNPV: number;
  equityNPV: number;
  
  minimumDSCR: number;
  averageDSCR: number;
  minimumLLCR: number;
  covenantBreached: boolean;
  
  breakEvenStrikePrice: number; // £/MWh needed for DSCR >= 1.05x
  breakEvenGenerationMWh: number;
  breakEvenCapacityFactor: number;
  repaymentMaturityYear: number;
}
