/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Synthetic Energy - Synthetic Instruments & Risk Types
 */

import { Currency } from './agreement';

export type InstrumentType =
  | 'REVENUE_LINKED_NOTE'
  | 'CAPACITY_REVENUE_NOTE'
  | 'GENERATION_CREDIT_LINKED_NOTE'
  | 'SYNTHETIC_TRANCHE_POOL'
  | 'ENERGY_RECEIVABLES_FACILITY'
  | 'CONSTRUCTION_RISK_PARTICIPATION';

export interface SyntheticTranche {
  trancheName: string; // e.g. Senior, Mezzanine, First-Loss Equity
  attachmentPointPercent: number; // e.g. 30%
  detachmentPointPercent: number; // e.g. 100%
  notional: number; // e.g. £15,000,000
  couponSpreadBps: number; // e.g. 250 bps
  allocatedLoss: number;
  remainingNotional: number;
  expectedYieldPercent: number;
  ratingAgencyImplied: string; // e.g. AAA, BBB-, B+
}

export interface SyntheticInstrument {
  id: string;
  name: string;
  instrumentType: InstrumentType;
  currency: Currency;
  notionalTotal: number;
  tenorYears: number;
  referenceAssetOrAgreement: string;
  referenceIndexName: string;
  baseCouponPercent: number;
  settlementMechanism: 'PHYSICAL_WATERFALL' | 'CASH_SETTLED_CFD' | 'CREDIT_DEFAULT_RECOVERY';
  recoveryAssumptionPercent: number; // e.g. 40%
  tranches: SyntheticTranche[];
  notes: string;
}

export interface WaterfallStep {
  priority: number;
  stepName: string;
  category: 'TAX_AND_OPEX' | 'SENIOR_DEBT_INTEREST' | 'SENIOR_PRINCIPAL' | 'MEZZANINE_DEBT' | 'SUBORDINATED_NOTES' | 'EQUITY_DISTRIBUTION';
  inflowAvailable: number;
  amountDue: number;
  amountPaid: number;
  shortfall: number;
  remainingCash: number;
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  priceShockPercent: number; // e.g. +100% or -50%
  demandShockPercent: number; // e.g. -20%
  generationShockPercent: number; // e.g. -25%
  capexOverrunPercent: number; // e.g. +20%
  delayMonths: number; // e.g. +12 months
  interestRateBpsShock: number; // e.g. +200 bps
}

export interface MonteCarloResult {
  simulationCount: number;
  seed: number;
  meanNetSettlement: number;
  standardDeviation: number;
  valueAtRisk95: number; // VaR 95%
  valueAtRisk99: number; // VaR 99%
  expectedShortfall95: number; // CVaR 95%
  expectedShortfall99: number; // CVaR 99%
  dscrDistribution: { percentile: number; dscrValue: number }[];
  covenantBreachProbability: number;
  histogramBins: { binStart: number; binEnd: number; frequency: number }[];
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userId: string;
  userRole: string;
  action: 'AGREEMENT_CREATED' | 'AGREEMENT_MODIFIED' | 'STRESS_TEST_RUN' | 'FINANCING_RESTRUCTURED' | 'MODEL_SAVED' | 'REPORT_GENERATED';
  entityId: string;
  entityName: string;
  details: string;
  previousValueSnapshot?: string;
  newValueSnapshot?: string;
}
