/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Synthetic Energy - Core Agreement Types
 */

export type Currency = 'GBP' | 'USD' | 'EUR';

export type MarketRegion = 
  | 'UK_N2EX'
  | 'ERCOT'
  | 'PJM'
  | 'CAISO'
  | 'NORD_POOL'
  | 'EPEX_SPOT_DE'
  | 'EPEX_SPOT_FR';

export type AgreementType =
  | 'FIXED_VOLUME_SYNTHETIC'
  | 'DEMAND_DEPENDENT_HEDGE'
  | 'FINANCIAL_CFD'
  | 'VPPA'
  | 'OPTIONAL_ELECTRICITY_PURCHASE'
  | 'CAPACITY_AVAILABILITY'
  | 'ENERGY_AND_CAPACITY_COMBINED'
  | 'GENERATION_REVENUE_LINKED'
  | 'STRUCTURED_ENERGY_FINANCE';

export type VolumeMode = 
  | 'FIXED_VOLUME'
  | 'ACTUAL_METERED'
  | 'PERCENTAGE_OF_DEMAND'
  | 'OPTIONAL_VOLUME';

export type SettlementInterval =
  | 'HALF_HOURLY'
  | 'HOURLY'
  | 'MONTHLY'
  | 'QUARTERLY'
  | 'ANNUAL';

export type AgreementStatus =
  | 'DRAFT'
  | 'PENDING_RISK_APPROVAL'
  | 'ACTIVE'
  | 'MATURED'
  | 'TERMINATED';

export type CounterpartyRole = 'BUYER' | 'SELLER' | 'DEVELOPER' | 'OFFTAKER' | 'FINANCIER';

export interface Counterparty {
  id: string;
  name: string;
  role: CounterpartyRole;
  creditRating: 'AAA' | 'AA+' | 'AA' | 'A+' | 'A' | 'BBB+' | 'BBB' | 'BB+' | 'BB' | 'B';
  creditSpreadBps: number; // e.g. 120 bps
  jurisdiction: string;
  csaAgreement: boolean;
  collateralThreshold: number; // in contract currency
}

export interface SyntheticElectricityAgreement {
  id: string;
  name: string;
  buyerId: string;
  sellerId: string;
  agreementType: AgreementType;
  currency: Currency;
  marketRegion: MarketRegion;
  settlementReference: string; // e.g., 'UK N2EX Day-Ahead Baseload'
  strikePrice: number; // in currency / MWh
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  tenorYears: number;
  settlementInterval: SettlementInterval;
  
  // Volume Terms
  volumeMode: VolumeMode;
  baseContractedVolumeMWh: number; // annual or total MWh
  demandPercentage?: number; // e.g. 80 for 80%
  minVolumeMWh?: number;
  maxVolumeMWh?: number;
  takeOrPayFloorMWh?: number;
  volumeTolerancePercent?: number; // e.g. 10 for +/-10%
  
  // Option terms (Mode 4)
  optionType?: 'CALL' | 'PUT';
  optionPremiumPerMWh?: number; // upfront or periodic premium
  exerciseHurdleSpread?: number; // e.g. £2/MWh buffer before exercise
  
  // Price boundaries
  priceCap?: number; // ceiling on reference settlement
  priceFloor?: number; // floor e.g. 0 to prevent negative settlement
  transactionFeePerMWh?: number;
  settlementDirection: 'BUYER_PROTECTIVE' | 'GENERATOR_PROTECTIVE';
  
  // Linked Components
  hasLinkedCapacity: boolean;
  linkedCapacityId?: string;
  hasLinkedFinancing: boolean;
  linkedFinancingId?: string;
  
  status: AgreementStatus;
  version: number;
  createdAt: string;
  updatedAt: string;
  tags?: string[];
  notes?: string;
}

export interface CapacityAgreement {
  id: string;
  agreementId: string;
  assetName: string;
  technology: GenerationTechnology;
  contractedCapacityMW: number;
  capacityPricePerMWYear: number; // in currency/MW-yr
  targetAvailabilityPercent: number; // e.g. 95%
  actualAvailabilityPercent: number; // e.g. 92%
  maintenanceAllowanceHours: number; // e.g. 300 hrs/yr
  forcedOutageRatePercent: number; // e.g. 3%
  penaltyMultiplier: number; // e.g. 1.5x deduction if below target
  commencementDate: string;
  expiryDate: string;
  
  // Battery Specific
  isStorage: boolean;
  storageCapacityMWh?: number; // e.g. 100 MWh for a 50 MW / 2hr battery
  roundTripEfficiencyPercent?: number; // e.g. 86%
  annualDegradationPercent?: number; // e.g. 2.0%
}

export type GenerationTechnology =
  | 'OFFSHORE_WIND'
  | 'ONSHORE_WIND'
  | 'SOLAR_PV'
  | 'BATTERY_STORAGE'
  | 'HYDROELECTRIC'
  | 'CCGT_CONVENTIONAL'
  | 'HYBRID_SOLAR_STORAGE';

export interface SettlementPeriodResult {
  periodIndex: number;
  periodLabel: string;
  marketReferencePrice: number;
  contractStrikePrice: number;
  meteredDemandMWh: number;
  eligibleVolumeMWh: number;
  effectivePriceSpread: number; // clamped by cap/floor
  grossEnergySettlement: number; // (Ref - Strike) * Volume
  optionPremiumPaid: number;
  capacityPayment: number;
  capacityPenalty: number;
  netSettlementCashFlow: number; // from Buyer's perspective (+ = inflow, - = outflow)
}

export interface AgreementSummaryMetrics {
  totalEligibleVolumeMWh: number;
  weightedAvgStrikePrice: number;
  totalEnergySettlement: number;
  totalCapacityPayment: number;
  netModelledCashFlow: number;
  presentValueNPV: number;
  buyerResidualMarketExposure: number;
  annualExpectedMWh: number;
}
