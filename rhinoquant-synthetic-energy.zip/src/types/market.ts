/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Synthetic Energy - Market Data & Forward Curves
 */

import { Currency, MarketRegion } from './agreement';

export interface ForwardCurvePoint {
  tenorYear: number;
  dateLabel: string;
  baseloadPrice: number; // in currency/MWh
  peakPrice: number;
  offPeakPrice: number;
  winterPrice: number;
  summerPrice: number;
  discountFactor: number; // risk-free or funding curve discount factor
}

export interface MarketForwardCurve {
  id: string;
  region: MarketRegion;
  currency: Currency;
  asOfDate: string;
  source: string;
  isObserved: boolean; // observed market vs simulated/modelled
  points: ForwardCurvePoint[];
}

export interface DemandProfilePoint {
  hourIndex: number; // 1-24 or 1-8760
  month: number;
  hourOfDay: number;
  demandMWh: number;
  profileType: 'INDUSTRIAL_24_7' | 'DATA_CENTER_FLAT' | 'MANUFACTURING_SHIFT' | 'COMMERCIAL_HVAC';
}

export interface MarketPriceObservation {
  timestamp: string;
  referencePrice: number;
  region: MarketRegion;
  currency: Currency;
  isNegative: boolean;
  isSpike: boolean;
  qualityFlag: 'VERIFIED' | 'ESTIMATED' | 'SYNTHETIC';
}
