/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Workspaces Navigation Bar
 */

import React from 'react';
import {
  LayoutDashboard,
  FilePlus2,
  TrendingUp,
  Gauge,
  Cpu,
  Building2,
  Layers,
  Calculator,
  AlertTriangle,
  Briefcase,
  FileText,
  GitCompare,
} from 'lucide-react';

export type WorkspaceTab =
  | 'OVERVIEW'
  | 'BUILDER'
  | 'STRIKE_DESK'
  | 'DEMAND_DESK'
  | 'CAPACITY_DESK'
  | 'PROJECT_FINANCE'
  | 'SYNTHETIC_LAB'
  | 'VALUATION_DESK'
  | 'RISK_ENGINE'
  | 'PORTFOLIO_DESK'
  | 'REPORTS_AUDIT'
  | 'HEDGE_COMPARATOR';

interface NavigationProps {
  activeTab: WorkspaceTab;
  onTabChange: (tab: WorkspaceTab) => void;
}

interface NavItem {
  key: WorkspaceTab;
  code: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const NAV_ITEMS: NavItem[] = [
  { key: 'OVERVIEW', code: '01', label: 'Energy Overview', icon: LayoutDashboard },
  { key: 'BUILDER', code: '02', label: 'Agreement Builder', icon: FilePlus2 },
  { key: 'STRIKE_DESK', code: '03', label: 'Strike Price Desk', icon: TrendingUp },
  { key: 'DEMAND_DESK', code: '04', label: 'Energy Demand Desk', icon: Gauge },
  { key: 'CAPACITY_DESK', code: '05', label: 'Capacity Desk', icon: Cpu },
  { key: 'PROJECT_FINANCE', code: '06', label: 'Installation Finance', icon: Building2 },
  { key: 'SYNTHETIC_LAB', code: '07', label: 'Synthetic Instrument Lab', icon: Layers },
  { key: 'VALUATION_DESK', code: '08', label: 'Valuation Desk', icon: Calculator },
  { key: 'RISK_ENGINE', code: '09', label: 'Risk Engine', icon: AlertTriangle },
  { key: 'PORTFOLIO_DESK', code: '10', label: 'Portfolio Desk', icon: Briefcase },
  { key: 'REPORTS_AUDIT', code: '11', label: 'Reports & Audit', icon: FileText },
  { key: 'HEDGE_COMPARATOR', code: '12', label: 'Hedge Comparator', icon: GitCompare },
];

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  return (
    <nav className="border-b border-slate-800 bg-[#091124] text-slate-300 px-6 py-1 overflow-x-auto no-print">
      <div className="flex items-center gap-1 max-w-[1720px] mx-auto min-w-max">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.key;
          return (
            <button
              key={item.key}
              onClick={() => onTabChange(item.key)}
              className={`flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-md transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 shadow-sm'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60 border border-transparent'
              }`}
            >
              <span className={`text-[10px] font-mono font-bold ${isActive ? 'text-amber-400' : 'text-slate-500'}`}>
                {item.code}
              </span>
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-300' : 'text-slate-400'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
