/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Workspace 03: Strike Price Desk
 */

import React, { useState } from 'react';
import { SyntheticElectricityAgreement } from '../types/agreement';
import { MarketForwardCurve } from '../types/market';
import { calculateStrikeSettlement } from '../models/strikeEngine';
import {
  TrendingUp,
  Sliders,
  Shield,
  Layers,
  ArrowRight,
  Info,
} from 'lucide-react';

interface StrikePriceDeskProps {
  agreements: SyntheticElectricityAgreement[];
  activeAgreementId: string;
  onSelectAgreement: (id: string) => void;
  activeCurve: MarketForwardCurve;
}

export const StrikePriceDesk: React.FC<StrikePriceDeskProps> = ({
  agreements,
  activeAgreementId,
  onSelectAgreement,
  activeCurve,
}) => {
  const selectedAgreement =
    agreements.find((a) => a.id === activeAgreementId) || agreements[0];

  const [simulatedRefPrice, setSimulatedRefPrice] = useState<number>(selectedAgreement.strikePrice + 15);
  const [usePriceFloor, setUsePriceFloor] = useState<boolean>(true);
  const [usePriceCap, setUsePriceCap] = useState<boolean>(true);

  // Generate sensitivity table across wholesale price scenarios
  const priceScenarios = [-20, 0, 25, 45, 60, 75, 90, 100, 120, 150, 180, 220, 280];

  const sensitivityRows = priceScenarios.map((refP) => {
    const calc = calculateStrikeSettlement({
      referencePrice: refP,
      strikePrice: selectedAgreement.strikePrice,
      volumeMWh: selectedAgreement.baseContractedVolumeMWh,
      settlementDirection: selectedAgreement.settlementDirection,
      priceFloor: usePriceFloor ? selectedAgreement.priceFloor : undefined,
      priceCap: usePriceCap ? selectedAgreement.priceCap : undefined,
      transactionFeePerMWh: selectedAgreement.transactionFeePerMWh,
    });

    return {
      referencePrice: refP,
      effectivePrice: calc.effectivePrice,
      spread: calc.priceSpread,
      grossSettlement: calc.grossSettlement,
      netSettlement: calc.netSettlement,
      isFloorActive: calc.effectivePrice !== refP && refP < (selectedAgreement.priceFloor ?? 0),
      isCapActive: calc.effectivePrice !== refP && refP > (selectedAgreement.priceCap ?? 999),
    };
  });

  const currentCalc = calculateStrikeSettlement({
    referencePrice: simulatedRefPrice,
    strikePrice: selectedAgreement.strikePrice,
    volumeMWh: selectedAgreement.baseContractedVolumeMWh,
    settlementDirection: selectedAgreement.settlementDirection,
    priceFloor: usePriceFloor ? selectedAgreement.priceFloor : undefined,
    priceCap: usePriceCap ? selectedAgreement.priceCap : undefined,
    transactionFeePerMWh: selectedAgreement.transactionFeePerMWh,
  });

  return (
    <div className="space-y-6">
      {/* Top Controls: Agreement Selector & Parameters */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">
            Workspace 03 · Forward Curve & Price Analytics
          </div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Strike Price Desk & Payoff Engine
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Model settlement schedules, asymmetric floor/cap protections, and negative pricing sensitivities.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label className="text-xs text-slate-400 font-medium">Select Agreement:</label>
          <select
            value={selectedAgreement.id}
            onChange={(e) => onSelectAgreement(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 font-medium focus:border-amber-400 focus:outline-none"
          >
            {agreements.map((a) => (
              <option key={a.id} value={a.id}>
                {a.id} — {a.name} (£{a.strikePrice.toFixed(2)}/MWh)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Contractual Strike Parameters Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-slate-900/50 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Contract Strike</span>
          <span className="font-mono font-bold text-amber-400 text-base">
            £{selectedAgreement.strikePrice.toFixed(2)}
          </span>
          <span className="text-slate-400 text-[10px] block mt-0.5">per MWh</span>
        </div>

        <div className="bg-slate-900/50 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Direction</span>
          <span className="font-mono font-bold text-slate-200 text-xs">
            {selectedAgreement.settlementDirection === 'BUYER_PROTECTIVE' ? 'Buyer Protective' : 'Generator Protective'}
          </span>
          <span className="text-slate-400 text-[10px] block mt-0.5">CfD Cash-Settled</span>
        </div>

        <div className="bg-slate-900/50 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Volume Unit</span>
          <span className="font-mono font-bold text-slate-200 text-base">
            {selectedAgreement.baseContractedVolumeMWh.toLocaleString()}
          </span>
          <span className="text-slate-400 text-[10px] block mt-0.5">MWh Annual Base</span>
        </div>

        <div className="bg-slate-900/50 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Price Floor</span>
          <span className="font-mono font-bold text-sky-400 text-base">
            {selectedAgreement.priceFloor !== undefined ? `£${selectedAgreement.priceFloor.toFixed(2)}` : 'None'}
          </span>
          <span className="text-slate-400 text-[10px] block mt-0.5">Floor Protection</span>
        </div>

        <div className="bg-slate-900/50 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Price Cap</span>
          <span className="font-mono font-bold text-purple-400 text-base">
            {selectedAgreement.priceCap !== undefined ? `£${selectedAgreement.priceCap.toFixed(2)}` : 'None'}
          </span>
          <span className="text-slate-400 text-[10px] block mt-0.5">Ceiling Limit</span>
        </div>

        <div className="bg-slate-900/50 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Reference Index</span>
          <span className="font-mono text-slate-200 text-xs truncate block">
            {selectedAgreement.settlementReference}
          </span>
          <span className="text-slate-400 text-[10px] block mt-0.5">{selectedAgreement.marketRegion}</span>
        </div>
      </div>

      {/* Payoff Diagram / Sensitivity Calculator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Spot Slider & Simulated Cash Flow (4 cols) */}
        <div className="lg:col-span-4 bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Settlement Simulator
            </h3>
            <span className="text-[11px] font-mono text-amber-400 font-bold">
              £{simulatedRefPrice.toFixed(2)} / MWh
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1 font-medium">Wholesale Reference Price</label>
              <input
                type="range"
                min="-20"
                max="200"
                step="1"
                value={simulatedRefPrice}
                onChange={(e) => setSimulatedRefPrice(parseFloat(e.target.value))}
                aria-label="Wholesale Reference Price"
                className="w-full accent-amber-400 h-1.5 bg-slate-800 rounded cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-1">
                <span>-£20 (Negative)</span>
                <span>£{selectedAgreement.strikePrice} (Strike)</span>
                <span>£200 (Spike)</span>
              </div>
            </div>

            <div className="flex items-center gap-4 pt-1">
              <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={usePriceFloor}
                  onChange={(e) => setUsePriceFloor(e.target.checked)}
                  className="accent-amber-400 rounded"
                />
                <span>Enable Floor (at £{selectedAgreement.priceFloor ?? 0})</span>
              </label>

              <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={usePriceCap}
                  onChange={(e) => setUsePriceCap(e.target.checked)}
                  className="accent-amber-400 rounded"
                />
                <span>Enable Cap (at £{selectedAgreement.priceCap ?? 250})</span>
              </label>
            </div>
          </div>

          {/* Model Output Card */}
          <div className="bg-slate-950 border border-slate-800 rounded p-4 space-y-2 text-xs font-mono">
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400 font-sans">Effective Settlement Price:</span>
              <span className="text-slate-100 font-bold">£{currentCalc.effectivePrice.toFixed(2)}/MWh</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400 font-sans">Price Spread (Ref - Strike):</span>
              <span className={currentCalc.priceSpread >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                {currentCalc.priceSpread >= 0 ? '+' : ''}£{currentCalc.priceSpread.toFixed(2)}/MWh
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400 font-sans">Contracted Volume:</span>
              <span className="text-slate-300">{selectedAgreement.baseContractedVolumeMWh.toLocaleString()} MWh</span>
            </div>
            <div className="flex justify-between py-2 bg-slate-900/80 px-2 rounded font-sans text-xs mt-2">
              <span className="font-semibold text-white">Net Settlement Payment:</span>
              <span className={`font-mono font-bold text-sm ${currentCalc.netSettlement >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {currentCalc.netSettlement >= 0 ? '+' : ''}£{currentCalc.netSettlement.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
              </span>
            </div>
            <p className="text-[10px] font-sans text-slate-400 pt-1">
              * Positive sign indicates payment to buyer; negative sign indicates payment from buyer.
            </p>
          </div>
        </div>

        {/* Right Column: Full Sensitivity Payoff Table (8 cols) */}
        <div className="lg:col-span-8 bg-slate-900/60 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Payoff Sensitivity Matrix Across Wholesale Price Scenarios
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Stress testing negative pricing, strike equality, and price cap ceilings.
              </p>
            </div>
            <div className="text-[11px] font-mono text-slate-400">
              dP/dSettlement = <span className="text-amber-400 font-bold">£{selectedAgreement.baseContractedVolumeMWh.toLocaleString()}</span> / £1 shock
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                  <th className="py-2.5 px-3">Reference Price</th>
                  <th className="py-2.5 px-3">Effective Price</th>
                  <th className="py-2.5 px-3 text-right">Spread vs Strike</th>
                  <th className="py-2.5 px-3 text-right">Net Settlement Cash Flow</th>
                  <th className="py-2.5 px-3 text-center font-sans">Boundary Rule</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40 text-slate-300">
                {sensitivityRows.map((row, idx) => {
                  const isCurrent = Math.abs(row.referencePrice - simulatedRefPrice) < 5;
                  const isStrike = row.referencePrice === selectedAgreement.strikePrice;
                  const isMasterPromptTest = row.referencePrice === 100 && selectedAgreement.strikePrice === 75;

                  return (
                    <tr
                      key={idx}
                      className={`hover:bg-slate-800/40 transition-colors ${
                        isMasterPromptTest ? 'bg-amber-950/20 font-bold' : isCurrent ? 'bg-slate-800/60' : ''
                      }`}
                    >
                      <td className="py-2 px-3 text-slate-200">
                        <span className={row.referencePrice < 0 ? 'text-rose-400 font-bold' : ''}>
                          £{row.referencePrice.toFixed(2)}/MWh
                        </span>
                      </td>
                      <td className="py-2 px-3 text-slate-300">
                        £{row.effectivePrice.toFixed(2)}/MWh
                      </td>
                      <td className={`py-2 px-3 text-right ${row.spread >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {row.spread >= 0 ? '+' : ''}£{row.spread.toFixed(2)}
                      </td>
                      <td className={`py-2 px-3 text-right font-bold ${row.netSettlement >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {row.netSettlement >= 0 ? '+' : '-'}£{Math.abs(row.netSettlement).toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-2 px-3 text-center font-sans text-[10px]">
                        {isMasterPromptTest ? (
                          <span className="text-amber-400 font-bold bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/30">
                            ★ Master Demonstration (£2.0M)
                          </span>
                        ) : isStrike ? (
                          <span className="text-slate-300 font-semibold bg-slate-800 px-1.5 py-0.5 rounded">
                            Strike Baseline (£0.00)
                          </span>
                        ) : row.isFloorActive ? (
                          <span className="text-sky-400 bg-sky-950/50 px-1.5 py-0.5 rounded border border-sky-800">
                            Floor Active (£0)
                          </span>
                        ) : row.isCapActive ? (
                          <span className="text-purple-400 bg-purple-950/50 px-1.5 py-0.5 rounded border border-purple-800">
                            Cap Ceiling (£250)
                          </span>
                        ) : (
                          <span className="text-slate-400">Standard Linear</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
