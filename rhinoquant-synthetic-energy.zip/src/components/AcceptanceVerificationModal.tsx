/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Section 19: 20 Acceptance Criteria & Invariant Verification Modal
 */

import React, { useState } from 'react';
import { runAcceptanceVerificationSuite, AcceptanceTestResult } from '../models/acceptanceTests';
import {
  CheckCircle2,
  XCircle,
  X,
  RotateCcw,
  ShieldCheck,
  Filter,
} from 'lucide-react';

interface AcceptanceVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AcceptanceVerificationModal: React.FC<AcceptanceVerificationModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [results, setResults] = useState<AcceptanceTestResult[]>(runAcceptanceVerificationSuite());
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  if (!isOpen) return null;

  const passedCount = results.filter((r) => r.passed).length;
  const filteredResults =
    categoryFilter === 'ALL' ? results : results.filter((r) => r.category === categoryFilter);

  const handleRerun = () => {
    setResults(runAcceptanceVerificationSuite());
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-[#091124] border border-slate-700 rounded-xl w-full max-w-5xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="border-b border-slate-800 p-5 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-tight">
                  Automated Invariant & Acceptance Verification Suite
                </h2>
                <span className="text-xs font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded">
                  {passedCount} / {results.length} PASSED
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Verification of the 20 institutional acceptance criteria specified in Section 19 of the Rhino Bank Master Specification.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleRerun}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium cursor-pointer transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Rerun Suite</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Category Filters */}
        <div className="border-b border-slate-800/80 px-5 py-2.5 bg-slate-950/60 flex flex-wrap items-center gap-1.5 text-xs">
          <span className="text-slate-400 mr-2 flex items-center gap-1">
            <Filter className="w-3 h-3" />
            <span>Category:</span>
          </span>
          {['ALL', 'STRIKE', 'VOLUME', 'CAPACITY', 'GENERATION', 'FINANCE', 'SYNTHETIC', 'RISK', 'GOVERNANCE'].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                categoryFilter === cat
                  ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Test List Table */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3">
          {filteredResults.map((test) => (
            <div
              key={test.id}
              className={`border rounded-lg p-3.5 text-xs transition-colors ${
                test.passed
                  ? 'bg-slate-900/40 border-slate-800/80 hover:border-slate-700'
                  : 'bg-rose-950/30 border-rose-500/50'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  {test.passed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  )}
                  <span className="font-mono text-slate-400 font-bold">
                    Test #{test.id.toString().padStart(2, '0')}
                  </span>
                  <span className="font-bold text-white text-xs">{test.title}</span>
                  <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                    {test.category}
                  </span>
                </div>

                <span
                  className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded self-start sm:self-auto ${
                    test.passed
                      ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800'
                      : 'bg-rose-950/80 text-rose-400 border border-rose-800'
                  }`}
                >
                  {test.passed ? 'PASSED' : 'FAILED'}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-800/60 font-mono text-[11px]">
                <div className="text-slate-400">
                  <span className="text-slate-400 block font-sans text-[10px]">Expected Invariant:</span>
                  <span className="text-slate-300">{test.expectedResult}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-sans text-[10px]">Actual Evaluated Result:</span>
                  <span className={test.passed ? 'text-emerald-300 font-bold' : 'text-rose-400 font-bold'}>
                    {test.actualResult}
                  </span>
                </div>
              </div>

              <div className="text-[11px] text-slate-400 font-sans mt-1.5">
                {test.details}
              </div>
            </div>
          ))}
        </div>

        {/* Modal Footer */}
        <div className="border-t border-slate-800 p-4 bg-slate-900/90 flex items-center justify-between text-xs">
          <span className="text-slate-400 font-mono">
            All invariant proofs calculated dynamically with exact mathematical reconciliation.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium cursor-pointer"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
