/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Workspace 01: Energy Overview
 */

import React from 'react';
import {
  SyntheticElectricityAgreement,
  CapacityAgreement,
} from '../types/agreement';
import { PowerInstallationProject } from '../types/projectFinance';
import { MarketForwardCurve } from '../types/market';
import { calculateStrikeSettlement } from '../models/strikeEngine';
import { calculateCapacitySettlement } from '../models/capacityEngine';
import {
  Zap,
  Activity,
  Layers,
  Building2,
  TrendingUp,
  ArrowUpRight,
  ShieldAlert,
  ChevronRight,
  Sliders,
} from 'lucide-react';

interface OverviewDeskProps {
  agreements: SyntheticElectricityAgreement[];
  projects: PowerInstallationProject[];
  capacities: CapacityAgreement[];
  activeCurve: MarketForwardCurve;
  onSelectAgreement: (id: string) => void;
  onNavigateTab: (tab: any) => void;
  simulatedSpotPrice: number;
  onSpotPriceChange: (price: number) => void;
}

export const OverviewDesk: React.FC<OverviewDeskProps> = ({
  agreements,
  projects,
  capacities,
  activeCurve,
  onSelectAgreement,
  onNavigateTab,
  simulatedSpotPrice,
  onSpotPriceChange,
}) => {
  // Aggregate portfolio metrics
  const totalContractedMWh = agreements.reduce((sum, a) => sum + a.baseContractedVolumeMWh, 0);
  const totalContractedMW = capacities.reduce((sum, c) => sum + c.contractedCapacityMW, 0);
  const totalCapex = projects.reduce((sum, p) => sum + p.totalCapex, 0);
  const totalSeniorDebt = projects.reduce((sum, p) => sum + (p.totalCapex * (p.debtPercentage / 100)), 0);

  // Calculate net portfolio settlement under current simulated spot price
  let netPortfolioSettlement = 0;
  for (const agr of agreements) {
    const calc = calculateStrikeSettlement({
      referencePrice: simulatedSpotPrice,
      strikePrice: agr.strikePrice,
      volumeMWh: agr.baseContractedVolumeMWh,
      settlementDirection: agr.settlementDirection,
      priceCap: agr.priceCap,
      priceFloor: agr.priceFloor,
    });
    netPortfolioSettlement += calc.netSettlement;
  }

  // Calculate annual capacity revenue across all agreements
  const totalCapacityAnnual = capacities.reduce((sum, c) => {
    const res = calculateCapacitySettlement(c);
    return sum + res.netAdjustedCapacityPayment;
  }, 0);

  return (
    <div className="space-y-6">
      {/* Top Banner: Master Demonstration Scenario Context */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider">
              <span>Section 20 Master Structure Calibrated</span>
              <span className="text-slate-600">·</span>
              <span className="text-slate-400">AeroTitan Advanced Materials Plc</span>
            </div>
            <h2 className="text-lg font-bold text-white tracking-tight">
              Synthetic Electricity CfD, 50 MW Capacity & Future Offshore Wind Financing
            </h2>
            <p className="text-xs text-slate-400 max-w-4xl leading-relaxed">
              Demonstrating simultaneous financial settlement at £75/MWh strike (80% of 100k MWh demand),
              50 MW capacity availability (£60k/MW-yr), and £65M Solway Firth project finance without double-counting.
            </p>
          </div>

          {/* Interactive Spot Shock Slider */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-md p-3 min-w-[320px]">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
              <span className="flex items-center gap-1.5 font-medium text-slate-300">
                <Sliders className="w-3.5 h-3.5 text-amber-400" />
                <span>Simulated Market Reference Price</span>
              </span>
              <span className="font-mono font-bold text-amber-300">
                £{simulatedSpotPrice.toFixed(2)} / MWh
              </span>
            </div>
            <input
              type="range"
              min="30"
              max="160"
              step="1"
              value={simulatedSpotPrice}
              onChange={(e) => onSpotPriceChange(parseFloat(e.target.value))}
              aria-label="Simulated Market Reference Price"
              className="w-full accent-amber-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
              <span>£30 (Crash)</span>
              <span>£75 (Strike)</span>
              <span>£100 (Prompt Test)</span>
              <span>£160 (Spike)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Contracted Energy Volume</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tracking-tight">
            {totalContractedMWh.toLocaleString()} <span className="text-xs text-slate-400 font-normal">MWh/yr</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <span>Across</span>
            <span className="font-semibold text-slate-300">{agreements.length} active agreements</span>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Contracted Capacity</span>
            <Layers className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tracking-tight">
            {totalContractedMW.toLocaleString()} <span className="text-xs text-slate-400 font-normal">MW</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            <span>Annual Capacity Value: </span>
            <span className="font-mono text-slate-300 font-semibold">£{(totalCapacityAnnual / 1e6).toFixed(2)}M/yr</span>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Net Energy Settlement</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className={`text-2xl font-bold font-mono tracking-tight ${netPortfolioSettlement >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {netPortfolioSettlement >= 0 ? '+' : '-'}£{(Math.abs(netPortfolioSettlement) / 1e6).toFixed(2)}M
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            <span>At £{simulatedSpotPrice.toFixed(2)}/MWh reference price</span>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Project Finance Exposure</span>
            <Building2 className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tracking-tight">
            £{(totalSeniorDebt / 1e6).toFixed(1)}M <span className="text-xs text-slate-400 font-normal">Debt</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            <span>Total CAPEX: </span>
            <span className="font-mono text-slate-300 font-semibold">£{(totalCapex / 1e6).toFixed(1)}M</span>
          </div>
        </div>
      </div>

      {/* Active Agreement Portfolio Table */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Active Synthetic Energy Agreements
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Live contractual commitments, strike parameters, linked assets and settlement direction.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('BUILDER')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-xs font-semibold transition-colors cursor-pointer"
          >
            <span>+ New Agreement</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-semibold">
                <th className="py-2.5 px-3">Agreement ID</th>
                <th className="py-2.5 px-3">Agreement Name</th>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">Region</th>
                <th className="py-2.5 px-3 font-mono text-right">Strike Price</th>
                <th className="py-2.5 px-3 font-mono text-right">Contracted MWh</th>
                <th className="py-2.5 px-3 text-center">Linked Components</th>
                <th className="py-2.5 px-3 font-mono text-right">Simulated Settlement</th>
                <th className="py-2.5 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {agreements.map((agr) => {
                const isMaster = agr.id.includes('UK-001');
                const calc = calculateStrikeSettlement({
                  referencePrice: simulatedSpotPrice,
                  strikePrice: agr.strikePrice,
                  volumeMWh: agr.baseContractedVolumeMWh,
                  settlementDirection: agr.settlementDirection,
                  priceCap: agr.priceCap,
                  priceFloor: agr.priceFloor,
                });

                return (
                  <tr
                    key={agr.id}
                    className={`hover:bg-slate-800/40 transition-colors ${isMaster ? 'bg-amber-950/10' : ''}`}
                  >
                    <td className="py-3 px-3 font-mono font-medium text-slate-300">
                      {agr.id}
                    </td>
                    <td className="py-3 px-3 font-medium text-white">
                      <div className="flex items-center gap-2">
                        <span>{agr.name}</span>
                        {isMaster && (
                          <span className="text-[10px] font-semibold text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
                            Master Demo
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-400">
                      {agr.agreementType.replace(/_/g, ' ')}
                    </td>
                    <td className="py-3 px-3 text-slate-300 font-mono text-[11px]">
                      {agr.marketRegion}
                    </td>
                    <td className="py-3 px-3 font-mono font-semibold text-right text-slate-100">
                      {agr.currency === 'GBP' ? '£' : agr.currency === 'EUR' ? '€' : '$'}
                      {agr.strikePrice.toFixed(2)}/MWh
                    </td>
                    <td className="py-3 px-3 font-mono text-right text-slate-300">
                      {agr.baseContractedVolumeMWh.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <div className="flex items-center justify-center gap-1.5 text-[10px]">
                        {agr.hasLinkedCapacity && (
                          <span className="bg-sky-950/60 text-sky-400 border border-sky-800 px-1.5 py-0.5 rounded">
                            Capacity MW
                          </span>
                        )}
                        {agr.hasLinkedFinancing && (
                          <span className="bg-purple-950/60 text-purple-400 border border-purple-800 px-1.5 py-0.5 rounded">
                            Project Finance
                          </span>
                        )}
                        {!agr.hasLinkedCapacity && !agr.hasLinkedFinancing && (
                          <span className="text-slate-400">Stand-Alone</span>
                        )}
                      </div>
                    </td>
                    <td className={`py-3 px-3 font-mono font-bold text-right ${calc.netSettlement >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {calc.netSettlement >= 0 ? '+' : '-'}£{Math.abs(calc.netSettlement).toLocaleString('en-GB', { maximumFractionDigits: 0 })}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <button
                        onClick={() => {
                          onSelectAgreement(agr.id);
                          onNavigateTab('STRIKE_DESK');
                        }}
                        className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium transition-colors cursor-pointer"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Forward Curve & Project Pipeline Summary Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Forward Curve Table */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                {activeCurve.region} Forward Reference Curve
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Baseload, peak/off-peak shaping and discount factors ({activeCurve.currency}/MWh).
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('STRIKE_DESK')}
              className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1"
            >
              <span>Curve Desk</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                  <th className="py-2 px-2">Tenor</th>
                  <th className="py-2 px-2 text-right">Baseload</th>
                  <th className="py-2 px-2 text-right">Peak</th>
                  <th className="py-2 px-2 text-right">Off-Peak</th>
                  <th className="py-2 px-2 text-right">Discount Factor</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40 text-slate-300">
                {activeCurve.points.map((pt) => (
                  <tr key={pt.tenorYear} className="hover:bg-slate-800/30">
                    <td className="py-2 px-2 font-sans font-medium text-slate-200">{pt.dateLabel}</td>
                    <td className="py-2 px-2 text-right font-bold text-amber-300">
                      £{pt.baseloadPrice.toFixed(2)}
                    </td>
                    <td className="py-2 px-2 text-right text-rose-300">£{pt.peakPrice.toFixed(2)}</td>
                    <td className="py-2 px-2 text-right text-sky-300">£{pt.offPeakPrice.toFixed(2)}</td>
                    <td className="py-2 px-2 text-right text-slate-400">{pt.discountFactor.toFixed(4)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Future Power Installations Pipeline */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Future Generation Installations Pipeline
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Project finance, construction milestones, and commercial operation dates (COD).
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('PROJECT_FINANCE')}
              className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1"
            >
              <span>Finance Desk</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {projects.map((proj) => (
              <div
                key={proj.id}
                className="bg-slate-950/60 border border-slate-800 rounded-md p-3 hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-xs text-white">
                    {proj.name}
                  </div>
                  <div className="text-[11px] font-mono text-purple-400 font-medium">
                    {proj.technology.replace(/_/g, ' ')}
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-2 mt-2 text-[11px] text-slate-400 font-mono">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Capacity</span>
                    <span className="text-slate-200 font-bold">{proj.nameplateCapacityMW} MW</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">CAPEX</span>
                    <span className="text-slate-200 font-bold">£{(proj.totalCapex / 1e6).toFixed(1)}M</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Senior Debt</span>
                    <span className="text-slate-200 font-bold">{proj.debtPercentage}%</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">COD</span>
                    <span className="text-amber-300 font-bold">{proj.commercialOperationDate}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
