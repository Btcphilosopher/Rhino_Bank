/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Workspace 04: Energy Demand Desk
 */

import React, { useState } from 'react';
import { SyntheticElectricityAgreement } from '../types/agreement';
import { calculateContractedVolume } from '../models/volumeEngine';
import { calculateStrikeSettlement } from '../models/strikeEngine';
import {
  Gauge,
  Sliders,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
} from 'lucide-react';

interface DemandDeskProps {
  agreements: SyntheticElectricityAgreement[];
  activeAgreementId: string;
  onSelectAgreement: (id: string) => void;
}

export const DemandDesk: React.FC<DemandDeskProps> = ({
  agreements,
  activeAgreementId,
  onSelectAgreement,
}) => {
  const selectedAgreement =
    agreements.find((a) => a.id === activeAgreementId) || agreements[0];

  const [meteredDemandInput, setMeteredDemandInput] = useState<number>(100000);
  const [profileType, setProfileType] = useState<string>('INDUSTRIAL_24_7');
  const [demandShockPercent, setDemandShockPercent] = useState<number>(0);
  const [curtailmentPercent, setCurtailmentPercent] = useState<number>(0);

  const effectiveMeteredDemand = meteredDemandInput * (1 + demandShockPercent / 100);

  const volCalc = calculateContractedVolume({
    agreement: selectedAgreement,
    meteredDemandMWh: effectiveMeteredDemand,
    marketReferencePrice: 85.0,
    curtailmentPercent,
  });

  const settlementPreview = calculateStrikeSettlement({
    referencePrice: 100.0,
    strikePrice: selectedAgreement.strikePrice,
    volumeMWh: volCalc.eligibleSettlementVolumeMWh,
    settlementDirection: selectedAgreement.settlementDirection,
  });

  // Monthly profile breakdown (12 months)
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthlyWeights = [0.095, 0.090, 0.088, 0.080, 0.076, 0.072, 0.070, 0.072, 0.078, 0.086, 0.093, 0.100];

  const monthlyBreakdown = monthNames.map((m, idx) => {
    const monthlyDemand = effectiveMeteredDemand * monthlyWeights[idx];
    const monthlyCalc = calculateContractedVolume({
      agreement: selectedAgreement,
      meteredDemandMWh: monthlyDemand,
      marketReferencePrice: 85.0,
      curtailmentPercent,
    });
    return {
      month: m,
      meteredDemand: monthlyDemand,
      contractedHedge: monthlyCalc.eligibleSettlementVolumeMWh,
      unhedgedResidual: monthlyCalc.unhedgedResidualDemandMWh,
    };
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">
            Workspace 04 · Load Profiling & Volumetric Engineering
          </div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Energy Demand Desk & Volume Engine
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Model metered consumption tracking, percentage-of-demand rules, volume caps/floors, and take-or-pay terms.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label className="text-xs text-slate-400 font-medium">Select Agreement:</label>
          <select
            value={selectedAgreement.id}
            onChange={(e) => onSelectAgreement(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 font-medium focus:border-amber-400 focus:outline-none"
          >
            {agreements.map((a) => (
              <option key={a.id} value={a.id}>
                {a.id} — {a.name} ({a.volumeMode.replace(/_/g, ' ')})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Primary Demand Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Actual Metered Demand</span>
          <div className="text-2xl font-bold font-mono text-white mt-1">
            {effectiveMeteredDemand.toLocaleString()} <span className="text-xs text-slate-400 font-normal">MWh</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Shock: <span className={demandShockPercent >= 0 ? 'text-emerald-400 font-mono' : 'text-rose-400 font-mono'}>{demandShockPercent >= 0 ? '+' : ''}{demandShockPercent}%</span>
          </span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Eligible Contracted Volume</span>
          <div className="text-2xl font-bold font-mono text-amber-400 mt-1">
            {volCalc.eligibleSettlementVolumeMWh.toLocaleString()} <span className="text-xs text-slate-400 font-normal">MWh</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {selectedAgreement.volumeMode === 'PERCENTAGE_OF_DEMAND'
              ? `${selectedAgreement.demandPercentage}% of metered demand`
              : 'Fixed / Optional volume'}
          </span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Residual Unhedged Demand</span>
          <div className="text-2xl font-bold font-mono text-slate-300 mt-1">
            {volCalc.unhedgedResidualDemandMWh.toLocaleString()} <span className="text-xs text-slate-400 font-normal">MWh</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Exposed to wholesale spot market</span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Take-or-Pay Status</span>
          <div className={`text-base font-bold font-mono mt-1 ${volCalc.takeOrPayTriggered ? 'text-rose-400' : 'text-emerald-400'}`}>
            {volCalc.takeOrPayTriggered ? 'PENALTY TRIGGERED' : 'SATISFIED (NO PENALTY)'}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Floor: {selectedAgreement.takeOrPayFloorMWh ? `${selectedAgreement.takeOrPayFloorMWh.toLocaleString()} MWh` : 'N/A'}
          </span>
        </div>
      </div>

      {/* Interactive Controls & Monthly Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sliders & Configuration (4 cols) */}
        <div className="lg:col-span-4 bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider border-b border-slate-800 pb-2">
            Demand Parameters & Stress Scenarios
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1 font-medium">Annual Baseline Demand (MWh)</label>
              <input
                type="number"
                step="5000"
                value={meteredDemandInput}
                onChange={(e) => setMeteredDemandInput(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100 font-mono font-bold focus:border-amber-400 focus:outline-none"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Demand Shock Stress:</span>
                <span className="font-mono font-bold text-amber-400">{demandShockPercent}%</span>
              </div>
              <input
                type="range"
                min="-50"
                max="50"
                step="5"
                value={demandShockPercent}
                onChange={(e) => setDemandShockPercent(parseFloat(e.target.value))}
                aria-label="Demand Shock Stress"
                className="w-full accent-amber-400 h-1.5 bg-slate-800 rounded cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-1">
                <span>-50% Slump</span>
                <span>0% Base</span>
                <span>+50% Surge</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Grid Curtailment:</span>
                <span className="font-mono font-bold text-amber-400">{curtailmentPercent}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="25"
                step="1"
                value={curtailmentPercent}
                onChange={(e) => setCurtailmentPercent(parseFloat(e.target.value))}
                aria-label="Grid Curtailment"
                className="w-full accent-amber-400 h-1.5 bg-slate-800 rounded cursor-pointer"
              />
            </div>

            <div className="pt-2 border-t border-slate-800 space-y-1 text-[11px] text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-400">Volume Cap:</span>
                <span className="font-mono">{selectedAgreement.maxVolumeMWh?.toLocaleString() ?? 'None'} MWh</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Volume Floor:</span>
                <span className="font-mono">{selectedAgreement.minVolumeMWh?.toLocaleString() ?? 'None'} MWh</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Tolerance:</span>
                <span className="font-mono">±{selectedAgreement.volumeTolerancePercent ?? 10}%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Monthly Breakdown Table (8 cols) */}
        <div className="lg:col-span-8 bg-slate-900/60 border border-slate-800 rounded-lg p-5">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
            Monthly Load Profile & Contract Volume Coverage
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                  <th className="py-2 px-3 font-sans">Month</th>
                  <th className="py-2 px-3 text-right">Metered Demand (MWh)</th>
                  <th className="py-2 px-3 text-right">Contracted Hedge (MWh)</th>
                  <th className="py-2 px-3 text-right">Residual Unhedged (MWh)</th>
                  <th className="py-2 px-3 text-right">Hedge Coverage</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40 text-slate-300">
                {monthlyBreakdown.map((row) => {
                  const coveragePct = (row.contractedHedge / row.meteredDemand) * 100;
                  return (
                    <tr key={row.month} className="hover:bg-slate-800/30">
                      <td className="py-2 px-3 font-sans font-medium text-slate-200">{row.month}</td>
                      <td className="py-2 px-3 text-right">{row.meteredDemand.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                      <td className="py-2 px-3 text-right text-amber-300 font-bold">
                        {row.contractedHedge.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </td>
                      <td className="py-2 px-3 text-right text-slate-400">
                        {row.unhedgedResidual.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </td>
                      <td className="py-2 px-3 text-right text-sky-400 font-bold">
                        {coveragePct.toFixed(1)}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
