/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Workspace 10: Cross-Agreement Portfolio Risk Desk
 */

import React, { useState } from 'react';
import {
  SyntheticElectricityAgreement,
  CapacityAgreement,
  Counterparty,
} from '../types/agreement';
import { PowerInstallationProject } from '../types/projectFinance';
import { calculateStrikeSettlement } from '../models/strikeEngine';
import {
  Briefcase,
  PieChart,
  Users,
  Globe,
  Layers,
  TrendingUp,
  Calendar,
  ShieldCheck,
} from 'lucide-react';

interface PortfolioDeskProps {
  agreements: SyntheticElectricityAgreement[];
  capacities: CapacityAgreement[];
  projects: PowerInstallationProject[];
  counterparties: Counterparty[];
  onSelectAgreement: (id: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const PortfolioDesk: React.FC<PortfolioDeskProps> = ({
  agreements,
  capacities,
  projects,
  counterparties,
  onSelectAgreement,
  onNavigateTab,
}) => {
  const [groupBy, setGroupBy] = useState<'COUNTERPARTY' | 'TYPE' | 'REGION' | 'TECHNOLOGY'>('COUNTERPARTY');

  // Total Portfolio Metrics
  const totalVolumeMWh = agreements.reduce((sum, a) => sum + a.baseContractedVolumeMWh, 0);
  const totalCapacityMW = capacities.reduce((sum, c) => sum + c.contractedCapacityMW, 0);
  const totalCapexExposure = projects.reduce((sum, p) => sum + p.totalCapex, 0);

  // Grouping Aggregations
  const counterpartyGroups = counterparties.map((cp) => {
    const cpAgreements = agreements.filter((a) => a.buyerId === cp.id || a.sellerId === cp.id);
    const volume = cpAgreements.reduce((sum, a) => sum + a.baseContractedVolumeMWh, 0);
    const notionalSettlement = cpAgreements.reduce((sum, a) => {
      const calc = calculateStrikeSettlement({
        referencePrice: 85.0,
        strikePrice: a.strikePrice,
        volumeMWh: a.baseContractedVolumeMWh,
        settlementDirection: a.settlementDirection,
      });
      return sum + calc.grossSettlement;
    }, 0);

    return {
      id: cp.id,
      name: cp.name,
      role: cp.role,
      rating: cp.creditRating,
      spreadBps: cp.creditSpreadBps,
      agreementCount: cpAgreements.length,
      volumeMWh: volume,
      volumeSharePct: totalVolumeMWh > 0 ? (volume / totalVolumeMWh) * 100 : 0,
      notionalSettlement,
    };
  }).filter((g) => g.agreementCount > 0);

  // Maturity Ladder (2026 to 2032)
  const maturityYears = [2026, 2027, 2028, 2029, 2030, 2031, 2032];
  const maturityLadder = maturityYears.map((yr) => {
    const activeInYear = agreements.filter((a) => {
      const startYr = parseInt(a.startDate.split('-')[0]);
      const endYr = parseInt(a.endDate.split('-')[0]);
      return yr >= startYr && yr <= endYr;
    });

    const maturingInYear = agreements.filter((a) => {
      const endYr = parseInt(a.endDate.split('-')[0]);
      return endYr === yr;
    });

    const volume = activeInYear.reduce((sum, a) => sum + a.baseContractedVolumeMWh, 0);

    return {
      year: yr,
      activeCount: activeInYear.length,
      maturingCount: maturingInYear.length,
      volumeMWh: volume,
    };
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">
            Workspace 10 · Cross-Agreement Portfolio Risk Desk
          </div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Portfolio Exposure, Counterparty Concentrations & Maturity Ladder
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Institutional portfolio view across multiple buyers, sellers, projects, currencies, and maturity tenors.
          </p>
        </div>

        {/* Group Selector */}
        <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded p-1 text-xs">
          <span className="text-slate-400 px-2 font-medium">Aggregate By:</span>
          {(['COUNTERPARTY', 'TYPE', 'REGION'] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => setGroupBy(mode)}
              className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                groupBy === mode
                  ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      {/* Primary Aggregate Portfolio KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Total Portfolio Volume</span>
          <div className="text-2xl font-bold font-mono text-white mt-1">
            {totalVolumeMWh.toLocaleString()} <span className="text-xs text-slate-400 font-normal">MWh/yr</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Across {agreements.length} institutional agreements
          </span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Total Committed Capacity</span>
          <div className="text-2xl font-bold font-mono text-sky-400 mt-1">
            {totalCapacityMW} <span className="text-xs text-slate-400 font-normal">MW</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Across {capacities.length} capacity reservation units
          </span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Project CAPEX Financed</span>
          <div className="text-2xl font-bold font-mono text-purple-400 mt-1">
            £{(totalCapexExposure / 1e6).toFixed(1)}M
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Across {projects.length} power installation assets
          </span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Active Counterparties</span>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            {counterpartyGroups.length}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Highest concentration: {counterpartyGroups[0]?.name.split(' ')[0]} ({counterpartyGroups[0]?.volumeSharePct.toFixed(0)}%)
          </span>
        </div>
      </div>

      {/* Counterparty Credit & Volume Concentration Table */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-3">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider">
          Counterparty Concentration & Credit Rating Exposure
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2.5 px-3 font-sans">Counterparty</th>
                <th className="py-2.5 px-3">Role</th>
                <th className="py-2.5 px-3">Credit Rating</th>
                <th className="py-2.5 px-3 text-right">Credit Spread</th>
                <th className="py-2.5 px-3 text-right">Agreements</th>
                <th className="py-2.5 px-3 text-right">Contracted MWh</th>
                <th className="py-2.5 px-3 text-right">Volume Share</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40 text-slate-300">
              {counterpartyGroups.map((cp) => (
                <tr key={cp.id} className="hover:bg-slate-800/30">
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-100">{cp.name}</td>
                  <td className="py-2.5 px-3 text-slate-400 font-sans">{cp.role}</td>
                  <td className="py-2.5 px-3">
                    <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 text-amber-300 font-bold">
                      {cp.rating}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-300">{cp.spreadBps} bps</td>
                  <td className="py-2.5 px-3 text-right text-slate-200">{cp.agreementCount}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-slate-100">
                    {cp.volumeMWh.toLocaleString()} MWh
                  </td>
                  <td className="py-2.5 px-3 text-right text-sky-400 font-bold">
                    {cp.volumeSharePct.toFixed(1)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Maturity Ladder Breakdown */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-3">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider">
          Maturity Ladder & Volume Expiration Profile (2026 - 2032)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2 px-3 font-sans">Calendar Year</th>
                <th className="py-2 px-3 text-right">Active Agreements</th>
                <th className="py-2 px-3 text-right">Maturing Agreements</th>
                <th className="py-2 px-3 text-right">Underwritten Volume (MWh)</th>
                <th className="py-2 px-3 font-sans text-center">Expiration Risk</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40 text-slate-300">
              {maturityLadder.map((row) => (
                <tr key={row.year} className="hover:bg-slate-800/30">
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-100">Cal-{row.year}</td>
                  <td className="py-2.5 px-3 text-right text-slate-300">{row.activeCount}</td>
                  <td className="py-2.5 px-3 text-right text-amber-400 font-bold">{row.maturingCount}</td>
                  <td className="py-2.5 px-3 text-right text-emerald-400 font-bold">
                    {row.volumeMWh.toLocaleString()} MWh
                  </td>
                  <td className="py-2.5 px-3 text-center font-sans text-[11px]">
                    {row.maturingCount > 0 ? (
                      <span className="text-amber-400 font-semibold bg-amber-950/40 px-1.5 py-0.5 rounded border border-amber-800/60">
                        {row.maturingCount} Contract(s) Expiring
                      </span>
                    ) : (
                      <span className="text-slate-400">Stable Tenor</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
