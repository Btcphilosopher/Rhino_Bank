/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Workspace 05: Installed Capacity Agreement Desk
 */

import React, { useState } from 'react';
import { CapacityAgreement } from '../types/agreement';
import { calculateCapacitySettlement } from '../models/capacityEngine';
import {
  Cpu,
  BatteryCharging,
  Sliders,
  AlertOctagon,
  CheckCircle2,
  TrendingDown,
} from 'lucide-react';

interface CapacityDeskProps {
  capacities: CapacityAgreement[];
  activeCapacityId: string;
  onSelectCapacity: (id: string) => void;
}

export const CapacityDesk: React.FC<CapacityDeskProps> = ({
  capacities,
  activeCapacityId,
  onSelectCapacity,
}) => {
  const selectedCapacity =
    capacities.find((c) => c.id === activeCapacityId) || capacities[0];

  const [simulatedAvailability, setSimulatedAvailability] = useState<number>(selectedCapacity.actualAvailabilityPercent);
  const [penaltyMultiplier, setPenaltyMultiplier] = useState<number>(selectedCapacity.penaltyMultiplier);

  const updatedCapacityObj: CapacityAgreement = {
    ...selectedCapacity,
    actualAvailabilityPercent: simulatedAvailability,
    penaltyMultiplier,
  };

  const settlement = calculateCapacitySettlement(updatedCapacityObj);

  // 10-year projection for degradation (especially for BESS or storage assets)
  const projectionYears = Array.from({ length: 10 }, (_, i) => i + 1);
  const degradationSchedule = projectionYears.map((yr) => {
    const res = calculateCapacitySettlement(updatedCapacityObj, yr);
    return {
      year: yr,
      netPayment: res.netAdjustedCapacityPayment,
      monthlyPayment: res.monthlyPayment,
      effectiveMWh: res.effectiveStorageCapacityMWh,
      degradationAdjustedMWh: res.degradationAdjustedMWh,
    };
  });

  return (
    <div className="space-y-6">
      {/* Top Controls */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-sky-400 uppercase tracking-wider">
            Workspace 05 · Installed Capacity & Availability Commitments
          </div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Capacity Desk & Asset Reliability Engine
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Model MW capacity commitments, target availability thresholds, forced outage penalties, and BESS degradation.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label className="text-xs text-slate-400 font-medium">Select Capacity Contract:</label>
          <select
            value={selectedCapacity.id}
            onChange={(e) => onSelectCapacity(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 font-medium focus:border-amber-400 focus:outline-none"
          >
            {capacities.map((c) => (
              <option key={c.id} value={c.id}>
                {c.id} — {c.assetName} ({c.contractedCapacityMW} MW @ £{c.capacityPricePerMWYear.toLocaleString()}/MW-yr)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* KPI Ribbon */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Contracted Capacity</span>
          <div className="text-2xl font-bold font-mono text-white mt-1">
            {selectedCapacity.contractedCapacityMW} <span className="text-xs text-slate-400 font-normal">MW</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Technology: <span className="text-slate-200">{selectedCapacity.technology.replace(/_/g, ' ')}</span>
          </span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Capacity Price</span>
          <div className="text-2xl font-bold font-mono text-sky-400 mt-1">
            £{selectedCapacity.capacityPricePerMWYear.toLocaleString()} <span className="text-xs text-slate-400 font-normal">/ MW-yr</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Base Annual: <span className="font-mono text-slate-200">£{(settlement.baseCapacityPayment / 1e6).toFixed(2)}M</span>
          </span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Availability Status</span>
          <div className="text-2xl font-bold font-mono text-white mt-1 flex items-center gap-2">
            <span>{simulatedAvailability.toFixed(1)}%</span>
            <span className="text-xs text-slate-400 font-normal">(Target: {selectedCapacity.targetAvailabilityPercent}%)</span>
          </div>
          <span className={`text-[11px] mt-1 block font-semibold ${settlement.availabilityShortfallPercent > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
            {settlement.availabilityShortfallPercent > 0
              ? `Shortfall: -${settlement.availabilityShortfallPercent.toFixed(1)}%`
              : 'Target Met (Full Payment)'}
          </span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Net Adjusted Payment</span>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            £{(settlement.netAdjustedCapacityPayment / 1e6).toFixed(3)}M
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Monthly: <span className="font-mono text-slate-300">£{settlement.monthlyPayment.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
          </span>
        </div>
      </div>

      {/* Simulator & Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Outage & Penalty Simulator (4 cols) */}
        <div className="lg:col-span-4 bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider border-b border-slate-800 pb-2">
            Availability & Outage Stress Simulator
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Modelled Availability (%):</span>
                <span className="font-mono font-bold text-sky-400">{simulatedAvailability.toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="65"
                max="100"
                step="0.5"
                value={simulatedAvailability}
                onChange={(e) => setSimulatedAvailability(parseFloat(e.target.value))}
                aria-label="Modelled Availability (%)"
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-1">
                <span>65% (Heavy Outage)</span>
                <span>{selectedCapacity.targetAvailabilityPercent}% Target</span>
                <span>100%</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Penalty Multiplier:</span>
                <span className="font-mono font-bold text-amber-400">{penaltyMultiplier.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="3.0"
                step="0.1"
                value={penaltyMultiplier}
                onChange={(e) => setPenaltyMultiplier(parseFloat(e.target.value))}
                aria-label="Penalty Multiplier"
                className="w-full accent-amber-400 h-1.5 bg-slate-800 rounded cursor-pointer"
              />
            </div>

            {selectedCapacity.isStorage && (
              <div className="bg-slate-950 border border-slate-800 rounded p-3 space-y-2 mt-3">
                <div className="flex items-center gap-2 text-amber-400 font-semibold">
                  <BatteryCharging className="w-4 h-4" />
                  <span>Battery Storage Modeling</span>
                </div>
                <div className="text-[11px] text-slate-400 space-y-1 font-mono">
                  <div className="flex justify-between">
                    <span>Storage Capacity:</span>
                    <span className="text-slate-200">{selectedCapacity.storageCapacityMWh} MWh</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Round-Trip Efficiency:</span>
                    <span className="text-slate-200">{selectedCapacity.roundTripEfficiencyPercent}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Annual Degradation:</span>
                    <span className="text-slate-200">{selectedCapacity.annualDegradationPercent}%/yr</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Multi-Year Schedule & Outage Penalty Breakdown (8 cols) */}
        <div className="lg:col-span-8 bg-slate-900/60 border border-slate-800 rounded-lg p-5">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
            Multi-Year Capacity Revenue & Degradation Profile
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                  <th className="py-2.5 px-3 font-sans">Year</th>
                  <th className="py-2.5 px-3 text-right">Annual Capacity Revenue</th>
                  <th className="py-2.5 px-3 text-right">Monthly Settlement</th>
                  {selectedCapacity.isStorage && (
                    <th className="py-2.5 px-3 text-right">Effective Storage (MWh)</th>
                  )}
                  <th className="py-2.5 px-3 text-center font-sans">Performance Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40 text-slate-300">
                {degradationSchedule.map((row) => (
                  <tr key={row.year} className="hover:bg-slate-800/30">
                    <td className="py-2 px-3 font-sans font-medium text-slate-200">Year {row.year}</td>
                    <td className="py-2 px-3 text-right font-bold text-sky-300">
                      £{row.netPayment.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-2 px-3 text-right text-slate-300">
                      £{row.monthlyPayment.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                    </td>
                    {selectedCapacity.isStorage && (
                      <td className="py-2 px-3 text-right text-amber-300">
                        {row.effectiveMWh ? row.effectiveMWh.toFixed(1) : '-'} MWh
                      </td>
                    )}
                    <td className="py-2 px-3 text-center font-sans text-[11px]">
                      {settlement.penaltyAmount > 0 ? (
                        <span className="text-rose-400 font-semibold bg-rose-950/40 px-1.5 py-0.5 rounded">
                          -£{settlement.penaltyAmount.toLocaleString()} Penalty
                        </span>
                      ) : (
                        <span className="text-emerald-400 font-semibold bg-emerald-950/40 px-1.5 py-0.5 rounded">
                          100% Target Met
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
