/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Workspace 07: Synthetic Instrument Lab & Structured Tranches Desk
 */

import React, { useState } from 'react';
import { SyntheticInstrument, SyntheticTranche } from '../types/syntheticInstruments';
import { executeCashWaterfall, allocateTrancheLosses } from '../models/syntheticLabEngine';
import {
  Layers,
  Sliders,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  ArrowDown,
  DollarSign,
  PieChart,
} from 'lucide-react';

interface SyntheticLabDeskProps {
  instruments: SyntheticInstrument[];
  activeInstrumentId: string;
  onSelectInstrument: (id: string) => void;
}

export const SyntheticLabDesk: React.FC<SyntheticLabDeskProps> = ({
  instruments,
  activeInstrumentId,
  onSelectInstrument,
}) => {
  const selectedInstrument =
    instruments.find((inst) => inst.id === activeInstrumentId) || instruments[0];

  const [poolLossInput, setPoolLossInput] = useState<number>(3500000); // £3.5M loss test case
  const [inflowAvailable, setInflowAvailable] = useState<number>(10000000); // £10M inflow for waterfall

  // Tranche loss allocation
  const lossRes = allocateTrancheLosses(poolLossInput, selectedInstrument.tranches);

  // Cash waterfall execution
  const waterfallRequirements = [
    { priority: 1, stepName: 'Taxes & Project OPEX', category: 'TAX_AND_OPEX' as any, amountDue: 2500000 },
    { priority: 2, stepName: 'Senior Debt Interest', category: 'SENIOR_DEBT_INTEREST' as any, amountDue: 3000000 },
    { priority: 3, stepName: 'Senior Debt Principal', category: 'SENIOR_PRINCIPAL' as any, amountDue: 3500000 },
    { priority: 4, stepName: 'Mezzanine Coupon (Class B)', category: 'MEZZANINE_DEBT' as any, amountDue: 1200000 },
    { priority: 5, stepName: 'Subordinated Notes & Reserves', category: 'SUBORDINATED_NOTES' as any, amountDue: 800000 },
    { priority: 6, stepName: 'Sponsor Equity Residual Distribution', category: 'EQUITY_DISTRIBUTION' as any, amountDue: 1500000 },
  ];

  const waterfallRes = executeCashWaterfall(inflowAvailable, waterfallRequirements);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">
            Workspace 07 · Structured Synthetic Finance & Risk Transfer
          </div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Synthetic Instrument Lab & Waterfall Desk
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Model revenue-linked notes, synthetic tranche subordination (Senior / Mezzanine / Equity), and cash-conserving waterfalls.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label className="text-xs text-slate-400 font-medium">Select Note Series:</label>
          <select
            value={selectedInstrument.id}
            onChange={(e) => onSelectInstrument(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 font-medium focus:border-amber-400 focus:outline-none"
          >
            {instruments.map((inst) => (
              <option key={inst.id} value={inst.id}>
                {inst.name} (Notional: £{(inst.notionalTotal / 1e6).toFixed(1)}M)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Synthetic Tranche Loss Allocation Section */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Subordinated Tranche Architecture & Loss Absorption
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Strict subordination: losses first exhaust First-Loss Equity (0-10%), then Mezzanine (10-30%), before touching Senior (30-100%).
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Total Reference Pool Notional:</span>
            <span className="font-mono font-bold text-white text-xs">
              £{(selectedInstrument.notionalTotal / 1e6).toFixed(1)}M
            </span>
          </div>
        </div>

        {/* Interactive Loss Slider */}
        <div className="bg-slate-950 border border-slate-800 rounded p-4 space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-medium">Simulated Pool Default / Revenue Loss:</span>
            <span className="font-mono font-bold text-rose-400 text-sm">
              £{poolLossInput.toLocaleString()} ({((poolLossInput / selectedInstrument.notionalTotal) * 100).toFixed(1)}% of Pool)
            </span>
          </div>
          <input
            type="range"
            min="0"
            max={selectedInstrument.notionalTotal}
            step="250000"
            value={poolLossInput}
            onChange={(e) => setPoolLossInput(parseFloat(e.target.value))}
            aria-label="Simulated Pool Default / Revenue Loss"
            className="w-full accent-rose-500 h-1.5 bg-slate-800 rounded cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-400 font-mono">
            <span>£0 (No Loss)</span>
            <span>£2.0M (Equity Wiped)</span>
            <span>£3.5M (Master Test)</span>
            <span>£6.0M (Mezz Wiped)</span>
            <span>£20.0M (Total Default)</span>
          </div>
        </div>

        {/* Visual Tranche Loss Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {lossRes.tranches.map((tranche) => {
            const lossPct = (tranche.allocatedLoss / tranche.notional) * 100;
            const isFullyImpaired = lossPct >= 99.9;
            const isProtected = lossPct <= 0.01;

            return (
              <div
                key={tranche.trancheName}
                className={`border rounded-lg p-4 space-y-2 ${
                  isFullyImpaired
                    ? 'bg-rose-950/20 border-rose-500/40'
                    : isProtected
                    ? 'bg-emerald-950/20 border-emerald-500/40'
                    : 'bg-amber-950/20 border-amber-500/40'
                }`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-xs font-bold text-white block">{tranche.trancheName}</span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      Attach: {tranche.attachmentPointPercent}% · Detach: {tranche.detachmentPointPercent}%
                    </span>
                  </div>
                  <span className="font-mono text-xs font-bold px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-200">
                    {tranche.ratingAgencyImplied}
                  </span>
                </div>

                <div className="space-y-1 text-xs font-mono pt-1">
                  <div className="flex justify-between text-slate-300">
                    <span>Tranche Notional:</span>
                    <span>£{(tranche.notional / 1e6).toFixed(2)}M</span>
                  </div>
                  <div className="flex justify-between text-rose-400 font-semibold">
                    <span>Allocated Loss:</span>
                    <span>-£{(tranche.allocatedLoss / 1e6).toFixed(2)}M</span>
                  </div>
                  <div className="flex justify-between text-slate-100 font-bold border-t border-slate-800/80 pt-1">
                    <span>Remaining Principal:</span>
                    <span>£{(tranche.remainingNotional / 1e6).toFixed(2)}M</span>
                  </div>
                  <div className="flex justify-between text-sky-400 pt-0.5">
                    <span>Yield (Adjusted):</span>
                    <span>{tranche.expectedYieldPercent.toFixed(2)}%</span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-2">
                  <div
                    className="bg-rose-500 h-full transition-all duration-300"
                    style={{ width: `${Math.min(100, lossPct)}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Cash Waterfall Priority Execution Table */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Institutional Cash-Flow Waterfall & Strict Cash Conservation
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Verified Invariant: Total Inflows == Total Distributed + Unallocated Cash. Zero leakage.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-400">Available Inflow:</span>
            <input
              type="number"
              step="500000"
              value={inflowAvailable}
              onChange={(e) => setInflowAvailable(parseFloat(e.target.value) || 0)}
              className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-amber-300 font-mono font-bold w-36"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2.5 px-3">Priority</th>
                <th className="py-2.5 px-3 font-sans">Payment Obligation</th>
                <th className="py-2.5 px-3 text-right">Inflow Available</th>
                <th className="py-2.5 px-3 text-right">Amount Due</th>
                <th className="py-2.5 px-3 text-right">Amount Paid</th>
                <th className="py-2.5 px-3 text-right">Shortfall</th>
                <th className="py-2.5 px-3 text-right">Remaining Cash</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40 text-slate-300">
              {waterfallRes.steps.map((step) => (
                <tr key={step.priority} className="hover:bg-slate-800/30">
                  <td className="py-2 px-3 text-slate-400 font-bold">#{step.priority}</td>
                  <td className="py-2 px-3 font-sans font-medium text-slate-200">{step.stepName}</td>
                  <td className="py-2 px-3 text-right text-slate-400">
                    £{step.inflowAvailable.toLocaleString()}
                  </td>
                  <td className="py-2 px-3 text-right text-slate-300">
                    £{step.amountDue.toLocaleString()}
                  </td>
                  <td className="py-2 px-3 text-right text-emerald-400 font-bold">
                    £{step.amountPaid.toLocaleString()}
                  </td>
                  <td className={`py-2 px-3 text-right ${step.shortfall > 0 ? 'text-rose-400 font-bold' : 'text-slate-400'}`}>
                    £{step.shortfall.toLocaleString()}
                  </td>
                  <td className="py-2 px-3 text-right text-sky-300">
                    £{step.remainingCash.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Conservation Invariant Bar */}
        <div className="bg-slate-950 border border-slate-800 rounded p-3 text-xs flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold text-emerald-300">Cash Conservation Invariant Verified:</span>
            <span className="text-slate-400">
              Inflows (£{waterfallRes.totalInflowAvailable.toLocaleString()}) == Distributed (£{waterfallRes.totalDistributed.toLocaleString()}) + Residual (£{waterfallRes.unallocatedCash.toLocaleString()})
            </span>
          </div>
          {waterfallRes.cumulativeShortfall > 0 && (
            <span className="text-rose-400 font-mono font-bold">
              Cumulative Shortfall: £{waterfallRes.cumulativeShortfall.toLocaleString()}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
