/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Workspace 08: Mark-to-Model Valuation & CVA Desk
 */

import React, { useState } from 'react';
import { SyntheticElectricityAgreement, Counterparty } from '../types/agreement';
import { MarketForwardCurve } from '../types/market';
import { calculateAgreementValuation } from '../models/valuationEngine';
import {
  Calculator,
  Sliders,
  ShieldAlert,
  TrendingUp,
  FileCheck2,
  DollarSign,
  AlertCircle,
} from 'lucide-react';

interface ValuationDeskProps {
  agreements: SyntheticElectricityAgreement[];
  activeAgreementId: string;
  onSelectAgreement: (id: string) => void;
  activeCurve: MarketForwardCurve;
  counterparties: Counterparty[];
}

export const ValuationDesk: React.FC<ValuationDeskProps> = ({
  agreements,
  activeAgreementId,
  onSelectAgreement,
  activeCurve,
  counterparties,
}) => {
  const selectedAgreement =
    agreements.find((a) => a.id === activeAgreementId) || agreements[0];

  const counterparty =
    counterparties.find((c) => c.id === selectedAgreement.buyerId) || counterparties[0];

  const [discountRate, setDiscountRate] = useState<number>(0.045); // 4.5% risk-free rate

  const valuation = calculateAgreementValuation(
    selectedAgreement,
    activeCurve,
    counterparty,
    discountRate
  );

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">
            Workspace 08 · Quantitative Valuation & Credit Adjustment
          </div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Mark-to-Model Valuation & CVA Desk
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Discounted expected cash flows, mark-to-model NPV, Bilateral Credit Valuation Adjustments (CVA), and Greeks.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label className="text-xs text-slate-400 font-medium">Select Agreement:</label>
          <select
            value={selectedAgreement.id}
            onChange={(e) => onSelectAgreement(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 font-medium focus:border-amber-400 focus:outline-none"
          >
            {agreements.map((a) => (
              <option key={a.id} value={a.id}>
                {a.id} — {a.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Primary Valuation KPI Ribbon */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Mark-to-Model NPV</span>
          <div className={`text-2xl font-bold font-mono mt-1 ${valuation.modelledNPV >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {valuation.modelledNPV >= 0 ? '+' : ''}£{(valuation.modelledNPV / 1e6).toFixed(3)}M
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Undiscounted: £{(valuation.undiscountedCashFlowSum / 1e6).toFixed(3)}M
          </span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Credit Valuation Adj (CVA)</span>
          <div className="text-2xl font-bold font-mono text-amber-400 mt-1">
            -£{valuation.creditValuationAdjustmentCVA.toLocaleString('en-GB', { maximumFractionDigits: 0 })}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Counterparty: {counterparty?.creditRating} ({counterparty?.creditSpreadBps} bps)
          </span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Net Risk-Adjusted MTM</span>
          <div className={`text-2xl font-bold font-mono mt-1 ${valuation.netRiskAdjustedMTM >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {valuation.netRiskAdjustedMTM >= 0 ? '+' : ''}£{(valuation.netRiskAdjustedMTM / 1e6).toFixed(3)}M
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Position: {valuation.isBuyerInTheMoney ? 'In-The-Money (Asset)' : 'Out-Of-The-Money (Liability)'}
          </span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
          <span className="text-slate-400 block text-xs font-semibold uppercase">Price Delta (dP/dMTM)</span>
          <div className="text-2xl font-bold font-mono text-sky-400 mt-1">
            £{(valuation.deltaWholesalePricePerMWh / 1000).toFixed(1)}k
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Sensitivity per £1/MWh shift</span>
        </div>
      </div>

      {/* Institutional Disclaimer Warning */}
      <div className="bg-slate-950 border border-slate-800 rounded-md p-3 text-xs text-slate-400 flex items-start gap-2.5">
        <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <p>
          <span className="text-slate-200 font-semibold">Institutional Governance Notice:</span> Modelled valuations reflect calibrated mark-to-model projections based on active broker forward curves and stated discount assumptions. They are not firm executable broker bid/offer quotations.
        </p>
      </div>

      {/* Multi-Year Discounted Cash Flow Waterfall Table */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            Discounted Cash-Flow Schedule Across Settlement Tenor (Cal-2026 — Cal-2030)
          </h3>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Discount Curve Rate:</span>
            <input
              type="number"
              step="0.005"
              value={discountRate}
              onChange={(e) => setDiscountRate(parseFloat(e.target.value) || 0.045)}
              className="bg-slate-950 border border-slate-800 rounded px-2 py-0.5 text-xs text-amber-400 font-mono w-20"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2.5 px-3 font-sans">Settlement Period</th>
                <th className="py-2.5 px-3 text-right">Forward Reference Price</th>
                <th className="py-2.5 px-3 text-right">Settled Volume (MWh)</th>
                <th className="py-2.5 px-3 text-right">Expected Cash Flow</th>
                <th className="py-2.5 px-3 text-right">Discount Factor</th>
                <th className="py-2.5 px-3 text-right">Discounted NPV</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40 text-slate-300">
              {valuation.settlementYears.map((yr) => (
                <tr key={yr.year} className="hover:bg-slate-800/30">
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-200">
                    Year {yr.year} (Cal-{2025 + yr.year})
                  </td>
                  <td className="py-2.5 px-3 text-right text-amber-300">
                    £{yr.forwardPrice.toFixed(2)}/MWh
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-200">
                    {yr.settledVolumeMWh.toLocaleString()}
                  </td>
                  <td className={`py-2.5 px-3 text-right ${yr.expectedCashFlow >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {yr.expectedCashFlow >= 0 ? '+' : ''}£{yr.expectedCashFlow.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-400">
                    {yr.discountFactor.toFixed(4)}
                  </td>
                  <td className={`py-2.5 px-3 text-right font-bold ${yr.discountedCashFlow >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {yr.discountedCashFlow >= 0 ? '+' : ''}£{yr.discountedCashFlow.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t border-slate-800 font-bold bg-slate-950/40">
                <td className="py-3 px-3 font-sans text-white">Cumulative Totals:</td>
                <td className="py-3 px-3 text-right text-slate-400">-</td>
                <td className="py-3 px-3 text-right text-slate-200">
                  {valuation.settlementYears.reduce((sum, y) => sum + y.settledVolumeMWh, 0).toLocaleString()} MWh
                </td>
                <td className={`py-3 px-3 text-right ${valuation.undiscountedCashFlowSum >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  £{(valuation.undiscountedCashFlowSum / 1e6).toFixed(3)}M
                </td>
                <td className="py-3 px-3 text-right text-slate-400">-</td>
                <td className={`py-3 px-3 text-right text-sm ${valuation.modelledNPV >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  £{(valuation.modelledNPV / 1e6).toFixed(3)}M
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
};
