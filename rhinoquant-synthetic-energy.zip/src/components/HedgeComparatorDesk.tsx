/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Workspace 12: Energy Procurement & Hedge Strategy Comparator (Section 14)
 */

import React, { useState } from 'react';
import { compareHedgeStrategies } from '../models/hedgeComparatorEngine';
import {
  GitCompare,
  Sliders,
  ShieldCheck,
  TrendingDown,
  Layers,
  ArrowRight,
  Info,
} from 'lucide-react';

export const HedgeComparatorDesk: React.FC = () => {
  const [annualDemandMWh, setAnnualDemandMWh] = useState<number>(100000);
  const [expectedWholesalePrice, setExpectedWholesalePrice] = useState<number>(85.0);
  const [strikePrice, setStrikePrice] = useState<number>(75.0);
  const [optionPremiumPerMWh, setOptionPremiumPerMWh] = useState<number>(6.50);
  const [capacityPricePerMWYear, setCapacityPricePerMWYear] = useState<number>(60000);
  const [peakCapacityNeededMW, setPeakCapacityNeededMW] = useState<number>(25);
  const [wholesaleVolatility, setWholesaleVolatility] = useState<number>(0.30);

  const results = compareHedgeStrategies({
    annualDemandMWh,
    expectedWholesalePrice,
    strikePrice,
    optionPremiumPerMWh,
    capacityPricePerMWYear,
    peakCapacityNeededMW,
    wholesalePriceVolatility: wholesaleVolatility,
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">
            Workspace 12 · Decision-Support & Procurement Strategy
          </div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Energy Procurement & Hedge Strategy Comparison
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Compare 6 alternative institutional contracting structures side-by-side: expected cost, tail risk, and collateral.
          </p>
        </div>

        <div className="text-right">
          <span className="text-[10px] text-slate-400 block">Baseline Demand</span>
          <span className="font-mono font-bold text-amber-300 text-sm">
            {annualDemandMWh.toLocaleString()} MWh / yr
          </span>
        </div>
      </div>

      {/* Input Parameter Controls */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
          Procurement Model Assumptions & Pricing Term Sheet
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
          <div>
            <label className="block text-slate-400 mb-1 font-medium">Annual Demand (MWh)</label>
            <input
              type="number"
              step="5000"
              value={annualDemandMWh}
              onChange={(e) => setAnnualDemandMWh(parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100 font-mono font-bold focus:border-amber-400 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1 font-medium">Expected Spot (£/MWh)</label>
            <input
              type="number"
              step="1"
              value={expectedWholesalePrice}
              onChange={(e) => setExpectedWholesalePrice(parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100 font-mono font-bold focus:border-amber-400 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1 font-medium">Contract Strike (£/MWh)</label>
            <input
              type="number"
              step="1"
              value={strikePrice}
              onChange={(e) => setStrikePrice(parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100 font-mono font-bold focus:border-amber-400 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1 font-medium">Option Premium (£/MWh)</label>
            <input
              type="number"
              step="0.5"
              value={optionPremiumPerMWh}
              onChange={(e) => setOptionPremiumPerMWh(parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100 font-mono font-bold focus:border-amber-400 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1 font-medium">Capacity (£/MW-yr)</label>
            <input
              type="number"
              step="5000"
              value={capacityPricePerMWYear}
              onChange={(e) => setCapacityPricePerMWYear(parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100 font-mono font-bold focus:border-amber-400 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1 font-medium">Spot Volatility (%)</label>
            <input
              type="number"
              step="5"
              value={Math.round(wholesaleVolatility * 100)}
              onChange={(e) => setWholesaleVolatility((parseFloat(e.target.value) || 30) / 100)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100 font-mono font-bold focus:border-amber-400 focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Comparison Matrix Table */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-3">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider">
          Strategy Comparison Matrix & Risk Profile
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px] font-semibold">
                <th className="py-2.5 px-3">Contracting Strategy</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3 font-mono text-right">Expected Cost</th>
                <th className="py-2.5 px-3 font-mono text-right">Effective £/MWh</th>
                <th className="py-2.5 px-3 font-mono text-right">Worst Case (95%)</th>
                <th className="py-2.5 px-3 text-center">Price Risk</th>
                <th className="py-2.5 px-3 text-center">Volume Flexibility</th>
                <th className="py-2.5 px-3 font-mono text-right">Collateral Buffer</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40 text-slate-300">
              {results.map((res) => {
                const isMasterStrategy = res.strategyKey === 'DEMAND_DEPENDENT_80';
                return (
                  <tr
                    key={res.strategyKey}
                    className={`hover:bg-slate-800/40 transition-colors ${
                      isMasterStrategy ? 'bg-amber-950/20 font-medium' : ''
                    }`}
                  >
                    <td className="py-3 px-3">
                      <div className="font-bold text-white flex items-center gap-2">
                        <span>{res.strategyName}</span>
                        {isMasterStrategy && (
                          <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1 py-0.5 rounded border border-amber-500/30">
                            Master Focus
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 font-normal mt-0.5 max-w-sm">
                        {res.description}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-400 text-[11px]">{res.category}</td>
                    <td className="py-3 px-3 font-mono font-bold text-right text-slate-100">
                      £{(res.expectedAnnualCost / 1e6).toFixed(2)}M
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-right text-amber-300">
                      £{res.effectiveCostPerMWh.toFixed(2)}
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-right text-rose-400">
                      £{(res.worstCaseCost95 / 1e6).toFixed(2)}M
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        res.priceRiskExposure === 'VERY_LOW'
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800'
                          : res.priceRiskExposure === 'LOW'
                          ? 'bg-sky-950/60 text-sky-400 border border-sky-800'
                          : 'bg-rose-950/60 text-rose-400 border border-rose-800'
                      }`}>
                        {res.priceRiskExposure}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center text-[10px] text-slate-300 font-mono">
                      {res.volumeFlexibility.replace(/_/g, ' ')}
                    </td>
                    <td className="py-3 px-3 font-mono text-right text-slate-400">
                      £{(res.collateralRequirement / 1e6).toFixed(2)}M
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Trade-Off Guidance Callout */}
      <div className="bg-slate-950 border border-slate-800 rounded-md p-4 text-xs text-slate-400 space-y-2">
        <div className="flex items-center gap-2 text-slate-200 font-semibold">
          <Info className="w-4 h-4 text-amber-400" />
          <span>RhinoQuant Quantitative Structuring Insights:</span>
        </div>
        <p className="leading-relaxed">
          No strategy is universally optimal under all market regimes. The <strong>Fixed Strike Agreement</strong> eliminates wholesale electricity volatility but carries negative mark-to-market if wholesale prices tumble. The <strong>Demand-Dependent 80% Hedge</strong> protects the buyer against factory shutdowns and volume shortfalls. The <strong>Optional-Volume Agreement</strong> acts as insurance, preserving market downside participation at the cost of an upfront premium. The <strong>Installation-Linked Structure</strong> provides long-term additionality and price certainty while directly supporting renewable project financing.
        </p>
      </div>
    </div>
  );
};
