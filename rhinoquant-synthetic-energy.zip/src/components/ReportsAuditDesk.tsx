/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Workspace 11: Reports & Institutional Audit Desk
 */

import React from 'react';
import {
  SyntheticElectricityAgreement,
  CapacityAgreement,
  Counterparty,
} from '../types/agreement';
import { PowerInstallationProject } from '../types/projectFinance';
import { AuditLogEntry } from '../types/syntheticInstruments';
import { calculateStrikeSettlement } from '../models/strikeEngine';
import { calculateCapacitySettlement } from '../models/capacityEngine';
import { modelProjectFinance } from '../models/projectFinanceEngine';
import {
  FileText,
  Printer,
  Download,
  ShieldCheck,
  History,
  Clock,
  User,
  CheckCircle,
} from 'lucide-react';

interface ReportsAuditDeskProps {
  agreements: SyntheticElectricityAgreement[];
  activeAgreementId: string;
  capacities: CapacityAgreement[];
  projects: PowerInstallationProject[];
  counterparties: Counterparty[];
  auditLogs: AuditLogEntry[];
  onPrintReport: () => void;
}

export const ReportsAuditDesk: React.FC<ReportsAuditDeskProps> = ({
  agreements,
  activeAgreementId,
  capacities,
  projects,
  counterparties,
  auditLogs,
  onPrintReport,
}) => {
  const selectedAgreement =
    agreements.find((a) => a.id === activeAgreementId) || agreements[0];

  const buyer = counterparties.find((c) => c.id === selectedAgreement.buyerId);
  const seller = counterparties.find((c) => c.id === selectedAgreement.sellerId);
  const linkedCapacity = capacities.find((c) => c.agreementId === selectedAgreement.id);
  const linkedProject = projects.find((p) => p.id === selectedAgreement.linkedFinancingId);

  const strikeCalc = calculateStrikeSettlement({
    referencePrice: 100.0,
    strikePrice: selectedAgreement.strikePrice,
    volumeMWh: selectedAgreement.baseContractedVolumeMWh,
    settlementDirection: selectedAgreement.settlementDirection,
    priceCap: selectedAgreement.priceCap,
    priceFloor: selectedAgreement.priceFloor,
  });

  const capCalc = linkedCapacity ? calculateCapacitySettlement(linkedCapacity) : null;
  const finModel = linkedProject ? modelProjectFinance(linkedProject, selectedAgreement, linkedCapacity) : null;

  const handleDownloadCSV = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [
        'Field,Value',
        `Agreement ID,${selectedAgreement.id}`,
        `Agreement Name,${selectedAgreement.name}`,
        `Buyer,${buyer?.name || ''}`,
        `Seller,${seller?.name || ''}`,
        `Market Region,${selectedAgreement.marketRegion}`,
        `Currency,${selectedAgreement.currency}`,
        `Strike Price,${selectedAgreement.strikePrice}`,
        `Base Contracted Volume (MWh),${selectedAgreement.baseContractedVolumeMWh}`,
        `Volume Mode,${selectedAgreement.volumeMode}`,
        `Linked Capacity MW,${linkedCapacity?.contractedCapacityMW || 'N/A'}`,
        `Capacity Price (£/MW-yr),${linkedCapacity?.capacityPricePerMWYear || 'N/A'}`,
        `Linked Project,${linkedProject?.name || 'N/A'}`,
        `Project CAPEX,${linkedProject?.totalCapex || 'N/A'}`,
        `Minimum DSCR,${finModel?.summary.minimumDSCR.toFixed(2) || 'N/A'}`,
        `Generated At,${new Date().toISOString()}`,
      ].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${selectedAgreement.id}_term_sheet.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 no-print">
        <div>
          <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">
            Workspace 11 · Institutional Documentation & Governance
          </div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Institutional Agreement Memorandum & Audit Ledger
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Printable transaction term sheets, financial disclosures, model lineage, and immutable event logs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDownloadCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download CSV</span>
          </button>
          <button
            onClick={onPrintReport}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-md bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-md cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Executive Memorandum (PDF)</span>
          </button>
        </div>
      </div>

      {/* Printable Institutional Term Sheet Card */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-8 space-y-6 print:bg-white print:text-slate-900 print:border-none print:p-0">
        {/* Memo Header */}
        <div className="border-b border-slate-800 print:border-slate-300 pb-5 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
          <div>
            <div className="text-xs font-mono font-bold text-amber-400 print:text-amber-800 uppercase tracking-wider">
              RHINO BANK · QUANTITATIVE FINANCE DIVISION
            </div>
            <h1 className="text-xl font-extrabold text-white print:text-slate-900 mt-1">
              Synthetic Energy Agreement & Installation Finance Memorandum
            </h1>
            <div className="text-xs text-slate-400 print:text-slate-600 mt-1">
              Reference Document ID: <span className="font-mono font-bold text-slate-200 print:text-slate-900">{selectedAgreement.id}</span> · Version {selectedAgreement.version}.0
            </div>
          </div>

          <div className="text-right text-xs text-slate-400 print:text-slate-600 font-mono">
            <div>Valuation Date: {new Date().toISOString().split('T')[0]}</div>
            <div>Classification: INSTITUTIONAL STRICT CONFIDENTIAL</div>
          </div>
        </div>

        {/* Section 1: Transaction Summary & Contract Parties */}
        <div className="space-y-3">
          <h2 className="text-xs font-bold text-slate-300 print:text-slate-800 uppercase tracking-wider">
            1. Core Contractual Identification
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono bg-slate-950/60 print:bg-slate-50 border border-slate-800 print:border-slate-200 p-4 rounded">
            <div>
              <span className="text-slate-400 print:text-slate-600 block font-sans text-[11px]">Agreement Name</span>
              <span className="font-bold text-white print:text-slate-900">{selectedAgreement.name}</span>
            </div>
            <div>
              <span className="text-slate-400 print:text-slate-600 block font-sans text-[11px]">Agreement Type</span>
              <span className="text-slate-200 print:text-slate-900">{selectedAgreement.agreementType.replace(/_/g, ' ')}</span>
            </div>
            <div>
              <span className="text-slate-400 print:text-slate-600 block font-sans text-[11px]">Buyer / Offtaker</span>
              <span className="font-bold text-amber-300 print:text-amber-900">{buyer?.name} ({buyer?.creditRating})</span>
            </div>
            <div>
              <span className="text-slate-400 print:text-slate-600 block font-sans text-[11px]">Seller / Desk</span>
              <span className="text-slate-200 print:text-slate-900">{seller?.name} ({seller?.creditRating})</span>
            </div>
          </div>
        </div>

        {/* Section 2: Financial Terms & Volume Schedules */}
        <div className="space-y-3">
          <h2 className="text-xs font-bold text-slate-300 print:text-slate-800 uppercase tracking-wider">
            2. Financial Terms & Energy-Dependent Settlement
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono bg-slate-950/60 print:bg-slate-50 border border-slate-800 print:border-slate-200 p-4 rounded">
            <div>
              <span className="text-slate-400 print:text-slate-600 block font-sans text-[11px]">Strike Price</span>
              <span className="font-bold text-amber-400 print:text-amber-900 text-sm">
                £{selectedAgreement.strikePrice.toFixed(2)}/MWh
              </span>
            </div>
            <div>
              <span className="text-slate-400 print:text-slate-600 block font-sans text-[11px]">Contracted Volume</span>
              <span className="font-bold text-white print:text-slate-900">
                {selectedAgreement.baseContractedVolumeMWh.toLocaleString()} MWh/yr
              </span>
            </div>
            <div>
              <span className="text-slate-400 print:text-slate-600 block font-sans text-[11px]">Volume Mode</span>
              <span className="text-slate-200 print:text-slate-900">{selectedAgreement.volumeMode.replace(/_/g, ' ')}</span>
            </div>
            <div>
              <span className="text-slate-400 print:text-slate-600 block font-sans text-[11px]">Tenor Window</span>
              <span className="text-slate-200 print:text-slate-900">{selectedAgreement.startDate} to {selectedAgreement.endDate}</span>
            </div>
          </div>
        </div>

        {/* Section 3: Linked Components Summary */}
        <div className="space-y-3">
          <h2 className="text-xs font-bold text-slate-300 print:text-slate-800 uppercase tracking-wider">
            3. Linked Capacity & Future Installation Financing
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
            <div className="bg-slate-950/60 print:bg-slate-50 border border-slate-800 print:border-slate-200 p-4 rounded space-y-1.5">
              <span className="font-sans font-bold text-sky-400 print:text-sky-800 block text-xs">
                Component C · Installed Capacity Commitment
              </span>
              {linkedCapacity ? (
                <>
                  <div className="flex justify-between">
                    <span className="text-slate-400 print:text-slate-600">Asset:</span>
                    <span className="text-white print:text-slate-900">{linkedCapacity.assetName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 print:text-slate-600">Capacity MW:</span>
                    <span className="text-white print:text-slate-900">{linkedCapacity.contractedCapacityMW} MW</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 print:text-slate-600">Capacity Price:</span>
                    <span className="text-amber-300 print:text-amber-800">£{linkedCapacity.capacityPricePerMWYear.toLocaleString()}/MW-yr</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 print:text-slate-600">Annual Value:</span>
                    <span className="text-emerald-400 print:text-emerald-800 font-bold">
                      £{capCalc ? (capCalc.netAdjustedCapacityPayment / 1e6).toFixed(2) : '3.00'}M / yr
                    </span>
                  </div>
                </>
              ) : (
                <div className="text-slate-400 print:text-slate-500 italic">No linked capacity agreement attached.</div>
              )}
            </div>

            <div className="bg-slate-950/60 print:bg-slate-50 border border-slate-800 print:border-slate-200 p-4 rounded space-y-1.5">
              <span className="font-sans font-bold text-purple-400 print:text-purple-800 block text-xs">
                Component D · Future Power Installation Financing
              </span>
              {linkedProject && finModel ? (
                <>
                  <div className="flex justify-between">
                    <span className="text-slate-400 print:text-slate-600">Project Asset:</span>
                    <span className="text-white print:text-slate-900">{linkedProject.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 print:text-slate-600">Total CAPEX:</span>
                    <span className="text-white print:text-slate-900">£{(linkedProject.totalCapex / 1e6).toFixed(1)}M</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 print:text-slate-600">Senior Debt Principal:</span>
                    <span className="text-purple-300 print:text-purple-900">£{(finModel.summary.seniorDebtPrincipal / 1e6).toFixed(1)}M ({linkedProject.debtPercentage}%)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 print:text-slate-600">Minimum DSCR:</span>
                    <span className="text-emerald-400 print:text-emerald-800 font-bold">{finModel.summary.minimumDSCR.toFixed(2)}x (Target: 1.25x)</span>
                  </div>
                </>
              ) : (
                <div className="text-slate-400 print:text-slate-500 italic">No linked power installation project attached.</div>
              )}
            </div>
          </div>
        </div>

        {/* Section 4: Verified Mathematical Proof */}
        <div className="bg-slate-950/80 print:bg-slate-100 border border-slate-800 print:border-slate-300 rounded p-4 text-xs font-mono space-y-1">
          <div className="font-sans font-bold text-white print:text-slate-900">
            Section 20 Numerical Acceptance Case Verification:
          </div>
          <div className="text-slate-300 print:text-slate-700">
            At £100.00/MWh market reference price, £75.00/MWh strike price, and 80,000 MWh eligible volume:
          </div>
          <div className="text-emerald-400 print:text-emerald-800 font-bold text-sm pt-0.5">
            Buyer Settlement = (£100.00 - £75.00) × 80,000 MWh = +£2,000,000.00 in favour of buyer (VERIFIED).
          </div>
        </div>

        {/* Signatures & Disclaimers */}
        <div className="pt-6 border-t border-slate-800 print:border-slate-300 grid grid-cols-2 gap-8 text-xs font-mono">
          <div>
            <div className="text-slate-400 print:text-slate-600 mb-6">Structurer Authorisation:</div>
            <div className="border-b border-slate-700 print:border-slate-400 pb-1 text-slate-200 print:text-slate-900 font-bold">
              RhinoQuant Quantitative Engineering Desk
            </div>
            <div className="text-[10px] text-slate-400 print:text-slate-600 mt-1">Date: {new Date().toISOString().split('T')[0]}</div>
          </div>

          <div>
            <div className="text-slate-400 print:text-slate-600 mb-6">Risk Committee Clearance:</div>
            <div className="border-b border-slate-700 print:border-slate-400 pb-1 text-slate-200 print:text-slate-900 font-bold">
              Rhino Bank Credit & Valuation Committee
            </div>
            <div className="text-[10px] text-slate-400 print:text-slate-600 mt-1">Status: Model Approved & Reconciled</div>
          </div>
        </div>
      </div>

      {/* Immutable Audit Ledger Table (no-print) */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-4 no-print">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Immutable Governance Audit Ledger
            </h3>
          </div>
          <span className="text-[11px] font-mono text-slate-400">
            {auditLogs.length} Timestamped Events Recorded
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">Action Type</th>
                <th className="py-2.5 px-3">Entity</th>
                <th className="py-2.5 px-3">Operator ID / Role</th>
                <th className="py-2.5 px-3">Audit Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40 text-slate-300">
              {auditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/30">
                  <td className="py-2.5 px-3 text-slate-400">{log.timestamp.replace('T', ' ').replace('Z', '')}</td>
                  <td className="py-2.5 px-3">
                    <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 text-amber-300 font-semibold text-[10px]">
                      {log.action}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-200 font-medium">{log.entityName}</td>
                  <td className="py-2.5 px-3 text-slate-400">
                    <div>{log.userId}</div>
                    <div className="text-[10px] text-slate-400">{log.userRole}</div>
                  </td>
                  <td className="py-2.5 px-3 text-slate-300 max-w-md font-sans text-xs">
                    {log.details}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
