/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Institutional Header
 */

import React from 'react';
import { Shield, CheckCircle2, Printer, RefreshCw, Activity } from 'lucide-react';
import { MarketRegion } from '../types/agreement';

interface HeaderProps {
  activeRegion: MarketRegion;
  onRegionChange: (r: MarketRegion) => void;
  onOpenAcceptanceTests: () => void;
  onPrintReport: () => void;
  onResetDemo: () => void;
  testPassCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeRegion,
  onRegionChange,
  onOpenAcceptanceTests,
  onPrintReport,
  onResetDemo,
  testPassCount,
}) => {
  return (
    <header className="border-b border-slate-800 bg-[#070e1e] text-slate-100 sticky top-0 z-40 px-6 py-3 no-print">
      <div className="flex flex-wrap items-center justify-between gap-4 max-w-[1720px] mx-auto">
        {/* Brand & Division */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-500/20 to-blue-600/30 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold tracking-wider">
            <Shield className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base tracking-tight text-white uppercase">
                RHINO<span className="text-amber-400">QUANT</span>
              </span>
              <span className="text-slate-600">/</span>
              <span className="text-xs font-semibold text-slate-400 tracking-wider uppercase">
                Synthetic Energy
              </span>
            </div>
            <div className="text-[11px] text-slate-400 font-normal">
              Rhino Bank Quantitative Finance Division · Institutional Power Desk
            </div>
          </div>
        </div>

        {/* Global Controls & Actions */}
        <div className="flex items-center gap-3">
          {/* Market Region Selector */}
          <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-800 rounded-md px-3 py-1.5 text-xs">
            <span className="text-slate-400 uppercase text-[10px] font-semibold tracking-wider">Market</span>
            <select
              value={activeRegion}
              onChange={(e) => onRegionChange(e.target.value as MarketRegion)}
              aria-label="Select Market Region"
              className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="UK_N2EX" className="bg-slate-900 text-slate-100">UK N2EX (GBP)</option>
              <option value="ERCOT" className="bg-slate-900 text-slate-100">US ERCOT (USD)</option>
              <option value="NORD_POOL" className="bg-slate-900 text-slate-100">Nord Pool System (EUR)</option>
              <option value="EPEX_SPOT_DE" className="bg-slate-900 text-slate-100">EPEX Spot DE (EUR)</option>
            </select>
          </div>

          {/* Automated Invariants & Acceptance Suite */}
          <button
            onClick={onOpenAcceptanceTests}
            className="flex items-center gap-2 px-3 py-1.5 rounded-md border border-emerald-500/30 bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 text-xs font-medium transition-colors cursor-pointer"
            title="Inspect the 20 Acceptance Criteria and Invariant Tests"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>20 Acceptance Tests</span>
            <span className="font-mono text-[11px] text-emerald-400 ml-1">
              ({testPassCount}/20 Passed)
            </span>
          </button>

          {/* Print / Institutional Report */}
          <button
            onClick={onPrintReport}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors cursor-pointer"
            title="Export Institutional Term Sheet and Audit Memorandum"
          >
            <Printer className="w-3.5 h-3.5 text-slate-300" />
            <span>Export Report</span>
          </button>

          {/* Reset Demo */}
          <button
            onClick={onResetDemo}
            className="p-1.5 rounded-md border border-slate-800 bg-slate-900/60 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
            title="Reset to Master Demonstration Scenario"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
