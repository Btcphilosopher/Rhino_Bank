/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Workspace 09: Risk & Stress Testing Engine
 */

import React, { useState } from 'react';
import { SyntheticElectricityAgreement, CapacityAgreement } from '../types/agreement';
import { PowerInstallationProject } from '../types/projectFinance';
import { runMonteCarloSimulation } from '../models/monteCarloEngine';
import {
  executeStressTest,
  PREDEFINED_STRESS_SCENARIOS,
  StressTestExecutionResult,
} from '../models/stressTestingEngine';
import {
  AlertTriangle,
  Play,
  Sliders,
  ShieldCheck,
  RotateCcw,
  BarChart3,
  TrendingDown,
  Activity,
} from 'lucide-react';

interface RiskEngineDeskProps {
  agreements: SyntheticElectricityAgreement[];
  activeAgreementId: string;
  onSelectAgreement: (id: string) => void;
  capacities: CapacityAgreement[];
  projects: PowerInstallationProject[];
}

export const RiskEngineDesk: React.FC<RiskEngineDeskProps> = ({
  agreements,
  activeAgreementId,
  onSelectAgreement,
  capacities,
  projects,
}) => {
  const selectedAgreement =
    agreements.find((a) => a.id === activeAgreementId) || agreements[0];

  const linkedCapacity = capacities.find((c) => c.agreementId === selectedAgreement.id);
  const linkedProject = projects.find((p) => p.id === selectedAgreement.linkedFinancingId) || projects[0];

  // Monte Carlo parameters
  const [simulationCount, setSimulationCount] = useState<number>(1000);
  const [seed, setSeed] = useState<number>(42);
  const [priceVolPercent, setPriceVolPercent] = useState<number>(35.0);
  const [demandVolPercent, setDemandVolPercent] = useState<number>(12.0);
  const [priceDemandCorrelation, setPriceDemandCorrelation] = useState<number>(0.40);

  // Selected Stress Scenario
  const [selectedStressId, setSelectedStressId] = useState<string>(PREDEFINED_STRESS_SCENARIOS[0].id);

  // Run simulation
  const mcResult = runMonteCarloSimulation({
    agreement: selectedAgreement,
    simulationCount,
    seed,
    basePrice: 85.0,
    priceVolatilityPercent: priceVolPercent,
    baseDemandMWh: selectedAgreement.baseContractedVolumeMWh,
    demandVolatilityPercent: demandVolPercent,
    priceDemandCorrelation,
    targetDSCRBaseline: 1.35,
  });

  // Execute stress scenario
  const currentScenario = PREDEFINED_STRESS_SCENARIOS.find((s) => s.id === selectedStressId) || PREDEFINED_STRESS_SCENARIOS[0];
  const stressResult = executeStressTest(
    currentScenario,
    selectedAgreement,
    85.0,
    linkedCapacity,
    linkedProject
  );

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-rose-400 uppercase tracking-wider">
            Workspace 09 · Institutional Risk Engine & Copula Simulation
          </div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Monte Carlo Simulation & Macro Stress Testing
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Bivariate Gaussian copula modelling, Value at Risk (VaR 95/99%), Expected Shortfall (CVaR), and financing stress.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label className="text-xs text-slate-400 font-medium">Select Agreement:</label>
          <select
            value={selectedAgreement.id}
            onChange={(e) => onSelectAgreement(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 font-medium focus:border-amber-400 focus:outline-none"
          >
            {agreements.map((a) => (
              <option key={a.id} value={a.id}>
                {a.id} — {a.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Monte Carlo Results Summary Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3">
        <div className="bg-slate-900/60 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Mean Expected Settlement</span>
          <div className={`font-mono font-bold text-base mt-1 ${mcResult.meanNetSettlement >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {mcResult.meanNetSettlement >= 0 ? '+' : '-'}£{(Math.abs(mcResult.meanNetSettlement) / 1e6).toFixed(2)}M
          </div>
          <span className="text-slate-400 text-[10px] block mt-0.5">
            Std Dev: £{(mcResult.standardDeviation / 1e6).toFixed(2)}M
          </span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Value at Risk (95% VaR)</span>
          <div className="font-mono font-bold text-amber-400 text-base mt-1">
            £{(Math.abs(mcResult.valueAtRisk95) / 1e6).toFixed(2)}M
          </div>
          <span className="text-slate-400 text-[10px] block mt-0.5">1-year horizon loss limit</span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Expected Shortfall (95% CVaR)</span>
          <div className="font-mono font-bold text-rose-400 text-base mt-1">
            £{(Math.abs(mcResult.expectedShortfall95) / 1e6).toFixed(2)}M
          </div>
          <span className="text-slate-400 text-[10px] block mt-0.5">Tail loss beyond 95% quantile</span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Extreme VaR (99%)</span>
          <div className="font-mono font-bold text-rose-500 text-base mt-1">
            £{(Math.abs(mcResult.valueAtRisk99) / 1e6).toFixed(2)}M
          </div>
          <span className="text-slate-400 text-[10px] block mt-0.5">
            99% CVaR: £{(Math.abs(mcResult.expectedShortfall99) / 1e6).toFixed(2)}M
          </span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Covenant Breach Risk</span>
          <div className={`font-mono font-bold text-base mt-1 ${mcResult.covenantBreachProbability > 0.05 ? 'text-rose-400' : 'text-emerald-400'}`}>
            {(mcResult.covenantBreachProbability * 100).toFixed(1)}%
          </div>
          <span className="text-slate-400 text-[10px] block mt-0.5">Prob(DSCR &lt; 1.05x)</span>
        </div>
      </div>

      {/* Monte Carlo Visual Histogram & Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Controls (4 cols) */}
        <div className="lg:col-span-4 bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider border-b border-slate-800 pb-2">
            Simulation Parameters & Seed Control
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1 font-medium">Simulation Count</label>
              <select
                value={simulationCount}
                onChange={(e) => setSimulationCount(parseInt(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:border-amber-400 focus:outline-none"
              >
                <option value="500">500 Iterations</option>
                <option value="1000">1,000 Iterations (Standard)</option>
                <option value="2000">2,000 Iterations (High Precision)</option>
              </select>
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Deterministic Seed:</span>
                <span className="font-mono font-bold text-amber-400">{seed}</span>
              </div>
              <input
                type="number"
                value={seed}
                onChange={(e) => setSeed(parseInt(e.target.value) || 42)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 font-mono focus:border-amber-400 focus:outline-none"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">Guarantees 100% reproducible statistical distributions.</span>
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Wholesale Price Volatility:</span>
                <span className="font-mono font-bold text-slate-200">{priceVolPercent}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="60"
                step="5"
                value={priceVolPercent}
                onChange={(e) => setPriceVolPercent(parseFloat(e.target.value))}
                aria-label="Wholesale Price Volatility"
                className="w-full accent-amber-400 h-1.5 bg-slate-800 rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Demand Volatility:</span>
                <span className="font-mono font-bold text-slate-200">{demandVolPercent}%</span>
              </div>
              <input
                type="range"
                min="5"
                max="30"
                step="1"
                value={demandVolPercent}
                onChange={(e) => setDemandVolPercent(parseFloat(e.target.value))}
                aria-label="Demand Volatility"
                className="w-full accent-amber-400 h-1.5 bg-slate-800 rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Price-Demand Correlation (ρ):</span>
                <span className="font-mono font-bold text-sky-400">+{priceDemandCorrelation.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="-0.4"
                max="0.8"
                step="0.05"
                value={priceDemandCorrelation}
                onChange={(e) => setPriceDemandCorrelation(parseFloat(e.target.value))}
                aria-label="Price-Demand Correlation"
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Histogram Distribution (8 cols) */}
        <div className="lg:col-span-8 bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Simulated Net Settlement Probability Distribution
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Frequency histogram of simulated buyer financial settlement outcomes across {simulationCount.toLocaleString()} trials.
              </p>
            </div>
            <span className="text-[11px] font-mono text-emerald-400 font-bold">
              Mean: £{(mcResult.meanNetSettlement / 1e6).toFixed(2)}M
            </span>
          </div>

          {/* Graphical Histogram Bars */}
          <div className="h-44 flex items-end gap-1.5 pt-4 pb-2 px-2 bg-slate-950/60 border border-slate-800/80 rounded">
            {mcResult.histogramBins.map((bin, idx) => {
              const maxFreq = Math.max(...mcResult.histogramBins.map((b) => b.frequency));
              const heightPct = (bin.frequency / maxFreq) * 100;
              const isPositive = (bin.binStart + bin.binEnd) / 2 >= 0;

              return (
                <div
                  key={idx}
                  className="flex-1 flex flex-col items-center h-full justify-end group relative"
                >
                  <div
                    className={`w-full rounded-t transition-all ${
                      isPositive
                        ? 'bg-emerald-500/70 hover:bg-emerald-400'
                        : 'bg-rose-500/70 hover:bg-rose-400'
                    }`}
                    style={{ height: `${Math.max(4, heightPct)}%` }}
                  />
                  <span className="text-[9px] font-mono text-slate-400 mt-1 truncate">
                    {((bin.binStart + bin.binEnd) / (2 * 1e6)).toFixed(1)}M
                  </span>

                  {/* Tooltip on hover */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute bottom-full mb-2 bg-slate-900 border border-slate-700 text-slate-200 text-[10px] p-1.5 rounded pointer-events-none whitespace-nowrap z-20 shadow-lg font-mono">
                    <div>Range: £{(bin.binStart / 1e6).toFixed(2)}M to £{(bin.binEnd / 1e6).toFixed(2)}M</div>
                    <div>Frequency: {bin.frequency} runs ({((bin.frequency / simulationCount) * 100).toFixed(1)}%)</div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* DSCR Percentile Distribution */}
          <div className="pt-2">
            <span className="text-xs font-semibold text-slate-300 block mb-2">Project DSCR Distribution Across Quantiles:</span>
            <div className="grid grid-cols-5 gap-2 text-center text-xs font-mono">
              {mcResult.dscrDistribution.map((d) => (
                <div key={d.percentile} className="bg-slate-950 border border-slate-800 rounded p-2">
                  <span className="text-[10px] text-slate-400 block font-sans">P{d.percentile}</span>
                  <span className={`font-bold ${d.dscrValue < 1.05 ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {d.dscrValue.toFixed(2)}x
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Stress Testing Section */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Deterministic Macro Stress Test Scenarios
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Evaluate multi-factor stress shocks combining price spikes, negative pricing, demand contractions, and CAPEX delays.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Select Scenario:</span>
            <select
              value={selectedStressId}
              onChange={(e) => setSelectedStressId(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-amber-300 font-medium focus:border-amber-400 focus:outline-none"
            >
              {PREDEFINED_STRESS_SCENARIOS.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Selected Stress Card */}
        <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-800/80 pb-2">
            <div>
              <span className="text-xs font-bold text-white">{currentScenario.name}</span>
              <p className="text-xs text-slate-400 mt-0.5">{currentScenario.description}</p>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block">Stressed Reference Price</span>
              <span className="font-mono font-bold text-amber-400 text-sm">
                £{stressResult.stressedPrice.toFixed(2)} / MWh
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono pt-1">
            <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800">
              <span className="text-slate-400 block font-sans text-[10px]">Settlement Impact</span>
              <span className={`font-bold ${stressResult.settlementImpact >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {stressResult.settlementImpact >= 0 ? '+' : ''}£{(stressResult.settlementImpact / 1e6).toFixed(2)}M
              </span>
            </div>

            <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800">
              <span className="text-slate-400 block font-sans text-[10px]">Capacity Impact</span>
              <span className="text-slate-200 font-bold">
                £{(stressResult.capacityPaymentImpact / 1e6).toFixed(2)}M
              </span>
            </div>

            <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800">
              <span className="text-slate-400 block font-sans text-[10px]">Minimum DSCR Under Stress</span>
              <span className={`font-bold ${stressResult.covenantBreached ? 'text-rose-400' : 'text-emerald-400'}`}>
                {stressResult.projectDSCRImpact.toFixed(2)}x
              </span>
            </div>

            <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800">
              <span className="text-slate-400 block font-sans text-[10px]">Covenant Compliance</span>
              <span className={`font-bold font-sans ${stressResult.covenantBreached ? 'text-rose-400' : 'text-emerald-400'}`}>
                {stressResult.covenantBreached ? 'BREACHED' : 'RESILIENT'}
              </span>
            </div>
          </div>

          <div className="bg-slate-900/40 p-3 rounded text-xs text-slate-300 border border-slate-800 flex items-start gap-2">
            <AlertTriangle className={`w-4 h-4 shrink-0 mt-0.5 ${stressResult.covenantBreached ? 'text-rose-400' : 'text-amber-400'}`} />
            <div>
              <span className="font-semibold text-white">Narrative Risk Assessment: </span>
              <span>{stressResult.narrative}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
