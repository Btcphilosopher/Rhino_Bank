/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Workspace 06: Installation Project Finance Desk
 */

import React, { useState } from 'react';
import { PowerInstallationProject } from '../types/projectFinance';
import { SyntheticElectricityAgreement, CapacityAgreement } from '../types/agreement';
import { modelProjectFinance } from '../models/projectFinanceEngine';
import {
  Building2,
  Sliders,
  DollarSign,
  TrendingUp,
  Percent,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ShieldAlert,
} from 'lucide-react';

interface InstallationFinanceDeskProps {
  projects: PowerInstallationProject[];
  activeProjectId: string;
  onSelectProject: (id: string) => void;
  linkedAgreement?: SyntheticElectricityAgreement;
  linkedCapacity?: CapacityAgreement;
}

export const InstallationFinanceDesk: React.FC<InstallationFinanceDeskProps> = ({
  projects,
  activeProjectId,
  onSelectProject,
  linkedAgreement,
  linkedCapacity,
}) => {
  const selectedProject =
    projects.find((p) => p.id === activeProjectId) || projects[0];

  // Stress sliders
  const [capexShockPercent, setCapexShockPercent] = useState<number>(0);
  const [interestRateShockBps, setInterestRateShockBps] = useState<number>(0);
  const [constructionDelayMonths, setConstructionDelayMonths] = useState<number>(0);
  const [merchantPriceAssumption, setMerchantPriceAssumption] = useState<number>(65.0);

  const stressedProject: PowerInstallationProject = {
    ...selectedProject,
    totalCapex: selectedProject.totalCapex * (1 + capexShockPercent / 100),
    seniorDebtInterestRate: selectedProject.seniorDebtInterestRate + interestRateShockBps / 10000,
    constructionMonths: selectedProject.constructionMonths + constructionDelayMonths,
  };

  const { cashFlows, summary } = modelProjectFinance(
    stressedProject,
    linkedAgreement,
    linkedCapacity,
    merchantPriceAssumption
  );

  return (
    <div className="space-y-6">
      {/* Top Controls */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-purple-400 uppercase tracking-wider">
            Workspace 06 · Power Installation & Project Finance
          </div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Future Installation Financing & Debt Coverage Model
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Model CAPEX, construction debt drawdowns, CFADS, DSCR covenants, break-even strike prices, and Project/Equity IRR.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label className="text-xs text-slate-400 font-medium">Select Installation Project:</label>
          <select
            value={selectedProject.id}
            onChange={(e) => onSelectProject(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 font-medium focus:border-amber-400 focus:outline-none"
          >
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.nameplateCapacityMW} MW {p.technology.replace(/_/g, ' ')}) · CAPEX £{(p.totalCapex / 1e6).toFixed(1)}M
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Primary Financial Coverage KPI Ribbon */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <div className="bg-slate-900/50 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Total Project Cost</span>
          <span className="font-mono font-bold text-white text-base">
            £{(summary.totalProjectCost / 1e6).toFixed(2)}M
          </span>
          <span className="text-slate-400 text-[10px] block mt-0.5">
            IDC: £{(summary.interestDuringConstruction / 1e6).toFixed(2)}M
          </span>
        </div>

        <div className="bg-slate-900/50 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Senior Debt</span>
          <span className="font-mono font-bold text-purple-400 text-base">
            £{(summary.seniorDebtPrincipal / 1e6).toFixed(2)}M
          </span>
          <span className="text-slate-400 text-[10px] block mt-0.5">
            {selectedProject.debtPercentage}% LTV · {(stressedProject.seniorDebtInterestRate * 100).toFixed(2)}% Rate
          </span>
        </div>

        <div className="bg-slate-900/50 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Minimum DSCR</span>
          <span className={`font-mono font-bold text-base ${summary.minimumDSCR < selectedProject.targetMinimumDSCR ? 'text-rose-400' : 'text-emerald-400'}`}>
            {summary.minimumDSCR.toFixed(2)}x
          </span>
          <span className="text-slate-400 text-[10px] block mt-0.5">
            Target: {selectedProject.targetMinimumDSCR.toFixed(2)}x
          </span>
        </div>

        <div className="bg-slate-900/50 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Average DSCR</span>
          <span className="font-mono font-bold text-emerald-400 text-base">
            {summary.averageDSCR.toFixed(2)}x
          </span>
          <span className="text-slate-400 text-[10px] block mt-0.5">
            Loan Life Coverage (LLCR): {summary.minimumLLCR.toFixed(2)}x
          </span>
        </div>

        <div className="bg-slate-900/50 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Break-Even Strike</span>
          <span className="font-mono font-bold text-amber-400 text-base">
            £{summary.breakEvenStrikePrice.toFixed(2)}
          </span>
          <span className="text-slate-400 text-[10px] block mt-0.5">per MWh for DSCR=1.25x</span>
        </div>

        <div className="bg-slate-900/50 border border-slate-800 rounded p-3 text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-semibold">Equity / Project IRR</span>
          <span className="font-mono font-bold text-sky-400 text-base">
            {(summary.equityIRR * 100).toFixed(1)}% <span className="text-xs text-slate-400 font-normal">/ {(summary.projectIRR * 100).toFixed(1)}%</span>
          </span>
          <span className="text-slate-400 text-[10px] block mt-0.5">Levered / Unlevered</span>
        </div>
      </div>

      {/* Covenant Status Alert if breached */}
      {summary.covenantBreached && (
        <div className="bg-rose-950/60 border border-rose-500/40 rounded-lg p-3 text-xs text-rose-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span className="font-bold">DEBT COVENANT BREACH: Minimum DSCR fallen below required {selectedProject.targetMinimumDSCR}x hurdle!</span>
          </div>
          <span className="font-mono text-[11px] text-rose-200">Refinancing or equity cure required.</span>
        </div>
      )}

      {/* Parameter Shocks & Sensitivity Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sliders (4 cols) */}
        <div className="lg:col-span-4 bg-slate-900/60 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider border-b border-slate-800 pb-2">
            Financing Assumptions & Stress Controls
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>CAPEX Cost Overrun Shock:</span>
                <span className="font-mono font-bold text-amber-400">+{capexShockPercent}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="40"
                step="5"
                value={capexShockPercent}
                onChange={(e) => setCapexShockPercent(parseFloat(e.target.value))}
                aria-label="CAPEX Cost Overrun Shock"
                className="w-full accent-amber-400 h-1.5 bg-slate-800 rounded cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-0.5">
                <span>0% Base</span>
                <span>+20% High</span>
                <span>+40% Extreme</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Interest Rate Shift (bps):</span>
                <span className="font-mono font-bold text-purple-400">+{interestRateShockBps} bps</span>
              </div>
              <input
                type="range"
                min="0"
                max="300"
                step="25"
                value={interestRateShockBps}
                onChange={(e) => setInterestRateShockBps(parseFloat(e.target.value))}
                aria-label="Interest Rate Shift (bps)"
                className="w-full accent-purple-400 h-1.5 bg-slate-800 rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Construction Delay:</span>
                <span className="font-mono font-bold text-sky-400">+{constructionDelayMonths} months</span>
              </div>
              <input
                type="range"
                min="0"
                max="24"
                step="3"
                value={constructionDelayMonths}
                onChange={(e) => setConstructionDelayMonths(parseFloat(e.target.value))}
                aria-label="Construction Delay"
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Merchant Power Price:</span>
                <span className="font-mono font-bold text-slate-200">£{merchantPriceAssumption.toFixed(2)}/MWh</span>
              </div>
              <input
                type="range"
                min="40"
                max="120"
                step="2.5"
                value={merchantPriceAssumption}
                onChange={(e) => setMerchantPriceAssumption(parseFloat(e.target.value))}
                aria-label="Merchant Power Price"
                className="w-full accent-slate-400 h-1.5 bg-slate-800 rounded cursor-pointer"
              />
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded p-3 text-xs space-y-1.5 font-mono">
            <div className="text-[11px] font-sans text-slate-400 font-semibold mb-1">Linked Contract Support:</div>
            <div className="flex justify-between text-slate-300">
              <span className="font-sans">Hedge Strike:</span>
              <span className="text-amber-400 font-bold">£{linkedAgreement?.strikePrice.toFixed(2) ?? '75.00'}/MWh</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="font-sans">Hedged Volume:</span>
              <span>{linkedAgreement?.baseContractedVolumeMWh.toLocaleString() ?? '80,000'} MWh</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="font-sans">Capacity Revenue:</span>
              <span className="text-sky-400 font-bold">
                £{(linkedCapacity ? (linkedCapacity.contractedCapacityMW * linkedCapacity.capacityPricePerMWYear) / 1e6 : 3.0).toFixed(2)}M/yr
              </span>
            </div>
          </div>
        </div>

        {/* Project Annual Waterfall Table (8 cols) */}
        <div className="lg:col-span-8 bg-slate-900/60 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Annual Project Debt Waterfall & Coverage Schedule (Years 1 - 10)
            </h3>
            <span className="text-[11px] text-slate-400 font-mono">
              Amortization: {selectedProject.amortizationProfile.replace(/_/g, ' ')}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                  <th className="py-2 px-2 font-sans">Year / Phase</th>
                  <th className="py-2 px-2 text-right">Generation</th>
                  <th className="py-2 px-2 text-right">Total Rev</th>
                  <th className="py-2 px-2 text-right">CFADS</th>
                  <th className="py-2 px-2 text-right">Debt Service</th>
                  <th className="py-2 px-2 text-right">Closing Debt</th>
                  <th className="py-2 px-2 text-right">DSCR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40 text-slate-300">
                {cashFlows.slice(0, 10).map((row) => {
                  const isConst = row.phase === 'CONSTRUCTION';
                  return (
                    <tr
                      key={row.year}
                      className={`hover:bg-slate-800/30 ${isConst ? 'bg-slate-950/40 text-slate-400 italic' : ''}`}
                    >
                      <td className="py-2 px-2 font-sans font-medium text-slate-200">
                        Year {row.year} <span className="text-[10px] text-slate-400">({row.phase === 'CONSTRUCTION' ? 'Const' : 'Ops'})</span>
                      </td>
                      <td className="py-2 px-2 text-right">
                        {isConst ? '-' : `${(row.expectedGenerationMWh / 1000).toFixed(0)}k MWh`}
                      </td>
                      <td className="py-2 px-2 text-right">
                        {isConst ? '-' : `£${(row.totalRevenue / 1e6).toFixed(2)}M`}
                      </td>
                      <td className="py-2 px-2 text-right text-emerald-400 font-bold">
                        {isConst ? '-' : `£${(row.cfads / 1e6).toFixed(2)}M`}
                      </td>
                      <td className="py-2 px-2 text-right text-rose-300">
                        {row.totalDebtService > 0 ? `£${(row.totalDebtService / 1e6).toFixed(2)}M` : '-'}
                      </td>
                      <td className="py-2 px-2 text-right text-purple-300">
                        £{(row.closingDebtBalance / 1e6).toFixed(2)}M
                      </td>
                      <td className={`py-2 px-2 text-right font-bold ${
                        isConst ? 'text-slate-400' : row.dscr < 1.25 ? 'text-rose-400' : 'text-emerald-400'
                      }`}>
                        {isConst ? '-' : `${row.dscr.toFixed(2)}x`}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
