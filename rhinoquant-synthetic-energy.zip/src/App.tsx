/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Synthetic Energy - Main Application Orchestrator
 */

import React, { useState, useEffect } from 'react';
import { MarketRegion, SyntheticElectricityAgreement } from './types/agreement';
import { WorkspaceTab, Navigation } from './components/Navigation';
import { Header } from './components/Header';
import { OverviewDesk } from './components/OverviewDesk';
import { AgreementBuilderDesk } from './components/AgreementBuilderDesk';
import { StrikePriceDesk } from './components/StrikePriceDesk';
import { DemandDesk } from './components/DemandDesk';
import { CapacityDesk } from './components/CapacityDesk';
import { InstallationFinanceDesk } from './components/InstallationFinanceDesk';
import { SyntheticLabDesk } from './components/SyntheticLabDesk';
import { ValuationDesk } from './components/ValuationDesk';
import { RiskEngineDesk } from './components/RiskEngineDesk';
import { PortfolioDesk } from './components/PortfolioDesk';
import { ReportsAuditDesk } from './components/ReportsAuditDesk';
import { HedgeComparatorDesk } from './components/HedgeComparatorDesk';
import { AcceptanceVerificationModal } from './components/AcceptanceVerificationModal';
import {
  INITIAL_AGREEMENTS,
  INITIAL_PROJECTS,
  INITIAL_CAPACITY_AGREEMENTS,
  INITIAL_COUNTERPARTIES,
  INITIAL_SYNTHETIC_INSTRUMENTS,
  INITIAL_AUDIT_LOGS,
  FORWARD_CURVES,
  MASTER_AGREEMENT_ID,
  MASTER_PROJECT_ID,
} from './data/demonstrationData';
import { runAcceptanceVerificationSuite } from './models/acceptanceTests';
import { AuditLogEntry } from './types/syntheticInstruments';

export default function App() {
  const [activeRegion, setActiveRegion] = useState<MarketRegion>('UK_N2EX');
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('OVERVIEW');

  // Master Portfolio State
  const [agreements, setAgreements] = useState<SyntheticElectricityAgreement[]>(INITIAL_AGREEMENTS);
  const [activeAgreementId, setActiveAgreementId] = useState<string>(MASTER_AGREEMENT_ID);

  const [capacities, setCapacities] = useState(INITIAL_CAPACITY_AGREEMENTS);
  const [activeCapacityId, setActiveCapacityId] = useState<string>(INITIAL_CAPACITY_AGREEMENTS[0].id);

  const [projects, setProjects] = useState(INITIAL_PROJECTS);
  const [activeProjectId, setActiveProjectId] = useState<string>(MASTER_PROJECT_ID);

  const [counterparties, setCounterparties] = useState(INITIAL_COUNTERPARTIES);
  const [syntheticInstruments, setSyntheticInstruments] = useState(INITIAL_SYNTHETIC_INSTRUMENTS);
  const [activeInstrumentId, setActiveInstrumentId] = useState<string>(INITIAL_SYNTHETIC_INSTRUMENTS[0].id);

  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(INITIAL_AUDIT_LOGS);

  // Global simulated market price
  const [simulatedSpotPrice, setSimulatedSpotPrice] = useState<number>(85.0);

  // Acceptance Tests Modal State
  const [isAcceptanceModalOpen, setIsAcceptanceModalOpen] = useState<boolean>(false);
  const [testPassCount, setTestPassCount] = useState<number>(20);

  // Run test verification on initial load
  useEffect(() => {
    const tests = runAcceptanceVerificationSuite();
    const passed = tests.filter((t) => t.passed).length;
    setTestPassCount(passed);
  }, []);

  const activeCurve = FORWARD_CURVES[activeRegion] || FORWARD_CURVES.UK_N2EX;

  const handleSaveAgreement = (newAgr: SyntheticElectricityAgreement) => {
    setAgreements((prev) => {
      const idx = prev.findIndex((a) => a.id === newAgr.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = newAgr;
        return copy;
      }
      return [newAgr, ...prev];
    });

    setActiveAgreementId(newAgr.id);

    // Record immutable audit event
    const newLog: AuditLogEntry = {
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: 'rhino.quant.desk1',
      userRole: 'Senior Quantitative Structurer',
      action: 'AGREEMENT_CREATED',
      entityId: newAgr.id,
      entityName: newAgr.name,
      details: `Structured new agreement: Strike £${newAgr.strikePrice.toFixed(2)}/MWh, Volume ${newAgr.baseContractedVolumeMWh.toLocaleString()} MWh, Mode: ${newAgr.volumeMode}`,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  const handlePrintReport = () => {
    window.print();
  };

  const handleResetDemo = () => {
    setAgreements(INITIAL_AGREEMENTS);
    setActiveAgreementId(MASTER_AGREEMENT_ID);
    setProjects(INITIAL_PROJECTS);
    setActiveProjectId(MASTER_PROJECT_ID);
    setCapacities(INITIAL_CAPACITY_AGREEMENTS);
    setActiveCapacityId(INITIAL_CAPACITY_AGREEMENTS[0].id);
    setSimulatedSpotPrice(85.0);
  };

  return (
    <div className="min-h-screen bg-[#060b18] text-slate-100 flex flex-col font-sans">
      {/* Top Application Header */}
      <Header
        activeRegion={activeRegion}
        onRegionChange={setActiveRegion}
        onOpenAcceptanceTests={() => setIsAcceptanceModalOpen(true)}
        onPrintReport={handlePrintReport}
        onResetDemo={handleResetDemo}
        testPassCount={testPassCount}
      />

      {/* Institutional Workspaces Navigation Bar */}
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Main Workspace Canvas */}
      <main className="flex-1 max-w-[1720px] w-full mx-auto px-6 py-6">
        {activeTab === 'OVERVIEW' && (
          <OverviewDesk
            agreements={agreements}
            projects={projects}
            capacities={capacities}
            activeCurve={activeCurve}
            onSelectAgreement={setActiveAgreementId}
            onNavigateTab={setActiveTab}
            simulatedSpotPrice={simulatedSpotPrice}
            onSpotPriceChange={setSimulatedSpotPrice}
          />
        )}

        {activeTab === 'BUILDER' && (
          <AgreementBuilderDesk
            counterparties={counterparties}
            projects={projects}
            onSaveAgreement={handleSaveAgreement}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'STRIKE_DESK' && (
          <StrikePriceDesk
            agreements={agreements}
            activeAgreementId={activeAgreementId}
            onSelectAgreement={setActiveAgreementId}
            activeCurve={activeCurve}
          />
        )}

        {activeTab === 'DEMAND_DESK' && (
          <DemandDesk
            agreements={agreements}
            activeAgreementId={activeAgreementId}
            onSelectAgreement={setActiveAgreementId}
          />
        )}

        {activeTab === 'CAPACITY_DESK' && (
          <CapacityDesk
            capacities={capacities}
            activeCapacityId={activeCapacityId}
            onSelectCapacity={setActiveCapacityId}
          />
        )}

        {activeTab === 'PROJECT_FINANCE' && (
          <InstallationFinanceDesk
            projects={projects}
            activeProjectId={activeProjectId}
            onSelectProject={setActiveProjectId}
            linkedAgreement={agreements.find((a) => a.id === activeAgreementId)}
            linkedCapacity={capacities.find((c) => c.agreementId === activeAgreementId)}
          />
        )}

        {activeTab === 'SYNTHETIC_LAB' && (
          <SyntheticLabDesk
            instruments={syntheticInstruments}
            activeInstrumentId={activeInstrumentId}
            onSelectInstrument={setActiveInstrumentId}
          />
        )}

        {activeTab === 'VALUATION_DESK' && (
          <ValuationDesk
            agreements={agreements}
            activeAgreementId={activeAgreementId}
            onSelectAgreement={setActiveAgreementId}
            activeCurve={activeCurve}
            counterparties={counterparties}
          />
        )}

        {activeTab === 'RISK_ENGINE' && (
          <RiskEngineDesk
            agreements={agreements}
            activeAgreementId={activeAgreementId}
            onSelectAgreement={setActiveAgreementId}
            capacities={capacities}
            projects={projects}
          />
        )}

        {activeTab === 'PORTFOLIO_DESK' && (
          <PortfolioDesk
            agreements={agreements}
            capacities={capacities}
            projects={projects}
            counterparties={counterparties}
            onSelectAgreement={setActiveAgreementId}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'REPORTS_AUDIT' && (
          <ReportsAuditDesk
            agreements={agreements}
            activeAgreementId={activeAgreementId}
            capacities={capacities}
            projects={projects}
            counterparties={counterparties}
            auditLogs={auditLogs}
            onPrintReport={handlePrintReport}
          />
        )}

        {activeTab === 'HEDGE_COMPARATOR' && (
          <HedgeComparatorDesk />
        )}
      </main>

      {/* Acceptance & Invariant Verification Modal */}
      <AcceptanceVerificationModal
        isOpen={isAcceptanceModalOpen}
        onClose={() => setIsAcceptanceModalOpen(false)}
      />

      {/* Institutional Legal Footer */}
      <footer className="border-t border-slate-900 bg-[#040813] text-slate-400 text-xs py-4 px-6 no-print">
        <div className="max-w-[1720px] mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-400">RhinoQuant Synthetic Energy</span>
            <span>·</span>
            <span>Rhino Bank Quantitative Division</span>
            <span>·</span>
            <span className="text-amber-400">Institutional Energy & Project Finance</span>
          </div>

          <div className="text-[11px] text-slate-400 text-center md:text-right font-mono">
            Model Version 1.0.0 · Exact Reconciliation Enforced · Non-Executable Modelled Valuations
          </div>
        </div>
      </footer>
    </div>
  );
}
