/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Monte Carlo Simulation & Copula Engine
 */

import { SyntheticElectricityAgreement } from '../types/agreement';
import { MonteCarloResult } from '../types/syntheticInstruments';
import { calculateStrikeSettlement } from './strikeEngine';

/**
 * Pseudo-random number generator with seed (Linear Congruential Generator / Mulberry32)
 * for fully reproducible institutional simulations.
 */
function createSeededRandom(seed: number) {
  let s = seed >>> 0;
  return function () {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Box-Muller transform to generate standard normal variates.
 */
function generateNormalPair(randomFn: () => number): [number, number] {
  const u1 = Math.max(1e-10, randomFn());
  const u2 = randomFn();
  const radius = Math.sqrt(-2.0 * Math.log(u1));
  const theta = 2.0 * Math.PI * u2;
  return [radius * Math.cos(theta), radius * Math.sin(theta)];
}

export interface MonteCarloConfig {
  agreement: SyntheticElectricityAgreement;
  simulationCount?: number;
  seed?: number;
  basePrice?: number;
  priceVolatilityPercent?: number; // e.g. 35%
  baseDemandMWh?: number;
  demandVolatilityPercent?: number; // e.g. 12%
  priceDemandCorrelation?: number; // e.g. 0.40
  targetDSCRBaseline?: number; // e.g. 1.35x
}

/**
 * Runs reproducible bivariate Monte Carlo simulation for energy prices,
 * demand, financial settlement, and debt coverage risk.
 */
export function runMonteCarloSimulation(config: MonteCarloConfig): MonteCarloResult {
  const {
    agreement,
    simulationCount = 1000,
    seed = 42,
    basePrice = 85.0,
    priceVolatilityPercent = 35.0,
    baseDemandMWh = 100000,
    demandVolatilityPercent = 12.0,
    priceDemandCorrelation = 0.40,
    targetDSCRBaseline = 1.35,
  } = config;

  const rand = createSeededRandom(seed);
  const priceVol = priceVolatilityPercent / 100;
  const demandVol = demandVolatilityPercent / 100;
  const rho = Math.max(-0.95, Math.min(0.95, priceDemandCorrelation));
  const sqrtOneMinusRho2 = Math.sqrt(1 - rho * rho);

  const netSettlements: number[] = [];
  const simulatedDSCRs: number[] = [];

  for (let i = 0; i < simulationCount; i++) {
    const [z1, z2] = generateNormalPair(rand);
    // Correlated demand normal variate
    const zDemand = rho * z1 + sqrtOneMinusRho2 * z2;

    // Simulate price (lognormal to prevent unrealistic negatives unless spike enabled)
    const simPrice = basePrice * Math.exp(-0.5 * priceVol * priceVol + priceVol * z1);

    // Occasional price spike (5% chance of +50% surge)
    const spikeTrigger = rand();
    const finalPrice = spikeTrigger > 0.95 ? simPrice * 1.65 : simPrice;

    // Simulate metered demand
    const simDemand = Math.max(10000, baseDemandMWh * (1 + demandVol * zDemand));

    // Calculate eligible volume
    let eligibleMWh = agreement.baseContractedVolumeMWh;
    if (agreement.volumeMode === 'PERCENTAGE_OF_DEMAND' && agreement.demandPercentage) {
      eligibleMWh = simDemand * (agreement.demandPercentage / 100);
    } else if (agreement.volumeMode === 'ACTUAL_METERED') {
      eligibleMWh = simDemand;
    }

    if (agreement.minVolumeMWh) eligibleMWh = Math.max(agreement.minVolumeMWh, eligibleMWh);
    if (agreement.maxVolumeMWh) eligibleMWh = Math.min(agreement.maxVolumeMWh, eligibleMWh);

    const calc = calculateStrikeSettlement({
      referencePrice: finalPrice,
      strikePrice: agreement.strikePrice,
      volumeMWh: eligibleMWh,
      settlementDirection: agreement.settlementDirection,
      priceCap: agreement.priceCap,
      priceFloor: agreement.priceFloor,
      transactionFeePerMWh: agreement.transactionFeePerMWh,
      optionPremiumPerMWh: agreement.optionPremiumPerMWh,
    });

    netSettlements.push(calc.netSettlement);

    // Simulated DSCR: baseline scaled by revenue fluctuation
    const revenueFactor = (finalPrice * eligibleMWh) / (basePrice * agreement.baseContractedVolumeMWh);
    const simDSCR = Math.max(0.4, targetDSCRBaseline * (0.6 + 0.4 * revenueFactor));
    simulatedDSCRs.push(simDSCR);
  }

  // Statistical calculations
  netSettlements.sort((a, b) => a - b);
  simulatedDSCRs.sort((a, b) => a - b);

  const mean = netSettlements.reduce((sum, val) => sum + val, 0) / simulationCount;
  const variance =
    netSettlements.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / (simulationCount - 1);
  const stdDev = Math.sqrt(variance);

  // Percentiles for VaR (Buyer loss perspective = lower tail of settlements)
  const idx01 = Math.floor(simulationCount * 0.01);
  const idx05 = Math.floor(simulationCount * 0.05);

  const var99 = -netSettlements[idx01];
  const var95 = -netSettlements[idx05];

  // Expected Shortfall (CVaR = average of losses beyond VaR)
  const tail99 = netSettlements.slice(0, idx01 + 1);
  const tail95 = netSettlements.slice(0, idx05 + 1);
  const cvar99 = -(tail99.reduce((a, b) => a + b, 0) / tail99.length);
  const cvar95 = -(tail95.reduce((a, b) => a + b, 0) / tail95.length);

  // Covenant breaches (DSCR < 1.05x)
  const breaches = simulatedDSCRs.filter((d) => d < 1.05).length;
  const covenantBreachProbability = breaches / simulationCount;

  // Histogram buckets (12 bins)
  const minVal = netSettlements[0];
  const maxVal = netSettlements[netSettlements.length - 1];
  const binWidth = (maxVal - minVal) / 12 || 1;
  const histogramBins = Array.from({ length: 12 }, (_, bIdx) => {
    const binStart = minVal + bIdx * binWidth;
    const binEnd = binStart + binWidth;
    const count = netSettlements.filter((v) => v >= binStart && (bIdx === 11 ? v <= binEnd : v < binEnd)).length;
    return { binStart, binEnd, frequency: count };
  });

  const dscrPercentiles = [
    { percentile: 5, dscrValue: simulatedDSCRs[Math.floor(simulationCount * 0.05)] },
    { percentile: 25, dscrValue: simulatedDSCRs[Math.floor(simulationCount * 0.25)] },
    { percentile: 50, dscrValue: simulatedDSCRs[Math.floor(simulationCount * 0.50)] },
    { percentile: 75, dscrValue: simulatedDSCRs[Math.floor(simulationCount * 0.75)] },
    { percentile: 95, dscrValue: simulatedDSCRs[Math.floor(simulationCount * 0.95)] },
  ];

  return {
    simulationCount,
    seed,
    meanNetSettlement: mean,
    standardDeviation: stdDev,
    valueAtRisk95: var95,
    valueAtRisk99: var99,
    expectedShortfall95: cvar95,
    expectedShortfall99: cvar99,
    dscrDistribution: dscrPercentiles,
    covenantBreachProbability,
    histogramBins,
  };
}
