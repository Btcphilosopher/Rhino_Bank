/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Stress Testing Engine
 */

import { SyntheticElectricityAgreement, CapacityAgreement } from '../types/agreement';
import { PowerInstallationProject } from '../types/projectFinance';
import { StressScenario } from '../types/syntheticInstruments';
import { calculateStrikeSettlement } from './strikeEngine';
import { calculateCapacitySettlement } from './capacityEngine';
import { modelProjectFinance } from './projectFinanceEngine';

export interface StressTestExecutionResult {
  scenario: StressScenario;
  stressedPrice: number;
  stressedDemandMWh: number;
  settlementImpact: number;
  capacityPaymentImpact: number;
  projectDSCRImpact: number;
  projectEquityIRRImpact: number;
  stressLoss: number;
  covenantBreached: boolean;
  narrative: string;
}

export const PREDEFINED_STRESS_SCENARIOS: StressScenario[] = [
  {
    id: 'PRICE_SURGE_100',
    name: 'Wholesale Price Shock (+100%)',
    description: 'Gas supply squeeze driving market reference prices up 100% to £150/MWh.',
    priceShockPercent: 100,
    demandShockPercent: 0,
    generationShockPercent: 0,
    capexOverrunPercent: 0,
    delayMonths: 0,
    interestRateBpsShock: 50,
  },
  {
    id: 'MARKET_CRASH_60',
    name: 'Wholesale Market Collapse (-60%)',
    description: 'Renewable oversupply and industrial demand slump driving reference prices down to £30/MWh.',
    priceShockPercent: -60,
    demandShockPercent: -10,
    generationShockPercent: 0,
    capexOverrunPercent: 0,
    delayMonths: 0,
    interestRateBpsShock: -100,
  },
  {
    id: 'NEGATIVE_PRICE_FLOOD',
    name: 'Negative Wholesale Pricing Surge',
    description: 'High renewable generation with low weekend demand pushing prices to -£25/MWh with floor test.',
    priceShockPercent: -130, // reference price drops below 0
    demandShockPercent: -5,
    generationShockPercent: -10,
    capexOverrunPercent: 0,
    delayMonths: 0,
    interestRateBpsShock: 0,
  },
  {
    id: 'DEMAND_SHORTFALL_30',
    name: 'Industrial Demand Shortfall (-30%)',
    description: 'Offtaker plant reduction resulting in 30% metered demand decline and take-or-pay review.',
    priceShockPercent: -15,
    demandShockPercent: -30,
    generationShockPercent: 0,
    capexOverrunPercent: 0,
    delayMonths: 0,
    interestRateBpsShock: 25,
  },
  {
    id: 'CONSTRUCTION_DELAY_OVERRUN',
    name: 'Construction Delay +25% CAPEX Overrun',
    description: 'EPC supply chain delay of 12 months with 25% project cost overrun triggering financing stress.',
    priceShockPercent: 0,
    demandShockPercent: 0,
    generationShockPercent: 0,
    capexOverrunPercent: 25,
    delayMonths: 12,
    interestRateBpsShock: 150,
  },
  {
    id: 'RENEWABLE_DROUGHT_OUTAGE',
    name: 'Resource Drought & Forced Outages',
    description: '20% wind/solar resource deficit combined with 8% forced turbine outages.',
    priceShockPercent: 40,
    demandShockPercent: 5,
    generationShockPercent: -20,
    capexOverrunPercent: 0,
    delayMonths: 0,
    interestRateBpsShock: 50,
  },
  {
    id: 'COMPOUND_STAGFLATION',
    name: 'Compound Stagflation & Default Threat',
    description: 'Concurrent 200 bps rate surge, 15% CAPEX escalation, and 15% volume curtailment.',
    priceShockPercent: 25,
    demandShockPercent: -15,
    generationShockPercent: -15,
    capexOverrunPercent: 15,
    delayMonths: 6,
    interestRateBpsShock: 200,
  },
];

/**
 * Runs stress testing against the selected agreement, capacity contract, and project finance structure.
 */
export function executeStressTest(
  scenario: StressScenario,
  agreement: SyntheticElectricityAgreement,
  baseReferencePrice: number = 75.0,
  capacity?: CapacityAgreement,
  project?: PowerInstallationProject
): StressTestExecutionResult {
  // Stressed price calculation
  const stressedPrice = baseReferencePrice * (1 + scenario.priceShockPercent / 100);

  // Stressed demand calculation
  const baseDemand = agreement.baseContractedVolumeMWh;
  const stressedDemand = Math.max(1000, baseDemand * (1 + scenario.demandShockPercent / 100));

  // Determine eligible volume under stress
  let eligibleMWh = baseDemand;
  if (agreement.volumeMode === 'PERCENTAGE_OF_DEMAND' && agreement.demandPercentage) {
    eligibleMWh = stressedDemand * (agreement.demandPercentage / 100);
  } else if (agreement.volumeMode === 'ACTUAL_METERED') {
    eligibleMWh = stressedDemand;
  }
  if (agreement.minVolumeMWh) eligibleMWh = Math.max(agreement.minVolumeMWh, eligibleMWh);
  if (agreement.maxVolumeMWh) eligibleMWh = Math.min(agreement.maxVolumeMWh, eligibleMWh);

  // Energy settlement under stress
  const baseSettlement = calculateStrikeSettlement({
    referencePrice: baseReferencePrice,
    strikePrice: agreement.strikePrice,
    volumeMWh: agreement.baseContractedVolumeMWh,
    settlementDirection: agreement.settlementDirection,
    priceCap: agreement.priceCap,
    priceFloor: agreement.priceFloor,
  });

  const stressedSettlement = calculateStrikeSettlement({
    referencePrice: stressedPrice,
    strikePrice: agreement.strikePrice,
    volumeMWh: eligibleMWh,
    settlementDirection: agreement.settlementDirection,
    priceCap: agreement.priceCap,
    priceFloor: agreement.priceFloor,
  });

  const settlementImpact = stressedSettlement.netSettlement - baseSettlement.netSettlement;

  // Capacity settlement under stress
  let capImpact = 0;
  if (capacity) {
    const baseCap = calculateCapacitySettlement(capacity);
    const stressedCapacityObj: CapacityAgreement = {
      ...capacity,
      actualAvailabilityPercent: Math.max(50, capacity.actualAvailabilityPercent - (scenario.generationShockPercent < 0 ? Math.abs(scenario.generationShockPercent) * 0.4 : 0)),
    };
    const stressedCap = calculateCapacitySettlement(stressedCapacityObj);
    capImpact = stressedCap.netAdjustedCapacityPayment - baseCap.netAdjustedCapacityPayment;
  }

  // Project finance under stress
  let projectDSCR = 1.35;
  let projectEquityIRR = 0.115;
  let covenantBreached = false;

  if (project) {
    const stressedProject: PowerInstallationProject = {
      ...project,
      totalCapex: project.totalCapex * (1 + scenario.capexOverrunPercent / 100),
      constructionMonths: project.constructionMonths + scenario.delayMonths,
      seniorDebtInterestRate: project.seniorDebtInterestRate + scenario.interestRateBpsShock / 10000,
      grossCapacityFactorPercent: project.grossCapacityFactorPercent * (1 + scenario.generationShockPercent / 100),
    };

    const finModel = modelProjectFinance(stressedProject, agreement, capacity, stressedPrice);
    projectDSCR = finModel.summary.minimumDSCR;
    projectEquityIRR = finModel.summary.equityIRR;
    covenantBreached = finModel.summary.covenantBreached;
  }

  const stressLoss = settlementImpact < 0 ? Math.abs(settlementImpact) : 0;

  let narrative = `Under ${scenario.name}, market price moves to ${stressedPrice.toFixed(2)} ${agreement.currency}/MWh. `;
  if (covenantBreached) {
    narrative += `Senior debt covenant breach detected! Minimum DSCR falls to ${projectDSCR.toFixed(2)}x (target is 1.25x).`;
  } else {
    narrative += `Debt service coverage remains resilient at ${projectDSCR.toFixed(2)}x DSCR.`;
  }

  return {
    scenario,
    stressedPrice,
    stressedDemandMWh: stressedDemand,
    settlementImpact,
    capacityPaymentImpact: capImpact,
    projectDSCRImpact: projectDSCR,
    projectEquityIRRImpact: projectEquityIRR,
    stressLoss,
    covenantBreached,
    narrative,
  };
}
