/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Installed-Capacity Agreement Engine
 */

import { CapacityAgreement } from '../types/agreement';

export interface CapacitySettlementResult {
  contractedCapacityMW: number;
  capacityPricePerMWYear: number;
  baseCapacityPayment: number;
  targetAvailabilityPercent: number;
  actualAvailabilityPercent: number;
  availabilityShortfallPercent: number;
  penaltyMultiplier: number;
  penaltyAmount: number;
  netAdjustedCapacityPayment: number;
  monthlyPayment: number;
  
  // Storage specific metrics
  effectiveStorageCapacityMWh?: number;
  degradationAdjustedMWh?: number;
}

/**
 * Calculates installed capacity revenue, availability adjustments,
 * and performance penalties according to institutional standards.
 */
export function calculateCapacitySettlement(
  agreement: CapacityAgreement,
  yearIndex: number = 1
): CapacitySettlementResult {
  const {
    contractedCapacityMW,
    capacityPricePerMWYear,
    targetAvailabilityPercent,
    actualAvailabilityPercent,
    penaltyMultiplier,
    isStorage,
    storageCapacityMWh,
    annualDegradationPercent = 0,
  } = agreement;

  // Base annual payment
  const baseCapacityPayment = contractedCapacityMW * capacityPricePerMWYear;

  // Availability Shortfall & Penalty calculation
  const shortfall = Math.max(0, targetAvailabilityPercent - actualAvailabilityPercent);
  let penaltyAmount = 0;

  if (shortfall > 0) {
    // Penalty is proportional to shortfall and multiplier
    const shortfallFraction = shortfall / 100;
    penaltyAmount = baseCapacityPayment * shortfallFraction * penaltyMultiplier;
  }

  const netAdjustedPayment = Math.max(0, baseCapacityPayment - penaltyAmount);
  const monthlyPayment = netAdjustedPayment / 12;

  // Battery storage calculations
  let effectiveStorageMWh: number | undefined;
  let degradationAdjustedMWh: number | undefined;

  if (isStorage && storageCapacityMWh) {
    const degradationFactor = Math.pow(1 - (annualDegradationPercent / 100), yearIndex - 1);
    degradationAdjustedMWh = storageCapacityMWh * degradationFactor;
    effectiveStorageMWh = degradationAdjustedMWh * (actualAvailabilityPercent / 100);
  }

  return {
    contractedCapacityMW,
    capacityPricePerMWYear,
    baseCapacityPayment,
    targetAvailabilityPercent,
    actualAvailabilityPercent,
    availabilityShortfallPercent: shortfall,
    penaltyMultiplier,
    penaltyAmount,
    netAdjustedCapacityPayment: netAdjustedPayment,
    monthlyPayment,
    effectiveStorageCapacityMWh: effectiveStorageMWh,
    degradationAdjustedMWh,
  };
}
