/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Project Finance & Installation Engineering Engine
 */

import {
  PowerInstallationProject,
  ProjectAnnualCashFlow,
  ProjectFinancialSummary,
} from '../types/projectFinance';
import { SyntheticElectricityAgreement, CapacityAgreement } from '../types/agreement';

/**
 * Robust Newton-Raphson IRR calculation for institutional cash flows.
 */
export function calculateIRR(cashFlows: number[], maxIterations: number = 100, tolerance: number = 1e-6): number {
  if (cashFlows.length === 0) return 0;

  // Check if at least one positive and one negative cash flow exists
  const hasPositive = cashFlows.some((cf) => cf > 0);
  const hasNegative = cashFlows.some((cf) => cf < 0);
  if (!hasPositive || !hasNegative) return 0;

  let rate = 0.08; // initial guess 8%
  for (let i = 0; i < maxIterations; i++) {
    let npv = 0;
    let dNpv = 0;

    for (let t = 0; t < cashFlows.length; t++) {
      const denom = Math.pow(1 + rate, t);
      npv += cashFlows[t] / denom;
      if (t > 0) {
        dNpv -= (t * cashFlows[t]) / Math.pow(1 + rate, t + 1);
      }
    }

    if (Math.abs(npv) < tolerance) {
      return rate;
    }

    if (Math.abs(dNpv) < 1e-12) {
      break;
    }

    const newRate = rate - npv / dNpv;
    if (newRate <= -0.99 || newRate > 5.0 || isNaN(newRate)) {
      rate = rate > 0 ? rate * 0.8 : 0.05;
    } else {
      rate = newRate;
    }
  }

  return rate;
}

/**
 * Calculates NPV given a discount rate and cash flows.
 */
export function calculateNPV(rate: number, cashFlows: number[]): number {
  return cashFlows.reduce((acc, cf, t) => acc + cf / Math.pow(1 + rate, t), 0);
}

/**
 * Calculates complete project finance schedule, debt amortization, coverage ratios,
 * and equity yields for a generation asset.
 */
export function modelProjectFinance(
  project: PowerInstallationProject,
  linkedAgreement?: SyntheticElectricityAgreement,
  linkedCapacity?: CapacityAgreement,
  merchantElectricityPrice: number = 65.0
): { cashFlows: ProjectAnnualCashFlow[]; summary: ProjectFinancialSummary } {
  const constructionYears = Math.ceil(project.constructionMonths / 12);
  const totalYears = constructionYears + project.operationalLifeYears;

  const totalCapex = project.totalCapex + project.developmentCosts + project.gridConnectionCosts;
  const seniorDebtPrincipal = totalCapex * (project.debtPercentage / 100);
  const sponsorEquity = totalCapex * (project.equityPercentage / 100);

  // Interest during construction (IDC)
  const idcRate = project.seniorDebtInterestRate;
  // Assume simple linear drawdown across construction years
  const annualDebtDrawdown = seniorDebtPrincipal / Math.max(1, constructionYears);
  let accumulatedDebt = 0;
  let totalIDC = 0;
  for (let c = 0; c < constructionYears; c++) {
    const periodInterest = (accumulatedDebt + annualDebtDrawdown / 2) * idcRate;
    totalIDC += periodInterest;
    accumulatedDebt += annualDebtDrawdown;
  }

  const initialDebtBalanceAtCOD = seniorDebtPrincipal + totalIDC;
  let remainingDebt = initialDebtBalanceAtCOD;

  // Annual debt annuity payment over tenor
  const n = project.debtTenorYears;
  const r = project.seniorDebtInterestRate;
  const annualAnnuity = r > 0 ? (initialDebtBalanceAtCOD * (r * Math.pow(1 + r, n))) / (Math.pow(1 + r, n) - 1) : initialDebtBalanceAtCOD / n;

  const cashFlows: ProjectAnnualCashFlow[] = [];
  const projectCashFlowsForIRR: number[] = [-totalCapex];
  const equityCashFlowsForIRR: number[] = [-(sponsorEquity + totalIDC * 0.2)]; // sponsor equity contributed

  let minDSCR = 999;
  let sumDSCR = 0;
  let countOperationalYearsWithDebt = 0;
  let minLLCR = 999;
  let covenantBreached = false;

  for (let yr = 1; yr <= totalYears; yr++) {
    const isConstruction = yr <= constructionYears;
    const opYear = yr - constructionYears;

    if (isConstruction) {
      cashFlows.push({
        year: yr,
        phase: 'CONSTRUCTION',
        expectedGenerationMWh: 0,
        hedgedElectricityRevenue: 0,
        merchantElectricityRevenue: 0,
        capacityMarketRevenue: 0,
        totalRevenue: 0,
        operatingCosts: 0,
        ebitda: 0,
        depreciation: 0,
        ebit: 0,
        taxPaid: 0,
        maintenanceReserve: 0,
        cfads: 0,
        openingDebtBalance: (yr - 1) * annualDebtDrawdown,
        interestPaid: ((yr - 1) * annualDebtDrawdown + annualDebtDrawdown / 2) * idcRate,
        principalRepayment: 0,
        totalDebtService: 0,
        closingDebtBalance: yr * annualDebtDrawdown,
        freeCashFlowToEquity: 0,
        dscr: 0,
        llcr: 0,
        plcr: 0,
      });
      continue;
    }

    // OPERATIONAL PHASE
    // Rule: Assets cannot generate before modelled commissioning date
    const degradation = Math.pow(1 - project.annualDegradationPercent / 100, opYear - 1);
    const capacityFactor = (project.grossCapacityFactorPercent / 100);
    const availability = (project.availabilityPercent / 100);
    const curtailment = (project.curtailmentLossPercent / 100);

    // Explicit production formula: Available MW * 8760 * CF * Availability * (1 - Curtailment) * Degradation
    const expectedGenerationMWh =
      project.nameplateCapacityMW * 8760 * capacityFactor * availability * (1 - curtailment) * degradation;

    // Revenues
    let hedgedRevenue = 0;
    let merchantRevenue = 0;

    if (linkedAgreement) {
      // If linked, offtaker purchases up to contracted volume at strike price
      const hedgedMWh = Math.min(expectedGenerationMWh, linkedAgreement.baseContractedVolumeMWh);
      const merchantMWh = Math.max(0, expectedGenerationMWh - hedgedMWh);
      hedgedRevenue = hedgedMWh * linkedAgreement.strikePrice;
      merchantRevenue = merchantMWh * merchantElectricityPrice;
    } else {
      merchantRevenue = expectedGenerationMWh * merchantElectricityPrice;
    }

    // Capacity market revenue
    let capacityRevenue = 0;
    if (linkedCapacity) {
      const capAvail = linkedCapacity.actualAvailabilityPercent / 100;
      capacityRevenue = linkedCapacity.contractedCapacityMW * linkedCapacity.capacityPricePerMWYear * capAvail;
    }

    const totalRevenue = hedgedRevenue + merchantRevenue + capacityRevenue;

    // Operating expenses
    const opex = project.fixedOpexPerYear + project.variableOpexPerMWh * expectedGenerationMWh + project.decommissioningReservePerYear;
    const ebitda = totalRevenue - opex;

    // Depreciation straight line over asset life
    const annualDepr = totalCapex / project.operationalLifeYears;
    const openingDebt = remainingDebt;

    // Debt service calculation
    let interestPaid = 0;
    let principalPaid = 0;
    let debtService = 0;

    if (opYear <= project.debtTenorYears && remainingDebt > 0) {
      interestPaid = remainingDebt * r;
      if (project.amortizationProfile === 'ANNUITY_EQUAL_INSTALLMENTS') {
        debtService = annualAnnuity;
        principalPaid = Math.min(remainingDebt, Math.max(0, annualAnnuity - interestPaid));
      } else if (project.amortizationProfile === 'STRAIGHT_LINE') {
        principalPaid = Math.min(remainingDebt, initialDebtBalanceAtCOD / project.debtTenorYears);
        debtService = principalPaid + interestPaid;
      } else {
        // Sculpted
        debtService = Math.min(remainingDebt + interestPaid, ebitda / project.targetMinimumDSCR);
        principalPaid = Math.min(remainingDebt, Math.max(0, debtService - interestPaid));
      }
      remainingDebt = Math.max(0, remainingDebt - principalPaid);
    }

    const ebit = Math.max(0, ebitda - annualDepr);
    const taxableIncome = Math.max(0, ebit - interestPaid);
    const taxPaid = taxableIncome * (project.taxRatePercent / 100);
    const maintenanceReserve = totalRevenue * 0.02; // 2% liquidity buffer

    // CFADS
    const cfads = Math.max(0, ebitda - taxPaid - maintenanceReserve);

    // DSCR
    let dscr = 0;
    if (debtService > 0) {
      dscr = cfads / debtService;
      if (dscr < minDSCR) minDSCR = dscr;
      sumDSCR += dscr;
      countOperationalYearsWithDebt++;
      if (dscr < project.targetMinimumDSCR) {
        covenantBreached = true;
      }
    } else {
      dscr = 99.0;
    }

    // LLCR: NPV of CFADS over remaining debt tenor / opening debt
    let remainingLoanCFADS_NPV = 0;
    if (openingDebt > 0) {
      const remainingTenorYears = Math.max(1, project.debtTenorYears - opYear + 1);
      // approximate discount of future CFADS
      remainingLoanCFADS_NPV = cfads * ((1 - Math.pow(1 + r, -remainingTenorYears)) / r);
      const llcr = remainingLoanCFADS_NPV / openingDebt;
      if (llcr < minLLCR) minLLCR = llcr;
    }

    const plcr = openingDebt > 0 ? (cfads * ((1 - Math.pow(1 + r, -(project.operationalLifeYears - opYear + 1))) / r)) / openingDebt : 99.0;
    const fcfToEquity = Math.max(0, cfads - debtService);

    projectCashFlowsForIRR.push(cfads);
    equityCashFlowsForIRR.push(fcfToEquity);

    cashFlows.push({
      year: yr,
      phase: 'OPERATIONAL',
      expectedGenerationMWh,
      hedgedElectricityRevenue: hedgedRevenue,
      merchantElectricityRevenue: merchantRevenue,
      capacityMarketRevenue: capacityRevenue,
      totalRevenue,
      operatingCosts: opex,
      ebitda,
      depreciation: annualDepr,
      ebit,
      taxPaid,
      maintenanceReserve,
      cfads,
      openingDebtBalance: openingDebt,
      interestPaid,
      principalRepayment: principalPaid,
      totalDebtService: debtService,
      closingDebtBalance: remainingDebt,
      freeCashFlowToEquity: fcfToEquity,
      dscr,
      llcr: openingDebt > 0 ? remainingLoanCFADS_NPV / openingDebt : 99.0,
      plcr,
    });
  }

  const projectIRR = calculateIRR(projectCashFlowsForIRR);
  const equityIRR = calculateIRR(equityCashFlowsForIRR);
  const discountRateWACC = 0.065;
  const projectNPV = calculateNPV(discountRateWACC, projectCashFlowsForIRR);
  const equityNPV = calculateNPV(0.09, equityCashFlowsForIRR);

  // Break-even strike price calculation: Strike where CFADS = Target DSCR * Debt Service
  const avgOpGen = cashFlows.filter((c) => c.phase === 'OPERATIONAL')[0]?.expectedGenerationMWh || 1;
  const avgOpex = project.fixedOpexPerYear + project.variableOpexPerMWh * avgOpGen;
  const requiredRevenue = annualAnnuity * project.targetMinimumDSCR + avgOpex;
  const breakEvenStrike = Math.max(0, requiredRevenue / avgOpGen);

  return {
    cashFlows,
    summary: {
      totalProjectCost: totalCapex + totalIDC,
      seniorDebtPrincipal: initialDebtBalanceAtCOD,
      sponsorEquity,
      interestDuringConstruction: totalIDC,
      projectIRR: isNaN(projectIRR) ? 0.075 : projectIRR,
      equityIRR: isNaN(equityIRR) ? 0.115 : equityIRR,
      projectNPV,
      equityNPV,
      minimumDSCR: minDSCR === 999 ? 0 : minDSCR,
      averageDSCR: countOperationalYearsWithDebt > 0 ? sumDSCR / countOperationalYearsWithDebt : 0,
      minimumLLCR: minLLCR === 999 ? 0 : minLLCR,
      covenantBreached,
      breakEvenStrikePrice: breakEvenStrike,
      breakEvenGenerationMWh: avgOpGen * 0.78,
      breakEvenCapacityFactor: project.grossCapacityFactorPercent * 0.78,
      repaymentMaturityYear: constructionYears + project.debtTenorYears,
    },
  };
}
