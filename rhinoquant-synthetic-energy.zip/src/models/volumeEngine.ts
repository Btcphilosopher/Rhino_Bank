/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Volume & Energy-Dependence Engine
 */

import { SyntheticElectricityAgreement, VolumeMode } from '../types/agreement';

export interface VolumeCalculationInput {
  agreement: SyntheticElectricityAgreement;
  meteredDemandMWh: number;
  marketReferencePrice: number;
  curtailmentPercent?: number;
}

export interface VolumeCalculationOutput {
  mode: VolumeMode;
  meteredDemandMWh: number;
  rawContractedVolumeMWh: number;
  cappedVolumeMWh: number;
  eligibleSettlementVolumeMWh: number;
  isCappedByMaximum: boolean;
  isFlooredByMinimum: boolean;
  takeOrPayTriggered: boolean;
  takeOrPayPenaltyVolumeMWh: number;
  isOptionExercised: boolean;
  curtailmentDeductionMWh: number;
  unhedgedResidualDemandMWh: number;
}

/**
 * Calculates contractual volume based on energy dependence mode,
 * respecting contractual caps, floors, tolerances, and exercise rules.
 */
export function calculateContractedVolume(input: VolumeCalculationInput): VolumeCalculationOutput {
  const { agreement, meteredDemandMWh, marketReferencePrice, curtailmentPercent = 0 } = input;
  let rawVolume = 0;
  let isOptionExercised = true;

  switch (agreement.volumeMode) {
    case 'FIXED_VOLUME':
      rawVolume = agreement.baseContractedVolumeMWh;
      break;

    case 'ACTUAL_METERED':
      rawVolume = meteredDemandMWh;
      break;

    case 'PERCENTAGE_OF_DEMAND': {
      const pct = (agreement.demandPercentage ?? 100) / 100;
      rawVolume = meteredDemandMWh * pct;
      break;
    }

    case 'OPTIONAL_VOLUME': {
      const hurdle = agreement.exerciseHurdleSpread ?? 0;
      // Call option exercises when market price exceeds strike + hurdle
      isOptionExercised = marketReferencePrice > (agreement.strikePrice + hurdle);
      rawVolume = isOptionExercised ? agreement.baseContractedVolumeMWh : 0;
      break;
    }

    default:
      rawVolume = agreement.baseContractedVolumeMWh;
  }

  // Deduct curtailment if applicable
  const curtailmentDeduction = (curtailmentPercent / 100) * rawVolume;
  let volumeAfterCurtailment = Math.max(0, rawVolume - curtailmentDeduction);

  let isCapped = false;
  let isFloored = false;

  // Apply maximum cap
  if (agreement.maxVolumeMWh !== undefined && volumeAfterCurtailment > agreement.maxVolumeMWh) {
    volumeAfterCurtailment = agreement.maxVolumeMWh;
    isCapped = true;
  }

  // Apply minimum floor
  if (agreement.minVolumeMWh !== undefined && volumeAfterCurtailment < agreement.minVolumeMWh && isOptionExercised) {
    volumeAfterCurtailment = agreement.minVolumeMWh;
    isFloored = true;
  }

  // Take-or-pay floor check
  let takeOrPayTriggered = false;
  let takeOrPayPenaltyMWh = 0;
  if (agreement.takeOrPayFloorMWh !== undefined && agreement.takeOrPayFloorMWh > volumeAfterCurtailment) {
    takeOrPayTriggered = true;
    takeOrPayPenaltyMWh = agreement.takeOrPayFloorMWh - volumeAfterCurtailment;
  }

  // Residual unhedged demand
  const residualDemand = Math.max(0, meteredDemandMWh - volumeAfterCurtailment);

  return {
    mode: agreement.volumeMode,
    meteredDemandMWh,
    rawContractedVolumeMWh: rawVolume,
    cappedVolumeMWh: volumeAfterCurtailment,
    eligibleSettlementVolumeMWh: volumeAfterCurtailment,
    isCappedByMaximum: isCapped,
    isFlooredByMinimum: isFloored,
    takeOrPayTriggered,
    takeOrPayPenaltyVolumeMWh: takeOrPayPenaltyMWh,
    isOptionExercised,
    curtailmentDeductionMWh: curtailmentDeduction,
    unhedgedResidualDemandMWh: residualDemand,
  };
}
