/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Strike-Price & Settlement Engine
 */

import { SyntheticElectricityAgreement, SettlementPeriodResult } from '../types/agreement';

export interface StrikeSettlementParams {
  referencePrice: number;
  strikePrice: number;
  volumeMWh: number;
  settlementDirection?: 'BUYER_PROTECTIVE' | 'GENERATOR_PROTECTIVE';
  priceCap?: number;
  priceFloor?: number;
  transactionFeePerMWh?: number;
  optionPremiumPerMWh?: number;
  isExercised?: boolean;
}

export interface StrikeCalculationResult {
  effectivePrice: number;
  priceSpread: number;
  grossSettlement: number;
  optionPremium: number;
  fees: number;
  netSettlement: number; // positive = payment to buyer (in buyer protective mode)
}

/**
 * Calculates financial settlement for a strike price agreement.
 * Convention:
 * Under BUYER_PROTECTIVE (standard CfD):
 * Buyer Settlement = (Reference Price - Strike Price) * Volume
 * When Reference Price > Strike, Buyer receives positive payment from Seller.
 * When Reference Price < Strike, Buyer pays negative difference to Seller.
 *
 * Under GENERATOR_PROTECTIVE:
 * Generator Settlement = (Strike Price - Reference Price) * Volume
 */
export function calculateStrikeSettlement(params: StrikeSettlementParams): StrikeCalculationResult {
  const {
    referencePrice,
    strikePrice,
    volumeMWh,
    settlementDirection = 'BUYER_PROTECTIVE',
    priceCap,
    priceFloor,
    transactionFeePerMWh = 0,
    optionPremiumPerMWh = 0,
    isExercised = true,
  } = params;

  if (volumeMWh <= 0 || !isExercised) {
    const optPrem = optionPremiumPerMWh * Math.max(0, volumeMWh);
    return {
      effectivePrice: referencePrice,
      priceSpread: 0,
      grossSettlement: 0,
      optionPremium: optPrem,
      fees: 0,
      netSettlement: -optPrem,
    };
  }

  // Apply floor and cap to reference price if configured
  let effectiveRefPrice = referencePrice;
  if (priceFloor !== undefined && effectiveRefPrice < priceFloor) {
    effectiveRefPrice = priceFloor;
  }
  if (priceCap !== undefined && effectiveRefPrice > priceCap) {
    effectiveRefPrice = priceCap;
  }

  let priceSpread = 0;
  let grossSettlement = 0;

  if (settlementDirection === 'BUYER_PROTECTIVE') {
    priceSpread = effectiveRefPrice - strikePrice;
    grossSettlement = priceSpread * volumeMWh;
  } else {
    // Generator protective
    priceSpread = strikePrice - effectiveRefPrice;
    grossSettlement = priceSpread * volumeMWh;
  }

  const optionPremium = optionPremiumPerMWh * volumeMWh;
  const fees = transactionFeePerMWh * volumeMWh;
  const netSettlement = grossSettlement - optionPremium - fees;

  return {
    effectivePrice: effectiveRefPrice,
    priceSpread,
    grossSettlement,
    optionPremium,
    fees,
    netSettlement,
  };
}

/**
 * Multi-period settlement schedule generator based on forward curve points or historic data.
 */
export function generateSettlementSchedule(
  agreement: SyntheticElectricityAgreement,
  pricePoints: { periodIndex: number; periodLabel: string; referencePrice: number; demandMWh?: number }[]
): SettlementPeriodResult[] {
  return pricePoints.map((pt) => {
    // Determine eligible volume for period
    let eligibleMWh = agreement.baseContractedVolumeMWh;
    const meteredDemand = pt.demandMWh ?? agreement.baseContractedVolumeMWh;

    if (agreement.volumeMode === 'PERCENTAGE_OF_DEMAND' && agreement.demandPercentage) {
      eligibleMWh = meteredDemand * (agreement.demandPercentage / 100);
    } else if (agreement.volumeMode === 'ACTUAL_METERED') {
      eligibleMWh = meteredDemand;
    }

    // Apply contractual volume caps and floors
    if (agreement.minVolumeMWh !== undefined) {
      eligibleMWh = Math.max(agreement.minVolumeMWh, eligibleMWh);
    }
    if (agreement.maxVolumeMWh !== undefined) {
      eligibleMWh = Math.min(agreement.maxVolumeMWh, eligibleMWh);
    }

    // For Mode 4 Optional purchases
    let isExercised = true;
    if (agreement.volumeMode === 'OPTIONAL_VOLUME') {
      const hurdle = agreement.exerciseHurdleSpread ?? 0;
      isExercised = pt.referencePrice > (agreement.strikePrice + hurdle);
    }

    const calc = calculateStrikeSettlement({
      referencePrice: pt.referencePrice,
      strikePrice: agreement.strikePrice,
      volumeMWh: isExercised ? eligibleMWh : 0,
      settlementDirection: agreement.settlementDirection,
      priceCap: agreement.priceCap,
      priceFloor: agreement.priceFloor,
      transactionFeePerMWh: agreement.transactionFeePerMWh,
      optionPremiumPerMWh: agreement.optionPremiumPerMWh,
      isExercised,
    });

    return {
      periodIndex: pt.periodIndex,
      periodLabel: pt.periodLabel,
      marketReferencePrice: pt.referencePrice,
      contractStrikePrice: agreement.strikePrice,
      meteredDemandMWh: meteredDemand,
      eligibleVolumeMWh: isExercised ? eligibleMWh : 0,
      effectivePriceSpread: calc.priceSpread,
      grossEnergySettlement: calc.grossSettlement,
      optionPremiumPaid: calc.optionPremium,
      capacityPayment: 0,
      capacityPenalty: 0,
      netSettlementCashFlow: calc.netSettlement,
    };
  });
}
