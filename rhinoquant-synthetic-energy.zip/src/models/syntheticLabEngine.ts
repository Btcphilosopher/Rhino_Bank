/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Synthetic Structured Instrument & Waterfall Engine
 */

import { SyntheticInstrument, SyntheticTranche, WaterfallStep } from '../types/syntheticInstruments';

export interface WaterfallExecutionResult {
  steps: WaterfallStep[];
  totalInflowAvailable: number;
  totalDistributed: number;
  cashConserved: boolean;
  unallocatedCash: number;
  cumulativeShortfall: number;
}

export interface TrancheLossAllocationResult {
  tranches: SyntheticTranche[];
  totalPoolLoss: number;
  totalAllocatedLoss: number;
  lossReconciliationValid: boolean;
}

/**
 * Executes a prioritized structured cash-flow waterfall.
 * Strictly verifies cash conservation: Inflows == Distributed + Unallocated Cash.
 */
export function executeCashWaterfall(
  availableInflow: number,
  requirements: { priority: number; stepName: string; category: WaterfallStep['category']; amountDue: number }[]
): WaterfallExecutionResult {
  let remainingCash = Math.max(0, availableInflow);
  let totalDistributed = 0;
  let cumulativeShortfall = 0;

  const sortedReqs = [...requirements].sort((a, b) => a.priority - b.priority);
  const steps: WaterfallStep[] = [];

  for (const req of sortedReqs) {
    const amountDue = req.amountDue;
    const amountPaid = Math.min(remainingCash, amountDue);
    const shortfall = Math.max(0, amountDue - amountPaid);
    remainingCash -= amountPaid;
    totalDistributed += amountPaid;
    cumulativeShortfall += shortfall;

    steps.push({
      priority: req.priority,
      stepName: req.stepName,
      category: req.category,
      inflowAvailable: remainingCash + amountPaid,
      amountDue,
      amountPaid,
      shortfall,
      remainingCash,
    });
  }

  // Cash conservation invariant: Inflow == Total Distributed + Remaining Cash
  const cashConserved = Math.abs(availableInflow - (totalDistributed + remainingCash)) < 1e-4;

  return {
    steps,
    totalInflowAvailable: availableInflow,
    totalDistributed,
    cashConserved,
    unallocatedCash: remainingCash,
    cumulativeShortfall,
  };
}

/**
 * Allocates pool credit or revenue losses across structured tranches.
 * Follows strict subordination: First-Loss (Equity) -> Mezzanine -> Senior.
 * Invariant: Sum of allocated losses == Min(Total Pool Loss, Total Notional).
 */
export function allocateTrancheLosses(
  totalPoolLoss: number,
  tranches: SyntheticTranche[]
): TrancheLossAllocationResult {
  const totalNotional = tranches.reduce((sum, t) => sum + t.notional, 0);
  let unallocatedLoss = Math.min(totalPoolLoss, totalNotional);

  // Sort tranches from lowest detachment/attachment (First-Loss) to highest (Senior)
  // Attachment point 0% is first-loss
  const sortedTranches = [...tranches].sort((a, b) => a.attachmentPointPercent - b.attachmentPointPercent);

  const updatedTranches: SyntheticTranche[] = sortedTranches.map((tranche) => {
    const trancheCapacity = tranche.notional;
    const lossForThisTranche = Math.min(unallocatedLoss, trancheCapacity);
    unallocatedLoss = Math.max(0, unallocatedLoss - lossForThisTranche);

    const remainingNotional = Math.max(0, trancheCapacity - lossForThisTranche);
    const lossFraction = trancheCapacity > 0 ? lossForThisTranche / trancheCapacity : 0;
    const effectiveYield = Math.max(0, tranche.expectedYieldPercent * (1 - lossFraction));

    return {
      ...tranche,
      allocatedLoss: lossForThisTranche,
      remainingNotional,
      expectedYieldPercent: effectiveYield,
    };
  });

  const totalAllocatedLoss = updatedTranches.reduce((sum, t) => sum + t.allocatedLoss, 0);
  const lossReconciliationValid = Math.abs(totalAllocatedLoss - Math.min(totalPoolLoss, totalNotional)) < 1e-4;

  return {
    tranches: updatedTranches,
    totalPoolLoss,
    totalAllocatedLoss,
    lossReconciliationValid,
  };
}
