/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Mark-to-Model Valuation & CVA Engine
 */

import { SyntheticElectricityAgreement, Counterparty } from '../types/agreement';
import { MarketForwardCurve } from '../types/market';
import { generateSettlementSchedule } from './strikeEngine';

export interface ValuationOutput {
  agreementId: string;
  valuationDate: string;
  modelledNPV: number;
  undiscountedCashFlowSum: number;
  creditValuationAdjustmentCVA: number;
  netRiskAdjustedMTM: number;
  deltaWholesalePricePerMWh: number; // £/MWh sensitivity
  deltaDemandVolumeMWh: number; // sensitivity to 1% demand shift
  weightedAverageReferencePrice: number;
  isBuyerInTheMoney: boolean;
  settlementYears: {
    year: number;
    forwardPrice: number;
    settledVolumeMWh: number;
    expectedCashFlow: number;
    discountFactor: number;
    discountedCashFlow: number;
  }[];
}

/**
 * Calculates institutional mark-to-model valuation, discounted cash flows,
 * CVA (Credit Valuation Adjustment), and risk sensitivities.
 */
export function calculateAgreementValuation(
  agreement: SyntheticElectricityAgreement,
  forwardCurve: MarketForwardCurve,
  counterparty?: Counterparty,
  riskFreeRate: number = 0.045
): ValuationOutput {
  // Map forward curve points to settlement schedules
  const scheduleInputs = forwardCurve.points.slice(0, agreement.tenorYears).map((pt, idx) => ({
    periodIndex: idx + 1,
    periodLabel: `Year ${idx + 1} (${pt.dateLabel})`,
    referencePrice: pt.baseloadPrice,
    demandMWh: agreement.baseContractedVolumeMWh,
  }));

  const settlements = generateSettlementSchedule(agreement, scheduleInputs);

  let undiscountedSum = 0;
  let totalDiscountedNPV = 0;
  let sumWeightedPrice = 0;
  let totalVolume = 0;

  const yearlyBreakdown = settlements.map((s, idx) => {
    const pt = forwardCurve.points[idx] || { discountFactor: Math.pow(1 + riskFreeRate, -(idx + 1)) };
    const df = pt.discountFactor ?? Math.pow(1 + riskFreeRate, -(idx + 1));
    const discounted = s.netSettlementCashFlow * df;

    undiscountedSum += s.netSettlementCashFlow;
    totalDiscountedNPV += discounted;
    sumWeightedPrice += s.marketReferencePrice * s.eligibleVolumeMWh;
    totalVolume += s.eligibleVolumeMWh;

    return {
      year: idx + 1,
      forwardPrice: s.marketReferencePrice,
      settledVolumeMWh: s.eligibleVolumeMWh,
      expectedCashFlow: s.netSettlementCashFlow,
      discountFactor: df,
      discountedCashFlow: discounted,
    };
  });

  // Credit Valuation Adjustment (CVA)
  // CVA = (1 - Recovery) * Sum(Discounted Expected Exposure * Marginal PD)
  const counterpartySpreadBps = counterparty ? counterparty.creditSpreadBps : 120;
  const impliedHazardRate = (counterpartySpreadBps / 10000) / (1 - 0.40); // 40% recovery assumption
  let cva = 0;
  if (totalDiscountedNPV > 0) {
    // If agreement is an asset (positive MTM to buyer), buyer has counterparty credit exposure
    const annualDefaultProb = 1 - Math.exp(-impliedHazardRate);
    cva = totalDiscountedNPV * annualDefaultProb * (1 - 0.40);
  }

  // Sensitivities:
  // Delta Wholesale Price: change in undiscounted cash flow for a +£1/MWh shift in forward price
  const deltaPrice = totalVolume * (agreement.settlementDirection === 'BUYER_PROTECTIVE' ? 1 : -1);

  // Delta Demand: change for +1% demand shift
  const deltaDemand = undiscountedSum * 0.01;

  return {
    agreementId: agreement.id,
    valuationDate: new Date().toISOString().split('T')[0],
    modelledNPV: totalDiscountedNPV,
    undiscountedCashFlowSum: undiscountedSum,
    creditValuationAdjustmentCVA: cva,
    netRiskAdjustedMTM: totalDiscountedNPV - cva,
    deltaWholesalePricePerMWh: deltaPrice,
    deltaDemandVolumeMWh: deltaDemand,
    weightedAverageReferencePrice: totalVolume > 0 ? sumWeightedPrice / totalVolume : 0,
    isBuyerInTheMoney: totalDiscountedNPV > 0,
    settlementYears: yearlyBreakdown,
  };
}
