/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RhinoQuant Energy Procurement & Hedge Comparison Engine
 */

export interface HedgeStrategyComparisonInput {
  annualDemandMWh: number; // e.g. 100,000 MWh
  expectedWholesalePrice: number; // e.g. £85/MWh
  strikePrice: number; // e.g. £75/MWh
  optionPremiumPerMWh: number; // e.g. £6.50/MWh
  capacityPricePerMWYear: number; // e.g. £60,000/MW-yr
  peakCapacityNeededMW: number; // e.g. 25 MW
  wholesalePriceVolatility: number; // e.g. 30%
}

export interface StrategyComparisonResult {
  strategyKey: string;
  strategyName: string;
  category: string;
  expectedAnnualCost: number; // in currency
  effectiveCostPerMWh: number; // total cost / demand
  worstCaseCost95: number; // 95th percentile cost under price spike
  bestCaseCost: number; // under cheap wholesale market
  priceRiskExposure: 'HIGH' | 'MODERATE' | 'LOW' | 'VERY_LOW';
  volumeFlexibility: 'NONE' | 'FULL_DEMAND_TRACKING' | 'ASYMMETRIC_OPTIONAL' | 'PARTIAL';
  collateralRequirement: number;
  description: string;
}

/**
 * Evaluates the 6 institutional energy procurement and hedge structures side-by-side.
 */
export function compareHedgeStrategies(input: HedgeStrategyComparisonInput): StrategyComparisonResult[] {
  const {
    annualDemandMWh,
    expectedWholesalePrice,
    strikePrice,
    optionPremiumPerMWh,
    capacityPricePerMWYear,
    peakCapacityNeededMW,
    wholesalePriceVolatility,
  } = input;

  const spikePrice = expectedWholesalePrice * (1 + wholesalePriceVolatility * 1.65); // 95% worst-case price
  const cheapPrice = expectedWholesalePrice * (1 - wholesalePriceVolatility * 1.2);

  // Strategy 1: Unhedged wholesale exposure
  const unhedgedExpected = annualDemandMWh * expectedWholesalePrice;
  const unhedgedWorst = annualDemandMWh * spikePrice;
  const unhedgedBest = annualDemandMWh * cheapPrice;

  // Strategy 2: Fixed strike-price agreement (100% volume fixed)
  // Buyer pays wholesale, receives (Wholesale - Strike)*Demand -> Net cost is fixed at Strike * Demand
  const fixedExpected = annualDemandMWh * strikePrice;
  const fixedWorst = annualDemandMWh * strikePrice; // fully hedged against price risk!
  const fixedBest = annualDemandMWh * strikePrice;

  // Strategy 3: Demand-dependent financial hedge (80% metered demand)
  // 80% volume hedged at strike (£75), 20% residual exposed to wholesale
  const demandHedgedExpected = annualDemandMWh * (0.8 * strikePrice + 0.2 * expectedWholesalePrice);
  const demandHedgedWorst = annualDemandMWh * (0.8 * strikePrice + 0.2 * spikePrice);
  const demandHedgedBest = annualDemandMWh * (0.8 * strikePrice + 0.2 * cheapPrice);

  // Strategy 4: Optional-volume agreement (Call option hedge)
  // Buyer pays premium upfront (£6.50/MWh on 100k MWh = £650k).
  // If price > strike: buyer exercises call, net electricity cost is strike. Total = (Strike + Prem)*Demand
  // If price <= strike: buyer lets expire, buys wholesale. Total = (Wholesale + Prem)*Demand
  const optExpected = annualDemandMWh * (optionPremiumPerMWh + Math.min(expectedWholesalePrice, strikePrice));
  const optWorst = annualDemandMWh * (strikePrice + optionPremiumPerMWh);
  const optBest = annualDemandMWh * (cheapPrice + optionPremiumPerMWh);

  // Strategy 5: Combined electricity and capacity contract
  // 80% demand hedge at strike + fixed capacity availability reservation
  const capacityAnnualCost = peakCapacityNeededMW * capacityPricePerMWYear;
  const combinedExpected = demandHedgedExpected + capacityAnnualCost;
  const combinedWorst = demandHedgedWorst + capacityAnnualCost;
  const combinedBest = demandHedgedBest + capacityAnnualCost;

  // Strategy 6: Contract linked to future generation installation (Project-backed VPPA/Financed)
  // Tailored long-term structure with developer margin buffer, discount for 15-year commitment
  const installationDiscountedStrike = strikePrice * 0.94; // e.g. £70.50/MWh
  const installExpected = annualDemandMWh * (0.85 * installationDiscountedStrike + 0.15 * expectedWholesalePrice);
  const installWorst = annualDemandMWh * (0.85 * installationDiscountedStrike + 0.15 * spikePrice);
  const installBest = annualDemandMWh * (0.85 * installationDiscountedStrike + 0.15 * cheapPrice);

  return [
    {
      strategyKey: 'UNHEDGED_WHOLESALE',
      strategyName: '1. Unhedged Wholesale Exposure',
      category: 'Spot Market Only',
      expectedAnnualCost: unhedgedExpected,
      effectiveCostPerMWh: unhedgedExpected / annualDemandMWh,
      worstCaseCost95: unhedgedWorst,
      bestCaseCost: unhedgedBest,
      priceRiskExposure: 'HIGH',
      volumeFlexibility: 'NONE',
      collateralRequirement: 0,
      description: 'Zero forward hedge. 100% exposure to spot price volatility, weather extremes, and wholesale spikes.',
    },
    {
      strategyKey: 'FIXED_STRIKE',
      strategyName: '2. Fixed Strike-Price Agreement',
      category: 'Baseload Financial CfD',
      expectedAnnualCost: fixedExpected,
      effectiveCostPerMWh: fixedExpected / annualDemandMWh,
      worstCaseCost95: fixedWorst,
      bestCaseCost: fixedBest,
      priceRiskExposure: 'VERY_LOW',
      volumeFlexibility: 'NONE',
      collateralRequirement: fixedExpected * 0.12,
      description: 'Locks in 100% of volume at fixed strike price. Eliminates upside price spikes, but locks in payment if spot falls.',
    },
    {
      strategyKey: 'DEMAND_DEPENDENT_80',
      strategyName: '3. Demand-Dependent Hedge (80%)',
      category: 'Volume-Flexible CfD',
      expectedAnnualCost: demandHedgedExpected,
      effectiveCostPerMWh: demandHedgedExpected / annualDemandMWh,
      worstCaseCost95: demandHedgedWorst,
      bestCaseCost: demandHedgedBest,
      priceRiskExposure: 'LOW',
      volumeFlexibility: 'FULL_DEMAND_TRACKING',
      collateralRequirement: demandHedgedExpected * 0.09,
      description: 'Contracts 80% of metered demand at strike price. Adapts to industrial shift changes and plant downtimes.',
    },
    {
      strategyKey: 'OPTIONAL_VOLUME_CALL',
      strategyName: '4. Optional-Volume Agreement',
      category: 'Asymmetric Option Hedge',
      expectedAnnualCost: optExpected,
      effectiveCostPerMWh: optExpected / annualDemandMWh,
      worstCaseCost95: optWorst,
      bestCaseCost: optBest,
      priceRiskExposure: 'VERY_LOW',
      volumeFlexibility: 'ASYMMETRIC_OPTIONAL',
      collateralRequirement: annualDemandMWh * optionPremiumPerMWh,
      description: 'Caps maximum electricity price at strike while preserving full participation when wholesale prices collapse.',
    },
    {
      strategyKey: 'COMBINED_ENERGY_CAPACITY',
      strategyName: '5. Combined Energy + Capacity Contract',
      category: 'Structured Multi-Product',
      expectedAnnualCost: combinedExpected,
      effectiveCostPerMWh: combinedExpected / annualDemandMWh,
      worstCaseCost95: combinedWorst,
      bestCaseCost: combinedBest,
      priceRiskExposure: 'VERY_LOW',
      volumeFlexibility: 'FULL_DEMAND_TRACKING',
      collateralRequirement: combinedExpected * 0.14,
      description: 'Combines 80% energy strike price hedge with guaranteed installed capacity availability rights for peak security.',
    },
    {
      strategyKey: 'INSTALLATION_LINKED_VPPA',
      strategyName: '6. Installation-Linked Project VPPA',
      category: 'Long-Term Infrastructure Linked',
      expectedAnnualCost: installExpected,
      effectiveCostPerMWh: installExpected / annualDemandMWh,
      worstCaseCost95: installWorst,
      bestCaseCost: installBest,
      priceRiskExposure: 'LOW',
      volumeFlexibility: 'PARTIAL',
      collateralRequirement: installExpected * 0.15,
      description: 'Directly underpins a new renewable installation. Delivers long-term discounted strike pricing and additionality.',
    },
  ];
}
