# RhinoQuant Synthetic Energy

**Institutional Energy-Finance Platform for Synthetic Electricity Agreements, Strike-Price Trading & Future Power-Installation Project Finance**

Developed for **RhinoQuant**, the quantitative finance division of **Rhino Bank**.

---

## 1. Executive Summary

RhinoQuant Synthetic Energy is an institutional quantitative energy-finance platform for structuring, pricing, managing, and stress-testing:
1. **Synthetic electricity agreements & strike-price contracts** (Baseload CfDs, VPPAs, optional purchases).
2. **Energy-dependent purchasing structures** (Fixed, actual metered consumption, percentage-of-demand e.g. 80%, asymmetric exercise calls).
3. **Installed-capacity agreements** (MW commitments, £/MW-yr availability payments, performance outage penalties, BESS degradation).
4. **Future power-installation project finance** (CAPEX, construction loans, S-curve drawdowns, CFADS, DSCR covenants, break-even strike prices, Project & Equity IRR).
5. **Combined synthetic energy structures** linking energy hedges, capacity availability, and generation project finance without duplicating cash flows.

---

## 2. Core Quantitative Invariant Principles

- **Sign Convention**: Under standard buyer-protective CfD:
  $$\text{Buyer Settlement} = (\text{Reference Price} - \text{Strike Price}) \times \text{Settled MWh}$$
  A positive settlement represents a payment to the buyer; negative represents a payment from the buyer.
- **Section 20 Master Test Proof**:
  - Industrial Buyer: AeroTitan Advanced Materials Plc
  - Baseline Demand: 100,000 MWh/year
  - Contracted Volume: 80% of metered demand = 80,000 MWh
  - Strike Price: £75.00/MWh
  - Market Reference Price: £100.00/MWh
  - Gross Financial Settlement: $(£100.00 - £75.00) \times 80,000\text{ MWh} = +\mathbf{£2,000,000.00}$ in favour of buyer.
- **Unit Decoupling**: Instantaneous capacity (MW) is decoupled from cumulative energy volume (MWh):
  $$\text{Expected Annual Generation (MWh)} = \text{Capacity (MW)} \times 8,760 \times \text{Capacity Factor} \times \text{Availability} \times (1 - \text{Curtailment})$$
- **Pre-COD Generation Invariant**: Generation and operational revenues are strictly zero before Commercial Operation Date (COD).
- **Waterfall Cash Conservation**: Total Inflows $\equiv$ Total Distributed + Unallocated Cash. Zero leakage.
- **Subordinated Loss Absorption**: Credit/revenue losses absorb First-Loss Equity (0–10%) first, Mezzanine (10–30%) second, and Senior (30–100%) last.

---

## 3. Workspaces & Desks

1. **01 — Energy Overview**: Portfolio aggregate KPIs, contracted MWh/MW, net settlement cash flows, senior debt outstanding, live spot shock slider.
2. **02 — Agreement Builder**: Structured contract wizard with real-time mathematical validation, draft preview, and immutable audit logging.
3. **03 — Strike Price Desk**: Forward curve shaping, payoff sensitivity matrix, floor/cap boundary protections, and negative pricing handling.
4. **04 — Energy Demand Desk**: Metered load profiles, 80% demand hedging, volume caps/floors, take-or-pay threshold testing.
5. **05 — Capacity Desk**: Contracted MW commitments, target vs actual availability, outage deductions, and battery storage degradation.
6. **06 — Installation Finance**: Renewable project finance, senior debt sculpting, CFADS, DSCR/LLCR/PLCR distributions, Project & Equity IRR.
7. **07 — Synthetic Instrument Lab**: Multi-tranche synthetic risk transfer, attachment/detachment points, and priority waterfalls.
8. **08 — Valuation Desk**: Mark-to-model discounted cash flows, Bilateral Credit Valuation Adjustments (CVA), and Greeks ($dP/dMTM$).
9. **09 — Risk Engine**: Bivariate Gaussian copula Monte Carlo simulations ($n=1,000$, seeded), VaR 95/99%, Expected Shortfall (CVaR), and 7 macro stress tests.
10. **10 — Portfolio Desk**: Cross-agreement risk desk, counterparty credit ratings, and maturity ladder (2026–2032).
11. **11 — Reports & Audit**: Printable institutional memorandum, PDF tear-sheets, CSV data export, and audit history.
12. **12 — Hedge Strategy Comparator**: Side-by-side comparison of 6 procurement strategies (Spot, Fixed CfD, 80% Demand, Option Call, Combined, Installation-Linked).

---

## 4. Automated Acceptance Criteria Suite

Click the **"20 Acceptance Tests"** badge in the application header to execute the complete verification suite verifying all 20 acceptance criteria defined in Section 19 of the Master Specification.
