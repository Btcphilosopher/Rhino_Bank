# RhinoQuant Data Dictionary & Model Risk Governance

## Data Dictionary

| Field | Type | Units | Description |
|---|---|---|---|
| `strikePrice` | Float | Currency/MWh | Contractual agreed electricity strike price |
| `baseContractedVolumeMWh` | Float | MWh/year | Baseline annual energy volume eligible for settlement |
| `contractedCapacityMW` | Float | MW | Committed instantaneous generation capacity |
| `capacityPricePerMWYear` | Float | Currency/MW-year | Annual payment rate for available capacity |
| `grossSettlement` | Float | Currency | $(P_{\text{ref}} - P_{\text{strike}}) \times \text{Volume}$ |
| `cfads` | Float | Currency | Cash Flow Available for Debt Service ($\text{EBITDA} - \text{Tax} - \text{Reserves}$) |
| `dscr` | Float | Ratio ($x$) | $\text{CFADS} / \text{Scheduled Debt Service}$ |
| `llcr` | Float | Ratio ($x$) | NPV of loan-life CFADS / Outstanding Debt |
| `plcr` | Float | Ratio ($x$) | NPV of project-life CFADS / Outstanding Debt |

## Model Risk & Limitations

1. **Mark-to-Model Nature**: Valuations reflect mathematical model outputs based on forward curves and user discount assumptions. They are not firm broker quotations.
2. **Deterministic & Seeded Simulation**: Monte Carlo simulations utilize deterministic PRNGs ($seed=42$) to ensure bit-exact audit reproducibility.
3. **No Execution Claim**: Modelled structures are non-executed analytical agreements for structuring, stress-testing, and risk management.
