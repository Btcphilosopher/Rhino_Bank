# RhinoQuant Synthetic Energy - System Architecture

## Architecture Overview

RhinoQuant Synthetic Energy separates concerns into modular mathematical, financial, and analytical engines:

1. **Agreement Schema & State (`src/types/agreement.ts`, `R/agreement_schema.R`)**:
   Defines typed data representations for counterparties, energy agreements, capacity contracts, and status lifecycles.

2. **Strike-Price & Settlement Engine (`src/models/strikeEngine.ts`, `R/strike_price_engine.R`)**:
   Enforces bilateral cash-settled contracts for difference (CfD) with configurable caps, floors, transaction fees, and option premiums.

3. **Volumetric & Energy-Dependence Engine (`src/models/volumeEngine.ts`, `R/volume_engine.R`)**:
   Computes eligible settlement volume under four modes: Fixed Volume, Actual Metered, Percentage of Demand (e.g. 80%), and Optional Exercise.

4. **Installed Capacity Engine (`src/models/capacityEngine.ts`, `R/capacity_engine.R`)**:
   Models MW commitments, availability shortfall penalties, and battery energy storage degradation.

5. **Project Finance & Installation Model (`src/models/projectFinanceEngine.ts`, `R/project_finance.R`)**:
   Calculates CAPEX drawdowns, Interest During Construction (IDC), senior debt amortization, Cash Flow Available for Debt Service (CFADS), DSCR, LLCR, PLCR, and Project/Equity IRR via Newton-Raphson.

6. **Synthetic Instrument Lab (`src/models/syntheticLabEngine.ts`)**:
   Executes prioritized cash-flow waterfalls and subordinated tranche loss allocation (Senior, Mezzanine, First-Loss Equity).

7. **Valuation & CVA Desk (`src/models/valuationEngine.ts`)**:
   Discounts expected multi-year cash flows and applies counterparty credit risk adjustments.

8. **Risk & Monte Carlo Engine (`src/models/monteCarloEngine.ts`, `src/models/stressTestingEngine.ts`)**:
   Bivariate correlated simulation of energy prices and demand using Box-Muller transforms and seeded PRNGs.

9. **Acceptance Verification Suite (`src/models/acceptanceTests.ts`)**:
   Automated verification for all 20 acceptance criteria from Section 19 of the specification.
