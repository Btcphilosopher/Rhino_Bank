/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { 
  INITIAL_RESERVOIRS, 
  INITIAL_TREATMENT_WORKS, 
  INITIAL_DMAS, 
  INITIAL_PIPES, 
  INITIAL_LEAKS, 
  INITIAL_INCIDENTS, 
  INITIAL_WORK_ORDERS, 
  CUSTOMER_MASTER, 
  PROPERTY_MASTER, 
  METER_MASTER, 
  ENERGY_METERS, 
  PIPELINE_SYNC_REGISTRY, 
  LABORATORY_SAMPLES, 
  INITIAL_AUDIT_LOGS 
} from "./src/data/mockData.js";
import { TelemetryReading, AuditLogEntry, Incident, WorkOrder, Leak, LaboratorySample } from "./src/types.js";

const app = express();
const PORT = 3000;

app.use(express.json());

// In-Memory Database State
let reservoirs = [...INITIAL_RESERVOIRS];
let treatmentWorks = [...INITIAL_TREATMENT_WORKS];
let dmas = [...INITIAL_DMAS];
let pipes = [...INITIAL_PIPES];
let leaks = [...INITIAL_LEAKS];
let incidents = [...INITIAL_INCIDENTS];
let workOrders = [...INITIAL_WORK_ORDERS];
let customers = [...CUSTOMER_MASTER];
let properties = [...PROPERTY_MASTER];
let meters = [...METER_MASTER];
let energyMeters = [...ENERGY_METERS];
let pipelines = [...PIPELINE_SYNC_REGISTRY];
let laboratory = [...LABORATORY_SAMPLES];
let auditLogs = [...INITIAL_AUDIT_LOGS];

// Active simulation profile: "NORMAL" | "HEATWAVE" | "HEAVY_STORM" | "PIPE_BURST" | "TELEMETRY_FAULT" | "POWER_OUTAGE"
let simulationMode: "NORMAL" | "HEATWAVE" | "HEAVY_STORM" | "PIPE_BURST" | "TELEMETRY_FAULT" | "POWER_OUTAGE" = "NORMAL";

// Telemetry buffer representing the "TimescaleDB" data engine (retaining last 50 readings)
let telemetryBuffer: TelemetryReading[] = [];

// Helper to push audit logs
function addAudit(user: string, action: string, objectType: string, objectId: string, oldValue: string, newValue: string, reason: string, source: string = "Operational Simulator") {
  const log: AuditLogEntry = {
    id: `AUD-${Math.floor(10000 + Math.random() * 90000)}`,
    user,
    timestamp: new Date().toISOString(),
    action,
    objectType,
    objectId,
    oldValue,
    newValue,
    reason,
    source
  };
  auditLogs.unshift(log);
  if (auditLogs.length > 100) auditLogs.pop();
}

// Generate starting telemetry readings
function initTelemetry() {
  const now = new Date();
  reservoirs.forEach(res => {
    telemetryBuffer.push({
      timestamp: now.toISOString(),
      sensorId: `${res.id}-LEVEL`,
      value: res.currentLevelM,
      qualityCode: "VALID",
      source: "SCADA_RESERVOIR_OUTSTAT",
      ingestionTime: now.toISOString()
    });
  });
  dmas.forEach(dma => {
    telemetryBuffer.push({
      timestamp: now.toISOString(),
      sensorId: `${dma.id}-FLOW`,
      value: dma.measuredInflowMLD,
      qualityCode: "VALID",
      source: "SCADA_DISTRIBUTION_DMA",
      ingestionTime: now.toISOString()
    });
  });
}
initTelemetry();

// Simulation ticker running every 3 seconds to update operational parameters in real time!
setInterval(() => {
  const now = new Date();
  const timeStr = now.toISOString();

  // 1. Weather and natural changes depending on mode
  if (simulationMode === "NORMAL") {
    // Slight random walks for realism
    reservoirs = reservoirs.map(res => {
      const step = (Math.random() - 0.5) * 0.05;
      const volStep = step * (res.capacityML / 50);
      const newVol = Math.max(0, Math.min(res.capacityML, res.currentVolumeML + volStep));
      return {
        ...res,
        currentVolumeML: Number(newVol.toFixed(1)),
        currentLevelM: Number((res.currentLevelM + step * 0.1).toFixed(2)),
        percentageFull: Number(((newVol / res.capacityML) * 100).toFixed(1)),
        rainfallMM: Number((Math.max(0, res.rainfallMM + (Math.random() - 0.5) * 0.2)).toFixed(1)),
        waterQualityStatus: "EXCELLENT",
        telemetryStatus: "ONLINE"
      };
    });

    // Make sure incidents/work orders are aligned
    dmas = dmas.map(dma => {
      const walk = (Math.random() - 0.5) * 0.2;
      const inflow = Math.max(3.0, dma.measuredInflowMLD + walk);
      const leakage = Number((inflow * 0.15).toFixed(2));
      const consumption = Number((inflow - leakage - 0.2).toFixed(2));
      return {
        ...dma,
        measuredInflowMLD: Number(inflow.toFixed(2)),
        estimatedConsumptionMLD: consumption,
        leakageEstimateMLD: leakage,
        waterBalance: {
          input: Number(inflow.toFixed(2)),
          consumption,
          leakage,
          otherLosses: 0.2
        }
      };
    });

    // Ensure Keldgate / Headingley WTW operate normally
    treatmentWorks = treatmentWorks.map(tw => {
      if (tw.id.startsWith("WTW")) {
        return {
          ...tw,
          status: "OPERATIONAL",
          throughputMLD: Number((tw.capacityMLD * 0.75 + (Math.random() - 0.5) * 2).toFixed(1)),
          energyConsumptionKWh: Number((30000 + Math.random() * 5000).toFixed(0)),
          turbidityNTU: Number((0.05 + Math.random() * 0.04).toFixed(3)),
          phValue: Number((7.2 + (Math.random() - 0.5) * 0.1).toFixed(2)),
          chlorineResidualPPM: Number((0.5 + (Math.random() - 0.5) * 0.05).toFixed(2))
        };
      } else {
        // Wastewater works
        return {
          ...tw,
          status: "OPERATIONAL",
          throughputMLD: Number((tw.capacityMLD * 0.8 + (Math.random() - 0.5) * 3).toFixed(1)),
          energyConsumptionKWh: Number((60000 + Math.random() * 8000).toFixed(0)),
          turbidityNTU: Number((4.5 + Math.random() * 1.2).toFixed(2)),
          phValue: Number((6.8 + (Math.random() - 0.5) * 0.15).toFixed(2))
        };
      }
    });

  } else if (simulationMode === "HEATWAVE") {
    // Reservoirs fall, consumption spikes, temperatures spike
    reservoirs = reservoirs.map(res => {
      const abstractionIncr = 1.3; // Higher abstraction for demand
      const flowOut = res.outflowMLD * abstractionIncr;
      const inflowDecr = res.inflowMLD * 0.8;
      const volChange = (inflowDecr - flowOut) / 24; // 1-hour equivalent step
      const newVol = Math.max(0, Math.min(res.capacityML, res.currentVolumeML + volChange));
      return {
        ...res,
        inflowMLD: Number(inflowDecr.toFixed(1)),
        outflowMLD: Number(flowOut.toFixed(1)),
        currentVolumeML: Number(newVol.toFixed(1)),
        currentLevelM: Number((res.currentLevelM - 0.15).toFixed(2)),
        percentageFull: Number(((newVol / res.capacityML) * 100).toFixed(1)),
        waterQualityStatus: res.percentageFull < 70 ? "FAIR" : "EXCELLENT",
        rainfallMM: 0.0
      };
    });

    dmas = dmas.map(dma => {
      // Consumption spikes up to 25% higher
      const baseInflow = dma.measuredInflowMLD * 1.2;
      const consumption = Number((baseInflow * 0.85).toFixed(2));
      const leakage = Number((baseInflow * 0.12).toFixed(2));
      return {
        ...dma,
        measuredInflowMLD: Number(baseInflow.toFixed(2)),
        estimatedConsumptionMLD: consumption,
        leakageEstimateMLD: leakage,
        waterBalance: {
          input: Number(baseInflow.toFixed(2)),
          consumption,
          leakage,
          otherLosses: 0.3
        }
      };
    });

    treatmentWorks = treatmentWorks.map(tw => {
      if (tw.id.startsWith("WTW")) {
        // Pushing capacity limits
        return {
          ...tw,
          status: "OPERATIONAL",
          throughputMLD: Number((tw.capacityMLD * 0.95).toFixed(1)),
          energyConsumptionKWh: Number((45000 + Math.random() * 2000).toFixed(0)),
          turbidityNTU: Number((0.09 + Math.random() * 0.03).toFixed(3))
        };
      }
      return tw;
    });

  } else if (simulationMode === "HEAVY_STORM") {
    // Storm event: Rainfall spikes, reservoir inflows surge, wastewater flows exceed safe parameters, overflow active!
    reservoirs = reservoirs.map(res => {
      const stormInflow = res.inflowMLD * 2.2;
      const spillRelease = res.envReleaseMLD * 3.5;
      const volChange = (stormInflow - res.outflowMLD - spillRelease) / 24;
      const newVol = Math.max(0, Math.min(res.capacityML, res.currentVolumeML + volChange));
      return {
        ...res,
        inflowMLD: Number(stormInflow.toFixed(1)),
        envReleaseMLD: Number(spillRelease.toFixed(1)),
        rainfallMM: Number((res.rainfallMM + 12.5).toFixed(1)),
        currentVolumeML: Number(newVol.toFixed(1)),
        currentLevelM: Number((res.currentLevelM + 0.35).toFixed(2)),
        percentageFull: Number(((newVol / res.capacityML) * 100).toFixed(1))
      };
    });

    treatmentWorks = treatmentWorks.map(tw => {
      if (tw.id.startsWith("WWTW")) {
        // Wastewater treatment plants overloaded! Turbidity/PH fluctuates, flows exceed limits
        return {
          ...tw,
          status: "OPERATIONAL",
          throughputMLD: Number((tw.capacityMLD * 1.15).toFixed(1)), // Surcharged
          turbidityNTU: Number((12.4 + Math.random() * 4).toFixed(2)), // Higher particulates in effluent
          stages: {
            ...tw.stages,
            sedimentation: "WARNING"
          }
        };
      }
      return tw;
    });

  } else if (simulationMode === "PIPE_BURST") {
    // Triggered severe burst in Leeds City DMA
    dmas = dmas.map(dma => {
      if (dma.id === "DMA-LEED-001") {
        const burstInflow = 21.4; // Massively elevated flow
        const leakage = 9.8; // Estimated leakage spikes
        const consumption = 10.2; // Stable consumption but lower pressure
        return {
          ...dma,
          measuredInflowMLD: burstInflow,
          leakageEstimateMLD: leakage,
          minimumNightFlowLPS: 48.5, // Spiked night flow
          avgPressurePSI: 14.0, // Low pressure alert!
          waterBalance: {
            input: burstInflow,
            consumption,
            leakage,
            otherLosses: 1.4
          }
        };
      }
      return dma;
    });

    // Mark Leeds mainline pipe condition as POOR/FAILURE
    pipes = pipes.map(pipe => {
      if (pipe.id === "PIP-HEAD-LEED") {
        return { ...pipe, condition: "POOR", failureHistoryCount: pipe.failureHistoryCount + 1 };
      }
      return pipe;
    });

  } else if (simulationMode === "TELEMETRY_FAULT") {
    // Telemetry reporting corrupt or missing sensor values
    reservoirs = reservoirs.map(res => {
      if (res.id === "RES-ECCU-005") {
        return { ...res, telemetryStatus: "OFFLINE" };
      }
      return res;
    });
  } else if (simulationMode === "POWER_OUTAGE") {
    // Headingley WTW power supply interrupted!
    treatmentWorks = treatmentWorks.map(tw => {
      if (tw.id === "WTW-HEAD-001") {
        return {
          ...tw,
          status: "SHUTDOWN",
          throughputMLD: 0,
          energyConsumptionKWh: 0,
          stages: {
            screening: "FAIL",
            coagulation: "FAIL",
            sedimentation: "FAIL",
            filtration: "FAIL",
            disinfection: "FAIL"
          }
        };
      }
      return tw;
    });
  }

  // 2. Generate and push new Telemetry Readings into the Time-Series Ingestion Buffer
  reservoirs.forEach(res => {
    let readingVal = res.currentLevelM;
    let code: "VALID" | "SUSPECT" | "MISSING" | "ESTIMATED" = "VALID";
    
    if (simulationMode === "TELEMETRY_FAULT" && res.id === "RES-ECCU-005") {
      readingVal = -999.0; // Bad reading
      code = "SUSPECT";
    }

    telemetryBuffer.unshift({
      timestamp: timeStr,
      sensorId: `${res.id}-LEVEL`,
      value: readingVal,
      qualityCode: code,
      source: "SCADA_RESERVOIR_OUTSTAT",
      ingestionTime: timeStr
    });
  });

  dmas.forEach(dma => {
    let value = dma.measuredInflowMLD;
    let code: "VALID" | "SUSPECT" | "MISSING" | "ESTIMATED" = "VALID";
    
    if (simulationMode === "TELEMETRY_FAULT" && dma.id === "DMA-LEED-001") {
      // flatlining telemetry sensor simulation
      value = 12.4; 
      code = "ESTIMATED";
    }

    telemetryBuffer.unshift({
      timestamp: timeStr,
      sensorId: `${dma.id}-FLOW`,
      value,
      qualityCode: code,
      source: "SCADA_DISTRIBUTION_DMA",
      ingestionTime: timeStr
    });
  });

  // Limit telemetry buffer to 100 elements to prevent infinite memory growth
  if (telemetryBuffer.length > 100) {
    telemetryBuffer = telemetryBuffer.slice(0, 100);
  }

  // Increment some Sync Table statistics to prove real continuous processing
  pipelines = pipelines.map(p => {
    const recordsIncr = Math.floor(Math.random() * 5) + 1;
    let errs = p.errorCount;
    if (simulationMode === "TELEMETRY_FAULT" && p.name.includes("Telemetry")) {
      errs += 1;
    }
    return {
      ...p,
      lastSync: timeStr,
      recordCount: p.recordCount + recordsIncr,
      errorCount: errs,
      qualityScore: Number(Math.max(90, p.qualityScore - (errs > p.errorCount ? 0.4 : -0.05)).toFixed(1))
    };
  });

}, 3000);

// --- REST API ENDPOINTS ---

// GET - Single entry point for all operational states (Digital Twin master)
app.get("/api/v1/state", (req, res) => {
  res.json({
    reservoirs,
    treatmentWorks,
    dmas,
    pipes,
    leaks,
    incidents,
    workOrders,
    customers,
    properties,
    meters,
    energyMeters,
    pipelines,
    laboratory,
    auditLogs,
    simulationMode,
    telemetryBuffer
  });
});

// GET - Specific domains
app.get("/api/v1/reservoirs", (req, res) => res.json(reservoirs));
app.get("/api/v1/dmas", (req, res) => res.json(dmas));
app.get("/api/v1/incidents", (req, res) => res.json(incidents));
app.get("/api/v1/leaks", (req, res) => res.json(leaks));
app.get("/api/v1/customers", (req, res) => res.json(customers));
app.get("/api/v1/work-orders", (req, res) => res.json(workOrders));
app.get("/api/v1/telemetry", (req, res) => res.json(telemetryBuffer));
app.get("/api/v1/water-quality", (req, res) => res.json(laboratory));
app.get("/api/v1/audit-log", (req, res) => res.json(auditLogs));

// POST - Change Simulation Mode
app.post("/api/v1/simulate", (req, res) => {
  const { mode } = req.body;
  if (!["NORMAL", "HEATWAVE", "HEAVY_STORM", "PIPE_BURST", "TELEMETRY_FAULT", "POWER_OUTAGE"].includes(mode)) {
    return res.status(400).json({ error: "Invalid simulation mode" });
  }

  const oldMode = simulationMode;
  simulationMode = mode;

  // Trigger side-effects based on mode
  if (mode === "PIPE_BURST") {
    // Ensure active Incident exists for the burst
    const hasBurstIncident = incidents.some(inc => inc.id === "INC-2026-1042" && inc.status !== "CLOSED");
    if (!hasBurstIncident) {
      const newIncident: Incident = {
        id: `INC-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        type: "BURST_MAIN",
        severity: 4,
        location: "Clay Pit Lane, Leeds City Centre",
        latitude: 53.804,
        longitude: -1.542,
        startTime: new Date().toISOString(),
        detectedTime: new Date().toISOString(),
        owner: "John Harrison (Water Network Manager)",
        status: "INVESTIGATING",
        affectedAssets: ["PIP-HEAD-LEED"],
        affectedPropertiesCount: 2481,
        affectedCustomersCount: 4820,
        estimatedRestoration: new Date(Date.now() + 6 * 3600000).toISOString(),
        actualRestoration: null,
        timeline: [
          { timestamp: new Date().toISOString(), update: "Operational simulation initiated critical pipe burst event." }
        ]
      };
      incidents.unshift(newIncident);
    }
  } else if (mode === "NORMAL" && oldMode === "PIPE_BURST") {
    // Resolve incident
    incidents = incidents.map(inc => {
      if (inc.type === "BURST_MAIN" && inc.status !== "CLOSED") {
        return {
          ...inc,
          status: "RESOLVED",
          actualRestoration: new Date().toISOString(),
          timeline: [...inc.timeline, { timestamp: new Date().toISOString(), update: "Burst main repaired. System pressure fully restored." }]
        };
      }
      return inc;
    });
    // Reset DMA pressure
    dmas = dmas.map(dma => {
      if (dma.id === "DMA-LEED-001") {
        return {
          ...dma,
          measuredInflowMLD: 12.4,
          leakageEstimateMLD: 1.8,
          minimumNightFlowLPS: 18.5,
          avgPressurePSI: 48.5,
          waterBalance: { input: 12.4, consumption: 10.2, leakage: 1.8, otherLosses: 0.4 }
        };
      }
      return dma;
    });
  }

  addAudit(
    "tom@ahyx.org",
    "TRIGGER_SIMULATION",
    "SYSTEM",
    "SIMULATOR",
    oldMode,
    mode,
    `Operator updated utility simulation environment profile.`,
    "Simulation Control Board"
  );

  res.json({ success: true, currentMode: simulationMode });
});

// POST - Create / Report new incident
app.post("/api/v1/incidents", (req, res) => {
  const { type, severity, location, latitude, longitude, description } = req.body;
  if (!type || !severity || !location) {
    return res.status(400).json({ error: "Missing required incident properties" });
  }

  const newIncident: Incident = {
    id: `INC-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    type,
    severity: Number(severity) as 1 | 2 | 3 | 4,
    location,
    latitude: latitude || 53.801,
    longitude: longitude || -1.545,
    startTime: new Date().toISOString(),
    detectedTime: new Date().toISOString(),
    owner: "Network Control Desk",
    status: "INVESTIGATING",
    affectedAssets: [],
    affectedPropertiesCount: type === "BURST_MAIN" ? 1400 : 0,
    affectedCustomersCount: type === "BURST_MAIN" ? 2800 : 0,
    estimatedRestoration: new Date(Date.now() + 8 * 3600000).toISOString(),
    actualRestoration: null,
    timeline: [{ timestamp: new Date().toISOString(), update: `Incident reported manually: ${description || "No notes provided"}` }]
  };

  incidents.unshift(newIncident);
  addAudit(
    "tom@ahyx.org",
    "CREATE",
    "INCIDENT",
    newIncident.id,
    "NONE",
    newIncident.status,
    `Manually registered operational incident: ${type} at ${location}`,
    "Incident Management Desk"
  );

  res.json(newIncident);
});

// POST - Create / Update Work Order
app.post("/api/v1/work-orders", (req, res) => {
  const { id, status, notes, assignedEngineer, priority, assetId, location, incidentId } = req.body;

  if (id) {
    // Update existing work order
    let oldStatus = "UNKNOWN";
    workOrders = workOrders.map(wo => {
      if (wo.id === id) {
        oldStatus = wo.status;
        const isCompleting = status === "COMPLETED";
        return {
          ...wo,
          status,
          notes: notes || wo.notes,
          assignedEngineer: assignedEngineer || wo.assignedEngineer,
          completedTime: isCompleting ? new Date().toISOString() : wo.completedTime,
          labourHours: isCompleting ? Number((2 + Math.random() * 4).toFixed(2)) : wo.labourHours,
          costGBP: isCompleting ? Number((150 + Math.random() * 300).toFixed(2)) : wo.costGBP
        };
      }
      return wo;
    });

    addAudit(
      "tom@ahyx.org",
      "UPDATE",
      "WORK_ORDER",
      id,
      oldStatus,
      status,
      `Operator updated status to ${status}. Notes: ${notes || "None"}`,
      "Work Force Dispatcher"
    );

    res.json({ success: true, workOrder: workOrders.find(wo => wo.id === id) });
  } else {
    // Create new work order
    const newWO: WorkOrder = {
      id: `WO-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      incidentId: incidentId || null,
      assetId: assetId || "ASSET-UNSPECIFIED",
      assignedEngineer: assignedEngineer || "Unassigned Engineer Pool",
      priority: priority || "MEDIUM",
      location: location || "Yorkshire Network",
      createdTime: new Date().toISOString(),
      scheduledTime: new Date(Date.now() + 1800000).toISOString(),
      startedTime: null,
      completedTime: null,
      materialsUsed: [],
      labourHours: null,
      costGBP: null,
      notes: notes || "Initial dispatch instruction",
      status: "CREATED"
    };
    workOrders.unshift(newWO);

    addAudit(
      "tom@ahyx.org",
      "CREATE",
      "WORK_ORDER",
      newWO.id,
      "NONE",
      "CREATED",
      `Created work dispatch order for asset ${newWO.assetId} assigned to ${newWO.assignedEngineer}`,
      "Work Force Dispatcher"
    );

    res.json(newWO);
  }
});

// POST - Network Valve Control Simulator
app.post("/api/v1/valve-control", (req, res) => {
  const { valveId, action, reason } = req.body;
  if (!valveId || !action) {
    return res.status(400).json({ error: "Missing valveId or action parameters" });
  }

  addAudit(
    "tom@ahyx.org",
    "COMMAND_VALVE",
    "VALVE",
    valveId,
    action === "CLOSE" ? "OPEN" : "CLOSE",
    action,
    `Operator command: Valve ${action} at DMA bypass valve. Reason: ${reason || "Main balancing"}`,
    "SCADA Digital Controller"
  );

  res.json({ success: true, valveId, status: action });
});

// POST - Manual Laboratory Sample Input
app.post("/api/v1/laboratory", (req, res) => {
  const { samplingPoint, parameter, result, unit, thresholdValue, collectedBy } = req.body;
  if (!samplingPoint || !parameter || result === undefined) {
    return res.status(400).json({ error: "Missing LIMS registration inputs" });
  }

  const passed = Number(result) <= Number(thresholdValue);
  const newSample: LaboratorySample = {
    id: `SMP-2026-${Math.floor(10000 + Math.random() * 90000)}`,
    samplingPoint,
    sampleDate: new Date().toISOString(),
    collectedBy: collectedBy || "Self-Regulated Auto Sampler",
    parameter,
    result: Number(result),
    unit,
    detectionLimit: 0.01,
    method: "Spectrophotometry Analysis",
    passed,
    thresholdValue: Number(thresholdValue),
    chainOfCustody: "Sealed custody container verified by secure water platform"
  };

  laboratory.unshift(newSample);

  addAudit(
    "tom@ahyx.org",
    "REGISTER_SAMPLE",
    "LAB_SAMPLE",
    newSample.id,
    "NONE",
    passed ? "PASS" : "FAIL",
    `New laboratory water-quality analysis registered. Status: ${passed ? "PASSED" : "FAILED EXCEEDANCE ALERT"}`,
    "Laboratory LIMS Broker"
  );

  res.json(newSample);
});

// --- VITE MIDDLEWARE SETUP FOR DEV/PROD ---

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Yorkshire Water Central Data Platform running on http://localhost:${PORT}`);
  });
}

startServer();
