/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Reservoir, TreatmentWorks, DMA, Pipe, Leak, Incident, WorkOrder, Customer, Property, Meter, EnergyMeter, PipelineStatus, LaboratorySample, AuditLogEntry } from "../types";

export const INITIAL_RESERVOIRS: Reservoir[] = [
  {
    id: "RES-SCAR-001",
    name: "Scar House Reservoir",
    location: "Nidderdale (Upper Yorkshire)",
    catchmentName: "Nidderdale Catchment",
    capacityML: 9800,
    currentVolumeML: 7410,
    currentLevelM: 36.4,
    percentageFull: 75.6,
    inflowMLD: 42.0,
    outflowMLD: 31.0,
    rainfallMM: 2.4,
    damType: "Masonry Gravity Dam",
    envReleaseMLD: 8.5,
    abstractionMLD: 22.5,
    waterQualityStatus: "EXCELLENT",
    telemetryStatus: "ONLINE",
    historicalLevels: Array.from({ length: 12 }, (_, i) => ({
      timestamp: new Date(Date.now() - (11 - i) * 3600000 * 2).toISOString(),
      level: 36.4 + Math.sin(i / 2) * 0.4
    }))
  },
  {
    id: "RES-GRIM-002",
    name: "Grimwith Reservoir",
    location: "Wharfedale (Yorkshire Dales)",
    catchmentName: "Wharfedale Catchment",
    capacityML: 22000,
    currentVolumeML: 18120,
    currentLevelM: 45.2,
    percentageFull: 82.4,
    inflowMLD: 84.0,
    outflowMLD: 76.0,
    rainfallMM: 4.1,
    damType: "Earthfill Dam",
    envReleaseMLD: 15.0,
    abstractionMLD: 61.0,
    waterQualityStatus: "GOOD",
    telemetryStatus: "ONLINE",
    historicalLevels: Array.from({ length: 12 }, (_, i) => ({
      timestamp: new Date(Date.now() - (11 - i) * 3600000 * 2).toISOString(),
      level: 45.2 + Math.cos(i / 3) * 0.3
    }))
  },
  {
    id: "RES-FEWS-003",
    name: "Fewston Reservoir",
    location: "Washburn Valley",
    catchmentName: "Washburn Catchment",
    capacityML: 3900,
    currentVolumeML: 3120,
    currentLevelM: 18.1,
    percentageFull: 80.0,
    inflowMLD: 18.5,
    outflowMLD: 17.0,
    rainfallMM: 1.2,
    damType: "Earthfill with Clay Core",
    envReleaseMLD: 3.2,
    abstractionMLD: 13.8,
    waterQualityStatus: "GOOD",
    telemetryStatus: "ONLINE",
    historicalLevels: Array.from({ length: 12 }, (_, i) => ({
      timestamp: new Date(Date.now() - (11 - i) * 3600000 * 2).toISOString(),
      level: 18.1 + Math.sin(i / 4) * 0.2
    }))
  },
  {
    id: "RES-SWIN-004",
    name: "Swinsty Reservoir",
    location: "Washburn Valley",
    catchmentName: "Washburn Catchment",
    capacityML: 4300,
    currentVolumeML: 3268,
    currentLevelM: 19.5,
    percentageFull: 76.0,
    inflowMLD: 21.0,
    outflowMLD: 20.0,
    rainfallMM: 1.2,
    damType: "Earthfill",
    envReleaseMLD: 4.0,
    abstractionMLD: 16.0,
    waterQualityStatus: "EXCELLENT",
    telemetryStatus: "ONLINE",
    historicalLevels: Array.from({ length: 12 }, (_, i) => ({
      timestamp: new Date(Date.now() - (11 - i) * 3600000 * 2).toISOString(),
      level: 19.5 + Math.cos(i / 2) * 0.15
    }))
  },
  {
    id: "RES-ECCU-005",
    name: "Eccup Reservoir",
    location: "North Leeds",
    catchmentName: "Wharfe & Eccup Catchment",
    capacityML: 6400,
    currentVolumeML: 4210,
    currentLevelM: 22.8,
    percentageFull: 65.8,
    inflowMLD: 24.0,
    outflowMLD: 28.0,
    rainfallMM: 0.8,
    damType: "Earthen Dam",
    envReleaseMLD: 2.0,
    abstractionMLD: 26.0,
    waterQualityStatus: "FAIR",
    telemetryStatus: "DEGRADED",
    historicalLevels: Array.from({ length: 12 }, (_, i) => ({
      timestamp: new Date(Date.now() - (11 - i) * 3600000 * 2).toISOString(),
      level: 22.8 - (i * 0.05)
    }))
  }
];

export const INITIAL_TREATMENT_WORKS: TreatmentWorks[] = [
  {
    id: "WTW-HEAD-001",
    name: "Headingley Water Treatment Works",
    status: "OPERATIONAL",
    capacityMLD: 120.0,
    throughputMLD: 94.5,
    energyConsumptionKWh: 34200,
    chemicalUsageKg: { chlorine: 180, coagulant: 620, fluoride: 45 },
    stages: { screening: "PASS", coagulation: "PASS", sedimentation: "PASS", filtration: "PASS", disinfection: "PASS" },
    turbidityNTU: 0.08,
    phValue: 7.21,
    chlorineResidualPPM: 0.52
  },
  {
    id: "WTW-KELD-002",
    name: "Keldgate Water Treatment Works",
    status: "OPERATIONAL",
    capacityMLD: 150.0,
    throughputMLD: 112.0,
    energyConsumptionKWh: 48500,
    chemicalUsageKg: { chlorine: 220, coagulant: 750, fluoride: 58 },
    stages: { screening: "PASS", coagulation: "PASS", sedimentation: "PASS", filtration: "PASS", disinfection: "PASS" },
    turbidityNTU: 0.05,
    phValue: 7.42,
    chlorineResidualPPM: 0.48
  },
  {
    id: "WWTW-ESHL-003",
    name: "Esholt Wastewater Treatment Works",
    status: "OPERATIONAL",
    capacityMLD: 180.0,
    throughputMLD: 142.1,
    energyConsumptionKWh: 61200,
    chemicalUsageKg: { chlorine: 0, coagulant: 980, fluoride: 0 },
    stages: { screening: "PASS", coagulation: "PASS", sedimentation: "PASS", filtration: "PASS", disinfection: "PASS" },
    turbidityNTU: 4.8, // Treated effluent turbidity
    phValue: 6.85,
    chlorineResidualPPM: 0.02
  },
  {
    id: "WWTW-BLAC-004",
    name: "Blackburn Meadows WwTW",
    status: "OPERATIONAL",
    capacityMLD: 240.0,
    throughputMLD: 198.4,
    energyConsumptionKWh: 81400,
    chemicalUsageKg: { chlorine: 0, coagulant: 1240, fluoride: 0 },
    stages: { screening: "PASS", coagulation: "PASS", sedimentation: "PASS", filtration: "PASS", disinfection: "PASS" },
    turbidityNTU: 5.2,
    phValue: 6.91,
    chlorineResidualPPM: 0.01
  }
];

export const INITIAL_DMAS: DMA[] = [
  {
    id: "DMA-LEED-001",
    name: "Leeds City Centre DMA",
    region: "West Yorkshire",
    pressureZone: "LS-ZONE-A",
    inputMeterIds: ["MTR-IN-LDS01", "MTR-IN-LDS02"],
    outputMeterIds: ["MTR-OUT-LDS01"],
    connections: 18450,
    measuredInflowMLD: 12.4,
    estimatedConsumptionMLD: 10.2,
    minimumNightFlowLPS: 18.5,
    leakageEstimateMLD: 1.8,
    avgPressurePSI: 48.5,
    waterBalance: { input: 12.4, consumption: 10.2, leakage: 1.8, otherLosses: 0.4 }
  },
  {
    id: "DMA-SHEF-002",
    name: "Sheffield Hallam DMA",
    region: "South Yorkshire",
    pressureZone: "SH-ZONE-C",
    inputMeterIds: ["MTR-IN-SHF01"],
    outputMeterIds: [],
    connections: 12100,
    measuredInflowMLD: 8.6,
    estimatedConsumptionMLD: 6.8,
    minimumNightFlowLPS: 14.2,
    leakageEstimateMLD: 1.5,
    avgPressurePSI: 52.0,
    waterBalance: { input: 8.6, consumption: 6.8, leakage: 1.5, otherLosses: 0.3 }
  },
  {
    id: "DMA-BRAD-003",
    name: "Bradford West DMA",
    region: "West Yorkshire",
    pressureZone: "BD-ZONE-B",
    inputMeterIds: ["MTR-IN-BRD01", "MTR-IN-BRD02"],
    outputMeterIds: ["MTR-OUT-BRD01"],
    connections: 22150,
    measuredInflowMLD: 15.8,
    estimatedConsumptionMLD: 12.1,
    minimumNightFlowLPS: 28.4,
    leakageEstimateMLD: 3.1,
    avgPressurePSI: 44.2,
    waterBalance: { input: 15.8, consumption: 12.1, leakage: 3.1, otherLosses: 0.6 }
  },
  {
    id: "DMA-YORK-004",
    name: "York Minster DMA",
    region: "North Yorkshire",
    pressureZone: "YO-ZONE-MINSTER",
    inputMeterIds: ["MTR-IN-YRK01"],
    outputMeterIds: [],
    connections: 9800,
    measuredInflowMLD: 6.2,
    estimatedConsumptionMLD: 5.1,
    minimumNightFlowLPS: 8.9,
    leakageEstimateMLD: 0.9,
    avgPressurePSI: 46.0,
    waterBalance: { input: 6.2, consumption: 5.1, leakage: 0.9, otherLosses: 0.2 }
  },
  {
    id: "DMA-HARR-005",
    name: "Harrogate East DMA",
    region: "North Yorkshire",
    pressureZone: "HG-ZONE-EAST",
    inputMeterIds: ["MTR-IN-HRG01"],
    outputMeterIds: [],
    connections: 11400,
    measuredInflowMLD: 7.9,
    estimatedConsumptionMLD: 6.4,
    minimumNightFlowLPS: 12.8,
    leakageEstimateMLD: 1.2,
    avgPressurePSI: 50.5,
    waterBalance: { input: 7.9, consumption: 6.4, leakage: 1.2, otherLosses: 0.3 }
  }
];

export const INITIAL_PIPES: Pipe[] = [
  { id: "PIP-SCAR-GRIM", startNode: "RES-SCAR-001", endNode: "RES-GRIM-002", lengthM: 14500, diameterMM: 900, material: "STEEL", installationYear: 1978, pressureZone: "RAW-TRUNK", dmaId: "DMA-RAW", condition: "GOOD", failureHistoryCount: 1 },
  { id: "PIP-GRIM-HEAD", startNode: "RES-GRIM-002", endNode: "WTW-HEAD-001", lengthM: 26000, diameterMM: 1200, material: "DI", installationYear: 1989, pressureZone: "RAW-TRUNK", dmaId: "DMA-RAW", condition: "EXCELLENT", failureHistoryCount: 0 },
  { id: "PIP-FEWS-SWIN", startNode: "RES-FEWS-003", endNode: "RES-SWIN-004", lengthM: 2100, diameterMM: 800, material: "CI", installationYear: 1964, pressureZone: "RAW-TRUNK", dmaId: "DMA-RAW", condition: "FAIR", failureHistoryCount: 3 },
  { id: "PIP-SWIN-ECCU", startNode: "RES-SWIN-004", endNode: "RES-ECCU-005", lengthM: 12200, diameterMM: 1000, material: "DI", installationYear: 1995, pressureZone: "RAW-TRUNK", dmaId: "DMA-RAW", condition: "GOOD", failureHistoryCount: 0 },
  { id: "PIP-ECCU-HEAD", startNode: "RES-ECCU-005", endNode: "WTW-HEAD-001", lengthM: 6400, diameterMM: 800, material: "CI", installationYear: 1952, pressureZone: "RAW-TRUNK", dmaId: "DMA-RAW", condition: "POOR", failureHistoryCount: 8 },
  { id: "PIP-HEAD-LEED", startNode: "WTW-HEAD-001", endNode: "DMA-LEED-001", lengthM: 4200, diameterMM: 600, material: "PE", installationYear: 2012, pressureZone: "LS-ZONE-A", dmaId: "DMA-LEED-001", condition: "EXCELLENT", failureHistoryCount: 0 },
  { id: "PIP-HEAD-BRAD", startNode: "WTW-HEAD-001", endNode: "DMA-BRAD-003", lengthM: 8600, diameterMM: 600, material: "PE", installationYear: 2008, pressureZone: "BD-ZONE-B", dmaId: "DMA-BRAD-003", condition: "GOOD", failureHistoryCount: 1 }
];

export const INITIAL_LEAKS: Leak[] = [
  {
    id: "LEAK-2026-001",
    dmaId: "DMA-LEED-001",
    location: "Park Row, Leeds City Centre",
    latitude: 53.799,
    longitude: -1.547,
    detectionMethod: "ACOUSTIC_SENSOR",
    detectionDate: "2026-08-08T03:14:00Z",
    reportedDate: "2026-08-08T06:00:00Z",
    estimatedFlowLPS: 2.8,
    actualFlowLPS: 0.0,
    pipeId: "PIP-HEAD-LEED",
    status: "CONFIRMED",
    repairDate: null,
    repairCostGBP: null,
    waterSavedML: null
  },
  {
    id: "LEAK-2026-002",
    dmaId: "DMA-BRAD-003",
    location: "Thornton Road, Bradford West",
    latitude: 53.795,
    longitude: -1.782,
    detectionMethod: "DMA_ANALYSIS",
    detectionDate: "2026-08-09T01:45:00Z",
    reportedDate: "2026-08-09T02:30:00Z",
    estimatedFlowLPS: 4.5,
    actualFlowLPS: 0.0,
    pipeId: "PIP-HEAD-BRAD",
    status: "SCHEDULED",
    repairDate: null,
    repairCostGBP: null,
    waterSavedML: null
  },
  {
    id: "LEAK-2026-003",
    dmaId: "DMA-SHEF-002",
    location: "Fulwood Road, Sheffield",
    latitude: 53.374,
    longitude: -1.512,
    detectionMethod: "CUSTOMER_REPORT",
    detectionDate: "2026-08-05T14:20:00Z",
    reportedDate: "2026-08-05T14:35:00Z",
    estimatedFlowLPS: 1.5,
    actualFlowLPS: 1.5,
    pipeId: "PIP-ECCU-HEAD",
    status: "REPAIRED",
    repairDate: "2026-08-07T11:30:00Z",
    repairCostGBP: 3400,
    waterSavedML: 0.26
  }
];

export const INITIAL_INCIDENTS: Incident[] = [
  {
    id: "INC-2026-1042",
    type: "BURST_MAIN",
    severity: 3,
    location: "Clay Pit Lane, Leeds",
    latitude: 53.804,
    longitude: -1.542,
    startTime: "2026-08-10T04:15:00Z",
    detectedTime: "2026-08-10T04:18:00Z",
    owner: "John Harrison (Water Network Manager)",
    status: "REPAIRING",
    affectedAssets: ["PIP-HEAD-LEED"],
    affectedPropertiesCount: 2481,
    affectedCustomersCount: 4820,
    estimatedRestoration: "2026-08-10T12:00:00Z",
    actualRestoration: null,
    timeline: [
      { timestamp: "2026-08-10T04:18:00Z", update: "Telemetry alarm triggered: Sudden pressure drop (52 PSI -> 14 PSI) at Headingley Trunk Main feed." },
      { timestamp: "2026-08-10T04:25:00Z", update: "Incident level 3 declared. Multi-agency customer notifications dispatched via SMS." },
      { timestamp: "2026-08-10T04:50:00Z", update: "Field engineering crew isolated the burst section. Pressure stabilized on bypass feed." },
      { timestamp: "2026-08-10T05:30:00Z", update: "Excavation complete. Damaged 12-inch ductile iron pipe segment exposed." }
    ]
  },
  {
    id: "INC-2026-1043",
    type: "WATER_QUALITY",
    severity: 2,
    location: "Eccup Raw Water Valve",
    latitude: 53.868,
    longitude: -1.541,
    startTime: "2026-08-09T18:30:00Z",
    detectedTime: "2026-08-09T19:00:00Z",
    owner: "Sarah Jenkins (Laboratory Analyst)",
    status: "CONTAINED",
    affectedAssets: ["RES-ECCU-005"],
    affectedPropertiesCount: 0,
    affectedCustomersCount: 0,
    estimatedRestoration: "2026-08-11T18:00:00Z",
    actualRestoration: null,
    timeline: [
      { timestamp: "2026-08-09T19:00:00Z", update: "Routine laboratory sample detected turbidity spike of 4.2 NTU near raw intake." },
      { timestamp: "2026-08-09T20:15:00Z", update: "Adjusted coagulation dosage at Headingley WTW. Ingress isolated." }
    ]
  }
];

export const INITIAL_WORK_ORDERS: WorkOrder[] = [
  {
    id: "WO-2026-8941",
    incidentId: "INC-2026-1042",
    assetId: "PIP-HEAD-LEED",
    assignedEngineer: "Robert Sterling (Senior Field Engineer)",
    priority: "CRITICAL",
    location: "Clay Pit Lane, Leeds",
    createdTime: "2026-08-10T04:30:00Z",
    scheduledTime: "2026-08-10T04:35:00Z",
    startedTime: "2026-08-10T04:55:00Z",
    completedTime: null,
    materialsUsed: ["12-inch DI collar joint", "Granular gravel pack", "Enviropol sealing sleeve"],
    labourHours: null,
    costGBP: null,
    notes: "Requires complete excavation and replacement of high-stress joint near main roundabout. Traffic diversion in place.",
    status: "IN_PROGRESS"
  },
  {
    id: "WO-2026-8942",
    incidentId: "INC-2026-1043",
    assetId: "RES-ECCU-005",
    assignedEngineer: "Mark Higgins (Environmental Tech)",
    priority: "MEDIUM",
    location: "Eccup Inlet Gate 3",
    createdTime: "2026-08-10T01:00:00Z",
    scheduledTime: "2026-08-10T08:30:00Z",
    startedTime: "2026-08-10T09:00:00Z",
    completedTime: "2026-08-10T10:45:00Z",
    materialsUsed: ["Coagulant dosage pump diaphragm replacement", "Filter cleaning kit"],
    labourHours: 1.75,
    costGBP: 420.0,
    notes: "Completed routine inspection and replaced aging diaphragm on chemical feed system.",
    status: "COMPLETED"
  }
];

export const CUSTOMER_MASTER: Customer[] = [
  { id: "CST-94021", accountId: "ACC-1002-401", name: "Sir David Attenborough", email: "david.a@yorkshire-conservation.org", phone: "+44 7700 900077", commsPreference: "EMAIL", type: "RESIDENTIAL", vulnerabilityFlag: true, status: "ACTIVE", createdDate: "2018-05-12T08:00:00Z", updatedDate: "2025-01-20T10:00:00Z" },
  { id: "CST-10492", accountId: "ACC-5521-881", name: "Judi Dench", email: "judi.dench@theatre-york.co.uk", phone: "+44 7700 900142", commsPreference: "SMS", type: "RESIDENTIAL", vulnerabilityFlag: false, status: "ACTIVE", createdDate: "2020-11-04T09:15:00Z", updatedDate: "2026-03-12T14:30:00Z" },
  { id: "CST-20412", accountId: "ACC-9041-331", name: "Yorkshire Brewing Co.", email: "procurement@yorkshirebrews.co.uk", phone: "+44 113 496 0812", commsPreference: "EMAIL", type: "INDUSTRIAL", vulnerabilityFlag: false, status: "ACTIVE", createdDate: "2015-02-18T07:30:00Z", updatedDate: "2026-07-01T11:00:00Z" }
];

export const PROPERTY_MASTER: Property[] = [
  { id: "PRP-2041", uprn: "100051203401", address: "14 Nidderdale Rise, Harrogate", postcode: "HG1 5QN", latitude: 53.996, longitude: -1.534, type: "DETACHED", occupancy: 4, meterId: "MTR-SMT-004122", sewerConnected: true, waterZone: "HG-ZONE-EAST", dmaId: "DMA-HARR-005", pressureZone: "HG-ZONE-EAST", accountId: "ACC-1002-401" },
  { id: "PRP-5521", uprn: "100051208812", address: "Flat 4, Minster Court, York", postcode: "YO1 7JF", latitude: 53.962, longitude: -1.082, type: "APARTMENT", occupancy: 2, meterId: "MTR-SMT-009941", sewerConnected: true, waterZone: "YO-ZONE-MINSTER", dmaId: "DMA-YORK-004", pressureZone: "YO-ZONE-MINSTER", accountId: "ACC-5521-881" },
  { id: "PRP-9041", uprn: "100051203310", address: "Kirkstall Road Industrial Estate, Leeds", postcode: "LS4 2QD", latitude: 53.805, longitude: -1.579, type: "COMMERCIAL", occupancy: 45, meterId: "MTR-SMT-001088", sewerConnected: true, waterZone: "LS-ZONE-A", dmaId: "DMA-LEED-001", pressureZone: "LS-ZONE-A", accountId: "ACC-9041-331" }
];

export const METER_MASTER: Meter[] = [
  { id: "MTR-SMT-004122", propertyId: "PRP-2041", type: "SMART", manufacturer: "Kamstrup", installationDate: "2022-04-10T10:00:00Z", batteryStatus: 92, commStatus: "ONLINE", lastReading: 218.45, lastReadingTime: "2026-08-10T05:30:00Z" },
  { id: "MTR-SMT-009941", propertyId: "PRP-5521", type: "SMART", manufacturer: "Sensus", installationDate: "2023-01-15T11:30:00Z", batteryStatus: 88, commStatus: "ONLINE", lastReading: 104.22, lastReadingTime: "2026-08-10T05:45:00Z" },
  { id: "MTR-SMT-001088", propertyId: "PRP-9041", type: "SMART", manufacturer: "Elster", installationDate: "2021-08-20T09:00:00Z", batteryStatus: 74, commStatus: "ONLINE", lastReading: 1245.90, lastReadingTime: "2026-08-10T05:00:00Z" }
];

export const ENERGY_METERS: EnergyMeter[] = [
  { id: "ENG-HEAD-WTW", siteName: "Headingley WTW", type: "WATER_TREATMENT", kwhToday: 14250, costGBP: 2850, tariffName: "UtilityFlex Peak-Saver", carbonKg: 1980, renewableOffsetKWh: 4200, renewableSource: "SOLAR" },
  { id: "ENG-KELD-WTW", siteName: "Keldgate WTW", type: "WATER_TREATMENT", kwhToday: 18400, costGBP: 3680, tariffName: "UtilityFlex Peak-Saver", carbonKg: 2560, renewableOffsetKWh: 6800, renewableSource: "WIND" },
  { id: "ENG-ESHL-WWTW", siteName: "Esholt WwTW", type: "WASTEWATER", kwhToday: 32100, costGBP: 6420, tariffName: "EcoEnterprise Green", carbonKg: 4460, renewableOffsetKWh: 12400, renewableSource: "CHP" },
  { id: "ENG-BLAC-WWTW", siteName: "Blackburn Meadows WwTW", type: "WASTEWATER", kwhToday: 41200, costGBP: 8240, tariffName: "EcoEnterprise Green", carbonKg: 5720, renewableOffsetKWh: 15100, renewableSource: "CHP" }
];

export const PIPELINE_SYNC_REGISTRY: PipelineStatus[] = [
  { name: "Telemetry (SCADA-Timescale)", status: "HEALTHY", lastSync: "2026-08-10T06:09:50Z", recordCount: 1450210, errorCount: 0, qualityScore: 98.4 },
  { name: "Billing Systems (SAP-ISU)", status: "HEALTHY", lastSync: "2026-08-10T06:00:00Z", recordCount: 12500, errorCount: 0, qualityScore: 99.8 },
  { name: "GIS Spatial Maps (PostGIS-ESRI)", status: "WARNING", lastSync: "2026-08-09T22:00:00Z", recordCount: 84120, errorCount: 12, qualityScore: 99.1 },
  { name: "Laboratory LIMS System", status: "HEALTHY", lastSync: "2026-08-10T05:30:00Z", recordCount: 425, errorCount: 0, qualityScore: 99.9 }
];

export const LABORATORY_SAMPLES: LaboratorySample[] = [
  { id: "SMP-2026-40121", samplingPoint: "Headingley WTW Final Water Tank", sampleDate: "2026-08-10T04:30:00Z", collectedBy: "Clara Bow", parameter: "Chlorine Residual", result: 0.52, unit: "mg/L", detectionLimit: 0.01, method: "DPD Colorimetry", passed: true, thresholdValue: 0.5, chainOfCustody: "Secure LIMS Vault" },
  { id: "SMP-2026-40122", samplingPoint: "Headingley WTW Final Water Tank", sampleDate: "2026-08-10T04:30:00Z", collectedBy: "Clara Bow", parameter: "Turbidity", result: 0.08, unit: "NTU", detectionLimit: 0.01, method: "Nephelometry", passed: true, thresholdValue: 1.0, chainOfCustody: "Secure LIMS Vault" },
  { id: "SMP-2026-40123", samplingPoint: "Eccup Raw Water Intake", sampleDate: "2026-08-10T04:00:00Z", collectedBy: "Clara Bow", parameter: "pH Value", result: 7.21, unit: "pH", detectionLimit: 0.01, method: "Electrode Probe", passed: true, thresholdValue: 9.5, chainOfCustody: "Secure LIMS Vault" },
  { id: "SMP-2026-40124", samplingPoint: "Keldgate WTW Supply Main", sampleDate: "2026-08-09T14:00:00Z", collectedBy: "Dave Grohl", parameter: "Iron Content", result: 14.5, unit: "μg/L", detectionLimit: 1.0, method: "ICP-MS Spectrometry", passed: true, thresholdValue: 200.0, chainOfCustody: "Secure LIMS Vault" },
  { id: "SMP-2026-40125", samplingPoint: "Blackburn Meadows Effluent discharge", sampleDate: "2026-08-10T02:00:00Z", collectedBy: "Geddy Lee", parameter: "Ammonia (as N)", result: 4.8, unit: "mg/L", detectionLimit: 0.05, method: "Colorimetry", passed: false, thresholdValue: 3.0, chainOfCustody: "Discharge Audit Trail" }
];

export const INITIAL_AUDIT_LOGS: AuditLogEntry[] = [
  { id: "AUD-10021", user: "tom@ahyx.org", timestamp: "2026-08-10T05:30:00Z", action: "UPDATE", objectType: "WORK_ORDER", objectId: "WO-2026-8942", oldValue: "IN_PROGRESS", newValue: "COMPLETED", reason: "Maintenance work concluded. Repaired diaphragm on dosing pump.", source: "Web Dashboard" },
  { id: "AUD-10022", user: "SYSTEM_MONITOR", timestamp: "2026-08-10T04:18:00Z", action: "CREATE", objectType: "INCIDENT", objectId: "INC-2026-1042", oldValue: "NONE", newValue: "ACTIVE", reason: "Auto-detected sudden flow rate and pressure discrepancy inside Leeds City Center DMA.", source: "TimescaleDB Telemetry Analyser" }
];
