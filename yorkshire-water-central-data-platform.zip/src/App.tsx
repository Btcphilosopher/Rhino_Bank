/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Reservoir, 
  TreatmentWorks, 
  DMA, 
  Pipe, 
  Leak, 
  Incident, 
  WorkOrder, 
  TelemetryReading, 
  LaboratorySample, 
  PipelineStatus, 
  EnergyMeter, 
  AuditLogEntry, 
  Customer, 
  Property 
} from "./types";
import { NetworkMap } from "./components/NetworkMap";
import { TelemetryView } from "./components/TelemetryView";
import { ReservoirView } from "./components/ReservoirView";
import { LeakageView } from "./components/LeakageView";
import { LabView } from "./components/LabView";
import { IncidentView } from "./components/IncidentView";
import { AssetView } from "./components/AssetView";
import { EnergyView } from "./components/EnergyView";
import { SystemView } from "./components/SystemView";

import { 
  Droplet, 
  AlertTriangle, 
  Activity, 
  Users, 
  TrendingUp, 
  Wrench, 
  ShieldAlert, 
  RefreshCw, 
  Server, 
  FileText, 
  Sliders, 
  Radio, 
  HelpCircle,
  Database,
  Search,
  BookOpen
} from "lucide-react";

export default function App() {
  // Operational state from backend
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [reservoirs, setReservoirs] = useState<Reservoir[]>([]);
  const [treatmentWorks, setTreatmentWorks] = useState<TreatmentWorks[]>([]);
  const [dmas, setDmas] = useState<DMA[]>([]);
  const [pipes, setPipes] = useState<Pipe[]>([]);
  const [leaks, setLeaks] = useState<Leak[]>([]);
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [properties, setProperties] = useState<Property[]>([]);
  const [energyMeters, setEnergyMeters] = useState<EnergyMeter[]>([]);
  const [pipelines, setPipelines] = useState<PipelineStatus[]>([]);
  const [laboratory, setLaboratory] = useState<LaboratorySample[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [simulationMode, setSimulationMode] = useState<string>("NORMAL");
  const [telemetry, setTelemetry] = useState<TelemetryReading[]>([]);

  // Selection state for GIS map inspector
  const [selectedAsset, setSelectedAsset] = useState<{ id: string; name: string; type: string; data: any } | null>(null);

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<"map" | "telemetry" | "reservoirs" | "leakage" | "lab" | "incidents" | "assets" | "energy" | "system" | "docs">("map");

  // Manual SCADA Valve override simulator controls
  const [valveId, setValveId] = useState("VLV-DMA-042");
  const [valveAction, setValveAction] = useState("CLOSE");
  const [valveReason, setValveReason] = useState("DMA hydraulic isolation balance test");
  const [valveFeedback, setValveFeedback] = useState<string | null>(null);

  // Customer Property lookup search
  const [uprnSearch, setUprnSearch] = useState("");
  const [searchedProperty, setSearchedProperty] = useState<Property | null>(null);
  const [searchedCustomer, setSearchedCustomer] = useState<Customer | null>(null);

  // Poll state every 2.5 seconds for true real-time operational feedback!
  const fetchData = async (isInitial = false) => {
    try {
      if (isInitial) setLoading(true);
      const res = await fetch("/api/v1/state");
      if (!res.ok) throw new Error("Connection error to core CDP system broker");
      const data = await res.json();
      
      setReservoirs(data.reservoirs);
      setTreatmentWorks(data.treatmentWorks);
      setDmas(data.dmas);
      setPipes(data.pipes);
      setLeaks(data.leaks);
      setIncidents(data.incidents);
      setWorkOrders(data.workOrders);
      setCustomers(data.customers);
      setProperties(data.properties);
      setEnergyMeters(data.energyMeters);
      setPipelines(data.pipelines);
      setLaboratory(data.laboratory);
      setAuditLogs(data.auditLogs);
      setSimulationMode(data.simulationMode);
      setTelemetry(data.telemetryBuffer);
      setError(null);
    } catch (err: any) {
      setError(err.message || "Failed to synchronise state with authoritative CDP ledger.");
    } finally {
      if (isInitial) setLoading(false);
    }
  };

  useEffect(() => {
    fetchData(true);
    const interval = setInterval(() => fetchData(false), 2500);
    return () => clearInterval(interval);
  }, []);

  // Post - Set simulation profile
  const handleSimulate = async (mode: string) => {
    try {
      const res = await fetch("/api/v1/simulate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode })
      });
      if (res.ok) {
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Post - Trigger custom manual incident
  const handleAddIncident = async (newInc: { type: string; severity: number; location: string; description: string }) => {
    try {
      const res = await fetch("/api/v1/incidents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newInc)
      });
      if (res.ok) {
        fetchData();
        setActiveTab("incidents");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Post - Dispatch / Update work order
  const handleUpdateWorkOrder = async (id: string, status: string, notes: string) => {
    try {
      const res = await fetch("/api/v1/work-orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status, notes })
      });
      if (res.ok) {
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Post - Add laboratory sample analysis
  const handleAddSample = async (sample: any) => {
    try {
      const res = await fetch("/api/v1/laboratory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(sample)
      });
      if (res.ok) {
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Post - Manual SCADA override command
  const handleValveOverrideSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/v1/valve-control", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ valveId, action: valveAction, reason: valveReason })
      });
      if (res.ok) {
        setValveFeedback(`Valve command successfully registered: Valve ${valveId} set to ${valveAction}.`);
        setTimeout(() => setValveFeedback(null), 4000);
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Client-side Master Property UPRN index search lookup
  const handleUprnSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const prop = properties.find(p => p.uprn === uprnSearch || p.postcode.toLowerCase().replace(" ", "") === uprnSearch.toLowerCase().replace(" ", ""));
    if (prop) {
      setSearchedProperty(prop);
      const cust = customers.find(c => c.accountId === prop.accountId);
      setSearchedCustomer(cust || null);
    } else {
      setSearchedProperty(null);
      setSearchedCustomer(null);
    }
  };

  // HUD Metrics calculation
  const totalCapacity = reservoirs.reduce((sum, r) => sum + r.capacityML, 0);
  const currentVolume = reservoirs.reduce((sum, r) => sum + r.currentVolumeML, 0);
  const globalStoragePct = totalCapacity > 0 ? (currentVolume / totalCapacity) * 100 : 0;
  const activeIncidents = incidents.filter(i => i.status !== "CLOSED" && i.status !== "RESOLVED").length;
  const totalWaterSaved = leaks.reduce((sum, l) => sum + (l.waterSavedML || 0), 0);
  const totalDemand = dmas.reduce((sum, d) => sum + d.measuredInflowMLD, 0);
  const affectedCustomers = incidents.reduce((sum, i) => sum + (i.status !== "RESOLVED" && i.status !== "CLOSED" ? i.affectedCustomersCount : 0), 0);

  return (
    <div className="relative min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans overflow-x-hidden" id="cdp-root">
      {/* Subtle Dot Grid Background */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-[0.04]"
        style={{ 
          backgroundImage: "radial-gradient(circle at 2px 2px, #f8fafc 1.5px, transparent 0)", 
          backgroundSize: "24px 24px" 
        }} 
      />

      {/* Top Authoritative Banner */}
      <header className="relative z-10 bg-slate-900/50 backdrop-blur-md border-b border-slate-800/80 px-6 py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-sky-600 text-white w-10 h-10 rounded-lg flex items-center justify-center font-black tracking-wider text-base shadow-lg shadow-sky-950/40">
            YW
          </div>
          <div>
            <h1 className="text-lg font-black tracking-tight text-white flex items-center gap-2">
              YORKSHIRE WATER CENTRAL DATA PLATFORM
              <span className="bg-sky-500/10 border border-sky-500/20 text-sky-400 text-[9px] font-mono px-1.5 py-0.5 rounded uppercase tracking-wider font-bold">
                YW-CDP authoritative v2.4
              </span>
            </h1>
            <p className="text-xs text-slate-400 font-mono tracking-wide">
              Yorkshire Region Master Operational Telemetry Ingestion Hub • Single Source of Truth
            </p>
          </div>
        </div>

        {/* Sync Status Badge */}
        <div className="flex items-center gap-3">
          {error ? (
            <span className="text-xs text-red-400 bg-red-950/30 border border-red-500/25 px-3 py-1.5 rounded-lg flex items-center gap-1.5 font-mono">
              <ShieldAlert className="h-4 w-4 animate-bounce" /> {error}
            </span>
          ) : (
            <span className="text-xs text-emerald-400 bg-emerald-950/20 border border-emerald-500/25 px-3 py-1.5 rounded-lg flex items-center gap-1.5 font-mono">
              <RefreshCw className="h-3.5 w-3.5 animate-spin" style={{ animationDuration: "5s" }} />
              SCADA CENTRAL BROKER LINK HEALTHY (2.5s poll)
            </span>
          )}
          
          <div className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-[11px] font-mono text-slate-400">
            SIM: <span className="text-amber-400 font-bold uppercase">{simulationMode}</span>
          </div>
        </div>
      </header>

      {/* Main Stats HUD Ribbon - Bento Grid items */}
      <section className="relative z-10 px-6 py-4 grid grid-cols-2 md:grid-cols-6 gap-3.5 font-mono text-xs">
        
        <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-3 flex flex-col justify-between transition-all hover:border-slate-700/80 hover:bg-slate-900/80 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/5 rounded-full blur-xl group-hover:bg-emerald-500/10 transition-all duration-300"></div>
          <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Water Available</span>
          <span className="text-xl font-black text-emerald-400 block mt-1">98.7%</span>
          <span className="text-[10px] text-slate-400 mt-1">Treated reserves safe</span>
        </div>

        <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-3 flex flex-col justify-between transition-all hover:border-slate-700/80 hover:bg-slate-900/80 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-16 h-16 bg-red-500/5 rounded-full blur-xl group-hover:bg-red-500/10 transition-all duration-300"></div>
          <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Active Incidents</span>
          <span className={`text-xl font-black block mt-1 ${activeIncidents > 0 ? "text-rose-400" : "text-emerald-400"}`}>
            {activeIncidents}
          </span>
          <span className="text-[10px] text-slate-400 mt-1">Unresolved events</span>
        </div>

        <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-3 flex flex-col justify-between transition-all hover:border-slate-700/80 hover:bg-slate-900/80 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-16 h-16 bg-amber-500/5 rounded-full blur-xl group-hover:bg-amber-500/10 transition-all duration-300"></div>
          <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Active Leaks</span>
          <span className="text-xl font-black text-amber-400 block mt-1">
            {leaks.filter(l => l.status !== "CLOSED" && l.status !== "REPAIRED").length}
          </span>
          <span className="text-[10px] text-slate-400 mt-1">Under investigation</span>
        </div>

        <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-3 flex flex-col justify-between transition-all hover:border-slate-700/80 hover:bg-slate-900/80 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-16 h-16 bg-sky-500/5 rounded-full blur-xl group-hover:bg-sky-500/10 transition-all duration-300"></div>
          <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Reservoir Storage</span>
          <span className="text-xl font-black text-sky-400 block mt-1">
            {globalStoragePct.toFixed(1)}%
          </span>
          <span className="text-[10px] text-slate-400 mt-1">{currentVolume.toLocaleString()} ML total</span>
        </div>

        <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-3 flex flex-col justify-between transition-all hover:border-slate-700/80 hover:bg-slate-900/80 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-16 h-16 bg-orange-500/5 rounded-full blur-xl group-hover:bg-orange-500/10 transition-all duration-300"></div>
          <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Customer Impact</span>
          <span className={`text-xl font-black block mt-1 ${affectedCustomers > 0 ? "text-orange-400" : "text-emerald-400"}`}>
            {affectedCustomers.toLocaleString()}
          </span>
          <span className="text-[10px] text-slate-400 mt-1">Properties offline</span>
        </div>

        <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-3 flex flex-col justify-between transition-all hover:border-slate-700/80 hover:bg-slate-900/80 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-16 h-16 bg-slate-500/5 rounded-full blur-xl group-hover:bg-slate-500/10 transition-all duration-300"></div>
          <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Water Demand</span>
          <span className="text-xl font-black text-white block mt-1">
            {totalDemand.toFixed(1)} MLD
          </span>
          <span className="text-[10px] text-slate-400 mt-1">DMA current delivery</span>
        </div>

      </section>

      {/* Main Workspace Layout (Two-column layout: Main Content + Sidebar Controller) */}
      <div className="relative z-10 flex-1 flex flex-col xl:flex-row overflow-hidden">
        
        {/* Main Operational Views Content Area */}
        <main className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Dashboard Navigation Tabs - Bento pill style */}
          <div className="flex flex-wrap gap-2 border-b border-slate-850 pb-4 mb-4">
            <button
              onClick={() => setActiveTab("map")}
              className={`px-3.5 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                activeTab === "map" ? "bg-sky-600/15 border-sky-500 text-sky-400 shadow-sm shadow-sky-950/50" : "bg-slate-900/60 border-slate-800 hover:bg-slate-850 text-slate-400"
              }`}
            >
              GIS DIGITAL TWIN
            </button>
            <button
              onClick={() => setActiveTab("telemetry")}
              className={`px-3.5 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                activeTab === "telemetry" ? "bg-sky-600/15 border-sky-500 text-sky-400 shadow-sm shadow-sky-950/50" : "bg-slate-900/60 border-slate-800 hover:bg-slate-850 text-slate-400"
              }`}
            >
              SCADA TELEMETRY
            </button>
            <button
              onClick={() => setActiveTab("reservoirs")}
              className={`px-3.5 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                activeTab === "reservoirs" ? "bg-sky-600/15 border-sky-500 text-sky-400 shadow-sm shadow-sky-950/50" : "bg-slate-900/60 border-slate-800 hover:bg-slate-850 text-slate-400"
              }`}
            >
              CATCHMENTS & WTW
            </button>
            <button
              onClick={() => setActiveTab("leakage")}
              className={`px-3.5 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                activeTab === "leakage" ? "bg-sky-600/15 border-sky-500 text-sky-400 shadow-sm shadow-sky-950/50" : "bg-slate-900/60 border-slate-800 hover:bg-slate-850 text-slate-400"
              }`}
            >
              DMA LEAKAGE BALANCE
            </button>
            <button
              onClick={() => setActiveTab("lab")}
              className={`px-3.5 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                activeTab === "lab" ? "bg-sky-600/15 border-sky-500 text-sky-400 shadow-sm shadow-sky-950/50" : "bg-slate-900/60 border-slate-800 hover:bg-slate-850 text-slate-400"
              }`}
            >
              LIMS WATER SAFETY
            </button>
            <button
              onClick={() => setActiveTab("incidents")}
              className={`px-3.5 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                activeTab === "incidents" ? "bg-sky-600/15 border-sky-500 text-sky-400 shadow-sm shadow-sky-950/50" : "bg-slate-900/60 border-slate-800 hover:bg-slate-850 text-slate-400"
              }`}
            >
              INCIDENT OPS
            </button>
            <button
              onClick={() => setActiveTab("assets")}
              className={`px-3.5 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                activeTab === "assets" ? "bg-sky-600/15 border-sky-500 text-sky-400 shadow-sm shadow-sky-950/50" : "bg-slate-900/60 border-slate-800 hover:bg-slate-850 text-slate-400"
              }`}
            >
              ASSET REGISTRY & RISK
            </button>
            <button
              onClick={() => setActiveTab("energy")}
              className={`px-3.5 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                activeTab === "energy" ? "bg-sky-600/15 border-sky-500 text-sky-400 shadow-sm shadow-sky-950/50" : "bg-slate-900/60 border-slate-800 hover:bg-slate-850 text-slate-400"
              }`}
            >
              ENERGY INTENSITY
            </button>
            <button
              onClick={() => setActiveTab("system")}
              className={`px-3.5 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                activeTab === "system" ? "bg-sky-600/15 border-sky-500 text-sky-400 shadow-sm shadow-sky-950/50" : "bg-slate-900/60 border-slate-800 hover:bg-slate-850 text-slate-400"
              }`}
            >
              SYSTEM INTEGRATION
            </button>
            <button
              onClick={() => setActiveTab("docs")}
              className={`px-3.5 py-2 text-xs font-bold rounded-lg border transition-all flex items-center gap-1 cursor-pointer ${
                activeTab === "docs" ? "bg-sky-600/15 border-sky-500 text-sky-400 shadow-sm shadow-sky-950/50" : "bg-slate-900/60 border-slate-800 hover:bg-slate-850 text-slate-400"
              }`}
            >
              <BookOpen className="h-3 w-3" /> TECHNICAL DOCS
            </button>
          </div>

          {/* Loading Indicator */}
          {loading && (
            <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-12 text-center text-slate-400 font-mono flex flex-col items-center justify-center gap-3">
              <RefreshCw className="h-8 w-8 animate-spin text-sky-400" />
              <span>SYNCHRONISING YW-CDP TELEMETRY INDEX MASTER...</span>
            </div>
          )}

          {/* Main Tab Render Switch */}
          {!loading && (
            <div className="space-y-6">
              {activeTab === "map" && (
                <NetworkMap
                  reservoirs={reservoirs}
                  treatmentWorks={treatmentWorks}
                  dmas={dmas}
                  pipes={pipes}
                  leaks={leaks}
                  incidents={incidents}
                  selectedAssetId={selectedAsset ? selectedAsset.id : null}
                  onSelectAsset={setSelectedAsset}
                  onTriggerSimBurst={() => handleSimulate("PIPE_BURST")}
                />
              )}

              {activeTab === "telemetry" && (
                <TelemetryView telemetry={telemetry} />
              )}

              {activeTab === "reservoirs" && (
                <ReservoirView reservoirs={reservoirs} treatmentWorks={treatmentWorks} />
              )}

              {activeTab === "leakage" && (
                <LeakageView dmas={dmas} leaks={leaks} onTriggerSimBurst={() => handleSimulate("PIPE_BURST")} onSelectAsset={(asset) => { setSelectedAsset(asset); setActiveTab("map"); }} />
              )}

              {activeTab === "lab" && (
                <LabView samples={laboratory} onAddSample={handleAddSample} />
              )}

              {activeTab === "incidents" && (
                <IncidentView incidents={incidents} workOrders={workOrders} onAddIncident={handleAddIncident} onUpdateWorkOrder={handleUpdateWorkOrder} />
              )}

              {activeTab === "assets" && (
                <AssetView pipes={pipes} reservoirs={reservoirs} treatmentWorks={treatmentWorks} />
              )}

              {activeTab === "energy" && (
                <EnergyView energyMeters={energyMeters} />
              )}

              {activeTab === "system" && (
                <SystemView pipelines={pipelines} auditLogs={auditLogs} />
              )}

              {activeTab === "docs" && (
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm space-y-6 text-sm text-slate-300 leading-relaxed font-sans" id="docs-tab">
                  <h3 className="text-lg font-black text-white border-b border-slate-800 pb-2">TECHNICAL ARCHITECTURE SPECIFICATION</h3>
                  
                  <div className="space-y-4">
                    <p>
                      The **YW-CDP** acts as the central master data ingestion bus and distributed database abstraction layer for the entirety of Yorkshire's water assets. It interfaces legacy SCADA loops, laboratory LIMS samples, spatial GIS metadata databases, and customer records under a unified schema.
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                      <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
                        <h4 className="font-bold text-sky-400 mb-2 uppercase">1. Distributed System Stack</h4>
                        <ul className="space-y-1.5 text-slate-400">
                          <li>• <strong className="text-white">Authoritative Records:</strong> PostgreSQL (PostGIS geospatial bindings)</li>
                          <li>• <strong className="text-white">Time-Series Streams:</strong> TimescaleDB (hypertable partitioned log)</li>
                          <li>• <strong className="text-white">Caching Layer:</strong> Redis Cluster (real-time sub-millisecond keys)</li>
                          <li>• <strong className="text-white">Event Message Stream:</strong> Redpanda (Kafka-compliant broker)</li>
                        </ul>
                      </div>

                      <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
                        <h4 className="font-bold text-sky-400 mb-2 uppercase">2. Spatial Coordinate System</h4>
                        <p className="text-slate-400 leading-relaxed">
                          All spatial telemetry assets conform to British National Grid coordinates (Easting/Northing EPSG:27700) transformed dynamically to WSG84 (EPSG:4326) for browser Canvas renderers. Topology trees calculate downstream property boundaries automatically.
                        </p>
                      </div>
                    </div>

                    <h4 className="font-bold text-white uppercase mt-4">Calculations & Equations Applied</h4>
                    <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 font-mono text-xs text-slate-400 space-y-2.5">
                      <div>
                        <strong className="text-white">IWA Water Balance Formula:</strong>
                        <div className="text-sky-300 mt-1">System Input Volume (SIV) = Authorized Consumption (AC) + Water Losses (WL)</div>
                      </div>
                      <div>
                        <strong className="text-white">Minimum Night Flow (MNF) Analysis:</strong>
                        <div className="text-sky-300 mt-1">Legitimate Night Use = Connections * 0.0003 LPS. Unexplained loss = MNF - Legitimate Night Use.</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

        </main>

        {/* Dynamic Sidebar Control Deck */}
        <aside className="w-full xl:w-96 bg-slate-950/20 xl:border-l border-slate-800 p-6 space-y-6 overflow-y-auto relative z-10">
          
          {/* UPRN Property Master Lookup Search - Bento Card */}
          <div className="space-y-4 bg-slate-900/60 border border-slate-800/80 rounded-xl p-5 shadow-sm">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 font-mono">
              <Search className="h-4 w-4 text-sky-400" />
              UPRN Property Master Query
            </h4>
            
            <form onSubmit={handleUprnSearch} className="flex gap-1.5 text-xs font-mono">
              <input
                type="text"
                placeholder="Enter UPRN or Postcode..."
                value={uprnSearch}
                onChange={e => setUprnSearch(e.target.value)}
                className="flex-1 bg-slate-950 border border-slate-800/80 p-2.5 rounded-lg text-slate-200 focus:outline-none focus:border-sky-500 font-mono text-xs"
              />
              <button type="submit" className="bg-sky-600 hover:bg-sky-500 text-white font-bold px-3.5 py-2.5 rounded-lg text-xs cursor-pointer transition-colors">
                Search
              </button>
            </form>

            {searchedProperty ? (
              <div className="bg-slate-950/80 p-3.5 rounded-lg border border-slate-800 text-[11px] font-mono space-y-1.5 text-slate-300 animate-fadeIn">
                <div className="font-bold text-emerald-400 flex items-center gap-1">● Record found!</div>
                <div>UPRN: {searchedProperty.uprn}</div>
                <div className="text-slate-400 mt-0.5">{searchedProperty.address}</div>
                <div>Classification: {searchedProperty.type}</div>
                <div>DMA Bound: <span className="text-sky-300">{searchedProperty.dmaId}</span></div>
                {searchedCustomer && (
                  <div className="border-t border-slate-800/80 mt-2 pt-2">
                    <div className="text-slate-500 text-[9px] uppercase font-bold tracking-wider">Billing Account Master</div>
                    <div className="text-white font-bold">{searchedCustomer.name}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">Account status: {searchedCustomer.status}</div>
                  </div>
                )}
              </div>
            ) : uprnSearch && (
              <div className="text-[10px] text-slate-500 font-mono italic">
                * No corresponding address matched in Yorkshire database UPRN registry. (Try HG1 5QN)
              </div>
            )}
          </div>

          {/* Core Simulator Controls - Bento Card */}
          <div className="space-y-4 bg-slate-900/60 border border-slate-800/80 rounded-xl p-5 shadow-sm">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 font-mono">
              <Sliders className="h-4 w-4 text-amber-500" />
              Operational Simulator Deck
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed font-sans">
              Inject catchment crises or weather deviations to check cascading topological pressure drops & water safety compliance alarms.
            </p>

            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
              <button
                onClick={() => handleSimulate("NORMAL")}
                className={`py-2.5 px-2.5 rounded-lg border text-left transition-all cursor-pointer ${
                  simulationMode === "NORMAL" ? "bg-emerald-950/50 border-emerald-500 text-emerald-400 font-bold shadow-sm shadow-emerald-950" : "bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-850 hover:border-slate-700"
                }`}
              >
                ● NORMAL LOOP
              </button>
              <button
                onClick={() => handleSimulate("HEATWAVE")}
                className={`py-2.5 px-2.5 rounded-lg border text-left transition-all cursor-pointer ${
                  simulationMode === "HEATWAVE" ? "bg-amber-950/50 border-amber-500 text-amber-400 font-bold animate-pulse shadow-sm shadow-amber-950" : "bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-850 hover:border-slate-700"
                }`}
              >
                ● HEATWAVE
              </button>
              <button
                onClick={() => handleSimulate("HEAVY_STORM")}
                className={`py-2.5 px-2.5 rounded-lg border text-left transition-all cursor-pointer ${
                  simulationMode === "HEAVY_STORM" ? "bg-blue-950/50 border-blue-500 text-blue-400 font-bold animate-pulse shadow-sm shadow-blue-950" : "bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-850 hover:border-slate-700"
                }`}
              >
                ● STORM WAVE
              </button>
              <button
                onClick={() => handleSimulate("PIPE_BURST")}
                className={`py-2.5 px-2.5 rounded-lg border text-left transition-all cursor-pointer ${
                  simulationMode === "PIPE_BURST" ? "bg-red-950/50 border-red-500 text-red-400 font-bold animate-pulse shadow-sm shadow-red-950" : "bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-850 hover:border-slate-700"
                }`}
              >
                ● PIPE BURST
              </button>
              <button
                onClick={() => handleSimulate("TELEMETRY_FAULT")}
                className={`py-2.5 px-2.5 rounded-lg border text-left transition-all cursor-pointer ${
                  simulationMode === "TELEMETRY_FAULT" ? "bg-purple-950/50 border-purple-500 text-purple-400 font-bold animate-pulse shadow-sm shadow-purple-950" : "bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-850 hover:border-slate-700"
                }`}
              >
                ● SCADA FAULT
              </button>
              <button
                onClick={() => handleSimulate("POWER_OUTAGE")}
                className={`py-2.5 px-2.5 rounded-lg border text-left transition-all cursor-pointer ${
                  simulationMode === "POWER_OUTAGE" ? "bg-rose-950/50 border-rose-500 text-rose-400 font-bold animate-pulse shadow-sm shadow-rose-950" : "bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-850 hover:border-slate-700"
                }`}
              >
                ● POWER CRASH
              </button>
            </div>
          </div>

          {/* SCADA Remote Overrides Controller - Bento Card */}
          <div className="space-y-4 bg-slate-900/60 border border-slate-800/80 rounded-xl p-5 shadow-sm">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 font-mono">
              <Radio className="h-4 w-4 text-sky-400" />
              SCADA Digital Valve Overrides
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed font-sans">
              Transmit digital commands down to micro-controllers to isolate district sub-mains or close trunk bypass valves.
            </p>

            <form onSubmit={handleValveOverrideSubmit} className="space-y-4 text-xs font-mono">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-slate-500 mb-1">VALVE CODENAME</label>
                  <select
                    value={valveId}
                    onChange={e => setValveId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800/80 p-2 rounded text-slate-200 focus:outline-none focus:border-sky-500 font-mono text-xs"
                  >
                    <option value="VLV-DMA-042">VLV-DMA-042 (Leeds)</option>
                    <option value="VLV-DMA-101">VLV-DMA-101 (Sheffield)</option>
                    <option value="VLV-RAW-008">VLV-RAW-008 (Eccup Inlet)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-slate-500 mb-1">ACTUATION</label>
                  <select
                    value={valveAction}
                    onChange={e => setValveAction(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800/80 p-2 rounded text-slate-200 focus:outline-none focus:border-sky-500 font-mono text-xs"
                  >
                    <option value="CLOSE">CLOSE (0%)</option>
                    <option value="OPEN">OPEN (100%)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-slate-500 mb-1">REGULATORY COMPLIANCE REASON</label>
                <input
                  type="text"
                  value={valveReason}
                  onChange={e => setValveReason(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800/80 p-2 rounded-lg text-slate-200 font-sans focus:outline-none focus:border-sky-500 text-xs"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full bg-sky-600 hover:bg-sky-500 text-white font-bold py-2.5 rounded-lg transition-all uppercase text-[11px] cursor-pointer"
              >
                TRANSMIT COMMAND
              </button>

              {valveFeedback && (
                <div className="p-2.5 bg-slate-950/80 text-sky-400 border border-sky-500/30 rounded-lg font-mono text-[10px] leading-relaxed text-center">
                  {valveFeedback}
                </div>
              )}
            </form>
          </div>

        </aside>

      </div>
    </div>
  );
}
