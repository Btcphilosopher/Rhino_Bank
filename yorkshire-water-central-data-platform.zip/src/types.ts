/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Customer {
  id: string;
  accountId: string;
  name: string;
  email: string;
  phone: string;
  commsPreference: "EMAIL" | "SMS" | "POST";
  type: "RESIDENTIAL" | "COMMERCIAL" | "INDUSTRIAL";
  vulnerabilityFlag: boolean;
  status: "ACTIVE" | "PENDING" | "CLOSED";
  createdDate: string;
  updatedDate: string;
}

export interface Property {
  id: string;
  uprn: string;
  address: string;
  postcode: string;
  latitude: number;
  longitude: number;
  type: "DETACHED" | "SEMI_DETACHED" | "TERRACED" | "APARTMENT" | "COMMERCIAL";
  occupancy: number;
  meterId: string | null;
  sewerConnected: boolean;
  waterZone: string;
  dmaId: string;
  pressureZone: string;
  accountId: string;
}

export interface Meter {
  id: string;
  propertyId: string | null;
  type: "SMART" | "MANUAL";
  manufacturer: string;
  installationDate: string;
  batteryStatus: number; // percentage
  commStatus: "ONLINE" | "OFFLINE" | "TAMPER";
  lastReading: number; // m3
  lastReadingTime: string;
}

export interface Reservoir {
  id: string;
  name: string;
  location: string;
  catchmentName: string;
  capacityML: number; // MegaLitres
  currentVolumeML: number;
  currentLevelM: number; // Metres depth
  percentageFull: number;
  inflowMLD: number; // ML / day
  outflowMLD: number;
  rainfallMM: number;
  damType: string;
  envReleaseMLD: number;
  abstractionMLD: number;
  waterQualityStatus: "EXCELLENT" | "GOOD" | "FAIR" | "POOR";
  telemetryStatus: "ONLINE" | "DEGRADED" | "OFFLINE";
  historicalLevels: { timestamp: string; level: number }[];
}

export interface TreatmentWorks {
  id: string;
  name: string;
  status: "OPERATIONAL" | "MAINTENANCE" | "SHUTDOWN";
  capacityMLD: number;
  throughputMLD: number;
  energyConsumptionKWh: number;
  chemicalUsageKg: {
    chlorine: number;
    coagulant: number;
    fluoride: number;
  };
  stages: {
    screening: "PASS" | "WARNING" | "FAIL";
    coagulation: "PASS" | "WARNING" | "FAIL";
    sedimentation: "PASS" | "WARNING" | "FAIL";
    filtration: "PASS" | "WARNING" | "FAIL";
    disinfection: "PASS" | "WARNING" | "FAIL";
  };
  turbidityNTU: number;
  phValue: number;
  chlorineResidualPPM: number;
}

export interface LaboratorySample {
  id: string;
  samplingPoint: string;
  sampleDate: string;
  collectedBy: string;
  parameter: string;
  result: number;
  unit: string;
  detectionLimit: number;
  method: string;
  passed: boolean;
  thresholdValue: number;
  chainOfCustody: string;
}

export interface DMA {
  id: string;
  name: string;
  region: string;
  pressureZone: string;
  inputMeterIds: string[];
  outputMeterIds: string[];
  connections: number;
  measuredInflowMLD: number;
  estimatedConsumptionMLD: number;
  minimumNightFlowLPS: number; // Litres per second
  leakageEstimateMLD: number;
  avgPressurePSI: number;
  waterBalance: {
    input: number;
    consumption: number;
    leakage: number;
    otherLosses: number;
  };
}

export interface Leak {
  id: string;
  dmaId: string;
  location: string;
  latitude: number;
  longitude: number;
  detectionMethod: "DMA_ANALYSIS" | "SMART_METER" | "CUSTOMER_REPORT" | "ACOUSTIC_SENSOR";
  detectionDate: string;
  reportedDate: string;
  estimatedFlowLPS: number;
  actualFlowLPS: number;
  pipeId: string;
  status: "SUSPECTED" | "CONFIRMED" | "SCHEDULED" | "IN_REPAIR" | "REPAIRED" | "CLOSED";
  repairDate: string | null;
  repairCostGBP: number | null;
  waterSavedML: number | null;
}

export interface Pipe {
  id: string;
  startNode: string;
  endNode: string;
  lengthM: number;
  diameterMM: number;
  material: "DI" | "PE" | "PVC" | "CI" | "STEEL"; // Ductile Iron, Polyethylene, CI, etc.
  installationYear: number;
  pressureZone: string;
  dmaId: string;
  condition: "EXCELLENT" | "GOOD" | "FAIR" | "POOR";
  failureHistoryCount: number;
}

export interface Incident {
  id: string;
  type: "BURST_MAIN" | "LEAK" | "LOW_PRESSURE" | "NO_WATER" | "WATER_QUALITY" | "SEWER_FLOOD" | "POLLUTION" | "POWER_OUTAGE";
  severity: 1 | 2 | 3 | 4; // 1: Minor, 2: Operational, 3: Major, 4: Critical
  location: string;
  latitude: number;
  longitude: number;
  startTime: string;
  detectedTime: string;
  owner: string;
  status: "INVESTIGATING" | "CONTAINED" | "REPAIRING" | "RESOLVED" | "CLOSED";
  affectedAssets: string[];
  affectedPropertiesCount: number;
  affectedCustomersCount: number;
  estimatedRestoration: string | null;
  actualRestoration: string | null;
  timeline: { timestamp: string; update: string }[];
}

export interface WorkOrder {
  id: string;
  incidentId: string | null;
  assetId: string;
  assignedEngineer: string;
  priority: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  location: string;
  createdTime: string;
  scheduledTime: string | null;
  startedTime: string | null;
  completedTime: string | null;
  materialsUsed: string[];
  labourHours: number | null;
  costGBP: number | null;
  notes: string;
  status: "CREATED" | "SCHEDULED" | "IN_PROGRESS" | "COMPLETED" | "CANCELLED";
}

export interface AuditLogEntry {
  id: string;
  user: string;
  timestamp: string;
  action: string;
  objectType: string;
  objectId: string;
  oldValue: string;
  newValue: string;
  reason: string;
  source: string;
}

export interface PipelineStatus {
  name: string;
  status: "HEALTHY" | "WARNING" | "CRITICAL";
  lastSync: string;
  recordCount: number;
  errorCount: number;
  qualityScore: number; // percentage
}

export interface EnergyMeter {
  id: string;
  siteName: string;
  type: "WATER_TREATMENT" | "PUMPING" | "WASTEWATER" | "OFFICE";
  kwhToday: number;
  costGBP: number;
  tariffName: string;
  carbonKg: number;
  renewableOffsetKWh: number;
  renewableSource: "SOLAR" | "WIND" | "CHP" | "HYDRO" | "NONE";
}

export interface TelemetryReading {
  timestamp: string;
  sensorId: string;
  value: number;
  qualityCode: "VALID" | "SUSPECT" | "MISSING" | "ESTIMATED" | "OUT_OF_RANGE";
  source: string;
  ingestionTime: string;
}
