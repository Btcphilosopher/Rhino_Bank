/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { LaboratorySample } from "../types";
import { Beaker, ShieldCheck, ShieldAlert, CheckCircle2, FlaskConical, Plus } from "lucide-react";

interface LabViewProps {
  samples: LaboratorySample[];
  onAddSample: (sample: { samplingPoint: string; parameter: string; result: number; unit: string; thresholdValue: number; collectedBy: string }) => void;
}

export const LabView: React.FC<LabViewProps> = ({ samples, onAddSample }) => {
  const [samplingPoint, setSamplingPoint] = useState("Headingley WTW Final Water Tank");
  const [parameter, setParameter] = useState("Turbidity");
  const [result, setResult] = useState("");
  const [unit, setUnit] = useState("NTU");
  const [threshold, setThreshold] = useState("1.0");
  const [collectedBy, setCollectedBy] = useState("Tom Wood (Quality Engineer)");

  const [formSuccess, setFormSuccess] = useState(false);

  // Pre-configured regulatory threshold template
  const handleParameterChange = (param: string) => {
    setParameter(param);
    if (param === "Turbidity") {
      setUnit("NTU");
      setThreshold("1.0");
    } else if (param === "Chlorine Residual") {
      setUnit("mg/L");
      setThreshold("0.5");
    } else if (param === "pH Value") {
      setUnit("pH");
      setThreshold("9.5");
    } else if (param === "Iron Content") {
      setUnit("μg/L");
      setThreshold("200.0");
    } else if (param === "Ammonia") {
      setUnit("mg/L");
      setThreshold("3.0");
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!result || isNaN(Number(result))) return;

    onAddSample({
      samplingPoint,
      parameter,
      result: Number(result),
      unit,
      thresholdValue: Number(threshold),
      collectedBy
    });

    setResult("");
    setFormSuccess(true);
    setTimeout(() => setFormSuccess(false), 3000);
  };

  return (
    <div className="space-y-6" id="lab-view-root">
      
      {/* Regulatory Standards Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* UK Water Regulation Standards table */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 lg:col-span-2 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <Beaker className="h-4 w-4 text-sky-400" />
            Configurable DWI Regulatory Compliance Limits
          </h3>
          <p className="text-xs text-slate-400 mb-4">
            Under UK Drinking Water Inspectorate (DWI) guidelines, the following standard parametric limits apply. Laboratory entries with results exceeding thresholds generate critical network control alarms.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs font-mono">
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block text-[10px]">TURBIDITY</span>
              <span className="text-white font-bold text-sm block mt-0.5">&lt; 1.0 NTU</span>
              <span className="text-slate-400 text-[9px]">At Treatment Works</span>
            </div>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block text-[10px]">CHLORINE RESIDUAL</span>
              <span className="text-white font-bold text-sm block mt-0.5">0.2 - 0.5 mg/L</span>
              <span className="text-slate-400 text-[9px]">Residual Protection Range</span>
            </div>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block text-[10px]">pH HYDROGEN ION</span>
              <span className="text-white font-bold text-sm block mt-0.5">6.5 - 9.5 pH</span>
              <span className="text-slate-400 text-[9px]">Alkalinity balance index</span>
            </div>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block text-[10px]">IRON CONTENT</span>
              <span className="text-white font-bold text-sm block mt-0.5">&lt; 200 μg/L</span>
              <span className="text-slate-400 text-[9px]">Sewer Mains corrosion max</span>
            </div>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block text-[10px]">MICROBIOLOGY (E.COLI)</span>
              <span className="text-white font-bold text-sm block mt-0.5">0 / 100 mL</span>
              <span className="text-slate-400 text-[9px]">Absolute zero tolerance</span>
            </div>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block text-[10px]">AMMONIA (AS N)</span>
              <span className="text-white font-bold text-sm block mt-0.5">&lt; 0.5 mg/L</span>
              <span className="text-slate-400 text-[9px]">Effluent release max</span>
            </div>
          </div>
        </div>

        {/* Lab Sample Intake Form */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-1">
            <FlaskConical className="h-4 w-4 text-emerald-400" />
            LIMS Registration Terminal
          </h4>

          <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-slate-400 font-mono mb-1 font-bold">SAMPLING POINT</label>
              <select
                value={samplingPoint}
                onChange={e => setSamplingPoint(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded focus:border-emerald-500 font-mono"
              >
                <option value="Headingley WTW Final Water Tank">Headingley WTW Final Tank</option>
                <option value="Keldgate WTW Supply Main">Keldgate WTW Main</option>
                <option value="Eccup Raw Water Intake">Eccup Raw Intake</option>
                <option value="Blackburn Meadows Effluent discharge">Blackburn Meadows Effluent</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-400 font-mono mb-1 font-bold">PARAMETER</label>
                <select
                  value={parameter}
                  onChange={e => handleParameterChange(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded focus:border-emerald-500 font-mono"
                >
                  <option value="Turbidity">Turbidity</option>
                  <option value="Chlorine Residual">Chlorine</option>
                  <option value="pH Value">pH Value</option>
                  <option value="Iron Content">Iron Content</option>
                  <option value="Ammonia">Ammonia</option>
                </select>
              </div>
              <div>
                <label className="block text-slate-400 font-mono mb-1 font-bold">MEASURED RESULT</label>
                <input
                  type="text"
                  placeholder="e.g. 0.04"
                  value={result}
                  onChange={e => setResult(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded focus:border-emerald-500 font-mono text-sm font-bold"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-slate-500">
              <div>UNIT: <span className="text-slate-300 font-bold">{unit}</span></div>
              <div>THRESHOLD LIMIT: <span className="text-slate-300 font-bold">{threshold} {unit}</span></div>
            </div>

            <div>
              <label className="block text-slate-400 font-mono mb-1 font-bold">COLLECTING AUDITOR</label>
              <input
                type="text"
                value={collectedBy}
                onChange={e => setCollectedBy(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded focus:border-emerald-500 font-mono"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 rounded transition-all flex items-center justify-center gap-1 font-mono uppercase text-xs"
            >
              <Plus className="h-4 w-4" />
              Ingest Lab Result
            </button>

            {formSuccess && (
              <div className="bg-emerald-950 text-emerald-400 border border-emerald-500 p-2 rounded font-mono text-center flex items-center justify-center gap-1">
                <CheckCircle2 className="h-4 w-4" /> Certified & synchronised!
              </div>
            )}
          </form>
        </div>
      </div>

      {/* Laboratory Sampling Logs ledger */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <h4 className="font-semibold text-slate-200 mb-4 font-mono uppercase">Water Safety Laboratory (LIMS) Sample ledger</h4>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="p-3">SAMPLE ID</th>
                <th className="p-3">SAMPLING POINT / STATION</th>
                <th className="p-3">TESTED PARAMETER</th>
                <th className="p-3">ANALYSIS RESULT</th>
                <th className="p-3">REGULATORY PASS / LIMIT</th>
                <th className="p-3">CHAIN OF CUSTODY VERIFICATION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {samples.map((sample, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-sky-400">{sample.id}</td>
                  <td className="p-3 text-slate-300">
                    <div>{sample.samplingPoint}</div>
                    <div className="text-[10px] text-slate-500">{new Date(sample.sampleDate).toLocaleTimeString()}</div>
                  </td>
                  <td className="p-3 text-slate-200 font-bold">{sample.parameter}</td>
                  <td className="p-3">
                    <span className={`text-sm font-bold ${sample.passed ? "text-white" : "text-red-400"}`}>
                      {sample.result.toFixed(2)} {sample.unit}
                    </span>
                  </td>
                  <td className="p-3">
                    {sample.passed ? (
                      <span className="text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-2 py-0.5 rounded font-bold flex items-center gap-1 max-w-fit">
                        <ShieldCheck className="h-3 w-3" /> PASS (&lt;{sample.thresholdValue})
                      </span>
                    ) : (
                      <span className="text-red-400 bg-red-950/40 border border-red-500/30 px-2 py-0.5 rounded font-bold flex items-center gap-1 max-w-fit animate-pulse">
                        <ShieldAlert className="h-3 w-3" /> EXCEEDANCE (&gt;{sample.thresholdValue})
                      </span>
                    )}
                  </td>
                  <td className="p-3 text-slate-500 font-sans text-[11px]">{sample.chainOfCustody}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
