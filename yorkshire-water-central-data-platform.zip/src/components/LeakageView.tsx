/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { DMA, Leak } from "../types";
import { Activity, AlertTriangle, Check, Droplets, Info } from "lucide-react";

interface LeakageViewProps {
  dmas: DMA[];
  leaks: Leak[];
  onTriggerSimBurst: () => void;
  onSelectAsset: (asset: { id: string; name: string; type: string; data: any }) => void;
}

export const LeakageView: React.FC<LeakageViewProps> = ({ dmas, leaks, onTriggerSimBurst, onSelectAsset }) => {
  const [selectedDmaId, setSelectedDmaId] = useState<string>("DMA-LEED-001");
  const selectedDma = dmas.find(d => d.id === selectedDmaId) || dmas[0];

  return (
    <div className="space-y-6" id="leakage-view-root">
      
      {/* Leakage Metrics HUD */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-sm">
          <div className="text-xs font-mono text-slate-500 uppercase">Estimated Leakage Today</div>
          <div className="text-2xl font-bold text-amber-500 mt-1 font-mono">
            {dmas.reduce((sum, d) => sum + d.leakageEstimateMLD, 0).toFixed(1)} MLD
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Sum of all District Metered Areas</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-sm">
          <div className="text-xs font-mono text-slate-500 uppercase">Active Reported Leaks</div>
          <div className="text-2xl font-bold text-red-400 mt-1 font-mono">
            {leaks.filter(l => l.status !== "CLOSED" && l.status !== "REPAIRED").length} Leaks
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Awaiting excavation / repair</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-sm">
          <div className="text-xs font-mono text-slate-500 uppercase">Avg Night Flow Rate</div>
          <div className="text-2xl font-bold text-sky-400 mt-1 font-mono">
            {(dmas.reduce((sum, d) => sum + d.minimumNightFlowLPS, 0) / dmas.length).toFixed(1)} LPS
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Network background losses</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-sm">
          <div className="text-xs font-mono text-slate-500 uppercase">Water Saved This Month</div>
          <div className="text-2xl font-bold text-emerald-400 mt-1 font-mono">
            {leaks.reduce((sum, l) => sum + (l.waterSavedML || 0), 0).toFixed(2)} ML
          </div>
          <div className="text-[10px] text-slate-400 mt-1">From concluded active repairs</div>
        </div>
      </div>

      {/* DMA Selection & Water Balance Calculations */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left column: DMA selector list */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">District Metered Areas (DMAs)</h4>
          <div className="space-y-2">
            {dmas.map(dma => {
              const leakagePct = (dma.leakageEstimateMLD / dma.measuredInflowMLD) * 100;
              const isHigh = leakagePct > 18;
              return (
                <button
                  key={dma.id}
                  onClick={() => setSelectedDmaId(dma.id)}
                  className={`w-full text-left p-3 rounded-lg border font-mono transition-all flex justify-between items-center ${
                    selectedDmaId === dma.id
                      ? "bg-emerald-950/40 border-emerald-500 text-white"
                      : "bg-slate-950 hover:bg-slate-850 border-slate-800 text-slate-300"
                  }`}
                >
                  <div>
                    <div className="font-bold text-xs">{dma.name}</div>
                    <div className="text-[10px] text-slate-500">{dma.id} • {dma.connections.toLocaleString()} Conn</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-bold">{dma.measuredInflowMLD.toFixed(1)} MLD</div>
                    <div className={`text-[9px] font-bold ${isHigh ? "text-amber-500" : "text-emerald-500"}`}>
                      {leakagePct.toFixed(1)}% Leak
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Middle/Right columns: Selected DMA Water Balance Calculator */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 lg:col-span-2 shadow-sm space-y-6">
          <div className="flex justify-between items-start border-b border-slate-800 pb-3">
            <div>
              <h4 className="font-bold text-slate-200">DMA WATER BALANCE CALCULATION</h4>
              <p className="text-xs text-slate-500">IWA standard water balance formula applied to live telemetry readings.</p>
            </div>
            <div className="text-xs bg-slate-800 text-slate-300 font-mono px-2 py-1 rounded">
              ZONE ID: {selectedDma.pressureZone}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Visual Balance Graph (Custom SVG) */}
            <div className="space-y-4">
              <h5 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">Volumetric Balance allocation</h5>
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-4">
                
                {/* Total Input */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Total System Input Volume</span>
                    <span className="text-sky-400 font-bold">{selectedDma.measuredInflowMLD} MLD</span>
                  </div>
                  <div className="w-full bg-slate-900 h-2 rounded overflow-hidden">
                    <div className="h-full bg-sky-500 w-full" />
                  </div>
                </div>

                {/* Consumption */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Authorized Consumption (Revenue)</span>
                    <span className="text-emerald-400 font-bold">{selectedDma.estimatedConsumptionMLD} MLD</span>
                  </div>
                  <div className="w-full bg-slate-900 h-2 rounded overflow-hidden">
                    <div
                      className="h-full bg-emerald-500"
                      style={{ width: `${(selectedDma.estimatedConsumptionMLD / selectedDma.measuredInflowMLD) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Real Losses / Leakage */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Real Losses (Water Leakage)</span>
                    <span className="text-amber-500 font-bold">{selectedDma.leakageEstimateMLD} MLD</span>
                  </div>
                  <div className="w-full bg-slate-900 h-2 rounded overflow-hidden">
                    <div
                      className="h-full bg-amber-500"
                      style={{ width: `${(selectedDma.leakageEstimateMLD / selectedDma.measuredInflowMLD) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Apparent Losses */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Apparent/Unmeasured Losses</span>
                    <span className="text-slate-400 font-bold">{selectedDma.waterBalance.otherLosses} MLD</span>
                  </div>
                  <div className="w-full bg-slate-900 h-2 rounded overflow-hidden">
                    <div
                      className="h-full bg-slate-500"
                      style={{ width: `${(selectedDma.waterBalance.otherLosses / selectedDma.measuredInflowMLD) * 100}%` }}
                    />
                  </div>
                </div>

              </div>
            </div>

            {/* Minimum Night Flow Calculator explanation */}
            <div className="space-y-4">
              <h5 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">Minimum Night Flow (MNF) Analysis</h5>
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3 text-xs">
                <div className="flex justify-between font-mono">
                  <span className="text-slate-400">MNF Period (02:00 - 04:00):</span>
                  <span className="text-white font-bold">{selectedDma.minimumNightFlowLPS} Litres/sec</span>
                </div>
                <div className="flex justify-between font-mono">
                  <span className="text-slate-400">Estimated Legitimate Night Demands:</span>
                  <span className="text-emerald-400 font-bold">{(selectedDma.connections * 0.0003).toFixed(2)} Litres/sec</span>
                </div>
                <div className="border-t border-slate-800 my-1 pt-1 flex justify-between font-mono font-bold text-sm">
                  <span className="text-slate-300">Unexplained Background Loss:</span>
                  <span className="text-amber-400">{(selectedDma.minimumNightFlowLPS - (selectedDma.connections * 0.0003)).toFixed(2)} LPS</span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800 flex gap-2 items-start text-[10px] text-slate-400 font-sans">
                  <Info className="h-4 w-4 text-sky-400 shrink-0" />
                  <span>
                    When MNF exceeds legacy benchmarks, acoustic logger networks trigger alarms. Click active leaks or nodes on the GIS map to check localized pins.
                  </span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Leaks Registry Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <h4 className="font-semibold text-slate-200 mb-4 font-mono uppercase">Active Leakage Investigations ledger</h4>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="p-3">LEAK ID</th>
                <th className="p-3">DMA</th>
                <th className="p-3">LOCATION</th>
                <th className="p-3">DETECTION METHOD</th>
                <th className="p-3">FLOW VALUE (LPS)</th>
                <th className="p-3">STATUS</th>
                <th className="p-3">INVESTIGATE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {leaks.map(leak => (
                <tr key={leak.id} className="hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-amber-400">{leak.id}</td>
                  <td className="p-3 text-slate-300">{leak.dmaId}</td>
                  <td className="p-3 text-slate-300">{leak.location}</td>
                  <td className="p-3 text-slate-400 font-sans">{leak.detectionMethod.replace("_", " ")}</td>
                  <td className="p-3 text-white font-bold">{leak.estimatedFlowLPS || leak.actualFlowLPS} LPS</td>
                  <td className="p-3">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold border ${
                      leak.status === "REPAIRED" ? "bg-emerald-950/50 border-emerald-500 text-emerald-400" : "bg-amber-950/50 border-amber-500 text-amber-400"
                    }`}>
                      {leak.status}
                    </span>
                  </td>
                  <td className="p-3">
                    <button
                      onClick={() => onSelectAsset({ id: leak.id, name: `Leak ${leak.id}`, type: "LEAK", data: leak })}
                      className="text-[10px] bg-slate-800 hover:bg-slate-700 text-sky-400 px-2 py-1 rounded"
                    >
                      Locate
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
