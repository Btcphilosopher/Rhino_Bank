/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Pipe, Reservoir, TreatmentWorks } from "../types";
import { Shield, Hammer, AlertTriangle, Play, Settings } from "lucide-react";

interface AssetViewProps {
  pipes: Pipe[];
  reservoirs: Reservoir[];
  treatmentWorks: TreatmentWorks[];
}

export const AssetView: React.FC<AssetViewProps> = ({ pipes, reservoirs, treatmentWorks }) => {
  
  // Calculate aggregate stats
  const totalAssets = pipes.length + reservoirs.length + treatmentWorks.length;
  const excellentPipes = pipes.filter(p => p.condition === "EXCELLENT").length;
  const fairPipes = pipes.filter(p => p.condition === "FAIR").length;
  const poorPipes = pipes.filter(p => p.condition === "POOR").length;

  return (
    <div className="space-y-6" id="asset-view-root">
      
      {/* Risk Assessment Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Risk Score Matrix Grid (Failure Probability vs Consequence Impact) */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <Shield className="h-4 w-4 text-emerald-400" />
            Asset Criticality & Risk Matrix
          </h3>
          <p className="text-xs text-slate-400 mb-4">
            Dynamic risk matrix mapping probability of structural failure (condition/age index) against consequence of failure (customer/environmental impact).
          </p>

          {/* Matrix Design */}
          <div className="space-y-2 font-mono text-[10px]">
            {/* Rows (Probability) */}
            <div className="flex items-center gap-2">
              <span className="w-16 text-right text-slate-400">High Prob</span>
              <div className="grid grid-cols-5 gap-1.5 flex-1">
                <div className="bg-amber-950/40 border border-amber-500 text-amber-300 p-2 text-center rounded">
                  MODERATE
                </div>
                <div className="bg-orange-950/40 border border-orange-500 text-orange-300 p-2 text-center rounded">
                  HIGH
                </div>
                <div className="bg-red-950 border border-red-500 text-red-300 p-2 text-center rounded font-bold animate-pulse col-span-3">
                  CRITICAL RISK ZONE
                  <div className="text-[8px] font-normal text-slate-400 mt-0.5">Trunk Main PIP-ECCU-HEAD</div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="w-16 text-right text-slate-400">Med Prob</span>
              <div className="grid grid-cols-5 gap-1.5 flex-1">
                <div className="bg-emerald-950/40 border border-emerald-500 text-emerald-400 p-2 text-center rounded">
                  LOW
                </div>
                <div className="bg-amber-950/40 border border-amber-500 text-amber-300 p-2 text-center rounded col-span-2">
                  MODERATE RISK
                </div>
                <div className="bg-orange-950/40 border border-orange-500 text-orange-300 p-2 text-center rounded col-span-2">
                  HIGH (Grimwith Dam)
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="w-16 text-right text-slate-400">Low Prob</span>
              <div className="grid grid-cols-5 gap-1.5 flex-1">
                <div className="bg-emerald-950/30 border border-emerald-700/50 text-slate-400 p-2 text-center rounded col-span-3">
                  STABLE MINIMAL RISK
                  <div className="text-[8px] text-slate-500">Headingley WTW Final Main</div>
                </div>
                <div className="bg-emerald-950/40 border border-emerald-500 text-emerald-400 p-2 text-center rounded col-span-2">
                  LOW
                </div>
              </div>
            </div>

            {/* Column Label */}
            <div className="flex justify-between pl-20 pr-4 text-slate-500 mt-2 font-bold uppercase tracking-wider text-[8px]">
              <span>Low Impact (Customer)</span>
              <span>High Impact (Critical grid)</span>
            </div>
          </div>
        </div>

        {/* Maintenance Scheduler */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">
              <Hammer className="h-4 w-4 text-sky-400" />
              Predictive Maintenance Planners
            </h4>

            <div className="space-y-2.5 text-xs font-mono">
              <div className="border border-slate-800 p-3 rounded-lg bg-slate-950 flex justify-between items-center">
                <div>
                  <div className="font-bold text-slate-200">Headingley WTW Coagulation Chamber</div>
                  <div className="text-slate-500 mt-0.5 text-[10px]">Standard preventative inspection</div>
                </div>
                <div className="text-right">
                  <div className="text-emerald-400 font-bold">Every 90 Days</div>
                  <div className="text-[9px] text-slate-400 mt-0.5">Next: 12 Sept 2026</div>
                </div>
              </div>

              <div className="border border-slate-800 p-3 rounded-lg bg-slate-950 flex justify-between items-center">
                <div>
                  <div className="font-bold text-slate-200">Scar House Dam Structural Valve</div>
                  <div className="text-slate-500 mt-0.5 text-[10px]">Hydraulics diagnostic inspection</div>
                </div>
                <div className="text-right">
                  <div className="text-emerald-400 font-bold">Every 180 Days</div>
                  <div className="text-[9px] text-slate-400 mt-0.5">Next: 04 Nov 2026</div>
                </div>
              </div>

              <div className="border border-slate-800 p-3 rounded-lg bg-slate-950 flex justify-between items-center">
                <div>
                  <div className="font-bold text-slate-200">Esholt WwTW Secondary Clarifier</div>
                  <div className="text-slate-500 mt-0.5 text-[10px]">Predictive degradation replacement</div>
                </div>
                <div className="text-right">
                  <div className="text-orange-400 font-bold">CRITICAL SCHEDULE</div>
                  <div className="text-[9px] text-slate-400 mt-0.5">Next: 15 Aug 2026</div>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-4 text-[10px] text-slate-500 italic">
            * Failure probability integrates historical burst rate multipliers, acoustic noise curves, and concrete age parameters.
          </div>
        </div>
      </div>

      {/* Asset Registry Summary List */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <h4 className="font-semibold text-slate-200 mb-4 font-mono uppercase">Authoritative Asset Condition Registry</h4>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="p-3">ASSET ID</th>
                <th className="p-3">TYPE</th>
                <th className="p-3">INSTALL YEAR</th>
                <th className="p-3">DIAMETER / VOLUME</th>
                <th className="p-3">CONDITION INDEX</th>
                <th className="p-3">HISTORICAL OUTAGES</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {pipes.map(pipe => (
                <tr key={pipe.id} className="hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-slate-300">{pipe.id}</td>
                  <td className="p-3 text-slate-400">Distribution Trunk Pipe ({pipe.material})</td>
                  <td className="p-3 text-slate-400">{pipe.installationYear}</td>
                  <td className="p-3 text-white font-bold">{pipe.diameterMM} mm</td>
                  <td className="p-3">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold border ${
                      pipe.condition === "POOR" ? "bg-red-950 border-red-500 text-red-400" : "bg-emerald-950 border-emerald-500 text-emerald-400"
                    }`}>
                      {pipe.condition}
                    </span>
                  </td>
                  <td className="p-3 text-slate-400 font-bold">{pipe.failureHistoryCount} Burst main alarms</td>
                </tr>
              ))}
              {reservoirs.map(res => (
                <tr key={res.id} className="hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-sky-400">{res.id}</td>
                  <td className="p-3 text-sky-400">Reservoir Impounding Dam</td>
                  <td className="p-3 text-slate-400">Legacy asset</td>
                  <td className="p-3 text-white font-bold">{res.capacityML.toLocaleString()} ML Capacity</td>
                  <td className="p-3">
                    <span className="text-[10px] px-2 py-0.5 rounded font-bold border bg-emerald-950 border-emerald-500 text-emerald-400">
                      GOOD
                    </span>
                  </td>
                  <td className="p-3 text-slate-400">0 critical failures</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
