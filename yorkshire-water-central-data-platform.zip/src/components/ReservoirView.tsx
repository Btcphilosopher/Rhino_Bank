/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Reservoir, TreatmentWorks } from "../types";
import { Droplet, ArrowUpRight, ArrowDownRight, Zap, CheckCircle2, AlertTriangle, ShieldCheck } from "lucide-react";

interface ReservoirViewProps {
  reservoirs: Reservoir[];
  treatmentWorks: TreatmentWorks[];
}

export const ReservoirView: React.FC<ReservoirViewProps> = ({ reservoirs, treatmentWorks }) => {
  const getStageBadge = (status: string) => {
    switch (status) {
      case "PASS":
        return <span className="text-emerald-400 bg-emerald-950/80 border border-emerald-800 px-1.5 py-0.5 rounded text-[10px] font-bold">PASS</span>;
      case "WARNING":
        return <span className="text-amber-400 bg-amber-950/80 border border-amber-800 px-1.5 py-0.5 rounded text-[10px] font-bold">WARN</span>;
      case "FAIL":
        return <span className="text-red-400 bg-red-950/80 border border-red-800 px-1.5 py-0.5 rounded text-[10px] font-bold">FAIL</span>;
      default:
        return <span className="text-slate-400 px-1.5 py-0.5 rounded text-[10px]">{status}</span>;
    }
  };

  return (
    <div className="space-y-6" id="reservoir-view-root">
      {/* Reservoirs Grid */}
      <div>
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-1.5">
          <Droplet className="h-4 w-4 text-sky-400" />
          Authoritative Catchment & Reservoir Reserves
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reservoirs.map(res => {
            const isFull = res.percentageFull > 80;
            const isLow = res.percentageFull < 70;
            return (
              <div key={res.id} className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm hover:border-slate-700 transition-all">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h4 className="font-bold text-slate-100">{res.name}</h4>
                    <p className="text-xs text-slate-500 font-mono">{res.location}</p>
                  </div>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                    res.telemetryStatus === "ONLINE" ? "bg-emerald-950/50 border-emerald-500 text-emerald-400" : "bg-amber-950/50 border-amber-500 text-amber-400"
                  }`}>
                    {res.telemetryStatus}
                  </span>
                </div>

                {/* Reservoir Volumetric percentage meter */}
                <div className="space-y-1 mb-4">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Volumetric Reserves:</span>
                    <span className={`font-bold ${isLow ? "text-amber-400" : "text-sky-400"}`}>
                      {res.currentVolumeML.toLocaleString()} ML / {res.capacityML.toLocaleString()} ML
                    </span>
                  </div>
                  {/* Progress Bar */}
                  <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden border border-slate-800">
                    <div
                      className={`h-full rounded-full transition-all duration-1000 ${isLow ? "bg-amber-500" : "bg-sky-500"}`}
                      style={{ width: `${res.percentageFull}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Depth: {res.currentLevelM}m</span>
                    <span>{res.percentageFull}% Capacity</span>
                  </div>
                </div>

                {/* Hydraulic balance parameters */}
                <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-800 text-xs font-mono">
                  <div className="flex items-center gap-1">
                    <ArrowUpRight className="h-4 w-4 text-emerald-500" />
                    <div>
                      <div className="text-[10px] text-slate-500 uppercase">Daily Inflow</div>
                      <div className="font-bold text-slate-200">{res.inflowMLD} MLD</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <ArrowDownRight className="h-4 w-4 text-sky-500" />
                    <div>
                      <div className="text-[10px] text-slate-500 uppercase">Abstraction</div>
                      <div className="font-bold text-slate-200">{res.abstractionMLD} MLD</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Droplet className="h-4 w-4 text-slate-400" />
                    <div>
                      <div className="text-[10px] text-slate-500 uppercase">Release Compensation</div>
                      <div className="font-bold text-slate-200">{res.envReleaseMLD} MLD</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Zap className="h-4 w-4 text-amber-500" />
                    <div>
                      <div className="text-[10px] text-slate-500 uppercase">Rainfall</div>
                      <div className="font-bold text-slate-200">{res.rainfallMM} mm</div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Treatment Works & Chemical Stages */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-teal-400" />
          Clean Water Treatment Stages & Wastewater Compliance
        </h3>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {treatmentWorks.map(tw => {
            const isWastewater = tw.id.startsWith("WWTW");
            const isShutdown = tw.status === "SHUTDOWN";
            return (
              <div key={tw.id} className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start border-b border-slate-800 pb-2 mb-3">
                    <div>
                      <span className={`text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded mr-2 ${isWastewater ? "bg-slate-800 text-slate-400" : "bg-teal-950 text-teal-400"}`}>
                        {isWastewater ? "Wastewater (WwTW)" : "Clean Water (WTW)"}
                      </span>
                      <h4 className="text-sm font-bold text-slate-200 inline-block">{tw.name}</h4>
                    </div>
                    <span className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded-full ${
                      isShutdown ? "bg-red-950 text-red-400" : "bg-emerald-950 text-emerald-400"
                    }`}>
                      ● {tw.status}
                    </span>
                  </div>

                  {/* Flow KPIs */}
                  <div className="grid grid-cols-3 gap-2 text-xs font-mono bg-slate-900/60 p-2.5 rounded border border-slate-800/80 mb-4">
                    <div>
                      <div className="text-[10px] text-slate-500">OPERATIONAL CAPACITY</div>
                      <div className="font-bold text-slate-200">{tw.capacityMLD} MLD</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-500">ACTUAL THROUGHPUT</div>
                      <div className="font-bold text-white text-sm">{tw.throughputMLD} MLD</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-500">ENERGY DEMAND</div>
                      <div className="font-bold text-slate-200">{tw.energyConsumptionKWh.toLocaleString()} kWh</div>
                    </div>
                  </div>

                  {/* Chemical Treatment Multi-stages */}
                  <div className="space-y-2 mb-4">
                    <div className="text-[10px] uppercase font-bold text-slate-500">Chemical Process Multi-Barrier Stages</div>
                    <div className="grid grid-cols-5 gap-1.5 text-center font-mono text-[9px]">
                      <div className="bg-slate-900 p-1.5 rounded border border-slate-800">
                        <div className="text-slate-500 mb-1">SCREEN</div>
                        {getStageBadge(tw.stages.screening)}
                      </div>
                      <div className="bg-slate-900 p-1.5 rounded border border-slate-800">
                        <div className="text-slate-500 mb-1">COAG</div>
                        {getStageBadge(tw.stages.coagulation)}
                      </div>
                      <div className="bg-slate-900 p-1.5 rounded border border-slate-800">
                        <div className="text-slate-500 mb-1">SEDIMENT</div>
                        {getStageBadge(tw.stages.sedimentation)}
                      </div>
                      <div className="bg-slate-900 p-1.5 rounded border border-slate-800">
                        <div className="text-slate-500 mb-1">FILTER</div>
                        {getStageBadge(tw.stages.filtration)}
                      </div>
                      <div className="bg-slate-900 p-1.5 rounded border border-slate-800">
                        <div className="text-slate-500 mb-1">DISINFECT</div>
                        {getStageBadge(tw.stages.disinfection)}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Analytical Quality Parameters */}
                <div className="pt-3 border-t border-slate-800 grid grid-cols-3 gap-2 text-xs font-mono">
                  <div>
                    <span className="text-slate-500">pH Value:</span>
                    <span className="text-slate-200 font-bold ml-1.5">{tw.phValue}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">Turbidity:</span>
                    <span className="text-slate-200 font-bold ml-1.5">{tw.turbidityNTU} NTU</span>
                  </div>
                  <div>
                    <span className="text-slate-500">Chlorine Res:</span>
                    <span className="text-slate-200 font-bold ml-1.5">{tw.chlorineResidualPPM} PPM</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
