/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { TelemetryReading } from "../types";
import { Radio, AlertCircle, CheckCircle2, ShieldAlert, Cpu } from "lucide-react";

interface TelemetryViewProps {
  telemetry: TelemetryReading[];
}

export const TelemetryView: React.FC<TelemetryViewProps> = ({ telemetry }) => {
  const getQualityBadge = (code: string) => {
    switch (code) {
      case "VALID":
        return <span className="bg-emerald-950/80 border border-emerald-500 text-emerald-400 text-[10px] font-mono px-2 py-0.5 rounded flex items-center gap-1"><CheckCircle2 className="h-3 w-3" /> VALID</span>;
      case "SUSPECT":
        return <span className="bg-red-950/80 border border-red-500 text-red-400 text-[10px] font-mono px-2 py-0.5 rounded flex items-center gap-1"><ShieldAlert className="h-3 w-3 animate-pulse" /> SUSPECT</span>;
      case "ESTIMATED":
        return <span className="bg-amber-950/80 border border-amber-500 text-amber-400 text-[10px] font-mono px-2 py-0.5 rounded flex items-center gap-1"><AlertCircle className="h-3 w-3" /> ESTIMATED</span>;
      default:
        return <span className="bg-slate-800 border border-slate-700 text-slate-400 text-[10px] font-mono px-2 py-0.5 rounded">{code}</span>;
    }
  };

  return (
    <div className="space-y-6" id="telemetry-view-root">
      {/* Telemetry Architecture Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 lg:col-span-2 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
            <Radio className="h-4 w-4 text-sky-400" />
            TimescaleDB Continuous Telemetry Stream
          </h3>
          <p className="text-sm text-slate-300 leading-relaxed mb-4">
            The platform ingests over 12 million telemetry signals per day from acoustic leak pins, pressure transducers, flow meters, and smart batteries. Ingested time-series records are automatically checked against dynamic threshold boundary tables.
          </p>

          {/* Sparkline simulation blocks */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center text-xs text-slate-400 mb-2 font-mono">
                <span>SCADA_DMA-LEED_INFLOW</span>
                <span className="text-sky-400">12.4 MLD</span>
              </div>
              {/* Custom SVG Sparkline */}
              <svg className="w-full h-10" viewBox="0 0 200 40">
                <path
                  d="M 0 30 Q 20 20 40 32 T 80 18 T 120 25 T 160 12 T 200 28"
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="2"
                />
                <path
                  d="M 0 30 Q 20 20 40 32 T 80 18 T 120 25 T 160 12 T 200 28 L 200 40 L 0 40 Z"
                  fill="rgba(56, 189, 248, 0.08)"
                />
              </svg>
            </div>

            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center text-xs text-slate-400 mb-2 font-mono">
                <span>SCADA_SCAR_RES_LEVEL</span>
                <span className="text-teal-400">36.42 m</span>
              </div>
              <svg className="w-full h-10" viewBox="0 0 200 40">
                <path
                  d="M 0 15 L 40 16 L 80 14 L 120 15 L 160 13 L 200 14"
                  fill="none"
                  stroke="#2dd4bf"
                  strokeWidth="2"
                />
                <path
                  d="M 0 15 L 40 16 L 80 14 L 120 15 L 160 13 L 200 14 L 200 40 L 0 40 Z"
                  fill="rgba(45, 212, 191, 0.08)"
                />
              </svg>
            </div>
          </div>
        </div>

        {/* Dynamic Rules Engine */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">
              <Cpu className="h-4 w-4 text-emerald-400" />
              Real-Time Validation Rules
            </h4>
            <div className="space-y-3 text-xs font-mono">
              <div className="border border-slate-800 p-2.5 rounded bg-slate-950">
                <div className="font-bold text-slate-200">R01: OUT_OF_BOUNDS</div>
                <div className="text-slate-400 mt-1">If (reading &lt; min_threshold or reading &gt; max_threshold) then flag as SUSPECT.</div>
              </div>
              <div className="border border-slate-800 p-2.5 rounded bg-slate-950">
                <div className="font-bold text-slate-200">R02: RATE_OF_CHANGE</div>
                <div className="text-slate-400 mt-1">If (reading_t1 - reading_t0) &gt; 35% delta per minute, flag as SUSPECT (possible sensor drift).</div>
              </div>
              <div className="border border-slate-800 p-2.5 rounded bg-slate-950">
                <div className="font-bold text-slate-200">R03: FLATLINE_DETECT</div>
                <div className="text-slate-400 mt-1">If standard deviation of last 12 readings = 0.00, flag as ESTIMATED (sensor frozen).</div>
              </div>
            </div>
          </div>
          <div className="mt-4 text-[10px] text-slate-500 italic">
            * All data is processed using append-only time-series partitioning schema to achieve sub-millisecond querying speed.
          </div>
        </div>
      </div>

      {/* Telemetry Stream Log table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-4">
          <h4 className="font-semibold text-slate-200">AUTHORITATIVE SCADA TELEMETRY BUFFER (LATEST 15 READINGS)</h4>
          <span className="text-xs bg-slate-800 text-slate-400 px-2 py-1 rounded font-mono">TimescaleDB View: Active partition</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="p-3">INGESTION TIMESTAMP</th>
                <th className="p-3">SENSOR ID</th>
                <th className="p-3">MEASUREMENT VALUE</th>
                <th className="p-3">METRIC QUALITY</th>
                <th className="p-3">SCADA HOST / BROKER</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {telemetry.slice(0, 15).map((item, index) => (
                <tr key={index} className="hover:bg-slate-800/40">
                  <td className="p-3 text-slate-300">{new Date(item.timestamp).toLocaleTimeString()} ({new Date(item.timestamp).toLocaleDateString()})</td>
                  <td className="p-3 font-bold text-sky-400">{item.sensorId}</td>
                  <td className="p-3 font-bold text-white text-sm">{item.value.toFixed(2)}</td>
                  <td className="p-3">{getQualityBadge(item.qualityCode)}</td>
                  <td className="p-3 text-slate-500">{item.source}</td>
                </tr>
              ))}
              {telemetry.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-500 italic font-sans">
                    Ingesting telemetry signals... Waiting for TimescaleDB stream buffer.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
