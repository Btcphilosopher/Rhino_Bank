/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Reservoir, TreatmentWorks, DMA, Pipe, Leak, Incident } from "../types";
import { Layers, Droplet, AlertTriangle, Radio, Activity, HelpCircle } from "lucide-react";

interface NetworkMapProps {
  reservoirs: Reservoir[];
  treatmentWorks: TreatmentWorks[];
  dmas: DMA[];
  pipes: Pipe[];
  leaks: Leak[];
  incidents: Incident[];
  selectedAssetId: string | null;
  onSelectAsset: (asset: { id: string; name: string; type: string; data: any }) => void;
  onTriggerSimBurst: () => void;
}

export const NetworkMap: React.FC<NetworkMapProps> = ({
  reservoirs,
  treatmentWorks,
  dmas,
  pipes,
  leaks,
  incidents,
  selectedAssetId,
  onSelectAsset,
  onTriggerSimBurst
}) => {
  // Layer toggles
  const [showReservoirs, setShowReservoirs] = useState(true);
  const [showWTWs, setShowWTWs] = useState(true);
  const [showPipes, setShowPipes] = useState(true);
  const [showDMAs, setShowDMAs] = useState(true);
  const [showLeaks, setShowLeaks] = useState(true);
  const [showIncidents, setShowIncidents] = useState(true);

  // Coordinate projection from Yorkshire Lat/Lon to SVG box (800x480)
  // Yorkshire bounding box: Lat [53.3, 54.3], Lon [-2.0, -0.3]
  const projectX = (lon: number) => {
    const minLon = -2.1;
    const maxLon = -0.3;
    return 50 + ((lon - minLon) / (maxLon - minLon)) * 700;
  };

  const projectY = (lat: number) => {
    const minLat = 53.3;
    const maxLat = 54.3;
    // SVG has Y 0 at top, so subtract from height
    return 430 - ((lat - minLat) / (maxLat - minLat)) * 380;
  };

  // Node spatial coordinates helper (static anchor mappings)
  const getAssetCoords = (id: string) => {
    const res = reservoirs.find(r => r.id === id);
    if (res) {
      if (id === "RES-SCAR-001") return { x: projectX(-1.91), y: projectY(54.18) };
      if (id === "RES-GRIM-002") return { x: projectX(-1.94), y: projectY(54.06) };
      if (id === "RES-FEWS-003") return { x: projectX(-1.74), y: projectY(53.99) };
      if (id === "RES-SWIN-004") return { x: projectX(-1.72), y: projectY(53.97) };
      if (id === "RES-ECCU-005") return { x: projectX(-1.54), y: projectY(53.86) };
    }
    const tw = treatmentWorks.find(t => t.id === id);
    if (tw) {
      if (id === "WTW-HEAD-001") return { x: projectX(-1.58), y: projectY(53.82) };
      if (id === "WTW-KELD-002") return { x: projectX(-0.40), y: projectY(53.75) };
      if (id === "WWTW-ESHL-003") return { x: projectX(-1.70), y: projectY(53.83) };
      if (id === "WWTW-BLAC-004") return { x: projectX(-1.45), y: projectY(53.40) };
    }
    const dma = dmas.find(d => d.id === id);
    if (dma) {
      if (id === "DMA-LEED-001") return { x: projectX(-1.55), y: projectY(53.80) };
      if (id === "DMA-SHEF-002") return { x: projectX(-1.45), y: projectY(53.38) };
      if (id === "DMA-BRAD-003") return { x: projectX(-1.74), y: projectY(53.79) };
      if (id === "DMA-YORK-004") return { x: projectX(-1.08), y: projectY(53.96) };
      if (id === "DMA-HARR-005") return { x: projectX(-1.53), y: projectY(53.99) };
    }
    return { x: 400, y: 240 };
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 relative overflow-hidden shadow-xl" id="gis-map-container">
      {/* HUD Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4 border-b border-slate-800 pb-4">
        <div>
          <h3 className="text-lg font-semibold text-slate-100 flex items-center gap-2">
            <Layers className="h-5 w-5 text-sky-400" />
            Yorkshire GIS Digital Twin Network Map
          </h3>
          <p className="text-xs text-slate-400">
            Authoritative spatial topography with live volumetric water flows, leakage locations & active incident zones.
          </p>
        </div>

        {/* Legend / Layer Toggles */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setShowReservoirs(!showReservoirs)}
            className={`px-3 py-1.5 rounded text-xs font-medium border transition-all ${
              showReservoirs ? "bg-sky-950/80 border-sky-500 text-sky-300" : "bg-slate-800/50 border-slate-700 text-slate-500"
            }`}
          >
            Reservoirs
          </button>
          <button
            onClick={() => setShowWTWs(!showWTWs)}
            className={`px-3 py-1.5 rounded text-xs font-medium border transition-all ${
              showWTWs ? "bg-teal-950/80 border-teal-500 text-teal-300" : "bg-slate-800/50 border-slate-700 text-slate-500"
            }`}
          >
            Treatment Works
          </button>
          <button
            onClick={() => setShowPipes(!showPipes)}
            className={`px-3 py-1.5 rounded text-xs font-medium border transition-all ${
              showPipes ? "bg-blue-950/80 border-blue-500 text-blue-300" : "bg-slate-800/50 border-slate-700 text-slate-500"
            }`}
          >
            Trunk Mains
          </button>
          <button
            onClick={() => setShowDMAs(!showDMAs)}
            className={`px-3 py-1.5 rounded text-xs font-medium border transition-all ${
              showDMAs ? "bg-emerald-950/80 border-emerald-500 text-emerald-300" : "bg-slate-800/50 border-slate-700 text-slate-500"
            }`}
          >
            DMAs
          </button>
          <button
            onClick={() => setShowLeaks(!showLeaks)}
            className={`px-3 py-1.5 rounded text-xs font-medium border transition-all ${
              showLeaks ? "bg-amber-950/80 border-amber-500 text-amber-300" : "bg-slate-800/50 border-slate-700 text-slate-500"
            }`}
          >
            Leaks
          </button>
          <button
            onClick={() => setShowIncidents(!showIncidents)}
            className={`px-3 py-1.5 rounded text-xs font-medium border transition-all ${
              showIncidents ? "bg-red-950/80 border-red-500 text-red-300" : "bg-slate-800/50 border-slate-700 text-slate-500"
            }`}
          >
            Incidents
          </button>
        </div>
      </div>

      {/* SVG Canvas Map */}
      <div className="relative bg-slate-950/90 rounded-lg overflow-hidden border border-slate-800" style={{ height: "450px" }}>
        
        {/* Geographic Grid Lines */}
        <div className="absolute inset-0 grid grid-cols-6 grid-rows-4 pointer-events-none opacity-20">
          {Array.from({ length: 24 }).map((_, i) => (
            <div key={i} className="border-r border-b border-slate-700 text-[9px] text-slate-500 p-1 font-mono">
              {i % 6 === 0 ? `${(54.3 - (Math.floor(i / 6) * 0.25)).toFixed(2)}°N` : ""}
              {i < 6 ? `  ${(-2.1 + (i * 0.3)).toFixed(1)}°W` : ""}
            </div>
          ))}
        </div>

        {/* Flowing Water Flow/Pipes Layer */}
        <svg className="w-full h-full" viewBox="0 0 800 450">
          <defs>
            <marker id="arrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 1 L 10 5 L 0 9 z" fill="#0284c7" />
            </marker>
            <linearGradient id="blueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="100%" stopColor="#0284c7" />
            </linearGradient>
            <linearGradient id="redGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ef4444" />
              <stop offset="100%" stopColor="#991b1b" />
            </linearGradient>
          </defs>

          {/* Render Pipes */}
          {showPipes && pipes.map(pipe => {
            const start = getAssetCoords(pipe.startNode);
            const end = getAssetCoords(pipe.endNode);
            const isSelected = selectedAssetId === pipe.id;
            const isDamaged = pipe.condition === "POOR";
            return (
              <g key={pipe.id} className="cursor-pointer group" onClick={() => onSelectAsset({ id: pipe.id, name: `Main ${pipe.id}`, type: "PIPE", data: pipe })}>
                {/* Thick hover background */}
                <line
                  x1={start.x}
                  y1={start.y}
                  x2={end.x}
                  y2={end.y}
                  stroke="transparent"
                  strokeWidth="12"
                />
                {/* Visual Pipeline line */}
                <line
                  x1={start.x}
                  y1={start.y}
                  x2={end.x}
                  y2={end.y}
                  stroke={isDamaged ? "#f87171" : isSelected ? "#38bdf8" : "#1e3a8a"}
                  strokeWidth={isSelected ? "4" : "3"}
                  strokeDasharray={isDamaged ? "4,4" : "none"}
                  className="transition-all"
                  markerEnd="url(#arrow)"
                />
                {/* Flow motion particles on healthy high-flow lines */}
                {!isDamaged && (
                  <line
                    x1={start.x}
                    y1={start.y}
                    x2={end.x}
                    y2={end.y}
                    stroke="#60a5fa"
                    strokeWidth="1.5"
                    strokeDasharray="8, 20"
                    strokeDashoffset="2"
                    className="animate-[dash_8s_linear_infinite]"
                    style={{ strokeDasharray: "10,25", animation: "dash 4s linear infinite" }}
                  />
                )}
                <title>{`Pipe: ${pipe.id} (${pipe.material}, ${pipe.diameterMM}mm, Condition: ${pipe.condition})`}</title>
              </g>
            );
          })}

          {/* Render DMAs (Bounding Circles / Shaded Zones) */}
          {showDMAs && dmas.map(dma => {
            const coords = getAssetCoords(dma.id);
            const isSelected = selectedAssetId === dma.id;
            const size = dma.id === "DMA-LEED-001" ? 38 : 28;
            return (
              <g key={dma.id} className="cursor-pointer" onClick={() => onSelectAsset({ id: dma.id, name: dma.name, type: "DMA", data: dma })}>
                <circle
                  cx={coords.x}
                  cy={coords.y}
                  r={size}
                  fill={isSelected ? "rgba(16, 185, 129, 0.15)" : "rgba(30, 41, 59, 0.4)"}
                  stroke={isSelected ? "#10b981" : "#047857"}
                  strokeWidth="1.5"
                  strokeDasharray="4,3"
                  className="transition-all"
                />
                <text
                  x={coords.x}
                  y={coords.y - size - 4}
                  textAnchor="middle"
                  fill="#a7f3d0"
                  fontSize="9"
                  fontWeight="bold"
                  className="font-mono bg-slate-950"
                >
                  {dma.name.split(" ")[0]}
                </text>
              </g>
            );
          })}

          {/* Render Reservoirs */}
          {showReservoirs && reservoirs.map(res => {
            const coords = getAssetCoords(res.id);
            const isSelected = selectedAssetId === res.id;
            const fillPct = res.percentageFull / 100;
            // Draw a polygon or complex shape representing the reservoir lake
            return (
              <g key={res.id} className="cursor-pointer" onClick={() => onSelectAsset({ id: res.id, name: res.name, type: "RESERVOIR", data: res })}>
                {/* Outer shadow / selection glow */}
                <circle
                  cx={coords.x}
                  cy={coords.y}
                  r="18"
                  fill="none"
                  stroke={isSelected ? "#38bdf8" : "transparent"}
                  strokeWidth="2"
                  className="animate-pulse"
                />
                {/* Reservoir body */}
                <polygon
                  points={`${coords.x-12},${coords.y-4} ${coords.x+10},${coords.y-10} ${coords.x+14},${coords.y+8} ${coords.x-8},${coords.y+12}`}
                  fill={res.percentageFull < 70 ? "#0369a1" : "url(#blueGrad)"}
                  stroke="#0284c7"
                  strokeWidth="1.5"
                />
                {/* Water percentage visual */}
                <text
                  x={coords.x}
                  y={coords.y + 24}
                  textAnchor="middle"
                  fill="#e0f2fe"
                  fontSize="9"
                  fontWeight="600"
                  className="font-mono"
                >
                  {res.percentageFull}%
                </text>
                <text
                  x={coords.x}
                  y={coords.y - 14}
                  textAnchor="middle"
                  fill="#38bdf8"
                  fontSize="10"
                  fontWeight="bold"
                >
                  {res.name.replace(" Reservoir", "")}
                </text>
              </g>
            );
          })}

          {/* Render Treatment Works */}
          {showWTWs && treatmentWorks.map(tw => {
            const coords = getAssetCoords(tw.id);
            const isSelected = selectedAssetId === tw.id;
            const isWastewater = tw.id.startsWith("WWTW");
            const isDown = tw.status === "SHUTDOWN";
            return (
              <g key={tw.id} className="cursor-pointer" onClick={() => onSelectAsset({ id: tw.id, name: tw.name, type: "TREATMENT_WORKS", data: tw })}>
                {/* Hexagonal Treatment Works symbol */}
                <polygon
                  points={`${coords.x},${coords.y-12} ${coords.x+11},${coords.y-6} ${coords.x+11},${coords.y+6} ${coords.x},${coords.y+12} ${coords.x-11},${coords.y+6} ${coords.x-11},${coords.y-6}`}
                  fill={isDown ? "#7f1d1d" : isSelected ? "#0d9488" : isWastewater ? "#1e293b" : "#115e59"}
                  stroke={isDown ? "#ef4444" : isSelected ? "#2dd4bf" : isWastewater ? "#334155" : "#0d9488"}
                  strokeWidth="2"
                />
                {/* Interior icon dot */}
                <circle cx={coords.x} cy={coords.y} r="3" fill={isDown ? "#f87171" : "#ffffff"} />
                <text
                  x={coords.x}
                  y={coords.y + 22}
                  textAnchor="middle"
                  fill={isWastewater ? "#94a3b8" : "#2dd4bf"}
                  fontSize="9"
                  fontWeight="bold"
                >
                  {tw.name.split(" ")[0]} {isWastewater ? "WwTW" : "WTW"}
                </text>
              </g>
            );
          })}

          {/* Render Leaks */}
          {showLeaks && leaks.filter(l => l.status !== "CLOSED").map(leak => {
            const isRepaired = leak.status === "REPAIRED";
            if (isRepaired) return null; // Only show active leaks
            const coords = { x: projectX(leak.longitude), y: projectY(leak.latitude) };
            const isSelected = selectedAssetId === leak.id;
            return (
              <g key={leak.id} className="cursor-pointer" onClick={() => onSelectAsset({ id: leak.id, name: `Leak ${leak.id}`, type: "LEAK", data: leak })}>
                {/* Flashing sonar circle */}
                <circle cx={coords.x} cy={coords.y} r="10" fill="transparent" stroke="#f59e0b" strokeWidth="1" className="animate-ping" />
                <circle cx={coords.x} cy={coords.y} r="4" fill="#d97706" stroke={isSelected ? "#ffffff" : "none"} strokeWidth="1" />
                <title>{`Leak: ${leak.id} at ${leak.location} (${leak.estimatedFlowLPS} LPS)`}</title>
              </g>
            );
          })}

          {/* Render Incidents (Severe Bursts, Sewer flooding, pollution alerts) */}
          {showIncidents && incidents.filter(i => i.status !== "CLOSED" && i.status !== "RESOLVED").map(inc => {
            const coords = { x: projectX(inc.longitude), y: projectY(inc.latitude) };
            const isSelected = selectedAssetId === inc.id;
            return (
              <g key={inc.id} className="cursor-pointer" onClick={() => onSelectAsset({ id: inc.id, name: inc.location, type: "INCIDENT", data: inc })}>
                {/* Large Red warning flashing aura */}
                <circle cx={coords.x} cy={coords.y} r="18" fill="rgba(239, 68, 68, 0.2)" stroke="#ef4444" strokeWidth="1" className="animate-pulse" />
                {/* Triangle Icon */}
                <path
                  d={`M ${coords.x} ${coords.y - 8} L ${coords.x + 8} ${coords.y + 6} L ${coords.x - 8} ${coords.y + 6} Z`}
                  fill="#ef4444"
                  stroke={isSelected ? "#ffffff" : "#b91c1c"}
                  strokeWidth="1.5"
                />
                <text x={coords.x} y={coords.y - 12} textAnchor="middle" fill="#ef4444" fontSize="8" fontWeight="bold" className="font-mono">
                  INCIDENT {inc.severity === 4 ? "CRIT" : "MAJ"}
                </text>
              </g>
            );
          })}
        </svg>

        {/* CSS Keyframe Animation inject */}
        <style dangerouslySetInnerHTML={{__html: `
          @keyframes dash {
            to {
              stroke-dashoffset: -100;
            }
          }
        `}} />

        {/* Floating Controls panel */}
        <div className="absolute bottom-3 left-3 bg-slate-900/90 border border-slate-800 rounded-lg p-2 flex flex-col gap-1 text-[10px] text-slate-300 font-mono shadow-md backdrop-blur-sm">
          <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 bg-sky-500 rounded-sm"></span> Reservoir Volume</div>
          <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 bg-teal-600 rounded-sm"></span> Water Treatment (WTW)</div>
          <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 bg-slate-700 rounded-sm"></span> Wastewater Works (WwTW)</div>
          <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 border border-dashed border-emerald-500 rounded-sm"></span> District Meter Area (DMA)</div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 bg-red-500 rounded-full animate-ping"></span> Live Outage / Burst
          </div>
        </div>

        {/* Asset Details Inspector (embedded in map bottom right) */}
        <div className="absolute top-3 right-3 max-w-[240px] bg-slate-900/95 border border-slate-800 rounded-lg p-3 shadow-lg backdrop-blur-sm">
          <h4 className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-1 flex items-center gap-1">
            <Activity className="h-3 w-3 text-sky-400" />
            Control Room Telemetry
          </h4>
          {selectedAssetId ? (
            <div className="mt-2 text-xs text-slate-300 space-y-1.5 font-mono">
              <div className="text-[10px] text-slate-500">ASSET ID: {selectedAssetId}</div>
              {reservoirs.find(r => r.id === selectedAssetId) && (
                (() => {
                  const r = reservoirs.find(r => r.id === selectedAssetId)!;
                  return (
                    <>
                      <div className="font-bold text-sky-400">{r.name}</div>
                      <div>Level: <span className="text-white">{r.currentLevelM}m</span></div>
                      <div>Volume: <span className="text-white">{r.currentVolumeML} ML</span></div>
                      <div>Inflow: <span className="text-sky-300">{r.inflowMLD} MLD</span></div>
                      <div>Outflow: <span className="text-sky-300">{r.outflowMLD} MLD</span></div>
                    </>
                  );
                })()
              )}
              {treatmentWorks.find(t => t.id === selectedAssetId) && (
                (() => {
                  const t = treatmentWorks.find(t => t.id === selectedAssetId)!;
                  return (
                    <>
                      <div className="font-bold text-teal-400">{t.name}</div>
                      <div>Status: <span className={t.status === "OPERATIONAL" ? "text-emerald-400" : "text-red-400"}>{t.status}</span></div>
                      <div>Throughput: <span className="text-white">{t.throughputMLD} MLD</span></div>
                      <div>pH Level: <span className="text-white">{t.phValue}</span></div>
                      <div>Turbidity: <span className="text-white">{t.turbidityNTU} NTU</span></div>
                    </>
                  );
                })()
              )}
              {dmas.find(d => d.id === selectedAssetId) && (
                (() => {
                  const d = dmas.find(d => d.id === selectedAssetId)!;
                  return (
                    <>
                      <div className="font-bold text-emerald-400">{d.name}</div>
                      <div>Region: <span className="text-slate-400">{d.region}</span></div>
                      <div>Night Flow: <span className="text-white">{d.minimumNightFlowLPS} LPS</span></div>
                      <div>Leakage MLD: <span className="text-amber-400">{d.leakageEstimateMLD} MLD</span></div>
                      <div>Avg Pressure: <span className="text-white">{d.avgPressurePSI} PSI</span></div>
                    </>
                  );
                })()
              )}
              {pipes.find(p => p.id === selectedAssetId) && (
                (() => {
                  const p = pipes.find(p => p.id === selectedAssetId)!;
                  return (
                    <>
                      <div className="font-bold text-slate-300">Trunk Main {p.id}</div>
                      <div>Material: <span className="text-white">{p.material}</span></div>
                      <div>Diameter: <span className="text-white">{p.diameterMM}mm</span></div>
                      <div>Condition: <span className="text-amber-400">{p.condition}</span></div>
                    </>
                  );
                })()
              )}
              {leaks.find(l => l.id === selectedAssetId) && (
                (() => {
                  const l = leaks.find(l => l.id === selectedAssetId)!;
                  return (
                    <>
                      <div className="font-bold text-amber-400">Leak: {l.id}</div>
                      <div className="text-[10px] text-slate-400">{l.location}</div>
                      <div>Est Flow: <span className="text-white">{l.estimatedFlowLPS} LPS</span></div>
                      <div>Status: <span className="text-amber-400">{l.status}</span></div>
                    </>
                  );
                })()
              )}
              {incidents.find(i => i.id === selectedAssetId) && (
                (() => {
                  const i = incidents.find(i => i.id === selectedAssetId)!;
                  return (
                    <>
                      <div className="font-bold text-red-400">Incident: {i.id}</div>
                      <div className="text-[10px] text-red-300 font-bold uppercase">{i.type.replace("_", " ")}</div>
                      <div>Severity: <span className="text-red-400">LEVEL {i.severity}</span></div>
                      <div>Impacted UPRN: <span className="text-white">{i.affectedPropertiesCount}</span></div>
                    </>
                  );
                })()
              )}
            </div>
          ) : (
            <div className="mt-2 text-[11px] text-slate-500 italic flex items-center gap-1 font-sans">
              <HelpCircle className="h-3.5 w-3.5 text-slate-600" />
              Hover or click any network element, reservoir, pipe, or incident pin to inspect real-time digital twin state.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
