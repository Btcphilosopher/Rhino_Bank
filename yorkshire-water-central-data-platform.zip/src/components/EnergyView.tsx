/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { EnergyMeter } from "../types";
import { Zap, ShieldCheck, Leaf, Landmark } from "lucide-react";

interface EnergyViewProps {
  energyMeters: EnergyMeter[];
}

export const EnergyView: React.FC<EnergyViewProps> = ({ energyMeters }) => {
  const totalKWh = energyMeters.reduce((sum, e) => sum + e.kwhToday, 0);
  const totalCost = energyMeters.reduce((sum, e) => sum + e.costGBP, 0);
  const totalCarbon = energyMeters.reduce((sum, e) => sum + e.carbonKg, 0);
  const totalRenewables = energyMeters.reduce((sum, e) => sum + e.renewableOffsetKWh, 0);

  return (
    <div className="space-y-6" id="energy-view-root">
      
      {/* Energy Metrics HUD */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-sm">
          <div className="text-xs font-mono text-slate-500 uppercase">Power Demand Today</div>
          <div className="text-2xl font-bold text-amber-500 mt-1 font-mono">
            {totalKWh.toLocaleString()} kWh
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Sum of all industrial sites</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-sm">
          <div className="text-xs font-mono text-slate-500 uppercase">Carbon Output Today</div>
          <div className="text-2xl font-bold text-red-400 mt-1 font-mono">
            {totalCarbon.toLocaleString()} kg
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Grid carbon footprint load</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-sm">
          <div className="text-xs font-mono text-slate-500 uppercase">Renewable Generation</div>
          <div className="text-2xl font-bold text-emerald-400 mt-1 font-mono">
            {totalRenewables.toLocaleString()} kWh
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Offsets from local biogas/CHP</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-sm">
          <div className="text-xs font-mono text-slate-500 uppercase">Daily Utility Cost</div>
          <div className="text-2xl font-bold text-white mt-1 font-mono">
            £{totalCost.toLocaleString()}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Estimated industrial tariffs</div>
        </div>
      </div>

      {/* Grid: Site Specific Carbon Profiles & Energy Intensity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Columns: Intensity Explainer */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 lg:col-span-2 shadow-sm space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Zap className="h-4 w-4 text-sky-400" />
            Energy Intensity Benchmarks (kWh / m³ treated)
          </h3>
          <p className="text-xs text-slate-400">
            Water pumping and treatment represents approximately 8% of the UK's total electricity load. Real-time energy intensity indexes track the electrical power required to pump and purify one cubic meter of clean water.
          </p>

          <div className="space-y-3.5">
            {/* Clean Water treatment works */}
            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center text-xs font-mono text-slate-400 mb-1.5">
                <span>Clean Water Treatment Energy Intensity</span>
                <span className="text-sky-400 font-bold">0.42 kWh / m³</span>
              </div>
              <div className="w-full bg-slate-900 h-2.5 rounded overflow-hidden">
                <div className="h-full bg-sky-500 rounded-full" style={{ width: "42%" }} />
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                <span>Benchmark Peak: 0.55 kWh/m³</span>
                <span className="text-emerald-400 font-bold">OPTIMAL OPERATIONAL STATUS</span>
              </div>
            </div>

            {/* Wastewater treatment works */}
            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center text-xs font-mono text-slate-400 mb-1.5">
                <span>Wastewater Treatment & Pumping Intensity</span>
                <span className="text-teal-400 font-bold">0.31 kWh / m³</span>
              </div>
              <div className="w-full bg-slate-900 h-2.5 rounded overflow-hidden">
                <div className="h-full bg-teal-500 rounded-full" style={{ width: "31%" }} />
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                <span>Benchmark Peak: 0.45 kWh/m³</span>
                <span className="text-emerald-400 font-bold">OPTIMAL OPERATIONAL STATUS</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right column: Renewable Offset Ratios */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">
              <Leaf className="h-4 w-4 text-emerald-400" />
              Catchment Renewable Offset Rates
            </h4>

            {/* Micro graphs / stats */}
            <div className="space-y-4 font-mono text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Headingley WTW Solar</span>
                <span className="text-emerald-400 font-bold">29.4% Offset</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Keldgate WTW Wind turbine</span>
                <span className="text-emerald-400 font-bold">36.9% Offset</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Esholt WwTW Biogas CHP</span>
                <span className="text-emerald-400 font-bold">38.6% Offset</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Blackburn WwTW Biogas CHP</span>
                <span className="text-emerald-400 font-bold">36.6% Offset</span>
              </div>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-4 pt-3 text-[10px] text-slate-500">
            * Combined Heat & Power (CHP) generators burn biogas from anaerobic digesters to supply continuous zero-carbon heat and electricity.
          </div>
        </div>
      </div>

      {/* Energy Meter Table Ledger */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <h4 className="font-semibold text-slate-200 mb-4 font-mono uppercase">Authoritative Site Energy meters ledger</h4>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="p-3">METER ID</th>
                <th className="p-3">SITE NAME</th>
                <th className="p-3">CONSUMPTION TODAY</th>
                <th className="p-3">CARBON OUTPUT</th>
                <th className="p-3">RENEWABLE OFFSET</th>
                <th className="p-3">REVENUE TARIFF</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {energyMeters.map(meter => {
                const offsetPct = (meter.renewableOffsetKWh / meter.kwhToday) * 100;
                return (
                  <tr key={meter.id} className="hover:bg-slate-800/40">
                    <td className="p-3 font-bold text-sky-400">{meter.id}</td>
                    <td className="p-3 text-slate-300">
                      <div>{meter.siteName}</div>
                      <span className="text-[9px] uppercase bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-bold font-sans">
                        {meter.type.replace("_", " ")}
                      </span>
                    </td>
                    <td className="p-3 font-bold text-white text-sm">{meter.kwhToday.toLocaleString()} kWh</td>
                    <td className="p-3 text-red-400 font-bold">{meter.carbonKg.toLocaleString()} kg CO₂</td>
                    <td className="p-3 text-emerald-400 font-bold">
                      {meter.renewableOffsetKWh.toLocaleString()} kWh ({offsetPct.toFixed(1)}%)
                      <span className="text-slate-500 text-[10px] font-sans block">via {meter.renewableSource}</span>
                    </td>
                    <td className="p-3 text-slate-400 font-sans">{meter.tariffName}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
