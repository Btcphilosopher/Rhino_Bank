/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Incident, WorkOrder } from "../types";
import { AlertCircle, ShieldAlert, Users, Wrench, Calendar, MapPin, CheckSquare, Plus } from "lucide-react";

interface IncidentViewProps {
  incidents: Incident[];
  workOrders: WorkOrder[];
  onAddIncident: (incident: { type: string; severity: number; location: string; description: string }) => void;
  onUpdateWorkOrder: (id: string, status: string, notes: string) => void;
}

export const IncidentView: React.FC<IncidentViewProps> = ({ incidents, workOrders, onAddIncident, onUpdateWorkOrder }) => {
  const [incType, setIncType] = useState("BURST_MAIN");
  const [incSeverity, setIncSeverity] = useState("3");
  const [incLocation, setIncLocation] = useState("Leeds Briggate Main Connector");
  const [incNotes, setIncNotes] = useState("Reported by DMA night flow acoustic sensors. Sudden pressure loss.");

  const [selectedWO, setSelectedWO] = useState<WorkOrder | null>(null);
  const [woStatus, setWOStatus] = useState("COMPLETED");
  const [woNotes, setWONotes] = useState("Repaired joint collar. Backfilling excavation.");

  const handleIncidentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddIncident({
      type: incType,
      severity: Number(incSeverity),
      location: incLocation,
      description: incNotes
    });
    setIncNotes("");
  };

  const handleWOUpdateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedWO) return;
    onUpdateWorkOrder(selectedWO.id, woStatus, woNotes);
    setSelectedWO(null);
  };

  const getSeverityBadge = (sev: number) => {
    switch (sev) {
      case 4:
        return <span className="bg-red-950 border border-red-500 text-red-400 font-bold px-2 py-0.5 rounded text-[10px]">L4 - CRITICAL</span>;
      case 3:
        return <span className="bg-orange-950 border border-orange-500 text-orange-400 font-bold px-2 py-0.5 rounded text-[10px]">L3 - MAJOR</span>;
      case 2:
        return <span className="bg-yellow-950 border border-yellow-500 text-yellow-400 px-2 py-0.5 rounded text-[10px]">L2 - OPERATIONAL</span>;
      default:
        return <span className="bg-slate-800 border border-slate-700 text-slate-300 px-2 py-0.5 rounded text-[10px]">L1 - MINOR</span>;
    }
  };

  return (
    <div className="space-y-6" id="incident-view-root">
      
      {/* HUD Header */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Manual Incident Intake */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">
            <AlertCircle className="h-4 w-4 text-orange-400" />
            Control Desk Incident Registration
          </h4>

          <form onSubmit={handleIncidentSubmit} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-slate-400 font-mono mb-1 font-bold">INCIDENT TYPE</label>
              <select
                value={incType}
                onChange={e => setIncType(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded focus:border-orange-500 font-mono"
              >
                <option value="BURST_MAIN">Burst trunk pipeline main</option>
                <option value="LOW_PRESSURE">Systemic low pressure alarm</option>
                <option value="NO_WATER">Total supply loss reported</option>
                <option value="WATER_QUALITY">Esthetic water quality event</option>
                <option value="SEWER_FLOOD">Sewer overflow inundation</option>
                <option value="POLLUTION">Catchment pollution release</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-400 font-mono mb-1 font-bold">SEVERITY LEVEL</label>
                <select
                  value={incSeverity}
                  onChange={e => setIncSeverity(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded focus:border-orange-500 font-mono"
                >
                  <option value="1">L1 - Minor Local</option>
                  <option value="2">L2 - Operational</option>
                  <option value="3">L3 - Major Network</option>
                  <option value="4">L4 - Critical Emergency</option>
                </select>
              </div>
              <div>
                <label className="block text-slate-400 font-mono mb-1 font-bold">LOCATION</label>
                <input
                  type="text"
                  value={incLocation}
                  onChange={e => setIncLocation(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded focus:border-orange-500 font-mono"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-mono mb-1 font-bold">EVENT NOTES / AUDIT SUMMARY</label>
              <textarea
                value={incNotes}
                onChange={e => setIncNotes(e.target.value)}
                rows={2}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded focus:border-orange-500 font-sans"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-orange-600 hover:bg-orange-500 text-white font-bold py-2 rounded transition-all flex items-center justify-center gap-1 font-mono uppercase text-xs"
            >
              <Plus className="h-4 w-4" />
              Declare Network Incident
            </button>
          </form>
        </div>

        {/* Dynamic Workforce Dispatch & Field Work Orders */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm lg:col-span-2 flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">
              <Wrench className="h-4 w-4 text-sky-400" />
              Mobile Field Workforce dispatcher
            </h4>

            {selectedWO ? (
              <form onSubmit={handleWOUpdateSubmit} className="space-y-3 bg-slate-950 p-4 rounded-lg border border-slate-800 text-xs">
                <div className="flex justify-between font-mono">
                  <span className="font-bold text-sky-400">UPDATE WORK ORDER: {selectedWO.id}</span>
                  <button type="button" onClick={() => setSelectedWO(null)} className="text-slate-500 hover:text-slate-300">Cancel</button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-slate-400 font-mono mb-1">FIELD PROGRESS STATUS</label>
                    <select
                      value={woStatus}
                      onChange={e => setWOStatus(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 text-slate-200 p-1.5 rounded font-mono"
                    >
                      <option value="IN_PROGRESS">IN PROGRESS</option>
                      <option value="COMPLETED">COMPLETED</option>
                      <option value="SCHEDULED">SCHEDULED</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-400 font-mono mb-1">NOTES</label>
                    <input
                      type="text"
                      value={woNotes}
                      onChange={e => setWONotes(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 text-slate-200 p-1.5 rounded"
                      required
                    />
                  </div>
                </div>
                <button type="submit" className="w-full bg-sky-600 hover:bg-sky-500 text-white font-bold py-1.5 rounded font-mono text-[11px] uppercase">
                  Transmit telemetry update
                </button>
              </form>
            ) : (
              <div className="space-y-2.5">
                {workOrders.map(wo => {
                  const isCompleted = wo.status === "COMPLETED";
                  return (
                    <div key={wo.id} className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex justify-between items-center text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-sky-400">{wo.id}</span>
                          <span className={`text-[9px] font-mono font-bold px-1.5 rounded ${
                            wo.priority === "CRITICAL" ? "bg-red-950 text-red-400" : "bg-slate-800 text-slate-400"
                          }`}>{wo.priority}</span>
                        </div>
                        <div className="text-slate-300 mt-1">{wo.location}</div>
                        <div className="text-[10px] text-slate-500 font-mono mt-0.5">Crew: {wo.assignedEngineer}</div>
                      </div>
                      <div className="text-right flex flex-col items-end gap-1.5">
                        <span className={`font-mono text-[10px] font-bold px-2 py-0.5 rounded border ${
                          isCompleted ? "bg-emerald-950 border-emerald-500 text-emerald-400" : "bg-sky-950 border-sky-500 text-sky-400"
                        }`}>{wo.status}</span>
                        {!isCompleted && (
                          <button
                            onClick={() => { setSelectedWO(wo); setWONotes(wo.notes); }}
                            className="text-[10px] bg-slate-800 hover:bg-slate-700 text-sky-400 px-2 py-1 rounded font-mono"
                          >
                            Dispatch
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          <div className="text-[10px] text-slate-500 font-mono italic mt-4 border-t border-slate-800 pt-3">
            * Field telemetry transmits via private APN satellite uplink to log labor, asset replacement values & audit entries in real-time.
          </div>
        </div>
      </div>

      {/* Incidents Command center Ledger */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <h4 className="font-semibold text-slate-200 mb-4 font-mono uppercase">Yorkshire Network Active Incidents Log</h4>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="p-3">INCIDENT ID</th>
                <th className="p-3">SEVERITY</th>
                <th className="p-3">INCIDENT PROFILE</th>
                <th className="p-3">STREET LOCATION</th>
                <th className="p-3">AFFECTED PROPERTIES</th>
                <th className="p-3">COMMENCED</th>
                <th className="p-3">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {incidents.map((inc, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-red-400">{inc.id}</td>
                  <td className="p-3">{getSeverityBadge(inc.severity)}</td>
                  <td className="p-3 font-bold text-slate-200 uppercase">{inc.type.replace("_", " ")}</td>
                  <td className="p-3 text-slate-300">{inc.location}</td>
                  <td className="p-3">
                    <span className="text-white font-bold">{inc.affectedPropertiesCount.toLocaleString()}</span>
                    <span className="text-slate-500 text-[10px] block font-sans">({inc.affectedCustomersCount.toLocaleString()} Customers)</span>
                  </td>
                  <td className="p-3 text-slate-400">{new Date(inc.startTime).toLocaleTimeString()}</td>
                  <td className="p-3">
                    <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold border ${
                      inc.status === "RESOLVED" || inc.status === "CLOSED"
                        ? "bg-emerald-950 border-emerald-500 text-emerald-400"
                        : "bg-red-950 border-red-500 text-red-400 animate-pulse"
                    }`}>
                      {inc.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
