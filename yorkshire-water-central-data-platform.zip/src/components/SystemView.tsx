/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { PipelineStatus, AuditLogEntry } from "../types";
import { Layers, Database, ShieldAlert, History, Filter } from "lucide-react";

interface SystemViewProps {
  pipelines: PipelineStatus[];
  auditLogs: AuditLogEntry[];
}

export const SystemView: React.FC<SystemViewProps> = ({ pipelines, auditLogs }) => {
  const [search, setSearch] = useState("");

  const filteredLogs = auditLogs.filter(log => 
    log.user.toLowerCase().includes(search.toLowerCase()) ||
    log.objectId.toLowerCase().includes(search.toLowerCase()) ||
    log.objectType.toLowerCase().includes(search.toLowerCase()) ||
    log.newValue.toLowerCase().includes(search.toLowerCase()) ||
    log.reason.toLowerCase().includes(search.toLowerCase())
  );

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "HEALTHY":
        return <span className="bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded">HEALTHY</span>;
      case "WARNING":
        return <span className="bg-amber-950 text-amber-400 border border-amber-800 text-[10px] font-bold px-2 py-0.5 rounded animate-pulse">WARNING</span>;
      default:
        return <span className="bg-red-950 text-red-400 border border-red-800 text-[10px] font-bold px-2 py-0.5 rounded">{status}</span>;
    }
  };

  return (
    <div className="space-y-6" id="system-view-root">
      
      {/* Pipeline Ingestion Streams */}
      <div>
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-1.5">
          <Database className="h-4 w-4 text-sky-400" />
          Core Ingestion Adapters & Data Sync Pipeline Health
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {pipelines.map((p, idx) => {
            const hasErrors = p.errorCount > 0;
            return (
              <div key={idx} className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm hover:border-slate-700 transition-all font-mono">
                <div className="flex justify-between items-start mb-3">
                  <span className="text-slate-500 text-[9px] uppercase font-bold tracking-widest">SOURCE ADAPTER</span>
                  {getStatusBadge(p.status)}
                </div>

                <h4 className="text-xs font-bold text-slate-100 font-sans">{p.name}</h4>
                <div className="text-[10px] text-slate-500 mt-1">Last Sync: {new Date(p.lastSync).toLocaleTimeString()}</div>

                <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-800 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-500 block">RECORDS</span>
                    <span className="font-bold text-slate-200">{p.recordCount.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">ERRORS</span>
                    <span className={`font-bold ${hasErrors ? "text-amber-500" : "text-slate-400"}`}>{p.errorCount}</span>
                  </div>
                </div>

                <div className="mt-3 text-[10px] text-slate-400 flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800/80">
                  <span>Data Quality Score:</span>
                  <span className="text-emerald-400 font-bold">{p.qualityScore}%</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Append-Only Core Operational Audit Log */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <History className="h-4 w-4 text-sky-400" />
              Non-Modifiable Append-Only Audit Trail
            </h3>
            <p className="text-xs text-slate-500 font-sans mt-0.5">
              Every critical administrative update, hydraulic valve toggle, or manual quality register records immutable event history.
            </p>
          </div>

          {/* Search Audit Logs */}
          <div className="relative max-w-xs w-full">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Filter className="h-3 w-3 text-slate-500" />
            </span>
            <input
              type="text"
              placeholder="Filter audit trail logs..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-xs font-mono text-slate-300 pl-8 pr-3 py-1.5 rounded focus:outline-none focus:border-sky-500"
            />
          </div>
        </div>

        {/* Audit Log Ledger table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="p-3">LOG ID</th>
                <th className="p-3">OPERATOR / AGENT</th>
                <th className="p-3">ACTION ID</th>
                <th className="p-3">AFFECTED DOMAIN</th>
                <th className="p-3">HISTORIC VALUES</th>
                <th className="p-3">REGULATORY REASON / JUSTIFICATION</th>
                <th className="p-3">TIMESTAMP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredLogs.map(log => (
                <tr key={log.id} className="hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-slate-500">{log.id}</td>
                  <td className="p-3 text-sky-400 font-bold">{log.user}</td>
                  <td className="p-3">
                    <span className="bg-slate-950 border border-slate-800 text-slate-300 px-1.5 py-0.5 rounded text-[10px] font-bold font-mono">
                      {log.action}
                    </span>
                  </td>
                  <td className="p-3 text-slate-200 uppercase font-sans font-bold text-[10px]">
                    {log.objectType}
                    <span className="text-slate-500 text-[9px] block font-mono">ID: {log.objectId}</span>
                  </td>
                  <td className="p-3">
                    <div className="text-slate-500 text-[10px]">OLD: <span className="text-slate-400">{log.oldValue}</span></div>
                    <div className="text-slate-300 text-[10px]">NEW: <span className="text-white font-bold">{log.newValue}</span></div>
                  </td>
                  <td className="p-3 text-slate-300 font-sans text-[11px]">
                    {log.reason}
                    <span className="text-slate-500 text-[9px] block font-mono">Source: {log.source}</span>
                  </td>
                  <td className="p-3 text-slate-400 text-[10px]">{new Date(log.timestamp).toLocaleString()}</td>
                </tr>
              ))}
              {filteredLogs.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-500 italic font-sans">
                    No corresponding audit log trail files found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

      </div>

    </div>
  );
};
