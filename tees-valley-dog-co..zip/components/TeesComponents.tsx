'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingBag, 
  User, 
  Activity, 
  MapPin, 
  ArrowRight, 
  Settings, 
  TrendingUp, 
  Search, 
  Lock, 
  CheckCircle, 
  AlertCircle, 
  Truck, 
  ChevronRight, 
  Calculator,
  RefreshCw,
  FileText,
  Clock,
  Menu,
  X
} from 'lucide-react';
import { useApp, CartItem } from '@/lib/AppContext';
import { Product, products, tradeAccounts, Order } from '@/lib/data';

// ============================================================================
// 1. TECHNICAL LABEL (Section 5)
// ============================================================================
export function TechnicalLabel({ label, value, colorClass = "text-steel-grey" }: { label: string; value: string | number; colorClass?: string }) {
  return (
    <div className="flex flex-col border-l border-steel-grey/30 pl-3 py-1 font-mono">
      <span className="text-[10px] tracking-widest text-steel-grey uppercase">{label}</span>
      <span className={`text-sm font-semibold uppercase tracking-wider ${colorClass}`}>{value}</span>
    </div>
  );
}

// ============================================================================
// 2. NUTRITION PANEL (Section 18)
// ============================================================================
export function NutritionPanel({ product }: { product: Product }) {
  const macros = [
    { label: "PROTEIN", value: `${product.protein}%`, sub: "Muscle & Tissue" },
    { label: "FAT", value: `${product.fat}%`, sub: "Energy & Coat" },
    { label: "FIBRE", value: `${product.fibre}%`, sub: "Digestion Support" },
    { label: "ASH", value: `${product.ash}%`, sub: "Essential Minerals" },
    { label: "MOISTURE", value: `${product.moisture}%`, sub: "Formulation Stability" },
    { label: "ENERGY", value: product.energy, sub: "Metabolizable" }
  ];

  return (
    <div className="bg-steel-charcoal/40 border border-steel-grey/20 p-6 md:p-8 font-mono">
      <div className="flex items-center justify-between border-b border-steel-grey/30 pb-4 mb-6">
        <div>
          <span className="text-xs text-hot-orange tracking-widest block uppercase">ANALYTICAL CONSTITUENTS</span>
          <h4 className="text-lg font-bold tracking-tight text-bone">FORMULATION ANALYSIS</h4>
        </div>
        <span className="text-xs text-steel-grey hidden md:inline">BATCH: TV-260925-014</span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
        {macros.map((m, idx) => (
          <div key={idx} className="border border-steel-grey/20 p-4 relative group hover:border-hot-orange/40 transition-colors">
            <span className="text-[10px] text-steel-grey tracking-widest block mb-1">{m.label}</span>
            <div className="text-2xl font-bold tracking-tight text-bone font-mono tabular-nums">{m.value}</div>
            <span className="text-[11px] text-steel-grey block mt-2 border-t border-steel-grey/15 pt-1">{m.sub}</span>
            {/* Corner Industrial rivets */}
            <div className="absolute top-1 right-1 w-1 h-1 bg-steel-grey/30"></div>
          </div>
        ))}
      </div>

      <div className="mt-6 text-[11px] text-steel-grey flex items-start gap-2">
        <AlertCircle className="w-4.5 h-4.5 text-hot-orange shrink-0 mt-0.5" />
        <p>
          All nutritional analytical values are highly precise, deterministic, and scientifically formulated. Formulated specifically to feed healthy working and companion dogs without synthetic fillers.
        </p>
      </div>
    </div>
  );
}

// ============================================================================
// 3. INGREDIENT CARD (Section 19-20)
// ============================================================================
export function IngredientCard({ name, percentage, source, functionText }: { name: string; percentage: number; source: string; functionText: string }) {
  return (
    <div className="bg-concrete text-steel-charcoal border-l-4 border-mboro-brick p-5 flex flex-col justify-between hover:-translate-y-1 transition-transform duration-300">
      <div>
        <div className="flex justify-between items-baseline border-b border-steel-charcoal/15 pb-2 mb-3 font-mono">
          <span className="font-bold tracking-tight text-base uppercase">{name}</span>
          <span className="font-mono text-lg font-bold text-mboro-brick tabular-nums">{percentage}%</span>
        </div>
        <p className="text-sm text-steel-charcoal/80 mb-4">{functionText}</p>
      </div>
      <div className="font-mono text-[10px] text-steel-grey tracking-wider uppercase flex items-center gap-1 border-t border-steel-charcoal/10 pt-2">
        <MapPin className="w-3 h-3 text-mboro-brick" />
        <span>SOURCE: {source}</span>
      </div>
    </div>
  );
}

// ============================================================================
// 4. MANUFACTURING TIMELINE (Section 21-22)
// ============================================================================
export function ManufacturingTimeline() {
  const [activeStep, setActiveStep] = useState(2); // "COOK" active by default

  const steps = [
    { name: "INGREDIENTS", desc: "North Yorkshire grains and fresh British poultry analyzed & batch-weighed in Middlehaven silos." },
    { name: "MIX", desc: "Industrial high-accuracy steel batch blenders combine whole-meal fibers with essential trace elements." },
    { name: "COOK", desc: "Gentle low-temperature extrusion cooking preserves the raw amino acids & protein matrices." },
    { name: "FORM", desc: "Mechanical die heads mold uniform kibble shapes built for perfect canine tooth mechanical abrasion." },
    { name: "DRY", desc: "Horizontal heat-retention tunnels dehydrate kibble to exactly 9% moisture for natural storage." },
    { name: "TEST", desc: "Laser optical scanners and local lab tests verify foreign-body scans & microbiotics." },
    { name: "PACK", desc: "Auto-weighed filling into heavy multi-layer recyclable paper bags with protective sealing." },
    { name: "DISPATCH", desc: "Middlesbrough warehouse palletizing and freight loading for direct national trade dispatch." }
  ];

  return (
    <div className="border border-steel-grey/20 p-6 md:p-10 bg-steel-charcoal/20 relative">
      <div className="mb-6 md:mb-10">
        <span className="text-xs text-hot-orange tracking-widest block font-mono uppercase">PRODUCTION WORKFLOW</span>
        <h3 className="text-2xl md:text-3xl font-extrabold tracking-tight text-bone">THE MIDDLESBROUGH MANUFACTURING STANDARD</h3>
      </div>

      {/* Grid for Steps */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
        {steps.map((s, idx) => {
          const isActive = idx === activeStep;
          const isCompleted = idx < activeStep;
          
          return (
            <button
              key={idx}
              onClick={() => setActiveStep(idx)}
              className={`p-4 border text-left flex flex-col justify-between h-40 transition-all duration-300 relative group cursor-pointer ${
                isActive 
                  ? 'bg-hot-orange/10 border-hot-orange text-bone' 
                  : isCompleted
                  ? 'border-steel-grey/50 bg-steel-charcoal/50 text-steel-grey'
                  : 'border-steel-grey/20 bg-steel-charcoal/10 text-steel-grey/70'
              }`}
            >
              <div className="flex justify-between items-start font-mono w-full">
                <span className="text-xs font-bold tabular-nums">0{idx + 1}</span>
                {isActive && <div className="w-1.5 h-1.5 bg-hot-orange rounded-full animate-ping" />}
              </div>

              <div>
                <span className={`font-mono text-xs font-bold block tracking-wider uppercase mb-1 ${isActive ? 'text-hot-orange' : ''}`}>
                  {s.name}
                </span>
                <span className="text-[10px] line-clamp-2 leading-snug font-sans block text-steel-grey group-hover:text-bone/80 transition-colors">
                  {s.desc}
                </span>
              </div>

              {/* High-visibility active light */}
              {isActive && (
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-hot-orange" />
              )}
            </button>
          );
        })}
      </div>

      {/* Detail Showcase of Selected Stage */}
      <div className="mt-8 bg-steel-charcoal border border-steel-grey/20 p-5 md:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="max-w-2xl font-mono">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-xs bg-hot-orange text-steel-charcoal px-2 py-0.5 font-bold">STAGE 0{activeStep + 1} ACTIVE</span>
            <span className="text-xs text-steel-grey">PROCESS: CONTINUOUS INTEGRITY</span>
          </div>
          <h4 className="text-xl font-bold tracking-tight text-bone uppercase mb-2">{steps[activeStep].name} STAGE DETAILS</h4>
          <p className="text-sm font-sans text-bone/80 leading-relaxed">
            {steps[activeStep].desc} Every single batch processed on {steps[activeStep].name.toLowerCase()} stage is fully documented, traced with raw-ingredient receipts, and checked via strict computerized sensors in our Teesside dock-side facility.
          </p>
        </div>
        <div className="flex gap-4 font-mono">
          <button 
            disabled={activeStep === 0}
            onClick={() => setActiveStep(prev => prev - 1)}
            className="px-4 py-2 text-xs border border-steel-grey/30 text-steel-grey hover:border-bone hover:text-bone disabled:opacity-35 disabled:hover:text-steel-grey cursor-pointer"
          >
            PREVIOUS
          </button>
          <button 
            disabled={activeStep === steps.length - 1}
            onClick={() => setActiveStep(prev => prev + 1)}
            className="px-4 py-2 text-xs bg-hot-orange text-steel-charcoal font-bold hover:bg-hot-orange/90 cursor-pointer"
          >
            NEXT STAGE
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// 5. MARGIN CALCULATOR (Section 35)
// ============================================================================
export function MarginCalculator() {
  const [buyPrice, setBuyPrice] = useState<number>(31.80);
  const [retailPrice, setRetailPrice] = useState<number>(49.00);
  const [quantity, setQuantity] = useState<number>(100);

  // Math Calculations
  const revenue = quantity * retailPrice;
  const cost = quantity * buyPrice;
  const grossProfit = revenue - cost;
  const marginPercent = revenue > 0 ? (grossProfit / revenue) * 100 : 0;
  const markupPercent = buyPrice > 0 ? (grossProfit / cost) * 100 : 0;

  return (
    <div className="bg-steel-charcoal border border-steel-grey/30 p-6 md:p-8 font-mono">
      <div className="border-b border-steel-grey/20 pb-4 mb-6">
        <div className="flex items-center gap-2 mb-1">
          <Calculator className="w-5 h-5 text-hot-orange" />
          <span className="text-xs text-hot-orange tracking-widest uppercase font-bold">FINANCIAL SIMULATOR</span>
        </div>
        <h3 className="text-xl font-extrabold tracking-tight text-bone">B2B TRADE MARGIN CALCULATOR</h3>
        <p className="text-xs font-sans text-steel-grey mt-1">Calculate your gross margins and estimated regional resale profit.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {/* Input 1 */}
        <div className="flex flex-col">
          <label className="text-[10px] tracking-wider text-steel-grey mb-2 uppercase">BUY PRICE per case (£)</label>
          <input 
            type="number" 
            value={buyPrice}
            onChange={(e) => setBuyPrice(Math.max(0, parseFloat(e.target.value) || 0))}
            className="bg-steel-charcoal/80 border border-steel-grey/30 p-3 text-bone font-mono focus:border-hot-orange outline-none"
            step="0.1"
          />
        </div>

        {/* Input 2 */}
        <div className="flex flex-col">
          <label className="text-[10px] tracking-wider text-steel-grey mb-2 uppercase">RETAIL PRICE per unit (£)</label>
          <input 
            type="number" 
            value={retailPrice}
            onChange={(e) => setRetailPrice(Math.max(0, parseFloat(e.target.value) || 0))}
            className="bg-steel-charcoal/80 border border-steel-grey/30 p-3 text-bone font-mono focus:border-hot-orange outline-none"
            step="0.1"
          />
        </div>

        {/* Input 3 */}
        <div className="flex flex-col">
          <label className="text-[10px] tracking-wider text-steel-grey mb-2 uppercase">MONTHLY UNIT VOLUME (Bags)</label>
          <input 
            type="number" 
            value={quantity}
            onChange={(e) => setQuantity(Math.max(0, parseInt(e.target.value) || 0))}
            className="bg-steel-charcoal/80 border border-steel-grey/30 p-3 text-bone font-mono focus:border-hot-orange outline-none"
          />
        </div>
      </div>

      {/* Outputs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 bg-steel-charcoal/40 p-4 border border-steel-grey/20">
        <div className="border-r border-steel-grey/15 p-2">
          <span className="text-[10px] text-steel-grey block mb-1">GROSS REVENUE</span>
          <div className="text-2xl font-bold text-bone font-mono tabular-nums">£{revenue.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
        </div>

        <div className="border-r border-steel-grey/15 p-2">
          <span className="text-[10px] text-steel-grey block mb-1">COGS (COST OF GOODS)</span>
          <div className="text-2xl font-bold text-bone font-mono tabular-nums">£{cost.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
        </div>

        <div className="border-r border-steel-grey/15 p-2">
          <span className="text-[10px] text-steel-grey block mb-1">GROSS PROFIT</span>
          <div className="text-2xl font-bold text-hot-orange font-mono tabular-nums">£{grossProfit.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
        </div>

        <div className="p-2">
          <span className="text-[10px] text-steel-grey block mb-1">GROSS MARGIN %</span>
          <div className="text-2xl font-bold text-mboro-brick font-mono tabular-nums">{marginPercent.toFixed(1)}%</div>
        </div>
      </div>

      <div className="mt-5 text-[11px] text-steel-grey">
        * Estimates do not account for VAT or potential pallet shipping discounts. Standard wholesale margins average 30% to 36% depending on buy volume tiers.
      </div>
    </div>
  );
}

// ============================================================================
// 6. TRACEABILITY TIMELINE (Section 45)
// ============================================================================
export function TraceabilityTimeline() {
  const { batches } = useApp();
  const [selectedBatchId, setSelectedBatchId] = useState(batches[0]?.id || "TV-260925-014");
  const [searchQuery, setSearchQuery] = useState("");

  const currentBatch = batches.find(b => b.id === selectedBatchId || b.id.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="bg-steel-charcoal border border-steel-grey/20 p-6 md:p-8 font-mono">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-steel-grey/20 pb-4 mb-6 gap-4">
        <div>
          <span className="text-xs text-hot-orange tracking-widest block font-mono uppercase">TRACEABILITY LOGS</span>
          <h3 className="text-xl font-extrabold tracking-tight text-bone">BATCH TRACING & ANALYSIS</h3>
        </div>

        <div className="flex flex-wrap gap-2 w-full md:w-auto">
          {/* Dropdown Selector */}
          <select 
            value={selectedBatchId} 
            onChange={(e) => setSelectedBatchId(e.target.value)}
            className="bg-steel-charcoal/80 border border-steel-grey/30 text-bone p-2 text-xs outline-none focus:border-hot-orange cursor-pointer"
          >
            {batches.map(b => (
              <option key={b.id} value={b.id}>{b.id} ({b.productName.split(" — ")[0]})</option>
            ))}
          </select>
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search Batch ID..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-steel-charcoal/85 border border-steel-grey/30 text-bone p-2 pl-7 text-xs outline-none focus:border-hot-orange w-32"
            />
            <Search className="absolute left-2 top-2.5 w-3.5 h-3.5 text-steel-grey" />
          </div>
        </div>
      </div>

      {currentBatch ? (
        <div>
          {/* Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-steel-charcoal/40 p-4 border border-steel-grey/20 mb-6">
            <div>
              <span className="text-[10px] text-steel-grey block">BATCH ID</span>
              <span className="text-sm font-bold text-hot-orange uppercase">{currentBatch.id}</span>
            </div>
            <div>
              <span className="text-[10px] text-steel-grey block">PRODUCT</span>
              <span className="text-sm font-bold text-bone uppercase truncate block">{currentBatch.productName.split(" — ")[0]}</span>
            </div>
            <div>
              <span className="text-[10px] text-steel-grey block">MANUFACTURE DATE</span>
              <span className="text-sm font-bold text-bone uppercase">{currentBatch.productionDate}</span>
            </div>
            <div>
              <span className="text-[10px] text-steel-grey block">STATUS</span>
              <span className={`text-sm font-bold uppercase ${currentBatch.status === 'RELEASED' ? 'text-emerald-400' : 'text-amber-400'}`}>
                {currentBatch.status}
              </span>
            </div>
          </div>

          {/* Timeline */}
          <div className="relative border-l border-steel-grey/30 pl-6 ml-3 space-y-6">
            {/* Step 1 */}
            <div className="relative">
              <div className="absolute -left-9.5 top-0.5 w-7 h-7 bg-steel-charcoal border border-emerald-400 rounded-full flex items-center justify-center text-emerald-400 text-xs font-bold">1</div>
              <div>
                <h4 className="text-sm font-bold text-bone uppercase">INGREDIENT DISPATCH & LAB QUALITY VERIFICATION</h4>
                <p className="text-xs text-steel-grey font-sans mt-1">
                  Chicken Meal sourced from Yorkshire Farms, Flaked Oats sourced from Teesside Arable. Passed all micro-toxin tests.
                </p>
                <div className="flex gap-2 mt-2">
                  {currentBatch.ingredients.map((ing, i) => (
                    <span key={i} className="text-[9px] bg-steel-charcoal/70 border border-steel-grey/20 px-2 py-0.5 text-steel-grey">
                      {ing.name}: {ing.testStatus}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Step 2 */}
            <div className="relative">
              <div className="absolute -left-9.5 top-0.5 w-7 h-7 bg-steel-charcoal border border-emerald-400 rounded-full flex items-center justify-center text-emerald-400 text-xs font-bold">2</div>
              <div>
                <h4 className="text-sm font-bold text-bone uppercase">FABRICATION AND THERMAL EXTRUSION ({currentBatch.productionLine})</h4>
                <p className="text-xs text-steel-grey font-sans mt-1">
                  Extruded, formed, and dehydrated inside Middlehaven Dock facility under strict clean room standards. Continuous temperature logged.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="relative">
              <div className="absolute -left-9.5 top-0.5 w-7 h-7 bg-steel-charcoal border border-emerald-400 rounded-full flex items-center justify-center text-emerald-400 text-xs font-bold">3</div>
              <div>
                <h4 className="text-sm font-bold text-bone uppercase">ANALYTICAL QC & METAL SCAN CHECK</h4>
                <p className="text-xs text-steel-grey font-sans mt-1">
                  Passed all multi-spectrum moisture checks, foreign-body x-rays, and protein composition target checks.
                </p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2 max-w-lg">
                  <span className="text-[9px] bg-steel-charcoal/70 border border-emerald-500/20 px-2 py-0.5 text-emerald-400">Moisture: Passed</span>
                  <span className="text-[9px] bg-steel-charcoal/70 border border-emerald-500/20 px-2 py-0.5 text-emerald-400">Protein Target: Passed</span>
                  <span className="text-[9px] bg-steel-charcoal/70 border border-emerald-500/20 px-2 py-0.5 text-emerald-400">Metal Scan: Passed</span>
                  <span className="text-[9px] bg-steel-charcoal/70 border border-emerald-500/20 px-2 py-0.5 text-emerald-400">Microbial Screen: Passed</span>
                </div>
              </div>
            </div>

            {/* Step 4 */}
            <div className="relative">
              <div className="absolute -left-9.5 top-0.5 w-7 h-7 bg-steel-charcoal border border-hot-orange rounded-full flex items-center justify-center text-hot-orange text-xs font-bold">4</div>
              <div>
                <h4 className="text-sm font-bold text-bone uppercase">WAREHOUSE BIN ASSIGNMENT & DISPATCH RELEASE</h4>
                <p className="text-xs text-steel-grey font-sans mt-1">
                  Assigned location: <strong className="text-bone">{currentBatch.warehouseLocation}</strong>. QC batch release authorized digitally by: <strong className="text-bone">{currentBatch.qualityCheck.releaseAuthorizedBy}</strong>.
                </p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-8 text-center border border-dashed border-steel-grey/20 text-steel-grey text-sm">
          No batch found matching &quot;{searchQuery}&quot;. Try &quot;TV-260925-014&quot; or selecting from the dropdown.
        </div>
      )}
    </div>
  );
}

// ============================================================================
// 7. DELIVERY TRACKER (Section 40)
// ============================================================================
export function DeliveryTracker({ order }: { order: Order }) {
  const steps: Order['status'][] = ['CONFIRMED', 'ALLOCATED', 'PACKED', 'DISPATCHED', 'DELIVERED'];
  const currentIndex = steps.indexOf(order.status);

  return (
    <div className="bg-steel-charcoal/40 border border-steel-grey/20 p-6 font-mono w-full">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-steel-grey/20 pb-4 mb-6 gap-2">
        <div>
          <span className="text-[10px] text-hot-orange tracking-widest block uppercase">SHIPMENT CARRIER SYSTEM</span>
          <h4 className="text-base font-bold text-bone">TRACKING: {order.trackingNumber || `TV-SHP-${order.id.slice(-5)}`}</h4>
        </div>
        <div className="text-left md:text-right">
          <span className="text-[10px] text-steel-grey block">ORDER REF</span>
          <span className="text-xs font-bold text-bone">{order.id}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {steps.map((s, idx) => {
          const isActive = idx === currentIndex;
          const isCompleted = idx <= currentIndex;
          
          return (
            <div 
              key={s} 
              className={`p-3 border flex flex-col justify-between h-20 transition-all ${
                isActive 
                  ? 'bg-hot-orange/10 border-hot-orange text-bone' 
                  : isCompleted 
                  ? 'border-steel-grey/60 text-steel-grey' 
                  : 'border-steel-grey/20 text-steel-grey/40'
              }`}
            >
              <div className="flex justify-between items-center text-[10px] font-mono mb-1">
                <span>0{idx + 1}</span>
                {isCompleted && <CheckCircle className={`w-3 h-3 ${isActive ? 'text-hot-orange animate-pulse' : 'text-steel-grey'}`} />}
              </div>
              <span className="font-mono text-xs font-bold block tracking-wider truncate">{s}</span>
            </div>
          );
        })}
      </div>

      <div className="mt-4 text-xs font-sans text-steel-grey flex items-center gap-2">
        <Truck className="w-4 h-4 text-hot-orange" />
        <span>
          {order.status === 'DELIVERED' 
            ? "Your cargo has successfully docked and unloaded at destination." 
            : order.status === 'DISPATCHED' 
            ? "In transit via Freight Logistics. Estimated regional delivery is tomorrow." 
            : "Your premium dog food order is inside our Middlehaven packaging queue."}
        </span>
      </div>
    </div>
  );
}

// ============================================================================
// 8. DOG PROFILE CREATION (Section 30)
// ============================================================================
export function DogProfileComponent() {
  const { dogProfile, saveDogProfile, clearDogProfile } = useApp();
  const [name, setName] = useState("");
  const [breed, setBreed] = useState("");
  const [age, setAge] = useState<number>(3);
  const [weight, setWeight] = useState<number>(15);
  const [activity, setActivity] = useState<'LOW' | 'ACTIVE' | 'WORKING'>('ACTIVE');
  const [allergies, setAllergies] = useState("");
  const [preference, setPreference] = useState("Chicken");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !breed) return;
    saveDogProfile({
      name,
      breed,
      age,
      weight,
      activityLevel: activity,
      allergies,
      preference
    });
  };

  return (
    <div className="bg-steel-charcoal border border-steel-grey/20 p-6 md:p-8 font-mono relative">
      <div className="border-b border-steel-grey/20 pb-4 mb-6">
        <span className="text-xs text-hot-orange tracking-widest block uppercase font-bold">NUTRITION PROFILE CREATOR</span>
        <h3 className="text-xl font-extrabold tracking-tight text-bone">DOG NUTRITION ENGINE</h3>
        <p className="text-xs text-steel-grey mt-1">Build an engineering profile for your companion for direct product suggestions.</p>
      </div>

      {!dogProfile ? (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex flex-col">
              <label className="text-[10px] text-steel-grey mb-1.5 uppercase">DOG NAME</label>
              <input 
                type="text" 
                placeholder="e.g. Milo"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="bg-steel-charcoal/80 border border-steel-grey/30 p-2.5 text-sm text-bone focus:border-hot-orange outline-none"
                required
              />
            </div>

            <div className="flex flex-col">
              <label className="text-[10px] text-steel-grey mb-1.5 uppercase">BREED</label>
              <input 
                type="text" 
                placeholder="e.g. Cocker Spaniel"
                value={breed}
                onChange={(e) => setBreed(e.target.value)}
                className="bg-steel-charcoal/80 border border-steel-grey/30 p-2.5 text-sm text-bone focus:border-hot-orange outline-none"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex flex-col">
              <label className="text-[10px] text-steel-grey mb-1.5 uppercase">AGE (years)</label>
              <input 
                type="number" 
                value={age}
                onChange={(e) => setAge(Math.max(0, parseInt(e.target.value) || 0))}
                className="bg-steel-charcoal/80 border border-steel-grey/30 p-2.5 text-sm text-bone focus:border-hot-orange outline-none"
                min="0"
              />
            </div>

            <div className="flex flex-col">
              <label className="text-[10px] text-steel-grey mb-1.5 uppercase">WEIGHT (kg)</label>
              <input 
                type="number" 
                value={weight}
                onChange={(e) => setWeight(Math.max(0, parseInt(e.target.value) || 0))}
                className="bg-steel-charcoal/80 border border-steel-grey/30 p-2.5 text-sm text-bone focus:border-hot-orange outline-none"
                min="0"
              />
            </div>

            <div className="flex flex-col">
              <label className="text-[10px] text-steel-grey mb-1.5 uppercase">PROTEIN FOCUS</label>
              <select 
                value={preference}
                onChange={(e) => setPreference(e.target.value)}
                className="bg-steel-charcoal/80 border border-steel-grey/30 p-2.5 text-sm text-bone focus:border-hot-orange outline-none"
              >
                <option value="Chicken">Chicken (Lean Growth)</option>
                <option value="Salmon">Salmon (Skin & Coat)</option>
                <option value="Beef">Beef (High Calories)</option>
                <option value="Lamb">Lamb (Sensitive Tummy)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex flex-col">
              <label className="text-[10px] text-steel-grey mb-1.5 uppercase">ACTIVITY LEVEL</label>
              <div className="grid grid-cols-3 gap-2">
                {(['LOW', 'ACTIVE', 'WORKING'] as const).map(act => (
                  <button
                    key={act}
                    type="button"
                    onClick={() => setActivity(act)}
                    className={`p-2 border text-xs text-center font-bold font-mono transition-colors cursor-pointer ${
                      activity === act 
                        ? 'border-hot-orange bg-hot-orange/10 text-bone' 
                        : 'border-steel-grey/30 text-steel-grey hover:border-steel-grey'
                    }`}
                  >
                    {act}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col">
              <label className="text-[10px] text-steel-grey mb-1.5 uppercase">ALLERGIES / PROTEIN EXCLUSIONS</label>
              <input 
                type="text" 
                placeholder="e.g. Grain, Beef, Salmon (or leave blank)"
                value={allergies}
                onChange={(e) => setAllergies(e.target.value)}
                className="bg-steel-charcoal/80 border border-steel-grey/30 p-2.5 text-sm text-bone focus:border-hot-orange outline-none"
              />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full bg-hot-orange text-steel-charcoal font-extrabold p-3 text-sm tracking-widest hover:bg-hot-orange/90 transition-colors uppercase cursor-pointer"
          >
            COMPILE PROFILE
          </button>
        </form>
      ) : (
        <div className="space-y-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-steel-charcoal/40 border border-steel-grey/20 p-4 gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Activity className="w-5 h-5 text-hot-orange animate-pulse" />
                <span className="text-sm font-bold text-bone uppercase">{dogProfile.name} — {dogProfile.breed}</span>
              </div>
              <div className="text-xs text-steel-grey flex flex-wrap gap-x-4 gap-y-1">
                <span>AGE: {dogProfile.age} YEARS</span>
                <span>WEIGHT: {dogProfile.weight} KG</span>
                <span>ACTIVITY: {dogProfile.activityLevel}</span>
                {dogProfile.allergies && <span className="text-mboro-brick">EXCLUDES: {dogProfile.allergies}</span>}
              </div>
            </div>
            <button 
              onClick={clearDogProfile}
              className="text-xs text-mboro-brick hover:underline uppercase font-bold cursor-pointer"
            >
              RESET PROFILE
            </button>
          </div>

          <div className="text-xs text-steel-grey bg-steel-charcoal/30 border border-dashed border-steel-grey/20 p-3 italic">
            * Recommended feed parameters configured successfully. Dog Profile compatible listings activated across product store screens. For specific clinical dietary or veterinary health concerns, always consult your vet.
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// 9. JOURNAL CARD (Section 47)
// ============================================================================
export function JournalCard({ title, category, readTime, excerpt, bgImgClass }: { title: string; category: string; readTime: string; excerpt: string; bgImgClass: string }) {
  return (
    <div className="border border-steel-grey/20 bg-steel-charcoal flex flex-col justify-between h-96 group hover:border-hot-orange/40 transition-colors">
      <div className={`h-48 relative overflow-hidden ${bgImgClass} bg-cover bg-center`}>
        {/* Soft overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-steel-charcoal via-steel-charcoal/40 to-transparent" />
        <span className="absolute bottom-3 left-4 font-mono text-[10px] tracking-widest text-hot-orange uppercase">
          {category}
        </span>
      </div>

      <div className="p-5 flex flex-col justify-between flex-1">
        <div>
          <h4 className="font-bold text-base text-bone tracking-tight mb-2 group-hover:text-hot-orange transition-colors">
            {title}
          </h4>
          <p className="text-xs text-steel-grey line-clamp-3 font-sans leading-relaxed">{excerpt}</p>
        </div>
        <div className="flex justify-between items-center font-mono text-[10px] text-steel-grey pt-3 border-t border-steel-grey/15 mt-3">
          <span>{readTime}</span>
          <span className="flex items-center gap-1 group-hover:text-bone transition-colors uppercase font-bold cursor-pointer">
            READ ARTICLE <ArrowRight className="w-3 h-3 text-hot-orange" />
          </span>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// 10. FOOTER (Section 61-62)
// ============================================================================
export function Footer() {
  const { loginAsTrade, activeTradeAccount, logoutTrade } = useApp();

  return (
    <footer className="bg-steel-charcoal border-t border-steel-grey/20 text-bone pt-16 pb-8 font-mono">
      <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 md:grid-cols-4 gap-8 pb-12 border-b border-steel-grey/15">
        {/* Col 1 */}
        <div className="md:col-span-2 space-y-4">
          <h4 className="text-xl font-extrabold tracking-tight">
            TEES VALLEY<br />
            DOG CO.
          </h4>
          <p className="text-xs text-steel-grey font-sans max-w-sm leading-relaxed">
            Premium British dog-food engineered using high-quality ingredients, with a strong manufacturing identity rooted in Middlesbrough and the wider Teesside North East industrial landscape.
          </p>
          <div className="text-[11px] text-steel-grey flex items-center gap-1 uppercase">
            <MapPin className="w-4 h-4 text-mboro-brick" />
            <span>MIDDLEHAVEN DOCK, MIDDLESBROUGH, TEESSIDE, TS2</span>
          </div>
        </div>

        {/* Col 2 */}
        <div>
          <span className="text-[10px] text-hot-orange tracking-widest block mb-4 uppercase">NAVIGATION</span>
          <ul className="space-y-2 text-xs font-sans text-steel-grey">
            <li><a href="#shop" className="hover:text-bone transition-colors block">B2C SHOP CATALOGUE</a></li>
            <li><a href="#manufacturing" className="hover:text-bone transition-colors block">MANUFACTURING TIMELINE</a></li>
            <li><a href="#dog-profile" className="hover:text-bone transition-colors block">DOG NUTRITION ENGINE</a></li>
            <li><a href="#about" className="hover:text-bone transition-colors block">BUILT IN TEESSIDE</a></li>
            <li><a href="#traceability" className="hover:text-bone transition-colors block">BATCH TRACKER</a></li>
          </ul>
        </div>

        {/* Col 3 */}
        <div>
          <span className="text-[10px] text-hot-orange tracking-widest block mb-4 uppercase">DEVELOPER QUICK LOGIN (B2B)</span>
          <p className="text-[10px] font-sans text-steel-grey mb-3">Click below to instantly simulate active trade portal login states.</p>
          
          {activeTradeAccount ? (
            <div className="bg-tees-blue/20 border border-tees-blue/60 p-3 flex flex-col gap-2">
              <div className="text-[10px] text-bone font-bold block truncate">{activeTradeAccount.companyName}</div>
              <button 
                onClick={logoutTrade}
                className="text-[10px] font-bold text-mboro-brick uppercase tracking-wider hover:underline block text-left cursor-pointer"
              >
                LOGOUT TRADE VIEW
              </button>
            </div>
          ) : (
            <div className="flex flex-col gap-1.5">
              <button 
                onClick={() => loginAsTrade("trade-201")}
                className="text-[10px] font-semibold text-left text-hot-orange hover:text-bone uppercase border border-steel-grey/30 hover:border-hot-orange p-1.5 bg-steel-charcoal/50 block w-full truncate cursor-pointer"
              >
                LOG IN: Middlesbrough Pet Supplies (Distributor)
              </button>
              <button 
                onClick={() => loginAsTrade("trade-202")}
                className="text-[10px] font-semibold text-left text-hot-orange hover:text-bone uppercase border border-steel-grey/30 hover:border-hot-orange p-1.5 bg-steel-charcoal/50 block w-full truncate cursor-pointer"
              >
                LOG IN: Stockton-on-Tees Vets (Wholesale)
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] text-steel-grey">
        <div>
          © 2026 TEES VALLEY DOG CO. LTD. ALL RIGHTS RESERVED. REGISTERED IN ENGLAND & WALES.
        </div>
        <div className="flex gap-4">
          <span className="text-steel-grey uppercase">MADE FOR REAL DOGS. BUILT IN TEESSIDE.</span>
        </div>
      </div>
    </footer>
  );
}

// ============================================================================
// 11. TOP NAVIGATION CONTROLLER (Section 2, 27, 32)
// ============================================================================
export function Navigation() {
  const { viewMode, setViewMode, cart, b2bCart, activeTradeAccount, logoutTrade } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const totalB2cItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalB2bItems = b2bCart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <header className="bg-steel-charcoal border-b border-steel-grey/20 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between font-mono">
        {/* Zone 1: Single element brand wordmark */}
        <a href="/" className="flex flex-col select-none group">
          <span className="text-base font-black tracking-tighter text-bone leading-none group-hover:text-hot-orange transition-colors">TEES VALLEY</span>
          <span className="text-xs font-bold tracking-widest text-hot-orange leading-none mt-0.5">DOG CO.</span>
        </a>

        {/* Zone 2: Navigation Links (Text with hover underlines, 1-2 words) */}
        <nav className="hidden lg:flex items-center gap-8 text-xs tracking-widest uppercase font-bold text-steel-grey">
          <a href="#shop" className="hover:text-bone hover:underline decoration-hot-orange decoration-2 transition-all">B2C SHOP</a>
          <a href="#dog-profile" className="hover:text-bone hover:underline decoration-hot-orange decoration-2 transition-all">NUTRITION ENGINE</a>
          <a href="#manufacturing" className="hover:text-bone hover:underline decoration-hot-orange decoration-2 transition-all">FACTORY LINE</a>
          <a href="#traceability" className="hover:text-bone hover:underline decoration-hot-orange decoration-2 transition-all">TRACEABILITY</a>
          <a href="#trade" className="hover:text-bone hover:underline decoration-hot-orange decoration-2 transition-all">B2B TRADE PORTAL</a>
        </nav>

        {/* Zone 3: Navigation Actions */}
        <div className="flex items-center gap-3">
          {/* Mode Switcher */}
          <div className="flex items-center bg-steel-charcoal/90 border border-steel-grey/30 p-0.5 text-[10px] font-bold">
            <button 
              onClick={() => setViewMode('b2c')}
              className={`px-2 py-1 uppercase cursor-pointer ${viewMode === 'b2c' ? 'bg-hot-orange text-steel-charcoal font-black' : 'text-steel-grey hover:text-bone'}`}
            >
              RETAIL
            </button>
            <button 
              onClick={() => setViewMode('b2b')}
              className={`px-2 py-1 uppercase cursor-pointer ${viewMode === 'b2b' ? 'bg-mboro-brick text-bone font-black' : 'text-steel-grey hover:text-bone'}`}
            >
              TRADE
            </button>
          </div>

          {/* Cart Indicators */}
          {viewMode === 'b2c' ? (
            <a 
              href="#cart-section" 
              className="relative p-2 border border-steel-grey/20 hover:border-hot-orange transition-colors group flex items-center gap-1.5"
              aria-label="Shopping bag"
            >
              <ShoppingBag className="w-4 h-4 text-bone group-hover:text-hot-orange transition-colors" />
              {totalB2cItems > 0 && (
                <span className="text-[10px] font-bold text-hot-orange tabular-nums">{totalB2cItems}</span>
              )}
            </a>
          ) : (
            <a 
              href="#trade-order-builder" 
              className="relative p-2 border border-steel-grey/20 hover:border-mboro-brick transition-colors group flex items-center gap-1.5"
              aria-label="Trade bag"
            >
              <ShoppingBag className="w-4 h-4 text-bone group-hover:text-mboro-brick transition-colors" />
              {totalB2bItems > 0 && (
                <span className="text-[10px] font-bold text-mboro-brick tabular-nums">{totalB2bItems} CS</span>
              )}
            </a>
          )}

          {/* Trade Identity Badge or General Tag */}
          {activeTradeAccount ? (
            <div className="hidden md:flex items-center gap-2 border border-mboro-brick bg-mboro-brick/10 px-3 py-1.5">
              <span className="text-[10px] text-mboro-brick font-bold block animate-pulse">● TRADE SECURE</span>
              <span className="text-[10px] text-bone max-w-[100px] truncate">{activeTradeAccount.companyName}</span>
            </div>
          ) : (
            <div className="hidden md:block text-[10px] border border-steel-grey/20 px-3 py-1.5 text-steel-grey">
              TS2 / MIDDLESBROUGH
            </div>
          )}

          {/* Mobile Hamburguer */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-bone hover:text-hot-orange"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="lg:hidden bg-steel-charcoal border-b border-steel-grey/20 font-mono text-xs overflow-hidden"
          >
            <div className="px-4 py-4 space-y-3 flex flex-col">
              <a href="#shop" onClick={() => setMobileMenuOpen(false)} className="py-2 text-bone hover:text-hot-orange border-b border-steel-grey/10">B2C SHOP</a>
              <a href="#dog-profile" onClick={() => setMobileMenuOpen(false)} className="py-2 text-bone hover:text-hot-orange border-b border-steel-grey/10">NUTRITION ENGINE</a>
              <a href="#manufacturing" onClick={() => setMobileMenuOpen(false)} className="py-2 text-bone hover:text-hot-orange border-b border-steel-grey/10">FACTORY LINE</a>
              <a href="#traceability" onClick={() => setMobileMenuOpen(false)} className="py-2 text-bone hover:text-hot-orange border-b border-steel-grey/10">TRACEABILITY</a>
              <a href="#trade" onClick={() => setMobileMenuOpen(false)} className="py-2 text-bone hover:text-hot-orange">B2B TRADE PORTAL</a>
              
              {activeTradeAccount && (
                <div className="bg-mboro-brick/10 border border-mboro-brick/40 p-3 flex justify-between items-center">
                  <div className="text-[10px]">
                    <span className="text-mboro-brick font-black block">LOGGED IN TRADE</span>
                    <span className="text-bone">{activeTradeAccount.companyName}</span>
                  </div>
                  <button 
                    onClick={() => { logoutTrade(); setMobileMenuOpen(false); }}
                    className="text-[10px] font-bold text-mboro-brick underline cursor-pointer"
                  >
                    LOGOUT
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
