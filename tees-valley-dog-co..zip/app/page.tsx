'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingBag, 
  ArrowRight, 
  Sparkles, 
  Check, 
  Plus, 
  Minus, 
  X, 
  TrendingUp, 
  Lock, 
  Activity, 
  Info, 
  Clock, 
  Download, 
  UserPlus, 
  Heart,
  ChevronRight,
  ShieldCheck,
  Calendar,
  Layers,
  MapPin,
  Search
} from 'lucide-react';
import { useApp } from '@/lib/AppContext';
import { Product, products, tradeAccounts } from '@/lib/data';
import { 
  Navigation, 
  TechnicalLabel, 
  NutritionPanel, 
  IngredientCard, 
  ManufacturingTimeline, 
  MarginCalculator, 
  TraceabilityTimeline, 
  DeliveryTracker, 
  DogProfileComponent, 
  JournalCard, 
  Footer 
} from '@/components/TeesComponents';

export default function Home() {
  const {
    viewMode,
    setViewMode,
    cart,
    addToCart,
    removeFromCart,
    updateCartQty,
    clearCart,
    dogProfile,
    recommendedProducts,
    activeTradeAccount,
    loginAsTrade,
    logoutTrade,
    b2bCart,
    addToB2bCart,
    updateB2bCartQty,
    removeFromB2bCart,
    clearB2bCart,
    orders,
    invoices,
    subscriptions,
    submitB2COrder,
    submitB2BOrder,
    payInvoice,
    pauseSubscription,
    resumeSubscription,
    cancelSubscription,
    selectedProduct,
    setSelectedProduct
  } = useApp();

  // Navigation / active section sub-state inside B2C or B2B
  const [b2cActiveTab, setB2cActiveTab] = useState<'ALL' | 'PUPPY' | 'ADULT' | 'SENIOR' | 'WORKING'>('ALL');
  const [proteinFilter, setProteinFilter] = useState<string>('ALL');
  const [sizeFilter, setSizeFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Checkout modal/drawer states
  const [isB2cCartOpen, setIsB2cCartOpen] = useState(false);
  const [isB2cCheckoutOpen, setIsB2cCheckoutOpen] = useState(false);
  const [b2cCheckoutStep, setB2cCheckoutStep] = useState<1 | 2>(1); // 1: Delivery, 2: Done
  
  // Checkout Fields
  const [b2cName, setB2cName] = useState("");
  const [b2cEmail, setB2cEmail] = useState("");
  const [b2cAddress, setB2cAddress] = useState("");
  const [b2cPostcode, setB2cPostcode] = useState("");
  const [b2cSelectedSubId, setB2cSelectedSubId] = useState<string | null>(null);
  const [b2cCreatedOrder, setB2cCreatedOrder] = useState<any>(null);

  // B2B fields
  const [poReference, setPoReference] = useState("");
  const [isB2bCheckoutOpen, setIsB2bCheckoutOpen] = useState(false);
  const [b2bCreatedOrder, setB2bCreatedOrder] = useState<any>(null);

  // Trade Registration
  const [tradeRegName, setTradeRegName] = useState("");
  const [tradeRegCompany, setTradeRegCompany] = useState("");
  const [tradeRegEmail, setTradeRegEmail] = useState("");
  const [tradeRegVolume, setTradeRegVolume] = useState("Under 50 bags");
  const [tradeRegDone, setTradeRegDone] = useState(false);

  // Active tracking order ID selection
  const [trackingOrderId, setTrackingOrderId] = useState<string>("TV-ORD-20481");

  // Filtered Products for B2C Catalog
  const filteredProducts = React.useMemo(() => {
    return products.filter(p => {
      // Search
      if (searchQuery && !p.name.toLowerCase().includes(searchQuery.toLowerCase()) && !p.sku.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      // Tab Category
      if (b2cActiveTab !== 'ALL' && p.lifeStage !== b2cActiveTab) {
        return false;
      }
      // Protein
      if (proteinFilter !== 'ALL' && p.proteinSource !== proteinFilter) {
        return false;
      }
      // Size
      if (sizeFilter !== 'ALL' && p.bagSize !== sizeFilter) {
        return false;
      }
      return true;
    });
  }, [b2cActiveTab, proteinFilter, sizeFilter, searchQuery]);

  // Pricing helper based on active trade level
  const getB2bPrice = (p: Product) => {
    if (!activeTradeAccount) return p.tradePrice;
    if (activeTradeAccount.tier === 'DISTRIBUTOR') return p.distributorPrice;
    if (activeTradeAccount.tier === 'WHOLESALE') return p.wholesalePrice;
    return p.tradePrice;
  };

  const getB2bPriceLabel = () => {
    if (!activeTradeAccount) return "Trade Rate";
    if (activeTradeAccount.tier === 'DISTRIBUTOR') return "Distributor Rate (-36%)";
    if (activeTradeAccount.tier === 'WHOLESALE') return "Wholesale Rate (-31%)";
    return "Trade Standard (-24%)";
  };

  const selectedOrderToTrack = orders.find(o => o.id === trackingOrderId) || orders[0];

  return (
    <main className="min-h-screen bg-steel-charcoal text-bone selection:bg-hot-orange selection:text-steel-charcoal font-sans">
      <Navigation />

      {/* Hero Announcement Banner */}
      <div className="bg-hot-orange text-steel-charcoal font-mono text-[10px] tracking-widest text-center py-2.5 px-4 font-black flex items-center justify-center gap-2 relative">
        <span>MIDDLESBROUGH / TEESSIDE LOGISTICS HUB ACTIVE</span>
        <span className="hidden md:inline">·</span>
        <span className="hidden md:inline">ESTABLISHED 2026</span>
        <span className="hidden md:inline">·</span>
        <span className="hidden md:inline">PROPER FOOD FOR PROPER DOGS</span>
        <div className="absolute right-4 hidden lg:flex items-center gap-1.5 bg-steel-charcoal text-bone px-2 py-0.5 font-bold uppercase text-[9px]">
          <Activity className="w-3 h-3 text-hot-orange animate-pulse" />
          <span>PLANT TEMPERATURE: 74°C</span>
        </div>
      </div>

      {/* ======================================================================
          HERO SECTION (Middlesbrough Hypermodernism Split Screen, Sections 9-13)
          ====================================================================== */}
      <section className="relative bg-tees-blue min-h-[85vh] flex flex-col justify-center overflow-hidden border-b border-steel-grey/30">
        {/* Subtle structural architectural geometry background lines (Section 11/12) */}
        <div className="absolute inset-0 opacity-15 pointer-events-none z-0">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            {/* Horizontal Span grid (Transporter Bridge DNA) */}
            <line x1="0" y1="20%" x2="100%" y2="20%" stroke="#D7D4CD" strokeWidth="2" strokeDasharray="5,5" />
            <line x1="0" y1="60%" x2="100%" y2="60%" stroke="#D7D4CD" strokeWidth="1" />
            <line x1="20%" y1="0" x2="20%" y2="100%" stroke="#D7D4CD" strokeWidth="1" strokeDasharray="10,5" />
            <line x1="75%" y1="0" x2="75%" y2="100%" stroke="#D7D4CD" strokeWidth="2" />
            
            {/* Bridge diagonal truss system */}
            <line x1="20%" y1="20%" x2="35%" y2="60%" stroke="#E66A24" strokeWidth="1.5" />
            <line x1="50%" y1="20%" x2="35%" y2="60%" stroke="#E66A24" strokeWidth="1.5" />
            <line x1="50%" y1="20%" x2="65%" y2="60%" stroke="#E66A24" strokeWidth="1.5" />
            <line x1="75%" y1="20%" x2="65%" y2="60%" stroke="#E66A24" strokeWidth="1.5" />
          </svg>
        </div>

        {/* Content container */}
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-16 w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
          {/* Left Split Column */}
          <div className="lg:col-span-6 space-y-6 flex flex-col justify-center">
            <div className="font-mono text-xs text-hot-orange tracking-widest uppercase flex items-center gap-2">
              <span>ESTABLISHED MIDDLESBROUGH / 2026</span>
              <span>·</span>
              <span className="text-bone">COMPLETE FEED SYSTEM</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-black text-bone tracking-tighter leading-none uppercase">
              PROPER <br />
              <span className="text-hot-orange">FOOD.</span>
            </h1>

            <p className="text-base md:text-lg text-bone/90 font-sans max-w-lg leading-relaxed">
              Premium British formulation built around clean local proteins and slow-release Teesside grains. Engineered for dogs that actually live. No countryside cosplay, just high-performance food science.
            </p>

            <div className="flex flex-wrap gap-4 pt-4">
              <a 
                href="#shop" 
                className="bg-hot-orange hover:bg-hot-orange/90 text-steel-charcoal font-black tracking-widest text-xs px-8 py-4 uppercase flex items-center gap-2 transition-all cursor-pointer"
              >
                SHOP RETAIL <ArrowRight className="w-4 h-4" />
              </a>
              <a 
                href="#trade" 
                className="bg-steel-charcoal hover:bg-steel-charcoal/80 text-bone border border-steel-grey/40 hover:border-bone font-bold tracking-widest text-xs px-8 py-4 uppercase transition-all cursor-pointer"
              >
                B2B TRADE PLATFORM
              </a>
            </div>

            {/* Industrial metadata footer stats */}
            <div className="grid grid-cols-3 gap-3 border-t border-steel-grey/30 pt-6 mt-8">
              <TechnicalLabel label="PROTEIN BASE" value="28% Complete" />
              <TechnicalLabel label="TRACED TO" value="North Yorkshire" />
              <TechnicalLabel label="STANDARDS" value="ISO 9001 APPROVED" />
            </div>
          </div>

          {/* Right Split Column: Spectacular Dog Photo inside clean Modern Warehouse (Section 9) */}
          <div className="lg:col-span-6 relative flex justify-center">
            <div className="relative border-4 border-steel-charcoal bg-steel-charcoal p-2 max-w-md md:max-w-lg overflow-hidden group hover:border-hot-orange transition-colors">
              {/* Corner industrial markers */}
              <div className="absolute top-0 left-0 w-3 h-3 bg-hot-orange" />
              <div className="absolute bottom-0 right-0 w-3 h-3 bg-hot-orange" />

              <img 
                src="/images/hero_industrial_dog.jpg" 
                alt="Robust dog in a modern industrial architectural setting in Teesside" 
                className="w-full h-[350px] md:h-[450px] object-cover filter contrast-105 saturate-95 group-hover:scale-[1.02] transition-transform duration-700"
                referrerPolicy="no-referrer"
              />

              {/* Float box with packaging snippet */}
              <div className="absolute bottom-4 left-4 right-4 bg-steel-charcoal/90 backdrop-blur-xs border border-steel-grey/30 p-4 font-mono flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-hot-orange tracking-wider block">PACKAGING SPECIFICATION</span>
                  <span className="text-xs font-bold text-bone">TEES VALLEY ADULT CHICKEN & OAT</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-steel-grey block">NET WEIGHT</span>
                  <span className="text-xs font-bold text-bone">12.0 KG</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ======================================================================
          RETAIL (B2C) EXPERIENCE
          ====================================================================== */}
      {viewMode === 'b2c' ? (
        <div className="space-y-24 py-16">
          
          {/* ==================================================================
              DOG PROFILE NUTRITION ENGINE (Section 30)
              ================================================================== */}
          <section id="dog-profile" className="max-w-7xl mx-auto px-4 md:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              <div className="lg:col-span-5 space-y-6">
                <span className="text-xs text-hot-orange font-mono tracking-widest block uppercase">01. COMPATIBILITY ENGINE</span>
                <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight text-bone uppercase">
                  DETERMINISTIC DOG FORMULATION MATCHING
                </h2>
                <p className="text-sm font-sans text-steel-grey leading-relaxed">
                  Provide your dog&apos;s physical specification parameters (weight, breed, age, activity index) and potential ingredient restrictions. Our system will instantly lock onto the optimal formulation for muscle building, joint security, and carbohydrate slow-release.
                </p>
                
                {dogProfile && (
                  <div className="bg-concrete p-5 text-steel-charcoal space-y-3 font-mono">
                    <div className="text-xs font-bold uppercase tracking-wider text-mboro-brick">ACTIVE RECOMMENDATION SYSTEM ACTIVE</div>
                    <div className="text-base font-black uppercase">{dogProfile.name}&apos;S SUGGESTIONS ACTIVATED</div>
                    <p className="text-xs font-sans">We are prioritizing high-protein, zero-{dogProfile.allergies || 'grain'} formulations matching your {dogProfile.breed} companion.</p>
                    <a href="#shop" className="text-xs font-bold text-mboro-brick flex items-center gap-1 hover:underline uppercase">
                      VIEW FILTERED CATALOGUE <ChevronRight className="w-4 h-4" />
                    </a>
                  </div>
                )}
              </div>
              <div className="lg:col-span-7">
                <DogProfileComponent />
              </div>
            </div>
          </section>

          {/* ==================================================================
              B2C CATALOGUE & PRODUCT SYSTEM (Section 14-17, 28)
              ================================================================== */}
          <section id="shop" className="max-w-7xl mx-auto px-4 md:px-8 scroll-mt-20">
            <div className="border-b border-steel-grey/20 pb-6 mb-10 flex flex-col lg:flex-row justify-between items-start lg:items-end gap-6">
              <div>
                <span className="text-xs text-hot-orange font-mono tracking-widest block uppercase">02. PRODUCT SYSTEM</span>
                <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight text-bone">THE FORMULATION DIRECTORY</h2>
                <p className="text-xs font-mono text-steel-grey mt-1">
                  Showing {filteredProducts.length} premium bags produced in Middlesbrough.
                </p>
              </div>

              {/* Text filters - Unboxed buttons as segments, no pills (Section 1A) */}
              <div className="flex flex-wrap gap-2 items-center bg-steel-charcoal/90 border border-steel-grey/20 p-1 font-mono text-xs">
                {(['ALL', 'PUPPY', 'ADULT', 'SENIOR', 'WORKING'] as const).map(tab => (
                  <button
                    key={tab}
                    onClick={() => setB2cActiveTab(tab)}
                    className={`px-3 py-1.5 uppercase transition-colors font-bold cursor-pointer ${
                      b2cActiveTab === tab 
                        ? 'bg-hot-orange text-steel-charcoal' 
                        : 'text-steel-grey hover:text-bone'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            {/* Advanced filtering bar */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-10 font-mono text-xs">
              {/* Search Bar */}
              <div className="relative md:col-span-2">
                <input 
                  type="text"
                  placeholder="Search products by formulation, ingredient, or SKU..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-steel-charcoal border border-steel-grey/30 p-3 pl-10 text-bone outline-none focus:border-hot-orange"
                />
                <Search className="absolute left-3 top-3.5 w-4.5 h-4.5 text-steel-grey" />
              </div>

              {/* Protein Filter */}
              <div>
                <select
                  value={proteinFilter}
                  onChange={(e) => setProteinFilter(e.target.value)}
                  className="w-full bg-steel-charcoal border border-steel-grey/30 p-3 text-bone outline-none focus:border-hot-orange cursor-pointer"
                >
                  <option value="ALL">PROTEIN SOURCE: ALL</option>
                  <option value="Chicken">Chicken</option>
                  <option value="Turkey">Turkey</option>
                  <option value="Salmon">Salmon</option>
                  <option value="Lamb">Lamb</option>
                  <option value="Beef">Beef</option>
                </select>
              </div>

              {/* Size Filter */}
              <div>
                <select
                  value={sizeFilter}
                  onChange={(e) => setSizeFilter(e.target.value)}
                  className="w-full bg-steel-charcoal border border-steel-grey/30 p-3 text-bone outline-none focus:border-hot-orange cursor-pointer"
                >
                  <option value="ALL">BAG SIZE: ALL</option>
                  <option value="1.5kg">1.5kg Bag</option>
                  <option value="6kg">6kg Bag</option>
                  <option value="12kg">12kg Bag</option>
                </select>
              </div>
            </div>

            {/* Product Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map(product => {
                // Check if this matches dog recommendations to place an unboxed trust marker (Section 1A)
                const isRecommended = recommendedProducts.some(rp => rp.id === product.id);

                return (
                  <div 
                    key={product.id}
                    className="bg-steel-charcoal border border-steel-grey/20 flex flex-col justify-between group hover:border-hot-orange/40 transition-all duration-300 relative"
                  >
                    {isRecommended && (
                      <div className="absolute top-2 left-2 z-10 bg-mboro-brick text-bone font-mono text-[9px] font-bold px-2 py-0.5 tracking-widest uppercase">
                        IDEAL FOR {dogProfile?.name || 'MY DOG'}
                      </div>
                    )}

                    {/* Image Area */}
                    <div 
                      onClick={() => setSelectedProduct(product)}
                      className="bg-concrete h-56 relative overflow-hidden flex items-center justify-center p-6 cursor-pointer"
                    >
                      <img 
                        src="/images/product_dog_food_bag.jpg" 
                        alt={product.name} 
                        className="h-full object-contain filter drop-shadow-xl group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-steel-charcoal/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <span className="bg-steel-charcoal/90 border border-steel-grey/30 text-bone font-mono text-[10px] tracking-widest px-3 py-1.5 uppercase font-bold">
                          VIEW SPECS
                        </span>
                      </div>
                    </div>

                    {/* Content area */}
                    <div className="p-5 flex flex-col justify-between flex-1 font-mono">
                      <div className="space-y-1.5">
                        <div className="flex justify-between items-baseline text-[10px] text-steel-grey uppercase font-bold">
                          <span>{product.lifeStage} · {product.bagSize}</span>
                          <span className="text-hot-orange">IN STOCK</span>
                        </div>
                        <h3 
                          onClick={() => setSelectedProduct(product)}
                          className="font-black text-sm text-bone group-hover:text-hot-orange transition-colors cursor-pointer uppercase tracking-tight line-clamp-1"
                        >
                          {product.name}
                        </h3>
                        <p className="text-[10px] font-sans text-steel-grey line-clamp-2 leading-relaxed">
                          {product.description}
                        </p>
                      </div>

                      {/* Pricing + Add row */}
                      <div className="pt-4 border-t border-steel-grey/10 mt-4 flex items-center justify-between">
                        <span className="text-base font-extrabold text-bone tabular-nums">
                          £{product.price.toFixed(2)}
                        </span>
                        <button 
                          onClick={() => addToCart(product, 1)}
                          className="bg-steel-charcoal border border-steel-grey/40 hover:border-hot-orange hover:text-hot-orange text-bone font-bold text-[10px] tracking-widest px-3 py-2 uppercase transition-all cursor-pointer"
                        >
                          ADD TO BAG
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}

              {filteredProducts.length === 0 && (
                <div className="col-span-full border border-dashed border-steel-grey/30 p-12 text-center text-steel-grey font-mono text-xs">
                  NO SPECIALIZED FORMULATIONS MATCHED YOUR CORRESPONDING SEARCH FILTERS.
                </div>
              )}
            </div>
          </section>

          {/* ==================================================================
              NEVER RUN OUT SUBSCRIPTION (Section 29)
              ================================================================== */}
          <section className="bg-tees-blue/15 border-y border-steel-grey/25 py-16">
            <div className="max-w-7xl mx-auto px-4 md:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                <div className="lg:col-span-6 space-y-6">
                  <span className="text-xs text-hot-orange font-mono tracking-widest block uppercase">03. RECURRING SUPPLY</span>
                  <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight text-bone uppercase">
                    NEVER RUN OUT LOGISTICS
                  </h2>
                  <p className="text-sm font-sans text-steel-grey leading-relaxed">
                    Working dogs and active companions consume fuel on an extremely predictable, mathematical cycle. Save <strong className="text-hot-orange">10% on every order</strong> with our direct recurring bag subscriptions. Managed completely through your Middlehaven secure interface. Pause, edit, or cancel instantly with zero fees.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 font-mono">
                    <div className="border border-steel-grey/25 p-4">
                      <span className="text-[10px] text-hot-orange block uppercase font-bold mb-1">CONVENIENT INTERVALS</span>
                      <span className="text-xs text-bone block">2, 4, 6, or 8 weeks cycle</span>
                    </div>
                    <div className="border border-steel-grey/25 p-4">
                      <span className="text-[10px] text-hot-orange block uppercase font-bold mb-1">AUTOMATIC FREIGHT</span>
                      <span className="text-xs text-bone block">Direct Middlesbrough dispatch</span>
                    </div>
                  </div>
                </div>

                {/* Subscriptions Panel */}
                <div className="lg:col-span-6">
                  <div className="bg-steel-charcoal border border-steel-grey/20 p-6 md:p-8 font-mono">
                    <div className="border-b border-steel-grey/20 pb-4 mb-6">
                      <h3 className="text-lg font-bold text-bone uppercase">YOUR ACTIVE FREIGHT RECURRENCES</h3>
                      <p className="text-[11px] text-steel-grey">Simulating your active sub schedules</p>
                    </div>

                    <div className="space-y-4">
                      {subscriptions.map(sub => (
                        <div key={sub.id} className="border border-steel-grey/20 p-4 bg-steel-charcoal/40 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-[10px] bg-hot-orange text-steel-charcoal px-1.5 py-0.5 font-bold">{sub.id}</span>
                              <span className="text-xs font-bold text-bone uppercase">{sub.product.name.split(" — ")[0]}</span>
                            </div>
                            <div className="text-[11px] text-steel-grey flex flex-wrap gap-x-4">
                              <span>FOR: {sub.dogName}</span>
                              <span>CYCLE: {sub.interval}</span>
                              <span>NEXT SHIPMENT: {sub.nextDelivery}</span>
                            </div>
                          </div>

                          <div className="text-left md:text-right flex md:flex-col justify-between items-baseline md:items-end w-full md:w-auto gap-2 border-t md:border-t-0 border-steel-grey/10 pt-2 md:pt-0">
                            <span className="text-sm font-bold text-bone">£{sub.price.toFixed(2)}</span>
                            
                            <div className="flex gap-2">
                              {sub.status === 'ACTIVE' ? (
                                <button 
                                  onClick={() => pauseSubscription(sub.id)}
                                  className="text-[10px] text-amber-400 hover:underline uppercase font-bold cursor-pointer"
                                >
                                  PAUSE
                                </button>
                              ) : (
                                <button 
                                  onClick={() => resumeSubscription(sub.id)}
                                  className="text-[10px] text-emerald-400 hover:underline uppercase font-bold cursor-pointer"
                                >
                                  RESUME
                                </button>
                              )}
                              <button 
                                onClick={() => cancelSubscription(sub.id)}
                                className="text-[10px] text-mboro-brick hover:underline uppercase font-bold cursor-pointer"
                              >
                                CANCEL
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}

                      {subscriptions.length === 0 && (
                        <div className="p-8 text-center border border-dashed border-steel-grey/20 text-steel-grey text-xs">
                          NO ACTIVE RECURRING SUBSCRIPTIONS DETECTED. CHOOSE SUBSCRIPTION MODE IN DETAIL CARD TO ENROLL.
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* ==================================================================
              INGREDIENT PROVENANCE DECK (Section 19-20)
              ================================================================== */}
          <section className="max-w-7xl mx-auto px-4 md:px-8">
            <div className="border-b border-steel-grey/20 pb-6 mb-10">
              <span className="text-xs text-hot-orange font-mono tracking-widest block uppercase">04. FORMULATION TRACE</span>
              <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight text-bone">WHAT WE REFINE INTO KIBBLE</h2>
              <p className="text-xs font-mono text-steel-grey mt-1">
                A non-compromising review of the primary metabolic building blocks processed inside Middlehaven docks.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <IngredientCard 
                name="Fresh British Chicken" 
                percentage={35} 
                source="North Yorkshire Fields" 
                functionText="Provides dense amino acids to rebuild muscular and heart tissue in highly active town companions." 
              />
              <IngredientCard 
                name="Atlantic Sourced Salmon" 
                percentage={28} 
                source="Peterhead Harbours" 
                functionText="High concentrations of Omegas 3 & 6 promoting deep skin lipid repair and high-density coat luster." 
              />
              <IngredientCard 
                name="Teesside Rolled Oats" 
                percentage={25} 
                source="Darlington Arable Farms" 
                functionText="Unprocessed, complex carbohydrates providing slow-release glucose lines without causing blood sugar spikes." 
              />
              <IngredientCard 
                name="Glucosamine & Joint Pack" 
                percentage={2} 
                source="Teesside Bio-Labs" 
                functionText="Metabolic catalysts supporting cartilage structure protection and ease of motion as dogs age." 
              />
            </div>
          </section>

          {/* ==================================================================
              B2C CART SECTION & CHECKOUT SYSTEM (Section 31)
              ================================================================== */}
          <section id="cart-section" className="max-w-7xl mx-auto px-4 md:px-8 scroll-mt-20">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
              {/* Bag View */}
              <div className="lg:col-span-7 space-y-6">
                <div className="border-b border-steel-grey/25 pb-4">
                  <h3 className="text-2xl font-black text-bone uppercase">YOUR RETAIL DISPATCH BAG</h3>
                  <p className="text-xs text-steel-grey font-mono">Verify your bags prior to shipping channel allocation</p>
                </div>

                <div className="space-y-4 font-mono">
                  {cart.map((item, idx) => (
                    <div key={`${item.product.id}-${idx}`} className="border border-steel-grey/20 p-4 bg-steel-charcoal/20 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-bone uppercase">{item.product.name}</span>
                          {item.isSubscription && (
                            <span className="bg-hot-orange text-steel-charcoal text-[9px] font-bold px-1.5 py-0.5">AUTO-DISPATCH</span>
                          )}
                        </div>
                        <p className="text-[10px] text-steel-grey mt-1">
                          SKU: {item.product.sku} · STAGE: {item.product.lifeStage} · SIZE: {item.product.bagSize}
                        </p>
                        {item.isSubscription && (
                          <p className="text-[10px] text-hot-orange mt-0.5 font-bold">RECURS EVERY {item.interval?.toUpperCase()}</p>
                        )}
                      </div>

                      <div className="flex items-center gap-6 justify-between w-full md:w-auto border-t md:border-t-0 border-steel-grey/10 pt-2 md:pt-0">
                        {/* Qty controller */}
                        <div className="flex items-center border border-steel-grey/30">
                          <button 
                            onClick={() => updateCartQty(item.product.id, item.quantity - 1, item.isSubscription)}
                            className="p-1.5 text-steel-grey hover:text-bone cursor-pointer"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="px-3 text-xs text-bone font-bold tabular-nums">{item.quantity}</span>
                          <button 
                            onClick={() => updateCartQty(item.product.id, item.quantity + 1, item.isSubscription)}
                            className="p-1.5 text-steel-grey hover:text-bone cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <div className="text-right">
                          <div className="text-sm font-bold text-bone tabular-nums">
                            £{(item.product.price * item.quantity).toFixed(2)}
                          </div>
                          <button 
                            onClick={() => removeFromCart(item.product.id, item.isSubscription)}
                            className="text-[10px] text-mboro-brick hover:underline uppercase block text-right mt-1 cursor-pointer"
                          >
                            REMOVE
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}

                  {cart.length === 0 && (
                    <div className="border border-dashed border-steel-grey/20 p-12 text-center text-steel-grey text-xs">
                      YOUR DISPATCH BAG IS COMPLETELY EMPTY. EXPLORE THE CATALOGUE ABOVE TO ALLOCATE CARGO.
                    </div>
                  )}
                </div>
              </div>

              {/* Instant checkout sidebar */}
              <div className="lg:col-span-5">
                <div className="bg-steel-charcoal border border-steel-grey/25 p-6 font-mono relative">
                  {cart.length > 0 && b2cCheckoutStep === 1 ? (
                    <div className="space-y-4">
                      <div className="border-b border-steel-grey/20 pb-3 mb-4">
                        <span className="text-[10px] text-hot-orange block uppercase font-bold">MIDDLEHAVEN SECURE DIRECT GATEWAY</span>
                        <h4 className="text-base font-bold text-bone">CHECKOUT SUMMARY</h4>
                      </div>

                      <div className="space-y-2 text-xs border-b border-steel-grey/15 pb-4 mb-4">
                        <div className="flex justify-between">
                          <span className="text-steel-grey">ITEMS VALUE</span>
                          <span className="text-bone tabular-nums">£{cart.reduce((sum, i) => sum + i.product.price * i.quantity, 0).toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-steel-grey">FREIGHT HANDLING</span>
                          <span className="text-emerald-400">FREE OVER £40</span>
                        </div>
                        {cart.some(i => i.isSubscription) && (
                          <div className="flex justify-between text-hot-orange font-bold">
                            <span>SUBSCRIPTION REBATE</span>
                            <span className="tabular-nums">-10% applied</span>
                          </div>
                        )}
                        <div className="flex justify-between text-sm font-bold border-t border-steel-grey/10 pt-2 mt-2">
                          <span>TOTAL SECURE ESTIMATE</span>
                          <span className="text-hot-orange tabular-nums">£{cart.reduce((sum, i) => sum + i.product.price * i.quantity, 0).toFixed(2)}</span>
                        </div>
                      </div>

                      {/* Checkout fields */}
                      <form onSubmit={(e) => {
                        e.preventDefault();
                        if (!b2cName || !b2cEmail || !b2cAddress) return;
                        const order = submitB2COrder({ fullName: b2cName, email: b2cEmail, address: b2cAddress, postcode: b2cPostcode });
                        setB2cCreatedOrder(order);
                        setB2cCheckoutStep(2);
                      }} className="space-y-3 font-sans">
                        <div className="flex flex-col font-mono text-xs">
                          <label className="text-[10px] text-steel-grey mb-1 uppercase">RECIPIENT FULL NAME</label>
                          <input 
                            type="text" 
                            required 
                            placeholder="e.g. Thomas Teasdale"
                            value={b2cName}
                            onChange={(e) => setB2cName(e.target.value)}
                            className="bg-steel-charcoal border border-steel-grey/30 p-2 text-xs text-bone outline-none focus:border-hot-orange"
                          />
                        </div>
                        <div className="flex flex-col font-mono text-xs">
                          <label className="text-[10px] text-steel-grey mb-1 uppercase">SECURE DISPATCH EMAIL</label>
                          <input 
                            type="email" 
                            required 
                            placeholder="e.g. tom@ahyx.org"
                            value={b2cEmail}
                            onChange={(e) => setB2cEmail(e.target.value)}
                            className="bg-steel-charcoal border border-steel-grey/30 p-2 text-xs text-bone outline-none focus:border-hot-orange"
                          />
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <div className="flex flex-col font-mono text-xs col-span-2">
                            <label className="text-[10px] text-steel-grey mb-1 uppercase">SHIPPING ADDRESS</label>
                            <input 
                              type="text" 
                              required 
                              placeholder="e.g. 42 Transporter Way"
                              value={b2cAddress}
                              onChange={(e) => setB2cAddress(e.target.value)}
                              className="bg-steel-charcoal border border-steel-grey/30 p-2 text-xs text-bone outline-none focus:border-hot-orange"
                            />
                          </div>
                          <div className="flex flex-col font-mono text-xs">
                            <label className="text-[10px] text-steel-grey mb-1 uppercase">POSTCODE</label>
                            <input 
                              type="text" 
                              required 
                              placeholder="e.g. TS1 1RE"
                              value={b2cPostcode}
                              onChange={(e) => setB2cPostcode(e.target.value)}
                              className="bg-steel-charcoal border border-steel-grey/30 p-2 text-xs text-bone outline-none focus:border-hot-orange"
                            />
                          </div>
                        </div>

                        <button 
                          type="submit"
                          className="w-full bg-hot-orange text-steel-charcoal font-black p-3.5 text-xs tracking-widest font-mono hover:bg-hot-orange/90 transition-all uppercase cursor-pointer"
                        >
                          CONFIRM SECURE SHIPMENT
                        </button>
                      </form>
                    </div>
                  ) : b2cCheckoutStep === 2 && b2cCreatedOrder ? (
                    <div className="space-y-6 text-center py-6">
                      <div className="w-12 h-12 bg-emerald-400/10 border border-emerald-400 flex items-center justify-center mx-auto rounded-full text-emerald-400">
                        <Check className="w-6 h-6" />
                      </div>
                      <div className="space-y-2">
                        <h4 className="text-base font-bold text-bone uppercase">CARGO SECURED & CONFIRMED</h4>
                        <p className="text-xs text-steel-grey font-sans">
                          Middlesbrough warehouse packing system has allocated order: <strong className="text-bone font-mono">{b2cCreatedOrder.id}</strong>. A simulated dispatch tracking line is active.
                        </p>
                      </div>

                      <div className="bg-steel-charcoal/50 p-4 border border-steel-grey/15 text-left font-mono text-xs">
                        <div className="flex justify-between border-b border-steel-grey/10 pb-1 mb-1">
                          <span>ORDER REF</span>
                          <span className="text-bone">{b2cCreatedOrder.id}</span>
                        </div>
                        <div className="flex justify-between border-b border-steel-grey/10 pb-1 mb-1">
                          <span>SHIPPED TO</span>
                          <span className="text-bone truncate max-w-[150px]">{b2cCreatedOrder.customerName}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>VALUE</span>
                          <span className="text-hot-orange">£{b2cCreatedOrder.total.toFixed(2)}</span>
                        </div>
                      </div>

                      <div className="flex flex-col gap-2">
                        <button 
                          onClick={() => {
                            setTrackingOrderId(b2cCreatedOrder.id);
                            const el = document.getElementById("logistics-tracking");
                            if (el) el.scrollIntoView({ behavior: "smooth" });
                          }}
                          className="w-full bg-tees-blue text-bone border border-tees-blue hover:border-bone p-2.5 text-xs font-mono uppercase font-black cursor-pointer"
                        >
                          TRACK REGIONAL ROUTE
                        </button>
                        <button 
                          onClick={() => {
                            setB2cCheckoutStep(1);
                            setB2cCreatedOrder(null);
                            setB2cName("");
                            setB2cEmail("");
                            setB2cAddress("");
                            setB2cPostcode("");
                          }}
                          className="text-[10px] text-steel-grey hover:underline font-mono uppercase cursor-pointer"
                        >
                          CLOSE RECEIPT
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12 font-mono text-xs text-steel-grey border border-dashed border-steel-grey/20">
                      ALLOCATE PREMIUM FORMULATION BAGS ABOVE TO ENABLE CHECKOUT ROUTE CONTEXTS.
                    </div>
                  )}
                </div>
              </div>
            </div>
          </section>

        </div>
      ) : (
        // ====================================================================
        // B2B TRADE PORTAL EXPERIENCE
        // ====================================================================
        <div className="space-y-24 py-16">
          
          {/* B2B Header & Lock State overlay (Section 32-33) */}
          <section id="trade" className="max-w-7xl mx-auto px-4 md:px-8">
            <div className="border border-steel-grey/25 bg-tees-blue/10 p-6 md:p-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-8 relative overflow-hidden">
              <div className="space-y-4 max-w-2xl relative z-10">
                <div className="flex items-center gap-2 font-mono text-xs text-mboro-brick font-black uppercase">
                  <Lock className="w-4 h-4" />
                  <span>B2B PROCUREMENT TERMINAL SECURE</span>
                </div>
                <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight text-bone">
                  FEED YOUR REGIONAL BUSINESS
                </h2>
                <p className="text-sm font-sans text-steel-grey leading-relaxed">
                  Wholesale and regional distributor pricing tiers designed specifically for independent pet retailers, working-dog suppliers, veterinarians, and canine boarding centers across the UK.
                </p>

                {activeTradeAccount && (
                  <div className="flex items-center gap-3 font-mono text-xs text-bone bg-mboro-brick/20 border border-mboro-brick/40 p-3 max-w-md">
                    <Check className="w-5 h-5 text-emerald-400 shrink-0" />
                    <div>
                      <span>LOGGED IN: <strong>{activeTradeAccount.companyName}</strong></span>
                      <span className="block text-[10px] text-steel-grey">ACCOUNT ID: {activeTradeAccount.accountNumber} · TIER: {activeTradeAccount.tier}</span>
                    </div>
                  </div>
                )}
              </div>

              {!activeTradeAccount ? (
                <div className="bg-steel-charcoal border border-steel-grey/30 p-6 w-full md:w-80 font-mono relative z-10">
                  <span className="text-[10px] text-hot-orange tracking-widest block mb-4 uppercase font-bold">SECURE PARTNER SIGN-IN</span>
                  <p className="text-[10px] font-sans text-steel-grey mb-4 leading-relaxed">Select a simulated trade partner in the website footer or below to log in and unlock custom bulk matrices.</p>
                  <button 
                    onClick={() => loginAsTrade("trade-201")}
                    className="w-full bg-mboro-brick hover:bg-mboro-brick/90 text-bone p-3 text-xs uppercase font-black tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    LOG IN AS PARTNER <ArrowRight className="w-4.5 h-4.5" />
                  </button>
                </div>
              ) : (
                <button 
                  onClick={logoutTrade}
                  className="bg-steel-charcoal hover:bg-steel-charcoal/80 border border-steel-grey/30 p-3.5 text-xs text-bone font-mono uppercase font-bold cursor-pointer"
                >
                  DISCONNECT SESSION
                </button>
              )}
            </div>
          </section>

          {activeTradeAccount ? (
            <>
              {/* ==============================================================
                  B2B PROCUREMENT TABLE MATRIX (Section 36-37)
                  ============================================================== */}
              <section id="trade-order-builder" className="max-w-7xl mx-auto px-4 md:px-8 scroll-mt-20">
                <div className="border-b border-steel-grey/20 pb-6 mb-10">
                  <span className="text-xs text-hot-orange font-mono tracking-widest block uppercase">B2B MATRIX</span>
                  <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-bone">BUILD YOUR BULK DISPATCH LOAD</h2>
                  <p className="text-xs font-mono text-steel-grey mt-1">
                    Select cases of 6 bags below. Your trade account currently uses: <strong className="text-bone">{getB2bPriceLabel()}</strong>.
                  </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  {/* Bulk Table */}
                  <div className="lg:col-span-8 overflow-x-auto border border-steel-grey/25 font-mono">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-steel-charcoal text-steel-grey uppercase font-bold border-b border-steel-grey/20">
                        <tr>
                          <th className="p-3">SKU / FORMULATION</th>
                          <th className="p-3">STAGE</th>
                          <th className="p-3">SIZE</th>
                          <th className="p-3 text-right">RRP</th>
                          <th className="p-3 text-right">CASE PRICE (6x)</th>
                          <th className="p-3 text-center">QUANTITY</th>
                          <th className="p-3 text-right">ACTION</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-steel-grey/15">
                        {products.slice(0, 15).map(prod => { // Limit to top 15 in matrix for performance
                          const currentCartItem = b2bCart.find(item => item.product.id === prod.id);
                          const qtyInCart = currentCartItem?.quantity || 0;
                          
                          // Case rates are 6x single bag trade rates
                          const caseRate = getB2bPrice(prod) * 6;
                          const singleRrp = prod.price;

                          return (
                            <tr key={prod.id} className="hover:bg-steel-charcoal/40 transition-colors">
                              <td className="p-3 font-semibold text-bone truncate max-w-[180px]">
                                <div className="font-mono text-hot-orange text-[10px] block">{prod.sku}</div>
                                <span className="uppercase text-bone tracking-tight">{prod.name.split(" — ")[0]}</span>
                              </td>
                              <td className="p-3 text-steel-grey uppercase">{prod.lifeStage}</td>
                              <td className="p-3 text-steel-grey uppercase">{prod.bagSize}</td>
                              <td className="p-3 text-right tabular-nums text-steel-grey">£{singleRrp.toFixed(2)}</td>
                              <td className="p-3 text-right tabular-nums text-bone font-bold">£{caseRate.toFixed(2)}</td>
                              <td className="p-3 text-center">
                                <div className="flex items-center justify-center border border-steel-grey/30 max-w-[90px] mx-auto">
                                  <button 
                                    onClick={() => updateB2bCartQty(prod.id, qtyInCart - 1)}
                                    className="p-1 text-steel-grey hover:text-bone cursor-pointer"
                                  >
                                    <Minus className="w-3 h-3" />
                                  </button>
                                  <span className="px-2.5 font-bold tabular-nums text-bone">{qtyInCart}</span>
                                  <button 
                                    onClick={() => updateB2bCartQty(prod.id, qtyInCart + 1)}
                                    className="p-1 text-steel-grey hover:text-bone cursor-pointer"
                                  >
                                    <Plus className="w-3 h-3" />
                                  </button>
                                </div>
                              </td>
                              <td className="p-3 text-right">
                                <button 
                                  onClick={() => addToB2bCart(prod, 1)}
                                  className="bg-mboro-brick text-bone px-2 py-1 uppercase text-[10px] font-bold tracking-widest hover:bg-mboro-brick/90 cursor-pointer"
                                >
                                  ADD CASE
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* Summary Cargo builder Column */}
                  <div className="lg:col-span-4">
                    <div className="bg-steel-charcoal border border-steel-grey/25 p-6 font-mono">
                      <div className="border-b border-steel-grey/25 pb-3 mb-4">
                        <span className="text-[10px] text-mboro-brick font-black block">MIDDLEHAVEN TRADE LOGISTICS</span>
                        <h4 className="text-base font-bold text-bone">CARGO LOAD MATRIX</h4>
                      </div>

                      {b2bCart.length > 0 && !isB2bCheckoutOpen ? (
                        <div className="space-y-4">
                          <div className="space-y-2 text-xs border-b border-steel-grey/15 pb-4">
                            {b2bCart.map(item => (
                              <div key={item.product.id} className="flex justify-between items-center text-[11px] gap-2">
                                <span className="text-steel-grey truncate max-w-[180px] uppercase">{item.product.name.split(" — ")[0]}</span>
                                <span className="text-bone whitespace-nowrap">{item.quantity} Cases × £{(getB2bPrice(item.product) * 6).toFixed(2)}</span>
                              </div>
                            ))}
                          </div>

                          {/* Calculations */}
                          {(() => {
                            const netTotal = b2bCart.reduce((sum, item) => sum + (getB2bPrice(item.product) * 6) * item.quantity, 0);
                            const vat = netTotal * 0.20; // 20% Standard UK Trade VAT
                            const totalWeight = b2bCart.reduce((sum, item) => {
                              const sizeInKg = parseFloat(item.product.bagSize) || 0;
                              return sum + (sizeInKg * 6 * item.quantity);
                            }, 0);

                            return (
                              <div className="space-y-2 text-xs">
                                <div className="flex justify-between">
                                  <span>TOTAL NET VALUE</span>
                                  <span className="tabular-nums font-bold">£{netTotal.toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>LOGISTICS FREIGHT</span>
                                  <span className="text-emerald-400">FREE OVER 300KG</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>CARGO TOTAL WEIGHT</span>
                                  <span className="tabular-nums text-bone">{totalWeight.toLocaleString()} KG</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>UK VAT (20.0%)</span>
                                  <span className="tabular-nums">£{vat.toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between text-sm font-bold border-t border-steel-grey/10 pt-2 text-hot-orange">
                                  <span>GRAND TOTAL</span>
                                  <span className="tabular-nums">£{(netTotal + vat).toFixed(2)}</span>
                                </div>

                                <div className="pt-4 space-y-3 font-sans">
                                  <div className="flex flex-col font-mono text-xs">
                                    <label className="text-[10px] text-steel-grey mb-1">PURCHASE ORDER (PO) REF</label>
                                    <input 
                                      type="text" 
                                      placeholder="e.g. PO-MIDDLE-871"
                                      value={poReference}
                                      onChange={(e) => setPoReference(e.target.value)}
                                      className="bg-steel-charcoal border border-steel-grey/30 p-2 text-xs text-bone outline-none focus:border-hot-orange"
                                    />
                                  </div>

                                  <button 
                                    onClick={() => {
                                      const order = submitB2BOrder(poReference);
                                      setB2bCreatedOrder(order);
                                      setIsB2bCheckoutOpen(true);
                                      setPoReference("");
                                    }}
                                    className="w-full bg-mboro-brick hover:bg-mboro-brick/90 text-bone font-black p-3.5 text-xs font-mono tracking-widest uppercase transition-all cursor-pointer"
                                  >
                                    SUBMIT CARGO ORDER
                                  </button>
                                </div>
                              </div>
                            );
                          })()}
                        </div>
                      ) : isB2bCheckoutOpen && b2bCreatedOrder ? (
                        <div className="space-y-6 text-center py-6">
                          <div className="w-12 h-12 bg-mboro-brick/10 border border-mboro-brick flex items-center justify-center mx-auto rounded-full text-mboro-brick">
                            <ShieldCheck className="w-6 h-6" />
                          </div>
                          <div className="space-y-2">
                            <h4 className="text-base font-bold text-bone uppercase">B2B DISPATCH DISPATCHED</h4>
                            <p className="text-xs text-steel-grey font-sans">
                              Your purchase order has been logged inside Middlesbrough Freight and assigned invoice. Check status on logistics dashboard.
                            </p>
                          </div>

                          <div className="bg-steel-charcoal/50 p-4 border border-steel-grey/15 text-left font-mono text-xs">
                            <div className="flex justify-between border-b border-steel-grey/10 pb-1 mb-1">
                              <span>ORDER REF</span>
                              <span className="text-bone">{b2bCreatedOrder.id}</span>
                            </div>
                            <div className="flex justify-between border-b border-steel-grey/10 pb-1 mb-1">
                              <span>PO REF</span>
                              <span className="text-bone truncate max-w-[150px]">{b2bCreatedOrder.poReference || "PO-DIRECT"}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>VALUE (INC VAT)</span>
                              <span className="text-mboro-brick">£{b2bCreatedOrder.total.toFixed(2)}</span>
                            </div>
                          </div>

                          <div className="flex flex-col gap-2">
                            <button 
                              onClick={() => {
                                setTrackingOrderId(b2bCreatedOrder.id);
                                const el = document.getElementById("logistics-tracking");
                                if (el) el.scrollIntoView({ behavior: "smooth" });
                                setIsB2bCheckoutOpen(false);
                                setB2bCreatedOrder(null);
                              }}
                              className="w-full bg-tees-blue text-bone border border-tees-blue hover:border-bone p-2.5 text-xs font-mono uppercase font-black cursor-pointer"
                            >
                              TRACK FREIGHT ROUTE
                            </button>
                            <button 
                              onClick={() => {
                                setIsB2bCheckoutOpen(false);
                                setB2bCreatedOrder(null);
                              }}
                              className="text-[10px] text-steel-grey hover:underline font-mono uppercase cursor-pointer"
                            >
                              CONTINUE BROWSING
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-12 text-steel-grey text-xs border border-dashed border-steel-grey/20">
                          CONVERT CASES OF DOG FOOD FROM MATRIX TO ALLOCATE CARGO STORES.
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </section>

              {/* ==============================================================
                  B2B REORDER SHORTCUT (Section 38)
                  ============================================================== */}
              <section className="max-w-7xl mx-auto px-4 md:px-8">
                <div className="bg-steel-charcoal border border-steel-grey/25 p-6 md:p-8 font-mono">
                  <div className="border-b border-steel-grey/20 pb-4 mb-6">
                    <span className="text-[10px] text-hot-orange tracking-widest block uppercase font-bold">LOGISTICS SHORTCUTS</span>
                    <h3 className="text-lg font-bold text-bone">QUICK REORDER PREVIOUS MANIFEST</h3>
                    <p className="text-xs text-steel-grey font-sans mt-0.5">Click below to load your exact previous regional order into the cargo matrix.</p>
                  </div>

                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-steel-charcoal/40 border border-steel-grey/15 p-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Clock className="w-4 h-4 text-hot-orange" />
                        <span className="text-xs font-bold text-bone">LAST DISPATCH REFERENCE: TV-ORD-20485</span>
                      </div>
                      <div className="text-[11px] text-steel-grey flex flex-wrap gap-x-4">
                        <span>TEES ORIGINAL (12KG) — 20 CASES</span>
                        <span>TEES ACTIVE (12KG) — 12 CASES</span>
                        <span>TEES PUPPY (6KG) — 8 CASES</span>
                      </div>
                    </div>

                    <button 
                      onClick={() => {
                        clearB2bCart();
                        // Add previous order items deterministically
                        addToB2bCart(products[0], 20); // 20 cases Original
                        addToB2bCart(products[3], 12); // 12 cases Active
                        addToB2bCart(products[4], 8);  // 8 cases Puppy
                        const el = document.getElementById("trade-order-builder");
                        if (el) el.scrollIntoView({ behavior: "smooth" });
                      }}
                      className="bg-hot-orange text-steel-charcoal text-xs tracking-wider font-extrabold px-6 py-3 uppercase hover:bg-hot-orange/90 cursor-pointer"
                    >
                      LOAD & REORDER CONTEXT
                    </button>
                  </div>
                </div>
              </section>

              {/* ==============================================================
                  B2B FINANCIAL LEDGER INVOICES (Section 41-42)
                  ============================================================== */}
              <section className="max-w-7xl mx-auto px-4 md:px-8">
                <div className="border-b border-steel-grey/20 pb-6 mb-10">
                  <span className="text-xs text-hot-orange font-mono tracking-widest block uppercase">FINANCIAL LEDGER</span>
                  <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-bone">ACCOUNT INVOICES & LIABILITY</h2>
                  <p className="text-xs font-mono text-steel-grey mt-1">
                    Manage outstanding credit terms, download statements, and issue direct credit payments.
                  </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  {/* Financial Stats */}
                  <div className="lg:col-span-4 grid grid-cols-2 gap-4">
                    <div className="border border-steel-grey/20 p-5 bg-steel-charcoal/20">
                      <span className="text-[9px] text-steel-grey block uppercase font-mono">ACCOUNT BALANCE</span>
                      <div className="text-2xl font-bold font-mono text-bone tabular-nums">£{activeTradeAccount.balance.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                    </div>
                    <div className="border border-steel-grey/20 p-5 bg-steel-charcoal/20">
                      <span className="text-[9px] text-steel-grey block uppercase font-mono">CREDIT LIMIT</span>
                      <div className="text-2xl font-bold font-mono text-bone tabular-nums">£{activeTradeAccount.creditLimit.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                    </div>
                    <div className="border border-steel-grey/20 p-5 bg-steel-charcoal/20 col-span-2">
                      <span className="text-[9px] text-steel-grey block uppercase font-mono">CREDIT TERMS</span>
                      <div className="text-sm font-bold font-mono text-hot-orange uppercase">{activeTradeAccount.creditTerms} (DEFAULT CREDIT LINE)</div>
                    </div>
                  </div>

                  {/* Invoice list */}
                  <div className="lg:col-span-8 overflow-x-auto border border-steel-grey/25 font-mono">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-steel-charcoal text-steel-grey uppercase font-bold border-b border-steel-grey/20">
                        <tr>
                          <th className="p-3">INVOICE ID</th>
                          <th className="p-3">PO REF</th>
                          <th className="p-3">ISSUE DATE</th>
                          <th className="p-3">DUE DATE</th>
                          <th className="p-3 text-right">TOTAL INC VAT</th>
                          <th className="p-3 text-center">STATUS</th>
                          <th className="p-3 text-right">ACTIONS</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-steel-grey/15">
                        {invoices.slice(0, 8).map(inv => (
                          <tr key={inv.id} className="hover:bg-steel-charcoal/40 transition-colors">
                            <td className="p-3 text-bone font-bold uppercase">{inv.id}</td>
                            <td className="p-3 text-steel-grey uppercase">{inv.poReference}</td>
                            <td className="p-3 text-steel-grey uppercase">{inv.date}</td>
                            <td className="p-3 text-steel-grey uppercase">{inv.dueDate}</td>
                            <td className="p-3 text-right font-bold tabular-nums">£{inv.amount.toFixed(2)}</td>
                            <td className="p-3 text-center">
                              <span className={`px-2 py-0.5 text-[9px] font-bold uppercase ${
                                inv.status === 'PAID' 
                                  ? 'bg-emerald-500/10 border border-emerald-500 text-emerald-400' 
                                  : inv.status === 'OVERDUE'
                                  ? 'bg-mboro-brick/20 border border-mboro-brick text-mboro-brick'
                                  : 'bg-amber-500/10 border border-amber-500 text-amber-400'
                              }`}>
                                {inv.status}
                              </span>
                            </td>
                            <td className="p-3 text-right flex justify-end gap-2">
                              {inv.status !== 'PAID' && (
                                <button 
                                  onClick={() => payInvoice(inv.id)}
                                  className="text-[10px] text-emerald-400 font-bold border border-emerald-500/30 hover:border-emerald-500 px-2 py-1 cursor-pointer"
                                >
                                  PAY NOW
                                </button>
                              )}
                              <button 
                                onClick={() => alert(`Simulated downloading statement for invoice ${inv.id}`)}
                                className="text-[10px] text-steel-grey font-bold hover:text-bone p-1"
                                aria-label="Download statement"
                              >
                                <Download className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </section>

              {/* ==============================================================
                  B2B REGIONAL FINANCIAL SIMULATORS (Section 35)
                  ============================================================== */}
              <section className="max-w-7xl mx-auto px-4 md:px-8">
                <MarginCalculator />
              </section>
            </>
          ) : (
            // Lockout view explaining how to log in
            <section className="max-w-3xl mx-auto text-center py-12 font-mono space-y-6">
              <Lock className="w-12 h-12 text-steel-grey mx-auto animate-pulse" />
              <h3 className="text-xl font-bold uppercase text-bone">TRADE ACCESS RESTRICTED</h3>
              <p className="text-xs text-steel-grey font-sans leading-relaxed max-w-lg mx-auto">
                The Tees Valley Dog Co. wholesale procurement desk requires verified trade login state parameters. Select a regional demo account in the footer list below to load instant trade pricing modules.
              </p>
            </section>
          )}

          {/* ==================================================================
              TRADE REGISTRATION FORM (Section 43)
              ================================================================== */}
          <section className="max-w-7xl mx-auto px-4 md:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              <div className="lg:col-span-5 space-y-6">
                <span className="text-xs text-hot-orange font-mono tracking-widest block uppercase">B2B ENROLLMENT</span>
                <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight text-bone uppercase">
                  APPLY FOR RECURRING COMMERCIAL SUPPLIES
                </h2>
                <p className="text-sm font-sans text-steel-grey leading-relaxed">
                  Apply for verified regional retail partner coordinates to utilize the bulk dispatch matrix, net credit terms, and direct freight container drops. No automatic credit is granted; applications are evaluated by Middlehaven logistics heads.
                </p>
              </div>

              <div className="lg:col-span-7 bg-steel-charcoal border border-steel-grey/25 p-6 md:p-8 font-mono">
                {!tradeRegDone ? (
                  <form onSubmit={(e) => { e.preventDefault(); setTradeRegDone(true); }} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex flex-col text-xs">
                        <label className="text-[10px] text-steel-grey mb-1 uppercase">COMPANY TRADING NAME</label>
                        <input 
                          type="text" required placeholder="e.g. Cleveland Feed Depot"
                          value={tradeRegCompany}
                          onChange={(e) => setTradeRegCompany(e.target.value)}
                          className="bg-steel-charcoal border border-steel-grey/30 p-2.5 text-bone outline-none focus:border-hot-orange"
                        />
                      </div>
                      <div className="flex flex-col text-xs">
                        <label className="text-[10px] text-steel-grey mb-1 uppercase">AUTHORIZED CONTACT FULL NAME</label>
                        <input 
                          type="text" required placeholder="e.g. Jack Smith"
                          value={tradeRegName}
                          onChange={(e) => setTradeRegName(e.target.value)}
                          className="bg-steel-charcoal border border-steel-grey/30 p-2.5 text-bone outline-none focus:border-hot-orange"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex flex-col text-xs">
                        <label className="text-[10px] text-steel-grey mb-1 uppercase">PARTNER SECURE EMAIL</label>
                        <input 
                          type="email" required placeholder="e.g. jack@cleveland-feed.co.uk"
                          value={tradeRegEmail}
                          onChange={(e) => setTradeRegEmail(e.target.value)}
                          className="bg-steel-charcoal border border-steel-grey/30 p-2.5 text-bone outline-none focus:border-hot-orange"
                        />
                      </div>
                      <div className="flex flex-col text-xs">
                        <label className="text-[10px] text-steel-grey mb-1 uppercase">EXPECTED MONTHLY BAG VOLUME</label>
                        <select 
                          value={tradeRegVolume}
                          onChange={(e) => setTradeRegVolume(e.target.value)}
                          className="bg-steel-charcoal border border-steel-grey/30 p-2.5 text-bone outline-none focus:border-hot-orange cursor-pointer"
                        >
                          <option>Under 50 bags</option>
                          <option>50 to 200 bags</option>
                          <option>200 to 500 bags</option>
                          <option>Over 500 bags (Regional Freight Drop)</option>
                        </select>
                      </div>
                    </div>

                    <button 
                      type="submit"
                      className="w-full bg-mboro-brick hover:bg-mboro-brick/90 text-bone p-3 text-xs uppercase font-black tracking-widest cursor-pointer"
                    >
                      TRANSMIT TRADE REQ APPLICATION
                    </button>
                  </form>
                ) : (
                  <div className="text-center py-8 space-y-4">
                    <div className="w-12 h-12 bg-mboro-brick/10 border border-mboro-brick rounded-full flex items-center justify-center mx-auto text-mboro-brick">
                      <UserPlus className="w-6 h-6" />
                    </div>
                    <h4 className="text-base font-bold text-bone uppercase">APPLICATION RECEIVED & TRANSMITTED</h4>
                    <p className="text-xs text-steel-grey font-sans">
                      Partner request for <strong className="text-bone">{tradeRegCompany}</strong> has been logged inside our Middlesbrough partner desk. Evaluation responses usually return within 48 business hours.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </section>

        </div>
      )}

      {/* ======================================================================
          SHARED MANUFACTURING PIPELINE & TRACEABILITY SYSTEM (Section 21-25, 45)
          ====================================================================== */}
      <section id="manufacturing" className="max-w-7xl mx-auto px-4 md:px-8 py-16 scroll-mt-20">
        <ManufacturingTimeline />
      </section>

      {/* ======================================================================
          SHARED TRACEABILITY TIMELINE & QUALITY CONTROLS (Section 45-46)
          ====================================================================== */}
      <section id="traceability" className="max-w-7xl mx-auto px-4 md:px-8 py-16 scroll-mt-20">
        <TraceabilityTimeline />
      </section>

      {/* ======================================================================
          SHARED LOGISTICS REAL-TIME ROUTE DISPATCH TRACKER (Section 40)
          ====================================================================== */}
      <section id="logistics-tracking" className="max-w-7xl mx-auto px-4 md:px-8 py-16 scroll-mt-20">
        <div className="border border-steel-grey/25 p-6 md:p-8 bg-steel-charcoal font-mono relative">
          <div className="border-b border-steel-grey/20 pb-4 mb-6">
            <span className="text-[10px] text-hot-orange tracking-widest block uppercase font-bold">CARGO GEOGRAPHY FLOW</span>
            <h3 className="text-xl font-extrabold tracking-tight text-bone">REAL-TIME REGIONAL DISPATCH CARGO SHIPMENT TRACKING</h3>
            <p className="text-xs text-steel-grey font-sans mt-0.5">Select your active order ID below to trace cargo status moving through Teesside.</p>
          </div>

          <div className="flex flex-col lg:flex-row gap-8 items-start">
            {/* Left selector */}
            <div className="w-full lg:w-80 flex flex-col gap-2">
              <label className="text-[9px] text-steel-grey uppercase">ACTIVE REGISTERED CARGO</label>
              {orders.slice(0, 4).map(o => (
                <button
                  key={o.id}
                  onClick={() => setTrackingOrderId(o.id)}
                  className={`text-left p-3 border text-xs flex justify-between items-center transition-colors font-mono cursor-pointer ${
                    trackingOrderId === o.id 
                      ? 'border-hot-orange bg-hot-orange/10 text-bone' 
                      : 'border-steel-grey/25 text-steel-grey hover:border-steel-grey'
                  }`}
                >
                  <div>
                    <span className="font-bold block uppercase">{o.id}</span>
                    <span className="text-[9px] block text-steel-grey truncate max-w-[150px]">{o.companyName || o.customerName}</span>
                  </div>
                  <span className="text-[10px] text-hot-orange tracking-widest font-bold uppercase">{o.status}</span>
                </button>
              ))}
            </div>

            {/* Right details */}
            <div className="flex-1 w-full space-y-6">
              {selectedOrderToTrack ? (
                <>
                  <DeliveryTracker order={selectedOrderToTrack} />
                  
                  {/* Micro list of contained items */}
                  <div className="bg-steel-charcoal/40 border border-steel-grey/20 p-4 font-mono text-xs">
                    <div className="border-b border-steel-grey/15 pb-2 mb-2 font-bold uppercase">CONTAINED FREIGHT CONTENTS</div>
                    <div className="space-y-1.5">
                      {selectedOrderToTrack.items.map((item, i) => (
                        <div key={i} className="flex justify-between text-steel-grey">
                          <span className="uppercase">{item.productName} × {item.quantity}</span>
                          <span className="text-bone">SKU: {item.sku}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <div className="p-8 text-center border border-dashed border-steel-grey/20 text-steel-grey text-xs">
                  NO SECURE ACTIVE REGISTERED ORDER DETECTED FOR TRACING.
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ======================================================================
          INTERACTIVE MIDDLESBROUGH MAP (Section 24-25, 61-62)
          ====================================================================== */}
      <section id="about" className="max-w-7xl mx-auto px-4 md:px-8 py-16">
        <div className="border-b border-steel-grey/20 pb-6 mb-10">
          <span className="text-xs text-hot-orange font-mono tracking-widest block uppercase">05. THE GEOGRAPHY</span>
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight text-bone">BUILT IN TEESSIDE</h2>
          <p className="text-xs font-mono text-steel-grey mt-1">
            Our geographical coordinates and distribution channels plotted along the River Tees industrial lines.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Map Image SVG */}
          <div className="lg:col-span-7 bg-steel-charcoal border border-steel-grey/25 p-4 relative">
            <div className="absolute top-6 left-6 font-mono text-xs text-bone bg-steel-charcoal/90 border border-steel-grey/30 px-3 py-1.5 z-10">
              <span className="text-hot-orange font-bold block">SCHEMATIC CAD ANALYSIS</span>
              <span>MIDDLEHAVEN REGIONAL HUB MAP</span>
            </div>

            {/* High fidelity interactive local map using clean custom inline SVG (Section 24) */}
            <svg 
              viewBox="0 0 800 450" 
              className="w-full h-auto bg-steel-charcoal border border-steel-grey/15 filter saturate-90"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Background blueprint grid */}
              <defs>
                <pattern id="mapGrid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#252A2D" strokeWidth="1" />
                  <path d="M 200 0 L 0 0 0 200" fill="none" stroke="#123B52" strokeWidth="1.5" strokeOpacity="0.4" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#mapGrid)" />

              {/* River Tees (Tees Blue curve path) */}
              <path 
                d="M -50,150 C 150,140 250,280 400,220 C 520,170 600,120 850,110" 
                fill="none" 
                stroke="#123B52" 
                strokeWidth="45" 
                strokeLinecap="round" 
                opacity="0.9"
              />
              <path 
                d="M -50,150 C 150,140 250,280 400,220 C 520,170 600,120 850,110" 
                fill="none" 
                stroke="#E66A24" 
                strokeWidth="2" 
                strokeDasharray="4,6" 
                opacity="0.8" 
              />

              {/* Middlesbrough Dock layout representation (Middlehaven docks) */}
              <rect x="380" y="240" width="120" height="45" fill="#252A2D" stroke="#667078" strokeWidth="2" opacity="0.85" />
              <rect x="440" y="225" width="25" height="15" fill="#252A2D" stroke="#667078" strokeWidth="1.5" />

              {/* Transporter Bridge reference line (Section 25) */}
              <line x1="452" y1="180" x2="452" y2="280" stroke="#9B3F2F" strokeWidth="3" opacity="0.8" />
              <line x1="440" y1="195" x2="464" y2="195" stroke="#E66A24" strokeWidth="1.5" />
              <text x="460" y="190" fill="#E66A24" fontSize="9" fontFamily="monospace" fontWeight="bold">TRANSPORTER SPAN</text>

              {/* Railway infrastructure lines (Section 1) */}
              <path 
                d="M -10,360 L 320,360 L 400,320 L 810,320" 
                fill="none" 
                stroke="#667078" 
                strokeWidth="3" 
                strokeDasharray="6,3" 
                opacity="0.65" 
              />
              <text x="520" y="315" fill="#667078" fontSize="8" fontFamily="monospace" letterSpacing="1">RAIL FREIGHT CORRIDOR</text>

              {/* Production Facility Pin marker */}
              <circle cx="410" cy="260" r="12" fill="#E66A24" opacity="0.3" className="animate-ping" />
              <circle cx="410" cy="260" r="6" fill="#E66A24" />
              
              {/* Warehouse Pin marker */}
              <circle cx="480" cy="340" r="6" fill="#9B3F2F" />

              {/* Location labels */}
              <g fill="#F1EEE7" fontFamily="monospace" fontSize="9" fontWeight="bold">
                <rect x="350" y="285" width="120" height="16" fill="#252A2D" stroke="#E66A24" strokeWidth="1" />
                <text x="355" y="297" fill="#F1EEE7">01. MIDDLEHAVEN MFG</text>

                <rect x="420" y="365" width="120" height="16" fill="#252A2D" stroke="#9B3F2F" strokeWidth="1" />
                <text x="425" y="377" fill="#F1EEE7">02. REGIONAL WH</text>

                <text x="30" y="100" fill="#667078" opacity="0.8">RIVER TEES SHIPPING CHANNEL</text>
                <text x="630" y="210" fill="#667078" opacity="0.8">MIDDLESBROUGH TOWN CENTRE</text>
              </g>
            </svg>
          </div>

          <div className="lg:col-span-5 space-y-6">
            <span className="text-xs text-hot-orange font-mono tracking-widest block uppercase">THE STRATEGY</span>
            <h3 className="text-2xl font-black text-bone uppercase">MADE IN BRITAIN. REDESIGNED FOR THE HYPERMODERN AGE.</h3>
            <p className="text-sm font-sans text-steel-grey leading-relaxed">
              Our food isn&apos;t packaged in twee countryside aesthetics. It is fabricated inside an exceptionally clean, modern industrial dock environment in Middlesbrough, using engineering principles to design the precise physical and mineral properties of every recipe.
            </p>
            
            <div className="border-l-2 border-mboro-brick pl-4 py-2 font-mono text-xs space-y-2 text-steel-grey">
              <div>
                <strong className="text-bone uppercase">MIDDLEHAVEN FACILITY:</strong>
                <p className="font-sans">Where extrusion cooking, scanner testing, and packaging loops occur.</p>
              </div>
              <div>
                <strong className="text-bone uppercase">TEESSIDE RAIL DISPATCH:</strong>
                <p className="font-sans">Direct freight paths linking raw northern ingredients and distribution shipping routes.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ======================================================================
          SHARED EDITORIAL JOURNAL ARTICLES (Section 47)
          ====================================================================== */}
      <section className="max-w-7xl mx-auto px-4 md:px-8 py-16 border-t border-steel-grey/20">
        <div className="border-b border-steel-grey/20 pb-6 mb-10">
          <span className="text-xs text-hot-orange font-mono tracking-widest block uppercase">06. THE JOURNAL</span>
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight text-bone">EDITORIAL DISCOURSE</h2>
          <p className="text-xs font-mono text-steel-grey mt-1">
            Analyzing optimal protein metrics, manufacturing processes, and canine health science from Middlesbrough.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <JournalCard 
            bgImgClass="bg-tees-blue"
            category="NUTRITION" 
            title="Why Protein Sourcing Standards Matter" 
            readTime="6 MIN READ" 
            excerpt="An inside analysis of amino acid decay in low-temperature versus high-temperature pet food extrusion, highlighting Middlesbrough manufacturing protocols." 
          />
          <JournalCard 
            bgImgClass="bg-mboro-brick"
            category="ENGINEERING" 
            title="Inside a Hypermodern Dog Food Factory" 
            readTime="8 MIN READ" 
            excerpt="Analyzing the mechanical scanning technology, multi-layer silo storage, and metal detection loops safeguarding Teesside's premium dog food runs." 
          />
          <JournalCard 
            bgImgClass="bg-steel-grey"
            category="CULTURE" 
            title="From Teesside to Britain's Working Breeds" 
            readTime="5 MIN READ" 
            excerpt="Tracing our historical local connection with working spaniels, pointers, and retrievers living across the North East rugged landscape." 
          />
        </div>
      </section>

      {/* ======================================================================
          REAL LIFE DOG Vitality SPOTLIGHT (Section 26)
          ====================================================================== */}
      <section className="bg-concrete text-steel-charcoal py-16 border-t border-steel-grey/30">
        <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 relative">
            <div className="border-4 border-steel-charcoal bg-steel-charcoal p-1">
              <img 
                src="/images/dog_lifestyle_active.jpg" 
                alt="Healthy active dog running outdoors near the Teesside coast" 
                className="w-full h-80 md:h-[400px] object-cover filter contrast-105 saturate-95"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          <div className="lg:col-span-6 space-y-6">
            <span className="text-xs text-mboro-brick font-mono tracking-widest block uppercase font-bold">07. ACTIVE VITALITY</span>
            <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight text-steel-charcoal uppercase leading-none">
              BUILT FOR LIFE.<br />
              ENGINEERED TO WORK.
            </h2>
            <p className="text-sm font-sans text-steel-charcoal/90 leading-relaxed">
              We make exceptional fuel for dogs that actually live, run, swim, and work. Whether they are tearing across Saltburn beaches, tracking across North York Moors, or guarding warehouse gates. Our formulas contain dense, natural calories free from wheat gluten, soybean, or synthetic dyes. Just honest, high-quality British ingredients.
            </p>

            <div className="border-t border-steel-charcoal/20 pt-6 grid grid-cols-2 gap-4 font-mono">
              <div>
                <span className="text-[10px] text-steel-grey block uppercase font-bold">WHEAT GLUTEN RESISTANCE</span>
                <span className="text-sm font-black text-mboro-brick">0% INGREDIENTS MATCHED</span>
              </div>
              <div>
                <span className="text-[10px] text-steel-grey block uppercase font-bold">METABOLIC ACCIDENT REDUCTION</span>
                <span className="text-sm font-black text-mboro-brick">100% COMPLEX GRAINS</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />

      {/* ======================================================================
          PRODUCT DETAIL MODAL OVERLAY (Section 17, 18)
          ====================================================================== */}
      <AnimatePresence>
        {selectedProduct && (
          <div className="fixed inset-0 bg-steel-charcoal/85 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-steel-charcoal border border-steel-grey/30 max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6 md:p-8 font-mono grid grid-cols-1 md:grid-cols-12 gap-8 relative text-xs"
            >
              {/* Close Button */}
              <button 
                onClick={() => setSelectedProduct(null)}
                className="absolute top-4 right-4 text-steel-grey hover:text-hot-orange cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Left col: Image + quick features */}
              <div className="md:col-span-5 space-y-4">
                <div className="bg-concrete p-6 flex items-center justify-center border border-steel-grey/15 h-64 relative">
                  <img 
                    src="/images/product_dog_food_bag.jpg" 
                    alt={selectedProduct.name} 
                    className="h-full object-contain filter drop-shadow-xl"
                    referrerPolicy="no-referrer"
                  />
                  {/* Corner tag */}
                  <span className="absolute bottom-2 left-2 text-[9px] bg-steel-charcoal text-bone px-1.5 py-0.5 border border-steel-grey/30 font-bold uppercase">
                    100% SECURED BAG
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-center text-[10px]">
                  <div className="border border-steel-grey/25 p-2 bg-steel-charcoal/30">
                    <span className="text-steel-grey block">BAG SIZE</span>
                    <strong className="text-bone block">{selectedProduct.bagSize}</strong>
                  </div>
                  <div className="border border-steel-grey/25 p-2 bg-steel-charcoal/30">
                    <span className="text-steel-grey block">PROTEIN FOCUS</span>
                    <strong className="text-bone block uppercase">{selectedProduct.proteinSource}</strong>
                  </div>
                </div>

                {/* Subscriptions toggle inside PDP */}
                <div className="border border-hot-orange/20 bg-hot-orange/5 p-3 text-[10px] space-y-1.5">
                  <span className="text-hot-orange font-bold uppercase tracking-wider block">NEVER RUN OUT DISCOUNT REBATE</span>
                  <p className="text-steel-grey font-sans">Convert to a recurring subscription at checkout to secure an instant <strong className="text-bone">10% discount</strong> on all recurring loads.</p>
                </div>
              </div>

              {/* Right col: Formulations details */}
              <div className="md:col-span-7 space-y-5">
                <div className="space-y-1">
                  <span className="text-xs text-hot-orange tracking-widest block uppercase font-bold">{selectedProduct.lifeStage} SPECIFICATION</span>
                  <h3 className="text-xl font-extrabold text-bone tracking-tight uppercase leading-none">{selectedProduct.name}</h3>
                  <div className="text-sm font-bold text-hot-orange">£{selectedProduct.price.toFixed(2)}</div>
                </div>

                <p className="text-xs font-sans text-steel-grey leading-relaxed">
                  {selectedProduct.description} Sourced and formulated under strict QA coordinates in Middlehaven docks. Meets all AAFCO complete dietary requirements.
                </p>

                {/* Technical stats column */}
                <div className="grid grid-cols-3 gap-2 border-y border-steel-grey/15 py-3">
                  <TechnicalLabel label="PROTEIN COMPOUND" value={`${selectedProduct.protein}% BASE`} />
                  <TechnicalLabel label="SKU REFERENCE" value={selectedProduct.sku} />
                  <TechnicalLabel label="STOCK CAPACITY" value="RESERVED" />
                </div>

                {/* Analytical constituents */}
                <div>
                  <span className="text-[10px] text-steel-grey block mb-2 font-bold uppercase">MACRONUTRIENT RATIOS</span>
                  <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                    <div className="border border-steel-grey/15 py-1.5 bg-steel-charcoal/30">
                      <span className="text-steel-grey block">PROTEIN</span>
                      <span className="text-bone font-bold">{selectedProduct.protein}%</span>
                    </div>
                    <div className="border border-steel-grey/15 py-1.5 bg-steel-charcoal/30">
                      <span className="text-steel-grey block">FAT</span>
                      <span className="text-bone font-bold">{selectedProduct.fat}%</span>
                    </div>
                    <div className="border border-steel-grey/15 py-1.5 bg-steel-charcoal/30">
                      <span className="text-steel-grey block">ENERGY</span>
                      <span className="text-bone font-bold truncate block">{selectedProduct.energy.split(" ")[0]}</span>
                    </div>
                  </div>
                </div>

                {/* Sourcing details list */}
                <div>
                  <span className="text-[10px] text-steel-grey block mb-2 font-bold uppercase">INGREDIENT GEOGRAPHY TRACE</span>
                  <div className="space-y-1.5 font-sans">
                    {selectedProduct.ingredients.slice(0, 3).map((ing, i) => (
                      <div key={i} className="flex justify-between items-center text-[11px] text-steel-grey border-b border-steel-grey/10 pb-1.5">
                        <span className="font-mono text-bone text-xs uppercase">{ing.name} ({ing.percentage}%)</span>
                        <span className="text-xs truncate max-w-[150px]">{ing.source}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button 
                    onClick={() => { addToCart(selectedProduct, 1); setSelectedProduct(null); }}
                    className="flex-1 bg-hot-orange hover:bg-hot-orange/90 text-steel-charcoal font-black py-3 text-xs tracking-widest uppercase cursor-pointer"
                  >
                    ADD TO BAG
                  </button>
                  <button 
                    onClick={() => { 
                      addToCart(selectedProduct, 1, true, '4 weeks'); 
                      setSelectedProduct(null);
                      setIsB2cCartOpen(true);
                    }}
                    className="bg-steel-charcoal border border-steel-grey/40 hover:border-bone text-bone font-bold px-4 py-3 text-xs uppercase cursor-pointer"
                  >
                    SUBSCRIBE & SAVE 10%
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </main>
  );
}
