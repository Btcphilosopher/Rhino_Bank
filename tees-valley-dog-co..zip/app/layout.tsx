import type {Metadata} from 'next';
import './globals.css'; // Global styles
import { AppProvider } from '@/lib/AppContext';

export const metadata: Metadata = {
  title: 'Tees Valley Dog Co. | Premium British Dog Food',
  description: 'Premium British dog food and B2B trade platform, engineered around Middlesbrough\'s hypermodern industrial identity. Proper food for proper dogs.',
  openGraph: {
    title: 'Tees Valley Dog Co. | Premium British Dog Food',
    description: 'Premium British dog food and B2B trade platform, engineered around Middlesbrough\'s hypermodern industrial identity. Proper food for proper dogs.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Tees Valley Dog Co. | Premium British Dog Food',
    description: 'Premium British dog food and B2B trade platform, engineered around Middlesbrough\'s hypermodern industrial identity.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning className="bg-steel-charcoal text-bone">
        <AppProvider>{children}</AppProvider>
      </body>
    </html>
  );
}
