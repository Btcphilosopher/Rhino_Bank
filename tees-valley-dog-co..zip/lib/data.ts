// lib/data.ts
// Programmatically generated deterministic seeded data for Tees Valley Dog Co.

export interface Product {
  id: string;
  name: string;
  formulation: string;
  lifeStage: 'PUPPY' | 'ADULT' | 'SENIOR' | 'WORKING';
  proteinSource: 'Chicken' | 'Turkey' | 'Salmon' | 'Lamb' | 'Beef' | 'Duck';
  bagSize: string; // "1.5kg" | "6kg" | "12kg"
  price: number;
  tradePrice: number;
  wholesalePrice: number;
  distributorPrice: number;
  rrp: number;
  stock: number;
  sku: string;
  protein: number;
  fat: number;
  fibre: number;
  ash: number;
  moisture: number;
  energy: string; // e.g. "3,650 kcal/kg"
  ingredients: { name: string; percentage: number; source: string; function: string }[];
  description: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  city: string;
  postcode: string;
  isTrade: boolean;
}

export interface TradeAccount {
  id: string;
  companyName: string;
  accountNumber: string;
  vatNumber: string;
  contactName: string;
  email: string;
  phone: string;
  address: string;
  tier: 'TRADE' | 'WHOLESALE' | 'DISTRIBUTOR';
  creditTerms: string; // e.g. "Net 30"
  creditLimit: number;
  balance: number;
}

export interface Order {
  id: string;
  customerName: string;
  companyName?: string;
  date: string;
  items: { productName: string; sku: string; quantity: number; price: number }[];
  total: number;
  status: 'CONFIRMED' | 'ALLOCATED' | 'PACKED' | 'DISPATCHED' | 'DELIVERED';
  isTrade: boolean;
  trackingNumber?: string;
}

export interface Invoice {
  id: string;
  orderId: string;
  companyName: string;
  accountNumber: string;
  date: string;
  dueDate: string;
  amount: number;
  status: 'PAID' | 'UNPAID' | 'OVERDUE';
  poReference: string;
}

export interface Batch {
  id: string;
  productId: string;
  productName: string;
  productionDate: string;
  ingredients: { name: string; testStatus: 'PASSED' | 'FAILED' }[];
  productionLine: string;
  qualityCheck: {
    moistureCheck: 'PASSED' | 'FAILED';
    proteinCheck: 'PASSED' | 'FAILED';
    foreignBodyScan: 'PASSED' | 'FAILED';
    microbialScreen: 'PASSED' | 'FAILED';
    releaseAuthorizedBy: string;
  };
  warehouseLocation: string;
  status: 'APPROVED' | 'QUARANTINE' | 'RELEASED';
}

// Deterministic seed generation function helper
function pseudoRandom(seed: number) {
  const x = Math.sin(seed++) * 10000;
  return x - Math.floor(x);
}

// 1. GENERATE 30 PRODUCTS
export const FORMULATIONS = [
  { name: "TEES ORIGINAL", desc: "Our signature complete food formulated for everyday vitality, built with local high-quality protein." },
  { name: "TEES ACTIVE", desc: "High-energy nutrition for working breeds, sporting dogs, and active companions who run the Teesside beaches." },
  { name: "TEES SENIOR", desc: "Joint-supporting senior formulation with reduced fats and gentle oats for aging town dogs." },
  { name: "TEES FISH & POTATO", desc: "Single-source marine protein ideal for dogs with grain sensitivities or coat issues." },
  { name: "TEES PUPPY", desc: "Bone and brain development nutrition packed with essential minerals and gentle proteins." },
  { name: "TEES SENSITIVE", desc: "Hypoallergenic lamb and rice formulation specifically designed for dogs with delicate digestion." },
  { name: "TEES WORKING DOG", desc: "Heavy-duty formulation with dense calorie structure and enhanced electrolyte support for heavy working dogs." }
];

const PROTEINS = ["Chicken", "Turkey", "Salmon", "Lamb", "Beef", "Duck"] as const;
const STAGES = ["PUPPY", "ADULT", "SENIOR", "WORKING"] as const;
const SIZES = ["1.5kg", "6kg", "12kg"];

export const products: Product[] = [];
let skuCounter = 100;

FORMULATIONS.forEach((form, formIdx) => {
  SIZES.forEach((size, sizeIdx) => {
    skuCounter++;
    const seed = formIdx * 7 + sizeIdx * 13;
    const sizeMultiplier = size === "1.5kg" ? 0.15 : size === "6kg" ? 0.55 : 1.0;
    
    // Core retail price calculation
    const basePrice = 49.0;
    const price = Math.round((basePrice + (seed % 10) - 4) * sizeMultiplier * 100) / 100;
    
    // Trade tiers
    const tradePrice = Math.round(price * 0.76 * 100) / 100;
    const wholesalePrice = Math.round(price * 0.69 * 100) / 100;
    const distributorPrice = Math.round(price * 0.64 * 100) / 100;

    const proteinSrc = PROTEINS[seed % PROTEINS.length];
    const stage = STAGES[formIdx % STAGES.length];

    const proteinPercent = Math.round(24 + (seed % 6));
    const fatPercent = Math.round(12 + (seed % 5));
    const fibrePercent = Math.round(2.5 + (seed % 3) * 0.5);
    const ashPercent = Math.round(6.5 + (seed % 2) * 0.5);
    const moisturePercent = 9;

    products.push({
      id: `prod-${skuCounter}`,
      name: `${form.name} — ${proteinSrc} & Oat`,
      formulation: form.name,
      lifeStage: stage,
      proteinSource: proteinSrc,
      bagSize: size,
      price,
      tradePrice,
      wholesalePrice,
      distributorPrice,
      rrp: price,
      stock: Math.round(50 + pseudoRandom(seed) * 450),
      sku: `TV-DOG-${skuCounter}`,
      protein: proteinPercent,
      fat: fatPercent,
      fibre: fibrePercent,
      ash: ashPercent,
      moisture: moisturePercent,
      energy: `${3400 + (seed % 5) * 100} kcal/kg`,
      ingredients: [
        { name: `${proteinSrc} Meal`, percentage: proteinPercent + 10, source: "North Yorkshire Farms", function: "Muscle tissue & structural health" },
        { name: "Flaked Oats", percentage: 25, source: "Teesside Arable", function: "Slow-release carbohydrate energy" },
        { name: "White Rice", percentage: 15, source: "Imported Co-op", function: "Easily digestible energy support" },
        { name: "Sugar Beet Pulp", percentage: 4, source: "Lincolnshire Fields", function: "Soluble prebiotic digestion" },
        { name: "Poultry Fat", percentage: 5, source: "Local Abattoir", function: "Omegas & concentrated energy" },
        { name: "Joint Care Pack", percentage: 1, source: "Tees Science Lab", function: "Glucosamine & Chondroitin support" }
      ],
      description: `${form.desc} Made under rigorous food-safety standards in Middlesbrough using high-grade local grains and British protein sources. Complete nourishment for your companion.`
    });
  });
});

// Pad products to make exactly 30 products
for (let i = products.length; i < 30; i++) {
  const seed = i * 23;
  const size = SIZES[seed % SIZES.length];
  const sizeMultiplier = size === "1.5kg" ? 0.15 : size === "6kg" ? 0.55 : 1.0;
  const price = Math.round((42 + (seed % 15)) * sizeMultiplier * 100) / 100;
  const stage = STAGES[seed % STAGES.length];
  const proteinSrc = PROTEINS[seed % PROTEINS.length];
  skuCounter++;

  products.push({
    id: `prod-${skuCounter}`,
    name: `TEES SPECIAL — ${proteinSrc} & Rice`,
    formulation: "TEES SPECIAL",
    lifeStage: stage,
    proteinSource: proteinSrc,
    bagSize: size,
    price,
    tradePrice: Math.round(price * 0.76 * 100) / 100,
    wholesalePrice: Math.round(price * 0.69 * 100) / 100,
    distributorPrice: Math.round(price * 0.64 * 100) / 100,
    rrp: price,
    stock: Math.round(40 + pseudoRandom(seed) * 200),
    sku: `TV-DOG-${skuCounter}`,
    protein: 26,
    fat: 14,
    fibre: 3.0,
    ash: 7.0,
    moisture: 9,
    energy: "3,620 kcal/kg",
    ingredients: [
      { name: `${proteinSrc}`, percentage: 35, source: "Darlington Farms", function: "Premium digestible proteins" },
      { name: "Rice & Barley", percentage: 30, source: "Teesside Agricultural", function: "Complex energy matrix" },
      { name: "Linseed & Herbs", percentage: 3, source: "Tees Valley Botanical", function: "Coat conditioning & immunity" }
    ],
    description: "Specialized small-batch formulation focusing on single-source protein digestibility and local grain compounds."
  });
}

// 2. GENERATE 100 CUSTOMERS
export const UK_CITIES = [
  { city: "Middlesbrough", postcodes: ["TS1", "TS3", "TS4", "TS5"] },
  { city: "Stockton-on-Tees", postcodes: ["TS18", "TS19", "TS20"] },
  { city: "Redcar", postcodes: ["TS10", "TS11"] },
  { city: "Hartlepool", postcodes: ["TS24", "TS25", "TS26"] },
  { city: "Darlington", postcodes: ["DL1", "DL2", "DL3"] },
  { city: "Guisborough", postcodes: ["TS14"] },
  { city: "Saltburn-by-the-Sea", postcodes: ["TS12"] },
  { city: "Yarm", postcodes: ["TS15"] }
];

export const FIRST_NAMES = ["James", "Emma", "William", "Olivia", "Thomas", "Sophie", "George", "Charlotte", "Harry", "Amelia", "Jack", "Isla", "Oliver", "Emily", "Noah", "Ava", "Charlie", "Mia", "Jacob", "Lily"];
export const LAST_NAMES = ["Smith", "Jones", "Taylor", "Brown", "Wilson", "Johnson", "Davies", "Robinson", "Wright", "Thompson", "Evans", "Walker", "White", "Roberts", "Green", "Hall", "Wood", "Jackson", "Clarke", "Teasdale"];

export const customers: Customer[] = [];
for (let i = 1; i <= 100; i++) {
  const seed = i * 17;
  const fName = FIRST_NAMES[seed % FIRST_NAMES.length];
  const lName = LAST_NAMES[(seed + 7) % LAST_NAMES.length];
  const cityData = UK_CITIES[seed % UK_CITIES.length];
  const postcode = `${cityData.postcodes[seed % cityData.postcodes.length]} ${Math.round(1 + pseudoRandom(seed) * 8)}${String.fromCharCode(65 + (seed % 26))}${String.fromCharCode(65 + ((seed + 3) % 26))}`;

  customers.push({
    id: `cust-${1000 + i}`,
    name: `${fName} ${lName}`,
    email: `${fName.toLowerCase()}.${lName.toLowerCase()}${i}@teesside-dogs.co.uk`,
    city: cityData.city,
    postcode,
    isTrade: i <= 20 // First 20 are B2B buyers
  });
}

// 3. GENERATE 20 TRADE ACCOUNTS
export const COMPANY_SUFFIXES = ["Pet Supplies", "Vets", "Working Dogs", "Canine Feed", "Wholesale Pet", "K9 Nutrition", "Dog Care Center"];
export const tradeAccounts: TradeAccount[] = [];

for (let i = 1; i <= 20; i++) {
  const seed = i * 31;
  const suffix = COMPANY_SUFFIXES[seed % COMPANY_SUFFIXES.length];
  const place = UK_CITIES[seed % UK_CITIES.length].city;
  const companyName = `${place} ${suffix}`;
  
  const buyer = customers[i - 1]; // Link to first 20 customers
  const tier = i <= 5 ? "DISTRIBUTOR" : i <= 12 ? "WHOLESALE" : "TRADE";
  const creditLimit = tier === "DISTRIBUTOR" ? 15000 : tier === "WHOLESALE" ? 5000 : 1500;
  
  tradeAccounts.push({
    id: `trade-${200 + i}`,
    companyName,
    accountNumber: `TV-ACC-00${i}`,
    vatNumber: `GB${Math.round(100000000 + pseudoRandom(seed) * 899999999)}`,
    contactName: buyer.name,
    email: buyer.email,
    phone: `01642 ${Math.round(500000 + pseudoRandom(seed) * 499999)}`,
    address: `${Math.round(10 + pseudoRandom(seed) * 120)} Industrial Estate Road, Middlehaven, ${place}, TS2 1RE`,
    tier,
    creditTerms: tier === "DISTRIBUTOR" ? "Net 60" : "Net 30",
    creditLimit,
    balance: Math.round(pseudoRandom(seed) * creditLimit * 0.7 * 100) / 100
  });
}

// 4. GENERATE 20 BATCHES
export const warehouseLocations = ["WH-A-01", "WH-A-02", "WH-B-05", "WH-C-10", "WH-R-03"];
export const batchManagers = ["Sarah Jenkins (QC Lead)", "Michael Corby (Production Head)", "David Vance (Logistics Chief)"];

export const batches: Batch[] = [];
for (let i = 1; i <= 20; i++) {
  const seed = i * 43;
  const p = products[seed % products.length];
  const dateNum = 25 - (i % 10); // deterministic range of September dates
  const dateStr = `2026-09-${dateNum < 10 ? '0' + dateNum : dateNum}`;
  
  batches.push({
    id: `TV-${260925 - i * 13}`,
    productId: p.id,
    productName: p.name,
    productionDate: dateStr,
    ingredients: [
      { name: p.proteinSource, testStatus: 'PASSED' },
      { name: "Local Barley/Oat Stock", testStatus: 'PASSED' },
      { name: "Macro Vitamin Blend", testStatus: seed % 19 === 0 ? 'FAILED' : 'PASSED' } // 1 batch fails macro check for simulation variety
    ],
    productionLine: `Tees-Line ${1 + (seed % 3)}`,
    qualityCheck: {
      moistureCheck: 'PASSED',
      proteinCheck: 'PASSED',
      foreignBodyScan: 'PASSED',
      microbialScreen: 'PASSED',
      releaseAuthorizedBy: batchManagers[seed % batchManagers.length]
    },
    warehouseLocation: warehouseLocations[seed % warehouseLocations.length],
    status: seed % 11 === 0 ? 'QUARANTINE' : 'RELEASED'
  });
}

// 5. GENERATE 100 HISTORICAL ORDERS & 50 INVOICES
export const orders: Order[] = [];
export const invoices: Invoice[] = [];

let orderCounter = 20481;
let invoiceCounter = 90124;

// Populate historical orders
for (let i = 1; i <= 100; i++) {
  const seed = i * 59;
  const isTradeOrder = i % 3 !== 0; // 66% are Trade (B2B) orders
  const dateNum = 25 - (i % 20);
  const dateStr = `2026-09-${dateNum < 10 ? '0' + dateNum : dateNum}`;
  
  let customerName = "";
  let companyName = "";
  let accountNum = "";
  let tier: 'TRADE' | 'WHOLESALE' | 'DISTRIBUTOR' = 'TRADE';
  
  if (isTradeOrder) {
    const tradeAcc = tradeAccounts[seed % tradeAccounts.length];
    customerName = tradeAcc.contactName;
    companyName = tradeAcc.companyName;
    accountNum = tradeAcc.accountNumber;
    tier = tradeAcc.tier;
  } else {
    const cust = customers[seed % customers.length];
    customerName = cust.name;
  }

  // pick 1-3 random products
  const orderItems: { productName: string; sku: string; quantity: number; price: number }[] = [];
  const numItems = 1 + (seed % 3);
  let orderTotal = 0;

  for (let j = 0; j < numItems; j++) {
    const itemSeed = seed + j * 17;
    const prod = products[itemSeed % products.length];
    
    // Trade customers get tier pricing, retail gets retail price
    let itemPrice = prod.price;
    if (isTradeOrder) {
      if (tier === "DISTRIBUTOR") itemPrice = prod.distributorPrice;
      else if (tier === "WHOLESALE") itemPrice = prod.wholesalePrice;
      else itemPrice = prod.tradePrice;
    }

    const qty = isTradeOrder ? Math.round(5 + pseudoRandom(itemSeed) * 20) : Math.round(1 + pseudoRandom(itemSeed) * 3);
    orderItems.push({
      productName: prod.name,
      sku: prod.sku,
      quantity: qty,
      price: itemPrice
    });
    orderTotal += itemPrice * qty;
  }

  const roundedTotal = Math.round(orderTotal * 100) / 100;
  const statuses: Order['status'][] = ["CONFIRMED", "ALLOCATED", "PACKED", "DISPATCHED", "DELIVERED"];
  const orderStatus = statuses[seed % statuses.length];

  const currentOrderId = `TV-ORD-${orderCounter++}`;

  orders.push({
    id: currentOrderId,
    customerName,
    companyName: isTradeOrder ? companyName : undefined,
    date: dateStr,
    items: orderItems,
    total: roundedTotal,
    status: orderStatus,
    isTrade: isTradeOrder,
    trackingNumber: orderStatus !== "CONFIRMED" ? `TV-SHP-87${i}09` : undefined
  });

  // Generate 50 Invoices for the B2B orders
  if (isTradeOrder && invoices.length < 50) {
    const invoiceId = `TV-INV-${invoiceCounter++}`;
    const issueDate = dateStr;
    const dueDay = dateNum + (tier === "DISTRIBUTOR" ? 60 : 30);
    // calculate a proper future date string
    const dueDateStr = dueDay > 30 ? `2026-10-${(dueDay - 30).toString().padStart(2, '0')}` : `2026-09-${dueDay.toString().padStart(2, '0')}`;
    
    invoices.push({
      id: invoiceId,
      orderId: currentOrderId,
      companyName,
      accountNumber: accountNum,
      date: issueDate,
      dueDate: dueDateStr,
      amount: roundedTotal,
      status: seed % 5 === 0 ? 'OVERDUE' : seed % 3 === 0 ? 'UNPAID' : 'PAID',
      poReference: `PO-${10000 + i}`
    });
  }
}

// 6. HELPER TO GET STATISTICS FOR B2B
export function getB2BStats() {
  const totalOutstanding = invoices
    .filter(inv => inv.status !== 'PAID')
    .reduce((sum, inv) => sum + inv.amount, 0);

  const totalPaid = invoices
    .filter(inv => inv.status === 'PAID')
    .reduce((sum, inv) => sum + inv.amount, 0);

  const lowStockProducts = products.filter(p => p.stock < 100);

  return {
    outstandingBalance: Math.round(totalOutstanding * 100) / 100,
    paidInvoicesCount: invoices.filter(i => i.status === 'PAID').length,
    unpaidInvoicesCount: invoices.filter(i => i.status !== 'PAID').length,
    lowStockCount: lowStockProducts.length,
    activeOrdersCount: orders.filter(o => o.isTrade && o.status !== 'DELIVERED').length
  };
}
