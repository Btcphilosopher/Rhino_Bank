'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Product, 
  TradeAccount, 
  Order, 
  Invoice, 
  Batch, 
  products, 
  tradeAccounts, 
  orders as seededOrders, 
  invoices as seededInvoices, 
  batches as seededBatches 
} from './data';

export interface CartItem {
  product: Product;
  quantity: number;
  isSubscription?: boolean;
  interval?: string; // "2 weeks" | "4 weeks" | "6 weeks" | "8 weeks"
}

export interface DogProfile {
  name: string;
  breed: string;
  age: number;
  weight: number;
  activityLevel: 'LOW' | 'ACTIVE' | 'WORKING';
  allergies: string; // Exclusions
  preference: string;
}

export interface Subscription {
  id: string;
  product: Product;
  quantity: number;
  interval: string;
  dogName: string;
  nextDelivery: string;
  price: number;
  status: 'ACTIVE' | 'PAUSED';
}

interface AppContextType {
  viewMode: 'b2c' | 'b2b';
  setViewMode: (mode: 'b2c' | 'b2b') => void;
  
  // B2C Cart state
  cart: CartItem[];
  addToCart: (product: Product, quantity: number, isSubscription?: boolean, interval?: string) => void;
  removeFromCart: (productId: string, isSubscription?: boolean) => void;
  updateCartQty: (productId: string, qty: number, isSubscription?: boolean) => void;
  clearCart: () => void;
  
  // Dog Profile state
  dogProfile: DogProfile | null;
  saveDogProfile: (profile: DogProfile) => void;
  clearDogProfile: () => void;
  recommendedProducts: Product[];

  // B2B login & pricing tier state
  activeTradeAccount: TradeAccount | null;
  loginAsTrade: (accountId: string) => void;
  logoutTrade: () => void;

  // B2B cart state
  b2bCart: { product: Product; quantity: number }[];
  addToB2bCart: (product: Product, quantity: number) => void;
  updateB2bCartQty: (productId: string, qty: number) => void;
  removeFromB2bCart: (productId: string) => void;
  clearB2bCart: () => void;

  // Global lists (Stateful copies of seeded data to allow mock modifications)
  orders: Order[];
  invoices: Invoice[];
  batches: Batch[];
  subscriptions: Subscription[];
  
  // Action Handlers
  submitB2COrder: (deliveryDetails: any) => Order;
  submitB2BOrder: (poReference: string) => Order;
  payInvoice: (invoiceId: string) => void;
  pauseSubscription: (subId: string) => void;
  resumeSubscription: (subId: string) => void;
  cancelSubscription: (subId: string) => void;

  // Selected State helpers (modals etc)
  selectedProduct: Product | null;
  setSelectedProduct: (product: Product | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [viewMode, setViewMode] = useState<'b2c' | 'b2b'>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('tv_view_mode');
      if (stored === 'b2c' || stored === 'b2b') return stored;
    }
    return 'b2c';
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('tv_cart');
      if (stored) {
        try { return JSON.parse(stored); } catch (e) { return []; }
      }
    }
    return [];
  });

  const [dogProfile, setDogProfile] = useState<DogProfile | null>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('tv_dog_profile');
      if (stored) {
        try { return JSON.parse(stored); } catch (e) { return null; }
      }
    }
    return null;
  });

  const [activeTradeAccount, setActiveTradeAccount] = useState<TradeAccount | null>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('tv_active_trade_acc');
      if (stored) {
        try { return JSON.parse(stored); } catch (e) { return null; }
      }
    }
    return null;
  });

  const [b2bCart, setB2bCart] = useState<{ product: Product; quantity: number }[]>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('tv_b2b_cart');
      if (stored) {
        try { return JSON.parse(stored); } catch (e) { return []; }
      }
    }
    return [];
  });
  
  const [orders, setOrders] = useState<Order[]>(() => seededOrders);
  const [invoices, setInvoices] = useState<Invoice[]>(() => seededInvoices);
  const [batches, setBatches] = useState<Batch[]>(() => seededBatches);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>(() => [
    {
      id: 'SUB-402',
      product: products[0], // Tees Original
      quantity: 1,
      interval: 'Every 4 weeks',
      dogName: 'Milo',
      nextDelivery: '2026-10-15',
      price: products[0].price * 0.9, // 10% discount
      status: 'ACTIVE'
    },
    {
      id: 'SUB-405',
      product: products[4], // Tees Puppy
      quantity: 2,
      interval: 'Every 2 weeks',
      dogName: 'Luna',
      nextDelivery: '2026-10-02',
      price: products[4].price * 2 * 0.9,
      status: 'ACTIVE'
    }
  ]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Save changes to localStorage
  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('tv_view_mode', viewMode);
    }
  }, [viewMode]);

  useEffect(() => {
    if (typeof window !== 'undefined' && cart.length > 0) {
      localStorage.setItem('tv_cart', JSON.stringify(cart));
    } else {
      localStorage.removeItem('tv_cart');
    }
  }, [cart]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      if (dogProfile) localStorage.setItem('tv_dog_profile', JSON.stringify(dogProfile));
      else localStorage.removeItem('tv_dog_profile');
    }
  }, [dogProfile]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      if (activeTradeAccount) localStorage.setItem('tv_active_trade_acc', JSON.stringify(activeTradeAccount));
      else localStorage.removeItem('tv_active_trade_acc');
    }
  }, [activeTradeAccount]);

  useEffect(() => {
    if (typeof window !== 'undefined' && b2bCart.length > 0) {
      localStorage.setItem('tv_b2b_cart', JSON.stringify(b2bCart));
    } else {
      localStorage.removeItem('tv_b2b_cart');
    }
  }, [b2bCart]);

  // B2C Cart Handlers
  const addToCart = (product: Product, quantity: number, isSubscription = false, interval = '4 weeks') => {
    setCart(prev => {
      const existingIdx = prev.findIndex(item => 
        item.product.id === product.id && 
        !!item.isSubscription === isSubscription && 
        item.interval === (isSubscription ? interval : undefined)
      );

      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += quantity;
        return updated;
      } else {
        return [...prev, { product, quantity, isSubscription, interval: isSubscription ? interval : undefined }];
      }
    });
  };

  const removeFromCart = (productId: string, isSubscription = false) => {
    setCart(prev => prev.filter(item => !(item.product.id === productId && !!item.isSubscription === isSubscription)));
  };

  const updateCartQty = (productId: string, qty: number, isSubscription = false) => {
    if (qty <= 0) {
      removeFromCart(productId, isSubscription);
      return;
    }
    setCart(prev => prev.map(item => 
      item.product.id === productId && !!item.isSubscription === isSubscription
        ? { ...item, quantity: qty }
        : item
    ));
  };

  const clearCart = () => setCart([]);

  // Dog Profile Handlers
  const saveDogProfile = (profile: DogProfile) => {
    setDogProfile(profile);
  };

  const clearDogProfile = () => {
    setDogProfile(null);
  };

  // Recommendations logic (Based on lifeStage, activity level, exclusions)
  const recommendedProducts = React.useMemo(() => {
    if (!dogProfile) return products.slice(0, 4); // default items

    return products.filter(p => {
      // 1. Allergies exclusion filter
      if (dogProfile.allergies) {
        const lowerAllergy = dogProfile.allergies.toLowerCase();
        if (p.name.toLowerCase().includes(lowerAllergy) || p.proteinSource.toLowerCase().includes(lowerAllergy)) {
          return false;
        }
      }

      // 2. Life stage matching
      if (p.lifeStage === (dogProfile.age <= 1 ? 'PUPPY' : dogProfile.age >= 8 ? 'SENIOR' : 'ADULT')) {
        return true;
      }

      // 3. Activity matching
      if (dogProfile.activityLevel === 'WORKING' && p.lifeStage === 'WORKING') {
        return true;
      }
      
      return p.name.includes("ORIGINAL");
    }).slice(0, 4); // Limit to top 4 recommendations
  }, [dogProfile]);

  // B2B Login Handlers
  const loginAsTrade = (accountId: string) => {
    const acc = tradeAccounts.find(t => t.id === accountId);
    if (acc) {
      setActiveTradeAccount(acc);
      setViewMode('b2b'); // automatically swap view to trade portal
    }
  };

  const logoutTrade = () => {
    setActiveTradeAccount(null);
    setB2bCart([]);
    setViewMode('b2c');
  };

  // B2B Cart Handlers
  const addToB2bCart = (product: Product, quantity: number) => {
    setB2bCart(prev => {
      const idx = prev.findIndex(item => item.product.id === product.id);
      if (idx > -1) {
        const updated = [...prev];
        updated[idx].quantity += quantity;
        return updated;
      }
      return [...prev, { product, quantity }];
    });
  };

  const updateB2bCartQty = (productId: string, qty: number) => {
    if (qty <= 0) {
      setB2bCart(prev => prev.filter(i => i.product.id !== productId));
      return;
    }
    setB2bCart(prev => prev.map(item => item.product.id === productId ? { ...item, quantity: qty } : item));
  };

  const removeFromB2bCart = (productId: string) => {
    setB2bCart(prev => prev.filter(i => i.product.id !== productId));
  };

  const clearB2bCart = () => setB2bCart([]);

  // Checkout submissions
  const submitB2COrder = (deliveryDetails: any) => {
    const newOrderId = `TV-ORD-${Math.round(25000 + Math.random() * 5000)}`;
    const orderTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    
    const newOrder: Order = {
      id: newOrderId,
      customerName: deliveryDetails.fullName || "Guest Customer",
      date: new Date().toISOString().split('T')[0],
      items: cart.map(item => ({
        productName: item.product.name,
        sku: item.product.sku,
        quantity: item.quantity,
        price: item.product.price
      })),
      total: Math.round(orderTotal * 100) / 100,
      status: 'CONFIRMED',
      isTrade: false,
      trackingNumber: `TV-SHP-88${Math.round(100 + Math.random() * 899)}`
    };

    // Add subscription if there is one in cart
    cart.forEach(item => {
      if (item.isSubscription && item.interval) {
        const subId = `SUB-${Math.round(500 + Math.random() * 499)}`;
        setSubscriptions(prev => [
          ...prev,
          {
            id: subId,
            product: item.product,
            quantity: item.quantity,
            interval: `Every ${item.interval}`,
            dogName: dogProfile?.name || 'My Dog',
            nextDelivery: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 14 days out
            price: Math.round(item.product.price * item.quantity * 0.9 * 100) / 100, // 10% sub discount
            status: 'ACTIVE'
          }
        ]);
      }
    });

    setOrders(prev => [newOrder, ...prev]);
    clearCart();
    return newOrder;
  };

  const submitB2BOrder = (poReference: string) => {
    if (!activeTradeAccount) throw new Error("Must be logged in to trade account");

    const newOrderId = `TV-ORD-${Math.round(25000 + Math.random() * 5000)}`;
    
    // Choose appropriate pricing based on trade tier
    const getPrice = (p: Product) => {
      if (activeTradeAccount.tier === 'DISTRIBUTOR') return p.distributorPrice;
      if (activeTradeAccount.tier === 'WHOLESALE') return p.wholesalePrice;
      return p.tradePrice;
    };

    const orderTotal = b2bCart.reduce((sum, item) => sum + getPrice(item.product) * item.quantity, 0);
    const vat = orderTotal * 0.20; // 20% Standard UK VAT (dog food in bulk/trade attracts VAT)
    const grandTotal = Math.round((orderTotal + vat) * 100) / 100;

    const newOrder: Order = {
      id: newOrderId,
      customerName: activeTradeAccount.contactName,
      companyName: activeTradeAccount.companyName,
      date: new Date().toISOString().split('T')[0],
      items: b2bCart.map(item => ({
        productName: item.product.name,
        sku: item.product.sku,
        quantity: item.quantity,
        price: getPrice(item.product)
      })),
      total: grandTotal,
      status: 'ALLOCATED',
      isTrade: true,
      trackingNumber: `TV-SHP-89${Math.round(100 + Math.random() * 899)}`
    };

    // Create corresponding Invoice
    const newInvoiceId = `TV-INV-${Math.round(95000 + Math.random() * 4999)}`;
    const newInvoice: Invoice = {
      id: newInvoiceId,
      orderId: newOrderId,
      companyName: activeTradeAccount.companyName,
      accountNumber: activeTradeAccount.accountNumber,
      date: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // Net 30 default
      amount: grandTotal,
      status: 'UNPAID',
      poReference: poReference || 'PO-ONLINE'
    };

    setOrders(prev => [newOrder, ...prev]);
    setInvoices(prev => [newInvoice, ...prev]);
    
    // Deduct credit balance on account
    setActiveTradeAccount(prev => {
      if (!prev) return null;
      return {
        ...prev,
        balance: Math.round((prev.balance + grandTotal) * 100) / 100
      };
    });

    clearB2bCart();
    return newOrder;
  };

  const payInvoice = (invoiceId: string) => {
    setInvoices(prev => prev.map(inv => inv.id === invoiceId ? { ...inv, status: 'PAID' } : inv));
    
    // Reduce trade account outstanding balance copy
    const inv = invoices.find(i => i.id === invoiceId);
    if (inv && activeTradeAccount) {
      setActiveTradeAccount(prev => {
        if (!prev) return null;
        return {
          ...prev,
          balance: Math.max(0, Math.round((prev.balance - inv.amount) * 100) / 100)
        };
      });
    }
  };

  // Subscriptions management
  const pauseSubscription = (subId: string) => {
    setSubscriptions(prev => prev.map(sub => sub.id === subId ? { ...sub, status: 'PAUSED' } : sub));
  };

  const resumeSubscription = (subId: string) => {
    setSubscriptions(prev => prev.map(sub => sub.id === subId ? { ...sub, status: 'ACTIVE' } : sub));
  };

  const cancelSubscription = (subId: string) => {
    setSubscriptions(prev => prev.filter(sub => sub.id !== subId));
  };

  return (
    <AppContext.Provider value={{
      viewMode,
      setViewMode,
      cart,
      addToCart,
      removeFromCart,
      updateCartQty,
      clearCart,
      
      dogProfile,
      saveDogProfile,
      clearDogProfile,
      recommendedProducts,

      activeTradeAccount,
      loginAsTrade,
      logoutTrade,

      b2bCart,
      addToB2bCart,
      updateB2bCartQty,
      removeFromB2bCart,
      clearB2bCart,

      orders,
      invoices,
      batches,
      subscriptions,

      submitB2COrder,
      submitB2BOrder,
      payInvoice,
      pauseSubscription,
      resumeSubscription,
      cancelSubscription,

      selectedProduct,
      setSelectedProduct
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
