import React, { useState } from 'react';
import {
  ArrowRight,
  Building2,
  Calculator,
  CheckCircle2,
  DollarSign,
  Layers,
  PlusCircle,
  ShieldCheck,
  Sparkles,
  TrendingUp
} from 'lucide-react';
import { useTerminal } from '../../context/TerminalContext';
import { CreditRating, Currency, Seniority } from '../../types';
import { optimizeNewBondIssuance } from '../../quant/issuanceOptimizer';

export const NewIssueScreen: React.FC = () => {
  const { activeIssuer, setActiveScreen, setActiveDeal } = useTerminal();

  // Debt Origination Form Inputs
  const [targetAmount, setTargetAmount] = useState<number>(500);
  const [tenorYears, setTenorYears] = useState<number>(10);
  const [currency, setCurrency] = useState<Currency>('GBP');
  const [seniority, setSeniority] = useState<Seniority>('Senior Unsecured');
  const [expectedRating, setExpectedRating] = useState<CreditRating>('A-');
  const [benchmarkRate, setBenchmarkRate] = useState<number>(0.0435); // 4.35%
  const [baseSpreadBps, setBaseSpreadBps] = useState<number>(135);
  const [useOfProceeds, setUseOfProceeds] = useState<string>('Refinancing existing term debt and funding green energy capex.');

  const optimization = optimizeNewBondIssuance({
    targetAmountMillions: targetAmount,
    tenorYears,
    seniority,
    expectedRating,
    currency,
    benchmarkRate,
    issuerBaseSpreadBps: baseSpreadBps
  });

  const launchSyndication = () => {
    setActiveScreen('order-book');
  };

  return (
    <div className="p-4 space-y-4 font-sans text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-wrap items-center justify-between gap-3 font-mono">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-cyan-500/20 text-cyan-400 rounded border border-cyan-500/30">
            <PlusCircle className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-100">NEW BOND ISSUANCE WORKSTATION</h1>
            <p className="text-[11px] text-slate-400">
              Debt Origination • Pricing Scenario Optimizer • Capital Structure Impact
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-300 font-bold">ISSUER:</span>
          <span className="px-2.5 py-1 bg-slate-800 border border-slate-700 text-cyan-300 font-bold rounded text-xs">
            {activeIssuer.name} ({activeIssuer.ticker})
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 font-mono">
        {/* Left Column: Debt Structuring Form */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2">
            ISSUANCE PARAMETERS
          </div>

          <div className="space-y-3 text-[11px]">
            <div>
              <label className="text-slate-400 block mb-1 text-[10px]">TARGET ISSUANCE AMOUNT (MILLIONS)</label>
              <div className="relative">
                <input
                  type="number"
                  value={targetAmount}
                  onChange={(e) => setTargetAmount(parseFloat(e.target.value) || 100)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-cyan-300 font-bold text-sm"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-400 block mb-1 text-[10px]">TENOR (YEARS)</label>
                <input
                  type="number"
                  value={tenorYears}
                  onChange={(e) => setTenorYears(parseInt(e.target.value) || 5)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-slate-100 font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1 text-[10px]">CURRENCY</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as Currency)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-cyan-300 font-bold"
                >
                  <option value="GBP">GBP (£)</option>
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-400 block mb-1 text-[10px]">SENIORITY RANKING</label>
                <select
                  value={seniority}
                  onChange={(e) => setSeniority(e.target.value as Seniority)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-slate-200"
                >
                  <option value="Senior Unsecured">Senior Unsecured</option>
                  <option value="Senior Secured">Senior Secured</option>
                  <option value="Subordinated">Subordinated</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1 text-[10px]">EXPECTED RATING</label>
                <input
                  type="text"
                  value={expectedRating}
                  onChange={(e) => setExpectedRating(e.target.value as CreditRating)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-cyan-300 font-bold"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-400 block mb-1 text-[10px]">BENCHMARK YIELD (%)</label>
                <input
                  type="number"
                  step="0.001"
                  value={(benchmarkRate * 100).toFixed(2)}
                  onChange={(e) => setBenchmarkRate((parseFloat(e.target.value) || 0) / 100)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-slate-100"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1 text-[10px]">BASE SPREAD (BPS)</label>
                <input
                  type="number"
                  value={baseSpreadBps}
                  onChange={(e) => setBaseSpreadBps(parseInt(e.target.value) || 100)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-amber-300 font-bold"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1 text-[10px]">USE OF PROCEEDS</label>
              <textarea
                value={useOfProceeds}
                onChange={(e) => setUseOfProceeds(e.target.value)}
                rows={2}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200 text-[10px] font-sans"
              />
            </div>
          </div>
        </div>

        {/* Right 2 Columns: Pricing Scenarios & Debt Service Impact */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
            <div className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center justify-between">
              <span>QUANTITATIVE PRICING SCENARIOS</span>
              <span className="text-[10px] text-cyan-400">MARKET DEMAND OPTIMIZER</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Tight Scenario */}
              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
                <div className="text-cyan-400 font-bold text-xs">TIGHT GUIDANCE</div>
                <div className="text-lg font-bold text-slate-100">+{optimization.tightPricing.spreadBps} bps</div>
                <div className="text-[11px] text-slate-300">
                  Yield: <span className="font-bold">{optimization.tightPricing.yield}%</span>
                </div>
                <div className="text-[11px] text-slate-300">
                  Annual Exp: <span className="font-bold">£{optimization.tightPricing.annualInterestExpense}m</span>
                </div>
                <div className="text-[10px] text-emerald-400 font-bold border-t border-slate-800 pt-1">
                  Demand Ratio: {optimization.tightPricing.estimatedDemandRatio}x
                </div>
              </div>

              {/* Base Scenario */}
              <div className="p-3 bg-slate-950 rounded border border-cyan-500/40 space-y-2 bg-cyan-500/5">
                <div className="text-cyan-300 font-bold text-xs flex items-center justify-between">
                  <span>BASE PRICING</span>
                  <span className="text-[9px] bg-cyan-500/20 px-1 rounded text-cyan-300">RECOMMENDED</span>
                </div>
                <div className="text-xl font-bold text-amber-300">+{optimization.basePricing.spreadBps} bps</div>
                <div className="text-[11px] text-slate-200">
                  Yield: <span className="font-bold">{optimization.basePricing.yield}%</span>
                </div>
                <div className="text-[11px] text-slate-200">
                  Annual Exp: <span className="font-bold">£{optimization.basePricing.annualInterestExpense}m</span>
                </div>
                <div className="text-[10px] text-emerald-400 font-bold border-t border-slate-800 pt-1">
                  Demand Ratio: {optimization.basePricing.estimatedDemandRatio}x
                </div>
              </div>

              {/* Concession Scenario */}
              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
                <div className="text-slate-400 font-bold text-xs">CONCESSION PRICING</div>
                <div className="text-lg font-bold text-slate-100">+{optimization.concessionPricing.spreadBps} bps</div>
                <div className="text-[11px] text-slate-300">
                  Yield: <span className="font-bold">{optimization.concessionPricing.yield}%</span>
                </div>
                <div className="text-[11px] text-slate-300">
                  Annual Exp: <span className="font-bold">£{optimization.concessionPricing.annualInterestExpense}m</span>
                </div>
                <div className="text-[10px] text-emerald-400 font-bold border-t border-slate-800 pt-1">
                  Demand Ratio: {optimization.concessionPricing.estimatedDemandRatio}x
                </div>
              </div>
            </div>

            {/* Launch Primary Market Button */}
            <div className="pt-2">
              <button
                onClick={launchSyndication}
                className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-xs flex items-center justify-center gap-2 transition"
              >
                <span>LAUNCH DEAL TO PRIMARY ORDER BOOK SYNDICATION</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
