import React, { useState } from 'react';
import {
  BarChart3,
  CheckCircle2,
  GitCommit,
  Globe,
  LineChart,
  RefreshCw,
  Sliders,
  TrendingUp
} from 'lucide-react';
import { useTerminal } from '../../context/TerminalContext';

export const YieldCurveScreen: React.FC = () => {
  const { curves, activeCurve, setActiveCurve } = useTerminal();

  const [rateType, setRateType] = useState<'spotRate' | 'parRate' | 'zeroRate' | 'forwardRate'>('spotRate');

  return (
    <div className="p-4 space-y-4 font-sans text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-wrap items-center justify-between gap-3 font-mono">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded border border-emerald-500/30">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-100">BENCHMARK YIELD CURVES & BOOTSTRAPPING</h1>
            <p className="text-[11px] text-slate-400">
              Multi-Curve Framework • Spot, Par, Zero & Forward Curve Engine
            </p>
          </div>
        </div>

        {/* Curve Selector */}
        <div className="flex items-center gap-2">
          <select
            value={activeCurve.id}
            onChange={(e) => {
              const c = curves.find((x) => x.id === e.target.value);
              if (c) setActiveCurve(c);
            }}
            className="bg-slate-950 border border-slate-700 text-cyan-300 font-bold text-xs px-2.5 py-1.5 rounded focus:outline-none"
          >
            {curves.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.currency})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Columns: Visual Curve Graph Representation */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3 font-mono">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <LineChart className="w-4 h-4 text-emerald-400" />
              <span>{activeCurve.name} — CURVE STRUCTURE</span>
            </div>

            {/* Rate Type Selector */}
            <div className="flex bg-slate-950 rounded border border-slate-800 p-0.5 text-[10px]">
              <button
                onClick={() => setRateType('spotRate')}
                className={`px-2 py-1 rounded ${
                  rateType === 'spotRate' ? 'bg-cyan-600 text-slate-950 font-bold' : 'text-slate-400'
                }`}
              >
                SPOT
              </button>
              <button
                onClick={() => setRateType('parRate')}
                className={`px-2 py-1 rounded ${
                  rateType === 'parRate' ? 'bg-cyan-600 text-slate-950 font-bold' : 'text-slate-400'
                }`}
              >
                PAR
              </button>
              <button
                onClick={() => setRateType('zeroRate')}
                className={`px-2 py-1 rounded ${
                  rateType === 'zeroRate' ? 'bg-cyan-600 text-slate-950 font-bold' : 'text-slate-400'
                }`}
              >
                ZERO
              </button>
              <button
                onClick={() => setRateType('forwardRate')}
                className={`px-2 py-1 rounded ${
                  rateType === 'forwardRate' ? 'bg-cyan-600 text-slate-950 font-bold' : 'text-slate-400'
                }`}
              >
                FORWARD
              </button>
            </div>
          </div>

          {/* SVG Visual Curve Rendering */}
          <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-4 h-64 relative flex flex-col justify-between">
            <div className="flex justify-between text-[10px] text-slate-500 border-b border-slate-800 pb-1">
              <span>YIELD (%)</span>
              <span>CURVE MATURITY (1Y TO 30Y)</span>
            </div>

            {/* SVG Plot */}
            <div className="relative flex-1 w-full flex items-end">
              <svg className="w-full h-full overflow-visible" viewBox="0 0 500 150">
                {/* Grid Lines */}
                <line x1="0" y1="30" x2="500" y2="30" stroke="#334155" strokeDasharray="3 3" />
                <line x1="0" y1="75" x2="500" y2="75" stroke="#334155" strokeDasharray="3 3" />
                <line x1="0" y1="120" x2="500" y2="120" stroke="#334155" strokeDasharray="3 3" />

                {/* Plot Line */}
                {activeCurve.points.length > 1 && (
                  <polyline
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="3"
                    points={activeCurve.points
                      .map((pt, idx) => {
                        const x = (idx / (activeCurve.points.length - 1)) * 480 + 10;
                        const val = pt[rateType];
                        const y = 140 - (val - 0.02) * 2800; // scaling
                        return `${x},${Math.max(10, Math.min(140, y))}`;
                      })
                      .join(' ')}
                  />
                )}

                {/* Curve Data Nodes */}
                {activeCurve.points.map((pt, idx) => {
                  const x = (idx / (activeCurve.points.length - 1)) * 480 + 10;
                  const val = pt[rateType];
                  const y = Math.max(10, Math.min(140, 140 - (val - 0.02) * 2800));
                  return (
                    <g key={pt.tenor}>
                      <circle cx={x} cy={y} r="5" fill="#06b6d4" stroke="#0f172a" strokeWidth="2" />
                      <text x={x} y={y - 10} fill="#38bdf8" fontSize="10" textAnchor="middle" fontWeight="bold">
                        {(val * 100).toFixed(2)}%
                      </text>
                      <text x={x} y={145} fill="#64748b" fontSize="9" textAnchor="middle">
                        {pt.tenor}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>
          </div>
        </div>

        {/* Right Col: Curve Points Table */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3 font-mono">
          <div className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2">
            TENOR RATES & SPREADS
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-[11px]">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                  <th className="py-2 px-2">TENOR</th>
                  <th className="py-2 px-2 text-right">SPOT</th>
                  <th className="py-2 px-2 text-right">PAR</th>
                  <th className="py-2 px-2 text-right">ZERO</th>
                  <th className="py-2 px-2 text-right">FORWARD</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {activeCurve.points.map((pt) => (
                  <tr key={pt.tenor} className="hover:bg-slate-800/60">
                    <td className="py-2 px-2 font-bold text-cyan-300">{pt.tenor}</td>
                    <td className="py-2 px-2 text-right font-bold text-emerald-400">{(pt.spotRate * 100).toFixed(2)}%</td>
                    <td className="py-2 px-2 text-right text-slate-200">{(pt.parRate * 100).toFixed(2)}%</td>
                    <td className="py-2 px-2 text-right text-slate-200">{(pt.zeroRate * 100).toFixed(2)}%</td>
                    <td className="py-2 px-2 text-right font-bold text-amber-300">{(pt.forwardRate * 100).toFixed(2)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
