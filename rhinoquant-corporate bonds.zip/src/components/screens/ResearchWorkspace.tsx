import React, { useState } from 'react';
import {
  BookOpen,
  CheckCircle2,
  FileText,
  Filter,
  Layers,
  LineChart,
  Save,
  Search,
  Sparkles,
  Terminal
} from 'lucide-react';
import { useTerminal } from '../../context/TerminalContext';
import { SYNTHETIC_DOCUMENTS } from '../../data/syntheticData';

export const ResearchWorkspace: React.FC = () => {
  const { activeIssuer, activeBond } = useTerminal();

  const [analystNotes, setAnalystNotes] = useState<string>(
    `# RHINOQUANT RESEARCH NOTE\nIssuer: ${activeIssuer.name} (${activeIssuer.ticker})\nDate: 2026-08-31\n\nCredit Rating: ${activeIssuer.creditRating} (${activeIssuer.ratingOutlook})\n\nKEY TAKEAWAYS:\n- Strong interest coverage (10.0x EBITDA/Interest).\n- Refinancing wall in 2029 well supported by green hydrogen cash flow generation.\n- Recommended Overweight on ${activeBond.ticker} at +135 bps spread concession.`
  );

  return (
    <div className="p-4 space-y-4 font-sans text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-center justify-between font-mono">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-cyan-500/20 text-cyan-400 rounded border border-cyan-500/30">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-100">INSTITUTIONAL RESEARCH WORKSPACE</h1>
            <p className="text-[11px] text-slate-400">
              Analyst Research Studio • Document Intelligence • Covenant Extraction NLP
            </p>
          </div>
        </div>

        <button
          onClick={() => alert('Research note saved to RhinoQuant Workspace Repository.')}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-xs transition"
        >
          <Save className="w-3.5 h-3.5" />
          <span>SAVE WORKSPACE</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 font-mono">
        {/* Left Col: Document Intelligence Extractor */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>DOCUMENT INTELLIGENCE PARSER</span>
            </span>
            <span className="text-[10px] bg-cyan-500/20 px-2 py-0.5 rounded text-cyan-300">
              3 EXTRACTIONS VALIDATED
            </span>
          </div>

          <div className="space-y-3">
            {SYNTHETIC_DOCUMENTS.map((doc) => (
              <div key={doc.id} className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-cyan-300 text-xs">{doc.documentTitle}</span>
                  <span className="text-[10px] text-emerald-400 font-bold">
                    {(doc.confidenceScore * 100).toFixed(0)}% CONFIDENCE
                  </span>
                </div>
                <div className="text-[11px] text-slate-300 font-sans">
                  <span className="font-bold text-slate-200">{doc.extractedField}: </span>
                  <span>{doc.extractedValue}</span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-800">
                  <span>Source: {doc.sourceFile} (p. {doc.pageNumber})</span>
                  <span>Parsed: {doc.timestamp}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Col: Analyst Research Scratchpad */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-emerald-400" />
            <span>CREDIT ANALYST NOTES SCRATCHPAD</span>
          </div>

          <textarea
            value={analystNotes}
            onChange={(e) => setAnalystNotes(e.target.value)}
            rows={14}
            className="w-full bg-slate-950 border border-slate-700 rounded p-3 text-cyan-200 font-mono text-xs leading-relaxed focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>
    </div>
  );
};
