import React, { useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  DollarSign,
  Download,
  Filter,
  Layers,
  PieChart,
  Plus,
  ShieldCheck,
  Users
} from 'lucide-react';
import { useTerminal } from '../../context/TerminalContext';
import { SYNTHETIC_ORDERBOOK_ORDERS } from '../../data/syntheticData';
import { OrderBookOrder } from '../../types';

export const OrderBookScreen: React.FC = () => {
  const { activeDeal, activeIssuer } = useTerminal();

  const [orders, setOrders] = useState<OrderBookOrder[]>(SYNTHETIC_ORDERBOOK_ORDERS);
  const [dealStage, setDealStage] = useState<string>('ORDER_BOOK');

  // Form to add a new investor ticket
  const [newInvestorName, setNewInvestorName] = useState('');
  const [newAccountType, setNewAccountType] = useState<OrderBookOrder['accountType']>('Asset Manager');
  const [newQuantity, setNewQuantity] = useState(100);
  const [newSpread, setNewSpread] = useState(130);

  const totalBookSize = orders.reduce((sum, o) => sum + o.quantityMillions, 0);
  const targetAmount = activeDeal.targetAmountMillions;
  const oversubscription = (totalBookSize / targetAmount).toFixed(1);

  const stages = [
    'MANDATE',
    'INITIAL PRICE TALK',
    'INVESTOR MARKETING',
    'ORDER BOOK',
    'REVISED GUIDANCE',
    'FINAL TERMS',
    'ALLOCATION',
    'SETTLEMENT'
  ];

  const handleAddOrder = () => {
    if (!newInvestorName) return;
    const order: OrderBookOrder = {
      id: `ORD-${Date.now()}`,
      investorName: newInvestorName,
      accountType: newAccountType,
      geography: 'UK',
      quantityMillions: newQuantity,
      limitPriceOrSpread: `+${newSpread} bps`,
      limitSpreadBps: newSpread,
      orderType: 'LIMIT',
      timestamp: new Date().toLocaleTimeString(),
      status: 'ACCEPTED',
      allocatedMillions: Math.round(newQuantity * 0.25),
      allocationPct: 25.0
    };
    setOrders((prev) => [order, ...prev]);
    setNewInvestorName('');
  };

  return (
    <div className="p-4 space-y-4 font-sans text-xs">
      {/* Header & Stage Progression */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg space-y-3 font-mono">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-cyan-500/20 text-cyan-400 rounded border border-cyan-500/30">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base font-bold text-slate-100">{activeDeal.dealName}</h1>
              <p className="text-[11px] text-slate-400">
                Syndicate Desk Order Book Engine • Target: £{targetAmount}M • Book Size: £{totalBookSize}M ({oversubscription}x Oversubscribed)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold rounded text-xs">
              FINAL GUIDANCE: +{activeDeal.finalSpreadBps} BPS
            </span>
          </div>
        </div>

        {/* Stage Timeline */}
        <div className="flex items-center overflow-x-auto py-1 border-t border-slate-800/80 text-[10px] whitespace-nowrap scrollbar-none">
          {stages.map((stg, idx) => {
            const isCurrent = stg === dealStage;
            return (
              <React.Fragment key={stg}>
                <button
                  onClick={() => setDealStage(stg)}
                  className={`px-2.5 py-1 rounded font-bold transition ${
                    isCurrent
                      ? 'bg-cyan-500 text-slate-950 shadow-md'
                      : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {idx + 1}. {stg}
                </button>
                {idx < stages.length - 1 && <ChevronRight className="w-3 h-3 text-slate-600 shrink-0 mx-1" />}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      {/* Main Grid: Orders Table & Ticket Entry */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 font-mono">
        {/* Left 2 Cols: Order Book Tickets Table */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <Users className="w-4 h-4 text-cyan-400" />
              <span>INVESTOR ORDER BOOK ({orders.length} TICKETS)</span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-[11px]">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                  <th className="py-2 px-2">INVESTOR</th>
                  <th className="py-2 px-2">ACCOUNT TYPE</th>
                  <th className="py-2 px-2">GEO</th>
                  <th className="py-2 px-2 text-right">ORDER (£M)</th>
                  <th className="py-2 px-2 text-right">LIMIT SPREAD</th>
                  <th className="py-2 px-2 text-right">ALLOCATED (£M)</th>
                  <th className="py-2 px-2 text-right">ALLOC %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {orders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-slate-800/60">
                    <td className="py-2 px-2 font-bold text-slate-100">{ord.investorName}</td>
                    <td className="py-2 px-2 text-slate-300">{ord.accountType}</td>
                    <td className="py-2 px-2 text-slate-400">{ord.geography}</td>
                    <td className="py-2 px-2 text-right font-bold text-cyan-300">£{ord.quantityMillions}M</td>
                    <td className="py-2 px-2 text-right font-bold text-amber-300">{ord.limitPriceOrSpread}</td>
                    <td className="py-2 px-2 text-right font-bold text-emerald-400">£{ord.allocatedMillions}M</td>
                    <td className="py-2 px-2 text-right text-slate-300">{ord.allocationPct}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Col: Add Investor Ticket Form */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center gap-2">
            <Plus className="w-4 h-4 text-cyan-400" />
            <span>ENTER SYNDICATE ORDER TICKET</span>
          </div>

          <div className="space-y-3 text-[11px]">
            <div>
              <label className="text-slate-400 block mb-1">INVESTOR NAME</label>
              <input
                type="text"
                placeholder="e.g., Vanguard Global Credit"
                value={newInvestorName}
                onChange={(e) => setNewInvestorName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">ACCOUNT TYPE</label>
              <select
                value={newAccountType}
                onChange={(e) => setNewAccountType(e.target.value as OrderBookOrder['accountType'])}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-cyan-300"
              >
                <option value="Asset Manager">Asset Manager</option>
                <option value="Pension Fund">Pension Fund</option>
                <option value="Hedge Fund">Hedge Fund</option>
                <option value="Insurance">Insurance</option>
                <option value="Private Wealth">Private Wealth</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-400 block mb-1">TICKET SIZE (£M)</label>
                <input
                  type="number"
                  value={newQuantity}
                  onChange={(e) => setNewQuantity(parseInt(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-cyan-300 font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">LIMIT SPREAD (BPS)</label>
                <input
                  type="number"
                  value={newSpread}
                  onChange={(e) => setNewSpread(parseInt(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-amber-300 font-bold"
                />
              </div>
            </div>

            <button
              onClick={handleAddOrder}
              className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-xs transition mt-2"
            >
              SUBMIT ORDER TO SYNDICATE DESK
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
