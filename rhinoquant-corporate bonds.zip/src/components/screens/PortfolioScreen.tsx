import React from 'react';
import {
  BarChart3,
  DollarSign,
  Globe,
  PieChart,
  Plus,
  ShieldAlert,
  TrendingUp,
  Wallet
} from 'lucide-react';
import { useTerminal } from '../../context/TerminalContext';
import { calculatePortfolioAnalytics } from '../../quant/portfolioRisk';

export const PortfolioScreen: React.FC = () => {
  const { portfolioPositions, setActiveBond, setActiveScreen } = useTerminal();

  const summary = calculatePortfolioAnalytics(portfolioPositions);

  return (
    <div className="p-4 space-y-4 font-sans text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-wrap items-center justify-between gap-3 font-mono">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-cyan-500/20 text-cyan-400 rounded border border-cyan-500/30">
            <PieChart className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-100">INSTITUTIONAL PORTFOLIO ANALYTICS</h1>
            <p className="text-[11px] text-slate-400">
              Holdings Management • Multi-Currency Accounting • Risk & Spread Duration Aggregates
            </p>
          </div>
        </div>

        <button
          onClick={() => setActiveScreen('risk')}
          className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-xs transition"
        >
          RUN SCENARIO STRESS ENGINE →
        </button>
      </div>

      {/* Aggregate Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 font-mono">
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-slate-400 text-[10px]">TOTAL MARKET VALUE</span>
          <div className="text-base font-bold text-slate-100 mt-1">
            £{(summary.totalMarketValue / 1000000).toFixed(2)} M
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-slate-400 text-[10px]">UNREALIZED P&L</span>
          <div className={`text-base font-bold mt-1 ${summary.totalUnrealizedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            £{(summary.totalUnrealizedPnL / 1000).toFixed(1)} k
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-slate-400 text-[10px]">WEIGHTED YIELD</span>
          <div className="text-base font-bold text-cyan-300 mt-1">
            {(summary.weightedYield * 100).toFixed(2)}%
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-slate-400 text-[10px]">WEIGHTED DURATION</span>
          <div className="text-base font-bold text-emerald-400 mt-1">
            {summary.weightedDuration} YRS
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-slate-400 text-[10px]">TOTAL PORTFOLIO DV01</span>
          <div className="text-base font-bold text-amber-300 mt-1">
            ${summary.totalDv01.toLocaleString()}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-slate-400 text-[10px]">AVG CREDIT SPREAD</span>
          <div className="text-base font-bold text-slate-100 mt-1">
            +{summary.weightedSpreadBps} bps
          </div>
        </div>
      </div>

      {/* Main Table: Portfolio Holdings */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3 font-mono">
        <div className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center justify-between">
          <span>PORTFOLIO POSITIONS ({portfolioPositions.length} HOLDINGS)</span>
          <span className="text-[10px] text-slate-400">BASE CURRENCY: GBP</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-[11px]">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="py-2 px-2">BOND TICKER</th>
                <th className="py-2 px-2">ISIN</th>
                <th className="py-2 px-2 text-right">PAR (£M)</th>
                <th className="py-2 px-2 text-right">BOOK PRICE</th>
                <th className="py-2 px-2 text-right">MKT PRICE</th>
                <th className="py-2 px-2 text-right">YIELD</th>
                <th className="py-2 px-2 text-right">SPREAD</th>
                <th className="py-2 px-2 text-right">MARKET VALUE (£)</th>
                <th className="py-2 px-2 text-right">UNREALIZED P&L</th>
                <th className="py-2 px-2 text-right">DV01 ($)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {portfolioPositions.map((pos) => (
                <tr
                  key={pos.id}
                  onClick={() => {
                    setActiveBond(pos.bond);
                    setActiveScreen('bond-analytics');
                  }}
                  className="hover:bg-slate-800/60 transition cursor-pointer"
                >
                  <td className="py-2 px-2 font-bold text-cyan-300">{pos.bond.ticker}</td>
                  <td className="py-2 px-2 text-slate-400">{pos.bond.isin}</td>
                  <td className="py-2 px-2 text-right font-bold text-slate-100">£{pos.parAmountMillions}M</td>
                  <td className="py-2 px-2 text-right text-slate-300">{pos.bookPrice.toFixed(2)}</td>
                  <td className="py-2 px-2 text-right font-bold text-emerald-400">{pos.currentPrice.toFixed(2)}</td>
                  <td className="py-2 px-2 text-right text-slate-100">{(pos.currentYield * 100).toFixed(2)}%</td>
                  <td className="py-2 px-2 text-right text-amber-300">+{pos.currentSpreadBps} bps</td>
                  <td className="py-2 px-2 text-right font-bold text-slate-100">£{pos.marketValue.toLocaleString()}</td>
                  <td className={`py-2 px-2 text-right font-bold ${pos.unrealizedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    £{pos.unrealizedPnL.toLocaleString()}
                  </td>
                  <td className="py-2 px-2 text-right font-bold text-cyan-300">${pos.dv01Total.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
