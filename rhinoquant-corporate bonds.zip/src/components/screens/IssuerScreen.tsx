import React, { useState } from 'react';
import {
  BarChart3,
  Building2,
  Calendar,
  CheckCircle,
  Compass,
  DollarSign,
  FileText,
  Globe,
  Layers,
  LineChart,
  PlusCircle,
  ShieldCheck,
  TrendingUp
} from 'lucide-react';
import { useTerminal } from '../../context/TerminalContext';

export const IssuerScreen: React.FC = () => {
  const { issuers, activeIssuer, setActiveIssuer, bonds, setActiveBond, setActiveScreen } = useTerminal();

  const issuerBonds = bonds.filter((b) => b.issuerId === activeIssuer.id);

  return (
    <div className="p-4 space-y-4 font-sans text-xs">
      {/* Issuer Selector Header */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/20 text-cyan-400 rounded-lg border border-cyan-500/30">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold text-slate-100 font-mono">{activeIssuer.name}</h1>
              <span className="px-2 py-0.5 bg-slate-800 border border-slate-700 font-mono text-cyan-300 font-bold rounded text-[10px]">
                {activeIssuer.ticker}
              </span>
              <span className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/30 font-mono text-emerald-400 font-bold rounded text-[10px]">
                {activeIssuer.creditRating} ({activeIssuer.ratingOutlook})
              </span>
            </div>
            <div className="text-[11px] text-slate-400 font-mono mt-0.5 flex items-center gap-3">
              <span>{activeIssuer.legalEntity}</span>
              <span>•</span>
              <span>{activeIssuer.sector}</span>
              <span>•</span>
              <span>{activeIssuer.country}</span>
            </div>
          </div>
        </div>

        {/* Change Issuer Dropdown & Quick Actions */}
        <div className="flex items-center gap-2">
          <select
            value={activeIssuer.id}
            onChange={(e) => {
              const selected = issuers.find((i) => i.id === e.target.value);
              if (selected) setActiveIssuer(selected);
            }}
            className="bg-slate-950 border border-slate-700 text-cyan-300 font-mono text-xs px-2 py-1.5 rounded focus:outline-none focus:border-cyan-500"
          >
            {issuers.map((i) => (
              <option key={i.id} value={i.id}>
                {i.ticker} - {i.name}
              </option>
            ))}
          </select>

          <button
            onClick={() => setActiveScreen('new-issue')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold font-sans rounded transition text-xs"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>ORIGINATE NEW BOND</span>
          </button>
        </div>
      </div>

      {/* Credit Ratios & Financial Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg font-mono">
          <div className="text-slate-400 text-[10px]">NET DEBT / EBITDA</div>
          <div className="text-base font-bold text-cyan-300 mt-1">
            {activeIssuer.creditMetrics.netDebtToEbitda}x
          </div>
          <div className="text-[10px] text-emerald-400 mt-0.5">Below 3.0x Threshold</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg font-mono">
          <div className="text-slate-400 text-[10px]">EBITDA / INTEREST</div>
          <div className="text-base font-bold text-slate-100 mt-1">
            {activeIssuer.creditMetrics.ebitdaToInterest}x
          </div>
          <div className="text-[10px] text-emerald-400 mt-0.5">Strong Coverage</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg font-mono">
          <div className="text-slate-400 text-[10px]">TOTAL NET DEBT</div>
          <div className="text-base font-bold text-amber-300 mt-1">
            £{(activeIssuer.financials.netDebt / 1000).toFixed(2)} Bn
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Gross: £{(activeIssuer.financials.netDebt + activeIssuer.financials.cash) / 1000}B</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg font-mono">
          <div className="text-slate-400 text-[10px]">CASH & EQUIVALENTS</div>
          <div className="text-base font-bold text-emerald-400 mt-1">
            £{(activeIssuer.financials.cash / 1000).toFixed(2)} Bn
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Liquidity Buffer</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg font-mono">
          <div className="text-slate-400 text-[10px]">FREE CASH FLOW</div>
          <div className="text-base font-bold text-slate-100 mt-1">
            £{(activeIssuer.financials.freeCashFlow / 1000).toFixed(2)} Bn
          </div>
          <div className="text-[10px] text-emerald-400 mt-0.5">FCF/Debt: {(activeIssuer.creditMetrics.fcfToDebt * 100).toFixed(1)}%</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg font-mono">
          <div className="text-slate-400 text-[10px]">CURRENT RATIO</div>
          <div className="text-base font-bold text-cyan-300 mt-1">
            {activeIssuer.creditMetrics.currentRatio}x
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Short-term solvency</div>
        </div>
      </div>

      {/* Main Grid: Capital Structure & Bond Outstanding Universe */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Cols: Outstanding Bonds & Issuer Yield Curve */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2 font-bold text-sm text-slate-100 font-mono">
                <Layers className="w-4 h-4 text-cyan-400" />
                <span>OUTSTANDING BOND INSTRUMENTS ({issuerBonds.length})</span>
              </div>
              <button
                onClick={() => setActiveScreen('credit-curve')}
                className="text-cyan-400 hover:underline text-[11px] font-mono flex items-center gap-1"
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>VIEW ISSUER CREDIT CURVE →</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse font-mono text-[11px]">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/60">
                    <th className="py-2 px-2">TICKER</th>
                    <th className="py-2 px-2">ISIN</th>
                    <th className="py-2 px-2">SENIORITY</th>
                    <th className="py-2 px-2">MATURITY</th>
                    <th className="py-2 px-2 text-right">COUPON</th>
                    <th className="py-2 px-2 text-right">PRICE</th>
                    <th className="py-2 px-2 text-right">YIELD</th>
                    <th className="py-2 px-2 text-right">SPREAD</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {issuerBonds.map((bond) => (
                    <tr
                      key={bond.id}
                      onClick={() => {
                        setActiveBond(bond);
                        setActiveScreen('bond-analytics');
                      }}
                      className="hover:bg-slate-800/60 transition cursor-pointer group"
                    >
                      <td className="py-2 px-2 font-bold text-cyan-300 group-hover:underline">
                        {bond.ticker}
                      </td>
                      <td className="py-2 px-2 text-slate-300">{bond.isin}</td>
                      <td className="py-2 px-2 text-slate-300">{bond.seniority}</td>
                      <td className="py-2 px-2 text-slate-300">{bond.maturityDate}</td>
                      <td className="py-2 px-2 text-right text-slate-100">{(bond.coupon * 100).toFixed(3)}%</td>
                      <td className="py-2 px-2 text-right text-emerald-400">100.45</td>
                      <td className="py-2 px-2 text-right font-bold text-slate-100">5.250%</td>
                      <td className="py-2 px-2 text-right font-bold text-amber-400">+135 bps</td>
                    </tr>
                  ))}
                  {issuerBonds.length === 0 && (
                    <tr>
                      <td colSpan={8} className="py-4 text-center text-slate-500 italic">
                        No active bonds outstanding for this issuer in current Security Master.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Issuer Financial Statement Summary */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-2">
            <div className="font-bold text-sm text-slate-100 font-mono border-b border-slate-800 pb-2 flex items-center justify-between">
              <span>FINANCIAL STATEMENTS (IN MILLIONS GBP)</span>
              <span className="text-[10px] text-slate-400 font-normal">AS OF {activeIssuer.financials.asOfDate}</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono text-[11px] pt-1">
              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">TOTAL REVENUE</span>
                <span className="text-slate-100 font-bold text-xs">£{activeIssuer.financials.revenue.toLocaleString()} M</span>
              </div>
              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">EBITDA</span>
                <span className="text-cyan-300 font-bold text-xs">£{activeIssuer.financials.ebitda.toLocaleString()} M</span>
              </div>
              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">INTEREST EXPENSE</span>
                <span className="text-rose-400 font-bold text-xs">£{activeIssuer.financials.interestExpense.toLocaleString()} M</span>
              </div>
              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">TOTAL ASSETS</span>
                <span className="text-slate-100 font-bold text-xs">£{activeIssuer.financials.totalAssets.toLocaleString()} M</span>
              </div>
              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">TOTAL EQUITY</span>
                <span className="text-slate-100 font-bold text-xs">£{activeIssuer.financials.totalEquity.toLocaleString()} M</span>
              </div>
              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">DEBT TO CAPITAL</span>
                <span className="text-amber-300 font-bold text-xs">{(activeIssuer.creditMetrics.debtToCapital * 100).toFixed(1)}%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Covenants & Debt Maturity Wall Link */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
            <div className="font-bold text-sm text-slate-100 font-mono border-b border-slate-800 pb-2 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>BOND COVENANTS & GOVERNANCE</span>
            </div>

            <div className="p-2.5 bg-slate-950 rounded border border-slate-800 font-sans text-xs space-y-2">
              <p className="text-slate-300 leading-relaxed">{activeIssuer.covenantsOverview}</p>
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-emerald-400">
                <span className="flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" /> COVENANT HEADROOM: HEALTHY
                </span>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
            <div className="font-bold text-sm text-slate-100 font-mono border-b border-slate-800 pb-2 flex items-center gap-2">
              <Compass className="w-4 h-4 text-cyan-400" />
              <span>DEBT MATURITY WALL</span>
            </div>

            <p className="text-[11px] text-slate-400 font-sans">
              Analyze corporate refinancing schedule, impending maturity cliffs, and simulate capital structure optimization.
            </p>

            <button
              onClick={() => setActiveScreen('maturity-wall')}
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 font-mono font-bold rounded border border-slate-700 text-xs transition"
            >
              LAUNCH MATURITY WALL SIMULATOR →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
