import React, { useState } from 'react';
import {
  BarChart2,
  Calendar,
  CheckCircle2,
  DollarSign,
  FileCheck,
  Info,
  Layers,
  LineChart,
  Plus,
  ShieldAlert,
  Sparkles
} from 'lucide-react';
import { useTerminal } from '../../context/TerminalContext';
import { generateCashFlowSchedule } from '../../quant/cashflows';
import { priceBondInstrument } from '../../quant/pricingEngine';

export const BondScreen: React.FC = () => {
  const { activeBond, setActiveBond, bonds, setAuditModalBond, addPortfolioPosition } = useTerminal();

  const [inputMode, setInputMode] = useState<'PRICE' | 'YIELD'>('PRICE');
  const [inputValue, setInputValue] = useState<number>(100.25);
  const settlementDate = '2026-08-31';

  const pricing = priceBondInstrument(activeBond, settlementDate, inputMode, inputValue);
  const cashFlows = generateCashFlowSchedule(activeBond, settlementDate, pricing.ytm);

  return (
    <div className="p-4 space-y-4 font-sans text-xs">
      {/* Top Header Card */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 font-mono">
            <h1 className="text-base font-bold text-slate-100">{activeBond.ticker}</h1>
            <span className="px-2 py-0.5 bg-slate-800 border border-slate-700 text-cyan-300 font-bold rounded text-[10px]">
              {activeBond.currency}
            </span>
            <span className="px-2 py-0.5 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-bold rounded text-[10px]">
              {activeBond.ratingSP} / {activeBond.ratingMoody}
            </span>
            <span className="px-2 py-0.5 bg-amber-500/10 border border-amber-500/30 text-amber-300 font-bold rounded text-[10px]">
              {activeBond.marketDataStatus}
            </span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5 flex flex-wrap gap-3">
            <span>ISIN: {activeBond.isin}</span>
            <span>•</span>
            <span>CUSIP: {activeBond.cusip}</span>
            <span>•</span>
            <span>SEDOL: {activeBond.sedol}</span>
            <span>•</span>
            <span>Issuer: {activeBond.issuerName}</span>
          </div>
        </div>

        {/* Bond Selector & Quick Actions */}
        <div className="flex items-center gap-2">
          <select
            value={activeBond.id}
            onChange={(e) => {
              const b = bonds.find((x) => x.id === e.target.value);
              if (b) setActiveBond(b);
            }}
            className="bg-slate-950 border border-slate-700 text-cyan-300 font-mono text-xs px-2 py-1.5 rounded focus:outline-none"
          >
            {bonds.map((b) => (
              <option key={b.id} value={b.id}>
                {b.ticker} ({b.isin})
              </option>
            ))}
          </select>

          <button
            onClick={() => setAuditModalBond(activeBond)}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 font-mono font-bold rounded border border-slate-700 text-xs transition"
          >
            INSPECT PROVENANCE
          </button>

          <button
            onClick={() => addPortfolioPosition(activeBond, 10, pricing.cleanPrice)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-xs transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>ADD TO PORTFOLIO</span>
          </button>
        </div>
      </div>

      {/* Quantitative Analytics Dashboard Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 font-mono">
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <div className="text-slate-400 text-[10px]">CLEAN PRICE</div>
          <div className="text-base font-bold text-slate-100 mt-1">{pricing.cleanPrice.toFixed(2)}</div>
          <div className="text-[10px] text-slate-500">Par Value: 100.00</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <div className="text-slate-400 text-[10px]">DIRTY PRICE</div>
          <div className="text-base font-bold text-slate-100 mt-1">{pricing.dirtyPrice.toFixed(2)}</div>
          <div className="text-[10px] text-slate-500">Accrued: {pricing.accruedInterest.toFixed(2)}</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <div className="text-slate-400 text-[10px]">YIELD TO MATURITY</div>
          <div className="text-base font-bold text-cyan-300 mt-1">{(pricing.ytm * 100).toFixed(3)}%</div>
          <div className="text-[10px] text-cyan-500/80">YTW: {(pricing.ytw * 100).toFixed(3)}%</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <div className="text-slate-400 text-[10px]">BENCHMARK SPREAD</div>
          <div className="text-base font-bold text-amber-300 mt-1">+{pricing.spreadToBenchmarkBps} bps</div>
          <div className="text-[10px] text-slate-500">vs {activeBond.benchmarkTicker}</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <div className="text-slate-400 text-[10px]">MODIFIED DURATION</div>
          <div className="text-base font-bold text-emerald-400 mt-1">{pricing.modifiedDuration} yrs</div>
          <div className="text-[10px] text-slate-500">Mac Dur: {pricing.macaulayDuration}</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <div className="text-slate-400 text-[10px]">DV01 (PER 100K)</div>
          <div className="text-base font-bold text-emerald-400 mt-1">${(pricing.dv01 * 1000).toFixed(2)}</div>
          <div className="text-[10px] text-slate-500">Convexity: {pricing.convexity}</div>
        </div>
      </div>

      {/* Main Grid: Security Master Details & Cash Flow Schedule */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Col: Security Master Reference Data */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3 font-mono">
          <div className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center justify-between">
            <span>CANONICAL SECURITY MASTER</span>
            <FileCheck className="w-4 h-4 text-cyan-400" />
          </div>

          <div className="space-y-2 text-[11px]">
            <div className="flex justify-between py-1 border-b border-slate-800/40">
              <span className="text-slate-400">Coupon Rate:</span>
              <span className="text-slate-100 font-bold">{(activeBond.coupon * 100).toFixed(3)}%</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/40">
              <span className="text-slate-400">Frequency:</span>
              <span className="text-slate-100">{activeBond.couponFrequency}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/40">
              <span className="text-slate-400">Day-Count Convention:</span>
              <span className="text-cyan-300 font-bold">{activeBond.dayCountConvention}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/40">
              <span className="text-slate-400">Settlement Convention:</span>
              <span className="text-slate-100">{activeBond.settlementConvention}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/40">
              <span className="text-slate-400">Seniority Ranking:</span>
              <span className="text-slate-100 font-bold">{activeBond.seniority}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/40">
              <span className="text-slate-400">Issue Date:</span>
              <span className="text-slate-100">{activeBond.issueDate}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/40">
              <span className="text-slate-400">Maturity Date:</span>
              <span className="text-slate-100">{activeBond.maturityDate}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/40">
              <span className="text-slate-400">Callability:</span>
              <span className="text-amber-400 font-bold">
                {activeBond.isCallable ? `CALLABLE (${activeBond.callDate || 'Par Call'})` : 'NON-CALLABLE'}
              </span>
            </div>
          </div>

          <div className="pt-2">
            <span className="text-[10px] text-slate-400 font-bold block mb-1">BOND COVENANTS:</span>
            <div className="flex flex-wrap gap-1 font-sans">
              {activeBond.covenants.map((cov, idx) => (
                <span key={idx} className="px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded text-[10px] border border-slate-700">
                  {cov}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right 2 Cols: Cash Flow Schedule Engine */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="font-bold text-sm text-slate-100 font-mono flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-emerald-400" />
              <span>CASH-FLOW SCHEDULE ({cashFlows.length} PERIODS)</span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">
              SETTLEMENT: {settlementDate}
            </span>
          </div>

          <div className="overflow-x-auto max-h-80 overflow-y-auto">
            <table className="w-full text-left border-collapse font-mono text-[11px]">
              <thead className="sticky top-0 bg-slate-950 text-slate-400">
                <tr className="border-b border-slate-800">
                  <th className="py-2 px-2">PERIOD</th>
                  <th className="py-2 px-2">DATE</th>
                  <th className="py-2 px-2 text-right">COUPON</th>
                  <th className="py-2 px-2 text-right">PRINCIPAL</th>
                  <th className="py-2 px-2 text-right">TOTAL CF</th>
                  <th className="py-2 px-2 text-right">YEAR FRAC</th>
                  <th className="py-2 px-2 text-right">DISCOUNT FACTOR</th>
                  <th className="py-2 px-2 text-right">PV</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {cashFlows.map((cf) => (
                  <tr key={cf.periodNumber} className="hover:bg-slate-800/60 transition">
                    <td className="py-1.5 px-2 font-bold text-slate-300">#{cf.periodNumber}</td>
                    <td className="py-1.5 px-2 text-slate-200">{cf.date}</td>
                    <td className="py-1.5 px-2 text-right text-slate-200">{cf.couponAmount.toFixed(3)}</td>
                    <td className="py-1.5 px-2 text-right text-slate-200">{cf.principalAmount.toFixed(2)}</td>
                    <td className="py-1.5 px-2 text-right text-slate-100 font-bold">{cf.totalCashFlow.toFixed(3)}</td>
                    <td className="py-1.5 px-2 text-right text-slate-400">{cf.yearFraction.toFixed(3)}</td>
                    <td className="py-1.5 px-2 text-right text-cyan-400">{cf.discountFactor.toFixed(5)}</td>
                    <td className="py-1.5 px-2 text-right font-bold text-emerald-400">{cf.presentValue.toFixed(3)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
