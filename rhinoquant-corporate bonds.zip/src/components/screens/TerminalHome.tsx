import React, { useState } from 'react';
import {
  ArrowDownRight,
  ArrowUpRight,
  BarChart2,
  Building2,
  Calculator,
  ChevronRight,
  Filter,
  Flame,
  Globe,
  LineChart,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { useTerminal } from '../../context/TerminalContext';
import { BondInstrument } from '../../types';

export const TerminalHome: React.FC = () => {
  const { bonds, issuers, setActiveBond, setActiveIssuer, setActiveScreen, curves, setAuditModalBond } = useTerminal();
  
  const [filterCurrency, setFilterCurrency] = useState<string>('ALL');
  const [filterSector, setFilterSector] = useState<string>('ALL');

  const filteredBonds = bonds.filter((b) => {
    if (filterCurrency !== 'ALL' && b.currency !== filterCurrency) return false;
    if (filterSector !== 'ALL' && b.sector !== filterSector) return false;
    return true;
  });

  return (
    <div className="p-4 space-y-4 font-sans text-xs">
      {/* Top Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg shadow-sm">
          <div className="flex items-center justify-between text-slate-400 font-mono text-[11px]">
            <span>CANONICAL SECURITIES</span>
            <Globe className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="mt-2 text-xl font-bold font-mono text-cyan-300">
            {bonds.length} <span className="text-xs font-normal text-slate-400">Securities Tracked</span>
          </div>
          <div className="mt-1 text-[11px] text-emerald-400 font-mono flex items-center gap-1">
            <ShieldCheck className="w-3 h-3" />
            <span>100% Security Master Validated</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg shadow-sm">
          <div className="flex items-center justify-between text-slate-400 font-mono text-[11px]">
            <span>AVG IG CREDIT SPREAD</span>
            <BarChart2 className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="mt-2 text-xl font-bold font-mono text-slate-100">
            128 bps <span className="text-xs text-rose-400 font-normal">(+3.2 bps)</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400 font-mono">
            vs Sovereign Benchmarks
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg shadow-sm">
          <div className="flex items-center justify-between text-slate-400 font-mono text-[11px]">
            <span>PRIMARY ISSUANCE PIPELINE</span>
            <Zap className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="mt-2 text-xl font-bold font-mono text-amber-300">
            £2.45 Bn <span className="text-xs text-slate-400 font-normal">Active Orders</span>
          </div>
          <div className="mt-1 text-[11px] text-amber-400 font-mono">
            Rhino Industrial £500m Benchmark Deal
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg shadow-sm">
          <div className="flex items-center justify-between text-slate-400 font-mono text-[11px]">
            <span>10Y UK GILT BENCHMARK</span>
            <LineChart className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="mt-2 text-xl font-bold font-mono text-emerald-400">
            4.350% <span className="text-xs text-slate-400 font-normal">+2 bps</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400 font-mono">
            UK Debt Management Office Feed
          </div>
        </div>
      </div>

      {/* Main Grid: Live Bond Monitor & Market Curve Widget */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Cols: Real-Time Corporate Bond Monitor Table */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-cyan-400" />
              <h2 className="font-bold text-sm text-slate-100 font-mono">REAL-TIME BOND MARKET SCREEN</h2>
              <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-cyan-300 font-mono border border-cyan-500/20">
                {filteredBonds.length} INSTRUMENTS
              </span>
            </div>

            {/* Filters */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
                <Filter className="w-3 h-3 text-slate-400" />
                <span className="text-[10px] text-slate-400">CCY:</span>
                <select
                  value={filterCurrency}
                  onChange={(e) => setFilterCurrency(e.target.value)}
                  className="bg-transparent text-cyan-300 text-xs focus:outline-none"
                >
                  <option value="ALL">ALL</option>
                  <option value="GBP">GBP</option>
                  <option value="USD">USD</option>
                  <option value="EUR">EUR</option>
                </select>
              </div>

              <div className="flex items-center gap-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
                <span className="text-[10px] text-slate-400">SECTOR:</span>
                <select
                  value={filterSector}
                  onChange={(e) => setFilterSector(e.target.value)}
                  className="bg-transparent text-cyan-300 text-xs focus:outline-none"
                >
                  <option value="ALL">ALL</option>
                  <option value="Industrial">Industrial</option>
                  <option value="Energy">Energy</option>
                  <option value="Telecom">Telecom</option>
                  <option value="Infrastructure">Infrastructure</option>
                  <option value="Manufacturing">Manufacturing</option>
                  <option value="Healthcare">Healthcare</option>
                </select>
              </div>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse font-mono text-[11px]">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/60">
                  <th className="py-2 px-2">BOND / TICKER</th>
                  <th className="py-2 px-2">ISIN</th>
                  <th className="py-2 px-2">MATURITY</th>
                  <th className="py-2 px-2">RATING</th>
                  <th className="py-2 px-2 text-right">BID</th>
                  <th className="py-2 px-2 text-right">ASK</th>
                  <th className="py-2 px-2 text-right">YIELD</th>
                  <th className="py-2 px-2 text-right">SPREAD</th>
                  <th className="py-2 px-2 text-center">AUDIT</th>
                  <th className="py-2 px-2 text-right">ACTION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredBonds.map((bond) => {
                  const estYield = (bond.coupon * 100 + (100 - 99.85) / 5).toFixed(3);
                  const estSpread = Math.round((parseFloat(estYield) - 4.35) * 100);

                  return (
                    <tr
                      key={bond.id}
                      className="hover:bg-slate-800/60 transition group cursor-pointer"
                      onClick={() => {
                        setActiveBond(bond);
                        setActiveScreen('bond-analytics');
                      }}
                    >
                      <td className="py-2 px-2">
                        <div className="font-bold text-slate-100 group-hover:text-cyan-300 transition">
                          {bond.ticker}
                        </div>
                        <div className="text-[10px] text-slate-400 font-sans">{bond.issuerName}</div>
                      </td>
                      <td className="py-2 px-2 text-slate-300">{bond.isin}</td>
                      <td className="py-2 px-2 text-slate-300">{bond.maturityDate}</td>
                      <td className="py-2 px-2">
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-cyan-300 font-bold text-[10px]">
                          {bond.ratingSP}
                        </span>
                      </td>
                      <td className="py-2 px-2 text-right text-emerald-400 font-semibold">100.15</td>
                      <td className="py-2 px-2 text-right text-rose-400 font-semibold">100.45</td>
                      <td className="py-2 px-2 text-right text-slate-100 font-bold">{estYield}%</td>
                      <td className="py-2 px-2 text-right text-amber-400 font-bold">+{estSpread} bps</td>
                      <td className="py-2 px-2 text-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setAuditModalBond(bond);
                          }}
                          className="px-1.5 py-0.5 bg-slate-800 hover:bg-cyan-500/20 text-cyan-400 rounded border border-cyan-500/30 text-[10px] transition"
                          title="Inspect exact Cash Flow calculations & Provenance"
                        >
                          PROVENANCE
                        </button>
                      </td>
                      <td className="py-2 px-2 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveBond(bond);
                            setActiveScreen('bond-analytics');
                          }}
                          className="text-cyan-400 hover:text-cyan-300 font-semibold flex items-center justify-end gap-0.5 ml-auto"
                        >
                          ANALYZE <ChevronRight className="w-3 h-3" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Col: Issuer Directory & Yield Curve Quick View */}
        <div className="space-y-4">
          {/* Issuer Directory Widget */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-1.5 font-bold text-sm text-slate-100 font-mono">
                <Building2 className="w-4 h-4 text-cyan-400" />
                <span>ISSUER INTELLIGENCE LAYER</span>
              </div>
              <button
                onClick={() => setActiveScreen('issuer-profile')}
                className="text-cyan-400 hover:underline text-[11px] font-mono"
              >
                VIEW ALL →
              </button>
            </div>

            <div className="space-y-2">
              {issuers.slice(0, 5).map((issuer) => (
                <div
                  key={issuer.id}
                  onClick={() => {
                    setActiveIssuer(issuer);
                    setActiveScreen('issuer-profile');
                  }}
                  className="p-2 bg-slate-950 rounded border border-slate-800 hover:border-cyan-500/40 cursor-pointer transition flex items-center justify-between"
                >
                  <div>
                    <div className="font-bold text-slate-200 text-xs">{issuer.name}</div>
                    <div className="text-[10px] text-slate-400 font-mono flex items-center gap-2">
                      <span>{issuer.sector}</span>
                      <span>•</span>
                      <span>Net Debt: £{(issuer.financials.netDebt / 1000).toFixed(1)}B</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="px-1.5 py-0.5 bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 font-bold font-mono rounded text-[10px]">
                      {issuer.creditRating} ({issuer.ratingOutlook})
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Benchmark Curve Quick Widget */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-1.5 font-bold text-sm text-slate-100 font-mono">
                <LineChart className="w-4 h-4 text-emerald-400" />
                <span>BENCHMARK CURVES</span>
              </div>
              <button
                onClick={() => setActiveScreen('yield-curve')}
                className="text-emerald-400 hover:underline text-[11px] font-mono"
              >
                INTERACTIVE CURVES →
              </button>
            </div>

            <div className="space-y-1.5 font-mono text-[11px]">
              {curves[0].points.map((pt) => (
                <div key={pt.tenor} className="flex items-center justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400 font-bold">{pt.tenor} GILT BENCHMARK</span>
                  <div className="flex items-center gap-3">
                    <span className="text-slate-200">Spot: {(pt.spotRate * 100).toFixed(2)}%</span>
                    <span className="text-cyan-400 font-bold">Forward: {(pt.forwardRate * 100).toFixed(2)}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
