import React, { useState } from 'react';
import {
  BarChart3,
  Building2,
  Calendar,
  Compass,
  DollarSign,
  Info,
  Layers,
  LineChart,
  RefreshCw,
  TrendingUp
} from 'lucide-react';
import { useTerminal } from '../../context/TerminalContext';

export const MaturityWallScreen: React.FC = () => {
  const { activeIssuer } = useTerminal();

  // Baseline Maturity Wall Data (Millions GBP)
  const [maturityWall, setMaturityWall] = useState<Record<number, number>>({
    2027: 2400,
    2028: 1800,
    2029: 3200,
    2030: 4100,
    2031: 1200,
    2032: 5000,
    2033: 1500,
    2034: 2800
  });

  // Refinancing Simulator State
  const [selectedYear, setSelectedYear] = useState<number>(2028);
  const [refinanceTenor, setRefinanceTenor] = useState<number>(10);
  const [refinanceRatePct, setRefinanceRatePct] = useState<number>(5.5);

  const totalDebtMaturities = (Object.values(maturityWall) as number[]).reduce((a, b) => a + b, 0);

  const handleSimulateRefinance = () => {
    const amountToRefinance = maturityWall[selectedYear] || 0;
    if (amountToRefinance === 0) return;

    const newTargetYear = selectedYear + refinanceTenor;
    setMaturityWall((prev) => ({
      ...prev,
      [selectedYear]: 0,
      [newTargetYear]: (prev[newTargetYear] || 0) + amountToRefinance
    }));
  };

  return (
    <div className="p-4 space-y-4 font-sans text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-wrap items-center justify-between gap-3 font-mono">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-cyan-500/20 text-cyan-400 rounded border border-cyan-500/30">
            <Compass className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-100">{activeIssuer.name} — DEBT MATURITY WALL</h1>
            <p className="text-[11px] text-slate-400">
              Corporate Debt Refinancing Schedule • WAM Optimization • Liquidity & Debt Service Simulator
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 bg-slate-800 border border-slate-700 text-cyan-300 font-bold rounded text-xs">
            TOTAL DEBT OUTSTANDING: £{((totalDebtMaturities as number) / 1000).toFixed(1)} BN
          </span>
        </div>
      </div>

      {/* Visual Bar Chart Maturity Wall */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3 font-mono">
        <div className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center justify-between">
          <span>CORPORATE MATURITY WALL PROFILE (2027 - 2036)</span>
          <span className="text-[10px] text-cyan-400">IN MILLIONS GBP</span>
        </div>

        <div className="h-64 flex items-end justify-between gap-2 pt-6 border-b border-slate-800 pb-2 overflow-x-auto">
          {Object.entries(maturityWall)
            .sort(([y1], [y2]) => parseInt(y1) - parseInt(y2))
            .map(([yrStr, val]) => {
              const amt = val as number;
              const yr = parseInt(yrStr);
              const heightPct = Math.min(100, (amt / 6000) * 100);
              const isSelected = yr === selectedYear;

              return (
                <div
                  key={yr}
                  onClick={() => setSelectedYear(yr)}
                  className="flex-1 flex flex-col items-center gap-2 cursor-pointer group min-w-[40px]"
                >
                  <span className="text-[10px] font-bold text-cyan-300">£{(amt / 1000).toFixed(1)}B</span>
                  <div className="w-full bg-slate-950 rounded-t h-44 flex items-end p-1">
                    <div
                      style={{ height: `${heightPct}%` }}
                      className={`w-full rounded-t transition-all ${
                        isSelected
                          ? 'bg-cyan-500 shadow-lg shadow-cyan-500/50'
                          : amt > 3500
                          ? 'bg-rose-500/80 hover:bg-rose-400'
                          : 'bg-emerald-500/80 hover:bg-emerald-400'
                      }`}
                    />
                  </div>
                  <span className={`text-[11px] font-bold ${isSelected ? 'text-cyan-400' : 'text-slate-400'}`}>
                    {yr}
                  </span>
                </div>
              );
            })}
        </div>
      </div>

      {/* Interactive Refinancing Simulator Control Panel */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3 font-mono">
        <div className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center gap-2">
          <RefreshCw className="w-4 h-4 text-cyan-400" />
          <span>REFINANCING SIMULATION ENGINE</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-[11px]">
          <div>
            <label className="text-slate-400 block mb-1">TARGET MATURITY YEAR</label>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(parseInt(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-cyan-300 font-bold"
            >
              {Object.keys(maturityWall).map((y) => (
                <option key={y} value={y}>
                  {y} (£{maturityWall[parseInt(y)]}M)
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">NEW REFINANCING TENOR</label>
            <select
              value={refinanceTenor}
              onChange={(e) => setRefinanceTenor(parseInt(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100"
            >
              <option value={5}>5 Years</option>
              <option value={7}>7 Years</option>
              <option value={10}>10 Years</option>
              <option value={30}>30 Years</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">ESTIMATED NEW COUPON (%)</label>
            <input
              type="number"
              step="0.1"
              value={refinanceRatePct}
              onChange={(e) => setRefinanceRatePct(parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-amber-300 font-bold"
            />
          </div>

          <div className="flex items-end">
            <button
              onClick={handleSimulateRefinance}
              className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded transition text-xs"
            >
              SIMULATE REFINANCING →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
