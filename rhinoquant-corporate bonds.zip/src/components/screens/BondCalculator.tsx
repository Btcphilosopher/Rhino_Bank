import React, { useState } from 'react';
import {
  Calculator,
  Calendar,
  CheckCircle2,
  Download,
  Info,
  LineChart,
  RefreshCw,
  Sparkles
} from 'lucide-react';
import { useTerminal } from '../../context/TerminalContext';
import { BondInstrument, CouponFrequency, DayCountConvention } from '../../types';
import { priceBondInstrument } from '../../quant/pricingEngine';

export const BondCalculator: React.FC = () => {
  const { setAuditModalBond } = useTerminal();

  // Interactive Calculator State
  const [faceValue, setFaceValue] = useState<number>(100);
  const [couponPct, setCouponPct] = useState<number>(5.25);
  const [frequency, setFrequency] = useState<CouponFrequency>('Semi-Annual');
  const [dayCount, setDayCount] = useState<DayCountConvention>('30/360');
  const [settlementDate, setSettlementDate] = useState<string>('2026-08-31');
  const [maturityDate, setMaturityDate] = useState<string>('2032-08-31');
  const [inputMode, setInputMode] = useState<'PRICE' | 'YIELD'>('PRICE');
  const [inputValue, setInputValue] = useState<number>(99.75);

  // Construct dynamic temporary instrument for central quant engine calculation
  const customBond: BondInstrument = {
    id: 'CALC-CUSTOM-001',
    isin: 'CALC-PROVENANCE',
    cusip: 'CALC-001',
    sedol: 'CALC-00',
    ticker: 'CUSTOM CALCULATOR BOND',
    issuerId: 'CALC-ISSUER',
    issuerName: 'Custom Calculator Instrument',
    currency: 'GBP',
    country: 'United Kingdom',
    sector: 'Industrial',
    seniority: 'Senior Unsecured',
    faceValue,
    coupon: couponPct / 100,
    couponFrequency: frequency,
    couponType: 'Fixed',
    issueDate: '2022-08-31',
    maturityDate,
    settlementConvention: 'T+2',
    dayCountConvention: dayCount,
    isCallable: false,
    isPuttable: false,
    isConvertible: false,
    benchmarkTicker: 'UK 10Y GILT 4.25%',
    ratingMoody: 'A2',
    ratingSP: 'A',
    ratingFitch: 'A',
    covenants: [],
    ranking: 'Senior Unsecured',
    status: 'ACTIVE',
    marketDataStatus: 'SIMULATED'
  };

  const pricing = priceBondInstrument(customBond, settlementDate, inputMode, inputValue);

  return (
    <div className="p-4 space-y-4 font-sans text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-cyan-500/20 text-cyan-400 rounded border border-cyan-500/30">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-100 font-mono">INSTITUTIONAL BOND CALCULATOR</h1>
            <p className="text-[11px] text-slate-400 font-mono">
              Centralized Quantitative Pricing Engine • Precision Yield & Risk Solver
            </p>
          </div>
        </div>

        <button
          onClick={() => setAuditModalBond(customBond)}
          className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold font-mono rounded text-xs transition"
        >
          INSPECT MODEL PROVENANCE
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column: Calculator Inputs Form */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3 font-mono">
          <div className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2">
            BOND SPECIFICATIONS & INPUTS
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-slate-400 text-[10px] block mb-1">PAR FACE VALUE</label>
              <input
                type="number"
                value={faceValue}
                onChange={(e) => setFaceValue(parseFloat(e.target.value) || 100)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-cyan-300 font-bold text-xs"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-400 text-[10px] block mb-1">COUPON RATE (%)</label>
                <input
                  type="number"
                  step="0.001"
                  value={couponPct}
                  onChange={(e) => setCouponPct(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 font-bold text-xs"
                />
              </div>

              <div>
                <label className="text-slate-400 text-[10px] block mb-1">COUPON FREQUENCY</label>
                <select
                  value={frequency}
                  onChange={(e) => setFrequency(e.target.value as CouponFrequency)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-cyan-300 text-xs"
                >
                  <option value="Annual">Annual</option>
                  <option value="Semi-Annual">Semi-Annual</option>
                  <option value="Quarterly">Quarterly</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-400 text-[10px] block mb-1">SETTLEMENT DATE</label>
                <input
                  type="date"
                  value={settlementDate}
                  onChange={(e) => setSettlementDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-slate-200 text-xs"
                />
              </div>

              <div>
                <label className="text-slate-400 text-[10px] block mb-1">MATURITY DATE</label>
                <input
                  type="date"
                  value={maturityDate}
                  onChange={(e) => setMaturityDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-slate-200 text-xs"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-400 text-[10px] block mb-1">DAY-COUNT CONVENTION</label>
              <select
                value={dayCount}
                onChange={(e) => setDayCount(e.target.value as DayCountConvention)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-cyan-300 text-xs"
              >
                <option value="30/360">30/360 (Corporate Standard)</option>
                <option value="ACT/ACT">ACT/ACT (ICMA Standard)</option>
                <option value="ACT/360">ACT/360 (Money Market Standard)</option>
                <option value="ACT/365">ACT/365</option>
              </select>
            </div>

            <div className="pt-2 border-t border-slate-800 space-y-2">
              <label className="text-slate-400 text-[10px] block font-bold">SOLVER TARGET</label>
              <div className="flex rounded border border-slate-700 overflow-hidden text-xs">
                <button
                  onClick={() => setInputMode('PRICE')}
                  className={`flex-1 py-1.5 text-center font-bold ${
                    inputMode === 'PRICE' ? 'bg-cyan-600 text-slate-950' : 'bg-slate-950 text-slate-400'
                  }`}
                >
                  CLEAN PRICE → YIELD
                </button>
                <button
                  onClick={() => setInputMode('YIELD')}
                  className={`flex-1 py-1.5 text-center font-bold ${
                    inputMode === 'YIELD' ? 'bg-cyan-600 text-slate-950' : 'bg-slate-950 text-slate-400'
                  }`}
                >
                  YIELD → PRICE
                </button>
              </div>

              <div>
                <label className="text-slate-400 text-[10px] block mb-1">
                  {inputMode === 'PRICE' ? 'TARGET CLEAN PRICE' : 'TARGET YIELD (DECIMAL OR %)'}
                </label>
                <input
                  type="number"
                  step="0.001"
                  value={inputValue}
                  onChange={(e) => setInputValue(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-emerald-400 font-bold text-sm"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right 2 Columns: Outputs & Calculated Risk Sensitivity */}
        <div className="lg:col-span-2 space-y-4 font-mono">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
            <div className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center justify-between">
              <span>SOLVER OUTPUTS & RISK ANALYTICS</span>
              <span className="text-[10px] text-emerald-400">STATUS: CONVERGED (1e-7 TOL)</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">CLEAN PRICE</div>
                <div className="text-lg font-bold text-slate-100 mt-1">{pricing.cleanPrice.toFixed(4)}</div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">DIRTY PRICE</div>
                <div className="text-lg font-bold text-slate-100 mt-1">{pricing.dirtyPrice.toFixed(4)}</div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">ACCRUED INTEREST</div>
                <div className="text-lg font-bold text-amber-300 mt-1">{pricing.accruedInterest.toFixed(4)}</div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">YIELD TO MATURITY</div>
                <div className="text-lg font-bold text-cyan-300 mt-1">{(pricing.ytm * 100).toFixed(4)}%</div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">MODIFIED DURATION</div>
                <div className="text-lg font-bold text-emerald-400 mt-1">{pricing.modifiedDuration} YRS</div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">DV01 (PER $100K)</div>
                <div className="text-lg font-bold text-emerald-400 mt-1">${(pricing.dv01 * 1000).toFixed(2)}</div>
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 text-[11px] space-y-1 text-slate-300">
              <div className="flex justify-between">
                <span>Macaulay Duration:</span>
                <span className="font-bold text-slate-100">{pricing.macaulayDuration} years</span>
              </div>
              <div className="flex justify-between">
                <span>Convexity:</span>
                <span className="font-bold text-slate-100">{pricing.convexity}</span>
              </div>
              <div className="flex justify-between">
                <span>Spread to 10Y Benchmark:</span>
                <span className="font-bold text-amber-300">+{pricing.spreadToBenchmarkBps} bps</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
