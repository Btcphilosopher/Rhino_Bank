import React from 'react';
import {
  BarChart2,
  Building2,
  CheckCircle,
  ChevronRight,
  Flame,
  Info,
  LineChart,
  ShieldAlert,
  Sparkles,
  TrendingUp
} from 'lucide-react';
import { useTerminal } from '../../context/TerminalContext';
import { calculateCreditSpreads } from '../../quant/creditSpreads';

export const CreditCurveScreen: React.FC = () => {
  const { activeIssuer, bonds, curves, setActiveBond, setActiveScreen } = useTerminal();

  const issuerBonds = bonds.filter((b) => b.issuerId === activeIssuer.id);
  const govtCurve = curves[0];
  const swapCurve = curves[1] || curves[0];

  // Calculated Spread Metrics for Issuer Bonds
  const spreadsList = issuerBonds.map((bond) => {
    return {
      bond,
      spreads: calculateCreditSpreads(bond, '2026-08-31', 100.25, govtCurve, swapCurve)
    };
  });

  return (
    <div className="p-4 space-y-4 font-sans text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-wrap items-center justify-between gap-3 font-mono">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-amber-500/20 text-amber-400 rounded border border-amber-500/30">
            <BarChart2 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-100">{activeIssuer.name} — CREDIT SPREAD ENGINE</h1>
            <p className="text-[11px] text-slate-400">
              G-Spread • I-Spread • Z-Spread • ASW • OAS Curve Analytics
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 bg-slate-800 border border-slate-700 text-cyan-300 font-bold rounded text-xs">
            RATING: {activeIssuer.creditRating} ({activeIssuer.ratingOutlook})
          </span>
        </div>
      </div>

      {/* Credit Curve Summary Nodes */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 font-mono">
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-slate-400 text-[10px]">2Y SPREAD</span>
          <div className="text-base font-bold text-cyan-300 mt-1">+95 bps</div>
          <span className="text-[10px] text-slate-500">Benchmark +95</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-slate-400 text-[10px]">3Y SPREAD</span>
          <div className="text-base font-bold text-cyan-300 mt-1">+108 bps</div>
          <span className="text-[10px] text-slate-500">Benchmark +108</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-slate-400 text-[10px]">5Y SPREAD</span>
          <div className="text-base font-bold text-amber-300 mt-1">+135 bps</div>
          <span className="text-[10px] text-slate-500">Benchmark +135</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-slate-400 text-[10px]">7Y SPREAD</span>
          <div className="text-base font-bold text-amber-300 mt-1">+157 bps</div>
          <span className="text-[10px] text-slate-500">Benchmark +157</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg">
          <span className="text-slate-400 text-[10px]">10Y SPREAD</span>
          <div className="text-base font-bold text-rose-400 mt-1">+182 bps</div>
          <span className="text-[10px] text-slate-500">Benchmark +182</span>
        </div>
      </div>

      {/* Main Table: Multi-Spread Breakdown for Issuer Bonds */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3 font-mono">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-cyan-400" />
            <span>ISSUER BOND CREDIT SPREAD BREAKDOWN</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-[11px]">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="py-2 px-2">BOND TICKER</th>
                <th className="py-2 px-2">MATURITY</th>
                <th className="py-2 px-2">BENCHMARK</th>
                <th className="py-2 px-2 text-right">G-SPREAD</th>
                <th className="py-2 px-2 text-right">I-SPREAD</th>
                <th className="py-2 px-2 text-right">Z-SPREAD</th>
                <th className="py-2 px-2 text-right">ASW SPREAD</th>
                <th className="py-2 px-2 text-right">OAS</th>
                <th className="py-2 px-2 text-center">CURVE STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {spreadsList.map(({ bond, spreads }) => (
                <tr
                  key={bond.id}
                  onClick={() => {
                    setActiveBond(bond);
                    setActiveScreen('bond-analytics');
                  }}
                  className="hover:bg-slate-800/60 transition cursor-pointer"
                >
                  <td className="py-2 px-2 font-bold text-cyan-300">{bond.ticker}</td>
                  <td className="py-2 px-2 text-slate-200">{bond.maturityDate}</td>
                  <td className="py-2 px-2 text-slate-400">{spreads.benchmarkBondTicker}</td>
                  <td className="py-2 px-2 text-right font-bold text-amber-300">+{spreads.gSpreadBps} bps</td>
                  <td className="py-2 px-2 text-right font-bold text-slate-100">+{spreads.iSpreadBps} bps</td>
                  <td className="py-2 px-2 text-right font-bold text-cyan-300">+{spreads.zSpreadBps} bps</td>
                  <td className="py-2 px-2 text-right text-slate-300">+{spreads.assetSwapSpreadBps} bps</td>
                  <td className="py-2 px-2 text-right font-bold text-emerald-400">+{spreads.oasBps} bps</td>
                  <td className="py-2 px-2 text-center">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-[10px]">
                      FAIR VALUE
                    </span>
                  </td>
                </tr>
              ))}
              {spreadsList.length === 0 && (
                <tr>
                  <td colSpan={9} className="py-4 text-center text-slate-500 italic">
                    Select an issuer with active bonds to compute credit spread curves.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
