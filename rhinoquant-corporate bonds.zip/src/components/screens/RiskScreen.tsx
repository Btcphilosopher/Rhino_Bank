import React from 'react';
import {
  Activity,
  AlertTriangle,
  BarChart2,
  CheckCircle,
  Flame,
  LineChart,
  ShieldAlert,
  Sliders,
  TrendingDown,
  TrendingUp,
  Zap
} from 'lucide-react';
import { useTerminal } from '../../context/TerminalContext';
import { calculatePortfolioAnalytics, runPortfolioStressScenarios } from '../../quant/portfolioRisk';

export const RiskScreen: React.FC = () => {
  const { portfolioPositions } = useTerminal();

  const summary = calculatePortfolioAnalytics(portfolioPositions);
  const scenarios = runPortfolioStressScenarios(portfolioPositions, summary);

  return (
    <div className="p-4 space-y-4 font-sans text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-wrap items-center justify-between gap-3 font-mono">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-rose-500/20 text-rose-400 rounded border border-rose-500/30">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-100">FIXED-INCOME RISK & SCENARIO STRESS ENGINE</h1>
            <p className="text-[11px] text-slate-400">
              Interest Rate Risk • Credit Spread Risk • Duration & DV01 Limits • Stress Scenarios
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-300 font-bold rounded text-xs">
            TOTAL DV01 AT RISK: ${summary.totalDv01.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Risk Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
        <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg">
          <span className="text-slate-400 text-[10px]">INTEREST RATE SENSITIVITY (+100BP)</span>
          <div className="text-base font-bold text-rose-400 mt-1">
            -£{((summary.totalDv01 * 100 * 100) / 1000).toFixed(1)} k
          </div>
          <span className="text-[10px] text-slate-500">Duration: {summary.weightedDuration} yrs</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg">
          <span className="text-slate-400 text-[10px]">CREDIT SPREAD SENSITIVITY (+50BP)</span>
          <div className="text-base font-bold text-rose-400 mt-1">
            -£{((summary.totalDv01 * 100 * 50) / 1000).toFixed(1)} k
          </div>
          <span className="text-[10px] text-slate-500">Spread: +{summary.weightedSpreadBps} bps</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg">
          <span className="text-slate-400 text-[10px]">VAR (99% 1-DAY CONFIDENCE)</span>
          <div className="text-base font-bold text-amber-300 mt-1">
            £{(summary.totalMarketValue * 0.012).toFixed(0)}
          </div>
          <span className="text-[10px] text-slate-500">Historical Simulation</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg">
          <span className="text-slate-400 text-[10px]">CONCENTRATION RISK</span>
          <div className="text-base font-bold text-emerald-400 mt-1">27.6% MAX SINGLE OBLIGOR</div>
          <span className="text-[10px] text-slate-500">Limit: 30.0% Max</span>
        </div>
      </div>

      {/* Main Stress Scenarios Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3 font-mono">
        <div className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center justify-between">
          <span>MACROECONOMIC & CREDIT STRESS SCENARIOS</span>
          <span className="text-[10px] text-cyan-400">RECALCULATED POSITIONS</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-[11px]">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="py-2 px-2">STRESS SCENARIO</th>
                <th className="py-2 px-2 text-right">RATE SHIFT</th>
                <th className="py-2 px-2 text-right">SPREAD SHIFT</th>
                <th className="py-2 px-2 text-right">NEW MARKET VALUE (£)</th>
                <th className="py-2 px-2 text-right">ESTIMATED P&L (£)</th>
                <th className="py-2 px-2 text-right">P&L IMPACT (%)</th>
                <th className="py-2 px-2 text-right">NEW YIELD</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {scenarios.map((sc, idx) => (
                <tr
                  key={sc.scenarioName}
                  className={`hover:bg-slate-800/60 transition ${
                    idx === 0 ? 'bg-slate-950 font-bold' : ''
                  }`}
                >
                  <td className="py-2 px-2 text-slate-100">{sc.scenarioName}</td>
                  <td className="py-2 px-2 text-right text-slate-300">
                    {sc.rateShiftBps >= 0 ? `+${sc.rateShiftBps}` : sc.rateShiftBps} bps
                  </td>
                  <td className="py-2 px-2 text-right text-slate-300">
                    {sc.spreadShiftBps >= 0 ? `+${sc.spreadShiftBps}` : sc.spreadShiftBps} bps
                  </td>
                  <td className="py-2 px-2 text-right font-bold text-slate-100">
                    £{sc.portfolioMarketValueNew.toLocaleString()}
                  </td>
                  <td
                    className={`py-2 px-2 text-right font-bold ${
                      sc.portfolioPnLChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    £{sc.portfolioPnLChange.toLocaleString()}
                  </td>
                  <td
                    className={`py-2 px-2 text-right font-bold ${
                      sc.pnlChangePct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {sc.pnlChangePct >= 0 ? `+${sc.pnlChangePct}` : sc.pnlChangePct}%
                  </td>
                  <td className="py-2 px-2 text-right text-cyan-300 font-bold">
                    {(sc.portfolioNewYield * 100).toFixed(2)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
