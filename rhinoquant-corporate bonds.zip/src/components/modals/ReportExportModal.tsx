import React, { useState } from 'react';
import {
  CheckCircle2,
  Download,
  FileCheck,
  FileSpreadsheet,
  FileText,
  Printer,
  X
} from 'lucide-react';
import { useTerminal } from '../../context/TerminalContext';

export const ReportExportModal: React.FC = () => {
  const { reportExportOpen, setReportExportOpen, activeBond, activeIssuer } = useTerminal();

  const [reportType, setReportType] = useState<string>('TERM_SHEET');
  const [exportFormat, setExportFormat] = useState<string>('PDF');

  if (!reportExportOpen) return null;

  const handleExport = () => {
    alert(`Exporting ${reportType} in ${exportFormat} format. Download initiated.`);
    setReportExportOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-lg w-full flex flex-col shadow-2xl font-mono text-xs">
        {/* Modal Header */}
        <div className="p-3 border-b border-slate-800 flex items-center justify-between bg-slate-950 rounded-t-lg">
          <div className="flex items-center gap-2">
            <Download className="w-5 h-5 text-cyan-400" />
            <div>
              <h2 className="font-bold text-sm text-slate-100">INSTITUTIONAL REPORT GENERATOR</h2>
              <span className="text-[10px] text-slate-400">Bloomberg & Pitchbook Grade Publication Engine</span>
            </div>
          </div>

          <button
            onClick={() => setReportExportOpen(false)}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 space-y-4">
          <div className="space-y-2">
            <label className="text-slate-400 text-[10px] block font-bold">REPORT TYPE</label>
            <div className="space-y-2">
              <label className="flex items-center gap-2 p-2 bg-slate-950 border border-slate-800 rounded cursor-pointer hover:border-cyan-500/40">
                <input
                  type="radio"
                  name="reportType"
                  value="TERM_SHEET"
                  checked={reportType === 'TERM_SHEET'}
                  onChange={(e) => setReportType(e.target.value)}
                  className="accent-cyan-500"
                />
                <div>
                  <div className="font-bold text-slate-100">Primary Issue Term Sheet</div>
                  <div className="text-[10px] text-slate-400">
                    Complete syndicate term sheet for {activeIssuer.name} bond issuance
                  </div>
                </div>
              </label>

              <label className="flex items-center gap-2 p-2 bg-slate-950 border border-slate-800 rounded cursor-pointer hover:border-cyan-500/40">
                <input
                  type="radio"
                  name="reportType"
                  value="CREDIT_MEMO"
                  checked={reportType === 'CREDIT_MEMO'}
                  onChange={(e) => setReportType(e.target.value)}
                  className="accent-cyan-500"
                />
                <div>
                  <div className="font-bold text-slate-100">Institutional Credit Investment Memo</div>
                  <div className="text-[10px] text-slate-400">
                    Credit committee report with ratios, covenants, and risk matrices
                  </div>
                </div>
              </label>

              <label className="flex items-center gap-2 p-2 bg-slate-950 border border-slate-800 rounded cursor-pointer hover:border-cyan-500/40">
                <input
                  type="radio"
                  name="reportType"
                  value="PORTFOLIO_VALUATION"
                  checked={reportType === 'PORTFOLIO_VALUATION'}
                  onChange={(e) => setReportType(e.target.value)}
                  className="accent-cyan-500"
                />
                <div>
                  <div className="font-bold text-slate-100">Portfolio Mark-to-Market Valuation</div>
                  <div className="text-[10px] text-slate-400">
                    Audit-ready holding valuation and DV01 risk breakdown
                  </div>
                </div>
              </label>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-slate-400 text-[10px] block font-bold">EXPORT FORMAT</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setExportFormat('PDF')}
                className={`py-2 px-3 rounded border font-bold text-center ${
                  exportFormat === 'PDF'
                    ? 'bg-cyan-600 text-slate-950 border-cyan-500'
                    : 'bg-slate-950 text-slate-300 border-slate-800'
                }`}
              >
                PDF PRINT
              </button>
              <button
                onClick={() => setExportFormat('EXCEL')}
                className={`py-2 px-3 rounded border font-bold text-center ${
                  exportFormat === 'EXCEL'
                    ? 'bg-cyan-600 text-slate-950 border-cyan-500'
                    : 'bg-slate-950 text-slate-300 border-slate-800'
                }`}
              >
                EXCEL CSV
              </button>
              <button
                onClick={() => setExportFormat('XML')}
                className={`py-2 px-3 rounded border font-bold text-center ${
                  exportFormat === 'XML'
                    ? 'bg-cyan-600 text-slate-950 border-cyan-500'
                    : 'bg-slate-950 text-slate-300 border-slate-800'
                }`}
              >
                BLOOMBERG XML
              </button>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-3 border-t border-slate-800 bg-slate-950 rounded-b-lg flex justify-end gap-2">
          <button
            onClick={() => setReportExportOpen(false)}
            className="px-3 py-1.5 bg-slate-800 text-slate-300 font-bold rounded text-xs hover:bg-slate-700"
          >
            CANCEL
          </button>
          <button
            onClick={handleExport}
            className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-xs transition"
          >
            GENERATE & DOWNLOAD
          </button>
        </div>
      </div>
    </div>
  );
};
