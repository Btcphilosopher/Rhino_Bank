import React, { useState } from 'react';
import {
  Bell,
  CheckCircle2,
  ChevronDown,
  Download,
  Globe,
  Info,
  Moon,
  Search,
  Shield,
  Sun,
  Terminal,
  UserCheck
} from 'lucide-react';
import { useTerminal } from '../../context/TerminalContext';
import { UserRole } from '../../types';

export const Header: React.FC = () => {
  const {
    userRole,
    setUserRole,
    theme,
    setTheme,
    isSimulatedData,
    setIsSimulatedData,
    commandInput,
    setCommandInput,
    executeCommand,
    alerts,
    markAlertRead,
    setReportExportOpen
  } = useTerminal();

  const [alertsOpen, setAlertsOpen] = useState(false);
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);

  const unreadCount = alerts.filter((a) => !a.read).length;

  const roles: UserRole[] = [
    'Analyst',
    'Trader',
    'Syndicate Desk',
    'Portfolio Manager',
    'Risk Manager',
    'Corporate Issuer',
    'Compliance',
    'Administrator'
  ];

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      executeCommand(commandInput);
    }
  };

  return (
    <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-40 px-3 py-2 text-xs font-mono">
      {/* Top Banner Row */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        {/* Left: Branding & Terminal Identity */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 font-bold text-sm tracking-wider text-cyan-400">
            <div className="bg-cyan-500/20 text-cyan-400 p-1.5 rounded border border-cyan-500/30">
              <Terminal className="w-4 h-4" />
            </div>
            <span>RHINO<span className="text-slate-100 font-normal">QUANT</span></span>
            <span className="bg-slate-800 text-cyan-300 text-[10px] px-1.5 py-0.5 rounded border border-cyan-500/20 font-sans font-semibold">
              v2.4 INSTITUTIONAL
            </span>
          </div>

          <div className="hidden lg:flex items-center gap-2 text-slate-400 border-l border-slate-800 pl-3">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-[11px] font-sans font-medium text-emerald-400">CONNECTIVITY ACTIVE</span>
            </span>
            <span className="text-slate-600">|</span>
            <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-amber-400 border border-amber-500/30">
              {isSimulatedData ? 'SIMULATED DATA' : 'LIVE FEED'}
            </span>
          </div>
        </div>

        {/* Center: Command Bar */}
        <div className="flex-1 max-w-xl mx-2">
          <div className="relative flex items-center">
            <div className="absolute left-2.5 text-cyan-400 font-bold">
              <Search className="w-3.5 h-3.5" />
            </div>
            <input
              type="text"
              value={commandInput}
              onChange={(e) => setCommandInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="ENTER COMMAND OR TICKER (e.g., IBM CREDIT, YIELD CURVE, RHINO 2032, PORT RISK)..."
              className="w-full bg-slate-950 border border-slate-700/80 rounded pl-8 pr-16 py-1.5 text-xs text-cyan-300 placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 uppercase font-mono tracking-wide"
            />
            <button
              onClick={() => executeCommand(commandInput)}
              className="absolute right-1 px-2 py-0.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-[10px] font-semibold rounded border border-cyan-500/40"
            >
              GO ↵
            </button>
          </div>
        </div>

        {/* Right Controls: Role, Report, Theme, Alerts */}
        <div className="flex items-center gap-2">
          {/* Simulated Data Switcher */}
          <button
            onClick={() => setIsSimulatedData(!isSimulatedData)}
            className="hidden sm:flex items-center gap-1.5 px-2 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-[10px] font-sans font-medium text-slate-300"
            title="Toggle between Simulated Synthetic Universe and Live Market Feed"
          >
            <Globe className="w-3 h-3 text-cyan-400" />
            <span>{isSimulatedData ? 'SIMULATED' : 'LIVE'}</span>
          </button>

          {/* User Role Selector */}
          <div className="relative">
            <button
              onClick={() => setRoleMenuOpen(!roleMenuOpen)}
              className="flex items-center gap-1.5 px-2 py-1 bg-slate-800/80 hover:bg-slate-800 border border-slate-700 rounded text-slate-200 font-sans text-xs"
            >
              <UserCheck className="w-3.5 h-3.5 text-cyan-400" />
              <span>{userRole}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {roleMenuOpen && (
              <div className="absolute right-0 mt-1 w-44 bg-slate-900 border border-slate-700 rounded shadow-xl py-1 z-50">
                <div className="px-2 py-1 text-[10px] text-slate-400 font-semibold border-b border-slate-800">
                  SWITCH TERMINAL ROLE
                </div>
                {roles.map((r) => (
                  <button
                    key={r}
                    onClick={() => {
                      setUserRole(r);
                      setRoleMenuOpen(false);
                    }}
                    className={`w-full text-left px-2 py-1.5 text-xs hover:bg-slate-800 flex items-center justify-between ${
                      userRole === r ? 'text-cyan-400 font-bold bg-slate-800/50' : 'text-slate-300'
                    }`}
                  >
                    <span>{r}</span>
                    {userRole === r && <CheckCircle2 className="w-3 h-3" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Report Export Button */}
          <button
            onClick={() => setReportExportOpen(true)}
            className="flex items-center gap-1 px-2.5 py-1 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-sans font-bold rounded text-xs transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">REPORT</span>
          </button>

          {/* Theme Toggle */}
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-300"
            title="Toggle Dark/Light Mode"
          >
            {theme === 'dark' ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-indigo-400" />}
          </button>

          {/* Alerts Drawer Toggle */}
          <div className="relative">
            <button
              onClick={() => setAlertsOpen(!alertsOpen)}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-300 relative"
            >
              <Bell className="w-3.5 h-3.5 text-cyan-400" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-rose-500 text-white font-bold text-[9px] w-4 h-4 rounded-full flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </button>

            {alertsOpen && (
              <div className="absolute right-0 mt-2 w-80 bg-slate-900 border border-slate-700 rounded-lg shadow-2xl z-50 p-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="font-bold text-xs text-slate-200 flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-cyan-400" />
                    <span>SYSTEM ALERTS ({unreadCount})</span>
                  </div>
                  <button
                    onClick={() => setAlertsOpen(false)}
                    className="text-slate-400 hover:text-slate-200 text-xs"
                  >
                    ✕
                  </button>
                </div>

                <div className="mt-2 space-y-2 max-h-64 overflow-y-auto">
                  {alerts.map((a) => (
                    <div
                      key={a.id}
                      onClick={() => markAlertRead(a.id)}
                      className={`p-2 rounded border text-xs cursor-pointer transition ${
                        a.read ? 'bg-slate-950/50 border-slate-800 opacity-60' : 'bg-slate-800/80 border-cyan-500/30'
                      }`}
                    >
                      <div className="flex items-center justify-between font-bold text-cyan-300">
                        <span>{a.title}</span>
                        <span className="text-[10px] text-slate-400">{a.timestamp}</span>
                      </div>
                      <p className="mt-1 text-slate-300 text-[11px] font-sans">{a.message}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Sub-Header Market Ticker Tape */}
      <div className="mt-1.5 pt-1 border-t border-slate-800/60 flex items-center gap-6 overflow-x-auto text-[11px] text-slate-400 whitespace-nowrap scrollbar-none">
        <div className="flex items-center gap-1 text-cyan-400 font-bold">
          <Info className="w-3 h-3" />
          <span>BENCHMARKS:</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-slate-300 font-semibold">UK GILT 10Y:</span>
          <span className="text-emerald-400 font-mono">4.35% (+2bp)</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-slate-300 font-semibold">US T-10Y:</span>
          <span className="text-emerald-400 font-mono">4.30% (+1bp)</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-slate-300 font-semibold">GER BUND 10Y:</span>
          <span className="text-rose-400 font-mono">2.70% (-1bp)</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-slate-300 font-semibold">EUR IG SPREAD:</span>
          <span className="text-slate-200 font-mono">118 bps</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-slate-300 font-semibold">USD IG SPREAD:</span>
          <span className="text-slate-200 font-mono">124 bps</span>
        </div>
        <div className="flex items-center gap-1 text-slate-400">
          <span>GBP IG SPREAD:</span>
          <span className="text-slate-200 font-mono">138 bps</span>
        </div>
      </div>
    </header>
  );
};
