import React from 'react';
import {
  Activity,
  BarChart3,
  Building2,
  Calculator,
  Compass,
  FileText,
  Layers,
  LineChart,
  PieChart,
  PlusCircle,
  ShieldAlert,
  TrendingUp
} from 'lucide-react';
import { ScreenId, useTerminal } from '../../context/TerminalContext';

interface NavItem {
  id: ScreenId;
  label: string;
  category: 'MARKET' | 'ISSUER & BONDS' | 'ANALYTICS' | 'PRIMARY' | 'PORTFOLIO';
  icon: React.ReactNode;
  shortcut: string;
}

export const Sidebar: React.FC = () => {
  const { activeScreen, setActiveScreen } = useTerminal();

  const navItems: NavItem[] = [
    { id: 'terminal-home', label: '1. Terminal Home', category: 'MARKET', icon: <Activity className="w-4 h-4" />, shortcut: 'F1' },
    { id: 'issuer-profile', label: '2. Issuer Profile', category: 'ISSUER & BONDS', icon: <Building2 className="w-4 h-4" />, shortcut: 'F2' },
    { id: 'bond-analytics', label: '3. Bond Analytics', category: 'ISSUER & BONDS', icon: <LineChart className="w-4 h-4" />, shortcut: 'F3' },
    { id: 'bond-calculator', label: '4. Bond Calculator', category: 'ANALYTICS', icon: <Calculator className="w-4 h-4" />, shortcut: 'F4' },
    { id: 'yield-curve', label: '5. Yield Curves', category: 'ANALYTICS', icon: <TrendingUp className="w-4 h-4" />, shortcut: 'F5' },
    { id: 'credit-curve', label: '6. Credit Spread Curve', category: 'ANALYTICS', icon: <BarChart3 className="w-4 h-4" />, shortcut: 'F6' },
    { id: 'new-issue', label: '7. Debt Origination', category: 'PRIMARY', icon: <PlusCircle className="w-4 h-4" />, shortcut: 'F7' },
    { id: 'order-book', label: '8. Order Book Syndication', category: 'PRIMARY', icon: <Layers className="w-4 h-4" />, shortcut: 'F8' },
    { id: 'portfolio', label: '9. Portfolio Analytics', category: 'PORTFOLIO', icon: <PieChart className="w-4 h-4" />, shortcut: 'F9' },
    { id: 'risk', label: '10. Risk & Stress Engine', category: 'PORTFOLIO', icon: <ShieldAlert className="w-4 h-4" />, shortcut: 'F10' },
    { id: 'maturity-wall', label: '11. Debt Maturity Wall', category: 'ISSUER & BONDS', icon: <Compass className="w-4 h-4" />, shortcut: 'F11' },
    { id: 'research', label: '12. Research Workspace', category: 'ANALYTICS', icon: <FileText className="w-4 h-4" />, shortcut: 'F12' }
  ];

  return (
    <aside className="w-60 bg-slate-900 border-r border-slate-800 flex flex-col justify-between select-none font-sans text-xs shrink-0">
      <div className="py-2 overflow-y-auto">
        <div className="px-3 py-1.5 text-[10px] font-bold text-slate-500 uppercase tracking-widest font-mono">
          WORKSTATION MODULES
        </div>

        <nav className="space-y-0.5 px-1.5">
          {navItems.map((item) => {
            const isActive = activeScreen === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveScreen(item.id)}
                className={`w-full flex items-center justify-between px-2.5 py-2 rounded transition text-left ${
                  isActive
                    ? 'bg-cyan-500/15 text-cyan-300 font-semibold border-l-2 border-cyan-400 pl-2'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-slate-100'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className={isActive ? 'text-cyan-400' : 'text-slate-400'}>
                    {item.icon}
                  </span>
                  <span className="truncate">{item.label}</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500 bg-slate-950/60 px-1 py-0.2 rounded border border-slate-800">
                  {item.shortcut}
                </span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Terminal Footer Status Info */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950/40 text-[10px] text-slate-400 font-mono space-y-1">
        <div className="flex items-center justify-between">
          <span>MODEL VER:</span>
          <span className="text-cyan-400">RQ-QUANT-v2.4</span>
        </div>
        <div className="flex items-center justify-between">
          <span>PRECISION:</span>
          <span className="text-emerald-400">DOUBLE (64-BIT)</span>
        </div>
        <div className="flex items-center justify-between">
          <span>TIME:</span>
          <span className="text-slate-300">2026-08-31 UTC</span>
        </div>
      </div>
    </aside>
  );
};
