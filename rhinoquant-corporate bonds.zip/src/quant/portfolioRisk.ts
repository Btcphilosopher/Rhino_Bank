import { PortfolioPosition, ScenarioStressResult } from '../types';

export interface PortfolioSummary {
  totalMarketValue: number;
  totalBookValue: number;
  totalAccruedInterest: number;
  totalUnrealizedPnL: number;
  weightedYield: number;
  weightedDuration: number;
  weightedConvexity: number;
  totalDv01: number;
  weightedSpreadBps: number;
  currencyBreakdown: Record<string, number>;
  sectorBreakdown: Record<string, number>;
  ratingBreakdown: Record<string, number>;
}

export function calculatePortfolioAnalytics(positions: PortfolioPosition[]): PortfolioSummary {
  const totalMarketValue = positions.reduce((sum, p) => sum + p.marketValue, 0);
  const totalBookValue = positions.reduce((sum, p) => sum + p.parAmountMillions * (p.bookPrice / 100), 0);
  const totalAccruedInterest = positions.reduce((sum, p) => sum + p.accruedInterestTotal, 0);
  const totalUnrealizedPnL = positions.reduce((sum, p) => sum + p.unrealizedPnL, 0);

  if (totalMarketValue === 0) {
    return {
      totalMarketValue: 0,
      totalBookValue: 0,
      totalAccruedInterest: 0,
      totalUnrealizedPnL: 0,
      weightedYield: 0,
      weightedDuration: 0,
      weightedConvexity: 0,
      totalDv01: 0,
      weightedSpreadBps: 0,
      currencyBreakdown: {},
      sectorBreakdown: {},
      ratingBreakdown: {}
    };
  }

  let weightedYieldSum = 0;
  let weightedDurationSum = 0;
  let weightedSpreadSum = 0;
  let totalDv01 = 0;

  const currencyBreakdown: Record<string, number> = {};
  const sectorBreakdown: Record<string, number> = {};
  const ratingBreakdown: Record<string, number> = {};

  positions.forEach((pos) => {
    const weight = pos.marketValue / totalMarketValue;
    weightedYieldSum += pos.currentYield * weight;
    weightedDurationSum += (pos.bond.couponType === 'Zero' ? 5 : 4.8) * weight; // Approx duration
    weightedSpreadSum += pos.currentSpreadBps * weight;
    totalDv01 += pos.dv01Total;

    // Currency
    const ccy = pos.bond.currency;
    currencyBreakdown[ccy] = (currencyBreakdown[ccy] || 0) + pos.marketValue;

    // Sector
    const sec = pos.bond.sector;
    sectorBreakdown[sec] = (sectorBreakdown[sec] || 0) + pos.marketValue;

    // Rating
    const rat = pos.bond.ratingSP;
    ratingBreakdown[rat] = (ratingBreakdown[rat] || 0) + pos.marketValue;
  });

  return {
    totalMarketValue: Number(totalMarketValue.toFixed(2)),
    totalBookValue: Number(totalBookValue.toFixed(2)),
    totalAccruedInterest: Number(totalAccruedInterest.toFixed(2)),
    totalUnrealizedPnL: Number(totalUnrealizedPnL.toFixed(2)),
    weightedYield: Number(weightedYieldSum.toFixed(4)),
    weightedDuration: Number(weightedDurationSum.toFixed(2)),
    weightedConvexity: 0.35,
    totalDv01: Number(totalDv01.toFixed(2)),
    weightedSpreadBps: Math.round(weightedSpreadSum),
    currencyBreakdown,
    sectorBreakdown,
    ratingBreakdown
  };
}

export function runPortfolioStressScenarios(
  positions: PortfolioPosition[],
  summary: PortfolioSummary
): ScenarioStressResult[] {
  const mv = summary.totalMarketValue;
  const dv01 = summary.totalDv01;
  const duration = summary.weightedDuration;

  const scenarios: {
    name: string;
    rateShiftBps: number;
    spreadShiftBps: number;
    defaultMult: number;
  }[] = [
    { name: 'BASE (Current Market)', rateShiftBps: 0, spreadShiftBps: 0, defaultMult: 1 },
    { name: 'RATES +50bp Shift', rateShiftBps: 50, spreadShiftBps: 0, defaultMult: 1 },
    { name: 'RATES +100bp Shift', rateShiftBps: 100, spreadShiftBps: 0, defaultMult: 1 },
    { name: 'RATES -50bp Shift', rateShiftBps: -50, spreadShiftBps: 0, defaultMult: 1 },
    { name: 'SPREAD +25bp Widening', rateShiftBps: 0, spreadShiftBps: 25, defaultMult: 1.1 },
    { name: 'SPREAD +50bp Widening', rateShiftBps: 0, spreadShiftBps: 50, defaultMult: 1.25 },
    { name: 'RECESSION (Rates -75bp, Spread +120bp)', rateShiftBps: -75, spreadShiftBps: 120, defaultMult: 2.0 },
    { name: 'CREDIT DOWNGRADE WAVE (Spread +85bp)', rateShiftBps: 10, spreadShiftBps: 85, defaultMult: 1.5 },
    { name: 'LIQUIDITY STRESS (Spread +150bp)', rateShiftBps: 0, spreadShiftBps: 150, defaultMult: 2.5 }
  ];

  return scenarios.map((sc) => {
    // Total yield shift in basis points
    const totalShiftBps = sc.rateShiftBps + sc.spreadShiftBps;
    
    // P&L impact estimation using DV01 + Duration approximation
    // Delta P = - DV01 * 100 * (Shift in Bps)
    const pnlChange = - (dv01 * 100 * totalShiftBps / 100);
    const pnlChangePct = mv > 0 ? (pnlChange / mv) * 100 : 0;
    const portfolioMarketValueNew = Math.max(0, mv + pnlChange);

    return {
      scenarioName: sc.name,
      rateShiftBps: sc.rateShiftBps,
      spreadShiftBps: sc.spreadShiftBps,
      defaultProbabilityMultiplier: sc.defaultMult,
      portfolioMarketValueNew: Number(portfolioMarketValueNew.toFixed(2)),
      portfolioPnLChange: Number(pnlChange.toFixed(2)),
      pnlChangePct: Number(pnlChangePct.toFixed(2)),
      portfolioNewYield: Number((summary.weightedYield + totalShiftBps / 10000).toFixed(4)),
      portfolioNewDuration: Number((duration * (1 - totalShiftBps / 20000)).toFixed(2))
    };
  });
}
