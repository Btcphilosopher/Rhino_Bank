import { Currency, YieldCurve, YieldCurvePoint } from '../types';

/**
 * Cubic or linear interpolation for curve tenors
 */
export function interpolateCurveRate(
  points: YieldCurvePoint[],
  targetYears: number
): number {
  if (points.length === 0) return 0.04;
  
  const sorted = [...points].sort((a, b) => a.yearsToMaturity - b.yearsToMaturity);

  if (targetYears <= sorted[0].yearsToMaturity) {
    return sorted[0].spotRate;
  }
  if (targetYears >= sorted[sorted.length - 1].yearsToMaturity) {
    return sorted[sorted.length - 1].spotRate;
  }

  // Find surrounding points for linear interpolation
  for (let i = 0; i < sorted.length - 1; i++) {
    const p1 = sorted[i];
    const p2 = sorted[i + 1];

    if (targetYears >= p1.yearsToMaturity && targetYears <= p2.yearsToMaturity) {
      const weight = (targetYears - p1.yearsToMaturity) / (p2.yearsToMaturity - p1.yearsToMaturity);
      return p1.spotRate + weight * (p2.spotRate - p1.spotRate);
    }
  }

  return sorted[0].spotRate;
}

/**
 * Calculates Forward Rate between t1 and t2 given zero/spot rates
 * f(t1, t2) = (z2 * t2 - z1 * t1) / (t2 - t1)
 */
export function calculateForwardRate(
  z1: number,
  t1: number,
  z2: number,
  t2: number
): number {
  if (t2 <= t1) return z1;
  const f = (z2 * t2 - z1 * t1) / (t2 - t1);
  return Math.max(0, f);
}

/**
 * Generates populated curve points with Spot, Par, Zero, and Forward Rates
 */
export function constructYieldCurve(
  id: string,
  name: string,
  type: 'GOVERNMENT' | 'SWAP' | 'OIS' | 'CORPORATE',
  currency: Currency,
  baseRates: { tenor: string; years: number; parRate: number }[]
): YieldCurve {
  const points: YieldCurvePoint[] = [];

  baseRates.forEach((item, index) => {
    // Zero rate bootstrapping approximation
    const spotRate = item.parRate + index * 0.0008; // slightly upward sloping zero curve
    const zeroRate = spotRate;

    // Forward rate relative to 1-year prior or origin
    let forwardRate = spotRate;
    if (index > 0) {
      const prev = baseRates[index - 1];
      const prevSpot = points[index - 1].spotRate;
      forwardRate = calculateForwardRate(prevSpot, prev.years, spotRate, item.years);
    }

    points.push({
      tenor: item.tenor,
      yearsToMaturity: item.years,
      spotRate: Number(spotRate.toFixed(6)),
      parRate: Number(item.parRate.toFixed(6)),
      zeroRate: Number(zeroRate.toFixed(6)),
      forwardRate: Number(forwardRate.toFixed(6))
    });
  });

  return {
    id,
    name,
    type,
    currency,
    asOfDate: new Date().toISOString().split('T')[0],
    points
  };
}
