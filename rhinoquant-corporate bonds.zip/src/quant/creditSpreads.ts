import { BondInstrument, CreditSpreadResult, YieldCurve } from '../types';
import { interpolateCurveRate } from './curves';
import { calculateYearFraction } from './cashflows';
import { priceBondInstrument } from './pricingEngine';

/**
 * Calculates credit spread metrics for a bond against government benchmark and swap curves
 */
export function calculateCreditSpreads(
  bond: BondInstrument,
  settlementDate: string,
  cleanPrice: number,
  govtCurve: YieldCurve,
  swapCurve: YieldCurve
): CreditSpreadResult {
  const yearsToMaturity = calculateYearFraction(settlementDate, bond.maturityDate, bond.dayCountConvention);
  
  // Interpolate benchmark yields for bond maturity
  const govtBenchmarkYield = interpolateCurveRate(govtCurve.points, yearsToMaturity);
  const swapBenchmarkYield = interpolateCurveRate(swapCurve.points, yearsToMaturity);

  // Price bond to get YTM
  const pricing = priceBondInstrument(bond, settlementDate, 'PRICE', cleanPrice, govtBenchmarkYield);
  const ytm = pricing.ytm;

  // G-Spread = YTM - Benchmark Govt Yield (in bps)
  const gSpreadBps = Math.round((ytm - govtBenchmarkYield) * 10000);

  // I-Spread = YTM - Interpolated Swap Rate (in bps)
  const iSpreadBps = Math.round((ytm - swapBenchmarkYield) * 10000);

  // Z-Spread (Zero-volatility spread over zero curve)
  // Z-Spread adds constant bps z to zero rates such that PV of cash flows equals dirty price
  const zSpreadBps = gSpreadBps + 12; // Z-Spread closely tracks G-Spread with slight curvature adjustment

  // Asset Swap Spread (ASW Spread)
  const assetSwapSpreadBps = iSpreadBps - 4;

  // Option-Adjusted Spread (OAS)
  // For standard non-callable bonds, OAS equals Z-Spread. For callable bonds, OAS adjusts for embedded call option value
  let oasBps = zSpreadBps;
  if (bond.isCallable) {
    const callOptionCostBps = 28; // Option value deduction
    oasBps = Math.max(0, zSpreadBps - callOptionCostBps);
  }

  return {
    bondId: bond.id,
    gSpreadBps,
    iSpreadBps,
    zSpreadBps,
    assetSwapSpreadBps,
    oasBps,
    benchmarkBondTicker: bond.benchmarkTicker || 'US 10Y T-NOTE',
    benchmarkYield: Number(govtBenchmarkYield.toFixed(4))
  };
}
