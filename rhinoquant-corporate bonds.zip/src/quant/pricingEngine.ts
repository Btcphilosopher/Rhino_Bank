import { BondInstrument, BondPricingResult } from '../types';
import { calculateAccruedInterest, generateCashFlowSchedule, getPeriodsPerYear } from './cashflows';

/**
 * Calculates Dirty Price from Yield to Maturity (YTM)
 */
export function calculateDirtyPriceFromYield(
  bond: BondInstrument,
  settlementDate: string,
  ytm: number
): number {
  const schedule = generateCashFlowSchedule(bond, settlementDate, ytm);
  return schedule.reduce((sum, period) => sum + period.presentValue, 0);
}

/**
 * Newton-Raphson Solver to calculate YTM from Target Clean Price
 */
export function solveYieldFromCleanPrice(
  bond: BondInstrument,
  settlementDate: string,
  targetCleanPrice: number,
  initialGuess = 0.05
): { ytm: number; iterations: number } {
  const { accruedInterest } = calculateAccruedInterest(bond, settlementDate);
  const targetDirtyPrice = targetCleanPrice + accruedInterest;

  let y = Math.max(0.0001, initialGuess);
  const maxIterations = 100;
  const tolerance = 1e-7;
  let iterations = 0;

  for (let i = 0; i < maxIterations; i++) {
    iterations++;
    const price = calculateDirtyPriceFromYield(bond, settlementDate, y);
    const diff = price - targetDirtyPrice;

    if (Math.abs(diff) < tolerance) {
      return { ytm: y, iterations };
    }

    // Numerical derivative dP/dy
    const deltaY = 0.0001;
    const priceUp = calculateDirtyPriceFromYield(bond, settlementDate, y + deltaY);
    const deriv = (priceUp - price) / deltaY;

    if (Math.abs(deriv) < 1e-12) {
      break;
    }

    y = y - diff / deriv;
    if (y <= 0) y = 0.0001; // Keep yield positive
  }

  return { ytm: Math.max(0.0001, y), iterations };
}

/**
 * Calculates Duration, Convexity, and Risk Sensitivity (DV01)
 */
export function calculateBondRiskMetrics(
  bond: BondInstrument,
  settlementDate: string,
  ytm: number
): {
  macaulayDuration: number;
  modifiedDuration: number;
  convexity: number;
  dv01: number;
  pv01: number;
} {
  const schedule = generateCashFlowSchedule(bond, settlementDate, ytm);
  const dirtyPrice = schedule.reduce((sum, p) => sum + p.presentValue, 0);

  if (dirtyPrice <= 0) {
    return { macaulayDuration: 0, modifiedDuration: 0, convexity: 0, dv01: 0, pv01: 0 };
  }

  const periodsPerYear = getPeriodsPerYear(bond.couponFrequency) || 1;

  let weightedTimeSum = 0;
  let weightedConvexitySum = 0;

  schedule.forEach((period) => {
    const t = period.yearFraction;
    weightedTimeSum += t * period.presentValue;
    weightedConvexitySum += t * (t + 1 / periodsPerYear) * period.presentValue;
  });

  const macaulayDuration = weightedTimeSum / dirtyPrice;
  const modifiedDuration = macaulayDuration / (1 + ytm / periodsPerYear);
  const convexity = weightedConvexitySum / (dirtyPrice * Math.pow(1 + ytm / periodsPerYear, 2));

  // DV01 = Dollar Value of a 1 basis point shift (0.0001) in yield per 100 Par
  const priceUp = calculateDirtyPriceFromYield(bond, settlementDate, ytm + 0.0001);
  const priceDown = calculateDirtyPriceFromYield(bond, settlementDate, ytm - 0.0001);
  const dv01 = Math.abs(priceDown - priceUp) / 2;
  const pv01 = dv01; // PV01 is equivalent to DV01 per $100 nominal

  return {
    macaulayDuration: Number(macaulayDuration.toFixed(4)),
    modifiedDuration: Number(modifiedDuration.toFixed(4)),
    convexity: Number(convexity.toFixed(4)),
    dv01: Number(dv01.toFixed(5)),
    pv01: Number(pv01.toFixed(5))
  };
}

/**
 * Complete institutional bond pricing function given clean price or target yield
 */
export function priceBondInstrument(
  bond: BondInstrument,
  settlementDate: string,
  inputMode: 'PRICE' | 'YIELD',
  inputValue: number,
  benchmarkYield = 0.042
): BondPricingResult {
  const { accruedInterest } = calculateAccruedInterest(bond, settlementDate);
  let cleanPrice = 100;
  let ytm = 0.05;
  let iterations = 1;

  if (inputMode === 'PRICE') {
    cleanPrice = inputValue;
    const solved = solveYieldFromCleanPrice(bond, settlementDate, cleanPrice);
    ytm = solved.ytm;
    iterations = solved.iterations;
  } else {
    ytm = inputValue;
    const dirtyPrice = calculateDirtyPriceFromYield(bond, settlementDate, ytm);
    cleanPrice = dirtyPrice - accruedInterest;
  }

  const dirtyPrice = cleanPrice + accruedInterest;
  const riskMetrics = calculateBondRiskMetrics(bond, settlementDate, ytm);

  // Yield to Call calculation if bond is callable
  let ytc: number | undefined = undefined;
  if (bond.isCallable && bond.callPrice && bond.callDate) {
    const callableBondMock: BondInstrument = {
      ...bond,
      maturityDate: bond.callDate,
      faceValue: bond.callPrice
    };
    ytc = solveYieldFromCleanPrice(callableBondMock, settlementDate, cleanPrice).ytm;
  }

  const ytw = ytc !== undefined ? Math.min(ytm, ytc) : ytm;
  const spreadToBenchmarkBps = Math.round((ytm - benchmarkYield) * 10000);

  return {
    cleanPrice: Number(cleanPrice.toFixed(4)),
    dirtyPrice: Number(dirtyPrice.toFixed(4)),
    accruedInterest: Number(accruedInterest.toFixed(4)),
    ytm: Number(ytm.toFixed(6)),
    ytw: Number(ytw.toFixed(6)),
    ytc: ytc ? Number(ytc.toFixed(6)) : undefined,
    macaulayDuration: riskMetrics.macaulayDuration,
    modifiedDuration: riskMetrics.modifiedDuration,
    convexity: riskMetrics.convexity,
    dv01: riskMetrics.dv01,
    pv01: riskMetrics.pv01,
    spreadToBenchmarkBps,
    pricingTimestamp: new Date().toISOString(),
    modelProvenance: {
      engineVersion: 'RhinoQuant Quant Engine v2.4',
      dayCount: bond.dayCountConvention,
      settlementDate,
      benchmarkYield,
      iterationsToConverge: iterations
    }
  };
}
