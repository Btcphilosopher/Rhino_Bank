import { BondInstrument, CashFlowPeriod, CouponFrequency, DayCountConvention } from '../types';

/**
 * Converts frequency string to annual periods factor
 */
export function getPeriodsPerYear(freq: CouponFrequency): number {
  switch (freq) {
    case 'Annual': return 1;
    case 'Semi-Annual': return 2;
    case 'Quarterly': return 4;
    case 'Monthly': return 12;
    case 'Zero': return 0;
  }
}

/**
 * Calculates day count fraction between two dates according to convention
 */
export function calculateYearFraction(
  startDateStr: string,
  endDateStr: string,
  convention: DayCountConvention
): number {
  const start = new Date(startDateStr);
  const end = new Date(endDateStr);
  
  if (isNaN(start.getTime()) || isNaN(end.getTime()) || start >= end) {
    return 0;
  }

  const diffMs = end.getTime() - start.getTime();
  const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));

  if (convention === '30/360') {
    const d1 = Math.min(start.getDate(), 30);
    const d2 = d1 === 30 ? Math.min(end.getDate(), 30) : end.getDate();
    const m1 = start.getMonth() + 1;
    const m2 = end.getMonth() + 1;
    const y1 = start.getFullYear();
    const y2 = end.getFullYear();

    const days360 = (y2 - y1) * 360 + (m2 - m1) * 30 + (d2 - d1);
    return days360 / 360;
  } else if (convention === 'ACT/360') {
    return diffDays / 360;
  } else if (convention === 'ACT/365') {
    return diffDays / 365;
  } else {
    // ACT/ACT
    const isLeapYear = (year: number) => (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    const daysInYear = isLeapYear(start.getFullYear()) ? 366 : 365;
    return diffDays / daysInYear;
  }
}

/**
 * Calculates Accrued Interest per 100 Par
 */
export function calculateAccruedInterest(
  bond: BondInstrument,
  settlementDateStr: string
): { accruedInterest: number; daysAccrued: number } {
  if (bond.couponType === 'Zero' || bond.coupon === 0) {
    return { accruedInterest: 0, daysAccrued: 0 };
  }

  const periodsPerYear = getPeriodsPerYear(bond.couponFrequency);
  if (periodsPerYear === 0) return { accruedInterest: 0, daysAccrued: 0 };

  const settlement = new Date(settlementDateStr);
  const issue = new Date(bond.issueDate);
  const maturity = new Date(bond.maturityDate);

  if (settlement <= issue || settlement >= maturity) {
    return { accruedInterest: 0, daysAccrued: 0 };
  }

  // Find most recent coupon date prior to settlement
  const monthsInterval = 12 / periodsPerYear;
  let prevCoupon = new Date(maturity);

  while (prevCoupon > settlement) {
    prevCoupon.setMonth(prevCoupon.getMonth() - monthsInterval);
  }

  let nextCoupon = new Date(prevCoupon);
  nextCoupon.setMonth(nextCoupon.getMonth() + monthsInterval);

  const prevCouponStr = prevCoupon.toISOString().split('T')[0];
  const nextCouponStr = nextCoupon.toISOString().split('T')[0];

  const accruedFraction = calculateYearFraction(prevCouponStr, settlementDateStr, bond.dayCountConvention);
  const totalPeriodFraction = calculateYearFraction(prevCouponStr, nextCouponStr, bond.dayCountConvention);

  const annualCouponAmount = bond.faceValue * bond.coupon;
  const accruedInterest = annualCouponAmount * accruedFraction;
  const daysAccrued = Math.round((settlement.getTime() - prevCoupon.getTime()) / (1000 * 60 * 60 * 24));

  return {
    accruedInterest: Math.max(0, accruedInterest),
    daysAccrued: Math.max(0, daysAccrued)
  };
}

/**
 * Generates exact schedule of cash flows for a bond
 */
export function generateCashFlowSchedule(
  bond: BondInstrument,
  settlementDateStr: string,
  discountYield?: number
): CashFlowPeriod[] {
  const periodsPerYear = getPeriodsPerYear(bond.couponFrequency);
  const schedule: CashFlowPeriod[] = [];
  
  const issue = new Date(bond.issueDate);
  const maturity = new Date(bond.maturityDate);
  const settlement = new Date(settlementDateStr);

  if (bond.couponType === 'Zero' || periodsPerYear === 0) {
    // Zero-coupon bond
    const yearFraction = calculateYearFraction(settlementDateStr, bond.maturityDate, bond.dayCountConvention);
    const discountFactor = discountYield !== undefined ? Math.pow(1 + discountYield, -yearFraction) : 1;
    const pv = bond.faceValue * discountFactor;

    schedule.push({
      periodNumber: 1,
      date: bond.maturityDate,
      couponAmount: 0,
      principalAmount: bond.faceValue,
      totalCashFlow: bond.faceValue,
      accruedInterest: 0,
      yearFraction,
      discountFactor,
      presentValue: pv
    });
    return schedule;
  }

  const monthsInterval = 12 / periodsPerYear;
  let currentDate = new Date(maturity);

  // Collect cash flow dates backwards from maturity to settlement
  const cashFlowDates: Date[] = [];
  while (currentDate > settlement) {
    cashFlowDates.unshift(new Date(currentDate));
    currentDate.setMonth(currentDate.getMonth() - monthsInterval);
  }

  const annualCoupon = bond.coupon * bond.faceValue;
  const periodCoupon = annualCoupon / periodsPerYear;
  const y = discountYield ?? 0.05;

  let periodNum = 1;
  for (let i = 0; i < cashFlowDates.length; i++) {
    const cfDate = cashFlowDates[i];
    const cfDateStr = cfDate.toISOString().split('T')[0];
    const isFinalPeriod = i === cashFlowDates.length - 1;

    const t = calculateYearFraction(settlementDateStr, cfDateStr, bond.dayCountConvention);
    
    // Discounting using compounding corresponding to coupon frequency
    const discountFactor = Math.pow(1 + y / periodsPerYear, -t * periodsPerYear);
    const principalAmount = isFinalPeriod ? bond.faceValue : 0;
    const totalCashFlow = periodCoupon + principalAmount;
    const pv = totalCashFlow * discountFactor;

    schedule.push({
      periodNumber: periodNum++,
      date: cfDateStr,
      couponAmount: periodCoupon,
      principalAmount,
      totalCashFlow,
      accruedInterest: 0,
      yearFraction: t,
      discountFactor,
      presentValue: pv
    });
  }

  return schedule;
}
