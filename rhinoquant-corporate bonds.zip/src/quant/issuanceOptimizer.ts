import { CreditRating, Currency, Seniority } from '../types';

export interface IssuanceScenario {
  targetAmountMillions: number;
  tenorYears: number;
  seniority: Seniority;
  expectedRating: CreditRating;
  currency: Currency;
  benchmarkRate: number; // e.g. 0.0425 (4.25%)
  issuerBaseSpreadBps: number; // e.g. 135 bps
}

export interface OptimizedIssuanceResult {
  tightPricing: {
    spreadBps: number;
    yield: number;
    coupon: number;
    price: number;
    annualInterestExpense: number;
    estimatedDemandRatio: number;
  };
  basePricing: {
    spreadBps: number;
    yield: number;
    coupon: number;
    price: number;
    annualInterestExpense: number;
    estimatedDemandRatio: number;
  };
  concessionPricing: {
    spreadBps: number;
    yield: number;
    coupon: number;
    price: number;
    annualInterestExpense: number;
    estimatedDemandRatio: number;
  };
  totalDebtServiceImpact: {
    annualExtraInterestMillions: number;
    debtToEbitdaIncrease: number;
    newWeightedAverageMaturity: number;
  };
}

export function optimizeNewBondIssuance(scenario: IssuanceScenario): OptimizedIssuanceResult {
  const { targetAmountMillions, tenorYears, benchmarkRate, issuerBaseSpreadBps } = scenario;

  // Base Spread
  const baseSpread = issuerBaseSpreadBps;
  const tightSpread = Math.max(10, baseSpread - 15);
  const concessionSpread = baseSpread + 20;

  // Yields
  const baseYield = benchmarkRate + baseSpread / 10000;
  const tightYield = benchmarkRate + tightSpread / 10000;
  const concessionYield = benchmarkRate + concessionSpread / 10000;

  // Coupon (rounded to nearest 1/8th = 0.125%)
  const roundCoupon = (y: number) => Math.round(y * 800) / 800;

  const baseCoupon = roundCoupon(baseYield);
  const tightCoupon = roundCoupon(tightYield);
  const concessionCoupon = roundCoupon(concessionYield);

  // Annual interest expense
  const baseAnnualInterest = targetAmountMillions * baseCoupon;
  const tightAnnualInterest = targetAmountMillions * tightCoupon;
  const concessionAnnualInterest = targetAmountMillions * concessionCoupon;

  return {
    tightPricing: {
      spreadBps: tightSpread,
      yield: Number((tightYield * 100).toFixed(3)),
      coupon: Number((tightCoupon * 100).toFixed(3)),
      price: 99.85,
      annualInterestExpense: Number(tightAnnualInterest.toFixed(2)),
      estimatedDemandRatio: 2.1
    },
    basePricing: {
      spreadBps: baseSpread,
      yield: Number((baseYield * 100).toFixed(3)),
      coupon: Number((baseCoupon * 100).toFixed(3)),
      price: 100.00,
      annualInterestExpense: Number(baseAnnualInterest.toFixed(2)),
      estimatedDemandRatio: 3.4
    },
    concessionPricing: {
      spreadBps: concessionSpread,
      yield: Number((concessionYield * 100).toFixed(3)),
      coupon: Number((concessionCoupon * 100).toFixed(3)),
      price: 100.25,
      annualInterestExpense: Number(concessionAnnualInterest.toFixed(2)),
      estimatedDemandRatio: 4.8
    },
    totalDebtServiceImpact: {
      annualExtraInterestMillions: Number(baseAnnualInterest.toFixed(2)),
      debtToEbitdaIncrease: Number((targetAmountMillions / 1200).toFixed(2)), // approx against EBITDA
      newWeightedAverageMaturity: Number((5.4 + tenorYears * 0.25).toFixed(1))
    }
  };
}
