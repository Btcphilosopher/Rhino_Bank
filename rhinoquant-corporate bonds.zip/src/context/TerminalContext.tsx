import React, { createContext, useContext, useState } from 'react';
import {
  BondInstrument,
  IssuerProfile,
  PortfolioPosition,
  PrimaryIssuanceDeal,
  SystemAlert,
  UserRole,
  YieldCurve
} from '../types';
import {
  INITIAL_ALERTS,
  INITIAL_PORTFOLIO_POSITIONS,
  SYNTHETIC_BONDS,
  SYNTHETIC_CURVES,
  SYNTHETIC_DEALS,
  SYNTHETIC_ISSUERS
} from '../data/syntheticData';

export type ScreenId =
  | 'terminal-home'
  | 'issuer-profile'
  | 'bond-analytics'
  | 'bond-calculator'
  | 'yield-curve'
  | 'credit-curve'
  | 'new-issue'
  | 'order-book'
  | 'portfolio'
  | 'risk'
  | 'maturity-wall'
  | 'research';

interface TerminalContextType {
  activeScreen: ScreenId;
  setActiveScreen: (screen: ScreenId) => void;
  activeIssuer: IssuerProfile;
  setActiveIssuer: (issuer: IssuerProfile) => void;
  activeBond: BondInstrument;
  setActiveBond: (bond: BondInstrument) => void;
  activeCurve: YieldCurve;
  setActiveCurve: (curve: YieldCurve) => void;
  activeDeal: PrimaryIssuanceDeal;
  setActiveDeal: (deal: PrimaryIssuanceDeal) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  theme: 'dark' | 'light';
  setTheme: (theme: 'dark' | 'light') => void;
  isSimulatedData: boolean;
  setIsSimulatedData: (val: boolean) => void;
  commandInput: string;
  setCommandInput: (cmd: string) => void;
  executeCommand: (cmd: string) => void;
  alerts: SystemAlert[];
  markAlertRead: (id: string) => void;
  portfolioPositions: PortfolioPosition[];
  addPortfolioPosition: (bond: BondInstrument, parMillions: number, bookPrice: number) => void;
  auditModalBond: BondInstrument | null;
  setAuditModalBond: (bond: BondInstrument | null) => void;
  reportExportOpen: boolean;
  setReportExportOpen: (open: boolean) => void;
  issuers: IssuerProfile[];
  bonds: BondInstrument[];
  curves: YieldCurve[];
}

const TerminalContext = createContext<TerminalContextType | undefined>(undefined);

export const TerminalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeScreen, setActiveScreen] = useState<ScreenId>('terminal-home');
  const [issuers] = useState<IssuerProfile[]>(SYNTHETIC_ISSUERS);
  const [bonds] = useState<BondInstrument[]>(SYNTHETIC_BONDS);
  const [curves] = useState<YieldCurve[]>(SYNTHETIC_CURVES);

  const [activeIssuer, setActiveIssuer] = useState<IssuerProfile>(SYNTHETIC_ISSUERS[0]);
  const [activeBond, setActiveBond] = useState<BondInstrument>(SYNTHETIC_BONDS[0]);
  const [activeCurve, setActiveCurve] = useState<YieldCurve>(SYNTHETIC_CURVES[0]);
  const [activeDeal, setActiveDeal] = useState<PrimaryIssuanceDeal>(SYNTHETIC_DEALS[0]);

  const [userRole, setUserRole] = useState<UserRole>('Analyst');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [isSimulatedData, setIsSimulatedData] = useState<boolean>(true);
  const [commandInput, setCommandInput] = useState<string>('');
  const [alerts, setAlerts] = useState<SystemAlert[]>(INITIAL_ALERTS);
  const [portfolioPositions, setPortfolioPositions] = useState<PortfolioPosition[]>(INITIAL_PORTFOLIO_POSITIONS);

  const [auditModalBond, setAuditModalBond] = useState<BondInstrument | null>(null);
  const [reportExportOpen, setReportExportOpen] = useState<boolean>(false);

  const markAlertRead = (id: string) => {
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, read: true } : a)));
  };

  const addPortfolioPosition = (bond: BondInstrument, parMillions: number, bookPrice: number) => {
    const marketValue = parMillions * 1000000 * (100.45 / 100);
    const newPos: PortfolioPosition = {
      id: `POS-${Date.now()}`,
      bondId: bond.id,
      bond,
      parAmountMillions: parMillions,
      bookPrice,
      currentPrice: 100.45,
      currentYield: 0.052,
      currentSpreadBps: 120,
      marketValue,
      accruedInterestTotal: parMillions * 10000 * 1.5,
      unrealizedPnL: (100.45 - bookPrice) * parMillions * 10000,
      dv01Total: parMillions * 450,
      weightPct: 10
    };
    setPortfolioPositions((prev) => [...prev, newPos]);
  };

  const executeCommand = (rawCmd: string) => {
    const cmd = rawCmd.trim().toUpperCase();
    setCommandInput('');

    if (!cmd) return;

    // Search issuer by ticker or name
    const foundIssuer = issuers.find(
      (i) => i.ticker.toUpperCase() === cmd || i.name.toUpperCase().includes(cmd)
    );
    if (foundIssuer) {
      setActiveIssuer(foundIssuer);
      setActiveScreen('issuer-profile');
      return;
    }

    // Search bond by ticker, ISIN, or CUSIP
    const foundBond = bonds.find(
      (b) =>
        b.ticker.toUpperCase().includes(cmd) ||
        b.isin.toUpperCase() === cmd ||
        b.cusip.toUpperCase() === cmd ||
        b.id.toUpperCase() === cmd
    );
    if (foundBond) {
      setActiveBond(foundBond);
      setActiveScreen('bond-analytics');
      return;
    }

    // Bloomberg-style route shortcuts
    if (cmd.includes('CREDIT') || cmd.includes('ISSUER')) {
      setActiveScreen('issuer-profile');
    } else if (cmd.includes('CURVE') || cmd.includes('YIELD')) {
      setActiveScreen('yield-curve');
    } else if (cmd.includes('SPREAD') || cmd.includes('G-SPREAD')) {
      setActiveScreen('credit-curve');
    } else if (cmd.includes('PORT') || cmd.includes('PORTFOLIO')) {
      setActiveScreen('portfolio');
    } else if (cmd.includes('RISK') || cmd.includes('STRESS') || cmd.includes('DV01')) {
      setActiveScreen('risk');
    } else if (cmd.includes('NEW') || cmd.includes('ISSUE') || cmd.includes('SYNDICATE')) {
      setActiveScreen('new-issue');
    } else if (cmd.includes('BOOK') || cmd.includes('ORDER')) {
      setActiveScreen('order-book');
    } else if (cmd.includes('CALC') || cmd.includes('PRICING')) {
      setActiveScreen('bond-calculator');
    } else if (cmd.includes('MATURITY') || cmd.includes('WALL')) {
      setActiveScreen('maturity-wall');
    } else if (cmd.includes('RESEARCH') || cmd.includes('DOC')) {
      setActiveScreen('research');
    } else {
      setActiveScreen('terminal-home');
    }
  };

  return (
    <TerminalContext.Provider
      value={{
        activeScreen,
        setActiveScreen,
        activeIssuer,
        setActiveIssuer,
        activeBond,
        setActiveBond,
        activeCurve,
        setActiveCurve,
        activeDeal,
        setActiveDeal,
        userRole,
        setUserRole,
        theme,
        setTheme,
        isSimulatedData,
        setIsSimulatedData,
        commandInput,
        setCommandInput,
        executeCommand,
        alerts,
        markAlertRead,
        portfolioPositions,
        addPortfolioPosition,
        auditModalBond,
        setAuditModalBond,
        reportExportOpen,
        setReportExportOpen,
        issuers,
        bonds,
        curves
      }}
    >
      <div className={theme === 'dark' ? 'dark bg-slate-950 text-slate-100 min-h-screen' : 'light bg-slate-50 text-slate-900 min-h-screen'}>
        {children}
      </div>
    </TerminalContext.Provider>
  );
};

export const useTerminal = () => {
  const ctx = useContext(TerminalContext);
  if (!ctx) throw new Error('useTerminal must be used within TerminalProvider');
  return ctx;
};
