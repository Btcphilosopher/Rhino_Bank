import React from 'react';
import { TerminalProvider, useTerminal } from './context/TerminalContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { TerminalHome } from './components/screens/TerminalHome';
import { IssuerScreen } from './components/screens/IssuerScreen';
import { BondScreen } from './components/screens/BondScreen';
import { BondCalculator } from './components/screens/BondCalculator';
import { YieldCurveScreen } from './components/screens/YieldCurveScreen';
import { CreditCurveScreen } from './components/screens/CreditCurveScreen';
import { NewIssueScreen } from './components/screens/NewIssueScreen';
import { OrderBookScreen } from './components/screens/OrderBookScreen';
import { PortfolioScreen } from './components/screens/PortfolioScreen';
import { RiskScreen } from './components/screens/RiskScreen';
import { MaturityWallScreen } from './components/screens/MaturityWallScreen';
import { ResearchWorkspace } from './components/screens/ResearchWorkspace';
import { CalculationAuditModal } from './components/modals/CalculationAuditModal';
import { ReportExportModal } from './components/modals/ReportExportModal';

const TerminalMain: React.FC = () => {
  const { activeScreen } = useTerminal();

  const renderActiveScreen = () => {
    switch (activeScreen) {
      case 'home':
        return <TerminalHome />;
      case 'issuer-profile':
        return <IssuerScreen />;
      case 'bond-analytics':
        return <BondScreen />;
      case 'bond-calculator':
        return <BondCalculator />;
      case 'yield-curve':
        return <YieldCurveScreen />;
      case 'credit-curve':
        return <CreditCurveScreen />;
      case 'new-issue':
        return <NewIssueScreen />;
      case 'order-book':
        return <OrderBookScreen />;
      case 'portfolio':
        return <PortfolioScreen />;
      case 'risk':
        return <RiskScreen />;
      case 'maturity-wall':
        return <MaturityWallScreen />;
      case 'research':
        return <ResearchWorkspace />;
      default:
        return <TerminalHome />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Fixed Terminal Header with Global Search and Command Engine */}
      <Header />

      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Modular Navigation Sidebar */}
        <Sidebar />

        {/* Dynamic Screen Viewport */}
        <main className="flex-1 overflow-y-auto bg-slate-950">
          {renderActiveScreen()}
        </main>
      </div>

      {/* Audit & Report Export Modals */}
      <CalculationAuditModal />
      <ReportExportModal />
    </div>
  );
};

export function App() {
  return (
    <TerminalProvider>
      <TerminalMain />
    </TerminalProvider>
  );
}

export default App;
