/**
 * RhinoQuant Institutional Domain Models & Types
 */

export type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'CHF' | 'CAD';
export type Sector = 'Industrial' | 'Energy' | 'Telecom' | 'Infrastructure' | 'Manufacturing' | 'Logistics' | 'Healthcare' | 'Technology' | 'Banking' | 'Automotive';
export type CreditRating = 'AAA' | 'AA+' | 'AA' | 'AA-' | 'A+' | 'A' | 'A-' | 'BBB+' | 'BBB' | 'BBB-' | 'BB+' | 'BB' | 'BB-' | 'B+' | 'B' | 'B-';
export type RatingOutlook = 'Positive' | 'Stable' | 'Negative' | 'Developing' | 'Watch Positive' | 'Watch Negative';
export type Seniority = 'Senior Secured' | 'Senior Unsecured' | 'Subordinated' | 'Junior Subordinated' | 'First Lien' | 'Second Lien';
export type CouponFrequency = 'Annual' | 'Semi-Annual' | 'Quarterly' | 'Monthly' | 'Zero';
export type DayCountConvention = '30/360' | 'ACT/ACT' | 'ACT/360' | 'ACT/365';
export type SettlementConvention = 'T+1' | 'T+2' | 'T+3';
export type CouponType = 'Fixed' | 'Floating' | 'Zero' | 'Step-Up' | 'Step-Down' | 'Inflation-Linked';
export type MarketDataStatus = 'LIVE' | 'DELAYED' | 'HISTORICAL' | 'SIMULATED';

export interface BondInstrument {
  id: string; // RhinoQuant canonical ID
  isin: string;
  cusip: string;
  sedol: string;
  ticker: string;
  issuerId: string;
  issuerName: string;
  currency: Currency;
  country: string;
  sector: Sector;
  seniority: Seniority;
  faceValue: number;
  coupon: number; // e.g. 0.0525 for 5.25%
  couponFrequency: CouponFrequency;
  couponType: CouponType;
  issueDate: string; // YYYY-MM-DD
  maturityDate: string; // YYYY-MM-DD
  settlementConvention: SettlementConvention;
  dayCountConvention: DayCountConvention;
  isCallable: boolean;
  callDate?: string;
  callPrice?: number;
  isPuttable: boolean;
  putDate?: string;
  putPrice?: number;
  isConvertible: boolean;
  benchmarkTicker: string;
  ratingMoody: string;
  ratingSP: CreditRating;
  ratingFitch: CreditRating;
  covenants: string[];
  collateral?: string;
  ranking: string;
  status: 'ACTIVE' | 'MATURED' | 'NEW_ISSUE_PENDING';
  marketDataStatus: MarketDataStatus;
}

export interface IssuerProfile {
  id: string;
  name: string;
  legalEntity: string;
  ticker: string;
  sector: Sector;
  country: string;
  creditRating: CreditRating;
  ratingOutlook: RatingOutlook;
  description: string;
  financials: {
    revenue: number; // Millions in local currency
    ebitda: number;
    netDebt: number;
    cash: number;
    freeCashFlow: number;
    interestExpense: number;
    totalAssets: number;
    totalEquity: number;
    asOfDate: string;
  };
  creditMetrics: {
    debtToEbitda: number;
    netDebtToEbitda: number;
    ebitdaToInterest: number;
    fcfToDebt: number;
    debtToCapital: number;
    currentRatio: number;
    cashToDebt: number;
  };
  defaultHistory: string[];
  covenantsOverview: string;
}

export interface CashFlowPeriod {
  periodNumber: number;
  date: string;
  couponAmount: number;
  principalAmount: number;
  totalCashFlow: number;
  accruedInterest: number;
  yearFraction: number;
  discountFactor: number;
  presentValue: number;
}

export interface BondPricingResult {
  cleanPrice: number;
  dirtyPrice: number;
  accruedInterest: number;
  ytm: number; // Yield to maturity
  ytw: number; // Yield to worst
  ytc?: number; // Yield to call
  macaulayDuration: number;
  modifiedDuration: number;
  convexity: number;
  dv01: number; // Dollar Value of 01 basis point (per 100k or par)
  pv01: number;
  spreadToBenchmarkBps: number;
  pricingTimestamp: string;
  modelProvenance: {
    engineVersion: string;
    dayCount: DayCountConvention;
    settlementDate: string;
    benchmarkYield: number;
    iterationsToConverge: number;
  };
}

export interface YieldCurvePoint {
  tenor: string; // e.g. "1Y", "2Y", "5Y", "10Y", "30Y"
  yearsToMaturity: number;
  spotRate: number; // e.g. 0.0425
  parRate: number;
  zeroRate: number;
  forwardRate: number;
}

export interface YieldCurve {
  id: string;
  name: string;
  type: 'GOVERNMENT' | 'SWAP' | 'OIS' | 'CORPORATE';
  currency: Currency;
  asOfDate: string;
  points: YieldCurvePoint[];
}

export interface CreditSpreadResult {
  bondId: string;
  gSpreadBps: number; // Spread over benchmark government bond
  iSpreadBps: number; // Spread over swap curve
  zSpreadBps: number; // Zero-volatility spread
  assetSwapSpreadBps: number;
  oasBps: number; // Option-adjusted spread
  benchmarkBondTicker: string;
  benchmarkYield: number;
}

export interface OrderBookOrder {
  id: string;
  investorName: string;
  accountType: 'Asset Manager' | 'Pension Fund' | 'Hedge Fund' | 'Insurance' | 'Private Wealth' | 'Bank Treasury';
  geography: 'US' | 'UK' | 'EU' | 'Asia' | 'LatAm';
  quantityMillions: number;
  limitPriceOrSpread: string; // e.g. "+135 bps" or "99.85"
  limitSpreadBps: number;
  orderType: 'LIMIT' | 'MARKET' | 'SCALED';
  timestamp: string;
  status: 'PENDING' | 'ACCEPTED' | 'REJECTED' | 'ALLOCATED';
  allocatedMillions: number;
  allocationPct: number;
}

export interface PrimaryIssuanceDeal {
  id: string;
  dealName: string;
  issuerId: string;
  issuerName: string;
  currency: Currency;
  targetAmountMillions: number;
  tenorYears: number;
  maturityDate: string;
  seniority: Seniority;
  expectedRating: CreditRating;
  benchmark: string;
  benchmarkYield: number;
  stage: 'MANDATE' | 'INITIAL_PRICE_TALK' | 'INVESTOR_MARKETING' | 'ORDER_BOOK' | 'REVISED_GUIDANCE' | 'FINAL_TERMS' | 'ALLOCATION' | 'SETTLEMENT';
  initialGuidanceSpreadBps: number;
  revisedGuidanceSpreadBps: number;
  finalSpreadBps: number;
  finalCoupon: number;
  finalPrice: number;
  totalOrdersMillions: number;
  oversubscriptionRatio: number;
  useOfProceeds: string;
  leadManagers: string[];
}

export interface PortfolioPosition {
  id: string;
  bondId: string;
  bond: BondInstrument;
  parAmountMillions: number;
  bookPrice: number;
  currentPrice: number;
  currentYield: number;
  currentSpreadBps: number;
  marketValue: number;
  accruedInterestTotal: number;
  unrealizedPnL: number;
  dv01Total: number;
  weightPct: number;
}

export interface ScenarioStressResult {
  scenarioName: string;
  rateShiftBps: number;
  spreadShiftBps: number;
  defaultProbabilityMultiplier: number;
  portfolioMarketValueNew: number;
  portfolioPnLChange: number;
  pnlChangePct: number;
  portfolioNewYield: number;
  portfolioNewDuration: number;
}

export interface DocumentExtraction {
  id: string;
  documentTitle: string;
  documentType: 'Prospectus' | 'Offering Memorandum' | 'Final Terms' | 'Financial Statement' | 'Rating Report' | 'Covenant Document';
  sourceFile: string;
  pageNumber: number;
  extractedField: string;
  extractedValue: string;
  confidenceScore: number; // e.g. 0.98
  timestamp: string;
}

export interface SystemAlert {
  id: string;
  type: 'SPREAD_WIDENING' | 'YIELD_SPIKE' | 'RATING_CHANGE' | 'NEW_ISSUE' | 'DV01_LIMIT' | 'CURVE_INVERSION';
  severity: 'HIGH' | 'MEDIUM' | 'INFO';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  targetEntityId?: string;
}

export type UserRole = 'Analyst' | 'Trader' | 'Syndicate Desk' | 'Portfolio Manager' | 'Risk Manager' | 'Corporate Issuer' | 'Compliance' | 'Administrator';
