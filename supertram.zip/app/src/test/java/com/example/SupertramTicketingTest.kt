package com.example

import com.example.data.model.Ticket
import com.example.data.model.TicketStatus
import com.example.data.repository.StationRepository
import com.example.qr.QrCodeGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.math.BigDecimal
import java.time.Instant

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SupertramTicketingTest {

    private val stationRepository = StationRepository()

    @Test
    fun stationSearch_returnsMatchingStations() {
        val results = stationRepository.searchStations("cathedral")
        assertTrue(results.isNotEmpty())
        assertEquals("Cathedral", results.first().name)
    }

    @Test
    fun qrCodeGenerator_createsValidBitmap() {
        val payload = "SUPERTRAM-DEMO:ST-839291"
        val qrBitmap = QrCodeGenerator.generateQrBitmap(payload)
        assertNotNull(qrBitmap)
    }

    @Test
    fun ticketModel_attributesMatchesExpectedValues() {
        val now = Instant.now()
        val ticket = Ticket(
            id = "ST-839291",
            productId = "single-demo",
            productName = "Single",
            origin = "Cathedral",
            destination = "Meadowhall",
            route = "BLUE",
            purchaseTime = now,
            validFrom = now,
            validUntil = now.plusSeconds(7200),
            price = BigDecimal("3.20"),
            status = TicketStatus.ACTIVE,
            qrPayload = "SUPERTRAM-DEMO:ST-839291"
        )

        assertEquals("ST-839291", ticket.id)
        assertEquals("Cathedral", ticket.origin)
        assertEquals("Meadowhall", ticket.destination)
        assertEquals(TicketStatus.ACTIVE, ticket.status)
        assertEquals("SUPERTRAM-DEMO:ST-839291", ticket.qrPayload)
    }
}
