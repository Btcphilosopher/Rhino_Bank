package com.example.data.model

import java.math.BigDecimal
import java.time.Instant

data class Ticket(
    val id: String,
    val productId: String,
    val productName: String,
    val origin: String,
    val destination: String,
    val route: String?,
    val purchaseTime: Instant,
    val validFrom: Instant,
    val validUntil: Instant?,
    val price: BigDecimal,
    val status: TicketStatus,
    val qrPayload: String
)
