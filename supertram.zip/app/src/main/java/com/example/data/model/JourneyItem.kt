package com.example.data.model

data class JourneyItem(
    val id: String,
    val origin: String,
    val destination: String,
    val dateGroup: String,
    val time: String,
    val price: String
)
