package com.example.data.model

data class Station(
    val id: String,
    val name: String,
    val routes: List<String>,
    val isPopular: Boolean = false
)
