package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val productName: String,
    val origin: String,
    val destination: String,
    val route: String?,
    val purchaseTimeEpochMs: Long,
    val validFromEpochMs: Long,
    val validUntilEpochMs: Long?,
    val priceAmount: String,
    val status: String,
    val qrPayload: String
)
