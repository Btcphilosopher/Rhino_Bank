package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.RouteBlue
import com.example.ui.theme.RoutePurple
import com.example.ui.theme.RouteTramTrain
import com.example.ui.theme.RouteYellow

enum class SupertramRoute(
    val displayName: String,
    val code: String,
    val color: Color,
    val routeDescription: String,
    val terminals: Pair<String, String>,
    val stops: List<String>
) {
    BLUE(
        displayName = "Blue Route",
        code = "BLUE",
        color = RouteBlue,
        routeDescription = "Halfway ↔ City Centre ↔ Malin Bridge",
        terminals = "Halfway" to "Malin Bridge",
        stops = listOf(
            "Halfway", "Waterthorpe", "Beighton", "Crystal Peaks", "Drakehouse",
            "Mosborough Parkway", "Westfield", "Hackenthorpe", "Birley Lane", "Birley Moor",
            "Gleadless Townend", "Hollinsend", "Spring Lane", "Park Grange", "Castle Square",
            "Cathedral", "City Hall", "West Street", "University of Sheffield", "Glover Road",
            "Shalesmoor", "Infirmary Road", "Langsett / Primrose View", "Bamforth Street",
            "Hillsborough", "Hillsborough Park", "Leppings Lane", "Middlewood", "Malin Bridge"
        )
    ),
    YELLOW(
        displayName = "Yellow Route",
        code = "YELLOW",
        color = RouteYellow,
        routeDescription = "Meadowhall ↔ City Centre ↔ Middlewood",
        terminals = "Meadowhall" to "Middlewood",
        stops = listOf(
            "Meadowhall Interchange", "Meadowhall South / Tinsley", "Carbrook", "Valley Centertainment",
            "Arena / Olympic Legacy Park", "Attercliffe", "Woodshof", "Darnall", "Hyde Park",
            "Fitzalan Square / Ponds Forge", "Cathedral", "City Hall", "West Street",
            "University of Sheffield", "Shalesmoor", "Infirmary Road", "Hillsborough",
            "Hillsborough Park", "Leppings Lane", "Middlewood"
        )
    ),
    PURPLE(
        displayName = "Purple Route",
        code = "PURPLE",
        color = RoutePurple,
        routeDescription = "Herdings Park ↔ City Centre ↔ Cathedral",
        terminals = "Herdings Park" to "Cathedral",
        stops = listOf(
            "Herdings Park", "Herdings / Leighton Road", "Gleadless Townend", "Hollinsend",
            "Spring Lane", "Park Grange Croft", "Park Grange", "Arbourthorne Road",
            "Granville Road / Sheffield College", "Sheffield Station / Hallam University",
            "Fitzalan Square / Ponds Forge", "Cathedral"
        )
    ),
    TRAM_TRAIN(
        displayName = "Tram Train",
        code = "TRAM_TRAIN",
        color = RouteTramTrain,
        routeDescription = "Rotherham Parkgate ↔ City Centre ↔ Cathedral",
        terminals = "Rotherham Parkgate" to "Cathedral",
        stops = listOf(
            "Rotherham Parkgate", "Rotherham Central Station", "Ickles",
            "Meadowhall South / Tinsley", "Carbrook", "Valley Centertainment",
            "Arena / Olympic Legacy Park", "Attercliffe", "Fitzalan Square / Ponds Forge",
            "Cathedral"
        )
    )
}
