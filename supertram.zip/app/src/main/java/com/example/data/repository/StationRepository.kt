package com.example.data.repository

import com.example.data.model.Station

class StationRepository {

    private val allStations = listOf(
        Station("cathedral", "Cathedral", listOf("BLUE", "YELLOW", "PURPLE", "TRAM_TRAIN"), isPopular = true),
        Station("meadowhall", "Meadowhall Interchange", listOf("YELLOW"), isPopular = true),
        Station("sheffield_station", "Sheffield Station / Hallam Uni", listOf("PURPLE"), isPopular = true),
        Station("university", "University of Sheffield", listOf("BLUE", "YELLOW"), isPopular = true),
        Station("shalesmoor", "Shalesmoor", listOf("BLUE", "YELLOW"), isPopular = false),
        Station("city_hall", "City Hall", listOf("BLUE", "YELLOW"), isPopular = false),
        Station("west_street", "West Street", listOf("BLUE", "YELLOW"), isPopular = false),
        Station("fitzalan_square", "Fitzalan Square / Ponds Forge", listOf("YELLOW", "PURPLE", "TRAM_TRAIN"), isPopular = true),
        Station("valley_centertainment", "Valley Centertainment", listOf("YELLOW", "TRAM_TRAIN"), isPopular = false),
        Station("arena", "Arena / Olympic Legacy Park", listOf("YELLOW", "TRAM_TRAIN"), isPopular = false),
        Station("hillsborough", "Hillsborough", listOf("BLUE", "YELLOW"), isPopular = false),
        Station("malin_bridge", "Malin Bridge", listOf("BLUE"), isPopular = false),
        Station("middlewood", "Middlewood", listOf("BLUE", "YELLOW"), isPopular = false),
        Station("halfway", "Halfway", listOf("BLUE"), isPopular = false),
        Station("crystal_peaks", "Crystal Peaks", listOf("BLUE"), isPopular = false),
        Station("herdings_park", "Herdings Park", listOf("PURPLE"), isPopular = false),
        Station("rotherham_parkgate", "Rotherham Parkgate", listOf("TRAM_TRAIN"), isPopular = false),
        Station("rotherham_central", "Rotherham Central Station", listOf("TRAM_TRAIN"), isPopular = false),
        Station("attercliffe", "Attercliffe", listOf("YELLOW", "TRAM_TRAIN"), isPopular = false),
        Station("carbrook", "Carbrook", listOf("YELLOW", "TRAM_TRAIN"), isPopular = false)
    )

    fun getStations(): List<Station> = allStations

    fun getPopularStations(): List<Station> = allStations.filter { it.isPopular }

    fun getRecentStations(): List<Station> = listOf(
        allStations.first { it.name.startsWith("Cathedral") },
        allStations.first { it.name.startsWith("Meadowhall") },
        allStations.first { it.name == "Shalesmoor" }
    )

    fun searchStations(query: String): List<Station> {
        if (query.isBlank()) return allStations
        val cleanQuery = query.trim().lowercase()
        return allStations.filter { it.name.lowercase().contains(cleanQuery) }
    }
}
