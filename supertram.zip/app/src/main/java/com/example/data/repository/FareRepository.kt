package com.example.data.repository

import android.content.Context
import com.example.data.model.FareProduct
import org.json.JSONObject
import java.math.BigDecimal

class FareRepository(private val context: Context) {

    fun getFareProducts(): List<FareProduct> {
        return try {
            val jsonString = context.assets.open("fares.json").bufferedReader().use { it.readText() }
            val jsonObject = JSONObject(jsonString)
            val productsArray = jsonObject.getJSONArray("products")
            val list = mutableListOf<FareProduct>()
            for (i in 0 until productsArray.length()) {
                val item = productsArray.getJSONObject(i)
                list.add(
                    FareProduct(
                        id = item.getString("id"),
                        name = item.getString("name"),
                        price = BigDecimal(item.getDouble("price").toString()),
                        validityMinutes = item.getLong("validityMinutes"),
                        restrictions = item.getString("restrictions"),
                        code = item.optString("code", "SUP")
                    )
                )
            }
            list
        } catch (e: Exception) {
            getFallbackProducts()
        }
    }

    private fun getFallbackProducts(): List<FareProduct> = listOf(
        FareProduct("single-demo", "Single", BigDecimal("3.20"), 120, "Valid for 1 journey on selected route", "SGL"),
        FareProduct("return-demo", "Return", BigDecimal("5.20"), 1440, "Valid for 2 journeys between origin & destination today", "RTN"),
        FareProduct("day-ticket-demo", "Day Ticket", BigDecimal("5.60"), 1440, "Unlimited travel across all Supertram routes today", "DAY"),
        FareProduct("group-ticket-demo", "Group Day Ticket", BigDecimal("12.00"), 1440, "Unlimited travel for up to 2 adults and 3 children", "GRP"),
        FareProduct("concessionary-demo", "Student / Concession", BigDecimal("2.00"), 120, "Valid with valid student or concession pass", "CON")
    )
}
