package com.example.data.model

import java.math.BigDecimal

data class FareProduct(
    val id: String,
    val name: String,
    val price: BigDecimal,
    val validityMinutes: Long,
    val restrictions: String,
    val code: String
)
