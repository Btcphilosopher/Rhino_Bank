package com.example.data.model

enum class TicketStatus {
    ACTIVE,
    UPCOMING,
    EXPIRED,
    CANCELLED
}
