package com.example.data.repository

import com.example.data.local.TicketDao
import com.example.data.local.TicketEntity
import com.example.data.model.Ticket
import com.example.data.model.TicketStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.math.BigDecimal
import java.time.Instant

class TicketRepository(private val ticketDao: TicketDao) {

    val allTickets: Flow<List<Ticket>> = ticketDao.getAllTickets().map { entities ->
        entities.map { it.toDomainModel() }
    }

    suspend fun getTicketById(id: String): Ticket? {
        return ticketDao.getTicketById(id)?.toDomainModel()
    }

    suspend fun saveTicket(ticket: Ticket) {
        ticketDao.insertTicket(ticket.toEntity())
    }

    suspend fun updateStatus(id: String, status: TicketStatus) {
        ticketDao.updateStatus(id, status.name)
    }

    private fun TicketEntity.toDomainModel(): Ticket {
        val nowMs = System.currentTimeMillis()
        val computedStatus = if (status == TicketStatus.ACTIVE.name && validUntilEpochMs != null && validUntilEpochMs < nowMs) {
            TicketStatus.EXPIRED
        } else {
            TicketStatus.valueOf(status)
        }

        return Ticket(
            id = id,
            productId = productId,
            productName = productName,
            origin = origin,
            destination = destination,
            route = route,
            purchaseTime = Instant.ofEpochMilli(purchaseTimeEpochMs),
            validFrom = Instant.ofEpochMilli(validFromEpochMs),
            validUntil = validUntilEpochMs?.let { Instant.ofEpochMilli(it) },
            price = BigDecimal(priceAmount),
            status = computedStatus,
            qrPayload = qrPayload
        )
    }

    private fun Ticket.toEntity(): TicketEntity {
        return TicketEntity(
            id = id,
            productId = productId,
            productName = productName,
            origin = origin,
            destination = destination,
            route = route,
            purchaseTimeEpochMs = purchaseTime.toEpochMilli(),
            validFromEpochMs = validFrom.toEpochMilli(),
            validUntilEpochMs = validUntil?.toEpochMilli(),
            priceAmount = price.toPlainString(),
            status = status.name,
            qrPayload = qrPayload
        )
    }
}
