package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Ticket
import com.example.ui.components.PerforatedTicketCard
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.SteelBorderDark
import com.example.ui.theme.SteelGreyLight
import com.example.ui.theme.SteelGreyMedium
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketDetailsScreen(
    ticket: Ticket,
    countdownTimer: String?,
    onClose: () -> Unit
) {
    var showTermsSheet by remember { mutableStateOf(false) }

    val dateFormatter = remember {
        DateTimeFormatter.ofPattern("dd MMMM yyyy", Locale.UK).withZone(ZoneId.systemDefault())
    }
    val timeFormatter = remember {
        DateTimeFormatter.ofPattern("HH:mm", Locale.UK).withZone(ZoneId.systemDefault())
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepGraphite)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            // Close bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DIGITAL TICKET PASS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.5.sp,
                        color = PaperWhite
                    )
                )

                IconButton(
                    onClick = onClose,
                    modifier = Modifier.testTag("close_ticket_details_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close ticket view",
                        tint = PaperWhite
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Piece de resistance Perforated Ticket Card Component
            PerforatedTicketCard(
                ticket = ticket,
                remainingTimeString = countdownTimer,
                showQr = true
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Detailed Attributes Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = PaperWhite)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Text(
                        text = "TICKET DETAILS",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.5.sp,
                            color = DeepGraphite
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    DetailRow(label = "Product", value = ticket.productName)
                    DetailRow(label = "From", value = ticket.origin)
                    DetailRow(label = "To", value = ticket.destination)
                    DetailRow(label = "Purchased", value = "${dateFormatter.format(ticket.purchaseTime)} ${timeFormatter.format(ticket.purchaseTime)}")
                    DetailRow(label = "Valid Until", value = ticket.validUntil?.let { "${dateFormatter.format(it)} ${timeFormatter.format(it)}" } ?: "End of service today")
                    DetailRow(label = "Price", value = "£${ticket.price.toPlainString()}")
                    DetailRow(label = "Ticket ID", value = ticket.id, isMonospace = true)

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedButton(
                        onClick = { showTermsSheet = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ticket_terms_button")
                            .semantics { contentDescription = "Open ticket terms and conditions" },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text(
                            text = "TICKET TERMS & CONDITIONS",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = DeepGraphite
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }

        // Terms Bottom Sheet
        if (showTermsSheet) {
            ModalBottomSheet(
                onDismissRequest = { showTermsSheet = false },
                containerColor = PaperWhite,
                contentColor = DeepGraphite
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Text(
                        text = "SUPERTRAM TICKET TERMS",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = DeepGraphite
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "1. This ticket is valid for travel on Sheffield Supertram services as indicated on the pass.\n\n" +
                                "2. Tickets must be activated and presented upon request to Supertram conductors or ticket inspectors.\n\n" +
                                "3. Tickets are non-transferable and only valid on specified route products.\n\n" +
                                "4. DEMO TICKET: Issued for demonstration and evaluation purposes.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = DeepGraphite)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { showTermsSheet = false },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = DeepGraphite)
                    ) {
                        Text("AGREE & CLOSE")
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(
    label: String,
    value: String,
    isMonospace: Boolean = false
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(color = SteelGreyLight)
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.SansSerif,
                    color = DeepGraphite
                )
            )
        }
        HorizontalDivider(color = SteelBorderDark.copy(alpha = 0.1f))
    }
}
