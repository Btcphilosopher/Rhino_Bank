package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FareProduct
import com.example.data.model.Station
import com.example.ui.components.SupertramHeader
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.RouteBlue
import com.example.ui.theme.SheffieldRed
import com.example.ui.theme.SteelBorderDark
import com.example.ui.theme.SteelGreyLight
import com.example.ui.theme.SteelGreyMedium
import com.example.ui.viewmodel.PaymentUiState

enum class SelectedPaymentOption {
    GOOGLE_PAY,
    SAVED_CARD,
    DEMO_PAYMENT
}

@Composable
fun PaymentScreen(
    origin: Station,
    destination: Station,
    product: FareProduct,
    paymentState: PaymentUiState,
    onBackClick: () -> Unit,
    onPayClick: () -> Unit
) {
    var selectedOption by remember { mutableStateOf(SelectedPaymentOption.DEMO_PAYMENT) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperWhite)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 8.dp, end = 8.dp, top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("payment_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = DeepGraphite
                    )
                }
                Text(
                    text = "CHECKOUT",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.5.sp,
                        color = DeepGraphite
                    )
                )
            }

            SupertramHeader(title = "PAYMENT", subtitle = "DEMO GATEWAY")

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                // Ticket Summary Card
                Text(
                    text = "YOUR TICKET SUMMARY",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.5.sp,
                        color = DeepGraphite
                    ),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SteelBorderDark.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                    shape = RoundedCornerShape(12.dp),
                    color = PaperWhite,
                    shadowElevation = 2.dp
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = product.name.uppercase(),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = DeepGraphite
                                )
                            )
                            Text(
                                text = "£${product.price.toPlainString()}",
                                style = MaterialTheme.typography.displaySmall.copy(
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = DeepGraphite
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "${origin.name.uppercase()} → ${destination.name.uppercase()}",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = RouteBlue
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = SteelBorderDark.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = SteelGreyMedium,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "DEMO PAYMENT • NO REAL MONEY CHARGED",
                                style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "SELECT PAYMENT METHOD",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.5.sp,
                        color = DeepGraphite
                    ),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Payment Options
                PaymentOptionRow(
                    title = "Google Pay",
                    subtitle = "Fast & secure digital wallet",
                    icon = Icons.Default.Payment,
                    isSelected = selectedOption == SelectedPaymentOption.GOOGLE_PAY,
                    onSelect = { selectedOption = SelectedPaymentOption.GOOGLE_PAY },
                    testTag = "pay_option_gpay"
                )

                PaymentOptionRow(
                    title = "Saved Card (•••• 8821)",
                    subtitle = "Visa ending in 8821",
                    icon = Icons.Default.CreditCard,
                    isSelected = selectedOption == SelectedPaymentOption.SAVED_CARD,
                    onSelect = { selectedOption = SelectedPaymentOption.SAVED_CARD },
                    testTag = "pay_option_card"
                )

                PaymentOptionRow(
                    title = "Demo Instant Payment",
                    subtitle = "Recommended for fast evaluation testing",
                    icon = Icons.Default.FlashOn,
                    isSelected = selectedOption == SelectedPaymentOption.DEMO_PAYMENT,
                    onSelect = { selectedOption = SelectedPaymentOption.DEMO_PAYMENT },
                    testTag = "pay_option_demo"
                )

                Spacer(modifier = Modifier.height(28.dp))

                val isProcessing = paymentState is PaymentUiState.Processing

                Button(
                    onClick = onPayClick,
                    enabled = !isProcessing,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("confirm_payment_button")
                        .semantics { contentDescription = "Confirm payment and issue ticket" },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepGraphite),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(
                            color = PaperWhite,
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "ISSUING TICKET...",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp
                            )
                        )
                    } else {
                        Text(
                            text = "PAY £${product.price.toPlainString()} & ISSUE TICKET",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.5.sp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun PaymentOptionRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onSelect: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .border(
                if (isSelected) 2.dp else 1.dp,
                if (isSelected) DeepGraphite else SteelBorderDark.copy(alpha = 0.3f),
                RoundedCornerShape(8.dp)
            )
            .clickable { onSelect() }
            .testTag(testTag),
        shape = RoundedCornerShape(8.dp),
        color = PaperWhite
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = isSelected,
                onClick = onSelect,
                colors = RadioButtonDefaults.colors(selectedColor = DeepGraphite)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = DeepGraphite,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = DeepGraphite
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                )
            }
        }
    }
}
