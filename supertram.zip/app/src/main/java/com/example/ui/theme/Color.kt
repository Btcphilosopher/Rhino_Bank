package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sheffield Industrial & Transport Palette
val DeepGraphite = Color(0xFF121315)
val SteelDarkCard = Color(0xFF1C1E22)
val SteelBorderDark = Color(0xFF2C3038)

val WarmOffWhite = Color(0xFFF4F3EF)
val PaperWhite = Color(0xFFFFFFFF)
val SteelBorderLight = Color(0xFFE2E0D8)

val SteelGreyDark = Color(0xFF2C3036)
val SteelGreyMedium = Color(0xFF5A606C)
val SteelGreyLight = Color(0xFF8A909A)
val SteelGreyMuted = Color(0xFFB0B5BD)

// Supertram Official Route Identity Accent Colors
val RouteBlue = Color(0xFF0055A5)
val RouteYellow = Color(0xFFC78900)
val RoutePurple = Color(0xFF6A2A80)
val RouteTramTrain = Color(0xFFD9381E)

// Sheffield Civic Red Accent
val SheffieldRed = Color(0xFFC82A2B)
val SheffieldRedDark = Color(0xFF9E1F20)

// Active Ticket Neon-Steel Indicator
val TicketValidGreen = Color(0xFF0F7A40)
val TicketValidGreenBg = Color(0xFFE6F4EA)
