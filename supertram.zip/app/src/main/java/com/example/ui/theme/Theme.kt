package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = RouteBlue,
    onPrimary = PaperWhite,
    secondary = SteelGreyLight,
    onSecondary = PaperWhite,
    tertiary = SheffieldRed,
    background = DeepGraphite,
    onBackground = WarmOffWhite,
    surface = SteelDarkCard,
    onSurface = WarmOffWhite,
    surfaceVariant = SteelBorderDark,
    onSurfaceVariant = SteelGreyLight,
    outline = SteelGreyMedium
)

private val LightColorScheme = lightColorScheme(
    primary = DeepGraphite,
    onPrimary = PaperWhite,
    secondary = RouteBlue,
    onSecondary = PaperWhite,
    tertiary = SheffieldRed,
    background = WarmOffWhite,
    onBackground = DeepGraphite,
    surface = PaperWhite,
    onSurface = DeepGraphite,
    surfaceVariant = WarmOffWhite,
    onSurfaceVariant = SteelGreyMedium,
    outline = SteelBorderLight
)

@Composable
fun SupertramTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = SupertramTypography,
        content = content
    )
}
