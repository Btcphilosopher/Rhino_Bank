package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Station
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.RouteBlue
import com.example.ui.theme.SteelBorderDark
import com.example.ui.theme.SteelGreyLight
import com.example.ui.theme.SteelGreyMedium

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationSelectorModal(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    sheetState: SheetState,
    targetTitle: String,
    searchQuery: String,
    onQueryChange: (String) -> Unit,
    allStations: List<Station>,
    recentStations: List<Station>,
    popularStations: List<Station>,
    onSelectStation: (Station) -> Unit
) {
    if (!isOpen) return

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = PaperWhite,
        contentColor = DeepGraphite,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            // Header bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SELECT $targetTitle STATION",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.5.sp,
                        color = DeepGraphite
                    )
                )
                Spacer(modifier = Modifier.weight(1f))
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_station_modal")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close station search",
                        tint = DeepGraphite
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search input field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("station_search_input"),
                placeholder = {
                    Text(
                        text = "Type a station name...",
                        color = SteelGreyLight
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search icon",
                        tint = SteelGreyMedium
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = DeepGraphite,
                    unfocusedBorderColor = SteelBorderDark.copy(alpha = 0.4f),
                    focusedContainerColor = PaperWhite,
                    unfocusedContainerColor = PaperWhite
                ),
                shape = RoundedCornerShape(8.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Station list content
            val filteredStations = if (searchQuery.isBlank()) {
                allStations
            } else {
                allStations.filter { it.name.lowercase().contains(searchQuery.trim().lowercase()) }
            }

            LazyColumn(
                modifier = Modifier.fillMaxWidth()
            ) {
                if (searchQuery.isBlank()) {
                    // RECENT section
                    item {
                        Text(
                            text = "RECENT",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = SteelGreyMedium,
                                letterSpacing = 1.2.sp
                            ),
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }

                    items(recentStations) { station ->
                        StationRowItem(station = station, onSelect = { onSelectStation(station) })
                    }

                    item {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "POPULAR",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = SteelGreyMedium,
                                letterSpacing = 1.2.sp
                            ),
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }

                    items(popularStations) { station ->
                        StationRowItem(station = station, onSelect = { onSelectStation(station) })
                    }

                    item {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "ALL STATIONS",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = SteelGreyMedium,
                                letterSpacing = 1.2.sp
                            ),
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                }

                items(filteredStations) { station ->
                    StationRowItem(station = station, onSelect = { onSelectStation(station) })
                }
            }
        }
    }
}

@Composable
private fun StationRowItem(
    station: Station,
    onSelect: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .testTag("station_row_${station.id}")
            .semantics { contentDescription = "Select station ${station.name}" }
            .padding(vertical = 12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Place,
                contentDescription = null,
                tint = RouteBlue,
                modifier = Modifier.padding(end = 12.dp)
            )

            Text(
                text = station.name,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = DeepGraphite
                )
            )
        }
        HorizontalDivider(
            color = SteelBorderDark.copy(alpha = 0.15f),
            modifier = Modifier.padding(top = 10.dp)
        )
    }
}
