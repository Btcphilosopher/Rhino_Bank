package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import com.example.ui.theme.SteelBorderDark
import com.example.ui.theme.SteelBorderLight

@Composable
fun TramBackgroundPattern(
    modifier: Modifier = Modifier,
    isDark: Boolean = false
) {
    val lineAlpha = if (isDark) 0.15f else 0.08f
    val lineColor = if (isDark) SteelBorderDark.copy(alpha = lineAlpha) else SteelBorderLight.copy(alpha = lineAlpha)

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // Subtle parallel tram rail lines angling across background
        val railGap = 16f
        val pathEffect = PathEffect.dashPathEffect(floatArrayOf(30f, 15f), 0f)

        // Track line pair 1
        drawLine(
            color = lineColor,
            start = Offset(width * 0.1f, 0f),
            end = Offset(width * 0.1f, height),
            strokeWidth = 2f,
            pathEffect = pathEffect
        )
        drawLine(
            color = lineColor,
            start = Offset(width * 0.1f + railGap, 0f),
            end = Offset(width * 0.1f + railGap, height),
            strokeWidth = 2f,
            pathEffect = pathEffect
        )

        // Track line pair 2
        drawLine(
            color = lineColor,
            start = Offset(width * 0.85f, 0f),
            end = Offset(width * 0.85f, height),
            strokeWidth = 2f,
            pathEffect = pathEffect
        )
        drawLine(
            color = lineColor,
            start = Offset(width * 0.85f + railGap, 0f),
            end = Offset(width * 0.85f + railGap, height),
            strokeWidth = 2f,
            pathEffect = pathEffect
        )
    }
}
