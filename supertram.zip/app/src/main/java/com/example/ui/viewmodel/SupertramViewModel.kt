package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.FareProduct
import com.example.data.model.JourneyItem
import com.example.data.model.Station
import com.example.data.model.Ticket
import com.example.data.model.TicketStatus
import com.example.data.repository.FareRepository
import com.example.data.repository.StationRepository
import com.example.data.repository.TicketRepository
import com.example.payment.DemoPaymentProvider
import com.example.payment.PaymentProvider
import com.example.payment.PaymentResult
import com.example.ui.components.NavItem
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.time.Duration
import java.time.Instant

enum class StationTarget {
    ORIGIN,
    DESTINATION
}

sealed class PaymentUiState {
    data object Idle : PaymentUiState()
    data object Processing : PaymentUiState()
    data class Success(val ticket: Ticket) : PaymentUiState()
    data class Error(val message: String) : PaymentUiState()
}

class SupertramViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val ticketRepository = TicketRepository(db.ticketDao())
    private val stationRepository = StationRepository()
    private val fareRepository = FareRepository(application)
    private val paymentProvider: PaymentProvider = DemoPaymentProvider()

    // Navigation state
    private val _currentNavItem = MutableStateFlow(NavItem.HOME)
    val currentNavItem: StateFlow<NavItem> = _currentNavItem.asStateFlow()

    // Selected stations for purchase
    private val _stations = MutableStateFlow(stationRepository.getStations())
    val stations: StateFlow<List<Station>> = _stations.asStateFlow()

    private val _selectedOrigin = MutableStateFlow(
        stationRepository.getStations().first { it.name.startsWith("Cathedral") }
    )
    val selectedOrigin: StateFlow<Station> = _selectedOrigin.asStateFlow()

    private val _selectedDestination = MutableStateFlow(
        stationRepository.getStations().first { it.name.startsWith("Meadowhall") }
    )
    val selectedDestination: StateFlow<Station> = _selectedDestination.asStateFlow()

    // Station modal picker state
    private val _isStationPickerOpen = MutableStateFlow(false)
    val isStationPickerOpen: StateFlow<Boolean> = _isStationPickerOpen.asStateFlow()

    private val _stationPickerTarget = MutableStateFlow(StationTarget.ORIGIN)
    val stationPickerTarget: StateFlow<StationTarget> = _stationPickerTarget.asStateFlow()

    private val _stationSearchQuery = MutableStateFlow("")
    val stationSearchQuery: StateFlow<String> = _stationSearchQuery.asStateFlow()

    // Fares
    private val _fareProducts = MutableStateFlow(fareRepository.getFareProducts())
    val fareProducts: StateFlow<List<FareProduct>> = _fareProducts.asStateFlow()

    private val _selectedFareProduct = MutableStateFlow<FareProduct?>(fareRepository.getFareProducts().firstOrNull())
    val selectedFareProduct: StateFlow<FareProduct?> = _selectedFareProduct.asStateFlow()

    // Tickets State from Room DB
    private val _allTickets = MutableStateFlow<List<Ticket>>(emptyList())
    val allTickets: StateFlow<List<Ticket>> = _allTickets.asStateFlow()

    private val _activeTicket = MutableStateFlow<Ticket?>(null)
    val activeTicket: StateFlow<Ticket?> = _activeTicket.asStateFlow()

    private val _selectedTicketDetail = MutableStateFlow<Ticket?>(null)
    val selectedTicketDetail: StateFlow<Ticket?> = _selectedTicketDetail.asStateFlow()

    // Countdown Timer string
    private val _countdownString = MutableStateFlow<String?>(null)
    val countdownString: StateFlow<String?> = _countdownString.asStateFlow()

    // Payment State
    private val _paymentState = MutableStateFlow<PaymentUiState>(PaymentUiState.Idle)
    val paymentState: StateFlow<PaymentUiState> = _paymentState.asStateFlow()

    // First Run welcome experience
    private val _isFirstRun = MutableStateFlow(false)
    val isFirstRun: StateFlow<Boolean> = _isFirstRun.asStateFlow()

    // Journey History
    val journeyHistory = MutableStateFlow(
        listOf(
            JourneyItem("j1", "Cathedral", "Meadowhall Interchange", "Today", "12:37", "£3.20"),
            JourneyItem("j2", "University of Sheffield", "Cathedral", "Yesterday", "18:12", "£3.20"),
            JourneyItem("j3", "Meadowhall Interchange", "Cathedral", "17 Sep", "09:31", "£5.20")
        )
    )

    init {
        // Collect DB tickets reactively
        viewModelScope.launch {
            ticketRepository.allTickets.collectLatest { tickets ->
                _allTickets.value = tickets
                val active = tickets.firstOrNull { it.status == TicketStatus.ACTIVE }
                _activeTicket.value = active
            }
        }

        // Timer countdown loop
        viewModelScope.launch {
            while (true) {
                val ticket = _activeTicket.value
                if (ticket?.validUntil != null) {
                    val now = Instant.now()
                    if (now.isAfter(ticket.validUntil)) {
                        _countdownString.value = "EXPIRED"
                        ticketRepository.updateStatus(ticket.id, TicketStatus.EXPIRED)
                    } else {
                        val duration = Duration.between(now, ticket.validUntil)
                        val hours = duration.toHours()
                        val minutes = duration.toMinutes() % 60
                        val seconds = duration.seconds % 60
                        _countdownString.value = String.format("%02d:%02d:%02d", hours, minutes, seconds)
                    }
                } else {
                    _countdownString.value = null
                }
                delay(1000)
            }
        }
    }

    fun navigateTo(item: NavItem) {
        _currentNavItem.value = item
    }

    fun openStationPicker(target: StationTarget) {
        _stationPickerTarget.value = target
        _stationSearchQuery.value = ""
        _isStationPickerOpen.value = true
    }

    fun closeStationPicker() {
        _isStationPickerOpen.value = false
    }

    fun updateStationSearchQuery(query: String) {
        _stationSearchQuery.value = query
    }

    fun selectStation(station: Station) {
        if (_stationPickerTarget.value == StationTarget.ORIGIN) {
            _selectedOrigin.value = station
        } else {
            _selectedDestination.value = station
        }
        closeStationPicker()
    }

    fun swapStations() {
        val temp = _selectedOrigin.value
        _selectedOrigin.value = _selectedDestination.value
        _selectedDestination.value = temp
    }

    fun selectFareProduct(product: FareProduct) {
        _selectedFareProduct.value = product
    }

    fun openTicketDetail(ticket: Ticket) {
        _selectedTicketDetail.value = ticket
    }

    fun closeTicketDetail() {
        _selectedTicketDetail.value = null
    }

    fun completeFirstRun() {
        _isFirstRun.value = false
    }

    fun processPayment() {
        val product = _selectedFareProduct.value ?: return
        val origin = _selectedOrigin.value.name
        val destination = _selectedDestination.value.name

        viewModelScope.launch {
            _paymentState.value = PaymentUiState.Processing
            when (val result = paymentProvider.purchase(product)) {
                is PaymentResult.Success -> {
                    val now = Instant.now()
                    val validUntil = now.plusSeconds(product.validityMinutes * 60)
                    val ticketId = "ST-${(100000..999999).random()}"

                    val qrPayload = "SUPERTRAM-DEMO:$ticketId|FROM:$origin|TO:$destination|VALID:${validUntil.toEpochMilli()}"

                    val newTicket = Ticket(
                        id = ticketId,
                        productId = product.id,
                        productName = product.name,
                        origin = origin,
                        destination = destination,
                        route = "BLUE",
                        purchaseTime = now,
                        validFrom = now,
                        validUntil = validUntil,
                        price = product.price,
                        status = TicketStatus.ACTIVE,
                        qrPayload = qrPayload
                    )

                    ticketRepository.saveTicket(newTicket)
                    _paymentState.value = PaymentUiState.Success(newTicket)
                    _selectedTicketDetail.value = newTicket
                }
                is PaymentResult.Error -> {
                    _paymentState.value = PaymentUiState.Error(result.message)
                }
            }
        }
    }

    fun resetPaymentState() {
        _paymentState.value = PaymentUiState.Idle
    }
}
