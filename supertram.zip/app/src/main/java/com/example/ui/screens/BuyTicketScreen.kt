package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FareProduct
import com.example.data.model.Station
import com.example.ui.components.FareCard
import com.example.ui.components.SupertramHeader
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.RouteBlue
import com.example.ui.theme.SteelBorderDark
import com.example.ui.theme.SteelGreyLight

@Composable
fun BuyTicketScreen(
    origin: Station,
    destination: Station,
    fareProducts: List<FareProduct>,
    selectedProduct: FareProduct?,
    onOpenOriginPicker: () -> Unit,
    onOpenDestinationPicker: () -> Unit,
    onSwap: () -> Unit,
    onSelectProduct: (FareProduct) -> Unit,
    onProceedToPayment: () -> Unit
) {
    var rotationAngle by remember { mutableFloatStateOf(0f) }
    val animatedRotation by animateFloatAsState(
        targetValue = rotationAngle,
        animationSpec = tween(300),
        label = "swap_rotation"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperWhite)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            SupertramHeader(title = "BUY TICKET", subtitle = "SHEFFIELD FARES")

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp)
            ) {
                item {
                    Text(
                        text = "WHERE ARE YOU TRAVELLING?",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.5.sp,
                            color = DeepGraphite
                        ),
                        modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
                    )

                    // Journey Origin -> Destination Box with Tactile Swap
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, SteelBorderDark.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                        shape = RoundedCornerShape(12.dp),
                        color = PaperWhite,
                        shadowElevation = 2.dp
                    ) {
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                modifier = Modifier.padding(20.dp)
                            ) {
                                // From
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onOpenOriginPicker() }
                                        .padding(vertical = 4.dp)
                                        .testTag("buy_origin_field")
                                ) {
                                    Text(
                                        text = "FROM",
                                        style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                                    )
                                    Text(
                                        text = origin.name,
                                        style = MaterialTheme.typography.titleLarge.copy(
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DeepGraphite
                                        )
                                    )
                                }

                                HorizontalDivider(
                                    color = SteelBorderDark.copy(alpha = 0.2f),
                                    modifier = Modifier.padding(vertical = 12.dp)
                                )

                                // To
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onOpenDestinationPicker() }
                                        .padding(vertical = 4.dp)
                                        .testTag("buy_destination_field")
                                ) {
                                    Text(
                                        text = "TO",
                                        style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                                    )
                                    Text(
                                        text = destination.name,
                                        style = MaterialTheme.typography.titleLarge.copy(
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DeepGraphite
                                        )
                                    )
                                }
                            }

                            // Tactile Swap Button centered on divider
                            IconButton(
                                onClick = {
                                    rotationAngle += 180f
                                    onSwap()
                                },
                                modifier = Modifier
                                    .align(Alignment.CenterEnd)
                                    .padding(end = 16.dp)
                                    .size(44.dp)
                                    .background(DeepGraphite, CircleShape)
                                    .rotate(animatedRotation)
                                    .testTag("swap_stations_button")
                                    .semantics { contentDescription = "Swap origin and destination stations" }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SwapVert,
                                    contentDescription = null,
                                    tint = PaperWhite,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "SELECT TICKET PRODUCT",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.5.sp,
                            color = DeepGraphite
                        ),
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }

                // Fare Product Cards
                items(fareProducts) { product ->
                    FareCard(
                        product = product,
                        origin = origin.name,
                        destination = destination.name,
                        isSelected = selectedProduct?.id == product.id,
                        onSelect = { onSelectProduct(product) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = onProceedToPayment,
                        enabled = selectedProduct != null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("proceed_to_payment_button")
                            .semantics { contentDescription = "Proceed to payment screen" },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepGraphite),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "CONTINUE TO PAYMENT (£${selectedProduct?.price?.toPlainString() ?: "0.00"})",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.5.sp
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}
