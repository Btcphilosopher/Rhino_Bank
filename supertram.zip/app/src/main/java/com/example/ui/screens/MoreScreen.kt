package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SupertramHeader
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.SteelBorderDark
import com.example.ui.theme.SteelGreyLight

@Composable
fun MoreScreen(
    onOpenNetwork: () -> Unit,
    onOpenJourneys: () -> Unit,
    onOpenStationPicker: () -> Unit,
    usualStationName: String
) {
    var isHighContrast by remember { mutableStateOf(false) }
    var isReducedMotion by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperWhite)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            SupertramHeader(title = "MORE", subtitle = "CIVIC & SERVICES")

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                Text(
                    text = "NETWORK & TRAVEL",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.5.sp,
                        color = DeepGraphite
                    ),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                MoreRowItem(
                    title = "Supertram Network View",
                    subtitle = "Interactive 4-route schematic & stops",
                    icon = Icons.Default.Map,
                    onClick = onOpenNetwork,
                    testTag = "more_option_network"
                )

                MoreRowItem(
                    title = "Journey History",
                    subtitle = "View past travel logs and receipts",
                    icon = Icons.Default.History,
                    onClick = onOpenJourneys,
                    testTag = "more_option_journeys"
                )

                MoreRowItem(
                    title = "Usual Start Station ($usualStationName)",
                    subtitle = "Set default origin for quick ticketing",
                    icon = Icons.Default.Place,
                    onClick = onOpenStationPicker,
                    testTag = "more_option_start_station"
                )

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "ACCESSIBILITY & PREFERENCES",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.5.sp,
                        color = DeepGraphite
                    ),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .border(1.dp, SteelBorderDark.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                    shape = RoundedCornerShape(8.dp),
                    color = PaperWhite
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Accessible,
                                    contentDescription = null,
                                    tint = DeepGraphite
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "High Contrast Mode",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = DeepGraphite
                                        )
                                    )
                                    Text(
                                        text = "Enhance text contrast for accessibility",
                                        style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                                    )
                                }
                            }

                            Switch(
                                checked = isHighContrast,
                                onCheckedChange = { isHighContrast = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = PaperWhite, checkedTrackColor = DeepGraphite)
                            )
                        }

                        HorizontalDivider(
                            color = SteelBorderDark.copy(alpha = 0.15f),
                            modifier = Modifier.padding(vertical = 12.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Reduced Motion",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = DeepGraphite
                                    )
                                )
                                Text(
                                    text = "Disable ticket slide animations",
                                    style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                                )
                            }

                            Switch(
                                checked = isReducedMotion,
                                onCheckedChange = { isReducedMotion = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = PaperWhite, checkedTrackColor = DeepGraphite)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "INFORMATION & LEGAL",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.5.sp,
                        color = DeepGraphite
                    ),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                MoreRowItem(
                    title = "Help & Support",
                    subtitle = "Frequently asked questions & ticket assistance",
                    icon = Icons.Default.Help,
                    onClick = { },
                    testTag = "more_option_help"
                )

                MoreRowItem(
                    title = "Terms & Conditions",
                    subtitle = "Conditions of carriage and ticketing policy",
                    icon = Icons.Default.Policy,
                    onClick = { },
                    testTag = "more_option_terms"
                )

                MoreRowItem(
                    title = "About Supertram Sheffield",
                    subtitle = "Civic public transport infrastructure • Version 1.0",
                    icon = Icons.Default.Info,
                    onClick = { },
                    testTag = "more_option_about"
                )

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun MoreRowItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .border(1.dp, SteelBorderDark.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .testTag(testTag)
            .semantics { contentDescription = title },
        shape = RoundedCornerShape(8.dp),
        color = PaperWhite
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = DeepGraphite,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = DeepGraphite
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                )
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = SteelGreyLight
            )
        }
    }
}
