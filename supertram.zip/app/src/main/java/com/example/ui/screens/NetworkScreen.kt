package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Subway
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SupertramRoute
import com.example.ui.components.SupertramHeader
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.SteelBorderDark
import com.example.ui.theme.SteelGreyLight

@Composable
fun NetworkScreen() {
    var expandedRoute by remember { mutableStateOf<SupertramRoute?>(SupertramRoute.BLUE) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperWhite)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            SupertramHeader(title = "NETWORK", subtitle = "ROUTES & LINES")

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp)
            ) {
                item {
                    Text(
                        text = "SHEFFIELD SUPERTRAM LINES",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.5.sp,
                            color = DeepGraphite
                        ),
                        modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
                    )
                }

                items(SupertramRoute.entries) { route ->
                    val isExpanded = expandedRoute == route

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .border(1.dp, SteelBorderDark.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .clickable {
                                expandedRoute = if (isExpanded) null else route
                            }
                            .testTag("network_route_${route.code}"),
                        shape = RoundedCornerShape(12.dp),
                        color = PaperWhite,
                        shadowElevation = 2.dp
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .background(route.color, CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = route.displayName.uppercase(),
                                            style = MaterialTheme.typography.titleLarge.copy(
                                                fontWeight = FontWeight.ExtraBold,
                                                color = DeepGraphite,
                                                letterSpacing = 1.2.sp
                                            )
                                        )
                                        Text(
                                            text = route.routeDescription,
                                            style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                                        )
                                    }
                                }

                                Icon(
                                    imageVector = if (isExpanded) Icons.Default.ExpandMore else Icons.Default.ChevronRight,
                                    contentDescription = null,
                                    tint = DeepGraphite
                                )
                            }

                            AnimatedVisibility(visible = isExpanded) {
                                Column(
                                    modifier = Modifier.padding(top = 16.dp)
                                ) {
                                    HorizontalDivider(color = SteelBorderDark.copy(alpha = 0.2f))
                                    Spacer(modifier = Modifier.height(12.dp))

                                    Text(
                                        text = "STOPS ON ROUTE",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = SteelGreyLight,
                                            letterSpacing = 1.0.sp
                                        )
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    route.stops.forEachIndexed { index, stopName ->
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(vertical = 4.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .background(route.color, CircleShape)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(
                                                text = stopName,
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontWeight = if (index == 0 || index == route.stops.lastIndex) FontWeight.Bold else FontWeight.Normal,
                                                    color = DeepGraphite
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}
