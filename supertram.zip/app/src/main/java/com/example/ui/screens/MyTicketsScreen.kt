package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Ticket
import com.example.data.model.TicketStatus
import com.example.ui.components.SupertramHeader
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.RouteBlue
import com.example.ui.theme.SheffieldRed
import com.example.ui.theme.SteelBorderDark
import com.example.ui.theme.SteelGreyLight
import com.example.ui.theme.SteelGreyMedium
import com.example.ui.theme.TicketValidGreen
import com.example.ui.theme.TicketValidGreenBg
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun MyTicketsScreen(
    tickets: List<Ticket>,
    activeCountdown: String?,
    onOpenTicket: (Ticket) -> Unit
) {
    val activeTickets = tickets.filter { it.status == TicketStatus.ACTIVE }
    val pastTickets = tickets.filter { it.status != TicketStatus.ACTIVE }

    val dateFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.UK).withZone(ZoneId.systemDefault())

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperWhite)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            SupertramHeader(title = "MY TICKETS", subtitle = "DIGITAL WALLET")

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp)
            ) {
                // ACTIVE TICKETS SECTION
                item {
                    Text(
                        text = "ACTIVE TICKETS",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.5.sp,
                            color = DeepGraphite
                        ),
                        modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
                    )

                    if (activeTickets.isEmpty()) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .border(1.dp, SteelBorderDark.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                            shape = RoundedCornerShape(8.dp),
                            color = PaperWhite
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ConfirmationNumber,
                                    contentDescription = null,
                                    tint = SteelGreyMedium,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No active tickets",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = DeepGraphite
                                    )
                                )
                                Text(
                                    text = "Purchased tickets will appear here ready to show.",
                                    style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                                )
                            }
                        }
                    }
                }

                items(activeTickets) { ticket ->
                    ActiveTicketCard(
                        ticket = ticket,
                        countdown = activeCountdown,
                        onOpen = { onOpenTicket(ticket) }
                    )
                }

                // PAST TICKETS SECTION
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "PAST TICKETS",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.5.sp,
                            color = DeepGraphite
                        ),
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    if (pastTickets.isEmpty()) {
                        Text(
                            text = "No past tickets recorded.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = SteelGreyLight),
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                }

                items(pastTickets) { ticket ->
                    PastTicketRow(
                        ticket = ticket,
                        dateStr = dateFormatter.format(ticket.purchaseTime),
                        onOpen = { onOpenTicket(ticket) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}

@Composable
private fun ActiveTicketCard(
    ticket: Ticket,
    countdown: String?,
    onOpen: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .border(2.dp, DeepGraphite, RoundedCornerShape(12.dp))
            .clickable { onOpen() }
            .testTag("active_ticket_wallet_card"),
        shape = RoundedCornerShape(12.dp),
        color = PaperWhite,
        shadowElevation = 4.dp
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SUPERTRAM • ${ticket.productName.uppercase()}",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = DeepGraphite
                    )
                )

                Box(
                    modifier = Modifier
                        .background(TicketValidGreenBg, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "VALID TODAY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TicketValidGreen
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "${ticket.origin.uppercase()} → ${ticket.destination.uppercase()}",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = DeepGraphite
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (countdown != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = SheffieldRed,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = countdown,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = SheffieldRed
                            )
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                Button(
                    onClick = onOpen,
                    colors = ButtonDefaults.buttonColors(containerColor = DeepGraphite),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = null,
                        modifier = Modifier.padding(end = 6.dp)
                    )
                    Text(
                        text = "OPEN TICKET",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.0.sp
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun PastTicketRow(
    ticket: Ticket,
    dateStr: String,
    onOpen: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .border(1.dp, SteelBorderDark.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
            .clickable { onOpen() }
            .testTag("past_ticket_row_${ticket.id}"),
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFFFAF9F6)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "${ticket.origin} → ${ticket.destination}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SteelGreyMedium
                    )
                )
                Text(
                    text = "${ticket.productName} • $dateStr • £${ticket.price.toPlainString()}",
                    style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = ticket.status.name,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = SteelGreyLight
                    )
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = SteelGreyLight
                )
            }
        }
    }
}
