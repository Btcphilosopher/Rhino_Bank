package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Station
import com.example.data.model.Ticket
import com.example.ui.components.SupertramHeader
import com.example.ui.components.TramBackgroundPattern
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.RouteBlue
import com.example.ui.theme.SheffieldRed
import com.example.ui.theme.SteelBorderDark
import com.example.ui.theme.SteelGreyLight
import com.example.ui.theme.SteelGreyMedium

@Composable
fun HomeScreen(
    originStation: Station,
    destinationStation: Station,
    activeTicket: Ticket?,
    countdownTimer: String?,
    onOpenStationPicker: () -> Unit,
    onBuyClick: () -> Unit,
    onMyTicketsClick: () -> Unit,
    onOpenTicketDetail: (Ticket) -> Unit
) {
    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        TramBackgroundPattern()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            SupertramHeader()

            Spacer(modifier = Modifier.height(12.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
            ) {
                // Section 16: Active Ticket Banner
                if (activeTicket != null) {
                    AnimatedVisibility(
                        visible = true,
                        enter = fadeIn() + slideInVertically()
                    ) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 24.dp)
                                .border(2.dp, DeepGraphite, RoundedCornerShape(12.dp))
                                .testTag("active_ticket_home_banner"),
                            shape = RoundedCornerShape(12.dp),
                            color = PaperWhite,
                            shadowElevation = 6.dp
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "YOUR ACTIVE TICKET",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 1.5.sp,
                                            color = SheffieldRed
                                        )
                                    )
                                    if (countdownTimer != null) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Timer,
                                                contentDescription = null,
                                                tint = SheffieldRed,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = countdownTimer,
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = SheffieldRed
                                                )
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = "${activeTicket.origin.uppercase()} → ${activeTicket.destination.uppercase()}",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black,
                                        color = DeepGraphite
                                    )
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = { onOpenTicketDetail(activeTicket) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("open_active_ticket_button"),
                                    colors = ButtonDefaults.buttonColors(containerColor = DeepGraphite),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.QrCode,
                                        contentDescription = null,
                                        modifier = Modifier.padding(end = 8.dp)
                                    )
                                    Text(
                                        text = "OPEN TICKET",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 1.2.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // Poster-Style Journey Selector
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SteelBorderDark.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                    shape = RoundedCornerShape(12.dp),
                    color = PaperWhite,
                    shadowElevation = 2.dp
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Text(
                            text = "WHERE ARE YOU GOING?",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 2.0.sp,
                                color = DeepGraphite
                            )
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // From Origin Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenStationPicker() }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "FROM",
                                    style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                                )
                                Text(
                                    text = originStation.name,
                                    style = MaterialTheme.typography.displaySmall.copy(
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DeepGraphite
                                    )
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = "Change origin station",
                                tint = DeepGraphite,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        HorizontalDivider(
                            color = SteelBorderDark.copy(alpha = 0.2f),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        // To Destination Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenStationPicker() }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "TO",
                                    style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                                )
                                Text(
                                    text = destinationStation.name,
                                    style = MaterialTheme.typography.displaySmall.copy(
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DeepGraphite
                                    )
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = "Change destination station",
                                tint = DeepGraphite,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Dominant Primary Actions
                Button(
                    onClick = onBuyClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("buy_ticket_home_button")
                        .semantics { contentDescription = "Buy a tram ticket" },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepGraphite),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ShoppingCart,
                        contentDescription = null,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                    Text(
                        text = "BUY TICKET",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.0.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = onMyTicketsClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("my_tickets_home_button")
                        .semantics { contentDescription = "Open my tickets wallet" },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DeepGraphite)
                ) {
                    Icon(
                        imageVector = Icons.Default.ConfirmationNumber,
                        contentDescription = null,
                        modifier = Modifier.padding(end = 12.dp),
                        tint = DeepGraphite
                    )
                    Text(
                        text = "MY TICKETS",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            color = DeepGraphite
                        )
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}
