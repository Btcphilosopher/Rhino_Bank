package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Ticket
import com.example.data.model.TicketStatus
import com.example.qr.QrCodeGenerator
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.RouteBlue
import com.example.ui.theme.SheffieldRed
import com.example.ui.theme.SteelBorderDark
import com.example.ui.theme.SteelGreyLight
import com.example.ui.theme.SteelGreyMedium
import com.example.ui.theme.TicketValidGreen
import com.example.ui.theme.TicketValidGreenBg
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun PerforatedTicketCard(
    ticket: Ticket,
    remainingTimeString: String?,
    modifier: Modifier = Modifier,
    showQr: Boolean = true
) {
    val routeColor = remember(ticket.route) {
        when (ticket.route?.uppercase()) {
            "BLUE" -> RouteBlue
            "YELLOW" -> Color(0xFFC78900)
            "PURPLE" -> Color(0xFF6A2A80)
            "TRAM_TRAIN" -> Color(0xFFD9381E)
            else -> DeepGraphite
        }
    }

    val dateFormatter = remember {
        DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.UK).withZone(ZoneId.systemDefault())
    }
    val timeFormatter = remember {
        DateTimeFormatter.ofPattern("HH:mm", Locale.UK).withZone(ZoneId.systemDefault())
    }

    val dateStr = dateFormatter.format(ticket.validFrom)
    val timeStr = timeFormatter.format(ticket.purchaseTime)

    val qrBitmap = remember(ticket.qrPayload) {
        QrCodeGenerator.generateQrBitmap(ticket.qrPayload, 380, 380)
    }

    val isActive = ticket.status == TicketStatus.ACTIVE

    val accessibleDescription = "Sheffield Supertram ticket from ${ticket.origin} to ${ticket.destination}, ${ticket.productName}, price £${ticket.price.toPlainString()}, ticket ID ${ticket.id}"

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .border(1.dp, if (isActive) routeColor else SteelBorderDark, RoundedCornerShape(12.dp))
            .testTag("digital_ticket_card")
            .semantics { contentDescription = accessibleDescription },
        shape = RoundedCornerShape(12.dp),
        color = PaperWhite,
        shadowElevation = 4.dp
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Top route color header band with microtext
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp)
                    .background(routeColor)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SUPERTRAM • ${ticket.route ?: "SYSTEMWIDE"}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp,
                            color = PaperWhite
                        )
                    )
                    Text(
                        text = "ID: ${ticket.id}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            color = PaperWhite.copy(alpha = 0.85f)
                        )
                    )
                }
            }

            // Ticket Main Body
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Civic Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SUPERTRAM",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.0.sp,
                            color = DeepGraphite
                        )
                    )
                    Box(
                        modifier = Modifier
                            .background(
                                if (isActive) TicketValidGreenBg else Color(0xFFF0F1F3),
                                RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (isActive) "VALID TODAY" else ticket.status.name,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isActive) TicketValidGreen else SteelGreyMedium
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Station Journey Typography
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = ticket.origin.uppercase(),
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp,
                            color = DeepGraphite
                        ),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "to",
                        tint = routeColor,
                        modifier = Modifier.size(28.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = ticket.destination.uppercase(),
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp,
                            color = DeepGraphite
                        ),
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Product details row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PRODUCT",
                            style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                        )
                        Text(
                            text = ticket.productName.uppercase(),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = DeepGraphite
                            )
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "PRICE",
                            style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                        )
                        Text(
                            text = "£${ticket.price.toPlainString()}",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = DeepGraphite
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Date & Time row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ISSUED",
                            style = MaterialTheme.typography.labelSmall.copy(color = SteelGreyLight)
                        )
                        Text(
                            text = "$dateStr $timeStr",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                color = DeepGraphite
                            )
                        )
                    }

                    // Remaining time badge if applicable
                    if (remainingTimeString != null && isActive) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(Color(0xFFFEF2F2), RoundedCornerShape(4.dp))
                                .border(1.dp, SheffieldRed.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = SheffieldRed,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = remainingTimeString,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = SheffieldRed
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Ticket Perforation Divider Line
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(12.dp)
                ) {
                    val pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                    drawLine(
                        color = Color.LightGray,
                        start = Offset(0f, size.height / 2),
                        end = Offset(size.width, size.height / 2),
                        strokeWidth = 2f,
                        pathEffect = pathEffect
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // QR Code Area
                if (showQr) {
                    AnimatedVisibility(
                        visible = showQr,
                        enter = fadeIn()
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (qrBitmap != null) {
                                Box(
                                    modifier = Modifier
                                        .background(Color.White)
                                        .border(2.dp, DeepGraphite, RoundedCornerShape(8.dp))
                                        .padding(12.dp)
                                ) {
                                    Image(
                                        bitmap = qrBitmap,
                                        contentDescription = "Scannable ticket QR code for ticket ID ${ticket.id}",
                                        modifier = Modifier
                                            .size(180.dp)
                                            .testTag("qr_code_image")
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = Icons.Default.QrCode,
                                    contentDescription = "QR Code",
                                    modifier = Modifier.size(160.dp),
                                    tint = DeepGraphite
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Ticket ID: ${ticket.id}",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 1.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DeepGraphite
                                )
                            )

                            Text(
                                text = "SCAN AT GATES OR PRESENT TO CONDUCTOR",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    color = SteelGreyLight,
                                    letterSpacing = 0.8.sp
                                ),
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }

            // Bottom microtext footer
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF4F3EF))
                    .padding(vertical = 6.dp, horizontal = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "SHEFFIELD SUPERTRAM • CIVIC INFRASTRUCTURE • DEMO TICKET",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 8.sp,
                        color = SteelGreyMedium,
                        letterSpacing = 0.8.sp
                    )
                )
            }
        }
    }
}
