package com.example.payment

import com.example.data.model.FareProduct
import kotlinx.coroutines.delay
import java.util.UUID

class DemoPaymentProvider : PaymentProvider {
    override suspend fun purchase(product: FareProduct): PaymentResult {
        // Simulate realistic brief network confirmation pause
        delay(600)
        val mockTxId = "DEMO-TX-${UUID.randomUUID().toString().take(8).uppercase()}"
        return PaymentResult.Success(mockTxId)
    }
}
