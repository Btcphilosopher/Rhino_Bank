package com.example.payment

import com.example.data.model.FareProduct

sealed class PaymentResult {
    data class Success(val transactionId: String) : PaymentResult()
    data class Error(val message: String) : PaymentResult()
}

interface PaymentProvider {
    suspend fun purchase(product: FareProduct): PaymentResult
}
