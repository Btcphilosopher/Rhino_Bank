package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.BottomNavBar
import com.example.ui.components.NavItem
import com.example.ui.screens.BuyTicketScreen
import com.example.ui.screens.FirstRunScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.JourneysScreen
import com.example.ui.screens.MoreScreen
import com.example.ui.screens.MyTicketsScreen
import com.example.ui.screens.NetworkScreen
import com.example.ui.screens.PaymentScreen
import com.example.ui.screens.StationSelectorModal
import com.example.ui.screens.TicketDetailsScreen
import com.example.ui.theme.SupertramTheme
import com.example.ui.viewmodel.PaymentUiState
import com.example.ui.viewmodel.StationTarget
import com.example.ui.viewmodel.SupertramViewModel

enum class SubScreen {
    MAIN,
    PAYMENT,
    NETWORK,
    JOURNEYS
}

class MainActivity : ComponentActivity() {

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SupertramTheme {
                val viewModel: SupertramViewModel = viewModel()

                val currentNavItem by viewModel.currentNavItem.collectAsStateWithLifecycle()
                val origin by viewModel.selectedOrigin.collectAsStateWithLifecycle()
                val destination by viewModel.selectedDestination.collectAsStateWithLifecycle()
                val isStationPickerOpen by viewModel.isStationPickerOpen.collectAsStateWithLifecycle()
                val stationPickerTarget by viewModel.stationPickerTarget.collectAsStateWithLifecycle()
                val stationSearchQuery by viewModel.stationSearchQuery.collectAsStateWithLifecycle()
                val allStations by viewModel.stations.collectAsStateWithLifecycle()
                val fareProducts by viewModel.fareProducts.collectAsStateWithLifecycle()
                val selectedProduct by viewModel.selectedFareProduct.collectAsStateWithLifecycle()
                val allTickets by viewModel.allTickets.collectAsStateWithLifecycle()
                val activeTicket by viewModel.activeTicket.collectAsStateWithLifecycle()
                val selectedTicketDetail by viewModel.selectedTicketDetail.collectAsStateWithLifecycle()
                val countdownTimer by viewModel.countdownString.collectAsStateWithLifecycle()
                val paymentState by viewModel.paymentState.collectAsStateWithLifecycle()
                val isFirstRun by viewModel.isFirstRun.collectAsStateWithLifecycle()
                val journeyHistory by viewModel.journeyHistory.collectAsStateWithLifecycle()

                var subScreen by remember { mutableStateOf(SubScreen.MAIN) }

                val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

                if (isFirstRun) {
                    FirstRunScreen(
                        onGetStarted = { viewModel.completeFirstRun() },
                        onChooseStartStation = {
                            viewModel.completeFirstRun()
                            viewModel.openStationPicker(StationTarget.ORIGIN)
                        }
                    )
                } else {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        bottomBar = {
                            if (subScreen == SubScreen.MAIN && selectedTicketDetail == null) {
                                BottomNavBar(
                                    selectedItem = currentNavItem,
                                    onItemSelected = { item ->
                                        viewModel.navigateTo(item)
                                    }
                                )
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            if (subScreen == SubScreen.PAYMENT && selectedProduct != null) {
                                PaymentScreen(
                                    origin = origin,
                                    destination = destination,
                                    product = selectedProduct!!,
                                    paymentState = paymentState,
                                    onBackClick = {
                                        subScreen = SubScreen.MAIN
                                        viewModel.resetPaymentState()
                                    },
                                    onPayClick = {
                                        viewModel.processPayment()
                                    }
                                )
                            } else {
                                AnimatedContent(
                                    targetState = currentNavItem,
                                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                                    label = "screen_transition"
                                ) { navItem ->
                                    when (navItem) {
                                        NavItem.HOME -> HomeScreen(
                                            originStation = origin,
                                            destinationStation = destination,
                                            activeTicket = activeTicket,
                                            countdownTimer = countdownTimer,
                                            onOpenStationPicker = { viewModel.openStationPicker(StationTarget.ORIGIN) },
                                            onBuyClick = { viewModel.navigateTo(NavItem.BUY) },
                                            onMyTicketsClick = { viewModel.navigateTo(NavItem.TICKETS) },
                                            onOpenTicketDetail = { ticket -> viewModel.openTicketDetail(ticket) }
                                        )
                                        NavItem.BUY -> BuyTicketScreen(
                                            origin = origin,
                                            destination = destination,
                                            fareProducts = fareProducts,
                                            selectedProduct = selectedProduct,
                                            onOpenOriginPicker = { viewModel.openStationPicker(StationTarget.ORIGIN) },
                                            onOpenDestinationPicker = { viewModel.openStationPicker(StationTarget.DESTINATION) },
                                            onSwap = { viewModel.swapStations() },
                                            onSelectProduct = { product -> viewModel.selectFareProduct(product) },
                                            onProceedToPayment = { subScreen = SubScreen.PAYMENT }
                                        )
                                        NavItem.TICKETS -> MyTicketsScreen(
                                            tickets = allTickets,
                                            activeCountdown = countdownTimer,
                                            onOpenTicket = { ticket -> viewModel.openTicketDetail(ticket) }
                                        )
                                        NavItem.MORE -> {
                                            when (subScreen) {
                                                SubScreen.NETWORK -> NetworkScreen()
                                                SubScreen.JOURNEYS -> JourneysScreen(journeys = journeyHistory)
                                                else -> MoreScreen(
                                                    onOpenNetwork = { subScreen = SubScreen.NETWORK },
                                                    onOpenJourneys = { subScreen = SubScreen.JOURNEYS },
                                                    onOpenStationPicker = { viewModel.openStationPicker(StationTarget.ORIGIN) },
                                                    usualStationName = origin.name
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Digital Ticket Details overlay when a ticket is opened or newly created
                            if (selectedTicketDetail != null) {
                                TicketDetailsScreen(
                                    ticket = selectedTicketDetail!!,
                                    countdownTimer = if (selectedTicketDetail?.id == activeTicket?.id) countdownTimer else null,
                                    onClose = {
                                        viewModel.closeTicketDetail()
                                        subScreen = SubScreen.MAIN
                                        viewModel.resetPaymentState()
                                    }
                                )
                            }
                        }
                    }

                    // Station Picker Bottom Sheet
                    StationSelectorModal(
                        isOpen = isStationPickerOpen,
                        onDismiss = { viewModel.closeStationPicker() },
                        sheetState = sheetState,
                        targetTitle = if (stationPickerTarget == StationTarget.ORIGIN) "ORIGIN" else "DESTINATION",
                        searchQuery = stationSearchQuery,
                        onQueryChange = { viewModel.updateStationSearchQuery(it) },
                        allStations = allStations,
                        recentStations = allStations.take(3),
                        popularStations = allStations.filter { it.isPopular },
                        onSelectStation = { station -> viewModel.selectStation(station) }
                    )
                }
            }
        }
    }
}
