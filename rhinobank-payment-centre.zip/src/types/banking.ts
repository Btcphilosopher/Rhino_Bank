export type Currency = 'GBP' | 'USD' | 'EUR' | 'CHF' | 'JPY';

export type PaymentStatus = 
  | 'Completed'
  | 'Processing'
  | 'Pending Approval'
  | 'Risk Checked'
  | 'Held'
  | 'Failed'
  | 'Refunded';

export type PaymentDirection = 'Incoming' | 'Outgoing';

export type PaymentPriority = 'Instant Faster Payments' | 'CHAPS High Value' | 'SWIFT' | 'SEPA Enterprise';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface PaymentTimelineStep {
  title: string;
  status: 'completed' | 'in_progress' | 'pending' | 'failed';
  timestamp?: string;
  description?: string;
}

export interface Payment {
  id: string; // e.g. RHN_8F42901A
  amount: number;
  currency: Currency;
  direction: PaymentDirection;
  counterparty: string;
  counterpartyBank: string;
  counterpartyAccount?: string;
  counterpartySortCode?: string;
  counterpartyIban?: string;
  fromAccount: string;
  toAccount: string;
  reference: string;
  createdDate: string; // e.g. "23 Aug 2026, 14:42"
  settlementDate: string;
  status: PaymentStatus;
  fee: number;
  fxRate?: number;
  priority: PaymentPriority;
  bankReference: string;
  riskScore: number; // 0-100
  riskStatus: RiskLevel;
  reconciliationStatus: 'Matched' | 'Unmatched' | 'Pending' | 'Exception';
  approvalsRequired: number;
  approvalsCompleted: number;
  approvedBy?: string[];
  notes?: string;
  timeline: PaymentTimelineStep[];
  isSandbox?: boolean;
}

export interface BankAccount {
  id: string;
  name: string;
  accountNumber: string;
  sortCode: string;
  iban: string;
  currency: Currency;
  type: 'Operating' | 'Treasury Reserve' | 'Client Money' | 'FX Settlement' | 'Collateral';
  openingBalance: number;
  credits: number;
  debits: number;
  adjustments: number;
  closingBalance: number; // computed: opening + credits - debits + adjustments
  availableBalance: number;
  pendingBalance: number;
  reservedBalance: number;
  dailyLimit: number;
  perTransactionLimit: number;
}

export interface LedgerEntry {
  id: string;
  date: string;
  description: string;
  counterparty: string;
  reference: string;
  amount: number;
  currency: Currency;
  type: 'Credit' | 'Debit' | 'Adjustment';
  accountName: string;
  accountId: string;
  status: 'Completed' | 'Pending' | 'Reconciled';
  runningBalance: number;
}

export interface Customer {
  id: string;
  name: string;
  legalName: string;
  registrationNumber: string;
  jurisdiction: string;
  industry: string;
  tier: 'Tier 1 Global' | 'Enterprise' | 'Corporate' | 'Institutional Prime';
  totalBalance: number;
  currency: Currency;
  payments30DaysVolume: number;
  latestPaymentAmount: number;
  latestPaymentDate: string;
  kycStatus: 'Verified' | 'Under Review' | 'Tier 2 Complete';
  amlStatus: 'Clear' | 'Enhanced Due Diligence' | 'Flagged';
  riskScore: 'Low' | 'Medium' | 'High';
  paymentDailyLimit: number;
  relationshipManager: string;
  contactEmail: string;
  contactPhone: string;
  beneficialOwners: string[];
  accountsCount: number;
  activeInvoicesCount: number;
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  vatRate: number; // e.g. 0.20
  amount: number;
}

export interface Invoice {
  id: string; // RH-2026-1842
  customerName: string;
  customerId: string;
  customerEmail: string;
  issueDate: string;
  dueDate: string;
  currency: Currency;
  subtotal: number;
  vat: number;
  total: number;
  status: 'Paid' | 'Pending' | 'Overdue' | 'Draft' | 'Cancelled';
  items: InvoiceItem[];
  paymentReference: string;
  paidAt?: string;
  notes?: string;
}

export interface PaymentLink {
  id: string;
  slug: string;
  url: string;
  title: string;
  description: string;
  amount: number;
  currency: Currency;
  customerName?: string;
  reference: string;
  createdDate: string;
  expiryDate: string;
  status: 'Active' | 'Expired' | 'Completed';
  clicks: number;
  paymentAttempts: number;
  successfulPayments: number;
  revenue: number;
}

export interface RecurringPayment {
  id: string;
  customerName: string;
  description: string;
  amount: number;
  currency: Currency;
  frequency: 'Weekly' | 'Monthly' | 'Quarterly' | 'Annual';
  nextBillingDate: string;
  status: 'Active' | 'Paused' | 'Cancelled';
  totalCyclesCompleted: number;
  mandateReference: string;
  paymentMethod: 'Direct Debit Bacs' | 'SEPA Direct' | 'Card on File';
}

export interface Refund {
  id: string; // RFN-9482
  originalPaymentId: string;
  counterparty: string;
  amount: number;
  currency: Currency;
  reason: 'Duplicate payment' | 'Customer request' | 'Fraud suspected' | 'Goods/Services cancellation' | 'Administrative correction';
  status: 'Completed' | 'Pending Authorisation' | 'Rejected';
  requestedBy: string;
  authorisedBy?: string;
  createdAt: string;
  originalAmount: number;
  type: 'Full Refund' | 'Partial Refund';
}

export interface ApprovalRequest {
  id: string;
  paymentId: string;
  counterparty: string;
  amount: number;
  currency: Currency;
  approvalsRequired: number;
  approvalsCompleted: number;
  requestedBy: string;
  riskStatus: RiskLevel;
  riskScore: number;
  purpose: string;
  createdAt: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  category: 'High Value' | 'Cross Border' | 'New Beneficiary' | 'Executive Override';
  approvers: { name: string; role: string; timestamp?: string; status: 'Approved' | 'Pending' | 'Rejected' }[];
}

export interface FXRate {
  pair: string; // e.g. GBP/USD
  rate: number;
  change24h: number;
  bid: number;
  ask: number;
  high: number;
  low: number;
}

export interface FXTrade {
  id: string;
  sellCurrency: Currency;
  sellAmount: number;
  buyCurrency: Currency;
  buyAmount: number;
  rate: number;
  fee: number;
  type: 'Spot' | 'Forward' | 'Hedge';
  settlementDate: string;
  executedBy: string;
  status: 'Settled' | 'Processing';
  timestamp: string;
}

export interface RiskAlert {
  id: string;
  paymentId: string;
  counterparty: string;
  amount: number;
  currency: Currency;
  severity: RiskLevel;
  score: number;
  flagReasons: string[]; // e.g. ["Unusual velocity", "New beneficiary in high risk jurisdiction", "Device anomaly"]
  status: 'Open' | 'Investigating' | 'Released' | 'Blocked' | 'Held';
  createdAt: string;
  actionNotes?: string;
}

export interface ReconciliationException {
  id: string;
  amount: number;
  currency: Currency;
  reason: 'Invoice mismatch' | 'Duplicate reference' | 'Missing settlement' | 'Unmatched bank transaction' | 'Timing difference';
  counterparty: string;
  reference: string;
  date: string;
  status: 'Unresolved' | 'Investigating' | 'Matched' | 'Ignored' | 'Resolved';
  systemRecord?: string;
  bankRecord?: string;
}

export interface ApiKeyItem {
  id: string;
  name: string;
  keyPrefix: string;
  keyMasked: string;
  environment: 'Production' | 'Sandbox';
  created: string;
  lastUsed: string;
  scopes: string[];
  status: 'Active' | 'Revoked';
}

export interface ApiLog {
  id: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  endpoint: string;
  status: number;
  durationMs: number;
  ip: string;
  timestamp: string;
  requestId: string;
  customer?: string;
  apiKeyPrefix: string;
}

export interface WebhookEvent {
  id: string;
  event: 'payment.created' | 'payment.completed' | 'payment.failed' | 'payment.refunded' | 'invoice.created' | 'invoice.paid' | 'account.updated' | 'settlement.completed';
  timestamp: string;
  status: 'Delivered' | 'Failed' | 'Pending';
  attempts: number;
  endpointUrl: string;
  payload: Record<string, any>;
}

export interface AuditLog {
  id: string;
  user: string;
  action: string;
  timestamp: string;
  objectType: string;
  objectId: string;
  previousState?: string;
  newState?: string;
  ipAddress: string;
  authorisationMethod: string;
}

export type UserRole = 
  | 'Administrator'
  | 'Treasurer'
  | 'Finance Manager'
  | 'Payments Operator'
  | 'Risk Officer'
  | 'Compliance Officer'
  | 'Developer'
  | 'Auditor'
  | 'Read Only';

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
  lastLogin: string;
  mfaEnabled: boolean;
  avatarInitials: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timeAgo: string;
  type: 'payment' | 'approval' | 'liquidity' | 'risk' | 'settlement' | 'api';
  read: boolean;
  actionUrl?: string;
}
