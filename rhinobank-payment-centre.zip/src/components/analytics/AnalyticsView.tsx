import React from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Activity, 
  Zap, 
  PieChart as PieChartIcon
} from 'lucide-react';

export const AnalyticsView: React.FC = () => {
  const funnelStages = [
    { name: '1. Initiated', count: '12,842', pct: '100%', drop: '0.0%', desc: 'API / Portal payment intent generated' },
    { name: '2. Authenticated', count: '12,810', pct: '99.7%', drop: '-0.3%', desc: 'MFA & Cryptographic key valid' },
    { name: '3. Risk Approved', count: '12,785', pct: '99.5%', drop: '-0.2%', desc: 'AML / Sanctions rules clear' },
    { name: '4. Dispatched to Rail', count: '12,780', pct: '99.5%', drop: '0.0%', desc: 'FPS / CHAPS / SWIFT routing' },
    { name: '5. Clearing Accepted', count: '12,772', pct: '99.45%', drop: '-0.05%', desc: 'Bank of England RTGS confirmation' },
    { name: '6. Settled Finality', count: '12,768', pct: '99.42%', drop: '-0.03%', desc: 'Irrevocable beneficiary credit' },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Payments & Settlement Analytics</h1>
        <p className="text-xs text-slate-500 font-mono">
          Throughput telemetry · Irrevocable finality conversion funnel & latency distributions
        </p>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Success Rate</span>
          <div className="text-2xl font-bold font-mono text-emerald-700">99.42%</div>
          <span className="text-[11px] font-mono text-emerald-600 flex items-center gap-1 font-medium">
            <ArrowUpRight className="w-3 h-3" /> +0.8% vs last week
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Avg Clearing Duration</span>
          <div className="text-2xl font-bold font-mono text-slate-900">12.7s</div>
          <span className="text-[11px] font-mono text-slate-500">FPS instant rails</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Total 30D Gross Volume</span>
          <div className="text-2xl font-bold font-mono text-slate-900">£482.4m</div>
          <span className="text-[11px] font-mono text-emerald-600 flex items-center gap-1 font-medium">
            <ArrowUpRight className="w-3 h-3" /> +14.2% YoY
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Net Fee Yield</span>
          <div className="text-2xl font-bold font-mono text-blue-700">1.8 bps</div>
          <span className="text-[11px] font-mono text-slate-500">Institutional wholesale rate</span>
        </div>
      </div>

      {/* 6-Stage Payment Funnel */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-2xs space-y-4">
        <div>
          <h3 className="font-bold text-slate-900 text-sm">Institutional Payment Execution Funnel</h3>
          <p className="text-[11px] text-slate-500 font-mono">Conversion rate from payment creation to irrevocable settlement</p>
        </div>

        <div className="space-y-3 pt-2">
          {funnelStages.map((stage, idx) => {
            const widthPct = parseFloat(stage.pct);
            return (
              <div key={idx} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-mono">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{stage.name}</span>
                    <span className="text-[10px] text-slate-400 font-sans">{stage.desc}</span>
                  </div>
                  <div className="flex items-center gap-3 font-semibold">
                    <span className="text-slate-800">{stage.count}</span>
                    <span className="text-emerald-700">{stage.pct}</span>
                    {stage.drop !== '0.0%' && <span className="text-rose-600 text-[10px]">{stage.drop}</span>}
                  </div>
                </div>

                <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-amber-400 to-amber-500 rounded-full transition-all duration-500"
                    style={{ width: `${widthPct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
