import React from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  FileSpreadsheet, 
  Download, 
  FileText, 
  Calendar, 
  CheckCircle2, 
  ExternalLink,
  ShieldCheck
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const reportsList = [
    { title: 'Daily Payment & Clearing Summary', code: 'REP-PAY-01', period: 'Daily (T-1)', format: 'PDF / CSV', size: '2.4 MB', desc: 'Itemized summary of all incoming & outgoing clearing volumes.' },
    { title: 'PRA Regulatory Liquidity Report (LCR)', code: 'REP-LIQ-04', period: 'Intraday', format: 'XBRL / CSV', size: '1.1 MB', desc: 'Prudential Regulation Authority buffer calculation & high quality liquid assets.' },
    { title: 'Gross Settlement & Bank of England RTGS Reconciliation', code: 'REP-RTGS-09', period: 'Daily', format: 'PDF / CSV', size: '4.8 MB', desc: 'Matched CHAPS and FPS settlement journals against BoE reserves.' },
    { title: 'Foreign Exchange & Nostro Exposure Ledger', code: 'REP-FX-12', period: 'Weekly', format: 'CSV', size: '890 KB', desc: 'Multi-currency positions, open hedges and counterparty credit exposures.' },
    { title: 'Anti-Money Laundering & Sanctions Audit File', code: 'REP-AML-03', period: 'Monthly', format: 'PDF / JSON', size: '14.2 MB', desc: 'Comprehensive log of all high-risk triggers, releases, and SAR submissions.' },
  ];

  const handleDownload = (title: string) => {
    alert(`Downloading ${title}...`);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Institutional Financial Reports</h1>
        <p className="text-xs text-slate-500 font-mono">
          Regulatory compliance packages · BoE, FCA, and internal treasury audit archives
        </p>
      </div>

      {/* Reports Directory */}
      <div className="space-y-3">
        {reportsList.map((rep, idx) => (
          <div key={idx} className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-amber-400 transition-all">
            <div className="flex items-start gap-3.5">
              <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-800 flex items-center justify-center shrink-0">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-slate-900 text-sm">{rep.title}</h3>
                  <span className="px-2 py-0.5 bg-slate-100 text-slate-600 font-mono text-[10px] rounded font-semibold">
                    {rep.code}
                  </span>
                </div>
                <p className="text-slate-500 text-xs">{rep.desc}</p>
                <div className="flex items-center gap-3 text-[11px] font-mono text-slate-400 pt-1">
                  <span>Frequency: {rep.period}</span>
                  <span>·</span>
                  <span>Formats: {rep.format}</span>
                  <span>·</span>
                  <span>Size: {rep.size}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => handleDownload(rep.title)}
                className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-mono text-xs font-semibold rounded-md shadow-xs transition-colors flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-amber-400" />
                Download Report
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
