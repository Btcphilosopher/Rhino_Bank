import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  Users, 
  ShieldCheck, 
  Lock, 
  Key, 
  Clock, 
  CheckCircle2, 
  AlertCircle
} from 'lucide-react';

export const AdminView: React.FC = () => {
  const { auditLogs, currentUser, switchRole } = useBanking();
  const [activeTab, setActiveTab] = useState<'Audit Trail' | 'Team & Roles' | 'RBAC Matrix'>('Audit Trail');

  const teamMembers = [
    { name: 'Thomas Lawson', email: 't.lawson@rhinobank.com', role: 'Treasury Manager', status: 'Active', mfa: 'Hardware YubiKey' },
    { name: 'Sarah Jenkins', email: 's.jenkins@rhinobank.com', role: 'Head of Prime Banking', status: 'Active', mfa: 'FIDO2 Biometric' },
    { name: 'Alex Mercer', email: 'a.mercer@rhinobank.com', role: 'Senior Payments Operator', status: 'Active', mfa: 'Authenticator TOTP' },
    { name: 'Marcus Vance', email: 'm.vance@rhinobank.com', role: 'Chief Risk Officer', status: 'Active', mfa: 'Hardware Token' },
    { name: 'Elena Rostova', email: 'e.rostova@rhinobank.com', role: 'Lead Integration Engineer', status: 'Active', mfa: 'FIDO2 Key' },
  ];

  const rbacMatrix = [
    { permission: 'Initiate Clearing Payments (<£100k)', roles: ['Administrator', 'Treasurer', 'Finance Manager', 'Payments Operator'] },
    { permission: 'Approve High-Value Payments (≥£100k)', roles: ['Administrator', 'Treasurer', 'Chief Risk Officer'] },
    { permission: 'Execute FX Dealing & Hedging', roles: ['Administrator', 'Treasurer'] },
    { permission: 'Issue Payment Reversals & Refunds', roles: ['Administrator', 'Treasurer', 'Finance Manager'] },
    { permission: 'Access Developer REST & Webhook Keys', roles: ['Administrator', 'Developer'] },
    { permission: 'Override AML / Sanctions Risk Holds', roles: ['Administrator', 'Risk Officer', 'Compliance Officer'] },
    { permission: 'Export Regulatory PRA / BoE Reports', roles: ['Administrator', 'Treasurer', 'Auditor'] },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Governance, Security & Audit Log</h1>
          <p className="text-xs text-slate-500 font-mono">
            Role-based access control · Cryptographically immutable compliance activity log
          </p>
        </div>

        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
          {(['Audit Trail', 'Team & Roles', 'RBAC Matrix'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3 py-1 text-xs font-mono font-medium rounded-md transition-all ${
                activeTab === tab ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Audit Trail View */}
      {activeTab === 'Audit Trail' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <span className="font-mono text-xs font-bold text-slate-700 uppercase">
              Immutable System Events (Total: {auditLogs.length})
            </span>
            <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              SHA-256 Merkle Tree Verified
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="bg-slate-50/50 border-b border-slate-200 text-slate-500 text-[10px] uppercase">
                  <th className="py-3 px-4">Event ID / Time</th>
                  <th className="py-3 px-4">Acting Officer</th>
                  <th className="py-3 px-4">Action Performed</th>
                  <th className="py-3 px-4">Target Object / Ref</th>
                  <th className="py-3 px-4">IP Address</th>
                  <th className="py-3 px-4 text-center">Auth Method</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{log.id}</div>
                      <div className="text-[10px] text-slate-400">{log.timestamp}</div>
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-800">
                      {log.user}
                    </td>
                    <td className="py-3 px-4 text-slate-900 font-medium">
                      {log.action}
                    </td>
                    <td className="py-3 px-4 text-amber-700">
                      {log.objectType}: {log.objectId}
                    </td>
                    <td className="py-3 px-4 text-slate-500 text-[11px]">
                      {log.ipAddress}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                        {log.authorisationMethod}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Team & Roles View */}
      {activeTab === 'Team & Roles' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden divide-y divide-slate-100 text-xs">
          {teamMembers.map((member, idx) => (
            <div key={idx} className="p-4 flex items-center justify-between hover:bg-slate-50">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-slate-900 text-amber-400 font-mono font-bold flex items-center justify-center">
                  {member.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <div className="font-bold text-slate-900 text-sm">{member.name}</div>
                  <div className="text-slate-500 font-mono text-[11px]">{member.email} · {member.role}</div>
                </div>
              </div>

              <div className="flex items-center gap-4 text-right">
                <div className="font-mono text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {member.mfa}
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-slate-100 text-slate-700">
                  {member.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* RBAC Matrix View */}
      {activeTab === 'RBAC Matrix' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200">
            <h3 className="font-bold text-slate-900 text-xs font-mono uppercase">Fine-Grained Permission Matrix</h3>
          </div>
          <div className="divide-y divide-slate-100 text-xs font-mono">
            {rbacMatrix.map((item, idx) => (
              <div key={idx} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <span className="font-semibold text-slate-900">{item.permission}</span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {item.roles.map(r => (
                    <span key={r} className="px-2 py-0.5 bg-amber-50 text-amber-900 border border-amber-200 rounded text-[10px] font-bold">
                      {r}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
