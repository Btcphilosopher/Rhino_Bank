import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { RiskAlert } from '../../types/banking';

export const RiskDashboardView: React.FC = () => {
  const { riskAlerts, resolveRiskAlert, payments, setSelectedPayment } = useBanking();
  const [filterSeverity, setFilterSeverity] = useState('ALL');

  const filteredAlerts = riskAlerts.filter(a => filterSeverity === 'ALL' || a.severity === filterSeverity);

  const handleAction = (alertId: string, action: 'release' | 'hold' | 'block') => {
    resolveRiskAlert(alertId, action, `Officer manual review - marked ${action}`);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Payment Risk & AML Fraud Monitor</h1>
        <p className="text-xs text-slate-500 font-mono">
          Sub-50ms behavioral scoring · Real-time OFAC / UK Treasury sanctions filtering & velocity detection
        </p>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Transactions Monitored (24h)</span>
          <div className="text-2xl font-bold font-mono text-slate-900">12,842</div>
          <span className="text-[11px] font-mono text-emerald-600 font-medium">99.8% auto-cleared</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Active High Risk Alerts</span>
          <div className="text-2xl font-bold font-mono text-rose-700">4</div>
          <span className="text-[11px] font-mono text-rose-600 font-medium">Requires officer review</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Irrevocably Blocked</span>
          <div className="text-2xl font-bold font-mono text-slate-900">2</div>
          <span className="text-[11px] font-mono text-slate-400">OFAC / Sanctions matches</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">False Positive Rate</span>
          <div className="text-2xl font-bold font-mono text-emerald-700">0.04%</div>
          <span className="text-[11px] font-mono text-slate-400">Machine learning calibration</span>
        </div>
      </div>

      {/* Alerts Table */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-sm text-slate-900">Active Risk Cases & Behavioral Triggers</h2>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-slate-400">Severity:</span>
            <select
              value={filterSeverity}
              onChange={(e) => setFilterSeverity(e.target.value)}
              className="px-2.5 py-1 border border-slate-200 rounded-lg text-xs font-mono bg-white text-slate-700"
            >
              <option value="ALL">All Severities</option>
              <option value="CRITICAL">Critical</option>
              <option value="HIGH">High</option>
              <option value="MEDIUM">Medium</option>
              <option value="LOW">Low</option>
            </select>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-mono text-[11px] uppercase tracking-wider">
                  <th className="py-3 px-4 font-semibold">Alert ID / Time</th>
                  <th className="py-3 px-4 font-semibold">Payment / Entity</th>
                  <th className="py-3 px-4 font-semibold">Risk Reason & Rule Trigger</th>
                  <th className="py-3 px-4 font-semibold text-center">Score</th>
                  <th className="py-3 px-4 font-semibold text-center">Severity</th>
                  <th className="py-3 px-4 font-semibold text-center">Status</th>
                  <th className="py-3 px-4 font-semibold text-center">Officer Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAlerts.map((alert) => {
                  const p = payments.find(pay => pay.id === alert.paymentId);
                  return (
                    <tr key={alert.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-mono">
                        <div className="font-bold text-slate-900">{alert.id}</div>
                        <div className="text-[10px] text-slate-400">{alert.createdAt}</div>
                      </td>

                      <td className="py-3 px-4">
                        <button
                          onClick={() => p && setSelectedPayment(p)}
                          className="font-bold font-mono text-amber-600 hover:underline block text-left"
                        >
                          {alert.paymentId}
                        </button>
                        <div className="text-slate-800 font-medium text-xs">{alert.counterparty}</div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{alert.flagReasons[0] || 'Behavioral anomaly detected'}</div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          {alert.flagReasons.slice(1).join(', ') || 'High value out of pattern'}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-center font-mono font-bold text-xs">
                        <span className={`px-2 py-0.5 rounded ${alert.score >= 70 ? 'text-rose-700 bg-rose-50' : 'text-amber-700 bg-amber-50'}`}>
                          {alert.score}/100
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase ${
                          alert.severity === 'CRITICAL' ? 'bg-rose-100 text-rose-800 border border-rose-300' :
                          alert.severity === 'HIGH' ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                          'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}>
                          {alert.severity}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                          alert.status === 'Released' ? 'bg-emerald-50 text-emerald-700' :
                          alert.status === 'Blocked' ? 'bg-rose-100 text-rose-800' :
                          'bg-amber-100 text-amber-800'
                        }`}>
                          {alert.status}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5 font-mono text-[10px]">
                          {alert.status !== 'Released' && (
                            <button
                              onClick={() => handleAction(alert.id, 'release')}
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold transition-colors"
                            >
                              Release
                            </button>
                          )}
                          {alert.status !== 'Blocked' && (
                            <button
                              onClick={() => handleAction(alert.id, 'block')}
                              className="px-2 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded font-bold transition-colors"
                            >
                              Block
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
