import React from 'react';
import { useBanking } from '../../context/BankingContext';
import { X, CheckCircle2, Activity, Server, Shield, Zap, RefreshCw } from 'lucide-react';

export const SystemStatusModal: React.FC = () => {
  const { isSystemStatusOpen, setIsSystemStatusOpen } = useBanking();

  if (!isSystemStatusOpen) return null;

  const subsystems = [
    { name: 'Faster Payments Gateway (FPS)', status: 'Operational', latency: '18ms', uptime: '99.998%', desc: 'Direct BoE Real-time gross settlement interface' },
    { name: 'CHAPS High-Value RTGS Rail', status: 'Operational', latency: '24ms', uptime: '100.00%', desc: 'High-value same-day irrevocable clearing' },
    { name: 'SWIFT Alliance Gateway', status: 'Operational', latency: '65ms', uptime: '99.985%', desc: 'ISO 20022 message translation & sanctions check' },
    { name: 'SEPA Instant Credit Rail', status: 'Operational', latency: '32ms', uptime: '99.990%', desc: 'Pan-European EUR direct clearing' },
    { name: 'Double-Entry Core Ledger', status: 'Operational', latency: '4ms', uptime: '100.00%', desc: 'ACID-compliant institutional balance book' },
    { name: 'Real-Time FX Liquidity Engine', status: 'Operational', latency: '12ms', uptime: '99.994%', desc: 'Multi-bank streaming quotes & algorithmic hedging' },
    { name: 'AML / Fraud Scoring Neural Rulebase', status: 'Operational', latency: '41ms', uptime: '99.991%', desc: 'Sub-50ms behavioral & sanctions scanning' },
    { name: 'Developer REST & Webhooks Dispatcher', status: 'Operational', latency: '28ms', uptime: '99.989%', desc: 'TLS 1.3 signed event delivery' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-100">
      <div className="bg-white w-full max-w-xl rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <div>
              <h3 className="font-bold text-sm font-mono tracking-wide text-white">RHINOBANK INFRASTRUCTURE STATUS</h3>
              <p className="text-[11px] text-emerald-400 font-mono">ALL CORE BANKING ENGINES HEALTHY</p>
            </div>
          </div>
          <button
            onClick={() => setIsSystemStatusOpen(false)}
            className="p-1 text-slate-400 hover:text-white rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          <div className="grid grid-cols-3 gap-3 p-3 bg-slate-50 border border-slate-200 rounded-lg text-center font-mono">
            <div>
              <span className="text-[10px] text-slate-400 uppercase block">Global Latency</span>
              <span className="font-bold text-slate-900 text-sm">22ms avg</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase block">30-Day Uptime</span>
              <span className="font-bold text-emerald-700 text-sm">99.994%</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase block">Active Pods</span>
              <span className="font-bold text-slate-900 text-sm">12 Active (UK-LON)</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-[11px] font-mono font-bold uppercase text-slate-500">Subsystem Telemetry</div>
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden">
              {subsystems.map((sub, idx) => (
                <div key={idx} className="p-3 flex items-center justify-between hover:bg-slate-50">
                  <div className="space-y-0.5">
                    <div className="font-bold text-slate-900 flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>{sub.name}</span>
                    </div>
                    <div className="text-[10px] text-slate-500">{sub.desc}</div>
                  </div>

                  <div className="text-right font-mono">
                    <span className="text-emerald-700 font-semibold text-xs block">{sub.status}</span>
                    <span className="text-[10px] text-slate-400">{sub.latency} · {sub.uptime}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
          <span className="text-slate-500 font-mono text-[11px]">Heartbeat interval: 500ms</span>
          <button
            onClick={() => setIsSystemStatusOpen(false)}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-md font-mono text-xs"
          >
            Close Telemetry
          </button>
        </div>
      </div>
    </div>
  );
};
