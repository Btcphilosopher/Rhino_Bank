import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  X, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ShieldCheck, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Copy, 
  Check, 
  RotateCcw, 
  Download, 
  FileText, 
  Building2, 
  Lock, 
  ExternalLink,
  Scale
} from 'lucide-react';

export const PaymentDetailModal: React.FC = () => {
  const { selectedPayment, setSelectedPayment, processRefund, currentUser } = useBanking();
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [isRefundModalOpen, setIsRefundModalOpen] = useState(false);
  const [refundReason, setRefundReason] = useState<any>('Customer request');
  const [refundType, setRefundType] = useState<'Full Refund' | 'Partial Refund'>('Full Refund');
  const [partialAmount, setPartialAmount] = useState('');
  const [showJsonPayload, setShowJsonPayload] = useState(false);

  if (!selectedPayment) return null;

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleConfirmRefund = () => {
    const amountToRefund = refundType === 'Full Refund' ? selectedPayment.amount : parseFloat(partialAmount) || selectedPayment.amount;
    processRefund({
      paymentId: selectedPayment.id,
      amount: amountToRefund,
      reason: refundReason,
      type: refundType
    });
    setIsRefundModalOpen(false);
    setSelectedPayment(null);
  };

  const isOutgoing = selectedPayment.direction === 'Outgoing';

  const statusColors = {
    Completed: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    Processing: 'bg-amber-50 text-amber-700 border-amber-200',
    'Pending Approval': 'bg-amber-100 text-amber-800 border-amber-300',
    'Risk Checked': 'bg-blue-50 text-blue-700 border-blue-200',
    Held: 'bg-rose-50 text-rose-700 border-rose-200',
    Failed: 'bg-rose-100 text-rose-800 border-rose-300',
    Refunded: 'bg-purple-50 text-purple-700 border-purple-200'
  };

  const currencySymbol = {
    GBP: '£',
    USD: '$',
    EUR: '€',
    CHF: 'CHF ',
    JPY: '¥'
  }[selectedPayment.currency] || '£';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-2xl rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-6 bg-slate-900 text-white flex items-start justify-between relative">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
                {selectedPayment.priority}
              </span>
              <span className="text-xs text-slate-400 font-mono">·</span>
              <span className="text-xs text-slate-300 font-mono flex items-center gap-1">
                ID: {selectedPayment.id}
                <button
                  onClick={() => handleCopy(selectedPayment.id, 'id')}
                  className="p-1 text-slate-400 hover:text-white rounded"
                  title="Copy ID"
                >
                  {copiedField === 'id' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                </button>
              </span>
            </div>

            <div className="flex items-baseline gap-3 pt-1">
              <span className="text-3xl font-bold font-mono tracking-tight text-white tabular-nums">
                {isOutgoing ? '-' : '+'}{currencySymbol}{selectedPayment.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <span className={`px-2.5 py-0.5 text-xs font-mono font-bold uppercase rounded-full border ${statusColors[selectedPayment.status] || 'bg-slate-100 text-slate-700 border-slate-200'}`}>
                {selectedPayment.status}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {selectedPayment.createdDate} · Initiated via RhinoBank Gateway
            </p>
          </div>

          <button
            onClick={() => setSelectedPayment(null)}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* From / To Counterparty Grid */}
          <div className="grid grid-cols-2 gap-4 p-4 rounded-lg bg-slate-50 border border-slate-200/80">
            <div className="space-y-1">
              <div className="text-[10px] font-mono font-bold uppercase text-slate-400">From Account</div>
              <div className="font-bold text-slate-900 text-sm">{selectedPayment.fromAccount}</div>
              <div className="text-slate-500 font-mono text-[11px]">RhinoBank Master Clearing</div>
            </div>

            <div className="space-y-1 pl-4 border-l border-slate-200">
              <div className="text-[10px] font-mono font-bold uppercase text-slate-400">To Beneficiary</div>
              <div className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-slate-500" />
                {selectedPayment.counterparty}
              </div>
              <div className="text-slate-500 font-mono text-[11px]">
                {selectedPayment.counterpartyBank} · {selectedPayment.counterpartyAccount || 'Ref: ' + selectedPayment.reference}
              </div>
            </div>
          </div>

          {/* Payment Lifecycle Timeline */}
          <div>
            <div className="text-xs font-mono font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-amber-500" />
              Payment Execution Timeline
            </div>

            <div className="relative pl-6 space-y-4 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
              {selectedPayment.timeline.map((step, index) => {
                const isDone = step.status === 'completed';
                const isCurrent = step.status === 'in_progress';
                const isFail = step.status === 'failed';

                return (
                  <div key={index} className="relative flex items-start justify-between">
                    {/* Circle Node */}
                    <div 
                      className={`absolute -left-6 top-0.5 w-4 h-4 rounded-full flex items-center justify-center border-2 bg-white ${
                        isFail
                          ? 'border-rose-500 text-rose-500'
                          : isDone
                          ? 'border-emerald-500 bg-emerald-500 text-white'
                          : isCurrent
                          ? 'border-amber-500 bg-amber-100 text-amber-700 animate-pulse'
                          : 'border-slate-300 text-slate-300'
                      }`}
                    >
                      {isDone ? (
                        <Check className="w-2.5 h-2.5 stroke-[3]" />
                      ) : (
                        <span className="w-1.5 h-1.5 rounded-full bg-current" />
                      )}
                    </div>

                    <div className="space-y-0.5 pl-1">
                      <div className="font-semibold text-slate-900 text-xs flex items-center gap-2">
                        <span>{step.title}</span>
                        {step.timestamp && (
                          <span className="text-[10px] font-mono text-slate-400 font-normal">{step.timestamp}</span>
                        )}
                      </div>
                      {step.description && (
                        <div className="text-[11px] text-slate-500 leading-snug">{step.description}</div>
                      )}
                    </div>

                    <div>
                      <span className={`text-[10px] font-mono font-medium px-2 py-0.5 rounded capitalize ${
                        isDone ? 'bg-emerald-50 text-emerald-700' : isCurrent ? 'bg-amber-50 text-amber-700' : isFail ? 'bg-rose-50 text-rose-700' : 'text-slate-400'
                      }`}>
                        {step.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Institutional Metadata Details Table */}
          <div className="border border-slate-200 rounded-lg overflow-hidden divide-y divide-slate-100">
            <div className="bg-slate-50 px-4 py-2 text-[11px] font-mono font-bold uppercase text-slate-500 flex items-center justify-between">
              <span>Financial Metadata</span>
              <span>Clearing Reference: {selectedPayment.bankReference}</span>
            </div>

            <div className="grid grid-cols-2 p-3 gap-2">
              <div>
                <span className="text-slate-400 font-mono text-[10px] block">Payment Reference</span>
                <span className="font-semibold text-slate-800 font-mono text-xs">{selectedPayment.reference}</span>
              </div>
              <div>
                <span className="text-slate-400 font-mono text-[10px] block">Fees Assessed</span>
                <span className="font-semibold text-slate-800 font-mono text-xs">
                  {currencySymbol}{selectedPayment.fee.toFixed(2)}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 p-3 gap-2">
              <div>
                <span className="text-slate-400 font-mono text-[10px] block">Settlement Date</span>
                <span className="font-semibold text-slate-800 text-xs">{selectedPayment.settlementDate}</span>
              </div>
              <div>
                <span className="text-slate-400 font-mono text-[10px] block">Risk Score & Assessment</span>
                <span className="font-semibold text-slate-800 flex items-center gap-1.5 text-xs font-mono">
                  <span className={`w-2 h-2 rounded-full ${selectedPayment.riskStatus === 'HIGH' ? 'bg-rose-500' : selectedPayment.riskStatus === 'MEDIUM' ? 'bg-amber-500' : 'bg-emerald-500'}`} />
                  {selectedPayment.riskScore}/100 ({selectedPayment.riskStatus})
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 p-3 gap-2">
              <div>
                <span className="text-slate-400 font-mono text-[10px] block">Reconciliation Status</span>
                <span className="font-semibold text-slate-800 flex items-center gap-1.5 text-xs font-mono">
                  <Scale className="w-3.5 h-3.5 text-slate-400" />
                  {selectedPayment.reconciliationStatus}
                </span>
              </div>
              <div>
                <span className="text-slate-400 font-mono text-[10px] block">Authorization Required</span>
                <span className="font-semibold text-slate-800 font-mono text-xs">
                  {selectedPayment.approvalsCompleted} / {selectedPayment.approvalsRequired} Complete
                </span>
              </div>
            </div>

            {selectedPayment.notes && (
              <div className="p-3 bg-amber-50/40">
                <span className="text-amber-800 font-mono text-[10px] block font-bold">Officer Memo</span>
                <span className="text-slate-700 text-xs">{selectedPayment.notes}</span>
              </div>
            )}
          </div>

          {/* Raw JSON inspection toggle */}
          <div>
            <button
              onClick={() => setShowJsonPayload(!showJsonPayload)}
              className="text-xs font-mono text-slate-500 hover:text-slate-900 flex items-center gap-1.5 underline"
            >
              {showJsonPayload ? 'Hide API Payload' : 'Inspect Raw Bank API Payload (JSON)'}
            </button>
            {showJsonPayload && (
              <pre className="mt-2 p-3 bg-slate-900 text-amber-300 font-mono text-[11px] rounded-lg overflow-x-auto max-h-40">
                {JSON.stringify(selectedPayment, null, 2)}
              </pre>
            )}
          </div>
        </div>

        {/* Modal Action Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {selectedPayment.status === 'Completed' && (
              <button
                onClick={() => setIsRefundModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-md font-semibold text-xs transition-colors shadow-2xs font-mono"
              >
                <RotateCcw className="w-3.5 h-3.5 text-slate-600" />
                Issue Refund
              </button>
            )}

            <button
              onClick={() => {
                alert(`Bank Receipt downloaded for ${selectedPayment.id}`);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-md font-semibold text-xs transition-colors shadow-2xs font-mono"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              Download Receipt
            </button>
          </div>

          <button
            onClick={() => setSelectedPayment(null)}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-md font-medium text-xs transition-colors shadow-xs"
          >
            Close
          </button>
        </div>
      </div>

      {/* Nested Refund Modal */}
      {isRefundModalOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md rounded-xl shadow-2xl border border-slate-200 p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-amber-500" />
                Authorise Refund for {selectedPayment.id}
              </div>
              <button onClick={() => setIsRefundModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Refund Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRefundType('Full Refund')}
                    className={`py-2 px-3 rounded-md text-xs font-semibold border text-center transition-all ${
                      refundType === 'Full Refund' ? 'bg-slate-900 text-white border-slate-900' : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    Full Refund (£{selectedPayment.amount.toLocaleString()})
                  </button>
                  <button
                    type="button"
                    onClick={() => setRefundType('Partial Refund')}
                    className={`py-2 px-3 rounded-md text-xs font-semibold border text-center transition-all ${
                      refundType === 'Partial Refund' ? 'bg-slate-900 text-white border-slate-900' : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    Partial Refund
                  </button>
                </div>
              </div>

              {refundType === 'Partial Refund' && (
                <div>
                  <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Partial Amount (£)</label>
                  <input
                    type="number"
                    value={partialAmount}
                    onChange={(e) => setPartialAmount(e.target.value)}
                    placeholder="e.g. 5000.00"
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono text-xs focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              )}

              <div>
                <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Reason for Refund</label>
                <select
                  value={refundReason}
                  onChange={(e) => setRefundReason(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white"
                >
                  <option value="Customer request">Customer request</option>
                  <option value="Duplicate payment">Duplicate payment</option>
                  <option value="Fraud suspected">Fraud suspected</option>
                  <option value="Goods/Services cancellation">Goods/Services cancellation</option>
                  <option value="Administrative correction">Administrative correction</option>
                </select>
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-md text-amber-900 text-[11px] leading-relaxed">
                <strong>Accounting Note:</strong> Funds will be debited from RhinoBank Operating Account and credited back to the original beneficiary rail. An immutable audit record will be logged under officer <strong>{currentUser.name}</strong>.
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsRefundModalOpen(false)}
                className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md font-medium"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRefund}
                className="px-4 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-md font-mono transition-colors"
              >
                Confirm & Issue Refund
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
