import React from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  X, 
  CheckCheck, 
  Bell, 
  CreditCard, 
  Clock, 
  AlertTriangle, 
  TrendingUp, 
  Code2, 
  ShieldAlert,
  ArrowRight
} from 'lucide-react';

export const NotificationDrawer: React.FC = () => {
  const { 
    isNotificationsOpen, 
    setIsNotificationsOpen, 
    notifications, 
    markNotificationRead, 
    markAllNotificationsRead,
    setActiveTab
  } = useBanking();

  if (!isNotificationsOpen) return null;

  const iconMap = {
    payment: CreditCard,
    approval: Clock,
    liquidity: TrendingUp,
    risk: ShieldAlert,
    settlement: AlertTriangle,
    api: Code2
  };

  const colorMap = {
    payment: 'bg-emerald-100 text-emerald-700',
    approval: 'bg-amber-100 text-amber-700',
    liquidity: 'bg-blue-100 text-blue-700',
    risk: 'bg-rose-100 text-rose-700',
    settlement: 'bg-amber-100 text-amber-700',
    api: 'bg-purple-100 text-purple-700'
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/40 backdrop-blur-2xs animate-in fade-in duration-100">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl border-l border-slate-200 flex flex-col">
          {/* Header */}
          <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-amber-400" />
              <h3 className="font-bold text-sm font-mono tracking-wide text-white">NOTIFICATIONS & ALERTS</h3>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={markAllNotificationsRead}
                className="text-[11px] font-mono text-amber-300 hover:underline flex items-center gap-1"
                title="Mark all read"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                Mark all read
              </button>
              <button
                onClick={() => setIsNotificationsOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 divide-y divide-slate-100 text-xs">
            {notifications.map((notif) => {
              const Icon = iconMap[notif.type] || Bell;
              const colorClass = colorMap[notif.type] || 'bg-slate-100 text-slate-700';

              return (
                <div 
                  key={notif.id}
                  onClick={() => {
                    markNotificationRead(notif.id);
                    if (notif.actionUrl) {
                      setActiveTab(notif.actionUrl);
                      setIsNotificationsOpen(false);
                    }
                  }}
                  className={`pt-3 first:pt-0 p-2.5 rounded-lg transition-colors cursor-pointer ${
                    notif.read ? 'bg-white hover:bg-slate-50 opacity-75' : 'bg-amber-50/40 border border-amber-200/60 hover:bg-amber-50/70'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-8 h-8 rounded-lg ${colorClass} flex items-center justify-center shrink-0 mt-0.5`}>
                      <Icon className="w-4 h-4" />
                    </div>

                    <div className="flex-1 min-w-0 space-y-0.5">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-xs">{notif.title}</span>
                        <span className="text-[10px] font-mono text-slate-400">{notif.timeAgo}</span>
                      </div>
                      <p className="text-slate-600 text-[11px] leading-snug">{notif.message}</p>
                      {notif.actionUrl && (
                        <div className="pt-1 flex items-center gap-1 text-[11px] font-semibold text-amber-600">
                          <span>View in {notif.actionUrl}</span>
                          <ArrowRight className="w-3 h-3" />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Footer */}
          <div className="p-3 bg-slate-50 border-t border-slate-200 text-center">
            <span className="text-[10px] font-mono text-slate-400 uppercase">
              RhinoBank Real-Time Telemetry Event Bus
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
