import React from 'react';

interface RhinoLogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
  textColor?: string;
  subtitle?: string;
}

export const RhinoLogo: React.FC<RhinoLogoProps> = ({
  className = '',
  size = 28,
  showText = true,
  textColor = 'text-white',
  subtitle = 'PAYMENT CENTRE'
}) => {
  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Precision Geometric Rhino Icon Badge */}
      <div 
        className="relative flex items-center justify-center rounded-lg bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 shadow-md shadow-amber-500/20 p-1.5 shrink-0"
        style={{ width: size + 8, height: size + 8 }}
      >
        <svg 
          width={size} 
          height={size} 
          viewBox="0 0 32 32" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          className="text-slate-950"
        >
          {/* Institutional Rhino silhouette with geometric facets */}
          <path 
            d="M3 21C3 18 5 15 8 14L13 14L16 10L20 10L23 13L26 11L28 14L29 17L28 20L25 21L23 21L21 24L19 24L18 21L12 21L10 24L8 24L7 21L3 21Z" 
            fill="currentColor" 
          />
          {/* Forward Rhino Horn */}
          <path 
            d="M26 11L29 7L30 12L28 14L26 11Z" 
            fill="#FFFFFF" 
          />
          {/* Secondary Horn */}
          <path 
            d="M23 13L24 10L25.5 12.5L23 13Z" 
            fill="#FFFFFF" 
            opacity="0.85"
          />
          {/* Sturdy leg pillars & eye */}
          <circle cx="23" cy="15" r="1" fill="#FFFFFF" />
          <path d="M9 21V25M19 21V25" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className={`font-bold tracking-wider text-base uppercase ${textColor} font-mono leading-none`}>
              RHINOBANK
            </span>
          </div>
          {subtitle && (
            <span className="text-[9.5px] font-semibold tracking-widest text-amber-400 uppercase font-mono mt-0.5">
              {subtitle}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
