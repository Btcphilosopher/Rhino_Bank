import React, { useState, useEffect, useRef } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  Search, 
  ArrowUpRight, 
  FileText, 
  Building2, 
  ShieldAlert, 
  Coins, 
  Scale, 
  ReceiptText, 
  TrendingUp, 
  ArrowLeftRight, 
  FileSpreadsheet, 
  Code2, 
  FlaskConical, 
  X,
  CreditCard,
  UserCheck,
  ChevronRight
} from 'lucide-react';

export const CommandPalette: React.FC = () => {
  const { 
    isCommandPaletteOpen, 
    setIsCommandPaletteOpen, 
    setActiveTab, 
    setIsSendPaymentOpen, 
    setSelectedPayment,
    payments, 
    customers, 
    accounts,
    setEnvironment,
    environment
  } = useBanking();

  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isCommandPaletteOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isCommandPaletteOpen]);

  if (!isCommandPaletteOpen) return null;

  const quickActions = [
    { label: 'Send Payment', desc: 'Initiate institutional transfer or clearing run', icon: ArrowUpRight, action: () => { setIsSendPaymentOpen(true); setIsCommandPaletteOpen(false); } },
    { label: 'Create Invoice', desc: 'Generate new RhinoBank institutional invoice', icon: FileText, action: () => { setActiveTab('collections-invoices'); setIsCommandPaletteOpen(false); } },
    { label: 'Open Treasury Cash Position', desc: 'Inspect intraday liquidity & cash forecasting', icon: TrendingUp, action: () => { setActiveTab('treasury-cash'); setIsCommandPaletteOpen(false); } },
    { label: 'Open FX Dealing Desk', desc: 'Execute spot conversions or currency hedges', icon: ArrowLeftRight, action: () => { setActiveTab('treasury-fx'); setIsCommandPaletteOpen(false); } },
    { label: 'View Reconciliation Exceptions', desc: 'Inspect unmatched bank & invoice records', icon: Scale, action: () => { setActiveTab('reconciliation-exceptions'); setIsCommandPaletteOpen(false); } },
    { label: 'Switch to Sandbox Environment', desc: 'Simulate with £1,000,000 test balance', icon: FlaskConical, action: () => { setEnvironment(environment === 'Production' ? 'Sandbox' : 'Production'); setIsCommandPaletteOpen(false); } },
    { label: 'Generate Bank Statement', desc: 'Export certified statement PDF/CSV', icon: FileSpreadsheet, action: () => { setActiveTab('reconciliation-statements'); setIsCommandPaletteOpen(false); } },
    { label: 'Developer API Console', desc: 'Test live /v1 REST endpoints & inspect logs', icon: Code2, action: () => { setActiveTab('developers-api'); setIsCommandPaletteOpen(false); } },
  ];

  const matchingPayments = payments.filter(p => 
    p.id.toLowerCase().includes(query.toLowerCase()) ||
    p.counterparty.toLowerCase().includes(query.toLowerCase()) ||
    p.reference.toLowerCase().includes(query.toLowerCase()) ||
    p.amount.toString().includes(query)
  );

  const matchingCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(query.toLowerCase()) ||
    c.legalName.toLowerCase().includes(query.toLowerCase()) ||
    c.industry.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-100">
      <div className="bg-white w-full max-w-xl rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[70vh]">
        {/* Search Input Bar */}
        <div className="p-3 bg-slate-900 text-white flex items-center gap-2.5 border-b border-slate-800">
          <Search className="w-4 h-4 text-amber-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a command, customer, reference, payment ID, or account..."
            className="w-full bg-transparent text-sm text-white placeholder-slate-400 focus:outline-none font-mono"
          />
          <kbd className="px-1.5 py-0.5 text-[10px] font-mono text-slate-400 bg-slate-800 border border-slate-700 rounded">
            ESC
          </kbd>
        </div>

        {/* Results list */}
        <div className="overflow-y-auto p-2 space-y-3 text-xs max-h-[60vh]">
          {/* Quick Commands */}
          {query.trim() === '' && (
            <div>
              <div className="px-2 py-1 text-[10px] font-mono font-bold uppercase text-slate-400 tracking-wider">
                Quick Commands
              </div>
              <div className="space-y-0.5">
                {quickActions.map((action, idx) => {
                  const Icon = action.icon;
                  return (
                    <button
                      key={idx}
                      onClick={action.action}
                      className="w-full p-2 rounded-lg flex items-center justify-between hover:bg-slate-100 text-left transition-colors group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-7 h-7 rounded bg-amber-50 group-hover:bg-amber-100 text-amber-800 flex items-center justify-center">
                          <Icon className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <div className="font-semibold text-slate-800">{action.label}</div>
                          <div className="text-[11px] text-slate-500">{action.desc}</div>
                        </div>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-700" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Matched Payments */}
          {query.trim() !== '' && matchingPayments.length > 0 && (
            <div>
              <div className="px-2 py-1 text-[10px] font-mono font-bold uppercase text-slate-400 tracking-wider">
                Payments & Settlements ({matchingPayments.length})
              </div>
              <div className="space-y-0.5">
                {matchingPayments.slice(0, 5).map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      setSelectedPayment(p);
                      setIsCommandPaletteOpen(false);
                    }}
                    className="w-full p-2 rounded-lg flex items-center justify-between hover:bg-slate-100 text-left transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <CreditCard className="w-4 h-4 text-slate-400" />
                      <div>
                        <div className="font-bold text-slate-900 font-mono text-xs">{p.id} · {p.counterparty}</div>
                        <div className="text-[10px] text-slate-500 font-mono">{p.reference} · {p.status}</div>
                      </div>
                    </div>
                    <span className="font-mono font-bold text-slate-800">
                      £{p.amount.toLocaleString()}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Matched Customers */}
          {query.trim() !== '' && matchingCustomers.length > 0 && (
            <div>
              <div className="px-2 py-1 text-[10px] font-mono font-bold uppercase text-slate-400 tracking-wider">
                Institutional Customers ({matchingCustomers.length})
              </div>
              <div className="space-y-0.5">
                {matchingCustomers.slice(0, 4).map((c) => (
                  <button
                    key={c.id}
                    onClick={() => {
                      setActiveTab('accounts-customers');
                      setIsCommandPaletteOpen(false);
                    }}
                    className="w-full p-2 rounded-lg flex items-center justify-between hover:bg-slate-100 text-left transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <Building2 className="w-4 h-4 text-slate-400" />
                      <div>
                        <div className="font-bold text-slate-900 text-xs">{c.name}</div>
                        <div className="text-[10px] text-slate-500 font-mono">{c.industry} · {c.tier}</div>
                      </div>
                    </div>
                    <span className="font-mono font-semibold text-emerald-700 text-xs">
                      £{(c.totalBalance / 1000000).toFixed(2)}m
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Fallback no results */}
          {query.trim() !== '' && matchingPayments.length === 0 && matchingCustomers.length === 0 && (
            <div className="py-8 text-center text-slate-400">
              <p className="font-mono text-xs">No records matching "{query}"</p>
              <p className="text-[11px] text-slate-500 mt-1">Try searching by company, reference ID or payment amount.</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-2 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-[10px] font-mono text-slate-400">
          <span>RHINOBANK UNIVERSAL NAVIGATION</span>
          <span>Press ESC to close</span>
        </div>
      </div>
    </div>
  );
};
