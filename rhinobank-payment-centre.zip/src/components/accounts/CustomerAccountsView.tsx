import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  Building2, 
  Search, 
  ShieldCheck, 
  UserCheck, 
  ExternalLink, 
  CreditCard, 
  Lock, 
  TrendingUp, 
  ChevronRight
} from 'lucide-react';
import { Customer } from '../../types/banking';

export const CustomerAccountsView: React.FC = () => {
  const { customers } = useBanking();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  const filtered = customers.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.legalName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.industry.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Institutional Customer Directory</h1>
        <p className="text-xs text-slate-500 font-mono">
          Corporate clients, KYC verifications, daily volume caps & relationship governance
        </p>
      </div>

      {/* Search Bar */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
        <div className="relative w-full max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search corporate client name, legal entity, or industry..."
            className="w-full pl-9 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs bg-slate-50/50 focus:ring-1 focus:ring-amber-500"
          />
        </div>
        <span className="text-xs font-mono text-slate-400">{filtered.length} Authenticated Entities</span>
      </div>

      {/* Grid of Customers */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((customer) => (
          <div
            key={customer.id}
            onClick={() => setSelectedCustomer(customer)}
            className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4 hover:border-amber-400 transition-all cursor-pointer group"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-slate-900 text-amber-400 font-mono font-bold text-sm flex items-center justify-center">
                  {customer.name.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm group-hover:text-amber-600 transition-colors">
                    {customer.name}
                  </h3>
                  <span className="text-[10px] font-mono text-slate-400">{customer.industry} · {customer.tier}</span>
                </div>
              </div>

              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                {customer.kycStatus}
              </span>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg space-y-1.5 font-mono text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400 text-[10px] uppercase">Total Balance</span>
                <span className="font-bold text-slate-900">£{customer.totalBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 text-[10px] uppercase">Daily Limit</span>
                <span className="font-semibold text-slate-700">£{(customer.paymentDailyLimit / 1000000).toFixed(0)}m cap</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 text-[10px] uppercase">30D Volume</span>
                <span className="font-semibold text-emerald-600">£{(customer.payments30DaysVolume / 1000000).toFixed(1)}m</span>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
              <span className="font-mono">RM: {customer.relationshipManager}</span>
              <span className="flex items-center gap-1 font-semibold text-slate-700 group-hover:text-slate-900">
                View Entity <ChevronRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Customer Detail Drawer / Modal */}
      {selectedCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white w-full max-w-lg rounded-xl shadow-2xl border border-slate-200 p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-base text-slate-900">{selectedCustomer.name}</h3>
                <p className="text-[11px] text-slate-400 font-mono">Reg: {selectedCustomer.registrationNumber} · {selectedCustomer.jurisdiction}</p>
              </div>
              <button onClick={() => setSelectedCustomer(null)} className="text-slate-400 hover:text-slate-600 font-mono text-sm">
                ✕
              </button>
            </div>

            <div className="space-y-3 font-mono">
              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-lg">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase">KYC Status</span>
                  <span className="font-bold text-emerald-700">{selectedCustomer.kycStatus}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase">AML / Sanctions</span>
                  <span className="font-bold text-emerald-700">{selectedCustomer.amlStatus}</span>
                </div>
              </div>

              <div className="space-y-1 text-slate-700">
                <div><strong>Full Legal Entity:</strong> {selectedCustomer.legalName}</div>
                <div><strong>Corporate Email:</strong> {selectedCustomer.contactEmail}</div>
                <div><strong>Direct Phone:</strong> {selectedCustomer.contactPhone}</div>
                <div><strong>Relationship Manager:</strong> {selectedCustomer.relationshipManager}</div>
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-100">
              <button
                onClick={() => setSelectedCustomer(null)}
                className="px-4 py-1.5 bg-slate-900 text-white rounded-md font-mono text-xs font-semibold"
              >
                Close Profile
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
