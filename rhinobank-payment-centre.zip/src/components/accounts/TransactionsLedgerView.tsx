import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  Scale, 
  Search, 
  Download, 
  CheckCircle2, 
  FileSpreadsheet
} from 'lucide-react';
import { LedgerEntry } from '../../types/banking';

export const TransactionsLedgerView: React.FC = () => {
  const { ledger, accounts } = useBanking();
  const [searchTerm, setSearchTerm] = useState('');
  const [accountFilter, setAccountFilter] = useState('ALL');
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'Debit' | 'Credit'>('ALL');

  const filteredEntries = ledger.filter((entry) => {
    const matchesSearch = 
      entry.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.counterparty.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.accountName.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesAccount = accountFilter === 'ALL' || entry.accountName === accountFilter;
    const matchesType = typeFilter === 'ALL' || entry.type === typeFilter;

    return matchesSearch && matchesAccount && matchesType;
  });

  const exportLedgerCSV = () => {
    const headers = 'Entry ID,Date,Account,Type,Amount,Currency,Running Balance,Reference,Counterparty,Status\n';
    const rows = filteredEntries.map(e => 
      `${e.id},"${e.date}","${e.accountName}",${e.type},${e.amount},${e.currency},${e.runningBalance},"${e.reference}","${e.counterparty}",${e.status}`
    ).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rhinobank_double_entry_ledger_${Date.now()}.csv`;
    a.click();
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Double-Entry Transaction Ledger</h1>
          <p className="text-xs text-slate-500 font-mono">
            ACID-compliant cryptographic financial journal · Immutable running balance derivation
          </p>
        </div>

        <button
          onClick={exportLedgerCSV}
          className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-md font-mono text-xs font-medium transition-colors shadow-2xs flex items-center gap-1.5"
        >
          <Download className="w-3.5 h-3.5 text-slate-500" />
          Export Ledger (CSV)
        </button>
      </div>

      {/* Accounting Integrity Banner */}
      <div className="p-4 bg-slate-900 text-white rounded-xl border border-slate-800 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <div className="font-bold text-xs font-mono text-white">Double-Entry Proof: BALANCED (0.00 Delta)</div>
            <div className="text-[11px] text-slate-400 font-mono">
              Total Debits = Total Credits across all nostro and vostro mirrors.
            </div>
          </div>
        </div>

        <span className="text-[10px] font-mono font-bold uppercase text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded border border-emerald-500/20">
          ● Cryptographic Hash Valid
        </span>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search journal entries, counterparties, reference..."
            className="w-full pl-9 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs bg-slate-50/50 focus:ring-1 focus:ring-amber-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <select
            value={accountFilter}
            onChange={(e) => setAccountFilter(e.target.value)}
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg font-mono text-xs bg-white text-slate-700"
          >
            <option value="ALL">All Accounts</option>
            {accounts.map(a => (
              <option key={a.id} value={a.name}>{a.name}</option>
            ))}
          </select>

          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value as any)}
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg font-mono text-xs bg-white text-slate-700"
          >
            <option value="ALL">All Entry Types</option>
            <option value="Debit">Debits Only</option>
            <option value="Credit">Credits Only</option>
          </select>
        </div>
      </div>

      {/* Table Container */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-mono text-[11px] uppercase tracking-wider">
                <th className="py-3 px-4 font-semibold">Entry ID / Date</th>
                <th className="py-3 px-4 font-semibold">Account Affected</th>
                <th className="py-3 px-4 font-semibold">Counterparty / Description</th>
                <th className="py-3 px-4 font-semibold">Reference</th>
                <th className="py-3 px-4 font-semibold text-center">Type</th>
                <th className="py-3 px-4 font-semibold text-right">Debit / Credit Amount</th>
                <th className="py-3 px-4 font-semibold text-right">Running Balance</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredEntries.map((entry) => {
                const isDebit = entry.type === 'Debit';
                const curSymbol = entry.currency === 'GBP' ? '£' : entry.currency === 'USD' ? '$' : entry.currency === 'EUR' ? '€' : 'CHF ';

                return (
                  <tr key={entry.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-mono">
                      <div className="font-bold text-slate-900">{entry.id}</div>
                      <div className="text-[10px] text-slate-400">{entry.date}</div>
                    </td>

                    <td className="py-3 px-4 font-semibold text-slate-800">
                      {entry.accountName}
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{entry.counterparty}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{entry.description}</div>
                    </td>

                    <td className="py-3 px-4 font-mono text-slate-600">
                      {entry.reference}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        isDebit ? 'bg-rose-50 text-rose-700 border border-rose-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      }`}>
                        {entry.type.toUpperCase()}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right font-mono font-bold text-xs">
                      <span className={isDebit ? 'text-slate-900' : 'text-emerald-700'}>
                        {isDebit ? '-' : '+'}{curSymbol}{entry.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 text-xs">
                      {curSymbol}{entry.runningBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700">
                        {entry.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] font-mono text-slate-500">
          <span>Showing {filteredEntries.length} double-entry records</span>
          <span>Ledger state: Fully Derived</span>
        </div>
      </div>
    </div>
  );
};
