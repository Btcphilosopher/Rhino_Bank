import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  Building2, 
  ArrowUpRight, 
  ArrowDownLeft, 
  ArrowLeftRight, 
  Copy, 
  Check, 
  Lock, 
  TrendingUp, 
  ShieldCheck, 
  X,
  CreditCard
} from 'lucide-react';
import { Currency } from '../../types/banking';

export const AccountsView: React.FC = () => {
  const { accounts, sendPayment } = useBanking();
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [fromAccount, setFromAccount] = useState(accounts[0]?.name || '');
  const [toAccount, setToAccount] = useState(accounts[1]?.name || '');
  const [transferAmount, setTransferAmount] = useState('');
  const [transferMemo, setTransferMemo] = useState('Inter-account treasury rebalancing');

  const totalGbpEquivalent = accounts.reduce((acc, a) => {
    const rate = a.currency === 'USD' ? 0.74 : a.currency === 'EUR' ? 0.86 : a.currency === 'CHF' ? 0.88 : 1.0;
    return acc + a.availableBalance * rate;
  }, 0);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleExecuteInternalTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!transferAmount || fromAccount === toAccount) return;
    const sourceAcc = accounts.find(a => a.name === fromAccount);
    await sendPayment({
      counterparty: toAccount,
      counterpartyBank: 'RhinoBank PLC',
      amount: parseFloat(transferAmount),
      currency: sourceAcc?.currency || 'GBP',
      fromAccountName: fromAccount,
      reference: transferMemo,
      priority: 'Instant Faster Payments',
      purpose: 'Internal book transfer'
    });
    setIsTransferModalOpen(false);
    setTransferAmount('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Institutional Bank Accounts</h1>
          <p className="text-xs text-slate-500 font-mono">
            Multi-currency treasury clearing nodes · Real-time Bank of England & RTGS connections
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsTransferModalOpen(true)}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-mono text-xs font-semibold rounded-md shadow-xs transition-colors flex items-center gap-1.5"
          >
            <ArrowLeftRight className="w-3.5 h-3.5 text-amber-400" />
            Internal Account Transfer
          </button>
        </div>
      </div>

      {/* Aggregate Balance Banner */}
      <div className="bg-slate-900 text-white p-6 rounded-xl border border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
            Total Combined Institutional Liquidity (GBP Eq.)
          </span>
          <div className="text-3xl font-bold font-mono text-white mt-1">
            £{totalGbpEquivalent.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-xs text-emerald-400 font-mono mt-1 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4" />
            Direct Clearing · FSCS Institutional Ring-Fenced
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
          <div className="p-2.5 bg-slate-800/80 rounded-lg border border-slate-700">
            <span className="text-[10px] text-slate-400 uppercase block">GBP Clearing</span>
            <span className="font-bold text-white">£12.48m</span>
          </div>
          <div className="p-2.5 bg-slate-800/80 rounded-lg border border-slate-700">
            <span className="text-[10px] text-slate-400 uppercase block">USD Nostro</span>
            <span className="font-bold text-white">$4.82m</span>
          </div>
          <div className="p-2.5 bg-slate-800/80 rounded-lg border border-slate-700">
            <span className="text-[10px] text-slate-400 uppercase block">EUR Vostro</span>
            <span className="font-bold text-white">€2.18m</span>
          </div>
          <div className="p-2.5 bg-slate-800/80 rounded-lg border border-slate-700">
            <span className="text-[10px] text-slate-400 uppercase block">Reserve Buffer</span>
            <span className="font-bold text-white">£45.00m</span>
          </div>
        </div>
      </div>

      {/* Account Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {accounts.map((acc) => {
          const curSymbol = acc.currency === 'GBP' ? '£' : acc.currency === 'USD' ? '$' : acc.currency === 'EUR' ? '€' : 'CHF ';

          return (
            <div key={acc.id} className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4 hover:border-amber-400 transition-all">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-lg">
                    {acc.currency === 'GBP' ? '🇬🇧' : acc.currency === 'USD' ? '🇺🇸' : acc.currency === 'EUR' ? '🇪🇺' : '🇨🇭'}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{acc.name}</h3>
                    <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wide">{acc.type}</span>
                  </div>
                </div>

                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  Active
                </span>
              </div>

              {/* Balances Details */}
              <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg space-y-2 font-mono">
                <div className="flex items-baseline justify-between">
                  <span className="text-slate-400 text-[11px] uppercase">Available Balance</span>
                  <span className="text-xl font-bold text-slate-900 tabular-nums">
                    {curSymbol}{acc.availableBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>

                <div className="grid grid-cols-2 pt-2 border-t border-slate-200/80 text-[11px]">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Reserved / Holds:</span>
                    <span className="font-semibold text-slate-700">{curSymbol}{acc.reservedBalance.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Pending Settlement:</span>
                    <span className="font-semibold text-emerald-600">+{curSymbol}{acc.pendingBalance.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Coordinates */}
              <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1">
                <div className="p-2 bg-slate-100/60 rounded border border-slate-200/60 flex items-center justify-between">
                  <div>
                    <span className="text-[9px] text-slate-400 block uppercase">IBAN</span>
                    <span className="font-bold text-slate-800 text-[11px] truncate">{acc.iban}</span>
                  </div>
                  <button onClick={() => handleCopy(acc.iban, acc.id + 'iban')} className="p-1 text-slate-400 hover:text-slate-800">
                    {copiedId === acc.id + 'iban' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  </button>
                </div>

                <div className="p-2 bg-slate-100/60 rounded border border-slate-200/60 flex items-center justify-between">
                  <div>
                    <span className="text-[9px] text-slate-400 block uppercase">Sort Code & Account</span>
                    <span className="font-bold text-slate-800 text-[11px]">{acc.sortCode} · {acc.accountNumber}</span>
                  </div>
                  <button onClick={() => handleCopy(acc.sortCode, acc.id + 'bic')} className="p-1 text-slate-400 hover:text-slate-800">
                    {copiedId === acc.id + 'bic' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Internal Transfer Modal */}
      {isTransferModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md rounded-xl shadow-2xl border border-slate-200 p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <ArrowLeftRight className="w-4 h-4 text-amber-500" />
                Institutional Internal Book Transfer
              </div>
              <button onClick={() => setIsTransferModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleExecuteInternalTransfer} className="space-y-3">
              <div>
                <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Source Account (Debit)</label>
                <select
                  value={fromAccount}
                  onChange={(e) => setFromAccount(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md text-xs bg-white"
                >
                  {accounts.map(a => (
                    <option key={a.id} value={a.name}>
                      {a.name} ({a.currency} {a.availableBalance.toLocaleString()})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Destination Account (Credit)</label>
                <select
                  value={toAccount}
                  onChange={(e) => setToAccount(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md text-xs bg-white"
                >
                  {accounts.map(a => (
                    <option key={a.id} value={a.name}>
                      {a.name} ({a.currency} {a.availableBalance.toLocaleString()})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Transfer Amount</label>
                <input
                  type="number"
                  required
                  value={transferAmount}
                  onChange={(e) => setTransferAmount(e.target.value)}
                  placeholder="100000.00"
                  className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono text-xs focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Internal Ledger Memo</label>
                <input
                  type="text"
                  value={transferMemo}
                  onChange={(e) => setTransferMemo(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono text-xs focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="p-3 bg-amber-50 rounded text-[11px] text-amber-900 font-mono">
                Double-entry balancing: Instant same-second ledger execution with zero FX spread on same currency.
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsTransferModalOpen(false)}
                  className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-md font-mono transition-colors"
                >
                  Confirm Transfer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
