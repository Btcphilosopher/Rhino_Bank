import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  FileText, 
  Plus, 
  Eye, 
  X
} from 'lucide-react';
import { Invoice, Currency } from '../../types/banking';
import confetti from 'canvas-confetti';

export const InvoicingView: React.FC = () => {
  const { invoices, createInvoice, payInvoice, customers } = useBanking();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  // Form State
  const [customerName, setCustomerName] = useState(customers[0]?.name || '');
  const [dueDate, setDueDate] = useState('2026-09-15');
  const [currency, setCurrency] = useState<Currency>('GBP');
  const [itemDesc, setItemDesc] = useState('Institutional Liquidity & Clearing Access (Monthly)');
  const [itemQty, setItemQty] = useState(1);
  const [itemRate, setItemRate] = useState(42000);
  const [vatRate, setVatRate] = useState(20);

  const subtotal = itemQty * itemRate;
  const vat = subtotal * (vatRate / 100);
  const total = subtotal + vat;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const cust = customers.find(c => c.name === customerName);
    createInvoice({
      customerName,
      customerId: cust?.id || 'CUST-01',
      customerEmail: cust?.contactEmail || `billing@${customerName.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`,
      dueDate,
      currency,
      subtotal,
      vat,
      total,
      status: 'Pending',
      paymentReference: `INV-${Date.now().toString().slice(-6)}`,
      items: [
        {
          id: `item-${Date.now()}`,
          description: itemDesc,
          quantity: itemQty,
          unitPrice: itemRate,
          vatRate: vatRate / 100,
          amount: subtotal
        }
      ]
    });
    setIsCreateModalOpen(false);
  };

  const handlePay = (invoiceId: string) => {
    payInvoice(invoiceId);
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.6 }
    });
    if (selectedInvoice && selectedInvoice.id === invoiceId) {
      setSelectedInvoice(prev => prev ? { ...prev, status: 'Paid', paidAt: '23 Aug 2026' } : null);
    }
  };

  const totalOutstanding = invoices.filter(i => i.status !== 'Paid').reduce((acc, i) => acc + i.total, 0);
  const totalPaid = invoices.filter(i => i.status === 'Paid').reduce((acc, i) => acc + i.total, 0);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Institutional Invoicing & Billing</h1>
          <p className="text-xs text-slate-500 font-mono">
            Automated corporate receivables · Real-time escrow settlement & VAT compliance
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-mono text-xs font-semibold rounded-md shadow-xs transition-colors flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4 text-amber-400" />
          Create Invoice
        </button>
      </div>

      {/* Metrics Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Total Settled Invoices</span>
          <div className="text-xl font-bold font-mono text-emerald-700">£{totalPaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Outstanding Receivables</span>
          <div className="text-xl font-bold font-mono text-amber-700">£{totalOutstanding.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Auto-Collection Rate</span>
          <div className="text-xl font-bold font-mono text-slate-900">98.2% via FPS</div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-mono text-[11px] uppercase tracking-wider">
                <th className="py-3 px-4 font-semibold">Invoice # / Issue Date</th>
                <th className="py-3 px-4 font-semibold">Customer / Entity</th>
                <th className="py-3 px-4 font-semibold">Due Date</th>
                <th className="py-3 px-4 font-semibold text-right">Net Subtotal</th>
                <th className="py-3 px-4 font-semibold text-right">Total (inc. VAT)</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
                <th className="py-3 px-4 font-semibold text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {invoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-bold font-mono text-slate-900">{inv.id}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{inv.issueDate}</div>
                  </td>

                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-900">{inv.customerName}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{inv.customerEmail}</div>
                  </td>

                  <td className="py-3 px-4 font-mono text-slate-700">
                    {inv.dueDate}
                  </td>

                  <td className="py-3 px-4 text-right font-mono text-slate-700">
                    £{inv.subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>

                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 text-xs">
                    £{inv.total.toLocaleString(undefined, { minimumFractionDigits: 2 })} {inv.currency}
                  </td>

                  <td className="py-3 px-4 text-center">
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase ${
                      inv.status === 'Paid' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                      inv.status === 'Overdue' ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                      'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}>
                      {inv.status}
                    </span>
                  </td>

                  <td className="py-3 px-4 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => setSelectedInvoice(inv)}
                        className="p-1 text-slate-400 hover:text-slate-900 rounded"
                        title="View Invoice"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>

                      {inv.status !== 'Paid' && (
                        <button
                          onClick={() => handlePay(inv.id)}
                          className="px-2 py-0.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-mono text-[10px] font-bold"
                          title="Simulate Inbound Payment"
                        >
                          Settle Now
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invoice Detail Preview Modal */}
      {selectedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white w-full max-w-lg rounded-xl shadow-2xl border border-slate-200 p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-500" />
                <span className="font-bold text-sm text-slate-900">RHINOBANK INVOICE {selectedInvoice.id}</span>
              </div>
              <button onClick={() => setSelectedInvoice(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 font-mono">
              <div className="flex justify-between text-slate-600">
                <span>Customer: <strong>{selectedInvoice.customerName}</strong></span>
                <span>Due Date: <strong>{selectedInvoice.dueDate}</strong></span>
              </div>

              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full text-left text-[11px]">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-500">
                    <tr>
                      <th className="p-2">Description</th>
                      <th className="p-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {selectedInvoice.items.map(item => (
                      <tr key={item.id}>
                        <td className="p-2 text-slate-800">{item.description} (x{item.quantity})</td>
                        <td className="p-2 text-right font-bold">£{item.amount.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="space-y-1 text-right pt-2 border-t border-slate-100 text-xs">
                <div>Subtotal: <strong>£{selectedInvoice.subtotal.toLocaleString()}</strong></div>
                <div>VAT: <strong>£{selectedInvoice.vat.toLocaleString()}</strong></div>
                <div className="text-sm font-bold text-slate-900">Total: £{selectedInvoice.total.toLocaleString()} {selectedInvoice.currency}</div>
              </div>
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-slate-100">
              <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                selectedInvoice.status === 'Paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
              }`}>
                Status: {selectedInvoice.status}
              </span>

              <div className="flex gap-2">
                {selectedInvoice.status !== 'Paid' && (
                  <button
                    onClick={() => handlePay(selectedInvoice.id)}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-mono text-xs font-bold rounded"
                  >
                    Simulate Inbound Payment
                  </button>
                )}
                <button
                  onClick={() => setSelectedInvoice(null)}
                  className="px-3 py-1.5 bg-slate-900 text-white font-mono text-xs rounded"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Create Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md rounded-xl shadow-2xl border border-slate-200 p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-amber-500" />
                Issue New Commercial Invoice
              </div>
              <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Customer / Entity</label>
                <select
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md text-xs bg-white"
                >
                  {customers.map(c => (
                    <option key={c.id} value={c.name}>{c.name} ({c.industry})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Due Date</label>
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Item Description</label>
                <input
                  type="text"
                  value={itemDesc}
                  onChange={(e) => setItemDesc(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Net Amount (£)</label>
                  <input
                    type="number"
                    value={itemRate}
                    onChange={(e) => setItemRate(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">VAT Rate (%)</label>
                  <input
                    type="number"
                    value={vatRate}
                    onChange={(e) => setVatRate(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono text-xs"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded font-mono text-xs space-y-1">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>£{subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>VAT ({vatRate}%):</span>
                  <span>£{vat.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-slate-900 pt-1 border-t border-slate-200">
                  <span>Total Invoice:</span>
                  <span>£{total.toFixed(2)} GBP</span>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-md font-mono transition-colors"
                >
                  Dispatch Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
