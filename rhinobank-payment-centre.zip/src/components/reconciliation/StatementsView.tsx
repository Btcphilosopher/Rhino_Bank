import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  FileSpreadsheet, 
  Download, 
  Printer, 
  ShieldCheck
} from 'lucide-react';
import { RhinoLogo } from '../common/RhinoLogo';

export const StatementsView: React.FC = () => {
  const { accounts, ledger } = useBanking();
  const [selectedAccountName, setSelectedAccountName] = useState(accounts[0]?.name || 'GBP Operating Account');
  const [startDate, setStartDate] = useState('2026-08-01');
  const [endDate, setEndDate] = useState('2026-08-23');

  const selectedAccount = accounts.find(a => a.name === selectedAccountName) || accounts[0];
  const accountEntries = ledger.filter(e => e.accountName === selectedAccountName);

  const totalCredits = accountEntries.filter(e => e.type === 'Credit').reduce((acc, e) => acc + e.amount, 0);
  const totalDebits = accountEntries.filter(e => e.type === 'Debit').reduce((acc, e) => acc + e.amount, 0);
  const openingBalance = selectedAccount.availableBalance - totalCredits + totalDebits;

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    alert(`Downloading certified PDF statement for ${selectedAccountName} (${startDate} to ${endDate})`);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Certified Bank Statements</h1>
          <p className="text-xs text-slate-500 font-mono">
            Official RhinoBank regulatory statements · Cryptographically signed proof of balance
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-md font-mono text-xs font-medium transition-colors shadow-2xs flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5 text-slate-500" />
            Print
          </button>
          <button
            onClick={handleDownload}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-mono text-xs font-semibold rounded-md shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            Download PDF
          </button>
        </div>
      </div>

      {/* Account & Date Selectors */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col md:flex-row items-center gap-4 text-xs">
        <div className="w-full md:w-1/3">
          <label className="block text-slate-500 font-mono text-[10px] uppercase font-bold mb-1">Select Account</label>
          <select
            value={selectedAccountName}
            onChange={(e) => setSelectedAccountName(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs bg-white"
          >
            {accounts.map(a => (
              <option key={a.id} value={a.name}>{a.name} ({a.currency})</option>
            ))}
          </select>
        </div>

        <div className="w-full md:w-1/3">
          <label className="block text-slate-500 font-mono text-[10px] uppercase font-bold mb-1">From Date</label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
          />
        </div>

        <div className="w-full md:w-1/3">
          <label className="block text-slate-500 font-mono text-[10px] uppercase font-bold mb-1">To Date</label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
          />
        </div>
      </div>

      {/* Statement Sheet Simulation */}
      <div className="bg-white rounded-xl border border-slate-300 shadow-lg p-8 max-w-4xl mx-auto space-y-6 text-slate-900 font-sans">
        {/* Statement Header */}
        <div className="flex items-start justify-between border-b-2 border-slate-900 pb-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <RhinoLogo className="w-8 h-8" />
              <div>
                <span className="text-lg font-bold font-mono tracking-wider">RHINOBANK PLC</span>
                <span className="block text-[9px] font-mono text-slate-500 uppercase">Institutional & Corporate Banking</span>
              </div>
            </div>
            <p className="text-[11px] text-slate-500 font-mono pt-2">
              RhinoBank House, 1 Churchill Place, London E14 5HP<br />
              Authorized by the Prudential Regulation Authority (PRA) & FCA (FRN: 902184)
            </p>
          </div>

          <div className="text-right font-mono text-xs space-y-0.5">
            <div className="text-lg font-bold text-slate-900">STATEMENT OF ACCOUNT</div>
            <div className="text-slate-500">Period: {startDate} to {endDate}</div>
            <div className="text-slate-500">Generated: 23 Aug 2026 14:45 BST</div>
          </div>
        </div>

        {/* Account Details & Balances Grid */}
        <div className="grid grid-cols-2 gap-6 p-4 bg-slate-50 rounded-lg font-mono text-xs">
          <div className="space-y-1">
            <div className="text-[10px] uppercase text-slate-400 font-bold">Account Holder</div>
            <div className="font-bold text-slate-900 text-sm">RHINOBANK INSTITUTIONAL CLIENT</div>
            <div className="text-slate-600">Account: {selectedAccount.name}</div>
            <div className="text-slate-600">IBAN: {selectedAccount.iban}</div>
            <div className="text-slate-600">BIC / SWIFT: RHNOGB2L</div>
          </div>

          <div className="space-y-1 text-right">
            <div className="text-[10px] uppercase text-slate-400 font-bold">Summary of Activity</div>
            <div>Opening Balance: <strong>£{openingBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong></div>
            <div className="text-emerald-700">Total Credits (+): <strong>+£{totalCredits.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong></div>
            <div className="text-rose-700">Total Debits (-): <strong>-£{totalDebits.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong></div>
            <div className="pt-1 border-t border-slate-200 text-sm font-bold text-slate-900">
              Closing Balance: £{selectedAccount.availableBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })} {selectedAccount.currency}
            </div>
          </div>
        </div>

        {/* Statement Line Items */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b-2 border-slate-300 text-slate-600 text-[10px] uppercase">
                <th className="py-2">Date / ID</th>
                <th className="py-2">Description / Beneficiary</th>
                <th className="py-2">Reference</th>
                <th className="py-2 text-right">Debit (-)</th>
                <th className="py-2 text-right">Credit (+)</th>
                <th className="py-2 text-right">Balance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {accountEntries.map((e) => {
                const isDebit = e.type === 'Debit';
                return (
                  <tr key={e.id} className="py-2">
                    <td className="py-2 text-slate-700">
                      <div>{e.date}</div>
                      <div className="text-[9px] text-slate-400">{e.id}</div>
                    </td>
                    <td className="py-2 font-semibold text-slate-900">{e.counterparty}</td>
                    <td className="py-2 text-slate-600 text-[11px]">{e.reference}</td>
                    <td className="py-2 text-right text-rose-700 font-semibold">
                      {isDebit ? `£${e.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}` : '-'}
                    </td>
                    <td className="py-2 text-right text-emerald-700 font-semibold">
                      {!isDebit ? `£${e.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}` : '-'}
                    </td>
                    <td className="py-2 text-right font-bold text-slate-900">
                      £{e.runningBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Footer Seal */}
        <div className="pt-6 border-t border-slate-200 flex items-center justify-between text-[10px] font-mono text-slate-500">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Digital Cryptographic Signature: 0x8F92A7...01E9 (Verified Authentic)</span>
          </div>
          <span>Page 1 of 1</span>
        </div>
      </div>
    </div>
  );
};
