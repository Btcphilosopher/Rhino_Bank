import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  Scale, 
  CheckCircle2, 
  AlertCircle, 
  FileCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const ReconciliationView: React.FC = () => {
  const { exceptions, resolveException } = useBanking();

  const handleResolve = (id: string) => {
    resolveException(id, 'match');
    confetti({
      particleCount: 40,
      spread: 50,
      origin: { y: 0.6 }
    });
  };

  const pendingExceptions = exceptions.filter(e => e.status !== 'Resolved' && e.status !== 'Matched');

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Automated Reconciliation & Exceptions Queue</h1>
        <p className="text-xs text-slate-500 font-mono">
          Intraday 4-way matching engine · Bank feed vs Internal ledger vs Invoices vs Counterparty confirmations
        </p>
      </div>

      {/* Matching KPI Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Total Matched (24h)</span>
          <div className="text-2xl font-bold font-mono text-emerald-700">£18.24m</div>
          <span className="text-[11px] font-mono text-emerald-600 font-medium">99.7% automated match rate</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Unmatched Queue</span>
          <div className="text-2xl font-bold font-mono text-amber-700">£42,820.00</div>
          <span className="text-[11px] font-mono text-slate-500">2 incoming deposits</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Open Exceptions</span>
          <div className="text-2xl font-bold font-mono text-rose-700">{pendingExceptions.length}</div>
          <span className="text-[11px] font-mono text-slate-500">Requires desk intervention</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Ledger Discrepancy</span>
          <div className="text-2xl font-bold font-mono text-slate-900">£0.00</div>
          <span className="text-[11px] font-mono text-emerald-600 font-medium">Fully Balanced</span>
        </div>
      </div>

      {/* Exceptions Queue */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-sm text-slate-900">Discrepancy Resolution Desk</h2>
          <span className="text-xs font-mono text-slate-400">Auto-Rules: Tolerance ±£0.05 · Reference Fuzzy Match &gt;85%</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-mono text-[11px] uppercase tracking-wider">
                  <th className="py-3 px-4 font-semibold">Exception ID</th>
                  <th className="py-3 px-4 font-semibold">Counterparty / Reference</th>
                  <th className="py-3 px-4 font-semibold">Discrepancy Reason</th>
                  <th className="py-3 px-4 font-semibold text-right">Amount</th>
                  <th className="py-3 px-4 font-semibold text-center">Status</th>
                  <th className="py-3 px-4 font-semibold text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {pendingExceptions.map((exc) => (
                  <tr key={exc.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {exc.id}
                      <div className="text-[10px] text-slate-400 font-normal">{exc.date}</div>
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{exc.counterparty}</div>
                      <div className="text-[10px] text-slate-500 font-mono">Ref: {exc.reference}</div>
                    </td>

                    <td className="py-3 px-4 text-slate-700">
                      <span className="font-medium text-rose-700">{exc.reason}</span>
                      {exc.systemRecord && <div className="text-[10px] text-slate-400 font-mono">{exc.systemRecord}</div>}
                    </td>

                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                      £{exc.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} {exc.currency}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-100 text-amber-800">
                        {exc.status}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => handleResolve(exc.id)}
                        className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded font-mono text-[10px] font-bold shadow-xs transition-colors"
                      >
                        Reconcile & Match
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {pendingExceptions.length === 0 && (
            <div className="py-10 text-center text-slate-400">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-1 opacity-80" />
              <p className="font-semibold text-slate-700 text-xs">All exceptions resolved</p>
              <p className="text-[11px] text-slate-400">No open discrepancies between clearing feeds and internal books.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
