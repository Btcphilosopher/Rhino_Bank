import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  ArrowRight, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  TrendingUp, 
  DollarSign, 
  Coins, 
  FileText, 
  Link as LinkIcon, 
  ArrowLeftRight, 
  Users, 
  FileSpreadsheet, 
  ShieldAlert, 
  ShieldCheck, 
  Activity, 
  PlusCircle, 
  ChevronRight,
  Sparkles,
  Layers,
  Lock,
  RotateCcw
} from 'lucide-react';
import { Payment } from '../../types/banking';

export const OverviewView: React.FC = () => {
  const { 
    currentUser, 
    payments, 
    accounts, 
    approvals, 
    riskAlerts, 
    notifications, 
    setActiveTab, 
    setSelectedPayment, 
    setIsSendPaymentOpen 
  } = useBanking();

  const [timeRange, setTimeRange] = useState<'Today' | '7 days' | '30 days' | '90 days' | '12 months'>('7 days');
  const [hoveredPoint, setHoveredPoint] = useState<{ day: string; value: number; x: number; y: number } | null>(null);

  // Time range datasets
  const chartDatasets = {
    'Today': [
      { label: '08:00', value: 2.4 },
      { label: '10:00', value: 5.8 },
      { label: '12:00', value: 11.2 },
      { label: '14:00', value: 18.42 },
      { label: '16:00', value: 18.42 },
    ],
    '7 days': [
      { label: 'Mon', value: 4.8 },
      { label: 'Tue', value: 8.2 },
      { label: 'Wed', value: 13.5 },
      { label: 'Thu', value: 14.1 },
      { label: 'Fri', value: 18.42 },
      { label: 'Sat', value: 12.0 },
      { label: 'Sun', value: 6.5 },
    ],
    '30 days': [
      { label: 'W1', value: 45.2 },
      { label: 'W2', value: 68.4 },
      { label: 'W3', value: 82.1 },
      { label: 'W4', value: 112.8 },
    ],
    '90 days': [
      { label: 'Jun', value: 180.5 },
      { label: 'Jul', value: 240.2 },
      { label: 'Aug', value: 310.8 },
    ],
    '12 months': [
      { label: 'Q1', value: 420.0 },
      { label: 'Q2', value: 580.4 },
      { label: 'Q3', value: 740.1 },
      { label: 'Q4', value: 920.5 },
    ]
  };

  const currentData = chartDatasets[timeRange] || chartDatasets['7 days'];
  const maxValue = Math.max(...currentData.map(d => d.value)) * 1.25;

  // Compute SVG Path points for smooth aesthetic spline
  const svgWidth = 620;
  const svgHeight = 180;
  const paddingX = 40;
  const paddingY = 20;

  const points = currentData.map((d, index) => {
    const x = paddingX + (index / (currentData.length - 1)) * (svgWidth - paddingX * 2);
    const y = svgHeight - paddingY - (d.value / maxValue) * (svgHeight - paddingY * 2);
    return { ...d, x, y };
  });

  // Build SVG path
  const pathD = points.reduce((acc, point, i, arr) => {
    if (i === 0) return `M ${point.x} ${point.y}`;
    const prev = arr[i - 1];
    const cp1x = prev.x + (point.x - prev.x) / 2;
    const cp1y = prev.y;
    const cp2x = prev.x + (point.x - prev.x) / 2;
    const cp2y = point.y;
    return `${acc} C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${point.x} ${point.y}`;
  }, '');

  const areaD = `${pathD} L ${points[points.length - 1].x} ${svgHeight - paddingY} L ${points[0].x} ${svgHeight - paddingY} Z`;

  const pendingApprovalsCount = approvals.filter(a => a.status === 'Pending').length;

  return (
    <div className="space-y-6 pb-12 text-slate-100">
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <span>Good afternoon, {currentUser.name.split(' ')[0]}</span>
            <span className="w-2 h-2 rounded-full bg-amber-400"></span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5 font-mono">
            Direct institutional clearing network · RhinoBank Payment Operations Desk
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsSendPaymentOpen(true)}
            className="px-4 py-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-mono font-bold text-xs rounded-lg shadow-sm flex items-center gap-2 transition-all"
          >
            <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
            <span>Send Payment</span>
          </button>
        </div>
      </div>

      {/* TOP SUMMARY BENTO CARDS: Payments Today / Incoming / Outgoing / Net */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Payments Today */}
        <div className="bento-card p-4 space-y-2 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl group-hover:bg-amber-500/10 transition-all pointer-events-none" />
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-slate-400">Payments Today</span>
            <div className="w-7 h-7 rounded-lg bg-amber-400/10 text-amber-400 flex items-center justify-center border border-amber-400/20">
              <Activity className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold font-mono tracking-tight text-white tabular-nums">
              £18.42m
            </div>
            <div className="text-[11px] font-mono text-emerald-400 flex items-center gap-1 mt-1 font-medium">
              <ArrowUpRight className="w-3 h-3" />
              <span>12.6% vs yesterday</span>
            </div>
          </div>
        </div>

        {/* Incoming */}
        <div className="bento-card p-4 space-y-2 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl group-hover:bg-emerald-500/10 transition-all pointer-events-none" />
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-slate-400">Incoming</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/20">
              <ArrowDownLeft className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold font-mono tracking-tight text-white tabular-nums">
              £11.87m
            </div>
            <div className="text-[11px] font-mono text-emerald-400 flex items-center gap-1 mt-1 font-medium">
              <ArrowUpRight className="w-3 h-3" />
              <span>8.4% vs yesterday</span>
            </div>
          </div>
        </div>

        {/* Outgoing */}
        <div className="bento-card p-4 space-y-2 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-slate-400">Outgoing</span>
            <div className="w-7 h-7 rounded-lg bg-slate-800 text-slate-300 flex items-center justify-center border border-slate-700">
              <ArrowUpRight className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold font-mono tracking-tight text-white tabular-nums">
              £6.55m
            </div>
            <div className="text-[11px] font-mono text-slate-400 flex items-center gap-1 mt-1 font-medium">
              <ArrowUpRight className="w-3 h-3 text-slate-500" />
              <span>4.2% vs yesterday</span>
            </div>
          </div>
        </div>

        {/* Net Position */}
        <div className="bento-card p-4 space-y-2 relative overflow-hidden group border-amber-500/30">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-amber-400/90">Net Position</span>
            <div className="w-7 h-7 rounded-lg bg-amber-400/10 text-amber-400 flex items-center justify-center border border-amber-400/30">
              <TrendingUp className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold font-mono tracking-tight text-amber-300 tabular-nums">
              + £5.32m
            </div>
            <div className="text-[11px] font-mono text-emerald-400 flex items-center gap-1 mt-1 font-medium">
              <ArrowUpRight className="w-3 h-3" />
              <span>15.8% vs yesterday</span>
            </div>
          </div>
        </div>
      </div>

      {/* MAIN ROW: Interactive Payment Volume Chart & Payment Activity Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Payment Volume Interactive Chart (2 cols) */}
        <div className="lg:col-span-2 bento-card p-5 flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
            <div>
              <h3 className="font-bold text-white text-sm">Payment Volume</h3>
              <p className="text-[11px] text-slate-400 font-mono">Gross aggregate institutional clearing value (£m)</p>
            </div>

            {/* Time Range Selector */}
            <div className="flex items-center gap-1 bg-[#0D0F15] p-1 rounded-lg border border-[#202738]">
              {(['Today', '7 days', '30 days', '90 days', '12 months'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setTimeRange(r)}
                  className={`px-2.5 py-1 text-xs font-mono font-medium rounded-md transition-all ${
                    timeRange === r
                      ? 'bg-amber-400 text-slate-950 font-bold shadow-xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          {/* SVG Chart Area */}
          <div className="relative w-full overflow-hidden pt-2">
            <svg 
              viewBox={`0 0 ${svgWidth} ${svgHeight}`} 
              className="w-full h-48 overflow-visible"
            >
              <defs>
                <linearGradient id="goldBentoGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.35" />
                  <stop offset="100%" stopColor="#f59e0b" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Horizontal Grid lines */}
              {[0, 0.25, 0.5, 0.75, 1].map((ratio, idx) => {
                const y = svgHeight - paddingY - ratio * (svgHeight - paddingY * 2);
                const val = (ratio * maxValue).toFixed(0);
                return (
                  <g key={idx}>
                    <line 
                      x1={paddingX} 
                      y1={y} 
                      x2={svgWidth - paddingX} 
                      y2={y} 
                      stroke="#222838" 
                      strokeDasharray="4 4"
                    />
                    <text 
                      x={paddingX - 10} 
                      y={y + 3} 
                      fill="#64748b" 
                      fontSize="9" 
                      fontFamily="JetBrains Mono" 
                      textAnchor="end"
                    >
                      £{val}m
                    </text>
                  </g>
                );
              })}

              {/* Area Fill */}
              <path d={areaD} fill="url(#goldBentoGradient)" />

              {/* Line Stroke */}
              <path 
                d={pathD} 
                fill="none" 
                stroke="#fbbf24" 
                strokeWidth="2.5" 
                strokeLinecap="round" 
              />

              {/* Interactive Data Points */}
              {points.map((pt, idx) => {
                const isHovered = hoveredPoint?.day === pt.label;
                const isPeak = pt.value === Math.max(...currentData.map(d => d.value));

                return (
                  <g key={idx}>
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r={isHovered ? 6 : isPeak ? 4.5 : 3.5}
                      fill="#0A0A0A"
                      stroke="#fbbf24"
                      strokeWidth={isHovered ? 3 : 2}
                      className="cursor-pointer transition-all duration-150"
                      onMouseEnter={() => setHoveredPoint({ day: pt.label, value: pt.value, x: pt.x, y: pt.y })}
                      onMouseLeave={() => setHoveredPoint(null)}
                    />
                    <text
                      x={pt.x}
                      y={svgHeight - 4}
                      fill="#94a3b8"
                      fontSize="10"
                      fontFamily="JetBrains Mono"
                      textAnchor="middle"
                    >
                      {pt.label}
                    </text>
                  </g>
                );
              })}
            </svg>

            {/* Hover Tooltip */}
            {hoveredPoint && (
              <div 
                className="absolute bg-[#1B2130] text-white px-2.5 py-1.5 rounded-lg text-[11px] font-mono shadow-2xl border border-amber-400/40 pointer-events-none transform -translate-x-1/2 -translate-y-full mb-2 z-10 animate-in fade-in zoom-in-95 duration-100"
                style={{ left: `${(hoveredPoint.x / svgWidth) * 100}%`, top: `${(hoveredPoint.y / svgHeight) * 100}%` }}
              >
                <div className="text-[9px] text-slate-400 uppercase">{hoveredPoint.day}</div>
                <div className="font-bold text-amber-400">£{hoveredPoint.value.toFixed(2)}m</div>
              </div>
            )}
          </div>
        </div>

        {/* Payment Activity Live Feed (1 col) */}
        <div className="bento-card p-5 flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-white text-sm">Payment Activity</h3>
            <button
              onClick={() => setActiveTab('payments-all')}
              className="text-[11px] font-mono text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1"
            >
              View all
            </button>
          </div>

          <div className="space-y-2.5 flex-1 overflow-y-auto max-h-[260px] pr-1">
            {payments.slice(0, 5).map((p) => {
              const isCompleted = p.status === 'Completed';
              const isProcessing = p.status === 'Processing';
              const isHeld = p.status === 'Held';

              return (
                <div
                  key={p.id}
                  onClick={() => setSelectedPayment(p)}
                  className="p-2.5 rounded-lg border border-[#202738] bg-[#0E1119] hover:border-amber-400/50 hover:bg-[#141824] transition-all cursor-pointer flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <div 
                      className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                        isCompleted 
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40' 
                          : isProcessing 
                          ? 'bg-amber-950/60 text-amber-400 border border-amber-800/40 animate-pulse' 
                          : isHeld 
                          ? 'bg-rose-950/60 text-rose-400 border border-rose-800/40' 
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      ) : isProcessing ? (
                        <Clock className="w-3.5 h-3.5" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5" />
                      )}
                    </div>

                    <div>
                      <div className="font-mono font-bold text-xs text-white group-hover:text-amber-400 transition-colors">
                        £{p.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                        <span className="truncate max-w-[110px]">{p.counterparty}</span>
                        <span>→</span>
                        <span className="truncate max-w-[80px]">{p.counterpartyBank.split(' ')[0]}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span 
                      className={`text-[10px] font-mono font-semibold block ${
                        isCompleted ? 'text-emerald-400' : isProcessing ? 'text-amber-400' : isHeld ? 'text-rose-400' : 'text-slate-400'
                      }`}
                    >
                      {p.status}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {p.createdDate.split(',')[1]?.trim() || '14:42'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-3 border-t border-[#202738] mt-2">
            <button
              onClick={() => setActiveTab('payments-all')}
              className="w-full text-center text-xs font-semibold text-slate-400 hover:text-amber-400 flex items-center justify-center gap-1 py-1 transition-colors"
            >
              <span>View all payments</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* SECOND ROW: Account Balances (1.5 col) + Treasury Cash Position (1.5 col) + Risk Overview (1 col) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Account balances */}
        <div className="bento-card p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-white text-sm">Account balances</h3>
            <button
              onClick={() => setActiveTab('accounts-banks')}
              className="text-[11px] font-mono text-amber-400 hover:text-amber-300 font-semibold"
            >
              View all
            </button>
          </div>

          <div className="space-y-3 divide-y divide-[#202738] flex-1">
            {accounts.slice(0, 4).map((acc) => (
              <div key={acc.id} className="pt-2.5 first:pt-0 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-6 h-6 rounded bg-[#1A202E] border border-[#2B3347] flex items-center justify-center text-[10px] font-bold font-mono text-slate-200">
                    {acc.currency === 'GBP' ? '🇬🇧' : acc.currency === 'USD' ? '🇺🇸' : acc.currency === 'EUR' ? '🇪🇺' : '🇨🇭'}
                  </div>
                  <div>
                    <div className="font-bold text-xs text-white">{acc.name}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{acc.accountNumber}</div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-bold font-mono text-xs text-white">
                    {acc.currency === 'GBP' ? '£' : acc.currency === 'USD' ? '$' : acc.currency === 'EUR' ? '€' : 'CHF '}
                    {acc.availableBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </div>
                  <span className="text-[10px] text-emerald-400 font-mono">Available</span>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-[#202738] mt-2">
            <button
              onClick={() => setActiveTab('accounts-banks')}
              className="text-xs font-semibold text-slate-400 hover:text-amber-400 flex items-center gap-1 transition-colors"
            >
              <span>View all accounts</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Treasury — Cash Position */}
        <div className="bento-card p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="font-bold text-white text-sm">Treasury – Cash position</h3>
              <p className="text-[10px] text-slate-400 font-mono">£67.42m Total liquidity</p>
            </div>
            <button
              onClick={() => setActiveTab('treasury-cash')}
              className="text-[11px] font-mono text-amber-400 hover:text-amber-300 font-semibold"
            >
              View full dashboard
            </button>
          </div>

          <div className="flex items-center gap-4 flex-1">
            {/* Liquidity breakdown table */}
            <div className="space-y-1.5 flex-1 text-xs font-mono">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded-sm bg-emerald-400" />
                  Available
                </span>
                <span className="font-bold text-white">£42.80m</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded-sm bg-blue-500" />
                  Committed
                </span>
                <span className="font-bold text-white">£14.20m</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded-sm bg-amber-400" />
                  Reserved
                </span>
                <span className="font-bold text-white">£6.42m</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded-sm bg-indigo-400" />
                  Intraday
                </span>
                <span className="font-bold text-white">£4.82m</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded-sm bg-purple-400" />
                  Settlement
                </span>
                <span className="font-bold text-white">£-0.82m</span>
              </div>
            </div>

            {/* Circular Donut Diagram */}
            <div className="relative w-28 h-28 shrink-0 flex items-center justify-center">
              <svg viewBox="0 0 36 36" className="w-full h-full transform -rotate-90">
                <circle cx="18" cy="18" r="14" fill="none" stroke="#10b981" strokeWidth="4.5" strokeDasharray="63 100" strokeDashoffset="0" />
                <circle cx="18" cy="18" r="14" fill="none" stroke="#3b82f6" strokeWidth="4.5" strokeDasharray="21 100" strokeDashoffset="-63" />
                <circle cx="18" cy="18" r="14" fill="none" stroke="#f59e0b" strokeWidth="4.5" strokeDasharray="9 100" strokeDashoffset="-84" />
                <circle cx="18" cy="18" r="14" fill="none" stroke="#818cf8" strokeWidth="4.5" strokeDasharray="7 100" strokeDashoffset="-93" />
              </svg>
              <div className="absolute text-center">
                <div className="font-bold font-mono text-[11px] text-white leading-tight">£67.42m</div>
                <div className="text-[8px] font-mono text-slate-400 uppercase">Total</div>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-[#202738] mt-2">
            <button
              onClick={() => setActiveTab('treasury-cash')}
              className="text-xs font-semibold text-slate-400 hover:text-amber-400 flex items-center gap-1 transition-colors"
            >
              <span>View treasury</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Risk Overview */}
        <div className="bento-card p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-white text-sm">Risk overview</h3>
            <button
              onClick={() => setActiveTab('risk-fraud')}
              className="text-[11px] font-mono text-amber-400 hover:text-amber-300 font-semibold"
            >
              View all
            </button>
          </div>

          <div className="space-y-2 flex-1 text-xs">
            <div className="flex items-center justify-between text-slate-300">
              <span>Transactions monitored (24h)</span>
              <span className="font-bold font-mono text-white">12,842</span>
            </div>
            <div className="flex items-center justify-between text-slate-300">
              <span>High risk alerts</span>
              <span className="font-bold font-mono text-rose-400">23</span>
            </div>
            <div className="flex items-center justify-between text-slate-300">
              <span>Blocked</span>
              <span className="font-bold font-mono text-rose-500">5</span>
            </div>
            <div className="flex items-center justify-between text-slate-300">
              <span>Held</span>
              <span className="font-bold font-mono text-amber-400">18</span>
            </div>
            <div className="flex items-center justify-between text-slate-300">
              <span>Released</span>
              <span className="font-bold font-mono text-emerald-400">45</span>
            </div>

            {/* Risk Gauge Bar */}
            <div className="pt-2 flex items-center justify-between">
              <div className="flex items-center gap-3 text-[10px] font-mono">
                <span className="flex items-center gap-1 text-emerald-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  Low 94.7%
                </span>
                <span className="flex items-center gap-1 text-amber-400">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  Med 3.8%
                </span>
                <span className="flex items-center gap-1 text-rose-400">
                  <span className="w-2 h-2 rounded-full bg-rose-400" />
                  High 1.2%
                </span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-[#202738] mt-2">
            <button
              onClick={() => setActiveTab('risk-fraud')}
              className="text-xs font-semibold text-slate-400 hover:text-amber-400 flex items-center gap-1 transition-colors"
            >
              <span>View risk dashboard</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* QUICK ACTIONS BENTO ROW */}
      <div className="bento-card p-5">
        <h3 className="font-bold text-white text-sm mb-4">Quick actions</h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {[
            { id: 'send', label: 'Send Payment', icon: ArrowUpRight, action: () => setIsSendPaymentOpen(true) },
            { id: 'invoice', label: 'Create Invoice', icon: FileText, action: () => setActiveTab('collections-invoices') },
            { id: 'link', label: 'Payment Link', icon: LinkIcon, action: () => setActiveTab('payments-links') },
            { id: 'fx', label: 'FX Trade', icon: ArrowLeftRight, action: () => setActiveTab('treasury-fx') },
            { id: 'transfer', label: 'Account Transfer', icon: Layers, action: () => setActiveTab('accounts-banks') },
            { id: 'customer', label: 'New Customer', icon: Users, action: () => setActiveTab('accounts-customers') },
            { id: 'reports', label: 'Reports', icon: FileSpreadsheet, action: () => setActiveTab('reports') },
            { id: 'approvals', label: 'Approvals', icon: Lock, badge: pendingApprovalsCount, action: () => setActiveTab('payments-approvals') },
          ].map((act) => {
            const Icon = act.icon;
            return (
              <button
                key={act.id}
                onClick={act.action}
                className="relative p-3 rounded-xl border border-[#202738] bg-[#0E1119] hover:border-amber-400 hover:bg-[#151926] text-slate-300 hover:text-amber-400 flex flex-col items-center justify-center text-center gap-2 transition-all group"
              >
                {act.badge && act.badge > 0 ? (
                  <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-amber-400 text-slate-950 font-mono font-bold text-[9px] flex items-center justify-center">
                    {act.badge}
                  </span>
                ) : null}
                <div className="w-8 h-8 rounded-lg bg-[#181D2B] group-hover:bg-amber-400 group-hover:text-slate-950 text-slate-300 flex items-center justify-center transition-all">
                  <Icon className="w-4 h-4" />
                </div>
                <span className="text-[11px] font-medium leading-tight">{act.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
