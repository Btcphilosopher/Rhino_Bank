import React from 'react';
import { useBanking } from '../../context/BankingContext';
import { RefreshCw, Calendar, CheckCircle2, Pause, Play, ArrowUpRight } from 'lucide-react';

export const RecurringPaymentsView: React.FC = () => {
  const { recurringSchedules } = useBanking();

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Recurring Payments & Standing Mandates</h1>
          <p className="text-xs text-slate-500 font-mono">
            Automated institutional schedules · Direct Debit & automated clearing runs
          </p>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-mono text-[11px] uppercase tracking-wider">
                <th className="py-3 px-4 font-semibold">Mandate Ref / ID</th>
                <th className="py-3 px-4 font-semibold">Beneficiary Counterparty</th>
                <th className="py-3 px-4 font-semibold">Frequency</th>
                <th className="py-3 px-4 font-semibold">Next Scheduled Run</th>
                <th className="py-3 px-4 font-semibold text-right">Recurring Amount</th>
                <th className="py-3 px-4 font-semibold text-right">Total Disbursed</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {recurringSchedules.map((rec) => (
                <tr key={rec.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-bold font-mono text-slate-900">{rec.mandateReference}</div>
                    <div className="text-[10px] text-slate-400 font-mono">ID: {rec.id}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-900">{rec.counterparty}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{rec.counterpartyAccount}</div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded bg-slate-100 font-mono text-[11px] text-slate-700 font-medium">
                      {rec.frequency}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-700">
                    {rec.nextExecutionDate}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                    £{rec.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} {rec.currency}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-slate-600">
                    £{rec.totalDisbursed.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                      rec.status === 'Active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {rec.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
