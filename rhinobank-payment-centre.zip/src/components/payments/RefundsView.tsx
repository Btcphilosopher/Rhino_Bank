import React from 'react';
import { useBanking } from '../../context/BankingContext';
import { RotateCcw, CheckCircle2, ShieldCheck, ArrowDownLeft } from 'lucide-react';

export const RefundsView: React.FC = () => {
  const { refunds } = useBanking();

  const totalRefunded = refunds.reduce((acc, r) => acc + r.amount, 0);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Refunds & Reversals</h1>
          <p className="text-xs text-slate-500 font-mono">
            Cryptographically audited ledger reversals · Direct debit and credit reconciliation
          </p>
        </div>
      </div>

      {/* Metrics Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Total Settled Reversals</span>
          <div className="text-xl font-bold font-mono text-slate-900">£{totalRefunded.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Active Refund Cases</span>
          <div className="text-xl font-bold font-mono text-slate-900">{refunds.length}</div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Average Turnaround</span>
          <div className="text-xl font-bold font-mono text-emerald-700">&lt; 4 minutes</div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-mono text-[11px] uppercase tracking-wider">
                <th className="py-3 px-4 font-semibold">Refund ID / Date</th>
                <th className="py-3 px-4 font-semibold">Original Payment ID</th>
                <th className="py-3 px-4 font-semibold">Beneficiary Counterparty</th>
                <th className="py-3 px-4 font-semibold">Reason Category</th>
                <th className="py-3 px-4 font-semibold">Authorised By</th>
                <th className="py-3 px-4 font-semibold text-right">Refund Amount</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {refunds.map((ref) => (
                <tr key={ref.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-bold font-mono text-slate-900">{ref.id}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{ref.createdDate}</div>
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-amber-600">
                    {ref.paymentId}
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-800">
                    {ref.counterparty}
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded bg-slate-100 font-mono text-[10px] text-slate-700">
                      {ref.reason}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-600">
                    {ref.approvedBy}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-rose-700">
                    -£{ref.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} {ref.currency}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                      {ref.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
