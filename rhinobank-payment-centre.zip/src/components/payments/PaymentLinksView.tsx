import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  Link as LinkIcon, 
  Plus, 
  Copy, 
  Check, 
  ExternalLink, 
  TrendingUp, 
  MousePointerClick, 
  DollarSign, 
  X,
  CreditCard,
  QrCode
} from 'lucide-react';
import { PaymentLink, Currency } from '../../types/banking';

export const PaymentLinksView: React.FC = () => {
  const { paymentLinks, createPaymentLink } = useBanking();

  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState<Currency>('GBP');
  const [description, setDescription] = useState('');

  const totalCollected = paymentLinks.reduce((acc, l) => acc + l.revenue, 0);
  const totalClicks = paymentLinks.reduce((acc, l) => acc + l.clicks, 0);
  const totalCompleted = paymentLinks.reduce((acc, l) => acc + l.completedCount, 0);
  const avgConversion = totalClicks > 0 ? ((totalCompleted / totalClicks) * 100).toFixed(1) : '0.0';

  const handleCopyLink = (url: string, id: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !amount) return;
    createPaymentLink({
      title,
      amount: parseFloat(amount),
      currency,
      description
    });
    setIsCreateModalOpen(false);
    setTitle('');
    setAmount('');
    setDescription('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Payment Links</h1>
          <p className="text-xs text-slate-500 font-mono">
            Hostless institutional checkouts · Real-time escrow & settlement URLs
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-mono text-xs font-semibold rounded-md shadow-xs transition-colors flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4 text-amber-400" />
          Create Payment Link
        </button>
      </div>

      {/* Metrics Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Total Revenue Collected</span>
          <div className="text-xl font-bold font-mono text-slate-900">£{totalCollected.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Total Unique Clicks</span>
          <div className="text-xl font-bold font-mono text-slate-900">{totalClicks}</div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Completed Payments</span>
          <div className="text-xl font-bold font-mono text-emerald-700">{totalCompleted}</div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Conversion Rate</span>
          <div className="text-xl font-bold font-mono text-blue-600">{avgConversion}%</div>
        </div>
      </div>

      {/* Links List */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-mono text-[11px] uppercase tracking-wider">
                <th className="py-3 px-4 font-semibold">Title & Description</th>
                <th className="py-3 px-4 font-semibold">Unit Price</th>
                <th className="py-3 px-4 font-semibold">URL / Hosted Link</th>
                <th className="py-3 px-4 font-semibold text-center">Clicks</th>
                <th className="py-3 px-4 font-semibold text-center">Settled</th>
                <th className="py-3 px-4 font-semibold text-right">Gross Collected</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paymentLinks.map((link) => (
                <tr key={link.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-bold text-slate-900">{link.title}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{link.description || 'Institutional direct payment link'}</div>
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-800">
                    £{link.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} {link.currency}
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1.5 bg-slate-100 px-2 py-1 rounded font-mono text-[10px] text-slate-600 max-w-xs truncate">
                      <span className="truncate">{link.url}</span>
                      <button
                        onClick={() => handleCopyLink(link.url, link.id)}
                        className="p-1 hover:text-slate-900 rounded shrink-0"
                        title="Copy URL"
                      >
                        {copiedId === link.id ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                      </button>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-center font-mono text-slate-600">{link.clicks}</td>
                  <td className="py-3 px-4 text-center font-mono text-emerald-700 font-bold">{link.completedCount}</td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                    £{link.revenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                      {link.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md rounded-xl shadow-2xl border border-slate-200 p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <LinkIcon className="w-4 h-4 text-amber-500" />
                Create Institutional Payment Link
              </div>
              <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Link Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Q3 Prime Retainer Deposit"
                  className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono text-xs focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Fixed Amount</label>
                  <input
                    type="number"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="42850.00"
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono text-xs focus:ring-1 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Currency</label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as Currency)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md text-xs bg-white"
                  >
                    <option value="GBP">GBP (£)</option>
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="CHF">CHF</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Description / Memo</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Description presented to customer upon opening checkout link..."
                  rows={2}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-md font-mono transition-colors"
                >
                  Generate & Activate Link
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
