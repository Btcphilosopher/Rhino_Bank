import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  X, 
  ArrowUpRight, 
  CheckCircle2, 
  Building2, 
  ShieldCheck, 
  Clock, 
  Search, 
  CreditCard, 
  Lock, 
  HelpCircle,
  AlertTriangle,
  ArrowRight
} from 'lucide-react';
import { Currency, PaymentPriority } from '../../types/banking';
import confetti from 'canvas-confetti';

export const SendPaymentModal: React.FC = () => {
  const { isSendPaymentOpen, setIsSendPaymentOpen, sendPayment, customers, accounts, currentUser } = useBanking();

  const [step, setStep] = useState<number>(1);
  const [recipientSearch, setRecipientSearch] = useState('');
  const [selectedRecipient, setSelectedRecipient] = useState<any>(null);
  
  // Custom counterparty inputs
  const [customName, setCustomName] = useState('');
  const [customBank, setCustomBank] = useState('');
  const [customAccount, setCustomAccount] = useState('');
  const [customSortCode, setCustomSortCode] = useState('');

  // Step 2
  const [amount, setAmount] = useState<string>('42850.00');
  const [currency, setCurrency] = useState<Currency>('GBP');
  const [fromAccount, setFromAccount] = useState<string>('GBP Operating Account');

  // Step 3
  const [reference, setReference] = useState<string>('INV-2026-1842');
  const [invoiceNumber, setInvoiceNumber] = useState<string>('RH-2026-1842');
  const [purpose, setPurpose] = useState<string>('Institutional commercial supplier settlement');
  const [priority, setPriority] = useState<PaymentPriority>('Instant Faster Payments');

  // Step 5 loading / success
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [completedPayment, setCompletedPayment] = useState<any>(null);

  if (!isSendPaymentOpen) return null;

  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(recipientSearch.toLowerCase()) ||
    c.industry.toLowerCase().includes(recipientSearch.toLowerCase())
  );

  const numAmount = parseFloat(amount) || 0;
  const isHighValue = numAmount >= 100000;
  const fee = priority === 'CHAPS High Value' ? 15.00 : 0.00;
  const totalAmount = numAmount + fee;

  const handleSelectCustomer = (customer: any) => {
    setSelectedRecipient(customer);
    setCustomName(customer.name);
    setCustomBank('RhinoBank Direct Clearing');
    setCustomAccount('•••• 9012');
    setCustomSortCode('20-00-99');
    setStep(2);
  };

  const handleCustomRecipientNext = () => {
    if (!customName) return;
    setSelectedRecipient({
      name: customName,
      industry: 'External Counterparty',
      legalName: customName
    });
    setStep(2);
  };

  const handleExecutePayment = async () => {
    setIsSubmitting(true);
    try {
      const p = await sendPayment({
        counterparty: customName || selectedRecipient?.name || 'Institutional Beneficiary',
        counterpartyBank: customBank || 'Barclays Bank UK',
        counterpartyAccount: customAccount || '•••• 8820',
        counterpartySortCode: customSortCode || '20-04-12',
        amount: numAmount,
        currency,
        fromAccountName: fromAccount,
        reference: reference || 'INV-2026',
        priority,
        purpose,
        invoiceNumber
      });

      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.6 }
      });

      setCompletedPayment(p);
      setStep(5);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setIsSendPaymentOpen(false);
    // Reset state after close
    setTimeout(() => {
      setStep(1);
      setCompletedPayment(null);
      setSelectedRecipient(null);
      setRecipientSearch('');
    }, 200);
  };

  const currencySymbol = {
    GBP: '£',
    USD: '$',
    EUR: '€',
    CHF: 'CHF ',
    JPY: '¥'
  }[currency] || '£';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-2xl rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-[#0c1017] text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
            </div>
            <div>
              <h2 className="font-bold text-sm font-mono tracking-wide text-white">RHINOBANK PAYMENT DISPATCH</h2>
              <p className="text-[11px] text-amber-400/90 font-mono">Institutional Faster Payments & RTGS Clearing</p>
            </div>
          </div>

          <button onClick={handleClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Bar */}
        {step < 5 && (
          <div className="px-6 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-[11px] font-mono font-medium">
            <div className="flex items-center gap-4 text-slate-500">
              <span className={step === 1 ? 'text-amber-600 font-bold' : step > 1 ? 'text-emerald-600 font-semibold' : ''}>
                1. Recipient
              </span>
              <span>→</span>
              <span className={step === 2 ? 'text-amber-600 font-bold' : step > 2 ? 'text-emerald-600 font-semibold' : ''}>
                2. Amount
              </span>
              <span>→</span>
              <span className={step === 3 ? 'text-amber-600 font-bold' : step > 3 ? 'text-emerald-600 font-semibold' : ''}>
                3. Reference
              </span>
              <span>→</span>
              <span className={step === 4 ? 'text-amber-600 font-bold' : ''}>
                4. Review & Authorise
              </span>
            </div>
            <span className="text-slate-400">Step {step} of 4</span>
          </div>
        )}

        {/* Step Content */}
        <div className="p-6 overflow-y-auto flex-1 text-xs">
          {/* STEP 1: RECIPIENT */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <h3 className="font-bold text-slate-900 text-sm mb-1">Step 1: Who are you paying?</h3>
                <p className="text-slate-500 text-[11px]">Select from authenticated institutional counterparties or enter new bank coordinates.</p>
              </div>

              {/* Search bar */}
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={recipientSearch}
                  onChange={(e) => setRecipientSearch(e.target.value)}
                  placeholder="Search recipient (Northbridge, Meridian, Aureom, Yorkshire)..."
                  className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-amber-500 bg-slate-50/50"
                />
              </div>

              {/* Counterparty list */}
              <div className="border border-slate-200 rounded-lg divide-y divide-slate-100 max-h-48 overflow-y-auto">
                {filteredCustomers.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => handleSelectCustomer(c)}
                    className="w-full p-3 flex items-center justify-between text-left hover:bg-amber-50/60 transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded bg-slate-100 group-hover:bg-amber-100 text-slate-700 group-hover:text-amber-800 flex items-center justify-center font-bold font-mono">
                        {c.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-bold text-slate-900 text-xs">{c.name}</div>
                        <div className="text-slate-500 font-mono text-[10px]">{c.industry} · {c.tier}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-mono font-semibold text-slate-700 block">
                        Limit: £{(c.paymentDailyLimit / 1000000).toFixed(0)}m
                      </span>
                      <span className="text-[10px] text-emerald-600 font-mono">KYC Verified</span>
                    </div>
                  </button>
                ))}
              </div>

              {/* Or manual entry */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
                <div className="text-[11px] font-mono font-bold uppercase text-slate-500">Or Enter New Counterparty Coordinates</div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Company / Beneficiary Name</label>
                    <input
                      type="text"
                      value={customName}
                      onChange={(e) => setCustomName(e.target.value)}
                      placeholder="e.g. Northbridge Engineering Ltd"
                      className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white font-mono text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Beneficiary Bank</label>
                    <input
                      type="text"
                      value={customBank}
                      onChange={(e) => setCustomBank(e.target.value)}
                      placeholder="e.g. HSBC UK plc"
                      className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white font-mono text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Sort Code</label>
                    <input
                      type="text"
                      value={customSortCode}
                      onChange={(e) => setCustomSortCode(e.target.value)}
                      placeholder="40-12-88"
                      className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white font-mono text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Account Number / IBAN</label>
                    <input
                      type="text"
                      value={customAccount}
                      onChange={(e) => setCustomAccount(e.target.value)}
                      placeholder="12345678 or GB82 RHIN..."
                      className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white font-mono text-xs"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    onClick={handleCustomRecipientNext}
                    disabled={!customName}
                    className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-semibold rounded text-xs font-mono transition-colors"
                  >
                    Proceed with Custom Recipient →
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: AMOUNT & CURRENCY */}
          {step === 2 && (
            <div className="space-y-4">
              <div>
                <h3 className="font-bold text-slate-900 text-sm mb-1">Step 2: Amount & Currency</h3>
                <p className="text-slate-500 text-[11px]">Select funding account, transfer volume and currency denomination.</p>
              </div>

              {/* Funding Account Picker */}
              <div>
                <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Debit From RhinoBank Account</label>
                <select
                  value={fromAccount}
                  onChange={(e) => setFromAccount(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-amber-500"
                >
                  {accounts.map((acc) => (
                    <option key={acc.id} value={acc.name}>
                      {acc.name} — Available: {acc.currency} {acc.availableBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </option>
                  ))}
                </select>
              </div>

              {/* Amount and Currency */}
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Transfer Amount</label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 font-bold font-mono text-slate-400 text-sm">{currencySymbol}</span>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="42850.00"
                      className="w-full pl-8 pr-3 py-2.5 border border-slate-300 rounded-lg font-mono font-bold text-base focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Currency</label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as Currency)}
                    className="w-full px-3 py-2.5 border border-slate-300 rounded-lg font-mono font-bold text-xs bg-white focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="GBP">GBP — £ Sterling</option>
                    <option value="USD">USD — $ US Dollar</option>
                    <option value="EUR">EUR — € Euro</option>
                    <option value="CHF">CHF — Swiss Franc</option>
                    <option value="JPY">JPY — ¥ Japanese Yen</option>
                  </select>
                </div>
              </div>

              {/* Quick Amount presets */}
              <div className="flex items-center gap-2 pt-1">
                <span className="text-[10px] font-mono text-slate-400 uppercase">Presets:</span>
                {['8400.00', '42850.00', '74200.00', '125000.00', '850000.00'].map((preset) => (
                  <button
                    key={preset}
                    onClick={() => setAmount(preset)}
                    className="px-2 py-1 bg-slate-100 hover:bg-amber-100 hover:text-amber-900 border border-slate-200 rounded font-mono text-[10px]"
                  >
                    {currencySymbol}{parseFloat(preset).toLocaleString()}
                  </button>
                ))}
              </div>

              {/* Dual-approval warning threshold check */}
              {isHighValue && (
                <div className="p-3 bg-amber-50 border border-amber-300 rounded-lg flex items-start gap-2.5 text-amber-900 text-[11px]">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <strong>Dual Authorisation Mandatory:</strong> Payments of £100,000 or greater require 2-person signoff (Treasurer + Head of Prime Banking / Chief Risk Officer) before clearing execution.
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 3: REFERENCE & PRIORITY */}
          {step === 3 && (
            <div className="space-y-4">
              <div>
                <h3 className="font-bold text-slate-900 text-sm mb-1">Step 3: Reference & Clearing Rail</h3>
                <p className="text-slate-500 text-[11px]">Specify remittance identifiers and settlement rail priority.</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Payment Reference</label>
                  <input
                    type="text"
                    value={reference}
                    onChange={(e) => setReference(e.target.value)}
                    placeholder="INV-2026-1842"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Associated Invoice # (Optional)</label>
                  <input
                    type="text"
                    value={invoiceNumber}
                    onChange={(e) => setInvoiceNumber(e.target.value)}
                    placeholder="RH-2026-1842"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Purpose of Payment / Compliance Memo</label>
                <input
                  type="text"
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  placeholder="e.g. Q3 Structural components invoice settlement"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-amber-500"
                />
              </div>

              {/* Rail Selection */}
              <div>
                <label className="block text-slate-600 font-mono text-[10px] uppercase font-bold mb-1">Clearing Priority & Rail</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'Instant Faster Payments', label: 'Instant Faster Payments (FPS)', sub: 'Instant (<15s) · £0.00 fee' },
                    { id: 'CHAPS High Value', label: 'CHAPS Same-Day RTGS', sub: 'Immediate RTGS · £15.00 fee' },
                    { id: 'SWIFT', label: 'SWIFT Global Cross-Border', sub: 'T+0/T+1 · Real-time tracking' },
                    { id: 'SEPA Enterprise', label: 'SEPA Instant Credit Transfer', sub: 'EUR direct clearing' },
                  ].map((r) => (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => setPriority(r.id as PaymentPriority)}
                      className={`p-2.5 rounded-lg border text-left transition-all ${
                        priority === r.id
                          ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      <div className="font-bold text-xs">{r.label}</div>
                      <div className={`text-[10px] font-mono ${priority === r.id ? 'text-amber-400' : 'text-slate-400'}`}>
                        {r.sub}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: REVIEW */}
          {step === 4 && (
            <div className="space-y-4">
              <div>
                <h3 className="font-bold text-slate-900 text-sm mb-1">Step 4: Review Payment Parameters</h3>
                <p className="text-slate-500 text-[11px]">Verify counterparty coordinates and clearing debit before cryptographic dispatch.</p>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <span className="text-slate-500 font-mono text-[10px] uppercase">From Account</span>
                  <span className="font-bold text-slate-900 font-mono">{fromAccount}</span>
                </div>

                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <span className="text-slate-500 font-mono text-[10px] uppercase">To Beneficiary</span>
                  <span className="font-bold text-slate-900">{customName || selectedRecipient?.name}</span>
                </div>

                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <span className="text-slate-500 font-mono text-[10px] uppercase">Principal Amount</span>
                  <span className="font-bold font-mono text-sm text-slate-950">
                    {currencySymbol}{numAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currency}
                  </span>
                </div>

                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <span className="text-slate-500 font-mono text-[10px] uppercase">Clearing Rail Fee</span>
                  <span className="font-mono text-xs text-slate-700">{currencySymbol}{fee.toFixed(2)}</span>
                </div>

                <div className="flex items-center justify-between pt-1 font-bold text-sm">
                  <span className="text-slate-900 font-mono uppercase text-xs">Total Settlement Debit</span>
                  <span className="font-mono text-amber-600 text-base">
                    {currencySymbol}{totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div className="p-3 bg-slate-900 text-white rounded-lg flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>
                    Authorization Mode: <strong>{isHighValue ? 'Two-Person Board Approval' : 'Single Officer Sign-off'}</strong>
                  </span>
                </div>
                <span className="text-[10px] font-mono text-amber-400">Authenticated: {currentUser.name}</span>
              </div>
            </div>
          )}

          {/* STEP 5: COMPLETED */}
          {step === 5 && completedPayment && (
            <div className="py-6 text-center space-y-4">
              <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto ring-8 ring-emerald-50">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  {completedPayment.status === 'Pending Approval' ? 'Payment Submitted for Approval' : 'Payment Successfully Settled'}
                </h3>
                <p className="text-slate-500 text-xs mt-1">
                  Bank Reference ID: <strong className="font-mono text-slate-900">{completedPayment.id}</strong>
                </p>
              </div>

              <div className="max-w-md mx-auto p-4 bg-slate-50 border border-slate-200 rounded-lg text-left text-xs space-y-1.5 font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-400">Beneficiary:</span>
                  <span className="font-bold text-slate-800">{completedPayment.counterparty}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Amount:</span>
                  <span className="font-bold text-slate-800">
                    {currencySymbol}{completedPayment.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} {completedPayment.currency}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Reference:</span>
                  <span className="text-slate-800">{completedPayment.reference}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Clearing Status:</span>
                  <span className={`font-bold ${completedPayment.status === 'Pending Approval' ? 'text-amber-600' : 'text-emerald-600'}`}>
                    {completedPayment.status}
                  </span>
                </div>
              </div>

              <div className="pt-4 flex items-center justify-center gap-3">
                <button
                  onClick={handleClose}
                  className="px-6 py-2 bg-slate-900 hover:bg-slate-800 text-white font-mono font-semibold rounded-lg text-xs transition-colors"
                >
                  Return to Dashboard
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer Navigation */}
        {step < 5 && (
          <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
            {step > 1 ? (
              <button
                type="button"
                onClick={() => setStep(step - 1)}
                className="px-3 py-1.5 text-slate-600 hover:bg-slate-200/70 rounded-md font-medium text-xs font-mono"
              >
                ← Back
              </button>
            ) : (
              <div />
            )}

            {step < 4 ? (
              <button
                type="button"
                onClick={() => setStep(step + 1)}
                disabled={step === 1 && !selectedRecipient && !customName}
                className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-semibold rounded-md text-xs font-mono transition-colors flex items-center gap-1.5"
              >
                Next Step →
              </button>
            ) : (
              <button
                type="button"
                onClick={handleExecutePayment}
                disabled={isSubmitting}
                className="px-5 py-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold rounded-md text-xs font-mono shadow-sm transition-all flex items-center gap-2 uppercase tracking-wide"
              >
                {isSubmitting ? (
                  <>
                    <span className="w-3 h-3 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                    Signing & Clearing...
                  </>
                ) : (
                  <>
                    <Lock className="w-3.5 h-3.5" />
                    Authorise Payment
                  </>
                )}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
