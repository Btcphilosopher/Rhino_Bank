import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  Lock, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Building2, 
  Clock, 
  ShieldCheck, 
  UserCheck, 
  Info,
  Check,
  X
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const ApprovalsView: React.FC = () => {
  const { approvals, approvePayment, rejectPayment, setSelectedPayment, currentUser } = useBanking();
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  const pendingApprovals = approvals.filter(a => a.status === 'Pending');
  const pastApprovals = approvals.filter(a => a.status !== 'Pending');

  const handleApprove = (approvalId: string) => {
    approvePayment(approvalId);
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.6 }
    });
  };

  const handleConfirmReject = (approvalId: string) => {
    if (!rejectReason) return;
    rejectPayment(approvalId, rejectReason);
    setRejectingId(null);
    setRejectReason('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Payment Approval Centre</h1>
        <p className="text-xs text-slate-500 font-mono">
          Dual-authorisation queue · Institutional threshold governance (Mandatory &gt;£100,000)
        </p>
      </div>

      {/* Governance Banner */}
      <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl flex items-start gap-3 text-xs">
        <ShieldCheck className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="font-bold text-amber-900">Four-Eyes Governance Policy Enforced</div>
          <p className="text-amber-800 text-[11px] leading-relaxed">
            High-value institutional clearing transactions require cryptographic sign-off from at least two authorized treasury officers. Signatures are timestamped with hardware token authentication and committed to the immutable audit trail.
          </p>
        </div>
      </div>

      {/* Pending Approvals Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-500" />
            <h2 className="font-bold text-sm text-slate-900">Pending Authorisation Requests ({pendingApprovals.length})</h2>
          </div>
          <span className="text-[11px] font-mono text-slate-400">Authenticated Officer: {currentUser.name} ({currentUser.role})</span>
        </div>

        {pendingApprovals.length === 0 ? (
          <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-400">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2 opacity-80" />
            <p className="font-semibold text-slate-700 text-xs">Approval queue is empty</p>
            <p className="text-[11px] text-slate-400 mt-0.5">All high-value clearing payments have been signed and released.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {pendingApprovals.map((appr) => {
              const p = appr.payment;
              const curSymbol = p.currency === 'GBP' ? '£' : p.currency === 'USD' ? '$' : p.currency === 'EUR' ? '€' : 'CHF ';

              return (
                <div 
                  key={appr.id}
                  className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden transition-all hover:border-amber-400"
                >
                  <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold font-mono text-xs">
                        {p.currency}
                      </div>
                      <div>
                        <div className="font-bold text-sm font-mono text-white">
                          {curSymbol}{p.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} {p.currency}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          Payment ID: {p.id} · Initiated by: {p.authorizer || 'Alex Mercer (Treasury Ops)'}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold uppercase">
                        {appr.status}
                      </span>
                    </div>
                  </div>

                  <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                    {/* Beneficiary Details */}
                    <div className="space-y-1">
                      <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Beneficiary & Clearing</span>
                      <div className="font-bold text-slate-900">{p.counterparty}</div>
                      <div className="text-slate-500 font-mono text-[11px]">{p.counterpartyBank} · {p.counterpartyAccount}</div>
                    </div>

                    {/* Remittance & Purpose */}
                    <div className="space-y-1">
                      <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Remittance Purpose</span>
                      <div className="text-slate-800 font-mono font-medium">{p.reference}</div>
                      <div className="text-slate-500 text-[11px]">{p.notes || 'Institutional Commercial Settlement'}</div>
                    </div>

                    {/* Risk & Approval Quorum */}
                    <div className="space-y-1">
                      <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Risk Assessment & Signatures</span>
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                          p.riskStatus === 'HIGH' ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          Risk {p.riskScore}/100 ({p.riskStatus})
                        </span>
                        <span className="text-slate-600 font-mono text-[11px]">
                          Signatures: {p.approvalsCompleted}/{p.approvalsRequired}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        Rail: {p.priority} · Direct BoE settlement
                      </div>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="px-4 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
                    <button
                      onClick={() => setSelectedPayment(p)}
                      className="text-xs font-mono text-slate-600 hover:text-slate-900 underline"
                    >
                      Inspect Full Financial Breakdown →
                    </button>

                    <div className="flex items-center gap-2">
                      {rejectingId === appr.id ? (
                        <div className="flex items-center gap-2">
                          <input
                            type="text"
                            value={rejectReason}
                            onChange={(e) => setRejectReason(e.target.value)}
                            placeholder="Reason for rejection..."
                            className="px-2.5 py-1 text-xs border border-slate-300 rounded bg-white font-mono"
                          />
                          <button
                            onClick={() => handleConfirmReject(appr.id)}
                            className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white font-mono font-bold text-xs rounded"
                          >
                            Confirm Reject
                          </button>
                          <button
                            onClick={() => setRejectingId(null)}
                            className="px-2 py-1 text-slate-500 hover:text-slate-800 text-xs"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <>
                          <button
                            onClick={() => setRejectingId(appr.id)}
                            className="px-3 py-1.5 bg-white border border-slate-300 hover:bg-rose-50 hover:text-rose-700 text-slate-700 font-mono text-xs font-semibold rounded-md transition-colors"
                          >
                            Reject
                          </button>

                          <button
                            onClick={() => handleApprove(appr.id)}
                            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-mono text-xs font-bold rounded-md shadow-xs transition-colors flex items-center gap-1.5"
                          >
                            <Check className="w-3.5 h-3.5 text-amber-400" />
                            Approve & Release Funds
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Historical Approvals */}
      {pastApprovals.length > 0 && (
        <div className="space-y-3 pt-6 border-t border-slate-200">
          <h2 className="font-bold text-sm text-slate-900">Authorisation History</h2>
          <div className="bg-white rounded-xl border border-slate-200 divide-y divide-slate-100 overflow-hidden text-xs">
            {pastApprovals.map((appr) => (
              <div key={appr.id} className="p-3.5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center ${
                    appr.status === 'Approved' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                  }`}>
                    {appr.status === 'Approved' ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                  </div>
                  <div>
                    <div className="font-bold text-slate-900">{appr.payment.counterparty} · £{appr.payment.amount.toLocaleString()}</div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      Signed by {appr.reviewedBy || currentUser.name} on {appr.reviewedDate || '23 Aug 2026'}
                    </div>
                  </div>
                </div>

                <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                  appr.status === 'Approved' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700 border border-rose-200'
                }`}>
                  {appr.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
