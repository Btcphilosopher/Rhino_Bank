import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  Search, 
  Filter, 
  Download, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  ShieldAlert, 
  RotateCcw,
  SlidersHorizontal,
  ChevronDown
} from 'lucide-react';
import { Currency, PaymentStatus } from '../../types/banking';

export const PaymentsListView: React.FC = () => {
  const { payments, setSelectedPayment, setIsSendPaymentOpen } = useBanking();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [currencyFilter, setCurrencyFilter] = useState<string>('ALL');
  const [directionFilter, setDirectionFilter] = useState<string>('ALL');

  const filteredPayments = payments.filter((p) => {
    const matchesSearch = 
      p.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.counterparty.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.bankReference.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'ALL' || p.status === statusFilter;
    const matchesCurrency = currencyFilter === 'ALL' || p.currency === currencyFilter;
    const matchesDirection = directionFilter === 'ALL' || p.direction === directionFilter;

    return matchesSearch && matchesStatus && matchesCurrency && matchesDirection;
  });

  const exportPaymentsCSV = () => {
    const headers = 'ID,Counterparty,Bank,Amount,Currency,Direction,Status,Reference,Date\n';
    const rows = filteredPayments.map(p => 
      `${p.id},"${p.counterparty}","${p.counterpartyBank}",${p.amount},${p.currency},${p.direction},${p.status},${p.reference},"${p.createdDate}"`
    ).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rhinobank_payments_${Date.now()}.csv`;
    a.click();
  };

  const statusBadges: Record<string, string> = {
    Completed: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    Processing: 'bg-amber-50 text-amber-700 border-amber-200',
    'Pending Approval': 'bg-amber-100 text-amber-800 border-amber-300',
    'Risk Checked': 'bg-blue-50 text-blue-700 border-blue-200',
    Held: 'bg-rose-50 text-rose-700 border-rose-200',
    Failed: 'bg-rose-100 text-rose-800 border-rose-300',
    Refunded: 'bg-purple-50 text-purple-700 border-purple-200'
  };

  return (
    <div className="space-y-5 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">All Payments</h1>
          <p className="text-xs text-slate-500 font-mono">
            Direct institutional clearing ledger · Real-time Faster Payments & RTGS
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={exportPaymentsCSV}
            className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-md font-mono text-xs font-medium transition-colors shadow-2xs flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            Export CSV
          </button>
          <button
            onClick={() => setIsSendPaymentOpen(true)}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-mono text-xs font-semibold rounded-md shadow-xs transition-colors flex items-center gap-1.5"
          >
            <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
            Send Payment
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Filter by counterparty, reference, payment ID..."
            className="w-full pl-9 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs focus:ring-1 focus:ring-amber-500 focus:outline-none bg-slate-50/50"
          />
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto">
          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg font-mono text-xs bg-white text-slate-700"
          >
            <option value="ALL">All Statuses</option>
            <option value="Completed">Completed</option>
            <option value="Processing">Processing</option>
            <option value="Pending Approval">Pending Approval</option>
            <option value="Held">Held (Risk)</option>
            <option value="Failed">Failed</option>
            <option value="Refunded">Refunded</option>
          </select>

          {/* Currency Filter */}
          <select
            value={currencyFilter}
            onChange={(e) => setCurrencyFilter(e.target.value)}
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg font-mono text-xs bg-white text-slate-700"
          >
            <option value="ALL">All Currencies</option>
            <option value="GBP">GBP (£)</option>
            <option value="USD">USD ($)</option>
            <option value="EUR">EUR (€)</option>
            <option value="CHF">CHF</option>
          </select>

          {/* Direction Filter */}
          <select
            value={directionFilter}
            onChange={(e) => setDirectionFilter(e.target.value)}
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg font-mono text-xs bg-white text-slate-700"
          >
            <option value="ALL">All Directions</option>
            <option value="Outgoing">Outgoing (Debits)</option>
            <option value="Incoming">Incoming (Credits)</option>
          </select>
        </div>
      </div>

      {/* Table Container */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-mono text-[11px] uppercase tracking-wider">
                <th className="py-3 px-4 font-semibold">Payment ID / Date</th>
                <th className="py-3 px-4 font-semibold">Counterparty</th>
                <th className="py-3 px-4 font-semibold">Reference</th>
                <th className="py-3 px-4 font-semibold">Rail Priority</th>
                <th className="py-3 px-4 font-semibold text-right">Amount</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
                <th className="py-3 px-4 font-semibold text-center">Risk Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPayments.map((p) => {
                const isOutgoing = p.direction === 'Outgoing';
                const curSymbol = p.currency === 'GBP' ? '£' : p.currency === 'USD' ? '$' : p.currency === 'EUR' ? '€' : 'CHF ';

                return (
                  <tr
                    key={p.id}
                    onClick={() => setSelectedPayment(p)}
                    className="hover:bg-slate-50/90 transition-colors cursor-pointer group"
                  >
                    {/* ID & Date */}
                    <td className="py-3 px-4">
                      <div className="font-mono font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
                        {p.id}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">{p.createdDate}</div>
                    </td>

                    {/* Counterparty & Bank */}
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-800">{p.counterparty}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{p.counterpartyBank}</div>
                    </td>

                    {/* Reference */}
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {p.reference}
                    </td>

                    {/* Rail */}
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-500">
                      {p.priority}
                    </td>

                    {/* Amount */}
                    <td className="py-3 px-4 text-right">
                      <span className={`font-mono font-bold text-sm ${isOutgoing ? 'text-slate-900' : 'text-emerald-700'}`}>
                        {isOutgoing ? '-' : '+'}{curSymbol}{p.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                      <span className="block text-[10px] text-slate-400 font-mono">{p.currency}</span>
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4 text-center">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase border inline-block ${statusBadges[p.status] || 'bg-slate-100 text-slate-700'}`}>
                        {p.status}
                      </span>
                    </td>

                    {/* Risk Score */}
                    <td className="py-3 px-4 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        p.riskStatus === 'HIGH' ? 'bg-rose-100 text-rose-800' : p.riskStatus === 'MEDIUM' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {p.riskScore}/100
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredPayments.length === 0 && (
          <div className="py-12 text-center text-slate-400">
            <p className="font-mono text-xs">No payments matching current filter criteria.</p>
          </div>
        )}

        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] font-mono text-slate-500">
          <span>Showing {filteredPayments.length} of {payments.length} transactions</span>
          <span>Double-entry ledger status: RECONCILED</span>
        </div>
      </div>
    </div>
  );
};
