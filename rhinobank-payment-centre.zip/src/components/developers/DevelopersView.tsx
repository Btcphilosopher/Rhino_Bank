import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  Key, 
  Webhook, 
  Terminal, 
  Play, 
  Copy, 
  Check
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const DevelopersView: React.FC = () => {
  const { apiKeys, webhooks, generateApiKey, dispatchWebhookTest, executeApiConsoleRequest } = useBanking();
  const [activeTab, setActiveTab] = useState<'API Keys' | 'Webhooks' | 'API Console'>('API Console');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // API Console State
  const [method, setMethod] = useState<'GET' | 'POST'>('POST');
  const [endpoint, setEndpoint] = useState('/v1/payments');
  const [requestBody, setRequestBody] = useState(
    JSON.stringify({
      amount: 42850.00,
      currency: "GBP",
      counterparty: "Northbridge Engineering Ltd",
      reference: "INV-2026-1842",
      priority: "Instant Faster Payments"
    }, null, 2)
  );
  const [responsePayload, setResponsePayload] = useState<any>(null);
  const [isRunning, setIsRunning] = useState(false);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleRunApi = async () => {
    setIsRunning(true);
    try {
      const parsedBody = method === 'POST' ? JSON.parse(requestBody) : undefined;
      const res = await executeApiConsoleRequest(method, endpoint, parsedBody);
      setResponsePayload(res);
      confetti({ particleCount: 30, spread: 40 });
    } catch (err: any) {
      setResponsePayload({ error: err.message });
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Developer & API Integration Centre</h1>
          <p className="text-xs text-slate-500 font-mono">
            REST API v1 · TLS 1.3 cryptographic webhooks · Real-time JSON clearing specifications
          </p>
        </div>

        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
          {(['API Console', 'API Keys', 'Webhooks'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3 py-1 text-xs font-mono font-medium rounded-md transition-all ${
                activeTab === tab ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* API Console View */}
      {activeTab === 'API Console' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Request builder */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Terminal className="w-4 h-4 text-amber-500" />
                API Request Builder
              </h3>
              <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                Live Sandbox Ready
              </span>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={method}
                onChange={(e) => setMethod(e.target.value as any)}
                className="px-2.5 py-2 border border-slate-300 rounded-lg font-mono font-bold text-xs bg-white"
              >
                <option value="POST">POST</option>
                <option value="GET">GET</option>
              </select>

              <select
                value={endpoint}
                onChange={(e) => setEndpoint(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs bg-white"
              >
                <option value="/v1/payments">https://api.rhinobank.com/v1/payments</option>
                <option value="/v1/accounts">https://api.rhinobank.com/v1/accounts</option>
                <option value="/v1/quotes/fx">https://api.rhinobank.com/v1/quotes/fx</option>
              </select>
            </div>

            {method === 'POST' && (
              <div className="space-y-1">
                <label className="block text-slate-500 font-mono text-[10px] uppercase font-bold">Request Body (JSON)</label>
                <textarea
                  value={requestBody}
                  onChange={(e) => setRequestBody(e.target.value)}
                  rows={8}
                  className="w-full p-3 bg-slate-900 text-amber-300 font-mono text-xs rounded-lg border border-slate-800 focus:outline-none"
                />
              </div>
            )}

            <button
              onClick={handleRunApi}
              disabled={isRunning}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-mono font-bold text-xs rounded-lg shadow-sm transition-all flex items-center justify-center gap-2"
            >
              {isRunning ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Dispatching Request...
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 text-amber-400" />
                  Execute Endpoint
                </>
              )}
            </button>
          </div>

          {/* Response Payload */}
          <div className="bg-slate-900 rounded-xl p-5 border border-slate-800 shadow-2xs space-y-3 text-white">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-mono text-xs text-slate-400 font-semibold">Response Inspector</span>
              {responsePayload && (
                <span className="text-[10px] font-mono text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  HTTP 200 OK
                </span>
              )}
            </div>

            {responsePayload ? (
              <pre className="text-amber-300 font-mono text-xs overflow-x-auto max-h-[320px] p-2">
                {JSON.stringify(responsePayload, null, 2)}
              </pre>
            ) : (
              <div className="py-20 text-center text-slate-500 font-mono text-xs">
                Click "Execute Endpoint" to send an authenticated JSON payload.
              </div>
            )}
          </div>
        </div>
      )}

      {/* API Keys View */}
      {activeTab === 'API Keys' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Secret API Keys</h3>
              <p className="text-xs text-slate-500 font-mono">Use keys to authenticate REST endpoints and webhook verification</p>
            </div>
            <button
              onClick={() => generateApiKey('Treasury Automated Integration Key', ['read:all', 'write:payments'])}
              className="px-3.5 py-1.5 bg-slate-900 text-white font-mono text-xs font-semibold rounded-md"
            >
              + Create New Key
            </button>
          </div>

          <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden text-xs">
            {apiKeys.map((k) => (
              <div key={k.id} className="p-4 flex items-center justify-between hover:bg-slate-50">
                <div className="space-y-1">
                  <div className="font-bold text-slate-900 flex items-center gap-2">
                    <Key className="w-3.5 h-3.5 text-amber-500" />
                    <span>{k.name}</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-[10px] font-mono text-slate-600 font-normal">
                      {k.keyMasked}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono">
                    Created {k.created} · Last used {k.lastUsed}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopy(`${k.keyPrefix}_live_sec_institutional`, k.id)}
                    className="px-2.5 py-1 border border-slate-200 hover:bg-slate-100 rounded text-slate-700 font-mono text-[11px] flex items-center gap-1"
                  >
                    {copiedKey === k.id ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    Copy Key
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Webhooks View */}
      {activeTab === 'Webhooks' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Webhook Events Stream</h3>
              <p className="text-xs text-slate-500 font-mono">Real-time asynchronous events signed via HMAC-SHA256</p>
            </div>
            <button
              onClick={() => dispatchWebhookTest('payment.created')}
              className="px-3.5 py-1.5 bg-slate-900 text-white font-mono text-xs font-semibold rounded-md"
            >
              + Dispatch Test Event
            </button>
          </div>

          <div className="space-y-3">
            {webhooks.map((w) => (
              <div key={w.id} className="p-4 border border-slate-200 rounded-lg space-y-2 text-xs font-mono">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-slate-900 flex items-center gap-2">
                    <Webhook className="w-4 h-4 text-amber-500" />
                    <span>{w.event}</span>
                    <span className="text-[10px] text-slate-400">({w.id})</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    {w.status}
                  </span>
                </div>

                <div className="text-[11px] text-slate-600 truncate">
                  Target: {w.endpointUrl}
                </div>

                <div className="p-2 bg-slate-900 rounded text-amber-300 text-[10px] overflow-x-auto">
                  {JSON.stringify(w.payload, null, 2)}
                </div>

                <div className="pt-1 flex items-center justify-between text-[10px] text-slate-400">
                  <span>Timestamp: {w.timestamp}</span>
                  <span>Delivery Attempts: {w.attempts}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
