import React, { useState, useEffect } from 'react';
import { ArrowUpRight, ArrowDownRight, Clock } from 'lucide-react';
import { RhinoLogo } from '../common/RhinoLogo';

export const BottomTicker: React.FC = () => {
  const [time, setTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      const dateStr = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
      setTime(`${timeStr} · ${dateStr} · London`);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <footer className="h-16 bg-[#0B0F17] border-t border-slate-800 text-slate-300 px-6 flex items-center justify-between z-20 shrink-0 select-none text-xs font-sans">
      {/* Metric 1: Net Cash Position */}
      <div className="flex items-center gap-6 divide-x divide-slate-800/80">
        <div className="flex flex-col">
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">Net Cash Position</span>
          <div className="flex items-baseline gap-2">
            <span className="font-bold text-sm text-white font-mono tabular-nums">£5.32m</span>
            <span className="text-[10px] font-mono text-emerald-400 flex items-center">
              <ArrowUpRight className="w-2.5 h-2.5" />
              15.8% <span className="text-slate-400 hidden sm:inline ml-1">vs yesterday</span>
            </span>
          </div>
        </div>

        {/* Metric 2: Payments Success Rate */}
        <div className="flex flex-col pl-6">
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">Payments Success Rate</span>
          <div className="flex items-baseline gap-2">
            <span className="font-bold text-sm text-white font-mono tabular-nums">99.42%</span>
            <span className="text-[10px] font-mono text-emerald-400 flex items-center">
              <ArrowUpRight className="w-2.5 h-2.5" />
              0.8% <span className="text-slate-400 hidden sm:inline ml-1">vs yesterday</span>
            </span>
          </div>
        </div>

        {/* Metric 3: Avg Settlement Time */}
        <div className="hidden lg:flex flex-col pl-6">
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">Avg Settlement Time</span>
          <div className="flex items-baseline gap-2">
            <span className="font-bold text-sm text-white font-mono tabular-nums">12m 42s</span>
            <span className="text-[10px] font-mono text-emerald-400 flex items-center">
              <ArrowDownRight className="w-2.5 h-2.5" />
              4m <span className="text-slate-400 ml-1">faster</span>
            </span>
          </div>
        </div>

        {/* Metric 4: Fees Today */}
        <div className="hidden xl:flex flex-col pl-6">
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">Fees Today</span>
          <div className="flex items-baseline gap-2">
            <span className="font-bold text-sm text-white font-mono tabular-nums">£42,820.14</span>
            <span className="text-[10px] font-mono text-emerald-400 flex items-center">
              <ArrowUpRight className="w-2.5 h-2.5" />
              6.2%
            </span>
          </div>
        </div>
      </div>

      {/* Right Side: London Clock & RhinoBank Seal */}
      <div className="flex items-center gap-6">
        <div className="hidden md:flex flex-col items-end text-right">
          <div className="flex items-center gap-1 text-[11px] font-mono font-medium text-amber-400">
            <Clock className="w-3 h-3 text-amber-400" />
            <span className="tabular-nums">{time}</span>
          </div>
          <span className="text-[9px] text-slate-400 font-mono tracking-widest uppercase">RTGS Real-Time Settlement Open</span>
        </div>

        <div className="hidden sm:flex items-center gap-2 pl-4 border-l border-slate-800">
          <div className="flex flex-col text-right">
            <span className="text-xs font-bold font-mono tracking-wider text-white">RHINOBANK</span>
            <span className="text-[8px] font-mono tracking-widest uppercase text-amber-400">STRENGTH. STABILITY. TRUST.</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
