import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { RhinoLogo } from '../common/RhinoLogo';
import { 
  LayoutDashboard, 
  ArrowUpRight, 
  CreditCard, 
  Link as LinkIcon, 
  Repeat, 
  RotateCcw, 
  Building2, 
  Users, 
  Coins, 
  ReceiptText, 
  FileText, 
  Layers, 
  TrendingUp, 
  ArrowLeftRight, 
  ShieldAlert, 
  ShieldCheck, 
  Sliders, 
  Lock, 
  Scale, 
  AlertTriangle, 
  FileSpreadsheet, 
  BarChart3, 
  DollarSign, 
  LineChart, 
  PieChart, 
  Code2, 
  Webhook, 
  KeyRound, 
  ScrollText, 
  UserCheck, 
  Shield, 
  Settings, 
  ChevronDown, 
  ChevronRight,
  CheckCircle2,
  Clock,
  Sparkles
} from 'lucide-react';

interface NavSection {
  title: string;
  icon: any;
  items: { id: string; label: string; icon: any; badge?: number | string; badgeColor?: string }[];
}

export const Sidebar: React.FC = () => {
  const { 
    activeTab, 
    setActiveTab, 
    approvals, 
    riskAlerts, 
    exceptions, 
    environment, 
    currentUser, 
    switchRole,
    setIsSendPaymentOpen
  } = useBanking();

  // Collapsible sections state (default all open)
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({});

  const pendingApprovalsCount = approvals.filter(a => a.status === 'Pending').length;
  const activeRiskAlertsCount = riskAlerts.filter(a => a.status === 'Held' || a.status === 'Open').length;
  const openExceptionsCount = exceptions.filter(e => e.status === 'Unresolved').length;

  const toggleSection = (title: string) => {
    setCollapsedSections(prev => ({
      ...prev,
      [title]: !prev[title]
    }));
  };

  const navSections: NavSection[] = [
    {
      title: 'PAYMENTS',
      icon: CreditCard,
      items: [
        { id: 'payments-all', label: 'All Payments', icon: CreditCard },
        { id: 'payments-send', label: 'Send Payment', icon: ArrowUpRight },
        { id: 'payments-approvals', label: 'Approvals', icon: Clock, badge: pendingApprovalsCount > 0 ? pendingApprovalsCount : undefined, badgeColor: 'bg-amber-500 text-slate-950 font-bold' },
        { id: 'payments-links', label: 'Payment Links', icon: LinkIcon },
        { id: 'payments-recurring', label: 'Recurring', icon: Repeat },
        { id: 'payments-refunds', label: 'Refunds', icon: RotateCcw },
      ]
    },
    {
      title: 'ACCOUNTS',
      icon: Building2,
      items: [
        { id: 'accounts-banks', label: 'Bank Accounts', icon: Building2 },
        { id: 'accounts-customers', label: 'Customer Accounts', icon: Users },
        { id: 'accounts-balances', label: 'Balances', icon: Coins },
        { id: 'accounts-ledger', label: 'Transactions', icon: ReceiptText },
      ]
    },
    {
      title: 'COLLECTIONS',
      icon: FileText,
      items: [
        { id: 'collections-invoices', label: 'Invoices', icon: FileText },
        { id: 'collections-directdebit', label: 'Direct Debit', icon: Layers },
        { id: 'collections-requests', label: 'Payment Requests', icon: ArrowLeftRight },
      ]
    },
    {
      title: 'TREASURY',
      icon: TrendingUp,
      items: [
        { id: 'treasury-liquidity', label: 'Liquidity', icon: TrendingUp },
        { id: 'treasury-fx', label: 'FX Centre', icon: ArrowLeftRight },
        { id: 'treasury-cash', label: 'Cash Position', icon: DollarSign },
        { id: 'treasury-settlement', label: 'Settlement', icon: CheckCircle2 },
      ]
    },
    {
      title: 'RISK',
      icon: ShieldAlert,
      items: [
        { id: 'risk-fraud', label: 'Fraud Monitor', icon: ShieldAlert, badge: activeRiskAlertsCount > 0 ? activeRiskAlertsCount : undefined, badgeColor: 'bg-rose-500 text-white font-bold' },
        { id: 'risk-aml', label: 'AML & Sanctions', icon: ShieldCheck },
        { id: 'risk-limits', label: 'Limits', icon: Sliders },
        { id: 'risk-holds', label: 'Holds & Release', icon: Lock },
      ]
    },
    {
      title: 'RECONCILIATION',
      icon: Scale,
      items: [
        { id: 'reconciliation-matching', label: 'Matching', icon: Scale },
        { id: 'reconciliation-exceptions', label: 'Exceptions', icon: AlertTriangle, badge: openExceptionsCount > 0 ? openExceptionsCount : undefined, badgeColor: 'bg-amber-500 text-slate-950 font-bold' },
        { id: 'reconciliation-statements', label: 'Statements', icon: FileSpreadsheet },
      ]
    },
    {
      title: 'ANALYTICS',
      icon: BarChart3,
      items: [
        { id: 'analytics-payments', label: 'Payments', icon: BarChart3 },
        { id: 'analytics-revenue', label: 'Revenue', icon: LineChart },
        { id: 'analytics-customers', label: 'Customers', icon: Users },
        { id: 'analytics-cashflow', label: 'Cash Flow', icon: PieChart },
      ]
    },
    {
      title: 'REPORTS',
      icon: FileSpreadsheet,
      items: [
        { id: 'reports', label: 'All Reports', icon: FileSpreadsheet }
      ]
    },
    {
      title: 'DEVELOPERS',
      icon: Code2,
      items: [
        { id: 'developers-api', label: 'API Overview', icon: Code2 },
        { id: 'developers-webhooks', label: 'Webhooks', icon: Webhook },
        { id: 'developers-keys', label: 'API Keys', icon: KeyRound },
        { id: 'developers-logs', label: 'Logs', icon: ScrollText },
      ]
    },
    {
      title: 'ADMIN',
      icon: Shield,
      items: [
        { id: 'admin-users', label: 'Users', icon: UserCheck },
        { id: 'admin-roles', label: 'Roles & RBAC', icon: Shield },
        { id: 'admin-settings', label: 'Settings', icon: Settings },
      ]
    }
  ];

  return (
    <aside className="w-64 bg-[#0c1017] text-slate-300 border-r border-slate-800/80 flex flex-col h-screen select-none shrink-0 z-30 font-sans">
      {/* Brand Header */}
      <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
        <RhinoLogo />
        {environment === 'Sandbox' && (
          <span className="px-2 py-0.5 text-[10px] font-mono font-bold uppercase rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
            TEST
          </span>
        )}
      </div>

      {/* Primary Action Button */}
      <div className="px-3 pt-3 pb-1">
        <button
          onClick={() => setIsSendPaymentOpen(true)}
          className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-semibold rounded-md shadow-sm transition-all duration-150 text-xs tracking-wide uppercase font-mono"
        >
          <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
          <span>Send Payment</span>
        </button>
      </div>

      {/* Navigation Links Scrollable Area */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-4">
        {/* Overview Tab (Always Top) */}
        <div>
          <button
            onClick={() => setActiveTab('overview')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-xs font-medium transition-colors ${
              activeTab === 'overview'
                ? 'bg-amber-400/15 text-amber-300 font-semibold border-l-2 border-amber-400 pl-2.5'
                : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
            }`}
          >
            <LayoutDashboard className={`w-4 h-4 ${activeTab === 'overview' ? 'text-amber-400' : 'text-slate-400'}`} />
            <span>Overview</span>
          </button>
        </div>

        {/* Section Groups */}
        {navSections.map((section) => {
          const isCollapsed = collapsedSections[section.title];
          const hasActiveChild = section.items.some(item => item.id === activeTab);

          return (
            <div key={section.title} className="space-y-1">
              <button
                onClick={() => toggleSection(section.title)}
                className="w-full flex items-center justify-between px-2 py-1 text-[11px] font-mono font-semibold text-slate-300 uppercase tracking-wider hover:text-slate-100 transition-colors"
              >
                <span>{section.title}</span>
                {isCollapsed ? (
                  <ChevronRight className="w-3 h-3 text-slate-400" />
                ) : (
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                )}
              </button>

              {!isCollapsed && (
                <div className="space-y-0.5 pl-1">
                  {section.items.map((item) => {
                    const isActive = activeTab === item.id;
                    const Icon = item.icon;

                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          if (item.id === 'payments-send') {
                            setIsSendPaymentOpen(true);
                          } else {
                            setActiveTab(item.id);
                          }
                        }}
                        className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium transition-all ${
                          isActive
                            ? 'bg-amber-400/15 text-amber-300 font-semibold border-l-2 border-amber-400 pl-2'
                            : 'text-slate-300 hover:bg-slate-800/60 hover:text-slate-100'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 truncate">
                          <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                          <span className="truncate">{item.label}</span>
                        </div>
                        {item.badge !== undefined && (
                          <span className={`px-1.5 py-0.2 text-[10px] rounded font-mono ${item.badgeColor || 'bg-slate-800 text-slate-300'}`}>
                            {item.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer / User Profile & Environment Info */}
      <div className="p-3 border-t border-slate-800/80 bg-[#090d13] text-xs space-y-2">
        <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            London Node #04
          </span>
          <span className="text-slate-400">v3.7.0</span>
        </div>

        <div className="flex items-center gap-2.5 pt-1">
          <div className="w-7 h-7 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30 flex items-center justify-center font-bold text-xs font-mono shrink-0">
            {currentUser.avatarInitials}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-semibold text-slate-200 truncate">{currentUser.name}</div>
            <div className="text-[10px] text-amber-400/90 font-mono truncate">{currentUser.role}</div>
          </div>
        </div>
      </div>
    </aside>
  );
};
