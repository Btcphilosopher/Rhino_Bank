import React, { useState, useRef, useEffect } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  Search, 
  Bell, 
  HelpCircle, 
  ChevronDown, 
  CheckCircle2, 
  Sparkles, 
  ShieldCheck, 
  FlaskConical,
  Globe,
  Sliders,
  ExternalLink,
  Lock,
  UserCheck
} from 'lucide-react';
import { UserRole } from '../../types/banking';

export const TopBar: React.FC = () => {
  const { 
    environment, 
    setEnvironment, 
    currentUser, 
    switchRole,
    notifications,
    setIsSystemStatusOpen,
    setIsCommandPaletteOpen,
    setIsNotificationsOpen,
    globalSearchQuery,
    setGlobalSearchQuery,
    sandboxSimulate
  } = useBanking();

  const [isEnvDropdownOpen, setIsEnvDropdownOpen] = useState(false);
  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);

  const envRef = useRef<HTMLDivElement>(null);
  const userRef = useRef<HTMLDivElement>(null);
  const helpRef = useRef<HTMLDivElement>(null);

  const unreadNotificationsCount = notifications.filter(n => !n.read).length;

  const availableRoles: UserRole[] = [
    'Administrator',
    'Treasurer',
    'Finance Manager',
    'Payments Operator',
    'Risk Officer',
    'Compliance Officer',
    'Developer',
    'Auditor',
    'Read Only'
  ];

  // Click outside listener
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (envRef.current && !envRef.current.contains(event.target as Node)) {
        setIsEnvDropdownOpen(false);
      }
      if (userRef.current && !userRef.current.contains(event.target as Node)) {
        setIsUserDropdownOpen(false);
      }
      if (helpRef.current && !helpRef.current.contains(event.target as Node)) {
        setIsHelpOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="h-14 bg-[#0D0F15] border-b border-[#202636] px-6 flex items-center justify-between z-20 shrink-0 sticky top-0 text-[#E0E0E0]">
      {/* Global Search Bar */}
      <div className="flex-1 max-w-md">
        <button
          onClick={() => setIsCommandPaletteOpen(true)}
          className="w-full flex items-center justify-between px-3 py-1.5 bg-[#141822] hover:bg-[#1A202E] border border-[#242C3D] hover:border-[#38445E] rounded-lg text-xs text-slate-400 transition-all shadow-xs group"
        >
          <div className="flex items-center gap-2">
            <Search className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-400 transition-colors" />
            <span className="font-normal text-slate-400 group-hover:text-slate-200">Search anything (payments, IBANs, counterparties)...</span>
          </div>
          <kbd className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] font-mono font-medium text-amber-400/90 bg-[#0A0D14] border border-[#2A3348] rounded">
            ⌘ K
          </kbd>
        </button>
      </div>

      {/* Right Controls & Utilities */}
      <div className="flex items-center gap-4">
        {/* Environment Selector Switcher */}
        <div className="relative" ref={envRef}>
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-slate-400 hidden lg:inline text-[11px] font-mono">Environment</span>
            <button
              onClick={() => setIsEnvDropdownOpen(!isEnvDropdownOpen)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold font-mono border transition-all ${
                environment === 'Production'
                  ? 'bg-[#141822] text-slate-100 border-[#2A3348] hover:border-slate-500 shadow-xs'
                  : 'bg-amber-400/10 text-amber-300 border-amber-400/30 hover:bg-amber-400/20 shadow-xs'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${environment === 'Production' ? 'bg-emerald-400' : 'bg-amber-400 animate-pulse'}`} />
              <span>{environment}</span>
              <ChevronDown className="w-3 h-3 opacity-70" />
            </button>
          </div>

          {isEnvDropdownOpen && (
            <div className="absolute right-0 mt-1.5 w-60 bg-[#12151F] rounded-xl shadow-2xl border border-[#262E40] p-2 z-50 animate-in fade-in zoom-in-95 duration-100">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider px-2 py-1">
                Select Environment
              </div>
              <button
                onClick={() => {
                  setEnvironment('Production');
                  setIsEnvDropdownOpen(false);
                }}
                className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs text-left transition-colors ${
                  environment === 'Production' ? 'bg-amber-400 text-slate-950 font-semibold' : 'text-slate-300 hover:bg-[#1B2030]'
                }`}
              >
                <div>
                  <div className="font-semibold flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    Production
                  </div>
                  <div className="text-[10px] opacity-75 font-mono">Live Faster Payments & Clearing</div>
                </div>
                {environment === 'Production' && <CheckCircle2 className="w-4 h-4 text-slate-950" />}
              </button>

              <button
                onClick={() => {
                  setEnvironment('Sandbox');
                  setIsEnvDropdownOpen(false);
                }}
                className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs text-left mt-1 transition-colors ${
                  environment === 'Sandbox' ? 'bg-amber-400 text-slate-950 font-semibold' : 'text-slate-300 hover:bg-[#1B2030]'
                }`}
              >
                <div>
                  <div className="font-semibold flex items-center gap-1.5">
                    <FlaskConical className="w-3.5 h-3.5" />
                    Sandbox
                  </div>
                  <div className="text-[10px] opacity-80 font-mono">£1,000,000 Fictional Test Balance</div>
                </div>
                {environment === 'Sandbox' && <CheckCircle2 className="w-4 h-4 text-slate-950" />}
              </button>

              {environment === 'Sandbox' && (
                <div className="mt-2 pt-2 border-t border-[#202738] space-y-1">
                  <div className="text-[10px] font-mono font-bold text-amber-400 uppercase px-2">Quick Simulations</div>
                  <button
                    onClick={() => {
                      sandboxSimulate('payment');
                      setIsEnvDropdownOpen(false);
                    }}
                    className="w-full text-left px-2 py-1 text-[11px] text-slate-300 hover:bg-amber-400/10 hover:text-amber-300 rounded"
                  >
                    + Generate Test Payment (£50k)
                  </button>
                  <button
                    onClick={() => {
                      sandboxSimulate('failure');
                      setIsEnvDropdownOpen(false);
                    }}
                    className="w-full text-left px-2 py-1 text-[11px] text-slate-300 hover:bg-rose-400/10 hover:text-rose-300 rounded"
                  >
                    + Generate Failed Payment (IBAN Error)
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Global Operational Status */}
        <button
          onClick={() => setIsSystemStatusOpen(true)}
          className="hidden md:flex items-center gap-2 px-2.5 py-1 rounded-md text-xs font-mono font-medium text-emerald-400 bg-emerald-950/40 border border-emerald-800/60 hover:bg-emerald-900/40 transition-colors"
          title="Click to view full subsystem latencies"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-[11px] font-semibold text-emerald-300 tracking-wide">ALL SYSTEMS OPERATIONAL</span>
        </button>

        {/* Notifications Trigger */}
        <button
          onClick={() => setIsNotificationsOpen(true)}
          className="relative p-1.5 text-slate-400 hover:text-amber-400 hover:bg-[#171B26] rounded-md transition-colors"
          title="Notifications & Alerts"
        >
          <Bell className="w-4 h-4" />
          {unreadNotificationsCount > 0 && (
            <span className="absolute top-1 right-1 w-2 h-2 bg-amber-400 rounded-full ring-2 ring-[#0D0F15]" />
          )}
        </button>

        {/* Help & Documentation Guide */}
        <div className="relative" ref={helpRef}>
          <button
            onClick={() => setIsHelpOpen(!isHelpOpen)}
            className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-[#171B26] rounded-md transition-colors"
            title="Help & Guides"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          {isHelpOpen && (
            <div className="absolute right-0 mt-1.5 w-72 bg-[#12151F] rounded-xl shadow-2xl border border-[#262E40] p-3 z-50 text-xs text-slate-200">
              <div className="font-bold text-slate-100 mb-1 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                RhinoBank Payment Operating Guide
              </div>
              <p className="text-slate-400 text-[11px] leading-relaxed mb-2">
                This console is connected to RhinoBank's direct clearing rails. All transactions are backed by real double-entry ledger bookkeeping.
              </p>
              <div className="space-y-1.5 pt-2 border-t border-[#202738] text-[11px]">
                <div className="flex items-center justify-between text-slate-400">
                  <span>Fast Search & Commands</span>
                  <kbd className="px-1 py-0.5 bg-[#0A0D14] border border-[#2A3348] text-amber-400 rounded font-mono text-[10px]">⌘K</kbd>
                </div>
                <div className="flex items-center justify-between text-slate-400">
                  <span>Sandbox Testing</span>
                  <span className="text-amber-400 font-medium">Switch via Env picker</span>
                </div>
                <div className="flex items-center justify-between text-slate-400">
                  <span>Dual Approvals</span>
                  <span className="text-slate-200 font-mono">&gt;£100,000 threshold</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* User Account & Role Switcher */}
        <div className="relative" ref={userRef}>
          <button
            onClick={() => setIsUserDropdownOpen(!isUserDropdownOpen)}
            className="flex items-center gap-2.5 pl-2 pr-1.5 py-1 rounded-md hover:bg-[#171B26] transition-colors border border-transparent hover:border-[#262E40]"
          >
            <div className="w-7 h-7 rounded-full bg-[#1A202E] text-amber-400 font-mono font-bold text-xs flex items-center justify-center border border-amber-400/30">
              {currentUser.avatarInitials}
            </div>
            <div className="hidden sm:flex flex-col text-left">
              <span className="text-xs font-semibold text-slate-200 leading-tight">{currentUser.name}</span>
              <span className="text-[10px] text-amber-400/80 font-mono">{currentUser.role}</span>
            </div>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>

          {isUserDropdownOpen && (
            <div className="absolute right-0 mt-1.5 w-64 bg-[#12151F] rounded-xl shadow-2xl border border-[#262E40] p-2 z-50 animate-in fade-in zoom-in-95 duration-100">
              <div className="px-2 py-1.5 border-b border-[#202738] mb-1">
                <div className="font-bold text-slate-100 text-xs">{currentUser.name}</div>
                <div className="text-[10px] text-slate-400 font-mono">{currentUser.email}</div>
                <div className="text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-1.5 py-0.5 rounded mt-1 inline-block font-mono">
                  Hardware MFA Active
                </div>
              </div>

              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider px-2 py-1">
                Switch Active Role (RBAC)
              </div>
              <div className="max-h-48 overflow-y-auto space-y-0.5">
                {availableRoles.map((r) => (
                  <button
                    key={r}
                    onClick={() => {
                      switchRole(r);
                      setIsUserDropdownOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-2 py-1.5 rounded-lg text-xs text-left transition-colors ${
                      currentUser.role === r
                        ? 'bg-amber-400 text-slate-950 font-semibold'
                        : 'text-slate-300 hover:bg-[#1B2030]'
                    }`}
                  >
                    <span>{r}</span>
                    {currentUser.role === r && <CheckCircle2 className="w-3.5 h-3.5 text-slate-950" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
