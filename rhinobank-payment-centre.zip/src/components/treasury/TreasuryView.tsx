import React from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownLeft, 
  ShieldCheck, 
  PieChart as PieChartIcon, 
  Activity, 
  Coins,
  Scale
} from 'lucide-react';

export const TreasuryView: React.FC = () => {
  const { accounts } = useBanking();

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Treasury & Liquidity Management</h1>
        <p className="text-xs text-slate-500 font-mono">
          Intraday cash ladder · Real-time Bank of England settlement buffers & collateral allocation
        </p>
      </div>

      {/* Main Liquidity KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Total Group Liquidity</span>
          <div className="text-2xl font-bold font-mono text-slate-900">£67.42m</div>
          <span className="text-[11px] font-mono text-emerald-600 flex items-center gap-1 font-medium">
            <ArrowUpRight className="w-3 h-3" />
            +£4.20m intraday surplus
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Unencumbered Available</span>
          <div className="text-2xl font-bold font-mono text-emerald-700">£42.80m</div>
          <span className="text-[11px] font-mono text-slate-500">63.5% of total pool</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Committed Outflows (T+0)</span>
          <div className="text-2xl font-bold font-mono text-amber-700">£14.20m</div>
          <span className="text-[11px] font-mono text-slate-500">Settling by 16:30 BST</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Regulatory Buffer Ratio (LCR)</span>
          <div className="text-2xl font-bold font-mono text-blue-700">184.2%</div>
          <span className="text-[11px] font-mono text-emerald-600 font-medium">Well above 100% min</span>
        </div>
      </div>

      {/* Intraday Cash Position Chart & Liquidity Allocation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Intraday Cash Ladder (2 cols) */}
        <div className="lg:col-span-2 bg-white rounded-xl p-5 border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Intraday Cash Projection (Hourly)</h3>
              <p className="text-[11px] text-slate-500 font-mono">Simulated net cash delta across Faster Payments & CHAPS batches</p>
            </div>
            <span className="text-xs font-mono text-slate-400">London Time (BST)</span>
          </div>

          <div className="space-y-3 pt-2">
            {[
              { time: '08:00 - 10:00', opening: '£54.2m', inflows: '+£6.8m', outflows: '-£4.2m', closing: '£56.8m', net: '+£2.6m' },
              { time: '10:00 - 12:00', opening: '£56.8m', inflows: '+£8.4m', outflows: '-£5.1m', closing: '£60.1m', net: '+£3.3m' },
              { time: '12:00 - 14:00', opening: '£60.1m', inflows: '+£12.1m', outflows: '-£8.2m', closing: '£64.0m', net: '+£3.9m' },
              { time: '14:00 - 16:00 (Current)', opening: '£64.0m', inflows: '+£5.4m', outflows: '-£2.0m', closing: '£67.4m', net: '+£3.4m' },
              { time: '16:00 - 18:00 (Forecast)', opening: '£67.4m', inflows: '+£3.2m', outflows: '-£6.5m', closing: '£64.1m', net: '-£3.3m' },
            ].map((slot, idx) => (
              <div key={idx} className="p-3 bg-slate-50 border border-slate-200/80 rounded-lg flex items-center justify-between text-xs font-mono">
                <div>
                  <span className="font-bold text-slate-900 block">{slot.time}</span>
                  <span className="text-[10px] text-slate-400">Opening: {slot.opening}</span>
                </div>

                <div className="flex items-center gap-4 text-right">
                  <div>
                    <span className="text-emerald-700 font-semibold">{slot.inflows}</span>
                    <span className="text-slate-400 mx-1">/</span>
                    <span className="text-rose-700 font-semibold">{slot.outflows}</span>
                  </div>
                  <div>
                    <span className="font-bold text-slate-900 text-sm block">{slot.closing}</span>
                    <span className="text-[10px] text-emerald-600 font-semibold">{slot.net} net</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Currency Allocation Pool (1 col) */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs space-y-4">
          <div>
            <h3 className="font-bold text-slate-900 text-sm">Currency Allocation</h3>
            <p className="text-[11px] text-slate-500 font-mono">Multi-currency reserve distribution</p>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {accounts.map(acc => {
              const curSymbol = acc.currency === 'GBP' ? '£' : acc.currency === 'USD' ? '$' : acc.currency === 'EUR' ? '€' : 'CHF ';
              return (
                <div key={acc.id} className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-900">{acc.name}</span>
                    <span className="text-[10px] text-slate-500 uppercase">{acc.currency}</span>
                  </div>
                  <div className="text-base font-bold text-slate-900">
                    {curSymbol}{acc.availableBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>Account: {acc.accountNumber}</span>
                    <span className="text-emerald-600">Settled Real-time</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
