import React, { useState } from 'react';
import { useBanking } from '../../context/BankingContext';
import { 
  ArrowLeftRight, 
  TrendingUp, 
  TrendingDown, 
  CheckCircle2, 
  Lock
} from 'lucide-react';
import { Currency } from '../../types/banking';
import confetti from 'canvas-confetti';

export const FXCentreView: React.FC = () => {
  const { fxRates, executeFXTrade } = useBanking();

  const [fromCur, setFromCur] = useState<Currency>('GBP');
  const [toCur, setToCur] = useState<Currency>('USD');
  const [sellAmount, setSellAmount] = useState<string>('250000.00');
  const [isExecuting, setIsExecuting] = useState(false);
  const [tradeSuccess, setTradeSuccess] = useState<any>(null);

  // FX Rates Lookup
  const getRate = (from: Currency, to: Currency) => {
    if (from === to) return 1.0;
    const pair = `${from}/${to}`;
    const reversePair = `${to}/${from}`;

    const match = fxRates.find(r => r.pair === pair);
    if (match) return match.rate;

    const revMatch = fxRates.find(r => r.pair === reversePair);
    if (revMatch) return 1 / revMatch.rate;

    return 1.25;
  };

  const currentRate = getRate(fromCur, toCur);
  const numSell = parseFloat(sellAmount) || 0;
  const spreadFee = numSell * 0.0008; // 8 bps institutional tight spread
  const netBuy = (numSell - spreadFee) * currentRate;

  const handleExecuteTrade = () => {
    setIsExecuting(true);
    setTimeout(() => {
      executeFXTrade({
        sellCurrency: fromCur,
        sellAmount: numSell,
        buyCurrency: toCur,
        buyAmount: netBuy,
        rate: currentRate,
        fee: spreadFee,
        type: 'Spot'
      });
      setIsExecuting(false);
      const trade = {
        id: `FX-${Date.now().toString().slice(-6)}`,
        sold: `${fromCur} ${numSell.toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
        bought: `${toCur} ${netBuy.toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
        rate: currentRate.toFixed(4)
      };
      setTradeSuccess(trade);
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 }
      });
    }, 600);
  };

  const handleSwapPairs = () => {
    const temp = fromCur;
    setFromCur(toCur);
    setToCur(temp);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Institutional FX Dealing Desk</h1>
        <p className="text-xs text-slate-500 font-mono">
          Direct Tier-1 interbank liquidity · Sub-millisecond algorithmic spot execution & hedging
        </p>
      </div>

      {/* Live Interbank Currency Ticker Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {fxRates.map((rate) => {
          const isUp = rate.change24h >= 0;
          return (
            <div key={rate.pair} className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs font-mono text-slate-900">{rate.pair}</span>
                <span className={`text-[10px] font-mono font-semibold flex items-center ${isUp ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {isUp ? <TrendingUp className="w-2.5 h-2.5 mr-0.5" /> : <TrendingDown className="w-2.5 h-2.5 mr-0.5" />}
                  {isUp ? '+' : ''}{rate.change24h}%
                </span>
              </div>
              <div className="text-lg font-bold font-mono text-slate-900 tabular-nums">
                {rate.rate.toFixed(4)}
              </div>
              <div className="text-[9px] text-slate-400 font-mono flex justify-between">
                <span>Bid: {rate.bid}</span>
                <span>Ask: {rate.ask}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Dealing Console & Order Book */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Deal Ticket (2 cols) */}
        <div className="lg:col-span-2 bg-white rounded-xl p-6 border border-slate-200 shadow-2xs space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Spot Execution Ticket</h3>
              <p className="text-[11px] text-slate-500 font-mono">Guaranteed 30-second RFQ window</p>
            </div>
            <div className="flex items-center gap-2 text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-1 rounded border border-emerald-200">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              Streaming Direct Interbank Depth
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
            {/* Sell Leg */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Sell Currency</span>
              <div className="flex items-center gap-2">
                <select
                  value={fromCur}
                  onChange={(e) => setFromCur(e.target.value as Currency)}
                  className="px-2.5 py-2 border border-slate-300 rounded-lg font-mono font-bold text-xs bg-white focus:ring-1 focus:ring-amber-500"
                >
                  <option value="GBP">GBP (£)</option>
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="CHF">CHF</option>
                  <option value="JPY">JPY (¥)</option>
                </select>

                <input
                  type="number"
                  value={sellAmount}
                  onChange={(e) => setSellAmount(e.target.value)}
                  placeholder="250000.00"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-sm bg-white focus:ring-1 focus:ring-amber-500"
                />
              </div>
            </div>

            {/* Buy Leg */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Receive Currency</span>
                <button onClick={handleSwapPairs} className="text-[10px] font-mono text-amber-600 hover:underline flex items-center gap-1">
                  <ArrowLeftRight className="w-3 h-3" /> Swap
                </button>
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={toCur}
                  onChange={(e) => setToCur(e.target.value as Currency)}
                  className="px-2.5 py-2 border border-slate-300 rounded-lg font-mono font-bold text-xs bg-white focus:ring-1 focus:ring-amber-500"
                >
                  <option value="USD">USD ($)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="CHF">CHF</option>
                  <option value="JPY">JPY (¥)</option>
                </select>

                <div className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono font-bold text-sm bg-slate-100 text-slate-800 truncate">
                  {netBuy.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
              </div>
            </div>
          </div>

          {/* Pricing & Spread Breakdown */}
          <div className="p-4 bg-slate-900 text-white rounded-xl space-y-2 font-mono text-xs">
            <div className="flex justify-between text-slate-300">
              <span>Spot Fixing Rate:</span>
              <span className="font-bold text-amber-400">1 {fromCur} = {currentRate.toFixed(4)} {toCur}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span>Institutional Tight Spread (0.08%):</span>
              <span>{fromCur} {spreadFee.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span>Settlement Value Date:</span>
              <span className="text-emerald-400 font-bold">Same-Day RTGS (T+0 Immediate)</span>
            </div>
            <div className="flex justify-between pt-2 border-t border-slate-800 text-sm font-bold text-white">
              <span>Estimated Settlement Output:</span>
              <span className="text-amber-300">{toCur} {netBuy.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
          </div>

          {/* Execute Button */}
          <div>
            <button
              onClick={handleExecuteTrade}
              disabled={isExecuting || fromCur === toCur}
              className="w-full py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-mono font-bold rounded-lg text-sm shadow-md transition-all flex items-center justify-center gap-2 uppercase tracking-wide disabled:opacity-50"
            >
              {isExecuting ? (
                <>
                  <span className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                  Executing Spot Hedging Order...
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  Book & Execute FX Trade ({fromCur} → {toCur})
                </>
              )}
            </button>
          </div>

          {tradeSuccess && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-xs space-y-1 font-mono animate-in fade-in">
              <div className="font-bold text-emerald-800 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                FX Deal Ticket Confirmed: {tradeSuccess.id}
              </div>
              <div className="text-emerald-700">Sold: {tradeSuccess.sold} · Bought: {tradeSuccess.bought} @ {tradeSuccess.rate}</div>
            </div>
          )}
        </div>

        {/* Dealing Rules & Nostro Settlement (1 col) */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs space-y-4 text-xs">
          <h3 className="font-bold text-slate-900 text-sm">Settlement Nostro Coordinates</h3>
          <div className="space-y-3 font-mono">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
              <span className="text-[10px] text-slate-400 block uppercase">USD Nostro Correspondent</span>
              <div className="font-bold text-slate-900">JPMorgan Chase NY (CHASUS33)</div>
              <div className="text-[10px] text-slate-500">Acct: •••• 9920 · FEDWIRE Connected</div>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
              <span className="text-[10px] text-slate-400 block uppercase">EUR TARGET2 Settlement</span>
              <div className="font-bold text-slate-900">Deutsche Bank Frankfurt (DEUTDEDD)</div>
              <div className="text-[10px] text-slate-500">TARGET2 RTGS Direct Participant</div>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
              <span className="text-[10px] text-slate-400 block uppercase">CHF SIC Clearing</span>
              <div className="font-bold text-slate-900">UBS Switzerland AG (UBSWCHZH)</div>
              <div className="text-[10px] text-slate-500">Swiss Interbank Clearing Real-Time</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
