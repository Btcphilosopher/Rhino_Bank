import React from 'react';
import { BankingProvider, useBanking } from './context/BankingContext';
import { Sidebar } from './components/layout/Sidebar';
import { TopBar } from './components/layout/TopBar';
import { BottomTicker } from './components/layout/BottomTicker';
import { OverviewView } from './components/overview/OverviewView';
import { PaymentsListView } from './components/payments/PaymentsListView';
import { ApprovalsView } from './components/payments/ApprovalsView';
import { PaymentLinksView } from './components/payments/PaymentLinksView';
import { RecurringPaymentsView } from './components/payments/RecurringPaymentsView';
import { RefundsView } from './components/payments/RefundsView';
import { AccountsView } from './components/accounts/AccountsView';
import { CustomerAccountsView } from './components/accounts/CustomerAccountsView';
import { TransactionsLedgerView } from './components/accounts/TransactionsLedgerView';
import { InvoicingView } from './components/collections/InvoicingView';
import { TreasuryView } from './components/treasury/TreasuryView';
import { FXCentreView } from './components/treasury/FXCentreView';
import { RiskDashboardView } from './components/risk/RiskDashboardView';
import { ReconciliationView } from './components/reconciliation/ReconciliationView';
import { StatementsView } from './components/reconciliation/StatementsView';
import { AnalyticsView } from './components/analytics/AnalyticsView';
import { ReportsView } from './components/reports/ReportsView';
import { DevelopersView } from './components/developers/DevelopersView';
import { AdminView } from './components/admin/AdminView';

// Modals & Overlays
import { PaymentDetailModal } from './components/common/PaymentDetailModal';
import { SendPaymentModal } from './components/payments/SendPaymentModal';
import { CommandPalette } from './components/common/CommandPalette';
import { SystemStatusModal } from './components/common/SystemStatusModal';
import { NotificationDrawer } from './components/common/NotificationDrawer';

const MainContent: React.FC = () => {
  const { activeTab, environment } = useBanking();

  const renderView = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewView />;
      case 'payments-all':
        return <PaymentsListView />;
      case 'payments-approvals':
        return <ApprovalsView />;
      case 'payments-links':
        return <PaymentLinksView />;
      case 'payments-recurring':
        return <RecurringPaymentsView />;
      case 'payments-refunds':
        return <RefundsView />;
      case 'accounts-banks':
        return <AccountsView />;
      case 'accounts-customers':
        return <CustomerAccountsView />;
      case 'accounts-ledger':
        return <TransactionsLedgerView />;
      case 'collections-invoices':
        return <InvoicingView />;
      case 'treasury-cash':
        return <TreasuryView />;
      case 'treasury-fx':
        return <FXCentreView />;
      case 'risk-fraud':
        return <RiskDashboardView />;
      case 'reconciliation-match':
      case 'reconciliation-exceptions':
        return <ReconciliationView />;
      case 'reconciliation-statements':
        return <StatementsView />;
      case 'analytics-volume':
      case 'analytics-funnel':
        return <AnalyticsView />;
      case 'reports':
        return <ReportsView />;
      case 'developers-api':
      case 'developers-webhooks':
      case 'developers-logs':
        return <DevelopersView />;
      case 'admin-users':
      case 'admin-audit':
        return <AdminView />;
      default:
        return <OverviewView />;
    }
  };

  return (
    <div className="flex h-screen w-full bg-[#0A0A0A] text-[#E0E0E0] overflow-hidden font-sans selection:bg-amber-400 selection:text-slate-950">
      {/* Institutional Left Sidebar */}
      <Sidebar />

      {/* Main Column */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden bg-[#0A0A0A]">
        {/* Sandbox Indicator Banner if active */}
        {environment === 'Sandbox' && (
          <div className="bg-amber-500/15 border-b border-amber-500/30 text-amber-400 text-xs font-mono font-bold py-1.5 px-4 text-center tracking-wider shrink-0 flex items-center justify-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span>SANDBOX MODE ACTIVE — TRANSACTIONS SIMULATED WITH £1,000,000 TEST BALANCE</span>
          </div>
        )}

        {/* Top Control Bar */}
        <TopBar />

        {/* View Content Area */}
        <main className="flex-1 overflow-y-auto px-6 py-6 scroll-smooth bg-[#0A0A0A]">
          <div className="max-w-7xl mx-auto">
            {renderView()}
          </div>
        </main>

        {/* Bottom Financial Ticker */}
        <BottomTicker />
      </div>

      {/* Global Modals & Drawers */}
      <PaymentDetailModal />
      <SendPaymentModal />
      <CommandPalette />
      <SystemStatusModal />
      <NotificationDrawer />
    </div>
  );
};

export default function App() {
  return (
    <BankingProvider>
      <MainContent />
    </BankingProvider>
  );
}
