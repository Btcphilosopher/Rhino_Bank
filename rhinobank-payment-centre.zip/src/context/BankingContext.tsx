import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  BankAccount, 
  Payment, 
  LedgerEntry, 
  Customer, 
  Invoice, 
  PaymentLink, 
  RecurringPayment, 
  Refund, 
  ApprovalRequest, 
  FXRate, 
  FXTrade, 
  RiskAlert, 
  ReconciliationException, 
  ApiKeyItem, 
  ApiLog, 
  WebhookEvent, 
  AuditLog, 
  UserAccount, 
  NotificationItem,
  UserRole,
  Currency,
  PaymentPriority,
  RiskLevel
} from '../types/banking';
import { 
  INITIAL_ACCOUNTS, 
  INITIAL_PAYMENTS, 
  INITIAL_CUSTOMERS, 
  INITIAL_LEDGER_ENTRIES, 
  INITIAL_INVOICES, 
  INITIAL_APPROVALS, 
  INITIAL_FX_RATES, 
  INITIAL_FX_TRADES, 
  INITIAL_RISK_ALERTS, 
  INITIAL_EXCEPTIONS, 
  INITIAL_API_KEYS, 
  INITIAL_API_LOGS, 
  INITIAL_WEBHOOKS, 
  INITIAL_AUDIT_LOGS, 
  INITIAL_NOTIFICATIONS, 
  INITIAL_PAYMENT_LINKS, 
  INITIAL_RECURRING, 
  INITIAL_REFUNDS, 
  CURRENT_USER 
} from '../data/mockData';

interface SendPaymentParams {
  counterparty: string;
  counterpartyBank: string;
  counterpartyAccount?: string;
  counterpartySortCode?: string;
  amount: number;
  currency: Currency;
  fromAccountName: string;
  reference: string;
  priority: PaymentPriority;
  purpose?: string;
  invoiceNumber?: string;
}

interface BankingContextType {
  environment: 'Production' | 'Sandbox';
  setEnvironment: (env: 'Production' | 'Sandbox') => void;
  currentUser: UserAccount;
  switchRole: (role: UserRole) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  
  accounts: BankAccount[];
  payments: Payment[];
  ledger: LedgerEntry[];
  customers: Customer[];
  invoices: Invoice[];
  paymentLinks: PaymentLink[];
  recurring: RecurringPayment[];
  refunds: Refund[];
  approvals: ApprovalRequest[];
  fxRates: FXRate[];
  fxTrades: FXTrade[];
  riskAlerts: RiskAlert[];
  exceptions: ReconciliationException[];
  apiKeys: ApiKeyItem[];
  apiLogs: ApiLog[];
  webhooks: WebhookEvent[];
  auditLogs: AuditLog[];
  notifications: NotificationItem[];
  
  // UI states
  selectedPayment: Payment | null;
  setSelectedPayment: (payment: Payment | null) => void;
  isSendPaymentOpen: boolean;
  setIsSendPaymentOpen: (open: boolean) => void;
  isSystemStatusOpen: boolean;
  setIsSystemStatusOpen: (open: boolean) => void;
  isCommandPaletteOpen: boolean;
  setIsCommandPaletteOpen: (open: boolean) => void;
  isNotificationsOpen: boolean;
  setIsNotificationsOpen: (open: boolean) => void;
  globalSearchQuery: string;
  setGlobalSearchQuery: (query: string) => void;

  // Actions
  sendPayment: (params: SendPaymentParams) => Promise<Payment>;
  approvePayment: (approvalId: string) => void;
  rejectPayment: (approvalId: string, reason: string) => void;
  createInvoice: (inv: Partial<Invoice>) => void;
  payInvoice: (invoiceId: string) => void;
  createPaymentLink: (link: Partial<PaymentLink>) => void;
  processRefund: (params: { paymentId: string; amount: number; reason: any; type: 'Full Refund' | 'Partial Refund' }) => void;
  executeFXTrade: (params: { sellCurrency: Currency; sellAmount: number; buyCurrency: Currency; buyAmount: number; rate: number; fee: number; type: 'Spot' | 'Forward' | 'Hedge' }) => void;
  resolveRiskAlert: (alertId: string, action: 'release' | 'hold' | 'block', notes?: string) => void;
  resolveException: (exceptionId: string, action: 'match' | 'split' | 'ignore' | 'resolve') => void;
  generateApiKey: (name: string, scopes: string[]) => void;
  revokeApiKey: (keyId: string) => void;
  dispatchWebhookTest: (event: WebhookEvent['event']) => void;
  executeApiConsoleRequest: (method: 'GET' | 'POST' | 'PUT' | 'DELETE', endpoint: string, payload?: any) => Promise<any>;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  sandboxSimulate: (action: 'payment' | 'failure' | 'refund' | 'webhook' | 'settlement' | 'reset') => void;
}

const BankingContext = createContext<BankingContextType | undefined>(undefined);

export const BankingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [environment, setEnvironment] = useState<'Production' | 'Sandbox'>('Production');
  const [currentUser, setCurrentUser] = useState<UserAccount>(CURRENT_USER);
  const [activeTab, setActiveTab] = useState<string>('overview');

  const [accounts, setAccounts] = useState<BankAccount[]>(INITIAL_ACCOUNTS);
  const [payments, setPayments] = useState<Payment[]>(INITIAL_PAYMENTS);
  const [ledger, setLedger] = useState<LedgerEntry[]>(INITIAL_LEDGER_ENTRIES);
  const [customers, setCustomers] = useState<Customer[]>(INITIAL_CUSTOMERS);
  const [invoices, setInvoices] = useState<Invoice[]>(INITIAL_INVOICES);
  const [paymentLinks, setPaymentLinks] = useState<PaymentLink[]>(INITIAL_PAYMENT_LINKS);
  const [recurring, setRecurring] = useState<RecurringPayment[]>(INITIAL_RECURRING);
  const [refunds, setRefunds] = useState<Refund[]>(INITIAL_REFUNDS);
  const [approvals, setApprovals] = useState<ApprovalRequest[]>(INITIAL_APPROVALS);
  const [fxRates] = useState<FXRate[]>(INITIAL_FX_RATES);
  const [fxTrades, setFxTrades] = useState<FXTrade[]>(INITIAL_FX_TRADES);
  const [riskAlerts, setRiskAlerts] = useState<RiskAlert[]>(INITIAL_RISK_ALERTS);
  const [exceptions, setExceptions] = useState<ReconciliationException[]>(INITIAL_EXCEPTIONS);
  const [apiKeys, setApiKeys] = useState<ApiKeyItem[]>(INITIAL_API_KEYS);
  const [apiLogs, setApiLogs] = useState<ApiLog[]>(INITIAL_API_LOGS);
  const [webhooks, setWebhooks] = useState<WebhookEvent[]>(INITIAL_WEBHOOKS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  // Modals & Drawers
  const [selectedPayment, setSelectedPayment] = useState<Payment | null>(null);
  const [isSendPaymentOpen, setIsSendPaymentOpen] = useState(false);
  const [isSystemStatusOpen, setIsSystemStatusOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');

  // Keyboard shortcut for Command Palette (⌘K or Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const switchRole = (role: UserRole) => {
    setCurrentUser((prev) => ({
      ...prev,
      role
    }));
    // Add audit log
    addAuditLog('ROLE_SWITCHED', `Switched active RBAC profile to ${role}`, 'UserAccount', currentUser.id);
  };

  const addAuditLog = (action: string, detail: string, objectType: string, objectId: string, prev = 'N/A', next = 'N/A') => {
    const newLog: AuditLog = {
      id: `AUD_${Math.floor(1000 + Math.random() * 9000)}`,
      user: `${currentUser.name} (${currentUser.role})`,
      action,
      timestamp: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' BST',
      objectType,
      objectId,
      previousState: prev,
      newState: next,
      ipAddress: '194.72.10.45 (London, UK)',
      authorisationMethod: 'Hardware YubiKey Session'
    };
    setAuditLogs((prevLogs) => [newLog, ...prevLogs]);
  };

  const addNotification = (title: string, message: string, type: NotificationItem['type'], actionUrl?: string) => {
    const newNotif: NotificationItem = {
      id: `notif_${Date.now()}`,
      title,
      message,
      timeAgo: 'Just now',
      type,
      read: false,
      actionUrl
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const addApiLog = (method: 'GET' | 'POST' | 'PUT' | 'DELETE', endpoint: string, status: number, durationMs: number, customer?: string) => {
    const newLog: ApiLog = {
      id: `req_${Math.random().toString(36).substring(2, 9)}`,
      method,
      endpoint,
      status,
      durationMs,
      ip: '194.72.10.45',
      timestamp: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      requestId: `req_${Math.random().toString(36).substring(2, 10)}_live`,
      customer,
      apiKeyPrefix: 'rhn_live_99f8'
    };
    setApiLogs((prev) => [newLog, ...prev]);
  };

  const addWebhookEvent = (event: WebhookEvent['event'], payload: any) => {
    const newWh: WebhookEvent = {
      id: `wh_evt_${Date.now()}`,
      event,
      timestamp: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) + ', ' + new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
      status: 'Delivered',
      attempts: 1,
      endpointUrl: 'https://api.rhinobank-partner.example/webhooks',
      payload: {
        id: `evt_${Math.random().toString(36).substring(2, 8)}`,
        type: event,
        created_at: Date.now(),
        data: payload
      }
    };
    setWebhooks((prev) => [newWh, ...prev]);
  };

  // SEND PAYMENT WORKFLOW
  const sendPayment = async (params: SendPaymentParams): Promise<Payment> => {
    const paymentId = `RHN_${Math.random().toString(36).substring(2, 10).toUpperCase()}`;
    const nowTime = new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
    const todayFormatted = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) + `, ${nowTime}`;

    const requiresDualApproval = params.amount >= 100000;
    const isHighRisk = params.amount > 500000;
    const riskScore = isHighRisk ? 55 : params.amount > 50000 ? 25 : 10;
    const riskStatus: RiskLevel = riskScore > 70 ? 'HIGH' : riskScore > 40 ? 'MEDIUM' : 'LOW';

    const newPayment: Payment = {
      id: paymentId,
      amount: params.amount,
      currency: params.currency,
      direction: 'Outgoing',
      counterparty: params.counterparty,
      counterpartyBank: params.counterpartyBank || 'Barclays Bank UK',
      counterpartyAccount: params.counterpartyAccount || '•••• 8820',
      counterpartySortCode: params.counterpartySortCode || '20-04-12',
      fromAccount: params.fromAccountName,
      toAccount: `${params.counterparty} Operating`,
      reference: params.reference || `PAY-${Math.floor(1000 + Math.random() * 9000)}`,
      createdDate: todayFormatted,
      settlementDate: todayFormatted,
      status: requiresDualApproval ? 'Pending Approval' : 'Completed',
      fee: params.priority === 'CHAPS High Value' ? 15.00 : 0.00,
      priority: params.priority,
      bankReference: `RHN-${params.priority.substring(0, 3).toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`,
      riskScore,
      riskStatus,
      reconciliationStatus: requiresDualApproval ? 'Pending' : 'Matched',
      approvalsRequired: requiresDualApproval ? 2 : 1,
      approvalsCompleted: requiresDualApproval ? 0 : 1,
      approvedBy: requiresDualApproval ? [] : [currentUser.name],
      notes: params.purpose || 'Institutional commercial settlement',
      timeline: [
        { title: 'Created', status: 'completed', timestamp: nowTime, description: `Initiated by ${currentUser.name}` },
        { title: 'Authenticated', status: 'completed', timestamp: nowTime, description: 'Hardware MFA token validated' },
        { title: 'Risk checked', status: 'completed', timestamp: nowTime, description: `Rule Engine score: ${riskScore}/100` },
        { title: 'Sent', status: requiresDualApproval ? 'pending' : 'completed', timestamp: nowTime, description: requiresDualApproval ? 'Queued for dual treasury authorization' : 'Dispatched to clearing gateway' },
        { title: 'Accepted', status: requiresDualApproval ? 'pending' : 'completed', timestamp: nowTime, description: 'Counterparty bank ACK' },
        { title: 'Settled', status: requiresDualApproval ? 'pending' : 'completed', timestamp: nowTime, description: 'Double-entry ledger settled' },
      ],
      isSandbox: environment === 'Sandbox'
    };

    setPayments((prev) => [newPayment, ...prev]);

    // If no dual approval required, immediately debit accounts and update ledger
    if (!requiresDualApproval) {
      setAccounts((prevAccounts) =>
        prevAccounts.map((acc) => {
          if (acc.name === params.fromAccountName) {
            const newDebits = acc.debits + params.amount;
            const newClosing = acc.openingBalance + acc.credits - newDebits + acc.adjustments;
            return {
              ...acc,
              debits: newDebits,
              closingBalance: newClosing,
              availableBalance: newClosing - acc.reservedBalance
            };
          }
          return acc;
        })
      );

      // Create Ledger Entry
      const newLedgerEntry: LedgerEntry = {
        id: `LED_${Math.floor(100000 + Math.random() * 900000)}`,
        date: todayFormatted,
        description: `Outward ${params.priority} to ${params.counterparty}`,
        counterparty: params.counterparty,
        reference: newPayment.reference,
        amount: params.amount,
        currency: params.currency,
        type: 'Debit',
        accountName: params.fromAccountName,
        accountId: 'acc_gbp_op',
        status: 'Completed',
        runningBalance: 12482920.14 - params.amount
      };
      setLedger((prev) => [newLedgerEntry, ...prev]);

      addWebhookEvent('payment.completed', newPayment);
      addNotification('Payment Dispatched', `£${params.amount.toLocaleString()} to ${params.counterparty} settled irrevocably.`, 'payment', 'payments');
    } else {
      // Add to approvals list
      const newApproval: ApprovalRequest = {
        id: `APP_${Math.floor(1000 + Math.random() * 9000)}_${params.counterparty.substring(0, 6).toUpperCase()}`,
        paymentId: newPayment.id,
        counterparty: params.counterparty,
        amount: params.amount,
        currency: params.currency,
        approvalsRequired: 2,
        approvalsCompleted: 0,
        requestedBy: `${currentUser.name} (${currentUser.role})`,
        riskStatus,
        riskScore,
        purpose: params.purpose || 'High Value Commercial Transfer',
        createdAt: todayFormatted,
        status: 'Pending',
        category: 'High Value',
        approvers: [
          { name: 'Arthur Pendelton', role: 'Head of Prime Banking', status: 'Pending' },
          { name: 'Sarah Jenkins', role: 'Chief Risk Officer', status: 'Pending' }
        ]
      };
      setApprovals((prev) => [newApproval, ...prev]);
      addNotification('Approval Required', `£${params.amount.toLocaleString()} to ${params.counterparty} awaits 2 approvals.`, 'approval', 'approvals');
    }

    addAuditLog('PAYMENT_INITIATED', `Initiated outward payment of ${params.currency} ${params.amount.toLocaleString()} to ${params.counterparty}`, 'Payment', paymentId, 'NEW', requiresDualApproval ? 'PENDING_APPROVAL' : 'SETTLED');
    addApiLog('POST', '/v1/payments', 200, 72, params.counterparty);

    return newPayment;
  };

  const approvePayment = (approvalId: string) => {
    setApprovals((prev) =>
      prev.map((app) => {
        if (app.id === approvalId) {
          const newCompleted = app.approvalsCompleted + 1;
          const isFullyApproved = newCompleted >= app.approvalsRequired;
          
          if (isFullyApproved) {
            // Update the underlying payment
            setPayments((prevPayments) =>
              prevPayments.map((p) => {
                if (p.id === app.paymentId) {
                  return {
                    ...p,
                    status: 'Completed',
                    approvalsCompleted: app.approvalsRequired,
                    approvedBy: [...(p.approvedBy || []), currentUser.name],
                    reconciliationStatus: 'Matched',
                    timeline: p.timeline.map((t) => ({ ...t, status: 'completed' }))
                  };
                }
                return p;
              })
            );

            // Debit account
            setAccounts((prevAccounts) =>
              prevAccounts.map((acc) => {
                if (acc.id === 'acc_gbp_op' || acc.id === 'acc_treasury_res') {
                  const newDebits = acc.debits + app.amount;
                  const newClosing = acc.openingBalance + acc.credits - newDebits + acc.adjustments;
                  return {
                    ...acc,
                    debits: newDebits,
                    closingBalance: newClosing,
                    availableBalance: newClosing - acc.reservedBalance
                  };
                }
                return acc;
              })
            );

            addNotification('Payment Fully Approved', `Payment of £${app.amount.toLocaleString()} to ${app.counterparty} is now settled.`, 'payment');
          }

          return {
            ...app,
            approvalsCompleted: newCompleted,
            status: isFullyApproved ? 'Approved' : 'Pending',
            approvers: app.approvers.map((apr, idx) => idx === 0 ? { ...apr, status: 'Approved', timestamp: 'Just now' } : apr)
          };
        }
        return app;
      })
    );

    addAuditLog('APPROVAL_GRANTED', `Approved authorization request ${approvalId}`, 'ApprovalRequest', approvalId);
  };

  const rejectPayment = (approvalId: string, reason: string) => {
    setApprovals((prev) =>
      prev.map((app) => {
        if (app.id === approvalId) {
          setPayments((prevPayments) =>
            prevPayments.map((p) => (p.id === app.paymentId ? { ...p, status: 'Failed', notes: `Rejected: ${reason}` } : p))
          );
          return { ...app, status: 'Rejected' };
        }
        return app;
      })
    );
    addNotification('Payment Rejected', `Approval ${approvalId} was rejected: ${reason}`, 'approval');
    addAuditLog('APPROVAL_REJECTED', `Rejected approval ${approvalId}: ${reason}`, 'ApprovalRequest', approvalId);
  };

  const createInvoice = (inv: Partial<Invoice>) => {
    const newId = `RH-2026-${Math.floor(1850 + Math.random() * 1000)}`;
    const subtotal = inv.subtotal || 10000;
    const vat = subtotal * 0.2;
    const total = subtotal + vat;

    const newInvoice: Invoice = {
      id: newId,
      customerName: inv.customerName || 'Northbridge Engineering Ltd',
      customerId: inv.customerId || 'cust_northbridge',
      customerEmail: inv.customerEmail || 'billing@example.com',
      issueDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      dueDate: new Date(Date.now() + 14 * 86400000).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      currency: inv.currency || 'GBP',
      subtotal,
      vat,
      total,
      status: 'Pending',
      paymentReference: `INV-${newId}`,
      items: inv.items || [
        { id: '1', description: 'Institutional Treasury & Payment Services', quantity: 1, unitPrice: subtotal, vatRate: 0.2, amount: subtotal }
      ],
      notes: inv.notes || 'Payment terms: Net 14. Payable directly into RhinoBank Operating Account.'
    };

    setInvoices((prev) => [newInvoice, ...prev]);
    addAuditLog('INVOICE_CREATED', `Created invoice ${newId} for ${newInvoice.customerName} (${newInvoice.currency} ${total.toLocaleString()})`, 'Invoice', newId);
    addNotification('Invoice Issued', `Invoice ${newId} issued to ${newInvoice.customerName}`, 'payment', 'invoices');
    addWebhookEvent('invoice.created', newInvoice);
  };

  const payInvoice = (invoiceId: string) => {
    setInvoices((prev) =>
      prev.map((inv) => {
        if (inv.id === invoiceId) {
          // credit account
          setAccounts((prevAccounts) =>
            prevAccounts.map((acc) => {
              if (acc.currency === inv.currency) {
                const newCredits = acc.credits + inv.total;
                const newClosing = acc.openingBalance + newCredits - acc.debits + acc.adjustments;
                return {
                  ...acc,
                  credits: newCredits,
                  closingBalance: newClosing,
                  availableBalance: newClosing - acc.reservedBalance
                };
              }
              return acc;
            })
          );

          // Add payment
          const newPayment: Payment = {
            id: `RHN_INV_${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
            amount: inv.total,
            currency: inv.currency,
            direction: 'Incoming',
            counterparty: inv.customerName,
            counterpartyBank: 'RhinoBank Direct Pay',
            fromAccount: `${inv.customerName} Collection`,
            toAccount: 'GBP Operating Account',
            reference: inv.paymentReference,
            createdDate: 'Today, ' + new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
            settlementDate: 'Today, ' + new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
            status: 'Completed',
            fee: 0,
            priority: 'Instant Faster Payments',
            bankReference: `RHN-INV-SETTLE-${inv.id}`,
            riskScore: 5,
            riskStatus: 'LOW',
            reconciliationStatus: 'Matched',
            approvalsRequired: 0,
            approvalsCompleted: 0,
            timeline: [
              { title: 'Created', status: 'completed' },
              { title: 'Authenticated', status: 'completed' },
              { title: 'Risk checked', status: 'completed' },
              { title: 'Sent', status: 'completed' },
              { title: 'Accepted', status: 'completed' },
              { title: 'Settled', status: 'completed' },
            ]
          };
          setPayments((p) => [newPayment, ...p]);

          return {
            ...inv,
            status: 'Paid',
            paidAt: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) + ', ' + new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
          };
        }
        return inv;
      })
    );

    addNotification('Invoice Paid', `Invoice ${invoiceId} marked as settled and cleared.`, 'payment');
    addWebhookEvent('invoice.paid', { invoiceId });
  };

  const createPaymentLink = (link: Partial<PaymentLink>) => {
    const slug = link.slug || `pay-${Math.random().toString(36).substring(2, 7)}`;
    const newLink: PaymentLink = {
      id: `plink_${Date.now()}`,
      slug,
      url: `https://pay.rhinobank.example/l/${slug}`,
      title: link.title || 'Corporate Retainer Payment',
      description: link.description || 'Institutional direct clearing payment link',
      amount: link.amount || 5000,
      currency: link.currency || 'GBP',
      customerName: link.customerName || 'General Institutional Client',
      reference: `LNK-RHN-${Math.floor(1000 + Math.random() * 9000)}`,
      createdDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      expiryDate: new Date(Date.now() + 30 * 86400000).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      status: 'Active',
      clicks: 0,
      paymentAttempts: 0,
      successfulPayments: 0,
      revenue: 0
    };
    setPaymentLinks((prev) => [newLink, ...prev]);
    addAuditLog('PAYMENT_LINK_CREATED', `Generated payment link ${slug} for ${newLink.currency} ${newLink.amount.toLocaleString()}`, 'PaymentLink', newLink.id);
  };

  const processRefund = ({ paymentId, amount, reason, type }: { paymentId: string; amount: number; reason: any; type: 'Full Refund' | 'Partial Refund' }) => {
    const target = payments.find((p) => p.id === paymentId);
    if (!target) return;

    const newRefund: Refund = {
      id: `RFN-${Math.floor(1000 + Math.random() * 9000)}`,
      originalPaymentId: paymentId,
      counterparty: target.counterparty,
      amount,
      currency: target.currency,
      reason,
      status: 'Completed',
      requestedBy: currentUser.name,
      authorisedBy: currentUser.name,
      createdAt: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) + ', ' + new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
      originalAmount: target.amount,
      type
    };

    setRefunds((prev) => [newRefund, ...prev]);
    setPayments((prev) =>
      prev.map((p) => (p.id === paymentId ? { ...p, status: 'Refunded', notes: `Refunded £${amount.toLocaleString()} - Reason: ${reason}` } : p))
    );

    addAuditLog('REFUND_ISSUED', `Issued ${type} of ${target.currency} ${amount.toLocaleString()} for ${paymentId}`, 'Refund', newRefund.id);
    addNotification('Refund Processed', `${newRefund.id} of ${target.currency} ${amount.toLocaleString()} settled.`, 'payment');
    addWebhookEvent('payment.refunded', newRefund);
  };

  const executeFXTrade = ({ sellCurrency, sellAmount, buyCurrency, buyAmount, rate, fee, type }: { sellCurrency: Currency; sellAmount: number; buyCurrency: Currency; buyAmount: number; rate: number; fee: number; type: 'Spot' | 'Forward' | 'Hedge' }) => {
    const tradeId = `FX_TRD_${Math.floor(10000 + Math.random() * 90000)}`;
    const newTrade: FXTrade = {
      id: tradeId,
      sellCurrency,
      sellAmount,
      buyCurrency,
      buyAmount,
      rate,
      fee,
      type,
      settlementDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      executedBy: `${currentUser.name} (${currentUser.role})`,
      status: 'Settled',
      timestamp: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
    };

    setFxTrades((prev) => [newTrade, ...prev]);

    // Update Accounts (deduct sold currency, add bought currency)
    setAccounts((prev) =>
      prev.map((acc) => {
        if (acc.currency === sellCurrency) {
          const newDebits = acc.debits + sellAmount + fee;
          const newClosing = acc.openingBalance + acc.credits - newDebits + acc.adjustments;
          return { ...acc, debits: newDebits, closingBalance: newClosing, availableBalance: newClosing - acc.reservedBalance };
        }
        if (acc.currency === buyCurrency) {
          const newCredits = acc.credits + buyAmount;
          const newClosing = acc.openingBalance + newCredits - acc.debits + acc.adjustments;
          return { ...acc, credits: newCredits, closingBalance: newClosing, availableBalance: newClosing - acc.reservedBalance };
        }
        return acc;
      })
    );

    addAuditLog('FX_TRADE_EXECUTED', `Executed ${type} trade: Sold ${sellCurrency} ${sellAmount.toLocaleString()} -> Bought ${buyCurrency} ${buyAmount.toLocaleString()} @ ${rate}`, 'FXTrade', tradeId);
    addNotification('FX Trade Settled', `Sold ${sellCurrency} ${sellAmount.toLocaleString()} for ${buyCurrency} ${buyAmount.toLocaleString()}`, 'liquidity', 'treasury');
  };

  const resolveRiskAlert = (alertId: string, action: 'release' | 'hold' | 'block', notes?: string) => {
    setRiskAlerts((prev) =>
      prev.map((a) => {
        if (a.id === alertId) {
          const statusMap = {
            release: 'Released' as const,
            hold: 'Held' as const,
            block: 'Blocked' as const
          };
          return { ...a, status: statusMap[action], actionNotes: notes || `Actioned by ${currentUser.name}` };
        }
        return a;
      })
    );

    addAuditLog('RISK_ALERT_ACTIONED', `Risk alert ${alertId} set to ${action.toUpperCase()}`, 'RiskAlert', alertId);
    addNotification('Risk Action Applied', `Alert ${alertId} updated to ${action.toUpperCase()}`, 'risk');
  };

  const resolveException = (exceptionId: string, action: 'match' | 'split' | 'ignore' | 'resolve') => {
    setExceptions((prev) =>
      prev.map((exc) => {
        if (exc.id === exceptionId) {
          const statusMap = {
            match: 'Matched' as const,
            split: 'Investigating' as const,
            ignore: 'Ignored' as const,
            resolve: 'Resolved' as const
          };
          return { ...exc, status: statusMap[action] };
        }
        return exc;
      })
    );
    addAuditLog('RECONCILIATION_EXCEPTION_RESOLVED', `Exception ${exceptionId} actioned with ${action}`, 'ReconciliationException', exceptionId);
    addNotification('Reconciliation Updated', `Exception ${exceptionId} marked as ${action.toUpperCase()}`, 'settlement');
  };

  const generateApiKey = (name: string, scopes: string[]) => {
    const keyPrefix = `rhn_${environment.toLowerCase()}_${Math.random().toString(36).substring(2, 6)}`;
    const newKey: ApiKeyItem = {
      id: `key_${Date.now()}`,
      name,
      keyPrefix,
      keyMasked: `${keyPrefix}••••••••••••••••${Math.random().toString(36).substring(2, 6)}`,
      environment,
      created: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      lastUsed: 'Never',
      scopes,
      status: 'Active'
    };
    setApiKeys((prev) => [newKey, ...prev]);
    addAuditLog('API_KEY_GENERATED', `Provisioned API credentials for "${name}" with scopes [${scopes.join(', ')}]`, 'ApiKeyItem', newKey.id);
    addNotification('API Key Created', `New API key "${name}" generated successfully.`, 'api');
  };

  const revokeApiKey = (keyId: string) => {
    setApiKeys((prev) => prev.map((k) => (k.id === keyId ? { ...k, status: 'Revoked' } : k)));
    addAuditLog('API_KEY_REVOKED', `Revoked API key ${keyId}`, 'ApiKeyItem', keyId);
  };

  const dispatchWebhookTest = (event: WebhookEvent['event']) => {
    addWebhookEvent(event, {
      test_dispatch: true,
      triggered_by: currentUser.name,
      sample_id: `RHN_TEST_${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: Date.now()
    });
    addNotification('Webhook Sent', `Dispatched test event "${event}" to configured endpoints.`, 'api');
  };

  const executeApiConsoleRequest = async (method: 'GET' | 'POST' | 'PUT' | 'DELETE', endpoint: string, payload?: any) => {
    const duration = Math.floor(25 + Math.random() * 70);
    addApiLog(method, endpoint, 200, duration, 'Developer Console Sandbox');
    return {
      status: 200,
      timestamp: new Date().toISOString(),
      endpoint,
      method,
      data: payload || { message: 'Request executed successfully on RhinoBank Banking Engine' }
    };
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  // SANDBOX SIMULATOR
  const sandboxSimulate = (action: 'payment' | 'failure' | 'refund' | 'webhook' | 'settlement' | 'reset') => {
    if (action === 'payment') {
      sendPayment({
        counterparty: 'Synthetic Test Enterprise Ltd',
        counterpartyBank: 'RhinoBank Sandbox Test Rail',
        amount: 50000.00,
        currency: 'GBP',
        fromAccountName: 'GBP Operating Account',
        reference: 'SANDBOX-TX-9901',
        priority: 'Instant Faster Payments',
        purpose: 'Sandbox simulated instant transfer'
      });
    } else if (action === 'failure') {
      const failedPayment: Payment = {
        id: `RHN_FAIL_${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
        amount: 98000.00,
        currency: 'GBP',
        direction: 'Outgoing',
        counterparty: 'Simulated Invalid Beneficiary Corp',
        counterpartyBank: 'Invalid Clearing House Bank',
        fromAccount: 'GBP Operating Account',
        toAccount: 'Invalid Account',
        reference: 'SANDBOX-FAIL-01',
        createdDate: 'Just now',
        settlementDate: 'N/A',
        status: 'Failed',
        fee: 0,
        priority: 'Instant Faster Payments',
        bankReference: 'RHN-ERR-9912',
        riskScore: 89,
        riskStatus: 'HIGH',
        reconciliationStatus: 'Exception',
        approvalsRequired: 1,
        approvalsCompleted: 0,
        notes: 'Simulated failure: Beneficiary IBAN checksum check failed in Clearing Gateway.',
        timeline: [
          { title: 'Created', status: 'completed' },
          { title: 'Authenticated', status: 'completed' },
          { title: 'Risk checked', status: 'failed', description: 'Beneficiary account validation error' }
        ],
        isSandbox: true
      };
      setPayments((prev) => [failedPayment, ...prev]);
      addNotification('Simulated Payment Failed', 'Beneficiary IBAN checksum failed as expected in sandbox.', 'payment');
    } else if (action === 'webhook') {
      dispatchWebhookTest('payment.created');
    } else if (action === 'settlement') {
      addNotification('Settlement Simulation', 'Triggered full end-of-day RTGS batch reconciliation cycle.', 'settlement');
    } else if (action === 'reset') {
      setPayments(INITIAL_PAYMENTS);
      setAccounts(INITIAL_ACCOUNTS);
      setLedger(INITIAL_LEDGER_ENTRIES);
      setApprovals(INITIAL_APPROVALS);
      addNotification('Sandbox Reset', 'All balances, payments, and ledger entries reset to factory test data.', 'liquidity');
    }
  };

  return (
    <BankingContext.Provider
      value={{
        environment,
        setEnvironment,
        currentUser,
        switchRole,
        activeTab,
        setActiveTab,
        accounts,
        payments,
        ledger,
        customers,
        invoices,
        paymentLinks,
        recurring,
        refunds,
        approvals,
        fxRates,
        fxTrades,
        riskAlerts,
        exceptions,
        apiKeys,
        apiLogs,
        webhooks,
        auditLogs,
        notifications,
        selectedPayment,
        setSelectedPayment,
        isSendPaymentOpen,
        setIsSendPaymentOpen,
        isSystemStatusOpen,
        setIsSystemStatusOpen,
        isCommandPaletteOpen,
        setIsCommandPaletteOpen,
        isNotificationsOpen,
        setIsNotificationsOpen,
        globalSearchQuery,
        setGlobalSearchQuery,
        sendPayment,
        approvePayment,
        rejectPayment,
        createInvoice,
        payInvoice,
        createPaymentLink,
        processRefund,
        executeFXTrade,
        resolveRiskAlert,
        resolveException,
        generateApiKey,
        revokeApiKey,
        dispatchWebhookTest,
        executeApiConsoleRequest,
        markNotificationRead,
        markAllNotificationsRead,
        sandboxSimulate
      }}
    >
      {children}
    </BankingContext.Provider>
  );
};

export const useBanking = () => {
  const context = useContext(BankingContext);
  if (!context) {
    throw new Error('useBanking must be used within a BankingProvider');
  }
  return context;
};
