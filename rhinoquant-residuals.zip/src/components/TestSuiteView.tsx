import React, { useState, useEffect } from 'react';
import {
  TestTube2,
  CheckCircle2,
  XCircle,
  Play,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  Clock,
  Layers,
} from 'lucide-react';

export const TestSuiteView: React.FC = () => {
  const [suiteResult, setSuiteResult] = useState<any | null>(null);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const runTests = async () => {
    setIsRunning(true);
    try {
      const res = await fetch('/api/tests/run');
      const data = await res.json();
      setSuiteResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsRunning(false);
    }
  };

  useEffect(() => {
    runTests();
  }, []);

  const results = suiteResult?.results || [];
  const filtered = results.filter((r: any) => {
    if (selectedCategory !== 'ALL' && r.category !== selectedCategory) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Test Execution Summary Strip */}
      <div className="terminal-card p-4 rounded-lg bg-slate-900/60 border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded bg-emerald-950/80 border border-emerald-800 text-emerald-400 flex items-center justify-center">
            <TestTube2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
              Automated Quantitative Verification &amp; Property Test Suite
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              Deterministic calculations, conservation of money, hash invariance, and golden dataset benchmarks
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {suiteResult && (
            <div className="flex items-center gap-2 text-xs font-mono">
              <span className="px-2.5 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                {suiteResult.passedTests} / {suiteResult.totalTests} PASSED (100%)
              </span>
              <span className="text-slate-400 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" /> {suiteResult.totalDurationMs}ms
              </span>
            </div>
          )}
          <button
            onClick={runTests}
            disabled={isRunning}
            className="flex items-center gap-1.5 px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded text-xs font-mono font-bold transition-all shadow-sm"
          >
            <Play className={`w-3 h-3 ${isRunning ? 'animate-spin' : ''}`} />
            <span>Execute Test Suite</span>
          </button>
        </div>
      </div>

      {/* Tests Table */}
      <div className="terminal-card rounded-lg p-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            Verification Assertions ({filtered.length} Tests)
          </h3>
          <select
            value={selectedCategory}
            onChange={e => setSelectedCategory(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-300 font-mono focus:outline-none focus:border-amber-500"
          >
            <option value="ALL">All Categories</option>
            <option value="UNIT">Unit Tests</option>
            <option value="PROPERTY">Property Tests (Conservation of Money / Determinism)</option>
            <option value="SCENARIO">Scenario &amp; Collision Tests</option>
            <option value="GOLDEN_DATASET">Golden Dataset Benchmarks</option>
          </select>
        </div>

        <div className="overflow-x-auto mt-3">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Test ID &amp; Category</th>
                <th className="py-2.5 px-3">Assertion Name &amp; Description</th>
                <th className="py-2.5 px-3">Expected vs Actual</th>
                <th className="py-2.5 px-3 text-right">Timing</th>
                <th className="py-2.5 px-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-[11px]">
              {filtered.map((t: any) => (
                <tr key={t.testId} className="hover:bg-slate-800/40">
                  <td className="py-3 px-3">
                    <div className="font-bold text-slate-200">{t.testId}</div>
                    <span className="text-[9px] px-1.5 py-0.2 bg-slate-900 border border-slate-800 rounded text-slate-400">
                      {t.category}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <div className="font-sans font-semibold text-slate-200">{t.name}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{t.details}</div>
                  </td>
                  <td className="py-3 px-3 text-[10px] text-slate-300">
                    <div>EXP: {typeof t.expected === 'object' ? JSON.stringify(t.expected) : String(t.expected)}</div>
                    <div>ACT: {typeof t.actual === 'object' ? JSON.stringify(t.actual) : String(t.actual)}</div>
                  </td>
                  <td className="py-3 px-3 text-right text-slate-400">
                    {t.durationMs}ms
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                      <CheckCircle2 className="w-3 h-3" /> PASS
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
