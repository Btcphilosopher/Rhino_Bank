import React, { useState, useEffect } from 'react';
import {
  Asset,
  Contract,
  NormalisedRevenueRecord,
  Participant,
  CalculationAuditTrail,
  WaterfallNode,
  RuleType,
} from '../domain/types';
import {
  Cpu,
  ShieldCheck,
  Hash,
  ArrowDownRight,
  Layers,
  Sparkles,
  RefreshCw,
  FileCheck2,
  Lock,
  Wallet,
  Coins,
  ChevronRight,
  Info,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from 'recharts';

interface CalculationTerminalProps {
  assets: Asset[];
  contracts: Contract[];
  participants: Participant[];
  revenueRecords: NormalisedRevenueRecord[];
  currencySymbol: string;
}

export const CalculationTerminal: React.FC<CalculationTerminalProps> = ({
  assets,
  contracts,
  participants,
  revenueRecords,
  currencySymbol,
}) => {
  const [selectedRevenueId, setSelectedRevenueId] = useState<string>(revenueRecords[0]?.id || '');
  const [selectedContractId, setSelectedContractId] = useState<string>(contracts[0]?.id || '');
  const [selectedParticipantId, setSelectedParticipantId] = useState<string>(participants[0]?.id || '');

  const [grossOverride, setGrossOverride] = useState<number>(0);
  const [advanceOverride, setAdvanceOverride] = useState<number>(0);
  const [isCalculating, setIsCalculating] = useState<boolean>(false);

  const [calcResult, setCalcResult] = useState<CalculationAuditTrail | null>(null);
  const [waterfallResult, setWaterfallResult] = useState<any | null>(null);

  const activeRevenueRecord = revenueRecords.find(r => r.id === selectedRevenueId) || revenueRecords[0];
  const activeContract = contracts.find(c => c.id === selectedContractId) || contracts[0];
  const activeParticipant = participants.find(p => p.id === selectedParticipantId) || participants[0];

  useEffect(() => {
    if (activeRevenueRecord) {
      setGrossOverride(activeRevenueRecord.normalizedGrossGBP);
    }
  }, [selectedRevenueId]);

  useEffect(() => {
    if (activeContract && activeParticipant) {
      const adv = activeContract.advances.find(a => a.participantId === activeParticipant.id);
      setAdvanceOverride(adv ? adv.remainingBalance : 0);
    }
  }, [selectedContractId, selectedParticipantId]);

  // Execute Calculation API
  const runCalculation = async () => {
    setIsCalculating(true);
    try {
      // 1. Residual Calc
      const resCalc = await fetch('/api/calculate/residual', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          revenueRecordId: selectedRevenueId,
          contractId: selectedContractId,
          participantId: selectedParticipantId,
          advanceBalanceOverride: advanceOverride,
        }),
      });
      const dataCalc = await resCalc.json();
      setCalcResult(dataCalc);

      // 2. Waterfall Calc
      const resWater = await fetch('/api/calculate/waterfall', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contractId: selectedContractId,
          revenueRecordId: selectedRevenueId,
        }),
      });
      const dataWater = await resWater.json();
      setWaterfallResult(dataWater);
    } catch (e) {
      console.error('Calculation failed', e);
    } finally {
      setIsCalculating(false);
    }
  };

  useEffect(() => {
    runCalculation();
  }, [selectedRevenueId, selectedContractId, selectedParticipantId, advanceOverride]);

  // Waterfall Chart data
  const waterfallChartData = waterfallResult
    ? [
        {
          name: 'Gross Inflow',
          Amount: waterfallResult.grossRevenueGBP,
          fill: '#3b82f6',
        },
        {
          name: 'Distribution Fees',
          Amount: -waterfallResult.totalDistributionFeesGBP,
          fill: '#f43f5e',
        },
        {
          name: 'Guild Reserves & Off-Top',
          Amount: -waterfallResult.totalOffTheTopExpensesGBP,
          fill: '#fb7185',
        },
        {
          name: 'Producer Retained',
          Amount: waterfallResult.netProducerShareGBP,
          fill: '#10b981',
        },
        {
          name: 'Participant Pool',
          Amount: waterfallResult.totalParticipantPoolGBP,
          fill: '#f59e0b',
        },
      ]
    : [];

  return (
    <div className="space-y-6">
      {/* Control Configuration Bar */}
      <div className="terminal-card p-4 rounded-lg bg-slate-900/60 border-slate-800">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-amber-400" />
            <h2 className="font-display font-bold text-sm text-slate-100">
              Deterministic Residual &amp; Royalty Calculation Engine
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
              AUDITABLE HASH INVARIANCE ACTIVE
            </span>
            <button
              onClick={runCalculation}
              disabled={isCalculating}
              className="flex items-center gap-1.5 px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded text-xs font-mono font-bold transition-all shadow-sm"
            >
              <RefreshCw className={`w-3 h-3 ${isCalculating ? 'animate-spin' : ''}`} />
              <span>Execute Engine</span>
            </button>
          </div>
        </div>

        {/* Input Selectors */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mt-3 text-xs font-mono">
          <div>
            <label className="text-slate-400 block mb-1">1. Revenue Source Record</label>
            <select
              value={selectedRevenueId}
              onChange={e => setSelectedRevenueId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-500"
            >
              {revenueRecords.map(r => (
                <option key={r.id} value={r.id}>
                  {r.id} ({r.platform} - {r.channel} - {r.period})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">2. Target Contract</label>
            <select
              value={selectedContractId}
              onChange={e => setSelectedContractId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-500"
            >
              {contracts.map(c => (
                <option key={c.id} value={c.id}>
                  {c.id} - {c.title.substring(0, 32)}... (v{c.version})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">3. Participant Beneficiary</label>
            <select
              value={selectedParticipantId}
              onChange={e => setSelectedParticipantId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-500"
            >
              {participants.map(p => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.role}) - {p.taxJurisdiction}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">4. Unrecouped Advance Override ({currencySymbol})</label>
            <input
              type="number"
              value={advanceOverride}
              onChange={e => setAdvanceOverride(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-500 font-mono"
            />
          </div>
        </div>
      </div>

      {/* Main Calculation View: Trace Steps + Cascade Waterfall */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 Cols: Step-by-Step Calculation Trace */}
        <div className="lg:col-span-7 terminal-card rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
              <FileCheck2 className="w-4 h-4 text-emerald-400" />
              Contractual Calculation Trace &amp; Audit Trail
            </h3>
            {calcResult && (
              <span className="text-[10px] font-mono text-slate-400">
                ID: <span className="text-amber-400 font-semibold">{calcResult.calculationId}</span>
              </span>
            )}
          </div>

          {calcResult ? (
            <div className="space-y-3 text-xs font-mono">
              {/* Step 1: Gross Ingestion */}
              <div className="p-3 bg-slate-950/70 rounded border border-slate-800 flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 text-slate-300 font-bold font-sans">
                    <span className="w-5 h-5 rounded-full bg-blue-950 text-blue-400 flex items-center justify-center text-[10px] border border-blue-800">1</span>
                    Source Ingestion &amp; FX Normalisation
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Channel: <span className="text-slate-200">{activeRevenueRecord?.channel || 'N/A'}</span> • Platform: <span className="text-slate-200">{activeRevenueRecord?.platform || 'N/A'}</span> • Territory: <span className="text-slate-200">{activeRevenueRecord?.territory || 'N/A'}</span>
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Source: {activeRevenueRecord?.sourceCurrency || 'GBP'} {(activeRevenueRecord?.sourceGross ?? 0).toLocaleString()} @ FX {activeRevenueRecord?.fxRateToGBP ?? 1}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase block">Normalized Gross</span>
                  <span className="text-sm font-bold text-slate-100 font-mono">
                    {currencySymbol}{(calcResult?.grossRevenue ?? 0).toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Step 2: Deductions Cascade */}
              <div className="p-3 bg-slate-950/70 rounded border border-slate-800">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2 text-slate-300 font-bold font-sans">
                    <span className="w-5 h-5 rounded-full bg-rose-950 text-rose-400 flex items-center justify-center text-[10px] border border-rose-800">2</span>
                    Contractual Deductions &amp; Off-The-Top Reserves ({calcResult?.deductions?.length ?? 0} Rules)
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase block">Total Deductions</span>
                    <span className="text-sm font-bold text-rose-400 font-mono">
                      -{currencySymbol}{(calcResult?.totalDeductions ?? 0).toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="mt-2 space-y-1.5 pl-7">
                  {calcResult?.deductions?.map((d, i) => (
                    <div key={i} className="flex items-center justify-between text-[11px] text-slate-400 border-l-2 border-slate-800 pl-2">
                      <span>{d.name} ({d.appliedRate ? `${(d.appliedRate * 100).toFixed(1)}%` : 'Fixed'})</span>
                      <span className="text-rose-400 font-semibold">-{currencySymbol}{(d.calculatedAmount ?? 0).toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Step 3: Participation Net Base & Rule Execution */}
              <div className="p-3 bg-slate-950/70 rounded border border-slate-800">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 text-slate-300 font-bold font-sans">
                      <span className="w-5 h-5 rounded-full bg-amber-950 text-amber-400 flex items-center justify-center text-[10px] border border-amber-800">3</span>
                      Participation Base &amp; {calcResult?.appliedRuleType || 'Rule'} Execution
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Participation Base: <span className="text-slate-200 font-semibold">{currencySymbol}{(calcResult?.contractualNetRevenue ?? 0).toLocaleString()}</span>
                    </p>
                    <p className="text-[11px] text-slate-400">
                      Rule Applied: {((calcResult?.appliedRatePct ?? 0) * 100).toFixed(2)}% rate ({activeContract?.title || 'Contract'})
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase block">Gross Entitlement</span>
                    <span className="text-sm font-bold text-amber-400 font-mono">
                      {currencySymbol}{(calcResult?.grossEntitlement ?? 0).toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Tier Breakdowns if tiered */}
                {calcResult?.tierBreakdowns && calcResult.tierBreakdowns.length > 0 && (
                  <div className="mt-2.5 pt-2 border-t border-slate-800/80 pl-7 space-y-1">
                    <span className="text-[10px] text-slate-400 font-bold block">TIER ESCALATION STEPS:</span>
                    {calcResult.tierBreakdowns.map((tb, idx) => (
                      <div key={idx} className="flex items-center justify-between text-[11px] text-slate-400">
                        <span>{tb.tierDescription} ({currencySymbol}{(tb.portionInTier ?? 0).toLocaleString()} in band)</span>
                        <span className="text-slate-200 font-semibold">+{currencySymbol}{(tb.tierRoyaltyAmount ?? 0).toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Step 4: Advance Recoupment Offsets */}
              <div className="p-3 bg-slate-950/70 rounded border border-slate-800 flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 text-slate-300 font-bold font-sans">
                    <span className="w-5 h-5 rounded-full bg-purple-950 text-purple-400 flex items-center justify-center text-[10px] border border-purple-800">4</span>
                    Advance Recoupment Offset
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Unrecouped Advance: {currencySymbol}{(advanceOverride ?? 0).toLocaleString()} • Recoupment Policy: <span className="text-slate-200">{activeContract?.recoupmentPolicy || 'CROSS_COLLATERALIZED'}</span>
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Remaining Unrecouped Balance After: <span className="text-purple-300 font-semibold">{currencySymbol}{(calcResult?.remainingAdvanceBalanceAfter ?? 0).toLocaleString()}</span>
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase block">Recouped Offset</span>
                  <span className="text-sm font-bold text-purple-400 font-mono">
                    -{currencySymbol}{(calcResult?.advanceRecoupmentDeduction ?? 0).toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Step 5: Tax Withholding & Net Disbursement */}
              <div className="p-3 bg-slate-900 rounded border border-amber-500/40 flex items-start justify-between shadow-inner">
                <div>
                  <div className="flex items-center gap-2 text-amber-300 font-bold font-sans text-sm">
                    <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center text-[10px] font-extrabold">5</span>
                    Net Payable Cash Disbursement
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Tax Withholding: -{currencySymbol}{(calcResult?.taxWithholdingAmount ?? 0).toLocaleString()} ({((activeParticipant?.withholdingTaxPct ?? 0) * 100).toFixed(0)}% {activeParticipant?.taxJurisdiction || ''} Treaty)
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Beneficiary Account: <span className="text-slate-300 font-mono">{activeParticipant?.payoutAccountIban || 'N/A'}</span>
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-emerald-400 uppercase font-bold block">Final Net Payable</span>
                  <span className="text-xl font-bold text-emerald-400 font-mono">
                    {currencySymbol}{(calcResult?.netAmountPayable ?? 0).toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Cryptographic Hash Seal */}
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[10px] text-slate-400 font-mono">
                <div className="flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>IN: <span className="text-slate-300">{calcResult.inputHash}</span></span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span>OUT: <span className="text-slate-300">{calcResult.outputHash}</span></span>
                </div>
                <span className="text-emerald-400 font-bold">100% REPRODUCIBLE</span>
              </div>
            </div>
          ) : (
            <div className="py-12 text-center text-slate-500 font-mono text-xs">
              Calculating deterministic trace...
            </div>
          )}
        </div>

        {/* Right 5 Cols: Participation Waterfall Breakdown */}
        <div className="lg:col-span-5 space-y-6">
          {/* Waterfall Chart */}
          <div className="terminal-card rounded-lg p-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
                <Layers className="w-4 h-4 text-blue-400" />
                Revenue Cascade Waterfall
              </h3>
              <span className="text-[10px] font-mono text-slate-400">Gross to Net Pool</span>
            </div>

            <div className="h-56 mt-3">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={waterfallChartData} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                  <XAxis dataKey="name" stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 10 }} interval={0} angle={-15} textAnchor="end" />
                  <YAxis stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 10 }} tickFormatter={(val) => `£${(Math.abs(Number(val) || 0) / 1000).toFixed(0)}k`} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '11px', fontFamily: 'JetBrains Mono' }}
                    formatter={(val: any) => [`${currencySymbol}${Math.abs(Number(val) || 0).toLocaleString()}`, 'Amount']}
                  />
                  <Bar dataKey="Amount" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Participant Breakdown Table */}
            {waterfallResult?.participantDisbursements && (
              <div className="mt-4 pt-3 border-t border-slate-800">
                <span className="text-[11px] font-mono text-slate-400 block mb-2 font-semibold uppercase">
                  Participant Pool Allocation ({waterfallResult.participantDisbursements.length} Beneficiaries)
                </span>
                <div className="space-y-1.5 text-xs font-mono">
                  {waterfallResult.participantDisbursements.map((pd: any, idx: number) => (
                    <div key={idx} className="p-2 bg-slate-950 rounded border border-slate-800/80 flex items-center justify-between">
                      <div>
                        <span className="font-sans font-semibold text-slate-200 block">{pd?.participantName || 'Participant'}</span>
                        <span className="text-[10px] text-slate-400">{pd?.role || 'Role'} ({((pd?.sharePercentage ?? 0) * 100).toFixed(1)}% share)</span>
                      </div>
                      <div className="text-right">
                        <span className="text-amber-400 font-bold block">{currencySymbol}{(pd?.netDisbursementGBP ?? 0).toLocaleString()}</span>
                        {pd?.recoupmentDeductionGBP > 0 && (
                          <span className="text-[10px] text-purple-400">Recouped: -{currencySymbol}{(pd?.recoupmentDeductionGBP ?? 0).toLocaleString()}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
