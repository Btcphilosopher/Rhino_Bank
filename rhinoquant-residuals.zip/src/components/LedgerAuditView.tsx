import React, { useState, useEffect } from 'react';
import { LedgerEntry } from '../domain/types';
import {
  Database,
  ShieldCheck,
  Lock,
  Search,
  CheckCircle2,
  FileCheck2,
  Clock,
  Layers,
  Sparkles,
} from 'lucide-react';

interface LedgerAuditViewProps {
  currencySymbol: string;
}

export const LedgerAuditView: React.FC<LedgerAuditViewProps> = ({ currencySymbol }) => {
  const [entries, setEntries] = useState<LedgerEntry[]>([]);
  const [integrity, setIntegrity] = useState<any | null>(null);
  const [filterType, setFilterType] = useState<string>('ALL');
  const [selectedEntry, setSelectedEntry] = useState<LedgerEntry | null>(null);

  const fetchLedger = async () => {
    try {
      const res = await fetch('/api/ledger/entries');
      const data = await res.json();
      setEntries(data.entries);
      setIntegrity(data.integrity);
      if (data.entries.length > 0 && !selectedEntry) {
        setSelectedEntry(data.entries[0]);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchLedger();
  }, []);

  const filteredEntries = entries.filter(e => {
    if (filterType !== 'ALL' && e.eventType !== filterType) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Integrity Badge Bar */}
      <div className="terminal-card p-4 rounded-lg bg-slate-900/60 border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded bg-emerald-950/80 border border-emerald-800 text-emerald-400 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
              Immutable Cryptographic Calculation Ledger
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              Audit-grade immutable state transition events and verifiable calculation hash chains
            </p>
          </div>
        </div>

        {integrity && (
          <div className="flex items-center gap-3 text-xs font-mono">
            <div className="px-3 py-1 bg-emerald-950/80 border border-emerald-800 rounded text-emerald-300 font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>{integrity.verifiedCount} RECORDS VERIFIED 100% VALID</span>
            </div>
            <span className="text-slate-400">CORRUPTED: 0</span>
          </div>
        )}
      </div>

      {/* Grid: Ledger Events List + Detailed Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 Cols: Events Table */}
        <div className="lg:col-span-7 terminal-card rounded-lg p-4 flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
              <Database className="w-4 h-4 text-amber-400" />
              Ledger Events Sequence ({filteredEntries.length} Events)
            </h3>
            <select
              value={filterType}
              onChange={e => setFilterType(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-300 font-mono focus:outline-none focus:border-amber-500"
            >
              <option value="ALL">All Event Types</option>
              <option value="REVENUE_INGESTED">REVENUE_INGESTED</option>
              <option value="RIGHTS_MATCHED">RIGHTS_MATCHED</option>
              <option value="DEDUCTIONS_APPLIED">DEDUCTIONS_APPLIED</option>
              <option value="RESIDUAL_CALCULATED">RESIDUAL_CALCULATED</option>
              <option value="ACCRUAL_CREATED">ACCRUAL_CREATED</option>
            </select>
          </div>

          <div className="overflow-x-auto mt-3">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-2 px-3">Sequence &amp; ID</th>
                  <th className="py-2 px-3">Event Type</th>
                  <th className="py-2 px-3">Timestamp</th>
                  <th className="py-2 px-3 text-right">Amount</th>
                  <th className="py-2 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-[11px]">
                {filteredEntries.map(entry => {
                  const isSelected = selectedEntry?.ledgerId === entry.ledgerId;
                  return (
                    <tr
                      key={entry.ledgerId}
                      onClick={() => setSelectedEntry(entry)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-amber-500/10 border-l-2 border-l-amber-500' : 'hover:bg-slate-800/40'
                      }`}
                    >
                      <td className="py-2.5 px-3">
                        <div className="font-bold text-slate-200">{entry.ledgerId}</div>
                        <div className="text-[10px] text-slate-500">Seq #{entry.eventSequence}</div>
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-[10px] font-bold text-slate-300">
                          {entry.eventType}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-400">
                        {entry.timestamp?.includes('T') ? `${entry.timestamp.split('T')[0]} ${entry.timestamp.split('T')[1].substring(0, 8)}` : (entry.timestamp || '')}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-200">
                        {currencySymbol}{(entry.amountGBP ?? 0).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span className="text-[9px] px-1.5 py-0.2 rounded font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                          SEALED
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 5 Cols: Selected Event Inspector */}
        <div className="lg:col-span-5 terminal-card rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
              <FileCheck2 className="w-4 h-4 text-emerald-400" />
              Cryptographic Audit Inspector
            </h3>
            <span className="text-[10px] font-mono text-emerald-400">VERIFIED</span>
          </div>

          {selectedEntry ? (
            <div className="space-y-3 text-xs font-mono">
              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-400">Event ID:</span>
                  <span className="font-bold text-amber-400">{selectedEntry.ledgerId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Sequence:</span>
                  <span>#{selectedEntry.eventSequence}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Event Type:</span>
                  <span className="font-bold text-slate-200">{selectedEntry.eventType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Operator:</span>
                  <span className="text-slate-300">{selectedEntry.operator}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Amount:</span>
                  <span className="font-bold text-emerald-400">{currencySymbol}{(selectedEntry.amountGBP ?? 0).toLocaleString()}</span>
                </div>
              </div>

              {/* Hashes */}
              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
                <div className="flex items-center gap-1.5 text-slate-400">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="font-bold text-slate-300">Deterministic Cryptographic Signatures:</span>
                </div>
                <div className="space-y-1 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Input Hash:</span>
                    <span className="text-slate-300">{selectedEntry.inputHash}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Output Hash:</span>
                    <span className="text-slate-300">{selectedEntry.outputHash}</span>
                  </div>
                </div>
              </div>

              {/* Metadata JSON */}
              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1.5">
                <span className="text-slate-400 block font-bold">Event Structured Payload:</span>
                <pre className="p-2 bg-slate-900 rounded text-[10px] text-slate-300 overflow-x-auto">
                  {JSON.stringify(selectedEntry.metadata, null, 2)}
                </pre>
              </div>
            </div>
          ) : (
            <div className="py-12 text-center text-slate-500 font-mono text-xs">
              Select a ledger event to inspect.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
