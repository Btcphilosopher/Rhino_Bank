import React, { useState, useEffect } from 'react';
import {
  Sliders,
  TrendingUp,
  AlertTriangle,
  Play,
  RotateCcw,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from 'recharts';

interface ScenarioSandboxProps {
  currencySymbol: string;
}

export const ScenarioSandbox: React.FC<ScenarioSandboxProps> = ({ currencySymbol }) => {
  const [streamingDelta, setStreamingDelta] = useState<number>(0);
  const [platformDelta, setPlatformDelta] = useState<number>(0);
  const [renewalYears, setRenewalYears] = useState<number>(0);
  const [royaltyRateDelta, setRoyaltyRateDelta] = useState<number>(0);
  const [usGrowth, setUsGrowth] = useState<number>(0);
  const [fxShift, setFxShift] = useState<number>(0);
  const [decayShift, setDecayShift] = useState<number>(0);
  const [scenarioName, setScenarioName] = useState<string>('Custom Stress Scenario');

  const [impactResult, setImpactResult] = useState<any | null>(null);
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);

  const evaluateScenario = async () => {
    setIsEvaluating(true);
    try {
      const res = await fetch('/api/scenarios/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: scenarioName,
          streamingRevenueDeltaPct: streamingDelta,
          platformRevenueDeltaPct: platformDelta,
          contractRenewalYearsAdded: renewalYears,
          royaltyRateDeltaPctPoints: royaltyRateDelta,
          usMarketGrowthRatePct: usGrowth,
          gbpUsdFxShiftPct: fxShift,
          catalogueDecayShiftPct: decayShift,
        }),
      });
      const data = await res.json();
      setImpactResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsEvaluating(false);
    }
  };

  useEffect(() => {
    evaluateScenario();
  }, [streamingDelta, platformDelta, renewalYears, royaltyRateDelta, usGrowth, fxShift, decayShift]);

  const loadPreset = (preset: string) => {
    if (preset === 'STREAMING_DOUBLE') {
      setScenarioName('Streaming Revenue Surge (+100%)');
      setStreamingDelta(100);
      setPlatformDelta(15);
      setRenewalYears(2);
      setRoyaltyRateDelta(0);
      setUsGrowth(10);
      setFxShift(0);
      setDecayShift(-2);
    } else if (preset === 'PLATFORM_CRASH') {
      setScenarioName('Platform Compression & Carriage Dispute (-30%)');
      setStreamingDelta(-40);
      setPlatformDelta(-30);
      setRenewalYears(0);
      setRoyaltyRateDelta(0);
      setUsGrowth(-15);
      setFxShift(0);
      setDecayShift(4);
    } else if (preset === 'CONTRACT_EXTENSIONS') {
      setScenarioName('Portfolio Renewal Extension (+5 Years)');
      setStreamingDelta(10);
      setPlatformDelta(0);
      setRenewalYears(5);
      setRoyaltyRateDelta(0.5);
      setUsGrowth(5);
      setFxShift(0);
      setDecayShift(-3);
    } else if (preset === 'FX_DEPRECIATION') {
      setScenarioName('GBP/USD -15% FX Shock');
      setStreamingDelta(0);
      setPlatformDelta(0);
      setRenewalYears(0);
      setRoyaltyRateDelta(0);
      setUsGrowth(0);
      setFxShift(-15);
      setDecayShift(0);
    } else {
      setScenarioName('Baseline Reset');
      setStreamingDelta(0);
      setPlatformDelta(0);
      setRenewalYears(0);
      setRoyaltyRateDelta(0);
      setUsGrowth(0);
      setFxShift(0);
      setDecayShift(0);
    }
  };

  return (
    <div className="space-y-6">
      {/* Preset Quick Selectors */}
      <div className="terminal-card p-4 rounded-lg bg-slate-900/60 border-slate-800">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            <h2 className="font-display font-bold text-sm text-slate-100">
              Interactive Scenario &amp; Delta NAV Stress Testing Sandbox
            </h2>
          </div>
          <button
            onClick={() => loadPreset('RESET')}
            className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs font-mono transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Baseline</span>
          </button>
        </div>

        {/* Preset Buttons */}
        <div className="flex flex-wrap items-center gap-2 mt-3 text-xs font-mono">
          <span className="text-slate-500 uppercase text-[10px] mr-1">Institutional Presets:</span>
          <button
            onClick={() => loadPreset('STREAMING_DOUBLE')}
            className="px-2.5 py-1 bg-emerald-950/70 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 rounded transition-all"
          >
            🚀 Streaming Doubles (+100%)
          </button>
          <button
            onClick={() => loadPreset('PLATFORM_CRASH')}
            className="px-2.5 py-1 bg-rose-950/70 hover:bg-rose-900 text-rose-300 border border-rose-800 rounded transition-all"
          >
            📉 Platform Compression (-30%)
          </button>
          <button
            onClick={() => loadPreset('CONTRACT_EXTENSIONS')}
            className="px-2.5 py-1 bg-blue-950/70 hover:bg-blue-900 text-blue-300 border border-blue-800 rounded transition-all"
          >
            📜 +5Y Contract Extensions
          </button>
          <button
            onClick={() => loadPreset('FX_DEPRECIATION')}
            className="px-2.5 py-1 bg-purple-950/70 hover:bg-purple-900 text-purple-300 border border-purple-800 rounded transition-all"
          >
            💱 GBP/USD -15% FX Shock
          </button>
        </div>

        {/* Interactive Sliders Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-7 gap-3 mt-4 pt-3 border-t border-slate-800/80 text-xs font-mono">
          <div>
            <label className="text-slate-400 block mb-1 text-[11px]">Streaming Delta ({streamingDelta > 0 ? '+' : ''}{streamingDelta}%)</label>
            <input
              type="range"
              min="-60"
              max="150"
              step="5"
              value={streamingDelta}
              onChange={e => setStreamingDelta(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1 text-[11px]">Platform Delta ({platformDelta > 0 ? '+' : ''}{platformDelta}%)</label>
            <input
              type="range"
              min="-50"
              max="50"
              step="5"
              value={platformDelta}
              onChange={e => setPlatformDelta(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1 text-[11px]">Renewal Extension (+{renewalYears} Yrs)</label>
            <input
              type="range"
              min="0"
              max="10"
              step="1"
              value={renewalYears}
              onChange={e => setRenewalYears(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1 text-[11px]">Royalty Rate Shift ({royaltyRateDelta > 0 ? '+' : ''}{royaltyRateDelta}%)</label>
            <input
              type="range"
              min="-3"
              max="5"
              step="0.5"
              value={royaltyRateDelta}
              onChange={e => setRoyaltyRateDelta(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1 text-[11px]">US Market Growth ({usGrowth > 0 ? '+' : ''}{usGrowth}%)</label>
            <input
              type="range"
              min="-20"
              max="30"
              step="2"
              value={usGrowth}
              onChange={e => setUsGrowth(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1 text-[11px]">GBP/USD FX Shift ({fxShift > 0 ? '+' : ''}{fxShift}%)</label>
            <input
              type="range"
              min="-25"
              max="25"
              step="1"
              value={fxShift}
              onChange={e => setFxShift(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1 text-[11px]">Decay Shift ({decayShift > 0 ? '+' : ''}{decayShift}%)</label>
            <input
              type="range"
              min="-5"
              max="15"
              step="1"
              value={decayShift}
              onChange={e => setDecayShift(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Delta NAV & Scenario Impact Strip */}
      {impactResult && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="terminal-card p-4 rounded-lg border-l-2 border-l-amber-500">
            <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Baseline vs Scenario NAV</span>
            <div className="mt-1 text-xl font-bold font-mono text-slate-100 flex items-center gap-2">
              <span className="text-slate-400 text-sm line-through">{currencySymbol}{((impactResult.baselineNAVGBP ?? 0) / 1_000_000).toFixed(1)}M</span>
              <ArrowRight className="w-4 h-4 text-amber-400" />
              <span className="text-amber-400">{currencySymbol}{((impactResult.scenarioNAVGBP ?? 0) / 1_000_000).toFixed(1)}M</span>
            </div>
            <div className={`text-xs font-mono font-bold mt-1.5 flex items-center gap-1 ${(impactResult.navDeltaPercentage ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              <span>{(impactResult.navDeltaPercentage ?? 0) >= 0 ? '▲ +' : '▼ '}{impactResult.navDeltaPercentage ?? 0}%</span>
              <span>({(impactResult.navDeltaGBP ?? 0) >= 0 ? '+' : ''}{currencySymbol}{((impactResult.navDeltaGBP ?? 0) / 1_000_000).toFixed(2)}M)</span>
            </div>
          </div>

          <div className="terminal-card p-4 rounded-lg border-l-2 border-l-blue-500">
            <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">12M Cashflow Shift</span>
            <div className="mt-1 text-xl font-bold font-mono text-slate-100 flex items-center gap-2">
              <span className="text-slate-400 text-sm line-through">{currencySymbol}{((impactResult.baseline12mIncomeGBP ?? 0) / 1_000_000).toFixed(1)}M</span>
              <ArrowRight className="w-4 h-4 text-blue-400" />
              <span className="text-blue-400">{currencySymbol}{((impactResult.scenario12mIncomeGBP ?? 0) / 1_000_000).toFixed(1)}M</span>
            </div>
            <span className={`text-xs font-mono mt-1.5 block ${(impactResult.income12mDeltaGBP ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              Delta: {(impactResult.income12mDeltaGBP ?? 0) >= 0 ? '+' : ''}{currencySymbol}{((impactResult.income12mDeltaGBP ?? 0) / 1_000_000).toFixed(2)}M / yr
            </span>
          </div>

          <div className="terminal-card p-4 rounded-lg border-l-2 border-l-emerald-500">
            <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">5-Year Expected Cashflow</span>
            <div className="mt-1 text-xl font-bold font-mono text-emerald-400">
              {currencySymbol}{((impactResult.scenario5yExpectedGBP ?? 0) / 1_000_000).toFixed(1)}M
            </div>
            <span className="text-xs font-mono text-slate-400 mt-1.5 block">
              Baseline: {currencySymbol}{((impactResult.baseline5yExpectedGBP ?? 0) / 1_000_000).toFixed(1)}M
            </span>
          </div>

          <div className="terminal-card p-4 rounded-lg border-l-2 border-l-purple-500">
            <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Portfolio Implied IRR</span>
            <div className="mt-1 text-xl font-bold font-mono text-purple-300">
              {impactResult.scenarioIRRPct ?? 0}%
            </div>
            <span className="text-xs font-mono text-slate-400 mt-1.5 block">
              Baseline IRR: {impactResult.baselineIRRPct ?? 0}%
            </span>
          </div>
        </div>
      )}

      {/* Grid: Participant Impact Deltas & Quantitative Insights */}
      {impactResult?.participantPayableDeltas && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left 7 Cols: Participant Payable Shift Table */}
          <div className="lg:col-span-7 terminal-card rounded-lg p-4">
            <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2 pb-3 border-b border-slate-800">
              <TrendingUp className="w-4 h-4 text-amber-400" />
              Participant Accrual &amp; Cashflow Deltas
            </h3>

            <div className="overflow-x-auto mt-3">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="py-2 px-3">Participant Beneficiary</th>
                    <th className="py-2 px-3 text-right">Baseline Accrual</th>
                    <th className="py-2 px-3 text-right">Scenario Accrual</th>
                    <th className="py-2 px-3 text-right">Delta Cashflow</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-[11px]">
                  {impactResult.participantPayableDeltas.map((p: any) => (
                    <tr key={p.participantId} className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3">
                        <span className="font-sans font-bold text-slate-200">{p.participantName}</span>
                        <span className="text-[10px] text-slate-500 block">{p.participantId}</span>
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-400">
                        {currencySymbol}{(p.baselinePayableGBP ?? 0).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-200 font-bold">
                        {currencySymbol}{(p.scenarioPayableGBP ?? 0).toLocaleString()}
                      </td>
                      <td className={`py-2.5 px-3 text-right font-bold ${(p.deltaGBP ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {(p.deltaGBP ?? 0) >= 0 ? '+' : ''}{currencySymbol}{(p.deltaGBP ?? 0).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Right 5 Cols: Quantitative Summary Insights */}
          <div className="lg:col-span-5 terminal-card rounded-lg p-4 space-y-3">
            <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2 pb-3 border-b border-slate-800">
              <Sparkles className="w-4 h-4 text-amber-400" />
              Automated Quantitative Assessment
            </h3>

            <div className="space-y-2 text-xs font-sans">
              {impactResult.summaryInsights.map((insight: string, idx: number) => (
                <div key={idx} className="p-2.5 bg-slate-950/70 rounded border border-slate-800/80 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <p className="text-slate-300 text-[12px]">{insight}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
