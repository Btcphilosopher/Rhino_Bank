import React, { useState } from 'react';
import {
  Asset,
  AssetType,
  Contract,
  Participant,
  PortfolioRiskMetrics,
} from '../domain/types';
import {
  TrendingUp,
  AlertTriangle,
  Clock,
  PieChart as PieIcon,
  ShieldCheck,
  ChevronRight,
  Filter,
  BarChart3,
  Building,
  Radio,
  FileText,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

interface PortfolioCockpitProps {
  assets: Asset[];
  contracts: Contract[];
  participants: Participant[];
  summary: any;
  onSelectAsset: (asset: Asset) => void;
  currencySymbol: string;
}

const COLORS = ['#f59e0b', '#3b82f6', '#10b981', '#8b5cf6', '#ec4899', '#06b6d4', '#eab308', '#f97316'];

export const PortfolioCockpit: React.FC<PortfolioCockpitProps> = ({
  assets,
  contracts,
  participants,
  summary,
  onSelectAsset,
  currencySymbol,
}) => {
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [selectedStage, setSelectedStage] = useState<string>('ALL');

  const filteredAssets = assets.filter(a => {
    if (selectedType !== 'ALL' && a.type !== selectedType) return false;
    if (selectedStage !== 'ALL' && a.lifecycleStage !== selectedStage) return false;
    return true;
  });

  // Sector breakdown chart data
  const sectorData = Object.values(AssetType).map(type => {
    const matched = assets.filter(a => a.type === type);
    const totalGross = matched.reduce((s, a) => s + a.historicalGrossTotal, 0);
    return {
      name: type.replace('_', ' '),
      value: totalGross,
      count: matched.length,
    };
  }).filter(d => d.count > 0);

  // Expiry Timeline Chart data
  const expiryTimeline = [
    { period: '< 12 Months', count: 1, valueGBP: 8.5 },
    { period: '12 - 24 Months', count: 1, valueGBP: 9.7 },
    { period: '2 - 5 Years', count: 4, valueGBP: 92.4 },
    { period: '5+ Years', count: 2, valueGBP: 73.6 },
  ];

  return (
    <div className="space-y-6">
      {/* Top Metric Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        <div className="terminal-card p-3 rounded-lg border-l-2 border-l-amber-500">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Residual Portfolio NAV</span>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="text-xl font-bold font-mono text-amber-400">
              {currencySymbol}{((summary?.totalResidualNAVGBP || 184200000) / 1_000_000).toFixed(1)}M
            </span>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1 mt-1">
            <TrendingUp className="w-3 h-3" /> DCF @ 9.5% WACC
          </span>
        </div>

        <div className="terminal-card p-3 rounded-lg border-l-2 border-l-blue-500">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Expected 12M Income</span>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="text-xl font-bold font-mono text-slate-100">
              {currencySymbol}{((summary?.expected12mIncomeGBP || 24800000) / 1_000_000).toFixed(1)}M
            </span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono mt-1 block">
            Run-Rate Cash Yield: 13.5%
          </span>
        </div>

        <div className="terminal-card p-3 rounded-lg border-l-2 border-l-emerald-500">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">5Y Expected Cashflow</span>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="text-xl font-bold font-mono text-emerald-400">
              {currencySymbol}{((summary?.fiveYearExpectedIncomeGBP || 109120000) / 1_000_000).toFixed(1)}M
            </span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono mt-1 block">
            10Y NPV: {currencySymbol}{((summary?.tenYearNPVGBP || 169464000) / 1_000_000).toFixed(1)}M
          </span>
        </div>

        <div className="terminal-card p-3 rounded-lg border-l-2 border-l-purple-500">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Weighted Duration</span>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="text-xl font-bold font-mono text-purple-300">
              {summary?.weightedDurationYears || 5.4} <span className="text-xs font-normal">YRS</span>
            </span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono mt-1 block">
            Modified Dur: 4.9 Yrs
          </span>
        </div>

        <div className="terminal-card p-3 rounded-lg border-l-2 border-l-rose-500">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Expiry Cliff (&lt;24M)</span>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="text-xl font-bold font-mono text-rose-400">
              {summary?.expiringUnder24MonthsCount || 2} <span className="text-xs font-normal text-slate-400">Streams</span>
            </span>
          </div>
          <span className="text-[10px] text-rose-300/80 font-mono mt-1 block">
            At Risk: {currencySymbol}18.2M
          </span>
        </div>

        <div className="terminal-card p-3 rounded-lg border-l-2 border-l-cyan-500">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Platform HHI Index</span>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="text-xl font-bold font-mono text-cyan-300">
              {summary?.platformHHI || 2840}
            </span>
          </div>
          <span className="text-[10px] text-amber-400 font-mono mt-1 block">
            Concentration: Elevated
          </span>
        </div>

        <div className="terminal-card p-3 rounded-lg border-l-2 border-l-emerald-500">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Data Quality Score</span>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="text-xl font-bold font-mono text-emerald-400">
              96.4<span className="text-xs font-normal text-slate-400">/100</span>
            </span>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1 mt-1">
            <ShieldCheck className="w-3 h-3" /> Audit Grade A+
          </span>
        </div>
      </div>

      {/* Main Grid: Sector Exposure & Stress Test Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Catalogue Assets Table */}
        <div className="lg:col-span-2 terminal-card rounded-lg overflow-hidden flex flex-col">
          <div className="p-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 bg-slate-900/50">
            <div>
              <h2 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
                <Building className="w-4 h-4 text-amber-400" />
                Institutional Asset Catalogue ({filteredAssets.length} Assets)
              </h2>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Multi-sector residual revenue rights and active licensing contracts
              </p>
            </div>

            {/* Filter Pills */}
            <div className="flex items-center gap-2">
              <select
                value={selectedType}
                onChange={e => setSelectedType(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-300 font-mono focus:outline-none focus:border-amber-500"
              >
                <option value="ALL">All Asset Sectors</option>
                {Object.values(AssetType).map(t => (
                  <option key={t} value={t}>{t.replace('_', ' ')}</option>
                ))}
              </select>

              <select
                value={selectedStage}
                onChange={e => setSelectedStage(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-300 font-mono focus:outline-none focus:border-amber-500"
              >
                <option value="ALL">All Lifecycle Stages</option>
                <option value="LAUNCH">Launch (0-2 Yrs)</option>
                <option value="PRIME">Prime (2-5 Yrs)</option>
                <option value="CATALOGUE">Catalogue (5-10 Yrs)</option>
                <option value="LONG_TAIL">Long-Tail (10+ Yrs)</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/80 text-slate-400 font-mono uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Asset &amp; Sector</th>
                  <th className="py-2.5 px-3">Stage</th>
                  <th className="py-2.5 px-3 text-right">Lifetime Gross</th>
                  <th className="py-2.5 px-3 text-right">Residuals Paid</th>
                  <th className="py-2.5 px-3 text-right">Decay Rate</th>
                  <th className="py-2.5 px-3 text-right">Royalty Bench</th>
                  <th className="py-2.5 px-3 text-center">Quality</th>
                  <th className="py-2.5 px-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {filteredAssets.map(asset => {
                  const stageBadgeColor =
                    asset.lifecycleStage === 'PRIME'
                      ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                      : asset.lifecycleStage === 'CATALOGUE'
                      ? 'bg-blue-950 text-blue-300 border-blue-800'
                      : asset.lifecycleStage === 'LONG_TAIL'
                      ? 'bg-purple-950 text-purple-300 border-purple-800'
                      : 'bg-amber-950 text-amber-300 border-amber-800';

                  return (
                    <tr
                      key={asset.id}
                      className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                      onClick={() => onSelectAsset(asset)}
                    >
                      <td className="py-3 px-3">
                        <div className="font-sans font-semibold text-slate-200 group-hover:text-amber-400 transition-colors">
                          {asset.title}
                        </div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                          <span className="px-1.5 py-0.2 bg-slate-800 text-slate-300 rounded text-[9px]">
                            {asset.type.replace('_', ' ')}
                          </span>
                          <span>•</span>
                          <span>{asset.activeContractsCount} Contracts</span>
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${stageBadgeColor}`}>
                          {asset.lifecycleStage}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-semibold text-slate-200">
                        {currencySymbol}{((asset.historicalGrossTotal ?? 0) / 1_000_000).toFixed(1)}M
                      </td>
                      <td className="py-3 px-3 text-right text-emerald-400 font-semibold">
                        {currencySymbol}{((asset.historicalNetResidualsPaid ?? 0) / 1_000_000).toFixed(2)}M
                      </td>
                      <td className="py-3 px-3 text-right text-slate-300">
                        {(asset.baseDecayRateAnnualPct ?? 0).toFixed(1)}%/yr
                      </td>
                      <td className="py-3 px-3 text-right text-amber-400">
                        {(asset.marketRoyaltyBenchmarkRatePct ?? 0).toFixed(1)}%
                      </td>
                      <td className="py-3 px-3 text-center">
                        <span className="text-[11px] font-bold text-emerald-400">
                          {asset.dataQualityScore}%
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectAsset(asset);
                          }}
                          className="px-2 py-1 bg-slate-800 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 border border-slate-700 hover:border-amber-500/50 rounded text-[11px] flex items-center gap-1 mx-auto transition-all"
                        >
                          <span>Drilldown</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Col: Stress Test Scenarios & Asset Mix */}
        <div className="space-y-6">
          {/* Stress Testing Card */}
          <div className="terminal-card rounded-lg p-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                Macro Stress Test Matrix
              </h3>
              <span className="text-[10px] font-mono text-slate-400">6 Scenarios</span>
            </div>

            <div className="divide-y divide-slate-800/60 mt-3 text-xs font-mono">
              {(summary?.stressTestResults || []).map((st: any, idx: number) => {
                const badgeColor =
                  st.impactSeverity === 'CRITICAL'
                    ? 'bg-rose-950 text-rose-300 border-rose-800'
                    : st.impactSeverity === 'HIGH'
                    ? 'bg-orange-950 text-orange-300 border-orange-800'
                    : st.impactSeverity === 'MEDIUM'
                    ? 'bg-amber-950 text-amber-300 border-amber-800'
                    : 'bg-emerald-950 text-emerald-300 border-emerald-800';

                return (
                  <div key={idx} className="py-2.5 first:pt-0 last:pb-0">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-200 font-sans text-xs">{st.scenarioName}</span>
                      <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold border ${badgeColor}`}>
                        {st.impactSeverity}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1 font-sans">{st.description}</p>
                    <div className="flex items-center justify-between mt-1 text-[11px]">
                      <span className="text-slate-400">Stressed NAV: {currencySymbol}{((st.stressedNAVGBP ?? 0) / 1_000_000).toFixed(1)}M</span>
                      <span className={`font-bold ${(st.navLossPercentage ?? 0) > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                        {(st.navLossPercentage ?? 0) > 0 ? '-' : '+'}{Math.abs(st.navLossPercentage ?? 0)}% ({currencySymbol}{(Math.abs(st.navLossGBP ?? 0) / 1_000_000).toFixed(1)}M)
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Sector Allocation Breakdown */}
          <div className="terminal-card rounded-lg p-4">
            <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2 pb-3 border-b border-slate-800">
              <PieIcon className="w-4 h-4 text-amber-400" />
              Catalogue Gross Allocation
            </h3>
            <div className="h-44 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={sectorData}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={70}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {sectorData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '11px', fontFamily: 'JetBrains Mono' }}
                    formatter={(val: any) => [`${currencySymbol}${((Number(val) || 0) / 1_000_000).toFixed(1)}M`, 'Historical Gross']}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-2 text-[10px] font-mono">
              {sectorData.map((d, i) => (
                <div key={d.name} className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                  <span className="text-slate-400 truncate">{d.name}</span>
                  <span className="text-slate-200 font-semibold ml-auto">{(((d.value ?? 0) / (summary?.totalLifetimeGrossGBP || 647000000)) * 100).toFixed(0)}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
