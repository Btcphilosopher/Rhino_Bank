import React, { useState } from 'react';
import { Right, ExclusivityType, MediaChannel, TerritoryCode } from '../domain/types';
import {
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  Search,
  Calendar,
  Globe,
  Tv,
  Layers,
  Sparkles,
  Lock,
  Unlock,
} from 'lucide-react';

interface RightsRadarProps {
  rights: Right[];
  collisions: any[];
}

export const RightsRadar: React.FC<RightsRadarProps> = ({ rights, collisions }) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterMedium, setFilterMedium] = useState<string>('ALL');

  // Revenue Eligibility Sandbox
  const [testTerritory, setTestTerritory] = useState<TerritoryCode>(TerritoryCode.GLOBAL);
  const [testMedium, setTestMedium] = useState<MediaChannel>(MediaChannel.SVOD);
  const [testPlatform, setTestPlatform] = useState<string>('Netflix');
  const [testDate, setTestDate] = useState<string>('2026-09-11');
  const [testResult, setTestResult] = useState<any | null>(null);

  const filteredRights = rights.filter(r => {
    if (filterMedium !== 'ALL' && r.medium !== filterMedium) return false;
    if (searchTerm) {
      const match =
        r.owner.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.platform.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.window.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.assetId.toLowerCase().includes(searchTerm.toLowerCase());
      if (!match) return false;
    }
    return true;
  });

  const handleTestEligibility = async () => {
    try {
      const res = await fetch('/api/rights/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          propertyId: 'ASSET-FILM-01',
          territory: testTerritory,
          medium: testMedium,
          platform: testPlatform,
          date: testDate,
        }),
      });
      const data = await res.json();
      setTestResult(data);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6">
      {/* Active Collisions Banner */}
      {collisions && collisions.length > 0 ? (
        <div className="p-4 rounded-lg bg-rose-950/70 border border-rose-800/80 flex items-start gap-3 shadow-md">
          <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1 text-xs font-mono">
            <div className="flex items-center gap-2">
              <span className="font-sans font-bold text-sm text-rose-200">
                CRITICAL: {collisions.length} Rights Exclusivity Collision(s) Detected
              </span>
              <span className="px-1.5 py-0.2 bg-rose-900 text-rose-300 rounded text-[10px] font-bold">
                FATAL BREACH
              </span>
            </div>
            {collisions.map((col, idx) => (
              <p key={idx} className="text-rose-300/90 font-sans">
                • <strong className="font-mono">{col.rightAId}</strong> vs <strong className="font-mono">{col.rightBId}</strong>: {col.collisionReason}
              </p>
            ))}
          </div>
        </div>
      ) : (
        <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-800/60 flex items-center gap-2 text-xs font-mono text-emerald-400">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>ZERO FATAL RIGHTS COLLISIONS DETECTED ACROSS CATALOGUE MATRIX</span>
        </div>
      )}

      {/* Grid: Rights Inventory Table + Eligibility Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 8 Cols: Rights Granted Matrix */}
        <div className="lg:col-span-8 terminal-card rounded-lg p-4 flex flex-col">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div>
              <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
                <Globe className="w-4 h-4 text-amber-400" />
                Legal Rights &amp; Windowing Inventory ({filteredRights.length} Grants)
              </h3>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Territory, platform exclusivity, window dates, encumbrances and holdbacks
              </p>
            </div>

            {/* Filter */}
            <div className="flex items-center gap-2">
              <select
                value={filterMedium}
                onChange={e => setFilterMedium(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-300 font-mono focus:outline-none focus:border-amber-500"
              >
                <option value="ALL">All Media Channels</option>
                {Object.values(MediaChannel).map(m => (
                  <option key={m} value={m}>{m.replace('_', ' ')}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="overflow-x-auto mt-3">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-2 px-3">Right ID &amp; Owner</th>
                  <th className="py-2 px-3">Territory</th>
                  <th className="py-2 px-3">Medium</th>
                  <th className="py-2 px-3">Platform</th>
                  <th className="py-2 px-3">Window Term</th>
                  <th className="py-2 px-3 text-center">Exclusivity</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-[11px]">
                {filteredRights.map(right => {
                  const isExclusive = right.exclusivity === ExclusivityType.EXCLUSIVE;
                  return (
                    <tr key={right.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-2.5 px-3">
                        <div className="font-bold text-slate-200">{right.id}</div>
                        <div className="text-[10px] text-slate-400 font-sans">{right.owner}</div>
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-300 font-bold">
                          {right.territory}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-300">
                        {right.medium}
                      </td>
                      <td className="py-2.5 px-3 text-slate-200 font-sans font-semibold">
                        {right.platform}
                      </td>
                      <td className="py-2.5 px-3 text-slate-400">
                        <div>{right.startDate} to {right.endDate}</div>
                        <div className="text-[10px] text-slate-500 font-sans">{right.window}</div>
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                            isExclusive
                              ? 'bg-amber-950 text-amber-300 border-amber-800'
                              : right.exclusivity === ExclusivityType.CO_EXCLUSIVE
                              ? 'bg-blue-950 text-blue-300 border-blue-800'
                              : 'bg-slate-900 text-slate-400 border-slate-700'
                          }`}
                        >
                          {right.exclusivity}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 4 Cols: Revenue Eligibility Verifier */}
        <div className="lg:col-span-4 terminal-card rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              Rights Eligibility Verifier
            </h3>
            <span className="text-[10px] font-mono text-slate-400">Real-Time Check</span>
          </div>

          <p className="text-xs text-slate-400 font-sans">
            Validate whether a planned distribution deal, stream ingest, or sub-license violates existing grants or holdbacks.
          </p>

          <div className="space-y-3 text-xs font-mono">
            <div>
              <label className="text-slate-400 block mb-1">Target Territory</label>
              <select
                value={testTerritory}
                onChange={e => setTestTerritory(e.target.value as TerritoryCode)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-500"
              >
                {Object.values(TerritoryCode).map(t => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Media Channel</label>
              <select
                value={testMedium}
                onChange={e => setTestMedium(e.target.value as MediaChannel)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-500"
              >
                {Object.values(MediaChannel).map(m => (
                  <option key={m} value={m}>{m.replace('_', ' ')}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Platform Identifier</label>
              <input
                type="text"
                value={testPlatform}
                onChange={e => setTestPlatform(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Execution Date</label>
              <input
                type="date"
                value={testDate}
                onChange={e => setTestDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-500"
              />
            </div>

            <button
              onClick={handleTestEligibility}
              className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs transition-colors flex items-center justify-center gap-1.5 shadow-sm"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Verify Legal Eligibility</span>
            </button>

            {testResult && (
              <div
                className={`p-3 rounded border text-xs ${
                  testResult.isEligible
                    ? 'bg-emerald-950/80 border-emerald-800 text-emerald-300'
                    : 'bg-rose-950/80 border-rose-800 text-rose-300'
                }`}
              >
                <div className="font-bold flex items-center gap-1.5">
                  {testResult.isEligible ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                  <span>{testResult.isEligible ? 'ELIGIBLE & MATCHED' : 'INELIGIBLE / CONFLICT'}</span>
                </div>
                <p className="mt-1 text-[11px] font-sans text-slate-300">
                  {testResult.rejectionReason || `Matched Grant: ${testResult.matchedRight?.id} (${testResult.matchedRight?.owner})`}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
