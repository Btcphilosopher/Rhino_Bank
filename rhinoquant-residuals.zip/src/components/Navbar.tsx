import React from 'react';
import {
  Activity,
  Layers,
  Cpu,
  ShieldAlert,
  TrendingUp,
  Sliders,
  FileCheck2,
  TestTube2,
  Sparkles,
  Search,
  Database,
} from 'lucide-react';

export type TerminalTab =
  | 'PORTFOLIO'
  | 'CALCULATION'
  | 'RIGHTS'
  | 'FORECAST_VALUATION'
  | 'MONTE_CARLO'
  | 'SCENARIO'
  | 'LEDGER'
  | 'TESTS';

interface NavbarProps {
  activeTab: TerminalTab;
  setActiveTab: (tab: TerminalTab) => void;
  onOpenCopilot: () => void;
  currency: string;
  setCurrency: (c: string) => void;
  searchTerm: string;
  setSearchTerm: (s: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenCopilot,
  currency,
  setCurrency,
  searchTerm,
  setSearchTerm,
}) => {
  const tabs: { id: TerminalTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'PORTFOLIO', label: 'Portfolio Cockpit', icon: <Layers className="w-4 h-4" /> },
    { id: 'CALCULATION', label: 'Residual Engine', icon: <Cpu className="w-4 h-4" /> },
    { id: 'RIGHTS', label: 'Rights & Collisions', icon: <ShieldAlert className="w-4 h-4" />, badge: '1 Collision' },
    { id: 'FORECAST_VALUATION', label: 'Forecast & Valuation', icon: <TrendingUp className="w-4 h-4" /> },
    { id: 'MONTE_CARLO', label: 'Monte Carlo (P10-P90)', icon: <Activity className="w-4 h-4" /> },
    { id: 'SCENARIO', label: 'Scenario Sandbox', icon: <Sliders className="w-4 h-4" /> },
    { id: 'LEDGER', label: 'Audit Ledger', icon: <Database className="w-4 h-4" /> },
    { id: 'TESTS', label: 'Quant Test Suite', icon: <TestTube2 className="w-4 h-4" />, badge: '8/8 PASS' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#080c14]/95 backdrop-blur border-b border-slate-800">
      {/* Top Status & Brand Header */}
      <div className="px-4 lg:px-6 py-2.5 flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/60">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-8 h-8 rounded bg-gradient-to-br from-amber-500 to-amber-700 text-slate-950 font-display font-extrabold text-lg shadow-sm">
            RQ
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-display font-bold text-base tracking-wide text-slate-100">
                RHINOQUANT <span className="text-amber-400 font-mono font-medium text-xs">RESIDUALS</span>
              </h1>
              <span className="hidden sm:inline-block px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-800/80">
                CORE: v2.4.0-DETERMINISTIC
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono hidden md:block">
              Institutional Residuals, Royalties & Long-Tail Revenue Analytics Engine • Rhino Bank Quantitative Desk
            </p>
          </div>
        </div>

        {/* Global Controls & Status */}
        <div className="flex items-center gap-3 ml-auto">
          {/* Search Box */}
          <div className="relative w-48 sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search contracts, assets, ISAN..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1 bg-slate-900/90 border border-slate-800 rounded text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500/80 font-mono"
            />
          </div>

          {/* Currency Switcher */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded p-0.5 text-xs font-mono">
            {['GBP', 'USD', 'EUR'].map(c => (
              <button
                key={c}
                onClick={() => setCurrency(c)}
                className={`px-2 py-0.5 rounded text-[11px] transition-colors ${
                  currency === c
                    ? 'bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {c === 'GBP' ? '£ GBP' : c === 'USD' ? '$ USD' : '€ EUR'}
              </button>
            ))}
          </div>

          {/* AI Copilot Button */}
          <button
            onClick={onOpenCopilot}
            className="flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-amber-500/20 to-amber-600/20 hover:from-amber-500/30 hover:to-amber-600/30 border border-amber-500/50 rounded text-amber-300 text-xs font-mono font-medium shadow-sm transition-all"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>AI Copilot</span>
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <nav className="px-4 lg:px-6 flex items-center gap-1 overflow-x-auto no-scrollbar py-1">
        {tabs.map(tab => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-medium whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-slate-800 text-amber-400 border-b-2 border-amber-500 shadow-inner font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
              {tab.badge && (
                <span
                  className={`text-[9px] px-1.5 py-0.2 rounded font-mono font-bold ${
                    tab.badge.includes('PASS')
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/80'
                      : 'bg-rose-950 text-rose-300 border border-rose-800/80'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>
    </header>
  );
};
