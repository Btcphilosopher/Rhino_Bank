import React, { useState, useEffect } from 'react';
import { MonteCarloSimulationResult } from '../domain/types';
import {
  Activity,
  Play,
  RotateCcw,
  Sliders,
  TrendingUp,
  Percent,
  Layers,
  Sparkles,
  Info,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ReferenceLine,
} from 'recharts';

interface MonteCarloViewProps {
  currencySymbol: string;
}

export const MonteCarloView: React.FC<MonteCarloViewProps> = ({ currencySymbol }) => {
  const [iterations, setIterations] = useState<number>(2500);
  const [volatility, setVolatility] = useState<number>(0.19);
  const [renewalProb, setRenewalProb] = useState<number>(0.75);
  const [baseCashflow, setBaseCashflow] = useState<number>(520_000);
  const [horizonYears, setHorizonYears] = useState<number>(10);

  const [simResult, setSimResult] = useState<MonteCarloSimulationResult | null>(null);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  const runSimulation = async () => {
    setIsRunning(true);
    try {
      const res = await fetch('/api/monte-carlo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          baseCashflow,
          iterations,
          horizonYears,
          volatility,
          renewalProb,
        }),
      });
      const data = await res.json();
      setSimResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsRunning(false);
    }
  };

  useEffect(() => {
    runSimulation();
  }, [iterations, horizonYears]);

  // Transform sample paths for Recharts
  const samplePathsChartData = simResult
    ? Array.from({ length: horizonYears }, (_, yrIdx) => {
        const year = yrIdx + 1;
        const row: any = { year: `Yr ${year}` };
        simResult.samplePaths.forEach((path, pathIdx) => {
          row[`Path ${path.pathId}`] = path.annualCashflows[yrIdx];
        });
        return row;
      })
    : [];

  // Histogram data
  const histogramData = simResult
    ? simResult.histogramBins5Y.map(b => ({
        range: `${currencySymbol}${(b.rangeMin / 1000).toFixed(0)}k - ${(b.rangeMax / 1000).toFixed(0)}k`,
        count: b.count,
        percentage: b.percentage,
      }))
    : [];

  const p5 = simResult?.simulatedPercentiles5Y;

  return (
    <div className="space-y-6">
      {/* Parameter Control Panel */}
      <div className="terminal-card p-4 rounded-lg bg-slate-900/60 border-slate-800">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-amber-400" />
            <h2 className="font-display font-bold text-sm text-slate-100">
              Stochastic Monte Carlo Simulation Engine (P10 - P90)
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
              SEEDED DETERMINISTIC RNG: 98234
            </span>
            <button
              onClick={runSimulation}
              disabled={isRunning}
              className="flex items-center gap-1.5 px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded text-xs font-mono font-bold transition-all shadow-sm"
            >
              <Play className={`w-3 h-3 ${isRunning ? 'animate-spin' : ''}`} />
              <span>Simulate {iterations.toLocaleString()} Paths</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 mt-3 text-xs font-mono">
          <div>
            <label className="text-slate-400 block mb-1">Iterations ({iterations.toLocaleString()})</label>
            <select
              value={iterations}
              onChange={e => setIterations(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-500"
            >
              <option value={1000}>1,000 Iterations (Fast)</option>
              <option value={2500}>2,500 Iterations (Institutional)</option>
              <option value={5000}>5,000 Iterations (Deep Precision)</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Base Annual Residual ({currencySymbol})</label>
            <input
              type="number"
              value={baseCashflow}
              onChange={e => setBaseCashflow(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-500 font-mono"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Revenue Volatility ({(volatility * 100).toFixed(0)}%)</label>
            <input
              type="range"
              min="0.08"
              max="0.40"
              step="0.01"
              value={volatility}
              onChange={e => setVolatility(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Contract Renewal Prob ({(renewalProb * 100).toFixed(0)}%)</label>
            <input
              type="range"
              min="0.30"
              max="0.95"
              step="0.05"
              value={renewalProb}
              onChange={e => setRenewalProb(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Simulation Horizon</label>
            <select
              value={horizonYears}
              onChange={e => setHorizonYears(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-500"
            >
              <option value={5}>5-Year Cumulative</option>
              <option value={10}>10-Year Cumulative</option>
            </select>
          </div>
        </div>
      </div>

      {/* Stochastic Percentile Strip */}
      {p5 && (
        <div className="grid grid-cols-2 md:grid-cols-5 lg:grid-cols-7 gap-3">
          <div className="terminal-card p-3 rounded-lg border-l-2 border-l-rose-500">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">P10 (Conservative Floor)</span>
            <div className="mt-1 text-lg font-bold font-mono text-rose-400">
              {currencySymbol}{((p5.p10 ?? 0) / 1_000_000).toFixed(2)}M
            </div>
            <span className="text-[10px] text-slate-400 font-mono">90% Prob &gt; This Floor</span>
          </div>

          <div className="terminal-card p-3 rounded-lg border-l-2 border-l-amber-500">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">P25 (Lower Quartile)</span>
            <div className="mt-1 text-lg font-bold font-mono text-amber-300">
              {currencySymbol}{((p5.p25 ?? 0) / 1_000_000).toFixed(2)}M
            </div>
            <span className="text-[10px] text-slate-400 font-mono">75% Prob Exceedance</span>
          </div>

          <div className="terminal-card p-3 rounded-lg border-l-2 border-l-blue-500">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">P50 (Median Baseline)</span>
            <div className="mt-1 text-lg font-bold font-mono text-blue-400">
              {currencySymbol}{((p5.p50 ?? 0) / 1_000_000).toFixed(2)}M
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Central Scenario</span>
          </div>

          <div className="terminal-card p-3 rounded-lg border-l-2 border-l-cyan-500">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">P75 (Upper Quartile)</span>
            <div className="mt-1 text-lg font-bold font-mono text-cyan-300">
              {currencySymbol}{((p5.p75 ?? 0) / 1_000_000).toFixed(2)}M
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Strong Performance</span>
          </div>

          <div className="terminal-card p-3 rounded-lg border-l-2 border-l-emerald-500">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">P90 (Upside Case)</span>
            <div className="mt-1 text-lg font-bold font-mono text-emerald-400">
              {currencySymbol}{((p5.p90 ?? 0) / 1_000_000).toFixed(2)}M
            </div>
            <span className="text-[10px] text-slate-400 font-mono">10% Prob Hit Breakout</span>
          </div>

          <div className="terminal-card p-3 rounded-lg border-l-2 border-l-purple-500">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Expected Mean</span>
            <div className="mt-1 text-lg font-bold font-mono text-purple-300">
              {currencySymbol}{((p5.mean ?? 0) / 1_000_000).toFixed(2)}M
            </div>
            <span className="text-[10px] text-slate-400 font-mono">StdDev: {currencySymbol}{((p5.stdDev ?? 0) / 1_000_000).toFixed(2)}M</span>
          </div>

          <div className="terminal-card p-3 rounded-lg border-l-2 border-l-slate-600">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Tail Span (Min - Max)</span>
            <div className="mt-1 text-xs font-bold font-mono text-slate-300">
              {currencySymbol}{((p5.min ?? 0) / 1_000_000).toFixed(2)}M - {currencySymbol}{((p5.max ?? 0) / 1_000_000).toFixed(2)}M
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Empirical Range</span>
          </div>
        </div>
      )}

      {/* Main Charts: Distribution Histogram & Brownian Motion Paths */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 Cols: Probability Distribution Histogram */}
        <div className="lg:col-span-7 terminal-card rounded-lg p-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
                <BarChart className="w-4 h-4 text-amber-400" />
                5-Year Cumulative Cash Flow Probability Density
              </h3>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Frequency distribution across {iterations.toLocaleString()} stochastic simulation trials
              </p>
            </div>
          </div>

          <div className="h-64 mt-3">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={histogramData} margin={{ top: 10, right: 10, left: 10, bottom: 25 }}>
                <XAxis dataKey="range" stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 9 }} angle={-25} textAnchor="end" />
                <YAxis stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '11px', fontFamily: 'JetBrains Mono' }}
                  formatter={(val: any) => [`${val} trials`, 'Frequency']}
                />
                <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right 5 Cols: Sample Geometric Brownian Motion Trajectories */}
        <div className="lg:col-span-5 terminal-card rounded-lg p-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                Sample Simulated Trajectories
              </h3>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                12 stochastic paths with jump diffusion &amp; renewal shocks
              </p>
            </div>
          </div>

          <div className="h-64 mt-3">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={samplePathsChartData} margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
                <XAxis dataKey="year" stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <YAxis stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 10 }} tickFormatter={(val) => `£${(val / 1000).toFixed(0)}k`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '10px', fontFamily: 'JetBrains Mono' }}
                />
                {simResult?.samplePaths.map((p, idx) => (
                  <Line
                    key={p.pathId}
                    type="monotone"
                    dataKey={`Path ${p.pathId}`}
                    stroke={['#f59e0b', '#3b82f6', '#10b981', '#8b5cf6', '#ec4899', '#06b6d4', '#eab308'][idx % 7]}
                    strokeWidth={1.2}
                    dot={false}
                    opacity={0.8}
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
