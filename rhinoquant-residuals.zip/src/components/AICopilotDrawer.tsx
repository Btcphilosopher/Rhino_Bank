import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Send,
  Bot,
  User,
  ShieldCheck,
  FileCheck2,
  Cpu,
  CornerDownLeft,
} from 'lucide-react';

interface AICopilotDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'USER' | 'COPILOT';
  text: string;
  calculationId?: string;
  sourceRecords?: string[];
  modelVersion?: string;
}

export const AICopilotDrawer: React.FC<AICopilotDrawerProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'INIT-01',
      sender: 'COPILOT',
      text: `Welcome to **RhinoQuant Residuals AI Copilot**. I am connected directly to the deterministic calculation engines, contract definitions, rights matrix, and DCF/Monte Carlo models.\n\nAsk any question about portfolio cash flows, contract terms, deductions, rights exclusivity, or macro scenario impacts.`,
      calculationId: 'RES-AI-SYSTEM-READY',
      modelVersion: 'v2.4.0-PROD-DETERMINISTIC',
    },
  ]);
  const [inputQuery, setInputQuery] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  if (!isOpen) return null;

  const quickPrompts = [
    'Which contracts generate the highest residual cash flow?',
    'What contracts expire within 24 months and what is the value at risk?',
    'Which catalogue streams exhibit the steepest decay rate?',
    'Explain the SAG-AFTRA streaming guild deduction in Titanium Dawn.',
  ];

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `USER-${Date.now()}`,
      sender: 'USER',
      text: textToSend,
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuery('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/ai/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: textToSend }),
      });
      const data = await res.json();

      const aiMsg: ChatMessage = {
        id: `AI-${Date.now()}`,
        sender: 'COPILOT',
        text: data.answer,
        calculationId: data.calculationId,
        sourceRecords: data.sourceRecords,
        modelVersion: data.modelVersion,
      };

      setMessages(prev => [...prev, aiMsg]);
    } catch (e: any) {
      setMessages(prev => [
        ...prev,
        {
          id: `ERR-${Date.now()}`,
          sender: 'COPILOT',
          text: `An error occurred processing the quantitative query: ${e.message}`,
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[480px] bg-[#0b111c] border-l border-slate-800 shadow-2xl flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-amber-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-display font-bold text-sm text-slate-100">
              RhinoQuant AI Copilot
            </h3>
            <span className="text-[10px] text-emerald-400 font-mono">
              ENGINE GROUNDED • ZERO AI HALLUCINATIONS
            </span>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map(msg => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'USER' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[92%] p-3 rounded-lg text-xs ${
                msg.sender === 'USER'
                  ? 'bg-amber-500 text-slate-950 font-medium font-sans rounded-tr-none'
                  : 'bg-slate-900 border border-slate-800 text-slate-200 font-sans rounded-tl-none space-y-2'
              }`}
            >
              <div className="whitespace-pre-wrap leading-relaxed">{msg.text}</div>

              {/* Citations block for AI */}
              {msg.calculationId && (
                <div className="mt-2 pt-2 border-t border-slate-800 text-[10px] font-mono text-slate-400 space-y-0.5">
                  <div className="flex items-center gap-1 text-emerald-400 font-semibold">
                    <ShieldCheck className="w-3 h-3" />
                    <span>Calculation Proof Verified</span>
                  </div>
                  <div>Trace ID: <span className="text-slate-300">{msg.calculationId}</span></div>
                  <div>Model: <span className="text-slate-300">{msg.modelVersion}</span></div>
                </div>
              )}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 p-2 bg-slate-900/60 rounded border border-slate-800 w-fit">
            <Cpu className="w-3.5 h-3.5 animate-spin" />
            <span>Evaluating quantitative model context...</span>
          </div>
        )}
      </div>

      {/* Quick Prompts */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950/40">
        <span className="text-[10px] font-mono text-slate-500 uppercase block mb-1.5">Suggested Inquiries:</span>
        <div className="flex flex-wrap gap-1.5">
          {quickPrompts.map((qp, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(qp)}
              className="text-[10px] font-mono text-slate-400 hover:text-amber-300 bg-slate-900 hover:bg-slate-800 px-2 py-1 rounded border border-slate-800 transition-all truncate max-w-full text-left"
            >
              {qp}
            </button>
          ))}
        </div>
      </div>

      {/* Input Box */}
      <div className="p-3 border-t border-slate-800 bg-slate-950">
        <div className="relative">
          <textarea
            rows={2}
            value={inputQuery}
            onChange={e => setInputQuery(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Ask a question about contracts, valuations, or cash flows..."
            className="w-full bg-slate-900 border border-slate-800 rounded p-2.5 pr-10 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500 font-sans resize-none"
          />
          <button
            onClick={() => handleSend()}
            disabled={!inputQuery.trim() || isLoading}
            className="absolute right-2.5 bottom-3.5 p-1.5 bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 rounded transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
