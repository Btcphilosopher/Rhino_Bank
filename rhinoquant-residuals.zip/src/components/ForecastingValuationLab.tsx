import React, { useState, useEffect } from 'react';
import { Asset, Contract, ForecastResult, ValuationMetrics, ReliefFromRoyaltyValuation } from '../domain/types';
import {
  TrendingUp,
  Sliders,
  DollarSign,
  PieChart as PieIcon,
  Clock,
  Sparkles,
  BarChart3,
  Layers,
  ChevronRight,
  ShieldCheck,
  Scale,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from 'recharts';

interface ForecastingValuationLabProps {
  assets: Asset[];
  contracts: Contract[];
  currencySymbol: string;
}

export const ForecastingValuationLab: React.FC<ForecastingValuationLabProps> = ({
  assets,
  contracts,
  currencySymbol,
}) => {
  const [selectedAssetId, setSelectedAssetId] = useState<string>(assets[0]?.id || '');
  const [horizonYears, setHorizonYears] = useState<number>(10);
  const [discountRatePct, setDiscountRatePct] = useState<number>(9.5);
  const [curveType, setCurveType] = useState<'WEIBULL' | 'EXPONENTIAL' | 'POWER_LAW' | 'S_CURVE'>('WEIBULL');
  const [marketRoyaltyPct, setMarketRoyaltyPct] = useState<number>(7.5);

  const [forecast, setForecast] = useState<ForecastResult | null>(null);
  const [dcfValuation, setDcfValuation] = useState<ValuationMetrics | null>(null);
  const [reliefValuation, setReliefValuation] = useState<ReliefFromRoyaltyValuation | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const selectedAsset = assets.find(a => a.id === selectedAssetId) || assets[0];

  const runValuation = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/valuation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          assetId: selectedAssetId,
          discountRatePct,
          marketRoyaltyPct,
        }),
      });
      const data = await res.json();
      setForecast(data.forecast);
      setDcfValuation(data.dcfValuation);
      setReliefValuation(data.reliefValuation);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedAsset) {
      setMarketRoyaltyPct(selectedAsset.marketRoyaltyBenchmarkRatePct || 7.5);
    }
    runValuation();
  }, [selectedAssetId, horizonYears, discountRatePct, curveType, marketRoyaltyPct]);

  // Chart Data preparation
  const chartData = forecast
    ? forecast.forecastPeriods.map(p => ({
        name: p.periodLabel.split(' ')[0] + ' ' + p.periodLabel.split(' ')[1],
        Base: p.baseResidualIncomeGBP,
        Upside: p.upsideResidualIncomeGBP,
        Downside: p.downsideResidualIncomeGBP,
        Stress: p.stressResidualIncomeGBP,
        GrossRevenue: p.baseRevenueGBP,
      }))
    : [];

  return (
    <div className="space-y-6">
      {/* Parameter Control Panel */}
      <div className="terminal-card p-4 rounded-lg bg-slate-900/60 border-slate-800">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-amber-400" />
            <h2 className="font-display font-bold text-sm text-slate-100">
              Multi-Horizon Forecasting &amp; Quantitative Valuation Lab
            </h2>
          </div>
          <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
            MODEL: WEIBULL SURVIVAL &amp; GORDON GROWTH DCF
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 mt-3 text-xs font-mono">
          <div>
            <label className="text-slate-400 block mb-1">Target Asset Stream</label>
            <select
              value={selectedAssetId}
              onChange={e => setSelectedAssetId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-500"
            >
              {assets.map(a => (
                <option key={a.id} value={a.id}>
                  {a.title} ({a.type.replace('_', ' ')})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Time Horizon</label>
            <select
              value={horizonYears}
              onChange={e => setHorizonYears(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-500"
            >
              <option value={5}>5-Year Horizon</option>
              <option value={10}>10-Year Horizon</option>
              <option value={20}>20-Year Long-Tail</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Decay Curve Model</label>
            <select
              value={curveType}
              onChange={e => setCurveType(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-500"
            >
              <option value="WEIBULL">Weibull Decay (Parametric)</option>
              <option value="EXPONENTIAL">Exponential Halflife</option>
              <option value="POWER_LAW">Power-Law Long-Tail</option>
              <option value="S_CURVE">Logistic S-Curve</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Discount Rate / WACC ({discountRatePct}%)</label>
            <input
              type="range"
              min="5"
              max="18"
              step="0.5"
              value={discountRatePct}
              onChange={e => setDiscountRatePct(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Market Royalty Benchmark ({marketRoyaltyPct}%)</label>
            <input
              type="range"
              min="2"
              max="25"
              step="0.5"
              value={marketRoyaltyPct}
              onChange={e => setMarketRoyaltyPct(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Valuation Metrics KPI Cards */}
      {dcfValuation && (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          <div className="terminal-card p-3 rounded-lg border-l-2 border-l-amber-500">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Residual Stream NPV</span>
            <div className="mt-1 text-lg font-bold font-mono text-amber-400">
              {currencySymbol}{((dcfValuation.npvGBP ?? 0) / 1_000_000).toFixed(2)}M
            </div>
            <span className="text-[10px] text-slate-400 font-mono">@ {discountRatePct}% Discount</span>
          </div>

          <div className="terminal-card p-3 rounded-lg border-l-2 border-l-blue-500">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Internal Rate of Return (IRR)</span>
            <div className="mt-1 text-lg font-bold font-mono text-blue-400">
              {dcfValuation.irrPct ?? 0}%
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Cashflow Yield: {dcfValuation.cashFlowYieldPct ?? 0}%</span>
          </div>

          <div className="terminal-card p-3 rounded-lg border-l-2 border-l-purple-500">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Macaulay Duration</span>
            <div className="mt-1 text-lg font-bold font-mono text-purple-300">
              {dcfValuation.macaulayDurationYears ?? 0} <span className="text-xs font-normal">YRS</span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Mod Dur: {dcfValuation.modifiedDurationYears ?? 0} Yrs</span>
          </div>

          <div className="terminal-card p-3 rounded-lg border-l-2 border-l-emerald-500">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Payback Period</span>
            <div className="mt-1 text-lg font-bold font-mono text-emerald-400">
              {dcfValuation.paybackPeriodYears ?? 0} <span className="text-xs font-normal">YRS</span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Full Capital Recovery</span>
          </div>

          <div className="terminal-card p-3 rounded-lg border-l-2 border-l-cyan-500">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Gordon Terminal Value</span>
            <div className="mt-1 text-lg font-bold font-mono text-cyan-300">
              {currencySymbol}{((dcfValuation.terminalValueGBP ?? 0) / 1_000_000).toFixed(2)}M
            </div>
            <span className="text-[10px] text-slate-400 font-mono">g = 1.0% Terminal</span>
          </div>

          <div className="terminal-card p-3 rounded-lg border-l-2 border-l-rose-500">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Relief-from-Royalty IP Val</span>
            <div className="mt-1 text-lg font-bold font-mono text-rose-400">
              {currencySymbol}{((reliefValuation?.estimatedIPValuationGBP || 0) / 1_000_000).toFixed(2)}M
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Benchmark @ {marketRoyaltyPct}%</span>
          </div>
        </div>
      )}

      {/* Main Charts: Multi-Scenario Residual Projections */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 8 Cols: Scenario Forecast Curves */}
        <div className="lg:col-span-8 terminal-card rounded-lg p-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-amber-400" />
                Multi-Horizon Scenario Residual Streams ({horizonYears}-Year Horizon)
              </h3>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Base, Upside (+35%), Downside (-28%), and Stress (-55%) cash flows
              </p>
            </div>
          </div>

          <div className="h-72 mt-3">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
                <defs>
                  <linearGradient id="colorUpside" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorBase" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <YAxis stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 10 }} tickFormatter={(val) => `£${((Number(val) || 0) / 1000).toFixed(0)}k`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '11px', fontFamily: 'JetBrains Mono' }}
                  formatter={(val: any) => [`${currencySymbol}${(Number(val) || 0).toLocaleString()}`, 'Annual Residual']}
                />
                <Legend wrapperStyle={{ fontSize: '11px', fontFamily: 'JetBrains Mono' }} />
                <Area type="monotone" dataKey="Upside" stroke="#10b981" fillOpacity={1} fill="url(#colorUpside)" strokeWidth={2} />
                <Area type="monotone" dataKey="Base" stroke="#f59e0b" fillOpacity={1} fill="url(#colorBase)" strokeWidth={2.5} />
                <Line type="monotone" dataKey="Downside" stroke="#f43f5e" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
                <Line type="monotone" dataKey="Stress" stroke="#dc2626" strokeWidth={1.5} strokeDasharray="2 2" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right 4 Cols: 2D Sensitivity Grid & Relief-from-Royalty */}
        <div className="lg:col-span-4 space-y-6">
          {/* 2D Sensitivity Matrix */}
          <div className="terminal-card rounded-lg p-4">
            <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2 pb-3 border-b border-slate-800">
              <Scale className="w-4 h-4 text-amber-400" />
              2D Valuation Sensitivity Matrix
            </h3>
            <p className="text-[11px] text-slate-400 font-mono mt-1 mb-2">
              NPV Matrix: Discount Rate vs Decay Shift
            </p>

            <div className="overflow-x-auto text-[10px] font-mono">
              <table className="w-full text-center border-collapse">
                <thead>
                  <tr className="text-slate-400 bg-slate-950">
                    <th className="p-1.5 border border-slate-800">Disc \ Decay</th>
                    <th className="p-1.5 border border-slate-800 text-emerald-400">-5%</th>
                    <th className="p-1.5 border border-slate-800 text-slate-300">Base</th>
                    <th className="p-1.5 border border-slate-800 text-rose-400">+5%</th>
                  </tr>
                </thead>
                <tbody>
                  {[8.0, 9.5, 12.0, 14.0].map(dr => (
                    <tr key={dr} className="hover:bg-slate-800/40">
                      <td className="p-1.5 border border-slate-800 font-bold text-slate-300 bg-slate-950/60">{dr}%</td>
                      <td className="p-1.5 border border-slate-800 text-emerald-300">
                        {currencySymbol}{(((dcfValuation?.npvGBP || 1000000) * (9.5 / dr) * 1.12) / 1_000_000).toFixed(1)}M
                      </td>
                      <td className="p-1.5 border border-slate-800 text-amber-300 font-semibold">
                        {currencySymbol}{(((dcfValuation?.npvGBP || 1000000) * (9.5 / dr)) / 1_000_000).toFixed(1)}M
                      </td>
                      <td className="p-1.5 border border-slate-800 text-rose-300">
                        {currencySymbol}{(((dcfValuation?.npvGBP || 1000000) * (9.5 / dr) * 0.88) / 1_000_000).toFixed(1)}M
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Relief-from-Royalty Module Summary */}
          {reliefValuation && (
            <div className="terminal-card rounded-lg p-4 space-y-2">
              <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2 pb-2 border-b border-slate-800">
                <ShieldCheck className="w-4 h-4 text-rose-400" />
                Relief-from-Royalty Independent Valuation
              </h3>
              <div className="text-xs font-mono space-y-1.5 text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">10-Yr Forecast Gross:</span>
                  <span className="font-bold">{currencySymbol}{((reliefValuation.tenYearForecastRevenueGBP ?? 0) / 1_000_000).toFixed(1)}M</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Market Royalty Benchmark:</span>
                  <span className="font-bold text-amber-400">{reliefValuation.assumedMarketRoyaltyRatePct ?? 0}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Tax Adjustment Rate:</span>
                  <span>{reliefValuation.taxAdjustmentRatePct ?? 0}%</span>
                </div>
                <div className="pt-2 border-t border-slate-800 flex justify-between text-sm">
                  <span className="font-sans font-bold text-rose-300">Stand-Alone IP Value:</span>
                  <span className="font-mono font-bold text-rose-400">
                    {currencySymbol}{((reliefValuation.estimatedIPValuationGBP ?? 0) / 1_000_000).toFixed(2)}M
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
