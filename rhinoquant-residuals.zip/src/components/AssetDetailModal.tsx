import React from 'react';
import { Asset, Contract, Right } from '../domain/types';
import {
  X,
  Building,
  Calendar,
  Globe,
  Tv,
  FileText,
  TrendingUp,
  Cpu,
  ShieldCheck,
  ChevronRight,
  Layers,
} from 'lucide-react';

interface AssetDetailModalProps {
  asset: Asset | null;
  contracts: Contract[];
  rights: Right[];
  onClose: () => void;
  onNavigateToCalc: (assetId: string) => void;
  onNavigateToForecast: (assetId: string) => void;
  currencySymbol: string;
}

export const AssetDetailModal: React.FC<AssetDetailModalProps> = ({
  asset,
  contracts,
  rights,
  onClose,
  onNavigateToCalc,
  onNavigateToForecast,
  currencySymbol,
}) => {
  if (!asset) return null;

  const linkedContracts = contracts.filter(c => c.assetId === asset.id);
  const linkedRights = rights.filter(r => r.assetId === asset.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="w-full max-w-3xl max-h-[90vh] overflow-y-auto terminal-card bg-[#0b111c] rounded-xl border border-slate-700 shadow-2xl p-6 space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded text-[10px] font-mono font-bold">
                {asset.type.replace('_', ' ')}
              </span>
              <span className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded text-[10px] font-mono">
                {asset.lifecycleStage}
              </span>
            </div>
            <h2 className="text-xl font-display font-bold text-slate-100 mt-1">
              {asset.title}
            </h2>
            <p className="text-xs text-slate-400 mt-1 font-sans">
              {asset.description}
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Top Financial Stats Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 text-[10px] uppercase block">Historical Gross Total</span>
            <span className="text-base font-bold text-slate-100 font-mono">
              {currencySymbol}{((asset.historicalGrossTotal ?? 0) / 1_000_000).toFixed(1)}M
            </span>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 text-[10px] uppercase block">Net Residuals Paid</span>
            <span className="text-base font-bold text-emerald-400 font-mono">
              {currencySymbol}{((asset.historicalNetResidualsPaid ?? 0) / 1_000_000).toFixed(2)}M
            </span>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 text-[10px] uppercase block">Annual Decay Rate</span>
            <span className="text-base font-bold text-slate-200 font-mono">
              {(asset.baseDecayRateAnnualPct ?? 0).toFixed(1)}%/yr
            </span>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 text-[10px] uppercase block">Royalty Benchmark</span>
            <span className="text-base font-bold text-amber-400 font-mono">
              {(asset.marketRoyaltyBenchmarkRatePct ?? 0).toFixed(1)}%
            </span>
          </div>
        </div>

        {/* Linked Active Contracts */}
        <div className="space-y-3">
          <h3 className="font-display font-bold text-sm text-slate-200 flex items-center gap-2">
            <FileText className="w-4 h-4 text-amber-400" />
            Linked Contractual Agreements ({linkedContracts.length})
          </h3>

          <div className="space-y-2">
            {linkedContracts.map(c => (
              <div key={c.id} className="p-3 bg-slate-950 rounded border border-slate-800 flex items-start justify-between text-xs font-mono">
                <div>
                  <span className="font-sans font-semibold text-slate-200 block text-sm">{c.title}</span>
                  <div className="text-[11px] text-slate-400 flex flex-wrap items-center gap-2 mt-1">
                    <span>ID: <strong className="text-slate-300">{c.id}</strong> (v{c.version})</span>
                    <span>•</span>
                    <span>Matures: <strong className="text-slate-300">{c.expiryDate}</strong></span>
                    <span>•</span>
                    <span>Rule: <strong className="text-amber-400">{c.royaltyRules.ruleType}</strong></span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    Beneficiaries: {c.parties.participants.map(p => p.role).join(', ')}
                  </div>
                </div>
                <div className="text-right">
                  <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded text-[10px] font-bold">
                    {c.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Controls */}
        <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-end gap-3">
          <button
            onClick={() => {
              onClose();
              onNavigateToForecast(asset.id);
            }}
            className="flex items-center gap-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-mono font-medium transition-colors"
          >
            <TrendingUp className="w-3.5 h-3.5 text-blue-400" />
            <span>Launch Forecasting Lab</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onNavigateToCalc(asset.id);
            }}
            className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded text-xs font-mono font-bold transition-colors shadow-sm"
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Open in Residual Engine</span>
          </button>
        </div>
      </div>
    </div>
  );
};
