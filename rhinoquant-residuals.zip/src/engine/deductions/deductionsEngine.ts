/**
 * RhinoQuant Residuals - Deductions Engine
 * Handles tiered distribution fees, union SAG/WGA residuals, off-the-top costs, and capped deductions.
 */

import { ContractDeductionRule, MediaChannel, NormalisedRevenueRecord } from '../../domain/types';
import { roundCurrency } from '../math';

export interface EvaluatedDeduction {
  ruleId: string;
  name: string;
  type: string;
  ratePercentage?: number;
  calculatedAmount: number;
  isCapped: boolean;
  capAmount?: number;
  priorityOrder: number;
}

export function evaluateDeductions(
  revenueRecord: NormalisedRevenueRecord,
  deductionRules: ContractDeductionRule[],
  cumulativeChannelDeductionsToDate: number = 0
): {
  evaluatedDeductions: EvaluatedDeduction[];
  totalDeductionsGBP: number;
  netRevenueGBP: number;
} {
  const gross = revenueRecord.normalizedGrossGBP;
  const evaluatedDeductions: EvaluatedDeduction[] = [];
  let currentGrossBase = gross;
  let totalDeductions = 0;

  // Sort by priority order (1 = Off-The-Top, 2 = Distribution, etc.)
  const sortedRules = [...deductionRules].sort((a, b) => a.priorityOrder - b.priorityOrder);

  for (const rule of sortedRules) {
    // Check channel applicability
    if (rule.appliesToChannels && rule.appliesToChannels.length > 0) {
      if (!rule.appliesToChannels.includes(revenueRecord.channel)) {
        continue;
      }
    }

    let amount = 0;
    if (rule.ratePercentage !== undefined && rule.ratePercentage > 0) {
      amount = currentGrossBase * rule.ratePercentage;
    } else if (rule.fixedAmount !== undefined && rule.fixedAmount > 0) {
      amount = rule.fixedAmount;
    }

    // Apply cap if configured
    if (rule.isCapped && rule.capAmount) {
      const remainingCap = Math.max(0, rule.capAmount - cumulativeChannelDeductionsToDate);
      amount = Math.min(amount, remainingCap);
    }

    amount = roundCurrency(amount, 2);

    evaluatedDeductions.push({
      ruleId: rule.id,
      name: rule.name,
      type: rule.type,
      ratePercentage: rule.ratePercentage,
      calculatedAmount: amount,
      isCapped: rule.isCapped,
      capAmount: rule.capAmount,
      priorityOrder: rule.priorityOrder,
    });

    totalDeductions += amount;
  }

  const netRevenue = Math.max(0, roundCurrency(gross - totalDeductions, 2));

  return {
    evaluatedDeductions,
    totalDeductionsGBP: roundCurrency(totalDeductions, 2),
    netRevenueGBP: netRevenue,
  };
}
