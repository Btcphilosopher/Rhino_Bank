/**
 * RhinoQuant Residuals - Portfolio Risk & Stress Testing Engine
 * Concentration metrics (HHI), counterparty exposure, expiry cliff, and macro stress test scenarios.
 */

import { Asset, Contract, PortfolioRiskMetrics } from '../../domain/types';
import { roundCurrency, calculateHHI } from '../math';

export class RiskEngine {
  public static evaluatePortfolioRisk(
    assets: Asset[],
    contracts: Contract[],
    totalPortfolioNAV: number,
    expected12mIncome: number
  ): PortfolioRiskMetrics {
    // 1. Platform Exposure & HHI
    const platformWeights: Record<string, number> = {};
    for (const c of contracts) {
      for (const p of c.platforms) {
        platformWeights[p] = (platformWeights[p] || 0) + 1;
      }
    }
    const platformShares = Object.values(platformWeights);
    const platformHHI = calculateHHI(platformShares);

    // 2. Territory Exposure & HHI
    const territoryWeights: Record<string, number> = {};
    for (const a of assets) {
      for (const t of a.primaryTerritories) {
        territoryWeights[t] = (territoryWeights[t] || 0) + a.historicalGrossTotal;
      }
    }
    const territoryShares = Object.values(territoryWeights);
    const territoryHHI = calculateHHI(territoryShares);

    // 3. Counterparty HHI
    const counterpartyWeights: Record<string, number> = {};
    for (const c of contracts) {
      const licensee = c.parties.licensee;
      counterpartyWeights[licensee] = (counterpartyWeights[licensee] || 0) + 1;
    }
    const counterpartyHHI = calculateHHI(Object.values(counterpartyWeights));

    // 4. Contract Expiry Cliff (<24 Months)
    const now = new Date('2026-09-11').getTime();
    const twoYearsMs = 24 * 30.4375 * 24 * 3600 * 1000;
    const expiringContracts = contracts.filter(c => {
      const exp = new Date(c.expiryDate).getTime();
      return exp > now && exp - now <= twoYearsMs;
    });

    const expiringUnder24MonthsCount = expiringContracts.length;
    const expiringUnder24MonthsValueGBP = roundCurrency(
      totalPortfolioNAV * (expiringUnder24MonthsCount / Math.max(1, contracts.length)) * 0.72,
      2
    );

    // Top Risk Identification
    let topRisk = 'PLATFORM CONCENTRATION';
    if (platformHHI > 2500) topRisk = 'HIGH PLATFORM CONCENTRATION (HHI > 2,500)';
    else if (expiringUnder24MonthsCount > 3) topRisk = 'EXPIRY CLIFF: 4+ KEY CONTRACTS MATURING <24M';
    else if (territoryHHI > 3500) topRisk = 'REGIONAL EXPOSURE SENSITIVITY';

    // 5. Stress Test Scenarios
    const stressTestResults: PortfolioRiskMetrics['stressTestResults'] = [
      {
        scenarioName: 'STREAMING REVENUE -40%',
        description: 'SVOD/AVOD market compression and subscriber deceleration across all tiers.',
        baseNAVGBP: totalPortfolioNAV,
        stressedNAVGBP: roundCurrency(totalPortfolioNAV * 0.71, 2),
        navLossGBP: roundCurrency(totalPortfolioNAV * 0.29, 2),
        navLossPercentage: 29.0,
        impactSeverity: 'CRITICAL',
      },
      {
        scenarioName: 'GBP/USD -15% DEPRECIATION',
        description: 'Pound weakens significantly against USD international collections.',
        baseNAVGBP: totalPortfolioNAV,
        stressedNAVGBP: roundCurrency(totalPortfolioNAV * 1.09, 2), // Beneficial to foreign revenue converted to GBP
        navLossGBP: roundCurrency(-totalPortfolioNAV * 0.09, 2),
        navLossPercentage: -9.0,
        impactSeverity: 'LOW',
      },
      {
        scenarioName: 'CATALOGUE DECAY +10%',
        description: 'Accelerated obsolescence and reduced long-tail library syndication rates.',
        baseNAVGBP: totalPortfolioNAV,
        stressedNAVGBP: roundCurrency(totalPortfolioNAV * 0.84, 2),
        navLossGBP: roundCurrency(totalPortfolioNAV * 0.16, 2),
        navLossPercentage: 16.0,
        impactSeverity: 'HIGH',
      },
      {
        scenarioName: 'TOP PLATFORM LOSS (DISPUTE/CARRIAGE)',
        description: 'Complete blackout of largest single platform distributor for 18 months.',
        baseNAVGBP: totalPortfolioNAV,
        stressedNAVGBP: roundCurrency(totalPortfolioNAV * 0.79, 2),
        navLossGBP: roundCurrency(totalPortfolioNAV * 0.21, 2),
        navLossPercentage: 21.0,
        impactSeverity: 'HIGH',
      },
      {
        scenarioName: 'KEY CONTRACT EARLY TERMINATION',
        description: 'Legal breach or bankruptcy leading to immediate cancellation of top 2 contracts.',
        baseNAVGBP: totalPortfolioNAV,
        stressedNAVGBP: roundCurrency(totalPortfolioNAV * 0.81, 2),
        navLossGBP: roundCurrency(totalPortfolioNAV * 0.19, 2),
        navLossPercentage: 19.0,
        impactSeverity: 'HIGH',
      },
      {
        scenarioName: 'TERRITORY EMBARGO / GEOPOLITICAL LOCKOUT',
        description: 'Closure of APAC & LATAM licensing and distribution channels.',
        baseNAVGBP: totalPortfolioNAV,
        stressedNAVGBP: roundCurrency(totalPortfolioNAV * 0.88, 2),
        navLossGBP: roundCurrency(totalPortfolioNAV * 0.12, 2),
        navLossPercentage: 12.0,
        impactSeverity: 'MEDIUM',
      },
    ];

    return {
      totalResidualNAVGBP: totalPortfolioNAV,
      expected12mIncomeGBP: expected12mIncome,
      fiveYearExpectedIncomeGBP: roundCurrency(expected12mIncome * 4.4, 2),
      tenYearNPVGBP: roundCurrency(totalPortfolioNAV * 0.92, 2),
      weightedAverageDurationYears: 5.4,
      platformHerfindahlIndex: platformHHI,
      territoryHerfindahlIndex: territoryHHI,
      counterpartyHerfindahlIndex: counterpartyHHI,
      expiringUnder24MonthsCount,
      expiringUnder24MonthsValueGBP,
      topRiskFactor: topRisk,
      stressTestResults,
    };
  }
}
