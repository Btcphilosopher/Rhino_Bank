/**
 * RhinoQuant Residuals - Rights & Collision Detection Engine
 * Economic modeling of exclusive, territorial, windowed, and format rights.
 */

import { Right, ExclusivityType, TerritoryCode, MediaChannel } from '../../domain/types';

export interface RightsQuery {
  propertyId: string;
  territory: TerritoryCode;
  medium: MediaChannel;
  platform?: string;
  date: string;
}

export interface RightsValidationResult {
  isPermitted: boolean;
  matchedRightId?: string;
  owner?: string;
  exclusivity?: ExclusivityType;
  reasons: string[];
  activeEncumbrances?: string[];
}

export interface RightsCollision {
  rightAId: string;
  rightBId: string;
  propertyId: string;
  territory: TerritoryCode;
  medium: MediaChannel;
  platform: string;
  collisionReason: string;
  severity: 'FATAL_EXCLUSIVITY_BREACH' | 'WINDOW_OVERLAP_WARNING' | 'TERRITORIAL_AMBIGUITY';
}

export class RightsEngine {
  private rightsCatalog: Map<string, Right> = new Map();

  constructor(initialRights: Right[] = []) {
    initialRights.forEach(r => this.addRight(r));
  }

  public addRight(right: Right): void {
    this.rightsCatalog.set(right.id, right);
  }

  public getRight(rightId: string): Right | undefined {
    return this.rightsCatalog.get(rightId);
  }

  public getAllRights(): Right[] {
    return Array.from(this.rightsCatalog.values());
  }

  public getRightsForAsset(assetId: string): Right[] {
    return this.getAllRights().filter(r => r.assetId === assetId);
  }

  /**
   * Deterministically answers:
   * "Can this right legally/economically generate revenue in this territory and window?"
   */
  public evaluateRevenueEligibility(query: RightsQuery): RightsValidationResult {
    const reasons: string[] = [];
    const queryDate = new Date(query.date).getTime();

    const matchingRights = this.getAllRights().filter(r => {
      if (r.assetId !== query.propertyId) return false;

      // Territory check: GLOBAL covers all, or exact match
      const territoryMatches = r.territory === TerritoryCode.GLOBAL || r.territory === query.territory;
      if (!territoryMatches) return false;

      // Medium check
      if (r.medium !== query.medium) return false;

      // Platform check if specified
      if (query.platform && r.platform !== 'ALL' && r.platform.toLowerCase() !== query.platform.toLowerCase()) {
        return false;
      }

      // Date window check
      const start = new Date(r.startDate).getTime();
      const end = new Date(r.endDate).getTime();
      return queryDate >= start && queryDate <= end;
    });

    if (matchingRights.length === 0) {
      reasons.push(`No active right grants found for Asset ${query.propertyId} in ${query.territory} via ${query.medium} on ${query.date}.`);
      return { isPermitted: false, reasons };
    }

    // Check encumbrances or holdbacks
    const validRight = matchingRights[0];
    if (validRight.encumbrances && validRight.encumbrances.length > 0) {
      reasons.push(`Granted with encumbrances: ${validRight.encumbrances.join(', ')}`);
    }

    return {
      isPermitted: true,
      matchedRightId: validRight.id,
      owner: validRight.owner,
      exclusivity: validRight.exclusivity,
      reasons: reasons.length ? reasons : ['Authorized under valid contractual right grant.'],
      activeEncumbrances: validRight.encumbrances,
    };
  }

  /**
   * Detects legal collisions across catalogue rights (e.g. 2 exclusive grants in same territory/time)
   */
  public detectCollisions(): RightsCollision[] {
    const collisions: RightsCollision[] = [];
    const rights = this.getAllRights();

    for (let i = 0; i < rights.length; i++) {
      for (let j = i + 1; j < rights.length; j++) {
        const a = rights[i];
        const b = rights[j];

        if (a.assetId !== b.assetId) continue;

        // Check territory overlap
        const territoryOverlap =
          a.territory === TerritoryCode.GLOBAL ||
          b.territory === TerritoryCode.GLOBAL ||
          a.territory === b.territory;

        if (!territoryOverlap) continue;

        // Check medium overlap
        if (a.medium !== b.medium) continue;

        // Check platform overlap
        const platformOverlap = a.platform === 'ALL' || b.platform === 'ALL' || a.platform.toLowerCase() === b.platform.toLowerCase();
        if (!platformOverlap) continue;

        // Check date window overlap
        const aStart = new Date(a.startDate).getTime();
        const aEnd = new Date(a.endDate).getTime();
        const bStart = new Date(b.startDate).getTime();
        const bEnd = new Date(b.endDate).getTime();

        const datesOverlap = Math.max(aStart, bStart) <= Math.min(aEnd, bEnd);
        if (!datesOverlap) continue;

        // Collision logic: If either is EXCLUSIVE or SOLE, and owners differ or both claim exclusivity
        if (
          (a.exclusivity === ExclusivityType.EXCLUSIVE || b.exclusivity === ExclusivityType.EXCLUSIVE) &&
          a.owner !== b.owner
        ) {
          collisions.push({
            rightAId: a.id,
            rightBId: b.id,
            propertyId: a.assetId,
            territory: a.territory,
            medium: a.medium,
            platform: a.platform,
            collisionReason: `Exclusivity breach: ${a.owner} holds ${a.exclusivity} and ${b.owner} holds ${b.exclusivity} during overlapping period ${a.startDate} - ${a.endDate}`,
            severity: 'FATAL_EXCLUSIVITY_BREACH',
          });
        } else if (a.window === b.window && a.id !== b.id && a.owner !== b.owner) {
          collisions.push({
            rightAId: a.id,
            rightBId: b.id,
            propertyId: a.assetId,
            territory: a.territory,
            medium: a.medium,
            platform: a.platform,
            collisionReason: `Duplicate window assignment for window '${a.window}' between ${a.owner} and ${b.owner}`,
            severity: 'WINDOW_OVERLAP_WARNING',
          });
        }
      }
    }

    return collisions;
  }
}
