/**
 * RhinoQuant Residuals - Stochastic Monte Carlo Simulation Engine
 * Simulates 1,000 to 10,000 brownian motion + jump-diffusion paths with renewal hazard rates.
 * Generates P10, P25, P50, P75, P90 confidence percentiles and cash flow probability distributions.
 */

import { MonteCarloSimulationResult, MonteCarloPercentiles, MonteCarloHistogramBin } from '../../domain/types';
import { roundCurrency, createSeededRNG, sampleStandardNormal } from '../math';

export interface MonteCarloConfig {
  iterations?: number; // e.g. 2,000 to 5,000
  horizonYears?: number; // 5 or 10
  seed?: number;
  revenueGrowthMean?: number; // e.g. 0.03
  revenueVolatility?: number; // e.g. 0.18
  streamingGrowthRate?: number; // e.g. 0.05
  fxVolatilityGBPUSD?: number; // e.g. 0.11
  contractRenewalProbability?: number; // e.g. 0.72
  catalogueSurvivalRate?: number; // e.g. 0.94
  jumpDiffusionIntensity?: number; // e.g. 0.08 (8% chance per year of jump shock)
}

export class MonteCarloEngine {
  public static runSimulation(
    baseYearlyCashflowGBP: number,
    config: MonteCarloConfig = {}
  ): MonteCarloSimulationResult {
    const {
      iterations = 2500,
      horizonYears = 10,
      seed = 98234,
      revenueGrowthMean = 0.025,
      revenueVolatility = 0.19,
      streamingGrowthRate = 0.045,
      fxVolatilityGBPUSD = 0.12,
      contractRenewalProbability = 0.75,
      catalogueSurvivalRate = 0.92,
      jumpDiffusionIntensity = 0.06,
    } = config;

    const rng = createSeededRNG(seed);
    const simulatedTotals5Y: number[] = [];
    const simulatedTotals10Y: number[] = [];
    const samplePaths: MonteCarloSimulationResult['samplePaths'] = [];

    // Run N simulations
    for (let sim = 0; sim < iterations; sim++) {
      let currentCashflow = baseYearlyCashflowGBP;
      let cum5Y = 0;
      let cum10Y = 0;
      const annualPath: number[] = [];

      for (let yr = 1; yr <= horizonYears; yr++) {
        // Geometric Brownian Motion step: dS/S = (mu - 0.5*sigma^2)dt + sigma*dW
        const zRevenue = sampleStandardNormal(rng);
        const zFX = sampleStandardNormal(rng);

        const drift = revenueGrowthMean + (streamingGrowthRate / yr) - 0.5 * Math.pow(revenueVolatility, 2);
        const diffusion = revenueVolatility * zRevenue + fxVolatilityGBPUSD * zFX * 0.4;
        let growthMultiplier = Math.exp(drift + diffusion);

        // Catalogue survival decay factor
        growthMultiplier *= catalogueSurvivalRate;

        // Jump diffusion shock (positive viral hit or platform cancellation)
        const jumpEvent = rng() < jumpDiffusionIntensity;
        if (jumpEvent) {
          const jumpMagnitude = rng() > 0.45 ? 1.45 : 0.65;
          growthMultiplier *= jumpMagnitude;
        }

        // Contract renewal probability impact after year 4
        if (yr >= 4) {
          const renewed = rng() < contractRenewalProbability;
          if (!renewed) {
            growthMultiplier *= 0.4; // severe haircut if contract not renewed
          }
        }

        currentCashflow = Math.max(1000, currentCashflow * growthMultiplier);
        annualPath.push(roundCurrency(currentCashflow, 2));

        if (yr <= 5) cum5Y += currentCashflow;
        cum10Y += currentCashflow;
      }

      simulatedTotals5Y.push(cum5Y);
      simulatedTotals10Y.push(cum10Y);

      // Keep 12 representative visual sample paths
      if (sim < 12) {
        samplePaths.push({
          pathId: sim + 1,
          annualCashflows: annualPath,
        });
      }
    }

    // Sort to extract empirical percentiles
    simulatedTotals5Y.sort((a, b) => a - b);
    simulatedTotals10Y.sort((a, b) => a - b);

    const getPercentiles = (arr: number[]): MonteCarloPercentiles => {
      const p10 = arr[Math.floor(arr.length * 0.10)];
      const p25 = arr[Math.floor(arr.length * 0.25)];
      const p50 = arr[Math.floor(arr.length * 0.50)];
      const p75 = arr[Math.floor(arr.length * 0.75)];
      const p90 = arr[Math.floor(arr.length * 0.90)];
      const min = arr[0];
      const max = arr[arr.length - 1];
      const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
      const variance = arr.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / arr.length;

      return {
        p10: roundCurrency(p10, 2),
        p25: roundCurrency(p25, 2),
        p50: roundCurrency(p50, 2),
        p75: roundCurrency(p75, 2),
        p90: roundCurrency(p90, 2),
        mean: roundCurrency(mean, 2),
        stdDev: roundCurrency(Math.sqrt(variance), 2),
        min: roundCurrency(min, 2),
        max: roundCurrency(max, 2),
      };
    };

    const simulatedPercentiles5Y = getPercentiles(simulatedTotals5Y);
    const simulatedPercentiles10Y = getPercentiles(simulatedTotals10Y);

    // Build histogram for 5Y distribution
    const minVal = simulatedPercentiles5Y.min;
    const maxVal = simulatedPercentiles5Y.max;
    const binCount = 14;
    const binWidth = (maxVal - minVal) / binCount;
    const histogramBins5Y: MonteCarloHistogramBin[] = [];

    for (let b = 0; b < binCount; b++) {
      const bMin = minVal + b * binWidth;
      const bMax = bMin + binWidth;
      const count = simulatedTotals5Y.filter(v => v >= bMin && (b === binCount - 1 ? v <= bMax : v < bMax)).length;
      histogramBins5Y.push({
        rangeMin: roundCurrency(bMin, 2),
        rangeMax: roundCurrency(bMax, 2),
        count,
        percentage: roundCurrency((count / iterations) * 100, 1),
      });
    }

    const simulationId = `MC-SIM-${Math.floor(100000 + rng() * 900000)}`;

    return {
      simulationId,
      iterationsCount: iterations,
      horizonYears,
      simulatedPercentiles5Y,
      simulatedPercentiles10Y,
      histogramBins5Y,
      samplePaths,
      assumptions: {
        revenueGrowthMean,
        revenueVolatility,
        streamingGrowthRate,
        fxVolatilityGBPUSD,
        contractRenewalProbability,
        catalogueSurvivalRate,
        jumpDiffusionIntensity,
      },
    };
  }
}
