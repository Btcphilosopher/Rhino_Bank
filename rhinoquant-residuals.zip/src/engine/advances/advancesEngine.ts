/**
 * RhinoQuant Residuals - Advances & Recoupment Modeling Engine
 * Tracks advance balances, unrecouped capital, cross-collateralization, and projected payoff timelines.
 */

import { AdvanceRecord, PaymentFrequency } from '../../domain/types';
import { roundCurrency } from '../math';

export interface AdvanceRecoupmentProjection {
  advanceId: string;
  contractId: string;
  participantId: string;
  initialAdvanceGBP: number;
  recoupedToDateGBP: number;
  remainingBalanceGBP: number;
  historicalRecoupmentRateQuarterlyGBP: number;
  isFullyRecouped: boolean;
  projectedRecoupmentQuarter: string;
  projectedQuartersRemaining: number;
  crossCollateralized: boolean;
  timelineSchedule: {
    periodLabel: string;
    projectedGrossRoyaltiesGBP: number;
    recoupmentDeductionGBP: number;
    remainingBalanceAfterGBP: number;
    participantCashflowGBP: number;
  }[];
}

export class AdvancesEngine {
  public static projectRecoupment(
    advance: AdvanceRecord,
    forecastQuarterlyRoyalties: number[],
    startYear: number = 2026,
    startQuarter: number = 3
  ): AdvanceRecoupmentProjection {
    let currentBalance = advance.remainingBalance;
    const timelineSchedule: AdvanceRecoupmentProjection['timelineSchedule'] = [];
    let projectedQuartersRemaining = 0;
    let projectedRecoupmentQuarter = 'NEVER (Exceeds Horizon)';
    let isFullyRecouped = currentBalance <= 0;

    let y = startYear;
    let q = startQuarter;

    for (let i = 0; i < forecastQuarterlyRoyalties.length; i++) {
      const quarterlyRoyalty = forecastQuarterlyRoyalties[i];
      const periodLabel = `${y}-Q${q}`;

      const recoupAmount = Math.min(quarterlyRoyalty, currentBalance);
      currentBalance = roundCurrency(currentBalance - recoupAmount, 2);
      const participantCash = roundCurrency(quarterlyRoyalty - recoupAmount, 2);

      timelineSchedule.push({
        periodLabel,
        projectedGrossRoyaltiesGBP: quarterlyRoyalty,
        recoupmentDeductionGBP: recoupAmount,
        remainingBalanceAfterGBP: currentBalance,
        participantCashflowGBP: participantCash,
      });

      if (!isFullyRecouped && currentBalance <= 0) {
        isFullyRecouped = true;
        projectedRecoupmentQuarter = periodLabel;
        projectedQuartersRemaining = i + 1;
      }

      q++;
      if (q > 4) {
        q = 1;
        y++;
      }
    }

    const historicalQuarterlyVelocity =
      advance.recoupedToDate > 0 ? roundCurrency(advance.recoupedToDate / 4, 2) : 50000;

    return {
      advanceId: advance.id,
      contractId: advance.contractId,
      participantId: advance.participantId,
      initialAdvanceGBP: advance.initialAmount,
      recoupedToDateGBP: advance.recoupedToDate,
      remainingBalanceGBP: advance.remainingBalance,
      historicalRecoupmentRateQuarterlyGBP: historicalQuarterlyVelocity,
      isFullyRecouped: advance.remainingBalance <= 0,
      projectedRecoupmentQuarter:
        advance.remainingBalance <= 0 ? 'RECOUPED' : projectedRecoupmentQuarter,
      projectedQuartersRemaining:
        advance.remainingBalance <= 0 ? 0 : projectedQuartersRemaining,
      crossCollateralized: advance.crossCollateralized,
      timelineSchedule,
    };
  }
}
