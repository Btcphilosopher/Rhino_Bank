/**
 * RhinoQuant Residuals - Quantitative Financial Test & Verification Suite
 * Includes unit tests, property tests (conservation of money, determinism, ledger immutability),
 * and golden dataset benchmarks.
 */

import {
  Asset,
  AssetType,
  Contract,
  CurrencyCode,
  DeductionType,
  ExclusivityType,
  MediaChannel,
  NormalisedRevenueRecord,
  Participant,
  PaymentFrequency,
  RecoupmentPolicy,
  RuleType,
  TerritoryCode,
} from '../../domain/types';
import { ResidualCalculationEngine } from '../residuals/residualEngine';
import { WaterfallEngine } from '../waterfall/waterfallEngine';
import { ForecastEngine } from '../forecasting/forecastEngine';
import { ValuationEngine } from '../valuation/valuationEngine';
import { MonteCarloEngine } from '../probability/monteCarloEngine';
import { RightsEngine } from '../rights/rightsEngine';
import { roundCurrency } from '../math';

export interface TestResult {
  testId: string;
  category: 'UNIT' | 'PROPERTY' | 'SCENARIO' | 'GOLDEN_DATASET';
  name: string;
  passed: boolean;
  durationMs: number;
  expected: any;
  actual: any;
  details: string;
}

export class ResidualTestSuite {
  public static runAllTests(): {
    totalTests: number;
    passedTests: number;
    failedTests: number;
    totalDurationMs: number;
    results: TestResult[];
  } {
    const startTime = performance.now();
    const results: TestResult[] = [];

    // --- UNIT TESTS ---

    // 1. Fixed Rate Residual Test
    const t1Start = performance.now();
    const mockContractFixed: Contract = {
      id: 'CTR-UNIT-01',
      assetId: 'ASSET-MOCK-01',
      title: 'Fixed Test Contract',
      version: 1,
      effectiveDate: '2025-01-01',
      expiryDate: '2030-12-31',
      autoRenew: true,
      renewalProbabilityPct: 80,
      parties: {
        licensor: 'Rhino Media Corp',
        licensee: 'Global Streamer',
        participants: [{ participantId: 'PART-01', role: 'DIRECTOR', sharePercentage: 1.0 }],
      },
      territories: [TerritoryCode.GLOBAL],
      mediaChannels: [MediaChannel.SVOD],
      platforms: ['Netflix'],
      products: ['Feature Film'],
      rightsGranted: ['RG-01'],
      revenueDefinitions: {
        grossRevenueBasis: 'SVOD Licensing Receipts',
        allowedDeductions: ['10% Distribution Fee'],
        netRevenueFormula: 'Gross - Distribution',
      },
      deductions: [
        {
          id: 'DED-01',
          name: 'Distribution Fee',
          type: DeductionType.DISTRIBUTION_FEE,
          ratePercentage: 0.10,
          isCapped: false,
          priorityOrder: 1,
        },
      ],
      royaltyRules: {
        ruleType: RuleType.FIXED_PERCENTAGE,
        baseRatePercentage: 0.05, // 5% of net
      },
      residualRules: {
        ruleType: RuleType.FIXED_PERCENTAGE,
        formulaName: 'Net Residual Formula',
        ratePercentage: 0.05,
      },
      advances: [],
      guarantees: [],
      recoupmentPolicy: RecoupmentPolicy.SEPARATE_ASSET,
      paymentFrequency: PaymentFrequency.QUARTERLY,
      settlementCurrency: CurrencyCode.GBP,
      taxWithholdingRatePct: 0.20,
      terminationConditions: 'Standard breach clause',
      versionHistory: [],
      status: 'ACTIVE',
    };

    const mockRevenueRecord: NormalisedRevenueRecord = {
      id: 'REV-MOCK-01',
      sourceRecordId: 'SRC-01',
      assetId: 'ASSET-MOCK-01',
      date: '2026-06-30',
      period: '2026-Q2',
      territory: TerritoryCode.GLOBAL,
      platform: 'Netflix',
      channel: MediaChannel.SVOD,
      product: 'Feature Film',
      sourceGross: 1_000_000,
      sourceCurrency: CurrencyCode.GBP,
      fxRateToGBP: 1.0,
      normalizedGrossGBP: 1_000_000,
      units: 0,
      validationStatus: 'VALID',
    };

    const mockParticipant: Participant = {
      id: 'PART-01',
      name: 'Arthur Pendelton',
      legalEntity: 'Pendelton Creative Ltd',
      taxJurisdiction: 'UK',
      taxId: 'GB98234129',
      role: 'DIRECTOR',
      payoutAccountIban: 'GB82RHIN00192837465',
      withholdingTaxPct: 0.20,
      totalEntitlementsGross: 0,
      totalRecoupedDeductions: 0,
      totalPaidToDate: 0,
      currentUnpaidAccrual: 0,
    };

    // Calculation: Gross 1,000,000 -> 10% dist fee (100,000) -> Net 900,000 -> 5% rate = Gross Entitlement 45,000 -> 20% tax (9,000) -> Net Payable = 36,000
    const calcResult1 = ResidualCalculationEngine.calculateResidual({
      revenueRecord: mockRevenueRecord,
      contract: mockContractFixed,
      participant: mockParticipant,
      currentAdvanceBalance: 0,
      cumulativeParticipantRevenueBaseToDate: 0,
    });

    results.push({
      testId: 'TEST-UNIT-01',
      category: 'UNIT',
      name: 'Fixed Percentage Residual Calculation with Distribution Deduction & Tax',
      passed: calcResult1.grossEntitlement === 45000 && calcResult1.netAmountPayable === 36000,
      durationMs: +(performance.now() - t1Start).toFixed(2),
      expected: { grossEntitlement: 45000, netAmountPayable: 36000 },
      actual: { grossEntitlement: calcResult1.grossEntitlement, netAmountPayable: calcResult1.netAmountPayable },
      details: 'Evaluated Gross £1m - 10% Dist = £900k Net × 5% = £45k - 20% tax = £36k exact.',
    });

    // 2. Tiered Escalation Unit Test
    const t2Start = performance.now();
    const mockContractTiered: Contract = {
      ...mockContractFixed,
      id: 'CTR-UNIT-02',
      royaltyRules: {
        ruleType: RuleType.TIERED_PERCENTAGE,
        baseRatePercentage: 0.05,
        tiers: [
          { thresholdMin: 0, thresholdMax: 500_000, ratePercentage: 0.05, description: 'Tier 1: 0 - 500k @ 5%' },
          { thresholdMin: 500_000, thresholdMax: 1_000_000, ratePercentage: 0.08, description: 'Tier 2: 500k - 1M @ 8%' },
          { thresholdMin: 1_000_000, thresholdMax: undefined, ratePercentage: 0.12, description: 'Tier 3: 1M+ @ 12%' },
        ],
      },
    };

    // Revenue base = 800,000 net
    // Tier 1: 500,000 @ 5% = 25,000
    // Tier 2: 300,000 @ 8% = 24,000
    // Total gross entitlement = 49,000
    const mockRevTiered: NormalisedRevenueRecord = {
      ...mockRevenueRecord,
      normalizedGrossGBP: 800_000 / 0.9, // so that after 10% deduction net is exactly 800,000
    };

    const calcResultTiered = ResidualCalculationEngine.calculateResidual({
      revenueRecord: mockRevTiered,
      contract: mockContractTiered,
      participant: { ...mockParticipant, withholdingTaxPct: 0 },
      currentAdvanceBalance: 0,
      cumulativeParticipantRevenueBaseToDate: 0,
    });

    results.push({
      testId: 'TEST-UNIT-02',
      category: 'UNIT',
      name: 'Tiered Escalation Royalty Tiers Execution',
      passed: Math.abs(calcResultTiered.grossEntitlement - 49000) < 0.01,
      durationMs: +(performance.now() - t2Start).toFixed(2),
      expected: 49000,
      actual: calcResultTiered.grossEntitlement,
      details: 'Evaluated 500k @ 5% (£25k) + 300k @ 8% (£24k) = £49,000 exactly.',
    });

    // 3. Advance & Recoupment Offsets Unit Test
    const t3Start = performance.now();
    const calcResultAdvance = ResidualCalculationEngine.calculateResidual({
      revenueRecord: mockRevenueRecord, // generates 45k gross entitlement
      contract: mockContractFixed,
      participant: { ...mockParticipant, withholdingTaxPct: 0 },
      currentAdvanceBalance: 30000, // 30k remaining advance
      cumulativeParticipantRevenueBaseToDate: 0,
    });

    results.push({
      testId: 'TEST-UNIT-03',
      category: 'UNIT',
      name: 'Advance Recoupment Offset & Balance Depletion',
      passed:
        calcResultAdvance.advanceRecoupmentDeduction === 30000 &&
        calcResultAdvance.remainingAdvanceBalanceAfter === 0 &&
        calcResultAdvance.netAmountPayable === 15000,
      durationMs: +(performance.now() - t3Start).toFixed(2),
      expected: { recouped: 30000, remaining: 0, netPayable: 15000 },
      actual: {
        recouped: calcResultAdvance.advanceRecoupmentDeduction,
        remaining: calcResultAdvance.remainingAdvanceBalanceAfter,
        netPayable: calcResultAdvance.netAmountPayable,
      },
      details: 'Advance of £30k offset fully against £45k entitlement, leaving £15k net payable.',
    });

    // --- PROPERTY TESTS ---

    // 4. Property Test: Determinism (100 sequential identical runs yield identical hashes)
    const t4Start = performance.now();
    let isDeterministic = true;
    const baseHash = calcResult1.outputHash;
    for (let i = 0; i < 50; i++) {
      const reRun = ResidualCalculationEngine.calculateResidual({
        revenueRecord: mockRevenueRecord,
        contract: mockContractFixed,
        participant: mockParticipant,
        currentAdvanceBalance: 0,
        cumulativeParticipantRevenueBaseToDate: 0,
      });
      if (reRun.outputHash !== baseHash || reRun.netAmountPayable !== calcResult1.netAmountPayable) {
        isDeterministic = false;
        break;
      }
    }

    results.push({
      testId: 'TEST-PROP-01',
      category: 'PROPERTY',
      name: 'Calculation Determinism & Output Hash Invariance',
      passed: isDeterministic,
      durationMs: +(performance.now() - t4Start).toFixed(2),
      expected: '100% Invariant output hash across 50 iterations',
      actual: isDeterministic ? 'Deterministic' : 'Non-deterministic variance detected',
      details: `Hash invariant: ${baseHash}`,
    });

    // 5. Property Test: Conservation of Money in Participation Waterfall
    const t5Start = performance.now();
    const participantsList: Participant[] = [
      { ...mockParticipant, id: 'PART-A', name: 'Director Pool', withholdingTaxPct: 0 },
      { ...mockParticipant, id: 'PART-B', name: 'Writer Pool', withholdingTaxPct: 0 },
    ];
    const contractWaterfall: Contract = {
      ...mockContractFixed,
      parties: {
        licensor: 'Studio',
        licensee: 'Distributor',
        participants: [
          { participantId: 'PART-A', role: 'DIRECTOR', sharePercentage: 0.6 },
          { participantId: 'PART-B', role: 'WRITER', sharePercentage: 0.4 },
        ],
      },
      royaltyRules: {
        ruleType: RuleType.REVENUE_SHARE,
        baseRatePercentage: 0.20, // 20% of net after 10% dist fee
      },
    };

    const waterfallResult = WaterfallEngine.executeWaterfall(
      contractWaterfall,
      mockRevenueRecord,
      participantsList
    );

    // Gross £1m = Dist fee (£100k) + Off the top (£0) + Producer Net (£720k) + Participant Pool (£180k)
    const sumComponents =
      waterfallResult.totalDistributionFeesGBP +
      waterfallResult.totalOffTheTopExpensesGBP +
      waterfallResult.netProducerShareGBP +
      waterfallResult.totalParticipantPoolGBP;

    const moneyConserved = Math.abs(sumComponents - mockRevenueRecord.normalizedGrossGBP) < 0.01;

    results.push({
      testId: 'TEST-PROP-02',
      category: 'PROPERTY',
      name: 'Conservation of Money Across Participation Waterfall',
      passed: moneyConserved,
      durationMs: +(performance.now() - t5Start).toFixed(2),
      expected: mockRevenueRecord.normalizedGrossGBP,
      actual: roundCurrency(sumComponents, 2),
      details: 'Sum of distribution fees, producer retention, and participant pool equals 100.00% gross.',
    });

    // --- GOLDEN DATASET BENCHMARKS ---

    // 6. Golden Benchmark: Relief-from-Royalty Valuation
    const t6Start = performance.now();
    const mockAsset: Asset = {
      id: 'ASSET-GOLDEN-01',
      title: 'Apex Sound Masters',
      type: AssetType.MUSIC,
      releaseDate: '2021-03-15',
      lifecycleStage: 'CATALOGUE',
      historicalGrossTotal: 12_500_000,
      historicalNetResidualsPaid: 850_000,
      activeContractsCount: 3,
      primaryTerritories: [TerritoryCode.GLOBAL],
      primaryPlatforms: ['Spotify', 'Apple Music'],
      dataQualityScore: 98,
      baseDecayRateAnnualPct: 6.5,
      marketRoyaltyBenchmarkRatePct: 7.5,
      description: 'Golden benchmark asset for relief-from-royalty and DCF calibration.',
      metadata: {},
    };

    const forecast = ForecastEngine.generateForecast(mockAsset, [mockContractFixed], {
      timeHorizonYears: 5,
      discountRateAnnual: 0.10,
    });

    const reliefVal = ValuationEngine.calculateReliefFromRoyalty(mockAsset, forecast, 7.5, 20, 10);
    const goldenPassed = reliefVal.estimatedIPValuationGBP > 0 && reliefVal.annualAvoidedRoyaltyStreamGBP.length === 5;

    results.push({
      testId: 'TEST-GOLDEN-01',
      category: 'GOLDEN_DATASET',
      name: 'Relief-from-Royalty Independent IP Economic Benchmark',
      passed: goldenPassed,
      durationMs: +(performance.now() - t6Start).toFixed(2),
      expected: '5-Year discounted after-tax royalty savings > £0',
      actual: `Calculated IP Value: £${reliefVal.estimatedIPValuationGBP.toLocaleString()}`,
      details: 'Relief-from-royalty module cleanly separated from contractual residual ledger.',
    });

    // 7. Rights Collision Detection Engine
    const t7Start = performance.now();
    const rightsEngine = new RightsEngine([
      {
        id: 'R-01',
        assetId: 'ASSET-COLLISION-01',
        owner: 'Warner UK',
        territory: TerritoryCode.UK,
        medium: MediaChannel.SVOD,
        platform: 'Netflix',
        language: 'EN',
        window: 'First SVOD',
        startDate: '2026-01-01',
        endDate: '2027-12-31',
        exclusivity: ExclusivityType.EXCLUSIVE,
      },
      {
        id: 'R-02',
        assetId: 'ASSET-COLLISION-01',
        owner: 'Sony Pictures UK',
        territory: TerritoryCode.UK,
        medium: MediaChannel.SVOD,
        platform: 'Netflix',
        language: 'EN',
        window: 'First SVOD',
        startDate: '2026-06-01',
        endDate: '2028-06-01',
        exclusivity: ExclusivityType.EXCLUSIVE,
      },
    ]);

    const collisions = rightsEngine.detectCollisions();
    const collisionDetected = collisions.length === 1 && collisions[0].severity === 'FATAL_EXCLUSIVITY_BREACH';

    results.push({
      testId: 'TEST-SCENARIO-01',
      category: 'SCENARIO',
      name: 'Rights Conflict & Exclusivity Collision Detection',
      passed: collisionDetected,
      durationMs: +(performance.now() - t7Start).toFixed(2),
      expected: '1 Fatal Exclusivity Breach detected',
      actual: `${collisions.length} collision(s) detected`,
      details: collisionDetected ? collisions[0].collisionReason : 'Collision undetected',
    });

    // 8. Monte Carlo Percentile Monotonicity Test
    const t8Start = performance.now();
    const mcResult = MonteCarloEngine.runSimulation(500_000, { iterations: 1000, seed: 12345 });
    const p5Y = mcResult.simulatedPercentiles5Y;
    const isMonotonic = p5Y.p10 <= p5Y.p25 && p5Y.p25 <= p5Y.p50 && p5Y.p50 <= p5Y.p75 && p5Y.p75 <= p5Y.p90;

    results.push({
      testId: 'TEST-PROP-03',
      category: 'PROPERTY',
      name: 'Monte Carlo Stochastic Percentile Monotonicity (P10 ≤ P25 ≤ P50 ≤ P75 ≤ P90)',
      passed: isMonotonic,
      durationMs: +(performance.now() - t8Start).toFixed(2),
      expected: 'P10 <= P25 <= P50 <= P75 <= P90',
      actual: `P10: £${p5Y.p10.toLocaleString()} | P50: £${p5Y.p50.toLocaleString()} | P90: £${p5Y.p90.toLocaleString()}`,
      details: 'Strict monotonic ordering verified across empirical distribution quantiles.',
    });

    const totalDuration = +(performance.now() - startTime).toFixed(2);
    const passedTests = results.filter(r => r.passed).length;

    return {
      totalTests: results.length,
      passedTests,
      failedTests: results.length - passedTests,
      totalDurationMs: totalDuration,
      results,
    };
  }
}
