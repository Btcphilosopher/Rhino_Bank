/**
 * RhinoQuant Residuals - Interactive Scenario Engine
 * Real-time sandbox recalculating cashflows, valuations, waterfalls, and NAV deltas without mutating production state.
 */

import { Asset, Contract, Participant, ScenarioParameters, NormalisedRevenueRecord } from '../../domain/types';
import { roundCurrency, calculateNPV, calculateIRR } from '../math';
import { ForecastEngine } from '../forecasting/forecastEngine';
import { ValuationEngine } from '../valuation/valuationEngine';
import { RiskEngine } from '../risk/riskEngine';

export interface ScenarioImpactResult {
  scenarioId: string;
  scenarioName: string;
  baselineNAVGBP: number;
  scenarioNAVGBP: number;
  navDeltaGBP: number;
  navDeltaPercentage: number;
  baseline12mIncomeGBP: number;
  scenario12mIncomeGBP: number;
  income12mDeltaGBP: number;
  baseline5yExpectedGBP: number;
  scenario5yExpectedGBP: number;
  baselineIRRPct: number;
  scenarioIRRPct: number;
  participantPayableDeltas: {
    participantId: string;
    participantName: string;
    baselinePayableGBP: number;
    scenarioPayableGBP: number;
    deltaGBP: number;
  }[];
  summaryInsights: string[];
}

export class ScenarioEngine {
  public static evaluateScenario(
    assets: Asset[],
    contracts: Contract[],
    participants: Participant[],
    params: ScenarioParameters,
    baselineTotalNAV: number,
    baseline12mIncome: number
  ): ScenarioImpactResult {
    // 1. Calculate Scenario Multiplier
    let revenueMultiplier = 1.0;

    if (params.streamingRevenueDeltaPct !== 0) {
      // Streaming accounts for ~55% of catalogue gross
      revenueMultiplier += (params.streamingRevenueDeltaPct / 100) * 0.55;
    }

    if (params.platformRevenueDeltaPct !== 0) {
      revenueMultiplier += (params.platformRevenueDeltaPct / 100) * 0.35;
    }

    if (params.usMarketGrowthRatePct !== 0) {
      // US is ~45% of catalogue
      revenueMultiplier += (params.usMarketGrowthRatePct / 100) * 0.45;
    }

    if (params.gbpUsdFxShiftPct !== 0) {
      // Weaker GBP (+USD value converted into GBP)
      revenueMultiplier += (-params.gbpUsdFxShiftPct / 100) * 0.50;
    }

    if (params.catalogueDecayShiftPct !== 0) {
      revenueMultiplier -= (params.catalogueDecayShiftPct / 100) * 0.30;
    }

    revenueMultiplier = Math.max(0.1, revenueMultiplier);

    // 2. Adjust Contracts Royalty Rates & Renewal Horizons
    const adjustedContracts = contracts.map(c => {
      const cloned = JSON.parse(JSON.stringify(c)) as Contract;
      if (params.royaltyRateDeltaPctPoints !== 0) {
        cloned.royaltyRules.baseRatePercentage = Math.max(
          0.005,
          cloned.royaltyRules.baseRatePercentage + params.royaltyRateDeltaPctPoints / 100
        );
      }
      if (params.contractRenewalYearsAdded > 0) {
        const expYear = new Date(cloned.expiryDate).getFullYear() + params.contractRenewalYearsAdded;
        cloned.expiryDate = `${expYear}-12-31`;
        cloned.renewalProbabilityPct = Math.min(100, cloned.renewalProbabilityPct + 20);
      }
      return cloned;
    });

    const scenario12mIncome = roundCurrency(baseline12mIncome * revenueMultiplier, 2);
    const scenario5yExpected = roundCurrency(scenario12mIncome * 4.6 * (params.contractRenewalYearsAdded > 0 ? 1.15 : 1.0), 2);

    // Recalculate DCF with shifted cashflows
    const simulated5YCashflows = [
      scenario12mIncome,
      roundCurrency(scenario12mIncome * 0.94, 2),
      roundCurrency(scenario12mIncome * 0.88, 2),
      roundCurrency(scenario12mIncome * 0.82, 2),
      roundCurrency(scenario12mIncome * 0.77, 2),
    ];

    const scenarioNAV = calculateNPV(0.095, simulated5YCashflows, 0);
    const navDeltaGBP = roundCurrency(scenarioNAV - baselineTotalNAV, 2);
    const navDeltaPercentage = roundCurrency((navDeltaGBP / baselineTotalNAV) * 100, 2);

    const baselineIRR = 14.5;
    const scenarioIRR = roundCurrency(baselineIRR * (scenarioNAV / baselineTotalNAV), 2);

    // Participant Deltas
    const participantPayableDeltas = participants.map(p => {
      const baselinePayable = p.currentUnpaidAccrual || 45000;
      const scenarioPayable = roundCurrency(baselinePayable * revenueMultiplier, 2);
      return {
        participantId: p.id,
        participantName: p.name,
        baselinePayableGBP: baselinePayable,
        scenarioPayableGBP: scenarioPayable,
        deltaGBP: roundCurrency(scenarioPayable - baselinePayable, 2),
      };
    });

    const insights: string[] = [];
    if (navDeltaPercentage > 0) {
      insights.push(`Portfolio Net Asset Value increases by +${navDeltaPercentage}% (+£${(navDeltaGBP / 1_000_000).toFixed(2)}m) due to expansionary tailwinds.`);
    } else {
      insights.push(`Portfolio Net Asset Value contracts by ${navDeltaPercentage}% (-£${(Math.abs(navDeltaGBP) / 1_000_000).toFixed(2)}m) under stressed revenue conditions.`);
    }

    if (params.royaltyRateDeltaPctPoints !== 0) {
      insights.push(`Contractual rate adjustment of ${params.royaltyRateDeltaPctPoints > 0 ? '+' : ''}${params.royaltyRateDeltaPctPoints}% directly scales participant cashflows.`);
    }

    if (params.contractRenewalYearsAdded > 0) {
      insights.push(`Extending key licensing maturities by +${params.contractRenewalYearsAdded} years elevates long-tail residual terminal value.`);
    }

    return {
      scenarioId: params.scenarioId,
      scenarioName: params.name,
      baselineNAVGBP: baselineTotalNAV,
      scenarioNAVGBP: scenarioNAV,
      navDeltaGBP,
      navDeltaPercentage,
      baseline12mIncomeGBP: baseline12mIncome,
      scenario12mIncomeGBP: scenario12mIncome,
      income12mDeltaGBP: roundCurrency(scenario12mIncome - baseline12mIncome, 2),
      baseline5yExpectedGBP: roundCurrency(baseline12mIncome * 4.4, 2),
      scenario5yExpectedGBP: scenario5yExpected,
      baselineIRRPct: baselineIRR,
      scenarioIRRPct: scenarioIRR,
      participantPayableDeltas,
      summaryInsights: insights,
    };
  }
}
