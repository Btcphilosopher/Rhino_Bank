/**
 * RhinoQuant Residuals - Immutable Calculation Ledger Engine
 * Records cryptographic event state transitions and enforces reproducible accounting immutability.
 */

import { LedgerEntry } from '../../domain/types';
import { generateDeterministicHash } from '../math';

export class LedgerEngine {
  private ledgerEntries: LedgerEntry[] = [];
  private sequenceCounter: number = 1000;

  constructor(initialEntries: LedgerEntry[] = []) {
    this.ledgerEntries = [...initialEntries];
    if (initialEntries.length > 0) {
      this.sequenceCounter = Math.max(...initialEntries.map(e => e.eventSequence)) + 1;
    }
  }

  public recordEvent(entry: Omit<LedgerEntry, 'ledgerId' | 'eventSequence' | 'timestamp' | 'inputHash' | 'outputHash'> & {
    inputPayload?: any;
    outputPayload?: any;
  }): LedgerEntry {
    const sequence = ++this.sequenceCounter;
    const timestamp = new Date().toISOString();
    const ledgerId = `LEDGER-${sequence.toString().padStart(6, '0')}`;

    const inputHash = generateDeterministicHash(entry.inputPayload || { assetId: entry.assetId, event: entry.eventType });
    const outputHash = generateDeterministicHash(entry.outputPayload || { amount: entry.amountGBP, time: timestamp });

    const newEntry: LedgerEntry = {
      ledgerId,
      eventSequence: sequence,
      timestamp,
      eventType: entry.eventType,
      assetId: entry.assetId,
      contractId: entry.contractId,
      calculationId: entry.calculationId,
      participantId: entry.participantId,
      amountGBP: entry.amountGBP,
      inputHash,
      outputHash,
      operator: entry.operator || 'RHINO-QUANT-CORE',
      metadata: entry.metadata || {},
    };

    this.ledgerEntries.push(newEntry);
    return newEntry;
  }

  public getEntries(): LedgerEntry[] {
    return [...this.ledgerEntries];
  }

  public getEntriesForAsset(assetId: string): LedgerEntry[] {
    return this.ledgerEntries.filter(e => e.assetId === assetId);
  }

  public getEntriesForContract(contractId: string): LedgerEntry[] {
    return this.ledgerEntries.filter(e => e.contractId === contractId);
  }

  public verifyLedgerIntegrity(): { isValid: boolean; verifiedCount: number; corruptedCount: number } {
    let verifiedCount = 0;
    let corruptedCount = 0;

    for (let i = 0; i < this.ledgerEntries.length; i++) {
      const entry = this.ledgerEntries[i];
      if (!entry.inputHash || !entry.outputHash || !entry.ledgerId) {
        corruptedCount++;
      } else {
        verifiedCount++;
      }
    }

    return {
      isValid: corruptedCount === 0,
      verifiedCount,
      corruptedCount,
    };
  }
}
