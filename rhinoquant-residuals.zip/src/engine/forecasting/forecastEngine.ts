/**
 * RhinoQuant Residuals - Multi-Horizon Forecasting Engine
 * Models long-tail revenue curves, Weibull decay, catalogue longevity, platform migration, and renewal probabilities.
 */

import { Asset, Contract, ForecastPeriod, ForecastResult } from '../../domain/types';
import { roundCurrency } from '../math';

export interface ForecastOptions {
  timeHorizonYears?: number; // 5, 10, or 20
  discountRateAnnual?: number; // e.g. 0.10 for 10%
  baseDecayRateAnnualPct?: number; // e.g. 0.08
  streamingGrowthModifierPct?: number; // e.g. 0.05
  territoryExpansionBonusPct?: number; // e.g. 0.03
  contractRenewalProbOverride?: number;
  curveType?: 'WEIBULL' | 'EXPONENTIAL' | 'POWER_LAW' | 'S_CURVE';
}

export class ForecastEngine {
  /**
   * Generates deterministic multi-curve forecast for an individual asset or an aggregated portfolio.
   */
  public static generateForecast(
    asset: Asset,
    activeContracts: Contract[],
    options: ForecastOptions = {}
  ): ForecastResult {
    const {
      timeHorizonYears = 10,
      discountRateAnnual = 0.095,
      baseDecayRateAnnualPct = asset.baseDecayRateAnnualPct / 100 || 0.085,
      streamingGrowthModifierPct = 0.04,
      territoryExpansionBonusPct = 0.02,
      curveType = 'WEIBULL',
    } = options;

    const periods: ForecastPeriod[] = [];
    const baseFirstYearGross = asset.historicalGrossTotal > 0 ? asset.historicalGrossTotal * 0.22 : 2_500_000;
    const baseResidualRate = 0.065; // ~6.5% blended participant residual yield

    let totalBase = 0;
    let totalUpside = 0;
    let totalDownside = 0;
    let totalStress = 0;

    for (let t = 1; t <= timeHorizonYears; t++) {
      // Decay factor modeling: Weibull curve S(t) = exp(-(t/alpha)^beta)
      let decayFactor = 1.0;
      if (curveType === 'WEIBULL') {
        const alpha = 8.5; // Scale parameter
        const beta = 1.15; // Shape parameter
        decayFactor = Math.exp(-Math.pow(t / alpha, beta));
      } else if (curveType === 'EXPONENTIAL') {
        decayFactor = Math.exp(-baseDecayRateAnnualPct * (t - 1));
      } else if (curveType === 'POWER_LAW') {
        decayFactor = Math.pow(t, -0.65);
      } else {
        decayFactor = 1 / (1 + Math.exp(0.4 * (t - 6)));
      }

      // Check contract expiry drag
      const contractsActiveInYear = activeContracts.filter(c => {
        const expiryYear = new Date(c.expiryDate).getFullYear();
        const currentYear = 2026 + t;
        if (currentYear <= expiryYear) return true;
        // Auto-renew with probability
        return c.autoRenew && (c.renewalProbabilityPct / 100) > 0.4;
      }).length;

      const contractActiveRatio = activeContracts.length > 0 ? Math.max(0.2, contractsActiveInYear / activeContracts.length) : 1.0;

      // Base stream calculation
      const grossRevYearBase = baseFirstYearGross * decayFactor * (1 + (streamingGrowthModifierPct + territoryExpansionBonusPct) * (1 / t));
      const residualBase = grossRevYearBase * baseResidualRate * contractActiveRatio;

      // Upside scenario: Higher digital adoption, successful syndication (+35% drift, -3% decay)
      const residualUpside = residualBase * (1.25 + 0.03 * t);

      // Downside scenario: Faster churn, cord-cutting (-28% drift, +4% decay)
      const residualDownside = residualBase * Math.max(0.15, 0.78 - 0.02 * t);

      // Stress scenario: Major platform shutdown, dispute (-55% shock)
      const residualStress = residualBase * Math.max(0.05, 0.45 - 0.03 * t);

      const discountFactor = Math.pow(1 + discountRateAnnual, t);
      const discountedBase = residualBase / discountFactor;

      totalBase += residualBase;
      totalUpside += residualUpside;
      totalDownside += residualDownside;
      totalStress += residualStress;

      periods.push({
        periodLabel: `Year ${t} (${2026 + t})`,
        periodIndex: t,
        baseRevenueGBP: roundCurrency(grossRevYearBase, 2),
        baseResidualIncomeGBP: roundCurrency(residualBase, 2),
        upsideResidualIncomeGBP: roundCurrency(residualUpside, 2),
        downsideResidualIncomeGBP: roundCurrency(residualDownside, 2),
        stressResidualIncomeGBP: roundCurrency(residualStress, 2),
        discountFactor: roundCurrency(discountFactor, 4),
        discountedBaseIncomeGBP: roundCurrency(discountedBase, 2),
        activeContractsCount: contractsActiveInYear,
      });
    }

    return {
      assetId: asset.id,
      timeHorizonYears,
      forecastPeriods: periods,
      totalExpectedResidualBaseGBP: roundCurrency(totalBase, 2),
      totalExpectedResidualUpsideGBP: roundCurrency(totalUpside, 2),
      totalExpectedResidualDownsideGBP: roundCurrency(totalDownside, 2),
      totalExpectedResidualStressGBP: roundCurrency(totalStress, 2),
      decayCurveType: curveType,
      annualDecayRatePct: roundCurrency(baseDecayRateAnnualPct * 100, 2),
      growthDriverPcts: {
        streamingGrowth: roundCurrency(streamingGrowthModifierPct * 100, 2),
        territorialExpansion: roundCurrency(territoryExpansionBonusPct * 100, 2),
      },
    };
  }
}
