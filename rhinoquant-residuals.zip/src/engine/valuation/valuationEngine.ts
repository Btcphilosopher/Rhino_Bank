/**
 * RhinoQuant Residuals - Valuation & Relief-from-Royalty IP Valuation Engine
 * Institutional discounted cash flow (DCF), yield metrics, duration, sensitivity matrices, and relief-from-royalty methodology.
 */

import { Asset, ForecastResult, ValuationMetrics, ReliefFromRoyaltyValuation } from '../../domain/types';
import {
  roundCurrency,
  calculateNPV,
  calculateIRR,
  calculateDuration,
  calculatePaybackPeriod,
} from '../math';

export interface ValuationParameters {
  discountRateAnnualPct: number; // e.g. 9.5%
  taxRatePct?: number; // e.g. 21%
  terminalGrowthRatePct?: number; // e.g. 1.5%
  initialAcquisitionCostGBP?: number;
}

export class ValuationEngine {
  /**
   * Discounted Cash Flow (DCF) residual valuation
   */
  public static calculateValuation(
    targetId: string,
    forecast: ForecastResult,
    params: ValuationParameters
  ): ValuationMetrics {
    const discountRate = params.discountRateAnnualPct / 100;
    const cashflows = forecast.forecastPeriods.map(p => p.baseResidualIncomeGBP);
    const initialCost = params.initialAcquisitionCostGBP || (cashflows[0] ? cashflows[0] * 3.8 : 1_000_000);

    const npv = calculateNPV(discountRate, cashflows, 0);
    const irr = calculateIRR(cashflows, initialCost, 0.14);
    const { macaulayDuration, modifiedDuration } = calculateDuration(cashflows, discountRate);
    const paybackPeriod = calculatePaybackPeriod(cashflows, initialCost);

    // Terminal Value Gordon Growth Model
    const lastCF = cashflows[cashflows.length - 1] || 0;
    const g = (params.terminalGrowthRatePct || 0.01) / 100;
    const terminalValue = discountRate > g ? roundCurrency((lastCF * (1 + g)) / (discountRate - g), 2) : 0;

    const totalIncome = cashflows.reduce((a, b) => a + b, 0);
    const cashFlowYield = npv > 0 ? roundCurrency((cashflows[0] / npv) * 100, 2) : 0;

    // 2D Sensitivity Grid: Discount Rates [6%, 8%, 10%, 12%, 14%, 16%] vs Decay Shifts [-5%, 0%, +5%, +10%]
    const sensitivityMatrix: ValuationMetrics['sensitivityMatrix'] = [];
    const discountGrid = [0.06, 0.08, 0.10, 0.12, 0.14, 0.16];
    const decayGrid = [-0.05, 0.0, 0.05, 0.10];

    for (const dRate of discountGrid) {
      for (const dDecay of decayGrid) {
        const adjustedCashflows = cashflows.map((cf, idx) => cf * Math.pow(1 - dDecay, idx));
        const val = calculateNPV(dRate, adjustedCashflows, 0);
        sensitivityMatrix.push({
          discountRate: roundCurrency(dRate * 100, 1),
          decayRate: roundCurrency(dDecay * 100, 1),
          calculatedNPV: val,
        });
      }
    }

    return {
      targetId,
      valuationDate: '2026-09-11',
      discountRatePct: params.discountRateAnnualPct,
      npvGBP: npv,
      irrPct: roundCurrency(irr * 100, 2),
      macaulayDurationYears: macaulayDuration,
      modifiedDurationYears: modifiedDuration,
      paybackPeriodYears: paybackPeriod,
      cashFlowYieldPct: cashFlowYield,
      terminalValueGBP: terminalValue,
      reliefFromRoyaltyValueGBP: 0, // Populated via relief method
      sensitivityMatrix,
    };
  }

  /**
   * Relief-from-Royalty Intellectual Property Valuation Module
   * Formula:
   * Forecast Gross Revenue × Assumed Market Royalty Rate = Avoided Royalty Stream
   * Avoided Royalty Stream − Taxes / Adjustments = After-Tax Royalty Savings
   * Discount After-Tax Savings = Estimated IP Value
   */
  public static calculateReliefFromRoyalty(
    asset: Asset,
    forecast: ForecastResult,
    assumedMarketRoyaltyRatePct?: number,
    taxRatePct: number = 22,
    discountRatePct: number = 10.5
  ): ReliefFromRoyaltyValuation {
    const marketRoyaltyRate = (assumedMarketRoyaltyRatePct || asset.marketRoyaltyBenchmarkRatePct || 7.5) / 100;
    const taxRate = taxRatePct / 100;
    const discountRate = discountRatePct / 100;

    const annualGrossRevenues = forecast.forecastPeriods.map(p => p.baseRevenueGBP);
    const avoidedRoyaltyStream: number[] = [];
    const afterTaxSavings: number[] = [];

    let discountedIPValue = 0;

    for (let t = 0; t < annualGrossRevenues.length; t++) {
      const grossRev = annualGrossRevenues[t];
      const avoidedRoyalty = roundCurrency(grossRev * marketRoyaltyRate, 2);
      const afterTax = roundCurrency(avoidedRoyalty * (1 - taxRate), 2);

      avoidedRoyaltyStream.push(avoidedRoyalty);
      afterTaxSavings.push(afterTax);

      const period = t + 1;
      discountedIPValue += afterTax / Math.pow(1 + discountRate, period);
    }

    const fiveYearRevenue = annualGrossRevenues.slice(0, 5).reduce((a, b) => a + b, 0);
    const tenYearRevenue = annualGrossRevenues.reduce((a, b) => a + b, 0);

    return {
      assetId: asset.id,
      valuationDate: '2026-09-11',
      fiveYearForecastRevenueGBP: roundCurrency(fiveYearRevenue, 2),
      tenYearForecastRevenueGBP: roundCurrency(tenYearRevenue, 2),
      assumedMarketRoyaltyRatePct: roundCurrency(marketRoyaltyRate * 100, 2),
      annualAvoidedRoyaltyStreamGBP: avoidedRoyaltyStream,
      taxAdjustmentRatePct: roundCurrency(taxRate * 100, 2),
      annualAfterTaxSavingsGBP: afterTaxSavings,
      discountRatePct,
      estimatedIPValuationGBP: roundCurrency(discountedIPValue, 2),
      benchmarkComparables: [
        {
          peerName: 'Apex Licensing Index',
          industrySector: asset.type,
          observedRoyaltyRange: '6.0% - 9.5%',
          licenseStructure: 'Net Gross SVOD / Syndication Worldwide',
        },
        {
          peerName: 'Global Media Benchmark',
          industrySector: 'Enterprise / Master Rights',
          observedRoyaltyRange: '5.5% - 8.0%',
          licenseStructure: 'Quarterly with Minimum Guarantee',
        },
      ],
    };
  }
}
