/**
 * RhinoQuant Residuals - Financial Mathematics & Exact Arithmetic Utilities
 * Deterministic financial calculations, numerical solvers, and cryptographic hashing.
 */

// Precise Banker's Rounding to specified decimal places
export function roundCurrency(value: number, decimals: number = 2): number {
  if (isNaN(value) || !isFinite(value)) return 0;
  const factor = Math.pow(10, decimals);
  const n = +(value * factor).toFixed(8);
  const i = Math.floor(n);
  const f = n - i;
  const e = 1e-8;
  const r = (f > 0.5 - e && f < 0.5 + e) ? ((i % 2 === 0) ? i : i + 1) : Math.round(n);
  return r / factor;
}

// Fixed-point exact representation
export function formatGBP(amount: number, compact: boolean = false): string {
  if (isNaN(amount)) return '£0.00';
  if (compact) {
    if (Math.abs(amount) >= 1_000_000_000) {
      return `£${(amount / 1_000_000_000).toFixed(1)}B`;
    }
    if (Math.abs(amount) >= 1_000_000) {
      return `£${(amount / 1_000_000).toFixed(1)}m`;
    }
    if (Math.abs(amount) >= 1_000) {
      return `£${(amount / 1_000).toFixed(1)}k`;
    }
  }
  return new Intl.NumberFormat('en-GB', {
    style: 'currency',
    currency: 'GBP',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function formatPct(rate: number, decimals: number = 2): string {
  if (isNaN(rate)) return '0.00%';
  return `${(rate * 100).toFixed(decimals)}%`;
}

// Deterministic FNV-1a 64-bit Hex Hash for verifiable calculation audit trails
export function generateDeterministicHash(input: any): string {
  const str = typeof input === 'string' ? input : JSON.stringify(input);
  let h1 = 0xdeadbeef;
  let h2 = 0x41c6ce57;
  for (let i = 0; i < str.length; i++) {
    const ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507);
  h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507);
  h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  const hashVal = 4294967296 * (2097151 & h2) + (h1 >>> 0);
  return '0x' + hashVal.toString(16).padStart(14, '0').toUpperCase();
}

// Net Present Value (NPV)
export function calculateNPV(discountRateAnnual: number, annualCashflows: number[], initialOutlay: number = 0): number {
  let npv = -initialOutlay;
  for (let t = 0; t < annualCashflows.length; t++) {
    const period = t + 1;
    const discountFactor = Math.pow(1 + discountRateAnnual, period);
    npv += annualCashflows[t] / discountFactor;
  }
  return roundCurrency(npv, 2);
}

// Internal Rate of Return (IRR) using bounded Newton-Raphson
export function calculateIRR(cashflows: number[], initialOutflow: number, guess: number = 0.12): number {
  let rate = guess;
  const maxIterations = 100;
  const tolerance = 1e-6;

  for (let iter = 0; iter < maxIterations; iter++) {
    let fValue = -initialOutflow;
    let fDerivative = 0;

    for (let t = 0; t < cashflows.length; t++) {
      const period = t + 1;
      const denom = Math.pow(1 + rate, period);
      fValue += cashflows[t] / denom;
      fDerivative -= (period * cashflows[t]) / (denom * (1 + rate));
    }

    if (Math.abs(fValue) < tolerance) {
      return roundCurrency(rate, 4);
    }

    if (Math.abs(fDerivative) < 1e-12) {
      break;
    }

    const nextRate = rate - fValue / fDerivative;
    if (isNaN(nextRate) || nextRate < -0.99 || nextRate > 10.0) {
      // Out of bounds, fall back to bisection or clamped value
      break;
    }
    rate = nextRate;
  }

  return Math.max(0.01, Math.min(0.99, roundCurrency(rate, 4)));
}

// Macaulay & Modified Duration
export function calculateDuration(annualCashflows: number[], discountRateAnnual: number): {
  macaulayDuration: number;
  modifiedDuration: number;
} {
  let weightedTimePV = 0;
  let totalPV = 0;

  for (let t = 0; t < annualCashflows.length; t++) {
    const period = t + 1;
    const pv = annualCashflows[t] / Math.pow(1 + discountRateAnnual, period);
    weightedTimePV += period * pv;
    totalPV += pv;
  }

  if (totalPV <= 0) return { macaulayDuration: 0, modifiedDuration: 0 };

  const macaulayDuration = weightedTimePV / totalPV;
  const modifiedDuration = macaulayDuration / (1 + discountRateAnnual);

  return {
    macaulayDuration: roundCurrency(macaulayDuration, 2),
    modifiedDuration: roundCurrency(modifiedDuration, 2),
  };
}

// Payback Period (years)
export function calculatePaybackPeriod(cashflows: number[], initialInvestment: number): number {
  if (initialInvestment <= 0) return 0;
  let cumulative = 0;
  for (let t = 0; t < cashflows.length; t++) {
    const prev = cumulative;
    cumulative += cashflows[t];
    if (cumulative >= initialInvestment) {
      const needed = initialInvestment - prev;
      const fraction = cashflows[t] > 0 ? needed / cashflows[t] : 0;
      return roundCurrency(t + fraction, 2);
    }
  }
  return roundCurrency(cashflows.length, 2);
}

// Herfindahl-Hirschman Index (HHI) for concentration (0 to 10,000)
export function calculateHHI(sharesPct: number[]): number {
  const sum = sharesPct.reduce((acc, s) => acc + s, 0);
  if (sum === 0) return 0;
  // Normalized shares
  const normalized = sharesPct.map(s => (s / sum) * 100);
  const hhi = normalized.reduce((acc, s) => acc + Math.pow(s, 2), 0);
  return roundCurrency(hhi, 1);
}

// Seedable Deterministic Pseudo-Random Number Generator (Mulberry32)
export function createSeededRNG(seed: number = 42) {
  let s = seed >>> 0;
  return function next(): number {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Box-Muller standard normal transform
export function sampleStandardNormal(rng: () => number): number {
  let u = 0, v = 0;
  while (u === 0) u = rng();
  while (v === 0) v = rng();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}
