/**
 * RhinoQuant Residuals - Deterministic Residual & Royalty Calculation Rules Engine
 * Implements machine-readable contract execution, tiered waterfalls, recoupment, and cryptographic verification.
 */

import {
  Contract,
  NormalisedRevenueRecord,
  Participant,
  CalculationAuditTrail,
  RuleType,
  DeductionType,
} from '../../domain/types';
import { roundCurrency, generateDeterministicHash } from '../math';
import { evaluateDeductions } from '../deductions/deductionsEngine';

export interface CalculationInput {
  revenueRecord: NormalisedRevenueRecord;
  contract: Contract;
  participant: Participant;
  currentAdvanceBalance: number;
  cumulativeParticipantRevenueBaseToDate: number;
  calculationVersion?: string;
  adjustmentAmount?: number;
}

export class ResidualCalculationEngine {
  private static readonly CURRENT_ENGINE_VERSION = 'v2.4.0-PROD-DETERMINISTIC';

  /**
   * Deterministically calculates participant residual entitlement and net payable amount.
   * Produces an immutable, mathematically verifiable calculation audit record.
   */
  public static calculateResidual(input: CalculationInput): CalculationAuditTrail {
    const {
      revenueRecord,
      contract,
      participant,
      currentAdvanceBalance,
      cumulativeParticipantRevenueBaseToDate,
      calculationVersion = ResidualCalculationEngine.CURRENT_ENGINE_VERSION,
      adjustmentAmount = 0,
    } = input;

    const grossRevenue = revenueRecord.normalizedGrossGBP;

    // 1. Evaluate Contractual Deductions
    const { evaluatedDeductions, totalDeductionsGBP, netRevenueGBP } = evaluateDeductions(
      revenueRecord,
      contract.deductions
    );

    // 2. Derive Participation Base
    // Gross participation uses gross revenue; Net profit / standard residual uses contractual net
    const isGrossParticipation =
      contract.royaltyRules.ruleType === RuleType.GROSS_PARTICIPATION ||
      contract.residualRules.ruleType === RuleType.GROSS_PARTICIPATION;

    const participationBase = isGrossParticipation ? grossRevenue : netRevenueGBP;

    // Find participant's contractual share percentage in this contract
    const contractParticipantEntry = contract.parties.participants.find(
      p => p.participantId === participant.id
    );
    const participantPoolSharePct = contractParticipantEntry ? contractParticipantEntry.sharePercentage : 1.0;

    // 3. Compute Gross Entitlement based on Rule Type
    let appliedRuleType = contract.royaltyRules.ruleType;
    let appliedRatePct = contract.royaltyRules.baseRatePercentage;
    let grossEntitlement = 0;
    const tierBreakdown: CalculationAuditTrail['tierBreakdown'] = [];
    let formulaExplanation = '';

    const startBase = cumulativeParticipantRevenueBaseToDate;
    const endBase = startBase + participationBase;

    switch (appliedRuleType) {
      case RuleType.FIXED_PERCENTAGE:
      case RuleType.REVENUE_SHARE:
      case RuleType.GROSS_PARTICIPATION:
      case RuleType.NET_PROFIT_PARTICIPATION: {
        appliedRatePct = contract.royaltyRules.baseRatePercentage;
        const totalPoolEntitlement = participationBase * appliedRatePct;
        grossEntitlement = totalPoolEntitlement * participantPoolSharePct;
        formulaExplanation = `Base (£${participationBase.toLocaleString()}) × Rate (${(appliedRatePct * 100).toFixed(2)}%) × Participant Share (${(participantPoolSharePct * 100).toFixed(2)}%)`;
        break;
      }

      case RuleType.TIERED_PERCENTAGE:
      case RuleType.STEP_UP_RATE:
      case RuleType.STEP_DOWN_RATE: {
        const tiers = contract.royaltyRules.tiers || [];
        let remainingBaseToAllocate = participationBase;
        let runningStart = startBase;
        let totalPoolEntitlement = 0;

        for (const tier of tiers) {
          const tierMin = tier.thresholdMin;
          const tierMax = tier.thresholdMax !== undefined ? tier.thresholdMax : Infinity;

          // Check if revenue segment falls within this tier
          if (runningStart >= tierMax) {
            continue; // Already surpassed this tier
          }

          if (runningStart + remainingBaseToAllocate > tierMin) {
            const effectiveStart = Math.max(runningStart, tierMin);
            const effectiveEnd = Math.min(runningStart + remainingBaseToAllocate, tierMax);
            const baseInTier = Math.max(0, effectiveEnd - effectiveStart);

            if (baseInTier > 0) {
              const entitlementInTier = baseInTier * tier.ratePercentage;
              totalPoolEntitlement += entitlementInTier;

              tierBreakdown.push({
                tierMin,
                tierMax: tier.thresholdMax,
                baseSubjectToTier: roundCurrency(baseInTier, 2),
                tierRate: tier.ratePercentage,
                entitlementInTier: roundCurrency(entitlementInTier, 2),
              });

              remainingBaseToAllocate -= baseInTier;
              runningStart += baseInTier;
            }
          }

          if (remainingBaseToAllocate <= 0) break;
        }

        // Effective overall rate
        appliedRatePct = participationBase > 0 ? totalPoolEntitlement / participationBase : contract.royaltyRules.baseRatePercentage;
        grossEntitlement = totalPoolEntitlement * participantPoolSharePct;
        formulaExplanation = `Tiered Escalation across ${tierBreakdown.length} tiers applied to base £${participationBase.toLocaleString()}`;
        break;
      }

      case RuleType.PER_UNIT: {
        const units = revenueRecord.units || revenueRecord.viewsOrStreams || 0;
        const perUnitRate = contract.royaltyRules.perUnitRate || 0.0035; // e.g., £0.0035 per stream
        const poolEntitlement = units * perUnitRate;
        grossEntitlement = poolEntitlement * participantPoolSharePct;
        appliedRatePct = grossRevenue > 0 ? poolEntitlement / grossRevenue : 0;
        formulaExplanation = `Units (${units.toLocaleString()}) × Per-unit Rate (£${perUnitRate.toFixed(4)}) × Share (${(participantPoolSharePct * 100).toFixed(2)}%)`;
        break;
      }

      case RuleType.MINIMUM_GUARANTEE: {
        appliedRatePct = contract.royaltyRules.baseRatePercentage;
        const standardEntitlement = participationBase * appliedRatePct * participantPoolSharePct;
        const minGuarantee = contract.guarantees.find(g => g.type === 'MINIMUM')?.amount || 0;
        grossEntitlement = Math.max(standardEntitlement, minGuarantee);
        formulaExplanation = `MAX(Standard Entitlement £${roundCurrency(standardEntitlement, 2)}, Minimum Guarantee £${minGuarantee.toLocaleString()})`;
        break;
      }

      default: {
        appliedRatePct = contract.royaltyRules.baseRatePercentage || 0.05;
        grossEntitlement = participationBase * appliedRatePct * participantPoolSharePct;
        formulaExplanation = `Standard calculation: £${participationBase.toLocaleString()} × ${(appliedRatePct * 100).toFixed(2)}%`;
      }
    }

    grossEntitlement = roundCurrency(grossEntitlement, 2);

    // 4. Advances & Recoupment Execution
    let advanceRecoupmentDeduction = 0;
    let remainingAdvanceBalanceAfter = currentAdvanceBalance;

    if (currentAdvanceBalance > 0) {
      advanceRecoupmentDeduction = Math.min(grossEntitlement, currentAdvanceBalance);
      advanceRecoupmentDeduction = roundCurrency(advanceRecoupmentDeduction, 2);
      remainingAdvanceBalanceAfter = roundCurrency(currentAdvanceBalance - advanceRecoupmentDeduction, 2);
    }

    const postRecoupmentEntitlement = roundCurrency(grossEntitlement - advanceRecoupmentDeduction, 2);

    // 5. Tax Withholding
    const taxWithholdingRate = participant.withholdingTaxPct || contract.taxWithholdingRatePct || 0;
    const taxWithholdingAmount = roundCurrency(postRecoupmentEntitlement * taxWithholdingRate, 2);

    // 6. Net Amount Payable
    const netAmountPayable = Math.max(
      0,
      roundCurrency(postRecoupmentEntitlement - taxWithholdingAmount + adjustmentAmount, 2)
    );

    // 7. Cryptographic Deterministic Hashing
    const inputPayload = {
      sourceRecordId: revenueRecord.id,
      grossRevenue,
      deductions: evaluatedDeductions,
      contractId: contract.id,
      contractVersion: contract.version,
      participantId: participant.id,
      currentAdvanceBalance,
      cumulativeParticipantRevenueBaseToDate,
      calculationVersion,
    };

    const outputPayload = {
      grossEntitlement,
      advanceRecoupmentDeduction,
      remainingAdvanceBalanceAfter,
      taxWithholdingAmount,
      netAmountPayable,
    };

    const inputHash = generateDeterministicHash(inputPayload);
    const outputHash = generateDeterministicHash(outputPayload);
    const eventId = `EVT-${Math.floor(100000 + Math.random() * 900000)}`;
    const calculationId = `RES-${Math.floor(100000 + Math.random() * 900000)}`;

    return {
      calculationId,
      eventId,
      timestamp: new Date().toISOString(),
      sourceRecordId: revenueRecord.id,
      assetId: contract.assetId,
      contractId: contract.id,
      contractVersion: contract.version,
      calculationVersion,
      participantId: participant.id,
      participantName: participant.name,
      inputHash,
      outputHash,
      grossRevenue,
      deductions: evaluatedDeductions.map(d => ({
        type: d.type as DeductionType,
        name: d.name,
        amount: d.calculatedAmount,
        ratePct: d.ratePercentage,
      })),
      totalDeductions: totalDeductionsGBP,
      contractualNetRevenue: netRevenueGBP,
      recoupableCosts: 0,
      participationBase,
      appliedRuleType,
      appliedRatePct,
      tierBreakdown,
      grossEntitlement,
      advanceRecoupmentDeduction,
      remainingAdvanceBalanceAfter,
      taxWithholdingAmount,
      priorPaymentsOffset: 0,
      adjustments: adjustmentAmount,
      netAmountPayable,
      reproducibleFormulaStr: formulaExplanation,
    };
  }
}
