/**
 * RhinoQuant Residuals - Institutional Participation Waterfall Engine
 * Models multi-tiered waterfall cascades from gross revenue down to participant net disbursements.
 */

import { Contract, NormalisedRevenueRecord, Participant, WaterfallNode } from '../../domain/types';
import { roundCurrency } from '../math';
import { ResidualCalculationEngine } from '../residuals/residualEngine';

export interface WaterfallExecutionResult {
  assetId: string;
  contractId: string;
  reportingPeriod: string;
  nodes: WaterfallNode[];
  grossRevenueGBP: number;
  totalDistributionFeesGBP: number;
  totalOffTheTopExpensesGBP: number;
  totalRecoupmentsGBP: number;
  netProducerShareGBP: number;
  totalParticipantPoolGBP: number;
  totalNetPayableGBP: number;
  unrecoupedCarryForwardGBP: number;
}

export class WaterfallEngine {
  public static executeWaterfall(
    contract: Contract,
    revenueRecord: NormalisedRevenueRecord,
    participants: Participant[],
    advances: Map<string, number> = new Map()
  ): WaterfallExecutionResult {
    const gross = revenueRecord.normalizedGrossGBP;
    const nodes: WaterfallNode[] = [];

    // Level 1: Gross Ingest
    nodes.push({
      level: 1,
      title: 'Gross Revenue Ingestion',
      incomingAmountGBP: gross,
      deductionAmountGBP: 0,
      outgoingAmountGBP: gross,
      participantDistributions: [],
      explanation: `Normalized incoming gross revenue across channel ${revenueRecord.channel} in ${revenueRecord.territory}`,
    });

    // Level 2: Distribution Fees
    const distFeeRule = contract.deductions.find(d => d.type === 'DISTRIBUTION_FEE');
    const distFeeRate = distFeeRule?.ratePercentage || 0.15;
    const distFeeAmount = roundCurrency(gross * distFeeRate, 2);
    const postDistGross = roundCurrency(gross - distFeeAmount, 2);

    nodes.push({
      level: 2,
      title: 'Contractual Distribution Fee',
      incomingAmountGBP: gross,
      deductionAmountGBP: distFeeAmount,
      outgoingAmountGBP: postDistGross,
      participantDistributions: [],
      explanation: `Deducted ${(distFeeRate * 100).toFixed(1)}% distributor overhead fee (£${distFeeAmount.toLocaleString()})`,
    });

    // Level 3: Off-the-Top Costs (Marketing, SAG/WGA Union Residuals, Hosting)
    const otherDeductions = contract.deductions.filter(d => d.type !== 'DISTRIBUTION_FEE');
    let otherDeductionsTotal = 0;
    for (const rule of otherDeductions) {
      if (rule.ratePercentage) {
        otherDeductionsTotal += gross * rule.ratePercentage;
      } else if (rule.fixedAmount) {
        otherDeductionsTotal += rule.fixedAmount;
      }
    }
    otherDeductionsTotal = roundCurrency(otherDeductionsTotal, 2);
    const postDeductionsBase = Math.max(0, roundCurrency(postDistGross - otherDeductionsTotal, 2));

    nodes.push({
      level: 3,
      title: 'Direct Costs & Guild Residuals Reserve',
      incomingAmountGBP: postDistGross,
      deductionAmountGBP: otherDeductionsTotal,
      outgoingAmountGBP: postDeductionsBase,
      participantDistributions: [],
      explanation: `Applied off-the-top guild obligations, infrastructure fees & legal reserves (£${otherDeductionsTotal.toLocaleString()})`,
    });

    // Level 4: Recoupment & Producer Share Split
    const participationPoolPct = contract.royaltyRules.baseRatePercentage || 0.25;
    const participantPoolGross = roundCurrency(postDeductionsBase * participationPoolPct, 2);
    const producerShareGross = roundCurrency(postDeductionsBase - participantPoolGross, 2);

    nodes.push({
      level: 4,
      title: 'Participant Pool Allocation',
      incomingAmountGBP: postDeductionsBase,
      deductionAmountGBP: producerShareGross,
      outgoingAmountGBP: participantPoolGross,
      participantDistributions: [],
      explanation: `Allocated ${(participationPoolPct * 100).toFixed(1)}% to contract participation pool; remainder (£${producerShareGross.toLocaleString()}) retained by Producer / Licensor`,
    });

    // Level 5: Individual Participant Disbursements & Advance Offsets
    let totalNetPayable = 0;
    let totalRecouped = 0;
    let unrecoupedRemainingTotal = 0;
    const participantDistributions: WaterfallNode['participantDistributions'] = [];

    const contractParticipants = contract.parties.participants;

    for (const cp of contractParticipants) {
      const participant = participants.find(p => p.id === cp.participantId);
      const participantName = participant?.name || cp.participantId;
      const sharePct = cp.sharePercentage;
      const participantGrossShare = roundCurrency(participantPoolGross * sharePct, 2);

      const currentAdvance = advances.get(cp.participantId) || 0;
      const recoupAmount = Math.min(participantGrossShare, currentAdvance);
      const afterRecoup = roundCurrency(participantGrossShare - recoupAmount, 2);
      const withholdingRate = participant?.withholdingTaxPct || 0;
      const taxWithheld = roundCurrency(afterRecoup * withholdingRate, 2);
      const netPayable = Math.max(0, roundCurrency(afterRecoup - taxWithheld, 2));

      totalRecouped += recoupAmount;
      totalNetPayable += netPayable;
      unrecoupedRemainingTotal += Math.max(0, currentAdvance - recoupAmount);

      participantDistributions.push({
        participantId: cp.participantId,
        participantName,
        sharePct,
        amountGBP: netPayable,
      });
    }

    nodes.push({
      level: 5,
      title: 'Participant Net Disbursements (Post-Recoupment & Tax)',
      incomingAmountGBP: participantPoolGross,
      deductionAmountGBP: roundCurrency(totalRecouped + (participantPoolGross - totalRecouped - totalNetPayable), 2),
      outgoingAmountGBP: roundCurrency(totalNetPayable, 2),
      participantDistributions,
      explanation: `Disbursed to ${participantDistributions.length} active participants following advance recoupment and jurisdiction tax withholding`,
    });

    return {
      assetId: contract.assetId,
      contractId: contract.id,
      reportingPeriod: revenueRecord.period,
      nodes,
      grossRevenueGBP: gross,
      totalDistributionFeesGBP: distFeeAmount,
      totalOffTheTopExpensesGBP: otherDeductionsTotal,
      totalRecoupmentsGBP: roundCurrency(totalRecouped, 2),
      netProducerShareGBP: producerShareGross,
      totalParticipantPoolGBP: participantPoolGross,
      totalNetPayableGBP: roundCurrency(totalNetPayable, 2),
      unrecoupedCarryForwardGBP: roundCurrency(unrecoupedRemainingTotal, 2),
    };
  }
}
