/**
 * RhinoQuant Residuals - Core Domain Types & Enumerations
 * Institutional-grade quantitative residuals, royalties, participations, and long-tail revenue analytics
 */

export enum AssetType {
  FILM = 'FILM',
  TELEVISION = 'TELEVISION',
  MUSIC = 'MUSIC',
  PUBLISHING = 'PUBLISHING',
  SOFTWARE = 'SOFTWARE',
  LICENSING = 'LICENSING',
  PATENTS = 'PATENTS',
  TRADEMARKS = 'TRADEMARKS',
  CREATOR_AGREEMENTS = 'CREATOR_AGREEMENTS',
  DISTRIBUTION = 'DISTRIBUTION',
  SYNDICATION = 'SYNDICATION',
  STREAMING = 'STREAMING',
  SUBSCRIPTION_BUSINESS = 'SUBSCRIPTION_BUSINESS',
  FRANCHISING = 'FRANCHISING',
  AFFILIATE_ARRANGEMENTS = 'AFFILIATE_ARRANGEMENTS',
}

export enum ExclusivityType {
  EXCLUSIVE = 'EXCLUSIVE',
  NON_EXCLUSIVE = 'NON_EXCLUSIVE',
  CO_EXCLUSIVE = 'CO_EXCLUSIVE',
  SOLE = 'SOLE',
}

export enum TerritoryCode {
  GLOBAL = 'GLOBAL',
  US = 'US',
  UK = 'UK',
  EU = 'EU',
  APAC = 'APAC',
  LATAM = 'LATAM',
  CAN = 'CAN',
  MENA = 'MENA',
  ROW = 'ROW', // Rest of World
}

export enum MediaChannel {
  THEATRICAL = 'THEATRICAL',
  SVOD = 'SVOD', // Subscription VOD
  AVOD = 'AVOD', // Ad-supported VOD
  TVOD = 'TVOD', // Transactional VOD / Electronic Sell-Through
  LINEAR_TV = 'LINEAR_TV',
  PHYSICAL = 'PHYSICAL',
  DIGITAL_DOWNLOAD = 'DIGITAL_DOWNLOAD',
  STREAMING_AUDIO = 'STREAMING_AUDIO',
  MECHANICAL = 'MECHANICAL',
  PERFORMANCE = 'PERFORMANCE',
  SYNDICATION = 'SYNDICATION',
  APP_STORE = 'APP_STORE',
  ENTERPRISE_LICENSE = 'ENTERPRISE_LICENSE',
  SAAS_SUBSCRIPTION = 'SAAS_SUBSCRIPTION',
  FRANCHISE_FEE = 'FRANCHISE_FEE',
  PATENT_ROYALTY = 'PATENT_ROYALTY',
  AFFILIATE_COMMISSION = 'AFFILIATE_COMMISSION',
}

export enum RuleType {
  FIXED_PERCENTAGE = 'FIXED_PERCENTAGE',
  TIERED_PERCENTAGE = 'TIERED_PERCENTAGE',
  PER_UNIT = 'PER_UNIT',
  REVENUE_SHARE = 'REVENUE_SHARE',
  NET_PROFIT_PARTICIPATION = 'NET_PROFIT_PARTICIPATION',
  GROSS_PARTICIPATION = 'GROSS_PARTICIPATION',
  THRESHOLD_BASED = 'THRESHOLD_BASED',
  MINIMUM_GUARANTEE = 'MINIMUM_GUARANTEE',
  MAXIMUM_CAP = 'MAXIMUM_CAP',
  STEP_UP_RATE = 'STEP_UP_RATE',
  STEP_DOWN_RATE = 'STEP_DOWN_RATE',
}

export enum DeductionType {
  DISTRIBUTION_FEE = 'DISTRIBUTION_FEE',
  HOSTING_INFRASTRUCTURE = 'HOSTING_INFRASTRUCTURE',
  MARKETING_OVERHEAD = 'MARKETING_OVERHEAD',
  UNION_RESIDUALS_SAG_WGA = 'UNION_RESIDUALS_SAG_WGA',
  BAD_DEBT_RESERVE = 'BAD_DEBT_RESERVE',
  TAX_WITHHOLDING = 'TAX_WITHHOLDING',
  TRANSACTION_FEES = 'TRANSACTION_FEES',
  OFF_THE_TOP_EXPENSE = 'OFF_THE_TOP_EXPENSE',
  PHYSICAL_MANUFACTURING = 'PHYSICAL_MANUFACTURING',
}

export enum RecoupmentPolicy {
  CROSS_COLLATERALIZED = 'CROSS_COLLATERALIZED',
  SEPARATE_ASSET = 'SEPARATE_ASSET',
  UNRECOUPED_CARRY_FORWARD = 'UNRECOUPED_CARRY_FORWARD',
  TIME_BOUND = 'TIME_BOUND',
}

export enum PaymentFrequency {
  MONTHLY = 'MONTHLY',
  QUARTERLY = 'QUARTERLY',
  SEMI_ANNUAL = 'SEMI_ANNUAL',
  ANNUAL = 'ANNUAL',
}

export enum CurrencyCode {
  GBP = 'GBP',
  USD = 'USD',
  EUR = 'EUR',
  JPY = 'JPY',
  CAD = 'CAD',
  AUD = 'AUD',
}

export interface TierRule {
  thresholdMin: number; // e.g. 0
  thresholdMax?: number; // e.g. 1,000,000 or null for infinity
  ratePercentage: number; // e.g. 0.05 for 5%
  perUnitAmount?: number; // optional per unit fee
  description?: string;
}

export interface ContractDeductionRule {
  id: string;
  name: string;
  type: DeductionType;
  ratePercentage?: number; // e.g. 0.15 for 15% distribution fee
  fixedAmount?: number;
  isCapped: boolean;
  capAmount?: number;
  priorityOrder: number; // 1 = off-the-top, 2 = distribution, etc.
  appliesToChannels?: MediaChannel[];
}

export interface AdvanceRecord {
  id: string;
  contractId: string;
  participantId: string;
  initialAmount: number;
  currency: CurrencyCode;
  paidDate: string;
  recoupedToDate: number;
  remainingBalance: number;
  crossCollateralized: boolean;
  interestRatePct?: number;
  projectedRecoupmentQuarter?: string;
}

export interface GuaranteeRecord {
  id: string;
  type: 'MINIMUM' | 'MAXIMUM';
  period: 'ANNUAL' | 'LIFETIME' | 'QUARTERLY';
  amount: number;
  currency: CurrencyCode;
}

export interface ContractAmendment {
  amendmentId: string;
  effectiveDate: string;
  supersededVersion: number;
  newVersion: number;
  author: string;
  reason: string;
  summaryChanges: string;
  previousRuleSnapshot: any;
  newRuleSnapshot: any;
}

export interface Contract {
  id: string;
  assetId: string;
  title: string;
  version: number;
  effectiveDate: string;
  expiryDate: string;
  autoRenew: boolean;
  renewalProbabilityPct: number;
  parties: {
    licensor: string;
    licensee: string;
    agentOrGuild?: string;
    participants: {
      participantId: string;
      role: string;
      sharePercentage: number;
    }[];
  };
  territories: TerritoryCode[];
  mediaChannels: MediaChannel[];
  platforms: string[]; // e.g., 'Netflix', 'Spotify', 'AWS Marketplace', 'Steam', 'BBC iPlayer'
  products: string[];
  rightsGranted: string[]; // Right IDs
  revenueDefinitions: {
    grossRevenueBasis: string;
    allowedDeductions: string[];
    netRevenueFormula: string;
  };
  deductions: ContractDeductionRule[];
  royaltyRules: {
    ruleType: RuleType;
    baseRatePercentage: number;
    tiers?: TierRule[];
    perUnitRate?: number;
    thresholdAmount?: number;
    stepMultiplier?: number;
  };
  residualRules: {
    ruleType: RuleType;
    formulaName: string;
    ratePercentage: number;
    platformSplitRules?: Record<string, number>;
  };
  advances: AdvanceRecord[];
  guarantees: GuaranteeRecord[];
  recoupmentPolicy: RecoupmentPolicy;
  paymentFrequency: PaymentFrequency;
  settlementCurrency: CurrencyCode;
  taxWithholdingRatePct: number;
  terminationConditions: string;
  versionHistory: ContractAmendment[];
  status: 'ACTIVE' | 'PENDING_RENEWAL' | 'TERMINATED' | 'EXPIRED';
}

export interface Right {
  id: string;
  assetId: string;
  owner: string;
  territory: TerritoryCode;
  medium: MediaChannel;
  platform: string;
  language: string;
  window: string; // e.g., 'First Pay TV', 'Global SVOD 18M Window', 'Linear Syndication'
  startDate: string;
  endDate: string;
  exclusivity: ExclusivityType;
  encumbrances?: string[];
  holdbackDays?: number;
}

export interface Asset {
  id: string;
  title: string;
  type: AssetType;
  releaseDate: string;
  lifecycleStage: 'DEVELOPMENT' | 'LAUNCH' | 'PRIME' | 'CATALOGUE' | 'LONG_TAIL' | 'TERMINAL';
  historicalGrossTotal: number;
  historicalNetResidualsPaid: number;
  activeContractsCount: number;
  primaryTerritories: TerritoryCode[];
  primaryPlatforms: string[];
  dataQualityScore: number; // 0-100%
  baseDecayRateAnnualPct: number; // e.g. 8.5%
  marketRoyaltyBenchmarkRatePct: number; // for Relief-from-Royalty valuation, e.g. 7.5%
  description: string;
  metadata: Record<string, any>;
}

export interface Participant {
  id: string;
  name: string;
  legalEntity: string;
  taxJurisdiction: string;
  taxId: string;
  role: 'PRODUCER' | 'DIRECTOR' | 'WRITER' | 'ACTOR' | 'COMPOSER' | 'IP_HOLDER' | 'DEVELOPER' | 'FRANCHISEE' | 'AFFILIATE';
  payoutAccountIban: string;
  withholdingTaxPct: number;
  totalEntitlementsGross: number;
  totalRecoupedDeductions: number;
  totalPaidToDate: number;
  currentUnpaidAccrual: number;
}

export interface SourceRevenueRecord {
  sourceId: string;
  ingestionTimestamp: string;
  assetId: string;
  reportingPeriod: string; // e.g. '2026-Q1'
  date: string;
  territory: TerritoryCode;
  platform: string;
  channel: MediaChannel;
  product: string;
  grossRevenue: number;
  netRevenue: number;
  currency: CurrencyCode;
  units: number;
  viewsOrStreams?: number;
  downloads?: number;
  subscriptions?: number;
  licenceSales?: number;
  advertisingRevenue?: number;
  distributionRevenue?: number;
  rawSourcePayloadHash: string;
}

export interface NormalisedRevenueRecord {
  id: string;
  sourceRecordId: string;
  assetId: string;
  date: string;
  period: string;
  territory: TerritoryCode;
  platform: string;
  channel: MediaChannel;
  product: string;
  sourceGross: number;
  sourceCurrency: CurrencyCode;
  fxRateToGBP: number;
  normalizedGrossGBP: number;
  units: number;
  viewsOrStreams?: number;
  matchedContractId?: string;
  matchedRightId?: string;
  validationStatus: 'VALID' | 'RIGHTS_COLLISION' | 'UNMATCHED_CONTRACT' | 'CURRENCY_FLAG';
}

export interface CalculationAuditTrail {
  calculationId: string;
  eventId: string;
  timestamp: string;
  sourceRecordId: string;
  assetId: string;
  contractId: string;
  contractVersion: number;
  calculationVersion: string;
  participantId: string;
  participantName: string;
  inputHash: string;
  outputHash: string;
  grossRevenue: number;
  deductions: {
    type: DeductionType;
    name: string;
    amount: number;
    ratePct?: number;
  }[];
  totalDeductions: number;
  contractualNetRevenue: number;
  recoupableCosts: number;
  participationBase: number;
  appliedRuleType: RuleType;
  appliedRatePct: number;
  tierBreakdown?: {
    tierMin: number;
    tierMax?: number;
    baseSubjectToTier: number;
    tierRate: number;
    entitlementInTier: number;
  }[];
  grossEntitlement: number;
  advanceRecoupmentDeduction: number;
  remainingAdvanceBalanceAfter: number;
  taxWithholdingAmount: number;
  priorPaymentsOffset: number;
  adjustments: number;
  netAmountPayable: number;
  reproducibleFormulaStr: string;
}

export interface LedgerEntry {
  ledgerId: string;
  eventSequence: number;
  timestamp: string;
  eventType:
    | 'REVENUE_INGESTED'
    | 'RIGHTS_MATCHED'
    | 'CONTRACT_IDENTIFIED'
    | 'RULE_SELECTED'
    | 'DEDUCTIONS_APPLIED'
    | 'RESIDUAL_CALCULATED'
    | 'ACCRUAL_CREATED'
    | 'PAYMENT_ISSUED'
    | 'SETTLEMENT_CLOSED'
    | 'AMENDMENT_APPLIED';
  assetId: string;
  contractId: string;
  calculationId?: string;
  participantId?: string;
  amountGBP: number;
  inputHash: string;
  outputHash: string;
  operator: string;
  metadata: Record<string, any>;
}

export interface ForecastPeriod {
  periodLabel: string; // e.g., '2026-Q3', 'Year 1', 'Year 5'
  periodIndex: number;
  baseRevenueGBP: number;
  baseResidualIncomeGBP: number;
  upsideResidualIncomeGBP: number;
  downsideResidualIncomeGBP: number;
  stressResidualIncomeGBP: number;
  discountFactor: number;
  discountedBaseIncomeGBP: number;
  activeContractsCount: number;
}

export interface ForecastResult {
  assetId?: string; // or 'PORTFOLIO'
  timeHorizonYears: number; // 5, 10, 20
  forecastPeriods: ForecastPeriod[];
  totalExpectedResidualBaseGBP: number;
  totalExpectedResidualUpsideGBP: number;
  totalExpectedResidualDownsideGBP: number;
  totalExpectedResidualStressGBP: number;
  decayCurveType: 'WEIBULL' | 'EXPONENTIAL' | 'POWER_LAW' | 'S_CURVE';
  annualDecayRatePct: number;
  growthDriverPcts: Record<string, number>;
}

export interface MonteCarloPercentiles {
  p10: number; // Conservative 90% confidence lower bound
  p25: number;
  p50: number; // Median expected
  p75: number;
  p90: number; // Upside 90%
  mean: number;
  stdDev: number;
  min: number;
  max: number;
}

export interface MonteCarloHistogramBin {
  rangeMin: number;
  rangeMax: number;
  count: number;
  percentage: number;
}

export interface MonteCarloSimulationResult {
  simulationId: string;
  iterationsCount: number;
  horizonYears: number;
  simulatedPercentiles5Y: MonteCarloPercentiles;
  simulatedPercentiles10Y: MonteCarloPercentiles;
  histogramBins5Y: MonteCarloHistogramBin[];
  samplePaths: {
    pathId: number;
    annualCashflows: number[];
  }[];
  assumptions: {
    revenueGrowthMean: number;
    revenueVolatility: number;
    streamingGrowthRate: number;
    fxVolatilityGBPUSD: number;
    contractRenewalProbability: number;
    catalogueSurvivalRate: number;
    jumpDiffusionIntensity: number;
  };
}

export interface ValuationMetrics {
  targetId: string; // Asset ID or 'PORTFOLIO'
  valuationDate: string;
  discountRatePct: number;
  npvGBP: number;
  irrPct: number;
  macaulayDurationYears: number;
  modifiedDurationYears: number;
  paybackPeriodYears: number;
  cashFlowYieldPct: number;
  terminalValueGBP: number;
  reliefFromRoyaltyValueGBP: number;
  sensitivityMatrix: {
    discountRate: number;
    decayRate: number;
    calculatedNPV: number;
  }[];
}

export interface ReliefFromRoyaltyValuation {
  assetId: string;
  valuationDate: string;
  fiveYearForecastRevenueGBP: number;
  tenYearForecastRevenueGBP: number;
  assumedMarketRoyaltyRatePct: number;
  annualAvoidedRoyaltyStreamGBP: number[];
  taxAdjustmentRatePct: number;
  annualAfterTaxSavingsGBP: number[];
  discountRatePct: number;
  estimatedIPValuationGBP: number;
  benchmarkComparables: {
    peerName: string;
    industrySector: string;
    observedRoyaltyRange: string;
    licenseStructure: string;
  }[];
}

export interface PortfolioRiskMetrics {
  totalResidualNAVGBP: number;
  expected12mIncomeGBP: number;
  fiveYearExpectedIncomeGBP: number;
  tenYearNPVGBP: number;
  weightedAverageDurationYears: number;
  platformHerfindahlIndex: number; // HHI (0-10,000)
  territoryHerfindahlIndex: number;
  counterpartyHerfindahlIndex: number;
  expiringUnder24MonthsCount: number;
  expiringUnder24MonthsValueGBP: number;
  topRiskFactor: string;
  stressTestResults: {
    scenarioName: string;
    description: string;
    baseNAVGBP: number;
    stressedNAVGBP: number;
    navLossGBP: number;
    navLossPercentage: number;
    impactSeverity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  }[];
}

export interface ScenarioParameters {
  scenarioId: string;
  name: string;
  streamingRevenueDeltaPct: number; // e.g. +100% or -40%
  platformRevenueDeltaPct: number; // e.g. -30%
  contractRenewalYearsAdded: number; // e.g. +5 years
  royaltyRateDeltaPctPoints: number; // e.g. +2.0% (from 5% to 7%)
  usMarketGrowthRatePct: number; // e.g. +12%
  gbpUsdFxShiftPct: number; // e.g. -10% (GBP weakens)
  catalogueDecayShiftPct: number; // e.g. +10% faster decay
  disabledPlatforms?: string[];
  disabledTerritories?: TerritoryCode[];
}

export interface WaterfallNode {
  level: number;
  title: string;
  incomingAmountGBP: number;
  deductionAmountGBP: number;
  outgoingAmountGBP: number;
  participantDistributions: {
    participantId: string;
    participantName: string;
    sharePct: number;
    amountGBP: number;
  }[];
  explanation: string;
}
