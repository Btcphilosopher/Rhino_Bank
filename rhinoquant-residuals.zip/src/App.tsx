import React, { useState, useEffect } from 'react';
import { Navbar, TerminalTab } from './components/Navbar';
import { PortfolioCockpit } from './components/PortfolioCockpit';
import { CalculationTerminal } from './components/CalculationTerminal';
import { RightsRadar } from './components/RightsRadar';
import { ForecastingValuationLab } from './components/ForecastingValuationLab';
import { MonteCarloView } from './components/MonteCarloView';
import { ScenarioSandbox } from './components/ScenarioSandbox';
import { LedgerAuditView } from './components/LedgerAuditView';
import { TestSuiteView } from './components/TestSuiteView';
import { AICopilotDrawer } from './components/AICopilotDrawer';
import { AssetDetailModal } from './components/AssetDetailModal';

import {
  Asset,
  Contract,
  Participant,
  Right,
  NormalisedRevenueRecord,
} from './domain/types';

import {
  SEED_ASSETS,
  SEED_CONTRACTS,
  SEED_PARTICIPANTS,
  SEED_RIGHTS,
  SEED_REVENUE_RECORDS,
} from './data/seedData';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TerminalTab>('PORTFOLIO');
  const [currency, setCurrency] = useState<string>('GBP');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [isCopilotOpen, setIsCopilotOpen] = useState<boolean>(false);

  // Core Data
  const [assets, setAssets] = useState<Asset[]>(SEED_ASSETS);
  const [contracts, setContracts] = useState<Contract[]>(SEED_CONTRACTS);
  const [participants, setParticipants] = useState<Participant[]>(SEED_PARTICIPANTS);
  const [rights, setRights] = useState<Right[]>(SEED_RIGHTS);
  const [revenueRecords, setRevenueRecords] = useState<NormalisedRevenueRecord[]>(SEED_REVENUE_RECORDS);
  const [collisions, setCollisions] = useState<any[]>([]);
  const [portfolioSummary, setPortfolioSummary] = useState<any | null>(null);

  // Selected Asset for Modal
  const [selectedModalAsset, setSelectedModalAsset] = useState<Asset | null>(null);

  const currencySymbol = currency === 'GBP' ? '£' : currency === 'USD' ? '$' : '€';

  useEffect(() => {
    // Fetch initial backend state
    const initData = async () => {
      try {
        const [sumRes, assetsRes, contractsRes, rightsRes, revRes] = await Promise.all([
          fetch('/api/portfolio/summary'),
          fetch('/api/assets'),
          fetch('/api/contracts'),
          fetch('/api/rights'),
          fetch('/api/revenue/records'),
        ]);

        if (sumRes.ok) setPortfolioSummary(await sumRes.json());
        if (assetsRes.ok) setAssets(await assetsRes.json());
        if (contractsRes.ok) setContracts(await contractsRes.json());
        if (rightsRes.ok) {
          const rData = await rightsRes.json();
          setRights(rData.rights);
          setCollisions(rData.collisions);
        }
        if (revRes.ok) setRevenueRecords(await revRes.json());
      } catch (e) {
        console.error('Error initializing data from backend API:', e);
      }
    };

    initData();
  }, []);

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 flex flex-col selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Fixed Terminal Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenCopilot={() => setIsCopilotOpen(true)}
        currency={currency}
        setCurrency={setCurrency}
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
      />

      {/* Main Container Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'PORTFOLIO' && (
          <PortfolioCockpit
            assets={assets}
            contracts={contracts}
            participants={participants}
            summary={portfolioSummary}
            onSelectAsset={asset => setSelectedModalAsset(asset)}
            currencySymbol={currencySymbol}
          />
        )}

        {activeTab === 'CALCULATION' && (
          <CalculationTerminal
            assets={assets}
            contracts={contracts}
            participants={participants}
            revenueRecords={revenueRecords}
            currencySymbol={currencySymbol}
          />
        )}

        {activeTab === 'RIGHTS' && (
          <RightsRadar rights={rights} collisions={collisions} />
        )}

        {activeTab === 'FORECAST_VALUATION' && (
          <ForecastingValuationLab
            assets={assets}
            contracts={contracts}
            currencySymbol={currencySymbol}
          />
        )}

        {activeTab === 'MONTE_CARLO' && (
          <MonteCarloView currencySymbol={currencySymbol} />
        )}

        {activeTab === 'SCENARIO' && (
          <ScenarioSandbox currencySymbol={currencySymbol} />
        )}

        {activeTab === 'LEDGER' && (
          <LedgerAuditView currencySymbol={currencySymbol} />
        )}

        {activeTab === 'TESTS' && (
          <TestSuiteView />
        )}
      </main>

      {/* Institutional Footer Status Bar */}
      <footer className="border-t border-slate-800/80 bg-[#060910] px-4 lg:px-6 py-2.5 text-[11px] font-mono text-slate-500 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span>RhinoQuant Core Engine v2.4.0 Online</span>
          </span>
          <span className="text-slate-600 hidden sm:inline">•</span>
          <span className="hidden sm:inline">SHA-256 Ledger State Verified</span>
          <span className="text-slate-600 hidden md:inline">•</span>
          <span className="hidden md:inline">Precision Fixed-Point IEEE 754 Safe</span>
        </div>

        <div className="flex items-center gap-3 text-slate-400">
          <span>PORT: 3000</span>
          <span>•</span>
          <span>Rhino Bank Quantitative Analytics Desk © 2026</span>
        </div>
      </footer>

      {/* Asset Detail Modal */}
      <AssetDetailModal
        asset={selectedModalAsset}
        contracts={contracts}
        rights={rights}
        onClose={() => setSelectedModalAsset(null)}
        onNavigateToCalc={assetId => {
          setActiveTab('CALCULATION');
        }}
        onNavigateToForecast={assetId => {
          setActiveTab('FORECAST_VALUATION');
        }}
        currencySymbol={currencySymbol}
      />

      {/* AI Copilot Side Drawer */}
      <AICopilotDrawer
        isOpen={isCopilotOpen}
        onClose={() => setIsCopilotOpen(false)}
      />
    </div>
  );
};

export default App;
