import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

// Import our mathematical algorithms and initial data
import {
  INITIAL_ZONES,
  INITIAL_POWER_LINES,
  INITIAL_PARTICIPANTS,
  INITIAL_WEATHER,
  INITIAL_BATTERY_CONFIGS,
  ZONE_DISTANCES,
  calculateSDR,
  calculateCongestionIndex,
  calculateLocalStrikePrice,
  calculateRegionalEnergyScore,
  calculateLocalEnergyIndependence,
  calculateElasticDemand,
  optimiseBatteryDispatch,
  optimizeNetworkFlows,
  runMatchingEngine
} from './src/lib/marketEngine.js';

import {
  RegionalEnergyZone,
  MarketParticipant,
  MarketOrder,
  MatchedTrade,
  PowerFlowLine,
  WeatherForecastState,
  BatteryDispatchConfig,
  AIReport
} from './src/types.js';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// --- IN-MEMORY DATABASE STATE ---
let currentStep = 0;
let simulationTime = '08:00';
let zones: RegionalEnergyZone[] = JSON.parse(JSON.stringify(INITIAL_ZONES));
let participants: MarketParticipant[] = JSON.parse(JSON.stringify(INITIAL_PARTICIPANTS));
let powerLines: PowerFlowLine[] = JSON.parse(JSON.stringify(INITIAL_POWER_LINES));
let weather: WeatherForecastState[] = JSON.parse(JSON.stringify(INITIAL_WEATHER));
let batteryConfigs: BatteryDispatchConfig[] = JSON.parse(JSON.stringify(INITIAL_BATTERY_CONFIGS));

// Global order books & trading logs
let orderBook: MarketOrder[] = [
  {
    id: 'o-1',
    participantId: 'p6',
    participantName: 'Headingley Cooperative Housing',
    participantType: 'domestic_consumer',
    zoneId: 'leeds',
    type: 'buy',
    amountKwh: 1200,
    pricePerKwh: 0.12,
    timestamp: '08:00:00',
    status: 'pending'
  },
  {
    id: 'o-2',
    participantId: 'p3',
    participantName: 'Vale of York Solar Farm',
    participantType: 'solar_farm',
    zoneId: 'north_yorkshire',
    type: 'sell',
    amountKwh: 3500,
    pricePerKwh: 0.06,
    timestamp: '08:00:00',
    status: 'pending'
  },
  {
    id: 'o-3',
    participantId: 'p10',
    participantName: 'Don Valley Steelworks',
    participantType: 'factory',
    zoneId: 'sheffield',
    type: 'buy',
    amountKwh: 5000,
    pricePerKwh: 0.10,
    timestamp: '08:00:00',
    status: 'pending'
  },
  {
    id: 'o-4',
    participantId: 'p12',
    participantName: 'Humber Offshore Wind Array',
    participantType: 'wind_farm',
    zoneId: 'hull',
    type: 'sell',
    amountKwh: 8000,
    pricePerKwh: 0.05,
    timestamp: '08:00:00',
    status: 'pending'
  }
];

let tradesHistory: MatchedTrade[] = [
  {
    id: 't-pre-1',
    buyOrderId: 'ob-99',
    sellOrderId: 'os-99',
    buyerName: 'Leeds City Council Facilities',
    sellerName: 'Nidderdale Wind Coop',
    zoneId: 'leeds',
    amountKwh: 2500,
    pricePerKwh: 0.095,
    transmissionCostPerKwh: 0.009,
    carbonScore: 88,
    timestamp: '07:55:00',
    lossKwh: 56.2
  },
  {
    id: 't-pre-2',
    buyOrderId: 'ob-98',
    sellOrderId: 'os-98',
    buyerName: 'Stray Residential Smart Loop',
    sellerName: 'Swaledale Micro-Hydro Farm',
    zoneId: 'harrogate',
    amountKwh: 1000,
    pricePerKwh: 0.065,
    transmissionCostPerKwh: 0.004,
    carbonScore: 94,
    timestamp: '07:58:00',
    lossKwh: 10.0
  }
];

// Helper to update strike prices, congestion indexes, SDR and energy scores across all zones
function updateMarketEconomics() {
  const weatherIndex = currentStep % weather.length;
  const currentWeather = weather[weatherIndex];

  zones.forEach(zone => {
    // 1. Calculate active demand and generation based on participants in this zone
    let activeDemandMw = zone.baseDemand;
    let activeGenerationMw = zone.baseGeneration;

    // Apply weather multipliers to renewable participants
    participants.forEach(p => {
      if (p.zoneId === zone.id && p.status === 'active') {
        if (p.currentPowerKw < 0) {
          // It's a consumer (drawn as negative kW)
          activeDemandMw += Math.abs(p.currentPowerKw) / 1000;
        } else {
          // It's a generator
          let outputFactor = 1.0;
          if (p.type === 'solar_farm') {
            outputFactor = currentWeather.solarInsolation / 800; // Peak solar output benchmarked at 800 W/m^2
          } else if (p.type === 'wind_farm') {
            // Wind speed curve model
            const speed = currentWeather.windSpeed;
            if (speed < 3) outputFactor = 0; // Cut-in speed
            else if (speed > 25) outputFactor = 0; // Cut-out speed
            else outputFactor = (speed - 3) / 9; // Linear approximation up to rated speed of 12 m/s
          } else if (p.type === 'hydroelectric') {
            outputFactor = 0.8 + (currentWeather.rainfall * 0.15); // Hydro benefits from rainfall
          }
          outputFactor = Math.max(0, Math.min(1.2, outputFactor));
          activeGenerationMw += (p.capacityKw * outputFactor) / 1000;
        }
      }
    });

    // Handle active battery flows
    batteryConfigs.forEach(bc => {
      const p = participants.find(part => part.id === bc.batteryId);
      if (p && p.zoneId === zone.id && p.status === 'active') {
        // Find if battery is charging or discharging
        if (p.currentPowerKw > 0) {
          // Discharging to grid -> acts as generation
          activeGenerationMw += p.currentPowerKw / 1000;
        } else if (p.currentPowerKw < 0) {
          // Charging from grid -> acts as additional demand
          activeDemandMw += Math.abs(p.currentPowerKw) / 1000;
        }
      }
    });

    // Cap values dynamically
    zone.demand = parseFloat(activeDemandMw.toFixed(2));
    zone.generation = parseFloat(activeGenerationMw.toFixed(2));

    // 2. Supply Demand Ratio (SDR)
    const sdr = calculateSDR(zone.generation, zone.demand);

    // 3. Congestion Index (CI)
    // Congestion based on local transmission limits
    zone.congestionIndex = parseFloat(calculateCongestionIndex(zone.demand, zone.transmissionCapacity).toFixed(2));

    // 4. Local Energy Independence (LEI)
    const lei = calculateLocalEnergyIndependence(zone.generation, zone.demand);

    // 5. Strike Price
    // Setup a realistic base generation cost of £0.05 per kWh
    zone.strikePrice = parseFloat(
      calculateLocalStrikePrice(0.05, 0.015, zone.congestionIndex, sdr, zone.renewablePercentage, lei).toFixed(4)
    );

    // 6. Regional Energy Score
    // Stability factor based on congestion (closer to 1.0 index is good, extreme overload or extreme underload lowers score)
    const stabilityFactor = Math.max(0, Math.min(100, 100 - (Math.abs(1.0 - sdr) * 30) - (zone.congestionIndex > 1.0 ? 40 : 0)));
    const calculatedRes = calculateRegionalEnergyScore(
      zone.renewablePercentage,
      Math.min(1.0, lei),
      zone.storage,
      stabilityFactor
    );
    // Bind to zone score (displayed on maps and tables)
    (zone as any).regionalEnergyScore = Math.round(calculatedRes);
  });

  // Calculate optimized power line flows
  const flowResult = optimizeNetworkFlows(zones, powerLines);
  powerLines = flowResult.updatedLines;
}

// --- API ROUTES ---

// Get active platform market state
app.get('/api/market-state', (req, res) => {
  updateMarketEconomics();
  res.json({
    currentStep,
    timestamp: simulationTime,
    zones,
    participants,
    orderBook,
    tradesHistory,
    powerLines,
    weather,
    batteryConfigs
  });
});

// Place a new buy/sell order
app.post('/api/order', (req, res) => {
  const { participantId, type, amountKwh, pricePerKwh } = req.body;

  const p = participants.find(part => part.id === participantId);
  if (!p) {
    return res.status(404).json({ error: 'Market participant not found' });
  }

  const newOrder: MarketOrder = {
    id: `o-${Date.now()}`,
    participantId: p.id,
    participantName: p.name,
    participantType: p.type,
    zoneId: p.zoneId,
    type,
    amountKwh: parseFloat(amountKwh),
    pricePerKwh: parseFloat(pricePerKwh),
    timestamp: simulationTime,
    status: 'pending'
  };

  orderBook.push(newOrder);

  // Trigger continuous matching engine
  const zonePriceLookup: Record<string, number> = {};
  zones.forEach(z => {
    zonePriceLookup[z.id] = z.strikePrice;
  });

  const matchingResult = runMatchingEngine(orderBook, zonePriceLookup);
  
  if (matchingResult.matchedTrades.length > 0) {
    tradesHistory = [...matchingResult.matchedTrades, ...tradesHistory];
  }
  orderBook = matchingResult.remainingOrders;

  updateMarketEconomics();

  res.json({
    message: 'Order received and processed by matching engine successfully',
    newOrder,
    matchedTradesCount: matchingResult.matchedTrades.length,
    activeOrderCount: orderBook.length
  });
});

// Advance Simulation time and state
app.post('/api/simulation/step', (req, res) => {
  currentStep++;
  
  // Advance simulated clock
  const hourNum = (8 + currentStep) % 24;
  const hourStr = hourNum < 10 ? `0${hourNum}:00` : `${hourNum}:00`;
  simulationTime = hourStr;

  // 1. Weather shifts
  const weatherIndex = currentStep % weather.length;
  const currentW = weather[weatherIndex];

  // 2. Battery dispatch automation based on prices
  const avgStrikePrice = zones.reduce((sum, z) => sum + z.strikePrice, 0) / zones.length;

  batteryConfigs.forEach(bc => {
    const zone = zones.find(z => z.id === 'sheffield' || z.id === 'hull'); // locate battery zone
    if (!zone) return;

    const dispatchResult = optimiseBatteryDispatch(bc, zone.storage, zone.strikePrice, avgStrikePrice);
    
    // Find matching battery participant
    const part = participants.find(p => p.id === bc.batteryId);
    if (part) {
      if (dispatchResult.action === 'charge') {
        part.currentPowerKw = -dispatchResult.powerKw; // Charging acts as demand
        // Increase stored capacity
        bc.capacityKwh = Math.min(bc.capacityKwh, bc.capacityKwh + (dispatchResult.powerKw * 0.2)); // 5 min interval step
        zone.storage = Math.min(1.0, zone.storage + 0.05);
      } else if (dispatchResult.action === 'discharge') {
        part.currentPowerKw = dispatchResult.powerKw; // Discharging acts as generation
        zone.storage = Math.max(0.05, zone.storage - 0.05);
      } else {
        part.currentPowerKw = 0;
      }
    }
  });

  // 3. Elastic consumer price feedback loop
  zones.forEach(zone => {
    // Check if price increased significantly relative to baseline, reducing demand
    const baselinePrice = 0.08;
    const priceDelta = zone.strikePrice - baselinePrice;
    if (priceDelta > 0) {
      zone.baseDemand = Math.max(10, calculateElasticDemand(zone.baseDemand, 0.4, priceDelta));
    } else {
      // Elastic recovery when cheap
      zone.baseDemand = Math.min(zone.baseDemand * 1.02, zone.baseDemand + 1);
    }
  });

  // Update overall economics and flow dynamics
  updateMarketEconomics();

  res.json({
    message: `Simulation successfully advanced to hour ${simulationTime}`,
    currentStep,
    timestamp: simulationTime,
    zones,
    powerLines
  });
});

// Reset Simulation state
app.post('/api/simulation/reset', (req, res) => {
  currentStep = 0;
  simulationTime = '08:00';
  zones = JSON.parse(JSON.stringify(INITIAL_ZONES));
  participants = JSON.parse(JSON.stringify(INITIAL_PARTICIPANTS));
  powerLines = JSON.parse(JSON.stringify(INITIAL_POWER_LINES));
  weather = JSON.parse(JSON.stringify(INITIAL_WEATHER));
  batteryConfigs = JSON.parse(JSON.stringify(INITIAL_BATTERY_CONFIGS));
  orderBook = [
    {
      id: 'o-1',
      participantId: 'p6',
      participantName: 'Headingley Cooperative Housing',
      participantType: 'domestic_consumer',
      zoneId: 'leeds',
      type: 'buy',
      amountKwh: 1200,
      pricePerKwh: 0.12,
      timestamp: '08:00:00',
      status: 'pending'
    },
    {
      id: 'o-2',
      participantId: 'p3',
      participantName: 'Vale of York Solar Farm',
      participantType: 'solar_farm',
      zoneId: 'north_yorkshire',
      type: 'sell',
      amountKwh: 3500,
      pricePerKwh: 0.06,
      timestamp: '08:00:00',
      status: 'pending'
    }
  ];
  tradesHistory = [
    {
      id: 't-pre-1',
      buyOrderId: 'ob-99',
      sellOrderId: 'os-99',
      buyerName: 'Leeds City Council Facilities',
      sellerName: 'Nidderdale Wind Coop',
      zoneId: 'leeds',
      amountKwh: 2500,
      pricePerKwh: 0.095,
      transmissionCostPerKwh: 0.009,
      carbonScore: 88,
      timestamp: '07:55:00',
      lossKwh: 56.2
    }
  ];

  updateMarketEconomics();
  res.json({ message: 'Simulation database successfully reset to starting values' });
});

// AI Agent report generation using Gemini API (server-side only)
app.post('/api/ai/report', async (req, res) => {
  try {
    if (!process.env.GEMINI_API_KEY) {
      return res.status(400).json({
        error: 'Gemini API key is not configured. Please set the GEMINI_API_KEY environment variable.'
      });
    }

    const stateSummary = {
      timestamp: simulationTime,
      currentStep,
      zones: zones.map(z => ({
        name: z.name,
        generationMw: z.generation,
        demandMw: z.demand,
        strikePricePerKwh: z.strikePrice,
        congestionIndex: z.congestionIndex,
        carbonIntensity: z.carbonIntensity,
        renewablePercentage: z.renewablePercentage
      })),
      tradesCount: tradesHistory.length,
      weather: weather[currentStep % weather.length]
    };

    const prompt = `You are the Yorkshire Regional Energy Exchange (YREX) AI Agent, a combined group of energy economists, electric grid optimization engineers, and quantitative analysts.

Review the following Yorkshire Smart Grid and Marketplace State:
${JSON.stringify(stateSummary, null, 2)}

Produce a highly professional, institutional-grade market analysis report. You must output a JSON object strictly following the schema specified. No markdown, no wrappers, just direct JSON output.

JSON fields:
1. "title": A descriptive report title reflecting current Yorkshire market conditions.
2. "summary": Executive overview of the grid status (2-3 sentences), highlighting any major supply gaps, surpluses (e.g. North Yorkshire/Hull wind/solar), and carbon performance.
3. "priceForecast": 5-minute to 24-hour regional strike price trends and forecast, specifically warning of price volatility or peak demand spike locations (like Leeds).
4. "congestionAlerts": List of string warnings or alerts for transmission corridors/substations experiencing strain or exceeding safe thermal/transformer capacities (e.g., Leeds-Sheffield link).
5. "batteryDispatchRecommendation": Actionable instructions for Yorkshire battery assets (Meadowhall, Saltend) - whether to charge, discharge, or engage in frequency response/arbitrage.
6. "infrastructureSuggestions": Concrete suggestions for strategic long-term investments in Yorkshire's electricity infrastructure (substations, grid-scale storage, new offshore links).
7. "arbitrageProfitForecast": Short analytical projection of arbitrage spreads and estimated profits (£/MWh) for battery storage operators.
8. "behaviorAnalysis": Assessment of whether any micro-farms or heavy industrial factories are showing unusual or inefficient load/generation patterns.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            summary: { type: Type.STRING },
            priceForecast: { type: Type.STRING },
            congestionAlerts: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            batteryDispatchRecommendation: { type: Type.STRING },
            infrastructureSuggestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            arbitrageProfitForecast: { type: Type.STRING },
            behaviorAnalysis: { type: Type.STRING }
          },
          required: [
            'title',
            'summary',
            'priceForecast',
            'congestionAlerts',
            'batteryDispatchRecommendation',
            'infrastructureSuggestions',
            'arbitrageProfitForecast',
            'behaviorAnalysis'
          ]
        }
      }
    });

    const reportJson = JSON.parse(response.text || '{}');
    res.json(reportJson);
  } catch (error: any) {
    console.error('AI Report generation failed:', error);
    res.status(500).json({
      error: 'Failed to generate AI report due to an upstream engine error',
      details: error.message
    });
  }
});

// --- VITE DEV SERVER AND PRODUCTION SERVING ---
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    console.log('Vite middleware mounted for local development.');
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log('Serving compiled static web assets from production dist folder.');
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Yorkshire Regional Energy Exchange (YREX) active on http://localhost:${PORT}`);
  });
}

startServer();
