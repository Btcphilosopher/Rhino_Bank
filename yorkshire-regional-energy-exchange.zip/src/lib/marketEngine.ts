import { RegionalEnergyZone, MarketParticipant, MarketOrder, MatchedTrade, PowerFlowLine, WeatherForecastState, BatteryDispatchConfig } from '../types';

// Distance matrix between Yorkshire zones (in km)
export const ZONE_DISTANCES: Record<string, Record<string, number>> = {
  north_yorkshire: { north_yorkshire: 0, leeds: 45, sheffield: 90, hull: 85, harrogate: 20, york: 35 },
  leeds: { north_yorkshire: 45, leeds: 0, sheffield: 48, hull: 95, harrogate: 25, york: 38 },
  sheffield: { north_yorkshire: 90, leeds: 48, sheffield: 0, hull: 110, harrogate: 68, york: 75 },
  hull: { north_yorkshire: 85, leeds: 95, sheffield: 110, hull: 0, harrogate: 90, york: 60 },
  harrogate: { north_yorkshire: 20, leeds: 25, sheffield: 68, hull: 90, harrogate: 0, york: 30 },
  york: { north_yorkshire: 35, leeds: 38, sheffield: 75, hull: 60, harrogate: 30, york: 0 }
};

// Default zones of Yorkshire
export const INITIAL_ZONES: RegionalEnergyZone[] = [
  {
    id: 'north_yorkshire',
    name: 'North Yorkshire',
    generation: 45.0,
    storage: 0.65,
    storageCapacity: 80,
    storageCurrent: 52,
    demand: 28.0,
    transmissionCapacity: 60.0,
    distributionLosses: 0.04,
    strikePrice: 0.07,
    congestionIndex: 0.47,
    carbonIntensity: 45,
    renewablePercentage: 85,
    latitude: 54.2,
    longitude: -1.3,
    baseDemand: 25.0,
    baseGeneration: 40.0
  },
  {
    id: 'leeds',
    name: 'Leeds Metro',
    generation: 12.0,
    storage: 0.40,
    storageCapacity: 50,
    storageCurrent: 20,
    demand: 85.0,
    transmissionCapacity: 120.0,
    distributionLosses: 0.06,
    strikePrice: 0.11,
    congestionIndex: 0.71,
    carbonIntensity: 185,
    renewablePercentage: 25,
    latitude: 53.8,
    longitude: -1.55,
    baseDemand: 80.0,
    baseGeneration: 10.0
  },
  {
    id: 'sheffield',
    name: 'Sheffield Industrial',
    generation: 30.0,
    storage: 0.72,
    storageCapacity: 120,
    storageCurrent: 86.4,
    demand: 70.0,
    transmissionCapacity: 90.0,
    distributionLosses: 0.05,
    strikePrice: 0.09,
    congestionIndex: 0.78,
    carbonIntensity: 120,
    renewablePercentage: 45,
    latitude: 53.38,
    longitude: -1.47,
    baseDemand: 65.0,
    baseGeneration: 25.0
  },
  {
    id: 'hull',
    name: 'Hull Port & Wind',
    generation: 65.0,
    storage: 0.55,
    storageCapacity: 100,
    storageCurrent: 55,
    demand: 35.0,
    transmissionCapacity: 80.0,
    distributionLosses: 0.03,
    strikePrice: 0.08,
    congestionIndex: 0.44,
    carbonIntensity: 25,
    renewablePercentage: 92,
    latitude: 53.74,
    longitude: -0.34,
    baseDemand: 32.0,
    baseGeneration: 60.0
  },
  {
    id: 'harrogate',
    name: 'Harrogate Residential',
    generation: 15.0,
    storage: 0.50,
    storageCapacity: 30,
    storageCurrent: 15,
    demand: 22.0,
    transmissionCapacity: 40.0,
    distributionLosses: 0.04,
    strikePrice: 0.06,
    congestionIndex: 0.55,
    carbonIntensity: 65,
    renewablePercentage: 70,
    latitude: 53.99,
    longitude: -1.54,
    baseDemand: 20.0,
    baseGeneration: 12.0
  },
  {
    id: 'york',
    name: 'Historic York',
    generation: 8.0,
    storage: 0.30,
    storageCapacity: 20,
    storageCurrent: 6,
    demand: 25.0,
    transmissionCapacity: 30.0,
    distributionLosses: 0.05,
    strikePrice: 0.10,
    congestionIndex: 0.83,
    carbonIntensity: 140,
    renewablePercentage: 35,
    latitude: 53.96,
    longitude: -1.08,
    baseDemand: 23.0,
    baseGeneration: 7.0
  }
];

export const INITIAL_POWER_LINES: PowerFlowLine[] = [
  { id: 'l1', fromZoneId: 'north_yorkshire', toZoneId: 'harrogate', capacityMw: 30, flowMw: 12, resistanceOhms: 0.12, lossesMw: 0.15 },
  { id: 'l2', fromZoneId: 'north_yorkshire', toZoneId: 'york', capacityMw: 40, flowMw: 18, resistanceOhms: 0.15, lossesMw: 0.35 },
  { id: 'l3', fromZoneId: 'harrogate', toZoneId: 'leeds', capacityMw: 50, flowMw: 24, resistanceOhms: 0.10, lossesMw: 0.42 },
  { id: 'l4', fromZoneId: 'york', toZoneId: 'leeds', capacityMw: 50, flowMw: 15, resistanceOhms: 0.14, lossesMw: 0.28 },
  { id: 'l5', fromZoneId: 'hull', toZoneId: 'york', capacityMw: 60, flowMw: 25, resistanceOhms: 0.18, lossesMw: 0.75 },
  { id: 'l6', fromZoneId: 'leeds', toZoneId: 'sheffield', capacityMw: 80, flowMw: -20, resistanceOhms: 0.08, lossesMw: 0.55 },
  { id: 'l7', fromZoneId: 'hull', toZoneId: 'sheffield', capacityMw: 50, flowMw: 10, resistanceOhms: 0.20, lossesMw: 0.60 }
];

export const INITIAL_PARTICIPANTS: MarketParticipant[] = [
  { id: 'p1', name: 'Swaledale Micro-Hydro Farm', type: 'hydroelectric', zoneId: 'north_yorkshire', capacityKw: 1500, currentPowerKw: 1100, status: 'active' },
  { id: 'p2', name: 'Nidderdale Wind Coop', type: 'wind_farm', zoneId: 'north_yorkshire', capacityKw: 12000, currentPowerKw: 8500, status: 'active' },
  { id: 'p3', name: 'Vale of York Solar Farm', type: 'solar_farm', zoneId: 'north_yorkshire', capacityKw: 25000, currentPowerKw: 18000, status: 'active' },
  { id: 'p4', name: 'Northallerton Dairy Biogas', type: 'biogas', zoneId: 'north_yorkshire', capacityKw: 2500, currentPowerKw: 2100, status: 'active' },
  
  { id: 'p5', name: 'Leeds University Smart Grid V2G', type: 'ev_charger', zoneId: 'leeds', capacityKw: 5000, currentPowerKw: -3200, status: 'active' },
  { id: 'p6', name: 'Headingley Cooperative Housing', type: 'domestic_consumer', zoneId: 'leeds', capacityKw: 8000, currentPowerKw: -6500, status: 'active' },
  { id: 'p7', name: 'Leeds City Council Facilities', type: 'local_authority', zoneId: 'leeds', capacityKw: 12000, currentPowerKw: -9500, status: 'active' },
  { id: 'p8', name: 'Hunslet EV Bus Depot', type: 'ev_charger', zoneId: 'leeds', capacityKw: 10000, currentPowerKw: -4500, status: 'active' },

  { id: 'p9', name: 'Sheffield Forgemasters CHP', type: 'industrial_chp', zoneId: 'sheffield', capacityKw: 15000, currentPowerKw: 11500, status: 'active' },
  { id: 'p10', name: 'Don Valley Steelworks', type: 'factory', zoneId: 'sheffield', capacityKw: 45000, currentPowerKw: -38000, status: 'active' },
  { id: 'p11', name: 'Meadowhall Retail Battery Hub', type: 'battery_storage', zoneId: 'sheffield', capacityKw: 20000, currentPowerKw: 5000, status: 'active' },

  { id: 'p12', name: 'Humber Offshore Wind Array', type: 'wind_farm', zoneId: 'hull', capacityKw: 50000, currentPowerKw: 42000, status: 'active' },
  { id: 'p13', name: 'Hull Port Cargo Operations', type: 'factory', zoneId: 'hull', capacityKw: 25000, currentPowerKw: -18000, status: 'active' },
  { id: 'p14', name: 'Saltend Chemical Grid Storage', type: 'battery_storage', zoneId: 'hull', capacityKw: 30000, currentPowerKw: -12000, status: 'active' },

  { id: 'p15', name: 'Harrogate Spa District Heating', type: 'biogas', zoneId: 'harrogate', capacityKw: 4000, currentPowerKw: 3200, status: 'active' },
  { id: 'p16', name: 'Duchy Estate Solar & Battery', type: 'cooperative', zoneId: 'harrogate', capacityKw: 6000, currentPowerKw: 4100, status: 'active' },
  { id: 'p17', name: 'Stray Residential Smart Loop', type: 'domestic_consumer', zoneId: 'harrogate', capacityKw: 10000, currentPowerKw: -7200, status: 'active' },

  { id: 'p18', name: 'York Minster Solar Canopy', type: 'solar_farm', zoneId: 'york', capacityKw: 2000, currentPowerKw: 1500, status: 'active' },
  { id: 'p19', name: 'Clifton Moor Retail Park CHP', type: 'industrial_chp', zoneId: 'york', capacityKw: 5000, currentPowerKw: 3800, status: 'active' },
  { id: 'p20', name: 'York central Eco-District', type: 'cooperative', zoneId: 'york', capacityKw: 8000, currentPowerKw: -5200, status: 'active' }
];

export const INITIAL_WEATHER: WeatherForecastState[] = [
  { hour: '08:00', solarInsolation: 150, windSpeed: 6.5, temperature: 14, rainfall: 0.1, cloudCover: 40 },
  { hour: '09:00', solarInsolation: 320, windSpeed: 7.2, temperature: 15, rainfall: 0.0, cloudCover: 30 },
  { hour: '10:00', solarInsolation: 510, windSpeed: 8.0, temperature: 16, rainfall: 0.0, cloudCover: 20 },
  { hour: '11:00', solarInsolation: 650, windSpeed: 7.8, temperature: 18, rainfall: 0.0, cloudCover: 15 },
  { hour: '12:00', solarInsolation: 720, windSpeed: 8.5, temperature: 19, rainfall: 0.0, cloudCover: 10 },
  { hour: '13:00', solarInsolation: 680, windSpeed: 9.0, temperature: 20, rainfall: 0.0, cloudCover: 15 },
  { hour: '14:00', solarInsolation: 550, windSpeed: 8.2, temperature: 19, rainfall: 0.2, cloudCover: 35 },
  { hour: '15:00', solarInsolation: 380, windSpeed: 7.5, temperature: 18, rainfall: 0.5, cloudCover: 60 },
  { hour: '16:00', solarInsolation: 220, windSpeed: 6.8, temperature: 17, rainfall: 0.8, cloudCover: 80 },
  { hour: '17:00', solarInsolation: 110, windSpeed: 6.2, temperature: 16, rainfall: 1.2, cloudCover: 90 },
  { hour: '18:00', solarInsolation: 40, windSpeed: 5.5, temperature: 15, rainfall: 1.5, cloudCover: 95 },
  { hour: '19:00', solarInsolation: 0, windSpeed: 5.8, temperature: 14, rainfall: 1.0, cloudCover: 90 },
  { hour: '20:00', solarInsolation: 0, windSpeed: 6.0, temperature: 13, rainfall: 0.5, cloudCover: 85 }
];

export const INITIAL_BATTERY_CONFIGS: BatteryDispatchConfig[] = [
  { batteryId: 'p11', capacityKwh: 20000, maxChargeKw: 5000, maxDischargeKw: 5000, chargeEfficiency: 0.92, dischargeEfficiency: 0.90, degradationCostPerKwh: 0.015, pricingStrategy: 'arbitrage' },
  { batteryId: 'p14', capacityKwh: 30000, maxChargeKw: 8000, maxDischargeKw: 8000, chargeEfficiency: 0.94, dischargeEfficiency: 0.92, degradationCostPerKwh: 0.012, pricingStrategy: 'peak_shaving' }
];

// --- MATHEMATICAL ALGORITHMS IMPLEMENTATION ---

/**
 * 2. Supply Demand Ratio (SDR)
 * SDR = Available Generation / Electricity Demand
 */
export function calculateSDR(generation: number, demand: number): number {
  if (demand <= 0) return 99.0;
  return generation / demand;
}

/**
 * 3. Congestion Index (CI)
 * CI = Current Load / Network Capacity
 */
export function calculateCongestionIndex(currentLoad: number, networkCapacity: number): number {
  if (networkCapacity <= 0) return 2.0;
  return currentLoad / networkCapacity;
}

/**
 * 4. Battery State (SOC)
 * SOC = Current Energy / Maximum Capacity
 */
export function calculateSOC(currentEnergy: number, maxCapacity: number): number {
  if (maxCapacity <= 0) return 0;
  return Math.max(0, Math.min(1.0, currentEnergy / maxCapacity));
}

/**
 * 5. Transmission Loss
 * Loss = Distance × Resistance × Load
 * Inputs are formatted to keep magnitude logical (expressed in MW or kW loss)
 */
export function calculateTransmissionLoss(distanceKm: number, resistanceOhms: number, loadMw: number): number {
  const loadSign = Math.sign(loadMw);
  const absLoad = Math.abs(loadMw);
  // Resistance factor per km, engineering loss model
  const lossFactor = 0.00005 * distanceKm * resistanceOhms;
  const losses = absLoad * absLoad * lossFactor; // I^2 * R equivalent representation
  return Math.min(absLoad * 0.15, losses) * loadSign; // Limit loss to max 15% of flow
}

/**
 * 6. Regional Energy Score (RES)
 * RES = 0.35 * Renewable + 0.25 * Local Supply + 0.20 * Battery + 0.20 * Grid Stability
 * Scale: 0 - 100
 */
export function calculateRegionalEnergyScore(
  renewablePercentage: number, // 0 to 100
  localSupplyRatio: number,     // LEI or similar (0 to 1)
  batterySoc: number,           // 0 to 1
  gridStability: number         // 0 to 100
): number {
  const renewScore = renewablePercentage; // 0-100
  const localScore = Math.min(100, localSupplyRatio * 100); // 0-100
  const battScore = batterySoc * 100; // 0-100
  const stabilityScore = gridStability; // 0-100

  return (0.35 * renewScore) + (0.25 * localScore) + (0.20 * battScore) + (0.20 * stabilityScore);
}

/**
 * 7. Local Energy Independence (LEI)
 * LEI = Local Generation / Local Consumption
 * Target: 1.0
 */
export function calculateLocalEnergyIndependence(generation: number, consumption: number): number {
  if (consumption <= 0) return 1.0;
  return generation / consumption;
}

/**
 * 8. Price Elasticity Engine
 * Demand(t+1) = Demand(t) * exp(-beta * deltaPrice)
 */
export function calculateElasticDemand(currentDemand: number, beta: number, deltaPrice: number): number {
  return currentDemand * Math.exp(-beta * deltaPrice);
}

/**
 * 1. Local Strike Price
 * SP = GC + NC + CC + RM - RG - LGC
 * where:
 * - GC = Generation Cost (dependent on renewable % and baseline source)
 * - NC = Network Cost
 * - CC = Congestion Cost
 * - RM = Reserve Margin Cost
 * - RG = Renewable Generation Credit
 * - LGC = Local Generation Credit
 */
export function calculateLocalStrikePrice(
  baseGenCost: number, // e.g. 0.04 to 0.08 £/kWh
  networkCost: number,  // e.g. 0.015 £/kWh
  congestionIndex: number, // 0 to 2
  sdr: number,         // Supply Demand Ratio
  renewablePercentage: number, // 0 to 100
  lei: number          // Local Energy Independence
): number {
  // 1. Generation Cost (Higher clean energy reduces baseline fuel costs)
  const GC = baseGenCost + (0.02 * (1 - renewablePercentage / 100));

  // 2. Network Cost
  const NC = networkCost;

  // 3. Congestion Cost (exponential with congestion index)
  const CC = congestionIndex > 1.0 ? 0.06 * Math.pow(congestionIndex - 1.0, 1.8) : 0.0;

  // 4. Reserve Margin Cost (high SDR reduces cost, low SDR increases it)
  const RM = sdr < 1.0 ? 0.04 * (1.0 - sdr) : -0.01 * Math.min(2.0, sdr - 1.0);

  // 5. Renewable Generation Credit (up to -£0.015/kWh for 100% renewable)
  const RG = 0.018 * (renewablePercentage / 100);

  // 6. Local Generation Credit (high LEI rewards local trading up to -£0.012/kWh)
  const LGC = 0.012 * Math.min(1.2, lei);

  const rawPrice = GC + NC + CC + RM - RG - LGC;
  
  // Floor at £0.04 and Cap at £0.28 to keep it realistic
  return Math.max(0.04, Math.min(0.28, rawPrice));
}

/**
 * 9. Battery Dispatch Optimiser
 * Maximise Profit = Sell Revenue - Purchase Cost - Battery Degradation
 * Subject to capacity and charge/discharge constraints.
 * Simulates a single-period or continuous market cycle decision.
 */
export function optimiseBatteryDispatch(
  config: BatteryDispatchConfig,
  currentSoc: number,
  localStrikePrice: number,
  averageStrikePrice: number
): { action: 'charge' | 'discharge' | 'idle'; powerKw: number; expectedProfit: number } {
  const availableCapacityKwh = config.capacityKwh * (1.0 - currentSoc);
  const availableEnergyKwh = config.capacityKwh * currentSoc;

  // Set margins for taking action
  const lowPriceThreshold = averageStrikePrice * 0.85; // Buy when price is 15% below average
  const highPriceThreshold = averageStrikePrice * 1.15; // Sell when price is 15% above average

  let action: 'charge' | 'discharge' | 'idle' = 'idle';
  let powerKw = 0;
  let expectedProfit = 0;

  if (config.pricingStrategy === 'arbitrage') {
    if (localStrikePrice < lowPriceThreshold && currentSoc < 0.95) {
      // CHARGE!
      action = 'charge';
      powerKw = Math.min(config.maxChargeKw, availableCapacityKwh * 12); // Assume 5-min dispatch timescale
      const cost = powerKw * (localStrikePrice / config.chargeEfficiency);
      const futureValue = powerKw * averageStrikePrice;
      expectedProfit = futureValue - cost - (powerKw * config.degradationCostPerKwh);
    } else if (localStrikePrice > highPriceThreshold && currentSoc > 0.05) {
      // DISCHARGE!
      action = 'discharge';
      powerKw = Math.min(config.maxDischargeKw, availableEnergyKwh * 12);
      const revenue = powerKw * localStrikePrice * config.dischargeEfficiency;
      const originalCost = powerKw * averageStrikePrice;
      expectedProfit = revenue - originalCost - (powerKw * config.degradationCostPerKwh);
    }
  } else if (config.pricingStrategy === 'peak_shaving') {
    // Peak shaving focuses on discharging during congestion index > 0.8
    if (localStrikePrice > averageStrikePrice * 1.1 && currentSoc > 0.15) {
      action = 'discharge';
      powerKw = config.maxDischargeKw * 0.8;
      const revenue = powerKw * localStrikePrice * config.dischargeEfficiency;
      expectedProfit = revenue - (powerKw * config.degradationCostPerKwh);
    } else if (localStrikePrice < averageStrikePrice * 0.9 && currentSoc < 0.85) {
      action = 'charge';
      powerKw = config.maxChargeKw * 0.7;
    }
  }

  return { action, powerKw, expectedProfit: Math.max(0, expectedProfit) };
}

/**
 * 10. Network Optimisation Routing Model
 * Simple multi-zone power balancer. It routes energy from zones with SDR > 1.0 (surplus)
 * to zones with SDR < 1.0 (shortage) along power lines, minimising losses and congestion costs.
 */
export function optimizeNetworkFlows(
  zones: RegionalEnergyZone[],
  lines: PowerFlowLine[]
): { updatedLines: PowerFlowLine[]; networkLossesMw: number; balanceStatus: string } {
  // Calculate generation and demand across all zones
  const activeLines = [...lines];
  let totalLossesMw = 0;

  // Let's perform a simple linear proportional dispatch:
  // Identify surplus zones and deficit zones
  const surplusZones = zones.filter(z => z.generation > z.demand);
  const deficitZones = zones.filter(z => z.generation < z.demand);

  // Reset line flows first to base allocations
  activeLines.forEach(line => {
    line.flowMw = 0;
    line.lossesMw = 0;
  });

  surplusZones.forEach(sz => {
    let surplus = sz.generation - sz.demand;
    
    // Distribute surplus to deficit zones based on distance/losses
    deficitZones.forEach(dz => {
      if (surplus <= 0) return;
      const deficit = dz.demand - dz.generation;
      if (deficit <= 0) return;

      const flowAmount = Math.min(surplus, deficit, 15.0); // Limit flow per route to avoid transmission bottle-neck
      
      // Find a line connecting sz and dz or general path
      const directLine = activeLines.find(l => 
        (l.fromZoneId === sz.id && l.toZoneId === dz.id) || 
        (l.fromZoneId === dz.id && l.toZoneId === sz.id)
      );

      if (directLine) {
        const direction = directLine.fromZoneId === sz.id ? 1 : -1;
        directLine.flowMw += flowAmount * direction;
        
        // Calculate losses
        const dist = ZONE_DISTANCES[sz.id]?.[dz.id] || 30;
        const lineLoss = Math.abs(calculateTransmissionLoss(dist, directLine.resistanceOhms, directLine.flowMw));
        directLine.lossesMw = lineLoss;
        totalLossesMw += lineLoss;
        
        surplus -= flowAmount;
      }
    });
  });

  // Calculate secondary loops
  activeLines.forEach(line => {
    if (line.flowMw === 0) {
      // Add a small baseline flow simulating grid stabilization
      const dist = ZONE_DISTANCES[line.fromZoneId]?.[line.toZoneId] || 25;
      line.flowMw = Math.floor(Math.sin(Date.now() / 10000) * 5);
      line.lossesMw = Math.abs(calculateTransmissionLoss(dist, line.resistanceOhms, line.flowMw));
      totalLossesMw += line.lossesMw;
    }
  });

  return {
    updatedLines: activeLines,
    networkLossesMw: totalLossesMw,
    balanceStatus: 'Optimal regional balance achieved with minimal distribution loss'
  };
}

/**
 * Continuous Auction Matcher (Matching Engine)
 * Runs a continuous auction to match buyers and sellers.
 * Returns trades and unmatched orders.
 */
export function runMatchingEngine(
  pendingOrders: MarketOrder[],
  zonePriceLookup: Record<string, number>
): { matchedTrades: MatchedTrade[]; remainingOrders: MarketOrder[] } {
  const buyOrders = pendingOrders.filter(o => o.type === 'buy' && o.status === 'pending')
    .sort((a, b) => b.pricePerKwh - a.pricePerKwh); // Highest bids first
  const sellOrders = pendingOrders.filter(o => o.type === 'sell' && o.status === 'pending')
    .sort((a, b) => a.pricePerKwh - b.pricePerKwh); // Lowest offers first

  const matchedTrades: MatchedTrade[] = [];
  const unmatchedBuy: MarketOrder[] = [...buyOrders];
  const unmatchedSell: MarketOrder[] = [...sellOrders];

  for (let i = 0; i < unmatchedBuy.length; i++) {
    const buy = unmatchedBuy[i];
    
    for (let j = 0; j < unmatchedSell.length; j++) {
      const sell = unmatchedSell[j];

      // Buyers must offer at least what sellers ask
      if (buy.pricePerKwh >= sell.pricePerKwh) {
        // MATCH FOUND!
        const amount = Math.min(buy.amountKwh, sell.amountKwh);
        const matchPrice = (buy.pricePerKwh + sell.pricePerKwh) / 2; // Split the spread

        // Calculate losses based on transmission distance between zones
        const distance = ZONE_DISTANCES[buy.zoneId]?.[sell.zoneId] || 0;
        const lossFactor = 0.0005 * distance; // 0.05% per km
        const lossKwh = amount * lossFactor;

        // Cost of transport
        const transmissionCost = distance * 0.0002; // £0.0002 per km per kWh
        const carbonScore = Math.max(10, 100 - (distance * 0.8)); // score 10-100 based on keeping energy local

        matchedTrades.push({
          id: `t-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          buyOrderId: buy.id,
          sellOrderId: sell.id,
          buyerName: buy.participantName,
          sellerName: sell.participantName,
          zoneId: buy.zoneId,
          amountKwh: amount,
          pricePerKwh: parseFloat(matchPrice.toFixed(4)),
          transmissionCostPerKwh: parseFloat(transmissionCost.toFixed(4)),
          carbonScore: Math.round(carbonScore),
          timestamp: new Date().toLocaleTimeString(),
          lossKwh: parseFloat(lossKwh.toFixed(2))
        });

        // Deduct quantities
        buy.amountKwh -= amount;
        sell.amountKwh -= amount;

        if (buy.amountKwh <= 0) {
          buy.status = 'matched';
          unmatchedBuy.splice(i, 1);
          i--; // Adjust index
          break;
        }
      }
    }
  }

  // Filter out completed matches
  const remainingOrders = [
    ...unmatchedBuy.filter(o => o.amountKwh > 0),
    ...unmatchedSell.filter(o => o.amountKwh > 0)
  ];

  return { matchedTrades, remainingOrders };
}
