import React, { useState } from 'react';
import { MarketParticipant, MarketOrder, MatchedTrade } from '../types';
import { ShoppingBag, ArrowUpRight, ArrowDownLeft, ShieldCheck, Clock, Layers, Sparkles } from 'lucide-react';

interface OrderBookSectionProps {
  participants: MarketParticipant[];
  orderBook: MarketOrder[];
  tradesHistory: MatchedTrade[];
  onPlaceOrder: (order: { participantId: string; type: 'buy' | 'sell'; amountKwh: number; pricePerKwh: number }) => void;
  selectedZoneId: string | null;
  zonePrices: Record<string, number>;
}

export const OrderBookSection: React.FC<OrderBookSectionProps> = ({
  participants,
  orderBook,
  tradesHistory,
  onPlaceOrder,
  selectedZoneId,
  zonePrices
}) => {
  const [selectedParticipantId, setSelectedParticipantId] = useState(participants[0]?.id || '');
  const [orderType, setOrderType] = useState<'buy' | 'sell'>('buy');
  const [amountKwh, setAmountKwh] = useState<number>(1500);
  const [pricePerKwh, setPricePerKwh] = useState<number>(0.08);

  const selectedParticipant = participants.find(p => p.id === selectedParticipantId);

  // When participant changes, adjust defaults based on type & zone
  const handleParticipantChange = (id: string) => {
    setSelectedParticipantId(id);
    const p = participants.find(part => part.id === id);
    if (p) {
      // If consumer (negative currentPower or type is factory, consumer, EV), default to BUY. Else SELL.
      const isConsumer = p.type === 'factory' || p.type === 'domestic_consumer' || p.type === 'ev_charger' || p.type === 'commercial' || p.type === 'local_authority';
      setOrderType(isConsumer ? 'buy' : 'sell');
      
      const currentZonePrice = zonePrices[p.zoneId] || 0.08;
      setPricePerKwh(parseFloat(currentZonePrice.toFixed(4)));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedParticipantId || amountKwh <= 0 || pricePerKwh <= 0) return;
    onPlaceOrder({
      participantId: selectedParticipantId,
      type: orderType,
      amountKwh,
      pricePerKwh
    });
  };

  // Filter and sort active bids (Buy orders) and asks (Sell orders)
  const bids = orderBook.filter(o => o.type === 'buy').sort((a, b) => b.pricePerKwh - a.pricePerKwh);
  const asks = orderBook.filter(o => o.type === 'sell').sort((a, b) => a.pricePerKwh - b.pricePerKwh);

  // Filter lists based on selected zone if there is one focused
  const filteredBids = selectedZoneId ? bids.filter(o => o.zoneId === selectedZoneId) : bids;
  const filteredAsks = selectedZoneId ? asks.filter(o => o.zoneId === selectedZoneId) : asks;
  const filteredTrades = selectedZoneId ? tradesHistory.filter(t => t.zoneId === selectedZoneId) : tradesHistory;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="yrex-trading-block">
      {/* 1. Order Entry Panel */}
      <div className="lg:col-span-4 bg-[#0F1115] border border-slate-800/80 rounded-xl p-5 shadow-sm">
        <h3 className="text-lg font-bold text-slate-200 flex items-center gap-2 mb-4">
          <ShoppingBag className="h-5 w-5 text-blue-500" />
          Continuous Auction Order Entry
        </h3>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Participant Select */}
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
              Trading Identity (Participant)
            </label>
            <select
              value={selectedParticipantId}
              onChange={(e) => handleParticipantChange(e.target.value)}
              className="w-full bg-[#0A0A0B] border border-slate-800 text-slate-200 text-sm rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-[#070708] outline-none font-medium"
            >
              {participants.map(p => (
                <option key={p.id} value={p.id}>
                  [{p.zoneId.replace('_', ' ').toUpperCase()}] {p.name} ({p.type.replace('_', ' ')})
                </option>
              ))}
            </select>
          </div>

          {/* Action toggle Buy/Sell */}
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Market Action
            </label>
            <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-lg">
              <button
                type="button"
                onClick={() => setOrderType('buy')}
                className={`py-2 text-xs font-bold rounded-md transition-all flex items-center justify-center gap-1 cursor-pointer ${
                  orderType === 'buy'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#0F1115]'
                }`}
              >
                <ArrowDownLeft className="h-4 w-4" />
                BUY (Bid)
              </button>
              <button
                type="button"
                onClick={() => setOrderType('sell')}
                className={`py-2 text-xs font-bold rounded-md transition-all flex items-center justify-center gap-1 cursor-pointer ${
                  orderType === 'sell'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#0F1115]'
                }`}
              >
                <ArrowUpRight className="h-4 w-4" />
                SELL (Offer)
              </button>
            </div>
          </div>

          {/* Inputs */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                Volume (kWh)
              </label>
              <input
                type="number"
                value={amountKwh}
                onChange={(e) => setAmountKwh(Math.max(1, parseInt(e.target.value) || 0))}
                className="w-full bg-[#0A0A0B] border border-slate-800 text-slate-100 text-sm rounded-lg p-2 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-[#070708] outline-none font-mono font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                Price (£ / kWh)
              </label>
              <input
                type="number"
                step="0.0001"
                value={pricePerKwh}
                onChange={(e) => setPricePerKwh(Math.max(0.0001, parseFloat(e.target.value) || 0))}
                className="w-full bg-[#0A0A0B] border border-slate-800 text-slate-100 text-sm rounded-lg p-2 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-[#070708] outline-none font-mono font-bold text-blue-400"
              />
            </div>
          </div>

          {/* Estimated Calculations Summary */}
          {selectedParticipant && (
            <div className="bg-[#0A0A0B] rounded-lg p-3.5 border border-slate-800/60 text-xs text-slate-400 space-y-1">
              <div className="flex justify-between">
                <span>Identity Location:</span>
                <span className="font-bold text-slate-200">{selectedParticipant.zoneId.replace('_', ' ').toUpperCase()}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Value:</span>
                <span className="font-bold font-mono text-slate-200">£{(amountKwh * pricePerKwh).toFixed(2)}</span>
              </div>
              <div className="flex justify-between border-t border-slate-800/80 pt-1.5 mt-1.5">
                <span>Active REZ Price:</span>
                <span className="font-bold text-slate-200 font-mono">£{(zonePrices[selectedParticipant.zoneId] || 0.08).toFixed(4)}/kWh</span>
              </div>
            </div>
          )}

          {/* Submit Action */}
          <button
            type="submit"
            className={`w-full py-2.5 rounded-lg text-sm font-bold text-white shadow-md active:scale-[0.98] transition-all cursor-pointer ${
              orderType === 'buy' 
                ? 'bg-blue-600 hover:bg-blue-500 border border-blue-500/20' 
                : 'bg-emerald-600 hover:bg-emerald-500 border border-emerald-500/20'
            }`}
          >
            Submit Order to Rust Matching Engine
          </button>
        </form>
      </div>

      {/* 2. Order Book (Bids & Asks Grid) */}
      <div className="lg:col-span-4 bg-[#0F1115] border border-slate-800/80 rounded-xl p-5 shadow-sm flex flex-col h-full min-h-[350px]">
        <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider border-b border-slate-800/80 pb-2 mb-3 flex items-center gap-2">
          <Layers className="h-4.5 w-4.5 text-blue-500" />
          YREX Live Bid/Ask Order Book {selectedZoneId && <span className="text-[10px] text-amber-400 normal-case bg-amber-950/50 px-1.5 rounded font-bold border border-amber-900/30">Filtered Zone</span>}
        </h3>

        <div className="grid grid-cols-2 gap-4 flex-grow overflow-hidden font-mono text-xs">
          {/* ASKS (SELLS) - Sorted lowest to highest */}
          <div className="flex flex-col h-full">
            <div className="text-slate-400 font-bold border-b border-slate-800/80 pb-1 mb-1.5 flex justify-between">
              <span>ASK (Offer)</span>
              <span>Qty</span>
            </div>
            <div className="space-y-1 overflow-y-auto max-h-[220px] flex-grow pr-1">
              {filteredAsks.length === 0 ? (
                <div className="text-slate-500 text-[10px] italic py-4 text-center font-sans">No offers active</div>
              ) : (
                filteredAsks.map(ask => (
                  <div key={ask.id} className="flex justify-between items-center bg-emerald-950/30 border border-emerald-900/40 p-1.5 rounded text-emerald-300">
                    <span className="font-bold">£{ask.pricePerKwh.toFixed(4)}</span>
                    <span className="text-[10px] text-emerald-400">{ask.amountKwh.toFixed(0)}</span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* BIDS (BUYS) - Sorted highest to lowest */}
          <div className="flex flex-col h-full">
            <div className="text-slate-400 font-bold border-b border-slate-800/80 pb-1 mb-1.5 flex justify-between">
              <span>BID (Bid)</span>
              <span>Qty</span>
            </div>
            <div className="space-y-1 overflow-y-auto max-h-[220px] flex-grow pr-1">
              {filteredBids.length === 0 ? (
                <div className="text-slate-500 text-[10px] italic py-4 text-center font-sans">No active bids</div>
              ) : (
                filteredBids.map(bid => (
                  <div key={bid.id} className="flex justify-between items-center bg-blue-950/30 border border-blue-900/40 p-1.5 rounded text-blue-300">
                    <span className="font-bold">£{bid.pricePerKwh.toFixed(4)}</span>
                    <span className="text-[10px] text-blue-400">{bid.amountKwh.toFixed(0)}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
        <div className="border-t border-slate-800/80 pt-3 text-[10px] text-slate-500 flex justify-between items-center">
          <span>Continuous Auction Pool</span>
          <span className="font-bold text-slate-400 font-mono">Matched Trades: {tradesHistory.length}</span>
        </div>
      </div>

      {/* 3. Settled Trades Log */}
      <div className="lg:col-span-4 bg-[#0F1115] border border-slate-800/80 rounded-xl p-5 shadow-sm flex flex-col h-full min-h-[350px]">
        <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider border-b border-slate-800/80 pb-2 mb-3 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <Clock className="h-4.5 w-4.5 text-blue-500" />
            Settled Grid Transactions
          </span>
          <span className="text-[9px] bg-blue-950/40 text-blue-400 font-mono px-1 rounded font-bold border border-blue-900/30">LIVE METERS</span>
        </h3>

        <div className="space-y-2 overflow-y-auto max-h-[260px] flex-grow pr-1 text-xs">
          {filteredTrades.length === 0 ? (
            <div className="text-slate-500 text-center py-10 italic">No transactions settled yet</div>
          ) : (
            filteredTrades.map(trade => (
              <div key={trade.id} className="border border-slate-850 bg-[#0A0A0B] p-2.5 rounded-lg flex flex-col gap-1 shadow-sm hover:border-blue-900/50 transition-colors">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-slate-200 font-mono">{trade.amountKwh.toFixed(0)} kWh matched</span>
                  <span className="text-[10px] text-slate-500 font-mono">{trade.timestamp}</span>
                </div>
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span className="truncate max-w-[100px] text-slate-300" title={trade.sellerName}>Sell: {trade.sellerName}</span>
                  <span className="truncate max-w-[100px] text-slate-300" title={trade.buyerName}>Buy: {trade.buyerName}</span>
                </div>
                <div className="flex justify-between items-center text-[10px] border-t border-slate-850 pt-1 mt-1 text-slate-500">
                  <span className="flex items-center gap-0.5 font-bold font-mono text-blue-400">
                    £{trade.pricePerKwh.toFixed(3)}/kWh
                  </span>
                  <span className="flex items-center gap-1 text-[9px] font-bold font-mono bg-emerald-950/40 text-emerald-400 border border-emerald-900/30 px-1 rounded">
                    <Sparkles className="h-2.5 w-2.5 text-emerald-500" />
                    CO2 Score: {trade.carbonScore}
                  </span>
                  <span className="text-slate-400">Loss: {trade.lossKwh.toFixed(1)}kW</span>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="border-t border-slate-800/80 pt-3 text-[10px] text-slate-500 flex items-center gap-1">
          <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
          <span>Settlements guaranteed by smart contract protocols</span>
        </div>
      </div>
    </div>
  );
};
