import React from 'react';
import { RegionalEnergyZone, PowerFlowLine } from '../types';
import { Shield, Zap, TrendingDown, RefreshCw, AlertTriangle, BatteryCharging, Leaf } from 'lucide-react';

interface YorkshireMapProps {
  zones: RegionalEnergyZone[];
  powerLines: PowerFlowLine[];
  selectedZoneId: string | null;
  onSelectZone: (zoneId: string | null) => void;
}

export const YorkshireMap: React.FC<YorkshireMapProps> = ({
  zones,
  powerLines,
  selectedZoneId,
  onSelectZone
}) => {
  // Map dimensions
  const width = 600;
  const height = 450;

  // Normalized scaling function for Yorkshire coordinates (latitude: ~53.3 to 54.3, longitude: ~-1.6 to -0.3)
  const getCoords = (lat: number, lon: number) => {
    const minLat = 53.25;
    const maxLat = 54.35;
    const minLon = -1.7;
    const maxLon = -0.2;

    const x = ((lon - minLon) / (maxLon - minLon)) * width;
    const y = (1.0 - (lat - minLat) / (maxLat - minLat)) * height;
    return { x, y };
  };

  const selectedZoneObj = zones.find(z => z.id === selectedZoneId);

  return (
    <div id="yorkshire-gis-container" className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-inner relative text-white">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h3 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
            <Zap className="h-5 w-5 text-amber-400" />
            Yorkshire GIS Live Grid & Power Flows
          </h3>
          <p className="text-xs text-slate-400">
            Real-time power routing & Regional Electricity Zones (REZs) simulation
          </p>
        </div>
        <div className="flex gap-3 text-xs">
          <span className="flex items-center gap-1.5 bg-slate-800/80 px-2.5 py-1 rounded border border-slate-700/50">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
            Surplus
          </span>
          <span className="flex items-center gap-1.5 bg-slate-800/80 px-2.5 py-1 rounded border border-slate-700/50">
            <span className="h-2 w-2 rounded-full bg-rose-500 animate-pulse"></span>
            Congested
          </span>
        </div>
      </div>

      <div className="relative border border-slate-800 rounded-lg bg-slate-950/60 overflow-hidden flex items-center justify-center p-2 min-h-[380px]">
        <svg width="100%" height="100%" viewBox={`0 0 ${width} ${height}`} className="max-h-[420px]">
          {/* Defs for gradients & flow animation */}
          <defs>
            <linearGradient id="line-normal" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#10b981" />
              <stop offset="100%" stopColor="#06b6d4" />
            </linearGradient>
            <linearGradient id="line-congested" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#ef4444" />
            </linearGradient>
            <marker id="arrow-green" viewBox="0 0 10 10" refX="25" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#10b981" />
            </marker>
            <marker id="arrow-red" viewBox="0 0 10 10" refX="25" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#ef4444" />
            </marker>
          </defs>

          {/* Grid Background/Map Outline representation */}
          <rect width={width} height={height} fill="none" />
          <path d="M50,100 L120,40 L300,10 L520,60 L580,220 L520,380 L350,440 L180,420 L30,280 Z" fill="rgba(15, 23, 42, 0.4)" stroke="rgba(51, 65, 85, 0.2)" strokeWidth="3" strokeDasharray="5,5" />

          {/* Draw Transmission Grid Lines */}
          {powerLines.map(line => {
            const fromZone = zones.find(z => z.id === line.fromZoneId);
            const toZone = zones.find(z => z.id === line.toZoneId);
            if (!fromZone || !toZone) return null;

            const fromCoords = getCoords(fromZone.latitude, fromZone.longitude);
            const toCoords = getCoords(toZone.latitude, toZone.longitude);

            // Is line congested? (Load ratio > 0.85)
            const absoluteFlow = Math.abs(line.flowMw);
            const congestionRatio = absoluteFlow / line.capacityMw;
            const isCongested = congestionRatio > 0.8;
            const strokeColor = isCongested ? '#f59e0b' : '#334155';
            const strokeWidth = 2 + Math.min(6, absoluteFlow * 0.15);

            // Determine flow direction arrow
            const markerId = isCongested ? 'url(#arrow-red)' : 'url(#arrow-green)';

            return (
              <g key={line.id} className="opacity-80 hover:opacity-100 transition-opacity">
                {/* Connection line path */}
                <line
                  x1={fromCoords.x}
                  y1={fromCoords.y}
                  x2={toCoords.x}
                  y2={toCoords.y}
                  stroke={strokeColor}
                  strokeWidth={strokeWidth}
                  strokeDasharray={isCongested ? "6,4" : "none"}
                  markerEnd={absoluteFlow > 2 ? markerId : undefined}
                />
                
                {/* Animated active power current beads if flow is moving */}
                {absoluteFlow > 1 && (
                  <circle r="3.5" fill={isCongested ? "#f43f5e" : "#10b981"}>
                    <animateMotion
                      dur={`${10 / Math.max(1, absoluteFlow)}s`}
                      repeatCount="indefinite"
                      path={`M ${line.flowMw > 0 ? fromCoords.x : toCoords.x} ${line.flowMw > 0 ? fromCoords.y : toCoords.y} L ${line.flowMw > 0 ? toCoords.x : fromCoords.x} ${line.flowMw > 0 ? toCoords.y : fromCoords.y}`}
                    />
                  </circle>
                )}

                {/* Floating load indicator text */}
                <foreignObject
                  x={(fromCoords.x + toCoords.x) / 2 - 25}
                  y={(fromCoords.y + toCoords.y) / 2 - 12}
                  width="50"
                  height="24"
                >
                  <div className={`text-[10px] text-center font-mono py-0.5 px-1 rounded border shadow-md ${
                    isCongested ? 'bg-amber-950 border-amber-600 text-amber-300' : 'bg-slate-900 border-slate-700 text-slate-300'
                  }`}>
                    {absoluteFlow.toFixed(1)}M
                  </div>
                </foreignObject>
              </g>
            );
          })}

          {/* Draw Zone nodes */}
          {zones.map(zone => {
            const coords = getCoords(zone.latitude, zone.longitude);
            const isSelected = selectedZoneId === zone.id;
            
            // Color metrics
            const isSurplus = zone.generation > zone.demand;
            const markerColor = isSelected 
              ? 'ring-4 ring-amber-400 fill-amber-500 stroke-amber-300' 
              : isSurplus 
                ? 'fill-emerald-500 stroke-emerald-400' 
                : 'fill-sky-500 stroke-sky-400';

            const size = isSelected ? 22 : 16;

            return (
              <g
                key={zone.id}
                transform={`translate(${coords.x}, ${coords.y})`}
                onClick={() => onSelectZone(zone.id === selectedZoneId ? null : zone.id)}
                className="cursor-pointer group"
              >
                {/* Halo pulsator for congested zones */}
                {zone.congestionIndex > 0.8 && (
                  <circle r={size + 10} fill="rgba(239, 68, 68, 0.15)" className="animate-ping" />
                )}

                {/* Anchor Circle */}
                <circle
                  r={size}
                  className={`transition-all duration-300 shadow-lg ${markerColor} stroke-2`}
                />

                {/* Internal symbol */}
                <circle r={size / 2} fill="#0f172a" />
                <path d="M-3,-3 L3,3 M3,-3 L-3,3" stroke="#fff" strokeWidth="1" />

                {/* Floating pricing badge */}
                <foreignObject
                  x={-45}
                  y={size + 4}
                  width="90"
                  height="34"
                  className="overflow-visible"
                >
                  <div className={`flex flex-col items-center pointer-events-none transition-all duration-200 ${
                    isSelected ? 'scale-105' : 'opacity-90 group-hover:opacity-100'
                  }`}>
                    <span className={`text-[11px] font-bold px-1.5 py-0.5 rounded shadow ${
                      isSelected ? 'bg-amber-500 text-slate-950 font-extrabold' : 'bg-slate-950/90 text-white border border-slate-800'
                    }`}>
                      {zone.name.split(' ')[0]}
                    </span>
                    <span className="text-[10px] font-mono text-amber-300 font-bold bg-slate-950/80 px-1 rounded">
                      £{(zone.strikePrice).toFixed(2)}/kWh
                    </span>
                  </div>
                </foreignObject>
              </g>
            );
          })}
        </svg>

        {/* Legend Overlay */}
        <div className="absolute bottom-3 left-3 bg-slate-950/80 border border-slate-800 rounded p-2.5 text-[10px] space-y-1 font-mono text-slate-300 shadow-md">
          <div className="font-bold border-b border-slate-800 pb-1 mb-1 text-white">GRID SYMBOLS</div>
          <div className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-emerald-500"></span> Generation Surplus REZ</div>
          <div className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-sky-500"></span> Net Energy Consumer REZ</div>
          <div className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full border border-amber-500 bg-amber-500/20 animate-pulse"></span> Congestion Danger Area</div>
          <div className="flex items-center gap-1.5"><span className="h-0.5 w-4 bg-emerald-500"></span> Optimized Power flow</div>
        </div>
      </div>

      {/* Selected Node Details Box */}
      {selectedZoneObj && (
        <div className="mt-4 bg-slate-950 border border-slate-800/80 rounded-lg p-3 text-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div>
            <div className="text-slate-400 flex items-center gap-1">
              <Zap className="h-3.5 w-3.5 text-amber-400" />
              REZ Name
            </div>
            <div className="text-sm font-bold text-white">{selectedZoneObj.name}</div>
          </div>
          <div>
            <div className="text-slate-400 flex items-center gap-1">
              <TrendingDown className="h-3.5 w-3.5 text-emerald-400" />
              Strike Price
            </div>
            <div className="text-sm font-mono font-bold text-emerald-300">
              £{selectedZoneObj.strikePrice.toFixed(4)} <span className="text-[9px]">/kWh</span>
            </div>
          </div>
          <div>
            <div className="text-slate-400 flex items-center gap-1">
              <BatteryCharging className="h-3.5 w-3.5 text-sky-400" />
              SDR Ratio
            </div>
            <div className="text-sm font-mono font-bold text-white">
              {(selectedZoneObj.generation / selectedZoneObj.demand).toFixed(2)}
              <span className={`text-[9px] ml-1 ${
                selectedZoneObj.generation > selectedZoneObj.demand ? 'text-emerald-400' : 'text-rose-400'
              }`}>
                ({selectedZoneObj.generation > selectedZoneObj.demand ? 'Surplus' : 'Deficit'})
              </span>
            </div>
          </div>
          <div>
            <div className="text-slate-400 flex items-center gap-1">
              <Leaf className="h-3.5 w-3.5 text-green-400" />
              Renewables
            </div>
            <div className="text-sm font-mono font-bold text-green-400">
              {selectedZoneObj.renewablePercentage}% <span className="text-[9px] text-slate-400">({selectedZoneObj.carbonIntensity}g/kWh)</span>
            </div>
          </div>
          <div className="col-span-2 sm:col-span-4 flex justify-between items-center pt-2 border-t border-slate-800 text-[10px] text-slate-400">
            <span>
              Line Loading: <span className="font-mono text-white">Max {selectedZoneObj.transmissionCapacity} MW</span> Capacity
            </span>
            <button
              onClick={() => onSelectZone(null)}
              className="text-amber-400 hover:text-amber-300 font-bold hover:underline cursor-pointer"
            >
              Clear Focus Filter
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
