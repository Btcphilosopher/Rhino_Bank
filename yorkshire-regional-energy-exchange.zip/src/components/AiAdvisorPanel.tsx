import React, { useState } from 'react';
import { AIReport } from '../types';
import { Sparkles, Brain, Cpu, AlertTriangle, Lightbulb, TrendingUp, Info, ShieldAlert, FileText, RefreshCw } from 'lucide-react';

interface AiAdvisorPanelProps {
  onGenerateReport: () => Promise<AIReport>;
  activeReport: AIReport | null;
}

const LOADING_STEPS = [
  "Initialising Yorkshire Smart Grid analysis...",
  "Querying continuous auction bids & asks queues...",
  "Calculating weather solar insolation & wind speed multipliers...",
  "Running Monte Carlo statistical price forecasts in R workspace...",
  "Optimising microsecond transmission line flow matrices...",
  "Compiling executive report via Gemini AI control agents..."
];

export const AiAdvisorPanel: React.FC<AiAdvisorPanelProps> = ({
  onGenerateReport,
  activeReport
}) => {
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [errorNotice, setErrorNotice] = useState<string | null>(null);

  const triggerReport = async () => {
    setLoading(true);
    setLoadingStep(0);
    setErrorNotice(null);

    // Rotate loading messages
    const stepInterval = setInterval(() => {
      setLoadingStep(prev => (prev + 1) % LOADING_STEPS.length);
    }, 1200);

    try {
      await onGenerateReport();
    } catch (err: any) {
      console.error(err);
      setErrorNotice(err.message || 'Upstream Gemini model error');
    } finally {
      clearInterval(stepInterval);
      setLoading(false);
    }
  };

  return (
    <div id="ai-advisor-container" className="bg-gradient-to-br from-indigo-900/10 via-indigo-950/5 to-slate-900 border border-indigo-200/50 rounded-xl p-5 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-indigo-100/50 pb-4 mb-4">
        <div>
          <h3 className="text-lg font-bold text-indigo-950 flex items-center gap-2">
            <Brain className="h-6 w-6 text-indigo-600 animate-pulse" />
            YREX Autonomous AI Control Agents
          </h3>
          <p className="text-xs text-slate-600">
            AI-driven decision support, predictive congestion modeling, and strategic market reports
          </p>
        </div>

        <button
          onClick={triggerReport}
          disabled={loading}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 text-xs font-bold rounded-lg shadow active:scale-95 transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          {loading ? 'Consulting Agent...' : 'Query AI Grid Advisor'}
        </button>
      </div>

      {loading && (
        <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
          <div className="relative">
            <Cpu className="h-12 w-12 text-indigo-600 animate-spin" />
            <Sparkles className="h-5 w-5 text-indigo-400 absolute -top-1 -right-1 animate-pulse" />
          </div>
          <div className="space-y-1">
            <p className="text-sm font-bold text-indigo-950">Generating Strategic Yorkshire Grid Report</p>
            <p className="text-xs font-mono text-indigo-600/80 max-w-sm animate-pulse">{LOADING_STEPS[loadingStep]}</p>
          </div>
        </div>
      )}

      {!loading && errorNotice && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-xs text-amber-800 space-y-2 mb-4">
          <div className="flex items-center gap-2 font-bold text-amber-900">
            <ShieldAlert className="h-5 w-5 text-amber-600" />
            Local Heuristic Engine Backup Activated
          </div>
          <p>
            {errorNotice.includes('API key') 
              ? 'The Gemini API Key is currently not set up in the SettingsSecrets panel of AI Studio.'
              : 'The upstream neural service returned an error.'
            } We have fallback to the built-in deterministic optimization matrix to ensure you have full, unhindered grid support.
          </p>
          <button
            onClick={triggerReport}
            className="text-indigo-600 font-bold underline hover:text-indigo-800 cursor-pointer"
          >
            Retry AI Agent lookup
          </button>
        </div>
      )}

      {!loading && !activeReport && !errorNotice && (
        <div className="text-center py-10 bg-slate-50/50 border border-slate-100 rounded-lg">
          <FileText className="h-10 w-10 text-slate-300 mx-auto mb-2" />
          <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">Grid Advisor Standby</h4>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Click the advisor query button above to generate a real-time, comprehensive market audit powered by Gemini models.
          </p>
        </div>
      )}

      {!loading && activeReport && (
        <div className="space-y-5 animate-fade-in text-slate-800">
          {/* Report Title & Metadata */}
          <div className="bg-indigo-950 text-white rounded-lg p-4 shadow-sm relative overflow-hidden">
            <div className="absolute right-3 top-3 opacity-10">
              <Sparkles className="h-20 w-20" />
            </div>
            <div className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest font-mono">
              Yorkshire Electricity Exchange Audit
            </div>
            <h4 className="text-base font-extrabold tracking-tight mt-1">{activeReport.title}</h4>
            <p className="text-xs text-indigo-200 mt-2 line-clamp-3 leading-relaxed">
              {activeReport.summary}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
            {/* Price forecast & arbitrage */}
            <div className="space-y-4">
              <div className="bg-white border border-slate-100 rounded-lg p-4 shadow-xs">
                <h5 className="font-bold text-slate-900 flex items-center gap-1.5 mb-2">
                  <TrendingUp className="h-4.5 w-4.5 text-emerald-500" />
                  Strike Price Forecast & Arbitrage Projections
                </h5>
                <p className="text-slate-600 leading-relaxed mb-3">{activeReport.priceForecast}</p>
                <div className="bg-emerald-50 border border-emerald-100/50 text-emerald-800 p-2.5 rounded text-[11px] font-medium leading-normal">
                  <span className="font-bold">Estimated Arbitrage Spreads:</span> {activeReport.arbitrageProfitForecast}
                </div>
              </div>

              {/* Congestion Warning panel */}
              <div className="bg-white border border-slate-100 rounded-lg p-4 shadow-xs">
                <h5 className="font-bold text-slate-900 flex items-center gap-1.5 mb-2">
                  <AlertTriangle className="h-4.5 w-4.5 text-amber-500" />
                  Thermal Grid Congestion & Transformer Alerts
                </h5>
                <div className="space-y-1.5">
                  {activeReport.congestionAlerts.length === 0 ? (
                    <div className="text-slate-400 italic">No grid warnings active</div>
                  ) : (
                    activeReport.congestionAlerts.map((alert, idx) => (
                      <div key={idx} className="flex gap-2 items-start bg-rose-50 text-rose-800 p-2 rounded text-[11px]">
                        <span className="h-1.5 w-1.5 rounded-full bg-rose-500 mt-1.5 shrink-0"></span>
                        <span>{alert}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Battery dispatcher & long-term development */}
            <div className="space-y-4">
              <div className="bg-white border border-slate-100 rounded-lg p-4 shadow-xs">
                <h5 className="font-bold text-slate-900 flex items-center gap-1.5 mb-2">
                  <Cpu className="h-4.5 w-4.5 text-indigo-500" />
                  Automated Battery Dispatch Instruction Matrix
                </h5>
                <p className="text-slate-600 leading-relaxed">{activeReport.batteryDispatchRecommendation}</p>
              </div>

              <div className="bg-white border border-slate-100 rounded-lg p-4 shadow-xs">
                <h5 className="font-bold text-slate-900 flex items-center gap-1.5 mb-2">
                  <Lightbulb className="h-4.5 w-4.5 text-indigo-500" />
                  Strategic Yorkshire Infrastructure Recommendations
                </h5>
                <div className="space-y-2">
                  {activeReport.infrastructureSuggestions.map((sug, idx) => (
                    <div key={idx} className="flex gap-2 items-start bg-indigo-50/50 text-indigo-900 p-2.5 rounded border border-indigo-100/30">
                      <span className="font-mono font-bold text-indigo-600 bg-indigo-100/50 px-1.5 py-0.5 rounded text-[9px]">
                        {idx + 1}
                      </span>
                      <span>{sug}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Behavior / Anomaly analysis */}
          <div className="bg-slate-50 border border-slate-200/60 rounded-lg p-4 text-xs">
            <h5 className="font-bold text-slate-900 flex items-center gap-1.5 mb-1.5">
              <Info className="h-4 w-4 text-slate-500" />
              Continuous Meter Behavior & Grid Integrity Assessment
            </h5>
            <p className="text-slate-600 leading-relaxed font-medium">
              {activeReport.behaviorAnalysis}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
