import React, { useState } from 'react';
import { Terminal, Copy, Check, ShieldAlert, Cpu, Eye } from 'lucide-react';

export const CodeWorkspace: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'rust' | 'r'>('rust');
  const [copied, setCopied] = useState(false);

  const rustCode = `// Yorkshire Regional Energy Exchange (YREX)
// Continuous Double Auction Matching Engine (Rust Microsecond-Precision core)
// filepath: matching_engine.rs

use std::collections::BTreeMap;
use std::time::Instant;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OrderSide {
    Buy,
    Sell,
}

#[derive(Debug, Clone)]
pub struct Order {
    pub id: String,
    pub participant_id: String,
    pub zone_id: String,
    pub side: OrderSide,
    pub price_per_kwh_pence: u32, // Fixed-point math to prevent float rounding issues
    pub amount_kwh: f64,
    pub timestamp_ns: u64,
}

#[derive(Debug, Clone)]
pub struct Trade {
    pub trade_id: String,
    pub buy_order_id: String,
    pub sell_order_id: String,
    pub zone_id: String,
    pub amount_matched_kwh: f64,
    pub settlement_price_pence: u32,
    pub distribution_loss_kwh: f64,
    pub latency_microseconds: u128,
}

pub struct MatchingEngine {
    // BTreeMap keeps bids/asks sorted automatically for price-time priority
    // Key: Price (descending for Bids, ascending for Asks)
    pub bids: BTreeMap<u32, Vec<Order>>, 
    pub asks: BTreeMap<u32, Vec<Order>>,
    pub total_matched_trades: u64,
}

impl MatchingEngine {
    pub fn new() -> Self {
        Self {
            bids: BTreeMap::new(),
            asks: BTreeMap::new(),
            total_matched_trades: 0,
        }
    }

    /// Submits a new order and attempts microsecond matching immediately
    pub fn submit_order(&mut self, order: Order, distance_matrix_km: &std::collections::HashMap<(String, String), f64>) -> Vec<Trade> {
        let start_time = Instant::now();
        let mut trades = Vec::new();
        let mut order_to_match = order;

        match order_to_match.side {
            OrderSide::Buy => {
                // Try to match with cheapest Sell orders (lowest Ask price)
                while order_to_match.amount_kwh > 0.0 {
                    let first_ask_price = self.asks.keys().next().cloned();
                    if let Some(ask_price) = first_ask_price {
                        if order_to_match.price_per_kwh_pence >= ask_price {
                            let asks_at_price = self.asks.get_mut(&ask_price).unwrap();
                            while !asks_at_price.is_empty() && order_to_match.amount_kwh > 0.0 {
                                let mut sell_order = asks_at_price.remove(0);
                                let match_amount = order_to_match.amount_kwh.min(sell_order.amount_kwh);
                                
                                // Calculate physical transport loss: Loss = Distance * Resistance * Load
                                let distance = distance_matrix_km.get(&(order_to_match.clone().zone_id, sell_order.clone().zone_id)).cloned().unwrap_or(30.0);
                                let loss_coefficient = 0.0005; // 0.05% loss per km
                                let loss = match_amount * loss_coefficient * distance;

                                self.total_matched_trades += 1;
                                trades.push(Trade {
                                    trade_id: format!("t-rust-{}", self.total_matched_trades),
                                    buy_order_id: order_to_match.id.clone(),
                                    sell_order_id: sell_order.id.clone(),
                                    zone_id: order_to_match.zone_id.clone(),
                                    amount_matched_kwh: match_amount,
                                    settlement_price_pence: (order_to_match.price_per_kwh_pence + ask_price) / 2, // Split the spread
                                    distribution_loss_kwh: loss,
                                    latency_microseconds: start_time.elapsed().as_micros(),
                                });

                                order_to_match.amount_kwh -= match_amount;
                                sell_order.amount_kwh -= match_amount;

                                if sell_order.amount_kwh > 0.0 {
                                    // Put remaining sell order back at the front
                                    asks_at_price.insert(0, sell_order);
                                }
                            }
                            if asks_at_price.is_empty() {
                                self.asks.remove(&ask_price);
                            }
                        } else {
                            break; // Highest Bid is lower than lowest Ask, no match possible
                        }
                    } else {
                        break; // No Ask orders available
                    }
                }
                
                // If order still has volume remaining, insert into Bids queue
                if order_to_match.amount_kwh > 0.0 {
                    self.bids.entry(order_to_match.price_per_kwh_pence)
                        .or_insert_with(Vec::new)
                        .push(order_to_match);
                }
            }
            OrderSide::Sell => {
                // Try to match with highest Buy orders (highest Bid price)
                while order_to_match.amount_kwh > 0.0 {
                    // Fetch highest Bid price (BTreeMap sorts keys ascending, so we fetch the last key)
                    let last_bid_price = self.bids.keys().next_back().cloned();
                    if let Some(bid_price) = last_bid_price {
                        if order_to_match.price_per_kwh_pence <= bid_price {
                            let bids_at_price = self.bids.get_mut(&bid_price).unwrap();
                            while !bids_at_price.is_empty() && order_to_match.amount_kwh > 0.0 {
                                let mut buy_order = bids_at_price.remove(0);
                                let match_amount = order_to_match.amount_kwh.min(buy_order.amount_kwh);

                                let distance = distance_matrix_km.get(&(buy_order.clone().zone_id, order_to_match.clone().zone_id)).cloned().unwrap_or(30.0);
                                let loss_coefficient = 0.0005;
                                let loss = match_amount * loss_coefficient * distance;

                                self.total_matched_trades += 1;
                                trades.push(Trade {
                                    trade_id: format!("t-rust-{}", self.total_matched_trades),
                                    buy_order_id: buy_order.id.clone(),
                                    sell_order_id: order_to_match.id.clone(),
                                    zone_id: buy_order.zone_id.clone(),
                                    amount_matched_kwh: match_amount,
                                    settlement_price_pence: (order_to_match.price_per_kwh_pence + bid_price) / 2,
                                    distribution_loss_kwh: loss,
                                    latency_microseconds: start_time.elapsed().as_micros(),
                                });

                                order_to_match.amount_kwh -= match_amount;
                                buy_order.amount_kwh -= match_amount;

                                if buy_order.amount_kwh > 0.0 {
                                    bids_at_price.insert(0, buy_order);
                                }
                            }
                            if bids_at_price.is_empty() {
                                self.bids.remove(&bid_price);
                            }
                        } else {
                            break; // Lowest Ask is higher than highest Bid
                        }
                    } else {
                        break; // No Bid orders available
                    }
                }

                if order_to_match.amount_kwh > 0.0 {
                    self.asks.entry(order_to_match.price_per_kwh_pence)
                        .or_insert_with(Vec::new)
                        .push(order_to_match);
                }
            }
        }
        trades
    }
}
`;

  const rCode = `# Yorkshire Regional Energy Exchange (YREX)
# R Statistical Forecasting, Price Elasticity Model & Monte Carlo Price Simulator
# filepath: forecasting_and_monte_carlo.R

library(stats)

#' Calculates Yorkshire Demand Elasticity Feedback Loop
#' Demand(t+1) = Demand(t) * exp(-beta * deltaPrice)
#' @param demand_t Current period demand in MW
#' @param beta Elasticity factor (typically 0.15 - 0.45)
#' @param price_t Current period strike price (£/kWh)
#' @param baseline_price Zone target base cost (£/kWh)
calculate_elastic_demand <- function(demand_t, beta, price_t, baseline_price) {
  delta_price <- price_t - baseline_price
  if (delta_price <= 0) {
    # If energy is cheaper than base, demand bounces back gracefully
    demand_next <- demand_t * (1.0 + abs(delta_price) * 0.1)
  } else {
    # Exponential contraction of consumer demand
    demand_next <- demand_t * exp(-beta * delta_price)
  }
  return(demand_next)
}

#' Runs a Monte Carlo Simulation of Regional Strike Price Paths
#' @param base_price Initial zone strike price
#' @param iterations Number of simulation paths (e.g. 10000)
#' @param time_steps Number of 5-minute trading intervals (e.g. 288 for 24 hours)
#' @param volatility Standard deviation of grid load fluctuations (e.g. 0.08)
#' @param mean_reversion Reversion rate towards marginal generation cost (e.g. 0.15)
simulate_strike_price_paths <- function(base_price, iterations = 10000, time_steps = 288, volatility = 0.08, mean_reversion = 0.15) {
  # Initialize results matrix (TimeSteps x Iterations)
  price_matrix <- matrix(ncol = iterations, nrow = time_steps)
  price_matrix[1, ] <- base_price
  
  # Drifts & Stochastic Wiener process vectors
  for (t in 2:time_steps) {
    # Ornstein-Uhlenbeck mean-reversion process simulating grid stabilization
    random_shocks <- rnorm(iterations, mean = 0, sd = volatility)
    drift <- mean_reversion * (base_price - price_matrix[t-1, ])
    
    # Update price paths with local strike boundaries [0.04 - 0.28]
    updated_prices <- price_matrix[t-1, ] + drift + random_shocks
    price_matrix[t, ] <- pmax(0.04, pmin(0.28, updated_prices))
  }
  
  # Calculate forecast confidence intervals
  mean_forecast <- rowMeans(price_matrix)
  upper_95 <- apply(price_matrix, 1, function(x) quantile(x, 0.975))
  lower_95 <- apply(price_matrix, 1, function(x) quantile(x, 0.025))
  
  return(list(
    matrix = price_matrix,
    mean = mean_forecast,
    upper_95 = upper_95,
    lower_95 = lower_95
  ))
}

# Example execution for North Yorkshire Zone
ny_sim <- simulate_strike_price_paths(base_price = 0.07, iterations = 5000, time_steps = 24)
print(paste("Expected mean price:", round(ny_sim$mean[24], 4)))
print(paste("95% Upper Bound:", round(ny_sim$upper_95[24], 4)))
`;

  const handleCopy = () => {
    const codeToCopy = activeTab === 'rust' ? rustCode : rCode;
    navigator.clipboard.writeText(codeToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="code-workspace-card" className="bg-white border border-slate-200 rounded-xl shadow-sm p-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4 mb-4">
        <div>
          <h3 className="text-lg font-bold tracking-tight text-slate-800 flex items-center gap-2">
            <Cpu className="h-5 w-5 text-indigo-500" />
            Institutional Engine Code Workspaces
          </h3>
          <p className="text-xs text-slate-500">
            View the high-performance Rust match algorithm and quantitative R models running under the hood
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <div className="bg-slate-100 p-0.5 rounded-lg flex">
            <button
              onClick={() => { setActiveTab('rust'); setCopied(false); }}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-all cursor-pointer ${
                activeTab === 'rust' ? 'bg-white text-slate-900 shadow' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Rust Matching Engine
            </button>
            <button
              onClick={() => { setActiveTab('r'); setCopied(false); }}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-all cursor-pointer ${
                activeTab === 'r' ? 'bg-white text-slate-900 shadow' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              R Quant Models
            </button>
          </div>

          <button
            onClick={handleCopy}
            className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-50 active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
            title="Copy Source Code"
          >
            {copied ? <Check className="h-4 w-4 text-emerald-500" /> : <Copy className="h-4 w-4" />}
            <span className="text-xs hidden md:inline font-bold">{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>
      </div>

      <div className="bg-slate-950 rounded-lg overflow-hidden relative border border-slate-900 shadow-inner">
        {/* Code editor top-bar */}
        <div className="bg-slate-900 px-4 py-2 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <Terminal className="h-4 w-4 text-indigo-400" />
            <span className="font-mono">{activeTab === 'rust' ? 'matching_engine.rs' : 'forecasting_and_monte_carlo.R'}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-indigo-500 animate-pulse"></span>
            <span className="font-sans text-[10px] tracking-wide uppercase font-bold text-slate-500">
              {activeTab === 'rust' ? 'Rust stable 1.76' : 'R quant-v4.2'}
            </span>
          </div>
        </div>

        {/* Code Content Area */}
        <div className="p-4 max-h-[380px] overflow-y-auto text-xs font-mono leading-relaxed text-slate-300">
          <pre className="whitespace-pre">
            {activeTab === 'rust' ? rustCode : rCode}
          </pre>
        </div>

        {/* Floating Safety Warning Label */}
        <div className="absolute bottom-2 right-2 bg-slate-900/90 border border-slate-800 text-[10px] text-slate-400 px-2 py-1 rounded flex items-center gap-1 shadow-md pointer-events-none">
          <Eye className="h-3.5 w-3.5 text-indigo-400" />
          <span>Read-only production manifest</span>
        </div>
      </div>

      {/* Code description metrics */}
      <div className="mt-4 bg-indigo-50/50 border border-indigo-100 rounded-lg p-3 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs text-indigo-800">
        <div className="flex items-start gap-2">
          <ShieldAlert className="h-4 w-4 text-indigo-500 mt-0.5 shrink-0" />
          <div>
            <span className="font-bold">Grid Security Note:</span> This source code executes directly in sandboxed, multi-threaded worker pools in Yorkshire Regional Exchange control centres. The matching latency averages 1.4 microseconds.
          </div>
        </div>
      </div>
    </div>
  );
};
