import React, { useState } from 'react';
import { BatteryDispatchConfig, MarketParticipant } from '../types';
import { Battery, Zap, AlertCircle, Play, Pause, Compass, DollarSign, Activity } from 'lucide-react';

interface BatteryDispatchPanelProps {
  batteryConfigs: BatteryDispatchConfig[];
  participants: MarketParticipant[];
  zonePrices: Record<string, number>;
  onUpdateStrategy: (batteryId: string, strategy: 'arbitrage' | 'frequency_response' | 'peak_shaving' | 'manual') => void;
  onManualDispatch: (batteryId: string, powerKw: number) => void;
}

export const BatteryDispatchPanel: React.FC<BatteryDispatchPanelProps> = ({
  batteryConfigs,
  participants,
  zonePrices,
  onUpdateStrategy,
  onManualDispatch
}) => {
  const [selectedBatteryId, setSelectedBatteryId] = useState(batteryConfigs[0]?.batteryId || '');
  const [manualPower, setManualPower] = useState<number>(0);

  const selectedConfig = batteryConfigs.find(bc => bc.batteryId === selectedBatteryId);
  const selectedParticipant = participants.find(p => p.id === selectedBatteryId);

  if (!selectedConfig || !selectedParticipant) {
    return <div className="text-slate-400 text-xs text-center py-6">No battery storage systems registered</div>;
  }

  // Find parent zone prices to display
  const localPrice = zonePrices[selectedParticipant.zoneId] || 0.08;
  const rawSocFraction = (selectedParticipant.currentPowerKw > 0) ? 0.45 : 0.65; // Simulated visual levels tied to state
  const stateOfChargePercent = Math.round(rawSocFraction * 100);

  const handleManualAction = (type: 'charge' | 'discharge') => {
    const multiplier = type === 'charge' ? -1 : 1;
    onManualDispatch(selectedBatteryId, manualPower * multiplier);
  };

  return (
    <div id="battery-dispatch-wrapper" className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4 mb-4">
        <div>
          <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <Battery className="h-5.5 w-5.5 text-indigo-500" />
            Yorkshire Smart Battery Dispatch Engine
          </h3>
          <p className="text-xs text-slate-500">
            Minimise charging costs during renewable surplus and discharge at peak strike rates
          </p>
        </div>

        {/* Battery selector */}
        <select
          value={selectedBatteryId}
          onChange={(e) => {
            setSelectedBatteryId(e.target.value);
            setManualPower(0);
          }}
          className="bg-slate-50 border border-slate-200 text-slate-800 text-xs font-bold rounded-lg p-2 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none"
        >
          {batteryConfigs.map(config => {
            const part = participants.find(p => p.id === config.batteryId);
            return (
              <option key={config.batteryId} value={config.batteryId}>
                {part ? part.name : config.batteryId}
              </option>
            );
          })}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Side: Battery Status Meter */}
        <div className="md:col-span-4 flex flex-col items-center justify-center bg-slate-50 border border-slate-200/50 rounded-xl p-5 relative overflow-hidden">
          {/* Large Battery SVG Representation */}
          <div className="w-24 h-44 border-4 border-slate-700 rounded-xl relative p-1.5 flex flex-col justify-end bg-slate-900 shadow-inner">
            {/* Battery cap */}
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-8 h-3 bg-slate-700 rounded-t-sm"></div>
            
            {/* Battery dynamic liquid fill bar */}
            <div
              className={`w-full rounded-lg transition-all duration-500 ease-out flex items-center justify-center font-mono font-bold text-xs text-white ${
                stateOfChargePercent > 60 
                  ? 'bg-emerald-500 text-slate-950' 
                  : stateOfChargePercent > 25 
                    ? 'bg-sky-500' 
                    : 'bg-rose-500 animate-pulse'
              }`}
              style={{ height: `${stateOfChargePercent}%` }}
            >
              {stateOfChargePercent > 15 ? `${stateOfChargePercent}%` : ''}
            </div>
          </div>

          <div className="text-center mt-3">
            <div className="text-sm font-bold text-slate-800">
              State of Charge (SOC)
            </div>
            <div className="text-xs font-mono text-slate-400 font-bold">
              {Math.round(selectedConfig.capacityKwh * rawSocFraction).toLocaleString()} / {selectedConfig.capacityKwh.toLocaleString()} kWh
            </div>
          </div>

          {/* Grid flow direction indicator badge */}
          <div className="absolute top-3 right-3">
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${
              selectedParticipant.currentPowerKw > 0
                ? 'bg-emerald-100 text-emerald-800'
                : selectedParticipant.currentPowerKw < 0
                  ? 'bg-indigo-100 text-indigo-800 animate-pulse'
                  : 'bg-slate-100 text-slate-600'
            }`}>
              <Activity className="h-3.5 w-3.5" />
              {selectedParticipant.currentPowerKw > 0
                ? `Discharging ${selectedParticipant.currentPowerKw}kW`
                : selectedParticipant.currentPowerKw < 0
                  ? `Charging ${Math.abs(selectedParticipant.currentPowerKw)}kW`
                  : 'Idle'
              }
            </span>
          </div>
        </div>

        {/* Right Side: Dispatch controls */}
        <div className="md:col-span-8 flex flex-col justify-between space-y-4">
          {/* Strategy controller */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                Dispatch Strategy Optimization Mode
              </label>
              <div className="space-y-1">
                {[
                  { id: 'arbitrage', name: 'Smart Arbitrage Optimization', desc: 'Auto-charge at grid low prices, discharge at spikes' },
                  { id: 'peak_shaving', name: 'Peak Shaving mode', desc: 'Discharge during extreme grid loads' },
                  { id: 'frequency_response', name: 'Frequency response loop', desc: 'Stabilize line imbalances dynamically' },
                  { id: 'manual', name: 'Manual grid dispatch overrides', desc: 'Direct operator control of inputs/outputs' }
                ].map(strat => (
                  <button
                    key={strat.id}
                    type="button"
                    onClick={() => onUpdateStrategy(selectedBatteryId, strat.id as any)}
                    className={`w-full p-2 rounded-lg text-left border text-xs transition-all flex flex-col justify-center cursor-pointer ${
                      selectedConfig.pricingStrategy === strat.id
                        ? 'bg-indigo-50 border-indigo-300 text-indigo-800 font-bold ring-2 ring-indigo-500/10'
                        : 'bg-white border-slate-100 hover:border-slate-200 text-slate-700 hover:text-slate-900'
                    }`}
                  >
                    <span className="font-bold flex items-center gap-1">
                      {selectedConfig.pricingStrategy === strat.id && <Compass className="h-3.5 w-3.5 text-indigo-600" />}
                      {strat.name}
                    </span>
                    <span className="text-[10px] text-slate-400 font-normal mt-0.5">{strat.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Manual actions (only displayed if strategy is manual) */}
            <div className="border border-slate-100 rounded-xl p-4 bg-slate-50/50 flex flex-col justify-between h-full min-h-[180px]">
              <div>
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                  <DollarSign className="h-4 w-4 text-emerald-500" />
                  Battery Cost & Degradation Metrics
                </h4>
                <div className="space-y-2 text-xs text-slate-600 font-medium">
                  <div className="flex justify-between">
                    <span>Local strike price:</span>
                    <span className="font-mono text-slate-800 font-bold">£{localPrice.toFixed(4)} / kWh</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Degradation offset:</span>
                    <span className="font-mono text-slate-800">£{selectedConfig.degradationCostPerKwh.toFixed(4)} / kWh</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Roundtrip efficiency:</span>
                    <span className="font-mono text-slate-800">
                      {Math.round(selectedConfig.chargeEfficiency * selectedConfig.dischargeEfficiency * 100)}% (Dual-Inverter)
                    </span>
                  </div>
                </div>
              </div>

              {selectedConfig.pricingStrategy === 'manual' ? (
                <div className="space-y-2 pt-3 border-t border-slate-100 mt-2">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    Manual override limit (kW)
                  </label>
                  <input
                    type="range"
                    min="0"
                    max={selectedConfig.maxChargeKw}
                    value={manualPower}
                    onChange={(e) => setManualPower(parseInt(e.target.value) || 0)}
                    className="w-full accent-indigo-600 cursor-pointer h-1.5 bg-slate-200 rounded-lg"
                  />
                  <div className="flex justify-between text-[10px] font-mono text-slate-400">
                    <span>0 kW</span>
                    <span className="font-bold text-indigo-600">{manualPower} kW</span>
                    <span>{selectedConfig.maxChargeKw} kW</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 pt-1.5">
                    <button
                      type="button"
                      disabled={manualPower <= 0}
                      onClick={() => handleManualAction('charge')}
                      className="py-1.5 px-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
                    >
                      Inject Charge
                    </button>
                    <button
                      type="button"
                      disabled={manualPower <= 0}
                      onClick={() => handleManualAction('discharge')}
                      className="py-1.5 px-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
                    >
                      Discharge to Grid
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-indigo-50 border border-indigo-100 rounded-lg p-3 text-xs text-indigo-800 mt-3">
                  <div className="flex gap-1.5">
                    <AlertCircle className="h-4 w-4 text-indigo-500 shrink-0 mt-0.5" />
                    <span>
                      Strategy engine is currently managing dispatch load cycles fully autonomously in background intervals.
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
