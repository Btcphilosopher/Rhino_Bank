export interface RegionalEnergyZone {
  id: string;
  name: string;
  generation: number;       // active generation in MW
  storage: number;          // active storage SOC %
  storageCapacity: number;  // storage capacity in MWh
  storageCurrent: number;   // active storage current level in MWh
  demand: number;           // demand in MW
  transmissionCapacity: number; // transmission limit in MW
  distributionLosses: number; // fractional loss (e.g., 0.05 for 5%)
  strikePrice: number;      // calculated strike price in £/kWh
  congestionIndex: number;  // Current Load / Network Capacity
  carbonIntensity: number;  // gCO2/kWh
  renewablePercentage: number; // 0 to 100
  latitude: number;
  longitude: number;
  baseDemand: number;       // base demand in MW
  baseGeneration: number;   // base generation in MW
}

export type ParticipantType =
  | 'micro_farm'
  | 'solar_farm'
  | 'wind_farm'
  | 'hydroelectric'
  | 'biogas'
  | 'battery_storage'
  | 'industrial_chp'
  | 'commercial'
  | 'factory'
  | 'local_authority'
  | 'ev_charger'
  | 'domestic_consumer'
  | 'cooperative'
  | 'private_supplier';

export interface MarketParticipant {
  id: string;
  name: string;
  type: ParticipantType;
  zoneId: string;
  capacityKw: number;
  currentPowerKw: number;
  status: 'active' | 'standby' | 'maintenance';
}

export interface MarketOrder {
  id: string;
  participantId: string;
  participantName: string;
  participantType: ParticipantType;
  zoneId: string;
  type: 'buy' | 'sell';
  amountKwh: number;
  pricePerKwh: number;
  timestamp: string;
  status: 'pending' | 'matched' | 'cancelled';
}

export interface MatchedTrade {
  id: string;
  buyOrderId: string;
  sellOrderId: string;
  buyerName: string;
  sellerName: string;
  zoneId: string;
  amountKwh: number;
  pricePerKwh: number;
  transmissionCostPerKwh: number;
  carbonScore: number;
  timestamp: string;
  lossKwh: number;
}

export interface PowerFlowLine {
  id: string;
  fromZoneId: string;
  toZoneId: string;
  capacityMw: number;
  flowMw: number;
  resistanceOhms: number;
  lossesMw: number;
}

export interface BatteryDispatchConfig {
  batteryId: string;
  capacityKwh: number;
  maxChargeKw: number;
  maxDischargeKw: number;
  chargeEfficiency: number; // e.g. 0.90
  dischargeEfficiency: number; // e.g. 0.90
  degradationCostPerKwh: number; // Cost in £ of 1 kWh of throughput degradation
  pricingStrategy: 'arbitrage' | 'frequency_response' | 'peak_shaving' | 'manual';
}

export interface WeatherForecastState {
  hour: string;
  solarInsolation: number; // 0-1000 W/m^2
  windSpeed: number;       // m/s
  temperature: number;     // °C
  rainfall: number;        // mm/h
  cloudCover: number;      // %
}

export interface MarketSimulationState {
  currentStep: number;
  timestamp: string;
  zones: RegionalEnergyZone[];
  participants: MarketParticipant[];
  orderBook: MarketOrder[];
  tradesHistory: MatchedTrade[];
  powerLines: PowerFlowLine[];
  weather: WeatherForecastState[];
  batteryConfigs: BatteryDispatchConfig[];
  simulationSpeed: number; // ms per step
}

export interface AIReport {
  id: string;
  title: string;
  timestamp: string;
  summary: string;
  priceForecast: string;
  congestionAlerts: string[];
  batteryDispatchRecommendation: string;
  infrastructureSuggestions: string[];
  arbitrageProfitForecast: string;
  behaviorAnalysis: string;
}
