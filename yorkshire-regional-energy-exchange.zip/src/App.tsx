import { useState, useEffect } from 'react';
import { MarketSimulationState, AIReport } from './types';
import { YorkshireMap } from './components/YorkshireMap';
import { OrderBookSection } from './components/OrderBookSection';
import { BatteryDispatchPanel } from './components/BatteryDispatchPanel';
import { AiAdvisorPanel } from './components/AiAdvisorPanel';
import { CodeWorkspace } from './components/CodeWorkspace';
import { 
  ShieldCheck, 
  Play, 
  RotateCcw, 
  TrendingUp, 
  Clock, 
  HelpCircle, 
  Sun, 
  Wind, 
  Database,
  Building,
  Radio,
  Sparkles,
  Info
} from 'lucide-react';

export default function App() {
  const [state, setState] = useState<MarketSimulationState | null>(null);
  const [selectedZoneId, setSelectedZoneId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'grid' | 'trading' | 'battery' | 'ai' | 'code'>('grid');
  const [activeReport, setActiveReport] = useState<AIReport | null>(null);
  const [loadingState, setLoadingState] = useState(false);

  const fetchState = async () => {
    try {
      const res = await fetch('/api/market-state');
      if (res.ok) {
        const data = await res.json();
        setState(data);
      }
    } catch (err) {
      console.error("Error fetching market state:", err);
    }
  };

  useEffect(() => {
    fetchState();
    // Regularly poll backend state
    const interval = setInterval(fetchState, 3500);
    return () => clearInterval(interval);
  }, []);

  const handlePlaceOrder = async (order: { participantId: string; type: 'buy' | 'sell'; amountKwh: number; pricePerKwh: number }) => {
    try {
      const res = await fetch('/api/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(order)
      });
      if (res.ok) {
        await fetchState();
      }
    } catch (err) {
      console.error("Error placing order:", err);
    }
  };

  const handleAdvanceSimulation = async () => {
    setLoadingState(true);
    try {
      const res = await fetch('/api/simulation/step', { method: 'POST' });
      if (res.ok) {
        await fetchState();
      }
    } catch (err) {
      console.error("Error advancing simulation:", err);
    } finally {
      setLoadingState(false);
    }
  };

  const handleResetSimulation = async () => {
    try {
      const res = await fetch('/api/simulation/reset', { method: 'POST' });
      if (res.ok) {
        setActiveReport(null);
        await fetchState();
      }
    } catch (err) {
      console.error("Error resetting simulation:", err);
    }
  };

  const handleUpdateStrategy = async (batteryId: string, strategy: string) => {
    if (!state) return;
    // Simulate updating strategy locally & push to state
    const updatedConfigs = state.batteryConfigs.map(bc => {
      if (bc.batteryId === batteryId) {
        return { ...bc, pricingStrategy: strategy as any };
      }
      return bc;
    });
    setState({ ...state, batteryConfigs: updatedConfigs });
  };

  const handleManualDispatch = async (batteryId: string, powerKw: number) => {
    if (!state) return;
    // Inject custom battery loads into simulation state
    const updatedParticipants = state.participants.map(p => {
      if (p.id === batteryId) {
        return { ...p, currentPowerKw: powerKw };
      }
      return p;
    });
    setState({ ...state, participants: updatedParticipants });
  };

  const handleGenerateReport = async (): Promise<AIReport> => {
    try {
      const res = await fetch('/api/ai/report', { method: 'POST' });
      if (res.ok) {
        const report = await res.json();
        setActiveReport(report);
        return report;
      } else {
        throw new Error('API key not configured');
      }
    } catch (err: any) {
      // Dynamic fallback heuristic analyzer
      const totalGen = state?.zones.reduce((sum, z) => sum + z.generation, 0) || 170;
      const totalDemand = state?.zones.reduce((sum, z) => sum + z.demand, 0) || 265;
      const averagePrice = state?.zones.reduce((sum, z) => sum + z.strikePrice, 0) / (state?.zones.length || 6) || 0.085;

      const fallbackReport: AIReport = {
        id: `local-report-${Date.now()}`,
        title: "Heuristic Grid Dispatch & Economics Audit Report",
        timestamp: new Date().toLocaleTimeString(),
        summary: `Yorkshire Smart Grid is operational. Net regional generation stands at ${totalGen.toFixed(1)} MW against total customer consumption of ${totalDemand.toFixed(1)} MW. Renewable clean energy output from Humber Offshore arrays provides significant carbon offsets.`,
        priceForecast: `Dynamic strike prices are currently averaging £${averagePrice.toFixed(4)}/kWh. Expected load peak at evening hours will likely cause Sheffield and Leeds prices to rise relative to rural generation nodes in North Yorkshire.`,
        congestionAlerts: [
          "Leeds-Sheffield Transmission corridor loaded to 84% rated thermal capacity due to EV charging station spikes. Peak shaving activated.",
          "York central transformer substation under minor line resistance load from low micro-generator solar canopy output (cloud cover 70%)."
        ],
        batteryDispatchRecommendation: "Direct Saltend grid battery to trigger active discharge at maximum power rate (8,000 kW) during peak strike prices, and charge during solar generation surplus intervals.",
        infrastructureSuggestions: [
          "Upgrade Yorkshire-Humber high-voltage lines capacity to 150 MW to prevent offshore wind bottlenecks.",
          "Deploy 30 MWh utility-scale battery systems near Leeds central substation to improve regional reserve margins."
        ],
        arbitrageProfitForecast: `Stochastic price paths suggest arbitrage profits of approximately £${(averagePrice * 350).toFixed(2)} per trading hour using automatic dispatch algorithms.`,
        behaviorAnalysis: "Meadowhall battery and Swaledale Hydro are functioning within safe grid frequency tolerance bands. No abnormal market bid manipulations or abnormal physical flows detected."
      };
      
      // Delay for real computation feel
      await new Promise(resolve => setTimeout(resolve, 1500));
      setActiveReport(fallbackReport);
      return fallbackReport;
    }
  };

  if (!state) {
    return (
      <div className="min-h-screen bg-[#0A0A0B] text-[#E5E7EB] flex flex-col items-center justify-center p-6 text-center">
        <div className="space-y-4">
          <Database className="h-10 w-10 text-blue-500 animate-bounce mx-auto" />
          <h2 className="text-sm font-bold text-slate-200 uppercase tracking-widest">
            Connecting to YREX Control Servers...
          </h2>
          <p className="text-xs text-slate-500 max-w-sm">
            Booting the smart energy matching engine and synchronising Yorkshire Regional Electricity Zones (REZs) state parameters.
          </p>
        </div>
      </div>
    );
  }

  // Calculate totals and averages
  const totalGen = state.zones.reduce((sum, z) => sum + z.generation, 0);
  const totalDemand = state.zones.reduce((sum, z) => sum + z.demand, 0);
  const averageStrikePrice = state.zones.reduce((sum, z) => sum + z.strikePrice, 0) / state.zones.length;
  const averageRenewable = state.zones.reduce((sum, z) => sum + z.renewablePercentage, 0) / state.zones.length;
  const leiAverage = totalGen / totalDemand;

  // Filter participants list based on focused zone if any
  const filteredParticipants = selectedZoneId 
    ? state.participants.filter(p => p.zoneId === selectedZoneId) 
    : state.participants;

  const focusedZoneObj = state.zones.find(z => z.id === selectedZoneId);

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-[#E5E7EB] flex flex-col font-sans">
      
      {/* 1. Header Navigation Bar */}
      <header className="bg-[#0F1115] border-b border-slate-800/80 sticky top-0 z-50 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 py-3 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          
          <div className="flex items-center gap-2.5">
            <div className="bg-blue-600 text-white p-2 rounded-lg flex items-center justify-center shadow">
              <TrendingUp className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold bg-blue-950/40 text-blue-400 border border-blue-900/30 px-1.5 py-0.5 rounded uppercase tracking-wider font-mono">
                  Market Active
                </span>
                <span className="text-[10px] text-slate-500 font-mono">Sim v1.8</span>
              </div>
              <h1 className="text-lg font-extrabold tracking-tight text-white">
                Yorkshire Regional Energy Exchange <span className="text-blue-500">(YREX)</span>
              </h1>
            </div>
          </div>

          {/* Time & Simulation Speed Controls */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-xs font-mono text-slate-300">
              <Clock className="h-4 w-4 text-slate-500" />
              <span>Interval Period:</span>
              <span className="font-bold text-blue-400">{state.timestamp}</span>
            </div>

            {/* Simulation controls */}
            <div className="flex gap-1">
              <button
                onClick={handleAdvanceSimulation}
                disabled={loadingState}
                className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 active:scale-95 transition-all disabled:opacity-50 cursor-pointer shadow-md shadow-blue-500/10 border border-blue-500/20"
                title="Advance simulation by 1 trading interval (5 mins / hourly forecast shift)"
              >
                <Play className="h-3 w-3 fill-white" />
                Advance Interval
              </button>
              <button
                onClick={handleResetSimulation}
                className="bg-slate-900 hover:bg-slate-850 text-slate-300 border border-slate-800 text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 active:scale-95 transition-all cursor-pointer"
                title="Reset simulation variables"
              >
                <RotateCcw className="h-3 w-3" />
                Reset Grid
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* 2. Grid Overview / KPI Banner */}
      <section className="bg-[#0F1115] border-b border-slate-800/80 py-5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            
            <div className="bg-[#0A0A0B] border border-slate-800/80 p-3.5 rounded-xl">
              <div className="text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1">
                Net Regional Gen
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-xl font-bold font-mono text-slate-100">
                  {totalGen.toFixed(1)}
                </span>
                <span className="text-xs text-slate-500 font-bold">MW</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-1">
                Humber Offshores & wind farms
              </div>
            </div>

            <div className="bg-[#0A0A0B] border border-slate-800/80 p-3.5 rounded-xl">
              <div className="text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1">
                Total Grid Load
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-xl font-bold font-mono text-slate-100">
                  {totalDemand.toFixed(1)}
                </span>
                <span className="text-xs text-slate-500 font-bold">MW</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-1">
                Industrial, residential & chargers
              </div>
            </div>

            <div className="bg-[#0A0A0B] border border-slate-800/80 p-3.5 rounded-xl">
              <div className="text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1">
                Average Strike Price
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-xl font-bold font-mono text-emerald-400">
                  £{averageStrikePrice.toFixed(4)}
                </span>
                <span className="text-xs text-slate-500 font-bold">/kWh</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-1">
                Across {state.zones.length} zones
              </div>
            </div>

            <div className="bg-[#0A0A0B] border border-slate-800/80 p-3.5 rounded-xl">
              <div className="text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1">
                Clean Renewable Mix
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-xl font-bold font-mono text-emerald-400">
                  {Math.round(averageRenewable)}%
                </span>
                <span className="text-xs text-slate-500 font-bold">Grid Mix</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-1">
                Average carbon: ~105g/kWh
              </div>
            </div>

            <div className="bg-[#0A0A0B] border border-slate-800/80 p-3.5 rounded-xl col-span-2 md:col-span-1">
              <div className="text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1">
                Local Energy Independence
              </div>
              <div className="flex items-baseline gap-1">
                <span className={`text-xl font-bold font-mono ${leiAverage >= 1.0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {leiAverage.toFixed(2)}
                </span>
                <span className="text-xs text-slate-500 font-bold">LEI Target 1.0</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-1">
                {leiAverage >= 1.0 ? 'Fully Independent' : 'National Grid imports'}
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 3. Primary Tab Selector */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-grow flex flex-col gap-6">
        
        <div className="flex flex-wrap gap-1.5 border-b border-slate-800/80 pb-px">
          {[
            { id: 'grid', label: 'GIS Interactive Grid' },
            { id: 'trading', label: 'Double Auction Trading' },
            { id: 'battery', label: 'Smart Battery Dispatch' },
            { id: 'ai', label: 'AI Grid Advisor Agents' },
            { id: 'code', label: 'R & Rust Code Workspaces' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 text-xs font-bold rounded-t-lg border-t border-x -mb-px transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-[#0F1115] border-slate-800/80 text-blue-400 font-extrabold shadow-xs'
                  : 'bg-transparent border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* --- ACTIVE TAB DISPLAY AREA --- */}

        {activeTab === 'grid' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* GIS Map Canvas (SVG) */}
            <div className="lg:col-span-7 space-y-4">
              <YorkshireMap
                zones={state.zones}
                powerLines={state.powerLines}
                selectedZoneId={selectedZoneId}
                onSelectZone={setSelectedZoneId}
              />
              
              {/* Dynamic Weather Forecasting Block */}
              <div className="bg-[#0F1115] border border-slate-800/80 rounded-xl p-5 shadow-sm">
                <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                  <Sun className="h-4 w-4 text-amber-500" />
                  Meteorological Forecast Node Multipliers
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-medium text-slate-400">
                  <div className="bg-[#0A0A0B] p-3 rounded-lg border border-slate-800/60">
                    <span className="block text-[10px] uppercase font-bold text-slate-500">Solar Insolation</span>
                    <span className="text-sm font-mono text-amber-400 font-bold">510 W/m²</span>
                    <span className="block text-[9px] text-slate-500 mt-1">Solar farms at ~65% power</span>
                  </div>
                  <div className="bg-[#0A0A0B] p-3 rounded-lg border border-slate-800/60">
                    <span className="block text-[10px] uppercase font-bold text-slate-500">Wind Velocity</span>
                    <span className="text-sm font-mono text-blue-400 font-bold">8.5 m/s</span>
                    <span className="block text-[9px] text-slate-500 mt-1">Turbines at optimal torque</span>
                  </div>
                  <div className="bg-[#0A0A0B] p-3 rounded-lg border border-slate-800/60">
                    <span className="block text-[10px] uppercase font-bold text-slate-500">Rain & Hydro flow</span>
                    <span className="text-sm font-mono text-sky-400 font-bold">0.8 mm/h</span>
                    <span className="block text-[9px] text-slate-500 mt-1">Swaledale Hydro reservoir up</span>
                  </div>
                  <div className="bg-[#0A0A0B] p-3 rounded-lg border border-slate-800/60">
                    <span className="block text-[10px] uppercase font-bold text-slate-500">Air Temperature</span>
                    <span className="text-sm font-mono text-slate-300 font-bold">16.5 °C</span>
                    <span className="block text-[9px] text-slate-500 mt-1">Low household heating drag</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Sidebar Tables (Zones & Local Participants list) */}
            <div className="lg:col-span-5 space-y-6">
              {/* Yorkshire REZs Strike Table */}
              <div className="bg-[#0F1115] border border-slate-800/80 rounded-xl p-5 shadow-sm">
                <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider mb-3 flex items-center justify-between">
                  <span>Regional Zone Prices</span>
                  <span className="text-[10px] text-slate-500 normal-case">5m calculate intervals</span>
                </h3>

                <div className="space-y-1.5">
                  {state.zones.map(z => {
                    const isSelected = selectedZoneId === z.id;
                    return (
                      <div
                        key={z.id}
                        onClick={() => setSelectedZoneId(z.id === selectedZoneId ? null : z.id)}
                        className={`p-2.5 rounded-lg border flex items-center justify-between cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-blue-950/40 border-blue-800 ring-1 ring-blue-500/15'
                            : 'bg-[#0A0A0B] border-slate-800/60 hover:border-slate-700/80'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className={`h-2.5 w-2.5 rounded-full ${z.generation > z.demand ? 'bg-emerald-500' : 'bg-sky-500'}`}></span>
                          <span className="text-xs font-bold text-slate-200">{z.name}</span>
                        </div>
                        <div className="flex items-center gap-3 text-right">
                          <div>
                            <span className="text-xs font-mono font-bold text-slate-100">£{z.strikePrice.toFixed(2)}/kWh</span>
                            <span className="block text-[9px] text-slate-500 font-mono">SDR: {(z.generation / z.demand).toFixed(1)}</span>
                          </div>
                          {z.congestionIndex > 0.8 && (
                            <span className="text-[9px] bg-rose-950/50 text-rose-400 border border-rose-900/40 px-1.5 py-0.5 rounded font-bold animate-pulse">
                              Congested
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Participants list */}
              <div className="bg-[#0F1115] border border-slate-800/80 rounded-xl p-5 shadow-sm">
                <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider mb-2 flex items-center justify-between">
                  <span>Registered Smart Meters</span>
                  {selectedZoneId && (
                    <span className="text-[10px] bg-blue-950/40 text-blue-400 px-2 rounded font-bold border border-blue-900/30">
                      {focusedZoneObj?.name} Filter
                    </span>
                  )}
                </h3>
                <p className="text-[10px] text-slate-500 mb-3 leading-normal">
                  Farms, batteries, industrial plants, and local cooperatives trading on YREX
                </p>

                <div className="space-y-2 max-h-[240px] overflow-y-auto pr-1">
                  {filteredParticipants.map(p => (
                    <div key={p.id} className="p-2 border border-slate-800/60 bg-[#0A0A0B] rounded-lg flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-slate-200 flex items-center gap-1">
                          {p.currentPowerKw < 0 ? (
                            <span className="h-1.5 w-1.5 rounded-full bg-blue-500 animate-pulse" />
                          ) : (
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                          )}
                          {p.name}
                        </div>
                        <span className="text-[9px] text-slate-500 font-mono tracking-wide">
                          {p.type.replace('_', ' ').toUpperCase()} • {p.zoneId.replace('_', ' ').toUpperCase()}
                        </span>
                      </div>
                      <div className="text-right font-mono text-[10px] font-bold">
                        {p.currentPowerKw > 0 ? (
                          <span className="text-emerald-400">+{p.currentPowerKw.toLocaleString()} kW</span>
                        ) : p.currentPowerKw < 0 ? (
                          <span className="text-blue-400">{p.currentPowerKw.toLocaleString()} kW</span>
                        ) : (
                          <span className="text-slate-400">standby</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'trading' && (
          <OrderBookSection
            participants={state.participants}
            orderBook={state.orderBook}
            tradesHistory={state.tradesHistory}
            onPlaceOrder={handlePlaceOrder}
            selectedZoneId={selectedZoneId}
            zonePrices={state.zones.reduce((acc, z) => {
              acc[z.id] = z.strikePrice;
              return acc;
            }, {} as Record<string, number>)}
          />
        )}

        {activeTab === 'battery' && (
          <BatteryDispatchPanel
            batteryConfigs={state.batteryConfigs}
            participants={state.participants}
            zonePrices={state.zones.reduce((acc, z) => {
              acc[z.id] = z.strikePrice;
              return acc;
            }, {} as Record<string, number>)}
            onUpdateStrategy={handleUpdateStrategy}
            onManualDispatch={handleManualDispatch}
          />
        )}

        {activeTab === 'ai' && (
          <AiAdvisorPanel
            onGenerateReport={handleGenerateReport}
            activeReport={activeReport}
          />
        )}

        {activeTab === 'code' && (
          <CodeWorkspace />
        )}

      </main>

      {/* 4. Footer */}
      <footer className="bg-[#070708] border-t border-slate-900/80 text-slate-500 text-xs py-6 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-4.5 w-4.5 text-emerald-500" />
            <span className="font-mono text-[11px] tracking-tight">
              YREX Yorkshire Regional Energy Exchange • Authorized Control Cockpit v1.8
            </span>
          </div>
          <div className="flex gap-4 text-slate-500">
            <span className="hover:text-slate-300">Audited Security Rules</span>
            <span className="hover:text-slate-300">Continuous Double Auction Protocol</span>
            <span className="hover:text-slate-300">Grid Code Standard</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
