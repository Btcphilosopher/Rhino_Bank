#' Rhino Bank Portfolio Management Engine
#' @description R6 class representing a structured portfolio, providing aggregation and pricing.

library(R6)

#' @export
PortfolioEngine <- R6::R6Class(
  "PortfolioEngine",
  public = list(
    instruments = NULL, # list of instrument specs
    pricing_engine = NULL, # PricingEngine instance
    
    initialize = function(instruments = list(), pricing_engine = NULL) {
      self.instruments <- instruments
      self.pricing_engine <- pricing_engine
    },
    
    #' @description Price the entire portfolio and aggregate results
    #' @return Data frame of individual positions with NPV, Delta, Gamma, etc.
    evaluate_portfolio = function(val_date = Sys.Date()) {
      if (is.null(self.pricing_engine)) stop("Pricing engine context not set")
      
      results <- list()
      for (i in seq_along(self.instruments)) {
        inst <- self.instruments[[i]]
        eval_res <- tryCatch({
          self.pricing_engine$price(inst, val_date)
        }, error = function(e) {
          list(npv = NA, error = e$message)
        })
        
        results[[i]] <- data.frame(
          ID = inst$id,
          Type = inst$type,
          Currency = inst$currency,
          Notional = inst$nominal,
          NPV = ifelse(is.null(eval_res$npv), NA, eval_res$npv),
          Delta = ifelse(is.null(eval_res$delta), 0, eval_res$delta),
          Gamma = ifelse(is.null(eval_res$gamma), 0, eval_res$gamma),
          Vega = ifelse(is.null(eval_res$vega), 0, eval_res$vega),
          Theta = ifelse(is.null(eval_res$theta), 0, eval_res$theta),
          Rho = ifelse(is.null(eval_res$rho), 0, eval_res$rho),
          stringsAsFactors = FALSE
        )
      }
      
      do.call(rbind, results)
    },
    
    #' @description Get aggregate portfolio-level greeks
    get_portfolio_greeks = function(portfolio_eval_df) {
      list(
        Total_NPV = sum(portfolio_eval_df$NPV, na.rm = TRUE),
        Total_Delta = sum(portfolio_eval_df$Delta * portfolio_eval_df$Notional, na.rm = TRUE),
        Total_Gamma = sum(portfolio_eval_df$Gamma * portfolio_eval_df$Notional, na.rm = TRUE),
        Total_Vega = sum(portfolio_eval_df$Vega * portfolio_eval_df$Notional, na.rm = TRUE),
        Total_Theta = sum(portfolio_eval_df$Theta * portfolio_eval_df$Notional, na.rm = TRUE),
        Total_Rho = sum(portfolio_eval_df$Rho * portfolio_eval_df$Notional, na.rm = TRUE)
      )
    }
  )
)
