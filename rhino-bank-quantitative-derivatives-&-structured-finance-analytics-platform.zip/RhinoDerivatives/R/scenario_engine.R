#' Rhino Bank Macroeconomic Scenario Engine
#' @description Predefined multi-asset stress-testing suites representing historical and hypothetical global crises.

#' @description Generate a complete macro stress scenario context
#' @param base_engine The baseline PricingEngine
#' @param scenario_name "recession", "inflation_surge", "sovereign_crisis"
#' @return A list containing the shocked pricing engine and credit pool adjustments
apply_macro_scenario <- function(base_engine, scenario_name) {
  
  shocked_curves <- list()
  shocked_vols <- list()
  shocked_fx <- base_engine$fx_rates
  
  credit_defaults_multiplier <- 1.0
  credit_lgd_multiplier <- 1.0
  
  if (scenario_name == "recession") {
    # Rates drop (flight to safety), credit spreads widen, equity vol spikes, defaults surge
    for (ccy in names(base_engine$yield_curves)) {
      curve <- base_engine$yield_curves[[ccy]]
      # Shift down short-end, steepen long-end
      shocked_curves[[ccy]] <- stress_yield_curve(curve, "parallel_shift", -50)
    }
    # USD strengthens against EM, EUR drops
    if (!is.null(shocked_fx[["USD_EUR"]])) shocked_fx[["USD_EUR"]] <- shocked_fx[["USD_EUR"]] * 0.90 # USD rises 10%
    
    credit_defaults_multiplier <- 2.5 # Defaults increase 150%
    credit_lgd_multiplier <- 1.2 # Recovery declines (LGD increases 20%)
    
  } else if (scenario_name == "inflation_surge") {
    # Rates spike up dramatically, yield curves flatten
    for (ccy in names(base_engine$yield_curves)) {
      curve <- base_engine$yield_curves[[ccy]]
      shocked_curves[[ccy]] <- stress_yield_curve(curve, "parallel_shift", 150)
    }
    # Vols rise moderately
    credit_defaults_multiplier <- 1.2
    
  } else if (scenario_name == "sovereign_crisis") {
    # Credit spreads widen significantly on corporate/sovereign bonds
    for (ccy in names(base_engine$yield_curves)) {
      curve <- base_engine$yield_curves[[ccy]]
      # Short rates up due to liquidity squeeze, long rates up
      shocked_curves[[ccy]] <- stress_yield_curve(curve, "parallel_shift", 100)
    }
    credit_defaults_multiplier <- 2.0
    credit_lgd_multiplier <- 1.4 # Liquidation recovery drops
    
  } else {
    stop("Unknown macro scenario")
  }
  
  # Create shocked engine
  shocked_engine <- PricingEngine$new(
    yield_curves = shocked_curves,
    vol_surfaces = base_engine$vol_surfaces,
    fx_rates = shocked_fx
  )
  
  list(
    pricing_engine = shocked_engine,
    credit_pd_mult = credit_defaults_multiplier,
    credit_lgd_mult = credit_lgd_multiplier,
    name = scenario_name
  )
}
