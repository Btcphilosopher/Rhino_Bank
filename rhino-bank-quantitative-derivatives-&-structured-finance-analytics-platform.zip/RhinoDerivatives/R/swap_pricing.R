#' Rhino Bank Swap & Fixed Income Pricing Module
#' @description Full-scale pricing models for Interest Rate Swaps (IRS), FRAs, Caps, Floors, and Swaptions.

#' @description Price an Interest Rate Swap (IRS)
#' @param inst List containing swap properties (fixed_rate, nominal, is_payer, floating_spread, payment_freq, maturity_years)
#' @param curve YieldCurve object for discounting and indexing
swap_pricing <- function(inst, curve, val_date) {
  t_maturity <- inst$maturity_years
  freq <- inst$payment_freq # e.g., 2 for semi-annual, 4 for quarterly
  dt <- 1 / freq
  
  payment_times <- seq(dt, t_maturity, by = dt)
  df_times <- sapply(payment_times, function(t) curve$get_discount_factor(t))
  
  # Floating leg pricing using implied forward rates
  # For a simple par swap, floating leg NPV is roughly 1 - DF_maturity (if priced on curve)
  # But we model actual forward rate expectations:
  forward_rates <- numeric(length(payment_times))
  floating_cashflows <- numeric(length(payment_times))
  
  df_prev <- 1
  for (i in seq_along(payment_times)) {
    t_curr <- payment_times[i]
    df_curr <- df_times[i]
    # Implied forward rate
    forward_rates[i] <- (df_prev / df_curr - 1) / dt
    floating_cashflows[i] <- (forward_rates[i] + inst$floating_spread) * inst$nominal * dt
    df_prev <- df_curr
  }
  
  # Fixed leg pricing
  fixed_cashflows <- rep(inst$fixed_rate * inst$nominal * dt, length(payment_times))
  
  # Present values
  pv_fixed_leg <- sum(fixed_cashflows * df_times)
  pv_floating_leg <- sum(floating_cashflows * df_times)
  
  # Payer swap: Pay fixed, receive floating. Receiver: Pay floating, receive fixed.
  direction_multiplier <- if (inst$is_payer) 1 else -1
  npv <- direction_multiplier * (pv_floating_leg - pv_fixed_leg)
  
  # Calculate Fair (Par) Swap Rate: Fixed rate that makes NPV = 0
  sum_annuity_df <- sum(df_times * dt)
  par_swap_rate <- (1 - df_times[length(df_times)]) / sum_annuity_df
  
  list(
    npv = npv,
    pv_fixed_leg = pv_fixed_leg,
    pv_floating_leg = pv_floating_leg,
    par_swap_rate = par_swap_rate,
    annuity = sum_annuity_df,
    payment_times = payment_times,
    discount_factors = df_times
  )
}

#' @description Price a Forward Rate Agreement (FRA)
fra_pricing <- function(inst, curve, val_date) {
  # Inst has: fixing_date, maturity_date, contract_rate, nominal
  t1 <- as.numeric(difftime(inst$fixing_date, val_date, units = "days")) / 365.25
  t2 <- as.numeric(difftime(inst$maturity_date, val_date, units = "days")) / 365.25
  dt <- t2 - t1
  
  if (t1 <= 0) return(list(npv = 0, forward_rate = 0))
  
  df1 <- curve$get_discount_factor(t1)
  df2 <- curve$get_discount_factor(t2)
  
  # Implied forward rate
  forward_rate <- (df1 / df2 - 1) / dt
  
  # FRA payoff is settled at fixing (t1) or maturity (t2)
  # Standard FRA settles at t1 discounted:
  unadjusted_payoff <- (forward_rate - inst$contract_rate) * inst$nominal * dt
  npv <- unadjusted_payoff * df2 # discounted to today
  
  list(
    npv = npv,
    forward_rate = forward_rate,
    t1 = t1,
    t2 = t2,
    dt = dt
  )
}

#' @description Price Interest Rate Caps and Floors
cap_floor_pricing <- function(inst, curve, vol_surface, val_date) {
  # Priced as a portfolio of caplets/floorlets using Black's formula
  t_maturity <- inst$maturity_years
  freq <- inst$payment_freq
  dt <- 1 / freq
  times <- seq(dt, t_maturity, by = dt)
  
  strike <- inst$strike
  nominal <- inst$nominal
  is_cap <- inst$is_cap # TRUE for Cap, FALSE for Floor
  
  df_prev <- 1
  caplet_prices <- numeric(length(times))
  
  for (i in seq_along(times)) {
    t_curr <- times[i]
    df_curr <- curve$get_discount_factor(t_curr)
    
    # Implied forward rate for period i
    fwd <- (df_prev / df_curr - 1) / dt
    
    # Volatility for this tenor and strike
    vol <- vol_surface$get_volatility(t_curr, strike)
    
    # Pricing caplet using Black-76
    t_fixing <- t_curr - dt
    if (t_fixing > 0) {
      d1 <- (log(fwd / strike) + 0.5 * vol^2 * t_fixing) / (vol * sqrt(t_fixing))
      d2 <- d1 - vol * sqrt(t_fixing)
      
      if (is_cap) {
        caplet <- nominal * dt * df_curr * (fwd * pnorm(d1) - strike * pnorm(d2))
      } else {
        caplet <- nominal * dt * df_curr * (strike * pnorm(-d2) - fwd * pnorm(-d1))
      }
      caplet_prices[i] <- caplet
    } else {
      caplet_prices[i] <- 0
    }
    df_prev <- df_curr
  }
  
  list(
    npv = sum(caplet_prices),
    caplet_prices = caplet_prices,
    times = times
  )
}

#' @description Price Bonds (Gov, Corp, Floating Rate Notes)
bond_pricing <- function(inst, curve, val_date) {
  # Inst: type, coupon_rate, frequency, maturity_date, nominal, credit_spread
  t_mat <- as.numeric(difftime(inst$maturity_date, val_date, units = "days")) / 365.25
  if (t_mat <= 0) return(list(npv = 0))
  
  freq <- inst$frequency
  dt <- 1 / freq
  coupon_times <- seq(t_mat %% dt, t_mat, by = dt)
  coupon_times <- coupon_times[coupon_times > 0]
  
  # Calculate discounted cash flows with optional credit spread
  # Yield = Risk_free_rate + Credit_spread
  spread <- if (is.null(inst$credit_spread)) 0 else inst$credit_spread
  
  coupon_pvs <- sapply(coupon_times, function(t) {
    df <- curve$get_discount_factor(t)
    # adjust df for credit spread: df_credit = df * exp(-spread * t)
    df_credit <- df * exp(-spread * t)
    c_cf <- (inst$coupon_rate / freq) * inst$nominal
    c_cf * df_credit
  })
  
  df_mat_credit <- curve$get_discount_factor(t_mat) * exp(-spread * t_mat)
  redemption_pv <- inst$nominal * df_mat_credit
  
  npv <- sum(coupon_pvs) + redemption_pv
  
  # Calculate Duration and Convexity
  # Duration (Macauley & Modified)
  cashflows <- c(rep((inst$coupon_rate / freq) * inst$nominal, length(coupon_times) - 1), 
                 (inst$coupon_rate / freq) * inst$nominal + inst$nominal)
  pvs <- cashflows * sapply(coupon_times, function(t) curve$get_discount_factor(t) * exp(-spread * t))
  
  macaulay_duration <- sum(coupon_times * pvs) / npv
  # simple yield to maturity approximation
  ytm <- -log(curve$get_discount_factor(1)) + spread
  modified_duration <- macaulay_duration / (1 + ytm/freq)
  convexity <- sum(coupon_times^2 * pvs) / npv
  
  list(
    npv = npv,
    pv_coupons = sum(coupon_pvs),
    pv_principal = redemption_pv,
    duration = macaulay_duration,
    mod_duration = modified_duration,
    convexity = convexity,
    ytm = ytm
  )
}
