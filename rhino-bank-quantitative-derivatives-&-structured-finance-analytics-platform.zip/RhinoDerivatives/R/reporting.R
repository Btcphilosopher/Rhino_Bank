#' Rhino Bank Reporting Engine
#' @description Generates institutional PDF-ready risk tables, CSV/JSON extracts, and executive reports.

#' @description Daily Risk Summary Report Generator
#' @param portfolio_results Evaluated portfolio data frame
#' @param var_results List of calculated Value-at-Risk results
#' @param fx_exposures Data frame containing net open FX positions
#' @return A formatted text/csv output or structured table list
generate_daily_risk_report <- function(portfolio_results, var_results, fx_exposures) {
  report_date <- Sys.Date()
  
  cat("======================================================================\n")
  cat("                RHINO BANK DAILY RISK SUMMARY REPORT                 \n")
  cat(paste("Valuation Date:", report_date, "                                    \n"))
  cat("======================================================================\n\n")
  
  # 1. Portfolio Valuation
  total_pv <- sum(portfolio_results$NPV, na.rm = TRUE)
  cat(sprintf("Total Portfolio Net Present Value (NPV): $%s \n", format(total_pv, big.mark = ",")))
  cat("\nPosition Summary:\n")
  print(portfolio_results[, c("ID", "Type", "Currency", "Notional", "NPV")])
  
  # 2. Value at Risk
  cat("\n----------------------------------------------------------------------\n")
  cat("Market Risk Indicators (Value-at-Risk & Expected Shortfall)\n")
  cat("----------------------------------------------------------------------\n")
  cat(sprintf("Parametric VaR (99%%, 1-Day):   $%s\n", format(var_results$parametric$var, big.mark = ",")))
  cat(sprintf("Parametric Expected Shortfall:  $%s\n", format(var_results$parametric$es, big.mark = ",")))
  cat(sprintf("Historical VaR (99%%, 1-Day):    $%s\n", format(var_results$historical$var, big.mark = ",")))
  cat(sprintf("Historical Expected Shortfall:   $%s\n", format(var_results$historical$es, big.mark = ",")))
  
  # 3. FX Net Open Positions
  cat("\n----------------------------------------------------------------------\n")
  cat("Foreign Exchange Net Open Positions (NOP)\n")
  cat("----------------------------------------------------------------------\n")
  print(fx_exposures)
  cat("======================================================================\n")
}

#' @description Export portfolio results to CSV
export_to_csv <- function(df, filename) {
  write.csv(df, filename, row.names = FALSE)
}
