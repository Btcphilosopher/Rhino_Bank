#' Rhino Bank Stress Testing Engine
#' @description Systematic stress-testing and valuation shock analysis on portfolios.

#' @description Stress-test a yield curve
#' @param curve YieldCurve object to shock
#' @param type "parallel_shift", "steepening", "flattening"
#' @param amount Shift in basis points for parallel, or steepen/flatten factor
stress_yield_curve <- function(curve, type = "parallel_shift", amount = 100) {
  shift <- amount / 10000 # bps to decimal
  
  new_rates <- switch(
    type,
    "parallel_shift" = curve.market_rates + shift,
    "steepening" = {
      # Shift tenors proportionally: short-term rates shift less, long-term shift more
      curve$market_rates + shift * (curve$tenors / max(curve$tenors))
    },
    "flattening" = {
      # Long-term rates shift less or down, short-term shift up
      curve$market_rates + shift * (1 - curve$tenors / max(curve$tenors))
    },
    stop("Unknown stress type")
  )
  
  YieldCurve$new(
    currency = curve$currency,
    reference_date = curve$reference_date,
    tenors = curve$tenors,
    market_rates = new_rates,
    interpolation = curve$interpolation
  )
}

#' @description Multi-asset shock scenario
#' @param fx_shocks Named list of percentage changes (e.g., list(EUR_USD = -0.15))
#' @param vol_shocks Absolute percentage change in volatilities (e.g., +0.05)
stress_market_context <- function(pricing_engine, fx_shocks = list(), vol_shocks = 0) {
  # Create a cloned PricingEngine with shocked spot rates and volatility grids
  shocked_rates <- pricing_engine$fx_rates
  for (pair in names(fx_shocks)) {
    if (!is.null(shocked_rates[[pair]])) {
      shocked_rates[[pair]] <- shocked_rates[[pair]] * (1 + fx_shocks[[pair]])
    }
  }
  
  # Return updated PricingEngine
  PricingEngine$new(
    yield_curves = pricing_engine$yield_curves,
    vol_surfaces = pricing_engine$vol_surfaces, # Shock vols inside vol_surfaces if desired
    fx_rates = shocked_rates
  )
}
