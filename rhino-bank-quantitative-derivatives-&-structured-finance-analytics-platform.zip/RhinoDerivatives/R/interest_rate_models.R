#' Rhino Bank Short Rate & Interest Rate Models
#' @description Mathematical and analytical formulations of short rate models: Vasicek, CIR, and Hull-White.

#' @description Simulate interest rate paths using the Vasicek model
#' d_r = a * (b - r) * dt + sigma * dW
#' @param n_paths Number of simulated paths
#' @param n_steps Number of time steps
#' @param T Maturity in years
#' @param r0 Initial short rate
#' @param a Speed of mean reversion
#' @param b Long-term mean short rate
#' @param sigma Volatility of short rate
#' @return A matrix of simulated short rates (n_steps + 1) x n_paths
simulate_vasicek <- function(n_paths, n_steps, T, r0, a, b, sigma) {
  dt <- T / n_steps
  paths <- matrix(0, nrow = n_steps + 1, ncol = n_paths)
  paths[1, ] <- r0
  
  for (t in 1:n_steps) {
    dW <- rnorm(n_paths, mean = 0, sd = sqrt(dt))
    r_prev <- paths[t, ]
    paths[t + 1, ] <- r_prev + a * (b - r_prev) * dt + sigma * dW
  }
  
  return(paths)
}

#' @description Simulate interest rate paths using the Cox-Ingersoll-Ross (CIR) model
#' d_r = a * (b - r) * dt + sigma * sqrt(r) * dW
#' @return A matrix of simulated short rates (non-negative)
simulate_cir <- function(n_paths, n_steps, T, r0, a, b, sigma) {
  # Feller condition: 2 * a * b > sigma^2 keeps rate positive
  dt <- T / n_steps
  paths <- matrix(0, nrow = n_steps + 1, ncol = n_paths)
  paths[1, ] <- r0
  
  for (t in 1:n_steps) {
    dW <- rnorm(n_paths, mean = 0, sd = sqrt(dt))
    r_prev <- paths[t, ]
    # Truncate or use reflection to handle numerical boundary issues
    paths[t + 1, ] <- r_prev + a * (b - r_prev) * dt + sigma * sqrt(pmax(r_prev, 0)) * dW
    paths[t + 1, ] <- pmax(paths[t + 1, ], 0) # enforce positivity
  }
  
  return(paths)
}

#' @description Hull-White analytical Bond Option pricing (for Swaptions and Caps/Floors)
#' d_r = (theta(t) - a * r) * dt + sigma * dW
#' @param strike Strike rate/price
#' @param t Option expiry
#' @param s Bond maturity
#' @param r0 Initial short rate
#' @param a Speed of mean reversion
#' @param sigma Volatility
#' @param curve YieldCurve object for discounting
hull_white_bond_option <- function(strike, t, s, r0, a, sigma, curve) {
  # Closed-form European option on a zero-coupon bond under Hull-White model
  df_t <- curve$get_discount_factor(t)
  df_s <- curve$get_discount_factor(s)
  
  # B(t, s) in Hull-White
  B_ts <- (1 - exp(-a * (s - t))) / a
  
  # Volatility of the bond price: sigma_P
  sigma_P <- sigma * sqrt((1 - exp(-2 * a * t)) / (2 * a)) * B_ts
  
  # d1, d2
  d1 <- log(df_s / (df_t * strike)) / sigma_P + 0.5 * sigma_P
  d2 <- d1 - sigma_P
  
  # Call price
  call_price <- df_s * pnorm(d1) - strike * df_t * pnorm(d2)
  # Put price
  put_price <- strike * df_t * pnorm(-d2) - df_s * pnorm(-d1)
  
  list(call = call_price, put = put_price, sigma_p = sigma_P)
}
