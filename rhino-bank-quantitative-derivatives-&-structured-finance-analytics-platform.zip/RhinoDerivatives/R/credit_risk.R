#' Rhino Bank Credit Risk Engine
#' @description Computes counterparty risk, Potential Future Exposure (PFE), and Credit Valuation Adjustment (CVA).

#' @description Compute Credit Valuation Adjustment (CVA)
#' CVA = (1 - R) * sum_{i} DF(t_i) * EE(t_i) * PD(t_{i-1}, t_i)
#' @param expected_exposures Vector of expected exposures (EE) at grid dates
#' @param discount_factors Vector of discount factors at grid dates
#' @param marginal_pds Vector of marginal default probabilities between grid dates
#' @param recovery_rate Recovery rate (0 to 1, e.g., 0.4 for corporate bonds)
compute_cva <- function(expected_exposures, discount_factors, marginal_pds, recovery_rate = 0.4) {
  loss_given_default <- 1 - recovery_rate
  
  # CVA summation
  cva_terms <- expected_exposures * discount_factors * marginal_pds
  total_cva <- loss_given_default * sum(cva_terms)
  
  list(
    cva = total_cva,
    contributions = loss_given_default * cva_terms
  )
}

#' @description Calculate Potential Future Exposure (PFE) at a given percentile
#' @param exposure_paths Matrix of simulated exposure paths (steps x paths)
#' @param percentile Confidence level (typically 0.95 or 0.975)
compute_pfe <- function(exposure_paths, percentile = 0.95) {
  # For each time step, calculate the quantile of exposure
  pfe_curve <- apply(exposure_paths, 1, function(step_exp) {
    quantile(step_exp, probs = percentile)
  })
  
  expected_exposure <- apply(exposure_paths, 1, mean)
  maximum_pfe <- max(pfe_curve)
  
  list(
    pfe_curve = pfe_curve,
    expected_exposure = expected_exposure,
    max_pfe = maximum_pfe
  )
}
