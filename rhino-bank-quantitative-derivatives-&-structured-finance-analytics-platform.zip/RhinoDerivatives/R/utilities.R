#' Rhino Bank Quantitative Utilities
#' @description General utilities, math helpers, and date adjustments for the analytics engine.

#' @description Normal cumulative density function approximation (fast, if pnorm is slow)
fast_norm_cdf <- function(x) {
  pnorm(x)
}

#' @description Check if a year is a leap year
is_leap_year <- function(year) {
  (year %% 4 == 0 & year %% 100 != 0) | (year %% 400 == 0)
}

#' @description Financial rounding to standard basis points or decimal limits
round_bps <- function(rate) {
  round(rate * 10000, 2)
}

#' @description Test suite initialization
run_rhino_unit_tests <- function() {
  # Standard testthat container runner
  if (requireNamespace("testthat", quietly = TRUE)) {
    testthat::test_dir("tests")
  } else {
    warning("package 'testthat' is not installed. Skipping automated tests.")
  }
}
