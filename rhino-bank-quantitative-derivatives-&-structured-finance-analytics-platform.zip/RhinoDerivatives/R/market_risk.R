#' Rhino Bank Market Risk Management Engine
#' @description Computes Value-at-Risk (VaR) and Expected Shortfall (ES) under multiple methodologies.

#' @description Parametric (Variance-Covariance) Value-at-Risk
#' @param holdings Numeric vector of asset weights or dollar allocations
#' @param cov_matrix Covariance matrix of asset returns
#' @param confidence Confidence level (e.g., 0.95 or 0.99)
#' @param holding_period Holding period in days (typically 1 or 10)
parametric_var <- function(holdings, cov_matrix, confidence = 0.99, holding_period = 1) {
  # Portfolio variance = w^T * Cov * w
  port_variance <- as.numeric(t(holdings) %*% cov_matrix %*% holdings)
  port_sd <- sqrt(port_variance)
  
  # Scaling for holding period
  scaled_sd <- port_sd * sqrt(holding_period)
  
  # Quantile of normal distribution
  z_score <- qnorm(confidence)
  
  var_value <- z_score * scaled_sd
  
  # Expected Shortfall (ES) for normal distribution:
  # ES = alpha^-1 * sigma * phi(z_alpha)
  es_value <- (dnorm(z_score) / (1 - confidence)) * scaled_sd
  
  list(
    var = var_value,
    es = es_value,
    sd = scaled_sd,
    z_score = z_score
  )
}

#' @description Historical Simulation Value-at-Risk
#' @param historical_pnl Vector of historical daily profit-and-loss (P&L) values
#' @param confidence Confidence level (e.g., 0.95 or 0.99)
historical_var <- function(historical_pnl, confidence = 0.99) {
  sorted_pnl <- sort(historical_pnl)
  n <- length(sorted_pnl)
  
  # Index representing the loss threshold
  idx <- round((1 - confidence) * n)
  idx <- max(1, idx)
  
  var_value <- -sorted_pnl[idx] # expressed as positive loss
  
  # Expected Shortfall: Average of all losses exceeding VaR
  exceeding_losses <- sorted_pnl[1:idx]
  es_value <- -mean(exceeding_losses)
  
  list(
    var = var_value,
    es = es_value
  )
}

#' @description Monte Carlo simulation-based Value-at-Risk
#' @param simulated_pnl Matrix of simulated P&L paths
#' @param confidence Confidence level
monte_carlo_var <- function(simulated_pnl, confidence = 0.99) {
  historical_var(simulated_pnl, confidence)
}
