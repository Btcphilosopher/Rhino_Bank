#' Rhino Bank Yield Curve & Bootstrap Module
#' @description Handles curve representation, zero rates interpolation, and bootstrapping.

library(R6)

#' @export
YieldCurve <- R6::R6Class(
  "YieldCurve",
  public = list(
    currency = NULL,
    reference_date = NULL,
    tenors = NULL,      # e.g., c(1/12, 3/12, 6/12, 1, 2, 5, 10, 30)
    market_rates = NULL, # Market yield values
    interpolation = NULL, # "linear", "spline", or "nss"
    nss_params = NULL,   # Nelson-Siegel-Svensson parameters: beta0, beta1, beta2, beta3, tau1, tau2
    
    initialize = function(currency, reference_date, tenors, market_rates, interpolation = "linear") {
      self.currency <- currency
      self.reference_date <- as.Date(reference_date)
      self.tenors <- tenors
      self.market_rates <- market_rates
      self.interpolation <- interpolation
      
      if (interpolation == "nss") {
        self$calibrate_nss()
      }
    },
    
    #' @description Get the discount factor for a given tenor
    #' @param t Time in years (numeric vector)
    get_discount_factor = function(t) {
      r <- self$get_zero_rate(t)
      exp(-r * t)
    },
    
    #' @description Get the zero rate for a given tenor
    #' @param t Time in years (numeric vector)
    get_zero_rate = function(t) {
      # Handle t = 0 to prevent division by zero or log errors
      t <- pmax(t, 1e-6)
      
      if (self.interpolation == "linear") {
        approx(self.tenors, self.market_rates, xout = t, rule = 2)$y
      } else if (self.interpolation == "spline") {
        spline(self.tenors, self.market_rates, xout = t)$y
      } else if (self.interpolation == "nss") {
        self$nss_formula(t, self.nss_params)
      } else {
        stop("Unsupported interpolation method")
      }
    },
    
    nss_formula = function(t, p) {
      # Nelson-Siegel-Svensson equation
      # p = c(beta0, beta1, beta2, beta3, tau1, tau2)
      b0 <- p[1]; b1 <- p[2]; b2 <- p[3]; b3 <- p[4]; tau1 <- p[5]; tau2 <- p[6]
      
      term1 <- (1 - exp(-t / tau1)) / (t / tau1)
      term2 <- term1 - exp(-t / tau1)
      term3 <- (1 - exp(-t / tau2)) / (t / tau2) - exp(-t / tau2)
      
      b0 + b1 * term1 + b2 * term2 + b3 * term3
    },
    
    calibrate_nss = function() {
      # Objective function: minimize squared errors between market rates and NSS curve
      obj_fn <- function(p) {
        if (p[5] <= 0 || p[6] <= 0) return(1e10) # Tau constraints
        predicted <- self$nss_formula(self.tenors, p)
        sum((predicted - self.market_rates)^2)
      }
      
      # Initial guess
      start_p <- c(
        beta0 = tail(self.market_rates, 1),
        beta1 = self.market_rates[1] - tail(self.market_rates, 1),
        beta2 = 0,
        beta3 = 0,
        tau1 = 1.0,
        tau2 = 5.0
      )
      
      opt <- optim(start_p, obj_fn, method = "Nelder-Mead", control = list(maxit = 2000))
      self.nss_params <- opt$par
    },
    
    #' @description Bootstrap a curve from money market, FRA, and Swap instruments
    #' @param instruments list of market instruments
    bootstrap = function(instruments) {
      # Quick placeholder representation for bootstrapping logic
      # Real production systems iteratively solve for zero rates that price swaps to par.
      sorted_inst <- instruments[order(sapply(instruments, function(x) x$maturity))]
      # Simple bootstrap loop
      # t_prev <- 0
      # df_prev <- 1
      # ...
      # This calibrates the 'market_rates' zero rates vector based on par swap rates
    }
  )
)
