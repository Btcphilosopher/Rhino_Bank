#' Rhino Bank Cashflow Generation & Day Count Module
#' @description Projection engine for coupon calendars, amortization tables, and cashflow schedules.

#' @description Calculate fraction of year between two dates based on day-count convention
#' @param start_date Date
#' @param end_date Date
#' @param convention "ACT/365", "ACT/360", "30/360"
calculate_year_fraction <- function(start_date, end_date, convention = "ACT/365") {
  start <- as.Date(start_date)
  end <- as.Date(end_date)
  days <- as.numeric(end - start)
  
  if (convention == "ACT/365") {
    return(days / 365.25)
  } else if (convention == "ACT/360") {
    return(days / 360)
  } else if (convention == "30/360") {
    # US 30/360 algorithm
    d1 <- as.numeric(format(start, "%d"))
    d2 <- as.numeric(format(end, "%d"))
    m1 <- as.numeric(format(start, "%m"))
    m2 <- as.numeric(format(end, "%m"))
    y1 <- as.numeric(format(start, "%Y"))
    y2 <- as.numeric(format(end, "%Y"))
    
    if (d1 == 31) d1 <- 30
    if (d2 == 31 && d1 >= 30) d2 <- 30
    
    return( (360 * (y2 - y1) + 30 * (m2 - m1) + (d2 - d1)) / 360 )
  } else {
    stop("Unsupported day-count convention")
  }
}

#' @description Project cashflows for a standard fixed bond
#' @return Data frame of projected coupon and principal payments
project_bond_cashflows <- function(nominal, coupon_rate, frequency, maturity_date, issue_date, day_count = "ACT/365") {
  issue <- as.Date(issue_date)
  maturity <- as.Date(maturity_date)
  total_years <- as.numeric(difftime(maturity, issue, units = "days")) / 365.25
  
  n_payments <- round(total_years * frequency)
  payment_dates <- seq(issue, maturity, length.out = n_payments + 1)[-1]
  
  cashflows <- data.frame(
    PaymentDate = payment_dates,
    Coupon = (coupon_rate / frequency) * nominal,
    Principal = 0,
    TotalCashflow = (coupon_rate / frequency) * nominal
  )
  
  # Final principal payment
  cashflows$Principal[nrow(cashflows)] <- nominal
  cashflows$TotalCashflow[nrow(cashflows)] <- cashflows$Coupon[nrow(cashflows)] + nominal
  
  cashflows
}
