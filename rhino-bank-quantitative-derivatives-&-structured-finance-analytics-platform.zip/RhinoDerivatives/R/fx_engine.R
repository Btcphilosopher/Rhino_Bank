#' Rhino Bank Foreign Exchange Engine
#' @description Handles spot FX, forwards, cross-currency curves, CIP/UIP parity checks, and carry analysis.

#' @description Price an FX Forward
#' @param inst FX Forward specifications: maturity (t), domestic_ccy, foreign_ccy, strike_forward, notionals
#' @param dom_curve YieldCurve for domestic currency
#' @param for_curve YieldCurve for foreign currency
#' @param spot Spot rate (domestic/foreign, i.e., units of domestic currency per 1 unit of foreign)
#' @param val_date Valuation date
fx_forward_pricing <- function(inst, dom_curve, for_curve, spot, val_date) {
  t <- as.numeric(difftime(inst$maturity_date, val_date, units = "days")) / 365.25
  if (t <= 0) {
    return(list(npv = 0, fair_forward = spot, discount_dom = 1, discount_for = 1))
  }
  
  df_dom <- dom_curve$get_discount_factor(t)
  df_for <- for_curve$get_discount_factor(t)
  
  # Fair Forward Rate by Covered Interest Parity (CIP)
  fair_forward <- spot * (df_for / df_dom)
  
  # Forward premium / discount
  premium_bps <- (fair_forward / spot - 1) * 10000
  
  # NPV from long foreign / short domestic perspective
  # NPV = N_for * df_for * spot - N_dom * df_dom
  npv <- inst$notional_foreign * df_for * spot - inst$notional_domestic * df_dom
  
  list(
    npv = npv,
    fair_forward = fair_forward,
    premium_bps = premium_bps,
    df_dom = df_dom,
    df_for = df_for,
    t = t
  )
}

#' @description FX Swap pricing (Combined spot and forward leg)
fx_swap_pricing <- function(inst, dom_curve, for_curve, spot, val_date) {
  # Inst has two legs: Near Leg (Spot) and Far Leg (Forward)
  near_t <- as.numeric(difftime(inst$near_date, val_date, units = "days")) / 365.25
  far_t <- as.numeric(difftime(inst$far_date, val_date, units = "days")) / 365.25
  
  # Fair forward rate for far leg
  df_dom_far <- dom_curve$get_discount_factor(far_t)
  df_for_far <- for_curve$get_discount_factor(far_t)
  fair_forward_far <- spot * (df_for_far / df_dom_far)
  
  # NPV is the sum of discounted cash flows for near and far legs
  # Near leg is priced using near spot rate or near swap rate
  # Far leg is priced using the far swap rate vs. actual swap strike
  near_npv <- inst$notional_foreign_near * spot - inst$notional_domestic_near
  far_npv <- (inst$notional_foreign_far * for_curve$get_discount_factor(far_t) * spot) - 
             (inst$notional_domestic_far * dom_curve$get_discount_factor(far_t))
  
  list(
    npv = near_npv + far_npv,
    fair_forward_far = fair_forward_far,
    near_t = near_t,
    far_t = far_t
  )
}

#' @description Check CIP and UIP (Interest Rate Parity checks)
#' @return Data frame comparing market forward rates to implied theoretical curves
check_interest_rate_parity <- function(spot, dom_rates, for_rates, tenors) {
  data.frame(
    Tenor = tenors,
    Spot = spot,
    DomRate = dom_rates,
    ForRate = for_rates,
    TheoreticalForward = spot * ( (1 + dom_rates * tenors) / (1 + for_rates * tenors) ),
    CIP_Premium_Bps = (( ( (1 + dom_rates * tenors) / (1 + for_rates * tenors) ) - 1) * 10000)
  )
}

#' @description Aggregate FX exposures and calculate hedge effectiveness
#' @param portfolio Dataframe of FX positions (notional, currency, spot)
#' @param hedges Dataframe of FX hedges
analyze_fx_exposure <- function(portfolio, hedges) {
  # Net open positions (NOP) per currency
  ccy_exposures <- aggregate(Notional ~ Currency, data = portfolio, sum)
  ccy_hedges <- aggregate(Notional ~ Currency, data = hedges, sum)
  
  m <- merge(ccy_exposures, ccy_hedges, by = "Currency", all = TRUE, suffixes = c("_Gross", "_Hedge"))
  m[is.na(m)] <- 0
  m$Net_Exposure <- m$Notional_Gross + m$Notional_Hedge # assuming hedge is opposite sign
  m$Hedge_Ratio <- abs(m$Notional_Hedge / m$Notional_Gross)
  
  m
}
