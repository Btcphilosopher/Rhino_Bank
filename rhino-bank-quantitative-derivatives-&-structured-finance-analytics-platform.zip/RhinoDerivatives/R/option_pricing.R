#' Rhino Bank Derivative Option Pricing Module
#' @description Implements analytical (Black-Scholes-Merton, Garman-Kohlhagen) and numerical (Binomial Tree) option models.

#' @description Black-Scholes-Merton pricing for Vanilla European Options
#' @param inst List: strike, maturity_date, is_call, underlying_spot, dividend_yield
#' @param curve YieldCurve object for discounting
#' @param vol_surface VolatilitySurface object
option_pricing <- function(inst, curve, vol_surface, val_date) {
  s <- inst$underlying_spot
  k <- inst$strike
  t <- as.numeric(difftime(inst$maturity_date, val_date, units = "days")) / 365.25
  
  if (t <= 0) {
    payoff <- if (inst$is_call) max(s - k, 0) else max(k - s, 0)
    return(list(npv = payoff, delta = 0, gamma = 0, vega = 0, theta = 0, rho = 0))
  }
  
  r <- -log(curve$get_discount_factor(t)) / t
  q <- if (is.null(inst$dividend_yield)) 0 else inst$dividend_yield
  sig <- vol_surface$get_volatility(t, k)
  
  d1 <- (log(s / k) + (r - q + 0.5 * sig^2) * t) / (sig * sqrt(t))
  d2 <- d1 - sig * sqrt(t)
  
  if (inst$is_call) {
    npv <- s * exp(-q * t) * pnorm(d1) - k * exp(-r * t) * pnorm(d2)
    delta <- exp(-q * t) * pnorm(d1)
    rho <- k * t * exp(-r * t) * pnorm(d2)
  } else {
    npv <- k * exp(-r * t) * pnorm(-d2) - s * exp(-q * t) * pnorm(-d1)
    delta <- exp(-q * t) * (pnorm(d1) - 1)
    rho <- -k * t * exp(-r * t) * pnorm(-d2)
  }
  
  # Gamma, Vega, Theta are independent of call/put
  gamma <- exp(-q * t) * dnorm(d1) / (s * sig * sqrt(t))
  vega <- s * exp(-q * t) * sqrt(t) * dnorm(d1) # Vega per 100% vol
  
  theta_term1 <- -(s * sig * exp(-q * t) * dnorm(d1)) / (2 * sqrt(t))
  theta_term2 <- q * s * exp(-q * t) * pnorm(d1 * (if (inst$is_call) 1 else -1))
  theta_term3 <- r * k * exp(-r * t) * pnorm(d2 * (if (inst$is_call) 1 else -1))
  
  theta <- (theta_term1 + (if (inst$is_call) -1 else 1) * theta_term2 + (if (inst$is_call) -1 else 1) * theta_term3) / 365.25 # Theta per day
  
  list(
    npv = npv,
    delta = delta,
    gamma = gamma,
    vega = vega / 100, # normalized per 1% vol change
    theta = theta,
    rho = rho / 100, # normalized per 1% (100 bps) interest rate change
    implied_vol = sig,
    d1 = d1,
    d2 = d2
  )
}

#' @description Binomial Tree model for American Options
#' @param steps Number of binomial steps
binomial_american_pricing <- function(inst, curve, vol_surface, val_date, steps = 100) {
  s <- inst$underlying_spot
  k <- inst$strike
  t <- as.numeric(difftime(inst$maturity_date, val_date, units = "days")) / 365.25
  
  if (t <= 0) {
    return(if (inst$is_call) max(s - k, 0) else max(k - s, 0))
  }
  
  r <- -log(curve$get_discount_factor(t)) / t
  q <- if (is.null(inst$dividend_yield)) 0 else inst$dividend_yield
  sig <- vol_surface$get_volatility(t, k)
  
  dt <- t / steps
  u <- exp(sig * sqrt(dt))
  d <- 1 / u
  p <- (exp((r - q) * dt) - d) / (u - d)
  disc <- exp(-r * dt)
  
  # Initialize stock price tree
  s_tree <- numeric(steps + 1)
  for (i in 0:steps) {
    s_tree[i + 1] <- s * (u^(steps - i)) * (d^i)
  }
  
  # Option values at maturity
  v_tree <- numeric(steps + 1)
  if (inst$is_call) {
    v_tree <- pmax(s_tree - k, 0)
  } else {
    v_tree <- pmax(k - s_tree, 0)
  }
  
  # Backward induction
  for (j in (steps - 1):0) {
    for (i in 0:j) {
      s_curr <- s * (u^(j - i)) * (d^i)
      hold <- (p * v_tree[i + 1] + (1 - p) * v_tree[i + 2]) * disc
      
      # American exercise check
      early_exercise <- if (inst$is_call) max(s_curr - k, 0) else max(k - s_curr, 0)
      v_tree[i + 1] <- max(hold, early_exercise)
    }
  }
  
  v_tree[1]
}
