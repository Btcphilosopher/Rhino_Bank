#' Rhino Bank Volatility & SABR Modeling Module
#' @description Implements SABR calibration, implied vol mapping, and cubic spline volatility surface representation.

library(R6)

#' @export
VolatilitySurface <- R6::R6Class(
  "VolatilitySurface",
  public = list(
    reference_date = NULL,
    tenors = NULL,      # Numeric tenors (years)
    strikes = NULL,     # Numeric strikes
    vol_grid = NULL,    # Matrix of volatilities (tenors x strikes)
    
    initialize = function(reference_date, tenors, strikes, vol_grid) {
      self.reference_date <- as.Date(reference_date)
      self.tenors <- tenors
      self.strikes <- strikes
      self.vol_grid <- vol_grid
    },
    
    #' @description Bilinear or bicubic interpolation on the volatility surface
    #' @param t Tenor (years)
    #' @param k Strike price or moneyness
    get_volatility = function(t, k) {
      # Fallback boundary checks
      t <- max(min(t, max(self.tenors)), min(self.tenors))
      k <- max(min(k, max(self.strikes)), min(self.strikes))
      
      # Simple 2D bilinear interpolation
      t_idx <- findInterval(t, self.tenors)
      t_idx <- max(1, min(t_idx, length(self.tenors) - 1))
      
      k_idx <- findInterval(k, self.strikes)
      k_idx <- max(1, min(k_idx, length(self.strikes) - 1))
      
      # Interpolation coordinates
      t0 <- self.tenors[t_idx]; t1 <- self.tenors[t_idx + 1]
      k0 <- self.strikes[k_idx]; k1 <- self.strikes[k_idx + 1]
      
      v00 <- self.vol_grid[t_idx, k_idx]
      v01 <- self.vol_grid[t_idx, k_idx + 1]
      v10 <- self.vol_grid[t_idx + 1, k_idx]
      v11 <- self.vol_grid[t_idx + 1, k_idx + 1]
      
      # Normalize
      dt <- (t - t0) / (t1 - t0)
      dk <- (k - k0) / (k1 - k0)
      
      # Interp along strikes
      v_t0 <- v00 * (1 - dk) + v01 * dk
      v_t1 <- v10 * (1 - dk) + v11 * dk
      
      # Interp along tenors
      v_t0 * (1 - dt) + v_t1 * dt
    },
    
    #' @description Analytical SABR Volatility formula
    #' @param f Forward rate/price
    #' @param k Strike price
    #' @param t Tenor (years)
    #' @param alpha Volatility of volatility
    #' @param beta Elasticity parameter (typically 0.5 for rates, 1.0 for lognormal)
    #' @param rho Correlation between asset and volatility
    #' @param nu Vol-of-vol scaling
    sabr_vol = function(f, k, t, alpha, beta, rho, nu) {
      if (f == k) {
        # At-the-money formula
        num <- alpha * (1 - beta)^2 * t / 24 + rho * beta * alpha * nu * t / 4 + (2 - 3 * rho^2) * nu^2 * t / 24
        return(alpha * f^(beta - 1) * (1 + num))
      }
      
      fk <- f * k
      log_fk <- log(f / k)
      
      # Helper terms
      z <- (nu / alpha) * (fk)^((1 - beta) / 2) * log_fk
      x_z <- log((sqrt(1 - 2 * rho * z + z^2) + z - rho) / (1 - rho))
      
      denom1 <- (fk)^((1 - beta) / 2) * (1 + (1 - beta)^2 / 24 * log_fk^2 + (1 - beta)^4 / 1920 * log_fk^4)
      num1 <- z / x_z
      
      term2 <- 1 + ( (1 - beta)^2 / 24 * alpha^2 / (fk)^(1 - beta) + 0.25 * (rho * beta * nu * alpha) / (fk)^((1 - beta) / 2) + (2 - 3 * rho^2) / 24 * nu^2 ) * t
      
      alpha * num1 * term2 / denom1
    }
  )
)
