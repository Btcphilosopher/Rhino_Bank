#' Rhino Bank Structured Credit Analytics
#' @description Modeling tranche waterfalls, credit enhancement, collateral pool default distributions, and expected loss.

#' @description R6 Collateral Pool representation
#' @import R6
library(R6)

#' @export
CollateralPool <- R6::R6Class(
  "CollateralPool",
  public = list(
    assets = NULL, # list of assets with notional, PD (default prob), LGD (loss given default)
    size = NULL,
    
    initialize = function(assets = list()) {
      self.assets <- assets
      self.size <- length(assets)
    },
    
    get_total_notional = function() {
      sum(sapply(self.assets, function(x) x$notional))
    },
    
    get_weighted_pd = function() {
      notionals <- sapply(self.assets, function(x) x$notional)
      pds <- sapply(self.assets, function(x) x$pd)
      sum(notionals * pds) / sum(notionals)
    },
    
    get_weighted_lgd = function() {
      notionals <- sapply(self.assets, function(x) x$notional)
      lgds <- sapply(self.assets, function(x) x$lgd)
      sum(notionals * lgds) / sum(notionals)
    },
    
    #' @description Compute the analytical or simulated loss distribution of the collateral pool
    #' using a single-factor Gaussian Copula (Vasicek Model)
    #' @param correlation Asset pairwise correlation (constant assumption)
    #' @param confidence_levels vector of percentiles (e.g., c(0.95, 0.99))
    compute_loss_distribution = function(correlation, confidence_levels = c(0.95, 0.99)) {
      total_n <- self$get_total_notional()
      w_pd <- self$get_weighted_pd()
      w_lgd <- self$get_weighted_lgd()
      
      # Vasicek credit loss distribution: P(Loss <= x)
      # For a large homogeneous portfolio:
      # Loss_p(y) = LGD * Phi( (Phi^-1(PD) - sqrt(rho) * y) / sqrt(1 - rho) )
      # where y is the standard normal systematic market factor
      
      # VaR and Expected Shortfall under Vasicek Large Homogeneous Portfolio (LHP)
      var_losses <- sapply(confidence_levels, function(alpha) {
        y <- qnorm(1 - alpha) # systematic factor at alpha percentile
        loss_pct <- w_lgd * pnorm( (qnorm(w_pd) - sqrt(correlation) * y) / sqrt(1 - correlation) )
        loss_pct * total_n
      })
      
      names(var_losses) <- paste0("VaR_", confidence_levels * 100, "%")
      
      # Concentration analysis (Herfindahl-Hirschman Index based on Notional)
      notionals <- sapply(self.assets, function(x) x$notional)
      shares <- notionals / sum(notionals)
      hxi <- sum(shares^2)
      
      list(
        total_notional = total_n,
        weighted_pd = w_pd,
        weighted_lgd = w_lgd,
        var_losses = var_losses,
        hhi = hxi,
        effective_num_assets = 1 / hxi
      )
    }
  )
)

#' @description CDO Tranche Waterfall calculation
#' @param collateral_loss Numeric scalar representing the actual dollar loss in the pool
#' @param tranche_structure List of tranches with name, attachment, detachment, and current principal
#' @return List of updated tranches with written-down principal, loss allocated, and credit enhancement
apply_tranche_waterfall <- function(collateral_loss, tranche_structure) {
  # Sort tranches by attachment point (subordination hierarchy: Equity -> Mezzanine -> Senior)
  tranches <- tranche_structure[order(sapply(tranche_structure, function(x) x$attachment))]
  
  total_loss <- collateral_loss
  updated_tranches <- list()
  
  for (i in seq_along(tranches)) {
    tr <- tranches[[i]]
    notional <- tr$notional
    attach_dt <- tr$detachment - tr$attachment
    attach_loss_threshold <- tr$attachment * tr$pool_notional
    detach_loss_threshold <- tr$detachment * tr$pool_notional
    
    # Calculate allocated loss to this specific tranche
    tr_loss <- 0
    if (total_loss > attach_loss_threshold) {
      tr_loss <- min(total_loss - attach_loss_threshold, detach_loss_threshold - attach_loss_threshold)
    }
    
    remaining_notional <- max(notional - tr_loss, 0)
    loss_fraction <- tr_loss / notional
    
    # Credit enhancement is the ratio of sub-tranches that absorb losses first
    # This is roughly equal to the attachment point
    credit_enhancement <- tr$attachment
    
    updated_tranches[[tr$name]] <- list(
      name = tr$name,
      attachment = tr$attachment,
      detachment = tr$detachment,
      original_notional = notional,
      loss_allocated = tr_loss,
      remaining_notional = remaining_notional,
      loss_percentage = loss_fraction * 100,
      credit_enhancement = credit_enhancement
    )
  }
  
  updated_tranches
}
