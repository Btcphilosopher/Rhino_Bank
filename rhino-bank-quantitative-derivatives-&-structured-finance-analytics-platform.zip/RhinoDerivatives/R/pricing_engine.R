#' Rhino Bank Quantitative Derivatives Pricing Engine
#' @description Core R6 dispatcher for institutional derivative and fixed-income valuation.
#' @import R6
#' @import data.table

library(R6)

#' @export
PricingEngine <- R6::R6Class(
  "PricingEngine",
  public = list(
    yield_curves = NULL,
    vol_surfaces = NULL,
    fx_rates = NULL,
    
    #' @description Initialize Pricing Engine with market data context
    #' @param yield_curves List of YieldCurve objects
    #' @param vol_surfaces List of VolatilitySurface objects
    #' @param fx_rates Named numeric vector of spot FX rates (e.g., USD_EUR = 0.92)
    initialize = function(yield_curves = list(), vol_surfaces = list(), fx_rates = numeric()) {
      self.yield_curves <- yield_curves
      self.vol_surfaces <- vol_surfaces
      self.fx_rates <- fx_rates
    },
    
    #' @description Price a derivative instrument
    #' @param instrument List containing instrument specs (type, currency, maturity, etc.)
    #' @param valuation_date Date for valuation
    #' @return List containing NPV, cashflows, and risk sensitivities
    price = function(instrument, valuation_date = Sys.Date()) {
      if (is.null(instrument$type)) stop("Instrument type must be specified")
      
      switch(
        instrument$type,
        "bond" = self$price_bond(instrument, valuation_date),
        "swap" = self$price_swap(instrument, valuation_date),
        "fx_forward" = self$price_fx_forward(instrument, valuation_date),
        "fx_swap" = self$price_fx_swap(instrument, valuation_date),
        "vanilla_option" = self$price_option(instrument, valuation_date),
        "cln" = self$price_cln(instrument, valuation_date),
        "fra" = self$price_fra(instrument, valuation_date),
        "cap_floor" = self$price_cap_floor(instrument, valuation_date),
        stop(paste("Unsupported instrument type:", instrument$type))
      )
    },
    
    price_bond = function(inst, val_date) {
      # Dispatched to bond pricing module
      bond_pricing(inst, self$get_curve(inst$currency), val_date)
    },
    
    price_swap = function(inst, val_date) {
      # Dispatched to swap pricing module
      swap_pricing(inst, self$get_curve(inst$currency), val_date)
    },
    
    price_fx_forward = function(inst, val_date) {
      # Dispatched to FX module
      fx_forward_pricing(inst, self$get_curve(inst$domestic_ccy), self$get_curve(inst$foreign_ccy), self$get_fx_spot(inst$ccy_pair), val_date)
    },
    
    price_fx_swap = function(inst, val_date) {
      fx_swap_pricing(inst, self$get_curve(inst$domestic_ccy), self$get_curve(inst$foreign_ccy), self$get_fx_spot(inst$ccy_pair), val_date)
    },
    
    price_option = function(inst, val_date) {
      option_pricing(inst, self$get_curve(inst$currency), self$get_vol(inst$underlying), val_date)
    },
    
    price_cln = function(inst, val_date) {
      cln_pricing(inst, self$get_curve(inst$currency), val_date)
    },
    
    price_fra = function(inst, val_date) {
      fra_pricing(inst, self$get_curve(inst$currency), val_date)
    },
    
    price_cap_floor = function(inst, val_date) {
      cap_floor_pricing(inst, self$get_curve(inst$currency), self$get_vol(inst$index), val_date)
    },
    
    # Context helpers
    get_curve = function(ccy) {
      curve <- self.yield_curves[[ccy]]
      if (is.null(curve)) stop(paste("No yield curve found for currency:", ccy))
      return(curve)
    },
    
    get_vol = function(asset) {
      vol <- self.vol_surfaces[[asset]]
      if (is.null(vol)) stop(paste("No volatility surface found for asset:", asset))
      return(vol)
    },
    
    get_fx_spot = function(pair) {
      rate <- self.fx_rates[[pair]]
      if (is.null(rate)) stop(paste("No FX spot rate found for pair:", pair))
      return(rate)
    }
  )
)
