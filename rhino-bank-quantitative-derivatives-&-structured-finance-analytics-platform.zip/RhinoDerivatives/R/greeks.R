#' Rhino Bank Risk Sensitivities (Greeks) Engine
#' @description Implements finite-difference and analytical sensitivities across pricing modules.

#' @description Compute numerical greeks for any arbitrary instrument and pricing function
#' @param pricing_fn function that takes underlying spot S and returns NPV
#' @param s0 Spot price of the underlying
#' @param h Perturbation step size (fraction, e.g., 0.01 for 1%)
compute_numerical_greeks <- function(pricing_fn, s0, h = 0.01) {
  ds <- s0 * h
  
  npv_base <- pricing_fn(s0)
  npv_up <- pricing_fn(s0 + ds)
  npv_down <- pricing_fn(s0 - ds)
  
  # First-order central difference (Delta)
  delta <- (npv_up - npv_down) / (2 * ds)
  
  # Second-order central difference (Gamma)
  gamma <- (npv_up - 2 * npv_base + npv_down) / (ds^2)
  
  # Vega (numerical approximation assuming a vol parameter perturbation)
  # Theta (numerical time-decay representation)
  
  list(
    npv = npv_base,
    delta = delta,
    gamma = gamma
  )
}

#' @description PV01 and DV01 Sensitivity for Fixed Income and Swaps
#' @param pricing_fn function taking a YieldCurve as input and returning NPV
#' @param curve YieldCurve object
#' @param bps Perturbation in basis points (typically 1 bp or 10 bps)
compute_pv01 <- function(pricing_fn, curve, bps = 1) {
  # Perturb yield curve by a parallel shift of +bps
  shift <- bps / 10000
  
  # Create a shifted curve
  shifted_rates <- curve$market_rates + shift
  shifted_curve <- YieldCurve$new(
    currency = curve$currency,
    reference_date = curve$reference_date,
    tenors = curve$tenors,
    market_rates = shifted_rates,
    interpolation = curve$interpolation
  )
  
  npv_base <- pricing_fn(curve)
  npv_shifted <- pricing_fn(shifted_curve)
  
  # PV01 is the change in value for a 1 bp shift
  pv01 <- npv_shifted - npv_base
  dv01 <- -pv01 # DV01 is traditionally positive for positive interest rate exposure loss
  
  list(
    npv_base = npv_base,
    npv_shifted = npv_shifted,
    pv01 = pv01,
    dv01 = dv01
  )
}
