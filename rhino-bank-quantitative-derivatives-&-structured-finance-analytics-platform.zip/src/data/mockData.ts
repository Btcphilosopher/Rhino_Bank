import { Position, Tranche, MarketRiskResult, InstrumentType, MacroScenario } from "../types";

// Baseline positions for Rhino Bank Portfolio
export const INITIAL_POSITIONS: Position[] = [
  {
    id: "IRS-001",
    name: "10Y USD Payer Swap (EURIBOR/LIBOR)",
    type: "IRS",
    currency: "USD",
    notional: 100000000,
    maturityYears: 10,
    marketPrice: 1250000,
    greeks: { delta: 4500, gamma: -120, vega: 1800, theta: -250, rho: 8500, pv01: 4500, dv01: 4500 },
    details: { fixedRate: 0.038, floatingSpread: 0.001, paymentFreq: 2, isPayer: true, counterparty: "Goldman Sachs" }
  },
  {
    id: "FXF-002",
    name: "EUR/USD FX Forward Long Leg",
    type: "FX_FORWARD",
    currency: "EUR",
    notional: 50000000,
    maturityYears: 1,
    marketPrice: -340000,
    greeks: { delta: 12500, gamma: 45, vega: 450, theta: -12, rho: -150, pv01: 15, dv01: 15 },
    details: { spotRate: 1.085, strikeForward: 1.092, notionalForeign: 50000000, notionalDomestic: 54600000 }
  },
  {
    id: "CO-003",
    name: "GBP/USD European Call Option",
    type: "CURRENCY_OPTION",
    currency: "GBP",
    notional: 25000000,
    maturityYears: 0.5,
    marketPrice: 420000,
    greeks: { delta: 15400, gamma: 230, vega: 3200, theta: -850, rho: 120, pv01: 12, dv01: 12 },
    details: { strike: 1.28, underlyingSpot: 1.272, volatility: 0.115, isCall: true }
  },
  {
    id: "GB-004",
    name: "30Y US Treasury Government Bond",
    type: "GOV_BOND",
    currency: "USD",
    notional: 80000000,
    maturityYears: 24.5,
    marketPrice: 78500000,
    greeks: { delta: -18500, gamma: 450, vega: 0, theta: 1100, rho: -24500, pv01: -18500, dv01: 18500 },
    details: { couponRate: 0.0425, frequency: 2, creditSpread: 0, issueDate: "2020-05-15", rating: "AAA" }
  },
  {
    id: "CB-005",
    name: "5Y Rhino Energy Corporate Bond",
    type: "CORP_BOND",
    currency: "USD",
    notional: 40000000,
    maturityYears: 4.2,
    marketPrice: 38200000,
    greeks: { delta: -3200, gamma: 12, vega: 0, theta: 450, rho: -3800, pv01: -3200, dv01: 3200 },
    details: { couponRate: 0.0575, frequency: 2, creditSpread: 0.0185, rating: "BBB+" }
  },
  {
    id: "SW-006",
    name: "2Y x 10Y Co-Receiver Swaption",
    type: "SWAPTION",
    currency: "EUR",
    notional: 60000000,
    maturityYears: 2,
    marketPrice: 1680000,
    greeks: { delta: -850, gamma: 35, vega: 4600, theta: -1400, rho: -1250, pv01: -125, dv01: 125 },
    details: { optionExpiry: 2, swapMaturity: 10, strikeRate: 0.0315, underlyingVol: 0.185 }
  },
  {
    id: "CLN-007",
    name: "Credit Linked Note (Ref: Petrobras)",
    type: "CLN",
    currency: "USD",
    notional: 15000000,
    maturityYears: 3,
    marketPrice: 14750000,
    greeks: { delta: -80, gamma: 1, vega: 0, theta: 180, rho: -450, pv01: -45, dv01: 45 },
    details: { couponRate: 0.065, frequency: 4, creditSpread: 0.032, referenceEntity: "Petrobras", rating: "BB-" }
  },
  {
    id: "SC-008",
    name: "Synthetic CDO Mezzanine Tranche",
    type: "STRUCTURED_CREDIT",
    currency: "USD",
    notional: 30000000,
    maturityYears: 5,
    marketPrice: 28900000,
    greeks: { delta: -150, gamma: 5, vega: 850, theta: -45, rho: -1500, pv01: -150, dv01: 150 },
    details: { attachment: 0.03, detachment: 0.09, poolNotional: 500000000, currentPD: 0.024, correlation: 0.15 }
  }
];

// Re-evaluate a position given shift parameters (rates shift in bps, FX spot shocks in percent, Vol shocks in percent)
export function revaluePosition(
  pos: Position,
  ratesShiftBps: number,
  fxShockPercent: number,
  volShockPercent: number
): { pv: number; updatedGreeks: Position["greeks"] } {
  // Rates shift multiplier: e.g. -24500 rho means for +100bps rates shift, PV drops by -24500 * 100 = -2,450,000
  // Vol shift multiplier: vega
  // FX spot shift multiplier: delta (for EUR/GBP positions)
  
  const basePV = pos.marketPrice;
  const ratesShiftFrac = ratesShiftBps / 100; // per 1 bp shift
  const volShiftFrac = volShockPercent; // per 1% absolute shift
  const fxShiftFrac = fxShockPercent; // per 1% absolute shift
  
  // Calculate P&L impacts
  const ratesPnL = pos.greeks.rho * ratesShiftFrac;
  const volPnL = pos.greeks.vega * volShiftFrac * 10; // scaled
  
  let fxPnL = 0;
  if (pos.currency !== "USD") {
    fxPnL = pos.greeks.delta * fxShiftFrac * 100;
  }
  
  const totalPnL = ratesPnL + volPnL + fxPnL;
  const newPV = basePV + totalPnL;
  
  // Dynamic Greek adjustments (convexity impact on Delta, etc.)
  const gammaImpact = pos.greeks.gamma * (ratesShiftFrac / 10);
  const updatedGreeks = {
    ...pos.greeks,
    delta: pos.greeks.delta + gammaImpact
  };
  
  return { pv: newPV, updatedGreeks };
}

// Generates simulated daily portfolio returns for VaR histogram
export function generatePortfolioReturns(totalNPV: number): number[] {
  const returns: number[] = [];
  const dailyVolatility = 0.0085; // 0.85% daily vol
  const dailyDrift = 0.0001; // tiny upward drift
  
  // Reproducible seed simulation using a LCG-style custom random
  let seed = 42;
  const random = () => {
    const x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
  };
  
  // Box-Muller transform for normal distribution
  const rnorm = () => {
    let u = 0, v = 0;
    while(u === 0) u = random();
    while(v === 0) v = random();
    return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  };
  
  for (let i = 0; i < 250; i++) {
    const r = dailyDrift + dailyVolatility * rnorm();
    returns.push(r * totalNPV);
  }
  
  return returns;
}

// Compute VaR results
export function computeMarketRisk(
  portfolioPnL: number[],
  confidence: number,
  holdingPeriod: number
): MarketRiskResult {
  const n = portfolioPnL.length;
  // Sort returns descending (losses are negative, so sorted ascending puts worst losses first)
  const sortedPnL = [...portfolioPnL].sort((a, b) => a - b);
  
  // Historical VaR
  const histIndex = Math.floor((1 - confidence) * n);
  const historicalVaR = Math.abs(sortedPnL[histIndex]);
  
  // Historical Expected Shortfall
  const tailLosses = sortedPnL.slice(0, histIndex);
  const historicalES = Math.abs(tailLosses.reduce((acc, v) => acc + v, 0) / (tailLosses.length || 1));
  
  // Parametric VaR (assuming normal distribution of historical returns)
  const mean = portfolioPnL.reduce((acc, v) => acc + v, 0) / n;
  const variance = portfolioPnL.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / (n - 1);
  const stdDev = Math.sqrt(variance);
  
  const zScore = confidence === 0.95 ? 1.645 : confidence === 0.99 ? 2.33 : 3.09;
  const parametricVaR = (zScore * stdDev - mean) * Math.sqrt(holdingPeriod);
  
  // Parametric Expected Shortfall: ES = sigma * (phi(z) / (1-alpha))
  const phi = Math.exp(-0.5 * zScore * zScore) / Math.sqrt(2 * Math.PI);
  const parametricES = (stdDev * (phi / (1 - confidence)) - mean) * Math.sqrt(holdingPeriod);
  
  // Generate distribution coordinates for display
  const distribution: MarketRiskResult["distribution"] = [];
  const step = (stdDev * 8) / 80;
  for (let x = mean - stdDev * 4; x <= mean + stdDev * 4; x += step) {
    const z = (x - mean) / stdDev;
    const y = Math.exp(-0.5 * z * z) / (stdDev * Math.sqrt(2 * Math.PI));
    
    const lossValue = -x;
    const isVaR = lossValue >= parametricVaR;
    const isES = lossValue >= parametricES;
    
    distribution.push({ x: -lossValue, y, isVaR, isES });
  }
  
  return {
    parametricVaR,
    parametricES,
    historicalVaR,
    historicalES,
    monteCarloVaR: historicalVaR * 1.05, // slightly shifted for MC simulation variety
    monteCarloES: historicalES * 1.04,
    distribution
  };
}

// Collateral Pool Asset for Structured Credit modeling
export interface CollateralAsset {
  id: string;
  ticker: string;
  notional: number;
  pd: number;
  lgd: number;
}

export function generateCollateralPool(count: number = 100): CollateralAsset[] {
  const assets: CollateralAsset[] = [];
  const tickers = ["AAPL", "MSFT", "AMZN", "GOOGL", "META", "TSLA", "NFLX", "NVDA", "JPM", "GS"];
  for (let i = 0; i < count; i++) {
    const ticker = tickers[i % tickers.length] + "-" + (100 + i);
    assets.push({
      id: `CRD-${i + 1}`,
      ticker,
      notional: 5000000, // 5M per asset, total 500M
      pd: 0.015 + (i % 5) * 0.005, // 1.5% to 3.5% default probability
      lgd: 0.55 + (i % 3) * 0.05 // 55% to 65% loss given default
    });
  }
  return assets;
}

// CDO Tranche loss waterfall calculation
export function computeTrancheWaterfall(
  poolLoss: number,
  poolNotional: number,
  pd: number,
  lgd: number,
  correlation: number
): Tranche[] {
  // Tranches attachment / detachment structure
  const structure = [
    { name: "Equity Tranche", attachment: 0.0, detachment: 0.03 },
    { name: "Mezzanine Tranche", attachment: 0.03, detachment: 0.09 },
    { name: "Senior Tranche", attachment: 0.09, detachment: 0.25 },
    { name: "Super Senior Tranche", attachment: 0.25, detachment: 1.0 }
  ];
  
  return structure.map(tr => {
    const originalNotional = (tr.detachment - tr.attachment) * poolNotional;
    const attachLossThreshold = tr.attachment * poolNotional;
    const detachLossThreshold = tr.detachment * poolNotional;
    
    let lossAllocated = 0;
    if (poolLoss > attachLossThreshold) {
      lossAllocated = Math.min(poolLoss - attachLossThreshold, detachLossThreshold - attachLossThreshold);
    }
    
    const remainingNotional = Math.max(originalNotional - lossAllocated, 0);
    const lossPercentage = (lossAllocated / originalNotional) * 100;
    
    // Credit enhancement: the thickness of sub-tranches that must default before this tranche starts losing value
    const creditEnhancement = tr.attachment * 100;
    
    return {
      name: tr.name,
      attachment: tr.attachment,
      detachment: tr.detachment,
      originalNotional,
      lossAllocated,
      remainingNotional,
      lossPercentage,
      creditEnhancement
    };
  });
}

// Monte Carlo path generation models
export function simulatePaths(
  model: "GBM" | "VASICEK" | "CIR" | "HULL_WHITE",
  paths: number,
  steps: number,
  t: number,
  s0: number,
  param1: number, // drift (mu) or mean reversion speed (a)
  param2: number, // volatility (sigma) or long-term rate (b)
  param3: number  // optional additional parameter
): number[][] {
  const dt = t / steps;
  const resultPaths: number[][] = [];
  
  // Custom deterministic pseudo-random sequence for repeatability
  let rSeed = 101;
  const random = () => {
    const x = Math.sin(rSeed++) * 10000;
    return x - Math.floor(x);
  };
  
  const rnorm = () => {
    let u = 0, v = 0;
    while(u === 0) u = random();
    while(v === 0) v = random();
    return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  };
  
  for (let p = 0; p < paths; p++) {
    const path: number[] = [s0];
    let currentVal = s0;
    
    for (let s = 0; s < steps; s++) {
      const dW = rnorm() * Math.sqrt(dt);
      
      if (model === "GBM") {
        // Param1 = mu, Param2 = sigma
        const mu = param1;
        const sigma = param2;
        currentVal = currentVal * Math.exp((mu - 0.5 * Math.pow(sigma, 2)) * dt + sigma * dW);
      } else if (model === "VASICEK") {
        // d_r = a * (b - r) * dt + sigma * dW
        // Param1 = a, Param2 = b, Param3 = sigma
        const a = param1;
        const b = param2;
        const sigma = param3 || 0.02;
        currentVal = currentVal + a * (b - currentVal) * dt + sigma * dW;
      } else if (model === "CIR") {
        // d_r = a * (b - r) * dt + sigma * sqrt(r) * dW
        // Param1 = a, Param2 = b, Param3 = sigma
        const a = param1;
        const b = param2;
        const sigma = param3 || 0.02;
        currentVal = currentVal + a * (b - currentVal) * dt + sigma * Math.sqrt(Math.max(currentVal, 0.0001)) * dW;
        currentVal = Math.max(currentVal, 0); // positivity boundary
      } else if (model === "HULL_WHITE") {
        // d_r = (theta(t) - a * r) * dt + sigma * dW
        const a = param1;
        const theta = param2; // average target
        const sigma = param3 || 0.02;
        currentVal = currentVal + (theta - a * currentVal) * dt + sigma * dW;
      }
      
      path.push(currentVal);
    }
    resultPaths.push(path);
  }
  
  return resultPaths;
}

// Macro Scenarios configuration list
export const CRISIS_SCENARIOS: MacroScenario[] = [
  {
    id: "gfc",
    name: "Great Financial Crisis (GFC) Re-run",
    description: "Severe credit crisis: Parallel rates drop (-150bps) due to central bank interest cuts, domestic currency drops (-15%), asset volatilities spike (+25%), credit spreads widen (+350bps), credit defaults jump (3x).",
    ratesShiftBps: -150,
    fxShockPercent: -15,
    volShockPercent: 25,
    creditSpreadWidenBps: 350,
    defaultProbabilityMultiplier: 3.0
  },
  {
    id: "inflation",
    name: "2026 Inflation Surge Scenario",
    description: "Inflationary shock: Parallel rates spike upwards (+200bps), currencies strengthen (+10%), volatilities increase moderately (+10%), credit spreads widen moderately (+80bps), default probabilities rise 1.5x.",
    ratesShiftBps: 200,
    fxShockPercent: 10,
    volShockPercent: 10,
    creditSpreadWidenBps: 80,
    defaultProbabilityMultiplier: 1.5
  },
  {
    id: "sovereign",
    name: "Sovereign Debt Crisis & Widening",
    description: "Sovereign insolvency shock: Parallel rates climb (+100bps) on liquidity tightening, currency drops (-20%), volatility rises (+15%), corporate/sovereign credit spreads widen significantly (+450bps), defaults surge (2.5x).",
    ratesShiftBps: 100,
    fxShockPercent: -20,
    volShockPercent: 15,
    creditSpreadWidenBps: 450,
    defaultProbabilityMultiplier: 2.5
  }
];
