// Rhino Bank R Codebase Preloaded Storage

export const R_CODEBASE: Record<string, { desc: string; code: string }> = {
  "pricing_engine.R": {
    desc: "R6 Class dispatcher for institutional derivatives & fixed-income valuation.",
    code: `#' Rhino Bank Quantitative Derivatives Pricing Engine
#' @description Core R6 dispatcher for institutional derivative and fixed-income valuation.
library(R6)

PricingEngine <- R6::R6Class(
  "PricingEngine",
  public = list(
    yield_curves = NULL,
    vol_surfaces = NULL,
    fx_rates = NULL,
    
    initialize = function(yield_curves = list(), vol_surfaces = list(), fx_rates = numeric()) {
      self.yield_curves <- yield_curves
      self.vol_surfaces <- vol_surfaces
      self.fx_rates <- fx_rates
    },
    
    price = function(instrument, valuation_date = Sys.Date()) {
      switch(
        instrument$type,
        "bond" = self$price_bond(instrument, valuation_date),
        "swap" = self$price_swap(instrument, valuation_date),
        "fx_forward" = self$price_fx_forward(instrument, valuation_date),
        "vanilla_option" = self$price_option(instrument, valuation_date),
        "cln" = self$price_cln(instrument, valuation_date)
      )
    },
    
    price_bond = function(inst, val_date) {
      bond_pricing(inst, self$get_curve(inst$currency), val_date)
    },
    
    price_swap = function(inst, val_date) {
      swap_pricing(inst, self$get_curve(inst$currency), val_date)
    },
    
    get_curve = function(ccy) {
      self.yield_curves[[ccy]]
    }
  )
)`
  },
  "yield_curves.R": {
    desc: "Mathematical curve bootstrapper, spline interpolator, and Nelson-Siegel-Svensson calibration.",
    code: `#' Yield Curve Bootstrapping & NSS Calibration
library(R6)

YieldCurve <- R6::R6Class(
  "YieldCurve",
  public = list(
    currency = NULL,
    tenors = NULL,
    market_rates = NULL,
    interpolation = "linear",
    
    initialize = function(currency, tenors, market_rates, interpolation = "linear") {
      self.currency <- currency
      self.tenors <- tenors
      self.market_rates <- market_rates
      self.interpolation <- interpolation
    },
    
    get_zero_rate = function(t) {
      approx(self.tenors, self.market_rates, xout = t, rule = 2)$y
    },
    
    get_discount_factor = function(t) {
      exp(-self$get_zero_rate(t) * t)
    }
  )
)`
  },
  "fx_engine.R": {
    desc: "FX spot and forward curve analyzer, CIP parity checking, and Net Open Position analytics.",
    code: `#' FX Forward Valuation & Covered Interest Parity
fx_forward_pricing <- function(inst, dom_curve, for_curve, spot, val_date) {
  t <- as.numeric(difftime(inst$maturity_date, val_date, units = "days")) / 365
  df_dom <- dom_curve$get_discount_factor(t)
  df_for <- for_curve$get_discount_factor(t)
  fair_forward <- spot * (df_for / df_dom)
  npv <- inst$notional_foreign * df_for * spot - inst$notional_domestic * df_dom
  list(npv = npv, fair_forward = fair_forward, premium_bps = (fair_forward/spot - 1)*10000)
}`
  },
  "interest_rate_models.R": {
    desc: "Vasicek, CIR, and Hull-White short rate simulations and option formulas.",
    code: `#' Short-Rate Models (Vasicek & CIR)
simulate_vasicek <- function(n_paths, n_steps, T, r0, a, b, sigma) {
  dt <- T / n_steps
  paths <- matrix(0, nrow = n_steps + 1, ncol = n_paths)
  paths[1, ] <- r0
  for (t in 1:n_steps) {
    dW <- rnorm(n_paths, sd = sqrt(dt))
    paths[t+1, ] <- paths[t, ] + a * (b - paths[t, ]) * dt + sigma * dW
  }
  return(paths)
}`
  },
  "swap_pricing.R": {
    desc: "IRS, FRA, and bond pricing engines including par-rate calculators and annuity metrics.",
    code: `#' Swap Pricing Module
swap_pricing <- function(inst, curve, val_date) {
  payment_times <- seq(1/inst$freq, inst$maturity_years, by = 1/inst$freq)
  df_times <- sapply(payment_times, curve$get_discount_factor)
  pv_fixed <- sum(inst$fixed_rate * inst$nominal * df_times / inst$freq)
  pv_floating <- inst$nominal * (1 - df_times[length(df_times)])
  list(npv = pv_floating - pv_fixed, par_swap_rate = (1 - df_times[length(df_times)]) / sum(df_times / inst$freq))
}`
  },
  "option_pricing.R": {
    desc: "Black-Scholes analytical formulas, Garman-Kohlhagen for FX options, and Binomial Trees.",
    code: `#' Analytical Option Valuation (Black-Scholes-Merton)
option_pricing <- function(inst, curve, vol_surface, val_date) {
  s <- inst$underlying_spot; k <- inst$strike
  t <- as.numeric(difftime(inst$maturity_date, val_date, units="days")) / 365
  r <- -log(curve$get_discount_factor(t)) / t
  sig <- vol_surface$get_volatility(t, k)
  d1 <- (log(s/k) + (r + 0.5*sig^2)*t) / (sig*sqrt(t))
  d2 <- d1 - sig*sqrt(t)
  if(inst$is_call) {
    npv <- s*pnorm(d1) - k*exp(-r*t)*pnorm(d2)
  } else {
    npv <- k*exp(-r*t)*pnorm(-d2) - s*pnorm(-d1)
  }
  list(npv = npv, implied_vol = sig)
}`
  },
  "volatility_models.R": {
    desc: "SABR model implementation and 2D volatility surface interpolators.",
    code: `#' SABR Lognormal Volatility Formula
sabr_vol <- function(f, k, t, alpha, beta, rho, nu) {
  # Closed-form SABR volatility approximation
  fk <- f * k
  log_fk <- log(f / k)
  z <- (nu / alpha) * (fk)^((1 - beta) / 2) * log_fk
  x_z <- log((sqrt(1 - 2*rho*z + z^2) + z - rho) / (1 - rho))
  alpha * (z / x_z) / (fk)^((1-beta)/2)
}`
  },
  "structured_credit.R": {
    desc: "Tranche cashflow waterfalls (Equity, Mezzanine, Senior) and single-factor Copula collateral simulation.",
    code: `#' CDO Tranche Loss Allocation Waterfall
apply_tranche_waterfall <- function(collateral_loss, tranche_structure) {
  updated_tranches <- list()
  for (tr in tranche_structure) {
    attach_threshold <- tr$attachment * tr$pool_notional
    detach_threshold <- tr$detachment * tr$pool_notional
    tr_loss <- 0
    if (collateral_loss > attach_threshold) {
      tr_loss <- min(collateral_loss - attach_threshold, detach_threshold - attach_threshold)
    }
    updated_tranches[[tr$name]] <- list(
      name = tr$name, loss_allocated = tr_loss, remaining_notional = max(tr$notional - tr_loss, 0)
    )
  }
  updated_tranches
}`
  },
  "cashflow_engine.R": {
    desc: "Day-count fraction engine (ACT/365, ACT/360, 30/360) and amortization scheduler.",
    code: `#' Day-Count Year Fraction Calculator
calculate_year_fraction <- function(start_date, end_date, convention = "ACT/365") {
  days <- as.numeric(as.Date(end_date) - as.Date(start_date))
  if (convention == "ACT/365") return(days / 365.25)
  if (convention == "ACT/360") return(days / 360)
  if (convention == "30/360") {
    # 30/360 US algorithm
  }
}`
  },
  "portfolio_engine.R": {
    desc: "R6 aggregate coordinator which prices diverse cross-asset portfolios in parallel.",
    code: `#' Multi-Asset Portfolio Manager
PortfolioEngine <- R6::R6Class(
  "PortfolioEngine",
  public = list(
    instruments = NULL,
    pricing_engine = NULL,
    evaluate_portfolio = function() {
      sapply(self.instruments, function(inst) self.pricing_engine$price(inst))
    }
  )
)`
  },
  "market_risk.R": {
    desc: "Parametric, Historical, and Monte Carlo Value-at-Risk (VaR) and Expected Shortfall.",
    code: `#' Variance-Covariance Portfolio VaR
parametric_var <- function(holdings, cov_matrix, confidence = 0.99) {
  port_sd <- sqrt(as.numeric(t(holdings) %*% cov_matrix %*% holdings))
  z_score <- qnorm(confidence)
  list(var = z_score * port_sd, es = (dnorm(z_score)/(1-confidence)) * port_sd)
}`
  },
  "credit_risk.R": {
    desc: "CVA, DVA, counterparty risk modeling, and Potential Future Exposure (PFE).",
    code: `#' CVA Calculation
compute_cva <- function(expected_exposures, discount_factors, marginal_pds, recovery_rate = 0.4) {
  loss_given_default <- 1 - recovery_rate
  total_cva <- loss_given_default * sum(expected_exposures * discount_factors * marginal_pds)
  list(cva = total_cva)
}`
  },
  "stress_testing.R": {
    desc: "Revaluation engine for interest rate curves and multi-asset shock perturbations.",
    code: `#' Yield Curve Shocks (Parallel, Steepening, Flattening)
stress_yield_curve <- function(curve, type = "parallel_shift", amount_bps = 100) {
  shift <- amount_bps / 10000
  new_rates <- curve$market_rates + shift
  if (type == "steepening") {
    new_rates <- curve$market_rates + shift * (curve$tenors / max(curve$tenors))
  }
  return(YieldCurve$new(curve$currency, curve$tenors, new_rates))
}`
  },
  "monte_carlo.R": {
    desc: "Cholesky decomposition for correlated multi-asset walks and stochastic pathways.",
    code: `#' Multi-asset Correlated Monte Carlo
simulate_correlated_paths <- function(n_paths, n_steps, T, mu, vol, correlation_matrix) {
  # Cholesky decomposition of Correlation
  L <- chol(correlation_matrix)
  # Simulated correlated drift paths
}`
  },
  "scenario_engine.R": {
    desc: "Macro-financial crisis scenario mapping (Recession, Sovereign spread, Inflation surge).",
    code: `#' Crisis Scenario Loader
apply_macro_scenario <- function(base_engine, scenario_name) {
  if (scenario_name == "recession") {
    # Coordinated shocks: rates decline, default probs double, vol spikes
  }
}`
  },
  "greeks.R": {
    desc: "Central central-difference and analytic greeks for standard and exotics instruments.",
    code: `#' Analytical & Numerical Greeks
compute_numerical_greeks <- function(pricing_fn, s0, h = 0.01) {
  ds <- s0 * h
  delta <- (pricing_fn(s0 + ds) - pricing_fn(s0 - ds)) / (2 * ds)
  gamma <- (pricing_fn(s0 + ds) - 2*pricing_fn(s0) + pricing_fn(s0 - ds)) / (ds^2)
  list(delta = delta, gamma = gamma)
}`
  },
  "reporting.R": {
    desc: "Institutional summary tables, treasury reports, and CSV data stream exporters.",
    code: `#' Treasury & Risk Report Publisher
generate_daily_risk_report <- function(portfolio_results, var_results) {
  # Formats PDF/text ready summaries for Executive Risk Committees
}`
  },
  "dashboard.R": {
    desc: "Shiny UI layouts and reactive server connectors for interactive user flows.",
    code: `#' Shiny Executive Dashboard
shiny_ui <- fluidPage(
  titlePanel("Rhino Bank Executive Risk Portal"),
  sidebarLayout(
    sidebarPanel(selectInput("macro_scen", "Crisis Shock", choices = c("GFC", "Covid", "Inflation"))),
    mainPanel(plotOutput("risk_profile"))
  )
)`
  },
  "utilities.R": {
    desc: "Financial day-count calculators, leap year checkers, and test suite orchestrator.",
    code: `#' General Helper Routines
round_bps <- function(rate) { round(rate * 10000, 2) }`
  }
};
