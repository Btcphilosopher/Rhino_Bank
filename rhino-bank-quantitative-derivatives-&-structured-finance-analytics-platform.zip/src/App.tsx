import React, { useState, useEffect } from "react";
import {
  INITIAL_POSITIONS,
  revaluePosition,
  generatePortfolioReturns,
  computeMarketRisk,
  generateCollateralPool,
  computeTrancheWaterfall,
  simulatePaths,
  CRISIS_SCENARIOS,
  CollateralAsset
} from "./data/mockData";
import { Position, Tranche, MarketRiskResult, MacroScenario, InstrumentType } from "./types";
import RCodeExplorer from "./components/RCodeExplorer";
import {
  Activity,
  ArrowRight,
  CheckCircle,
  Database,
  DollarSign,
  Download,
  FileText,
  Globe,
  Layers,
  Printer,
  RotateCcw,
  Server,
  ShieldAlert,
  Sliders,
  TrendingDown,
  TrendingUp,
  UserCheck
} from "lucide-react";

export default function App() {
  // Current active tab
  const [activeTab, setActiveTab] = useState<string>("portfolio");

  // State for portfolio
  const [positions, setPositions] = useState<Position[]>(INITIAL_POSITIONS);
  const [selectedPositionId, setSelectedPositionId] = useState<string | null>(null);

  // Stress state
  const [ratesShift, setRatesShift] = useState<number>(0); // bps
  const [fxShock, setFxShock] = useState<number>(0); // percent
  const [volShock, setVolShock] = useState<number>(0); // percent
  const [activeScenarioId, setActiveScenarioId] = useState<string | null>(null);

  // Market Risk state
  const [confidence, setConfidence] = useState<number>(0.99);
  const [holdingPeriod, setHoldingPeriod] = useState<number>(1);
  const [returns, setReturns] = useState<number[]>([]);
  const [marketRisk, setMarketRisk] = useState<MarketRiskResult | null>(null);

  // Structured Credit state
  const [collateralPool, setCollateralPool] = useState<CollateralAsset[]>([]);
  const [assetCorrelation, setAssetCorrelation] = useState<number>(0.15);
  const [poolPD, setPoolPD] = useState<number>(0.024);
  const [poolLGD, setPoolLGD] = useState<number>(0.60);
  const [simulatedLoss, setSimulatedLoss] = useState<number>(12000000); // 12M pool loss
  const [tranches, setTranches] = useState<Tranche[]>([]);

  // Monte Carlo path simulation state
  const [mcModel, setMcModel] = useState<"GBM" | "VASICEK" | "CIR" | "HULL_WHITE">("VASICEK");
  const [mcPaths, setMcPaths] = useState<number>(10);
  const [mcSteps, setMcSteps] = useState<number>(50);
  const [mcS0, setMcS0] = useState<number>(0.035); // 3.5% initial interest rate
  const [mcParam1, setMcParam1] = useState<number>(0.15); // drift or reversion speed a
  const [mcParam2, setMcParam2] = useState<number>(0.04); // vol or reversion level b
  const [mcParam3, setMcParam3] = useState<number>(0.015); // rate vol
  const [simulatedMCData, setSimulatedMCData] = useState<number[][]>([]);

  // Yield Curve bootstrap inputs
  const [curveTenors, setCurveTenors] = useState<number[]>([0.25, 0.5, 1, 2, 5, 10, 30]);
  const [curveRates, setCurveRates] = useState<number[]>([0.038, 0.040, 0.042, 0.041, 0.039, 0.038, 0.041]);

  // General app setup on mount
  useEffect(() => {
    // Generate pool
    setCollateralPool(generateCollateralPool(100));
    
    // Simulate initial paths
    runMonteCarlo();
  }, []);

  // Sync calculations when inputs change
  useEffect(() => {
    // 1. Calculate positions with stress shocks
    const updated = INITIAL_POSITIONS.map((pos) => {
      const { pv, updatedGreeks } = revaluePosition(pos, ratesShift, fxShock, volShock);
      return {
        ...pos,
        marketPrice: pv,
        greeks: updatedGreeks
      };
    });
    setPositions(updated);

    // 2. Generate returns for Market Risk based on current NPV
    const totalNPV = updated.reduce((sum, p) => sum + p.marketPrice, 0);
    const pnlReturns = generatePortfolioReturns(totalNPV);
    setReturns(pnlReturns);

    // 3. Compute Market Risk VaR
    const risk = computeMarketRisk(pnlReturns, confidence, holdingPeriod);
    setMarketRisk(risk);

    // 4. Structured Credit waterfall
    const totalPoolNotional = 500000000; // 500M pool
    const computedTranches = computeTrancheWaterfall(
      simulatedLoss,
      totalPoolNotional,
      poolPD,
      poolLGD,
      assetCorrelation
    );
    setTranches(computedTranches);

  }, [ratesShift, fxShock, volShock, confidence, holdingPeriod, poolPD, poolLGD, assetCorrelation, simulatedLoss]);

  // Run Monte Carlo simulation
  const runMonteCarlo = () => {
    const paths = simulatePaths(
      mcModel,
      mcPaths,
      mcSteps,
      5.0, // T = 5 years
      mcS0,
      mcParam1,
      mcParam2,
      mcParam3
    );
    setSimulatedMCData(paths);
  };

  // Reset stress testing parameters
  const resetStress = () => {
    setRatesShift(0);
    setFxShock(0);
    setVolShock(0);
    setActiveScenarioId(null);
  };

  // Apply a macro-financial crisis scenario
  const applyScenario = (scen: MacroScenario) => {
    setActiveScenarioId(scen.id);
    setRatesShift(scen.ratesShiftBps);
    setFxShock(scen.fxShockPercent);
    setVolShock(scen.volShockPercent);
    
    // update credit variables
    setPoolPD(0.024 * scen.defaultProbabilityMultiplier);
    setSimulatedLoss(12000000 * scen.defaultProbabilityMultiplier);
  };

  const totalPortfolioNPV = positions.reduce((sum, p) => sum + p.marketPrice, 0);
  const selectedPosition = positions.find((p) => p.id === selectedPositionId);

  return (
    <div className="min-h-screen bg-[#0A0C10] text-[#E6EDF3] font-sans selection:bg-amber-900/40 flex flex-col antialiased">
      {/* Top Banner Status Panel */}
      <header className="bg-[#161B22] text-white border-b border-[#30363D] shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-[#D4AF37] text-[#0A0C10] p-2 rounded-lg font-black tracking-wider text-sm flex items-center justify-center">
              R
            </div>
            <div>
              <h1 className="text-base font-bold tracking-tight text-white">
                RHINO BANK
              </h1>
              <p className="text-[11px] font-mono tracking-wider text-[#D4AF37] uppercase">
                Quantitative Derivatives & Structured Finance Platform
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-[11px] font-mono text-slate-400">
            <div className="flex items-center gap-1.5 bg-[#0D1117] px-2.5 py-1 rounded border border-[#30363D]">
              <Server className="h-3 w-3 text-green-400" />
              <span>ENV: Cloud Run</span>
            </div>
            <div className="flex items-center gap-1.5 bg-[#0D1117] px-2.5 py-1 rounded border border-[#30363D]">
              <Database className="h-3 w-3 text-[#D4AF37]" />
              <span>REPOS: 19 R Scripts Loaded</span>
            </div>
            <div className="flex items-center gap-1.5 bg-[#0D1117] px-2.5 py-1 rounded border border-[#30363D]">
              <Activity className="h-3 w-3 text-blue-400" />
              <span>STATUS: Nominal</span>
            </div>
          </div>
        </div>
      </header>

      {/* Quick Dashboard Header Metrics */}
      <div className="bg-[#0D1117] text-slate-300 border-b border-[#30363D]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="p-3 bg-[#161B22] rounded-lg border border-[#30363D]">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-mono">Net Portfolio NPV</span>
            <div className="text-lg font-bold text-white font-mono mt-1">
              ${totalPortfolioNPV.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </div>
          </div>
          <div className="p-3 bg-[#161B22] rounded-lg border border-[#30363D]">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-mono">Market VaR (99% 1-Day)</span>
            <div className="text-lg font-bold text-red-400 font-mono mt-1">
              {marketRisk ? `$${marketRisk.parametricVaR.toLocaleString(undefined, { maximumFractionDigits: 0 })}` : "Calculating..."}
            </div>
          </div>
          <div className="p-3 bg-[#161B22] rounded-lg border border-[#30363D]">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-mono">FX Net Open Position</span>
            <div className="text-lg font-bold text-white font-mono mt-1">
              $54,250,000
            </div>
          </div>
          <div className="p-3 bg-[#161B22] rounded-lg border border-[#30363D] border-b-2 border-b-[#D4AF37]">
            <span className="text-[10px] uppercase tracking-wider text-[#D4AF37] font-mono">Structured Credit Rating</span>
            <div className="text-lg font-bold text-[#D4AF37] font-mono mt-1">
              BBB+ Pool
            </div>
          </div>
          <div className="p-3 bg-[#161B22] rounded-lg border border-[#30363D] col-span-2 md:col-span-1">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-mono">Valuation Date</span>
            <div className="text-sm font-semibold text-slate-300 mt-2 font-mono">
              2026-07-26
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <nav className="bg-[#161B22] border-b border-[#30363D] sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex overflow-x-auto gap-1 py-1 scrollbar-none">
            {[
              { id: "portfolio", label: "Portfolio Overview", icon: Activity },
              { id: "market-risk", label: "Market Risk", icon: ShieldAlert },
              { id: "fx-analytics", label: "FX Analytics", icon: Globe },
              { id: "ir-risk", label: "Interest Rate Risk", icon: Sliders },
              { id: "structured-credit", label: "Structured Credit", icon: Layers },
              { id: "monte-carlo", label: "Monte Carlo Sim", icon: Activity },
              { id: "stress-testing", label: "Stress testing", icon: Sliders },
              { id: "codebase", label: "R Library Explorer", icon: UserCheck },
              { id: "reports", label: "Executive Reports", icon: FileText }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-t-lg rounded-b-none text-xs font-semibold whitespace-nowrap transition-all border-b-2 ${
                    activeTab === tab.id
                      ? "bg-[#21262D] text-[#D4AF37] border-[#D4AF37] shadow-md"
                      : "text-slate-400 border-transparent hover:bg-[#0D1117] hover:text-[#E6EDF3]"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* TAB 1: PORTFOLIO OVERVIEW */}
        {activeTab === "portfolio" && (
          <div className="flex flex-col gap-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white">Portfolio Overview & Asset Allocations</h2>
                <p className="text-xs text-slate-400 mt-1">
                  Active institutional cross-asset positions under valuation in the current market context.
                </p>
              </div>

              {/* Stress controls link */}
              {ratesShift !== 0 || fxShock !== 0 || volShock !== 0 ? (
                <div className="flex items-center gap-2 bg-[#161B22] text-[#D4AF37] px-3 py-1.5 rounded-lg border border-[#30363D] text-xs font-medium">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-[#D4AF37]"></span>
                  </span>
                  <span>Portfolio Shocked (Rates: {ratesShift}bps, FX: {fxShock}%, Vol: {volShock}%)</span>
                  <button onClick={resetStress} className="underline font-bold ml-1 hover:text-white">
                    Reset
                  </button>
                </div>
              ) : null}
            </div>

            {/* Positions Table */}
            <div className="bg-[#0D1117] rounded-xl border border-[#30363D] shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-[#161B22] border-b border-[#30363D] text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      <th className="px-6 py-3">ID</th>
                      <th className="px-6 py-3">Asset Description</th>
                      <th className="px-6 py-3">Asset Class</th>
                      <th className="px-6 py-3">Currency</th>
                      <th className="px-6 py-3 text-right">Notional</th>
                      <th className="px-6 py-3 text-right">Maturity (Yrs)</th>
                      <th className="px-6 py-3 text-right">Net Present Value</th>
                      <th className="px-6 py-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#30363D] text-xs text-slate-300">
                    {positions.map((pos) => (
                      <tr
                        key={pos.id}
                        className={`hover:bg-[#161B22]/50 transition-all cursor-pointer ${
                          selectedPositionId === pos.id ? "bg-[#21262D]" : ""
                        }`}
                        onClick={() => setSelectedPositionId(pos.id === selectedPositionId ? null : pos.id)}
                      >
                        <td className="px-6 py-4 font-mono font-semibold text-slate-400">{pos.id}</td>
                        <td className="px-6 py-4 font-medium text-white">{pos.name}</td>
                        <td className="px-6 py-4">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#161B22] text-slate-300 border border-[#30363D] uppercase tracking-wide">
                            {pos.type.replace("_", " ")}
                          </span>
                        </td>
                        <td className="px-6 py-4 font-mono">{pos.currency}</td>
                        <td className="px-6 py-4 text-right font-mono">${pos.notional.toLocaleString()}</td>
                        <td className="px-6 py-4 text-right font-mono">{pos.maturityYears}</td>
                        <td className={`px-6 py-4 text-right font-mono font-semibold ${pos.marketPrice >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                          ${pos.marketPrice.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button className="text-[#D4AF37] hover:text-white font-semibold text-[11px] underline">
                            {selectedPositionId === pos.id ? "Close Details" : "View Details"}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Selected Position Detail Card */}
            {selectedPosition && (
              <div className="bg-[#0D1117] text-[#E6EDF3] p-6 rounded-xl border border-[#30363D] shadow-xl flex flex-col md:flex-row gap-8">
                <div className="flex-1 flex flex-col gap-4">
                  <div>
                    <span className="text-[10px] font-mono tracking-wider text-[#D4AF37] uppercase">
                      Position Deep-Dive ({selectedPosition.id})
                    </span>
                    <h3 className="text-lg font-bold text-white mt-1">{selectedPosition.name}</h3>
                  </div>

                  {/* Pricing Details */}
                  <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                    <div className="bg-[#161B22] p-3 rounded border border-[#30363D]">
                      <span className="text-slate-400 block text-[10px] uppercase">Original Notional</span>
                      <span className="text-sm font-bold mt-1 text-white block">
                        ${selectedPosition.notional.toLocaleString()}
                      </span>
                    </div>
                    <div className="bg-[#161B22] p-3 rounded border border-[#30363D]">
                      <span className="text-slate-400 block text-[10px] uppercase">Valuation Currency</span>
                      <span className="text-sm font-bold mt-1 text-white block">
                        {selectedPosition.currency}
                      </span>
                    </div>
                    {Object.entries(selectedPosition.details).map(([k, v]) => (
                      <div key={k} className="bg-[#161B22] p-3 rounded border border-[#30363D]">
                        <span className="text-slate-400 block text-[10px] uppercase">
                          {k.replace(/([A-Z])/g, " $1")}
                        </span>
                        <span className="text-sm font-bold mt-1 text-white block">
                          {typeof v === "number" ? v.toLocaleString(undefined, { maximumFractionDigits: 4 }) : String(v)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Greeks Grid */}
                <div className="md:w-80 flex flex-col gap-4 bg-[#0A0C10] p-4 rounded-lg border border-[#30363D]">
                  <h4 className="text-xs font-mono font-bold tracking-wider text-[#D4AF37] uppercase border-b border-[#30363D] pb-2">
                    Valuation Sensitivity (Greeks)
                  </h4>
                  <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                    <div className="bg-[#161B22]/60 p-2.5 rounded">
                      <span className="text-slate-400 text-[10px] block">DELTA (Δ)</span>
                      <span className="text-xs font-bold text-white">
                        {selectedPosition.greeks.delta.toFixed(2)}
                      </span>
                    </div>
                    <div className="bg-[#161B22]/60 p-2.5 rounded">
                      <span className="text-slate-400 text-[10px] block">GAMMA (Γ)</span>
                      <span className="text-xs font-bold text-white">
                        {selectedPosition.greeks.gamma.toFixed(4)}
                      </span>
                    </div>
                    <div className="bg-[#161B22]/60 p-2.5 rounded">
                      <span className="text-slate-400 text-[10px] block">VEGA (𝜈)</span>
                      <span className="text-xs font-bold text-white">
                        {selectedPosition.greeks.vega.toFixed(2)}
                      </span>
                    </div>
                    <div className="bg-[#161B22]/60 p-2.5 rounded">
                      <span className="text-slate-400 text-[10px] block">THETA (Θ)</span>
                      <span className="text-xs font-bold text-white">
                        {selectedPosition.greeks.theta.toFixed(2)} /day
                      </span>
                    </div>
                    <div className="bg-[#161B22]/60 p-2.5 rounded">
                      <span className="text-slate-400 text-[10px] block">RHO (ρ)</span>
                      <span className="text-xs font-bold text-white">
                        {selectedPosition.greeks.rho.toFixed(2)}
                      </span>
                    </div>
                    <div className="bg-[#161B22]/60 p-2.5 rounded col-span-2 border-t border-[#30363D] pt-2 mt-1">
                      <span className="text-slate-400 text-[10px] block">PV01 / DV01 (Interest rate 1 bp sensitivity)</span>
                      <span className="text-sm font-bold text-[#D4AF37]">
                        ${Math.abs(selectedPosition.greeks.pv01).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: MARKET RISK */}
        {activeTab === "market-risk" && marketRisk && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Sidebar: parameters */}
            <div className="lg:col-span-1 bg-[#0D1117] p-5 rounded-xl border border-[#30363D] flex flex-col gap-4 shadow-sm">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider border-b border-[#30363D] pb-2">
                Risk Engine Parameters
              </h3>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-400">Confidence Interval</label>
                <div className="grid grid-cols-3 gap-1">
                  {[0.95, 0.99, 0.999].map((lvl) => (
                    <button
                      key={lvl}
                      onClick={() => setConfidence(lvl)}
                      className={`py-1.5 text-xs font-bold rounded transition-all ${
                        confidence === lvl
                          ? "bg-[#D4AF37] text-[#0A0C10]"
                          : "bg-[#161B22] text-slate-400 hover:bg-[#21262D] border border-[#30363D]"
                      }`}
                    >
                      {(lvl * 100).toFixed(1)}%
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-400">Holding Period (Horizon)</label>
                <div className="grid grid-cols-2 gap-1">
                  {[1, 10].map((h) => (
                    <button
                      key={h}
                      onClick={() => setHoldingPeriod(h)}
                      className={`py-1.5 text-xs font-bold rounded transition-all ${
                        holdingPeriod === h
                          ? "bg-[#D4AF37] text-[#0A0C10]"
                          : "bg-[#161B22] text-slate-400 hover:bg-[#21262D] border border-[#30363D]"
                      }`}
                    >
                      {h} {h === 1 ? "Day" : "Days"}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-4 p-3 bg-[#161B22] rounded-lg border border-[#30363D] text-slate-400 text-[11px] leading-relaxed">
                <strong>Methodology:</strong> Calculated using institutional variance-covariance matrix and historical re-valuation of past 250 trading sessions.
              </div>
            </div>

            {/* Results & Distribution Chart */}
            <div className="lg:col-span-3 flex flex-col gap-6">
              <div className="bg-[#0D1117] p-6 rounded-xl border border-[#30363D] shadow-sm">
                <h3 className="text-base font-bold text-white mb-4">Value-at-Risk (VaR) & Expected Shortfall (ES)</h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-[#161B22] p-4 rounded-lg border border-[#30363D]">
                    <span className="text-[10px] text-slate-400 uppercase font-mono">Parametric (Normal) VaR</span>
                    <div className="text-xl font-bold text-white font-mono mt-1">
                      ${marketRisk.parametricVaR.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">
                      Expected Shortfall: ${marketRisk.parametricES.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </span>
                  </div>

                  <div className="bg-[#161B22] p-4 rounded-lg border border-[#30363D]">
                    <span className="text-[10px] text-slate-400 uppercase font-mono">Historical Simulation VaR</span>
                    <div className="text-xl font-bold text-white font-mono mt-1">
                      ${marketRisk.historicalVaR.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">
                      Expected Shortfall: ${marketRisk.historicalES.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </span>
                  </div>

                  <div className="bg-[#161B22] p-4 rounded-lg border border-[#30363D]">
                    <span className="text-[10px] text-slate-400 uppercase font-mono">Monte Carlo VaR</span>
                    <div className="text-xl font-bold text-white font-mono mt-1">
                      ${marketRisk.monteCarloVaR.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">
                      Expected Shortfall: ${marketRisk.monteCarloES.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </span>
                  </div>
                </div>

                {/* SVG Risk Distribution Chart */}
                <div>
                  <h4 className="text-xs font-semibold text-slate-400 mb-3 uppercase tracking-wider font-mono">
                    Portfolio Daily Returns & VaR Quantile Cutoff (P&L Distribution)
                  </h4>
                  <div className="relative w-full h-64 bg-[#0A0C10] rounded-xl overflow-hidden p-4 border border-[#30363D]">
                    {/* Render custom distribution */}
                    <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full">
                      {/* Grid lines */}
                      <line x1="25" y1="0" x2="25" y2="100" stroke="#22252c" strokeWidth="0.2" strokeDasharray="2,2" />
                      <line x1="50" y1="0" x2="50" y2="100" stroke="#22252c" strokeWidth="0.2" strokeDasharray="2,2" />
                      <line x1="75" y1="0" x2="75" y2="100" stroke="#22252c" strokeWidth="0.2" strokeDasharray="2,2" />
                      <line x1="0" y1="50" x2="100" y2="50" stroke="#22252c" strokeWidth="0.2" strokeDasharray="2,2" />

                      {/* Distribution Curve Path */}
                      <path
                        d={(() => {
                          const points = marketRisk.distribution;
                          const xMin = points[0].x;
                          const xMax = points[points.length - 1].x;
                          const yMax = Math.max(...points.map((p) => p.y));

                          return (
                            "M 0 100 " +
                            points
                              .map((p) => {
                                const px = ((p.x - xMin) / (xMax - xMin)) * 100;
                                const py = 100 - (p.y / yMax) * 80; // keep bottom padding
                                return `L ${px} ${py}`;
                              })
                              .join(" ") +
                            " L 100 100 Z"
                          );
                        })()}
                        fill="url(#curve-grad)"
                        stroke="#D4AF37"
                        strokeWidth="0.5"
                      />

                      {/* Risk Shaded Area (Tail Loss Region) */}
                      <path
                        d={(() => {
                          const points = marketRisk.distribution;
                          const tailPoints = points.filter((p) => p.isVaR);
                          const xMin = points[0].x;
                          const xMax = points[points.length - 1].x;
                          const yMax = Math.max(...points.map((p) => p.y));

                          if (tailPoints.length === 0) return "M 0 100 Z";

                          const startPx = ((tailPoints[0].x - xMin) / (xMax - xMin)) * 100;

                          return (
                            `M ${startPx} 100 ` +
                            tailPoints
                              .map((p) => {
                                const px = ((p.x - xMin) / (xMax - xMin)) * 100;
                                const py = 100 - (p.y / yMax) * 80;
                                return `L ${px} ${py}`;
                              })
                              .join(" ") +
                            " L 0 100 Z"
                          );
                        })()}
                        fill="rgba(239, 68, 68, 0.35)"
                        stroke="#ef4444"
                        strokeWidth="0.5"
                      />

                      {/* Linear Gradient definition */}
                      <defs>
                        <linearGradient id="curve-grad" x1="0%" y1="0%" x2="0%" y2="100%">
                          <stop offset="0%" stopColor="#D4AF37" stopOpacity="0.4" />
                          <stop offset="100%" stopColor="#D4AF37" stopOpacity="0.0" />
                        </linearGradient>
                      </defs>
                    </svg>

                    {/* Annotations */}
                    <div className="absolute top-4 left-4 bg-[#161B22]/90 text-slate-300 p-2.5 rounded border border-[#30363D] text-[10px] font-mono leading-relaxed">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 bg-[#D4AF37] rounded-sm"></span>
                        <span>Standard Profit & Loss Region</span>
                      </div>
                      <div className="flex items-center gap-1.5 mt-1">
                        <span className="w-2.5 h-2.5 bg-red-500/50 rounded-sm"></span>
                        <span>Tail Loss Hazard Zone ({(100 - confidence * 100).toFixed(1)}% Worst Cases)</span>
                      </div>
                    </div>

                    <div className="absolute right-4 top-4 text-xs font-mono font-bold text-red-500 flex items-center gap-1">
                      <span>Value at Risk Cutoff ➔</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: FX ANALYTICS */}
        {activeTab === "fx-analytics" && (
          <div className="flex flex-col gap-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Parity Checker */}
              <div className="lg:col-span-2 bg-[#0D1117] p-6 rounded-xl border border-[#30363D] flex flex-col shadow-sm">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-3">
                  Interest Rate Parity Checking (CIP Check)
                </h3>
                <p className="text-xs text-slate-400 mb-4">
                  Theoretical Forward rates calculated via Covered Interest Parity (CIP) compared against current market forward quotes.
                </p>

                <div className="overflow-x-auto flex-grow">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#161B22] border-b border-[#30363D] font-bold text-slate-400 uppercase">
                        <th className="px-4 py-3">Tenor</th>
                        <th className="px-4 py-3">Spot Rate</th>
                        <th className="px-4 py-3 text-right">USD rate</th>
                        <th className="px-4 py-3 text-right">EUR rate</th>
                        <th className="px-4 py-3 text-right">Implied Forward</th>
                        <th className="px-4 py-3 text-right">Market Quote</th>
                        <th className="px-4 py-3 text-right">Basis points Deviation</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#30363D] font-mono text-slate-300">
                      {[
                        { t: "1 Month", spot: 1.085, rDom: 0.052, rFor: 0.038, theoretical: 1.0837, market: 1.0835, dev: 1.8 },
                        { t: "3 Months", spot: 1.085, rDom: 0.0515, rFor: 0.0385, theoretical: 1.0815, market: 1.0812, dev: 2.7 },
                        { t: "6 Months", spot: 1.085, rDom: 0.051, rFor: 0.039, theoretical: 1.0785, market: 1.0781, dev: 3.5 },
                        { t: "1 Year", spot: 1.085, rDom: 0.050, rFor: 0.040, theoretical: 1.0742, market: 1.0736, dev: 5.2 }
                      ].map((item, idx) => (
                        <tr key={idx} className="hover:bg-[#161B22]/50">
                          <td className="px-4 py-3 font-semibold text-white">{item.t}</td>
                          <td className="px-4 py-3">{item.spot.toFixed(4)}</td>
                          <td className="px-4 py-3 text-right">{(item.rDom * 100).toFixed(2)}%</td>
                          <td className="px-4 py-3 text-right">{(item.rFor * 100).toFixed(2)}%</td>
                          <td className="px-4 py-3 text-right font-semibold">{item.theoretical.toFixed(4)}</td>
                          <td className="px-4 py-3 text-right font-semibold text-[#D4AF37]">{item.market.toFixed(4)}</td>
                          <td className="px-4 py-3 text-right text-rose-400 font-semibold">{item.dev.toFixed(1)} bps</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Exposure Aggregation */}
              <div className="bg-[#0D1117] p-6 rounded-xl border border-[#30363D] shadow-sm flex flex-col">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4">
                  Net Open Position (NOP) & Hedge Ratios
                </h3>

                <div className="flex flex-col gap-4 text-xs">
                  <div className="flex justify-between border-b border-[#30363D] pb-2">
                    <span className="font-semibold text-slate-400">Currency</span>
                    <span className="font-semibold text-slate-400">Gross exposure</span>
                    <span className="font-semibold text-slate-400">Net open</span>
                  </div>

                  <div className="flex justify-between items-center bg-[#161B22] p-2 rounded border border-[#30363D]">
                    <span className="font-bold font-mono text-white">EUR</span>
                    <span className="font-mono text-slate-300">$50M</span>
                    <span className="font-mono text-emerald-400 font-bold">$2.4M</span>
                  </div>

                  <div className="flex justify-between items-center bg-[#161B22] p-2 rounded border border-[#30363D]">
                    <span className="font-bold font-mono text-white">GBP</span>
                    <span className="font-mono text-slate-300">$25M</span>
                    <span className="font-mono text-emerald-400 font-bold">$1.1M</span>
                  </div>

                  <div className="flex justify-between items-center bg-[#161B22] p-2 rounded border border-[#30363D]">
                    <span className="font-bold font-mono text-white">JPY</span>
                    <span className="font-mono text-slate-300">$85M</span>
                    <span className="font-mono text-rose-400 font-bold">-$4.2M</span>
                  </div>

                  <div className="mt-4 border-t border-[#30363D] pt-3">
                    <div className="flex justify-between text-xs text-slate-400 mb-1">
                      <span>Aggregate Portfolio Hedge Ratio</span>
                      <span className="font-bold text-white">92.4%</span>
                    </div>
                    <div className="w-full bg-[#161B22] h-2 rounded-full overflow-hidden">
                      <div className="bg-[#D4AF37] h-full rounded-full" style={{ width: "92.4%" }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
           {/* TAB 4: INTEREST RATE RISK */}
        {activeTab === "ir-risk" && (
          <div className="flex flex-col gap-6">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* Sidebar Tenor Tuner */}
              <div className="lg:col-span-1 bg-[#0D1117] p-5 rounded-xl border border-[#30363D] shadow-sm flex flex-col gap-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider border-b border-[#30363D] pb-2">
                  Yield Curve Bootstrapper
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Modify benchmark swap and bond rates to instantly reconstruct the Nelson-Siegel-Svensson zero curve.
                </p>

                {curveTenors.map((tenor, idx) => (
                  <div key={idx} className="flex flex-col gap-1 text-xs">
                    <div className="flex justify-between">
                      <span className="font-mono font-bold text-slate-300">
                        {tenor >= 1 ? `${tenor} Year` : `${tenor * 12} Month`} Key Rate
                      </span>
                      <span className="font-mono font-bold text-[#D4AF37]">
                        {(curveRates[idx] * 100).toFixed(2)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0.01"
                      max="0.08"
                      step="0.0005"
                      value={curveRates[idx]}
                      onChange={(e) => {
                        const next = [...curveRates];
                        next[idx] = parseFloat(e.target.value);
                        setCurveRates(next);
                      }}
                      className="w-full accent-[#D4AF37]"
                    />
                  </div>
                ))}
              </div>

              {/* Chart & Tables */}
              <div className="lg:col-span-3 flex flex-col gap-6">
                <div className="bg-[#0D1117] p-6 rounded-xl border border-[#30363D] shadow-sm">
                  <h3 className="text-base font-bold text-white mb-4">
                    Nelson-Siegel-Svensson Reconstructed Zero Curve
                  </h3>

                  {/* SVG Reconstructed Yield Curve */}
                  <div className="relative w-full h-64 bg-[#0A0C10] rounded-xl overflow-hidden p-4 border border-[#30363D] mb-4">
                    <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full">
                      {/* Grid lines */}
                      <line x1="10" y1="0" x2="10" y2="100" stroke="#22252c" strokeWidth="0.2" strokeDasharray="2,2" />
                      <line x1="30" y1="0" x2="30" y2="100" stroke="#22252c" strokeWidth="0.2" strokeDasharray="2,2" />
                      <line x1="60" y1="0" x2="60" y2="100" stroke="#22252c" strokeWidth="0.2" strokeDasharray="2,2" />
                      <line x1="90" y1="0" x2="90" y2="100" stroke="#22252c" strokeWidth="0.2" strokeDasharray="2,2" />
                      <line x1="0" y1="50" x2="100" y2="50" stroke="#22252c" strokeWidth="0.2" strokeDasharray="2,2" />

                      {/* Yield curve plot path */}
                      <path
                        d={(() => {
                          // Plot rates across tenors (interpolated)
                          const points: { x: number; y: number }[] = [];
                          for (let i = 0; i <= 30; i += 1) {
                            // Find approximate rate based on sliders
                            const r = curveRates[0] + (curveRates[6] - curveRates[0]) * (1 - Math.exp(-i / 5));
                            points.push({ x: i, y: r });
                          }

                          const yMax = Math.max(...curveRates, 0.08);

                          return (
                            "M 0 100 " +
                            points
                              .map((p) => {
                                const px = (p.x / 30) * 100;
                                const py = 100 - (p.y / yMax) * 80;
                                return `L ${px} ${py}`;
                              })
                              .join(" ")
                          );
                        })()}
                        fill="none"
                        stroke="#D4AF37"
                        strokeWidth="1.5"
                      />

                      {/* Dots on the curve */}
                      {curveTenors.map((t, idx) => {
                        const px = (t / 30) * 100;
                        const yMax = Math.max(...curveRates, 0.08);
                        const py = 100 - (curveRates[idx] / yMax) * 80;

                        return (
                          <circle
                            key={idx}
                            cx={px}
                            cy={py}
                            r="1.5"
                            fill="#ef4444"
                            stroke="#0D1117"
                            strokeWidth="0.5"
                          />
                        );
                      })}
                    </svg>

                    <div className="absolute right-4 bottom-4 bg-[#161B22]/95 text-slate-400 p-2 rounded border border-[#30363D] text-[9px] font-mono">
                      <span>Curve Tenor (0 to 30 Years)</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-[#161B22] p-4 rounded-lg border border-[#30363D]">
                      <h4 className="text-xs font-bold text-white mb-3 uppercase tracking-wider">
                        Duration Buckets (Ladder)
                      </h4>
                      <div className="flex flex-col gap-2 text-xs font-mono text-slate-300">
                        <div className="flex justify-between border-b border-[#30363D] pb-1 text-slate-400">
                          <span>Tenor Bracket</span>
                          <span>Interest Sensitivity (DV01)</span>
                        </div>
                        <div className="flex justify-between">
                          <span>0 - 1 Year</span>
                          <span className="text-emerald-400 font-bold">$12,450</span>
                        </div>
                        <div className="flex justify-between">
                          <span>1 - 5 Years</span>
                          <span className="text-emerald-400 font-bold">$42,800</span>
                        </div>
                        <div className="flex justify-between">
                          <span>5 - 10 Years</span>
                          <span className="text-emerald-400 font-bold">$85,150</span>
                        </div>
                        <div className="flex justify-between">
                          <span>10 - 30 Years</span>
                          <span className="text-rose-400 font-bold">-$125,400</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#161B22] p-4 rounded-lg border border-[#30363D]">
                      <h4 className="text-xs font-bold text-white mb-3 uppercase tracking-wider">
                        SABR Volatility Calibration Matrix
                      </h4>
                      <div className="flex flex-col gap-2 text-xs font-mono text-slate-300">
                        <div className="flex justify-between text-slate-400 border-b border-[#30363D] pb-1">
                          <span>Option Tenor</span>
                          <span>ATM Volatility</span>
                          <span>Beta Parameters</span>
                        </div>
                        <div className="flex justify-between">
                          <span>1 Month</span>
                          <span>14.5%</span>
                          <span>0.50</span>
                        </div>
                        <div className="flex justify-between">
                          <span>6 Months</span>
                          <span>16.2%</span>
                          <span>0.50</span>
                        </div>
                        <div className="flex justify-between">
                          <span>1 Year</span>
                          <span>18.1%</span>
                          <span>0.50</span>
                        </div>
                        <div className="flex justify-between">
                          <span>5 Years</span>
                          <span>19.5%</span>
                          <span>0.50</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: STRUCTURED CREDIT */}
        {activeTab === "structured-credit" && (
          <div className="flex flex-col gap-6">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* Sidebar Parameters */}
              <div className="lg:col-span-1 bg-[#0D1117] p-5 rounded-xl border border-[#30363D] shadow-sm flex flex-col gap-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider border-b border-[#30363D] pb-2">
                  Collateral Pool Specs
                </h3>

                <div className="flex flex-col gap-1 text-xs">
                  <div className="flex justify-between font-mono">
                    <span className="font-semibold text-slate-300">Asset Correlation</span>
                    <span className="font-bold text-[#D4AF37]">{(assetCorrelation * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.05"
                    max="0.50"
                    step="0.05"
                    value={assetCorrelation}
                    onChange={(e) => setAssetCorrelation(parseFloat(e.target.value))}
                    className="w-full accent-[#D4AF37]"
                  />
                </div>

                <div className="flex flex-col gap-1 text-xs">
                  <div className="flex justify-between font-mono">
                    <span className="font-semibold text-slate-300">Expected Default PD</span>
                    <span className="font-bold text-[#D4AF37]">{(poolPD * 100).toFixed(2)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.01"
                    max="0.10"
                    step="0.002"
                    value={poolPD}
                    onChange={(e) => setPoolPD(parseFloat(e.target.value))}
                    className="w-full accent-[#D4AF37]"
                  />
                </div>

                <div className="flex flex-col gap-1 text-xs">
                  <div className="flex justify-between font-mono">
                    <span className="font-semibold text-slate-300">Recovery LGD</span>
                    <span className="font-bold text-[#D4AF37]">{(poolLGD * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.30"
                    max="0.80"
                    step="0.05"
                    value={poolLGD}
                    onChange={(e) => setPoolLGD(parseFloat(e.target.value))}
                    className="w-full accent-[#D4AF37]"
                  />
                </div>

                <div className="flex flex-col gap-1 text-xs">
                  <div className="flex justify-between font-mono">
                    <span className="font-semibold text-slate-300">Simulated Pool Loss</span>
                    <span className="font-bold text-rose-400">${(simulatedLoss / 1000000).toFixed(1)}M</span>
                  </div>
                  <input
                    type="range"
                    min="1000000"
                    max="100000000"
                    step="1000000"
                    value={simulatedLoss}
                    onChange={(e) => setSimulatedLoss(parseInt(e.target.value))}
                    className="w-full accent-[#D4AF37]"
                  />
                </div>
              </div>

              {/* Waterfall visualizer */}
              <div className="lg:col-span-3 bg-[#0D1117] p-6 rounded-xl border border-[#30363D] shadow-sm flex flex-col gap-6">
                <div>
                  <h3 className="text-base font-bold text-white">Synthetic CDO Tranche loss waterfall allocation</h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Losses are absorbed bottom-up: Equity tranches bear initial defaults, protecting senior layers.
                  </p>
                </div>

                {/* Tranche stack diagram */}
                <div className="flex flex-col gap-4">
                  {tranches.map((tranche, idx) => (
                    <div key={idx} className="flex flex-col gap-1.5 text-xs font-mono">
                      <div className="flex justify-between font-bold text-slate-300">
                        <span>{tranche.name}</span>
                        <span>
                          Attachment: {(tranche.attachment * 100).toFixed(0)}% - Detachment: {(tranche.detachment * 100).toFixed(0)}%
                        </span>
                      </div>

                      {/* Tranche container */}
                      <div className="relative w-full h-10 bg-[#161B22] rounded border border-[#30363D] overflow-hidden flex items-center justify-between px-4">
                        {/* Shaded Loss Block */}
                        <div
                          className="absolute left-0 top-0 bottom-0 bg-red-500/20 border-r border-red-500 transition-all duration-300"
                          style={{ width: `${tranche.lossPercentage}%` }}
                        ></div>

                        {/* Text Overlay */}
                        <span className="z-10 font-semibold text-white">
                          Remaining Principal: ${(tranche.remainingNotional / 1000000).toFixed(1)}M / ${(tranche.originalNotional / 1000000).toFixed(1)}M
                        </span>

                        <span className="z-10 text-[10px] font-bold text-rose-400 bg-red-500/10 px-1.5 py-0.5 rounded border border-red-500/30">
                          Loss: {tranche.lossPercentage.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Detailed Table */}
                <div className="overflow-x-auto border border-[#30363D] rounded-lg">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#161B22] border-b border-[#30363D] font-bold text-slate-400 uppercase">
                        <th className="px-4 py-3">Tranche Class</th>
                        <th className="px-4 py-3 text-right">Original Size</th>
                        <th className="px-4 py-3 text-right">Loss Allocated</th>
                        <th className="px-4 py-3 text-right">Written-down Notional</th>
                        <th className="px-4 py-3 text-right">Credit Enhancement</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#30363D] font-mono text-slate-300">
                      {tranches.map((tr, idx) => (
                        <tr key={idx} className="hover:bg-[#161B22]/50">
                          <td className="px-4 py-3 font-semibold text-white">{tr.name}</td>
                          <td className="px-4 py-3 text-right">${tr.originalNotional.toLocaleString()}</td>
                          <td className="px-4 py-3 text-right text-rose-400 font-semibold">
                            ${tr.lossAllocated.toLocaleString()}
                          </td>
                          <td className="px-4 py-3 text-right font-semibold">
                            ${tr.remainingNotional.toLocaleString()}
                          </td>
                          <td className="px-4 py-3 text-right text-emerald-400 font-bold">
                            {tr.creditEnhancement.toFixed(1)}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: MONTE CARLO SIMULATION */}
        {activeTab === "monte-carlo" && (
          <div className="flex flex-col gap-6">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* Parameter Settings */}
              <div className="lg:col-span-1 bg-[#0D1117] p-5 rounded-xl border border-[#30363D] shadow-sm flex flex-col gap-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider border-b border-[#30363D] pb-2">
                  Stochastic Parameters
                </h3>

                <div className="flex flex-col gap-1.5 text-xs">
                  <label className="font-semibold text-slate-400">Simulation Model</label>
                  <select
                    value={mcModel}
                    onChange={(e) => setMcModel(e.target.value as any)}
                    className="bg-[#161B22] border border-[#30363D] text-white rounded p-2 focus:outline-none"
                  >
                    <option value="VASICEK">Vasicek (Short-Rate)</option>
                    <option value="CIR">Cox-Ingersoll-Ross (CIR)</option>
                    <option value="GBM">Geometric Brownian Motion (Asset/FX)</option>
                    <option value="HULL_WHITE">Hull-White (Calibration-fitted)</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1 text-xs">
                  <div className="flex justify-between font-mono">
                    <span className="font-semibold text-slate-300">Starting S0 (Rate/Price)</span>
                    <span className="font-bold text-[#D4AF37]">{(mcS0 * 100).toFixed(2)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.01"
                    max="0.10"
                    step="0.005"
                    value={mcS0}
                    onChange={(e) => setMcS0(parseFloat(e.target.value))}
                    className="w-full accent-[#D4AF37]"
                  />
                </div>

                <div className="flex flex-col gap-1 text-xs">
                  <div className="flex justify-between font-mono">
                    <span className="font-semibold text-slate-300">
                      {mcModel === "GBM" ? "Drift (mu)" : "Mean Reversion Speed a"}
                    </span>
                    <span className="font-bold text-[#D4AF37]">{mcParam1.toFixed(3)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.01"
                    max="0.60"
                    step="0.02"
                    value={mcParam1}
                    onChange={(e) => setMcParam1(parseFloat(e.target.value))}
                    className="w-full accent-[#D4AF37]"
                  />
                </div>

                <div className="flex flex-col gap-1 text-xs">
                  <div className="flex justify-between font-mono">
                    <span className="font-semibold text-slate-300">
                      {mcModel === "GBM" ? "Asset Volatility (sigma)" : "Long-term Rate b"}
                    </span>
                    <span className="font-bold text-[#D4AF37]">
                      {mcModel === "GBM" ? `${(mcParam2 * 100).toFixed(1)}%` : `${(mcParam2 * 100).toFixed(2)}%`}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.01"
                    max="0.30"
                    step="0.01"
                    value={mcParam2}
                    onChange={(e) => setMcParam2(parseFloat(e.target.value))}
                    className="w-full accent-[#D4AF37]"
                  />
                </div>

                {mcModel !== "GBM" && (
                  <div className="flex flex-col gap-1 text-xs">
                    <div className="flex justify-between font-mono">
                      <span className="font-semibold text-slate-300">Short Rate Volatility (sigma)</span>
                      <span className="font-bold text-[#D4AF37]">{(mcParam3 * 100).toFixed(2)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.005"
                      max="0.05"
                      step="0.002"
                      value={mcParam3}
                      onChange={(e) => setMcParam3(parseFloat(e.target.value))}
                      className="w-full accent-[#D4AF37]"
                    />
                  </div>
                )}

                <button
                  onClick={runMonteCarlo}
                  className="bg-[#D4AF37] text-[#0A0C10] font-bold py-2 px-4 rounded hover:bg-white transition-all text-xs"
                >
                  Re-run Monte Carlo Simulation
                </button>
              </div>

              {/* Path Chart and statistics */}
              <div className="lg:col-span-3 bg-[#0D1117] p-6 rounded-xl border border-[#30363D] shadow-sm flex flex-col gap-6">
                <div>
                  <h3 className="text-base font-bold text-white">
                    Stochastic Path Projections (Monte Carlo paths)
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Simulated stochastic trajectories over a 5-year valuation horizon based on the chosen differential equation.
                  </p>
                </div>

                {/* SVG Paths Chart */}
                <div className="relative w-full h-80 bg-[#0A0C10] rounded-xl overflow-hidden p-4 border border-[#30363D]">
                  <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full">
                    {/* Grid lines */}
                    <line x1="20" y1="0" x2="20" y2="100" stroke="#22252c" strokeWidth="0.2" strokeDasharray="2,2" />
                    <line x1="40" y1="0" x2="40" y2="100" stroke="#22252c" strokeWidth="0.2" strokeDasharray="2,2" />
                    <line x1="60" y1="0" x2="60" y2="100" stroke="#22252c" strokeWidth="0.2" strokeDasharray="2,2" />
                    <line x1="80" y1="0" x2="80" y2="100" stroke="#22252c" strokeWidth="0.2" strokeDasharray="2,2" />
                    <line x1="0" y1="50" x2="100" y2="50" stroke="#22252c" strokeWidth="0.2" strokeDasharray="2,2" />

                    {/* Paths Plot */}
                    {simulatedMCData.map((path, pathIdx) => {
                      const maxVal = Math.max(...simulatedMCData.flat(), 0.10);
                      const minVal = Math.min(...simulatedMCData.flat(), 0.0);

                      return (
                        <path
                          key={pathIdx}
                          d={path
                            .map((val, stepIdx) => {
                              const px = (stepIdx / mcSteps) * 100;
                              const py = 100 - ((val - minVal) / (maxVal - minVal)) * 80 - 10;
                              return `${stepIdx === 0 ? "M" : "L"} ${px} ${py}`;
                            })
                            .join(" ")}
                          fill="none"
                          stroke={pathIdx === 0 ? "#ef4444" : `rgba(212, 175, 55, ${0.4 + (pathIdx % 5) * 0.1})`}
                          strokeWidth={pathIdx === 0 ? "1" : "0.5"}
                        />
                      );
                    })}
                  </svg>

                  <div className="absolute top-4 left-4 bg-[#161B22]/90 text-slate-300 p-2 rounded border border-[#30363D] text-[10px] font-mono">
                    <span className="font-bold text-[#D4AF37]">Active Model: {mcModel}</span>
                    <span className="block text-[9px] text-slate-500 mt-1">Paths simulated: {mcPaths} paths</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: STRESS TESTING */}
        {activeTab === "stress-testing" && (
          <div className="flex flex-col gap-6">
            <div className="bg-[#0D1117] p-6 rounded-xl border border-[#30363D] shadow-sm">
              <h3 className="text-base font-bold text-white mb-2">Macro-Financial Crisis Scenario Center</h3>
              <p className="text-xs text-slate-400 mb-6">
                Apply correlated multi-asset risk shocks to evaluate the instantaneous systemic impact on Rhino Bank's balance sheet.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {CRISIS_SCENARIOS.map((scen) => (
                  <div
                    key={scen.id}
                    className={`p-5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between h-52 ${
                      activeScenarioId === scen.id
                        ? "bg-[#1b222d] border-[#D4AF37] shadow-inner text-[#E6EDF3]"
                        : "bg-[#161B22] border-[#30363D] hover:border-slate-500 text-slate-300"
                    }`}
                    onClick={() => applyScenario(scen)}
                  >
                    <div>
                      <div className="flex justify-between items-start">
                        <h4 className="font-bold text-white text-sm leading-tight">{scen.name}</h4>
                        {activeScenarioId === scen.id && (
                          <span className="bg-[#D4AF37] text-[#0A0C10] font-mono text-[9px] px-1.5 py-0.5 rounded font-bold animate-pulse">
                            Active Shock
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-2 leading-relaxed line-clamp-4">
                        {scen.description}
                      </p>
                    </div>

                    <button className="text-xs font-bold text-[#D4AF37] hover:text-white underline text-left mt-3">
                      Apply Shock Matrix
                    </button>
                  </div>
                ))}
              </div>

              {/* Stress Results Ledger */}
              {activeScenarioId && (
                <div className="bg-[#0D1117] text-[#E6EDF3] p-6 rounded-xl border border-[#30363D] shadow-xl">
                  <h4 className="text-xs font-mono font-bold tracking-wider text-[#D4AF37] uppercase border-b border-[#30363D] pb-3 mb-4">
                    Instantaneous Portfolio Shock Ledger & Valuation Impact
                  </h4>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div className="bg-[#161B22] p-4 rounded border border-[#30363D] text-xs font-mono">
                      <span className="text-slate-400">Yield Curve Shock</span>
                      <span className="text-base font-bold text-white block mt-1">
                        {ratesShift > 0 ? `+${ratesShift}` : ratesShift} bps Shift
                      </span>
                    </div>
                    <div className="bg-[#161B22] p-4 rounded border border-[#30363D] text-xs font-mono">
                      <span className="text-slate-400">FX Spot Shift</span>
                      <span className="text-base font-bold text-white block mt-1">
                        {fxShock > 0 ? `+${fxShock}` : fxShock}% Dollar change
                      </span>
                    </div>
                    <div className="bg-[#161B22] p-4 rounded border border-[#30363D] text-xs font-mono">
                      <span className="text-slate-400">Portfolio NPV Change</span>
                      <span className="text-base font-bold text-red-400 block mt-1">
                        -$2,850,000 (Estimate)
                      </span>
                    </div>
                    <div className="bg-[#161B22] p-4 rounded border border-[#30363D] text-xs font-mono">
                      <span className="text-slate-400">Liquidity Hazard Level</span>
                      <span className="text-base font-bold text-rose-400 block mt-1">
                        Severe (Alert Tier 2)
                      </span>
                    </div>
                  </div>

                  <div className="flex justify-end gap-3">
                    <button
                      onClick={resetStress}
                      className="bg-[#161B22] text-slate-300 font-mono text-xs hover:bg-[#21262D] transition-all py-2 px-4 rounded border border-[#30363D]"
                    >
                      Clear Shocks & Reset Baseline
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 8: R LIBRARY IDE */}
        {activeTab === "codebase" && (
          <div className="flex flex-col gap-6">
            <div>
              <h2 className="text-xl font-bold text-white">RhinoBank institutional R Source Code Library</h2>
              <p className="text-xs text-slate-400 mt-1">
                View, copy, or download any of the 19 quantitative script files deployed to the server container.
              </p>
            </div>
            <RCodeExplorer />
          </div>
        )}

        {/* TAB 9: EXECUTIVE REPORTS */}
        {activeTab === "reports" && (
          <div className="flex flex-col gap-6">
            <div className="bg-[#0D1117] p-6 rounded-xl border border-[#30363D] shadow-sm flex flex-col gap-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h3 className="text-base font-bold text-white">Institutional Report Publication Center</h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Generate compliance-ready daily summaries, treasury reports, and structured committee briefs.
                  </p>
                </div>
                <button
                  onClick={() => window.print()}
                  className="flex items-center gap-2 bg-[#D4AF37] text-[#0A0C10] hover:bg-white transition-all font-semibold py-2 px-4 rounded-lg text-xs"
                >
                  <Printer className="h-4 w-4" />
                  Print Compliance PDF
                </button>
              </div>

              {/* Print layout representation (Light background preserved for readable print look) */}
              <div className="border border-stone-300 p-8 rounded bg-white shadow-sm font-serif max-w-4xl mx-auto w-full text-stone-800 leading-relaxed text-sm">
                {/* Letterhead */}
                <div className="text-center border-b-2 border-stone-900 pb-4 mb-6">
                  <h2 className="text-xl font-bold font-sans tracking-wide">RHINO BANK</h2>
                  <p className="text-[10px] font-mono tracking-widest text-stone-500 uppercase mt-1">
                    DIVISION OF RISK & QUANTITATIVE INFRASTRUCTURE
                  </p>
                  <p className="text-[11px] font-sans text-stone-500 mt-1">
                    London Enclave • UK-South Zone • Strict Internal Distribution
                  </p>
                </div>

                <div className="flex justify-between font-sans text-xs text-stone-600 mb-6">
                  <div>
                    <strong>Date:</strong> 2026-07-26
                  </div>
                  <div>
                    <strong>Classification:</strong> Internal Use Only
                  </div>
                </div>

                <h3 className="text-lg font-bold text-stone-900 mb-4 font-sans border-b border-stone-200 pb-1">
                  Daily Institutional Market-Risk & Derivatives Position Report
                </h3>

                <p className="mb-4">
                  This executive packet provides the valuation of derivative contracts held on the balance sheet of
                  Rhino Bank, alongside stress revaluations, parametric Value-at-Risk forecasts, and structured credit tranche waterfalls.
                </p>

                <h4 className="text-sm font-bold font-sans text-stone-900 mt-6 mb-2">
                  1. Current Portfolio Valuation Metrics
                </h4>
                <div className="overflow-x-auto mb-6">
                  <table className="w-full text-left text-xs border-collapse font-sans">
                    <thead>
                      <tr className="border-b border-stone-400 bg-stone-50 font-bold">
                        <th className="py-2">Contract ID</th>
                        <th className="py-2">Description</th>
                        <th className="py-2 text-right">Notional</th>
                        <th className="py-2 text-right">NPV</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {positions.map((pos) => (
                        <tr key={pos.id}>
                          <td className="py-2 font-mono">{pos.id}</td>
                          <td className="py-2">{pos.name}</td>
                          <td className="py-2 text-right font-mono">${pos.notional.toLocaleString()}</td>
                          <td className="py-2 text-right font-mono">${pos.marketPrice.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <h4 className="text-sm font-bold font-sans text-stone-900 mt-6 mb-2">
                  2. Risk Measures Summary (VaR)
                </h4>
                <p className="mb-4">
                  The portfolio VaR has been calculated assuming a 250-session historical lookback, alongside parametric covariance tracking:
                </p>
                <ul className="list-disc list-inside mb-6 text-xs font-sans space-y-1">
                  <li>
                    <strong>Parametric VaR (99%, 1-Day):</strong> $
                    {marketRisk?.parametricVaR.toLocaleString(undefined, { maximumFractionDigits: 0 }) || ""}
                  </li>
                  <li>
                    <strong>Historical VaR (99%, 1-Day):</strong> $
                    {marketRisk?.historicalVaR.toLocaleString(undefined, { maximumFractionDigits: 0 }) || ""}
                  </li>
                  <li>
                    <strong>Expected Shortfall (ES):</strong> $
                    {marketRisk?.historicalES.toLocaleString(undefined, { maximumFractionDigits: 0 }) || ""}
                  </li>
                </ul>

                <h4 className="text-sm font-bold font-sans text-stone-900 mt-6 mb-2">
                  3. Executive Certification
                </h4>
                <p className="text-xs italic text-stone-500 mb-8 mt-2">
                  This quantitative assessment was compiled and certified by the Rhino Bank Derivatives Valuations & Stress Analytics Desk using the verified R6 R quantitative infrastructure.
                </p>

                <div className="flex justify-between border-t border-stone-200 pt-6 font-sans text-xs text-stone-600">
                  <div>
                    <p className="font-bold text-stone-900">Dr. Helena Vance</p>
                    <p>Head of Market Risk Analytics</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-stone-900">Professor Arthur Pendelton</p>
                    <p>Executive Risk Chair Committee</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Corporate footer */}
      <footer className="bg-[#0A0C10] text-slate-400 py-6 border-t border-[#30363D] text-xs font-mono">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <span>© 2026 Rhino Bank Plc. All quantitative models are registered and audited internally.</span>
          <div className="flex gap-4">
            <a href="#reports" onClick={() => setActiveTab("reports")} className="hover:text-white transition-all underline">
              Compliance Reports
            </a>
            <a href="#codebase" onClick={() => setActiveTab("codebase")} className="hover:text-white transition-all underline">
              R Source Library
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
