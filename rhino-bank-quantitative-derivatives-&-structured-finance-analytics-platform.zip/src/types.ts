export type InstrumentType =
  | "FX_FORWARD"
  | "FX_SWAP"
  | "CURRENCY_OPTION"
  | "IRS"
  | "FRA"
  | "CAP_FLOOR"
  | "SWAPTION"
  | "GOV_BOND"
  | "CORP_BOND"
  | "FRN"
  | "CLN"
  | "STRUCTURED_CREDIT";

export interface Position {
  id: string;
  name: string;
  type: InstrumentType;
  currency: string;
  notional: number;
  maturityYears: number;
  marketPrice: number;
  greeks: {
    delta: number;
    gamma: number;
    vega: number;
    theta: number;
    rho: number;
    pv01: number;
    dv01: number;
  };
  details: Record<string, any>;
}

export interface Cashflow {
  time: number;
  dateString: string;
  coupon: number;
  principal: number;
  discountFactor: number;
  pv: number;
}

export interface Tranche {
  name: string;
  attachment: number;
  detachment: number;
  originalNotional: number;
  lossAllocated: number;
  remainingNotional: number;
  lossPercentage: number;
  creditEnhancement: number;
}

export interface MarketRiskResult {
  parametricVaR: number;
  parametricES: number;
  historicalVaR: number;
  historicalES: number;
  monteCarloVaR: number;
  monteCarloES: number;
  distribution: { x: number; y: number; isVaR: boolean; isES: boolean }[];
}

export interface MacroScenario {
  id: string;
  name: string;
  description: string;
  ratesShiftBps: number;
  fxShockPercent: number;
  volShockPercent: number;
  creditSpreadWidenBps: number;
  defaultProbabilityMultiplier: number;
}
