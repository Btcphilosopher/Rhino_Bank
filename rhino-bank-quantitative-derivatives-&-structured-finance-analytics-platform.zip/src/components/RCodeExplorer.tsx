import React, { useState } from "react";
import { R_CODEBASE } from "../data/rFiles";
import { Copy, Check, Download, FileCode, Search, Terminal } from "lucide-react";

export default function RCodeExplorer() {
  const [selectedFile, setSelectedFile] = useState<string>("pricing_engine.R");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [copied, setCopied] = useState<boolean>(false);

  const filesList = Object.keys(R_CODEBASE).filter((f) =>
    f.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const currentFile = R_CODEBASE[selectedFile] || {
    desc: "",
    code: "# Select a file to view",
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(currentFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSingle = () => {
    const blob = new Blob([currentFile.code], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = selectedFile;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadAll = () => {
    // Generate a single combined quantitative package file for convenience
    let combined = `# Rhino Bank Derivatives & Structured Finance Analytics Library\n`;
    combined += `# Exported: ${new Date().toISOString()}\n\n`;
    Object.entries(R_CODEBASE).forEach(([filename, item]) => {
      combined += `\n# ==========================================\n`;
      combined += `# FILE: ${filename}\n`;
      combined += `# DESCRIPTION: ${item.desc}\n`;
      combined += `# ==========================================\n\n`;
      combined += item.code;
      combined += `\n\n`;
    });

    const blob = new Blob([combined], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "RhinoDerivatives_Full_Library.R";
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 bg-[#0D1117] p-4 rounded-xl border border-[#30363D]">
      {/* Sidebar: File Explorer */}
      <div className="lg:col-span-1 flex flex-col gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search R codebase..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#161B22] text-[#E6EDF3] placeholder-slate-500 text-sm pl-9 pr-4 py-2 rounded-lg border border-[#30363D] focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
          />
        </div>

        <div className="flex flex-col gap-1 overflow-y-auto max-h-[500px] border border-[#30363D] rounded-lg p-2 bg-[#161B22]">
          <div className="px-2 py-1 text-[11px] font-semibold text-slate-500 tracking-wider uppercase">
            R Source Files
          </div>
          {filesList.map((filename) => (
            <button
              key={filename}
              onClick={() => setSelectedFile(filename)}
              className={`flex items-center gap-2 px-3 py-2 rounded-md text-left text-xs font-medium transition-all ${
                selectedFile === filename
                  ? "bg-[#21262D] text-white border-l-2 border-[#D4AF37] font-semibold"
                  : "text-slate-400 hover:bg-[#21262D]/50 hover:text-white"
              }`}
            >
              <FileCode className="h-4 w-4 shrink-0 opacity-80" />
              <span className="truncate">{filename}</span>
            </button>
          ))}
          {filesList.length === 0 && (
            <div className="text-center text-xs text-slate-500 py-4">
              No matching files found.
            </div>
          )}
        </div>

        <button
          onClick={handleDownloadAll}
          className="flex items-center justify-center gap-2 bg-[#D4AF37] text-[#0A0C10] hover:bg-[#c2a032] transition-all font-semibold py-2 px-4 rounded-lg text-xs"
        >
          <Download className="h-4 w-4" />
          Export Complete Library
        </button>
      </div>

      {/* Code Viewer Editor */}
      <div className="lg:col-span-3 flex flex-col border border-[#30363D] rounded-xl bg-[#161B22] shadow-inner overflow-hidden">
        {/* Header toolbar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-4 py-3 bg-[#0D1117] border-b border-[#30363D]">
          <div className="flex items-center gap-2">
            <Terminal className="h-4 w-4 text-[#D4AF37]" />
            <span className="text-slate-300 text-xs font-mono font-semibold">
              /RhinoDerivatives/R/{selectedFile}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-slate-400 hover:text-white hover:bg-[#21262D] transition-all text-xs font-mono border border-[#30363D]"
              title="Copy to Clipboard"
            >
              {copied ? (
                <>
                  <Check className="h-3.5 w-3.5 text-green-400" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  Copy
                </>
              )}
            </button>
            <button
              onClick={handleDownloadSingle}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-slate-400 hover:text-white hover:bg-[#21262D] transition-all text-xs font-mono border border-[#30363D]"
              title="Download File"
            >
              <Download className="h-3.5 w-3.5" />
              Download
            </button>
          </div>
        </div>

        {/* File Description */}
        <div className="bg-[#0D1117]/60 px-4 py-2 border-b border-[#30363D] text-slate-400 text-xs italic">
          {currentFile.desc}
        </div>

        {/* Code Content */}
        <div className="p-4 overflow-x-auto overflow-y-auto max-h-[450px] bg-[#0A0C10]">
          <pre className="text-slate-300 font-mono text-xs leading-relaxed">
            <code>{currentFile.code}</code>
          </pre>
        </div>
      </div>
    </div>
  );
}
