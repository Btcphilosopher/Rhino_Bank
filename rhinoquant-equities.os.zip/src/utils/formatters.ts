/**
 * Safe Time & Currency Formatters for RHINOQUANT EQUITIES.OS
 */

export function formatTimeDisplay(ts?: string): string {
  if (!ts) return '';
  if (ts.includes('T')) {
    const timePart = ts.split('T')[1];
    return timePart ? timePart.replace('Z', '') : ts;
  }
  return ts.replace('Z', '');
}
