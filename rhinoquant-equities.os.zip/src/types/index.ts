/**
 * RHINOQUANT EQUITIES.OS - Executable Stock Market Trading Infrastructure
 * Type definitions for Market Data, OMS/EMS, Risk, Smart Router, Portfolio, Settlement, Audit
 */

export type EnvironmentMode = 'SIMULATION' | 'PAPER' | 'TEST';

export type PrimaryView =
  | 'MARKETS'
  | 'WATCHLIST'
  | 'ORDERS'
  | 'EXECUTION'
  | 'POSITIONS'
  | 'PORTFOLIO'
  | 'RISK'
  | 'ALGORITHMS'
  | 'ROUTING'
  | 'VENUES'
  | 'RESEARCH'
  | 'SIMULATION'
  | 'CLEARING'
  | 'SETTLEMENT'
  | 'RECON'
  | 'SURVEILLANCE'
  | 'AUDIT'
  | 'TERMINAL';

export type SecondaryView =
  | 'SECURITIES'
  | 'INDICES'
  | 'SECTORS'
  | 'CORPORATE_ACTIONS'
  | 'REFERENCE_DATA'
  | 'ACCOUNTS'
  | 'BROKERS'
  | 'MODELS'
  | 'SCENARIOS'
  | 'SETTINGS';

export interface Security {
  securityId: string;
  symbol: string;
  companyName: string;
  country: string;
  exchange: string;
  currency: string;
  sector: string;
  industry: string;
  lotSize: number;
  tickSize: number;
  status: 'ACTIVE' | 'HALTED' | 'SUSPENDED' | 'PRE_MARKET' | 'CLOSED';
  primaryVenue: string;
  marketCap: number; // in USD
  sharesOutstanding: number;
  freeFloat: number;
  dividendYield: number;
  earningsDate: string;
  corporateActionStatus: 'NONE' | 'SPLIT_PENDING' | 'DIVIDEND_DECLARED' | 'MERGER_PENDING';
  isSynthetic: true;
}

export interface VenueQuote {
  venueId: string;
  venueName: string;
  bidPrice: number;
  bidSize: number;
  askPrice: number;
  askSize: number;
  latencyMs: number;
  feeBp: number;
  depth: number;
  liquidityScore: number;
}

export interface OrderBookLevel {
  price: number;
  size: number;
  ordersCount: number;
  venue?: string;
}

export interface OrderBookDepth {
  symbol: string;
  timestamp: string;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  spread: number;
  mid: number;
  imbalanceRatio: number; // -1 to +1 (negative = sell imbalance, positive = buy imbalance)
  estimatedImpactBp: number;
}

export interface TradeTapeItem {
  tradeId: string;
  timestamp: string;
  highResTs: number;
  symbol: string;
  price: number;
  size: number;
  venue: string;
  side: 'BUY' | 'SELL' | 'CROSS';
  condition: 'REGULAR' | 'SWEEP' | 'AUCTION' | 'DARK';
}

export interface AuctionImbalance {
  symbol: string;
  auctionType: 'OPENING' | 'CLOSING';
  indicativePrice: number;
  buyVolume: number;
  sellVolume: number;
  imbalanceVolume: number;
  imbalanceDirection: 'BUY_SURPLUS' | 'SELL_SURPLUS' | 'MATCHED';
  clearingPrice: number;
}

export type OrderSide = 'BUY' | 'SELL';

export type OrderType =
  | 'MARKET'
  | 'LIMIT'
  | 'STOP'
  | 'STOP_LIMIT'
  | 'IOC'
  | 'FOK'
  | 'DAY'
  | 'GTC'
  | 'GTD'
  | 'MOO'
  | 'MOC';

export type TimeInForce = 'DAY' | 'GTC' | 'GTD' | 'IOC' | 'FOK' | 'OPG' | 'CLS';

export type OrderState =
  | 'CREATED'
  | 'VALIDATING'
  | 'RISK_CHECK'
  | 'APPROVED'
  | 'ROUTING'
  | 'WORKING'
  | 'PARTIALLY_FILLED'
  | 'FILLED'
  | 'CANCELLED'
  | 'REJECTED'
  | 'EXPIRED'
  | 'REPLACED'
  | 'SUSPENDED';

export type AlgoStrategy =
  | 'DIRECT'
  | 'SMART_ROUTE'
  | 'VWAP'
  | 'TWAP'
  | 'POV'
  | 'IMPLEMENTATION_SHORTFALL'
  | 'ARRIVAL_PRICE'
  | 'ICEBERG'
  | 'PARTICIPATION';

export interface PreTradeRiskCheck {
  positionLimit: { status: 'PASS' | 'FAIL'; currentVal: number; maxLimit: number; detail: string };
  notionalLimit: { status: 'PASS' | 'FAIL'; currentVal: number; maxLimit: number; detail: string };
  priceCollar: { status: 'PASS' | 'FAIL'; currentPrice: number; collarRange: [number, number]; detail: string };
  buyingPower: { status: 'PASS' | 'FAIL'; requiredMargin: number; availableBuyingPower: number; detail: string };
  marketStatus: { status: 'PASS' | 'FAIL'; marketState: string; detail: string };
  securityStatus: { status: 'PASS' | 'FAIL'; securityState: string; detail: string };
  riskLimitOverall: { status: 'PASS' | 'FAIL'; overallScore: number; detail: string };
  overallPassed: boolean;
  rejectionReason?: string;
  recommendedAction?: string;
}

export interface ChildOrder {
  childId: string;
  parentId: string;
  symbol: string;
  venue: string;
  side: OrderSide;
  quantity: number;
  filledQuantity: number;
  price: number;
  status: OrderState;
  createdAt: string;
  updatedAt: string;
  latencyMs: number;
  feesPaid: number;
  avgFillPrice: number;
}

export interface Fill {
  fillId: string;
  orderId: string;
  childOrderId?: string;
  symbol: string;
  venue: string;
  price: number;
  quantity: number;
  timestamp: string;
  highResTs: number;
  liquidityRole: 'MAKER' | 'TAKER';
  fee: number;
  execBpImprovement: number;
}

export interface Order {
  orderId: string;
  clientId: string;
  account: string;
  trader: string;
  symbol: string;
  side: OrderSide;
  quantity: number;
  filledQuantity: number;
  remainingQuantity: number;
  orderType: OrderType;
  limitPrice?: number;
  stopPrice?: number;
  timeInForce: TimeInForce;
  algoStrategy: AlgoStrategy;
  algoParameters?: {
    windowMinutes?: number;
    targetParticipationPct?: number;
    maxSlippageBp?: number;
    icebergDisplaySize?: number;
  };
  state: OrderState;
  stateHistory: Array<{ state: OrderState; timestamp: string; note: string }>;
  createdAt: string;
  updatedAt: string;
  highResTsCreated: number;
  highResTsExecuted?: number;
  avgFillPrice: number;
  arrivalPrice: number;
  vwapBenchmark: number;
  slippageBp: number;
  spreadCost: number;
  marketImpactBp: number;
  totalFees: number;
  preTradeRisk: PreTradeRiskCheck;
  childOrders: ChildOrder[];
  fills: Fill[];
  routingDecision?: RoutingDecision;
  settlementInstructionId?: string;
  fixMessages: string[];
}

export interface RoutingDecision {
  orderId: string;
  timestamp: string;
  orderQuantity: number;
  symbol: string;
  venueSplits: Array<{
    venueId: string;
    venueName: string;
    allocatedShares: number;
    targetPrice: number;
    latencyMs: number;
    estimatedFeeBp: number;
    reason: string;
  }>;
  explanation: string;
}

export interface Position {
  securityId: string;
  symbol: string;
  companyName: string;
  quantity: number; // positive = LONG, negative = SHORT, 0 = FLAT
  avgPrice: number;
  marketPrice: number;
  marketValue: number;
  unrealizedPnL: number;
  unrealizedPnLPct: number;
  realizedPnL: number;
  costBasis: number;
  weightPct: number;
  side: 'LONG' | 'SHORT' | 'FLAT';
  borrowRatePct?: number;
  borrowCostDaily?: number;
  locateStatus?: 'APPROVED' | 'PENDING' | 'NOT_REQUIRED';
}

export interface AccountPortfolio {
  firmName: string;
  strategyName: string;
  fundName: string;
  accountId: string;
  traderName: string;
  cashBalance: number;
  settledCash: number;
  unsettledCash: number;
  buyingPower: number;
  marginUsed: number;
  totalMarketValue: number;
  totalEquity: number;
  dailyRealizedPnL: number;
  dailyUnrealizedPnL: number;
  totalPnL: number;
  sectorAllocations: Record<string, number>;
  countryAllocations: Record<string, number>;
  positions: Position[];
}

export interface PortfolioRiskMetrics {
  beta: number;
  volatilityPct: number;
  var95_1D: number; // 95% 1-Day Value at Risk in USD
  expectedShortfall: number;
  trackingErrorPct: number;
  activeSharePct: number;
  top3ConcentrationPct: number;
  factors: {
    market: number;
    size: number;
    value: number;
    momentum: number;
    quality: number;
    volatility: number;
  };
  factorContributions: Record<string, number>;
}

export interface StressScenarioResult {
  scenarioName: string;
  marketMovePct: number;
  estimatedPnL: number;
  marginRequirementAfter: number;
  liquidityShortfallUsd: number;
  maxDrawdownPct: number;
  riskStatus: 'SAFE' | 'WARNING' | 'BREACH';
}

export interface DoubleEntryLedgerAccount {
  accountCode: string;
  accountName: 'CASH' | 'SECURITIES' | 'RECEIVABLE' | 'PAYABLE' | 'P_AND_L' | 'FEES' | 'BORROW' | 'MARGIN';
  balance: number;
}

export interface LedgerEntry {
  entryId: string;
  timestamp: string;
  orderId?: string;
  description: string;
  debitAccount: string;
  debitAmount: number;
  creditAccount: string;
  creditAmount: number;
  balanced: boolean;
}

export interface SettlementInstruction {
  instructionId: string;
  orderId: string;
  tradeDate: string;
  settlementDate: string; // e.g. T+1 or T+2
  symbol: string;
  quantity: number;
  grossAmount: number;
  netAmount: number;
  counterpartyVenue: string;
  clearingStatus: 'UNMATCHED' | 'MATCHED' | 'CLEARING' | 'SETTLED' | 'FAILED';
  cashDelivered: boolean;
  securityDelivered: boolean;
}

export interface ReconciliationBreak {
  breakId: string;
  timestamp: string;
  symbol: string;
  internalQty: number;
  clearingQty: number;
  custodyQty: number;
  diffQty: number;
  status: 'OPEN_BREAK' | 'INVESTIGATING' | 'RESOLVED';
  reason: string;
  originEvent: string;
}

export interface AuditEvent {
  eventId: string;
  timestamp: string;
  highResTs: number;
  user: string;
  action: string;
  orderId?: string;
  securitySymbol?: string;
  oldState?: string;
  newState?: string;
  routingDecision?: string;
  details: string;
  sourceComponent: 'OMS' | 'ROUTER' | 'RISK_ENGINE' | 'MATCHING_ENGINE' | 'LEDGER' | 'SYSTEM';
}

export interface SurveillanceAlert {
  alertId: string;
  timestamp: string;
  symbol: string;
  orderId?: string;
  type: 'UNUSUAL_CANCEL' | 'PRICE_ANOMALY' | 'HIGH_VOLUME' | 'LIMIT_BREACH' | 'RAPID_MODIFY';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  description: string;
  isSimulated: true;
}

export interface MarketShockConfig {
  marketDropPct: number;
  volatilityIncreasePct: number;
  liquidityDropPct: number;
  shockType: 'GENERAL_CRASH' | 'TECH_SHOCK' | 'BANKING_SHOCK' | 'ENERGY_SHOCK' | 'RATE_HIKE';
}

export interface AlgorithmRun {
  runId: string;
  algoType: AlgoStrategy;
  symbol: string;
  parentOrderId: string;
  totalQuantity: number;
  filledQuantity: number;
  remainingQuantity: number;
  windowMinutes: number;
  elapsedMinutes: number;
  targetParticipationPct: number;
  actualParticipationPct: number;
  expectedVwap: number;
  executedVwap: number;
  slippageBp: number;
  status: 'SCHEDULED' | 'RUNNING' | 'PAUSED' | 'COMPLETED' | 'CANCELLED';
  timeline: Array<{
    minute: number;
    targetQty: number;
    cumExecutedQty: number;
    marketVwap: number;
    algoVwap: number;
  }>;
}
