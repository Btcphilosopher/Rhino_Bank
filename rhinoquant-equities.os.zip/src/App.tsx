/**
 * RHINOQUANT EQUITIES.OS - Main Operating System Application Container
 * Institutional Stock Market Trading Infrastructure
 */

import React, { useState } from 'react';
import { EnvironmentMode, PrimaryView, SecondaryView } from './types';
import { GlobalHeader } from './components/GlobalHeader';
import { PrimaryNav } from './components/PrimaryNav';
import { CommandPalette } from './components/CommandPalette';
import { RhinoTerminalMode } from './components/RhinoTerminalMode';
import { OrderTicketModal } from './components/OrderTicketModal';
import { AiAssistantDrawer } from './components/AiAssistantDrawer';

// Views
import { MarketsView } from './components/views/MarketsView';
import { OrdersView } from './components/views/OrdersView';
import { ExecutionAnalyticsView } from './components/views/ExecutionAnalyticsView';
import { RoutingView } from './components/views/RoutingView';
import { AlgorithmsView } from './components/views/AlgorithmsView';
import { PortfolioPositionsView } from './components/views/PortfolioPositionsView';
import { RiskView } from './components/views/RiskView';
import { SettlementLedgerView } from './components/views/SettlementLedgerView';
import { AuditTrailView } from './components/views/AuditTrailView';

export function App() {
  const [primaryView, setPrimaryView] = useState<PrimaryView>('MARKETS');
  const [secondaryView, setSecondaryView] = useState<SecondaryView>('SECURITIES');
  const [envMode, setEnvMode] = useState<EnvironmentMode>('SIMULATION');

  const [isOrderTicketOpen, setIsOrderTicketOpen] = useState<boolean>(false);
  const [orderTicketSymbol, setOrderTicketSymbol] = useState<string>('RQ-TECH-001');
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState<boolean>(false);
  const [isTerminalModeOpen, setIsTerminalModeOpen] = useState<boolean>(false);
  const [isAiCopilotOpen, setIsAiCopilotOpen] = useState<boolean>(false);

  const handleOpenTicketForSymbol = (sym: string) => {
    setOrderTicketSymbol(sym);
    setIsOrderTicketOpen(true);
  };

  const renderCurrentView = () => {
    switch (primaryView) {
      case 'MARKETS':
      case 'WATCHLIST':
        return <MarketsView onOpenOrderTicketForSymbol={handleOpenTicketForSymbol} />;
      case 'ORDERS':
        return <OrdersView onOpenOrderTicket={() => setIsOrderTicketOpen(true)} />;
      case 'EXECUTION':
        return <ExecutionAnalyticsView />;
      case 'ROUTING':
      case 'VENUES':
        return <RoutingView />;
      case 'ALGORITHMS':
        return <AlgorithmsView />;
      case 'POSITIONS':
      case 'PORTFOLIO':
        return <PortfolioPositionsView />;
      case 'RISK':
        return <RiskView />;
      case 'CLEARING':
      case 'SETTLEMENT':
      case 'RECON':
        return <SettlementLedgerView />;
      case 'AUDIT':
      case 'SURVEILLANCE':
        return <AuditTrailView />;
      default:
        return <MarketsView onOpenOrderTicketForSymbol={handleOpenTicketForSymbol} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#080a0e] text-slate-100 flex flex-col font-mono selection:bg-blue-600 selection:text-white">
      {/* Global Header */}
      <GlobalHeader
        envMode={envMode}
        setEnvMode={setEnvMode}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        onOpenTerminalMode={() => setIsTerminalModeOpen(true)}
        onOpenAiCopilot={() => setIsAiCopilotOpen(true)}
      />

      {/* Primary & Secondary Navigation */}
      <PrimaryNav
        currentPrimaryView={primaryView}
        setPrimaryView={setPrimaryView}
        currentSecondaryView={secondaryView}
        setSecondaryView={setSecondaryView}
        onOpenOrderTicket={() => setIsOrderTicketOpen(true)}
      />

      {/* Main OS Viewport Canvas */}
      <main className="flex-1 overflow-y-auto">
        {renderCurrentView()}
      </main>

      {/* Order Ticket Modal */}
      <OrderTicketModal
        isOpen={isOrderTicketOpen}
        onClose={() => setIsOrderTicketOpen(false)}
        defaultSymbol={orderTicketSymbol}
        defaultSide="BUY"
        defaultQuantity={25000}
        onOrderSubmitted={() => setPrimaryView('ORDERS')}
      />

      {/* Command Palette (Ctrl + K) */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        setPrimaryView={setPrimaryView}
        onOpenOrderTicketForSymbol={handleOpenTicketForSymbol}
        onOpenTerminalMode={() => setIsTerminalModeOpen(true)}
        onOpenAiCopilot={() => setIsAiCopilotOpen(true)}
      />

      {/* Terminal CLI Mode (<RQ>) */}
      <RhinoTerminalMode
        isOpen={isTerminalModeOpen}
        onClose={() => setIsTerminalModeOpen(false)}
      />

      {/* AI Assistant Drawer */}
      <AiAssistantDrawer
        isOpen={isAiCopilotOpen}
        onClose={() => setIsAiCopilotOpen(false)}
      />
    </div>
  );
}

export default App;
