/**
 * RHINOQUANT EQUITIES.OS - Pre-Trade & Portfolio Risk Engine
 * Runs institutional risk validation prior to order creation/submission
 */

import { Order, OrderSide, PreTradeRiskCheck, AccountPortfolio, PortfolioRiskMetrics, StressScenarioResult } from '../types';
import { globalMarketEngine } from './marketDataEngine';

export class RiskEngine {
  public validatePreTrade(
    symbol: string,
    side: OrderSide,
    quantity: number,
    limitPrice: number | undefined,
    portfolio: AccountPortfolio,
    orderType: string = 'LIMIT'
  ): PreTradeRiskCheck {
    const marketStats = globalMarketEngine.getStats(symbol);
    const execPrice = limitPrice && limitPrice > 0 ? limitPrice : marketStats.lastPrice;
    const notional = quantity * execPrice;

    // 1. Notional Limit ($50,000,000 single order ceiling)
    const maxNotional = 50_000_000;
    const notionalPassed = notional <= maxNotional;
    const notionalCheck = {
      status: notionalPassed ? ('PASS' as const) : ('FAIL' as const),
      currentVal: Math.round(notional),
      maxLimit: maxNotional,
      detail: notionalPassed
        ? `Order notional $${(notional / 1e6).toFixed(2)}M is within single order limit ($50M)`
        : `Order notional $${(notional / 1e6).toFixed(2)}M exceeds max limit $50M`,
    };

    // 2. Position Limit (Max 15% of total portfolio equity)
    const existingPos = portfolio.positions.find((p) => p.symbol === symbol);
    const existingShares = existingPos ? existingPos.quantity : 0;
    const newTotalShares = side === 'BUY' ? existingShares + quantity : existingShares - quantity;
    const newPositionNotional = Math.abs(newTotalShares * execPrice);
    const maxPositionPct = 0.15; // 15%
    const maxAllowedNotional = portfolio.totalEquity * maxPositionPct;
    const positionPassed = newPositionNotional <= maxAllowedNotional;
    const positionCheck = {
      status: positionPassed ? ('PASS' as const) : ('FAIL' as const),
      currentVal: Number(((newPositionNotional / portfolio.totalEquity) * 100).toFixed(1)),
      maxLimit: maxPositionPct * 100,
      detail: positionPassed
        ? `Post-trade position ${((newPositionNotional / portfolio.totalEquity) * 100).toFixed(1)}% is within 15% limit`
        : `Post-trade position ${((newPositionNotional / portfolio.totalEquity) * 100).toFixed(1)}% breaches 15% limit`,
    };

    // 3. Price Collar (Within +/- 3% of NBBO mid)
    const mid = marketStats.lastPrice;
    const lowerCollar = Number((mid * 0.97).toFixed(2));
    const upperCollar = Number((mid * 1.03).toFixed(2));
    const pricePassed = orderType === 'MARKET' || (execPrice >= lowerCollar && execPrice <= upperCollar);
    const priceCollarCheck = {
      status: pricePassed ? ('PASS' as const) : ('FAIL' as const),
      currentPrice: execPrice,
      collarRange: [lowerCollar, upperCollar] as [number, number],
      detail: pricePassed
        ? `Limit price $${execPrice} is within collar range [$${lowerCollar} - $${upperCollar}]`
        : `Limit price $${execPrice} outside 3% collar range [$${lowerCollar} - $${upperCollar}]`,
    };

    // 4. Buying Power / Margin
    const requiredMargin = side === 'BUY' ? notional * 0.5 : notional * 0.5; // 50% initial margin
    const buyingPowerPassed = portfolio.buyingPower >= requiredMargin;
    const buyingPowerCheck = {
      status: buyingPowerPassed ? ('PASS' as const) : ('FAIL' as const),
      requiredMargin: Math.round(requiredMargin),
      availableBuyingPower: Math.round(portfolio.buyingPower),
      detail: buyingPowerPassed
        ? `Required margin $${(requiredMargin / 1e3).toFixed(0)}k is covered by buying power $${(portfolio.buyingPower / 1e3).toFixed(0)}k`
        : `Insufficient buying power. Required $${(requiredMargin / 1e3).toFixed(0)}k vs Available $${(portfolio.buyingPower / 1e3).toFixed(0)}k`,
    };

    // 5. Market & Security Status
    const marketPassed = true; // Simulated market is open
    const marketCheck = {
      status: 'PASS' as const,
      marketState: 'SIMULATED / OPEN',
      detail: 'US Equities market is OPEN and trading',
    };

    const securityCheck = {
      status: 'PASS' as const,
      securityState: 'ACTIVE',
      detail: `Security ${symbol} is ACTIVE on venue`,
    };

    const overallPassed =
      notionalPassed &&
      positionPassed &&
      pricePassed &&
      buyingPowerPassed &&
      marketPassed;

    let rejectionReason = undefined;
    let recommendedAction = undefined;

    if (!overallPassed) {
      if (!positionPassed) {
        rejectionReason = 'MAX POSITION LIMIT BREACHED';
        const maxAddableNotional = Math.max(0, maxAllowedNotional - Math.abs(existingShares * execPrice));
        const maxAddableQty = Math.floor(maxAddableNotional / execPrice);
        recommendedAction = `REDUCE ORDER SIZE TO <= ${maxAddableQty.toLocaleString()} SHARES OR REQUEST RISK APPROVAL`;
      } else if (!notionalPassed) {
        rejectionReason = 'MAX SINGLE ORDER NOTIONAL LIMIT BREACHED';
        recommendedAction = `SPLIT ORDER INTO CHILD ORDERS <= $50M NOTIONAL`;
      } else if (!pricePassed) {
        rejectionReason = 'PRICE COLLAR BREACHED (+/-3% NBBO MID)';
        recommendedAction = `ADJUST LIMIT PRICE BETWEEN $${lowerCollar} AND $${upperCollar}`;
      } else if (!buyingPowerPassed) {
        rejectionReason = 'INSUFFICIENT BUYING POWER / MARGIN';
        recommendedAction = `DEPOSIT CASH OR REDUCE QUANTITY TO FIT AVAILABLE MARGIN`;
      }
    }

    return {
      positionLimit: positionCheck,
      notionalLimit: notionalCheck,
      priceCollar: priceCollarCheck,
      buyingPower: buyingPowerCheck,
      marketStatus: marketCheck,
      securityStatus: securityCheck,
      riskLimitOverall: {
        status: overallPassed ? 'PASS' : 'FAIL',
        overallScore: overallPassed ? 98 : 42,
        detail: overallPassed
          ? 'All 7 pre-trade risk checks passed successfully'
          : `Pre-trade risk failed: ${rejectionReason}`,
      },
      overallPassed,
      rejectionReason,
      recommendedAction,
    };
  }

  public calculatePortfolioRisk(portfolio: AccountPortfolio): PortfolioRiskMetrics {
    return {
      beta: 1.18,
      volatilityPct: 18.4,
      var95_1D: Math.round(portfolio.totalMarketValue * 0.0185), // 1.85% daily VaR
      expectedShortfall: Math.round(portfolio.totalMarketValue * 0.026), // 2.6% Expected Shortfall
      trackingErrorPct: 2.1,
      activeSharePct: 78.4,
      top3ConcentrationPct: 42.1,
      factors: {
        market: 1.05,
        size: 0.24,
        value: -0.12,
        momentum: 0.48,
        quality: 0.31,
        volatility: 0.15,
      },
      factorContributions: {
        'Market (SPX)': 62.4,
        'Tech Momentum': 21.8,
        'Quality Growth': 10.2,
        'Size Premium': 5.6,
      },
    };
  }

  public runStressTest(portfolio: AccountPortfolio): StressScenarioResult[] {
    const mv = portfolio.totalMarketValue;
    return [
      {
        scenarioName: 'Market Crash (-10%)',
        marketMovePct: -10,
        estimatedPnL: Math.round(mv * -0.118),
        marginRequirementAfter: Math.round(portfolio.marginUsed * 1.35),
        liquidityShortfallUsd: 0,
        maxDrawdownPct: 11.8,
        riskStatus: 'SAFE',
      },
      {
        scenarioName: 'Severe Crash (-20%)',
        marketMovePct: -20,
        estimatedPnL: Math.round(mv * -0.236),
        marginRequirementAfter: Math.round(portfolio.marginUsed * 1.8),
        liquidityShortfallUsd: 1_200_000,
        maxDrawdownPct: 23.6,
        riskStatus: 'WARNING',
      },
      {
        scenarioName: 'Black Swan (-30%)',
        marketMovePct: -30,
        estimatedPnL: Math.round(mv * -0.354),
        marginRequirementAfter: Math.round(portfolio.marginUsed * 2.5),
        liquidityShortfallUsd: 8_500_000,
        maxDrawdownPct: 35.4,
        riskStatus: 'BREACH',
      },
      {
        scenarioName: 'Interest Rates (+100bps)',
        marketMovePct: -4.2,
        estimatedPnL: Math.round(mv * -0.048),
        marginRequirementAfter: Math.round(portfolio.marginUsed * 1.05),
        liquidityShortfallUsd: 0,
        maxDrawdownPct: 4.8,
        riskStatus: 'SAFE',
      },
      {
        scenarioName: 'Tech Shock (-20%)',
        marketMovePct: -14.5,
        estimatedPnL: Math.round(mv * -0.172),
        marginRequirementAfter: Math.round(portfolio.marginUsed * 1.45),
        liquidityShortfallUsd: 0,
        maxDrawdownPct: 17.2,
        riskStatus: 'WARNING',
      },
    ];
  }
}

export const globalRiskEngine = new RiskEngine();
