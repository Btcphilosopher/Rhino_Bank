/**
 * RHINOQUANT EQUITIES.OS - Portfolio, Double-Entry Ledger & Settlement Engine
 * Manages positions, P&L, cash balances, journal entries, T+1/T+2 settlement & reconciliation
 */

import {
  AccountPortfolio,
  DoubleEntryLedgerAccount,
  Fill,
  LedgerEntry,
  Order,
  Position,
  ReconciliationBreak,
  SettlementInstruction,
} from '../types';
import { globalMarketEngine } from './marketDataEngine';

export class PortfolioEngine {
  private portfolio: AccountPortfolio;
  private ledgerAccounts: DoubleEntryLedgerAccount[];
  private ledgerEntries: LedgerEntry[];
  private settlementInstructions: SettlementInstruction[];
  private reconciliationBreaks: ReconciliationBreak[];

  constructor() {
    this.portfolio = {
      firmName: 'RhinoQuant Capital Management LP',
      strategyName: 'Global Equity Quantitative Alpha',
      fundName: 'RhinoQuant Master Fund Ltd',
      accountId: 'ACT-RQ-9921',
      traderName: 'Head Trader (Desk 01)',
      cashBalance: 142_500_000,
      settledCash: 120_000_000,
      unsettledCash: 22_500_000,
      buyingPower: 285_000_000, // 2x leverage
      marginUsed: 42_100_000,
      totalMarketValue: 84_120_000,
      totalEquity: 226_620_000, // Cash + Market Value
      dailyRealizedPnL: 142_500,
      dailyUnrealizedPnL: 820_400,
      totalPnL: 962_900,
      sectorAllocations: {
        Technology: 42.5,
        Financials: 22.0,
        Healthcare: 15.5,
        Energy: 10.0,
        Industrial: 10.0,
      },
      countryAllocations: {
        'United States': 72.0,
        'United Kingdom': 12.0,
        Japan: 8.0,
        Europe: 8.0,
      },
      positions: [
        {
          securityId: 'SEC-001',
          symbol: 'RQ-TECH-001',
          companyName: 'RhinoQuant Tech Corp (Synthetic)',
          quantity: 125_000,
          avgPrice: 178.40,
          marketPrice: 182.43,
          marketValue: 22_803_750,
          unrealizedPnL: 503_750,
          unrealizedPnLPct: 2.26,
          realizedPnL: 45_000,
          costBasis: 22_300_000,
          weightPct: 27.1,
          side: 'LONG',
        },
        {
          securityId: 'SEC-002',
          symbol: 'RQ-FIN-002',
          companyName: 'Global Financial Group (Synthetic)',
          quantity: 350_000,
          avgPrice: 44.20,
          marketPrice: 45.80,
          marketValue: 16_030_000,
          unrealizedPnL: 560_000,
          unrealizedPnLPct: 3.62,
          realizedPnL: 12_500,
          costBasis: 15_470_000,
          weightPct: 19.1,
          side: 'LONG',
        },
        {
          securityId: 'SEC-003',
          symbol: 'RQ-HLTH-003',
          companyName: 'BioPharma Dynamics (Synthetic)',
          quantity: -40_000, // SHORT position
          avgPrice: 215.00,
          marketPrice: 210.15,
          marketValue: -8_406_000,
          unrealizedPnL: 194_000, // short gain as price dropped
          unrealizedPnLPct: 2.26,
          realizedPnL: 28_000,
          costBasis: 8_600_000,
          weightPct: -10.0,
          side: 'SHORT',
          borrowRatePct: 0.85,
          borrowCostDaily: 198,
          locateStatus: 'APPROVED',
        },
      ],
    };

    this.ledgerAccounts = [
      { accountCode: '1010', accountName: 'CASH', balance: 142_500_000 },
      { accountCode: '1020', accountName: 'SECURITIES', balance: 84_120_000 },
      { accountCode: '1030', accountName: 'RECEIVABLE', balance: 22_500_000 },
      { accountCode: '2010', accountName: 'PAYABLE', balance: 0 },
      { accountCode: '3010', accountName: 'P_AND_L', balance: 962_900 },
      { accountCode: '4010', accountName: 'FEES', balance: -14_200 },
      { accountCode: '2020', accountName: 'BORROW', balance: 8_600_000 },
      { accountCode: '2030', accountName: 'MARGIN', balance: 42_100_000 },
    ];

    this.ledgerEntries = [
      {
        entryId: 'LEDG-0001',
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        description: 'INITIAL SYSTEM CAPITALIZATION',
        debitAccount: 'CASH (1010)',
        debitAmount: 142_500_000,
        creditAccount: 'P_AND_L (3010)',
        creditAmount: 142_500_000,
        balanced: true,
      },
    ];

    this.settlementInstructions = [
      {
        instructionId: 'SETTL-88102',
        orderId: 'ORD-HIST-01',
        tradeDate: '2026-09-21',
        settlementDate: '2026-09-22',
        symbol: 'RQ-TECH-001',
        quantity: 25_000,
        grossAmount: 4_560_750,
        netAmount: 4_561_434,
        counterpartyVenue: 'RQEX',
        clearingStatus: 'SETTLED',
        cashDelivered: true,
        securityDelivered: true,
      },
    ];

    this.reconciliationBreaks = [];
    this.updateMarketPrices();
  }

  public getPortfolio(): AccountPortfolio {
    this.updateMarketPrices();
    return this.portfolio;
  }

  public getLedgerAccounts(): DoubleEntryLedgerAccount[] {
    return this.ledgerAccounts;
  }

  public getLedgerEntries(): LedgerEntry[] {
    return this.ledgerEntries;
  }

  public getSettlementInstructions(): SettlementInstruction[] {
    return this.settlementInstructions;
  }

  public getReconciliationBreaks(): ReconciliationBreak[] {
    return this.reconciliationBreaks;
  }

  public updateMarketPrices(): void {
    let totalMv = 0;
    let totalUnrealized = 0;

    this.portfolio.positions.forEach((pos) => {
      const currentPrice = globalMarketEngine.getPrice(pos.symbol);
      pos.marketPrice = currentPrice;
      pos.marketValue = pos.quantity * currentPrice;

      if (pos.quantity > 0) {
        // LONG
        pos.unrealizedPnL = (currentPrice - pos.avgPrice) * pos.quantity;
        pos.side = 'LONG';
      } else if (pos.quantity < 0) {
        // SHORT
        pos.unrealizedPnL = (pos.avgPrice - currentPrice) * Math.abs(pos.quantity);
        pos.side = 'SHORT';
      } else {
        pos.unrealizedPnL = 0;
        pos.side = 'FLAT';
      }

      pos.unrealizedPnLPct = pos.costBasis > 0 ? Number(((pos.unrealizedPnL / pos.costBasis) * 100).toFixed(2)) : 0;
      totalMv += Math.abs(pos.marketValue);
      totalUnrealized += pos.unrealizedPnL;
    });

    this.portfolio.totalMarketValue = totalMv;
    this.portfolio.dailyUnrealizedPnL = Math.round(totalUnrealized);
    this.portfolio.totalEquity = this.portfolio.cashBalance + totalMv;
    this.portfolio.buyingPower = this.portfolio.cashBalance * 2; // 2x leverage

    // Calculate position weights
    this.portfolio.positions.forEach((pos) => {
      pos.weightPct = this.portfolio.totalEquity > 0
        ? Number(((Math.abs(pos.marketValue) / this.portfolio.totalEquity) * 100).toFixed(1))
        : 0;
    });
  }

  public processFill(fill: Fill, order: Order): void {
    const symbol = fill.symbol;
    const fillNotional = fill.price * fill.quantity;
    const fee = fill.fee;

    let pos = this.portfolio.positions.find((p) => p.symbol === symbol);

    if (!pos) {
      const sec = globalMarketEngine.getStats(symbol);
      pos = {
        securityId: `SEC-${symbol}`,
        symbol,
        companyName: `${symbol} Synthetic Corp`,
        quantity: 0,
        avgPrice: fill.price,
        marketPrice: fill.price,
        marketValue: 0,
        unrealizedPnL: 0,
        unrealizedPnLPct: 0,
        realizedPnL: 0,
        costBasis: 0,
        weightPct: 0,
        side: 'FLAT',
      };
      this.portfolio.positions.push(pos);
    }

    const isBuy = order.side === 'BUY';
    const signedQty = isBuy ? fill.quantity : -fill.quantity;

    // Update position quantity and average cost basis
    const prevQty = pos.quantity;
    const newQty = prevQty + signedQty;

    if (prevQty === 0) {
      pos.avgPrice = fill.price;
      pos.costBasis = fillNotional;
    } else if ((prevQty > 0 && isBuy) || (prevQty < 0 && !isBuy)) {
      // Adding to existing position
      const totalCost = pos.avgPrice * Math.abs(prevQty) + fillNotional;
      pos.avgPrice = Number((totalCost / Math.abs(newQty)).toFixed(2));
      pos.costBasis = totalCost;
    } else {
      // Closing / Reducing position -> Calculate Realized P&L
      const closedQty = Math.min(Math.abs(prevQty), fill.quantity);
      const priceDiff = isBuy ? pos.avgPrice - fill.price : fill.price - pos.avgPrice;
      const realizedGain = closedQty * priceDiff;

      pos.realizedPnL += realizedGain;
      this.portfolio.dailyRealizedPnL += Math.round(realizedGain);
      pos.costBasis = Math.abs(newQty) * pos.avgPrice;
    }

    pos.quantity = newQty;
    pos.side = newQty > 0 ? 'LONG' : newQty < 0 ? 'SHORT' : 'FLAT';

    // Update Cash Balance & Unsettled Cash
    if (isBuy) {
      this.portfolio.cashBalance -= fillNotional + fee;
      this.portfolio.unsettledCash += fillNotional;
    } else {
      this.portfolio.cashBalance += fillNotional - fee;
      this.portfolio.unsettledCash -= fillNotional;
    }

    // Double Entry Ledger Recording
    const entryId = `LEDG-${Math.floor(10000 + Math.random() * 90000)}`;
    const nowIso = new Date().toISOString();

    const ledgerEntry: LedgerEntry = isBuy
      ? {
          entryId,
          timestamp: nowIso,
          orderId: order.orderId,
          description: `EXECUTION FILL BUY ${fill.quantity.toLocaleString()} ${symbol} @ $${fill.price}`,
          debitAccount: 'SECURITIES (1020)',
          debitAmount: Math.round(fillNotional),
          creditAccount: 'CASH (1010)',
          creditAmount: Math.round(fillNotional),
          balanced: true,
        }
      : {
          entryId,
          timestamp: nowIso,
          orderId: order.orderId,
          description: `EXECUTION FILL SELL ${fill.quantity.toLocaleString()} ${symbol} @ $${fill.price}`,
          debitAccount: 'CASH (1010)',
          debitAmount: Math.round(fillNotional),
          creditAccount: 'SECURITIES (1020)',
          creditAmount: Math.round(fillNotional),
          balanced: true,
        };

    this.ledgerEntries.unshift(ledgerEntry);

    // Create Settlement Instruction (T+1)
    const settlId = `SETTL-${Math.floor(10000 + Math.random() * 90000)}`;
    const tradeDate = nowIso.split('T')[0];
    const settlDate = new Date(Date.now() + 86400000).toISOString().split('T')[0];

    const settlInst: SettlementInstruction = {
      instructionId: settlId,
      orderId: order.orderId,
      tradeDate,
      settlementDate: settlDate,
      symbol,
      quantity: fill.quantity,
      grossAmount: Math.round(fillNotional),
      netAmount: Math.round(fillNotional + fee),
      counterpartyVenue: fill.venue,
      clearingStatus: 'MATCHED',
      cashDelivered: false,
      securityDelivered: false,
    };

    this.settlementInstructions.unshift(settlInst);
    this.updateMarketPrices();
  }

  public executeCorporateAction(symbol: string, actionType: '2_TO_1_SPLIT' | 'CASH_DIVIDEND_2_00'): string {
    const pos = this.portfolio.positions.find((p) => p.symbol === symbol);
    if (!pos || pos.quantity === 0) {
      return `No position in ${symbol} to apply corporate action.`;
    }

    if (actionType === '2_TO_1_SPLIT') {
      const oldShares = pos.quantity;
      const oldAvgPrice = pos.avgPrice;

      pos.quantity = oldShares * 2;
      pos.avgPrice = Number((oldAvgPrice / 2).toFixed(2));
      pos.costBasis = pos.quantity * pos.avgPrice;

      // Add Ledger Audit Entry
      this.ledgerEntries.unshift({
        entryId: `LEDG-CORP-${Math.floor(10000 + Math.random() * 90000)}`,
        timestamp: new Date().toISOString(),
        description: `CORPORATE ACTION 2:1 STOCK SPLIT ${symbol}: ${oldShares.toLocaleString()} shs @ $${oldAvgPrice} -> ${pos.quantity.toLocaleString()} shs @ $${pos.avgPrice}`,
        debitAccount: 'SECURITIES (1020)',
        debitAmount: 0,
        creditAccount: 'SECURITIES (1020)',
        creditAmount: 0,
        balanced: true,
      });

      this.updateMarketPrices();
      return `Applied 2:1 Stock Split for ${symbol}: Shares updated from ${oldShares.toLocaleString()} to ${pos.quantity.toLocaleString()}, avg cost $${oldAvgPrice} -> $${pos.avgPrice}.`;
    } else if (actionType === 'CASH_DIVIDEND_2_00') {
      const dividendPerShare = 2.0;
      const dividendPayout = pos.quantity * dividendPerShare;
      this.portfolio.cashBalance += dividendPayout;

      this.ledgerEntries.unshift({
        entryId: `LEDG-DIV-${Math.floor(10000 + Math.random() * 90000)}`,
        timestamp: new Date().toISOString(),
        description: `CASH DIVIDEND RECEIVED ${symbol}: $${dividendPerShare}/sh on ${pos.quantity.toLocaleString()} shares`,
        debitAccount: 'CASH (1010)',
        debitAmount: dividendPayout,
        creditAccount: 'P_AND_L (3010)',
        creditAmount: dividendPayout,
        balanced: true,
      });

      this.updateMarketPrices();
      return `Processed Cash Dividend of $2.00/share for ${symbol}: Cash balance increased by +$${dividendPayout.toLocaleString()}.`;
    }

    return 'Action executed.';
  }

  public runReconciliation(): ReconciliationBreak[] {
    const breaks: ReconciliationBreak[] = [];
    const nowIso = new Date().toISOString();

    this.portfolio.positions.forEach((p) => {
      // Simulate minor custody mismatch on 1 position for realistic recon workflow
      if (p.symbol === 'RQ-FIN-002') {
        breaks.push({
          breakId: `BRK-${Math.floor(1000 + Math.random() * 9000)}`,
          timestamp: nowIso,
          symbol: p.symbol,
          internalQty: p.quantity,
          clearingQty: p.quantity,
          custodyQty: p.quantity - 100, // 100 share discrepancy
          diffQty: 100,
          status: 'OPEN_BREAK',
          reason: 'Late clearing settlement allocation from venue NORTHSTAR',
          originEvent: 'SETTL-88102 pending DTCC match',
        });
      }
    });

    this.reconciliationBreaks = breaks;
    return breaks;
  }
}

export const globalPortfolioEngine = new PortfolioEngine();
