/**
 * RHINOQUANT EQUITIES.OS - Order Management & Execution Engine
 * Manages Order State Machine, FIX Message Protocol, Matching Engine, Algorithmic Execution & Audit Trail
 */

import {
  AlgoStrategy,
  AlgorithmRun,
  AuditEvent,
  ChildOrder,
  Fill,
  Order,
  OrderSide,
  OrderState,
  OrderType,
  TimeInForce,
} from '../types';
import { globalMarketEngine } from './marketDataEngine';
import { globalPortfolioEngine } from './portfolioEngine';
import { globalRiskEngine } from './riskEngine';
import { globalRoutingEngine } from './routingEngine';

export class ExecutionEngine {
  private activeOrders: Order[] = [];
  private auditTrail: AuditEvent[] = [];
  private activeAlgorithms: AlgorithmRun[] = [];

  constructor() {
    this.createSeedHistory();
  }

  private createSeedHistory() {
    // Populate an initial historical order for UI demonstration
    const seedOrder: Order = {
      orderId: 'ORD-RQ-00921',
      clientId: 'CL-MASTER-01',
      account: 'ACT-RQ-9921',
      trader: 'Desk 01 (Quant)',
      symbol: 'RQ-TECH-001',
      side: 'BUY',
      quantity: 50000,
      filledQuantity: 50000,
      remainingQuantity: 0,
      orderType: 'LIMIT',
      limitPrice: 182.50,
      timeInForce: 'DAY',
      algoStrategy: 'SMART_ROUTE',
      state: 'FILLED',
      stateHistory: [
        { state: 'CREATED', timestamp: '2026-09-22T14:02:11.102Z', note: 'Order created via Order Ticket' },
        { state: 'VALIDATING', timestamp: '2026-09-22T14:02:11.105Z', note: 'Schema validation complete' },
        { state: 'RISK_CHECK', timestamp: '2026-09-22T14:02:11.108Z', note: 'Pre-Trade Risk checks passed' },
        { state: 'APPROVED', timestamp: '2026-09-22T14:02:11.112Z', note: 'Trader desk approval granted' },
        { state: 'ROUTING', timestamp: '2026-09-22T14:02:11.115Z', note: 'SOR generated multi-venue split' },
        { state: 'WORKING', timestamp: '2026-09-22T14:02:11.120Z', note: 'Child orders routed to RQEX, MERIDIAN' },
        { state: 'FILLED', timestamp: '2026-09-22T14:02:11.240Z', note: 'Executed 50,000 shares @ $182.42 avg' },
      ],
      createdAt: '2026-09-22T14:02:11.102Z',
      updatedAt: '2026-09-22T14:02:11.240Z',
      highResTsCreated: Date.now() - 3600000,
      highResTsExecuted: Date.now() - 3599800,
      avgFillPrice: 182.42,
      arrivalPrice: 182.43,
      vwapBenchmark: 182.40,
      slippageBp: -0.5,
      spreadCost: 0.01,
      marketImpactBp: 0.8,
      totalFees: 12.5,
      preTradeRisk: {
        positionLimit: { status: 'PASS', currentVal: 8.2, maxLimit: 15, detail: 'Within 15% limit' },
        notionalLimit: { status: 'PASS', currentVal: 9121000, maxLimit: 50000000, detail: 'Within $50M limit' },
        priceCollar: { status: 'PASS', currentPrice: 182.50, collarRange: [176.95, 187.90], detail: 'Within +/-3% collar' },
        buyingPower: { status: 'PASS', requiredMargin: 4560500, availableBuyingPower: 285000000, detail: 'Sufficient buying power' },
        marketStatus: { status: 'PASS', marketState: 'SIMULATED / OPEN', detail: 'Market open' },
        securityStatus: { status: 'PASS', securityState: 'ACTIVE', detail: 'Security active' },
        riskLimitOverall: { status: 'PASS', overallScore: 98, detail: 'All 7 risk checks passed' },
        overallPassed: true,
      },
      childOrders: [],
      fills: [
        {
          fillId: 'FILL-9901',
          orderId: 'ORD-RQ-00921',
          symbol: 'RQ-TECH-001',
          venue: 'RQEX',
          price: 182.42,
          quantity: 30000,
          timestamp: '2026-09-22T14:02:11.200Z',
          highResTs: Date.now() - 3599840,
          liquidityRole: 'TAKER',
          fee: 7.5,
          execBpImprovement: 0.5,
        },
        {
          fillId: 'FILL-9902',
          orderId: 'ORD-RQ-00921',
          symbol: 'RQ-TECH-001',
          venue: 'MERIDIAN',
          price: 182.42,
          quantity: 20000,
          timestamp: '2026-09-22T14:02:11.240Z',
          highResTs: Date.now() - 3599800,
          liquidityRole: 'TAKER',
          fee: 5.0,
          execBpImprovement: 0.5,
        },
      ],
      fixMessages: [
        '8=FIX.4.4|35=D|11=ORD-RQ-00921|55=RQ-TECH-001|54=1|38=50000|40=2|44=182.50|59=0|10=182',
        '8=FIX.4.4|35=8|11=ORD-RQ-00921|39=2|150=2|14=50000|6=182.42|10=204',
      ],
    };

    this.activeOrders.push(seedOrder);

    this.auditTrail.push({
      eventId: 'AUD-0001',
      timestamp: seedOrder.createdAt,
      highResTs: seedOrder.highResTsCreated,
      user: 'TRADER_DESK_01',
      action: 'ORDER_SUBMITTED',
      orderId: seedOrder.orderId,
      securitySymbol: seedOrder.symbol,
      oldState: 'NONE',
      newState: 'FILLED',
      routingDecision: 'SOR multi-venue split (RQEX 60%, MERIDIAN 40%)',
      details: 'Executed 50,000 shares @ $182.42 avg in 138ms',
      sourceComponent: 'OMS',
    });
  }

  public getOrders(): Order[] {
    return this.activeOrders;
  }

  public getAuditTrail(): AuditEvent[] {
    return this.auditTrail;
  }

  public getActiveAlgorithms(): AlgorithmRun[] {
    return this.activeAlgorithms;
  }

  public createAndExecuteOrder(
    symbol: string,
    side: OrderSide,
    quantity: number,
    orderType: OrderType = 'LIMIT',
    limitPrice?: number,
    algoStrategy: AlgoStrategy = 'SMART_ROUTE',
    algoParameters?: Order['algoParameters']
  ): Order {
    const portfolio = globalPortfolioEngine.getPortfolio();
    const marketStats = globalMarketEngine.getStats(symbol);
    const arrivalP = marketStats.lastPrice;
    const now = new Date();
    const nowIso = now.toISOString();
    const highResTs = now.getTime();
    const orderId = `ORD-RQ-${Math.floor(10000 + Math.random() * 90000)}`;

    // Run Pre-Trade Risk Check
    const preRisk = globalRiskEngine.validatePreTrade(
      symbol,
      side,
      quantity,
      limitPrice,
      portfolio,
      orderType
    );

    const fixTag54 = side === 'BUY' ? '1' : '2';
    const fixTag40 = orderType === 'LIMIT' ? '2' : '1';
    const initialFixMsg = `8=FIX.4.4|35=D|11=${orderId}|55=${symbol}|54=${fixTag54}|38=${quantity}|40=${fixTag40}|44=${limitPrice || arrivalP}|59=0|10=192`;

    const stateHistory: Order['stateHistory'] = [
      { state: 'CREATED', timestamp: nowIso, note: 'Order intent initialized' },
      { state: 'VALIDATING', timestamp: nowIso, note: 'Passed syntax & account schema verification' },
    ];

    if (!preRisk.overallPassed) {
      stateHistory.push({
        state: 'REJECTED',
        timestamp: nowIso,
        note: `REJECTED BY PRE-TRADE RISK: ${preRisk.rejectionReason}`,
      });

      const rejectedOrder: Order = {
        orderId,
        clientId: 'CL-MASTER-01',
        account: portfolio.accountId,
        trader: portfolio.traderName,
        symbol,
        side,
        quantity,
        filledQuantity: 0,
        remainingQuantity: quantity,
        orderType,
        limitPrice,
        timeInForce: 'DAY',
        algoStrategy,
        algoParameters,
        state: 'REJECTED',
        stateHistory,
        createdAt: nowIso,
        updatedAt: nowIso,
        highResTsCreated: highResTs,
        avgFillPrice: 0,
        arrivalPrice: arrivalP,
        vwapBenchmark: arrivalP,
        slippageBp: 0,
        spreadCost: 0,
        marketImpactBp: 0,
        totalFees: 0,
        preTradeRisk: preRisk,
        childOrders: [],
        fills: [],
        fixMessages: [initialFixMsg, `8=FIX.4.4|35=8|11=${orderId}|39=8|150=8|58=${preRisk.rejectionReason}|10=088`],
      };

      this.activeOrders.unshift(rejectedOrder);

      this.auditTrail.unshift({
        eventId: `AUD-${Math.floor(10000 + Math.random() * 90000)}`,
        timestamp: nowIso,
        highResTs,
        user: portfolio.traderName,
        action: 'ORDER_REJECTED',
        orderId,
        securitySymbol: symbol,
        oldState: 'RISK_CHECK',
        newState: 'REJECTED',
        details: `Order rejected by Pre-Trade Risk Engine: ${preRisk.rejectionReason}. Action: ${preRisk.recommendedAction}`,
        sourceComponent: 'RISK_ENGINE',
      });

      return rejectedOrder;
    }

    stateHistory.push({ state: 'RISK_CHECK', timestamp: nowIso, note: 'All 7 pre-trade risk controls passed' });
    stateHistory.push({ state: 'APPROVED', timestamp: nowIso, note: 'Order approved for execution engine' });

    // Calculate Routing
    const routingDecision = globalRoutingEngine.calculateRouting(symbol, side, quantity, limitPrice);
    routingDecision.orderId = orderId;
    stateHistory.push({ state: 'ROUTING', timestamp: nowIso, note: routingDecision.explanation });

    // Create Child Orders
    const childOrders: ChildOrder[] = routingDecision.venueSplits.map((split, idx) => ({
      childId: `CHILD-${orderId}-${idx + 1}`,
      parentId: orderId,
      symbol,
      venue: split.venueId,
      side,
      quantity: split.allocatedShares,
      filledQuantity: 0,
      price: split.targetPrice,
      status: 'WORKING',
      createdAt: nowIso,
      updatedAt: nowIso,
      latencyMs: split.latencyMs,
      feesPaid: 0,
      avgFillPrice: 0,
    }));

    stateHistory.push({ state: 'WORKING', timestamp: nowIso, note: `Routed ${childOrders.length} child order(s) to venues` });

    const newOrder: Order = {
      orderId,
      clientId: 'CL-MASTER-01',
      account: portfolio.accountId,
      trader: portfolio.traderName,
      symbol,
      side,
      quantity,
      filledQuantity: 0,
      remainingQuantity: quantity,
      orderType,
      limitPrice,
      timeInForce: 'DAY',
      algoStrategy,
      algoParameters,
      state: 'WORKING',
      stateHistory,
      createdAt: nowIso,
      updatedAt: nowIso,
      highResTsCreated: highResTs,
      avgFillPrice: 0,
      arrivalPrice: arrivalP,
      vwapBenchmark: marketStats.vwap,
      slippageBp: 0,
      spreadCost: 0,
      marketImpactBp: 0,
      totalFees: 0,
      preTradeRisk: preRisk,
      childOrders,
      fills: [],
      routingDecision,
      fixMessages: [initialFixMsg],
    };

    // Execute Fills deterministically
    this.executeOrderFills(newOrder);

    this.activeOrders.unshift(newOrder);

    this.auditTrail.unshift({
      eventId: `AUD-${Math.floor(10000 + Math.random() * 90000)}`,
      timestamp: nowIso,
      highResTs,
      user: portfolio.traderName,
      action: 'ORDER_EXECUTED',
      orderId,
      securitySymbol: symbol,
      oldState: 'WORKING',
      newState: newOrder.state,
      routingDecision: routingDecision.explanation,
      details: `Order filled ${newOrder.filledQuantity.toLocaleString()} / ${newOrder.quantity.toLocaleString()} shares @ avg $${newOrder.avgFillPrice}`,
      sourceComponent: 'MATCHING_ENGINE',
    });

    return newOrder;
  }

  private executeOrderFills(order: Order): void {
    let totalFilled = 0;
    let totalCost = 0;
    let totalFees = 0;
    const now = Date.now();

    order.childOrders.forEach((child, idx) => {
      const fillQty = child.quantity;
      const fillPrice = child.price;
      const fee = Number(((fillQty * fillPrice * 0.0001) / 10).toFixed(2));

      child.filledQuantity = fillQty;
      child.avgFillPrice = fillPrice;
      child.status = 'FILLED';
      child.feesPaid = fee;

      totalFilled += fillQty;
      totalCost += fillQty * fillPrice;
      totalFees += fee;

      const fillObj: Fill = {
        fillId: `FILL-${Math.floor(10000 + Math.random() * 90000)}`,
        orderId: order.orderId,
        childOrderId: child.childId,
        symbol: order.symbol,
        venue: child.venue,
        price: fillPrice,
        quantity: fillQty,
        timestamp: new Date(now + idx * 15).toISOString(),
        highResTs: now + idx * 15,
        liquidityRole: 'TAKER',
        fee,
        execBpImprovement: Number(((order.arrivalPrice - fillPrice) * 10000 / order.arrivalPrice).toFixed(1)),
      };

      order.fills.push(fillObj);

      // Process in Portfolio & Double-Entry Ledger
      globalPortfolioEngine.processFill(fillObj, order);
    });

    order.filledQuantity = totalFilled;
    order.remainingQuantity = order.quantity - totalFilled;
    order.avgFillPrice = Number((totalCost / totalFilled).toFixed(2));
    order.totalFees = Number(totalFees.toFixed(2));
    order.state = order.remainingQuantity === 0 ? 'FILLED' : 'PARTIALLY_FILLED';
    order.updatedAt = new Date().toISOString();
    order.highResTsExecuted = now + 45;

    // Calculate execution analytics
    const slippage = ((order.avgFillPrice - order.arrivalPrice) / order.arrivalPrice) * 10000;
    order.slippageBp = Number((order.side === 'BUY' ? slippage : -slippage).toFixed(1));
    order.marketImpactBp = Number((Math.abs(order.quantity) / 100000 * 1.2).toFixed(1));

    order.stateHistory.push({
      state: order.state,
      timestamp: order.updatedAt,
      note: `Executed ${totalFilled.toLocaleString()} shares @ avg $${order.avgFillPrice}`,
    });

    order.fixMessages.push(
      `8=FIX.4.4|35=8|11=${order.orderId}|39=2|150=2|14=${totalFilled}|6=${order.avgFillPrice}|10=218`
    );
  }

  public runVwapAlgorithm(
    symbol: string,
    totalQuantity: number,
    windowMinutes: number = 60
  ): AlgorithmRun {
    const marketStats = globalMarketEngine.getStats(symbol);
    const order = this.createAndExecuteOrder(
      symbol,
      'BUY',
      totalQuantity,
      'LIMIT',
      marketStats.lastPrice * 1.005,
      'VWAP',
      { windowMinutes, targetParticipationPct: 10 }
    );

    const timeline = [];
    const intervalMins = 10;
    const slices = Math.max(1, Math.floor(windowMinutes / intervalMins));
    const sliceQty = Math.floor(totalQuantity / slices);

    let cum = 0;
    for (let i = 1; i <= slices; i++) {
      cum += sliceQty;
      timeline.push({
        minute: i * intervalMins,
        targetQty: cum,
        cumExecutedQty: cum,
        marketVwap: marketStats.vwap,
        algoVwap: order.avgFillPrice,
      });
    }

    const algoRun: AlgorithmRun = {
      runId: `VWAP-${Math.floor(1000 + Math.random() * 9000)}`,
      algoType: 'VWAP',
      symbol,
      parentOrderId: order.orderId,
      totalQuantity,
      filledQuantity: totalQuantity,
      remainingQuantity: 0,
      windowMinutes,
      elapsedMinutes: windowMinutes,
      targetParticipationPct: 10,
      actualParticipationPct: 9.8,
      expectedVwap: marketStats.vwap,
      executedVwap: order.avgFillPrice,
      slippageBp: order.slippageBp,
      status: 'COMPLETED',
      timeline,
    };

    this.activeAlgorithms.unshift(algoRun);
    return algoRun;
  }
}

export const globalExecutionEngine = new ExecutionEngine();
