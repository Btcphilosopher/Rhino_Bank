/**
 * RHINOQUANT EQUITIES.OS - Smart Order Router (SOR)
 * Calculates optimal venue allocation splits based on price, depth, latency, fees & impact
 */

import { OrderSide, RoutingDecision, VenueQuote } from '../types';
import { globalMarketEngine } from './marketDataEngine';

export class RoutingEngine {
  public calculateRouting(
    symbol: string,
    side: OrderSide,
    quantity: number,
    limitPrice?: number
  ): RoutingDecision {
    const quotes = globalMarketEngine.getVenueQuotes(symbol);
    const nowIso = new Date().toISOString();

    // Sort venues by execution cost (for BUY: lowest ask price, then lowest fee, lowest latency; for SELL: highest bid)
    const sorted = [...quotes].sort((a, b) => {
      if (side === 'BUY') {
        if (a.askPrice !== b.askPrice) return a.askPrice - b.askPrice;
        if (a.feeBp !== b.feeBp) return a.feeBp - b.feeBp;
        return a.latencyMs - b.latencyMs;
      } else {
        if (a.bidPrice !== b.bidPrice) return b.bidPrice - a.bidPrice;
        if (a.feeBp !== b.feeBp) return a.feeBp - b.feeBp;
        return a.latencyMs - b.latencyMs;
      }
    });

    let remaining = quantity;
    const splits: Array<{
      venueId: string;
      venueName: string;
      allocatedShares: number;
      targetPrice: number;
      latencyMs: number;
      estimatedFeeBp: number;
      reason: string;
    }> = [];

    for (const v of sorted) {
      if (remaining <= 0) break;

      const avail = side === 'BUY' ? v.askSize : v.bidSize;
      const targetP = side === 'BUY' ? v.askPrice : v.bidPrice;

      if (limitPrice && limitPrice > 0) {
        if (side === 'BUY' && targetP > limitPrice) continue;
        if (side === 'SELL' && targetP < limitPrice) continue;
      }

      // Take up to available venue size or remaining order quantity
      const takeQty = Math.min(remaining, avail);
      if (takeQty > 0) {
        splits.push({
          venueId: v.venueId,
          venueName: v.venueName,
          allocatedShares: takeQty,
          targetPrice: targetP,
          latencyMs: v.latencyMs,
          estimatedFeeBp: v.feeBp,
          reason: `Best price $${targetP} with ${v.latencyMs}ms latency. Filled ${takeQty.toLocaleString()} shares of ${avail.toLocaleString()} depth.`,
        });
        remaining -= takeQty;
      }
    }

    // If remaining shares exist (e.g., order exceeds total Level 1 depth), sweep remainder into top liquidity venue
    if (remaining > 0) {
      const primaryVenue = sorted[0];
      const targetP = side === 'BUY' ? primaryVenue.askPrice : primaryVenue.bidPrice;
      const existingSplit = splits.find((s) => s.venueId === primaryVenue.venueId);

      if (existingSplit) {
        existingSplit.allocatedShares += remaining;
        existingSplit.reason += ` (Swept remaining ${remaining.toLocaleString()} shares into primary book)`;
      } else {
        splits.push({
          venueId: primaryVenue.venueId,
          venueName: primaryVenue.venueName,
          allocatedShares: remaining,
          targetPrice: targetP,
          latencyMs: primaryVenue.latencyMs,
          estimatedFeeBp: primaryVenue.feeBp,
          reason: `Swept remaining ${remaining.toLocaleString()} shares into venue with best price $${targetP}`,
        });
      }
    }

    // Explainer narrative
    const primaryVenue = splits[0]?.venueId || 'RQEX';
    const explanation = `SOR selected ${splits.length} execution venue(s) across synthetic liquidity pools. Primary allocation ${splits[0]?.allocatedShares.toLocaleString()} shares routed to ${primaryVenue} offering optimal NBBO price and ${splits[0]?.latencyMs}ms ultra-low latency. Multi-venue split minimizes market impact and maximizes fill rate.`;

    return {
      orderId: '',
      timestamp: nowIso,
      orderQuantity: quantity,
      symbol,
      venueSplits: splits,
      explanation,
    };
  }
}

export const globalRoutingEngine = new RoutingEngine();
