/**
 * RHINOQUANT EQUITIES.OS - Deterministic Market Data Engine
 * Seeded with RHINO-EQUITY-SEED-2026
 * Generates Level 2 Order Books, Multi-Venue Quotes, Trade Tapes & Market Shocks
 */

import {
  AuctionImbalance,
  OrderBookDepth,
  OrderBookLevel,
  Security,
  TradeTapeItem,
  VenueQuote,
} from '../types';

export const SYNTHETIC_SEED = 'RHINO-EQUITY-SEED-2026';

export const VENUES_LIST = [
  { venueId: 'RQEX', venueName: 'Rhino Exchange (Lit Direct)', latencyMs: 0.4, feeBp: 0.15, baseDepth: 12000 },
  { venueId: 'NORTHSTAR', venueName: 'Northstar ECN (High Speed)', latencyMs: 0.2, feeBp: 0.10, baseDepth: 18000 },
  { venueId: 'ALBION', venueName: 'Albion Hub (European Liquidity)', latencyMs: 0.6, feeBp: 0.12, baseDepth: 9500 },
  { venueId: 'PACIFIC', venueName: 'Pacific Pool (APAC & Crossing)', latencyMs: 0.8, feeBp: 0.08, baseDepth: 15000 },
  { venueId: 'MERIDIAN', venueName: 'Meridian Direct (Institutional)', latencyMs: 0.3, feeBp: 0.05, baseDepth: 22000 },
  { venueId: 'VECTOR', venueName: 'Vector Smart Venue (Maker Rebate)', latencyMs: 0.1, feeBp: -0.05, baseDepth: 8000 },
];

export const INITIAL_SECURITIES: Security[] = [
  {
    securityId: 'SEC-001',
    symbol: 'RQ-TECH-001',
    companyName: 'RhinoQuant Tech Corp (Synthetic)',
    country: 'United States',
    exchange: 'RQEX',
    currency: 'USD',
    sector: 'Technology',
    industry: 'Enterprise AI & Semiconductors',
    lotSize: 100,
    tickSize: 0.01,
    status: 'ACTIVE',
    primaryVenue: 'RQEX',
    marketCap: 1_850_000_000_000,
    sharesOutstanding: 10_136_978_000,
    freeFloat: 0.92,
    dividendYield: 0.008,
    earningsDate: '2026-10-24',
    corporateActionStatus: 'NONE',
    isSynthetic: true,
  },
  {
    securityId: 'SEC-002',
    symbol: 'RQ-FIN-002',
    companyName: 'Global Financial Group (Synthetic)',
    country: 'United States',
    exchange: 'RQEX',
    currency: 'USD',
    sector: 'Financials',
    industry: 'Investment Banking & Capital Markets',
    lotSize: 100,
    tickSize: 0.01,
    status: 'ACTIVE',
    primaryVenue: 'MERIDIAN',
    marketCap: 420_000_000_000,
    sharesOutstanding: 9_170_305_000,
    freeFloat: 0.95,
    dividendYield: 0.024,
    earningsDate: '2026-10-18',
    corporateActionStatus: 'NONE',
    isSynthetic: true,
  },
  {
    securityId: 'SEC-003',
    symbol: 'RQ-HLTH-003',
    companyName: 'BioPharma Dynamics (Synthetic)',
    country: 'United States',
    exchange: 'RQEX',
    currency: 'USD',
    sector: 'Healthcare',
    industry: 'Biotechnology & Genomics',
    lotSize: 100,
    tickSize: 0.01,
    status: 'ACTIVE',
    primaryVenue: 'NORTHSTAR',
    marketCap: 280_000_000_000,
    sharesOutstanding: 1_332_381_000,
    freeFloat: 0.88,
    dividendYield: 0.015,
    earningsDate: '2026-11-05',
    corporateActionStatus: 'NONE',
    isSynthetic: true,
  },
  {
    securityId: 'SEC-004',
    symbol: 'RQ-ENG-004',
    companyName: 'AeroEnergy Systems (Synthetic)',
    country: 'United Kingdom',
    exchange: 'ALBION',
    currency: 'GBP',
    sector: 'Energy',
    industry: 'Clean Power & Turbines',
    lotSize: 100,
    tickSize: 0.01,
    status: 'ACTIVE',
    primaryVenue: 'ALBION',
    marketCap: 110_000_000_000,
    sharesOutstanding: 3_216_374_000,
    freeFloat: 0.90,
    dividendYield: 0.038,
    earningsDate: '2026-11-12',
    corporateActionStatus: 'NONE',
    isSynthetic: true,
  },
  {
    securityId: 'SEC-005',
    symbol: 'RQ-SEMI-005',
    companyName: 'Tokyo Silicon Foundry (Synthetic)',
    country: 'Japan',
    exchange: 'PACIFIC',
    currency: 'JPY',
    sector: 'Technology',
    industry: 'Semiconductor Fabrication',
    lotSize: 100,
    tickSize: 1.0,
    status: 'ACTIVE',
    primaryVenue: 'PACIFIC',
    marketCap: 310_000_000_000,
    sharesOutstanding: 75_242_718_000,
    freeFloat: 0.85,
    dividendYield: 0.018,
    earningsDate: '2026-10-29',
    corporateActionStatus: 'NONE',
    isSynthetic: true,
  },
  {
    securityId: 'SEC-006',
    symbol: 'AAPL-SYNTH',
    companyName: 'Apple Synthetic Inc (Simulated Data)',
    country: 'United States',
    exchange: 'RQEX',
    currency: 'USD',
    sector: 'Technology',
    industry: 'Consumer Electronics',
    lotSize: 100,
    tickSize: 0.01,
    status: 'ACTIVE',
    primaryVenue: 'RQEX',
    marketCap: 3_450_000_000_000,
    sharesOutstanding: 15_360_000_000,
    freeFloat: 0.98,
    dividendYield: 0.005,
    earningsDate: '2026-10-31',
    corporateActionStatus: 'NONE',
    isSynthetic: true,
  },
  {
    securityId: 'SEC-007',
    symbol: 'NVDA-SYNTH',
    companyName: 'Nvidia Synthetic Corp (Simulated Data)',
    country: 'United States',
    exchange: 'NORTHSTAR',
    currency: 'USD',
    sector: 'Technology',
    industry: 'Graphics Processors',
    lotSize: 100,
    tickSize: 0.01,
    status: 'ACTIVE',
    primaryVenue: 'NORTHSTAR',
    marketCap: 2_910_000_000_000,
    sharesOutstanding: 24_600_000_000,
    freeFloat: 0.96,
    dividendYield: 0.001,
    earningsDate: '2026-11-20',
    corporateActionStatus: 'NONE',
    isSynthetic: true,
  },
  {
    securityId: 'SEC-008',
    symbol: 'MSFT-SYNTH',
    companyName: 'Microsoft Synthetic Corp (Simulated Data)',
    country: 'United States',
    exchange: 'RQEX',
    currency: 'USD',
    sector: 'Technology',
    industry: 'Software & Cloud Infrastructure',
    lotSize: 100,
    tickSize: 0.01,
    status: 'ACTIVE',
    primaryVenue: 'MERIDIAN',
    marketCap: 3_180_000_000_000,
    sharesOutstanding: 7_430_000_000,
    freeFloat: 0.98,
    dividendYield: 0.007,
    earningsDate: '2026-10-22',
    corporateActionStatus: 'NONE',
    isSynthetic: true,
  },
];

// Seeded Pseudo Random Generator for deterministic market evolutions
class SeededRandom {
  private state: number;

  constructor(seedStr: string) {
    let hash = 0;
    for (let i = 0; i < seedStr.length; i++) {
      hash = (hash << 5) - hash + seedStr.charCodeAt(i);
      hash |= 0;
    }
    this.state = Math.abs(hash) || 123456789;
  }

  next(): number {
    this.state = (this.state * 9301 + 49297) % 233280;
    return this.state / 233280;
  }
}

export class MarketDataEngine {
  private rng: SeededRandom;
  private prices: Record<string, number> = {};
  private prevCloses: Record<string, number> = {};
  private opens: Record<string, number> = {};
  private highs: Record<string, number> = {};
  private lows: Record<string, number> = {};
  private volumes: Record<string, number> = {};
  private vwaps: Record<string, number> = {};
  private cumNotional: Record<string, number> = {};
  private tradeTapes: Record<string, TradeTapeItem[]> = {};
  private marketShockMultiplier: number = 1.0;
  private volatilityMultiplier: number = 1.0;
  private liquidityMultiplier: number = 1.0;

  constructor() {
    this.rng = new SeededRandom(SYNTHETIC_SEED);
    this.initDefaultPrices();
  }

  private initDefaultPrices() {
    const defaultPriceMap: Record<string, number> = {
      'RQ-TECH-001': 182.43,
      'RQ-FIN-002': 45.80,
      'RQ-HLTH-003': 210.15,
      'RQ-ENG-004': 34.20,
      'RQ-SEMI-005': 4120.0,
      'AAPL-SYNTH': 224.50,
      'NVDA-SYNTH': 118.20,
      'MSFT-SYNTH': 428.10,
    };

    INITIAL_SECURITIES.forEach((sec) => {
      const p = defaultPriceMap[sec.symbol] || 150.0;
      this.prices[sec.symbol] = p;
      this.prevCloses[sec.symbol] = Number((p * 0.996).toFixed(2));
      this.opens[sec.symbol] = Number((p * 0.998).toFixed(2));
      this.highs[sec.symbol] = Number((p * 1.015).toFixed(2));
      this.lows[sec.symbol] = Number((p * 0.985).toFixed(2));
      this.volumes[sec.symbol] = 8_420_000;
      this.vwaps[sec.symbol] = Number((p * 0.998).toFixed(2));
      this.cumNotional[sec.symbol] = 8_420_000 * p * 0.998;
      this.tradeTapes[sec.symbol] = this.generateInitialTape(sec.symbol, p);
    });
  }

  private generateInitialTape(symbol: string, currentPrice: number): TradeTapeItem[] {
    const items: TradeTapeItem[] = [];
    const now = Date.now();
    for (let i = 20; i >= 1; i--) {
      const ts = new Date(now - i * 1500);
      const iso = ts.toISOString();
      const priceOffset = (this.rng.next() - 0.49) * 0.08;
      const price = Number((currentPrice + priceOffset).toFixed(2));
      const size = Math.floor(this.rng.next() * 15 + 1) * 100;
      const venueObj = VENUES_LIST[Math.floor(this.rng.next() * VENUES_LIST.length)];
      items.push({
        tradeId: `TRD-${Math.floor(100000 + this.rng.next() * 900000)}`,
        timestamp: iso,
        highResTs: ts.getTime(),
        symbol,
        price,
        size,
        venue: venueObj.venueId,
        side: this.rng.next() > 0.5 ? 'BUY' : 'SELL',
        condition: 'REGULAR',
      });
    }
    return items;
  }

  public tickMarket(symbol: string): void {
    const baseP = this.prices[symbol] || 100;
    const vol = 0.0008 * this.volatilityMultiplier;
    const changePct = (this.rng.next() - 0.495) * vol;
    let newP = baseP * (1 + changePct);
    newP = Number((newP * this.marketShockMultiplier).toFixed(2));

    this.prices[symbol] = newP;
    if (newP > this.highs[symbol]) this.highs[symbol] = newP;
    if (newP < this.lows[symbol]) this.lows[symbol] = newP;

    // Add trade
    const size = Math.floor(this.rng.next() * 20 + 1) * 100;
    this.volumes[symbol] += size;
    this.cumNotional[symbol] += newP * size;
    this.vwaps[symbol] = Number((this.cumNotional[symbol] / this.volumes[symbol]).toFixed(2));

    const now = new Date();
    const iso = now.toISOString();
    const venueObj = VENUES_LIST[Math.floor(this.rng.next() * VENUES_LIST.length)];

    const newItem: TradeTapeItem = {
      tradeId: `TRD-${Math.floor(100000 + this.rng.next() * 900000)}`,
      timestamp: iso,
      highResTs: now.getTime(),
      symbol,
      price: newP,
      size,
      venue: venueObj.venueId,
      side: changePct >= 0 ? 'BUY' : 'SELL',
      condition: 'REGULAR',
    };

    if (!this.tradeTapes[symbol]) this.tradeTapes[symbol] = [];
    this.tradeTapes[symbol].unshift(newItem);
    if (this.tradeTapes[symbol].length > 100) {
      this.tradeTapes[symbol].pop();
    }
  }

  public applyShock(dropPct: number, volMultiplier: number, liquidityDropPct: number): void {
    this.marketShockMultiplier = 1.0 - dropPct / 100;
    this.volatilityMultiplier = volMultiplier;
    this.liquidityMultiplier = 1.0 - liquidityDropPct / 100;

    Object.keys(this.prices).forEach((symbol) => {
      this.prices[symbol] = Number((this.prices[symbol] * (1 - dropPct / 100)).toFixed(2));
      this.lows[symbol] = Math.min(this.lows[symbol], this.prices[symbol]);
    });
  }

  public resetShock(): void {
    this.marketShockMultiplier = 1.0;
    this.volatilityMultiplier = 1.0;
    this.liquidityMultiplier = 1.0;
  }

  public getSecurities(): Security[] {
    return INITIAL_SECURITIES;
  }

  public getPrice(symbol: string): number {
    return this.prices[symbol] || 150.0;
  }

  public getStats(symbol: string) {
    const current = this.prices[symbol] || 150.0;
    const prev = this.prevCloses[symbol] || current * 0.996;
    const change = current - prev;
    const changePct = (change / prev) * 100;

    return {
      symbol,
      lastPrice: current,
      prevClose: prev,
      open: this.opens[symbol] || current,
      high: this.highs[symbol] || current,
      low: this.lows[symbol] || current,
      volume: this.volumes[symbol] || 1000000,
      vwap: this.vwaps[symbol] || current,
      change: Number(change.toFixed(2)),
      changePct: Number(changePct.toFixed(2)),
    };
  }

  public getVenueQuotes(symbol: string): VenueQuote[] {
    const mid = this.getPrice(symbol);
    const tick = symbol.includes('JPY') ? 1.0 : 0.01;

    return VENUES_LIST.map((v, idx) => {
      const spreadOffset = (idx * 0.01 + 0.01) * tick;
      const bid = Number((mid - spreadOffset).toFixed(2));
      const ask = Number((mid + spreadOffset).toFixed(2));
      const depthMultiplier = Math.max(0.2, this.liquidityMultiplier);
      const baseDepth = v.baseDepth * depthMultiplier;

      return {
        venueId: v.venueId,
        venueName: v.venueName,
        bidPrice: bid,
        bidSize: Math.floor((baseDepth + (this.rng.next() * 2000 - 1000)) / 100) * 100,
        askPrice: ask,
        askSize: Math.floor((baseDepth + (this.rng.next() * 2000 - 1000)) / 100) * 100,
        latencyMs: v.latencyMs,
        feeBp: v.feeBp,
        depth: Math.floor(baseDepth * 2),
        liquidityScore: Number((baseDepth / 20000).toFixed(2)),
      };
    });
  }

  public getLevel2Depth(symbol: string): OrderBookDepth {
    const mid = this.getPrice(symbol);
    const quotes = this.getVenueQuotes(symbol);
    const bestBid = Math.max(...quotes.map((q) => q.bidPrice));
    const bestAsk = Math.min(...quotes.map((q) => q.askPrice));
    const spread = Number((bestAsk - bestBid).toFixed(2));

    const bids: OrderBookLevel[] = [];
    const asks: OrderBookLevel[] = [];

    let totalBidQty = 0;
    let totalAskQty = 0;

    for (let i = 0; i < 5; i++) {
      const bidP = Number((bestBid - i * 0.01).toFixed(2));
      const askP = Number((bestAsk + i * 0.01).toFixed(2));

      const bidS = Math.floor((12400 - i * 1500 + (this.rng.next() * 1000 - 500)) * this.liquidityMultiplier / 100) * 100;
      const askS = Math.floor((11300 - i * 1200 + (this.rng.next() * 1000 - 500)) * this.liquidityMultiplier / 100) * 100;

      totalBidQty += Math.max(100, bidS);
      totalAskQty += Math.max(100, askS);

      bids.push({ price: bidP, size: Math.max(100, bidS), ordersCount: Math.floor(bidS / 800) + 1, venue: VENUES_LIST[i % VENUES_LIST.length].venueId });
      asks.push({ price: askP, size: Math.max(100, askS), ordersCount: Math.floor(askS / 800) + 1, venue: VENUES_LIST[(i + 2) % VENUES_LIST.length].venueId });
    }

    const imbalanceRatio = Number(((totalBidQty - totalAskQty) / (totalBidQty + totalAskQty)).toFixed(2));

    return {
      symbol,
      timestamp: new Date().toISOString(),
      bids,
      asks,
      spread,
      mid: Number(((bestBid + bestAsk) / 2).toFixed(2)),
      imbalanceRatio,
      estimatedImpactBp: Number((Math.abs(imbalanceRatio) * 4.2 + (1 - this.liquidityMultiplier) * 15).toFixed(1)),
    };
  }

  public getTradeTape(symbol: string): TradeTapeItem[] {
    return this.tradeTapes[symbol] || [];
  }

  public getAuctionImbalance(symbol: string): AuctionImbalance {
    const mid = this.getPrice(symbol);
    return {
      symbol,
      auctionType: 'CLOSING',
      indicativePrice: Number((mid * 1.001).toFixed(2)),
      buyVolume: 1_250_000,
      sellVolume: 980_000,
      imbalanceVolume: 270_000,
      imbalanceDirection: 'BUY_SURPLUS',
      clearingPrice: Number((mid * 1.0012).toFixed(2)),
    };
  }
}

export const globalMarketEngine = new MarketDataEngine();
