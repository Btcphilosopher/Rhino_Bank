/**
 * RHINOQUANT EQUITIES.OS - Institutional Command Palette (Ctrl + K)
 * Keyboard-driven fast execution & navigation bar
 */

import React, { useState, useEffect } from 'react';
import { Search, X, Zap, Shield, TrendingDown, Terminal, Cpu } from 'lucide-react';
import { PrimaryView } from '../types';
import { INITIAL_SECURITIES } from '../services/marketDataEngine';
import { globalExecutionEngine } from '../services/executionEngine';
import { globalMarketEngine } from '../services/marketDataEngine';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  setPrimaryView: (view: PrimaryView) => void;
  onOpenOrderTicketForSymbol: (symbol: string) => void;
  onOpenTerminalMode: () => void;
  onOpenAiCopilot: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  setPrimaryView,
  onOpenOrderTicketForSymbol,
  onOpenTerminalMode,
  onOpenAiCopilot,
}) => {
  const [query, setQuery] = useState<string>('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else {
          // Open
        }
      } else if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleAction = (action: () => void) => {
    action();
    onClose();
  };

  const filteredSecurities = INITIAL_SECURITIES.filter(
    (s) =>
      s.symbol.toLowerCase().includes(query.toLowerCase()) ||
      s.companyName.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 bg-black/80 backdrop-blur-xs p-4 font-mono select-none">
      <div className="bg-[#11151e] border border-slate-700 w-full max-w-xl rounded-lg shadow-2xl overflow-hidden text-slate-200">
        {/* Command Search Input */}
        <div className="bg-[#181f2c] px-3 py-2.5 border-b border-slate-700 flex items-center space-x-2">
          <Search className="w-4 h-4 text-blue-400" />
          <input
            type="text"
            autoFocus
            placeholder="Type command, ticker symbol (e.g. RQ-TECH-001) or shortcut..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-xs text-slate-100 font-bold focus:outline-none placeholder-slate-500"
          />
          <button onClick={onClose} className="text-slate-500 hover:text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Command Actions List */}
        <div className="p-2 space-y-3 max-h-96 overflow-y-auto text-xs">
          {/* Quick Actions */}
          <div>
            <div className="text-[10px] font-bold text-slate-500 uppercase px-2 py-1">QUICK ACTIONS</div>
            <div className="space-y-0.5">
              <button
                onClick={() =>
                  handleAction(() => {
                    onOpenOrderTicketForSymbol('RQ-TECH-001');
                  })
                }
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-[#1a2332] text-emerald-400 font-semibold flex items-center justify-between"
              >
                <span>BUY 25,000 SHARES RQ-TECH-001 (ORDER TICKET)</span>
                <span className="text-[10px] text-slate-500">BUY / TICKET</span>
              </button>

              <button
                onClick={() =>
                  handleAction(() => {
                    globalExecutionEngine.runVwapAlgorithm('RQ-TECH-001', 250000, 60);
                    setPrimaryView('ALGORITHMS');
                  })
                }
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-[#1a2332] text-blue-400 font-semibold flex items-center justify-between"
              >
                <span className="flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-blue-400" />
                  START $50M / 250,000 SHARE VWAP ALGORITHM
                </span>
                <span className="text-[10px] text-slate-500">VWAP EXEC</span>
              </button>

              <button
                onClick={() =>
                  handleAction(() => {
                    globalMarketEngine.applyShock(10, 1.8, 0.4);
                    setPrimaryView('RISK');
                  })
                }
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-[#1a2332] text-rose-400 font-semibold flex items-center justify-between"
              >
                <span className="flex items-center gap-1.5">
                  <TrendingDown className="w-3.5 h-3.5 text-rose-400" />
                  SIMULATE MARKET SHOCK (-10% CRASH + 50% VOL)
                </span>
                <span className="text-[10px] text-slate-500">STRESS SHOCK</span>
              </button>

              <button
                onClick={() =>
                  handleAction(() => {
                    onOpenTerminalMode();
                  })
                }
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-[#1a2332] text-amber-300 font-semibold flex items-center justify-between"
              >
                <span className="flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-amber-400" />
                  OPEN RHINOQUANT &lt;RQ&gt; TERMINAL CLI MODE
                </span>
                <span className="text-[10px] text-slate-500">CLI MODE</span>
              </button>

              <button
                onClick={() =>
                  handleAction(() => {
                    onOpenAiCopilot();
                  })
                }
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-[#1a2332] text-cyan-300 font-semibold flex items-center justify-between"
              >
                <span className="flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                  ASK RHINOQUANT AI COPILOT
                </span>
                <span className="text-[10px] text-slate-500">AI ASSISTANT</span>
              </button>
            </div>
          </div>

          {/* Module Navigation */}
          <div>
            <div className="text-[10px] font-bold text-slate-500 uppercase px-2 py-1">NAVIGATION MODULES</div>
            <div className="grid grid-cols-2 gap-1">
              {(
                [
                  ['MARKETS', 'Market Center & Level 2 Book'],
                  ['ORDERS', 'Order Management System (OMS)'],
                  ['EXECUTION', 'Execution Quality & Rule 605 Analytics'],
                  ['POSITIONS', 'Position Engine & Short Borrow'],
                  ['PORTFOLIO', 'Portfolio Accounting & Hierarchy'],
                  ['RISK', 'Pre-Trade & Portfolio Factor Risk'],
                  ['ALGORITHMS', 'VWAP / TWAP Algo Execution Engine'],
                  ['ROUTING', 'Smart Order Router (SOR) & Venue Split'],
                  ['SETTLEMENT', 'Double-Entry Ledger & T+1 Settlement'],
                  ['AUDIT', 'Immutable Order Event Audit Trail'],
                ] as const
              ).map(([view, desc]) => (
                <button
                  key={view}
                  onClick={() =>
                    handleAction(() => {
                      setPrimaryView(view as PrimaryView);
                    })
                  }
                  className="text-left px-2 py-1.5 rounded hover:bg-[#1a2332] text-slate-300 text-[11px]"
                >
                  <div className="font-bold text-blue-300">{view}</div>
                  <div className="text-[9px] text-slate-500 truncate">{desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Filtered Securities */}
          <div>
            <div className="text-[10px] font-bold text-slate-500 uppercase px-2 py-1">SECURITY MASTER LOOKUP</div>
            <div className="space-y-0.5">
              {filteredSecurities.map((s) => (
                <button
                  key={s.symbol}
                  onClick={() =>
                    handleAction(() => {
                      onOpenOrderTicketForSymbol(s.symbol);
                    })
                  }
                  className="w-full text-left px-2.5 py-1.5 rounded hover:bg-[#1a2332] text-slate-200 flex items-center justify-between"
                >
                  <div>
                    <span className="font-bold text-slate-100 mr-2">{s.symbol}</span>
                    <span className="text-slate-400 text-[10px]">{s.companyName}</span>
                  </div>
                  <span className="text-slate-400 text-[10px] font-mono">${globalMarketEngine.getPrice(s.symbol)}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-[#0b0e14] px-3 py-1.5 border-t border-slate-800 text-[10px] text-slate-500 flex justify-between items-center">
          <span>Press ESC to close</span>
          <span>RhinoQuant Equities OS v3.6</span>
        </div>
      </div>
    </div>
  );
};
