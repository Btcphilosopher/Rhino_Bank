/**
 * RHINOQUANT EQUITIES.OS - Dense Terminal CLI Mode (<RQ>)
 * Monospaced terminal interface with commands and live numerical stats
 */

import React, { useState, useEffect } from 'react';
import { X, Terminal as TerminalIcon, Send } from 'lucide-react';
import { globalMarketEngine } from '../services/marketDataEngine';
import { globalPortfolioEngine } from '../services/portfolioEngine';
import { globalExecutionEngine } from '../services/executionEngine';

interface RhinoTerminalModeProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RhinoTerminalMode: React.FC<RhinoTerminalModeProps> = ({ isOpen, onClose }) => {
  const [cmdInput, setCmdInput] = useState<string>('');
  const [cliLogs, setCliLogs] = useState<string[]>([
    'RHINOQUANT EQUITIES.OS TERMINAL MODE v3.6',
    'CONNECTED TO SYNTHETIC EXECUTIVE ENGINE (SEED: RHINO-EQUITY-SEED-2026)',
    'Type HELP for command list. Example: "BUY 50000 RQ-TECH-001", "SHOCK 10", "VWAP 250000", "POS"',
  ]);
  const [selectedSymbol, setSelectedSymbol] = useState<string>('RQ-TECH-001');

  if (!isOpen) return null;

  const stats = globalMarketEngine.getStats(selectedSymbol);
  const quotes = globalMarketEngine.getVenueQuotes(selectedSymbol);
  const bestBid = Math.max(...quotes.map((q) => q.bidPrice));
  const bestAsk = Math.min(...quotes.map((q) => q.askPrice));
  const spread = Number((bestAsk - bestBid).toFixed(2));
  const portfolio = globalPortfolioEngine.getPortfolio();
  const pos = portfolio.positions.find((p) => p.symbol === selectedSymbol);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cmdInput.trim()) return;

    const input = cmdInput.trim();
    const parts = input.toUpperCase().split(' ');
    const cmd = parts[0];

    const logs = [...cliLogs, `<RQ> ${input}`];

    if (cmd === 'HELP') {
      logs.push('AVAILABLE COMMANDS:');
      logs.push('  BUY <QTY> <SYMBOL>      - Execute buy limit order via SOR');
      logs.push('  SELL <QTY> <SYMBOL>     - Execute sell limit order via SOR');
      logs.push('  VWAP <QTY> [MINUTES]    - Start VWAP execution algorithm');
      logs.push('  SHOCK <DROP_PCT>        - Trigger market shock (-10%, -20%)');
      logs.push('  RESET                   - Reset market shock');
      logs.push('  TICKER <SYMBOL>         - Inspect ticker security master');
      logs.push('  POS                     - List current portfolio positions');
      logs.push('  CLEAR                   - Clear CLI console log');
    } else if (cmd === 'BUY' || cmd === 'SELL') {
      const qty = parseInt(parts[1]) || 10000;
      const sym = parts[2] || selectedSymbol;
      const side = cmd as 'BUY' | 'SELL';

      const order = globalExecutionEngine.createAndExecuteOrder(sym, side, qty);
      logs.push(
        `ORDER EXECUTION RESULT: ${order.orderId} ${order.state} - ${order.filledQuantity.toLocaleString()} / ${order.quantity.toLocaleString()} shs @ $${order.avgFillPrice}`
      );
    } else if (cmd === 'VWAP') {
      const qty = parseInt(parts[1]) || 250000;
      const mins = parseInt(parts[2]) || 60;
      const run = globalExecutionEngine.runVwapAlgorithm(selectedSymbol, qty, mins);
      logs.push(`VWAP ALGO STARTED: ID ${run.runId} - Target ${qty.toLocaleString()} shs over ${mins}m window`);
    } else if (cmd === 'SHOCK') {
      const drop = parseFloat(parts[1]) || 10;
      globalMarketEngine.applyShock(drop, 1.8, 0.4);
      logs.push(`MARKET SHOCK APPLIED: -${drop}% drop, 1.8x Volatility, 40% Liquidity Drop`);
    } else if (cmd === 'RESET') {
      globalMarketEngine.resetShock();
      logs.push('MARKET SHOCK RESET TO NORMAL STATE');
    } else if (cmd === 'TICKER') {
      const sym = parts[1] || 'RQ-TECH-001';
      setSelectedSymbol(sym);
      logs.push(`SWITCHED TERMINAL FOCUS TO ${sym}`);
    } else if (cmd === 'POS') {
      portfolio.positions.forEach((p) => {
        logs.push(`  ${p.symbol}: ${p.quantity.toLocaleString()} shs @ $${p.avgPrice} (Mkt $${p.marketPrice}) P&L: +$${p.unrealizedPnL.toLocaleString()}`);
      });
    } else if (cmd === 'CLEAR') {
      setCliLogs([]);
      setCmdInput('');
      return;
    } else {
      logs.push(`UNRECOGNIZED COMMAND "${cmd}". Type HELP for syntax.`);
    }

    setCliLogs(logs);
    setCmdInput('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-xs p-4 font-mono select-none">
      <div className="bg-[#0a0d12] border border-blue-900/60 w-full max-w-4xl rounded-lg shadow-2xl overflow-hidden text-slate-200">
        {/* Terminal Title Bar */}
        <div className="bg-[#121824] px-4 py-2 border-b border-blue-900/60 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <TerminalIcon className="w-4 h-4 text-blue-400" />
            <span className="font-bold text-xs text-blue-300">&lt;RQ&gt; RHINOQUANT TERMINAL CLI MODE</span>
            <span className="text-[10px] text-slate-500">| HIGH-DENSITY INSTITUTIONAL COCKPIT</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-100">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Dense Ticker Focus Box */}
        <div className="bg-[#0e131d] p-3 border-b border-slate-800 grid grid-cols-6 gap-3 text-xs">
          <div className="col-span-2 bg-[#141b29] p-2 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase">ACTIVE SECURITY</div>
            <div className="font-bold text-base text-slate-100 flex items-center justify-between">
              <span>{selectedSymbol}</span>
              <span className="text-emerald-400 text-sm">${stats.lastPrice}</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1 flex justify-between">
              <span>BID: <strong className="text-slate-200">${bestBid}</strong></span>
              <span>ASK: <strong className="text-slate-200">${bestAsk}</strong></span>
              <span>SPREAD: <strong className="text-amber-400">${spread}</strong></span>
            </div>
          </div>

          <div className="bg-[#141b29] p-2 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">VOLUME / VWAP</div>
            <div className="font-bold text-slate-200 mt-1">{(stats.volume / 1e6).toFixed(2)}M</div>
            <div className="text-[10px] text-blue-400 font-bold">${stats.vwap}</div>
          </div>

          <div className="bg-[#141b29] p-2 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">POSITION / MTM</div>
            <div className="font-bold text-slate-200 mt-1">{pos ? pos.quantity.toLocaleString() : '0'} shs</div>
            <div className={`text-[10px] font-bold ${pos && pos.unrealizedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              MTM: {pos ? `+$${pos.unrealizedPnL.toLocaleString()}` : '$0'}
            </div>
          </div>

          <div className="bg-[#141b29] p-2 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">BETA / VOL</div>
            <div className="font-bold text-slate-200 mt-1">1.21</div>
            <div className="text-[10px] text-slate-400">28.4% ANNL</div>
          </div>

          <div className="bg-[#141b29] p-2 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">LIQUIDITY SCORE</div>
            <div className="font-bold text-emerald-400 mt-1">HIGH (0.92)</div>
            <div className="text-[10px] text-slate-500">6 VENUES</div>
          </div>
        </div>

        {/* CLI Console Output */}
        <div className="p-3 bg-[#080a0f] h-64 overflow-y-auto space-y-1 text-xs font-mono text-emerald-400">
          {cliLogs.map((log, idx) => (
            <div key={idx} className={log.startsWith('<RQ>') ? 'text-blue-300 font-bold' : ''}>
              {log}
            </div>
          ))}
        </div>

        {/* CLI Input Form */}
        <form onSubmit={handleCommand} className="bg-[#121824] px-3 py-2 border-t border-slate-800 flex items-center space-x-2">
          <span className="text-blue-400 font-bold text-xs">&lt;RQ&gt;</span>
          <input
            type="text"
            autoFocus
            value={cmdInput}
            onChange={(e) => setCmdInput(e.target.value)}
            placeholder='Enter CLI command... (e.g. "BUY 100000 RQ-TECH-001", "VWAP 250000", "HELP")'
            className="w-full bg-transparent text-xs text-slate-100 font-mono font-semibold focus:outline-none placeholder-slate-600"
          />
          <button type="submit" className="bg-blue-600 hover:bg-blue-500 text-white p-1 rounded">
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
