/**
 * RHINOQUANT EQUITIES.OS - Primary Navigation Bar
 * Dense, institutional tab switcher for Primary & Secondary views
 */

import React from 'react';
import { PrimaryView, SecondaryView } from '../types';

interface PrimaryNavProps {
  currentPrimaryView: PrimaryView;
  setPrimaryView: (view: PrimaryView) => void;
  currentSecondaryView: SecondaryView;
  setSecondaryView: (view: SecondaryView) => void;
  onOpenOrderTicket: () => void;
}

const PRIMARY_TABS: { id: PrimaryView; label: string }[] = [
  { id: 'MARKETS', label: 'MARKETS' },
  { id: 'WATCHLIST', label: 'WATCHLIST' },
  { id: 'ORDERS', label: 'ORDERS (OMS)' },
  { id: 'EXECUTION', label: 'EXECUTION' },
  { id: 'POSITIONS', label: 'POSITIONS' },
  { id: 'PORTFOLIO', label: 'PORTFOLIO' },
  { id: 'RISK', label: 'RISK' },
  { id: 'ALGORITHMS', label: 'ALGORITHMS' },
  { id: 'ROUTING', label: 'ROUTING (SOR)' },
  { id: 'VENUES', label: 'VENUES' },
  { id: 'RESEARCH', label: 'RESEARCH' },
  { id: 'SIMULATION', label: 'SIMULATION' },
  { id: 'CLEARING', label: 'CLEARING' },
  { id: 'SETTLEMENT', label: 'SETTLEMENT' },
  { id: 'RECON', label: 'RECON' },
  { id: 'SURVEILLANCE', label: 'SURVEILLANCE' },
  { id: 'AUDIT', label: 'AUDIT TRAIL' },
];

const SECONDARY_TABS: { id: SecondaryView; label: string }[] = [
  { id: 'SECURITIES', label: 'SECURITIES' },
  { id: 'INDICES', label: 'INDICES' },
  { id: 'SECTORS', label: 'SECTORS' },
  { id: 'CORPORATE_ACTIONS', label: 'CORPORATE ACTIONS' },
  { id: 'REFERENCE_DATA', label: 'REF DATA' },
  { id: 'ACCOUNTS', label: 'ACCOUNTS' },
  { id: 'BROKERS', label: 'BROKERS' },
  { id: 'MODELS', label: 'MODELS' },
  { id: 'SCENARIOS', label: 'SCENARIOS' },
  { id: 'SETTINGS', label: 'SETTINGS' },
];

export const PrimaryNav: React.FC<PrimaryNavProps> = ({
  currentPrimaryView,
  setPrimaryView,
  currentSecondaryView,
  setSecondaryView,
  onOpenOrderTicket,
}) => {
  return (
    <nav className="bg-[#12161f] border-b border-slate-800 text-xs select-none">
      {/* Primary Module Navigation Tabs */}
      <div className="flex items-center justify-between px-2 overflow-x-auto no-scrollbar scrollbar-none border-b border-slate-800/80">
        <div className="flex items-center space-x-0.5">
          {PRIMARY_TABS.map((tab) => {
            const isActive = currentPrimaryView === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setPrimaryView(tab.id)}
                className={`px-3 py-2 font-mono text-[11px] font-semibold tracking-wide whitespace-nowrap transition-colors border-b-2 ${
                  isActive
                    ? 'border-blue-500 text-blue-400 bg-[#1a212d]'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-[#161c26]'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Quick Order Ticket Trigger */}
        <div className="pl-3 py-1.5 flex items-center">
          <button
            onClick={onOpenOrderTicket}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-[11px] px-3 py-1 rounded border border-emerald-400/30 shadow-sm flex items-center gap-1.5 transition-all"
          >
            <span className="w-2 h-2 rounded-full bg-white animate-ping"></span>
            NEW ORDER TICKET
          </button>
        </div>
      </div>

      {/* Secondary Category Navigation */}
      <div className="flex items-center space-x-1 px-3 py-1 bg-[#0e1117] text-[10px] font-mono overflow-x-auto">
        <span className="text-slate-500 uppercase tracking-widest font-semibold mr-2">SUB-NAV:</span>
        {SECONDARY_TABS.map((tab) => {
          const isActive = currentSecondaryView === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setSecondaryView(tab.id)}
              className={`px-2 py-0.5 rounded transition-colors ${
                isActive
                  ? 'bg-slate-800 text-slate-100 font-bold border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
