/**
 * RHINOQUANT EQUITIES.OS - AI Assistant Copilot Drawer
 * Server-backed quantitative copilot powered by Gemini 3.8 Flash
 */

import React, { useState } from 'react';
import { X, Send, Cpu, Bot, User, Sparkles } from 'lucide-react';

interface AiAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  sender: 'user' | 'ai';
  text: string;
  time: string;
}

export const AiAssistantDrawer: React.FC<AiAssistantDrawerProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'ai',
      text: 'RhinoQuant Quantitative AI Copilot initialized. I have real-time read-only access to your market book depth, active OMS orders, factor risk exposures, and double-entry ledger state. How can I assist with your execution analysis?',
      time: new Date().toLocaleTimeString(),
    },
  ]);
  const [input, setInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    const nowTime = new Date().toLocaleTimeString();

    setMessages((prev) => [...prev, { sender: 'user', text: userMsg, time: nowTime }]);
    setInput('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: userMsg }),
      });
      const data = await res.json();

      setMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: data.reply || 'No response received from assistant.',
          time: new Date().toLocaleTimeString(),
        },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: 'Error communicating with RhinoQuant server assistant.',
          time: new Date().toLocaleTimeString(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-96 bg-[#0f131a] border-l border-slate-800 shadow-2xl flex flex-col font-mono text-xs select-none">
      {/* Drawer Header */}
      <div className="bg-[#181f2b] px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Cpu className="w-4 h-4 text-blue-400" />
          <span className="font-bold text-slate-100">RHINOQUANT AI COPILOT</span>
          <span className="text-[10px] bg-blue-900/50 text-blue-300 border border-blue-700/60 px-1.5 py-0.5 rounded">
            GEMINI 3.8
          </span>
        </div>
        <button onClick={onClose} className="text-slate-400 hover:text-slate-100">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Messages List */}
      <div className="flex-1 p-3 overflow-y-auto space-y-3 bg-[#0a0d12]">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`p-3 rounded border text-xs space-y-1 ${
              m.sender === 'user'
                ? 'bg-[#182232] border-blue-800/60 text-slate-100 ml-6'
                : 'bg-[#131924] border-slate-800 text-slate-200 mr-4'
            }`}
          >
            <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
              <span className="font-bold flex items-center gap-1">
                {m.sender === 'user' ? (
                  <>
                    <User className="w-3 h-3 text-blue-400" /> TRADER
                  </>
                ) : (
                  <>
                    <Bot className="w-3 h-3 text-emerald-400" /> RHINOQUANT COPILOT
                  </>
                )}
              </span>
              <span>{m.time}</span>
            </div>
            <p className="whitespace-pre-line leading-relaxed text-slate-300">{m.text}</p>
          </div>
        ))}

        {isLoading && (
          <div className="p-3 bg-[#131924] border border-slate-800 rounded text-slate-400 text-xs flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-400 animate-spin" />
            Analyzing portfolio & market order book depth...
          </div>
        )}
      </div>

      {/* Suggested Prompts */}
      <div className="px-3 py-2 bg-[#10141d] border-t border-slate-800 flex gap-1 overflow-x-auto text-[10px]">
        <button
          onClick={() => setInput('Explain why order routing split across RQEX and MERIDIAN')}
          className="bg-[#18202d] hover:bg-[#202b3d] text-slate-300 px-2 py-1 rounded border border-slate-700 whitespace-nowrap"
        >
          Explain SOR Venue Split
        </button>
        <button
          onClick={() => setInput('Evaluate VaR and factor risk under 10% market crash')}
          className="bg-[#18202d] hover:bg-[#202b3d] text-slate-300 px-2 py-1 rounded border border-slate-700 whitespace-nowrap"
        >
          Evaluate Crash Risk
        </button>
      </div>

      {/* Input Form */}
      <form onSubmit={handleSend} className="p-3 bg-[#181f2b] border-t border-slate-800 flex items-center space-x-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask quantitative desk copilot..."
          className="flex-1 bg-[#0d1118] border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 text-xs focus:outline-none focus:border-blue-500 placeholder-slate-500"
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="bg-blue-600 hover:bg-blue-500 text-white p-2 rounded disabled:opacity-50"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
