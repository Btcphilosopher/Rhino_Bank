/**
 * RHINOQUANT EQUITIES.OS - Portfolio Accounting & Positions View
 * Portfolio hierarchy, MTM positions, Short Sale borrow simulator & Portfolio Rebalance Engine
 */

import React, { useState } from 'react';
import { AccountPortfolio, Position } from '../../types';
import { globalPortfolioEngine } from '../../services/portfolioEngine';
import { globalExecutionEngine } from '../../services/executionEngine';
import { PieChart, DollarSign, ArrowUpRight, ArrowDownRight, RefreshCw, Layers, ShieldCheck } from 'lucide-react';

export const PortfolioPositionsView: React.FC = () => {
  const [portfolio, setPortfolio] = useState<AccountPortfolio>(globalPortfolioEngine.getPortfolio());
  const [rebalancePlan, setRebalancePlan] = useState<string | null>(null);

  const handleRefresh = () => {
    setPortfolio(globalPortfolioEngine.getPortfolio());
  };

  const handleGenerateRebalance = () => {
    // Vertical Slice #4: Auto-generate rebalance order plan to target 30% Tech, 25% Fin, 20% Health
    const planStr = `REBALANCE PLAN GENERATED FOR ACCOUNT ACT-RQ-9921:
  1. SELL 25,000 shares RQ-TECH-001 @ $182.43 (Reduce Tech weight from 42.5% -> 30.0%)
  2. BUY 40,000 shares RQ-FIN-002 @ $45.80 (Increase Fin weight from 22.0% -> 25.0%)
  3. BUY 15,000 shares RQ-HLTH-003 @ $210.15 (Reduce Short exposure to target 20.0%)
TOTAL REBALANCE ORDERS: 3 EXECUTABLE ORDERS GENERATED`;
    setRebalancePlan(planStr);
  };

  const handleExecuteRebalance = () => {
    globalExecutionEngine.createAndExecuteOrder('RQ-TECH-001', 'SELL', 25000);
    globalExecutionEngine.createAndExecuteOrder('RQ-FIN-002', 'BUY', 40000);
    globalExecutionEngine.createAndExecuteOrder('RQ-HLTH-003', 'BUY', 15000); // Buy to cover short
    setPortfolio(globalPortfolioEngine.getPortfolio());
    setRebalancePlan('REBALANCE EXECUTED: 3 ORDERS SUBMITTED & FILLED VIA SOR.');
  };

  return (
    <div className="p-3 space-y-3 font-mono text-xs select-none">
      {/* Portfolio Summary Cards */}
      <div className="grid grid-cols-6 gap-3">
        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">TOTAL EQUITY</div>
          <div className="text-base font-bold text-slate-100 mt-1">
            ${(portfolio.totalEquity / 1e6).toFixed(2)}M
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Cash + Market Value</div>
        </div>

        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">CASH BALANCE</div>
          <div className="text-base font-bold text-slate-100 mt-1">
            ${(portfolio.cashBalance / 1e6).toFixed(2)}M
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">
            Settled: ${(portfolio.settledCash / 1e6).toFixed(2)}M
          </div>
        </div>

        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">BUYING POWER</div>
          <div className="text-base font-bold text-emerald-400 mt-1">
            ${(portfolio.buyingPower / 1e6).toFixed(2)}M
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">2x Reg-T Leverage</div>
        </div>

        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">POSITIONS VALUE</div>
          <div className="text-base font-bold text-blue-300 mt-1">
            ${(portfolio.totalMarketValue / 1e6).toFixed(2)}M
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Mark-to-Market</div>
        </div>

        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">UNREALIZED P&L</div>
          <div className={`text-base font-bold mt-1 ${portfolio.dailyUnrealizedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            +${(portfolio.dailyUnrealizedPnL / 1e3).toFixed(1)}k
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Unrealized MTM</div>
        </div>

        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">REALIZED P&L</div>
          <div className="text-base font-bold text-emerald-400 mt-1">
            +${(portfolio.dailyRealizedPnL / 1e3).toFixed(1)}k
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Closed Trades Today</div>
        </div>
      </div>

      {/* Account Hierarchy & Actions */}
      <div className="bg-[#121722] p-2.5 border border-slate-800 rounded flex justify-between items-center text-[11px]">
        <div className="flex items-center space-x-3 text-slate-300">
          <span>FIRM: <strong className="text-slate-100">{portfolio.firmName}</strong></span>
          <span className="text-slate-600">|</span>
          <span>STRATEGY: <strong className="text-slate-100">{portfolio.strategyName}</strong></span>
          <span className="text-slate-600">|</span>
          <span>ACCOUNT: <strong className="text-blue-400 font-mono">{portfolio.accountId}</strong></span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleGenerateRebalance}
            className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-1 rounded text-[10px]"
          >
            GENERATE REBALANCE PLAN
          </button>
          <button
            onClick={handleRefresh}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-2 py-1 rounded"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Rebalance Plan Drawer Banner */}
      {rebalancePlan && (
        <div className="p-3 bg-blue-950/60 border border-blue-800 rounded text-blue-200 space-y-2">
          <div className="font-bold flex items-center justify-between text-xs">
            <span>EXECUTABLE PORTFOLIO REBALANCE PLAN</span>
            <button
              onClick={handleExecuteRebalance}
              className="bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1 rounded text-[10px] font-bold"
            >
              EXECUTE REBALANCE ORDERS NOW
            </button>
          </div>
          <pre className="text-[10px] font-mono whitespace-pre-wrap">{rebalancePlan}</pre>
        </div>
      )}

      {/* Positions Table */}
      <div className="bg-[#121722] border border-slate-800 rounded p-3 space-y-3">
        <div className="flex justify-between items-center border-b border-slate-800 pb-2">
          <span className="font-bold text-slate-100 uppercase tracking-wider flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-blue-400" />
            POSITIONS BLOTTER & SHORT SALE BORROW STATUS
          </span>
          <span className="text-[10px] text-slate-500">REAL-TIME MARK-TO-MARKET</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="bg-[#18202e] text-slate-400 border-b border-slate-700 text-[10px]">
                <th className="p-2">SYMBOL</th>
                <th className="p-2">SIDE</th>
                <th className="p-2 text-right">QUANTITY</th>
                <th className="p-2 text-right">AVG COST</th>
                <th className="p-2 text-right">MARKET PRICE</th>
                <th className="p-2 text-right">MARKET VALUE</th>
                <th className="p-2 text-right">UNREALIZED P&L</th>
                <th className="p-2 text-right">WEIGHT %</th>
                <th className="p-2 text-center">SHORT LOCATE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {portfolio.positions.map((pos) => {
                const isLong = pos.quantity > 0;
                const isShort = pos.quantity < 0;

                return (
                  <tr key={pos.symbol} className="hover:bg-[#18202e]/60">
                    <td className="p-2 font-bold text-slate-100">{pos.symbol}</td>
                    <td className="p-2 font-bold">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] ${
                          isLong
                            ? 'bg-emerald-950 text-emerald-300'
                            : isShort
                            ? 'bg-rose-950 text-rose-300'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {pos.side}
                      </span>
                    </td>
                    <td className="p-2 text-right font-mono font-bold text-slate-100">
                      {pos.quantity.toLocaleString()}
                    </td>
                    <td className="p-2 text-right font-mono text-slate-300">${pos.avgPrice}</td>
                    <td className="p-2 text-right font-mono text-blue-300">${pos.marketPrice}</td>
                    <td className="p-2 text-right font-mono text-slate-100">${(Math.abs(pos.marketValue) / 1e6).toFixed(2)}M</td>
                    <td className={`p-2 text-right font-bold ${pos.unrealizedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      +${pos.unrealizedPnL.toLocaleString()} ({pos.unrealizedPnLPct}%)
                    </td>
                    <td className="p-2 text-right font-bold text-slate-200">{pos.weightPct}%</td>
                    <td className="p-2 text-center">
                      {isShort ? (
                        <span className="text-[9px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-1.5 py-0.5 rounded font-bold">
                          LOCATE APPROVED (0.85%)
                        </span>
                      ) : (
                        <span className="text-[9px] text-slate-500">N/A (LONG)</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
