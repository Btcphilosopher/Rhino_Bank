/**
 * RHINOQUANT EQUITIES.OS - Execution Analytics & Quality View
 * SEC Rule 605 execution quality measurement: Slippage Bp, Spread Cost, Market Impact & Arrival Benchmarks
 */

import React from 'react';
import { globalExecutionEngine } from '../../services/executionEngine';
import { BarChart3, TrendingUp, ShieldCheck, Zap } from 'lucide-react';

export const ExecutionAnalyticsView: React.FC = () => {
  const orders = globalExecutionEngine.getOrders().filter((o) => o.state === 'FILLED' || o.state === 'PARTIALLY_FILLED');

  return (
    <div className="p-3 space-y-3 font-mono text-xs select-none">
      {/* Analytics Summary Cards */}
      <div className="grid grid-cols-4 gap-3">
        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">AVG SLIPPAGE VS ARRIVAL</div>
          <div className="text-xl font-bold text-emerald-400 mt-1">-0.42 BP</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Price improvement achieved via SOR</div>
        </div>

        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">AVG SPREAD COST</div>
          <div className="text-xl font-bold text-slate-100 mt-1">$0.008 / SH</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Capturing inside NBBO quote spread</div>
        </div>

        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">ESTIMATED MARKET IMPACT</div>
          <div className="text-xl font-bold text-amber-400 mt-1">0.85 BP</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Temporary price movement caused by order</div>
        </div>

        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">SEC RULE 605 COMPLIANCE</div>
          <div className="text-xl font-bold text-blue-400 mt-1">100.0%</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Sub-millisecond execution audit logging</div>
        </div>
      </div>

      {/* Execution Quality Blotter */}
      <div className="bg-[#121722] border border-slate-800 rounded p-3 space-y-3">
        <div className="flex justify-between items-center border-b border-slate-800 pb-2">
          <span className="font-bold text-slate-100 uppercase tracking-wider flex items-center gap-1.5">
            <BarChart3 className="w-4 h-4 text-blue-400" />
            SEC RULE 605 EXECUTION QUALITY & BENCHMARK ANALYTICS
          </span>
          <span className="text-[10px] text-slate-500">REAL-TIME BENCHMARKING</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="bg-[#18202e] text-slate-400 border-b border-slate-700 text-[10px]">
                <th className="p-2">ORDER ID</th>
                <th className="p-2">SYMBOL</th>
                <th className="p-2 text-right">QUANTITY</th>
                <th className="p-2 text-right">ARRIVAL PRICE</th>
                <th className="p-2 text-right">EXEC AVG PRICE</th>
                <th className="p-2 text-right">VWAP BENCHMARK</th>
                <th className="p-2 text-right">SLIPPAGE (BP)</th>
                <th className="p-2 text-right">IMPACT (BP)</th>
                <th className="p-2 text-right">TOTAL FEES</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {orders.map((ord) => (
                <tr key={ord.orderId} className="hover:bg-[#18202e]/60">
                  <td className="p-2 font-bold text-slate-100">{ord.orderId}</td>
                  <td className="p-2 font-bold text-slate-200">{ord.symbol}</td>
                  <td className="p-2 text-right font-mono">{ord.quantity.toLocaleString()}</td>
                  <td className="p-2 text-right font-mono text-slate-300">${ord.arrivalPrice}</td>
                  <td className="p-2 text-right font-bold text-emerald-400">${ord.avgFillPrice}</td>
                  <td className="p-2 text-right font-mono text-blue-300">${ord.vwapBenchmark}</td>
                  <td className="p-2 text-right font-bold text-emerald-400">{ord.slippageBp} BP</td>
                  <td className="p-2 text-right font-mono text-amber-300">{ord.marketImpactBp} BP</td>
                  <td className="p-2 text-right font-mono text-slate-400">${ord.totalFees}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
