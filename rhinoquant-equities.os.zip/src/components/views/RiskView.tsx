/**
 * RHINOQUANT EQUITIES.OS - Pre-Trade & Portfolio Risk Control View
 * Value at Risk (VaR), Expected Shortfall, Factor Exposures & Interactive Stress Testing
 */

import React, { useState } from 'react';
import { globalRiskEngine } from '../../services/riskEngine';
import { globalPortfolioEngine } from '../../services/portfolioEngine';
import { globalMarketEngine } from '../../services/marketDataEngine';
import { ShieldAlert, TrendingDown, AlertTriangle, Activity, BarChart2, Zap } from 'lucide-react';

export const RiskView: React.FC = () => {
  const [portfolio, setPortfolio] = useState(globalPortfolioEngine.getPortfolio());
  const riskMetrics = globalRiskEngine.calculatePortfolioRisk(portfolio);
  const stressResults = globalRiskEngine.runStressTest(portfolio);

  const handleApplyShock = (dropPct: number) => {
    globalMarketEngine.applyShock(dropPct, 1.8, 0.4);
    setPortfolio(globalPortfolioEngine.getPortfolio());
  };

  const handleResetShock = () => {
    globalMarketEngine.resetShock();
    setPortfolio(globalPortfolioEngine.getPortfolio());
  };

  return (
    <div className="p-3 space-y-3 font-mono text-xs select-none">
      {/* Top Banner & Shock Trigger Controls */}
      <div className="bg-[#121722] p-3 border border-slate-800 rounded flex justify-between items-center">
        <div>
          <span className="font-bold text-slate-100 text-sm flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            INSTITUTIONAL RISK CONTROL & FACTOR ANALYTICS
          </span>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Real-time Value at Risk (VaR), Expected Shortfall, Pre-Trade Collar Enforcement & Stress Testing
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => handleApplyShock(10)}
            className="bg-amber-950 hover:bg-amber-900 border border-amber-800 text-amber-200 font-bold px-3 py-1.5 rounded flex items-center gap-1.5"
          >
            <TrendingDown className="w-3.5 h-3.5 text-amber-400" />
            TRIGGER -10% CRASH
          </button>
          <button
            onClick={() => handleApplyShock(20)}
            className="bg-rose-950 hover:bg-rose-900 border border-rose-800 text-rose-200 font-bold px-3 py-1.5 rounded flex items-center gap-1.5"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            TRIGGER -20% BLACK SWAN
          </button>
          <button
            onClick={handleResetShock}
            className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-1.5 rounded"
          >
            RESET RISK SHOCK
          </button>
        </div>
      </div>

      {/* Risk Metrics Cards */}
      <div className="grid grid-cols-5 gap-3">
        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">PORTFOLIO BETA (SPX)</div>
          <div className="text-xl font-bold text-slate-100 mt-1">{riskMetrics.beta}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Market sensitivity multiplier</div>
        </div>

        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">VALUE AT RISK (95% 1-DAY)</div>
          <div className="text-xl font-bold text-rose-400 mt-1">
            ${(riskMetrics.var95_1D / 1e6).toFixed(2)}M
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Max daily loss at 95% confidence</div>
        </div>

        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">EXPECTED SHORTFALL (CVAR)</div>
          <div className="text-xl font-bold text-rose-400 mt-1">
            ${(riskMetrics.expectedShortfall / 1e6).toFixed(2)}M
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Average loss beyond 95% VaR tail</div>
        </div>

        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">ANNUALIZED VOLATILITY</div>
          <div className="text-xl font-bold text-amber-400 mt-1">{riskMetrics.volatilityPct}%</div>
          <div className="text-[10px] text-slate-500 mt-0.5">30-Day historical volatility</div>
        </div>

        <div className="bg-[#121722] border border-slate-800 rounded p-3">
          <div className="text-[10px] text-slate-400 uppercase font-bold">ACTIVE SHARE</div>
          <div className="text-xl font-bold text-blue-400 mt-1">{riskMetrics.activeSharePct}%</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Deviation from benchmark</div>
        </div>
      </div>

      {/* Stress Testing Table */}
      <div className="bg-[#121722] border border-slate-800 rounded p-3 space-y-3">
        <div className="flex justify-between items-center border-b border-slate-800 pb-2">
          <span className="font-bold text-slate-100 uppercase tracking-wider flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-rose-400" />
            STRESS TESTING & SCENARIO ANALYSIS
          </span>
          <span className="text-[10px] text-slate-500">MONTE CARLO SIMULATION</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="bg-[#18202e] text-slate-400 border-b border-slate-700 text-[10px]">
                <th className="p-2">SCENARIO NAME</th>
                <th className="p-2 text-right">MARKET MOVE</th>
                <th className="p-2 text-right">ESTIMATED P&L IMPACT</th>
                <th className="p-2 text-right">POST-SHOCK MARGIN</th>
                <th className="p-2 text-right">LIQUIDITY SHORTFALL</th>
                <th className="p-2 text-center">RISK STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {stressResults.map((s, idx) => (
                <tr key={idx} className="hover:bg-[#18202e]/60">
                  <td className="p-2 font-bold text-slate-100">{s.scenarioName}</td>
                  <td className="p-2 text-right font-bold text-rose-400">{s.marketMovePct}%</td>
                  <td className="p-2 text-right font-bold text-rose-400 font-mono">
                    -${(Math.abs(s.estimatedPnL) / 1e6).toFixed(2)}M
                  </td>
                  <td className="p-2 text-right font-mono text-slate-200">
                    ${(s.marginRequirementAfter / 1e6).toFixed(2)}M
                  </td>
                  <td className="p-2 text-right font-mono text-amber-300">
                    ${(s.liquidityShortfallUsd / 1e6).toFixed(2)}M
                  </td>
                  <td className="p-2 text-center">
                    <span
                      className={`text-[9px] font-bold px-2 py-0.5 rounded ${
                        s.riskStatus === 'SAFE'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : s.riskStatus === 'WARNING'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-rose-950 text-rose-300 border border-rose-800'
                      }`}
                    >
                      {s.riskStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
