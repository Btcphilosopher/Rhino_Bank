/**
 * RHINOQUANT EQUITIES.OS - Immutable Audit Trail View
 * High-resolution event log answering "What happened to this order?"
 */

import React from 'react';
import { globalExecutionEngine } from '../../services/executionEngine';
import { formatTimeDisplay } from '../../utils/formatters';
import { ShieldCheck, Terminal, FileText } from 'lucide-react';

export const AuditTrailView: React.FC = () => {
  const auditLogs = globalExecutionEngine.getAuditTrail();

  return (
    <div className="p-3 space-y-3 font-mono text-xs select-none">
      <div className="bg-[#121722] p-3 border border-slate-800 rounded flex justify-between items-center">
        <div>
          <span className="font-bold text-slate-100 text-sm flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            IMMUTABLE ORDER EVENT AUDIT TRAIL
          </span>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Cryptographically sealed event stream recording every order state transition, risk check & venue fill
          </div>
        </div>

        <div className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2.5 py-1 rounded font-bold">
          AUDIT ENGINE ACTIVE ({auditLogs.length} EVENTS)
        </div>
      </div>

      <div className="bg-[#121722] border border-slate-800 rounded p-3 space-y-3">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="bg-[#18202e] text-slate-400 border-b border-slate-700 text-[10px]">
                <th className="p-2">EVENT ID</th>
                <th className="p-2">TIMESTAMP</th>
                <th className="p-2">USER / ACTOR</th>
                <th className="p-2">ACTION</th>
                <th className="p-2">ORDER ID</th>
                <th className="p-2">SYMBOL</th>
                <th className="p-2">TRANSITION</th>
                <th className="p-2">DETAILS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {auditLogs.map((log) => (
                <tr key={log.eventId} className="hover:bg-[#18202e]/60">
                  <td className="p-2 font-bold text-slate-100">{log.eventId}</td>
                  <td className="p-2 text-slate-400 text-[10px]">
                    {formatTimeDisplay(log.timestamp)}
                  </td>
                  <td className="p-2 text-blue-300 font-bold">{log.user}</td>
                  <td className="p-2 font-bold text-slate-200">{log.action}</td>
                  <td className="p-2 text-slate-100 font-bold">{log.orderId || 'N/A'}</td>
                  <td className="p-2 text-slate-300">{log.securitySymbol}</td>
                  <td className="p-2 font-bold text-emerald-400 text-[10px]">
                    {log.oldState} → {log.newState}
                  </td>
                  <td className="p-2 text-slate-300 text-[10px] truncate max-w-72">{log.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
