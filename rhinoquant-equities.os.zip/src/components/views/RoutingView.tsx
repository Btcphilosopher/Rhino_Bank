/**
 * RHINOQUANT EQUITIES.OS - Smart Order Router (SOR) & Venues View
 * Multi-venue liquidity pool matrix, latency, fees, depth distribution & routing decision explainers
 */

import React from 'react';
import { globalMarketEngine } from '../../services/marketDataEngine';
import { GitMerge, Cpu, ShieldCheck, Zap } from 'lucide-react';

export const RoutingView: React.FC = () => {
  const symbol = 'RQ-TECH-001';
  const venueQuotes = globalMarketEngine.getVenueQuotes(symbol);

  return (
    <div className="p-3 space-y-3 font-mono text-xs select-none">
      {/* Top Banner */}
      <div className="bg-[#121722] p-3 border border-slate-800 rounded flex justify-between items-center">
        <div>
          <span className="font-bold text-slate-100 text-sm flex items-center gap-2">
            <GitMerge className="w-4 h-4 text-blue-400" />
            SMART ORDER ROUTER (SOR) — MULTI-VENUE LIQUIDITY POOLS
          </span>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Evaluating 6 synthetic venues for price, depth, latency, taker fees & market impact
          </div>
        </div>
        <div className="text-[10px] bg-blue-950 text-blue-300 border border-blue-800 px-2.5 py-1 rounded font-bold">
          SOR ALGORITHM: REG NMS RULE 611 SWEEP
        </div>
      </div>

      {/* Venues Matrix Table */}
      <div className="bg-[#121722] border border-slate-800 rounded p-3 space-y-3">
        <div className="flex justify-between items-center border-b border-slate-800 pb-2">
          <span className="font-bold text-slate-100 uppercase tracking-wider">
            VENUE LIQUIDITY & LATENCY MATRIX ({symbol})
          </span>
          <span className="text-[10px] text-emerald-400 font-bold">6 VENUES ACTIVE</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="bg-[#18202e] text-slate-400 border-b border-slate-700 text-[10px]">
                <th className="p-2">VENUE CODE</th>
                <th className="p-2">VENUE NAME</th>
                <th className="p-2">TYPE</th>
                <th className="p-2 text-right">BID PRICE / SIZE</th>
                <th className="p-2 text-right">ASK PRICE / SIZE</th>
                <th className="p-2 text-right">LATENCY (MS)</th>
                <th className="p-2 text-right">TAKER FEE (BP)</th>
                <th className="p-2 text-center">ROUTING RANK</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {venueQuotes.map((vq, idx) => (
                <tr key={vq.venueId} className="hover:bg-[#18202e]/60">
                  <td className="p-2 font-bold text-blue-400">{vq.venueId}</td>
                  <td className="p-2 font-bold text-slate-100">{vq.venueName}</td>
                  <td className="p-2 text-slate-400 text-[10px]">EXCHANGE (L1/L2)</td>
                  <td className="p-2 text-right text-emerald-400 font-bold">
                    ${vq.bidPrice} ({vq.bidSize.toLocaleString()} shs)
                  </td>
                  <td className="p-2 text-right text-rose-400 font-bold">
                    ${vq.askPrice} ({vq.askSize.toLocaleString()} shs)
                  </td>
                  <td className="p-2 text-right font-mono text-amber-300">{vq.latencyMs} ms</td>
                  <td className="p-2 text-right font-mono text-slate-300">{vq.feeBp} BP</td>
                  <td className="p-2 text-center font-bold text-emerald-400">#{idx + 1}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Routing Explainer Card */}
      <div className="bg-[#121722] border border-slate-800 rounded p-3 space-y-2">
        <div className="font-bold text-slate-100 text-[11px] uppercase tracking-wider flex items-center gap-1.5">
          <Cpu className="w-4 h-4 text-blue-400" />
          SOR DECISION LOGIC EXPLAINER
        </div>
        <p className="text-slate-300 text-[11px] leading-relaxed">
          The Smart Order Router (SOR) splits large institutional block orders across multiple venues to prevent market signaling and minimize slippage. Venues offering the tightest NBBO ask/bid price are prioritized first, followed by sub-millisecond execution latency (e.g. RQEX at 0.42ms) and fee rebate structures. If order size exceeds Level 1 top-of-book depth, the remaining child order shares are swept into secondary dark/lit liquidity books deterministically.
        </p>
      </div>
    </div>
  );
};
