/**
 * RHINOQUANT EQUITIES.OS - Markets View
 * Market Centre, Country Selector, Real-Time Security Master Grid, Level 2 Depth Book & Trade Tape
 */

import React, { useState, useEffect } from 'react';
import { Security, OrderBookDepth, TradeTapeItem } from '../../types';
import { globalMarketEngine } from '../../services/marketDataEngine';
import { formatTimeDisplay } from '../../utils/formatters';
import { ArrowUpRight, ArrowDownRight, Layers, DollarSign, Activity, Play, Zap } from 'lucide-react';

interface MarketsViewProps {
  onOpenOrderTicketForSymbol: (symbol: string) => void;
}

const COUNTRIES = [
  { id: 'US', label: 'UNITED STATES (NYSE / NASDAQ)' },
  { id: 'UK', label: 'UNITED KINGDOM (LSE)' },
  { id: 'EUR', label: 'EUROPE (EURONEXT)' },
  { id: 'JPN', label: 'JAPAN (TSE)' },
  { id: 'HK', label: 'HONG KONG (HKEX)' },
];

export const MarketsView: React.FC<MarketsViewProps> = ({ onOpenOrderTicketForSymbol }) => {
  const [selectedCountry, setSelectedCountry] = useState<string>('US');
  const [selectedSymbol, setSelectedSymbol] = useState<string>('RQ-TECH-001');
  const [stats, setStats] = useState(globalMarketEngine.getStats('RQ-TECH-001'));
  const [l2Book, setL2Book] = useState<OrderBookDepth>(globalMarketEngine.getLevel2Depth('RQ-TECH-001'));
  const [tape, setTape] = useState<TradeTapeItem[]>(globalMarketEngine.getTradeTape('RQ-TECH-001'));

  useEffect(() => {
    const timer = setInterval(() => {
      setStats(globalMarketEngine.getStats(selectedSymbol));
      setL2Book(globalMarketEngine.getLevel2Depth(selectedSymbol));
      setTape(globalMarketEngine.getTradeTape(selectedSymbol));
    }, 250);
    return () => clearInterval(timer);
  }, [selectedSymbol]);

  const allSecurities: Security[] = globalMarketEngine.getSecurities();

  return (
    <div className="p-3 space-y-3 font-mono text-xs select-none">
      {/* Top Country Selector */}
      <div className="bg-[#121722] p-2 border border-slate-800 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-bold uppercase text-[10px]">GLOBAL VENUE JURISDICTION:</span>
          {COUNTRIES.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCountry(c.id)}
              className={`px-2.5 py-1 rounded text-[11px] font-bold transition-colors ${
                selectedCountry === c.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-[#18202e] text-slate-400 hover:text-slate-200'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        <div className="text-[10px] text-slate-400 flex items-center gap-2">
          <span>SEED: <strong className="text-slate-200">RHINO-EQUITY-SEED-2026</strong></span>
          <span className="text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-1.5 py-0.5 rounded">
            L2 BOOK FEED ONLINE
          </span>
        </div>
      </div>

      {/* Main Grid Layout */}
      <div className="grid grid-cols-12 gap-3">
        {/* Left Column: Security Master Grid (7 cols) */}
        <div className="col-span-7 bg-[#121722] border border-slate-800 rounded p-3 space-y-3">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <span className="font-bold text-slate-100 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-blue-400" />
              INSTITUTIONAL SECURITY MASTER & REAL-TIME QUOTES
            </span>
            <span className="text-[10px] text-slate-500">CLICK ROW TO FOCUS LEVEL 2</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="bg-[#18202e] text-slate-400 border-b border-slate-700 text-[10px]">
                  <th className="p-2">SYMBOL</th>
                  <th className="p-2">COMPANY</th>
                  <th className="p-2 text-right">LAST</th>
                  <th className="p-2 text-right">CHG %</th>
                  <th className="p-2 text-right">BID / ASK</th>
                  <th className="p-2 text-right">VWAP</th>
                  <th className="p-2 text-right">VOLUME</th>
                  <th className="p-2 text-center">ACTION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {allSecurities.map((sec) => {
                  const secStats = globalMarketEngine.getStats(sec.symbol);
                  const isPositive = secStats.changePct >= 0;
                  const isSelected = sec.symbol === selectedSymbol;

                  return (
                    <tr
                      key={sec.symbol}
                      onClick={() => setSelectedSymbol(sec.symbol)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-blue-950/40 border-l-2 border-blue-500' : 'hover:bg-[#18202e]/60'
                      }`}
                    >
                      <td className="p-2 font-bold text-slate-100">{sec.symbol}</td>
                      <td className="p-2 text-slate-400 text-[10px] max-w-36 truncate">{sec.companyName}</td>
                      <td className="p-2 text-right font-bold text-slate-100">${secStats.lastPrice}</td>
                      <td className={`p-2 text-right font-bold ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {isPositive ? '+' : ''}{secStats.changePct}%
                      </td>
                      <td className="p-2 text-right text-slate-300 text-[10px]">
                        ${(secStats.lastPrice * 0.9995).toFixed(2)} / ${(secStats.lastPrice * 1.0005).toFixed(2)}
                      </td>
                      <td className="p-2 text-right text-blue-300 font-semibold">${secStats.vwap}</td>
                      <td className="p-2 text-right text-slate-300 font-mono">
                        {(secStats.volume / 1e6).toFixed(2)}M
                      </td>
                      <td className="p-2 text-center" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => onOpenOrderTicketForSymbol(sec.symbol)}
                          className="bg-blue-600 hover:bg-blue-500 text-white px-2 py-0.5 rounded text-[10px] font-bold"
                        >
                          TRADE
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column: L2 Order Book Depth & Trade Tape (5 cols) */}
        <div className="col-span-5 space-y-3">
          {/* Level 2 Book Depth */}
          <div className="bg-[#121722] border border-slate-800 rounded p-3">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2 mb-2">
              <span className="font-bold text-slate-100 text-[11px] flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-emerald-400" />
                LEVEL 2 ORDER BOOK DEPTH ({selectedSymbol})
              </span>
              <span className="text-[10px] text-amber-400 font-bold">
                MID: ${(l2Book.mid).toFixed(2)} | SPREAD: ${(l2Book.spread).toFixed(2)}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
              {/* Bids */}
              <div>
                <div className="bg-emerald-950/40 text-emerald-400 font-bold text-[10px] px-2 py-1 rounded flex justify-between border border-emerald-900/60 mb-1">
                  <span>BID SIZE</span>
                  <span>BID PRICE</span>
                </div>
                <div className="space-y-0.5">
                  {l2Book.bids.map((b, i) => (
                    <div key={i} className="flex justify-between px-2 py-0.5 bg-[#161c28] rounded text-emerald-300 hover:bg-[#1f2838]">
                      <span>{b.size.toLocaleString()}</span>
                      <span className="font-bold">${b.price}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Asks */}
              <div>
                <div className="bg-rose-950/40 text-rose-400 font-bold text-[10px] px-2 py-1 rounded flex justify-between border border-rose-900/60 mb-1">
                  <span>ASK PRICE</span>
                  <span>ASK SIZE</span>
                </div>
                <div className="space-y-0.5">
                  {l2Book.asks.map((a, i) => (
                    <div key={i} className="flex justify-between px-2 py-0.5 bg-[#161c28] rounded text-rose-300 hover:bg-[#1f2838]">
                      <span className="font-bold">${a.price}</span>
                      <span>{a.size.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Time & Sales Trade Tape */}
          <div className="bg-[#121722] border border-slate-800 rounded p-3">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2 mb-2">
              <span className="font-bold text-slate-100 text-[11px]">REAL-TIME TRADE TAPE</span>
              <span className="text-[10px] text-slate-500">MILLISECOND PRECISION</span>
            </div>

            <div className="space-y-1 max-h-48 overflow-y-auto text-[10px] font-mono">
              {tape.slice(0, 10).map((t, i) => (
                <div key={i} className="flex justify-between items-center px-2 py-1 bg-[#161c28] rounded text-slate-300">
                  <span className="text-slate-500">{formatTimeDisplay(t.timestamp)}</span>
                  <span className="font-bold text-slate-100">${t.price}</span>
                  <span>{t.size.toLocaleString()} shs</span>
                  <span className="text-blue-400 font-semibold">{t.venue}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
