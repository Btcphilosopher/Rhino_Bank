/**
 * RHINOQUANT EQUITIES.OS - Algorithmic Execution Engine View
 * VWAP, TWAP, POV & Implementation Shortfall execution monitor with participation rate curves
 */

import React, { useState } from 'react';
import { AlgorithmRun } from '../../types';
import { globalExecutionEngine } from '../../services/executionEngine';
import { globalMarketEngine } from '../../services/marketDataEngine';
import { Zap, Play, TrendingDown, RefreshCw, BarChart2 } from 'lucide-react';

export const AlgorithmsView: React.FC = () => {
  const [selectedAlgoId, setSelectedAlgoId] = useState<string | null>(null);

  const algos = globalExecutionEngine.getActiveAlgorithms();
  const selectedAlgo = algos.find((a) => a.runId === selectedAlgoId) || algos[0];

  const handleRun50MVwap = () => {
    const run = globalExecutionEngine.runVwapAlgorithm('RQ-TECH-001', 250000, 60); // 250,000 shares @ ~182 = ~$45.6M
    setSelectedAlgoId(run.runId);
  };

  const handleTriggerShock = () => {
    globalMarketEngine.applyShock(10, 1.8, 0.4);
  };

  return (
    <div className="p-3 space-y-3 font-mono text-xs select-none">
      {/* Top Controls Bar */}
      <div className="bg-[#121722] p-3 border border-slate-800 rounded flex justify-between items-center">
        <div>
          <span className="font-bold text-slate-100 text-sm flex items-center gap-2">
            <Zap className="w-4 h-4 text-blue-400" />
            ALGORITHMIC EXECUTION ENGINE (VWAP / TWAP / POV)
          </span>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Slices large institutional orders to match volume participation curves and benchmark VWAP
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleRun50MVwap}
            className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-1.5 rounded flex items-center gap-1.5 shadow"
          >
            <Play className="w-3.5 h-3.5" />
            RUN $50M VWAP ALGO (250k SHARES)
          </button>
          <button
            onClick={handleTriggerShock}
            className="bg-rose-950 hover:bg-rose-900 border border-rose-800 text-rose-200 font-bold px-3 py-1.5 rounded flex items-center gap-1.5"
          >
            <TrendingDown className="w-3.5 h-3.5 text-rose-400" />
            TRIGGER MARKET SHOCK DURING EXECUTION
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-12 gap-3">
        {/* Left: Active Algorithms Table (6 cols) */}
        <div className="col-span-6 bg-[#121722] border border-slate-800 rounded p-3 space-y-3">
          <div className="font-bold text-slate-100 uppercase tracking-wider border-b border-slate-800 pb-2">
            RUNNING & HISTORICAL ALGORITHMS ({algos.length})
          </div>

          {algos.length === 0 ? (
            <div className="p-6 text-center text-slate-500 text-xs">
              No algorithm runs active. Click "RUN $50M VWAP ALGO" above to initiate.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="bg-[#18202e] text-slate-400 border-b border-slate-700 text-[10px]">
                    <th className="p-2">RUN ID</th>
                    <th className="p-2">ALGO TYPE</th>
                    <th className="p-2">SYMBOL</th>
                    <th className="p-2 text-right">TARGET QTY</th>
                    <th className="p-2 text-right">FILLED QTY</th>
                    <th className="p-2 text-right">SLIPPAGE</th>
                    <th className="p-2 text-center">STATUS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {algos.map((a) => (
                    <tr
                      key={a.runId}
                      onClick={() => setSelectedAlgoId(a.runId)}
                      className={`cursor-pointer hover:bg-[#18202e]/60 ${
                        selectedAlgo?.runId === a.runId ? 'bg-blue-950/40 border-l-2 border-blue-500' : ''
                      }`}
                    >
                      <td className="p-2 font-bold text-slate-100">{a.runId}</td>
                      <td className="p-2 font-bold text-blue-400">{a.algoType}</td>
                      <td className="p-2 font-bold text-slate-200">{a.symbol}</td>
                      <td className="p-2 text-right font-mono">{a.totalQuantity.toLocaleString()}</td>
                      <td className="p-2 text-right font-mono text-emerald-400">{a.filledQuantity.toLocaleString()}</td>
                      <td className="p-2 text-right font-bold text-emerald-400">{a.slippageBp} BP</td>
                      <td className="p-2 text-center">
                        <span className="text-[9px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-bold">
                          {a.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Right: Selected Algo Participation Curve & Execution Breakdown (6 cols) */}
        {selectedAlgo ? (
          <div className="col-span-6 bg-[#121722] border border-slate-800 rounded p-3 space-y-3">
            <div className="border-b border-slate-800 pb-2 flex justify-between items-center">
              <div>
                <span className="font-bold text-slate-100 text-sm">{selectedAlgo.runId}</span>
                <span className="text-slate-500 text-[10px] ml-2">VWAP EXECUTION BENCHMARK PROFILE</span>
              </div>
              <span className="text-[10px] bg-blue-950 text-blue-300 border border-blue-800 px-2 py-0.5 rounded font-bold">
                PARTICIPATION: {selectedAlgo.actualParticipationPct}%
              </span>
            </div>

            {/* Participation Timeline */}
            <div className="bg-[#0d1017] p-3 rounded border border-slate-800 space-y-2">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <BarChart2 className="w-3.5 h-3.5 text-blue-400" />
                CUMULATIVE VOLUME PARTICIPATION TIMELINE
              </div>
              <div className="space-y-1.5 text-[10px]">
                {selectedAlgo.timeline.map((point, idx) => (
                  <div key={idx} className="space-y-1 bg-[#161c28] p-2 rounded">
                    <div className="flex justify-between font-bold text-slate-200">
                      <span>INTERVAL {point.minute} MIN</span>
                      <span className="text-emerald-400">{point.cumExecutedQty.toLocaleString()} / {selectedAlgo.totalQuantity.toLocaleString()} SHARES</span>
                    </div>
                    <div className="w-full bg-slate-800 h-1.5 rounded overflow-hidden">
                      <div
                        className="bg-blue-500 h-full rounded"
                        style={{ width: `${(point.cumExecutedQty / selectedAlgo.totalQuantity) * 100}%` }}
                      ></div>
                    </div>
                    <div className="flex justify-between text-[9px] text-slate-400">
                      <span>MKT VWAP: <strong className="text-slate-200">${point.marketVwap}</strong></span>
                      <span>ALGO EXECUTED VWAP: <strong className="text-emerald-400">${point.algoVwap}</strong></span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
};
