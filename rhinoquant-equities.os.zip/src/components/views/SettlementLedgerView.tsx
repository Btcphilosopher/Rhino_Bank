/**
 * RHINOQUANT EQUITIES.OS - Settlement, Double-Entry Ledger & Corporate Actions View
 * Double-Entry Journal entries, T+1 DTCC settlement lifecycle, Recon Breaks & Corporate Actions Engine
 */

import React, { useState } from 'react';
import { globalPortfolioEngine } from '../../services/portfolioEngine';
import { BookOpen, CheckCircle2, AlertOctagon, RefreshCw, FileText, Gift } from 'lucide-react';

export const SettlementLedgerView: React.FC = () => {
  const [corporateActionResult, setCorporateActionResult] = useState<string | null>(null);

  const ledgerAccounts = globalPortfolioEngine.getLedgerAccounts();
  const ledgerEntries = globalPortfolioEngine.getLedgerEntries();
  const settlements = globalPortfolioEngine.getSettlementInstructions();
  const reconBreaks = globalPortfolioEngine.getReconciliationBreaks();

  const handleCorporateAction = (actionType: '2_TO_1_SPLIT' | 'CASH_DIVIDEND_2_00') => {
    const res = globalPortfolioEngine.executeCorporateAction('RQ-TECH-001', actionType);
    setCorporateActionResult(res);
  };

  const handleRunRecon = () => {
    globalPortfolioEngine.runReconciliation();
    setCorporateActionResult('Reconciliation complete. Scanned 3,421 settlement records across DTCC & Custody.');
  };

  return (
    <div className="p-3 space-y-3 font-mono text-xs select-none">
      {/* Top Controls & Corporate Actions Banner */}
      <div className="bg-[#121722] p-3 border border-slate-800 rounded flex justify-between items-center">
        <div>
          <span className="font-bold text-slate-100 text-sm flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-blue-400" />
            DOUBLE-ENTRY INTERNAL LEDGER & T+1 SETTLEMENT ENGINE
          </span>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Immutable debit/credit journal entries, DTCC clearing instructions & corporate action processing
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => handleCorporateAction('2_TO_1_SPLIT')}
            className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-1.5 rounded text-[10px]"
          >
            EXECUTE 2:1 STOCK SPLIT (RQ-TECH-001)
          </button>
          <button
            onClick={() => handleCorporateAction('CASH_DIVIDEND_2_00')}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded text-[10px]"
          >
            PROCESS $2.00 CASH DIVIDEND
          </button>
          <button
            onClick={handleRunRecon}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold px-3 py-1.5 rounded text-[10px] flex items-center gap-1"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            RUN RECON
          </button>
        </div>
      </div>

      {corporateActionResult && (
        <div className="p-3 bg-blue-950/60 border border-blue-800 rounded text-blue-200 text-xs font-mono flex items-center justify-between">
          <span>{corporateActionResult}</span>
          <button onClick={() => setCorporateActionResult(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Ledger Accounts Balance Overview */}
      <div className="bg-[#121722] border border-slate-800 rounded p-3 space-y-2">
        <div className="font-bold text-slate-100 uppercase tracking-wider border-b border-slate-800 pb-2">
          DOUBLE-ENTRY LEDGER ACCOUNT BALANCES
        </div>
        <div className="grid grid-cols-4 gap-2">
          {ledgerAccounts.map((acc) => (
            <div key={acc.accountCode} className="bg-[#18202e] p-2 rounded border border-slate-700/60 flex justify-between items-center">
              <div>
                <div className="text-[10px] text-slate-400">{acc.accountCode} — {acc.accountName}</div>
                <div className="font-bold text-slate-100 text-sm mt-0.5">${acc.balance.toLocaleString()}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Grid: Journal Entries & Settlement Instructions */}
      <div className="grid grid-cols-12 gap-3">
        {/* Left: Journal Entries (7 cols) */}
        <div className="col-span-7 bg-[#121722] border border-slate-800 rounded p-3 space-y-2">
          <div className="font-bold text-slate-100 uppercase tracking-wider border-b border-slate-800 pb-2">
            JOURNAL ENTRIES DEBIT / CREDIT LOG ({ledgerEntries.length})
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="bg-[#18202e] text-slate-400 border-b border-slate-700 text-[10px]">
                  <th className="p-2">ENTRY ID</th>
                  <th className="p-2">DESCRIPTION</th>
                  <th className="p-2">DEBIT ACCOUNT</th>
                  <th className="p-2 text-right">DEBIT ($)</th>
                  <th className="p-2">CREDIT ACCOUNT</th>
                  <th className="p-2 text-right">CREDIT ($)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {ledgerEntries.map((e) => (
                  <tr key={e.entryId} className="hover:bg-[#18202e]/60 text-[10px]">
                    <td className="p-2 font-bold text-slate-100">{e.entryId}</td>
                    <td className="p-2 text-slate-300 truncate max-w-44">{e.description}</td>
                    <td className="p-2 text-emerald-400 font-bold">{e.debitAccount}</td>
                    <td className="p-2 text-right font-bold text-emerald-400">${e.debitAmount.toLocaleString()}</td>
                    <td className="p-2 text-rose-400 font-bold">{e.creditAccount}</td>
                    <td className="p-2 text-right font-bold text-rose-400">${e.creditAmount.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right: Settlement Instructions & Recon Breaks (5 cols) */}
        <div className="col-span-5 space-y-3">
          {/* Settlement Instructions */}
          <div className="bg-[#121722] border border-slate-800 rounded p-3 space-y-2">
            <div className="font-bold text-slate-100 uppercase tracking-wider border-b border-slate-800 pb-2">
              T+1 DTCC SETTLEMENT INSTRUCTIONS
            </div>
            <div className="space-y-1.5 text-[10px]">
              {settlements.map((s) => (
                <div key={s.instructionId} className="bg-[#18202e] p-2 rounded border border-slate-700/60 space-y-1">
                  <div className="flex justify-between font-bold text-slate-200">
                    <span>{s.instructionId} ({s.symbol})</span>
                    <span className="text-emerald-400">{s.clearingStatus}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>{s.quantity.toLocaleString()} shs @ NET ${s.netAmount.toLocaleString()}</span>
                    <span>SETTL DATE: {s.settlementDate}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Reconciliation Breaks */}
          <div className="bg-[#121722] border border-slate-800 rounded p-3 space-y-2">
            <div className="font-bold text-slate-100 uppercase tracking-wider border-b border-slate-800 pb-2 flex justify-between">
              <span>RECONCILIATION BREAKS</span>
              <span className="text-amber-400">{reconBreaks.length} BREAKS FOUND</span>
            </div>
            {reconBreaks.length === 0 ? (
              <div className="text-slate-500 text-[10px] py-2">No reconciliation breaks detected. Internal == Custody.</div>
            ) : (
              <div className="space-y-1.5 text-[10px]">
                {reconBreaks.map((b) => (
                  <div key={b.breakId} className="bg-amber-950/40 border border-amber-800/80 p-2 rounded text-amber-200 space-y-1">
                    <div className="flex justify-between font-bold">
                      <span>{b.breakId} — {b.symbol}</span>
                      <span className="text-amber-400">DIFF: {b.diffQty} SHARES</span>
                    </div>
                    <div className="text-slate-300">{b.reason}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
