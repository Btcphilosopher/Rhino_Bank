/**
 * RHINOQUANT EQUITIES.OS - Order Management System (OMS) View
 * Executable order lifecycle inspection, parent/child routing tree, FIX message protocol log & Rule 605 timestamps
 */

import React, { useState } from 'react';
import { Order, OrderState } from '../../types';
import { globalExecutionEngine } from '../../services/executionEngine';
import { formatTimeDisplay } from '../../utils/formatters';
import { CheckCircle2, AlertOctagon, GitBranch, Terminal, Shield, RefreshCw, Layers } from 'lucide-react';

interface OrdersViewProps {
  onOpenOrderTicket: () => void;
}

export const OrdersView: React.FC<OrdersViewProps> = ({ onOpenOrderTicket }) => {
  const [filterState, setFilterState] = useState<string>('ALL');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  const orders = globalExecutionEngine.getOrders();
  const filteredOrders = orders.filter((o) => (filterState === 'ALL' ? true : o.state === filterState));

  const selectedOrder = orders.find((o) => o.orderId === selectedOrderId) || orders[0];

  return (
    <div className="p-3 space-y-3 font-mono text-xs select-none">
      {/* Top Filter Bar */}
      <div className="bg-[#121722] p-2 border border-slate-800 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-bold uppercase text-[10px]">ORDER STATE FILTER:</span>
          {['ALL', 'WORKING', 'FILLED', 'PARTIALLY_FILLED', 'REJECTED', 'CANCELLED'].map((st) => (
            <button
              key={st}
              onClick={() => setFilterState(st)}
              className={`px-2.5 py-1 rounded text-[10px] font-bold transition-colors ${
                filterState === st
                  ? 'bg-blue-600 text-white'
                  : 'bg-[#18202e] text-slate-400 hover:text-slate-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        <button
          onClick={onOpenOrderTicket}
          className="bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1 rounded font-bold text-[11px] flex items-center gap-1.5"
        >
          + NEW ORDER TICKET
        </button>
      </div>

      {/* Main Split Layout */}
      <div className="grid grid-cols-12 gap-3">
        {/* Orders Table (7 cols) */}
        <div className="col-span-7 bg-[#121722] border border-slate-800 rounded p-3 space-y-2">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <span className="font-bold text-slate-100 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-blue-400" />
              OMS ORDER BLOTTER ({filteredOrders.length})
            </span>
            <span className="text-[10px] text-slate-500">CLICK ORDER TO INSPECT LIFECYCLE</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="bg-[#18202e] text-slate-400 border-b border-slate-700 text-[10px]">
                  <th className="p-2">ORDER ID</th>
                  <th className="p-2">SIDE</th>
                  <th className="p-2">SYMBOL</th>
                  <th className="p-2 text-right">QTY</th>
                  <th className="p-2 text-right">FILLED</th>
                  <th className="p-2 text-right">AVG PRICE</th>
                  <th className="p-2 text-center">STATE</th>
                  <th className="p-2 text-right">CREATED</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredOrders.map((ord) => {
                  const isSelected = selectedOrder?.orderId === ord.orderId;
                  const isBuy = ord.side === 'BUY';

                  return (
                    <tr
                      key={ord.orderId}
                      onClick={() => setSelectedOrderId(ord.orderId)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-blue-950/40 border-l-2 border-blue-500' : 'hover:bg-[#18202e]/60'
                      }`}
                    >
                      <td className="p-2 font-bold text-slate-100">{ord.orderId}</td>
                      <td className={`p-2 font-bold ${isBuy ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {ord.side}
                      </td>
                      <td className="p-2 font-bold text-slate-200">{ord.symbol}</td>
                      <td className="p-2 text-right text-slate-300 font-mono">{ord.quantity.toLocaleString()}</td>
                      <td className="p-2 text-right text-slate-300 font-mono">{ord.filledQuantity.toLocaleString()}</td>
                      <td className="p-2 text-right font-bold text-slate-100">
                        ${ord.avgFillPrice > 0 ? ord.avgFillPrice : ord.limitPrice || 'MKT'}
                      </td>
                      <td className="p-2 text-center">
                        <span
                          className={`text-[9px] font-bold px-2 py-0.5 rounded ${
                            ord.state === 'FILLED'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : ord.state === 'REJECTED'
                              ? 'bg-rose-950 text-rose-300 border border-rose-800'
                              : 'bg-blue-950 text-blue-300 border border-blue-800'
                          }`}
                        >
                          {ord.state}
                        </span>
                      </td>
                      <td className="p-2 text-right text-slate-500 text-[10px]">
                        {formatTimeDisplay(ord.createdAt)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Selected Order Inspector (5 cols) */}
        {selectedOrder ? (
          <div className="col-span-5 bg-[#121722] border border-slate-800 rounded p-3 space-y-3">
            <div className="border-b border-slate-800 pb-2 flex justify-between items-center">
              <div>
                <span className="font-bold text-slate-100 text-sm">{selectedOrder.orderId}</span>
                <span className="text-slate-500 text-[10px] ml-2">LIFECYCLE & ROUTING INSPECTOR</span>
              </div>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                  selectedOrder.state === 'FILLED'
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : 'bg-blue-950 text-blue-300 border border-blue-800'
                }`}
              >
                {selectedOrder.state}
              </span>
            </div>

            {/* State Machine History Flow */}
            <div className="bg-[#0d1017] p-2.5 rounded border border-slate-800 space-y-1.5 text-[11px]">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
                <GitBranch className="w-3.5 h-3.5 text-blue-400" />
                EXECUTABLE STATE MACHINE TIMELINE
              </div>
              <div className="space-y-1 text-[10px]">
                {selectedOrder.stateHistory.map((sh, idx) => (
                  <div key={idx} className="flex justify-between items-center bg-[#161c28] p-1.5 rounded">
                    <span className="font-bold text-blue-300">{sh.state}</span>
                    <span className="text-slate-400 text-[9px]">{sh.note}</span>
                    <span className="text-slate-500 text-[9px]">{formatTimeDisplay(sh.timestamp)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Parent / Child Order Routing Tree */}
            <div className="bg-[#0d1017] p-2.5 rounded border border-slate-800 space-y-1 text-[11px]">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                SMART ORDER ROUTER (SOR) VENUE ALLOCATION TREE
              </div>
              <div className="p-2 bg-[#141b27] rounded text-[10px] space-y-1 font-mono">
                <div className="font-bold text-blue-300">
                  PARENT ORDER: {selectedOrder.quantity.toLocaleString()} shs {selectedOrder.symbol}
                </div>
                {selectedOrder.childOrders.map((child, idx) => (
                  <div key={idx} className="pl-3 border-l-2 border-slate-700 flex justify-between text-slate-300">
                    <span>↳ CHILD {child.childId} ({child.venue})</span>
                    <span className="font-bold text-emerald-400">{child.quantity.toLocaleString()} shs @ ${child.price}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Raw FIX 4.4 Protocol Messages */}
            <div className="bg-[#0d1017] p-2.5 rounded border border-slate-800 space-y-1">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <Terminal className="w-3.5 h-3.5 text-amber-400" />
                RAW FIX 4.4 PROTOCOL MESSAGES
              </div>
              <div className="p-2 bg-[#080a0e] rounded text-[9px] font-mono text-amber-300/90 space-y-1 overflow-x-auto">
                {selectedOrder.fixMessages.map((msg, i) => (
                  <div key={i} className="whitespace-nowrap">{msg}</div>
                ))}
              </div>
            </div>

            {/* Fills Table */}
            <div className="bg-[#0d1017] p-2.5 rounded border border-slate-800 space-y-1">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                EXECUTION FILLS ({selectedOrder.fills.length})
              </div>
              <div className="space-y-1 text-[10px]">
                {selectedOrder.fills.map((f, i) => (
                  <div key={i} className="flex justify-between items-center bg-[#161c28] p-1 rounded">
                    <span>{f.venue}</span>
                    <span className="font-bold text-emerald-400">{f.quantity.toLocaleString()} shs</span>
                    <span className="font-bold text-slate-100">${f.price}</span>
                    <span className="text-slate-400 text-[9px]">{f.liquidityRole}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
};
