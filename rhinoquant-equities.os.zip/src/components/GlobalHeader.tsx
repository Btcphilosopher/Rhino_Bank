/**
 * RHINOQUANT EQUITIES.OS - Global Terminal Header
 * Compact institutional market ticker header with millisecond clock, index ticks, system health & environment switcher
 */

import React, { useState, useEffect } from 'react';
import { EnvironmentMode } from '../types';
import { Activity, ShieldCheck, Terminal, AlertTriangle, Search, Cpu } from 'lucide-react';

interface GlobalHeaderProps {
  envMode: EnvironmentMode;
  setEnvMode: (mode: EnvironmentMode) => void;
  onOpenCommandPalette: () => void;
  onOpenTerminalMode: () => void;
  onOpenAiCopilot: () => void;
}

export const GlobalHeader: React.FC<GlobalHeaderProps> = ({
  envMode,
  setEnvMode,
  onOpenCommandPalette,
  onOpenTerminalMode,
  onOpenAiCopilot,
}) => {
  const [clock, setClock] = useState<string>('');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const mins = String(now.getMinutes()).padStart(2, '0');
      const secs = String(now.getSeconds()).padStart(2, '0');
      const ms = String(now.getMilliseconds()).padStart(3, '0');
      setClock(`${hours}:${mins}:${secs}.${ms}`);
    };

    updateClock();
    const interval = setInterval(updateClock, 33); // ~30fps millisecond update
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="bg-[#0b0d11] border-b border-slate-800 text-slate-200 text-xs select-none">
      {/* Top Banner Notice */}
      <div className="bg-[#141820] px-3 py-1 border-b border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
        <div className="flex items-center space-x-3">
          <span className="font-semibold text-slate-100 tracking-wider flex items-center gap-1.5">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            RHINOQUANT EQUITIES.OS
          </span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-300">MARKET: <strong className="text-slate-100">US EQUITIES</strong></span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-300">STATUS: <strong className="text-emerald-400">SIMULATED / OPEN</strong></span>
          <span className="text-slate-600">|</span>
          <span>DATE: <strong className="text-slate-200">22 SEP 2026</strong></span>
          <span className="text-slate-600">|</span>
          <span>CLOCK: <strong className="text-amber-400">{clock || '14:37:21.842'}</strong></span>
        </div>

        {/* Environment Switcher */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center bg-[#1e2430] border border-slate-700 rounded px-1 py-0.5 space-x-1">
            <span className="text-[10px] text-slate-400 uppercase font-semibold px-1">ENV:</span>
            {(['SIMULATION', 'PAPER', 'TEST'] as EnvironmentMode[]).map((mode) => (
              <button
                key={mode}
                onClick={() => setEnvMode(mode)}
                className={`px-1.5 py-0.5 text-[10px] font-mono rounded font-medium transition-colors ${
                  envMode === mode
                    ? 'bg-blue-600 text-white font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>

          <div className="bg-amber-950/40 border border-amber-800/60 text-amber-300 px-2 py-0.5 rounded text-[10px] flex items-center gap-1">
            <AlertTriangle className="w-3 h-3 text-amber-400" />
            SYNTHETIC MARKET / NO LIVE ORDER ROUTING
          </div>
        </div>
      </div>

      {/* Ticker Row */}
      <div className="px-3 py-1.5 flex items-center justify-between border-b border-slate-800/60 bg-[#0f1217]">
        {/* Indices */}
        <div className="flex items-center space-x-6 font-mono text-[11px]">
          <div className="flex items-center space-x-2">
            <span className="text-slate-400 font-bold">SPX</span>
            <span className="text-slate-100 font-semibold">6,482.12</span>
            <span className="text-emerald-400">+0.41%</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-slate-400 font-bold">NASDAQ</span>
            <span className="text-slate-100 font-semibold">21,402.81</span>
            <span className="text-emerald-400">+0.68%</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-slate-400 font-bold">DOW</span>
            <span className="text-slate-100 font-semibold">46,281.42</span>
            <span className="text-emerald-400">+0.18%</span>
          </div>
          <div className="border-l border-slate-800 h-4 mx-1"></div>
          <div className="flex items-center space-x-3 text-slate-400 text-[10px]">
            <span>ADV: <strong className="text-emerald-400">2,841</strong></span>
            <span>DECL: <strong className="text-rose-400">1,714</strong></span>
            <span>UNCH: <strong className="text-slate-300">201</strong></span>
          </div>
        </div>

        {/* System Health Indicators */}
        <div className="flex items-center space-x-4 text-[10px] font-mono">
          <div className="flex items-center space-x-1.5 text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>MKT DATA</span>
          </div>
          <div className="flex items-center space-x-1.5 text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>OMS</span>
          </div>
          <div className="flex items-center space-x-1.5 text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>RISK</span>
          </div>
          <div className="flex items-center space-x-1.5 text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>ROUTER</span>
          </div>
          <div className="flex items-center space-x-1.5 text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>EXECUTION</span>
          </div>
          <div className="flex items-center space-x-1.5 text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>LEDGER</span>
          </div>

          <div className="flex items-center space-x-2 pl-2 border-l border-slate-800">
            <button
              onClick={onOpenTerminalMode}
              className="bg-[#1c2331] hover:bg-[#283244] text-blue-300 border border-blue-800/60 px-2 py-0.5 rounded font-mono text-[11px] flex items-center gap-1"
            >
              <Terminal className="w-3 h-3 text-blue-400" />
              &lt;RQ&gt; CLI
            </button>
            <button
              onClick={onOpenCommandPalette}
              className="bg-[#1c2331] hover:bg-[#283244] text-slate-300 border border-slate-700 px-2 py-0.5 rounded font-mono text-[11px] flex items-center gap-1"
            >
              <Search className="w-3 h-3 text-slate-400" />
              Ctrl+K
            </button>
            <button
              onClick={onOpenAiCopilot}
              className="bg-blue-900/40 hover:bg-blue-800/50 border border-blue-700/80 text-blue-200 px-2 py-0.5 rounded font-mono text-[11px] flex items-center gap-1"
            >
              <Cpu className="w-3 h-3 text-blue-400" />
              AI COPILOT
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
