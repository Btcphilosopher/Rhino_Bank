/**
 * RHINOQUANT EQUITIES.OS - Institutional Order Ticket Modal
 * Executable financial object creation with live Pre-Trade Risk checks
 */

import React, { useState, useEffect } from 'react';
import {
  AlgoStrategy,
  OrderSide,
  OrderType,
  PreTradeRiskCheck,
  TimeInForce,
} from '../types';
import { INITIAL_SECURITIES, globalMarketEngine } from '../services/marketDataEngine';
import { globalRiskEngine } from '../services/riskEngine';
import { globalPortfolioEngine } from '../services/portfolioEngine';
import { globalExecutionEngine } from '../services/executionEngine';
import { X, ShieldCheck, AlertOctagon, CheckCircle2, ArrowRight } from 'lucide-react';

interface OrderTicketModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultSymbol?: string;
  defaultSide?: OrderSide;
  defaultQuantity?: number;
  onOrderSubmitted?: () => void;
}

export const OrderTicketModal: React.FC<OrderTicketModalProps> = ({
  isOpen,
  onClose,
  defaultSymbol = 'RQ-TECH-001',
  defaultSide = 'BUY',
  defaultQuantity = 25000,
  onOrderSubmitted,
}) => {
  const [symbol, setSymbol] = useState<string>(defaultSymbol);
  const [side, setSide] = useState<OrderSide>(defaultSide);
  const [quantity, setQuantity] = useState<number>(defaultQuantity);
  const [orderType, setOrderType] = useState<OrderType>('LIMIT');
  const [limitPrice, setLimitPrice] = useState<number>(182.40);
  const [timeInForce, setTimeInForce] = useState<TimeInForce>('DAY');
  const [algoStrategy, setAlgoStrategy] = useState<AlgoStrategy>('SMART_ROUTE');
  const [account, setAccount] = useState<string>('ACT-RQ-9921 (RhinoQuant Master Fund)');
  const [riskCheck, setRiskCheck] = useState<PreTradeRiskCheck | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Sync market ask/bid price on symbol or side change
  useEffect(() => {
    const stats = globalMarketEngine.getStats(symbol);
    if (side === 'BUY') {
      setLimitPrice(Number((stats.lastPrice * 1.0005).toFixed(2)));
    } else {
      setLimitPrice(Number((stats.lastPrice * 0.9995).toFixed(2)));
    }
  }, [symbol, side]);

  // Recalculate pre-trade risk when inputs change
  useEffect(() => {
    const portfolio = globalPortfolioEngine.getPortfolio();
    const check = globalRiskEngine.validatePreTrade(
      symbol,
      side,
      quantity,
      limitPrice,
      portfolio,
      orderType
    );
    setRiskCheck(check);
  }, [symbol, side, quantity, limitPrice, orderType]);

  if (!isOpen) return null;

  const handleSubmitted = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      globalExecutionEngine.createAndExecuteOrder(
        symbol,
        side,
        quantity,
        orderType,
        limitPrice,
        algoStrategy
      );

      setIsSubmitting(false);
      if (onOrderSubmitted) onOrderSubmitted();
      onClose();
    }, 200);
  };

  const selectedSecurity = INITIAL_SECURITIES.find((s) => s.symbol === symbol);
  const notional = quantity * limitPrice;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 font-mono select-none">
      <div className="bg-[#121620] border border-slate-700 w-full max-w-2xl rounded-lg shadow-2xl overflow-hidden text-slate-200">
        {/* Ticket Header */}
        <div className="bg-[#1a212f] px-4 py-3 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
            <h2 className="font-bold text-sm text-slate-100 tracking-wider">NEW EQUITY ORDER TICKET</h2>
            <span className="text-slate-500 text-xs">| EXECUTABLE FINANCIAL OBJECT</span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-100 p-1 rounded hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmitted} className="p-4 space-y-4 text-xs">
          {/* Top Form Fields */}
          <div className="grid grid-cols-2 gap-4">
            {/* Left Column: Order Parameters */}
            <div className="space-y-3 bg-[#0d1017] p-3 rounded border border-slate-800">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">ORDER SPECIFICATION</div>

              <div>
                <label className="block text-[10px] text-slate-400 mb-1">SECURITY</label>
                <select
                  value={symbol}
                  onChange={(e) => setSymbol(e.target.value)}
                  className="w-full bg-[#161c27] border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 font-bold focus:outline-none focus:border-blue-500"
                >
                  {INITIAL_SECURITIES.map((s) => (
                    <option key={s.symbol} value={s.symbol}>
                      {s.symbol} — {s.companyName}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">SIDE</label>
                  <div className="grid grid-cols-2 gap-1 bg-[#161c27] p-1 rounded border border-slate-700">
                    <button
                      type="button"
                      onClick={() => setSide('BUY')}
                      className={`py-1 text-center font-bold text-[11px] rounded transition-colors ${
                        side === 'BUY' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      BUY
                    </button>
                    <button
                      type="button"
                      onClick={() => setSide('SELL')}
                      className={`py-1 text-center font-bold text-[11px] rounded transition-colors ${
                        side === 'SELL' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      SELL
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">QUANTITY (SHARES)</label>
                  <input
                    type="number"
                    step="100"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(100, Number(e.target.value)))}
                    className="w-full bg-[#161c27] border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 font-bold text-right focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">ORDER TYPE</label>
                  <select
                    value={orderType}
                    onChange={(e) => setOrderType(e.target.value as OrderType)}
                    className="w-full bg-[#161c27] border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 font-semibold focus:outline-none focus:border-blue-500"
                  >
                    <option value="LIMIT">LIMIT</option>
                    <option value="MARKET">MARKET</option>
                    <option value="STOP">STOP</option>
                    <option value="STOP_LIMIT">STOP LIMIT</option>
                    <option value="IOC">IOC (Immediate or Cancel)</option>
                    <option value="FOK">FOK (Fill or Kill)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">LIMIT PRICE ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    disabled={orderType === 'MARKET'}
                    value={limitPrice}
                    onChange={(e) => setLimitPrice(Number(e.target.value))}
                    className="w-full bg-[#161c27] border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 font-bold text-right focus:outline-none focus:border-blue-500 disabled:opacity-50"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">TIME IN FORCE</label>
                  <select
                    value={timeInForce}
                    onChange={(e) => setTimeInForce(e.target.value as TimeInForce)}
                    className="w-full bg-[#161c27] border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 font-semibold focus:outline-none focus:border-blue-500"
                  >
                    <option value="DAY">DAY</option>
                    <option value="GTC">GTC (Good Till Cancel)</option>
                    <option value="IOC">IOC</option>
                    <option value="FOK">FOK</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">ROUTING / ALGO</label>
                  <select
                    value={algoStrategy}
                    onChange={(e) => setAlgoStrategy(e.target.value as AlgoStrategy)}
                    className="w-full bg-[#161c27] border border-slate-700 rounded px-2.5 py-1.5 text-blue-400 font-bold focus:outline-none focus:border-blue-500"
                  >
                    <option value="SMART_ROUTE">SMART ORDER ROUTE (SOR)</option>
                    <option value="VWAP">VWAP (60-MIN WINDOW)</option>
                    <option value="TWAP">TWAP (INTERVAL SLICES)</option>
                    <option value="POV">POV (10% PARTICIPATION)</option>
                    <option value="IMPLEMENTATION_SHORTFALL">IMPLEMENTATION SHORTFALL</option>
                  </select>
                </div>
              </div>

              <div className="bg-[#141a24] p-2 rounded text-[11px] flex justify-between items-center text-slate-300">
                <span>ESTIMATED NOTIONAL:</span>
                <span className="font-bold text-slate-100 text-sm">${notional.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
            </div>

            {/* Right Column: Pre-Trade Risk Verification */}
            <div className="space-y-3 bg-[#0d1017] p-3 rounded border border-slate-800 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
                    PRE-TRADE RISK VALIDATION
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      riskCheck?.overallPassed
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-rose-950 text-rose-300 border border-rose-800'
                    }`}
                  >
                    {riskCheck?.overallPassed ? 'ALL CHECKS PASSED' : 'RISK REJECTED'}
                  </span>
                </div>

                <div className="space-y-1.5 text-[11px]">
                  <div className="flex justify-between items-center py-1 border-b border-slate-800">
                    <span className="text-slate-400">POSITION LIMIT (MAX 15%):</span>
                    <span className={riskCheck?.positionLimit.status === 'PASS' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                      {riskCheck?.positionLimit.status === 'PASS' ? 'PASS' : 'FAIL'} ({riskCheck?.positionLimit.currentVal}%)
                    </span>
                  </div>

                  <div className="flex justify-between items-center py-1 border-b border-slate-800">
                    <span className="text-slate-400">NOTIONAL LIMIT ($50M MAX):</span>
                    <span className={riskCheck?.notionalLimit.status === 'PASS' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                      {riskCheck?.notionalLimit.status === 'PASS' ? 'PASS' : 'FAIL'} (${(notional / 1e6).toFixed(2)}M)
                    </span>
                  </div>

                  <div className="flex justify-between items-center py-1 border-b border-slate-800">
                    <span className="text-slate-400">PRICE COLLAR (+/-3% MID):</span>
                    <span className={riskCheck?.priceCollar.status === 'PASS' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                      {riskCheck?.priceCollar.status === 'PASS' ? 'PASS' : 'FAIL'}
                    </span>
                  </div>

                  <div className="flex justify-between items-center py-1 border-b border-slate-800">
                    <span className="text-slate-400">BUYING POWER COVERAGE:</span>
                    <span className={riskCheck?.buyingPower.status === 'PASS' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                      {riskCheck?.buyingPower.status === 'PASS' ? 'PASS' : 'FAIL'}
                    </span>
                  </div>

                  <div className="flex justify-between items-center py-1 border-b border-slate-800">
                    <span className="text-slate-400">SECURITY STATUS:</span>
                    <span className="text-emerald-400 font-bold">PASS (ACTIVE)</span>
                  </div>

                  <div className="flex justify-between items-center py-1 border-b border-slate-800">
                    <span className="text-slate-400">MARKET STATUS:</span>
                    <span className="text-emerald-400 font-bold">PASS (OPEN)</span>
                  </div>
                </div>

                {/* Risk Rejection Explanation */}
                {!riskCheck?.overallPassed && (
                  <div className="mt-3 p-2 bg-rose-950/60 border border-rose-800 text-rose-200 rounded text-[10px] space-y-1">
                    <div className="font-bold text-rose-300 flex items-center gap-1">
                      <AlertOctagon className="w-3.5 h-3.5 text-rose-400" />
                      REASON: {riskCheck?.rejectionReason}
                    </div>
                    <div>ACTION: {riskCheck?.recommendedAction}</div>
                  </div>
                )}
              </div>

              {/* Account Box */}
              <div className="bg-[#141a24] p-2 rounded text-[10px] text-slate-400">
                <div>ACCOUNT: <strong className="text-slate-200">{account}</strong></div>
                <div>VENUE ROUTER: <strong className="text-blue-300">SOR Multi-Venue (RQEX, MERIDIAN, NORTHSTAR)</strong></div>
              </div>
            </div>
          </div>

          {/* Bottom Actions */}
          <div className="pt-2 flex items-center justify-between border-t border-slate-800">
            <span className="text-[10px] text-slate-500">
              * Fills create double-entry ledger journals and T+1 DTCC settlement instructions.
            </span>

            <div className="flex items-center space-x-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-1.5 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 text-xs font-medium"
              >
                CANCEL
              </button>
              <button
                type="submit"
                disabled={!riskCheck?.overallPassed || isSubmitting}
                className={`px-5 py-2 rounded font-bold text-xs flex items-center gap-2 shadow-lg transition-all ${
                  riskCheck?.overallPassed
                    ? side === 'BUY'
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                      : 'bg-rose-600 hover:bg-rose-500 text-white'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {isSubmitting ? (
                  'EXECUTING IN OMS...'
                ) : (
                  <>
                    SUBMIT EXECUTABLE ORDER
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
