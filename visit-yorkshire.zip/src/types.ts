export interface Destination {
  id: string;
  name: string;
  region: 'dales' | 'moors' | 'coast' | 'cities' | 'south';
  weather: string;
  temp: number;
  description: string;
  distance: string;
  travelTime: string;
  image: string;
  coordinates: { x: number; y: number }; // Percentage coordinate for our map
  highlights: string[];
}

export interface Experience {
  id: string;
  title: string;
  category: 'outdoor' | 'history' | 'food' | 'culture' | 'wellness';
  description: string;
  image: string;
  tag: string;
  readTime?: string;
}

export interface FoodSpot {
  id: string;
  name: string;
  type: 'michelin' | 'pub' | 'tea-room' | 'farm-shop' | 'brewery';
  location: string;
  description: string;
  image: string;
  specialty: string;
}

export interface EventItem {
  id: string;
  title: string;
  date: string;
  month: string; // E.g., 'AUG', 'DEC'
  location: string;
  category: 'music' | 'food' | 'culture' | 'sport';
  price: string;
  image: string;
  description: string;
}

export interface Accommodation {
  id: string;
  name: string;
  type: 'hotel' | 'manor' | 'cottage' | 'glamping' | 'lodge';
  location: string;
  price: string; // E.g. '£180/night'
  rating: number;
  image: string;
  description: string;
  features: string[];
}

export interface BlogArticle {
  id: string;
  title: string;
  readingTime: string;
  category: string;
  author: string;
  date: string;
  image: string;
  snippet: string;
}

export interface WildlifeSpecies {
  id: string;
  name: string;
  habitat: string;
  bestTime: string;
  location: string;
  description: string;
  image: string;
}

export interface HistoryEra {
  id: string;
  era: string;
  period: string;
  title: string;
  description: string;
  legacy: string;
  image: string;
}

// Curated High-Quality Data for Yorkshire
export const DESTINATIONS: Destination[] = [
  {
    id: 'york',
    name: 'York',
    region: 'cities',
    weather: 'Mostly Sunny',
    temp: 18,
    description: 'A majestic walled city of Roman and Viking heritage. Wander through cobblestone medieval alleys, marvel at the Gothic architecture of York Minster, and trace 2,000 years of living history.',
    distance: '190 miles from London',
    travelTime: '1h 50m via LNER Rail',
    image: 'https://images.unsplash.com/photo-1570356528233-b482cbdb4074?auto=format&fit=crop&q=80&w=1200',
    coordinates: { x: 55, y: 58 },
    highlights: ['York Minster Cathedral', 'The Shambles medieval street', 'Jorvik Viking Centre', 'National Railway Museum']
  },
  {
    id: 'yorkshire-dales',
    name: 'Yorkshire Dales',
    region: 'dales',
    weather: 'Clear Skylines',
    temp: 16,
    description: 'An expansive landscape of dramatic limestone valleys, classic drystone walls, and rolling green hills. A paradise for fell walkers, wild swimmers, and lovers of serene country pubs.',
    distance: '230 miles from London',
    travelTime: '3h 15m drive',
    image: 'https://images.unsplash.com/photo-1543872084-c7bd3822856f?auto=format&fit=crop&q=80&w=1200',
    coordinates: { x: 28, y: 38 },
    highlights: ['Malham Cove limestone cliff', 'Ribblehead Viaduct', 'Aysgarth Falls', 'Wensleydale Creamery']
  },
  {
    id: 'whitby',
    name: 'Whitby & Robin Hood\'s Bay',
    region: 'coast',
    weather: 'Bracing Sea Breeze',
    temp: 15,
    description: 'A dramatic coastal town crowned by the Gothic ruins of Whitby Abbey. Taste world-class seafood, descend the iconic 199 steps, and explore the red-roofed, cliffside fishing cottages of Robin Hood\'s Bay.',
    distance: '245 miles from London',
    travelTime: '3h via Rail & Express bus',
    image: 'https://images.unsplash.com/photo-1596464716127-f2a82984de30?auto=format&fit=crop&q=80&w=1200',
    coordinates: { x: 78, y: 24 },
    highlights: ['Whitby Abbey gothic ruins', '199 Steps & Harbour', 'Award-winning Fish & Chips', 'Robin Hood\'s Bay coastal path']
  },
  {
    id: 'north-york-moors',
    name: 'North York Moors',
    region: 'moors',
    weather: 'Sun Spells',
    temp: 16,
    description: 'A vast heather-clothed moorland meeting dramatic coastal cliffs. Ride a nostalgic heritage steam train across timeless valleys and stargaze under one of the UK\'s darkest night skies.',
    distance: '220 miles from London',
    travelTime: '2h 30m train & car',
    image: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=1200',
    coordinates: { x: 62, y: 34 },
    highlights: ['Heather Moorland Bloom', 'North Yorkshire Moors Railway', 'Rievaulx Abbey ruins', 'Goathland Village']
  },
  {
    id: 'leeds',
    name: 'Leeds',
    region: 'cities',
    weather: 'Partly Cloudy',
    temp: 19,
    description: 'A vibrant capital of culture, fashion, and independent gastronomy. Explore grand Victorian shopping arcades, world-class modern art galleries, and a thriving waterfront canal district.',
    distance: '195 miles from London',
    travelTime: '2h 10m via LNER Rail',
    image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=1200',
    coordinates: { x: 44, y: 72 },
    highlights: ['Victoria Quarter shopping', 'Royal Armouries Museum', 'Leeds Corn Exchange', 'Waterfront Dining']
  },
  {
    id: 'harrogate',
    name: 'Harrogate',
    region: 'cities',
    weather: 'Mild',
    temp: 17,
    description: 'A sophisticated Victorian spa town of manicured gardens, refined stone architecture, and elegant afternoon teas. Indulge in restorative Turkish baths and walk through pristine royal parks.',
    distance: '200 miles from London',
    travelTime: '2h 20m via Rail',
    image: 'https://images.unsplash.com/photo-1508849789987-4e5333c12b78?auto=format&fit=crop&q=80&w=1200',
    coordinates: { x: 45, y: 52 },
    highlights: ['Betty\'s Café Tea Rooms', 'Victorian Turkish Baths', 'The Stray 200-acre park', 'RHS Garden Harlow Carr']
  },
  {
    id: 'sheffield',
    name: 'Sheffield',
    region: 'cities',
    weather: 'Sunny Spells',
    temp: 18,
    description: 'The Outdoor City. Merges a rich manufacturing heritage with lush urban woodlands, a legendary music legacy, and immediate trail access to the Peak District.',
    distance: '160 miles from London',
    travelTime: '2h via East Midlands Railway',
    image: 'https://images.unsplash.com/photo-1533103054090-334e6e60ab29?auto=format&fit=crop&q=80&w=1200',
    coordinates: { x: 38, y: 88 },
    highlights: ['Sheffield Winter Garden', 'Millennium Gallery', 'Kelham Island Museum', 'Peak District trails']
  },
  {
    id: 'scarborough',
    name: 'Scarborough',
    region: 'coast',
    weather: 'Fresh Breeze',
    temp: 15,
    description: 'A pioneering seaside resort boasting twin sandy bays, a cliffside Victorian funicular railway, and an imposing 12th-century castle overlooking the bay.',
    distance: '240 miles from London',
    travelTime: '3h via TransPennine Rail',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=1200',
    coordinates: { x: 88, y: 38 },
    highlights: ['Scarborough Castle ruins', 'Peasholm Park boating lake', 'South Bay sandy beach', 'Stephen Joseph Theatre']
  },
  {
    id: 'peak-district',
    name: 'Peak District (Yorkshire)',
    region: 'dales',
    weather: 'Clear Skylines',
    temp: 16,
    description: 'The spectacular northern reaches of the Peak District, featuring dramatic gritstone edges, historic stone villages, and panoramic fells perfect for fells walking.',
    distance: '165 miles from London',
    travelTime: '2h 30m drive',
    image: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&q=80&w=1200',
    coordinates: { x: 22, y: 80 },
    highlights: ['Stanage Edge gritstone escarpment', 'Langsett Reservoir', 'Saddleworth Moor trails', 'Uppermill Village']
  },
  {
    id: 'hull',
    name: 'Hull (Kingston-upon-Hull)',
    region: 'cities',
    weather: 'Breezy',
    temp: 17,
    description: 'A vibrant maritime city of historic cobblestone old towns, free world-class museums, a thriving digital scene, and the spectacular Humber Bridge spanning the estuary.',
    distance: '198 miles from London',
    travelTime: '2h 30m via Hull Trains',
    image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&q=80&w=1200',
    coordinates: { x: 74, y: 78 },
    highlights: ['The Deep sub-aquatic aquarium', 'Historic Old Town & cobblestones', 'Humber Bridge lookout', 'Ferens Art Gallery']
  }
];

export const EXPERIENCES: Experience[] = [
  {
    id: 'walking',
    title: 'Fell Walking & Hikes',
    category: 'outdoor',
    description: 'Conquer the legendary Yorkshire Three Peaks (Pen-y-ghent, Whernside, and Ingleborough) or walk along the spectacular limestone pavement of Malham Cove.',
    image: 'https://images.unsplash.com/photo-1551632811-561732d1e306?auto=format&fit=crop&q=80&w=600',
    tag: 'Adventurous'
  },
  {
    id: 'castles',
    title: 'Medieval Abbeys & Castles',
    category: 'history',
    description: 'Explore the spectacular, atmospheric ruins of Fountains Abbey (a UNESCO World Heritage site), Rievaulx Abbey, and the imposing battlements of Richmond Castle.',
    image: 'https://images.unsplash.com/photo-1533103054090-334e6e60ab29?auto=format&fit=crop&q=80&w=600',
    tag: 'Timeless'
  },
  {
    id: 'steam-railway',
    title: 'Heritage Steam Railways',
    category: 'history',
    description: 'Step back in time on the North Yorkshire Moors Railway, riding a beautifully restored steam train through breathtaking heather-clad valleys and charming villages.',
    image: 'https://images.unsplash.com/photo-1474487548417-781cb71495f3?auto=format&fit=crop&q=80&w=600',
    tag: 'Nostalgic'
  },
  {
    id: 'beaches',
    title: 'Wild Coastlines & Beaches',
    category: 'outdoor',
    description: 'Walk along the dramatic cliffs of Flamborough Head, hunt for fossils on Whitby beach, or watch the picturesque fishing boats in the sheltered harbor of Staithes.',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=600',
    tag: 'Authentic'
  },
  {
    id: 'pubs',
    title: 'Historic Country Pubs',
    category: 'food',
    description: 'Warm up by roaring open fires in hundreds-of-years-old stone inns, sipping award-winning local pale ales and tasting locally sourced, traditional pub dishes.',
    image: 'https://images.unsplash.com/photo-1544148103-0773bf10d330?auto=format&fit=crop&q=80&w=600',
    tag: 'Cozy'
  },
  {
    id: 'dark-skies',
    title: 'Dark Sky Stargazing',
    category: 'outdoor',
    description: 'With dual International Dark Sky Reserves in the Dales and Moors, experience pristine, crystal-clear night skies showing the Milky Way in dazzling clarity.',
    image: 'https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?auto=format&fit=crop&q=80&w=600',
    tag: 'Breath-taking'
  }
];

export const FOOD_SPOTS: FoodSpot[] = [
  {
    id: 'the-black-swan',
    name: 'The Black Swan at Oldstead',
    type: 'michelin',
    location: 'Oldstead, North York Moors',
    description: 'Michelin-starred dining led by Chef Tommy Banks. Almost every single ingredient is grown, reared, or foraged on their productive family farm, creating a pure taste of Yorkshire.',
    image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&q=80&w=600',
    specialty: 'Foraged Multi-course Tasting Menu'
  },
  {
    id: 'bettys-cafe',
    name: 'Bettys Café Tea Rooms',
    type: 'tea-room',
    location: 'Harrogate & York',
    description: 'A timeless institution serving elegant afternoon tea since 1919. Expect pristine white aprons, grand piano melodies, and legendary Swiss-Yorkshire pastries.',
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&q=80&w=600',
    specialty: 'Traditional Imperial Afternoon Tea'
  },
  {
    id: 'magpie-cafe',
    name: 'The Magpie Café',
    type: 'pub',
    location: 'Whitby Harbour',
    description: 'Known internationally as one of the very best spots for British fish and chips. Located in an elegant black-and-white merchant house overlooking the sea.',
    image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&q=80&w=600',
    specialty: 'Line-Caught Haddock & Twice-Cooked Beef Dripping Chips'
  },
  {
    id: 'keelham-farm',
    name: 'Keelham Farm Shop',
    type: 'farm-shop',
    location: 'Skipton, Dales Gateway',
    description: 'A massive celebration of regional agriculture, stocking award-winning meats from local dales butchers, seasonal vegetables, Yorkshire cheeses, and independent spirits.',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=600',
    specialty: 'Artisanal Yorkshire Blue and Wensleydale Cheeses'
  }
];

export const EVENTS: EventItem[] = [
  {
    id: 'great-yorkshire-show',
    title: 'The Great Yorkshire Show',
    date: '14 - 17 July 2026',
    month: 'JUL',
    location: 'Showground, Harrogate',
    category: 'culture',
    price: '£32.50',
    image: 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&q=80&w=600',
    description: 'England\'s premier agricultural event celebrating countryside culture, food, and majestic livestock championships. A highly premium showcase of rural excellence.'
  },
  {
    id: 'york-food-festival',
    title: 'York Food & Drink Festival',
    date: '18 - 27 Sept 2026',
    month: 'SEP',
    location: 'Parliament Street, York',
    category: 'food',
    price: 'Free Entry',
    image: 'https://images.unsplash.com/photo-1505576399279-565b52d4ac71?auto=format&fit=crop&q=80&w=600',
    description: 'A 10-day culinary celebration featuring regional farm stalls, live cookery theaters led by Michelin-starred chefs, local brewery bars, and evening street food markets.'
  },
  {
    id: 'whitby-goth-weekend',
    title: 'Whitby Goth Weekend',
    date: '30 Oct - 1 Nov 2026',
    month: 'OCT',
    location: 'Spa Pavilion, Whitby',
    category: 'culture',
    price: '£22.00+',
    image: 'https://images.unsplash.com/photo-1509248961158-e54f6934749c?auto=format&fit=crop&q=80&w=600',
    description: 'A world-famous alternative cultural festival, paying homage to Bram Stoker\'s Dracula which was inspired by Whitby Abbey. Features grand gothic attire and live music.'
  },
  {
    id: 'dales-walking-festival',
    title: 'Yorkshire Dales Walking Festival',
    date: '12 - 20 June 2026',
    month: 'JUN',
    location: 'Across the Dales',
    category: 'sport',
    price: '£8.00 / guided walk',
    image: 'https://images.unsplash.com/photo-1551632811-561732d1e306?auto=format&fit=crop&q=80&w=600',
    description: 'Guided historical, flora, and fauna hikes across rolling limestone peaks led by expert mountain rangers. Includes cozy pub finishers.'
  }
];

export const ACCOMMODATION: Accommodation[] = [
  {
    id: 'grantley-hall',
    name: 'Grantley Hall',
    type: 'manor',
    location: 'Ripon, North Yorkshire',
    description: 'A breathtaking 17th-century country house estate offering ultimate luxury, a Michelin-starred restaurant, and an ultra-modern holistic wellness spa.',
    price: '£450/night',
    rating: 5.0,
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=600',
    features: ['Three AA Rosette Restaurant', 'Holistic ELITE Wellness Gym', 'Manicured Japanese Gardens', 'Valet Parking']
  },
  {
    id: 'the-pheasant-inn',
    name: 'The Pheasant Hotel',
    type: 'hotel',
    location: 'Harome, North York Moors',
    description: 'A beautifully restored boutique country inn overlooking a picturesque duck pond. Filled with rustic oak beams, country fabrics, and exceptional regional food.',
    price: '£185/night',
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&q=80&w=600',
    features: ['Award-winning Dining', 'Indoor Heated Pool', 'Dog Friendly', 'Real log fireplaces']
  },
  {
    id: 'dales-stone-cottage',
    name: 'Beckside Stone Cottage',
    type: 'cottage',
    location: 'Muker, Swaledale',
    description: 'A cozy, centuries-old traditional dales cottage featuring flagstone floors, a wood-burning stove, and a private garden bordering a babbling hill stream.',
    price: '£120/night',
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1549693578-d683be217e58?auto=format&fit=crop&q=80&w=600',
    features: ['Wood-burning Stove', 'Stargazing skylights', 'Direct trail access', 'Local Cheese hamper']
  },
  {
    id: 'moors-dome',
    name: 'High Moorland Geodesic Domes',
    type: 'glamping',
    location: 'Goathland, Moors',
    description: 'Luxury transparent geodesic domes nestled in private meadows. Sleep beneath dark night skies with all the comforts of a high-end boutique hotel room.',
    price: '£160/night',
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&q=80&w=600',
    features: ['Private Wood-fired Hot Tub', 'Transparent ceiling', 'En-suite shower room', 'Heated floors']
  }
];

export const ARTICLES: BlogArticle[] = [
  {
    id: 'stargazing-guide',
    title: 'A Guide to Stargazing in Yorkshire\'s Dark Sky Reserves',
    readingTime: '6 min read',
    category: 'Adventure',
    author: 'Dr. Emily Hughes',
    date: '12 June 2026',
    image: 'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?auto=format&fit=crop&q=80&w=800',
    snippet: 'With negligible light pollution, the Yorkshire Dales and North York Moors offer some of the most spectacular, crystal-clear stargazing spots in Europe. Here is where and when to look up.'
  },
  {
    id: 'michelin-trail',
    title: 'The Ultimate Yorkshire Michelin-Starred Culinary Tour',
    readingTime: '8 min read',
    category: 'Gastronomy',
    author: 'Marcus Vance',
    date: '28 May 2026',
    image: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&q=80&w=800',
    snippet: 'Yorkshire boasts more Michelin stars than any other English region outside London. We map a five-day route taking in spectacular estates, farm-to-table pubs, and sensory culinary marvels.'
  },
  {
    id: 'coastal-escape',
    title: 'Secrets of the Heritage Coast: Staithes to Robin Hood\'s Bay',
    readingTime: '5 min read',
    category: 'Travel',
    author: 'Sarah Jenkins',
    date: '10 April 2026',
    image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=800',
    snippet: 'Beyond the crowded harbors lie secret beaches, fossil beds dating back millions of years, and smugglers\' tunnels carved directly into Yorkshire\'s towering coastal cliffs.'
  }
];

export const WILDLIFE: WildlifeSpecies[] = [
  {
    id: 'seals',
    name: 'Grey Seals & Common Seals',
    habitat: 'Coastal Shores',
    bestTime: 'November - January (Pupping season)',
    location: 'Ravenscar Coastal Cliffs',
    description: 'Witness hundreds of grey seals basking on beach rocks beneath massive coastal cliffs. A spectacular natural sight, viewable from safe vantage points above.',
    image: 'https://images.unsplash.com/photo-1470240731273-7821a6eeb6bd?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'puffins',
    name: 'Atlantic Puffins',
    habitat: 'Ocean Cliffs',
    bestTime: 'April - July',
    location: 'Bempton Cliffs Nature Reserve',
    description: 'Half a million seabirds gather on Yorkshire\'s towering chalk cliffs. See puffins, gannets, and guillemots nesting in massive, noisy, and colorful sea colonies.',
    image: 'https://images.unsplash.com/photo-1518173946687-a4c8a383392e?auto=format&fit=crop&q=80&w=600'
  }
];

export const HISTORY_TIMELINE: HistoryEra[] = [
  {
    id: 'romans',
    era: '71 AD - 410 AD',
    period: 'Roman Eboracum',
    title: 'The Birth of York',
    description: 'Romans establish Eboracum as a major military fortress and capital of Britannia Inferior. Emperors Constantine the Great is crowned here, and Hadrian visits to inspect the northern defenses.',
    legacy: 'York\'s Roman fortress walls, baths, and underground sewers.',
    image: 'https://images.unsplash.com/photo-1549693578-d683be217e58?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'vikings',
    era: '866 AD - 954 AD',
    period: 'Viking Jórvík',
    title: 'The Norse Capital',
    description: 'The Great Heathen Army captures York, renaming it Jórvík. Under Viking rulers like Eric Bloodaxe, the city thrives as a major international trading port connected to Baltic trade routes.',
    legacy: 'Jorvik Street excavations, Viking names ending in -gate, and craft relics.',
    image: 'https://images.unsplash.com/photo-1509248961158-e54f6934749c?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'monastics',
    era: '1132 AD - 1539 AD',
    period: 'Medieval Monasticism',
    title: 'Abbeys of Infinite Power',
    description: 'Cistercian and Benedictine monks construct architectural masterpieces in Yorkshire valleys. Abbeys like Fountains and Rievaulx become centers of wealth, learning, and massive wool export.',
    legacy: 'The majestic ruined Gothic arches of Fountains Abbey (UNESCO) and Whitby.',
    image: 'https://images.unsplash.com/photo-1533103054090-334e6e60ab29?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'industrial',
    era: '1780 AD - 1900 AD',
    period: 'Industrial Revolution',
    title: 'The Engine of Britain',
    description: 'Leeds, Sheffield, and Bradford become world capitals of textiles and steel. Sheffield masters precision cutlery while Saltaire (UNESCO) establishes a model village for textile weavers.',
    legacy: 'Grand Victorian civic halls, canal networks, and historic mills.',
    image: 'https://images.unsplash.com/photo-1474487548417-781cb71495f3?auto=format&fit=crop&q=80&w=600'
  }
];
