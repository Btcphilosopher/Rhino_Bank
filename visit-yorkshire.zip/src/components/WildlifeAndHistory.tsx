import { useState } from "react";
import { BookOpen, Calendar, ShieldCheck, Heart, MapPin, Search, Compass, Sparkles, User, Info } from "lucide-react";
import { HISTORY_TIMELINE, WILDLIFE, HistoryEra, WildlifeSpecies } from "../types";
import { motion, AnimatePresence } from "motion/react";

export default function WildlifeAndHistory() {
  const [activeTab, setActiveTab] = useState<"history" | "wildlife">("history");
  const [selectedEra, setSelectedEra] = useState<HistoryEra>(HISTORY_TIMELINE[0]);
  const [selectedSpecies, setSelectedSpecies] = useState<WildlifeSpecies>(WILDLIFE[0]);

  return (
    <section id="wildlife-heritage" className="py-24 md:py-32 bg-yorkshire-stone dark:bg-yorkshire-slate border-t border-yorkshire-slate/10 dark:border-white/10">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Title Block */}
        <div className="mb-16 text-left max-w-3xl">
          <span className="text-xs uppercase font-bold tracking-[0.25em] text-minster-gold block mb-3">
            ROOTS & HEIRLOOMS
          </span>
          <h2 className="font-serif text-4xl md:text-6xl font-bold tracking-tight text-yorkshire-slate dark:text-white leading-tight mb-6">
            Chronicles & Native Wildlife
          </h2>
          <p className="text-base md:text-lg text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
            Uncover 2,000 years of historic triumphs—from Viking kings and Gothic abbey ruins to the Brontë sisters' moorlands—and locate colonies of wild puffins, sea lions, and red squirrels.
          </p>
        </div>

        {/* Dual-Themed Tab Switches */}
        <div className="flex justify-center mb-16">
          <div className="bg-yorkshire-stone/85 dark:bg-black/25 border border-yorkshire-slate/10 dark:border-white/10 p-1.5 rounded-2xl flex">
            <button
              onClick={() => setActiveTab("history")}
              className={`px-8 py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer focus:outline-none ${
                activeTab === "history"
                  ? "bg-yorkshire-slate dark:bg-yorkshire-stone text-yorkshire-stone dark:text-yorkshire-slate shadow-md"
                  : "text-yorkshire-slate/60 dark:text-yorkshire-stone/60 hover:text-yorkshire-slate"
              }`}
            >
              Chronicles of History
            </button>
            <button
              onClick={() => setActiveTab("wildlife")}
              className={`px-8 py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer focus:outline-none ${
                activeTab === "wildlife"
                  ? "bg-yorkshire-slate dark:bg-yorkshire-stone text-yorkshire-stone dark:text-yorkshire-slate shadow-md"
                  : "text-yorkshire-slate/60 dark:text-yorkshire-stone/60 hover:text-yorkshire-slate"
              }`}
            >
              Native Wildlife Watch
            </button>
          </div>
        </div>

        {/* Tab Contents */}
        <AnimatePresence mode="wait">
          {activeTab === "history" ? (
            /* HISTORY INTERACTIVE SPLIT PANEL */
            <motion.div
              key="history"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.45 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch"
            >
              {/* Left timeline selector cards (Span 5) */}
              <div className="lg:col-span-5 space-y-4">
                <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-yorkshire-slate/40 dark:text-yorkshire-stone/40 block mb-2 font-mono">HISTORICAL TIMELINE ERAS</span>
                {HISTORY_TIMELINE.map((era) => {
                  const isSelected = selectedEra.id === era.id;
                  return (
                    <button
                      key={era.id}
                      onClick={() => setSelectedEra(era)}
                      className={`w-full text-left p-5 rounded-2xl border transition-all cursor-pointer focus:outline-none block ${
                        isSelected
                          ? "bg-white dark:bg-white/10 border-minster-gold shadow-md"
                          : "bg-white/30 dark:bg-white/5 border-yorkshire-slate/10 dark:border-white/5 hover:border-minster-gold/30"
                      }`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-[9px] font-mono uppercase font-bold text-minster-gold">
                          {era.period}
                        </span>
                        <span className="text-[9px] uppercase font-extrabold tracking-widest bg-yorkshire-stone/80 dark:bg-black/30 text-yorkshire-slate/50 dark:text-yorkshire-stone/50 px-2 py-0.5 rounded">
                          {era.era}
                        </span>
                      </div>
                      <h3 className={`font-serif text-lg font-bold ${isSelected ? "text-minster-gold" : "text-yorkshire-slate dark:text-white"}`}>
                        {era.title}
                      </h3>
                    </button>
                  );
                })}
              </div>

              {/* Right Showcase card (Span 7) */}
              <div className="lg:col-span-7 bg-white/45 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 p-8 md:p-10 rounded-3xl flex flex-col justify-between">
                <div>
                  {/* Photo Frame */}
                  <div className="relative aspect-16/9 rounded-xl overflow-hidden mb-6 bg-yorkshire-slate/10 shadow-inner">
                    <img
                      src={selectedEra.image}
                      alt={selectedEra.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent pointer-events-none" />
                    <span className="absolute bottom-4 left-4 text-white text-xs font-mono font-bold">
                      {selectedEra.period}
                    </span>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-minster-gold">
                      <BookOpen className="w-4 h-4" />
                      <span>{selectedEra.era} Narrative Chronicles</span>
                    </div>

                    <h3 className="font-serif text-3xl font-bold text-yorkshire-slate dark:text-white leading-tight">
                      {selectedEra.title}
                    </h3>
                    
                    <p className="text-sm text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
                      {selectedEra.description}
                    </p>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-yorkshire-slate/10 dark:border-white/10 bg-yorkshire-stone/30 dark:bg-black/15 p-4 rounded-xl flex items-start space-x-3 text-xs">
                  <Info className="w-4.5 h-4.5 text-minster-gold mt-0.5 flex-shrink-0" />
                  <div>
                    <span className="text-[9px] uppercase font-bold text-yorkshire-slate/40 dark:text-yorkshire-stone/40 block mb-0.5 font-mono">REGIONAL ARCHAEOLOGICAL LEGACY</span>
                    <p className="font-light text-yorkshire-slate/85 dark:text-yorkshire-stone/85 leading-relaxed italic">
                      "{selectedEra.legacy}"
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          ) : (
            /* WILDLIFE WATCH INTERACTIVE SPLIT PANEL */
            <motion.div
              key="wildlife"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.45 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch"
            >
              {/* Left selectors list (Span 5) */}
              <div className="lg:col-span-5 space-y-4">
                <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-yorkshire-slate/40 dark:text-yorkshire-stone/40 block mb-2 font-mono">NATIVE FAUNA WATCH</span>
                {WILDLIFE.map((spec) => {
                  const isSelected = selectedSpecies.id === spec.id;
                  return (
                    <button
                      key={spec.id}
                      onClick={() => setSelectedSpecies(spec)}
                      className={`w-full text-left p-5 rounded-2xl border transition-all cursor-pointer focus:outline-none block ${
                        isSelected
                          ? "bg-white dark:bg-white/10 border-minster-gold shadow-md"
                          : "bg-white/30 dark:bg-white/5 border-yorkshire-slate/10 dark:border-white/5 hover:border-minster-gold/30"
                      }`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-[9px] font-mono uppercase font-bold text-minster-gold">
                          Best Sightings: {spec.bestTime}
                        </span>
                      </div>
                      <h3 className={`font-serif text-lg font-bold ${isSelected ? "text-minster-gold" : "text-yorkshire-slate dark:text-white"}`}>
                        {spec.name}
                      </h3>
                      <p className="text-[11px] text-yorkshire-slate/50 dark:text-yorkshire-stone/50 truncate">
                        {spec.habitat}
                      </p>
                    </button>
                  );
                })}
              </div>

              {/* Right Details Card (Span 7) */}
              <div className="lg:col-span-7 bg-white/45 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 p-8 md:p-10 rounded-3xl flex flex-col justify-between">
                <div>
                  {/* Photo Frame */}
                  <div className="relative aspect-16/9 rounded-xl overflow-hidden mb-6 bg-yorkshire-slate/10">
                    <img
                      src={selectedSpecies.image}
                      alt={selectedSpecies.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent pointer-events-none" />
                    <span className="absolute bottom-4 left-4 text-white text-xs font-mono font-bold flex items-center">
                      <MapPin className="w-3.5 h-3.5 mr-1.5 text-minster-gold" />
                      {selectedSpecies.location}
                    </span>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-minster-gold">
                      <Heart className="w-4 h-4" />
                      <span>Sighting Season: {selectedSpecies.bestTime}</span>
                    </div>

                    <h3 className="font-serif text-3xl font-bold text-yorkshire-slate dark:text-white leading-tight">
                      {selectedSpecies.name}
                    </h3>

                    <p className="text-sm text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
                      {selectedSpecies.description}
                    </p>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-yorkshire-slate/10 dark:border-white/10 grid grid-cols-2 gap-4">
                  <div className="bg-yorkshire-stone/30 dark:bg-black/15 p-4 rounded-xl text-xs">
                    <span className="text-[9px] uppercase font-bold text-yorkshire-slate/40 dark:text-yorkshire-stone/40 block mb-1">SIGHTING SPOTLIGHT</span>
                    <p className="font-semibold text-yorkshire-slate dark:text-white leading-tight">{selectedSpecies.location}</p>
                    <p className="text-[10px] text-yorkshire-slate/50 dark:text-yorkshire-stone/50 mt-1">Snaizeholme / Cliffs reserves.</p>
                  </div>
                  <div className="bg-yorkshire-stone/30 dark:bg-black/15 p-4 rounded-xl text-xs flex items-start space-x-2.5">
                    <ShieldCheck className="w-5 h-5 text-moorland-green mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="text-[9px] uppercase font-bold text-moorland-green block mb-0.5">RANGER ETHICS</span>
                      <p className="text-[10px] text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
                        Keep distance, use telescopic lenses, and carry out all waste. Protect our peat & shores.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
