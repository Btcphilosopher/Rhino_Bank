import { useState } from "react";
import { Snowflake, Sun, Leaf, Flower, Sparkles, Compass } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface SeasonData {
  id: "spring" | "summer" | "autumn" | "winter";
  name: string;
  tagline: string;
  icon: any;
  description: string;
  image: string;
  activities: string[];
  vibe: string;
  colorClass: string;
}

const SEASONS: SeasonData[] = [
  {
    id: "spring",
    name: "Spring",
    tagline: "Wild Daffodils & New Life in the Valleys",
    icon: Flower,
    vibe: "Vibrant Awakening",
    colorClass: "text-moorland-green",
    description: "Experience Farndale filled with millions of wild yellow daffodils. Watch newborn lambs skip across drystone walls in Swaledale while dramatic mountain waterfalls run full from melting snows.",
    image: "https://images.unsplash.com/photo-1543872084-c7bd3822856f?auto=format&fit=crop&q=80&w=1200",
    activities: [
      "Walk the Farndale Daffodil Valley walk",
      "Observe sheep farming pupping season in Muker fells",
      "Taste fresh spring rhubarb in the 'Rhubarb Triangle'",
      "Hike around Malham Tarn as spring flora awakens"
    ]
  },
  {
    id: "summer",
    name: "Summer",
    tagline: "Sunkissed Coastal Cliffs & Bright Moorlands",
    icon: Sun,
    vibe: "Warm Exploration",
    colorClass: "text-minster-gold",
    description: "Bask on sandy shores in Scarborough and Whitby, climb under clear skies on Stanage Edge, and wander through pristine royal parks. Evenings are made for local beer gardens in stone villages.",
    image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=1200",
    activities: [
      "Sail along the Heritage Coast cliffs from Whitby",
      "Attend the prestigious Great Yorkshire Show in Harrogate",
      "Enjoy local ales in beer gardens beside limestone streams",
      "Camp beneath pristine night skies during the Milky Way season"
    ]
  },
  {
    id: "autumn",
    name: "Autumn",
    tagline: "Golden Moorlands & Atmospheric Ruins",
    icon: Leaf,
    vibe: "Mellow & Gothic",
    colorClass: "text-burnt-orange",
    description: "See the North York Moors turn a deep rust-purple as heather blooms fade. Golden copper foliage frames monastic ruins like Fountains Abbey, creating a spectacular photography paradise.",
    image: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=1200",
    activities: [
      "Explore Fountains Abbey surrounded by fiery golden forests",
      "Ride the steam train during the North York Moors autumn gala",
      "Experience Whitby Goth Weekend's Dracula celebrations",
      "Forage for wild mushrooms in national park woodlands"
    ]
  },
  {
    id: "winter",
    name: "Winter",
    tagline: "Frosty Fell Valleys & Cozy Fireside Pubs",
    icon: Snowflake,
    vibe: "Cozy Solitude",
    colorClass: "text-sea-blue",
    description: "Watch a pristine, silent layer of white frost settle over rolling drystone pastures. Retreat inside historic stone inns to warm up by crackling open hearths with locally brewed stout.",
    image: "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&q=80&w=1200",
    activities: [
      "Stroll through magical Christmas Markets in medieval York",
      "Walk the frosted, quiet paths of Settle and Malham",
      "Gather around roaring open fires in a 300-year-old stone pub",
      "Observe stargazing constellations during the dark skies peak"
    ]
  }
];

export default function SeasonalInspiration() {
  const [activeSeason, setActiveSeason] = useState<SeasonData>(SEASONS[0]);

  return (
    <section id="seasons" className="py-24 md:py-32 bg-yorkshire-stone dark:bg-yorkshire-slate">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Section Header */}
        <div className="mb-16 text-left max-w-3xl">
          <span className="text-xs uppercase font-bold tracking-[0.25em] text-minster-gold block mb-3">
            A YEAR-ROUND WONDER
          </span>
          <h2 className="font-serif text-4xl md:text-6xl font-bold tracking-tight text-yorkshire-slate dark:text-white leading-tight mb-6">
            Seasonal Inspiration
          </h2>
          <p className="text-base md:text-lg text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
            Every season in Yorkshire brings an immersive shift in sensory experiences, visual beauty, and heritage activities. Select a season below to envision your perfect getaway.
          </p>
        </div>

        {/* Season Navigation Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {SEASONS.map((season) => {
            const isActive = activeSeason.id === season.id;
            const IconComp = season.icon;
            return (
              <button
                key={season.id}
                onClick={() => setActiveSeason(season)}
                className={`p-6 rounded-2xl border text-center transition-all duration-300 flex flex-col items-center justify-center space-y-3 cursor-pointer focus:outline-none ${
                  isActive
                    ? "bg-white dark:bg-white/10 shadow-lg border-minster-gold scale-[1.02]"
                    : "bg-white/40 dark:bg-white/5 border-yorkshire-slate/10 dark:border-white/5 hover:border-minster-gold/40"
                }`}
              >
                <div className={`p-3 rounded-full bg-yorkshire-stone/80 dark:bg-black/25 ${season.colorClass}`}>
                  <IconComp className="w-6 h-6" />
                </div>
                <div>
                  <span className="block font-serif text-lg font-bold text-yorkshire-slate dark:text-white leading-none">
                    {season.name}
                  </span>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-yorkshire-slate/40 dark:text-yorkshire-stone/40 mt-1 block">
                    {season.vibe}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Interactive Season Showcase Display Frame */}
        <div className="bg-white dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 rounded-3xl overflow-hidden shadow-xl">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSeason.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.5 }}
              className="grid grid-cols-1 lg:grid-cols-12 items-stretch"
            >
              {/* Left Side: Editorial Details */}
              <div className="lg:col-span-7 p-8 md:p-12 lg:p-16 flex flex-col justify-between">
                <div>
                  <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-minster-gold mb-4">
                    <Sparkles className="w-4 h-4" />
                    <span>{activeSeason.vibe} in Yorkshire</span>
                  </div>
                  
                  <h3 className="font-serif text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight text-yorkshire-slate dark:text-white mb-2 leading-tight">
                    {activeSeason.name}
                  </h3>
                  <h4 className="font-serif text-lg md:text-xl text-minster-gold italic font-semibold mb-6">
                    {activeSeason.tagline}
                  </h4>
                  
                  <p className="text-sm md:text-base text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light mb-8">
                    {activeSeason.description}
                  </p>

                  <h5 className="text-xs uppercase font-extrabold tracking-wider text-yorkshire-slate/50 dark:text-yorkshire-stone/50 mb-4 flex items-center">
                    <Compass className="w-4 h-4 mr-2 text-minster-gold" />
                    Recommended Activities
                  </h5>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {activeSeason.activities.map((act, index) => (
                      <li key={index} className="text-xs text-yorkshire-slate/80 dark:text-yorkshire-stone/80 flex items-start">
                        <span className="w-1.5 h-1.5 rounded-full bg-minster-gold mt-1.5 mr-3 flex-shrink-0" />
                        <span>{act}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Right Side: Photo Frame */}
              <div className="lg:col-span-5 h-[350px] lg:h-auto min-h-[350px] relative">
                <img
                  src={activeSeason.image}
                  alt={activeSeason.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-white dark:from-yorkshire-slate via-transparent to-transparent pointer-events-none" />
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

      </div>
    </section>
  );
}
