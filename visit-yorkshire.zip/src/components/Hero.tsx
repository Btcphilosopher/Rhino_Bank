import { useState, useEffect } from "react";
import { ArrowDown, Play, ChevronRight, Volume2, VolumeX } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface HeroProps {
  scrollToSection: (id: string) => void;
}

const HERO_IMAGES = [
  {
    url: "https://images.unsplash.com/photo-1543872084-c7bd3822856f?auto=format&fit=crop&q=80&w=1920",
    title: "Golden Sunrise over the Yorkshire Dales",
    caption: "A timeless morning glow painting limestone valleys and drystone walls."
  },
  {
    url: "https://images.unsplash.com/photo-1596464716127-f2a82984de30?auto=format&fit=crop&q=80&w=1920",
    title: "Spectacular Gothic ruins of Whitby Abbey",
    caption: "Hovering high above the wild North Sea where legends were born."
  },
  {
    url: "https://images.unsplash.com/photo-1570356528233-b482cbdb4074?auto=format&fit=crop&q=80&w=1920",
    title: "The Majestic spires of York Minster Cathedral",
    caption: "Over 2,000 years of English heritage captured in hand-carved medieval stone."
  },
  {
    url: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=1920",
    title: "Purple heather blooms across North York Moors",
    caption: "A wild, untamed sea of vibrant flora framing coastal cliffs."
  }
];

export default function Hero({ scrollToSection }: HeroProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % HERO_IMAGES.length);
    }, 7500); // Crossfade every 7.5 seconds
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="hero" className="relative w-full h-screen overflow-hidden bg-yorkshire-slate flex items-center">
      {/* Cinematic Background Slideshow */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence mode="popLayout">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.8, ease: "easeInOut" }}
            className="absolute inset-0 w-full h-full overflow-hidden"
          >
            {/* The slow continuous zoom effect is handled natively by index.css's ken-burns keyframe */}
            <img
              src={HERO_IMAGES[currentIndex].url}
              alt={HERO_IMAGES[currentIndex].title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover ken-burns brightness-65 dark:brightness-50"
            />
          </motion.div>
        </AnimatePresence>
        
        {/* Soft elegant gradient overlays for visual balance and maximum typography contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-yorkshire-stone dark:from-yorkshire-slate via-transparent to-black/35 z-10" />
      </div>

      {/* Main Hero Content Overlay */}
      <div className="relative z-20 max-w-7xl mx-auto px-6 md:px-12 w-full pt-16 flex flex-col justify-center h-full">
        <div className="max-w-3xl text-left">
          {/* Accent text badge */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 mb-6"
          >
            <span className="w-2 h-2 rounded-full bg-minster-gold animate-pulse" />
            <span className="text-xs font-semibold uppercase tracking-[0.25em] text-white">
              DISCOVER ENGLAND'S GREATEST COUNTY
            </span>
          </motion.div>

          {/* Majestic Hero Title */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 1 }}
            className="font-serif text-6xl md:text-8xl lg:text-[9rem] font-bold text-white tracking-tight leading-none mb-4"
          >
            Yorkshire
          </motion.h1>

          {/* Captivating Subheading */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.9 }}
            className="font-serif text-2xl md:text-4xl text-minster-gold italic font-semibold mb-6 tracking-wide"
          >
            England's Greatest Landscape
          </motion.h2>

          {/* Narrative Introduction */}
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.9 }}
            className="text-base md:text-lg text-white/90 leading-relaxed font-light mb-10 max-w-xl"
          >
            Experience wild heather-clad coastlines, medieval walled cities, rolling stone-walled dales, world-famous local food, and unforgettable outdoor adventures.
          </motion.p>

          {/* Action CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.9 }}
            className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-4 sm:space-y-0 sm:space-x-4"
          >
            <button
              onClick={() => scrollToSection("planner")}
              className="px-8 py-4 rounded-full bg-white text-yorkshire-slate hover:bg-minster-gold hover:text-white font-semibold tracking-wider uppercase text-xs transition-all duration-300 shadow-xl flex items-center justify-center space-x-2 cursor-pointer focus:outline-none"
            >
              <span>Plan Your Trip</span>
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => scrollToSection("destinations")}
              className="px-8 py-4 rounded-full border border-white/40 text-white hover:bg-white/10 font-semibold tracking-wider uppercase text-xs transition-all duration-300 flex items-center justify-center space-x-2 cursor-pointer focus:outline-none"
            >
              <span>Explore Yorkshire</span>
            </button>
          </motion.div>
        </div>
      </div>

      {/* Floating Status / Carousel Controls & Informative Labels */}
      <div className="absolute bottom-10 left-6 md:left-12 right-6 md:right-12 z-20 flex flex-col md:flex-row justify-between items-start md:items-end space-y-4 md:space-y-0 text-white">
        {/* Caption & Location info */}
        <div className="max-w-md hidden md:block">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ duration: 0.6 }}
              className="space-y-1"
            >
              <span className="text-xs uppercase font-bold tracking-widest text-minster-gold">
                Featured Location
              </span>
              <p className="font-serif font-bold text-sm text-white">
                {HERO_IMAGES[currentIndex].title}
              </p>
              <p className="text-xs text-white/70 font-light font-mono leading-tight">
                {HERO_IMAGES[currentIndex].caption}
              </p>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Dynamic Carousel Indicators */}
        <div className="flex items-center space-x-3 w-full md:w-auto justify-between md:justify-end">
          <div className="flex space-x-2">
            {HERO_IMAGES.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                aria-label={`Slide ${index + 1}`}
                className="group relative h-1.5 focus:outline-none cursor-pointer"
              >
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    currentIndex === index ? "w-12 bg-minster-gold" : "w-3 bg-white/40 hover:bg-white/70"
                  }`}
                />
              </button>
            ))}
          </div>

          {/* Elegant Mouse Scroll Indicator */}
          <button
            onClick={() => scrollToSection("destinations")}
            aria-label="Scroll down to destinations"
            className="flex items-center space-x-2 text-xs uppercase tracking-widest font-mono opacity-80 hover:opacity-100 transition-opacity focus:outline-none"
          >
            <span>Scroll</span>
            <motion.div
              animate={{ y: [0, 6, 0] }}
              transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
            >
              <ArrowDown className="w-4 h-4 text-minster-gold" />
            </motion.div>
          </button>
        </div>
      </div>
    </section>
  );
}
