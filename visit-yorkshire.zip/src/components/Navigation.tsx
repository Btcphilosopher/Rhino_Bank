import { useState, useEffect, FormEvent } from "react";
import { Search, Heart, Globe, Menu, X, Sun, Moon, MapPin, Calendar, HelpCircle, Utensils, BookOpen, Compass } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface NavigationProps {
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  activeSection: string;
  scrollToSection: (id: string) => void;
}

export default function Navigation({ darkMode, setDarkMode, activeSection, scrollToSection }: NavigationProps) {
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [languageOpen, setLanguageOpen] = useState(false);
  const [selectedLang, setSelectedLang] = useState("EN");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { label: "Destinations", id: "destinations", icon: Compass },
    { label: "Experiences", id: "experiences", icon: Heart },
    { label: "Interactive Map", id: "map", icon: MapPin },
    { label: "Food & Drink", id: "food", icon: Utensils },
    { label: "AI Trip Planner", id: "planner", icon: Calendar },
    { label: "Where to Stay", id: "stay", icon: MapPin },
    { label: "Wildlife & Heritage", id: "wildlife-heritage", icon: BookOpen },
    { label: "Articles", id: "blog", icon: BookOpen },
  ];

  const handleSearchSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Find element matching searchQuery or scroll to Destinations
      scrollToSection("destinations");
      setSearchOpen(false);
    }
  };

  return (
    <>
      <header
        id="site-header"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 border-b ${
          scrolled
            ? "bg-yorkshire-stone/95 dark:bg-yorkshire-slate/95 backdrop-blur-md py-4 shadow-sm border-yorkshire-slate/10 dark:border-white/10"
            : "bg-transparent py-6 border-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
          {/* Logo & Brand */}
          <button
            id="brand-logo"
            onClick={() => scrollToSection("hero")}
            className="flex items-center space-x-3 group cursor-pointer focus:outline-none"
          >
            <div className="w-10 h-10 rounded-full border-2 border-minster-gold flex items-center justify-center font-serif text-lg font-bold text-yorkshire-slate dark:text-yorkshire-stone bg-white/20 backdrop-blur-sm group-hover:bg-minster-gold group-hover:text-white transition-all duration-300">
              Y
            </div>
            <div className="text-left">
              <span className="block text-xs uppercase tracking-[0.3em] font-medium text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-none">
                Official Guide
              </span>
              <span className="font-serif text-xl font-semibold tracking-tight text-yorkshire-slate dark:text-yorkshire-stone">
                Visit <span className="text-minster-gold">Yorkshire</span>
              </span>
            </div>
          </button>

          {/* Desktop Navigation Menu */}
          <nav id="desktop-nav" className="hidden lg:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                id={`nav-link-${item.id}`}
                onClick={() => scrollToSection(item.id)}
                className={`text-sm font-medium tracking-wide transition-all duration-300 hover:text-minster-gold cursor-pointer relative py-1 focus:outline-none ${
                  activeSection === item.id
                    ? "text-minster-gold font-semibold"
                    : "text-yorkshire-slate/85 dark:text-yorkshire-stone/85"
                }`}
              >
                {item.label}
                {activeSection === item.id && (
                  <motion.div
                    layoutId="activeIndicator"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-minster-gold"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  />
                )}
              </button>
            ))}
          </nav>

          {/* Interactive Utilities */}
          <div id="nav-utilities" className="hidden md:flex items-center space-x-5">
            {/* Search Icon */}
            <button
              id="search-toggle-btn"
              onClick={() => setSearchOpen(true)}
              aria-label="Search website"
              className="p-2 rounded-full hover:bg-yorkshire-slate/5 dark:hover:bg-white/10 text-yorkshire-slate dark:text-yorkshire-stone transition-colors cursor-pointer focus:outline-none"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Language Dropdown */}
            <div className="relative">
              <button
                id="language-selector-btn"
                onClick={() => setLanguageOpen(!languageOpen)}
                aria-label="Change language"
                className="p-2 rounded-full hover:bg-yorkshire-slate/5 dark:hover:bg-white/10 text-yorkshire-slate dark:text-yorkshire-stone transition-colors cursor-pointer flex items-center space-x-1 focus:outline-none"
              >
                <Globe className="w-5 h-5" />
                <span className="text-xs font-semibold tracking-wider font-mono">{selectedLang}</span>
              </button>

              <AnimatePresence>
                {languageOpen && (
                  <motion.div
                    id="language-dropdown-menu"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute right-0 mt-2 w-36 bg-white dark:bg-yorkshire-slate shadow-xl rounded-lg border border-yorkshire-slate/10 dark:border-white/10 py-2 z-50 overflow-hidden"
                  >
                    {[
                      { code: "EN", name: "English" },
                      { code: "DE", name: "Deutsch" },
                      { code: "FR", name: "Français" },
                      { code: "ZH", name: "中文" },
                    ].map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => {
                          setSelectedLang(lang.code);
                          setLanguageOpen(false);
                        }}
                        className={`w-full text-left px-4 py-2 text-xs font-medium hover:bg-yorkshire-stone/30 dark:hover:bg-white/5 transition-colors cursor-pointer flex items-center justify-between ${
                          selectedLang === lang.code ? "text-minster-gold" : "text-yorkshire-slate dark:text-yorkshire-stone"
                        }`}
                      >
                        <span>{lang.name}</span>
                        <span className="text-[10px] opacity-60 font-mono">{lang.code}</span>
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Theme Toggle */}
            <button
              id="theme-toggle-btn"
              onClick={() => setDarkMode(!darkMode)}
              aria-label="Toggle visual theme"
              className="p-2 rounded-full hover:bg-yorkshire-slate/5 dark:hover:bg-white/10 text-yorkshire-slate dark:text-yorkshire-stone transition-colors cursor-pointer focus:outline-none"
            >
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            {/* Premium Callout Button */}
            <button
              id="nav-cta-planner"
              onClick={() => scrollToSection("planner")}
              className="px-5 py-2 rounded-full bg-yorkshire-slate dark:bg-yorkshire-stone text-yorkshire-stone dark:text-yorkshire-slate hover:bg-minster-gold dark:hover:bg-minster-gold hover:text-white dark:hover:text-white text-xs font-semibold uppercase tracking-wider transition-all duration-300 shadow-md cursor-pointer focus:outline-none"
            >
              AI Trip Planner
            </button>
          </div>

          {/* Mobile Menu Actions */}
          <div className="flex items-center space-x-3 lg:hidden">
            <button
              id="mobile-theme-toggle"
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 text-yorkshire-slate dark:text-yorkshire-stone focus:outline-none"
            >
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-yorkshire-slate dark:text-yorkshire-stone focus:outline-none"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Slide-out Mobile Menu Panel */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            id="mobile-menu-panel"
            initial={{ opacity: 0, x: "100%" }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: "100%" }}
            transition={{ type: "tween", duration: 0.35 }}
            className="fixed inset-0 z-40 bg-yorkshire-stone dark:bg-yorkshire-slate flex flex-col justify-between pt-28 pb-10 px-8"
          >
            <div className="space-y-6">
              <span className="block text-xs uppercase tracking-widest text-minster-gold font-bold">
                EXPLORE GOD'S OWN COUNTY
              </span>
              <nav className="space-y-4">
                {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      scrollToSection(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className="w-full text-left text-2xl font-serif font-semibold text-yorkshire-slate dark:text-yorkshire-stone hover:text-minster-gold transition-colors flex items-center space-x-4 py-1"
                  >
                    <item.icon className="w-6 h-6 text-minster-gold" />
                    <span>{item.label}</span>
                  </button>
                ))}
              </nav>
            </div>

            <div className="space-y-6">
              <div className="h-px bg-yorkshire-slate/10 dark:bg-white/10" />
              <div className="flex items-center justify-between">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setSearchOpen(true);
                  }}
                  className="flex items-center space-x-2 text-sm text-yorkshire-slate/70 dark:text-yorkshire-stone/70"
                >
                  <Search className="w-4 h-4" />
                  <span>Search Guide</span>
                </button>
                <div className="flex space-x-3 text-sm font-mono font-bold text-minster-gold">
                  {["EN", "DE", "FR"].map((code) => (
                    <button
                      key={code}
                      onClick={() => setSelectedLang(code)}
                      className={selectedLang === code ? "underline" : "opacity-50"}
                    >
                      {code}
                    </button>
                  ))}
                </div>
              </div>
              <button
                onClick={() => {
                  scrollToSection("planner");
                  setMobileMenuOpen(false);
                }}
                className="w-full py-3 rounded-full bg-yorkshire-slate dark:bg-yorkshire-stone text-yorkshire-stone dark:text-yorkshire-slate text-center font-semibold uppercase text-xs tracking-wider"
              >
                Build AI Itinerary
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Global Interactive Search Overlay Modal */}
      <AnimatePresence>
        {searchOpen && (
          <motion.div
            id="search-modal-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-yorkshire-slate/75 dark:bg-black/85 backdrop-blur-md flex items-center justify-center p-6"
          >
            <motion.div
              id="search-modal-content"
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-yorkshire-stone dark:bg-yorkshire-slate max-w-2xl w-full rounded-2xl p-8 shadow-2xl relative border border-white/10"
            >
              <button
                id="search-close-btn"
                onClick={() => setSearchOpen(false)}
                className="absolute top-6 right-6 p-2 rounded-full hover:bg-yorkshire-slate/5 dark:hover:bg-white/15 text-yorkshire-slate/70 dark:text-yorkshire-stone/70 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="font-serif text-2xl font-bold mb-2 text-yorkshire-slate dark:text-yorkshire-stone">
                Search Yorkshire Guide
              </h3>
              <p className="text-sm text-yorkshire-slate/60 dark:text-yorkshire-stone/60 mb-6">
                Discover valleys, coastal paths, Michelin dining, castles, and scenic railways.
              </p>

              <form onSubmit={handleSearchSubmit} className="relative">
                <input
                  id="search-input-field"
                  type="text"
                  placeholder="e.g., Whitby Abbey, Dales walking, farm shops..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-white dark:bg-white/5 border border-yorkshire-slate/20 dark:border-white/10 rounded-xl py-4 pl-12 pr-28 text-yorkshire-slate dark:text-yorkshire-stone placeholder-yorkshire-slate/40 focus:border-minster-gold focus:ring-1 focus:ring-minster-gold font-medium"
                  autoFocus
                />
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-yorkshire-slate/40 dark:text-yorkshire-stone/40" />
                <button
                  type="submit"
                  className="absolute right-2 top-1/2 -translate-y-1/2 px-4 py-2 rounded-lg bg-minster-gold hover:bg-minster-gold/90 text-white text-xs font-semibold uppercase tracking-wider transition-colors"
                >
                  Explore
                </button>
              </form>

              <div className="mt-8">
                <span className="block text-xs uppercase tracking-wider text-yorkshire-slate/50 dark:text-yorkshire-stone/50 font-bold mb-3">
                  Suggested Searches
                </span>
                <div className="flex flex-wrap gap-2">
                  {["Malham Cove", "Betty's Afternoon Tea", "Viking Heritage", "Three Peaks", "Steam Railway"].map(
                    (tag) => (
                      <button
                        key={tag}
                        onClick={() => {
                          setSearchQuery(tag);
                          scrollToSection("destinations");
                          setSearchOpen(false);
                        }}
                        className="px-3.5 py-1.5 rounded-full bg-yorkshire-slate/5 dark:bg-white/5 hover:bg-minster-gold hover:text-white dark:hover:bg-minster-gold text-xs font-medium text-yorkshire-slate dark:text-yorkshire-stone transition-all cursor-pointer"
                      >
                        {tag}
                      </button>
                    )
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
