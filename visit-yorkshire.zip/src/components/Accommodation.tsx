import { useState, FormEvent } from "react";
import { Bed, Star, MapPin, Check, Sparkles, X, Heart, Shield } from "lucide-react";
import { ACCOMMODATION, Accommodation as AccType } from "../types";
import { motion, AnimatePresence } from "motion/react";

export default function Accommodation() {
  const [selectedStyle, setSelectedStyle] = useState<string>("all");
  const [inquiryStay, setInquiryStay] = useState<AccType | null>(null);
  const [submittedInquiry, setSubmittedInquiry] = useState<boolean>(false);
  const [guestEmail, setGuestEmail] = useState<string>("");

  const styles = [
    { id: "all", label: "All Stays" },
    { id: "luxury", label: "Luxury Manors" },
    { id: "cottage", label: "Stone Cottages" },
    { id: "inn", label: "Historic Inns" }
  ];

  const filtered = selectedStyle === "all"
    ? ACCOMMODATION
    : ACCOMMODATION.filter((acc) => acc.type === selectedStyle);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!guestEmail.trim()) return;
    setSubmittedInquiry(true);
  };

  const handleClose = () => {
    setInquiryStay(null);
    setSubmittedInquiry(false);
    setGuestEmail("");
  };

  return (
    <section id="stay" className="py-24 md:py-32 bg-yorkshire-stone dark:bg-yorkshire-slate border-t border-yorkshire-slate/10 dark:border-white/10">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Title Block */}
        <div className="mb-16 text-left max-w-3xl">
          <span className="text-xs uppercase font-bold tracking-[0.25em] text-minster-gold block mb-3">
            REFINED SANCTUARIES
          </span>
          <h2 className="font-serif text-4xl md:text-6xl font-bold tracking-tight text-yorkshire-slate dark:text-white leading-tight mb-6">
            Bespoke Yorkshire Lodgings
          </h2>
          <p className="text-base md:text-lg text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
            Whether you seek the five-star opulence of a Palladian manor house, a snug fireplace in a stone-built cottage, or a historic coaching inn on a windswept coast.
          </p>
        </div>

        {/* Stay Filters */}
        <div className="flex flex-wrap items-center gap-2 mb-12 overflow-x-auto pb-4 hide-scrollbar">
          {styles.map((style) => (
            <button
              key={style.id}
              onClick={() => setSelectedStyle(style.id)}
              className={`px-5 py-2.5 rounded-full text-xs font-semibold uppercase tracking-wider transition-all duration-300 relative cursor-pointer focus:outline-none ${
                selectedStyle === style.id
                  ? "text-white bg-yorkshire-slate dark:bg-yorkshire-stone dark:text-yorkshire-slate shadow-md"
                  : "text-yorkshire-slate/60 dark:text-yorkshire-stone/60 hover:text-yorkshire-slate dark:hover:text-white hover:bg-yorkshire-slate/5 dark:hover:bg-white/5"
              }`}
            >
              <span>{style.label}</span>
            </button>
          ))}
        </div>

        {/* Accommodation Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence mode="popLayout">
            {filtered.map((stay) => (
              <motion.div
                layout
                key={stay.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.45 }}
                className="group flex flex-col justify-between bg-white/45 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl hover:border-minster-gold/25 transition-all duration-500"
              >
                {/* Photo & Pricing Overlay */}
                <div className="relative aspect-4/3 overflow-hidden bg-yorkshire-slate/10">
                  <img
                    src={stay.image}
                    alt={stay.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                  />
                  {/* Styling Pill badge */}
                  <span className="absolute bottom-4 left-4 px-3 py-1 bg-white/95 dark:bg-yorkshire-slate/95 text-minster-gold border border-yorkshire-slate/5 text-[10px] font-extrabold uppercase tracking-widest rounded-md">
                    {stay.type}
                  </span>
                  
                  {/* Price overlay */}
                  <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-sm border border-white/20 px-3 py-1 rounded-full text-white text-xs font-semibold font-mono">
                    {stay.price} <span className="opacity-60 font-sans font-light">/ night</span>
                  </div>
                </div>

                {/* Card description details */}
                <div className="p-6 md:p-8 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-minster-gold flex items-center">
                        <MapPin className="w-3.5 h-3.5 mr-1 text-minster-gold" />
                        {stay.location}
                      </span>
                      <div className="flex items-center space-x-1">
                        <Star className="w-3.5 h-3.5 text-minster-gold fill-current" />
                        <span className="text-xs font-bold text-yorkshire-slate dark:text-white">{stay.rating}</span>
                      </div>
                    </div>

                    <h3 className="font-serif text-2xl font-bold text-yorkshire-slate dark:text-white tracking-tight mb-3">
                      {stay.name}
                    </h3>

                    <p className="text-xs md:text-sm text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light mb-6 line-clamp-3">
                      {stay.description}
                    </p>
                  </div>

                  <div className="space-y-4 mt-auto">
                    {/* Amenities list */}
                    <div className="flex flex-wrap gap-2">
                      {stay.features.map((amenity, index) => (
                        <span
                          key={index}
                          className="px-2.5 py-1 bg-yorkshire-stone/50 dark:bg-white/5 border border-yorkshire-slate/5 dark:border-white/5 rounded text-[10px] text-yorkshire-slate/70 dark:text-yorkshire-stone/70"
                        >
                          {amenity}
                        </span>
                      ))}
                    </div>

                    {/* Book / Enquiry Action */}
                    <button
                      onClick={() => setInquiryStay(stay)}
                      className="w-full py-3 border border-yorkshire-slate/20 dark:border-white/10 hover:border-minster-gold hover:text-white hover:bg-minster-gold text-yorkshire-slate dark:text-yorkshire-stone text-xs font-bold uppercase tracking-wider text-center rounded-lg transition-all cursor-pointer"
                    >
                      Inquire Availability
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Inquiry Modal */}
        <AnimatePresence>
          {inquiryStay && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-yorkshire-slate/75 dark:bg-black/85 backdrop-blur-sm flex items-center justify-center p-6"
              onClick={handleClose}
            >
              <motion.div
                initial={{ scale: 0.95, y: 15 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 15 }}
                className="bg-yorkshire-stone dark:bg-yorkshire-slate rounded-2xl overflow-hidden shadow-2xl max-w-md w-full border border-yorkshire-slate/10 dark:border-white/15 p-8 relative"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button */}
                <button
                  onClick={handleClose}
                  className="absolute top-6 right-6 p-2 rounded-full hover:bg-yorkshire-slate/5 dark:hover:bg-white/10 text-yorkshire-slate/70 dark:text-yorkshire-stone/70 z-10 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>

                {!submittedInquiry ? (
                  /* Form Inquiry */
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-minster-gold">
                      <Bed className="w-4 h-4 animate-pulse" />
                      <span>SANCTUARY INQUIRY</span>
                    </div>

                    <div>
                      <span className="text-[9px] uppercase font-bold text-minster-gold font-mono">SELECTED HAVEN</span>
                      <h3 className="font-serif text-2xl font-bold text-yorkshire-slate dark:text-white leading-tight mt-1">
                        {inquiryStay.name}
                      </h3>
                      <p className="text-xs text-yorkshire-slate/60 dark:text-yorkshire-stone/60 flex items-center mt-2">
                        <MapPin className="w-3.5 h-3.5 mr-1 text-minster-gold" />
                        {inquiryStay.location} · {inquiryStay.price}
                      </p>
                    </div>

                    <div className="h-px bg-yorkshire-slate/10 dark:bg-white/10" />

                    <div>
                      <label className="block text-xs uppercase font-extrabold tracking-widest text-yorkshire-slate/50 dark:text-yorkshire-stone/50 mb-2">
                        Your Email Address
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="e.g., james.herriot@gmail.com"
                        value={guestEmail}
                        onChange={(e) => setGuestEmail(e.target.value)}
                        className="w-full bg-white dark:bg-white/5 border border-yorkshire-slate/20 dark:border-white/10 rounded-xl px-4 py-3 text-xs text-yorkshire-slate dark:text-white"
                      />
                    </div>

                    <div className="bg-white/50 dark:bg-black/20 p-4 rounded-xl border border-yorkshire-slate/5 dark:border-white/5">
                      <span className="text-[10px] uppercase font-bold text-minster-gold mb-2 block flex items-center">
                        <Star className="w-3.5 h-3.5 mr-1.5 text-minster-gold fill-current" />
                        Concierge Guarantee
                      </span>
                      <p className="text-[11px] text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
                        Our direct links bypass online booking sites, locking in native rates, complimentary cream teas, and direct estate contact.
                      </p>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-4 rounded-xl bg-minster-gold hover:bg-minster-gold/90 text-white text-xs font-bold uppercase tracking-widest shadow-md cursor-pointer"
                    >
                      Inquire Concierge Rate
                    </button>
                  </form>
                ) : (
                  /* Success Screen */
                  <div className="space-y-6 text-center py-4">
                    <div className="w-12 h-12 rounded-full bg-moorland-green/15 text-moorland-green flex items-center justify-center mx-auto mb-4 border border-moorland-green/20">
                      <Check className="w-6 h-6" />
                    </div>

                    <div>
                      <span className="text-[10px] uppercase font-bold text-moorland-green tracking-widest block mb-1">INQUIRY FORWARDED</span>
                      <h3 className="font-serif text-2xl font-bold text-yorkshire-slate dark:text-white leading-tight">
                        Concierge Connected
                      </h3>
                      <p className="text-xs text-yorkshire-slate/60 dark:text-yorkshire-stone/60 mt-2 max-w-sm mx-auto">
                        We have dispatched your request directly to the house staff at <strong>{inquiryStay.name}</strong>. A boutique travel specialist will connect with you via {guestEmail} within 2 hours.
                      </p>
                    </div>

                    <button
                      onClick={handleClose}
                      className="w-full py-3 bg-yorkshire-slate dark:bg-yorkshire-stone text-yorkshire-stone dark:text-yorkshire-slate text-xs font-bold uppercase tracking-wider rounded-lg transition-colors cursor-pointer"
                    >
                      Return to Lodgings
                    </button>
                  </div>
                )}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
