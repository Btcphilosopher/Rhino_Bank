import { useState, useEffect } from "react";
import { Train, ShieldAlert, Navigation, Zap, MapPin, Compass, Sparkles, RefreshCw, AlertCircle, CheckCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ServiceStatus {
  service: string;
  category: "rail" | "road" | "shuttle";
  status: "smooth" | "minor-delay" | "closed";
  message: string;
  updated: string;
}

const INITIAL_SERVICES: ServiceStatus[] = [
  {
    service: "LNER East Coast Mainline",
    category: "rail",
    status: "smooth",
    message: "London Kings Cross to York / Leeds running on time.",
    updated: "Just now"
  },
  {
    service: "TransPennine Express",
    category: "rail",
    status: "minor-delay",
    message: "10-minute residual signaling delays near Leeds station.",
    updated: "4 mins ago"
  },
  {
    service: "Settle-Carlisle Scenic Rail",
    category: "rail",
    status: "smooth",
    message: "All historic steam and diesel diesel excursions fully operational.",
    updated: "10 mins ago"
  },
  {
    service: "Buttertubs Mountain Pass (Hawes)",
    category: "road",
    status: "smooth",
    message: "Clear skies and fully open. Outstanding visibility across the fells.",
    updated: "Just now"
  },
  {
    service: "Robin Hood's Bay Coastal Route",
    category: "road",
    status: "smooth",
    message: "Seaside roadways clear. High-tide warnings complete.",
    updated: "20 mins ago"
  }
];

export default function Travel() {
  const [services, setServices] = useState<ServiceStatus[]>(INITIAL_SERVICES);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>("rail");

  const evChargers = [
    { name: "York Central Supercharger", spots: "8 Plugs", speed: "150kW Ultra-Fast", location: "Peasholme Green, York" },
    { name: "Harrogate Spa EV Charging", spots: "4 Plugs", speed: "50kW Fast", location: "Royal Baths, Harrogate" },
    { name: "Settle Market Square", spots: "2 Plugs", speed: "22kW Medium", location: "Town Centre, Settle Dales" },
    { name: "Whitby Harbour Car Park", spots: "4 Plugs", speed: "50kW Fast", location: "Marina Drive, Whitby Coast" },
    { name: "Leeds Victoria Quarter Gate", spots: "12 Plugs", speed: "250kW Ultra-Fast", location: "Victoria Gate, Leeds" }
  ];

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      // Simulate slight update changes for realistic interactive feel
      setServices((prev) =>
        prev.map((s, idx) => {
          if (idx === 1) {
            return {
              ...s,
              status: Math.random() > 0.5 ? "smooth" : "minor-delay",
              message: "Delays cleared. Services returning to regular timetables."
            };
          }
          return s;
        })
      );
      setIsRefreshing(false);
    }, 1200);
  };

  return (
    <section id="travel" className="py-24 md:py-32 bg-yorkshire-stone dark:bg-yorkshire-slate">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Title Section */}
        <div className="mb-16 text-left max-w-3xl">
          <span className="text-xs uppercase font-bold tracking-[0.25em] text-minster-gold block mb-3">
            LIVE TRANSIT INDEX
          </span>
          <h2 className="font-serif text-4xl md:text-6xl font-bold tracking-tight text-yorkshire-slate dark:text-white leading-tight mb-6">
            Transit & Travel Hub
          </h2>
          <p className="text-base md:text-lg text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
            Plan your physical route effortlessly. Monitor real-time trains, locate regional high-speed EV charging grids, and check remote national park mountain pass road conditions.
          </p>
        </div>

        {/* Layout Grid: Left Details, Right Status Monitor */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          
          {/* Left Columns: Rail Guide & EV Charger List (Span 7) */}
          <div className="lg:col-span-7 bg-white/40 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 p-8 rounded-3xl flex flex-col justify-between">
            <div>
              {/* Category selector */}
              <div className="flex border-b border-yorkshire-slate/10 dark:border-white/10 pb-4 mb-8">
                {[
                  { id: "rail", label: "Rail Routes" },
                  { id: "ev", label: "EV Charger Directory" },
                  { id: "scenic", label: "Scenic Road Drives" }
                ].map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setActiveTab(t.id)}
                    className={`pb-4 px-4 text-xs font-bold uppercase tracking-wider transition-all relative -mb-[17px] cursor-pointer focus:outline-none ${
                      activeTab === t.id
                        ? "text-minster-gold border-b-2 border-minster-gold"
                        : "text-yorkshire-slate/50 dark:text-yorkshire-stone/50 hover:text-yorkshire-slate"
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              <AnimatePresence mode="wait">
                {activeTab === "rail" && (
                  <motion.div
                    key="rail"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="space-y-6"
                  >
                    <div className="space-y-4">
                      <div className="flex items-start space-x-4">
                        <div className="p-3 bg-minster-gold/10 rounded-xl text-minster-gold">
                          <Train className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="text-base font-bold text-yorkshire-slate dark:text-white mb-1">
                            LNER Rail Links
                          </h4>
                          <p className="text-xs text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
                            Depart from London Kings Cross and arrive in historic York in just <strong>1 hour and 50 minutes</strong>, or central Leeds in <strong>2 hours and 10 minutes</strong>. Fast, carbon-efficient hourly connections operate daily.
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start space-x-4">
                        <div className="p-3 bg-minster-gold/10 rounded-xl text-minster-gold">
                          <Compass className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="text-base font-bold text-yorkshire-slate dark:text-white mb-1">
                            Settle-Carlisle Scenic Railroad
                          </h4>
                          <p className="text-xs text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
                            Acclaimed as one of the world's most spectacular scenic train journeys. Glide over the iconic 24-arch Ribblehead Viaduct and sweep through pristine national park valleys.
                          </p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === "ev" && (
                  <motion.div
                    key="ev"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="space-y-4"
                  >
                    <p className="text-xs text-yorkshire-slate/60 dark:text-yorkshire-stone/60 mb-2 font-light">
                      Yorkshire boasts robust EV infrastructure. Keep your journey green with ultra-fast charging stops situated near major highway entries and key market towns.
                    </p>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {evChargers.map((chg, idx) => (
                        <div
                          key={idx}
                          className="p-3 bg-yorkshire-stone/50 dark:bg-black/10 border border-yorkshire-slate/5 rounded-xl flex items-start space-x-3 text-xs"
                        >
                          <Zap className="w-4 h-4 text-minster-gold mt-0.5 flex-shrink-0" />
                          <div>
                            <h5 className="font-bold text-yorkshire-slate dark:text-white">{chg.name}</h5>
                            <p className="text-[10px] text-yorkshire-slate/50 dark:text-yorkshire-stone/50 mt-0.5">{chg.spots} · {chg.speed}</p>
                            <p className="text-[10px] text-minster-gold font-medium mt-1">{chg.location}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}

                {activeTab === "scenic" && (
                  <motion.div
                    key="scenic"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="space-y-6"
                  >
                    <div className="space-y-4">
                      <div className="p-4 bg-yorkshire-stone/40 dark:bg-black/10 rounded-xl border border-dashed border-yorkshire-slate/10 dark:border-white/5">
                        <span className="text-[9px] font-bold text-minster-gold uppercase tracking-widest block mb-1">Epic Pass Drive</span>
                        <h4 className="text-sm font-bold text-yorkshire-slate dark:text-white mb-1">Buttertubs Pass (Hawes to Thwaite)</h4>
                        <p className="text-xs text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
                          Described by Jeremy Clarkson as "England's only truly spectacular road". This high, rolling 5.5-mile ribbon path snakes past limestone cliffs and open fells. Drive with care.
                        </p>
                      </div>

                      <div className="p-4 bg-yorkshire-stone/40 dark:bg-black/10 rounded-xl border border-dashed border-yorkshire-slate/10 dark:border-white/5">
                        <span className="text-[9px] font-bold text-minster-gold uppercase tracking-widest block mb-1">Coastal Ocean Highway</span>
                        <h4 className="text-sm font-bold text-yorkshire-slate dark:text-white mb-1">Whitby to Scarborough Coastal Trail</h4>
                        <p className="text-xs text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
                          Hike or drive parallel to fossil-rich seaside cliffs, descending into sheltered red-roofed coves like Robin Hood's Bay and Ravenscar.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="pt-8 border-t border-yorkshire-slate/10 dark:border-white/10 mt-8 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-xs">
              <div className="flex items-center text-yorkshire-slate/60 dark:text-yorkshire-stone/60">
                <CheckCircle2 className="w-4 h-4 mr-2 text-moorland-green" />
                <span>All routes verified against National Park closures</span>
              </div>
            </div>
          </div>

          {/* Right Column: Live Transport Feed (Span 5) */}
          <div className="lg:col-span-5 bg-white/40 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 p-8 rounded-3xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-minster-gold">
                  <AlertCircle className="w-4 h-4 animate-pulse" />
                  <span>LIVE ROAD & RAIL SERVICE FEED</span>
                </div>
                
                {/* Refresh action */}
                <button
                  onClick={handleRefresh}
                  disabled={isRefreshing}
                  className="p-1.5 rounded bg-yorkshire-stone/50 dark:bg-white/10 hover:text-minster-gold text-yorkshire-slate dark:text-white cursor-pointer disabled:opacity-35 transition-colors"
                  title="Check Live Updates"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin" : ""}`} />
                </button>
              </div>

              {/* Simulated Service feeds */}
              <div className="space-y-4">
                {services.map((srv, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-white/60 dark:bg-black/10 border border-yorkshire-slate/5 rounded-xl flex items-start justify-between"
                  >
                    <div className="space-y-1">
                      <h5 className="text-xs font-bold text-yorkshire-slate dark:text-white leading-tight">
                        {srv.service}
                      </h5>
                      <p className="text-[11px] text-yorkshire-slate/70 dark:text-yorkshire-stone/70 leading-relaxed font-light font-sans">
                        {srv.message}
                      </p>
                      <span className="text-[9px] text-yorkshire-slate/40 dark:text-yorkshire-stone/40 font-mono block">
                        Updated {srv.updated}
                      </span>
                    </div>

                    {/* Status Pill Badge */}
                    <span
                      className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-widest ${
                        srv.status === "smooth"
                          ? "bg-moorland-green/10 text-moorland-green border border-moorland-green/20"
                          : srv.status === "minor-delay"
                          ? "bg-minster-gold/10 text-minster-gold border border-minster-gold/20"
                          : "bg-red-500/10 text-red-500 border border-red-500/20"
                      }`}
                    >
                      {srv.status === "smooth" ? "On Time" : srv.status === "minor-delay" ? "Delay" : "Closed"}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-yorkshire-stone/50 dark:bg-black/20 p-4 rounded-xl border border-yorkshire-slate/5 dark:border-white/5 mt-8">
              <p className="text-[11px] text-yorkshire-slate/60 dark:text-yorkshire-stone/60 leading-relaxed font-light">
                * Timetable schedules are simulated. For final LNER train ticket configurations, refer to central rail operator desks.
              </p>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
