import { useState } from "react";
import { BookOpen, User, Clock, ArrowRight, X, Sparkles, Heart, Share2 } from "lucide-react";
import { ARTICLES, BlogArticle } from "../types";
import { motion, AnimatePresence } from "motion/react";

export default function Blog() {
  const [activeArticle, setActiveArticle] = useState<BlogArticle | null>(null);

  return (
    <section id="blog" className="py-24 md:py-32 bg-yorkshire-stone dark:bg-yorkshire-slate">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Title block */}
        <div className="mb-16 md:mb-20 text-left max-w-3xl">
          <span className="text-xs uppercase font-bold tracking-[0.25em] text-minster-gold block mb-3">
            EDITORIAL JOURNAL
          </span>
          <h2 className="font-serif text-4xl md:text-6xl font-bold tracking-tight text-yorkshire-slate dark:text-white leading-tight mb-6">
            The Yorkshire Gazette
          </h2>
          <p className="text-base md:text-lg text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
            Immerse yourself in deeply researched, beautifully illustrated chronicles on local heritage, fell-walking secrets, coastal fossil hunting, and gourmet culinary developments.
          </p>
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {ARTICLES.map((article, idx) => (
            <motion.article
              key={article.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              onClick={() => setActiveArticle(article)}
              className="group cursor-pointer flex flex-col justify-between bg-white/40 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 rounded-2xl overflow-hidden hover:shadow-xl hover:bg-white dark:hover:bg-white/10 hover:border-minster-gold/25 transition-all duration-500"
            >
              {/* Photo Frame */}
              <div className="relative aspect-16/10 overflow-hidden bg-yorkshire-slate/15">
                <img
                  src={article.image}
                  alt={article.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                />
                <span className="absolute bottom-4 left-4 px-3 py-1 bg-white/95 dark:bg-yorkshire-slate/95 text-minster-gold border border-yorkshire-slate/5 text-[10px] font-extrabold uppercase tracking-widest rounded-md">
                  {article.category}
                </span>
              </div>

              {/* Text content details */}
              <div className="p-6 md:p-8 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center space-x-4 text-[10px] font-mono text-yorkshire-slate/40 dark:text-yorkshire-stone/40 mb-3 font-bold uppercase">
                    <span className="flex items-center">
                      <User className="w-3 h-3 mr-1 text-minster-gold" />
                      {article.author}
                    </span>
                    <span className="flex items-center">
                      <Clock className="w-3 h-3 mr-1 text-minster-gold" />
                      {article.readingTime}
                    </span>
                  </div>

                  <h3 className="font-serif text-2xl font-bold text-yorkshire-slate dark:text-white leading-tight mb-3 group-hover:text-minster-gold transition-colors duration-300">
                    {article.title}
                  </h3>

                  <p className="text-xs md:text-sm text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light mb-6 line-clamp-3">
                    {article.snippet}
                  </p>
                </div>

                <div className="border-t border-yorkshire-slate/10 dark:border-white/10 pt-5 flex items-center justify-between text-xs font-semibold text-minster-gold uppercase tracking-wider group-hover:text-yorkshire-slate dark:group-hover:text-white transition-colors">
                  <span>Read Article</span>
                  <div className="p-1.5 rounded-full bg-yorkshire-stone/80 dark:bg-black/20 group-hover:bg-minster-gold group-hover:text-white transition-colors">
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            </motion.article>
          ))}
        </div>

        {/* Full Screen Immersive Editorial Reader Modal */}
        <AnimatePresence>
          {activeArticle && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-yorkshire-slate/85 dark:bg-black/95 backdrop-blur-md flex items-center justify-center p-6"
              onClick={() => setActiveArticle(null)}
            >
              <motion.div
                initial={{ scale: 0.95, y: 15 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 15 }}
                className="bg-yorkshire-stone dark:bg-yorkshire-slate rounded-2xl overflow-y-auto shadow-2xl max-w-3xl w-full max-h-[85vh] border border-yorkshire-slate/10 dark:border-white/15 p-8 md:p-12 relative"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button */}
                <button
                  onClick={() => setActiveArticle(null)}
                  className="absolute top-6 right-6 p-2 rounded-full hover:bg-yorkshire-slate/5 dark:hover:bg-white/10 text-yorkshire-slate/70 dark:text-yorkshire-stone/70 z-10 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>

                <article className="space-y-6 font-sans">
                  {/* Article Metadata */}
                  <div className="space-y-3">
                    <span className="px-3 py-1 bg-minster-gold/15 text-minster-gold border border-minster-gold/20 text-[10px] font-extrabold uppercase tracking-widest rounded-md inline-block">
                      {activeArticle.category}
                    </span>
                    <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl font-bold text-yorkshire-slate dark:text-white leading-tight">
                      {activeArticle.title}
                    </h2>
                    
                    <div className="flex items-center space-x-6 text-xs text-yorkshire-slate/50 dark:text-yorkshire-stone/50 font-mono font-bold uppercase pt-1">
                      <span className="flex items-center">
                        <User className="w-3.5 h-3.5 mr-1.5 text-minster-gold" />
                        By {activeArticle.author}
                      </span>
                      <span>Published 2026</span>
                      <span className="flex items-center">
                        <Clock className="w-3.5 h-3.5 mr-1.5 text-minster-gold" />
                        {activeArticle.readingTime}
                      </span>
                    </div>
                  </div>

                  <div className="h-px bg-yorkshire-slate/10 dark:bg-white/10" />

                  {/* Photo Frame */}
                  <div className="relative aspect-16/9 rounded-xl overflow-hidden bg-yorkshire-slate/10">
                    <img
                      src={activeArticle.image}
                      alt={activeArticle.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Immersive Editorial Text with Dropcap */}
                  <div className="prose prose-stone dark:prose-invert max-w-none text-yorkshire-slate/85 dark:text-yorkshire-stone/85 text-sm md:text-base leading-relaxed font-light space-y-6">
                    <p className="first-line:uppercase first-line:tracking-widest first-letter:text-6xl first-letter:font-serif first-letter:font-bold first-letter:text-minster-gold first-letter:float-left first-letter:mr-3 first-letter:line-height-none">
                      {activeArticle.snippet}
                    </p>
                    
                    <p>
                      Across the rolling hills of Yorkshire, stories weave through drystone pastures, limestone cliffs, and misty moorlands. This landscape is not merely observed; it is absorbed. Writers, chefs, and fell rangers alike find inspiration under our deep north skies, carving a rich heritage of craft, gastronomy, and literature.
                    </p>
                    
                    <p>
                      To truly know God’s Own County is to traverse it slowly. Take the winding pass over Buttertubs, sit beside the roaring hearth of a 300-year-old stone coaching inn, or wander beneath the Gothic gargoyles of York Minster. What you discover is a timeless, authentic region with an iron-clad community spirit and a boundless landscape that stays with you forever.
                    </p>
                  </div>

                  {/* Footer article elements */}
                  <div className="pt-8 border-t border-yorkshire-slate/10 dark:border-white/10 flex items-center justify-between text-xs font-mono text-yorkshire-slate/40 dark:text-yorkshire-stone/40">
                    <span className="flex items-center">
                      <Heart className="w-4 h-4 mr-1.5 text-red-500 fill-current" />
                      Add to saved journal
                    </span>
                    <span className="flex items-center cursor-pointer hover:text-minster-gold transition-colors">
                      <Share2 className="w-4 h-4 mr-1.5" />
                      Share Article
                    </span>
                  </div>

                </article>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
