import { useState, useEffect, FormEvent } from "react";
import { Sparkles, Compass, Calendar, Gift, AlertCircle, MapPin, Coffee, Bed, ArrowRight, Printer, Star, Heart, CheckCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface Activity {
  time: string;
  title: string;
  description: string;
  location: string;
  tip?: string;
}

interface ItineraryDay {
  dayNumber: number;
  theme: string;
  activities: Activity[];
  accommodationRecommendation?: string;
  diningRecommendation?: string;
}

interface ItineraryResponse {
  title: string;
  summary: string;
  days: ItineraryDay[];
}

const REASSURING_MESSAGES = [
  "Mapping topography of the Settle-Carlisle line...",
  "Consulting local fell and national park rangers...",
  "Gathering Michelin-starred farm restaurant openings...",
  "Sourcing coastal trails and smuggler cave tides...",
  "Aligning local boutique inn and manor availabilities...",
  "Curating medieval gothic routes through York Minster..."
];

export default function TripPlanner() {
  const [days, setDays] = useState<number>(3);
  const [budget, setBudget] = useState<string>("standard");
  const [travelers, setTravelers] = useState<string>("couple");
  const [selectedInterests, setSelectedInterests] = useState<string[]>(["Walking", "History"]);
  
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingMessageIdx, setLoadingMessageIdx] = useState<number>(0);
  const [itinerary, setItinerary] = useState<ItineraryResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const interestOptions = [
    "Walking", "History", "Rail travel", "Food", "Cycling", "Wellness", "Wildlife", "Adventure", "Luxury", "Coast"
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (loading) {
      interval = setInterval(() => {
        setLoadingMessageIdx((prev) => (prev + 1) % REASSURING_MESSAGES.length);
      }, 2500);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const toggleInterest = (interest: string) => {
    setSelectedInterests((prev) =>
      prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]
    );
  };

  const handleBuildItinerary = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setItinerary(null);
    setLoadingMessageIdx(0);

    try {
      const response = await fetch("/api/plan-itinerary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          days,
          budget,
          travelers,
          interests: selectedInterests
        })
      });

      const data = await response.json();
      if (data.itinerary) {
        setItinerary(data.itinerary);
      } else {
        throw new Error("Unable to read plan schema from the server.");
      }
    } catch (err) {
      console.error("AI Planner fetch failed:", err);
      setError("We encountered an issue connecting to the travel compiler. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="planner" className="py-24 md:py-32 bg-yorkshire-stone dark:bg-yorkshire-slate border-t border-yorkshire-slate/10 dark:border-white/10">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Header Block */}
        <div className="mb-16 text-left max-w-3xl">
          <span className="text-xs uppercase font-bold tracking-[0.25em] text-minster-gold block mb-3">
            INTELLIGENT COMPILER
          </span>
          <h2 className="font-serif text-4xl md:text-6xl font-bold tracking-tight text-yorkshire-slate dark:text-white leading-tight mb-6">
            AI Itinerary Builder
          </h2>
          <p className="text-base md:text-lg text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
            Compose a completely customized multi-day travel planner with the help of artificial intelligence. Specify your duration, interests, and group profile, and get an immediate, hand-crafted itinerary.
          </p>
        </div>

        {/* Form and Output Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Form Side (Span 5) */}
          <div className="lg:col-span-5 bg-white/40 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 p-8 rounded-3xl shadow-sm">
            <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-minster-gold mb-6">
              <Sparkles className="w-4 h-4" />
              <span>Itinerary Parameters</span>
            </div>

            <form onSubmit={handleBuildItinerary} className="space-y-6">
              {/* Days Select */}
              <div>
                <label className="block text-xs uppercase font-extrabold tracking-widest text-yorkshire-slate/50 dark:text-yorkshire-stone/50 mb-3">
                  Duration of Stay
                </label>
                <div className="grid grid-cols-5 gap-2">
                  {[1, 2, 3, 4, 5].map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setDays(d)}
                      className={`py-3 rounded-xl text-xs font-bold font-mono transition-all border ${
                        days === d
                          ? "bg-yorkshire-slate dark:bg-yorkshire-stone text-yorkshire-stone dark:text-yorkshire-slate border-yorkshire-slate dark:border-yorkshire-stone"
                          : "bg-white dark:bg-white/5 border-yorkshire-slate/15 dark:border-white/10 text-yorkshire-slate/60 dark:text-yorkshire-stone/60 hover:border-minster-gold"
                      }`}
                    >
                      {d} {d === 1 ? "Day" : "Days"}
                    </button>
                  ))}
                </div>
              </div>

              {/* Budget Profile */}
              <div>
                <label className="block text-xs uppercase font-extrabold tracking-widest text-yorkshire-slate/50 dark:text-yorkshire-stone/50 mb-3">
                  Budget Profile
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: "budget", label: "Cozy & Local" },
                    { id: "standard", label: "Classic Yorkshire" },
                    { id: "luxury", label: "Grantley Luxury" }
                  ].map((b) => (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => setBudget(b.id)}
                      className={`px-3 py-3 rounded-xl text-xs font-semibold transition-all border ${
                        budget === b.id
                          ? "bg-yorkshire-slate dark:bg-yorkshire-stone text-yorkshire-stone dark:text-yorkshire-slate border-yorkshire-slate dark:border-yorkshire-stone"
                          : "bg-white dark:bg-white/5 border-yorkshire-slate/15 dark:border-white/10 text-yorkshire-slate/60 dark:text-yorkshire-stone/60 hover:border-minster-gold"
                      }`}
                    >
                      {b.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Traveler Category */}
              <div>
                <label className="block text-xs uppercase font-extrabold tracking-widest text-yorkshire-slate/50 dark:text-yorkshire-stone/50 mb-3">
                  Traveler Profile
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: "solo", label: "Solo" },
                    { id: "couple", label: "Couple" },
                    { id: "family", label: "Family" },
                    { id: "friends", label: "Friends" }
                  ].map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setTravelers(t.id)}
                      className={`py-3 rounded-xl text-xs font-semibold transition-all border ${
                        travelers === t.id
                          ? "bg-yorkshire-slate dark:bg-yorkshire-stone text-yorkshire-stone dark:text-yorkshire-slate border-yorkshire-slate dark:border-yorkshire-stone"
                          : "bg-white dark:bg-white/5 border-yorkshire-slate/15 dark:border-white/10 text-yorkshire-slate/60 dark:text-yorkshire-stone/60 hover:border-minster-gold"
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Interests Grid Checkboxes */}
              <div>
                <label className="block text-xs uppercase font-extrabold tracking-widest text-yorkshire-slate/50 dark:text-yorkshire-stone/50 mb-3">
                  Interests & Passions
                </label>
                <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto p-1 border border-yorkshire-slate/10 dark:border-white/10 rounded-xl bg-white/20 dark:bg-black/5">
                  {interestOptions.map((opt) => {
                    const isSelected = selectedInterests.includes(opt);
                    return (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => toggleInterest(opt)}
                        className={`flex items-center space-x-2.5 p-2.5 rounded-lg border text-left transition-colors cursor-pointer focus:outline-none ${
                          isSelected
                            ? "bg-minster-gold/10 border-minster-gold/50 text-yorkshire-slate dark:text-white"
                            : "bg-white dark:bg-white/5 border-transparent text-yorkshire-slate/60 dark:text-yorkshire-stone/60 hover:border-yorkshire-slate/10"
                        }`}
                      >
                        <span className={`w-3.5 h-3.5 rounded border flex items-center justify-center ${
                          isSelected ? "bg-minster-gold border-minster-gold text-white" : "border-yorkshire-slate/20 dark:border-white/20 bg-transparent"
                        }`}>
                          {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-white block" />}
                        </span>
                        <span className="text-xs font-medium">{opt}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 bg-minster-gold hover:bg-minster-gold/90 text-white rounded-xl text-xs font-bold uppercase tracking-widest shadow-md hover:shadow-lg transition-all flex items-center justify-center space-x-2 disabled:opacity-50 cursor-pointer"
              >
                <Compass className="w-4 h-4 animate-spin-slow" />
                <span>{loading ? "Compiling Itinerary..." : "Compile Itinerary"}</span>
              </button>
            </form>
          </div>

          {/* Output Display Panel (Span 7) */}
          <div className="lg:col-span-7">
            <AnimatePresence mode="wait">
              {loading ? (
                /* Reassuring Loading State Card */
                <motion.div
                  key="loading"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="bg-white/40 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 rounded-3xl p-12 text-center min-h-[480px] flex flex-col justify-center items-center relative overflow-hidden"
                >
                  <div className="w-16 h-16 rounded-full bg-minster-gold/15 text-minster-gold flex items-center justify-center mb-6 animate-spin">
                    <Compass className="w-8 h-8" />
                  </div>

                  <span className="text-[10px] uppercase font-bold tracking-[0.2em] text-minster-gold block mb-2">
                    COMPILING FLIGHT PATHS & SITES
                  </span>
                  
                  <AnimatePresence mode="wait">
                    <motion.p
                      key={loadingMessageIdx}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -8 }}
                      transition={{ duration: 0.4 }}
                      className="font-serif text-lg font-bold text-yorkshire-slate dark:text-white h-12"
                    >
                      {REASSURING_MESSAGES[loadingMessageIdx]}
                    </motion.p>
                  </AnimatePresence>

                  <p className="text-xs text-yorkshire-slate/50 dark:text-yorkshire-stone/50 font-light max-w-sm mt-4 leading-relaxed">
                    Our digital compiler maps topography, aligns opening hours, and cross-checks coordinates with official national park directories.
                  </p>
                </motion.div>
              ) : error ? (
                /* Error card */
                <motion.div
                  key="error"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="bg-red-500/10 border border-red-500/30 rounded-3xl p-8 text-center min-h-[380px] flex flex-col justify-center items-center"
                >
                  <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
                  <h4 className="font-serif text-xl font-bold text-red-600 dark:text-red-400 mb-2">
                    Connection Issue
                  </h4>
                  <p className="text-sm text-yorkshire-slate dark:text-white max-w-md">
                    {error}
                  </p>
                </motion.div>
              ) : itinerary ? (
                /* Real Itinerary Output Layout */
                <motion.div
                  key="itinerary"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-8 print:bg-white print:p-8"
                >
                  {/* Itinerary Header */}
                  <div className="bg-white/40 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 p-8 rounded-3xl relative">
                    <div className="absolute top-6 right-6 hidden sm:block">
                      <button
                        onClick={() => window.print()}
                        className="p-3 bg-white dark:bg-white/10 hover:bg-yorkshire-stone/40 text-yorkshire-slate dark:text-white border border-yorkshire-slate/15 dark:border-white/10 rounded-full transition-colors cursor-pointer"
                        title="Print Itinerary"
                      >
                        <Printer className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-minster-gold mb-3">
                      <CheckCircle2 className="w-4 h-4 text-moorland-green" />
                      <span>Custom Compilation Complete</span>
                    </div>

                    <h3 className="font-serif text-3xl md:text-4xl font-bold text-yorkshire-slate dark:text-white leading-tight mb-4">
                      {itinerary.title}
                    </h3>
                    
                    <p className="text-xs md:text-sm text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
                      {itinerary.summary}
                    </p>
                  </div>

                  {/* Days Timeline breakdown */}
                  <div className="relative border-l border-minster-gold/30 ml-4 space-y-10 pl-6 md:pl-8">
                    {itinerary.days.map((day) => (
                      <div key={day.dayNumber} className="relative">
                        
                        {/* Day Number floating pin */}
                        <span className="absolute -left-[39px] md:-left-[47px] top-0 w-8 h-8 rounded-full bg-minster-gold text-white flex items-center justify-center font-mono text-xs font-extrabold shadow-md border-2 border-yorkshire-stone dark:border-yorkshire-slate">
                          {day.dayNumber}
                        </span>

                        <div className="space-y-4">
                          {/* Day Title theme */}
                          <div>
                            <span className="text-[10px] uppercase font-bold tracking-[0.2em] text-minster-gold block leading-none">DAY {day.dayNumber} SUMMARY</span>
                            <h4 className="font-serif text-xl font-bold text-yorkshire-slate dark:text-white mt-1">
                              {day.theme}
                            </h4>
                          </div>

                          {/* Day Activities Checklist */}
                          <div className="space-y-3">
                            {day.activities.map((act, actIdx) => (
                              <div
                                key={actIdx}
                                className="bg-white/40 dark:bg-white/5 border border-yorkshire-slate/5 dark:border-white/5 p-4 rounded-xl flex flex-col sm:flex-row gap-4 items-start hover:border-minster-gold/25 transition-all"
                              >
                                <span className="px-2.5 py-1 bg-minster-gold/10 border border-minster-gold/20 rounded text-[9px] font-mono text-minster-gold font-bold flex-shrink-0">
                                  {act.time}
                                </span>
                                <div className="space-y-1.5 flex-1">
                                  <h5 className="text-xs font-bold text-yorkshire-slate dark:text-white leading-tight">
                                    {act.title}
                                  </h5>
                                  <p className="text-xs text-yorkshire-slate/70 dark:text-yorkshire-stone/70 leading-relaxed font-light">
                                    {act.description}
                                  </p>
                                  <span className="text-[9px] font-bold text-yorkshire-slate/40 dark:text-yorkshire-stone/40 block flex items-center mt-1">
                                    <MapPin className="w-3 h-3 mr-1 text-minster-gold" />
                                    {act.location}
                                  </span>
                                  {act.tip && (
                                    <div className="mt-2 bg-yorkshire-stone/50 dark:bg-black/20 p-2.5 rounded-lg border border-dashed border-yorkshire-slate/10 dark:border-white/5 text-[10px] text-yorkshire-slate/85 dark:text-yorkshire-stone/85 leading-relaxed font-light italic">
                                      <span className="font-bold text-minster-gold not-italic">Native Tip: </span>
                                      {act.tip}
                                    </div>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>

                          {/* Recommendations footnotes cards */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4 pt-1">
                            {day.accommodationRecommendation && (
                              <div className="p-3 bg-white/40 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 rounded-xl flex items-center space-x-3 text-xs">
                                <div className="p-2 bg-minster-gold/10 rounded-lg text-minster-gold">
                                  <Bed className="w-4 h-4" />
                                </div>
                                <div>
                                  <span className="text-[9px] uppercase font-bold text-yorkshire-slate/40 dark:text-yorkshire-stone/40 block leading-none mb-1">Recommended Stay</span>
                                  <p className="font-semibold leading-tight text-yorkshire-slate dark:text-white">{day.accommodationRecommendation}</p>
                                </div>
                              </div>
                            )}
                            {day.diningRecommendation && (
                              <div className="p-3 bg-white/40 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 rounded-xl flex items-center space-x-3 text-xs">
                                <div className="p-2 bg-minster-gold/10 rounded-lg text-minster-gold">
                                  <Coffee className="w-4 h-4" />
                                </div>
                                <div>
                                  <span className="text-[9px] uppercase font-bold text-yorkshire-slate/40 dark:text-yorkshire-stone/40 block leading-none mb-1">Recommended Feast</span>
                                  <p className="font-semibold leading-tight text-yorkshire-slate dark:text-white">{day.diningRecommendation}</p>
                                </div>
                              </div>
                            )}
                          </div>

                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              ) : (
                /* Waiting Initial default template panel */
                <motion.div
                  key="initial"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="bg-white/20 dark:bg-white/5 border border-dashed border-yorkshire-slate/20 dark:border-white/10 rounded-3xl p-12 text-center min-h-[480px] flex flex-col justify-center items-center"
                >
                  <Compass className="w-12 h-12 text-minster-gold mb-4 animate-spin-slow" />
                  <h4 className="font-serif text-2xl font-bold text-yorkshire-slate dark:text-white mb-2 leading-tight">
                    Custom Compilation Ready
                  </h4>
                  <p className="text-xs text-yorkshire-slate/60 dark:text-yorkshire-stone/60 max-w-sm leading-relaxed mb-6">
                    Define your travel duration and interests on the left panel, then trigger compilation to generate a complete travel dossier using generative AI.
                  </p>
                  <div className="flex flex-wrap justify-center gap-2">
                    {["Three Peaks", "Medieval Walls", "Dracula Trails", "Michelin Feasts"].map((lbl) => (
                      <span key={lbl} className="px-2.5 py-1 bg-white/50 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 rounded-md text-[10px] font-bold text-yorkshire-slate/50 dark:text-yorkshire-stone/50 font-mono">
                        {lbl}
                      </span>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
}
