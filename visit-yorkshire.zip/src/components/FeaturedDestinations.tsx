import { useState } from "react";
import { MapPin, CloudSun, Compass, ShieldAlert, ArrowRight, X, Sparkles, Navigation } from "lucide-react";
import { DESTINATIONS, Destination } from "../types";
import { motion, AnimatePresence } from "motion/react";

export default function FeaturedDestinations() {
  const [selectedRegion, setSelectedRegion] = useState<string>("all");
  const [activeCard, setActiveCard] = useState<Destination | null>(null);

  const regions = [
    { label: "All Regions", id: "all" },
    { label: "National Parks & Dales", id: "dales" },
    { label: "Coastal Shores", id: "coast" },
    { label: "Vibrant Cities", id: "cities" },
    { label: "Heather Moorlands", id: "moors" },
  ];

  const filteredDestinations = selectedRegion === "all"
    ? DESTINATIONS
    : DESTINATIONS.filter((d) => d.region === selectedRegion);

  return (
    <section id="destinations" className="py-24 md:py-32 bg-yorkshire-stone dark:bg-yorkshire-slate">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Section Header */}
        <div className="mb-16 md:mb-20 text-left max-w-3xl">
          <span className="text-xs uppercase font-bold tracking-[0.25em] text-minster-gold block mb-3">
            WHERE TO EXPLORE
          </span>
          <h2 className="font-serif text-4xl md:text-6xl font-bold tracking-tight text-yorkshire-slate dark:text-white leading-tight mb-6">
            Featured Destinations
          </h2>
          <p className="text-base md:text-lg text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
            From the gothic alleyways of York and vibrant cultural hubs of Leeds and Sheffield, to the vast limestone valleys of the Dales and fossil-rich cliffs of the coast.
          </p>
        </div>

        {/* Region Filter Tabs */}
        <div className="flex flex-wrap items-center gap-2 mb-12 border-b border-yorkshire-slate/10 dark:border-white/10 pb-6 overflow-x-auto hide-scrollbar">
          {regions.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedRegion(tab.id)}
              className={`px-6 py-3 rounded-full text-xs font-semibold uppercase tracking-wider transition-all duration-300 relative cursor-pointer focus:outline-none ${
                selectedRegion === tab.id
                  ? "text-white bg-yorkshire-slate dark:bg-yorkshire-stone dark:text-yorkshire-slate shadow-md"
                  : "text-yorkshire-slate/60 dark:text-yorkshire-stone/60 hover:text-yorkshire-slate dark:hover:text-white hover:bg-yorkshire-slate/5 dark:hover:bg-white/5"
              }`}
            >
              <span className="relative z-10">{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Destinations Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence mode="popLayout">
            {filteredDestinations.map((destination) => (
              <motion.div
                layout
                key={destination.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.5 }}
                onClick={() => setActiveCard(destination)}
                className="group cursor-pointer bg-white dark:bg-white/5 rounded-2xl overflow-hidden border border-yorkshire-slate/5 dark:border-white/5 shadow-sm hover:shadow-xl hover:border-minster-gold/25 transition-all duration-500 flex flex-col justify-between"
              >
                {/* Image & Weather Badge */}
                <div className="relative aspect-4/3 overflow-hidden bg-yorkshire-slate/10">
                  <img
                    src={destination.image}
                    alt={destination.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                  />
                  
                  {/* Subtle Top Gradient for Badge Visibility */}
                  <div className="absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-black/40 to-transparent pointer-events-none" />

                  {/* Weather Overlay */}
                  <div className="absolute top-4 right-4 bg-white/20 dark:bg-black/45 backdrop-blur-md border border-white/25 px-3 py-1.5 rounded-full flex items-center space-x-2 text-white text-xs font-semibold shadow-sm">
                    <CloudSun className="w-4 h-4 text-minster-gold" />
                    <span>{destination.temp}°C · {destination.weather}</span>
                  </div>

                  {/* Region Indicator */}
                  <div className="absolute bottom-4 left-4 bg-yorkshire-slate/85 dark:bg-white/90 text-yorkshire-stone dark:text-yorkshire-slate px-3 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider">
                    {destination.region}
                  </div>
                </div>

                {/* Info Content */}
                <div className="p-6 md:p-8 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start mb-3">
                      <h3 className="font-serif text-2xl font-bold tracking-tight text-yorkshire-slate dark:text-white group-hover:text-minster-gold transition-colors duration-300">
                        {destination.name}
                      </h3>
                      <div className="p-2 rounded-full bg-yorkshire-stone/50 dark:bg-white/5 text-yorkshire-slate/40 dark:text-white/40 group-hover:bg-minster-gold group-hover:text-white transition-all duration-300">
                        <ArrowRight className="w-4 h-4" />
                      </div>
                    </div>
                    
                    <p className="text-sm text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light mb-6 line-clamp-3">
                      {destination.description}
                    </p>
                  </div>

                  <div className="border-t border-yorkshire-slate/10 dark:border-white/10 pt-5 mt-auto flex flex-col gap-2">
                    <div className="flex items-center text-xs font-medium text-yorkshire-slate/60 dark:text-yorkshire-stone/60">
                      <MapPin className="w-3.5 h-3.5 mr-2 text-minster-gold" />
                      <span>{destination.distance}</span>
                    </div>
                    <div className="flex items-center text-xs font-medium text-yorkshire-slate/60 dark:text-yorkshire-stone/60">
                      <Navigation className="w-3.5 h-3.5 mr-2 text-minster-gold" />
                      <span>{destination.travelTime}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Detailed Modal Drawer */}
        <AnimatePresence>
          {activeCard && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-yorkshire-slate/75 dark:bg-black/85 backdrop-blur-sm flex items-center justify-center p-6"
              onClick={() => setActiveCard(null)}
            >
              <motion.div
                initial={{ scale: 0.95, y: 15 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 15 }}
                className="bg-yorkshire-stone dark:bg-yorkshire-slate rounded-2xl overflow-hidden shadow-2xl max-w-4xl w-full border border-yorkshire-slate/10 dark:border-white/15 relative"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button */}
                <button
                  onClick={() => setActiveCard(null)}
                  className="absolute top-6 right-6 p-2 rounded-full bg-black/40 hover:bg-black/60 border border-white/20 text-white z-10 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="grid grid-cols-1 md:grid-cols-2">
                  {/* Left Side: Photo */}
                  <div className="relative h-64 md:h-full min-h-[300px]">
                    <img
                      src={activeCard.image}
                      alt={activeCard.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
                    <div className="absolute bottom-6 left-6 text-white">
                      <span className="text-xs font-bold uppercase tracking-widest text-minster-gold">
                        Featured Destination
                      </span>
                      <h3 className="font-serif text-3xl font-bold mt-1">
                        {activeCard.name}
                      </h3>
                    </div>
                  </div>

                  {/* Right Side: Info Panel */}
                  <div className="p-8 md:p-10 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center space-x-3 mb-4">
                        <span className="px-3 py-1 bg-minster-gold/15 text-minster-gold border border-minster-gold/20 text-[10px] font-extrabold uppercase tracking-widest rounded-md">
                          {activeCard.region}
                        </span>
                        <div className="flex items-center text-xs text-yorkshire-slate/60 dark:text-yorkshire-stone/60">
                          <CloudSun className="w-4 h-4 mr-1.5 text-minster-gold" />
                          <span>{activeCard.temp}°C · {activeCard.weather}</span>
                        </div>
                      </div>

                      <p className="text-sm text-yorkshire-slate/85 dark:text-yorkshire-stone/85 leading-relaxed font-light mb-6">
                        {activeCard.description}
                      </p>

                      {/* Travel details summary cards */}
                      <div className="grid grid-cols-2 gap-4 mb-8 bg-white/40 dark:bg-white/5 border border-yorkshire-slate/5 dark:border-white/5 p-4 rounded-xl">
                        <div>
                          <span className="text-[10px] uppercase font-bold text-yorkshire-slate/40 dark:text-yorkshire-stone/40">Distance</span>
                          <p className="text-xs font-semibold text-yorkshire-slate dark:text-white mt-0.5">{activeCard.distance}</p>
                        </div>
                        <div>
                          <span className="text-[10px] uppercase font-bold text-yorkshire-slate/40 dark:text-yorkshire-stone/40">Travel Time</span>
                          <p className="text-xs font-semibold text-yorkshire-slate dark:text-white mt-0.5">{activeCard.travelTime}</p>
                        </div>
                      </div>

                      <h4 className="text-xs uppercase font-extrabold tracking-widest text-yorkshire-slate/50 dark:text-yorkshire-stone/50 mb-3 flex items-center">
                        <Sparkles className="w-4 h-4 mr-2 text-minster-gold" />
                        Must-See Highlights
                      </h4>
                      <ul className="space-y-2 mb-8">
                        {activeCard.highlights.map((highlight, idx) => (
                          <li key={idx} className="text-xs text-yorkshire-slate/85 dark:text-yorkshire-stone/85 flex items-start">
                            <span className="w-1.5 h-1.5 rounded-full bg-minster-gold mt-1.5 mr-3 flex-shrink-0" />
                            <span>{highlight}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex gap-4">
                      <a
                        href="#planner"
                        onClick={() => {
                          setActiveCard(null);
                          // Give time for modal close then scroll
                          setTimeout(() => {
                            const p = document.getElementById("planner");
                            p?.scrollIntoView({ behavior: "smooth" });
                          }, 100);
                        }}
                        className="flex-1 py-3 bg-yorkshire-slate dark:bg-yorkshire-stone text-yorkshire-stone dark:text-yorkshire-slate hover:bg-minster-gold dark:hover:bg-minster-gold hover:text-white dark:hover:text-white text-xs font-bold uppercase tracking-wider text-center rounded-lg transition-colors"
                      >
                        Plan Trip to {activeCard.name}
                      </a>
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
