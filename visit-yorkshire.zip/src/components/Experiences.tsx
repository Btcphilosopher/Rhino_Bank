import { useState } from "react";
import { Compass, Camera, Heart, HelpCircle, ArrowUpRight, FlameKindling, Waves, BookOpen, Star } from "lucide-react";
import { EXPERIENCES, Experience } from "../types";
import { motion, AnimatePresence } from "motion/react";

// Expand the experience list directly inside the component to provide rich content for the entire prompt scope
const ENRICHED_EXPERIENCES: Experience[] = [
  ...EXPERIENCES,
  {
    id: "cycling",
    title: "World-Class Cycling Trails",
    category: "outdoor",
    description: "Follow the pathways of the Tour de Yorkshire. Challenge yourself on the legendary Buttertubs Pass climb or enjoy traffic-free family rail trails.",
    image: "https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&q=80&w=600",
    tag: "Athletic",
    readTime: "4 min read"
  },
  {
    id: "wild-swimming",
    title: "Wild Swimming & Waterfalls",
    category: "wellness",
    description: "Plunge into crystal-clear pools beneath Janet's Foss waterfall in Malham or cool off in the tranquil, wide waters of the River Wharfe at Appletreewick.",
    image: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&q=80&w=600",
    tag: "Restorative",
    readTime: "5 min read"
  },
  {
    id: "literature-bronte",
    title: "Brontë Country & Literature",
    category: "culture",
    description: "Walk the windswept moorlands of Haworth that inspired Emily Brontë's Wuthering Heights. Visit the historic Brontë Parsonage Museum.",
    image: "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&q=80&w=600",
    tag: "Literary",
    readTime: "6 min read"
  },
  {
    id: "food-trails",
    title: "Artisanal Food Trails & Markets",
    category: "food",
    description: "Follow curated cheese, gin, and beer trails across the county, exploring bustling weekly farmers' markets in Malton—the official food capital of Yorkshire.",
    image: "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=600",
    tag: "Gastronomic",
    readTime: "5 min read"
  },
  {
    id: "film-locations",
    title: "Historic Film Locations",
    category: "culture",
    description: "Visit real filming sets of Harry Potter (Goathland), Victoria, All Creatures Great and Small (Grassington), and Dracula in Whitby.",
    image: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&q=80&w=600",
    tag: "Cinematic",
    readTime: "3 min read"
  },
  {
    id: "festivals-wellness",
    title: "Rural Wellness & Festivals",
    category: "wellness",
    description: "Rejuvenate at boutique country estate spas, attend elite literature festivals, or participate in dark sky stargazing therapy sessions in remote moorlands.",
    image: "https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&q=80&w=600",
    tag: "Serene",
    readTime: "4 min read"
  }
];

export default function Experiences() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [activeExp, setActiveExp] = useState<Experience | null>(null);

  const categories = [
    { id: "all", label: "All Experiences" },
    { id: "outdoor", label: "Wild Outdoors" },
    { id: "history", label: "Historic Chronicles" },
    { id: "food", label: "Gastronomy" },
    { id: "culture", label: "Arts & Culture" },
    { id: "wellness", label: "Restorative Wellness" },
  ];

  const filtered = selectedCategory === "all"
    ? ENRICHED_EXPERIENCES
    : ENRICHED_EXPERIENCES.filter((e) => e.category === selectedCategory);

  return (
    <section id="experiences" className="py-24 md:py-32 bg-yorkshire-stone dark:bg-yorkshire-slate">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Editorial Title Block */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16 md:mb-24 items-end">
          <div className="lg:col-span-7">
            <span className="text-xs uppercase font-bold tracking-[0.25em] text-minster-gold block mb-3">
              CURATED MEMORIES
            </span>
            <h2 className="font-serif text-4xl md:text-6xl font-bold tracking-tight text-yorkshire-slate dark:text-white leading-tight">
              Unforgettable Experiences
            </h2>
          </div>
          <div className="lg:col-span-5 text-left">
            <p className="text-sm md:text-base text-yorkshire-slate/70 dark:text-yorkshire-stone/70 leading-relaxed font-light">
              Yorkshire isn't merely a destination to behold; it is a region to feel. Choose your pace—from scaling gritstone ridges to experiencing heritage railway luxury and tasting Michelin-starred gastronomy.
            </p>
          </div>
        </div>

        {/* Directory Filters */}
        <div className="flex flex-wrap items-center gap-2 mb-12 overflow-x-auto pb-4 hide-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-5 py-2.5 rounded-full text-xs font-semibold uppercase tracking-wider transition-all duration-300 relative cursor-pointer focus:outline-none border ${
                selectedCategory === cat.id
                  ? "text-yorkshire-stone bg-yorkshire-slate dark:bg-yorkshire-stone dark:text-yorkshire-slate border-yorkshire-slate dark:border-yorkshire-stone shadow-sm"
                  : "text-yorkshire-slate/70 dark:text-yorkshire-stone/70 border-yorkshire-slate/15 dark:border-white/10 hover:bg-yorkshire-slate/5 dark:hover:bg-white/5 hover:text-yorkshire-slate dark:hover:text-white"
              }`}
            >
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

        {/* Experiences Masonry Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence mode="popLayout">
            {filtered.map((exp, idx) => (
              <motion.div
                layout
                key={exp.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.45, delay: idx * 0.05 }}
                onClick={() => setActiveExp(exp)}
                className="group cursor-pointer flex flex-col justify-between bg-white/45 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 rounded-2xl p-6 hover:bg-white dark:hover:bg-white/10 hover:shadow-xl hover:border-minster-gold/20 transition-all duration-500"
              >
                <div>
                  {/* Photo Frame */}
                  <div className="relative aspect-16/10 rounded-xl overflow-hidden mb-6 bg-yorkshire-slate/10">
                    <img
                      src={exp.image}
                      alt={exp.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                    />
                    <div className="absolute top-3 left-3 px-3 py-1 bg-white/95 dark:bg-yorkshire-slate/95 border border-yorkshire-slate/10 dark:border-white/10 rounded-full text-[10px] font-extrabold uppercase tracking-widest text-minster-gold">
                      {exp.tag}
                    </div>
                  </div>

                  <div className="flex items-start justify-between mb-3">
                    <h3 className="font-serif text-2xl font-bold tracking-tight text-yorkshire-slate dark:text-white group-hover:text-minster-gold transition-colors duration-300">
                      {exp.title}
                    </h3>
                    <div className="p-1 rounded-full text-yorkshire-slate/40 dark:text-white/40 group-hover:text-minster-gold group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all">
                      <ArrowUpRight className="w-5 h-5" />
                    </div>
                  </div>

                  <p className="text-sm text-yorkshire-slate/75 dark:text-yorkshire-stone/75 font-light leading-relaxed mb-6">
                    {exp.description}
                  </p>
                </div>

                <div className="flex items-center justify-between border-t border-yorkshire-slate/10 dark:border-white/10 pt-4 text-xs text-yorkshire-slate/50 dark:text-yorkshire-stone/50 font-mono font-bold uppercase tracking-wider">
                  <span className="flex items-center">
                    <Compass className="w-3.5 h-3.5 mr-2 text-minster-gold" />
                    Category: {exp.category}
                  </span>
                  {exp.readTime && (
                    <span>{exp.readTime}</span>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Modal for Experience Detail */}
        <AnimatePresence>
          {activeExp && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-yorkshire-slate/75 dark:bg-black/85 backdrop-blur-sm flex items-center justify-center p-6"
              onClick={() => setActiveExp(null)}
            >
              <motion.div
                initial={{ scale: 0.95, y: 15 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 15 }}
                className="bg-yorkshire-stone dark:bg-yorkshire-slate rounded-2xl overflow-hidden shadow-2xl max-w-xl w-full border border-yorkshire-slate/10 dark:border-white/15 p-8 relative"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button */}
                <button
                  onClick={() => setActiveExp(null)}
                  className="absolute top-6 right-6 p-2 rounded-full hover:bg-yorkshire-slate/5 dark:hover:bg-white/10 text-yorkshire-slate/70 dark:text-yorkshire-stone/70 z-10 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>

                {/* Cover Image */}
                <div className="relative aspect-16/9 rounded-xl overflow-hidden mb-6 bg-yorkshire-slate/10">
                  <img
                    src={activeExp.image}
                    alt={activeExp.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent pointer-events-none" />
                  <span className="absolute bottom-4 left-4 px-3 py-1 bg-minster-gold text-white text-[10px] font-bold uppercase tracking-widest rounded-md">
                    {activeExp.tag}
                  </span>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center space-x-2 text-xs text-minster-gold uppercase font-bold tracking-widest font-mono">
                    <Star className="w-4 h-4 fill-current" />
                    <span>Highly Recommended Experience</span>
                  </div>
                  
                  <h3 className="font-serif text-3xl font-bold text-yorkshire-slate dark:text-white leading-tight">
                    {activeExp.title}
                  </h3>
                  
                  <p className="text-sm text-yorkshire-slate/80 dark:text-yorkshire-stone/80 leading-relaxed font-light">
                    {activeExp.description} This curated Yorkshire highlight guarantees an authentic, premium encounter with local nature, history, and community. Prepare to discover what truly sets "God's Own County" apart.
                  </p>

                  <div className="pt-4 border-t border-yorkshire-slate/10 dark:border-white/10 flex items-center justify-between text-xs text-yorkshire-slate/50 dark:text-yorkshire-stone/50 font-mono font-bold uppercase">
                    <span className="flex items-center">
                      <Compass className="w-4 h-4 mr-2 text-minster-gold" />
                      Classified: {activeExp.category}
                    </span>
                    <span>Ready to Explore</span>
                  </div>

                  <div className="pt-6 flex gap-3">
                    <button
                      onClick={() => {
                        setActiveExp(null);
                        const target = document.getElementById("planner");
                        target?.scrollIntoView({ behavior: "smooth" });
                      }}
                      className="flex-1 py-3 bg-yorkshire-slate dark:bg-yorkshire-stone text-yorkshire-stone dark:text-yorkshire-slate text-xs font-semibold uppercase tracking-wider text-center rounded-lg hover:bg-minster-gold dark:hover:bg-minster-gold hover:text-white dark:hover:text-white transition-colors"
                    >
                      Add to Custom Trip Itinerary
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
export function X(props: any) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M18 6 6 18" />
      <path d="m6 6 12 12" />
    </svg>
  );
}
