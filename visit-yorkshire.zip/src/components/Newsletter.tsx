import { useState, FormEvent } from "react";
import { Mail, CheckCircle2, FileText, ArrowRight, Sparkles, Download, ArrowUpRight } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function Newsletter() {
  const [email, setEmail] = useState<string>("");
  const [subscribed, setSubscribed] = useState<boolean>(false);
  const [downloadingGuideId, setDownloadingGuideId] = useState<string | null>(null);

  const guides = [
    { id: "walking", title: "Fell Walking & Dales Trails", format: "PDF (18.2 MB)", downloads: "4.2k downloads" },
    { id: "gastro", title: "Michelin & Artisanal Food Map", format: "PDF (12.4 MB)", downloads: "3.1k downloads" },
    { id: "gothic", title: "Historic Abbeys & Castles Guide", format: "PDF (24.1 MB)", downloads: "5.8k downloads" }
  ];

  const handleSubscribe = (e: FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubscribed(true);
  };

  const handleDownload = (id: string, title: string) => {
    setDownloadingGuideId(id);
    setTimeout(() => {
      // Simulate download delivery alert
      alert(`"${title}" brochure download complete! The high-definition PDF has been downloaded.`);
      setDownloadingGuideId(null);
    }, 1500);
  };

  return (
    <section id="newsletter" className="py-24 md:py-32 bg-yorkshire-stone dark:bg-yorkshire-slate border-t border-yorkshire-slate/10 dark:border-white/10">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
          
          {/* Left Column: Official downloads (Span 6) */}
          <div className="lg:col-span-6 space-y-8">
            <div>
              <span className="text-xs uppercase font-bold tracking-[0.25em] text-minster-gold block mb-3">
                REGIONAL BROCHURES
              </span>
              <h2 className="font-serif text-3xl md:text-5xl font-bold tracking-tight text-yorkshire-slate dark:text-white leading-tight mb-4">
                Official Digital Guides
              </h2>
              <p className="text-sm md:text-base text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
                Secure our beautifully illustrated, ranger-endorsed brochures to consult offline. Contains detailed topographic maps, food trail coordinates, and gothic literature path coordinates.
              </p>
            </div>

            <div className="space-y-4">
              {guides.map((guide) => {
                const isDownloading = downloadingGuideId === guide.id;
                return (
                  <div
                    key={guide.id}
                    className="p-5 bg-white/40 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 rounded-2xl flex items-center justify-between hover:shadow-md transition-all group"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="p-3 bg-minster-gold/10 rounded-xl text-minster-gold">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-yorkshire-slate dark:text-white group-hover:text-minster-gold transition-colors">
                          {guide.title}
                        </h4>
                        <p className="text-[10px] text-yorkshire-slate/50 dark:text-yorkshire-stone/50 mt-1 font-mono font-bold uppercase">
                          {guide.format} · {guide.downloads}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDownload(guide.id, guide.title)}
                      disabled={isDownloading}
                      className="p-3 bg-yorkshire-slate dark:bg-yorkshire-stone text-yorkshire-stone dark:text-yorkshire-slate hover:bg-minster-gold dark:hover:bg-minster-gold hover:text-white dark:hover:text-white rounded-xl transition-all cursor-pointer disabled:opacity-50 flex items-center space-x-1.5"
                    >
                      <Download className={`w-4 h-4 ${isDownloading ? "animate-bounce" : ""}`} />
                      <span className="text-[9px] uppercase font-bold tracking-wider hidden sm:inline">
                        {isDownloading ? "Downloading..." : "Download"}
                      </span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Newsletter sign up (Span 6) */}
          <div className="lg:col-span-6 bg-yorkshire-slate dark:bg-white/5 border border-white/10 dark:border-white/5 p-8 md:p-12 rounded-3xl relative overflow-hidden shadow-xl text-white">
            {/* Ambient visual graphic accent */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-minster-gold/10 rounded-full blur-2xl pointer-events-none" />

            <div className="relative z-10 space-y-6">
              <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-minster-gold">
                <Sparkles className="w-4 h-4" />
                <span>WEEKLY TRAVEL GAZETTE</span>
              </div>

              <h3 className="font-serif text-3xl md:text-4xl font-bold leading-tight">
                Subscribe to Visit Yorkshire
              </h3>
              
              <p className="text-xs md:text-sm text-yorkshire-stone/80 leading-relaxed font-light">
                Join 45,000+ global travelers receiving our highly curated weekly journal, unlocking exclusive seasonal packages, independent gastronomy routes, and early festival ticket priorities.
              </p>

              <AnimatePresence mode="wait">
                {!subscribed ? (
                  <motion.form
                    key="form"
                    onSubmit={handleSubscribe}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex flex-col sm:flex-row gap-3 pt-2"
                  >
                    <div className="relative flex-1">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-yorkshire-stone/40" />
                      <input
                        type="email"
                        required
                        placeholder="Enter your email address"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-white/10 hover:bg-white/15 focus:bg-white border border-white/15 focus:border-minster-gold text-white focus:text-yorkshire-slate rounded-xl pl-12 pr-4 py-3.5 text-xs transition-all focus:outline-none placeholder-yorkshire-stone/40"
                      />
                    </div>
                    <button
                      type="submit"
                      className="px-6 py-3.5 bg-minster-gold hover:bg-minster-gold/90 text-white rounded-xl text-xs font-bold uppercase tracking-widest transition-colors cursor-pointer flex items-center justify-center space-x-2 shrink-0"
                    >
                      <span>Join Gazette</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </motion.form>
                ) : (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-6 bg-white/10 rounded-2xl border border-white/10 text-center space-y-3"
                  >
                    <CheckCircle2 className="w-8 h-8 text-minster-gold mx-auto" />
                    <h4 className="font-serif text-lg font-bold">You are Registered</h4>
                    <p className="text-xs text-yorkshire-stone/75 leading-relaxed font-light">
                      Welcome to the Gazette! We have delivered your welcoming regional brochure bundle directly to your email inbox: <strong>{email}</strong>.
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
