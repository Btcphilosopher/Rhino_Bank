import { useState, useRef, MouseEvent } from "react";
import { Map, MapPin, ZoomIn, ZoomOut, RotateCcw, Filter, Sparkles, Navigation, Info, Ship, Train, Compass, CloudSun } from "lucide-react";
import { DESTINATIONS, Destination } from "../types";
import { motion, AnimatePresence } from "motion/react";

interface MapFeature {
  id: string;
  name: string;
  category: "national-park" | "village" | "coastal-path" | "castle" | "museum" | "railway";
  x: number; // percentage coordinate
  y: number; // percentage coordinate
  description: string;
  image: string;
  specialty?: string;
  temp?: number;
  weather?: string;
}

const MAP_FEATURES: MapFeature[] = [
  {
    id: "dales-np",
    name: "Yorkshire Dales National Park",
    category: "national-park",
    x: 28,
    y: 35,
    description: "Thousands of square miles of outstanding drystone valleys, deep limestone caves, and legendary fell walks.",
    image: "https://images.unsplash.com/photo-1543872084-c7bd3822856f?auto=format&fit=crop&q=80&w=400",
    specialty: "Three Peaks Challenge Path"
  },
  {
    id: "moors-np",
    name: "North York Moors National Park",
    category: "national-park",
    x: 65,
    y: 32,
    description: "One of the largest expanses of heather moorland in the UK, cascading directly down to dramatic coastal cliffs.",
    image: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=400",
    specialty: "International Dark Sky Reserve"
  },
  {
    id: "fountains-abbey",
    name: "Fountains Abbey (UNESCO)",
    category: "castle",
    x: 44,
    y: 46,
    description: "The magnificent ruins of one of the largest and best-preserved Cistercian monasteries in England, set in Georgian water gardens.",
    image: "https://images.unsplash.com/photo-1533103054090-334e6e60ab29?auto=format&fit=crop&q=80&w=400",
    specialty: "Medieval Gothic Architecture"
  },
  {
    id: "whitby-abbey-map",
    name: "Whitby Abbey",
    category: "castle",
    x: 78,
    y: 22,
    description: "Crowned atop headlands, this 7th-century Christian monastery ruins inspired Bram Stoker's Dracula masterpiece.",
    image: "https://images.unsplash.com/photo-1596464716127-f2a82984de30?auto=format&fit=crop&q=80&w=400",
    specialty: "199 Steps Clifftop Ascent"
  },
  {
    id: "york-minster-map",
    name: "York Minster",
    category: "museum",
    x: 55,
    y: 56,
    description: "One of the world's most magnificent Gothic cathedrals, featuring medieval stained glass windows of unparalleled scale.",
    image: "https://images.unsplash.com/photo-1570356528233-b482cbdb4074?auto=format&fit=crop&q=80&w=400",
    specialty: "The Great East Window"
  },
  {
    id: "moors-railway",
    name: "North Yorkshire Moors Steam Railway",
    category: "railway",
    x: 60,
    y: 42,
    description: "A nostalgic heritage line taking visitors on an enchanting journey across timeless green dales and high heather meadows.",
    image: "https://images.unsplash.com/photo-1474487548417-781cb71495f3?auto=format&fit=crop&q=80&w=400",
    specialty: "Classic Steam Engine Rides"
  },
  {
    id: "staithes-village",
    name: "Staithes Fishing Village",
    category: "village",
    x: 74,
    y: 16,
    description: "A highly picturesque fishing village of tightly packed cottages clinging precariously to sheltering harbor cliffs.",
    image: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=400",
    specialty: "Rockpooling & Fossil Hunting"
  },
  {
    id: "cleveland-way",
    name: "Cleveland Way Coastal Path",
    category: "coastal-path",
    x: 82,
    y: 30,
    description: "An incredible 109-mile trail showcasing the spectacular junction where towering heather moorlands plunge into the sea.",
    image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=400",
    specialty: "Clifftop Panoramic Hiking"
  }
];

export default function InteractiveMap() {
  const [selectedFeature, setSelectedFeature] = useState<MapFeature | null>(MAP_FEATURES[0]);
  const [activeFilters, setActiveFilters] = useState<string[]>(["national-park", "castle", "village", "coastal-path", "museum", "railway"]);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const isDragging = useRef(false);
  const dragStart = useRef({ x: 0, y: 0 });

  const filterOptions = [
    { id: "national-park", label: "National Parks", color: "bg-moorland-green" },
    { id: "village", label: "Villages", color: "bg-sea-blue" },
    { id: "coastal-path", label: "Coastal Paths", color: "bg-burnt-orange" },
    { id: "castle", label: "Castles & Abbeys", color: "bg-minster-gold" },
    { id: "museum", label: "Heritage Sites", color: "bg-heather-purple" },
    { id: "railway", label: "Steam Railways", color: "bg-yorkshire-slate" },
  ];

  const toggleFilter = (id: string) => {
    setActiveFilters((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleZoom = (direction: "in" | "out") => {
    if (direction === "in" && zoomLevel < 2) {
      setZoomLevel((z) => parseFloat((z + 0.25).toFixed(2)));
    } else if (direction === "out" && zoomLevel > 0.75) {
      setZoomLevel((z) => parseFloat((z - 0.25).toFixed(2)));
      // Reset offset if zooming out to avoid getting lost
      if (zoomLevel <= 1) setPanOffset({ x: 0, y: 0 });
    }
  };

  const handleReset = () => {
    setZoomLevel(1);
    setPanOffset({ x: 0, y: 0 });
    setSelectedFeature(MAP_FEATURES[0]);
  };

  const handleMouseDown = (e: MouseEvent) => {
    isDragging.current = true;
    dragStart.current = { x: e.clientX - panOffset.x, y: e.clientY - panOffset.y };
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging.current || zoomLevel <= 1) return;
    setPanOffset({
      x: e.clientX - dragStart.current.x,
      y: e.clientY - dragStart.current.y
    });
  };

  const handleMouseUp = () => {
    isDragging.current = false;
  };

  return (
    <section id="map" className="py-24 md:py-32 bg-yorkshire-stone dark:bg-yorkshire-slate border-t border-yorkshire-slate/10 dark:border-white/10 relative">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Header section */}
        <div className="mb-16 text-left max-w-3xl">
          <span className="text-xs uppercase font-bold tracking-[0.25em] text-minster-gold block mb-3">
            TERRAIN NAVIGATOR
          </span>
          <h2 className="font-serif text-4xl md:text-6xl font-bold tracking-tight text-yorkshire-slate dark:text-white leading-tight mb-6">
            Interactive Yorkshire Explorer
          </h2>
          <p className="text-base md:text-lg text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
            Filter our high-fidelity topographical chart to reveal hidden medieval castles, historic steam railway lines, scenic coastal pathways, and secluded national parks.
          </p>
        </div>

        {/* Layout Grid: Left filter controls, center map canvas, right sidebar */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Column 1: Filters (Span 3) */}
          <div className="lg:col-span-3 space-y-6">
            <div className="bg-white/40 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 p-6 rounded-2xl">
              <h3 className="font-serif text-lg font-bold text-yorkshire-slate dark:text-white mb-4 flex items-center">
                <Filter className="w-4 h-4 mr-2 text-minster-gold" />
                Filter Landmarks
              </h3>
              <p className="text-xs text-yorkshire-slate/60 dark:text-yorkshire-stone/60 leading-relaxed mb-6 font-light">
                Toggle categories to pinpoint precise coordinates on our vector terrain map.
              </p>
              
              <div className="space-y-3">
                {filterOptions.map((opt) => {
                  const isActive = activeFilters.includes(opt.id);
                  return (
                    <button
                      key={opt.id}
                      onClick={() => toggleFilter(opt.id)}
                      className="w-full flex items-center justify-between p-3 rounded-xl border transition-all text-left group cursor-pointer focus:outline-none"
                      style={{
                        borderColor: isActive ? "var(--color-minster-gold)" : "rgba(36,36,36,0.1)",
                        backgroundColor: isActive ? "rgba(199,161,86,0.05)" : "transparent"
                      }}
                    >
                      <div className="flex items-center space-x-3">
                        <span className={`w-3 h-3 rounded-full ${opt.color} block-shrink-0`} />
                        <span className={`text-xs font-semibold ${isActive ? "text-yorkshire-slate dark:text-white" : "text-yorkshire-slate/60 dark:text-yorkshire-stone/60"}`}>
                          {opt.label}
                        </span>
                      </div>
                      <span className={`w-1.5 h-1.5 rounded-full transition-all ${isActive ? "bg-minster-gold scale-125" : "bg-transparent"}`} />
                    </button>
                  );
                })}
              </div>

              {/* Reset view utility */}
              <button
                onClick={handleReset}
                className="w-full mt-6 py-2.5 rounded-xl border border-dashed border-yorkshire-slate/20 dark:border-white/10 hover:border-minster-gold hover:text-minster-gold text-[10px] font-bold uppercase tracking-widest text-center transition-colors cursor-pointer"
              >
                Reset Map Focus
              </button>
            </div>
          </div>

          {/* Column 2: Vector Map Stage (Span 6) */}
          <div className="lg:col-span-6 flex flex-col">
            <div className="relative flex-1 min-h-[450px] bg-yorkshire-stone/30 dark:bg-black/15 rounded-2xl border border-yorkshire-slate/10 dark:border-white/10 overflow-hidden shadow-inner flex items-center justify-center">
              
              {/* Map controls panel overlay */}
              <div className="absolute bottom-4 right-4 z-10 flex space-x-1.5 bg-white/80 dark:bg-yorkshire-slate/80 backdrop-blur-md p-1.5 rounded-xl border border-yorkshire-slate/10 dark:border-white/10 shadow-sm">
                <button
                  onClick={() => handleZoom("in")}
                  disabled={zoomLevel >= 2}
                  className="p-2 rounded-lg hover:bg-yorkshire-stone/50 dark:hover:bg-white/10 disabled:opacity-30 cursor-pointer"
                  title="Zoom In"
                >
                  <ZoomIn className="w-4 h-4 text-yorkshire-slate dark:text-white" />
                </button>
                <button
                  onClick={() => handleZoom("out")}
                  disabled={zoomLevel <= 0.75}
                  className="p-2 rounded-lg hover:bg-yorkshire-stone/50 dark:hover:bg-white/10 disabled:opacity-30 cursor-pointer"
                  title="Zoom Out"
                >
                  <ZoomOut className="w-4 h-4 text-yorkshire-slate dark:text-white" />
                </button>
                <button
                  onClick={handleReset}
                  className="p-2 rounded-lg hover:bg-yorkshire-stone/50 dark:hover:bg-white/10 cursor-pointer"
                  title="Reset Orientation"
                >
                  <RotateCcw className="w-4 h-4 text-yorkshire-slate dark:text-white" />
                </button>
              </div>

              {/* Map Canvas - drag support only when zoomed in */}
              <div
                className={`w-full h-full relative ${zoomLevel > 1 ? "cursor-grab active:cursor-grabbing" : "cursor-default"}`}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
              >
                <motion.div
                  className="w-full h-full absolute inset-0"
                  animate={{
                    scale: zoomLevel,
                    x: zoomLevel > 1 ? panOffset.x : 0,
                    y: zoomLevel > 1 ? panOffset.y : 0
                  }}
                  transition={{ type: "spring", stiffness: 300, damping: 28 }}
                >
                  {/* High Quality SVG Vector Topographical Base */}
                  <svg
                    viewBox="0 0 500 500"
                    className="w-full h-full select-none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    {/* Cartographic Coordinate Lines Grid */}
                    <g opacity="0.1" stroke="currentColor" strokeWidth="0.5">
                      <line x1="50" y1="0" x2="50" y2="500" />
                      <line x1="150" y1="0" x2="150" y2="500" />
                      <line x1="250" y1="0" x2="250" y2="500" />
                      <line x1="350" y1="0" x2="350" y2="500" />
                      <line x1="450" y1="0" x2="450" y2="500" />
                      
                      <line x1="0" y1="50" x2="500" y2="50" />
                      <line x1="0" y1="150" x2="500" y2="150" />
                      <line x1="0" y1="250" x2="500" y2="250" />
                      <line x1="0" y1="350" x2="500" y2="350" />
                      <line x1="0" y1="450" x2="500" y2="450" />
                    </g>

                    {/* Coastal Blue Border shading (Estuary details) */}
                    <path
                      d="M 380,0 Q 420,50 430,90 T 470,180 T 500,240 L 500,500 L 350,500 Q 300,430 350,380 T 400,280 Z"
                      fill="rgba(78, 120, 151, 0.08)"
                      stroke="rgba(78, 120, 151, 0.2)"
                      strokeWidth="1.5"
                    />

                    {/* Yorkshire Boundary Contour Border (National Geographic feel) */}
                    <path
                      d="M 120,30 C 180,20 220,10 270,35 C 310,25 360,30 380,45 C 410,75 430,120 455,160 C 470,200 480,250 490,290 C 480,330 460,360 440,380 C 420,400 410,430 370,450 C 330,470 280,485 240,490 C 180,490 140,460 110,440 C 80,420 50,390 40,340 C 30,280 20,240 35,180 C 50,140 70,80 120,30 Z"
                      fill="none"
                      stroke="var(--color-minster-gold)"
                      strokeWidth="2"
                      strokeDasharray="6 4"
                      opacity="0.55"
                    />

                    {/* Shaded Valleys Terrain Areas */}
                    {/* Dales Area Green overlay */}
                    <path
                      d="M 60,80 Q 150,110 180,180 T 210,320 T 110,350 Z"
                      fill="rgba(94, 111, 90, 0.09)"
                    />
                    {/* Moors Area purple shading */}
                    <path
                      d="M 280,120 Q 380,140 400,210 T 350,330 T 250,250 Z"
                      fill="rgba(116, 107, 140, 0.08)"
                    />

                    {/* Estuary Humber Waterway line */}
                    <path
                      d="M 370,450 Q 420,440 460,465 T 500,480"
                      fill="none"
                      stroke="rgba(78, 120, 151, 0.5)"
                      strokeWidth="4"
                    />

                    {/* Map Labels */}
                    <text x="32%" y="24%" fill="rgba(94, 111, 90, 0.4)" fontSize="10" fontWeight="bold" letterSpacing="2" className="pointer-events-none">YORKSHIRE DALES</text>
                    <text x="58%" y="22%" fill="rgba(116, 107, 140, 0.4)" fontSize="10" fontWeight="bold" letterSpacing="2" className="pointer-events-none">NORTH YORK MOORS</text>
                    <text x="76%" y="48%" fill="rgba(78, 120, 151, 0.4)" fontSize="10" fontWeight="bold" letterSpacing="2" className="pointer-events-none">HERITAGE COAST</text>
                  </svg>

                  {/* Render Feature Markers (pushed onto grid using absolute percentage) */}
                  {MAP_FEATURES.map((feature) => {
                    const isFilterActive = activeFilters.includes(feature.category);
                    if (!isFilterActive) return null;

                    const isSelected = selectedFeature?.id === feature.id;
                    return (
                      <button
                        key={feature.id}
                        id={`map-marker-${feature.id}`}
                        onClick={() => setSelectedFeature(feature)}
                        className="absolute z-20 focus:outline-none -translate-x-1/2 -translate-y-1/2 group cursor-pointer"
                        style={{ left: `${feature.x}%`, top: `${feature.y}%` }}
                      >
                        {/* Selected Indicator Ripple */}
                        {isSelected && (
                          <motion.span
                            layoutId="markerPulse"
                            className="absolute -inset-4 rounded-full bg-minster-gold/25 block border border-minster-gold/40"
                            animate={{ scale: [1, 1.4, 1] }}
                            transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                          />
                        )}

                        {/* Interactive Marker Pin */}
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center border shadow-md transition-all duration-300 ${
                            isSelected
                              ? "bg-minster-gold text-white border-white scale-125"
                              : "bg-white dark:bg-yorkshire-slate border-yorkshire-slate/20 dark:border-white/10 text-yorkshire-slate dark:text-yorkshire-stone group-hover:bg-minster-gold group-hover:text-white"
                          }`}
                        >
                          <MapPin className="w-3.5 h-3.5" />
                        </div>

                        {/* Hover Name Overlay Tooltip */}
                        <span className="absolute left-1/2 -translate-x-1/2 top-7 scale-0 group-hover:scale-100 bg-yorkshire-slate dark:bg-white text-yorkshire-stone dark:text-yorkshire-slate text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded shadow-lg whitespace-nowrap transition-transform duration-200 pointer-events-none">
                          {feature.name}
                        </span>
                      </button>
                    );
                  })}
                </motion.div>
              </div>
            </div>
          </div>

          {/* Column 3: Sidebar Details Console (Span 3) */}
          <div className="lg:col-span-3">
            <AnimatePresence mode="wait">
              {selectedFeature ? (
                <motion.div
                  key={selectedFeature.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.35 }}
                  className="bg-white/40 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 p-6 rounded-2xl h-full flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    {/* Feature Image Header */}
                    <div className="relative aspect-16/10 rounded-xl overflow-hidden bg-yorkshire-slate/15">
                      <img
                        src={selectedFeature.image}
                        alt={selectedFeature.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute top-3 left-3 px-2 py-0.5 bg-yorkshire-slate/80 text-white rounded text-[8px] font-bold uppercase tracking-wider font-mono">
                        {selectedFeature.category.replace("-", " ")}
                      </span>
                    </div>

                    <div>
                      <h4 className="font-serif text-xl font-bold text-yorkshire-slate dark:text-white leading-tight mb-2">
                        {selectedFeature.name}
                      </h4>
                      <p className="text-xs text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
                        {selectedFeature.description}
                      </p>
                    </div>

                    <div className="h-px bg-yorkshire-slate/10 dark:bg-white/10" />

                    {selectedFeature.specialty && (
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-widest text-yorkshire-slate/40 dark:text-yorkshire-stone/40 block mb-1">
                          Key Highlight
                        </span>
                        <div className="flex items-center space-x-2 text-xs font-semibold text-yorkshire-slate dark:text-white">
                          <Sparkles className="w-3.5 h-3.5 text-minster-gold" />
                          <span>{selectedFeature.specialty}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="pt-6">
                    <button
                      onClick={() => {
                        const target = document.getElementById("planner");
                        target?.scrollIntoView({ behavior: "smooth" });
                      }}
                      className="w-full py-2.5 bg-yorkshire-slate dark:bg-yorkshire-stone hover:bg-minster-gold dark:hover:bg-minster-gold hover:text-white dark:hover:text-white text-yorkshire-stone dark:text-yorkshire-slate text-[10px] font-bold uppercase tracking-widest text-center rounded-lg transition-colors cursor-pointer"
                    >
                      Plan Route Stops
                    </button>
                  </div>
                </motion.div>
              ) : (
                <div className="bg-white/40 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 p-6 rounded-2xl h-full flex flex-col items-center justify-center text-center">
                  <Compass className="w-8 h-8 text-minster-gold mb-3 animate-spin" />
                  <p className="text-xs text-yorkshire-slate/60 dark:text-yorkshire-stone/60">
                    Select any coordinate marker on the map to display topographical context.
                  </p>
                </div>
              )}
            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
}
