import { useState } from "react";
import { Utensils, Star, ShoppingBag, ShieldAlert, Coffee, Compass, Sparkles, BookOpen, Clock } from "lucide-react";
import { FOOD_SPOTS, FoodSpot } from "../types";
import { motion, AnimatePresence } from "motion/react";

export default function YorkshireFood() {
  const [selectedType, setSelectedType] = useState<string>("all");
  const [puddingStep, setPuddingStep] = useState<number>(0);

  const filterTabs = [
    { id: "all", label: "All Culinary Spots" },
    { id: "michelin", label: "Fine Dining" },
    { id: "tea-room", label: "Tea Rooms" },
    { id: "farm-shop", label: "Farm Shops" },
    { id: "pub", label: "Coastal & Pubs" }
  ];

  const filteredSpots = selectedType === "all"
    ? FOOD_SPOTS
    : FOOD_SPOTS.filter((s) => s.type === selectedType);

  const recipeSteps = [
    {
      title: "The Batter Whisk",
      desc: "Whisk 4 large free-range eggs, 140g plain flour, and 200ml milk together until completely smooth. Season with a pinch of salt and black pepper."
    },
    {
      title: "The Rest & Chill",
      desc: "Pour batter into a jug and rest at room temperature (or chill in fridge) for at least 30 minutes. This relaxes the gluten, ensuring massive rises."
    },
    {
      title: "The Searing Fat Heat",
      desc: "Preheat oven to 230°C / Gas 8. Drizzle beef dripping or vegetable oil into a 12-hole muffin tray. Place tray in oven for 10 mins until fat smoking hot."
    },
    {
      title: "The Hot Pour & Bake",
      desc: "Carefully pull out tray, quickly pour batter into holes, and return to oven immediately. Bake for 20-25 mins. Do NOT open oven door!"
    }
  ];

  return (
    <section id="food" className="py-24 md:py-32 bg-yorkshire-stone dark:bg-yorkshire-slate border-t border-yorkshire-slate/10 dark:border-white/10">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Title Block */}
        <div className="mb-16 text-left max-w-3xl">
          <span className="text-xs uppercase font-bold tracking-[0.25em] text-minster-gold block mb-3">
            GASTRONOMY CAPITAL
          </span>
          <h2 className="font-serif text-4xl md:text-6xl font-bold tracking-tight text-yorkshire-slate dark:text-white leading-tight mb-6">
            A Taste of God's Own County
          </h2>
          <p className="text-base md:text-lg text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light">
            With more Michelin stars than any other English region outside London, Yorkshire blends grand high-end farm estates with bustling coastal harbors, historic tea rooms, and century-old local farm shops.
          </p>
        </div>

        {/* Directory Filters */}
        <div className="flex flex-wrap items-center gap-2 mb-12 overflow-x-auto pb-4 hide-scrollbar">
          {filterTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedType(tab.id)}
              className={`px-5 py-2.5 rounded-full text-xs font-semibold uppercase tracking-wider transition-all duration-300 relative cursor-pointer focus:outline-none ${
                selectedType === tab.id
                  ? "text-white bg-yorkshire-slate dark:bg-yorkshire-stone dark:text-yorkshire-slate shadow-md"
                  : "text-yorkshire-slate/60 dark:text-yorkshire-stone/60 hover:text-yorkshire-slate dark:hover:text-white hover:bg-yorkshire-slate/5 dark:hover:bg-white/5"
              }`}
            >
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Food Spots Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20"
        >
          <AnimatePresence mode="popLayout">
            {filteredSpots.map((spot) => (
              <motion.div
                layout
                key={spot.id}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.4 }}
                className="bg-white/50 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 rounded-2xl p-6 md:p-8 flex flex-col sm:flex-row gap-6 md:gap-8 items-start hover:shadow-lg hover:bg-white dark:hover:bg-white/10 transition-all duration-300"
              >
                {/* Left image column */}
                <div className="w-full sm:w-40 h-40 rounded-xl overflow-hidden bg-yorkshire-slate/10 flex-shrink-0 relative">
                  <img
                    src={spot.image}
                    alt={spot.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute bottom-2 left-2 px-2 py-0.5 bg-black/60 backdrop-blur-sm text-white rounded text-[8px] font-bold uppercase tracking-wider">
                    {spot.type}
                  </span>
                </div>

                {/* Right text details column */}
                <div className="flex-1 flex flex-col justify-between h-full">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-minster-gold">
                        {spot.location}
                      </span>
                      {spot.type === "michelin" && (
                        <div className="flex text-minster-gold">
                          <Star className="w-3.5 h-3.5 fill-current" />
                          <Star className="w-3.5 h-3.5 fill-current" />
                        </div>
                      )}
                    </div>
                    
                    <h3 className="font-serif text-xl font-bold text-yorkshire-slate dark:text-white leading-tight mb-2">
                      {spot.name}
                    </h3>
                    
                    <p className="text-xs text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light mb-4">
                      {spot.description}
                    </p>
                  </div>

                  <div className="bg-yorkshire-stone/50 dark:bg-black/20 p-3 rounded-xl border border-yorkshire-slate/5 dark:border-white/5">
                    <span className="text-[9px] uppercase font-bold tracking-widest text-yorkshire-slate/40 dark:text-yorkshire-stone/40 block mb-0.5">
                      Signature Specialty
                    </span>
                    <p className="text-xs font-semibold text-yorkshire-slate dark:text-white flex items-center">
                      <Utensils className="w-3.5 h-3.5 mr-2 text-minster-gold" />
                      {spot.specialty}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Immersive Editorial Highlight: Yorkshire Pudding Recipe Panel */}
        <div className="bg-white/45 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 rounded-3xl p-8 md:p-12 shadow-xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left instructions block */}
          <div className="lg:col-span-7">
            <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-minster-gold mb-4">
              <Sparkles className="w-4 h-4 animate-pulse" />
              <span>NATIVE KITCHEN CLASSIC</span>
            </div>
            
            <h3 className="font-serif text-3xl md:text-4xl font-bold text-yorkshire-slate dark:text-white mb-2 tracking-tight">
              Traditional Yorkshire Pudding
            </h3>
            <p className="text-sm text-yorkshire-slate/70 dark:text-yorkshire-stone/70 leading-relaxed font-light mb-8">
              The secret to God's own pudding lies in searingly hot beef dripping and resting the batter. Master the ancient regional art of the perfect massive rise with our interactive guide.
            </p>

            {/* Recipe Steps navigation */}
            <div className="relative border-l border-minster-gold/30 pl-6 space-y-6">
              {recipeSteps.map((step, idx) => {
                const isActive = puddingStep === idx;
                return (
                  <button
                    key={idx}
                    onClick={() => setPuddingStep(idx)}
                    className="w-full text-left focus:outline-none cursor-pointer block relative group py-1"
                  >
                    {/* Floating circular number indicator */}
                    <span
                      className={`absolute -left-[31px] top-1.5 w-4 h-4 rounded-full border flex items-center justify-center text-[8px] font-mono font-bold transition-all ${
                        isActive
                          ? "bg-minster-gold text-white border-minster-gold scale-125 shadow-md"
                          : "bg-white dark:bg-yorkshire-slate border-yorkshire-slate/30 dark:border-white/10 text-yorkshire-slate/50 dark:text-yorkshire-stone/50 group-hover:border-minster-gold"
                      }`}
                    >
                      {idx + 1}
                    </span>

                    <h4 className={`text-sm font-bold ${isActive ? "text-minster-gold" : "text-yorkshire-slate/60 dark:text-yorkshire-stone/60 group-hover:text-minster-gold"} transition-colors`}>
                      {step.title}
                    </h4>
                    
                    {isActive && (
                      <p className="text-xs text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light mt-1.5">
                        {step.desc}
                      </p>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right graphics/illustration card */}
          <div className="lg:col-span-5 h-[280px] rounded-2xl overflow-hidden relative border border-yorkshire-slate/10 dark:border-white/5 bg-yorkshire-slate flex items-center justify-center">
            <img
              src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&q=80&w=800"
              alt="Golden Yorkshire Puddings rising"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover brightness-65"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
            <div className="absolute bottom-6 left-6 text-white max-w-xs">
              <span className="text-[9px] font-bold uppercase tracking-widest text-minster-gold flex items-center">
                <Clock className="w-3 h-3 mr-1" />
                Prep: 15 mins · Bake: 20 mins
              </span>
              <p className="font-serif font-bold text-sm mt-1">
                "A true Yorkshire pudding must be tall, airy, golden, and possess a deep crisp cup for rich beef gravy."
              </p>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
