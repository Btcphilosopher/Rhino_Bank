import { useState, FormEvent } from "react";
import { Calendar, Tag, MapPin, X, Plus, Minus, CreditCard, CheckCircle, Ticket, Printer, Compass, Sparkles } from "lucide-react";
import { EVENTS, EventItem } from "../types";
import { motion, AnimatePresence } from "motion/react";

export default function EventsCalendar() {
  const [selectedEvent, setSelectedEvent] = useState<EventItem | null>(null);
  const [ticketCount, setTicketCount] = useState<number>(1);
  const [ticketHolder, setTicketHolder] = useState<string>("");
  const [bookingConfirmed, setBookingConfirmed] = useState<boolean>(false);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const categories = [
    { id: "all", label: "All Events" },
    { id: "culture", label: "Civic & Culture" },
    { id: "food", label: "Gastronomy" },
    { id: "sport", label: "Outdoor Sport" }
  ];

  const filteredEvents = selectedCategory === "all"
    ? EVENTS
    : EVENTS.filter((e) => e.category === selectedCategory);

  const calculateTotal = (priceStr: string) => {
    if (priceStr.toLowerCase().includes("free")) return "Free";
    const numeric = parseFloat(priceStr.replace(/[^0-9.]/g, ""));
    if (isNaN(numeric)) return priceStr;
    return `£${(numeric * ticketCount).toFixed(2)}`;
  };

  const handleBookSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!ticketHolder.trim()) return;
    setBookingConfirmed(true);
  };

  const handleCloseModal = () => {
    setSelectedEvent(null);
    setTicketCount(1);
    setTicketHolder("");
    setBookingConfirmed(false);
  };

  return (
    <section id="events" className="py-24 md:py-32 bg-yorkshire-stone dark:bg-yorkshire-slate">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Title Section */}
        <div className="mb-16 md:mb-20 text-left max-w-3xl">
          <span className="text-xs uppercase font-bold tracking-[0.25em] text-minster-gold block mb-3">
            UPCOMING ON THE TIMELINE
          </span>
          <h2 className="font-serif text-4xl md:text-6xl font-bold tracking-tight text-yorkshire-slate dark:text-white leading-tight mb-6">
            Cultural Events Calendar
          </h2>
          <p className="text-base md:text-lg text-yorkshire-slate/75 dark:text-yorkshire-stone/75 leading-relaxed font-light font-sans">
            From majestic countryside county shows to bustling historic food assemblies, plan your journey around Yorkshire's most significant cultural landmarks and seasons.
          </p>
        </div>

        {/* Categories Tab */}
        <div className="flex flex-wrap items-center gap-2 mb-12 overflow-x-auto pb-4 hide-scrollbar">
          {categories.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedCategory(tab.id)}
              className={`px-5 py-2.5 rounded-full text-xs font-semibold uppercase tracking-wider transition-all duration-300 relative cursor-pointer focus:outline-none border ${
                selectedCategory === tab.id
                  ? "text-yorkshire-stone bg-yorkshire-slate dark:bg-yorkshire-stone dark:text-yorkshire-slate border-yorkshire-slate dark:border-yorkshire-stone shadow-sm"
                  : "text-yorkshire-slate/70 dark:text-yorkshire-stone/70 border-yorkshire-slate/15 dark:border-white/10 hover:bg-yorkshire-slate/5 dark:hover:bg-white/5 hover:text-yorkshire-slate"
              }`}
            >
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Elegant Timeline Cards */}
        <div className="space-y-6">
          <AnimatePresence mode="popLayout">
            {filteredEvents.map((item, idx) => (
              <motion.div
                layout
                key={item.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.45, delay: idx * 0.05 }}
                className="bg-white/40 dark:bg-white/5 border border-yorkshire-slate/10 dark:border-white/5 p-6 rounded-2xl flex flex-col lg:flex-row items-stretch gap-6 md:gap-8 hover:bg-white dark:hover:bg-white/10 transition-all duration-300 shadow-sm"
              >
                {/* Visual Date Badge (Left) */}
                <div className="flex flex-col items-center justify-center bg-yorkshire-stone dark:bg-black/20 p-6 rounded-xl border border-yorkshire-slate/5 dark:border-white/5 w-full lg:w-32 flex-shrink-0 text-center min-h-[110px]">
                  <span className="text-[10px] font-bold tracking-[0.3em] uppercase text-minster-gold">
                    {item.month}
                  </span>
                  <span className="font-serif text-3xl font-extrabold text-yorkshire-slate dark:text-white mt-1 leading-none">
                    {item.date.match(/\d+/)?.[0]}
                  </span>
                  <span className="text-[9px] font-mono opacity-50 mt-1 uppercase font-bold">2026</span>
                </div>

                {/* Event Photo Frame */}
                <div className="w-full lg:w-44 h-44 lg:h-auto min-h-[140px] rounded-xl overflow-hidden bg-yorkshire-slate/10 flex-shrink-0 relative">
                  <img
                    src={item.image}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2 px-2.5 py-0.5 bg-black/60 text-white rounded text-[8px] font-bold uppercase tracking-wider font-mono">
                    {item.category}
                  </div>
                </div>

                {/* Event text details */}
                <div className="flex-1 flex flex-col justify-between py-1">
                  <div>
                    <h3 className="font-serif text-2xl font-bold text-yorkshire-slate dark:text-white tracking-tight mb-2 leading-tight">
                      {item.title}
                    </h3>
                    
                    <p className="text-xs text-yorkshire-slate/75 dark:text-yorkshire-stone/75 font-light leading-relaxed mb-4 max-w-2xl">
                      {item.description}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-y-3 gap-x-6 text-xs text-yorkshire-slate/60 dark:text-yorkshire-stone/60">
                    <span className="flex items-center">
                      <MapPin className="w-4 h-4 mr-1.5 text-minster-gold" />
                      {item.location}
                    </span>
                    <span className="flex items-center">
                      <Calendar className="w-4 h-4 mr-1.5 text-minster-gold" />
                      {item.date}
                    </span>
                    <span className="flex items-center font-mono font-bold text-minster-gold">
                      <Tag className="w-4 h-4 mr-1.5" />
                      {item.price}
                    </span>
                  </div>
                </div>

                {/* Button Action Block (Right) */}
                <div className="flex items-center justify-start lg:justify-end flex-shrink-0">
                  <button
                    onClick={() => setSelectedEvent(item)}
                    className="w-full lg:w-auto px-6 py-3.5 rounded-xl bg-yorkshire-slate dark:bg-yorkshire-stone text-yorkshire-stone dark:text-yorkshire-slate hover:bg-minster-gold dark:hover:bg-minster-gold hover:text-white dark:hover:text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                  >
                    Book Passes
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Booking & Checkout Interactive Overlay Modal */}
        <AnimatePresence>
          {selectedEvent && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-yorkshire-slate/75 dark:bg-black/85 backdrop-blur-sm flex items-center justify-center p-6"
              onClick={handleCloseModal}
            >
              <motion.div
                initial={{ scale: 0.95, y: 15 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 15 }}
                className="bg-yorkshire-stone dark:bg-yorkshire-slate rounded-2xl overflow-hidden shadow-2xl max-w-lg w-full border border-yorkshire-slate/10 dark:border-white/15 p-8 relative"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button */}
                <button
                  onClick={handleCloseModal}
                  className="absolute top-6 right-6 p-2 rounded-full hover:bg-yorkshire-slate/5 dark:hover:bg-white/10 text-yorkshire-slate/70 dark:text-yorkshire-stone/70 z-10 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>

                {!bookingConfirmed ? (
                  /* Form State */
                  <form onSubmit={handleBookSubmit} className="space-y-6">
                    <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-minster-gold">
                      <Ticket className="w-4 h-4" />
                      <span>Pass Reservation</span>
                    </div>

                    <div>
                      <span className="text-[10px] uppercase font-bold text-yorkshire-slate/40 dark:text-yorkshire-stone/40 font-mono">SELECTED ASSEMBLY</span>
                      <h3 className="font-serif text-2xl font-bold text-yorkshire-slate dark:text-white leading-tight mt-1">
                        {selectedEvent.title}
                      </h3>
                      <p className="text-xs text-yorkshire-slate/60 dark:text-yorkshire-stone/60 flex items-center mt-2">
                        <MapPin className="w-3.5 h-3.5 mr-1 text-minster-gold" />
                        {selectedEvent.location}
                      </p>
                    </div>

                    <div className="h-px bg-yorkshire-slate/10 dark:bg-white/10" />

                    {/* Step 1: Holder Name */}
                    <div>
                      <label className="block text-xs uppercase font-extrabold tracking-widest text-yorkshire-slate/50 dark:text-yorkshire-stone/50 mb-2">
                        Lead Ticket Holder
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g., Charlotte Brontë"
                        value={ticketHolder}
                        onChange={(e) => setTicketHolder(e.target.value)}
                        className="w-full bg-white dark:bg-white/5 border border-yorkshire-slate/20 dark:border-white/10 rounded-xl px-4 py-3 text-xs text-yorkshire-slate dark:text-white"
                      />
                    </div>

                    {/* Step 2: Quantity selector */}
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="block text-xs uppercase font-extrabold tracking-widest text-yorkshire-slate/50 dark:text-yorkshire-stone/50">
                          Pass Quantity
                        </label>
                        <span className="text-[10px] text-yorkshire-slate/40 dark:text-yorkshire-stone/40">Max 6 per booking</span>
                      </div>
                      <div className="flex items-center space-x-3 bg-white dark:bg-white/5 border border-yorkshire-slate/20 dark:border-white/10 p-2 rounded-xl">
                        <button
                          type="button"
                          onClick={() => setTicketCount((c) => Math.max(1, c - 1))}
                          className="p-1.5 rounded-lg hover:bg-yorkshire-stone/50 dark:hover:bg-white/10 text-yorkshire-slate dark:text-white cursor-pointer"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="w-6 text-center text-xs font-bold text-yorkshire-slate dark:text-white font-mono">{ticketCount}</span>
                        <button
                          type="button"
                          onClick={() => setTicketCount((c) => Math.min(6, c + 1))}
                          className="p-1.5 rounded-lg hover:bg-yorkshire-stone/50 dark:hover:bg-white/10 text-yorkshire-slate dark:text-white cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Pricing summary */}
                    <div className="bg-white/50 dark:bg-black/20 p-4 rounded-xl border border-yorkshire-slate/5 dark:border-white/5 flex items-center justify-between">
                      <div>
                        <span className="text-[9px] uppercase font-bold tracking-widest text-yorkshire-slate/40 dark:text-yorkshire-stone/40 block">Unit Cost: {selectedEvent.price}</span>
                        <span className="text-xs font-bold text-yorkshire-slate dark:text-white mt-1 block">Total Reservation Fee</span>
                      </div>
                      <span className="text-xl font-serif font-extrabold text-minster-gold font-mono">
                        {calculateTotal(selectedEvent.price)}
                      </span>
                    </div>

                    {/* Book Action button */}
                    <button
                      type="submit"
                      className="w-full py-4 rounded-xl bg-minster-gold hover:bg-minster-gold/90 text-white text-xs font-bold uppercase tracking-widest flex items-center justify-center space-x-2 shadow-md cursor-pointer"
                    >
                      <CreditCard className="w-4 h-4" />
                      <span>Confirm Reservation</span>
                    </button>
                  </form>
                ) : (
                  /* Success / Pass E-ticket screen */
                  <div className="space-y-6 text-center">
                    <div className="w-12 h-12 rounded-full bg-moorland-green/15 text-moorland-green flex items-center justify-center mx-auto mb-4 border border-moorland-green/20">
                      <CheckCircle className="w-6 h-6" />
                    </div>

                    <div>
                      <span className="text-[10px] uppercase font-bold text-moorland-green tracking-widest block mb-1">RESERVATION SECURED</span>
                      <h3 className="font-serif text-2xl font-bold text-yorkshire-slate dark:text-white leading-tight">
                        You're Heading to Yorkshire!
                      </h3>
                      <p className="text-xs text-yorkshire-slate/60 dark:text-yorkshire-stone/60 mt-2 max-w-sm mx-auto">
                        Your official regional pass barcode is registered under your name. Take a screenshot or print this pass for entry.
                      </p>
                    </div>

                    {/* High-fidelity Ticket Graphic */}
                    <div className="bg-white text-yorkshire-slate p-6 rounded-xl border border-yorkshire-slate/10 shadow-lg text-left relative overflow-hidden font-sans">
                      {/* Left and right notch cutouts for coupon look */}
                      <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-3 w-6 h-6 rounded-full bg-yorkshire-stone dark:bg-yorkshire-slate" />
                      <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-3 w-6 h-6 rounded-full bg-yorkshire-stone dark:bg-yorkshire-slate" />

                      <div className="flex justify-between items-start border-b border-dashed border-yorkshire-slate/20 pb-4 mb-4">
                        <div>
                          <span className="text-[8px] font-bold uppercase tracking-widest text-minster-gold block">Official Assembly Ticket</span>
                          <span className="font-serif text-base font-extrabold">{selectedEvent.title}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-[8px] uppercase tracking-wider block opacity-50">E-TICKET NO.</span>
                          <span className="text-xs font-mono font-bold text-yorkshire-slate">#YORK-{Math.floor(Math.random() * 90000) + 10000}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-y-4 gap-x-2 text-[10px] pb-4 border-b border-dashed border-yorkshire-slate/20 mb-4">
                        <div>
                          <span className="opacity-50 block uppercase">Lead Holder</span>
                          <span className="font-bold">{ticketHolder}</span>
                        </div>
                        <div>
                          <span className="opacity-50 block uppercase">Quantity</span>
                          <span className="font-bold">{ticketCount} Passes</span>
                        </div>
                        <div>
                          <span className="opacity-50 block uppercase">Date & Assembly</span>
                          <span className="font-bold">{selectedEvent.date}</span>
                        </div>
                        <div>
                          <span className="opacity-50 block uppercase">Admission Paid</span>
                          <span className="font-bold font-mono text-minster-gold text-xs">{calculateTotal(selectedEvent.price)}</span>
                        </div>
                      </div>

                      {/* Barcode representation */}
                      <div className="flex flex-col items-center space-y-1">
                        <div className="w-full h-8 bg-[repeating-linear-gradient(90deg,black,black_2px,transparent_2px,transparent_6px,black_6px,black_10px,transparent_10px,transparent_12px)] opacity-85" />
                        <span className="text-[8px] font-mono opacity-50 uppercase font-bold tracking-[0.2em]">Barcode Verified</span>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex gap-3 pt-2">
                      <button
                        onClick={() => window.print()}
                        className="flex-1 py-3 border border-yorkshire-slate/20 dark:border-white/10 hover:border-minster-gold hover:text-minster-gold text-xs font-bold uppercase tracking-wider rounded-lg transition-colors cursor-pointer flex items-center justify-center space-x-2"
                      >
                        <Printer className="w-4 h-4" />
                        <span>Print Pass</span>
                      </button>
                      <button
                        onClick={handleCloseModal}
                        className="flex-1 py-3 bg-yorkshire-slate dark:bg-yorkshire-stone text-yorkshire-stone dark:text-yorkshire-slate text-xs font-bold uppercase tracking-wider rounded-lg transition-colors cursor-pointer"
                      >
                        Done
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
