import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Compass, Heart, MapPin, Calendar, HelpCircle, Utensils, BookOpen, ExternalLink, ArrowUp, Sparkles, Navigation as NavIcon } from "lucide-react";

// Curated custom-crafted components
import Navigation from "./components/Navigation";
import Hero from "./components/Hero";
import FeaturedDestinations from "./components/FeaturedDestinations";
import Experiences from "./components/Experiences";
import InteractiveMap from "./components/InteractiveMap";
import SeasonalInspiration from "./components/SeasonalInspiration";
import YorkshireFood from "./components/YorkshireFood";
import EventsCalendar from "./components/EventsCalendar";
import TripPlanner from "./components/TripPlanner";
import Accommodation from "./components/Accommodation";
import Travel from "./components/Travel";
import WildlifeAndHistory from "./components/WildlifeAndHistory";
import Blog from "./components/Blog";
import Newsletter from "./components/Newsletter";

export default function App() {
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem("yorkshire-theme");
    return saved === "dark" || (!saved && window.matchMedia("(prefers-color-scheme: dark)").matches);
  });
  const [activeSection, setActiveSection] = useState<string>("hero");
  const [showScrollTop, setShowScrollTop] = useState<boolean>(false);

  // Sync theme with root DOM
  useEffect(() => {
    const root = window.document.documentElement;
    if (darkMode) {
      root.classList.add("dark");
      localStorage.setItem("yorkshire-theme", "dark");
    } else {
      root.classList.remove("dark");
      localStorage.setItem("yorkshire-theme", "light");
    }
  }, [darkMode]);

  // Track active section and scroll top button
  useEffect(() => {
    const handleScroll = () => {
      // Show scroll-top button
      if (window.scrollY > 600) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }

      // Track active section on scroll
      const sections = [
        "hero",
        "destinations",
        "experiences",
        "map",
        "food",
        "planner",
        "stay",
        "wildlife-heritage",
        "blog"
      ];
      
      const currentScroll = window.scrollY + 200;
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (currentScroll >= top && currentScroll < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
      setActiveSection(id);
    }
  };

  return (
    <div className="min-h-screen bg-yorkshire-stone text-yorkshire-slate dark:bg-yorkshire-slate dark:text-yorkshire-stone font-sans selection:bg-minster-gold selection:text-white transition-colors duration-500">
      
      {/* Sticky Header Navigation Component */}
      <Navigation
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        activeSection={activeSection}
        scrollToSection={scrollToSection}
      />

      {/* Main Experience Flow */}
      <main className="relative z-10">
        
        {/* Parallax Slideshow Cinematic Hero */}
        <Hero scrollToSection={scrollToSection} />

        {/* Region Filtered Destinations Grid with custom Drawer */}
        <FeaturedDestinations />

        {/* Detailed Experiences Index */}
        <Experiences />

        {/* SVG Terrain Vector Map of landmarks */}
        <InteractiveMap />

        {/* Immersive Seasons Carousel switcher */}
        <SeasonalInspiration />

        {/* Michelin stars fine dining & Recipe card */}
        <YorkshireFood />

        {/* Events Calendar with ticket booking simulation */}
        <EventsCalendar />

        {/* AI Itinerary planning desk calling server endpoint */}
        <TripPlanner />

        {/* Stays & Accommodations with pricing concierge */}
        <Accommodation />

        {/* Live transport conditions & Electric Vehicle Grid */}
        <Travel />

        {/* History timelines & Native wildlife guides */}
        <WildlifeAndHistory />

        {/* Editorial Gazette articles block */}
        <Blog />

        {/* Newsletter & Official high-def brochures downloads */}
        <Newsletter />

      </main>

      {/* Premium Editorial Footer */}
      <footer id="footer" className="bg-yorkshire-slate text-white border-t border-white/5 py-20 relative overflow-hidden font-sans">
        {/* Ambient background styling */}
        <div className="absolute top-0 left-0 w-full h-full bg-radial-gradient(ellipse_at_top,rgba(199,161,86,0.03),transparent) pointer-events-none" />

        <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 pb-16 border-b border-white/10">
            
            {/* Column 1: Brand details (Span 5) */}
            <div className="lg:col-span-5 space-y-6 text-left">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full border-2 border-minster-gold flex items-center justify-center font-serif text-lg font-bold bg-white/5">
                  Y
                </div>
                <h3 className="font-serif text-2xl font-bold tracking-tight">
                  Visit <span className="text-minster-gold">Yorkshire</span>
                </h3>
              </div>
              <p className="text-xs md:text-sm text-yorkshire-stone/70 leading-relaxed font-light max-w-sm">
                Official guide to England's greatest county. Empowering regional tourism, preservation of wild habitats, drystone heritage, and local artisanal gastonomies.
              </p>
              <div className="text-[10px] uppercase font-mono font-bold tracking-wider text-minster-gold flex items-center">
                <Sparkles className="w-3.5 h-3.5 mr-2" />
                "Modern Yorkshire Supermodernism" Architecture
              </div>
            </div>

            {/* Column 2: Navigation directories (Span 3) */}
            <div className="lg:col-span-3 space-y-4 text-left">
              <h4 className="text-xs uppercase font-extrabold tracking-widest text-white/40 font-mono">
                Explore Content
              </h4>
              <ul className="space-y-2 text-xs text-yorkshire-stone/70">
                {["destinations", "experiences", "map", "food"].map((id) => (
                  <li key={id}>
                    <button
                      onClick={() => scrollToSection(id)}
                      className="hover:text-minster-gold transition-colors capitalize cursor-pointer focus:outline-none"
                    >
                      {id === "map" ? "Interactive Map" : id}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Column 3: Trip planning directories (Span 2) */}
            <div className="lg:col-span-2 space-y-4 text-left">
              <h4 className="text-xs uppercase font-extrabold tracking-widest text-white/40 font-mono">
                Reservations
              </h4>
              <ul className="space-y-2 text-xs text-yorkshire-stone/70">
                {["planner", "stay", "events", "travel"].map((id) => (
                  <li key={id}>
                    <button
                      onClick={() => scrollToSection(id)}
                      className="hover:text-minster-gold transition-colors capitalize cursor-pointer focus:outline-none"
                    >
                      {id === "stay" ? "Where to Stay" : id === "planner" ? "AI Trip Planner" : id}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Column 4: National Resources (Span 2) */}
            <div className="lg:col-span-2 space-y-4 text-left">
              <h4 className="text-xs uppercase font-extrabold tracking-widest text-white/40 font-mono">
                Partnerships
              </h4>
              <ul className="space-y-2 text-xs text-yorkshire-stone/70">
                <li><a href="https://www.nationaltrust.org.uk/" target="_blank" className="hover:text-minster-gold transition-all flex items-center">National Trust <ArrowUpRight className="w-3 h-3 ml-1" /></a></li>
                <li><a href="https://www.english-heritage.org.uk/" target="_blank" className="hover:text-minster-gold transition-all flex items-center">English Heritage <ArrowUpRight className="w-3 h-3 ml-1" /></a></li>
                <li><a href="https://www.yorkshirewildlifetrust.org.uk/" target="_blank" className="hover:text-minster-gold transition-all flex items-center">Wildlife Trust <ArrowUpRight className="w-3 h-3 ml-1" /></a></li>
              </ul>
            </div>

          </div>

          {/* Legal Bar */}
          <div className="pt-12 flex flex-col md:flex-row justify-between items-center text-[10px] md:text-xs text-yorkshire-stone/50 font-light font-sans gap-4">
            <p>© 2026 Visit Yorkshire Tourism Council. All rights reserved. Registered UK NGO Charity.</p>
            <div className="flex space-x-6">
              <a href="#" className="hover:text-white">Privacy Manifesto</a>
              <a href="#" className="hover:text-white">Editorial Guidelines</a>
              <a href="#" className="hover:text-white">Cookie Consent</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating Scroll to Top button */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="fixed bottom-6 right-6 z-40 p-3 rounded-full bg-minster-gold hover:bg-minster-gold/90 text-white shadow-xl hover:scale-105 transition-all cursor-pointer"
            title="Scroll to Top"
          >
            <ArrowUp className="w-5 h-5" />
          </motion.button>
        )}
      </AnimatePresence>

    </div>
  );
}

export function ArrowUpRight(props: any) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <line x1="7" y1="17" x2="17" y2="7" />
      <polyline points="7 7 17 7 17 17" />
    </svg>
  );
}
