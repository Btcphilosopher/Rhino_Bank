import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Google GenAI client lazily to prevent crashing on boot if key is missing
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
      aiClient = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
  }
  return aiClient;
}

// Robust fallback generator if Gemini API key is missing
function generateFallbackItinerary(days: number, budget: string, travelers: string, interests: string[]) {
  const isLuxury = budget === "luxury";
  const interestStr = interests.length > 0 ? interests.join(" & ") : "General Sightseeing";
  
  const activitiesByDay = [
    {
      theme: "Historical Foundations of York",
      activities: [
        {
          time: "09:00 - 12:00",
          title: "York Minster Gothic Masterpiece Cathedral",
          description: "Ascend the central tower for breathtaking panoramic views of York and explore the ancient undercroft museum.",
          location: "York Minster, Deangate, York",
          tip: "Book your tower climbing slot in advance, as places are strictly limited to prevent crowds."
        },
        {
          time: "12:30 - 14:30",
          title: "Walk the Medieval Walls & The Shambles",
          description: "Walk along the beautifully preserved Roman/medieval stone walls, then visit the cobblestone Shambles, the inspiration for Diagon Alley.",
          location: "The Shambles, York",
          tip: "Grab a hot roast pork sandwich from the Shambles Kitchen for an authentic local lunch."
        },
        {
          time: "15:00 - 17:30",
          title: "Jorvik Viking Centre Immersive Excavation",
          description: "Ride a revolutionary time-capsule back to the year 975 AD, smelling the turf fires and experiencing Viking Jórvík as it was unearthed by archaeologists.",
          location: "Jorvik Viking Centre, Coppergate, York",
          tip: "Pre-booking is highly recommended to secure fast-track entry."
        }
      ],
      accommodationRecommendation: isLuxury ? "Grantley Hall five-star estate" : "The Pheasant Inn Harome cozy boutique rooms",
      diningRecommendation: isLuxury ? "Tommy Banks' Michelin-starred Black Swan tasting menu" : "Betty's Café tea rooms traditional roast lunch"
    },
    {
      theme: "Untamed Peaks of the Yorkshire Dales",
      activities: [
        {
          time: "09:30 - 12:30",
          title: "The Majestic Limestone Cliffs of Malham Cove",
          description: "Hike up the spectacular limestone amphitheater. Walk across the dramatic pavement that featured in Harry Potter and look for nesting falcons.",
          location: "Malham, Skipton BD23 4DA",
          tip: "Arrive before 9 AM to secure a parking space in the national park visitor lot."
        },
        {
          time: "13:00 - 15:30",
          title: "Artesian Wensleydale Creamery & Cheese Tasting",
          description: "Travel to Hawes and witness traditional artisan cheesemaking. Taste the iconic Wensleydale and take home freshly made chutneys.",
          location: "Wensleydale Creamery, Hawes",
          tip: "Don't miss the warm cheese-on-toast flight at the onsite 1897 Coffee Shop."
        },
        {
          time: "16:00 - 18:00",
          title: "The Ribblehead Viaduct & Settle-Carlisle Railway",
          description: "Marvel at the spectacular Victorian engineering achievement of 24 massive stone arches framing the wild moorland peaks.",
          location: "Ribblehead Viaduct, Low Sleets",
          tip: "Catch the afternoon steam locomotive crossing if you plan your timing precisely!"
        }
      ],
      accommodationRecommendation: "Beckside traditional stone cottage or luxury lodge in Malham",
      diningRecommendation: "The George Inn at Hubberholme (historic favorite pub of J.B. Priestley)"
    },
    {
      theme: "Dramatic Coastal Cliffs & Ruins",
      activities: [
        {
          time: "09:00 - 11:30",
          title: "Whitby Abbey Gothic ruins exploration",
          description: "Climb the world-famous 199 steps leading from the town to the majestic clifftop ruins that inspired Bram Stoker's Dracula.",
          location: "Chinnery Walk, Whitby YO22 4DP",
          tip: "Touch-screen visual audio guides are included with admission, giving historical reenactments."
        },
        {
          time: "12:00 - 14:00",
          title: "Coastal Seafood Feast & Harbour Walk",
          description: "Stroll along the atmospheric fishing harbor and sample world-renowned Whitby smoked kippers or premium fish & chips.",
          location: "The Magpie Café, Whitby",
          tip: "The queue is long but moves fast; the coastal views from the top dining room are spectacular."
        },
        {
          time: "14:30 - 17:30",
          title: "Smugglers' Paths of Robin Hood's Bay",
          description: "Explore the narrow cliffside pathways, steep stone stairs, and hidden tunnels of this beautiful red-roofed coastal village.",
          location: "Robin Hood's Bay beach and village",
          tip: "Check the tide times before heading out on beach coastal walks to avoid getting cut off."
        }
      ],
      accommodationRecommendation: "Coastal luxury cottages or Raven Hall Country House Hotel on the cliffs",
      diningRecommendation: "The Star Inn The Harbour for exquisite fresh seafood"
    }
  ];

  // Construct itinerary according to requested number of days
  const daysArray = [];
  for (let i = 1; i <= days; i++) {
    const templateIndex = (i - 1) % activitiesByDay.length;
    const template = activitiesByDay[templateIndex];
    daysArray.push({
      dayNumber: i,
      theme: `Day ${i}: ${template.theme} (${interests[0] || "Exploring Yorkshire"})`,
      activities: template.activities,
      accommodationRecommendation: template.accommodationRecommendation,
      diningRecommendation: template.diningRecommendation
    });
  }

  return {
    title: `The Ultimate ${days}-Day ${travelers.toUpperCase()} Yorkshire Getaway`,
    summary: `A carefully designed ${days}-day itinerary tailored for ${travelers} looking to experience the absolute finest of Yorkshire's ${interestStr}. This curation captures the perfect harmony of historic towns, rugged peaks, and artisanal food.`,
    days: daysArray
  };
}

// API endpoint for AI Itinerary Builder
app.post("/api/plan-itinerary", async (req, res) => {
  const { days, budget, travelers, interests } = req.body;
  
  const parsedDays = parseInt(days) || 3;
  const parsedBudget = budget || "standard";
  const parsedTravelers = travelers || "couple";
  const parsedInterests = Array.isArray(interests) ? interests : ["Walking", "History"];

  const client = getAiClient();
  
  if (!client) {
    console.log("No valid GEMINI_API_KEY detected. Returning high-quality curated fallback itinerary.");
    const fallback = generateFallbackItinerary(parsedDays, parsedBudget, parsedTravelers, parsedInterests);
    return res.json({ source: "fallback", itinerary: fallback });
  }

  try {
    const prompt = `
Generate a world-class, premium, detailed travel itinerary for a visitor to Yorkshire, England.
Trip details:
- Number of Days: ${parsedDays}
- Budget Level: ${parsedBudget} (budget, standard, luxury)
- Traveler Type: ${parsedTravelers} (solo, couple, family, friends)
- Interests: ${parsedInterests.join(", ")}

The response must be in English. Provide rich, highly descriptive narrative descriptions for each activity. Do not use boring generic recommendations. Give actual, real names of Yorkshire spots (e.g. Fountains Abbey, Betty's Harrogate, Malham Cove, Robin Hood's Bay, York Shambles, North Yorkshire Moors Railway, etc.). Make it sound highly curated, like National Geographic, Airbnb, and Monocle.

Return the JSON matching the specified schema.
`;

    const response = await client.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are an elite, award-winning travel editor and Yorkshire native who crafts highly exclusive, visually poetic, and practically detailed travel itineraries.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: "Elegant title of the trip" },
            summary: { type: Type.STRING, description: "Inspiring executive summary of the journey" },
            days: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  dayNumber: { type: Type.INTEGER },
                  theme: { type: Type.STRING, description: "Theme of this day (e.g. Wild Coasts & Goth Legends)" },
                  activities: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        time: { type: Type.STRING, description: "Time of day (e.g., 09:00 - 12:00)" },
                        title: { type: Type.STRING, description: "Fascinating name of the activity" },
                        description: { type: Type.STRING, description: "Immersive narrative describing the sight, smells, history, and exact experience of this stop" },
                        location: { type: Type.STRING, description: "Detailed location or address in Yorkshire" },
                        tip: { type: Type.STRING, description: "Expert native travel tip" }
                      },
                      required: ["time", "title", "description", "location"]
                    }
                  },
                  accommodationRecommendation: { type: Type.STRING, description: "Curated premium accommodation recommendation" },
                  diningRecommendation: { type: Type.STRING, description: "Curated gourmet dining recommendation matching the day's area" }
                },
                required: ["dayNumber", "theme", "activities"]
              }
            }
          },
          required: ["title", "summary", "days"]
        }
      }
    });

    if (response.text) {
      const data = JSON.parse(response.text.trim());
      return res.json({ source: "gemini", itinerary: data });
    } else {
      throw new Error("Empty response received from Gemini API");
    }

  } catch (error) {
    console.error("Gemini API error:", error);
    // If Gemini fails, gracefully fallback so the site is never broken
    const fallback = generateFallbackItinerary(parsedDays, parsedBudget, parsedTravelers, parsedInterests);
    return res.json({ source: "fallback_due_to_error", itinerary: fallback, error: String(error) });
  }
});

// Setup Vite & static assets serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Setting up Vite development server middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Running in Production. Serving static files from /dist...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Visit Yorkshire full-stack server running on http://localhost:${PORT}`);
  });
}

startServer();
