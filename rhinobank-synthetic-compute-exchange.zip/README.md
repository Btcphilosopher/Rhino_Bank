# RhinoBank Synthetic Compute Derivatives Market (RB-SCDM)
**Platform Identifier:** `RB-SCDM` | **API Namespace:** `/api/v1` | **Environment:** `SIMULATION`

Institutional-grade market infrastructure and quantitative valuation platform for financial contracts referenced to compute-capacity economics, GPU accelerator-hours, regional basis, and inference-workload benchmarks.

---

## Architecture Overview

```
                      ┌──────────────────────────────────────────────┐
                      │    Institutional API Gateway (/api/v1)       │
                      └───────┬───────────────────────────────┬──────┘
                              │                               │
              ┌───────────────▼──────────────┐ ┌──────────────▼──────────────┐
              │ Rust Market Core Engine      │ │ Python Quant Pricing Engine  │
              │ - Order Book & CLOB Matching │ │ - Black-76 European Options  │
              │ - Bilateral OTC RFQ Desk     │ │ - Fixed-Float Swap Cashflows │
              │ - Pre-Trade Risk Checks      │ │ - Forward Curve Construction │
              │ - Deterministic Audit Trail  │ │ - Basis & Structured Payoffs │
              └───────────────┬──────────────┘ └──────────────┬──────────────┘
                              │                               │
                              └───────────────┬───────────────┘
                                              │
              ┌───────────────────────────────▼──────────────────────────────┐
              │ PostgreSQL 16 Durable State & Time-Series Observations       │
              └───────────────────────────────┬──────────────────────────────┘
                                              │
                              ┌───────────────▼──────────────┐
                              │ R Statistical Validation     │
                              │ - Volatility Estimation (GARCH)
                              │ - Regional Cointegration (ECM)│
                              │ - Payoff Distribution Tests  │
                              └──────────────────────────────┘
```

## System Components

1. **Rust Market Core (`services/market-core`)**:
   - Deterministic matching engine (price-time priority).
   - Invariant preservation: executed quantity cannot exceed accepted quantity.
   - Pre-trade risk enforcement (notional, collars, position limits).
   - Authoritative contract lifecycle transitions.
   - Cryptographic audit trail hashing.

2. **Python Quantitative Pricing Engine (`services/pricing`)**:
   - Pydantic v2 schemas and FastAPI endpoints.
   - Black-76 option pricing and analytical Greeks ($\Delta, \Gamma, \mathcal{V}, \Theta$).
   - Forward valuation for non-storable compute services:
     $$\text{Payoff} = q \cdot m \cdot (P_{\text{final}} - K)$$
   - Fixed-vs-floating swap schedules with compounding observation windows.
   - Regional & hardware basis spreads (LON vs FRA, H100 vs B200).

3. **R Statistical Validation (`analytics/r`)**:
   - Compute price volatility estimation and clustering tests.
   - Regional cointegration and basis mean-reversion analysis.
   - Risk measure and VaR backtesting.

4. **Database & Migrations (`db/migrations`)**:
   - PostgreSQL schema with exact `NUMERIC(18, 6)` arithmetic precision (no floating-point cash errors).
   - Versioned instruments, orders, trades, contracts, valuations, and audit events.

5. **Android Executive Terminal (`app/`)**:
   - Jetpack Compose M3 institutional platform for live simulation, order entry, RFQ desk, quantitative calculator, risk monitor, and audit log.

---

## Quickstart & Local Execution

### 1. Run Services with Docker Compose

```bash
# Start PostgreSQL, Rust Market Core, Python Pricing Service
docker-compose up -d --build

# Run database migrations and load deterministic seed data
docker-compose exec -T postgres psql -U rhinobank -d rb_scdm < db/migrations/001_initial_schema.sql
docker-compose exec -T postgres psql -U rhinobank -d rb_scdm < db/seeds/seed_market_data.sql
```

### 2. Verify Service Health

```bash
# Check Rust Market Core
curl -s http://localhost:8080/health | jq .

# Check Python Pricing Service
curl -s http://localhost:8000/health | jq .
```

### 3. Run Sample Institutional Client

```bash
python3 examples/clients/institutional_client.py
```

### 4. Run Quantitative Tests

```bash
# Python tests
pytest services/pricing/tests/ -v

# Rust tests
cargo test --manifest-path services/market-core/Cargo.toml
```
