package com.example

import com.example.engine.MarketEngine
import com.example.model.Order
import com.example.model.OrderSide
import com.example.model.OrderStatus
import com.example.quant.QuantEngine
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testBlack76CallAndPutGreeks() {
        val forwardPrice = 3.35
        val strike = 3.40
        val vol = 0.42
        val tenor = 0.25
        val r = 0.045

        val call = QuantEngine.priceBlack76(forwardPrice, strike, vol, tenor, r, isCall = true, quantity = 1, contractMultiplier = 1000)
        val put = QuantEngine.priceBlack76(forwardPrice, strike, vol, tenor, r, isCall = false, quantity = 1, contractMultiplier = 1000)

        // Prices must be strictly positive
        assertTrue("Call price must be positive", call.pricePerUnit > 0.0)
        assertTrue("Put price must be positive", put.pricePerUnit > 0.0)

        // Greeks bounds
        assertTrue("Call Delta must be between 0 and 1", call.delta in 0.0..1.0)
        assertTrue("Put Delta must be between -1 and 0", put.delta in -1.0..0.0)
        assertTrue("Gamma must be positive", call.gamma > 0.0)
        assertTrue("Vega must be positive", call.vega > 0.0)

        // Put-Call Parity for Futures/Forwards: C - P = e^(-rT) * (F - K)
        val discountFactor = Math.exp(-r * tenor)
        val expectedDifference = discountFactor * (forwardPrice - strike)
        val actualDifference = call.pricePerUnit - put.pricePerUnit
        assertEquals("Black-76 Put-Call Parity", expectedDifference, actualDifference, 0.01)
    }

    @Test
    fun testPreTradeRiskRejectionOnCollarBreach() {
        val engine = MarketEngine()
        val instrument = engine.instruments.first()

        // Reference spot is ~3.25. 20% collar range is [2.60, 3.90].
        // An order at $5.00 should be rejected by pre-trade risk.
        val aggressiveOrder = Order(
            clientOrderId = "TEST-RISK-1",
            portfolioId = "PORT-RHINO-PROP",
            instrumentId = instrument.id,
            side = OrderSide.BUY,
            limitPrice = 5.50,
            initialQuantity = 10
        )

        val (matchedOrder, trades) = engine.submitOrder(aggressiveOrder)
        assertEquals("Order must be rejected", OrderStatus.REJECTED, matchedOrder.status)
        assertTrue("No trades generated on rejected order", trades.isEmpty())
    }

    @Test
    fun testDeterministicOrderMatching() {
        val engine = MarketEngine()
        val instrument = engine.instruments.first() // RB-H100-FWD-Q4-26

        // Best resting ask in seeded book is at 3.32 (qty 40).
        // Submit aggressive BUY limit order at 3.35 for 20 units.
        val buyOrder = Order(
            clientOrderId = "TAKER-BUY-1",
            portfolioId = "PORT-RHINO-PROP",
            instrumentId = instrument.id,
            side = OrderSide.BUY,
            limitPrice = 3.35,
            initialQuantity = 20
        )

        val (matchedOrder, trades) = engine.submitOrder(buyOrder)
        assertEquals("Order must be fully filled", OrderStatus.FILLED, matchedOrder.status)
        assertEquals("Filled quantity must be 20", 20, matchedOrder.filledQuantity)
        assertEquals("Remaining quantity must be 0", 0, matchedOrder.remainingQuantity)
        assertEquals("Must generate 1 trade", 1, trades.size)
        assertEquals("Maker passive price 3.32 respected", 3.32, trades.first().price, 0.001)
    }
}
