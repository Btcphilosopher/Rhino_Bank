package com.example.engine

import com.example.model.*
import com.example.quant.QuantEngine
import java.util.UUID

class MarketEngine {

    val instruments = mutableListOf<Instrument>()
    val referenceIndices = mutableListOf<ReferenceIndex>()
    val orderBooks = mutableMapOf<String, MutableList<Order>>()
    val trades = mutableListOf<Trade>()
    val rfqs = mutableListOf<Rfq>()
    val bilateralContracts = mutableListOf<BilateralContract>()
    val positions = mutableListOf<Position>()
    val auditEvents = mutableListOf<AuditEvent>()

    var riskLimits = RiskLimits()
    var isEmergencyHalted = false

    var currentPortfolio = PortfolioRiskSummary(
        portfolioId = "PORT-RHINO-PROP",
        institutionName = "RhinoBank Quantitative Principal Trading",
        collateralBalance = 10_000_000.0,
        initialMarginReq = 450_000.0,
        variationMarginReq = 0.0,
        totalUnrealizedPnl = 84_500.0,
        totalGrossNotional = 4_250_000.0
    )

    init {
        seedInitialMarketData()
    }

    private fun seedInitialMarketData() {
        // 1. Reference Indices
        referenceIndices.addAll(
            listOf(
                ReferenceIndex("RB-GPU-REF-LON", "London H100 Benchmark", "NVIDIA_H100_SXM5_80GB", "LON", 3.25, 1.25, "$/GPU-hr", IndexQuality.LIVE_VERIFIED, 22),
                ReferenceIndex("RB-GPU-REF-FRA", "Frankfurt H100 Benchmark", "NVIDIA_H100_SXM5_80GB", "FRA", 3.12, -0.45, "$/GPU-hr", IndexQuality.LIVE_VERIFIED, 18),
                ReferenceIndex("RB-CPU-REF-EU", "Pan-European CPU Index", "AMD_EPYC_9654_128C", "EU", 0.045, 0.10, "$/Core-hr", IndexQuality.LIVE_VERIFIED, 34),
                ReferenceIndex("RB-COMP-INDEX-EU", "Synthetic Compute Basket", "AI_CLUSTER_V1", "EU", 142.50, 2.10, "Points", IndexQuality.MODELLED, 14),
                ReferenceIndex("RB-GPU-BASIS-LON-FRA", "Regional Basis Spread (LON-FRA)", "H100_REGIONAL_DIFF", "EU", 0.13, 3.80, "$/GPU-hr", IndexQuality.LIVE_VERIFIED, 40)
            )
        )

        // 2. Standardized Registered Derivative Instruments
        instruments.addAll(
            listOf(
                Instrument(
                    id = "RB-H100-FWD-Q4-26",
                    name = "H100 Q4-26 Compute Forward",
                    type = InstrumentType.FORWARD,
                    underlyingIndex = "RB-GPU-REF-LON",
                    hardwareClass = "NVIDIA H100 SXM5 80GB",
                    region = "LON",
                    contractMultiplier = 1000,
                    strikePrice = 3.30,
                    expiryDescription = "2026-12-31 23:59 UTC"
                ),
                Instrument(
                    id = "RB-H100-FUT-DEC26",
                    name = "H100 Dec-26 Cash-Settled Futures",
                    type = InstrumentType.FUTURES,
                    underlyingIndex = "RB-GPU-REF-LON",
                    hardwareClass = "NVIDIA H100 SXM5 80GB",
                    region = "LON",
                    contractMultiplier = 1000,
                    strikePrice = 3.35,
                    expiryDescription = "2026-12-18 16:00 UTC"
                ),
                Instrument(
                    id = "RB-H100-OPT-C340-DEC26",
                    name = "H100 Dec-26 $3.40 European Call",
                    type = InstrumentType.EUROPEAN_OPTION,
                    underlyingIndex = "RB-GPU-REF-LON",
                    hardwareClass = "NVIDIA H100 SXM5 80GB",
                    region = "LON",
                    contractMultiplier = 1000,
                    strikePrice = 3.40,
                    expiryDescription = "2026-12-18 16:00 UTC"
                ),
                Instrument(
                    id = "RB-H100-OPT-P320-DEC26",
                    name = "H100 Dec-26 $3.20 European Put",
                    type = InstrumentType.EUROPEAN_OPTION,
                    underlyingIndex = "RB-GPU-REF-LON",
                    hardwareClass = "NVIDIA H100 SXM5 80GB",
                    region = "LON",
                    contractMultiplier = 1000,
                    strikePrice = 3.20,
                    expiryDescription = "2026-12-18 16:00 UTC"
                ),
                Instrument(
                    id = "RB-SWAP-H100-1YR-26",
                    name = "H100 1-Year Fixed/Floating Compute Swap",
                    type = InstrumentType.SWAP,
                    underlyingIndex = "RB-GPU-REF-LON",
                    hardwareClass = "NVIDIA H100 SXM5 80GB",
                    region = "LON",
                    contractMultiplier = 8760,
                    strikePrice = 3.20,
                    expiryDescription = "2027-10-09 23:59 UTC"
                ),
                Instrument(
                    id = "RB-BASIS-LON-FRA-DEC26",
                    name = "LON-FRA Dec-26 Regional Basis Swap",
                    type = InstrumentType.REGIONAL_BASIS,
                    underlyingIndex = "RB-GPU-BASIS-LON-FRA",
                    hardwareClass = "NVIDIA H100 Spread",
                    region = "EU",
                    contractMultiplier = 1000,
                    strikePrice = 0.12,
                    expiryDescription = "2026-12-18 16:00 UTC"
                )
            )
        )

        // 3. Seed initial Resting Orders in CLOB for RB-H100-FWD-Q4-26
        val book = mutableListOf(
            Order(clientOrderId = "MM-BID-1", portfolioId = "PORT-HYPERSCALE-A", instrumentId = "RB-H100-FWD-Q4-26", side = OrderSide.BUY, limitPrice = 3.28, initialQuantity = 50, remainingQuantity = 50),
            Order(clientOrderId = "MM-BID-2", portfolioId = "PORT-AI-LABS-ALPHA", instrumentId = "RB-H100-FWD-Q4-26", side = OrderSide.BUY, limitPrice = 3.27, initialQuantity = 100, remainingQuantity = 100),
            Order(clientOrderId = "MM-BID-3", portfolioId = "PORT-HYPERSCALE-A", instrumentId = "RB-H100-FWD-Q4-26", side = OrderSide.BUY, limitPrice = 3.25, initialQuantity = 150, remainingQuantity = 150),
            Order(clientOrderId = "MM-ASK-1", portfolioId = "PORT-HYPERSCALE-A", instrumentId = "RB-H100-FWD-Q4-26", side = OrderSide.SELL, limitPrice = 3.32, initialQuantity = 40, remainingQuantity = 40),
            Order(clientOrderId = "MM-ASK-2", portfolioId = "PORT-AI-LABS-ALPHA", instrumentId = "RB-H100-FWD-Q4-26", side = OrderSide.SELL, limitPrice = 3.34, initialQuantity = 80, remainingQuantity = 80),
            Order(clientOrderId = "MM-ASK-3", portfolioId = "PORT-HYPERSCALE-A", instrumentId = "RB-H100-FWD-Q4-26", side = OrderSide.SELL, limitPrice = 3.37, initialQuantity = 120, remainingQuantity = 120)
        )
        orderBooks["RB-H100-FWD-Q4-26"] = book

        // Seed initial Position
        positions.add(
            Position(
                instrumentId = "RB-H100-FWD-Q4-26",
                side = OrderSide.BUY,
                quantity = 150,
                multiplier = 1000,
                averageEntryPrice = 3.24,
                markPrice = 3.30,
                realizedPnl = 12_500.0
            )
        )
        positions.add(
            Position(
                instrumentId = "RB-H100-OPT-C340-DEC26",
                side = OrderSide.BUY,
                quantity = 50,
                multiplier = 1000,
                averageEntryPrice = 0.22,
                markPrice = 0.265,
                realizedPnl = 0.0
            )
        )

        // Seed initial Contract
        bilateralContracts.add(
            BilateralContract(
                id = "CTR-LON-FRA-7721",
                instrumentId = "RB-BASIS-LON-FRA-DEC26",
                partyA = "PORT-RHINO-PROP",
                partyB = "PORT-HYPERSCALE-A",
                agreedRate = 0.125,
                quantity = 200,
                multiplier = 1000,
                state = ContractState.ACTIVE
            )
        )

        recordAudit("SYS-BOOT", "ENGINE", "BOOTSTRAP", "System bootstrap with deterministic market state")
    }

    /**
     * Pre-Trade Risk Enforcement Gate
     */
    fun validatePreTradeRisk(
        order: Order,
        instrument: Instrument,
        referenceIndex: ReferenceIndex
    ): PreTradeCheckResult {
        if (isEmergencyHalted) {
            return PreTradeCheckResult(false, "Market is halted under emergency circuit breaker")
        }
        if (instrument.status != MarketStatus.ACTIVE) {
            return PreTradeCheckResult(false, "Instrument ${instrument.id} is suspended")
        }
        if (order.initialQuantity > riskLimits.maxOrderQuantity) {
            return PreTradeCheckResult(false, "Order size ${order.initialQuantity} exceeds max ticket limit (${riskLimits.maxOrderQuantity})")
        }

        val notional = order.limitPrice * order.initialQuantity * instrument.contractMultiplier
        if (notional > riskLimits.maxOrderNotional) {
            return PreTradeCheckResult(false, "Order notional $${"%,.2f".format(notional)} exceeds portfolio limit ($${"%,.2f".format(riskLimits.maxOrderNotional)})")
        }

        // Price collar check around current reference spot
        val minCollar = referenceIndex.currentSpotRate * (1.0 - riskLimits.priceCollarPercent)
        val maxCollar = referenceIndex.currentSpotRate * (1.0 + riskLimits.priceCollarPercent)
        if (order.limitPrice < minCollar || order.limitPrice > maxCollar) {
            return PreTradeCheckResult(false, "Limit price $${order.limitPrice} breaches 20% collar range [$${"%.2f".format(minCollar)}, $${"%.2f".format(maxCollar)}]")
        }

        return PreTradeCheckResult(true)
    }

    /**
     * Submit and match order using deterministic price-time priority.
     */
    fun submitOrder(incoming: Order): Pair<Order, List<Trade>> {
        val instrument = instruments.find { it.id == incoming.instrumentId } ?: error("Instrument not found")
        val index = referenceIndices.find { it.id == instrument.underlyingIndex } ?: referenceIndices.first()

        val riskCheck = validatePreTradeRisk(incoming, instrument, index)
        if (!riskCheck.isApproved) {
            incoming.status = OrderStatus.REJECTED
            recordAudit(incoming.id, "ORDER", "REJECT", "Pre-trade risk failed: ${riskCheck.reason}")
            return Pair(incoming, emptyList())
        }

        val book = orderBooks.getOrPut(incoming.instrumentId) { mutableListOf() }
        val generatedTrades = mutableListOf<Trade>()

        if (incoming.side == OrderSide.BUY) {
            // Match against ASKS sorted lowest price, then earliest timestamp
            val matchingAsks = book.filter { it.side == OrderSide.SELL && it.remainingQuantity > 0 && it.limitPrice <= incoming.limitPrice }
                .sortedWith(compareBy<Order> { it.limitPrice }.thenBy { it.timestamp })

            for (maker in matchingAsks) {
                if (incoming.remainingQuantity <= 0) break

                val matchQty = minOf(incoming.remainingQuantity, maker.remainingQuantity)
                val execPrice = maker.limitPrice // Maker's price priority

                incoming.filledQuantity += matchQty
                incoming.remainingQuantity -= matchQty
                maker.filledQuantity += matchQty
                maker.remainingQuantity -= matchQty

                maker.status = if (maker.remainingQuantity == 0) OrderStatus.FILLED else OrderStatus.PARTIALLY_FILLED

                val trade = Trade(
                    instrumentId = incoming.instrumentId,
                    makerOrderId = maker.id,
                    takerOrderId = incoming.id,
                    buyerPortfolioId = incoming.portfolioId,
                    sellerPortfolioId = maker.portfolioId,
                    price = execPrice,
                    quantity = matchQty,
                    multiplier = instrument.contractMultiplier
                )
                generatedTrades.add(trade)
                trades.add(0, trade)

                updatePositionOnTrade(incoming.instrumentId, incoming.side, matchQty, execPrice, instrument.contractMultiplier)
                recordAudit(trade.id, "TRADE", "EXECUTE", "Matched ${matchQty}x @ $execPrice against maker ${maker.id}")
            }

            if (incoming.remainingQuantity > 0) {
                incoming.status = if (incoming.filledQuantity > 0) OrderStatus.PARTIALLY_FILLED else OrderStatus.NEW
                book.add(incoming)
            } else {
                incoming.status = OrderStatus.FILLED
            }
        } else {
            // SELL order: Match against BIDS sorted highest price, then earliest timestamp
            val matchingBids = book.filter { it.side == OrderSide.BUY && it.remainingQuantity > 0 && it.limitPrice >= incoming.limitPrice }
                .sortedWith(compareByDescending<Order> { it.limitPrice }.thenBy { it.timestamp })

            for (maker in matchingBids) {
                if (incoming.remainingQuantity <= 0) break

                val matchQty = minOf(incoming.remainingQuantity, maker.remainingQuantity)
                val execPrice = maker.limitPrice

                incoming.filledQuantity += matchQty
                incoming.remainingQuantity -= matchQty
                maker.filledQuantity += matchQty
                maker.remainingQuantity -= matchQty

                maker.status = if (maker.remainingQuantity == 0) OrderStatus.FILLED else OrderStatus.PARTIALLY_FILLED

                val trade = Trade(
                    instrumentId = incoming.instrumentId,
                    makerOrderId = maker.id,
                    takerOrderId = incoming.id,
                    buyerPortfolioId = maker.portfolioId,
                    sellerPortfolioId = incoming.portfolioId,
                    price = execPrice,
                    quantity = matchQty,
                    multiplier = instrument.contractMultiplier
                )
                generatedTrades.add(trade)
                trades.add(0, trade)

                updatePositionOnTrade(incoming.instrumentId, incoming.side, matchQty, execPrice, instrument.contractMultiplier)
                recordAudit(trade.id, "TRADE", "EXECUTE", "Matched ${matchQty}x @ $execPrice against maker ${maker.id}")
            }

            if (incoming.remainingQuantity > 0) {
                incoming.status = if (incoming.filledQuantity > 0) OrderStatus.PARTIALLY_FILLED else OrderStatus.NEW
                book.add(incoming)
            } else {
                incoming.status = OrderStatus.FILLED
            }
        }

        recalculatePortfolioMetrics()
        return Pair(incoming, generatedTrades)
    }

    private fun updatePositionOnTrade(instrumentId: String, side: OrderSide, qty: Int, price: Double, multiplier: Int) {
        val existing = positions.find { it.instrumentId == instrumentId && it.side == side }
        if (existing != null) {
            val totalQty = existing.quantity + qty
            val newAvg = ((existing.quantity * existing.averageEntryPrice) + (qty * price)) / totalQty
            existing.quantity = totalQty
            // existing.averageEntryPrice is updated through new instance
            positions.remove(existing)
            positions.add(existing.copy(quantity = totalQty, averageEntryPrice = (newAvg * 1000.0).toLong() / 1000.0))
        } else {
            positions.add(
                Position(
                    instrumentId = instrumentId,
                    side = side,
                    quantity = qty,
                    multiplier = multiplier,
                    averageEntryPrice = price,
                    markPrice = price
                )
            )
        }
    }

    fun recalculatePortfolioMetrics() {
        var totalGross = 0.0
        var totalUnrealized = 0.0
        for (pos in positions) {
            val inst = instruments.find { it.id == pos.instrumentId }
            val index = referenceIndices.find { it.id == inst?.underlyingIndex }
            val mark = index?.currentSpotRate ?: pos.markPrice
            pos.markPrice = mark
            totalGross += pos.grossNotional
            totalUnrealized += pos.unrealizedPnl
        }
        val im = totalGross * 0.10 // 10% Initial Margin
        currentPortfolio = currentPortfolio.copy(
            totalGrossNotional = totalGross,
            totalUnrealizedPnl = totalUnrealized,
            initialMarginReq = im
        )
    }

    /**
     * Bilateral OTC: Create RFQ
     */
    fun createRfq(instrumentId: String, side: OrderSide, quantity: Int): Rfq {
        val instrument = instruments.find { it.id == instrumentId } ?: error("Instrument not found")
        val index = referenceIndices.find { it.id == instrument.underlyingIndex } ?: referenceIndices.first()
        val spot = index.currentSpotRate

        val rfq = Rfq(
            clientPortfolioId = currentPortfolio.portfolioId,
            instrumentId = instrumentId,
            side = side,
            quantity = quantity,
            status = RfqStatus.QUOTED
        )

        // Stream quotes from institutional dealers
        val spreadOffset = if (side == OrderSide.BUY) 0.04 else -0.04
        val quote1 = DealerQuote(
            dealerName = "RhinoBank Principal Dealing Desk",
            quotedRate = ((spot + spreadOffset) * 1000.0).toLong() / 1000.0
        )
        val quote2 = DealerQuote(
            dealerName = "Hyperscale Cloud Treasury",
            quotedRate = ((spot + spreadOffset + 0.015) * 1000.0).toLong() / 1000.0
        )
        rfq.quotes.addAll(listOf(quote1, quote2))
        rfqs.add(0, rfq)

        recordAudit(rfq.id, "RFQ", "CREATE", "Created RFQ for ${quantity}x $instrumentId ($side)")
        return rfq
    }

    /**
     * Bilateral OTC: Accept Quote and generate legally binding derivative contract
     */
    fun acceptQuote(rfqId: String, quoteId: String): BilateralContract? {
        val rfq = rfqs.find { it.id == rfqId } ?: return null
        val quote = rfq.quotes.find { it.id == quoteId } ?: return null

        quote.isAccepted = true
        rfq.status = RfqStatus.ACCEPTED

        val instrument = instruments.find { it.id == rfq.instrumentId } ?: error("Instrument not found")

        val contract = BilateralContract(
            instrumentId = rfq.instrumentId,
            partyA = rfq.clientPortfolioId,
            partyB = quote.dealerName,
            agreedRate = quote.quotedRate,
            quantity = rfq.quantity,
            multiplier = instrument.contractMultiplier,
            state = ContractState.ACTIVE
        )
        bilateralContracts.add(0, contract)

        // Update positions
        updatePositionOnTrade(rfq.instrumentId, rfq.side, rfq.quantity, quote.quotedRate, instrument.contractMultiplier)
        recalculatePortfolioMetrics()

        recordAudit(contract.id, "CONTRACT", "EXECUTE_BILATERAL", "Binding contract created with ${quote.dealerName} @ $${quote.quotedRate}")
        return contract
    }

    /**
     * Cash Settlement & Fixing Calculation
     */
    fun calculateSettlement(contractId: String, fixingPrice: Double): Double {
        val contract = bilateralContracts.find { it.id == contractId } ?: error("Contract not found")
        val instrument = instruments.find { it.id == contract.instrumentId } ?: error("Instrument not found")

        contract.fixingPrice = fixingPrice
        contract.state = ContractState.FIXED

        // Payoff = q * m * (P_fixing - K)
        val payoff = contract.quantity.toDouble() * instrument.contractMultiplier * (fixingPrice - contract.agreedRate)
        contract.settlementPayoff = payoff
        contract.state = ContractState.SETTLED

        // Credit/Debit portfolio collateral
        currentPortfolio = currentPortfolio.copy(
            collateralBalance = currentPortfolio.collateralBalance + payoff
        )

        recordAudit(contract.id, "SETTLEMENT", "CALCULATE", "Fixed @ $${fixingPrice}, Cash Payoff: $${"%,.2f".format(payoff)}")
        return payoff
    }

    /**
     * Append-only cryptographic audit logger
     */
    fun recordAudit(entityId: String, entityType: String, action: String, detail: String) {
        val payload = "ENTITY=$entityType|ID=$entityId|ACTION=$action|DETAIL=$detail|TIME=${System.currentTimeMillis()}"
        val hash = QuantEngine.sha256(payload)
        val event = AuditEvent(
            entityType = entityType,
            entityId = entityId,
            action = action,
            actor = "RHINO-QUANT-SYSTEM",
            payloadPreview = detail,
            sha256Hash = hash
        )
        auditEvents.add(0, event)
    }

    fun toggleEmergencyStop(): Boolean {
        isEmergencyHalted = !isEmergencyHalted
        val action = if (isEmergencyHalted) "SUSPEND_MARKET" else "RESUME_MARKET"
        recordAudit("EMERGENCY-STOP", "MARKET_CONTROL", action, "Circuit breaker status changed to: isHalted=$isEmergencyHalted")
        return isEmergencyHalted
    }

    fun getOrderBookSnapshot(instrumentId: String): Pair<List<OrderBookLevel>, List<OrderBookLevel>> {
        val book = orderBooks[instrumentId] ?: return Pair(emptyList(), emptyList())
        val bids = book.filter { it.side == OrderSide.BUY && it.remainingQuantity > 0 }
            .groupBy { it.limitPrice }
            .map { (price, orders) ->
                OrderBookLevel(price = price, quantity = orders.sumOf { it.remainingQuantity }, orderCount = orders.size)
            }
            .sortedByDescending { it.price }

        val asks = book.filter { it.side == OrderSide.SELL && it.remainingQuantity > 0 }
            .groupBy { it.limitPrice }
            .map { (price, orders) ->
                OrderBookLevel(price = price, quantity = orders.sumOf { it.remainingQuantity }, orderCount = orders.size)
            }
            .sortedBy { it.price }

        return Pair(bids, asks)
    }
}
