package com.example.quant

import com.example.model.OptionGreeksResult
import com.example.model.SwapSchedulePeriod
import com.example.model.SwapValuationResult
import java.security.MessageDigest
import java.util.UUID
import kotlin.math.*

object QuantEngine {

    private const val INV_SQRT_2PI = 0.3989422804014327

    /**
     * Standard normal probability density function: n(x) = (1 / sqrt(2*pi)) * exp(-x^2 / 2)
     */
    fun standardNormalPdf(x: Double): Double {
        return INV_SQRT_2PI * exp(-0.5 * x * x)
    }

    /**
     * High-precision cumulative normal distribution function: N(x)
     * Approximation via Abramowitz and Stegun 26.2.17 (error < 7.5e-8).
     */
    fun standardNormalCdf(x: Double): Double {
        val b1 = 0.319381530
        val b2 = -0.356563782
        val b3 = 1.781477937
        val b4 = -1.821255978
        val b5 = 1.330274429
        val p = 0.2316419

        val absX = abs(x)
        val t = 1.0 / (1.0 + p * absX)
        val poly = ((((b5 * t + b4) * t + b3) * t + b2) * t + b1) * t
        val cdf = 1.0 - standardNormalPdf(absX) * poly

        return if (x >= 0.0) cdf else 1.0 - cdf
    }

    /**
     * Black-76 Model for European Compute Options on Forward Rates.
     */
    fun priceBlack76(
        forwardPrice: Double,
        strike: Double,
        volatility: Double,
        timeToExpiryYears: Double,
        discountRate: Double,
        isCall: Boolean,
        quantity: Int = 1,
        contractMultiplier: Int = 1000
    ): OptionGreeksResult {
        require(forwardPrice > 0.0) { "Forward price must be positive" }
        require(strike > 0.0) { "Strike must be positive" }
        require(volatility > 0.0) { "Volatility must be positive" }
        require(timeToExpiryYears > 0.0) { "Tenor must be positive" }

        val sqrtT = sqrt(timeToExpiryYears)
        val d1 = (ln(forwardPrice / strike) + 0.5 * volatility * volatility * timeToExpiryYears) / (volatility * sqrtT)
        val d2 = d1 - volatility * sqrtT

        val discountFactor = exp(-discountRate * timeToExpiryYears)
        val pdfD1 = standardNormalPdf(d1)

        val pricePerUnit: Double
        val delta: Double
        val intrinsic: Double
        val theta: Double

        if (isCall) {
            val cdfD1 = standardNormalCdf(d1)
            val cdfD2 = standardNormalCdf(d2)
            pricePerUnit = discountFactor * (forwardPrice * cdfD1 - strike * cdfD2)
            delta = discountFactor * cdfD1
            intrinsic = max(0.0, forwardPrice - strike)
            theta = (discountRate * pricePerUnit) - (discountFactor * forwardPrice * volatility * pdfD1) / (2.0 * sqrtT)
        } else {
            val cdfMinusD1 = standardNormalCdf(-d1)
            val cdfMinusD2 = standardNormalCdf(-d2)
            pricePerUnit = discountFactor * (strike * cdfMinusD2 - forwardPrice * cdfMinusD1)
            delta = -discountFactor * cdfMinusD1
            intrinsic = max(0.0, strike - forwardPrice)
            theta = (discountRate * pricePerUnit) - (discountFactor * forwardPrice * volatility * pdfD1) / (2.0 * sqrtT)
        }

        val gamma = (discountFactor * pdfD1) / (forwardPrice * volatility * sqrtT)
        val vega = discountFactor * forwardPrice * sqrtT * pdfD1
        val timeValue = max(0.0, pricePerUnit - intrinsic)
        val totalPremium = pricePerUnit * quantity * contractMultiplier

        return OptionGreeksResult(
            pricePerUnit = round6(pricePerUnit),
            totalPremium = round2(totalPremium),
            intrinsicValue = round6(intrinsic),
            timeValue = round6(timeValue),
            delta = round6(delta),
            gamma = round6(gamma),
            vega = round6(vega),
            theta = round6(theta),
            discountFactor = round6(discountFactor),
            valuationId = "VAL-" + UUID.randomUUID().toString().take(8).uppercase()
        )
    }

    /**
     * Forward valuation for non-storable compute capacity:
     * F = S * exp((r + electricityDrift + scarcity - depreciation) * T)
     */
    fun priceComputeForward(
        spotRate: Double,
        tenorYears: Double,
        discountRate: Double = 0.045,
        electricityCostDrift: Double = 0.02,
        scarcityPremium: Double = 0.03,
        depreciationRate: Double = 0.05
    ): Double {
        val netDrift = discountRate + electricityCostDrift + scarcityPremium - depreciationRate
        return round6(spotRate * exp(netDrift * tenorYears))
    }

    /**
     * Fixed-for-floating compute swap NPV and cash flow schedule.
     */
    fun calculateComputeSwap(
        fixedRate: Double,
        forwardCurve: List<Double>,
        tenorPeriods: Int = 4,
        hoursPerPeriod: Int = 2190, // quarterly
        quantityUnits: Int = 10,
        annualDiscountRate: Double = 0.045
    ): SwapValuationResult {
        val periods = mutableListOf<SwapSchedulePeriod>()
        var totalFixedNpv = 0.0
        var totalFloatNpv = 0.0
        var sumDiscountFactors = 0.0

        for (i in 1..tenorPeriods) {
            val tYears = (i * hoursPerPeriod) / 8760.0
            val df = exp(-annualDiscountRate * tYears)
            sumDiscountFactors += df

            val floatRate = if (i - 1 < forwardCurve.size) forwardCurve[i - 1] else forwardCurve.last()
            val fixedCashflow = fixedRate * hoursPerPeriod * quantityUnits
            val floatCashflow = floatRate * hoursPerPeriod * quantityUnits
            val netCashflow = floatCashflow - fixedCashflow
            val discountedNpv = netCashflow * df

            totalFixedNpv += fixedCashflow * df
            totalFloatNpv += floatCashflow * df

            periods.add(
                SwapSchedulePeriod(
                    period = i,
                    fixedRate = round4(fixedRate),
                    floatingRate = round4(floatRate),
                    netCashflow = round2(netCashflow),
                    discountedNpv = round2(discountedNpv),
                    discountFactor = round4(df)
                )
            )
        }

        val netNpv = totalFloatNpv - totalFixedNpv
        val parSwapRate = if (sumDiscountFactors > 0) {
            totalFloatNpv / (hoursPerPeriod * quantityUnits * sumDiscountFactors)
        } else fixedRate

        return SwapValuationResult(
            fixedLegNpv = round2(totalFixedNpv),
            floatingLegNpv = round2(totalFloatNpv),
            netSwapNpv = round2(netNpv),
            parSwapRate = round4(parSwapRate),
            periods = periods
        )
    }

    /**
     * Calculates cryptographic SHA-256 hash for audit events.
     */
    fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun round2(v: Double) = (v * 100.0).roundToLong() / 100.0
    private fun round4(v: Double) = (v * 10000.0).roundToLong() / 10000.0
    private fun round6(v: Double) = (v * 1000000.0).roundToLong() / 1000000.0
}
