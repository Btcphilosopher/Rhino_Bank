package com.example.model

import java.util.UUID

enum class MarketStatus {
    DRAFT, PENDING_APPROVAL, ACTIVE, SUSPENDED, EXPIRED, SETTLED, CANCELLED
}

enum class InstrumentType(val displayName: String) {
    FORWARD("Forward"),
    FUTURES("Futures"),
    SWAP("Swap"),
    EUROPEAN_OPTION("European Option"),
    REGIONAL_BASIS("Regional Basis"),
    HARDWARE_BASIS("Hardware Basis"),
    CAPACITY_RESERVATION("Capacity Reservation"),
    INDEX_DERIVATIVE("Index Derivative")
}

data class Instrument(
    val id: String,
    val name: String,
    val version: String = "1.0",
    val type: InstrumentType,
    val underlyingIndex: String,
    val hardwareClass: String,
    val region: String,
    val quantityUnit: String = "GPU_HOUR",
    val contractMultiplier: Int, // e.g. 1000 GPU-hours
    val currency: String = "USD",
    val tickSize: Double = 0.01,
    val strikePrice: Double? = null,
    val expiryDescription: String,
    val settlementMethod: String = "CASH_SETTLED_TWAP",
    var status: MarketStatus = MarketStatus.ACTIVE,
    val benchmarkDescription: String = "Top-5 Tier 1 European Datacenter Cloud Providers"
)

enum class IndexQuality {
    LIVE_VERIFIED, HISTORICAL, SIMULATED, MODELLED, STALE
}

data class ReferenceIndex(
    val id: String,
    val name: String,
    val hardwareClass: String,
    val region: String,
    var currentSpotRate: Double,
    var change24hPct: Double,
    val unit: String = "$/GPU-hr",
    val quality: IndexQuality = IndexQuality.LIVE_VERIFIED,
    val sampleDatacenters: Int = 18,
    val lastFixingTwap: Double = currentSpotRate
)

enum class OrderSide {
    BUY, SELL
}

enum class OrderStatus {
    NEW, PARTIALLY_FILLED, FILLED, CANCELLED, REJECTED
}

data class Order(
    val id: String = UUID.randomUUID().toString(),
    val clientOrderId: String,
    val portfolioId: String,
    val instrumentId: String,
    val side: OrderSide,
    val limitPrice: Double,
    val initialQuantity: Int,
    var filledQuantity: Int = 0,
    var remainingQuantity: Int = initialQuantity,
    var status: OrderStatus = OrderStatus.NEW,
    val timestamp: Long = System.currentTimeMillis()
)

data class Trade(
    val id: String = UUID.randomUUID().toString().take(8).uppercase(),
    val instrumentId: String,
    val makerOrderId: String,
    val takerOrderId: String,
    val buyerPortfolioId: String,
    val sellerPortfolioId: String,
    val price: Double,
    val quantity: Int,
    val multiplier: Int,
    val notional: Double = price * quantity * multiplier,
    val timestamp: Long = System.currentTimeMillis()
)

data class OrderBookLevel(
    val price: Double,
    val quantity: Int,
    val orderCount: Int,
    val cumulativeQuantity: Int = quantity
)

enum class RfqStatus {
    OPEN, QUOTED, ACCEPTED, EXPIRED, CANCELLED
}

data class DealerQuote(
    val id: String = UUID.randomUUID().toString().take(8).uppercase(),
    val dealerName: String,
    val quotedRate: Double,
    val validSeconds: Int = 30,
    val timestamp: Long = System.currentTimeMillis(),
    var isAccepted: Boolean = false
)

data class Rfq(
    val id: String = UUID.randomUUID().toString().take(8).uppercase(),
    val clientPortfolioId: String,
    val instrumentId: String,
    val side: OrderSide,
    val quantity: Int,
    var status: RfqStatus = RfqStatus.OPEN,
    val quotes: MutableList<DealerQuote> = mutableListOf(),
    val createdAt: Long = System.currentTimeMillis()
)

enum class ContractState {
    DRAFT, ACTIVE, FIXING_PENDING, FIXED, SETTLEMENT_CALCULATED, APPROVED, SETTLED, CANCELLED
}

data class BilateralContract(
    val id: String = "CTR-" + UUID.randomUUID().toString().take(8).uppercase(),
    val instrumentId: String,
    val partyA: String,
    val partyB: String,
    val agreedRate: Double,
    val quantity: Int,
    val multiplier: Int,
    val notional: Double = agreedRate * quantity * multiplier,
    var state: ContractState = ContractState.ACTIVE,
    var fixingPrice: Double? = null,
    var settlementPayoff: Double? = null,
    val createdAt: Long = System.currentTimeMillis()
)

data class Position(
    val instrumentId: String,
    val side: OrderSide,
    var quantity: Int,
    val multiplier: Int,
    val averageEntryPrice: Double,
    var markPrice: Double,
    val realizedPnl: Double = 0.0
) {
    val netExposureGpuHours: Long
        get() = (quantity.toLong() * multiplier) * if (side == OrderSide.BUY) 1 else -1

    val grossNotional: Double
        get() = quantity.toDouble() * multiplier * markPrice

    val unrealizedPnl: Double
        get() {
            val priceDiff = if (side == OrderSide.BUY) (markPrice - averageEntryPrice) else (averageEntryPrice - markPrice)
            return priceDiff * quantity * multiplier
        }
}

data class PortfolioRiskSummary(
    val portfolioId: String,
    val institutionName: String,
    var collateralBalance: Double = 10_000_000.0,
    val initialMarginReq: Double,
    val variationMarginReq: Double,
    val totalUnrealizedPnl: Double,
    val totalGrossNotional: Double,
    val riskStatus: String = "HEALTHY"
)

data class RiskLimits(
    val maxOrderQuantity: Int = 500,
    val maxOrderNotional: Double = 2_500_000.0,
    val priceCollarPercent: Double = 0.20 // 20%
)

data class PreTradeCheckResult(
    val isApproved: Boolean,
    val reason: String? = null
)

data class OptionGreeksResult(
    val pricePerUnit: Double,
    val totalPremium: Double,
    val intrinsicValue: Double,
    val timeValue: Double,
    val delta: Double,
    val gamma: Double,
    val vega: Double,
    val theta: Double,
    val discountFactor: Double,
    val valuationId: String
)

data class SwapSchedulePeriod(
    val period: Int,
    val fixedRate: Double,
    val floatingRate: Double,
    val netCashflow: Double,
    val discountedNpv: Double,
    val discountFactor: Double
)

data class SwapValuationResult(
    val fixedLegNpv: Double,
    val floatingLegNpv: Double,
    val netSwapNpv: Double,
    val parSwapRate: Double,
    val periods: List<SwapSchedulePeriod>
)

data class AuditEvent(
    val id: String = UUID.randomUUID().toString().take(12),
    val timestamp: Long = System.currentTimeMillis(),
    val entityType: String,
    val entityId: String,
    val action: String,
    val actor: String,
    val payloadPreview: String,
    val sha256Hash: String
)
