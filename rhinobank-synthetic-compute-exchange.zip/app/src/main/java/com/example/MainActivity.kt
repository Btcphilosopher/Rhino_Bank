package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.InstitutionalHeader
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MarketViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScaffold()
            }
        }
    }
}

@Composable
fun MainAppScaffold(marketViewModel: MarketViewModel = viewModel()) {
    val currentTab by marketViewModel.currentTab.collectAsStateWithLifecycle()
    val instruments by marketViewModel.instruments.collectAsStateWithLifecycle()
    val referenceIndices by marketViewModel.referenceIndices.collectAsStateWithLifecycle()
    val selectedInstrument by marketViewModel.selectedInstrument.collectAsStateWithLifecycle()
    val bids by marketViewModel.bids.collectAsStateWithLifecycle()
    val asks by marketViewModel.asks.collectAsStateWithLifecycle()
    val trades by marketViewModel.trades.collectAsStateWithLifecycle()
    val rfqs by marketViewModel.rfqs.collectAsStateWithLifecycle()
    val contracts by marketViewModel.contracts.collectAsStateWithLifecycle()
    val positions by marketViewModel.positions.collectAsStateWithLifecycle()
    val portfolio by marketViewModel.portfolio.collectAsStateWithLifecycle()
    val auditEvents by marketViewModel.auditEvents.collectAsStateWithLifecycle()
    val isEmergencyHalted by marketViewModel.isEmergencyHalted.collectAsStateWithLifecycle()
    val quantState by marketViewModel.quantState.collectAsStateWithLifecycle()
    val orderFeedback by marketViewModel.orderSubmitFeedback.collectAsStateWithLifecycle()

    // Handle back button to return to Markets Overview if on a secondary tab
    BackHandler(enabled = currentTab != MainTab.MARKETS) {
        marketViewModel.setTab(MainTab.MARKETS)
    }

    Scaffold(
        topBar = {
            InstitutionalHeader(
                isEmergencyHalted = isEmergencyHalted,
                onToggleEmergencyStop = { marketViewModel.toggleEmergencyStop() }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = RhinoSurface,
                contentColor = TextPrimary,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavigationItem(
                    tab = MainTab.MARKETS,
                    icon = Icons.Default.Analytics,
                    currentTab = currentTab,
                    onSelect = { marketViewModel.setTab(MainTab.MARKETS) }
                )
                NavigationItem(
                    tab = MainTab.CLOB,
                    icon = Icons.Default.CandlestickChart,
                    currentTab = currentTab,
                    onSelect = { marketViewModel.setTab(MainTab.CLOB) }
                )
                NavigationItem(
                    tab = MainTab.OTC_RFQ,
                    icon = Icons.Default.Handshake,
                    currentTab = currentTab,
                    onSelect = { marketViewModel.setTab(MainTab.OTC_RFQ) }
                )
                NavigationItem(
                    tab = MainTab.QUANT_LAB,
                    icon = Icons.Default.Calculate,
                    currentTab = currentTab,
                    onSelect = { marketViewModel.setTab(MainTab.QUANT_LAB) }
                )
                NavigationItem(
                    tab = MainTab.RISK,
                    icon = Icons.Default.Shield,
                    currentTab = currentTab,
                    onSelect = { marketViewModel.setTab(MainTab.RISK) }
                )
                NavigationItem(
                    tab = MainTab.SETTLEMENT,
                    icon = Icons.Default.ReceiptLong,
                    currentTab = currentTab,
                    onSelect = { marketViewModel.setTab(MainTab.SETTLEMENT) }
                )
            }
        },
        containerColor = RhinoBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(RhinoBackground),
            contentAlignment = Alignment.TopCenter
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 840.dp)
            ) {
                when (currentTab) {
                    MainTab.MARKETS -> {
                        MarketsOverviewScreen(
                            referenceIndices = referenceIndices,
                            instruments = instruments,
                            onSelectInstrumentToTrade = { marketViewModel.selectInstrument(it) },
                            onNavigateTab = { marketViewModel.setTab(it) }
                        )
                    }
                    MainTab.CLOB -> {
                        OrderBookScreen(
                            instruments = instruments,
                            selectedInstrument = selectedInstrument,
                            bids = bids,
                            asks = asks,
                            trades = trades,
                            feedback = orderFeedback,
                            onSelectInstrument = { marketViewModel.selectInstrument(it) },
                            onSubmitOrder = { side, limitPrice, quantity ->
                                marketViewModel.submitOrder(side, limitPrice, quantity)
                            },
                            onDismissFeedback = { marketViewModel.clearOrderFeedback() }
                        )
                    }
                    MainTab.OTC_RFQ -> {
                        RfqDeskScreen(
                            instruments = instruments,
                            rfqs = rfqs,
                            contracts = contracts,
                            onCreateRfq = { instId, side, qty ->
                                marketViewModel.createRfq(instId, side, qty)
                            },
                            onAcceptQuote = { rfqId, quoteId ->
                                marketViewModel.acceptQuote(rfqId, quoteId)
                            }
                        )
                    }
                    MainTab.QUANT_LAB -> {
                        QuantLabScreen(
                            state = quantState,
                            onUpdateQuant = { fwd, strike, vol, tenor, r, isCall, qty ->
                                marketViewModel.updateQuantParameters(fwd, strike, vol, tenor, r, isCall, qty)
                            },
                            onUpdateSwap = { fixedRate ->
                                marketViewModel.updateSwapParameters(fixedRate)
                            }
                        )
                    }
                    MainTab.RISK -> {
                        RiskPortfolioScreen(
                            portfolio = portfolio,
                            positions = positions
                        )
                    }
                    MainTab.SETTLEMENT -> {
                        SettlementAuditScreen(
                            contracts = contracts,
                            auditEvents = auditEvents,
                            onExecuteSettlement = { cId, fixPrice ->
                                marketViewModel.executeSettlement(cId, fixPrice)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RowScope.NavigationItem(
    tab: MainTab,
    icon: ImageVector,
    currentTab: MainTab,
    onSelect: () -> Unit
) {
    val isSelected = currentTab == tab
    NavigationBarItem(
        selected = isSelected,
        onClick = onSelect,
        icon = {
            Icon(
                imageVector = icon,
                contentDescription = tab.title,
                tint = if (isSelected) CyberCyan else TextSecondary,
                modifier = Modifier.size(20.dp)
            )
        },
        label = {
            Text(
                text = tab.title,
                fontSize = 10.sp,
                color = if (isSelected) CyberCyan else TextSecondary
            )
        },
        colors = NavigationBarItemDefaults.colors(
            indicatorColor = CyberCyan.copy(alpha = 0.15f)
        ),
        modifier = Modifier.testTag("nav_item_${tab.name}")
    )
}
