package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AuditEvent
import com.example.model.BilateralContract
import com.example.model.ContractState
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun SettlementAuditScreen(
    contracts: List<BilateralContract>,
    auditEvents: List<AuditEvent>,
    onExecuteSettlement: (contractId: String, fixingPrice: Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var subTab by remember { mutableStateOf(0) } // 0: Settlement Desk, 1: Cryptographic Audit Trail, 2: API Inspector
    var selectedContractId by remember { mutableStateOf(contracts.firstOrNull()?.id ?: "") }
    var fixingPriceText by remember { mutableStateOf("3.42") }
    var settlementFeedback by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        // Sub-Navigation Tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(RhinoSurfaceVariant)
                    .padding(4.dp)
            ) {
                listOf("Settlement Desk", "Audit Ledger", "API Console").forEachIndexed { idx, title ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (subTab == idx) CyberCyan else Color.Transparent)
                            .clickable { subTab = idx }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (subTab == idx) RhinoBackground else TextSecondary
                        )
                    }
                }
            }
        }

        when (subTab) {
            0 -> {
                // Settlement Desk Section
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = RhinoCard),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "CONTRACT FIXING & CASH SETTLEMENT",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberCyan,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Contractual Payoff = Quantity * Multiplier * (Fixing_TWAP - Agreed_Rate)",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = InstitutionalGold
                            )
                            Spacer(modifier = Modifier.height(14.dp))

                            Text(text = "SELECT ACTIVE CONTRACT", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))

                            if (contracts.isEmpty()) {
                                Text(text = "No contracts available. Execute an OTC trade or trade on CLOB first.", fontSize = 11.sp, color = TextMuted)
                            } else {
                                contracts.take(3).forEach { c ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (selectedContractId == c.id) CyberCyan.copy(alpha = 0.15f) else RhinoSurfaceVariant)
                                            .border(if (selectedContractId == c.id) 1.dp else 0.dp, if (selectedContractId == c.id) CyberCyan else Color.Transparent, RoundedCornerShape(6.dp))
                                            .clickable { selectedContractId = c.id }
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(text = "${c.id} • ${c.instrumentId}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                            Text(text = "${c.quantity}x @ $${c.agreedRate} (Notional: $${"%,.0f".format(c.notional)})", fontSize = 10.sp, color = TextSecondary, fontFamily = FontFamily.Monospace)
                                        }
                                        StatusBadge(text = c.state.name, isPositive = c.state == ContractState.ACTIVE)
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                OutlinedTextField(
                                    value = fixingPriceText,
                                    onValueChange = { fixingPriceText = it },
                                    label = { Text("Final Fixing Benchmark TWAP ($)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    modifier = Modifier.fillMaxWidth().testTag("fixing_price_input"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CyberCyan,
                                        unfocusedBorderColor = RhinoBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    ),
                                    singleLine = true
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                Button(
                                    onClick = {
                                        val fixing = fixingPriceText.toDoubleOrNull() ?: 3.42
                                        if (selectedContractId.isNotEmpty()) {
                                            onExecuteSettlement(selectedContractId, fixing)
                                            settlementFeedback = "Contract $selectedContractId successfully settled against fixing price $${fixing}."
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ProfitGreen, contentColor = RhinoBackground),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth().height(42.dp).testTag("execute_settlement_btn")
                                ) {
                                    Icon(imageVector = Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = "CALCULATE & APPROVE CASH SETTLEMENT", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                if (settlementFeedback != null) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = ProfitGreenBg),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().border(1.dp, ProfitGreen, RoundedCornerShape(8.dp))
                        ) {
                            Text(
                                text = settlementFeedback ?: "",
                                fontSize = 12.sp,
                                color = ProfitGreen,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }
            1 -> {
                // Append-Only Cryptographic Audit Ledger
                item {
                    Text(
                        text = "CRYPTOGRAPHIC APPEND-ONLY AUDIT LEDGER",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyan,
                        letterSpacing = 1.sp
                    )
                }

                items(auditEvents) { event ->
                    AuditEventCard(event = event)
                }
            }
            2 -> {
                // Interactive API Console
                item {
                    ApiConsoleSection()
                }
            }
        }
    }
}

@Composable
fun AuditEventCard(event: AuditEvent) {
    val timeFormat = remember { SimpleDateFormat("HH:mm:ss.SSS", Locale.US) }
    Card(
        colors = CardDefaults.cardColors(containerColor = RhinoCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Fingerprint, contentDescription = null, tint = InstitutionalGold, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "${event.entityType} • ${event.action}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                Text(text = timeFormat.format(Date(event.timestamp)), fontSize = 10.sp, color = TextMuted, fontFamily = FontFamily.Monospace)
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = event.payloadPreview, fontSize = 11.sp, color = TextSecondary)
            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(RhinoSurface)
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "SHA-256: ${event.sha256Hash}",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = CyberCyan
                )
            }
        }
    }
}

@Composable
fun ApiConsoleSection() {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = RhinoCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "INTERACTIVE REST / OPENAPI EXPLORER",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyan,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Gateway Namespace: /api/v1 • Environment: SIMULATION", fontSize = 11.sp, color = TextMuted, fontFamily = FontFamily.Monospace)

                Spacer(modifier = Modifier.height(12.dp))

                ApiEndpointCard(
                    method = "POST",
                    endpoint = "/api/v1/orders",
                    description = "Submit limit order to central order book with pre-trade risk checks",
                    samplePayload = "{\n  \"client_order_id\": \"CLI-9182\",\n  \"instrument_id\": \"RB-H100-FWD-Q4-26\",\n  \"side\": \"BUY\",\n  \"limit_price\": 3.30,\n  \"quantity\": 25,\n  \"idempotency_key\": \"UUID-817263\"\n}"
                )

                Spacer(modifier = Modifier.height(10.dp))

                ApiEndpointCard(
                    method = "POST",
                    endpoint = "/api/v1/pricing/option",
                    description = "Value European compute option via Black-76 with analytical Greeks",
                    samplePayload = "{\n  \"instrument_id\": \"RB-H100-OPT-C340-DEC26\",\n  \"forward_price\": 3.35,\n  \"strike\": 3.40,\n  \"volatility\": 0.42,\n  \"time_to_expiry_years\": 0.25,\n  \"discount_rate\": 0.045\n}"
                )

                Spacer(modifier = Modifier.height(10.dp))

                ApiEndpointCard(
                    method = "GET",
                    endpoint = "/api/v1/instruments",
                    description = "Retrieve registered contract specifications and lifecycle status",
                    samplePayload = "[\n  {\n    \"instrument_id\": \"RB-H100-FWD-Q4-26\",\n    \"multiplier\": 1000,\n    \"market_status\": \"ACTIVE\"\n  }\n]"
                )
            }
        }
    }
}

@Composable
fun ApiEndpointCard(
    method: String,
    endpoint: String,
    description: String,
    samplePayload: String
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (method == "POST") ProfitGreen else CyberCyan)
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(text = method, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = RhinoBackground)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = endpoint, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = TextPrimary)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = description, fontSize = 10.sp, color = TextMuted)
            Spacer(modifier = Modifier.height(6.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(RhinoBackground)
                    .padding(8.dp)
            ) {
                Text(
                    text = samplePayload,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = InstitutionalGold
                )
            }
        }
    }
}
