package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*

@Composable
fun RfqDeskScreen(
    instruments: List<Instrument>,
    rfqs: List<Rfq>,
    contracts: List<BilateralContract>,
    onCreateRfq: (instrumentId: String, side: OrderSide, quantity: Int) -> Unit,
    onAcceptQuote: (rfqId: String, quoteId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedInstrumentId by remember { mutableStateOf(instruments.firstOrNull()?.id ?: "") }
    var side by remember { mutableStateOf(OrderSide.BUY) }
    var quantityText by remember { mutableStateOf("100") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        // 1. Bilateral RFQ Creator Ticket
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = RhinoCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "BILATERAL OTC RFQ DESK",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberCyan,
                            letterSpacing = 1.sp
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(RhinoSurfaceVariant)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = "DEALER QUOTE NETWORK", fontSize = 9.sp, color = InstitutionalGold, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Instrument Selector Chips
                    Text(text = "TARGET INSTRUMENT", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        instruments.take(3).forEach { inst ->
                            FilterChip(
                                selected = selectedInstrumentId == inst.id,
                                onClick = { selectedInstrumentId = inst.id },
                                label = { Text(inst.name.take(16) + "...", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
                                    selectedLabelColor = CyberCyan
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = quantityText,
                            onValueChange = { quantityText = it },
                            label = { Text("Quantity (Units)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("rfq_quantity_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = RhinoBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "DIRECTION", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Button(
                                    onClick = { side = OrderSide.BUY },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (side == OrderSide.BUY) ProfitGreen else RhinoSurfaceVariant,
                                        contentColor = if (side == OrderSide.BUY) RhinoBackground else TextSecondary
                                    ),
                                    shape = RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp),
                                    modifier = Modifier.weight(1f).height(40.dp)
                                ) {
                                    Text("BUY", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { side = OrderSide.SELL },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (side == OrderSide.SELL) RiskRed else RhinoSurfaceVariant,
                                        contentColor = if (side == OrderSide.SELL) TextPrimary else TextSecondary
                                    ),
                                    shape = RoundedCornerShape(topEnd = 6.dp, bottomEnd = 6.dp),
                                    modifier = Modifier.weight(1f).height(40.dp)
                                ) {
                                    Text("SELL", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val q = quantityText.toIntOrNull() ?: 100
                            if (selectedInstrumentId.isNotEmpty()) {
                                onCreateRfq(selectedInstrumentId, side, q)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = InstitutionalGold, contentColor = RhinoBackground),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp)
                            .testTag("broadcast_rfq_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "BROADCAST RFQ TO DEALERS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // 2. Active RFQ & Quote Stream
        item {
            Text(
                text = "REQUEST FOR QUOTE (RFQ) SESSIONS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = CyberCyan,
                letterSpacing = 1.sp
            )
        }

        if (rfqs.isEmpty()) {
            item {
                Text(
                    text = "No active RFQs. Broadcast a request above to receive firm quotes from registered market dealers.",
                    fontSize = 12.sp,
                    color = TextMuted,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
        } else {
            items(rfqs) { rfq ->
                RfqSessionCard(rfq = rfq, onAcceptQuote = onAcceptQuote)
            }
        }

        // 3. Bilateral Derivative Contracts
        item {
            Text(
                text = "EXECUTED BILATERAL CONTRACTS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = CyberCyan,
                letterSpacing = 1.sp
            )
        }

        if (contracts.isEmpty()) {
            item {
                Text(
                    text = "No bilateral contracts executed yet.",
                    fontSize = 12.sp,
                    color = TextMuted
                )
            }
        } else {
            items(contracts) { contract ->
                BilateralContractCard(contract = contract)
            }
        }
    }
}

@Composable
fun RfqSessionCard(
    rfq: Rfq,
    onAcceptQuote: (rfqId: String, quoteId: String) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = RhinoCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "RFQ-${rfq.id} • ${rfq.instrumentId}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(text = "${rfq.side} ${rfq.quantity} Contracts", fontSize = 11.sp, color = TextSecondary, fontFamily = FontFamily.Monospace)
                }
                StatusBadge(text = rfq.status.name, isPositive = rfq.status == RfqStatus.ACCEPTED)
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = RhinoBorder.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Text(text = "DEALER QUOTES", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            rfq.quotes.forEach { quote ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(RhinoSurfaceVariant)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = quote.dealerName, fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                        Text(text = "Rate: $${"%.3f".format(quote.quotedRate)} / GPU-hr", fontSize = 12.sp, color = InstitutionalGold, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }

                    if (rfq.status != RfqStatus.ACCEPTED) {
                        Button(
                            onClick = { onAcceptQuote(rfq.id, quote.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = ProfitGreen, contentColor = RhinoBackground),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp).testTag("accept_quote_${quote.id}")
                        ) {
                            Text(text = "ACCEPT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    } else if (quote.isAccepted) {
                        Text(text = "ACCEPTED", fontSize = 11.sp, color = ProfitGreen, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun BilateralContractCard(contract: BilateralContract) {
    Card(
        colors = CardDefaults.cardColors(containerColor = RhinoCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = contract.id, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = CyberCyan, fontFamily = FontFamily.Monospace)
                    Text(text = contract.instrumentId, fontSize = 11.sp, color = TextSecondary)
                }
                StatusBadge(text = contract.state.name, isPositive = contract.state == ContractState.ACTIVE || contract.state == ContractState.SETTLED)
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = RhinoBorder.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(text = "COUNTERPARTY", fontSize = 9.sp, color = TextMuted)
                    Text(text = contract.partyB.take(20), fontSize = 11.sp, color = TextPrimary)
                }
                Column {
                    Text(text = "AGREED RATE", fontSize = 9.sp, color = TextMuted)
                    Text(text = "$${contract.agreedRate}", fontSize = 12.sp, color = InstitutionalGold, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "NOTIONAL", fontSize = 9.sp, color = TextMuted)
                    Text(text = "$${"%,.0f".format(contract.notional)}", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
