package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OrderSide
import com.example.model.PortfolioRiskSummary
import com.example.model.Position
import com.example.ui.components.MetricCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*

@Composable
fun RiskPortfolioScreen(
    portfolio: PortfolioRiskSummary,
    positions: List<Position>,
    modifier: Modifier = Modifier
) {
    var selectedStressScenario by remember { mutableStateOf(0) } // 0: None, 1: +25% Spike, 2: -25% Drop, 3: Power Surge

    val marginUtilization = if (portfolio.collateralBalance > 0) {
        (portfolio.initialMarginReq / portfolio.collateralBalance) * 100.0
    } else 0.0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        // 1. Account & Collateral Summary Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = RhinoCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "INSTITUTIONAL ACCOUNT RISK", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberCyan, letterSpacing = 1.sp)
                            Text(text = portfolio.institutionName, fontSize = 12.sp, color = TextSecondary)
                        }
                        StatusBadge(text = portfolio.riskStatus, isPositive = portfolio.riskStatus == "HEALTHY")
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            title = "COLLATERAL BALANCE",
                            value = "$${"%,.0f".format(portfolio.collateralBalance)}",
                            valueColor = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "UNREALIZED P&L",
                            value = "${if (portfolio.totalUnrealizedPnl >= 0) "+" else ""}$${"%,.0f".format(portfolio.totalUnrealizedPnl)}",
                            valueColor = if (portfolio.totalUnrealizedPnl >= 0) ProfitGreen else RiskRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            title = "INITIAL MARGIN (IM)",
                            value = "$${"%,.0f".format(portfolio.initialMarginReq)}",
                            valueColor = InstitutionalGold,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "MARGIN USAGE",
                            value = "${"%.1f".format(marginUtilization)}%",
                            valueColor = if (marginUtilization > 80) RiskRed else ProfitGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 2. Open Derivative Positions
        item {
            Text(
                text = "OPEN DERIVATIVE POSITIONS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = CyberCyan,
                letterSpacing = 1.sp
            )
        }

        if (positions.isEmpty()) {
            item {
                Text(
                    text = "No open derivative positions in portfolio.",
                    fontSize = 12.sp,
                    color = TextMuted,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
        } else {
            items(positions) { pos ->
                PositionRowCard(position = pos)
            }
        }

        // 3. Scenario Stress Testing Matrix
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = RhinoCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "PORTFOLIO STRESS TESTING & SCENARIO SHOCKS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = InstitutionalGold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Evaluate counterparty credit risk and variation margin shortfall under macroeconomic compute shocks.",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Baseline", "+25% Compute Spike", "-25% Capacity Glut").forEachIndexed { idx, label ->
                            FilterChip(
                                selected = selectedStressScenario == idx,
                                onClick = { selectedStressScenario = idx },
                                label = { Text(label, fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
                                    selectedLabelColor = CyberCyan
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val shockFactor = when (selectedStressScenario) {
                        1 -> 0.25
                        2 -> -0.25
                        else -> 0.0
                    }
                    val simulatedShift = portfolio.totalGrossNotional * shockFactor * 0.40
                    val simulatedIm = portfolio.initialMarginReq * (1.0 + shockFactor.coerceAtLeast(0.0))

                    SpecRow("Simulated Scenario Impact", "${if (simulatedShift >= 0) "+" else ""}$${"%,.0f".format(simulatedShift)}")
                    SpecRow("Stressed Initial Margin", "$${"%,.0f".format(simulatedIm)}")
                    SpecRow("Margin Call Risk", if (simulatedIm > portfolio.collateralBalance) "MARGIN CALL TRIGGERED" else "SURPLUS COLLATERAL")
                }
            }
        }

        // 4. Pre-Trade Limits Specification
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = RhinoCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "ACTIVE PRE-TRADE RISK LIMITS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyan,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    SpecRow("Max Single Ticket Quantity", "500 Contracts")
                    SpecRow("Max Single Ticket Notional", "$2,500,000 USD")
                    SpecRow("Price Collar Threshold", "±20% vs Reference Spot")
                    SpecRow("Circuit Breaker Mode", "Automated Emergency Halt")
                }
            }
        }
    }
}

@Composable
fun PositionRowCard(position: Position) {
    val isLong = position.side == OrderSide.BUY
    Card(
        colors = CardDefaults.cardColors(containerColor = RhinoCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = position.instrumentId, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(
                        text = "${if (isLong) "LONG" else "SHORT"} ${position.quantity} Contracts (${"%,d".format(position.netExposureGpuHours)} hrs)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isLong) ProfitGreen else RiskRed,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "UNREALIZED P&L", fontSize = 9.sp, color = TextMuted)
                    Text(
                        text = "${if (position.unrealizedPnl >= 0) "+" else ""}$${"%,.2f".format(position.unrealizedPnl)}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (position.unrealizedPnl >= 0) ProfitGreen else RiskRed
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = RhinoBorder.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(text = "AVG ENTRY", fontSize = 9.sp, color = TextMuted)
                    Text(text = "$${position.averageEntryPrice}", fontSize = 11.sp, color = TextSecondary, fontFamily = FontFamily.Monospace)
                }
                Column {
                    Text(text = "MARK PRICE", fontSize = 9.sp, color = TextMuted)
                    Text(text = "$${position.markPrice}", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "GROSS NOTIONAL", fontSize = 9.sp, color = TextMuted)
                    Text(text = "$${"%,.0f".format(position.grossNotional)}", fontSize = 11.sp, color = TextPrimary, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
