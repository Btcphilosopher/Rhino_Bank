package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val InstitutionalDarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = Color(0xFF001E2E),
    primaryContainer = Color(0xFF004D61),
    onPrimaryContainer = Color(0xFFBCE9FF),
    secondary = InstitutionalGold,
    onSecondary = Color(0xFF332000),
    secondaryContainer = Color(0xFF5E3C00),
    onSecondaryContainer = Color(0xFFFFDDB3),
    tertiary = ProfitGreen,
    onTertiary = Color(0xFF00210E),
    error = RiskRed,
    onError = Color(0xFF38000A),
    background = RhinoBackground,
    onBackground = TextPrimary,
    surface = RhinoSurface,
    onSurface = TextPrimary,
    surfaceVariant = RhinoSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = RhinoBorder,
    outlineVariant = Color(0xFF1E2D4A)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = InstitutionalDarkColorScheme,
        typography = Typography,
        content = content
    )
}
