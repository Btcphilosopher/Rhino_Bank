package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val RhinoBackground = Color(0xFF070B14)
val RhinoSurface = Color(0xFF0E1626)
val RhinoSurfaceVariant = Color(0xFF152238)
val RhinoCard = Color(0xFF18263E)
val RhinoBorder = Color(0xFF243656)

val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDark = Color(0xFF00B0FF)
val InstitutionalGold = Color(0xFFFFB300)
val InstitutionalGoldVariant = Color(0xFFFF8F00)

val ProfitGreen = Color(0xFF00E676)
val ProfitGreenBg = Color(0xFF0A2E1A)
val RiskRed = Color(0xFFFF5252)
val RiskRedBg = Color(0xFF33141E)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
