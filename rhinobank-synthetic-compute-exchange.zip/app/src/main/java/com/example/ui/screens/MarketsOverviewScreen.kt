package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.IndexQuality
import com.example.model.Instrument
import com.example.model.InstrumentType
import com.example.model.ReferenceIndex
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainTab

@Composable
fun MarketsOverviewScreen(
    referenceIndices: List<ReferenceIndex>,
    instruments: List<Instrument>,
    onSelectInstrumentToTrade: (Instrument) -> Unit,
    onNavigateTab: (MainTab) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf<InstrumentType?>(null) }
    var viewingSpecInstrument by remember { mutableStateOf<Instrument?>(null) }

    val filteredInstruments = remember(instruments, selectedFilter) {
        if (selectedFilter == null) instruments else instruments.filter { it.type == selectedFilter }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        // 1. Reference Indices Section
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "REFERENCE COMPUTE INDICES",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyan,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Real-Time Aggregates",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(referenceIndices) { index ->
                        ReferenceIndexCard(index = index)
                    }
                }
            }
        }

        // 2. Instrument Filter Bar
        item {
            Column {
                Text(
                    text = "STANDARDIZED DERIVATIVE CONTRACTS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyan,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedFilter == null,
                            onClick = { selectedFilter = null },
                            label = { Text("All (${instruments.size})", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
                                selectedLabelColor = CyberCyan
                            )
                        )
                    }
                    items(InstrumentType.values()) { type ->
                        val count = instruments.count { it.type == type }
                        if (count > 0) {
                            FilterChip(
                                selected = selectedFilter == type,
                                onClick = { selectedFilter = if (selectedFilter == type) null else type },
                                label = { Text("${type.displayName} ($count)", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
                                    selectedLabelColor = CyberCyan
                                )
                            )
                        }
                    }
                }
            }
        }

        // 3. Instruments List
        items(filteredInstruments) { inst ->
            InstrumentRowCard(
                instrument = inst,
                onTradeClob = {
                    onSelectInstrumentToTrade(inst)
                    onNavigateTab(MainTab.CLOB)
                },
                onViewSpec = { viewingSpecInstrument = inst }
            )
        }
    }

    // Contract Specification Dialog
    viewingSpecInstrument?.let { inst ->
        AlertDialog(
            onDismissRequest = { viewingSpecInstrument = null },
            title = {
                Text(
                    text = inst.name,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyan,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SpecRow("Instrument ID", inst.id)
                    SpecRow("Contract Type", inst.type.displayName)
                    SpecRow("Underlying Reference", inst.underlyingIndex)
                    SpecRow("Hardware Class", inst.hardwareClass)
                    SpecRow("Region", inst.region)
                    SpecRow("Quantity Unit", inst.quantityUnit)
                    SpecRow("Multiplier", "${inst.contractMultiplier} GPU-hours / unit")
                    SpecRow("Tick Size", "$${inst.tickSize}")
                    if (inst.strikePrice != null) {
                        SpecRow("Strike / Aggr Price", "$${inst.strikePrice}")
                    }
                    SpecRow("Settlement Method", inst.settlementMethod)
                    SpecRow("Expiry / Delivery", inst.expiryDescription)
                    SpecRow("Benchmark Protocol", inst.benchmarkDescription)
                }
            },
            confirmButton = {
                TextButton(onClick = { viewingSpecInstrument = null }) {
                    Text("Close", color = CyberCyan)
                }
            },
            containerColor = RhinoCard,
            shape = RoundedCornerShape(12.dp)
        )
    }
}

@Composable
fun ReferenceIndexCard(index: ReferenceIndex) {
    Card(
        colors = CardDefaults.cardColors(containerColor = RhinoCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.width(220.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = index.region,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = InstitutionalGold
                )
                StatusBadge(
                    text = if (index.quality == IndexQuality.LIVE_VERIFIED) "VERIFIED" else "MODEL",
                    isPositive = index.quality == IndexQuality.LIVE_VERIFIED
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = index.name,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = TextSecondary,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = "$${"%.3f".format(index.currentSpotRate)}",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TextPrimary
                )
                Text(
                    text = "${if (index.change24hPct >= 0) "+" else ""}${"%.2f".format(index.change24hPct)}%",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    color = if (index.change24hPct >= 0) ProfitGreen else RiskRed
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${index.hardwareClass} • ${index.sampleDatacenters} Datacenters",
                fontSize = 9.sp,
                color = TextMuted,
                maxLines = 1
            )
        }
    }
}

@Composable
fun InstrumentRowCard(
    instrument: Instrument,
    onTradeClob: () -> Unit,
    onViewSpec: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = RhinoCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = instrument.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${instrument.id} • ${instrument.hardwareClass}",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextMuted
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(CyberCyan.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = instrument.type.displayName.uppercase(),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = RhinoBorder.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "MULTIPLIER", fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                    Text(text = "${instrument.contractMultiplier} hrs", fontSize = 12.sp, color = TextSecondary, fontFamily = FontFamily.Monospace)
                }
                Column {
                    Text(text = "STRIKE / RATE", fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                    Text(text = instrument.strikePrice?.let { "$${it}" } ?: "Market", fontSize = 12.sp, color = InstitutionalGold, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
                Column {
                    Text(text = "EXPIRY", fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                    Text(text = instrument.expiryDescription.split(" ").firstOrNull() ?: "-", fontSize = 12.sp, color = TextSecondary)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(
                        onClick = onViewSpec,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("spec_btn_${instrument.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Contract Specification",
                            tint = TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Button(
                        onClick = onTradeClob,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = RhinoBackground),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("trade_btn_${instrument.id}")
                    ) {
                        Text(text = "Trade CLOB", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun SpecRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 11.sp, color = TextSecondary)
        Text(text = value, fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Medium, fontFamily = FontFamily.Monospace)
    }
}
