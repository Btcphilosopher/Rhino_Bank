package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.MetricCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.QuantLabState

@Composable
fun QuantLabScreen(
    state: QuantLabState,
    onUpdateQuant: (forward: Double, strike: Double, vol: Double, tenor: Double, r: Double, isCall: Boolean, qty: Int) -> Unit,
    onUpdateSwap: (fixedRate: Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var subTab by remember { mutableStateOf(0) } // 0: Options, 1: Swaps, 2: Forward & Basis

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        // Sub-Navigation Tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(RhinoSurfaceVariant)
                    .padding(4.dp)
            ) {
                listOf("Black-76 Options", "Compute Swaps", "Forward & Basis").forEachIndexed { index, title ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (subTab == index) CyberCyan else Color.Transparent)
                            .clickable { subTab = index }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (subTab == index) RhinoBackground else TextSecondary
                        )
                    }
                }
            }
        }

        when (subTab) {
            0 -> {
                // Black-76 Option Pricer
                item {
                    Black76OptionPricerSection(state = state, onUpdateQuant = onUpdateQuant)
                }
            }
            1 -> {
                // Compute Swaps
                item {
                    ComputeSwapSection(state = state, onUpdateSwap = onUpdateSwap)
                }
            }
            2 -> {
                // Forward & Basis
                item {
                    ForwardAndBasisSection(state = state)
                }
            }
        }
    }
}

@Composable
fun Black76OptionPricerSection(
    state: QuantLabState,
    onUpdateQuant: (forward: Double, strike: Double, vol: Double, tenor: Double, r: Double, isCall: Boolean, qty: Int) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = RhinoCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "BLACK-76 OPTION PRICING MODEL",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyan,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "MODEL: RB-QUANT-V3.8",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = InstitutionalGold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Call / Put Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(RhinoSurfaceVariant)
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (state.isCall) CyberCyan else Color.Transparent)
                            .clickable { onUpdateQuant(state.forwardPrice, state.strikePrice, state.volatility, state.tenorYears, state.discountRate, true, state.quantity) }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "EUROPEAN CALL",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (state.isCall) RhinoBackground else TextSecondary
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (!state.isCall) CyberCyan else Color.Transparent)
                            .clickable { onUpdateQuant(state.forwardPrice, state.strikePrice, state.volatility, state.tenorYears, state.discountRate, false, state.quantity) }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "EUROPEAN PUT",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (!state.isCall) RhinoBackground else TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Sliders & Parameters
                ParamSlider(
                    label = "Forward Compute Rate (F)",
                    value = state.forwardPrice,
                    range = 2.0..5.0,
                    formatter = { "$${"%.2f".format(it)} / GPU-hr" },
                    onValueChange = { onUpdateQuant(it, state.strikePrice, state.volatility, state.tenorYears, state.discountRate, state.isCall, state.quantity) }
                )

                ParamSlider(
                    label = "Strike Price (K)",
                    value = state.strikePrice,
                    range = 2.0..5.0,
                    formatter = { "$${"%.2f".format(it)} / GPU-hr" },
                    onValueChange = { onUpdateQuant(state.forwardPrice, it, state.volatility, state.tenorYears, state.discountRate, state.isCall, state.quantity) }
                )

                ParamSlider(
                    label = "Implied Volatility (σ)",
                    value = state.volatility,
                    range = 0.10..1.00,
                    formatter = { "${"%.0f".format(it * 100)}%" },
                    onValueChange = { onUpdateQuant(state.forwardPrice, state.strikePrice, it, state.tenorYears, state.discountRate, state.isCall, state.quantity) }
                )

                ParamSlider(
                    label = "Tenor to Expiry (T)",
                    value = state.tenorYears,
                    range = 0.05..1.00,
                    formatter = { "${"%.0f".format(it * 365)} days (${"%.2f".format(it)} yr)" },
                    onValueChange = { onUpdateQuant(state.forwardPrice, state.strikePrice, state.volatility, it, state.discountRate, state.isCall, state.quantity) }
                )
            }
        }

        // Valuation Results & Greeks Grid
        Text(
            text = "ANALYTICAL VALUATION & GREEKS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = CyberCyan,
            letterSpacing = 1.sp
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(
                title = "PREMIUM / UNIT",
                value = "$${"%.4f".format(state.optionResult.pricePerUnit)}",
                subtitle = "Per GPU-Hour",
                valueColor = InstitutionalGold,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "TOTAL PREMIUM",
                value = "$${"%,.2f".format(state.optionResult.totalPremium)}",
                subtitle = "${state.quantity} x 1,000 hrs",
                valueColor = ProfitGreen,
                modifier = Modifier.weight(1f)
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(
                title = "DELTA (Δ)",
                value = "${"%.4f".format(state.optionResult.delta)}",
                subtitle = "Hedge Ratio",
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "GAMMA (Γ)",
                value = "${"%.4f".format(state.optionResult.gamma)}",
                subtitle = "Curvature",
                modifier = Modifier.weight(1f)
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(
                title = "VEGA (ν)",
                value = "${"%.4f".format(state.optionResult.vega)}",
                subtitle = "Per 1% Vol",
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "THETA (Θ)",
                value = "${"%.4f".format(state.optionResult.theta)}",
                subtitle = "Daily Decay",
                valueColor = RiskRed,
                modifier = Modifier.weight(1f)
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(
                title = "INTRINSIC VALUE",
                value = "$${"%.4f".format(state.optionResult.intrinsicValue)}",
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "TIME VALUE",
                value = "$${"%.4f".format(state.optionResult.timeValue)}",
                modifier = Modifier.weight(1f)
            )
        }

        Text(
            text = "Valuation ID: ${state.optionResult.valuationId} • SHA-256 Verified",
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            color = TextMuted
        )
    }
}

@Composable
fun ComputeSwapSection(
    state: QuantLabState,
    onUpdateSwap: (fixedRate: Double) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = RhinoCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "FIXED-VS-FLOATING COMPUTE SWAP",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyan,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                ParamSlider(
                    label = "Agreed Fixed Rate",
                    value = state.swapFixedRate,
                    range = 2.5..4.0,
                    formatter = { "$${"%.3f".format(it)} / GPU-hr" },
                    onValueChange = onUpdateSwap
                )
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(
                title = "NET SWAP NPV",
                value = "$${"%,.0f".format(state.swapResult.netSwapNpv)}",
                valueColor = if (state.swapResult.netSwapNpv >= 0) ProfitGreen else RiskRed,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "PAR SWAP RATE",
                value = "$${"%.3f".format(state.swapResult.parSwapRate)}",
                valueColor = InstitutionalGold,
                modifier = Modifier.weight(1f)
            )
        }

        Text(
            text = "PERIOD CASHFLOW SCHEDULE (QUARTERLY)",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = CyberCyan,
            letterSpacing = 1.sp
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = RhinoCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "PERIOD", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                    Text(text = "FIXED / FLOAT", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                    Text(text = "NET FLOW", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                    Text(text = "DISCOUNTED NPV", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                }
                Divider(color = RhinoBorder, modifier = Modifier.padding(vertical = 4.dp))

                state.swapResult.periods.forEach { period ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Q${period.period}", fontSize = 11.sp, color = TextSecondary, fontFamily = FontFamily.Monospace)
                        Text(text = "$${period.fixedRate} / $${period.floatingRate}", fontSize = 11.sp, color = TextPrimary, fontFamily = FontFamily.Monospace)
                        Text(
                            text = "$${"%,.0f".format(period.netCashflow)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (period.netCashflow >= 0) ProfitGreen else RiskRed,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "$${"%,.0f".format(period.discountedNpv)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = InstitutionalGold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ForwardAndBasisSection(state: QuantLabState) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = RhinoCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "NON-STORABLE COMPUTE FORWARD CURVE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyan,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "F(0, T) = S(0) * exp( (r + power_drift + scarcity - tech_depreciation) * T )",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = InstitutionalGold
                )
                Spacer(modifier = Modifier.height(12.dp))

                SpecRow("Current Spot Rate (S)", "$${state.forwardSpotRate} / GPU-hr")
                SpecRow("Electricity Drift Rate", "+2.00% p.a.")
                SpecRow("Scarcity / SLA Premium", "+3.00% p.a.")
                SpecRow("Tech Depreciation", "-5.00% p.a.")
                SpecRow("6-Month Forward Price", "$${state.forwardEstimated} / GPU-hr")
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = RhinoCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "REGIONAL BASIS ANALYSIS (LON vs FRA)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyan,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                SpecRow("London H100 Spot", "$3.250 / GPU-hr")
                SpecRow("Frankfurt H100 Spot", "$3.120 / GPU-hr")
                SpecRow("Basis Spread (LON - FRA)", "+$0.130 / GPU-hr")
                SpecRow("Mean Reversion Half-Life", "14.2 Trading Days")
                SpecRow("Implied Fiber Latency Cost", "$0.025 / GPU-hr")
            }
        }
    }
}

@Composable
fun ParamSlider(
    label: String,
    value: Double,
    range: ClosedFloatingPointRange<Double>,
    formatter: (Double) -> String,
    onValueChange: (Double) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, fontSize = 11.sp, color = TextSecondary)
            Text(text = formatter(value), fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onValueChange(it.toDouble()) },
            valueRange = range.start.toFloat()..range.endInclusive.toFloat(),
            colors = SliderDefaults.colors(
                thumbColor = CyberCyan,
                activeTrackColor = CyberCyan,
                inactiveTrackColor = RhinoBorder
            ),
            modifier = Modifier.height(30.dp)
        )
    }
}
