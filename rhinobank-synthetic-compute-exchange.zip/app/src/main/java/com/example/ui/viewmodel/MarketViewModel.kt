package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.MarketEngine
import com.example.model.*
import com.example.quant.QuantEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class MainTab(val title: String) {
    MARKETS("Markets"),
    CLOB("CLOB Depth"),
    OTC_RFQ("Bilateral RFQ"),
    QUANT_LAB("Quant Lab"),
    RISK("Risk & Margin"),
    SETTLEMENT("Settlement & API")
}

data class QuantLabState(
    val forwardPrice: Double = 3.35,
    val strikePrice: Double = 3.40,
    val volatility: Double = 0.42,
    val tenorYears: Double = 0.25,
    val discountRate: Double = 0.045,
    val isCall: Boolean = true,
    val quantity: Int = 10,
    val contractMultiplier: Int = 1000,
    val optionResult: OptionGreeksResult = QuantEngine.priceBlack76(3.35, 3.40, 0.42, 0.25, 0.045, true, 10, 1000),
    val swapFixedRate: Double = 3.25,
    val swapResult: SwapValuationResult = QuantEngine.calculateComputeSwap(3.25, listOf(3.30, 3.34, 3.38, 3.42)),
    val forwardSpotRate: Double = 3.25,
    val forwardEstimated: Double = QuantEngine.priceComputeForward(3.25, 0.5)
)

class MarketViewModel : ViewModel() {

    private val engine = MarketEngine()

    private val _currentTab = MutableStateFlow(MainTab.MARKETS)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _instruments = MutableStateFlow<List<Instrument>>(emptyList())
    val instruments: StateFlow<List<Instrument>> = _instruments.asStateFlow()

    private val _referenceIndices = MutableStateFlow<List<ReferenceIndex>>(emptyList())
    val referenceIndices: StateFlow<List<ReferenceIndex>> = _referenceIndices.asStateFlow()

    private val _selectedInstrument = MutableStateFlow<Instrument?>(null)
    val selectedInstrument: StateFlow<Instrument?> = _selectedInstrument.asStateFlow()

    private val _bids = MutableStateFlow<List<OrderBookLevel>>(emptyList())
    val bids: StateFlow<List<OrderBookLevel>> = _bids.asStateFlow()

    private val _asks = MutableStateFlow<List<OrderBookLevel>>(emptyList())
    val asks: StateFlow<List<OrderBookLevel>> = _asks.asStateFlow()

    private val _trades = MutableStateFlow<List<Trade>>(emptyList())
    val trades: StateFlow<List<Trade>> = _trades.asStateFlow()

    private val _rfqs = MutableStateFlow<List<Rfq>>(emptyList())
    val rfqs: StateFlow<List<Rfq>> = _rfqs.asStateFlow()

    private val _contracts = MutableStateFlow<List<BilateralContract>>(emptyList())
    val contracts: StateFlow<List<BilateralContract>> = _contracts.asStateFlow()

    private val _positions = MutableStateFlow<List<Position>>(emptyList())
    val positions: StateFlow<List<Position>> = _positions.asStateFlow()

    private val _portfolio = MutableStateFlow(engine.currentPortfolio)
    val portfolio: StateFlow<PortfolioRiskSummary> = _portfolio.asStateFlow()

    private val _auditEvents = MutableStateFlow<List<AuditEvent>>(emptyList())
    val auditEvents: StateFlow<List<AuditEvent>> = _auditEvents.asStateFlow()

    private val _isEmergencyHalted = MutableStateFlow(false)
    val isEmergencyHalted: StateFlow<Boolean> = _isEmergencyHalted.asStateFlow()

    private val _quantState = MutableStateFlow(QuantLabState())
    val quantState: StateFlow<QuantLabState> = _quantState.asStateFlow()

    private val _orderSubmitFeedback = MutableStateFlow<String?>(null)
    val orderSubmitFeedback: StateFlow<String?> = _orderSubmitFeedback.asStateFlow()

    init {
        refreshState()
        startMarketDataSimulation()
    }

    fun setTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun selectInstrument(instrument: Instrument) {
        _selectedInstrument.value = instrument
        refreshOrderBook(instrument.id)
    }

    fun refreshOrderBook(instrumentId: String) {
        val (b, a) = engine.getOrderBookSnapshot(instrumentId)
        _bids.value = b
        _asks.value = a
    }

    fun submitOrder(side: OrderSide, limitPrice: Double, quantity: Int) {
        val instrument = _selectedInstrument.value ?: return
        val order = Order(
            clientOrderId = "CLI-" + Random.nextInt(1000, 9999),
            portfolioId = engine.currentPortfolio.portfolioId,
            instrumentId = instrument.id,
            side = side,
            limitPrice = limitPrice,
            initialQuantity = quantity,
            remainingQuantity = quantity
        )

        val (matched, generatedTrades) = engine.submitOrder(order)
        if (matched.status == OrderStatus.REJECTED) {
            _orderSubmitFeedback.value = "Order Rejected by Pre-Trade Risk: Collar/Notional breach"
        } else if (generatedTrades.isNotEmpty()) {
            _orderSubmitFeedback.value = "Executed ${generatedTrades.sumOf { it.quantity }} contracts across ${generatedTrades.size} fills"
        } else {
            _orderSubmitFeedback.value = "Resting limit order placed in order book (#${matched.clientOrderId})"
        }

        refreshState()
    }

    fun clearOrderFeedback() {
        _orderSubmitFeedback.value = null
    }

    fun createRfq(instrumentId: String, side: OrderSide, quantity: Int) {
        engine.createRfq(instrumentId, side, quantity)
        refreshState()
    }

    fun acceptQuote(rfqId: String, quoteId: String) {
        engine.acceptQuote(rfqId, quoteId)
        refreshState()
    }

    fun executeSettlement(contractId: String, fixingPrice: Double) {
        engine.calculateSettlement(contractId, fixingPrice)
        refreshState()
    }

    fun toggleEmergencyStop() {
        val halted = engine.toggleEmergencyStop()
        _isEmergencyHalted.value = halted
        refreshState()
    }

    fun updateQuantParameters(
        forward: Double = _quantState.value.forwardPrice,
        strike: Double = _quantState.value.strikePrice,
        vol: Double = _quantState.value.volatility,
        tenor: Double = _quantState.value.tenorYears,
        r: Double = _quantState.value.discountRate,
        isCall: Boolean = _quantState.value.isCall,
        qty: Int = _quantState.value.quantity
    ) {
        val result = QuantEngine.priceBlack76(forward, strike, vol, tenor, r, isCall, qty, 1000)
        val fwdEst = QuantEngine.priceComputeForward(_quantState.value.forwardSpotRate, tenor)
        _quantState.value = _quantState.value.copy(
            forwardPrice = forward,
            strikePrice = strike,
            volatility = vol,
            tenorYears = tenor,
            discountRate = r,
            isCall = isCall,
            quantity = qty,
            optionResult = result,
            forwardEstimated = fwdEst
        )
    }

    fun updateSwapParameters(fixedRate: Double) {
        val result = QuantEngine.calculateComputeSwap(fixedRate, listOf(3.30, 3.34, 3.38, 3.42))
        _quantState.value = _quantState.value.copy(
            swapFixedRate = fixedRate,
            swapResult = result
        )
    }

    private fun refreshState() {
        _instruments.value = engine.instruments.toList()
        _referenceIndices.value = engine.referenceIndices.toList()
        if (_selectedInstrument.value == null && engine.instruments.isNotEmpty()) {
            _selectedInstrument.value = engine.instruments.first()
        }
        _selectedInstrument.value?.let { refreshOrderBook(it.id) }
        _trades.value = engine.trades.toList()
        _rfqs.value = engine.rfqs.toList()
        _contracts.value = engine.bilateralContracts.toList()
        _positions.value = engine.positions.toList()
        _portfolio.value = engine.currentPortfolio
        _auditEvents.value = engine.auditEvents.toList()
        _isEmergencyHalted.value = engine.isEmergencyHalted
    }

    private fun startMarketDataSimulation() {
        viewModelScope.launch {
            while (true) {
                delay(3000)
                if (!_isEmergencyHalted.value) {
                    // Small deterministic jitter for spot rates
                    for (index in engine.referenceIndices) {
                        val delta = (Random.nextDouble(-0.015, 0.015) * 1000).toLong() / 1000.0
                        index.currentSpotRate = maxOf(0.01, ((index.currentSpotRate + delta) * 1000.0).toLong() / 1000.0)
                        index.change24hPct += (delta * 0.5)
                    }
                    engine.recalculatePortfolioMetrics()
                    refreshState()
                }
            }
        }
    }
}
