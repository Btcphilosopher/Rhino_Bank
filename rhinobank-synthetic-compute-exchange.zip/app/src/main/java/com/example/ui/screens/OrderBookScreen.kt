package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun OrderBookScreen(
    instruments: List<Instrument>,
    selectedInstrument: Instrument?,
    bids: List<OrderBookLevel>,
    asks: List<OrderBookLevel>,
    trades: List<Trade>,
    feedback: String?,
    onSelectInstrument: (Instrument) -> Unit,
    onSubmitOrder: (side: OrderSide, limitPrice: Double, quantity: Int) -> Unit,
    onDismissFeedback: () -> Unit,
    modifier: Modifier = Modifier
) {
    var orderSide by remember { mutableStateOf(OrderSide.BUY) }
    var priceText by remember { mutableStateOf("3.30") }
    var quantityText by remember { mutableStateOf("25") }
    var isDropdownExpanded by remember { mutableStateOf(false) }

    val currentInst = selectedInstrument ?: instruments.firstOrNull()

    // Sync default price with selected instrument if available
    LaunchedEffect(currentInst) {
        if (currentInst != null && currentInst.strikePrice != null) {
            priceText = currentInst.strikePrice.toString()
        }
    }

    val parsedPrice = priceText.toDoubleOrNull() ?: 0.0
    val parsedQty = quantityText.toIntOrNull() ?: 0
    val multiplier = currentInst?.contractMultiplier ?: 1000
    val calculatedNotional = parsedPrice * parsedQty * multiplier

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        // 1. Instrument Selector Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = RhinoCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isDropdownExpanded = true }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "TRADING INSTRUMENT (CLOB)", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                        Text(
                            text = currentInst?.name ?: "Select Instrument",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberCyan
                        )
                        Text(
                            text = "${currentInst?.id} • ${currentInst?.hardwareClass} • ${multiplier} hrs/unit",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextSecondary
                        )
                    }
                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Select", tint = CyberCyan)
                }

                DropdownMenu(
                    expanded = isDropdownExpanded,
                    onDismissRequest = { isDropdownExpanded = false },
                    modifier = Modifier.background(RhinoSurfaceVariant)
                ) {
                    instruments.forEach { inst ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(text = inst.name, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text(text = inst.id, color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                            },
                            onClick = {
                                onSelectInstrument(inst)
                                isDropdownExpanded = false
                            }
                        )
                    }
                }
            }
        }

        // Feedback Banner
        if (feedback != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (feedback.contains("Rejected")) RiskRedBg else ProfitGreenBg
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            if (feedback.contains("Rejected")) RiskRed else ProfitGreen,
                            RoundedCornerShape(8.dp)
                        )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = if (feedback.contains("Rejected")) Icons.Default.Warning else Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (feedback.contains("Rejected")) RiskRed else ProfitGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = feedback,
                                fontSize = 12.sp,
                                color = if (feedback.contains("Rejected")) RiskRed else ProfitGreen,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        TextButton(onClick = onDismissFeedback) {
                            Text("OK", color = TextPrimary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // 2. Order Entry Ticket Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = RhinoCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ORDER ENTRY TICKET",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = InstitutionalGold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Buy / Sell Selector
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(RhinoSurfaceVariant)
                            .padding(2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (orderSide == OrderSide.BUY) ProfitGreen else Color.Transparent)
                                .clickable { orderSide = OrderSide.BUY }
                                .padding(vertical = 8.dp)
                                .testTag("buy_side_tab"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "BUY / LONG",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (orderSide == OrderSide.BUY) RhinoBackground else TextSecondary
                            )
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (orderSide == OrderSide.SELL) RiskRed else Color.Transparent)
                                .clickable { orderSide = OrderSide.SELL }
                                .padding(vertical = 8.dp)
                                .testTag("sell_side_tab"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "SELL / SHORT",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (orderSide == OrderSide.SELL) TextPrimary else TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Input Row: Price and Quantity
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = priceText,
                            onValueChange = { priceText = it },
                            label = { Text("Limit Price ($)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("order_price_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = RhinoBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = quantityText,
                            onValueChange = { quantityText = it },
                            label = { Text("Quantity (Units)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("order_qty_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = RhinoBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Pre-Trade Risk Indicators
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(RhinoSurface)
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "NOTIONAL VALUE", fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                            Text(
                                text = "$${"%,.2f".format(calculatedNotional)}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = if (calculatedNotional > 2_500_000.0) RiskRed else TextPrimary
                            )
                        }
                        Column {
                            Text(text = "GPU-HOURS", fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                            Text(
                                text = "${"%,d".format(parsedQty.toLong() * multiplier)} hrs",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TextSecondary
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "PRE-TRADE RISK", fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (calculatedNotional > 2_500_000.0) "BREACH > $2.5M" else if (parsedQty > 500) "QTY BREACH" else "PASS OK",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (calculatedNotional > 2_500_000.0 || parsedQty > 500) RiskRed else ProfitGreen
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            if (parsedPrice > 0.0 && parsedQty > 0) {
                                onSubmitOrder(orderSide, parsedPrice, parsedQty)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (orderSide == OrderSide.BUY) ProfitGreen else RiskRed,
                            contentColor = if (orderSide == OrderSide.BUY) RhinoBackground else TextPrimary
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("submit_order_btn")
                    ) {
                        Text(
                            text = "SUBMIT ${if (orderSide == OrderSide.BUY) "BUY" else "SELL"} LIMIT ORDER",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // 3. Central Order Book Depth Ladder (L2)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = RhinoCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "L2 ORDER BOOK DEPTH",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberCyan,
                            letterSpacing = 1.sp
                        )
                        val bestBid = bids.firstOrNull()?.price
                        val bestAsk = asks.firstOrNull()?.price
                        val spread = if (bestBid != null && bestAsk != null) bestAsk - bestBid else null
                        Text(
                            text = if (spread != null) "Spread: $${"%.3f".format(spread)}" else "No Spread",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "SIDE / ORDERS", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(text = "PRICE ($)", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(text = "QUANTITY", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    }
                    Divider(color = RhinoBorder)

                    // Asks (Sells)
                    if (asks.isEmpty()) {
                        Text(text = "No resting asks", fontSize = 11.sp, color = TextMuted, modifier = Modifier.padding(vertical = 8.dp))
                    } else {
                        asks.take(4).reversed().forEach { ask ->
                            OrderBookRow(level = ask, isBid = false)
                        }
                    }

                    // Spread line
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(RhinoSurfaceVariant.copy(alpha = 0.5f))
                            .padding(vertical = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "--- SPREAD ---", fontSize = 9.sp, color = InstitutionalGold, letterSpacing = 2.sp)
                    }

                    // Bids (Buys)
                    if (bids.isEmpty()) {
                        Text(text = "No resting bids", fontSize = 11.sp, color = TextMuted, modifier = Modifier.padding(vertical = 8.dp))
                    } else {
                        bids.take(4).forEach { bid ->
                            OrderBookRow(level = bid, isBid = true)
                        }
                    }
                }
            }
        }

        // 4. Recent Executions / Trades Stream
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = RhinoCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "EXECUTED TRADES STREAM",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyan,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    if (trades.isEmpty()) {
                        Text(
                            text = "No trades executed yet. Place an aggressive marketable limit order to match resting depth.",
                            fontSize = 11.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    } else {
                        trades.take(5).forEach { trade ->
                            TradeRow(trade = trade)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OrderBookRow(level: OrderBookLevel, isBid: Boolean) {
    val color = if (isBid) ProfitGreen else RiskRed
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "${if (isBid) "BID" else "ASK"} (${level.orderCount})",
            fontSize = 11.sp,
            color = TextSecondary,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = "$${"%.3f".format(level.price)}",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = color,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = "${level.quantity}x",
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = TextPrimary,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun TradeRow(trade: Trade) {
    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = "T-${trade.id} • ${trade.quantity}x @ $${trade.price}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = "${trade.buyerPortfolioId} ⇄ ${trade.sellerPortfolioId}", fontSize = 9.sp, color = TextMuted)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(text = "$${"%,.0f".format(trade.notional)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InstitutionalGold, fontFamily = FontFamily.Monospace)
            Text(text = timeFormat.format(Date(trade.timestamp)), fontSize = 9.sp, color = TextMuted)
        }
    }
}
