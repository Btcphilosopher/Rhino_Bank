# RB-SCDM Operational Runbook & Disaster Recovery

### Emergency Kill Switch & Market Suspension
The simulation environment provides an authorized emergency circuit breaker:
- Endpoint: `POST /api/v1/admin/emergency-stop`
- Action:
  1. Immediately halts CLOB matching engine across all order books.
  2. Cancels all pending resting limit orders.
  3. Rejects new RFQs and orders with `STATUS: MARKET_SUSPENDED`.
  4. Records cryptographic SHA-256 event in audit ledger.

### Data Recovery & Idempotency
- Every order and RFQ acceptance requires an `idempotency_key`.
- In case of network timeout, repeating the request with the identical `idempotency_key` returns the stored state without double execution.
