# RhinoBank Synthetic Compute Derivatives Market (RB-SCDM)
## Systems Architecture & Boundary Documentation

### 1. Architectural Philosophy
RB-SCDM is designed as an institutional market system where compute capacity (GPU accelerator-hours, benchmark clusters, inference tokens) serves as the underlying reference asset for standardized derivative contracts.

Compute is fundamentally non-storable: unlike crude oil or precious metals, idle GPU hours perish instantaneously. Consequently, pricing models must not apply naive storable-commodity cost-of-carry equations. Instead, contracts model availability, electrical power drift, marginal datacenter pricing, regional latency basis, and hardware technology depreciation.

### 2. Service Domain Boundaries

1. **Market Core Engine (Rust)**
   - Strict ownership of order matching, execution sequence, and lifecycle state.
   - Deterministic price-time priority.
   - Pre-trade risk enforcement gate: rejects orders that breach maximum notional, order size, or price collars prior to order book matching.
   - Invariant: cumulative filled quantity cannot exceed initial order quantity.

2. **Quantitative Pricing Microservice (Python / NumPy / SciPy)**
   - Isolated analytical calculation engine.
   - Black-76 model for European options on forward compute rates.
   - Fixed-vs-floating swap schedule generator and Net Present Value (NPV) calculation.
   - Non-storable forward curve generator incorporating electricity drift and scarcity premiums.
   - Versioned model outputs with reproducible valuation IDs.

3. **Statistical Validation (R)**
   - GARCH volatility modeling and rolling realized volatility estimators.
   - Cointegration and error correction testing on regional compute basis (e.g. London vs Frankfurt).
   - Value-at-Risk (VaR) distribution backtesting.

4. **Persistence & Audit Layer (PostgreSQL)**
   - `NUMERIC(18, 6)` arithmetic precision for monetary values to eliminate binary floating-point roundoff errors.
   - Append-only cryptographic audit trail linking events via SHA-256 hashes.
