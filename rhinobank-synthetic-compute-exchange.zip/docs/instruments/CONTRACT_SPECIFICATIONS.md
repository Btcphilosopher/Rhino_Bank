# RB-SCDM Standardized Contract Specifications

### 1. Compute Reference Forwards & Futures
- **Identifier:** `RB-H100-FWD-Q4-26`, `RB-H100-FUT-DEC26`
- **Underlying Index:** `RB-GPU-REF-LON` (TWAP of Tier-1 London Datacenters)
- **Hardware Class:** NVIDIA H100 SXM5 80GB
- **Quantity Unit:** GPU Accelerator-Hour
- **Contract Multiplier:** 1,000 GPU-hours
- **Tick Size:** $0.01 per GPU-hour
- **Payoff Formula:**
  $$\text{Payoff} = q \cdot m \cdot (P_{\text{final}} - K)$$
- **Settlement:** Cash-settled against terminal observation fixing TWAP.

### 2. European Compute Options
- **Identifiers:** `RB-H100-OPT-C340-DEC26` (Call), `RB-H100-OPT-P320-DEC26` (Put)
- **Underlying:** Forward Compute Index Rate
- **Exercise Style:** European (exercise exclusively at expiry)
- **Settlement:** Cash-settled vs fixing TWAP
- **Pricing Baseline:** Black-76 model with analytical Greeks ($\Delta, \Gamma, \mathcal{V}, \Theta$).

### 3. Compute-Capacity Swaps
- **Identifier:** `RB-SWAP-H100-1YR-26`
- **Tenor:** 1 Year (4 quarterly compounding calculation periods)
- **Fixed Leg:** Agreed fixed rate ($/GPU-hr) paid quarterly
- **Floating Leg:** Realized quarterly average of `RB-GPU-REF-LON`
- **Multiplier:** 8,760 hours (annualized continuous compute block per unit)

### 4. Regional Basis Swaps
- **Identifier:** `RB-BASIS-LON-FRA-DEC26`
- **Underlying Spread:** `RB-GPU-REF-LON` minus `RB-GPU-REF-FRA`
- **Economic Purpose:** Hedges regional datacenter power cost variations and interconnect fiber latency arbitrage.
