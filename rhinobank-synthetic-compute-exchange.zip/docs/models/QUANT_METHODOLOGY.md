# RB-SCDM Quantitative Valuation Methodology

### 1. Black-76 Forward Option Pricing Model
Compute European options reference forward or futures contracts on the underlying reference index $F$.
The closed-form pricing equation is:

$$d_1 = \frac{\ln(F/K) + \frac{1}{2}\sigma^2 T}{\sigma\sqrt{T}}$$
$$d_2 = d_1 - \sigma\sqrt{T}$$
$$C = e^{-rT} \left[ F \cdot N(d_1) - K \cdot N(d_2) \right]$$
$$P = e^{-rT} \left[ K \cdot N(-d_2) - F \cdot N(-d_1) \right]$$

### 2. Analytical Greeks
- **Delta:** $\Delta_C = e^{-rT} N(d_1)$, $\Delta_P = -e^{-rT} N(-d_1)$
- **Gamma:** $\Gamma = \frac{e^{-rT} n(d_1)}{F \sigma \sqrt{T}}$
- **Vega:** $\mathcal{V} = e^{-rT} F \sqrt{T} n(d_1)$
- **Theta:** $\Theta_C = rC - \frac{e^{-rT} F \sigma n(d_1)}{2\sqrt{T}}$

### 3. Non-Storable Compute Forward Curve Construction
Unlike storable physical commodities with storage convenience yield, non-storable compute reflects expected future supply capacity and electrical input cost drift:

$$F(0, T) = S_0 \cdot \exp\left( (r + \mu_{\text{power}} + \lambda_{\text{scarcity}} - \delta_{\text{depreciation}}) \cdot T \right)$$
