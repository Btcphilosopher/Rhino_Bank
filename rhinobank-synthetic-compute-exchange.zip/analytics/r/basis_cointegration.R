# RhinoBank Synthetic Compute Derivatives Market (RB-SCDM)
# Quantitative Research & Statistical Validation: Regional Basis Cointegration
# Platform Identifier: RB-SCDM | Analytics Module R-BASIS-1.0

# Analyzes long-run equilibrium between London (LON) and Frankfurt (FRA) compute reference indices
test_basis_cointegration <- function(lon_rates, fra_rates) {
  spread <- lon_rates - fra_rates
  mean_spread <- mean(spread)
  sd_spread <- sd(spread)
  
  # AR(1) mean-reversion test: delta(spread) = alpha + beta * spread_{t-1} + e
  n <- length(spread)
  y <- diff(spread)
  x <- spread[1:(n-1)]
  
  fit <- lm(y ~ x)
  summary_fit <- summary(fit)
  
  beta <- coef(fit)["x"]
  half_life_days <- if (beta < 0) -log(2) / log(1 + beta) else Inf
  
  list(
    mean_spread_usd = mean_spread,
    sd_spread_usd = sd_spread,
    mean_reversion_speed_beta = beta,
    half_life_days = half_life_days,
    r_squared = summary_fit$r.squared
  )
}

cat("=== RhinoBank SCDM Regional Basis Cointegration Test ===\n")
set.seed(42)
n <- 180
lon <- 3.25 + cumsum(rnorm(n, 0, 0.03))
# FRA follows LON with stationary error spread (arbitrage corridor)
spread_noise <- arima.sim(list(order=c(1,0,0), ar=0.85), n=n, sd=0.04)
fra <- lon - 0.13 + as.numeric(spread_noise)

results <- test_basis_cointegration(lon, fra)
cat(sprintf("Mean Spread (LON - FRA): $%.4f/GPU-hr\n", results$mean_spread_usd))
cat(sprintf("Basis Volatility: $%.4f\n", results$sd_spread_usd))
cat(sprintf("Mean Reversion Half-Life: %.1f trading days\n", results$half_life_days))
cat(sprintf("Equilibrium R-squared: %.3f\n", results$r_squared))
