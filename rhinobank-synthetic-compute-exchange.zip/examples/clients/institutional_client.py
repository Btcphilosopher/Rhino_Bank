#!/usr/bin/env python3
"""
RhinoBank Synthetic Compute Derivatives Market (RB-SCDM)
Institutional Client API Integration Example
"""

import requests
import json
import uuid

API_BASE = "http://localhost:8080/api/v1"
PRICING_BASE = "http://localhost:8000/api/v1"

def run_institutional_demo():
    print("=" * 65)
    print(" RhinoBank Synthetic Compute Derivatives Market (RB-SCDM)")
    print(" Institutional Participant Lifecycle Integration")
    print("=" * 65)

    # 1. Price European Compute Call Option via Quantitative Engine
    print("\n[Step 1] Requesting Black-76 Valuation for H100 Option...")
    pricing_payload = {
        "instrument_id": "RB-H100-OPT-C340-DEC26",
        "forward_price": 3.35,
        "strike": 3.40,
        "volatility": 0.42,
        "time_to_expiry_years": 0.25,
        "discount_rate": 0.045,
        "quantity": 10,
        "contract_multiplier": 1000,
        "is_call": True
    }
    try:
        res = requests.post(f"{PRICING_BASE}/pricing/option", json=pricing_payload, timeout=3)
        if res.status_code == 200:
            val = res.json()
            print(f"  Valuation ID:   {val['valuation_id']}")
            print(f"  Model Version:  {val['model_version']}")
            print(f"  Premium / Unit: ${val['price_per_unit']:.4f} / GPU-hr")
            print(f"  Total Premium:  ${val['total_premium']:,.2f}")
            print(f"  Greeks:         Delta={val['delta']:.4f}, Gamma={val['gamma']:.4f}, Vega={val['vega']:.4f}")
        else:
            print(f"  Pricing Error: {res.status_code}")
    except Exception as e:
        print(f"  Pricing service offline (simulated fallback applied): {e}")

    # 2. Central Order Book Submission with Pre-Trade Risk Enforcement
    print("\n[Step 2] Submitting Limit Order to Central Order Book...")
    order_payload = {
        "client_order_id": f"ORD-{uuid.uuid4().hex[:8].upper()}",
        "portfolio_id": "PORT-RHINO-PROP",
        "instrument_id": "RB-H100-FWD-Q4-26",
        "side": "BUY",
        "limit_price": 3.30,
        "quantity": 50,
        "idempotency_key": str(uuid.uuid4())
    }
    try:
        res = requests.post(f"{API_BASE}/orders", json=order_payload, timeout=3)
        if res.status_code in [200, 201]:
            ord_res = res.json()
            print(f"  Order ID:   {ord_res['order_id']}")
            print(f"  Status:     {ord_res['status']}")
            print(f"  Filled Qty: {ord_res['filled_quantity']}")
            print(f"  Remaining:  {ord_res['remaining_quantity']}")
        else:
            print(f"  Order Response ({res.status_code}): {res.text}")
    except Exception as e:
        print(f"  Market Core offline (simulated fallback): {e}")

    # 3. Retrieve Order Book Snapshot
    print("\n[Step 3] Fetching L2 Depth Snapshot for RB-H100-FWD-Q4-26...")
    try:
        res = requests.get(f"{API_BASE}/markets/RB-H100-FWD-Q4-26/quote", timeout=3)
        if res.status_code == 200:
            snapshot = res.json()
            print(f"  Bids Depth: {len(snapshot.get('bids', []))} levels")
            print(f"  Asks Depth: {len(snapshot.get('asks', []))} levels")
    except Exception as e:
        print(f"  Fetch skipped: {e}")

    print("\n[Success] Institutional workflow simulation finished.")

if __name__ == "__main__":
    run_institutional_demo()
