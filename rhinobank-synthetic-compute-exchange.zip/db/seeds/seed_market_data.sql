-- Seed Data for RhinoBank Synthetic Compute Derivatives Market (RB-SCDM)

-- 1. Reference Indices
INSERT INTO reference_indices (index_id, hardware_class, benchmark_methodology, region, current_spot_rate, quality_status)
VALUES
('RB-GPU-REF-LON', 'NVIDIA_H100_SXM5_80GB', 'TWAP_TOP5_TIER1_DATACENTERS', 'LON', 3.250000, 'LIVE_VERIFIED'),
('RB-GPU-REF-FRA', 'NVIDIA_H100_SXM5_80GB', 'TWAP_TOP5_TIER1_DATACENTERS', 'FRA', 3.120000, 'LIVE_VERIFIED'),
('RB-CPU-REF-EU',  'AMD_EPYC_9654_128CORE',  'VOLUME_WEIGHTED_CLOUD_MEDIAN', 'EU', 0.045000, 'LIVE_VERIFIED'),
('RB-COMP-INDEX-EU', 'SYNTHETIC_AI_BASKET_V1', 'BASKET_80_H100_20_CPU_NORMALIZED', 'EU', 142.500000, 'MODELLED'),
('RB-GPU-BASIS-LON-FRA', 'NVIDIA_H100_SPREAD', 'DIFFERENTIAL_LON_MINUS_FRA', 'EU', 0.130000, 'LIVE_VERIFIED')
ON CONFLICT (index_id) DO UPDATE SET current_spot_rate = EXCLUDED.current_spot_rate;

-- 2. Registered Standardized Derivative Instruments
INSERT INTO instruments (instrument_id, specification_version, instrument_type, underlying_index, hardware_class, region, contract_multiplier, strike_price, expiry_timestamp, settlement_date, market_status)
VALUES
('RB-H100-FWD-Q4-26', '1.0', 'FORWARD', 'RB-GPU-REF-LON', 'NVIDIA_H100_SXM5_80GB', 'LON', 1000, 3.300000, '2026-12-31 23:59:59+00', '2027-01-02 12:00:00+00', 'ACTIVE'),
('RB-H100-FUT-DEC26', '1.0', 'FUTURES', 'RB-GPU-REF-LON', 'NVIDIA_H100_SXM5_80GB', 'LON', 1000, 3.350000, '2026-12-18 16:00:00+00', '2026-12-20 12:00:00+00', 'ACTIVE'),
('RB-H100-OPT-C340-DEC26', '1.0', 'EUROPEAN_OPTION', 'RB-GPU-REF-LON', 'NVIDIA_H100_SXM5_80GB', 'LON', 1000, 3.400000, '2026-12-18 16:00:00+00', '2026-12-20 12:00:00+00', 'ACTIVE'),
('RB-H100-OPT-P320-DEC26', '1.0', 'EUROPEAN_OPTION', 'RB-GPU-REF-LON', 'NVIDIA_H100_SXM5_80GB', 'LON', 1000, 3.200000, '2026-12-18 16:00:00+00', '2026-12-20 12:00:00+00', 'ACTIVE'),
('RB-SWAP-H100-1YR-26', '1.0', 'SWAP', 'RB-GPU-REF-LON', 'NVIDIA_H100_SXM5_80GB', 'LON', 8760, 3.200000, '2027-10-09 23:59:59+00', '2027-10-15 12:00:00+00', 'ACTIVE'),
('RB-BASIS-LON-FRA-DEC26', '1.0', 'REGIONAL_BASIS', 'RB-GPU-BASIS-LON-FRA', 'NVIDIA_H100_SXM5_80GB', 'EU', 1000, 0.120000, '2026-12-18 16:00:00+00', '2026-12-20 12:00:00+00', 'ACTIVE')
ON CONFLICT (instrument_id) DO NOTHING;

-- 3. Institutional Portfolios
INSERT INTO portfolios (portfolio_id, institution_name, collateral_balance, initial_margin_requirement, variation_margin_requirement, risk_status)
VALUES
('PORT-RHINO-PROP', 'RhinoBank Quantitative Principal Trading', 10000000.000000, 450000.000000, 0.000000, 'HEALTHY'),
('PORT-HYPERSCALE-A', 'Global Cloud Provider Treasury', 25000000.000000, 1200000.000000, 0.000000, 'HEALTHY'),
('PORT-AI-LABS-ALPHA', 'Frontier Foundation AI Lab Hedging Desk', 5000000.000000, 380000.000000, 0.000000, 'HEALTHY')
ON CONFLICT (portfolio_id) DO NOTHING;
