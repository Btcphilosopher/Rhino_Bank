-- RhinoBank Synthetic Compute Derivatives Market (RB-SCDM)
-- Initial PostgreSQL DDL Migration 001
-- Precision: NUMERIC(18, 6) for financial cash amounts and contract rates

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Reference Indices Table
CREATE TABLE IF NOT EXISTS reference_indices (
    index_id VARCHAR(64) PRIMARY KEY,
    hardware_class VARCHAR(64) NOT NULL,
    benchmark_methodology VARCHAR(128) NOT NULL,
    region VARCHAR(32) NOT NULL,
    currency VARCHAR(8) NOT NULL DEFAULT 'USD',
    measurement_unit VARCHAR(32) NOT NULL DEFAULT 'USD_PER_GPU_HR',
    current_spot_rate NUMERIC(18, 6) NOT NULL,
    quality_status VARCHAR(32) NOT NULL DEFAULT 'SIMULATED',
    last_updated TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Raw and Aggregated Price Observations
CREATE TABLE IF NOT EXISTS price_observations (
    observation_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    index_id VARCHAR(64) REFERENCES reference_indices(index_id),
    source_id VARCHAR(64) NOT NULL,
    observed_rate NUMERIC(18, 6) NOT NULL,
    hardware_spec VARCHAR(64) NOT NULL,
    region VARCHAR(32) NOT NULL,
    observation_type VARCHAR(32) NOT NULL, -- 'SPOT', 'RESERVED_1YR', 'SPOT_INTERRUPTIBLE'
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'LIVE_VERIFIED',
    observed_at TIMESTAMPTZ NOT NULL,
    ingested_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Versioned Instruments Registry
CREATE TABLE IF NOT EXISTS instruments (
    instrument_id VARCHAR(64) PRIMARY KEY,
    specification_version VARCHAR(16) NOT NULL DEFAULT '1.0',
    instrument_type VARCHAR(32) NOT NULL, -- 'FORWARD', 'FUTURES', 'SWAP', 'EUROPEAN_OPTION', 'REGIONAL_BASIS'
    underlying_index VARCHAR(64) REFERENCES reference_indices(index_id),
    hardware_class VARCHAR(64) NOT NULL,
    region VARCHAR(32) NOT NULL,
    quantity_unit VARCHAR(32) NOT NULL DEFAULT 'GPU_HOUR',
    contract_multiplier INT NOT NULL DEFAULT 1000,
    currency VARCHAR(8) NOT NULL DEFAULT 'USD',
    tick_size NUMERIC(18, 6) NOT NULL DEFAULT 0.010000,
    strike_price NUMERIC(18, 6),
    expiry_timestamp TIMESTAMPTZ NOT NULL,
    settlement_date TIMESTAMPTZ NOT NULL,
    settlement_methodology VARCHAR(64) NOT NULL DEFAULT 'CASH_SETTLED_TWAP',
    market_status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. Portfolios and Institutional Accounts
CREATE TABLE IF NOT EXISTS portfolios (
    portfolio_id VARCHAR(64) PRIMARY KEY,
    institution_name VARCHAR(128) NOT NULL,
    collateral_currency VARCHAR(8) NOT NULL DEFAULT 'USD',
    collateral_balance NUMERIC(18, 6) NOT NULL DEFAULT 1000000.000000,
    initial_margin_requirement NUMERIC(18, 6) NOT NULL DEFAULT 0.000000,
    variation_margin_requirement NUMERIC(18, 6) NOT NULL DEFAULT 0.000000,
    risk_status VARCHAR(32) NOT NULL DEFAULT 'HEALTHY',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. Central Limit Order Book Orders
CREATE TABLE IF NOT EXISTS orders (
    order_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_order_id VARCHAR(64) NOT NULL,
    portfolio_id VARCHAR(64) REFERENCES portfolios(portfolio_id),
    instrument_id VARCHAR(64) REFERENCES instruments(instrument_id),
    side VARCHAR(8) NOT NULL, -- 'BUY', 'SELL'
    quantity INT NOT NULL,
    limit_price NUMERIC(18, 6) NOT NULL,
    order_type VARCHAR(16) NOT NULL DEFAULT 'LIMIT',
    time_in_force VARCHAR(16) NOT NULL DEFAULT 'GTC',
    filled_quantity INT NOT NULL DEFAULT 0,
    remaining_quantity INT NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'NEW', -- 'NEW', 'PARTIALLY_FILLED', 'FILLED', 'CANCELLED', 'REJECTED'
    rejection_reason TEXT,
    idempotency_key VARCHAR(128) UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. Executions and Trades
CREATE TABLE IF NOT EXISTS trades (
    trade_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    instrument_id VARCHAR(64) REFERENCES instruments(instrument_id),
    maker_order_id UUID REFERENCES orders(order_id),
    taker_order_id UUID REFERENCES orders(order_id),
    buyer_portfolio_id VARCHAR(64) REFERENCES portfolios(portfolio_id),
    seller_portfolio_id VARCHAR(64) REFERENCES portfolios(portfolio_id),
    execution_price NUMERIC(18, 6) NOT NULL,
    executed_quantity INT NOT NULL,
    contract_multiplier INT NOT NULL,
    total_notional NUMERIC(18, 6) NOT NULL,
    currency VARCHAR(8) NOT NULL DEFAULT 'USD',
    executed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. Bilateral OTC RFQs and Quotes
CREATE TABLE IF NOT EXISTS rfqs (
    rfq_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_portfolio_id VARCHAR(64) REFERENCES portfolios(portfolio_id),
    instrument_id VARCHAR(64) REFERENCES instruments(instrument_id),
    side VARCHAR(8) NOT NULL,
    quantity INT NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'OPEN', -- 'OPEN', 'QUOTED', 'ACCEPTED', 'EXPIRED', 'CANCELLED'
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS quotes (
    quote_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rfq_id UUID REFERENCES rfqs(rfq_id),
    dealer_id VARCHAR(64) NOT NULL,
    quoted_rate NUMERIC(18, 6) NOT NULL,
    valid_until TIMESTAMPTZ NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE' -- 'ACTIVE', 'ACCEPTED', 'EXPIRED', 'WITHDRAWN'
);

-- 8. Bilateral Derivative Contracts
CREATE TABLE IF NOT EXISTS contracts (
    contract_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    instrument_id VARCHAR(64) REFERENCES instruments(instrument_id),
    party_a_portfolio VARCHAR(64) REFERENCES portfolios(portfolio_id),
    party_b_portfolio VARCHAR(64) REFERENCES portfolios(portfolio_id),
    agreed_rate NUMERIC(18, 6) NOT NULL,
    quantity INT NOT NULL,
    contract_multiplier INT NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE', -- 'ACTIVE', 'FIXING_PENDING', 'FIXED', 'SETTLED', 'CANCELLED'
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 9. Settled Financial Cash Calculations
CREATE TABLE IF NOT EXISTS settlements (
    settlement_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID REFERENCES contracts(contract_id),
    fixing_price NUMERIC(18, 6) NOT NULL,
    settlement_amount NUMERIC(18, 6) NOT NULL,
    payer_portfolio VARCHAR(64) REFERENCES portfolios(portfolio_id),
    receiver_portfolio VARCHAR(64) REFERENCES portfolios(portfolio_id),
    status VARCHAR(32) NOT NULL DEFAULT 'SETTLEMENT_CALCULATED',
    calculated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 10. Append-Only Cryptographic Audit Log
CREATE TABLE IF NOT EXISTS audit_events (
    audit_id BIGSERIAL PRIMARY KEY,
    event_uuid UUID NOT NULL DEFAULT uuid_generate_v4(),
    entity_type VARCHAR(64) NOT NULL,
    entity_id VARCHAR(64) NOT NULL,
    action VARCHAR(64) NOT NULL,
    actor_identity VARCHAR(64) NOT NULL,
    payload JSONB NOT NULL,
    sha256_hash VARCHAR(64) NOT NULL,
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_orders_instrument ON orders(instrument_id, status);
CREATE INDEX IF NOT EXISTS idx_trades_instrument ON trades(instrument_id, executed_at);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_events(entity_type, entity_id);
