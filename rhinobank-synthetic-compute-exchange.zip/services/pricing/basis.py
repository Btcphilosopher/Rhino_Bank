"""
RhinoBank Synthetic Compute Derivatives Market (RB-SCDM)
Basis & Non-Storable Forward Curve Valuation
"""

import math
from typing import Dict, Any

class ComputeForwardEngine:
    @staticmethod
    def calculate_forward(
        spot_rate: float,
        time_to_delivery_years: float,
        risk_free_rate: float,
        electricity_cost_drift: float,
        capacity_scarcity_premium: float,
        technology_depreciation_rate: float,
    ) -> Dict[str, Any]:
        """
        Forward valuation for non-storable compute capacity.
        Note: Unlike storable commodities (metals/crude), compute cannot be stored in inventory.
        F(0, T) = S(0) * exp( (r + power_drift + scarcity_premium - tech_depreciation) * T )
        """
        drift = risk_free_rate + electricity_cost_drift + capacity_scarcity_premium - technology_depreciation_rate
        forward_price = spot_rate * math.exp(drift * time_to_delivery_years)
        basis = forward_price - spot_rate

        return {
            "spot_rate": round(spot_rate, 6),
            "forward_price": round(forward_price, 6),
            "absolute_basis": round(basis, 6),
            "annualized_basis_bps": round((basis / spot_rate) * 10000.0 / time_to_delivery_years, 2) if time_to_delivery_years > 0 else 0.0,
            "net_drift_rate": round(drift, 4),
        }

    @staticmethod
    def calculate_regional_basis(
        spot_region_a: float,
        spot_region_b: float,
        latency_penalty: float = 0.0,
        power_spread: float = 0.0,
    ) -> Dict[str, Any]:
        """
        Regional basis differential between two compute hubs (e.g., London vs Frankfurt).
        """
        spread = spot_region_a - spot_region_b
        return {
            "region_a_spot": round(spot_region_a, 6),
            "region_b_spot": round(spot_region_b, 6),
            "basis_spread": round(spread, 6),
            "implied_arbitrage_cost": round(latency_penalty + power_spread, 6),
        }
