"""
RhinoBank Synthetic Compute Derivatives Market (RB-SCDM)
Quantitative Pricing API Microservice
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import uuid
import datetime
from typing import List, Optional

from black76 import Black76Model
from swaps import ComputeSwapEngine
from basis import ComputeForwardEngine

app = FastAPI(
    title="RhinoBank SCDM Quantitative Pricing Service",
    version="1.4.0",
    docs_url="/docs",
    openapi_url="/api/v1/openapi.json"
)

MODEL_VERSION = "RB-QUANT-V3.8"

class OptionPricingRequest(BaseModel):
    instrument_id: str
    forward_price: float = Field(gt=0, description="Forward index reference price")
    strike: float = Field(gt=0, description="Option strike price")
    volatility: float = Field(gt=0, description="Annualized volatility")
    time_to_expiry_years: float = Field(gt=0, description="Time to expiry in years")
    discount_rate: float = Field(ge=0, description="Continuously compounded discount rate")
    quantity: int = Field(gt=0, default=1)
    contract_multiplier: int = Field(gt=0, default=1000)
    is_call: bool = True

class ForwardPricingRequest(BaseModel):
    instrument_id: str
    spot_rate: float = Field(gt=0)
    time_to_delivery_years: float = Field(gt=0)
    risk_free_rate: float = 0.045
    electricity_cost_drift: float = 0.02
    capacity_scarcity_premium: float = 0.03
    technology_depreciation_rate: float = 0.05

class SwapPricingRequest(BaseModel):
    instrument_id: str
    fixed_rate: float = Field(gt=0)
    forward_curve: List[float] = Field(default=[3.30, 3.32, 3.35, 3.38])
    tenor_periods: int = Field(default=4)
    hours_per_period: int = Field(default=2190) # Quarter
    quantity_units: int = Field(default=10)
    annual_discount_rate: float = Field(default=0.045)

@app.get("/health")
def health_check():
    return {
        "status": "HEALTHY",
        "service": "rb-scdm-pricing-service",
        "model_version": MODEL_VERSION,
        "environment": "SIMULATION"
    }

@app.post("/api/v1/pricing/option")
def price_option(req: OptionPricingRequest):
    try:
        res = Black76Model.price_european_option(
            forward_price=req.forward_price,
            strike=req.strike,
            volatility=req.volatility,
            time_to_expiry_years=req.time_to_expiry_years,
            discount_rate=req.discount_rate,
            is_call=req.is_call
        )
        total_premium = round(res["price_per_unit"] * req.quantity * req.contract_multiplier, 2)
        return {
            "valuation_id": f"VAL-{uuid.uuid4().hex[:12].upper()}",
            "instrument_id": req.instrument_id,
            "model_version": MODEL_VERSION,
            "valuation_timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "quantity": req.quantity,
            "contract_multiplier": req.contract_multiplier,
            "total_premium": total_premium,
            "option_type": "CALL" if req.is_call else "PUT",
            **res
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/v1/pricing/forward")
def price_forward(req: ForwardPricingRequest):
    try:
        res = ComputeForwardEngine.calculate_forward(
            spot_rate=req.spot_rate,
            time_to_delivery_years=req.time_to_delivery_years,
            risk_free_rate=req.risk_free_rate,
            electricity_cost_drift=req.electricity_cost_drift,
            capacity_scarcity_premium=req.capacity_scarcity_premium,
            technology_depreciation_rate=req.technology_depreciation_rate
        )
        return {
            "valuation_id": f"VAL-{uuid.uuid4().hex[:12].upper()}",
            "instrument_id": req.instrument_id,
            "model_version": MODEL_VERSION,
            "valuation_timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            **res
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/v1/pricing/swap")
def price_swap(req: SwapPricingRequest):
    try:
        res = ComputeSwapEngine.calculate_swap_cashflows(
            fixed_rate=req.fixed_rate,
            forward_curve=req.forward_curve,
            tenor_periods=req.tenor_periods,
            hours_per_period=req.hours_per_period,
            quantity_units=req.quantity_units,
            annual_discount_rate=req.annual_discount_rate
        )
        return {
            "valuation_id": f"VAL-{uuid.uuid4().hex[:12].upper()}",
            "instrument_id": req.instrument_id,
            "model_version": MODEL_VERSION,
            "valuation_timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            **res
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
