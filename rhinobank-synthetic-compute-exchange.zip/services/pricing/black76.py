"""
RhinoBank Synthetic Compute Derivatives Market (RB-SCDM)
Quantitative Pricing Engine: Black-76 European Option Model
"""

import math
from typing import Dict, Any
from scipy.stats import norm

class Black76Model:
    @staticmethod
    def price_european_option(
        forward_price: float,
        strike: float,
        volatility: float,
        time_to_expiry_years: float,
        discount_rate: float,
        is_call: bool,
    ) -> Dict[str, float]:
        """
        Computes Black-76 theoretical value and analytical Greeks for European compute options.
        
        Args:
            forward_price (F): Forward reference index rate (e.g. $3.35/GPU-hr)
            strike (K): Contract strike price
            volatility (sigma): Annualized implied volatility of compute index
            time_to_expiry_years (T): Tenor in year fractions
            discount_rate (r): Continuously compounded risk-free discount rate
            is_call: True for Call option, False for Put option
        """
        if forward_price <= 0.0 or strike <= 0.0 or volatility <= 0.0 or time_to_expiry_years <= 0.0:
            raise ValueError("All price, volatility, and tenor inputs must be strictly positive.")

        F = forward_price
        K = strike
        sigma = volatility
        T = time_to_expiry_years
        r = discount_rate

        sqrt_T = math.sqrt(T)
        d1 = (math.log(F / K) + 0.5 * (sigma ** 2) * T) / (sigma * sqrt_T)
        d2 = d1 - sigma * sqrt_T

        discount_factor = math.exp(-r * T)
        n_d1_pdf = norm.pdf(d1)

        if is_call:
            price = discount_factor * (F * norm.cdf(d1) - K * norm.cdf(d2))
            delta = discount_factor * norm.cdf(d1)
            intrinsic = max(0.0, F - K)
            theta = (r * price) - (discount_factor * F * sigma * n_d1_pdf) / (2.0 * sqrt_T)
        else:
            price = discount_factor * (K * norm.cdf(-d2) - F * norm.cdf(-d1))
            delta = -discount_factor * norm.cdf(-d1)
            intrinsic = max(0.0, K - F)
            theta = (r * price) - (discount_factor * F * sigma * n_d1_pdf) / (2.0 * sqrt_T)

        gamma = (discount_factor * n_d1_pdf) / (F * sigma * sqrt_T)
        vega = discount_factor * F * sqrt_T * n_d1_pdf
        time_value = max(0.0, price - intrinsic)

        return {
            "price_per_unit": round(price, 6),
            "intrinsic_value": round(intrinsic, 6),
            "time_value": round(time_value, 6),
            "delta": round(delta, 6),
            "gamma": round(gamma, 6),
            "vega": round(vega, 6),
            "theta": round(theta, 6),
            "discount_factor": round(discount_factor, 6),
        }
