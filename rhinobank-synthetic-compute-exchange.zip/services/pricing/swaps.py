"""
RhinoBank Synthetic Compute Derivatives Market (RB-SCDM)
Fixed-vs-Floating Compute Swap Valuation Engine
"""

import math
from typing import List, Dict, Any

class ComputeSwapEngine:
    @staticmethod
    def calculate_swap_cashflows(
        fixed_rate: float,
        forward_curve: List[float],
        tenor_periods: int,
        hours_per_period: int,
        quantity_units: int,
        annual_discount_rate: float,
    ) -> Dict[str, Any]:
        """
        Calculates period cash flows and Net Present Value for fixed-for-floating compute swaps.
        Fixed Payer Net Flow = (Floating Rate - Fixed Rate) * Hours * Units
        """
        schedule = []
        total_fixed_npv = 0.0
        total_float_npv = 0.0
        dt_year = (hours_per_period / 8760.0)

        for i in range(1, tenor_periods + 1):
            t_years = i * dt_year
            df = math.exp(-annual_discount_rate * t_years)
            float_rate = forward_curve[i - 1] if i - 1 < len(forward_curve) else forward_curve[-1]

            fixed_cashflow = fixed_rate * hours_per_period * quantity_units
            float_cashflow = float_rate * hours_per_period * quantity_units
            net_cashflow = float_cashflow - fixed_cashflow

            fixed_pv = fixed_cashflow * df
            float_pv = float_cashflow * df
            net_pv = net_cashflow * df

            total_fixed_npv += fixed_pv
            total_float_npv += float_pv

            schedule.append({
                "period": i,
                "discount_factor": round(df, 6),
                "fixed_rate": fixed_rate,
                "floating_forward_rate": round(float_rate, 6),
                "net_cashflow": round(net_cashflow, 2),
                "discounted_net_npv": round(net_pv, 2),
            })

        net_swap_npv = total_float_npv - total_fixed_npv
        # Par swap rate is fixed rate that sets net NPV to zero
        sum_df = sum(p["discount_factor"] for p in schedule)
        par_swap_rate = (total_float_npv / (hours_per_period * quantity_units * sum_df)) if sum_df > 0 else fixed_rate

        return {
            "fixed_leg_npv": round(total_fixed_npv, 2),
            "floating_leg_npv": round(total_float_npv, 2),
            "net_swap_npv": round(net_swap_npv, 2),
            "par_swap_rate": round(par_swap_rate, 6),
            "tenor_periods": tenor_periods,
            "cashflow_schedule": schedule,
        }
