use crate::models::{Order, OrderSide, OrderStatus, Trade};
use chrono::Utc;
use rust_decimal::Decimal;
use std::collections::{BTreeMap, VecDeque};
use uuid::Uuid;

#[derive(Debug)]
pub struct OrderBook {
    pub instrument_id: String,
    pub contract_multiplier: u32,
    // Bids sorted highest price first
    pub bids: BTreeMap<Decimal, VecDeque<Order>>,
    // Asks sorted lowest price first
    pub asks: BTreeMap<Decimal, VecDeque<Order>>,
}

impl OrderBook {
    pub fn new(instrument_id: String, contract_multiplier: u32) -> Self {
        Self {
            instrument_id,
            contract_multiplier,
            bids: BTreeMap::new(),
            asks: BTreeMap::new(),
        }
    }

    /// Submit an order with price-time priority and partial fill support.
    /// Invariant: total executed quantity never exceeds order initial quantity.
    pub fn match_order(&mut self, mut incoming: Order) -> (Order, Vec<Trade>) {
        let mut trades = Vec::new();

        match incoming.side {
            OrderSide::BUY => {
                let mut best_asks: Vec<Decimal> = self.asks.keys().cloned().collect();
                best_asks.sort(); // Lowest ask first

                for ask_price in best_asks {
                    if incoming.remaining_quantity == 0 || incoming.limit_price < ask_price {
                        break;
                    }

                    if let Some(queue) = self.asks.get_mut(&ask_price) {
                        while let Some(mut resting) = queue.pop_front() {
                            let match_qty = incoming.remaining_quantity.min(resting.remaining_quantity);
                            let exec_price = resting.limit_price; // Maker gets passive price

                            incoming.filled_quantity += match_qty;
                            incoming.remaining_quantity -= match_qty;
                            resting.filled_quantity += match_qty;
                            resting.remaining_quantity -= match_qty;

                            let notional = exec_price * Decimal::from(match_qty) * Decimal::from(self.contract_multiplier);

                            let trade = Trade {
                                trade_id: Uuid::new_v4(),
                                instrument_id: self.instrument_id.clone(),
                                maker_order_id: resting.order_id,
                                taker_order_id: incoming.order_id,
                                buyer_portfolio_id: incoming.portfolio_id.clone(),
                                seller_portfolio_id: resting.portfolio_id.clone(),
                                execution_price: exec_price,
                                executed_quantity: match_qty,
                                contract_multiplier: self.contract_multiplier,
                                total_notional: notional,
                                executed_at: Utc::now(),
                            };
                            trades.push(trade);

                            if resting.remaining_quantity > 0 {
                                resting.status = OrderStatus::PARTIALLY_FILLED;
                                queue.push_front(resting);
                                break;
                            } else {
                                resting.status = OrderStatus::FILLED;
                            }

                            if incoming.remaining_quantity == 0 {
                                break;
                            }
                        }
                    }
                }

                // Clean empty queues
                self.asks.retain(|_, q| !q.is_empty());

                if incoming.remaining_quantity > 0 {
                    incoming.status = if incoming.filled_quantity > 0 {
                        OrderStatus::PARTIALLY_FILLED
                    } else {
                        OrderStatus::NEW
                    };
                    self.bids
                        .entry(incoming.limit_price)
                        .or_default()
                        .push_back(incoming.clone());
                } else {
                    incoming.status = OrderStatus::FILLED;
                }
            }
            OrderSide::SELL => {
                let mut best_bids: Vec<Decimal> = self.bids.keys().cloned().collect();
                best_bids.sort_by(|a, b| b.cmp(a)); // Highest bid first

                for bid_price in best_bids {
                    if incoming.remaining_quantity == 0 || incoming.limit_price > bid_price {
                        break;
                    }

                    if let Some(queue) = self.bids.get_mut(&bid_price) {
                        while let Some(mut resting) = queue.pop_front() {
                            let match_qty = incoming.remaining_quantity.min(resting.remaining_quantity);
                            let exec_price = resting.limit_price;

                            incoming.filled_quantity += match_qty;
                            incoming.remaining_quantity -= match_qty;
                            resting.filled_quantity += match_qty;
                            resting.remaining_quantity -= match_qty;

                            let notional = exec_price * Decimal::from(match_qty) * Decimal::from(self.contract_multiplier);

                            let trade = Trade {
                                trade_id: Uuid::new_v4(),
                                instrument_id: self.instrument_id.clone(),
                                maker_order_id: resting.order_id,
                                taker_order_id: incoming.order_id,
                                buyer_portfolio_id: resting.portfolio_id.clone(),
                                seller_portfolio_id: incoming.portfolio_id.clone(),
                                execution_price: exec_price,
                                executed_quantity: match_qty,
                                contract_multiplier: self.contract_multiplier,
                                total_notional: notional,
                                executed_at: Utc::now(),
                            };
                            trades.push(trade);

                            if resting.remaining_quantity > 0 {
                                resting.status = OrderStatus::PARTIALLY_FILLED;
                                queue.push_front(resting);
                                break;
                            } else {
                                resting.status = OrderStatus::FILLED;
                            }

                            if incoming.remaining_quantity == 0 {
                                break;
                            }
                        }
                    }
                }

                self.bids.retain(|_, q| !q.is_empty());

                if incoming.remaining_quantity > 0 {
                    incoming.status = if incoming.filled_quantity > 0 {
                        OrderStatus::PARTIALLY_FILLED
                    } else {
                        OrderStatus::NEW
                    };
                    self.asks
                        .entry(incoming.limit_price)
                        .or_default()
                        .push_back(incoming.clone());
                } else {
                    incoming.status = OrderStatus::FILLED;
                }
            }
        }

        (incoming, trades)
    }

    pub fn cancel_order(&mut self, order_id: Uuid) -> Option<Order> {
        for queue in self.bids.values_mut() {
            if let Some(pos) = queue.iter().position(|o| o.order_id == order_id) {
                let mut cancelled = queue.remove(pos).unwrap();
                cancelled.status = OrderStatus::CANCELLED;
                return Some(cancelled);
            }
        }
        for queue in self.asks.values_mut() {
            if let Some(pos) = queue.iter().position(|o| o.order_id == order_id) {
                let mut cancelled = queue.remove(pos).unwrap();
                cancelled.status = OrderStatus::CANCELLED;
                return Some(cancelled);
            }
        }
        None
    }
}
