use axum::{
    extract::{Path, State},
    http::StatusCode,
    response::IntoResponse,
    routing::{get, post},
    Json, Router,
};
use rb_scdm_market_core::{
    engine::OrderBook,
    models::{Order, OrderSide, OrderStatus, Trade},
    risk::PreTradeRiskEngine,
};
use rust_decimal::Decimal;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::{Arc, Mutex};
use uuid::Uuid;

#[derive(Clone)]
struct AppState {
    books: Arc<Mutex<HashMap<String, OrderBook>>>,
    risk_engine: Arc<PreTradeRiskEngine>,
}

#[derive(Deserialize)]
struct SubmitOrderRequest {
    client_order_id: String,
    portfolio_id: String,
    instrument_id: String,
    side: OrderSide,
    limit_price: Decimal,
    quantity: u32,
    idempotency_key: Option<String>,
}

#[derive(Serialize)]
struct SubmitOrderResponse {
    order_id: Uuid,
    client_order_id: String,
    status: OrderStatus,
    filled_quantity: u32,
    remaining_quantity: u32,
    trades: Vec<Trade>,
}

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt::init();

    let mut initial_books = HashMap::new();
    initial_books.insert(
        "RB-H100-FWD-Q4-26".to_string(),
        OrderBook::new("RB-H100-FWD-Q4-26".to_string(), 1000),
    );
    initial_books.insert(
        "RB-H100-FUT-DEC26".to_string(),
        OrderBook::new("RB-H100-FUT-DEC26".to_string(), 1000),
    );

    let state = AppState {
        books: Arc::new(Mutex::new(initial_books)),
        risk_engine: Arc::new(PreTradeRiskEngine::default()),
    };

    let app = Router::new()
        .route("/health", get(health_check))
        .route("/api/v1/orders", post(submit_order))
        .route("/api/v1/markets/:instrument_id/quote", get(get_market_quote))
        .with_state(state);

    let addr = SocketAddr::from(([0, 0, 0, 0], 8080));
    tracing::info!("RB-SCDM Market Core listening on {}", addr);
    let listener = tokio::net::TcpListener::bind(addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}

async fn health_check() -> impl IntoResponse {
    Json(serde_json::json!({
        "status": "HEALTHY",
        "service": "rb-scdm-market-core",
        "version": "1.4.0",
        "environment": "SIMULATION"
    }))
}

async fn submit_order(
    State(state): State<AppState>,
    Json(payload): Json<SubmitOrderRequest>,
) -> Result<(StatusCode, Json<SubmitOrderResponse>), (StatusCode, String)> {
    let order_id = Uuid::new_v4();
    let order = Order {
        order_id,
        client_order_id: payload.client_order_id.clone(),
        portfolio_id: payload.portfolio_id,
        instrument_id: payload.instrument_id.clone(),
        side: payload.side,
        limit_price: payload.limit_price,
        initial_quantity: payload.quantity,
        filled_quantity: 0,
        remaining_quantity: payload.quantity,
        status: OrderStatus::NEW,
        created_at: chrono::Utc::now(),
        idempotency_key: payload.idempotency_key,
    };

    let reference_price = Decimal::from_str_exact("3.25").unwrap();
    let contract_multiplier = 1000;

    // Run Pre-trade Risk Enforcement
    if let Err(risk_err) = state.risk_engine.validate_order(
        &order,
        contract_multiplier,
        reference_price,
        true,
    ) {
        return Err((StatusCode::UNPROCESSABLE_ENTITY, risk_err.to_string()));
    }

    let mut books = state.books.lock().unwrap();
    let book = books
        .entry(payload.instrument_id)
        .or_insert_with_key(|id| OrderBook::new(id.clone(), contract_multiplier));

    let (matched_order, trades) = book.match_order(order);

    Ok((
        StatusCode::CREATED,
        Json(SubmitOrderResponse {
            order_id: matched_order.order_id,
            client_order_id: matched_order.client_order_id,
            status: matched_order.status,
            filled_quantity: matched_order.filled_quantity,
            remaining_quantity: matched_order.remaining_quantity,
            trades,
        }),
    ))
}

async fn get_market_quote(
    State(state): State<AppState>,
    Path(instrument_id): Path<String>,
) -> impl IntoResponse {
    let books = state.books.lock().unwrap();
    if let Some(book) = books.get(&instrument_id) {
        let bids: Vec<serde_json::Value> = book
            .bids
            .iter()
            .map(|(p, q)| {
                serde_json::json!({
                    "price": p,
                    "quantity": q.iter().map(|o| o.remaining_quantity).sum::<u32>()
                })
            })
            .collect();
        let asks: Vec<serde_json::Value> = book
            .asks
            .iter()
            .map(|(p, q)| {
                serde_json::json!({
                    "price": p,
                    "quantity": q.iter().map(|o| o.remaining_quantity).sum::<u32>()
                })
            })
            .collect();
        Json(serde_json::json!({
            "instrument_id": instrument_id,
            "bids": bids,
            "asks": asks
        }))
    } else {
        Json(serde_json::json!({
            "instrument_id": instrument_id,
            "bids": [],
            "asks": []
        }))
    }
}
