use crate::models::{Order, OrderSide};
use rust_decimal::Decimal;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum RiskRejection {
    #[error("Order quantity {quantity} breaches maximum allowed per order {max}")]
    QuantityLimitExceeded { quantity: u32, max: u32 },

    #[error("Order notional {notional} exceeds portfolio single-ticket limit {max}")]
    NotionalLimitExceeded { notional: Decimal, max: Decimal },

    #[error("Limit price {price} breaches allowable price collar [{min_collar}, {max_collar}]")]
    PriceCollarBreached { price: Decimal, min_collar: Decimal, max_collar: Decimal },

    #[error("Instrument {instrument_id} is currently suspended from trading")]
    InstrumentSuspended { instrument_id: String },
}

#[derive(Debug, Clone)]
pub struct PreTradeRiskEngine {
    pub max_order_quantity: u32,
    pub max_order_notional: Decimal,
    pub price_collar_percentage: Decimal, // e.g. 0.15 for 15%
}

impl Default for PreTradeRiskEngine {
    fn default() -> Self {
        Self {
            max_order_quantity: 500, // 500 contracts max
            max_order_notional: Decimal::from(2_500_000), // $2.5M
            price_collar_percentage: Decimal::from_str_exact("0.20").unwrap(), // 20%
        }
    }
}

impl PreTradeRiskEngine {
    pub fn validate_order(
        &self,
        order: &Order,
        contract_multiplier: u32,
        reference_price: Decimal,
        is_active: bool,
    ) -> Result<(), RiskRejection> {
        if !is_active {
            return Err(RiskRejection::InstrumentSuspended {
                instrument_id: order.instrument_id.clone(),
            });
        }

        if order.initial_quantity > self.max_order_quantity {
            return Err(RiskRejection::QuantityLimitExceeded {
                quantity: order.initial_quantity,
                max: self.max_order_quantity,
            });
        }

        let notional = order.limit_price
            * Decimal::from(order.initial_quantity)
            * Decimal::from(contract_multiplier);

        if notional > self.max_order_notional {
            return Err(RiskRejection::NotionalLimitExceeded {
                notional,
                max: self.max_order_notional,
            });
        }

        // Price collar check around reference price
        let collar_spread = reference_price * self.price_collar_percentage;
        let min_collar = reference_price - collar_spread;
        let max_collar = reference_price + collar_spread;

        if order.limit_price < min_collar || order.limit_price > max_collar {
            return Err(RiskRejection::PriceCollarBreached {
                price: order.limit_price,
                min_collar,
                max_collar,
            });
        }

        Ok(())
    }
}
