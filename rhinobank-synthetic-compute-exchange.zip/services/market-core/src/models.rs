use chrono::{DateTime, Utc};
use rust_decimal::Decimal;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum MarketStatus {
    DRAFT,
    PENDING_APPROVAL,
    ACTIVE,
    SUSPENDED,
    EXPIRED,
    SETTLED,
    CANCELLED,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum InstrumentType {
    FORWARD,
    FUTURES,
    SWAP,
    EUROPEAN_OPTION,
    REGIONAL_BASIS,
    HARDWARE_BASIS,
    CAPACITY_RESERVATION,
    INDEX_DERIVATIVE,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Instrument {
    pub instrument_id: String,
    pub specification_version: String,
    pub instrument_type: InstrumentType,
    pub underlying_index: String,
    pub hardware_class: String,
    pub region: String,
    pub quantity_unit: String,
    pub contract_multiplier: u32,
    pub currency: String,
    pub tick_size: Decimal,
    pub strike_price: Option<Decimal>,
    pub expiry_timestamp: DateTime<Utc>,
    pub settlement_date: DateTime<Utc>,
    pub market_status: MarketStatus,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum OrderSide {
    BUY,
    SELL,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum OrderStatus {
    NEW,
    PARTIALLY_FILLED,
    FILLED,
    CANCELLED,
    REJECTED,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Order {
    pub order_id: Uuid,
    pub client_order_id: String,
    pub portfolio_id: String,
    pub instrument_id: String,
    pub side: OrderSide,
    pub limit_price: Decimal,
    pub initial_quantity: u32,
    pub filled_quantity: u32,
    pub remaining_quantity: u32,
    pub status: OrderStatus,
    pub created_at: DateTime<Utc>,
    pub idempotency_key: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Trade {
    pub trade_id: Uuid,
    pub instrument_id: String,
    pub maker_order_id: Uuid,
    pub taker_order_id: Uuid,
    pub buyer_portfolio_id: String,
    pub seller_portfolio_id: String,
    pub execution_price: Decimal,
    pub executed_quantity: u32,
    pub contract_multiplier: u32,
    pub total_notional: Decimal,
    pub executed_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum ContractState {
    DRAFT,
    ACTIVE,
    FIXING_PENDING,
    FIXED,
    SETTLEMENT_CALCULATED,
    APPROVED,
    SETTLED,
    CANCELLED,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BilateralContract {
    pub contract_id: Uuid,
    pub instrument_id: String,
    pub party_a: String,
    pub party_b: String,
    pub agreed_rate: Decimal,
    pub quantity: u32,
    pub contract_multiplier: u32,
    pub state: ContractState,
    pub created_at: DateTime<Utc>,
}
