import React from 'react';
import { Activity, ShieldAlert, Cpu, Lock, Landmark, FileSpreadsheet, Network, Database, RefreshCw } from 'lucide-react';
import { ReserveCoverage, FormalInvariants } from '../types/rhino';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentSlot: number;
  currentEpoch: number;
  currentBlockHeight: number;
  coverage: ReserveCoverage;
  invariants: FormalInvariants;
  emergencyPaused: boolean;
  onTickBlock: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  currentSlot,
  currentEpoch,
  currentBlockHeight,
  coverage,
  invariants,
  emergencyPaused,
  onTickBlock
}) => {
  const tabs = [
    { id: 'dashboard', label: 'Monetary State', icon: Activity },
    { id: 'issuance', label: 'Issuance Control', icon: Landmark },
    { id: 'reserves', label: 'Reserve Engine', icon: Database },
    { id: 'validators', label: 'PoS Consensus', icon: Cpu },
    { id: 'explorer', label: 'Digital Thread', icon: Network },
    { id: 'accounting', label: 'Double-Entry', icon: FileSpreadsheet },
    { id: 'redemption', label: 'Redemption & Treasury', icon: RefreshCw },
    { id: 'governance', label: 'Governance & Emergency', icon: Lock },
    { id: 'simulator', label: 'Simulator & Chaos', icon: ShieldAlert },
  ];

  const allInvariantsPassing = Object.values(invariants).every(v => typeof v === 'boolean' ? v : true);

  return (
    <header className="bg-[#050505] border-b border-[#27272A] text-[#D4D4D8]">
      {/* Top Status Strip */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between text-xs font-mono border-b border-[#27272A] gap-2">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 font-bold text-[#F2F2F2] tracking-tight">
            <span className="w-2 h-2 rounded-full bg-[#10B981] shadow-[0_0_8px_#10B981]"></span>
            <span className="text-sm tracking-tighter font-extrabold">RHINOBANK.VALIDATOR</span>
            <span className="text-[#71717A] font-mono text-[10px] uppercase tracking-widest">v3.6.0-PROD</span>
          </div>
          <span className="text-[#27272A]">|</span>
          <div className="text-[#71717A] text-[11px]">
            EPOCH <span className="text-[#F2F2F2] font-bold">{currentEpoch}</span> · SLOT <span className="text-[#F2F2F2] font-bold">{currentSlot}</span> · BLOCK <span className="text-[#10B981] font-bold">#{currentBlockHeight}</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="font-mono text-[10px] uppercase tracking-widest text-[#71717A]">COVERAGE:</span>
            <span className={`px-2 py-0.5 text-[11px] font-mono font-bold border ${
              coverage.coverage_ratio >= 1.05 ? 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/40' :
              coverage.coverage_ratio >= 1.0 ? 'bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/40' :
              'bg-[#EF4444]/10 text-[#EF4444] border-[#EF4444]/40'
            }`}>
              {(coverage.coverage_ratio * 100).toFixed(1)}% ({coverage.alert_level})
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="font-mono text-[10px] uppercase tracking-widest text-[#71717A]">INVARIANTS:</span>
            <span className={`px-2 py-0.5 text-[11px] font-mono font-bold border ${
              allInvariantsPassing ? 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/40' : 'bg-[#EF4444]/10 text-[#EF4444] border-[#EF4444]/40'
            }`}>
              {allInvariantsPassing ? '100% VERIFIED' : 'BREACH DETECTED'}
            </span>
          </div>

          {emergencyPaused && (
            <div className="px-2 py-0.5 bg-[#EF4444] text-white font-mono text-[10px] font-bold uppercase tracking-widest">
              CIRCUIT BREAKER
            </div>
          )}

          <button
            onClick={onTickBlock}
            className="flex items-center gap-1.5 bg-[#09090B] hover:bg-[#18181B] text-[#F2F2F2] px-3 py-1 text-xs font-mono font-bold uppercase tracking-widest border border-[#3F3F46] hover:border-[#F2F2F2] transition-colors cursor-pointer"
            title="Produce next PoS Block"
          >
            <RefreshCw className="w-3 h-3 text-[#10B981]" />
            <span>TICK BLOCK</span>
          </button>
        </div>
      </div>

      {/* Main App Title & Navigation */}
      <div className="max-w-7xl mx-auto px-4 pt-4 pb-0">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tighter text-[#F2F2F2] flex items-center gap-2">
              <Landmark className="w-6 h-6 text-[#F2F2F2]" />
              RHINO BANK PROOF-OF-STAKE MONETARY NETWORK
            </h1>
            <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-[#71717A] mt-1">
              Sovereign Digital Money Issuance · Reserve Backing Engine · Double-Entry Accounting · PoS Consensus
            </p>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            <div className="bg-[#080809] px-3 py-1.5 border border-[#27272A] text-[11px]">
              <span className="text-[#71717A] uppercase tracking-wider">DOMAIN RULE: </span>
              <span className="text-[#10B981] font-bold">CONSENSUS AUTHORITY ≠ ISSUANCE AUTHORITY</span>
            </div>
          </div>
        </div>

        {/* Tab Bar */}
        <div className="flex space-x-1 overflow-x-auto no-scrollbar border-b border-[#27272A]">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 text-xs font-mono font-bold uppercase tracking-wider border-b-2 whitespace-nowrap cursor-pointer transition-all ${
                  isActive
                    ? 'border-[#10B981] text-[#F2F2F2] bg-[#080809]'
                    : 'border-transparent text-[#71717A] hover:text-[#D4D4D8] hover:border-[#3F3F46]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#10B981]' : 'text-[#71717A]'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
