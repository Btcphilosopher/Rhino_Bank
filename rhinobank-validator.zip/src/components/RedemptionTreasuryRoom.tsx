import React, { useState } from 'react';
import { RefreshCw, Flame, ArrowRight, ShieldCheck, Landmark, CheckCircle2, DollarSign } from 'lucide-react';
import { RedemptionRequest, LedgerAccount, ReserveAsset } from '../types/rhino';

interface RedemptionProps {
  redemptions: RedemptionRequest[];
  accounts: LedgerAccount[];
  reserves: ReserveAsset[];
  onSubmitRedemption: (coinId: string, amount: number, requester: string, bankAccount: string, reserveId: string) => void;
}

export const RedemptionTreasuryRoom: React.FC<RedemptionProps> = ({
  redemptions,
  accounts,
  reserves,
  onSubmitRedemption
}) => {
  const [coinId, setCoinId] = useState('RGBP');
  const [amountInput, setAmountInput] = useState('1000000');
  const [requesterInput, setRequesterInput] = useState('ACC_BARCLAYS_INST');
  const [bankAccountInput, setBankAccInput] = useState('GB99BARC20000098765432');
  const [reserveAssetInput, setReserveAssetInput] = useState('RES_BOE_CASH');
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(amountInput);
    if (!amt || amt <= 0) return;

    onSubmitRedemption(coinId, amt, requesterInput, bankAccountInput, reserveAssetInput);
    setFeedback(`Redemption request submitted & processed: ${amt.toLocaleString()} ${coinId} burned & reserve asset released.`);
    setTimeout(() => setFeedback(null), 5000);
  };

  return (
    <div className="space-y-6">
      {/* Top Title & 6-Stage Redemption Pipeline Diagram */}
      <div className="bg-[#080809] border border-[#27272A] p-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-[#F59E0B]" />
              PAR REDEMPTION & COIN BURN ENGINE
            </h2>
            <p className="text-xs text-[#71717A] font-mono mt-1">
              Convert issued digital coins back to fiat bank reserve cash at 1:1 par value. Automatically burns coin supply and posts balanced double-entry journals.
            </p>
          </div>
        </div>

        {/* Pipeline Diagram */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2 text-center font-mono text-xs">
          <div className="p-3 bg-[#050505] border border-[#27272A]">
            <div className="text-[#F2F2F2] font-extrabold uppercase text-[10px] tracking-wider">1. REQUEST</div>
            <div className="text-[9px] text-[#71717A] mt-0.5">Validate Holder</div>
          </div>
          <div className="p-3 bg-[#050505] border border-[#27272A]">
            <div className="text-[#F2F2F2] font-extrabold uppercase text-[10px] tracking-wider">2. BALANCE</div>
            <div className="text-[9px] text-[#71717A] mt-0.5">Coins Verified</div>
          </div>
          <div className="p-3 bg-[#050505] border border-[#27272A]">
            <div className="text-[#EF4444] font-extrabold uppercase text-[10px] tracking-wider">3. BURN COINS</div>
            <div className="text-[9px] text-[#71717A] mt-0.5">PoS State Reduced</div>
          </div>
          <div className="p-3 bg-[#050505] border border-[#27272A]">
            <div className="text-[#F59E0B] font-extrabold uppercase text-[10px] tracking-wider">4. SETTLEMENT</div>
            <div className="text-[9px] text-[#71717A] mt-0.5">Bank Wire</div>
          </div>
          <div className="p-3 bg-[#050505] border border-[#27272A]">
            <div className="text-[#10B981] font-extrabold uppercase text-[10px] tracking-wider">5. RELEASE</div>
            <div className="text-[9px] text-[#71717A] mt-0.5">BoE Cash Out</div>
          </div>
          <div className="p-3 bg-[#050505] border border-[#27272A]">
            <div className="text-[#10B981] font-extrabold uppercase text-[10px] tracking-wider">6. JOURNAL</div>
            <div className="text-[9px] text-[#71717A] mt-0.5">Ledger Posted</div>
          </div>
        </div>
      </div>

      {/* Main Grid: Form & Active Redemptions List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form */}
        <div className="bg-[#080809] border border-[#27272A] p-6">
          <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] mb-4 flex items-center gap-2">
            <Flame className="w-4 h-4 text-[#EF4444]" />
            SUBMIT REDEMPTION & BURN REQUEST
          </h3>

          <form onSubmit={handleSubmit} className="space-y-4 font-mono text-xs">
            <div>
              <label className="block text-[#71717A] uppercase tracking-widest text-[10px] mb-1">COIN TO REDEEM</label>
              <select
                value={coinId}
                onChange={(e) => setCoinId(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-3 text-[#F2F2F2] outline-none font-bold"
              >
                <option value="RGBP">RGBP (Rhino Digital Pound)</option>
                <option value="RUSD">RUSD (Rhino Digital Dollar)</option>
                <option value="REUR">REUR (Rhino Digital Euro)</option>
              </select>
            </div>

            <div>
              <label className="block text-[#71717A] uppercase tracking-widest text-[10px] mb-1">REDEMPTION AMOUNT ({coinId})</label>
              <input
                type="number"
                value={amountInput}
                onChange={(e) => setAmountInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-3 text-[#F2F2F2] font-extrabold outline-none"
              />
            </div>

            <div>
              <label className="block text-[#71717A] uppercase tracking-widest text-[10px] mb-1">REQUESTER ACCOUNT</label>
              <select
                value={requesterInput}
                onChange={(e) => setRequesterInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-3 text-[#F2F2F2] outline-none font-bold"
              >
                {accounts.map(acc => (
                  <option key={acc.account_id} value={acc.account_id}>
                    {acc.owner_name} ({acc.account_id})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[#71717A] uppercase tracking-widest text-[10px] mb-1">SETTLEMENT BANK ACCOUNT (WIRE)</label>
              <input
                type="text"
                value={bankAccountInput}
                onChange={(e) => setBankAccInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-3 text-[#F2F2F2] outline-none font-bold"
              />
            </div>

            <div>
              <label className="block text-[#71717A] uppercase tracking-widest text-[10px] mb-1">RESERVE ASSET TO RELEASE</label>
              <select
                value={reserveAssetInput}
                onChange={(e) => setReserveAssetInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-3 text-[#F2F2F2] outline-none font-bold"
              >
                {reserves.map(r => (
                  <option key={r.asset_id} value={r.asset_id}>
                    {r.name} ({r.custodian})
                  </option>
                ))}
              </select>
            </div>

            {feedback && (
              <div className="p-3 bg-[#10B981]/10 border border-[#10B981]/40 text-[#10B981] text-xs font-mono font-bold uppercase tracking-wider">
                {feedback}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-[#EF4444] hover:bg-[#DC2626] text-white font-bold p-3 transition-colors flex items-center justify-center gap-2 cursor-pointer uppercase tracking-widest text-xs"
            >
              <Flame className="w-4 h-4" />
              <span>REDEEM & BURN COINS</span>
            </button>
          </form>
        </div>

        {/* List of Redemptions */}
        <div className="bg-[#080809] border border-[#27272A] p-6 lg:col-span-2 space-y-4">
          <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] flex items-center gap-2">
            <RefreshCw className="w-4 h-4 text-[#F59E0B]" />
            REDEMPTION & SETTLEMENT HISTORY
          </h3>

          <div className="space-y-3 font-mono text-xs">
            {redemptions.length === 0 ? (
              <div className="p-6 text-center text-[#71717A] bg-[#050505] border border-[#27272A]">
                No redemption requests submitted yet. Use the form to execute a par 1:1 redemption.
              </div>
            ) : (
              redemptions.map(r => (
                <div key={r.request_id} className="p-4 bg-[#050505] border border-[#27272A] space-y-2">
                  <div className="flex justify-between items-start border-b border-[#27272A] pb-2">
                    <div>
                      <div className="font-extrabold text-[#F2F2F2] text-sm flex items-center gap-2">
                        <span>{r.request_id}</span>
                        <span className="px-2 py-0.5 text-[10px] font-bold uppercase bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/40">
                          {r.status}
                        </span>
                      </div>
                      <div className="text-xs text-[#A1A1AA] mt-1">
                        Burned: <span className="text-[#EF4444] font-extrabold">-{r.burn_amount.toLocaleString()} {r.coin_id}</span> · Requester: <span className="text-[#F2F2F2] font-bold">{r.requester_account}</span>
                      </div>
                    </div>

                    <div className="text-right text-xs text-[#A1A1AA]">
                      <div>Target Bank: <span className="text-[#F2F2F2] font-bold">{r.settlement_bank_account}</span></div>
                      {r.burn_tx_hash && <div className="text-[#71717A] text-[10px] mt-0.5">{r.burn_tx_hash}</div>}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
