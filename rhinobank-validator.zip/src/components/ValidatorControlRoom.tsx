import React from 'react';
import { Cpu, ShieldCheck, AlertTriangle, Layers, Award, CheckCircle2, Zap } from 'lucide-react';
import { Validator, SlashingEvent } from '../types/rhino';

interface ValidatorProps {
  validators: Validator[];
  slashingEvents: SlashingEvent[];
  currentSlot: number;
  currentEpoch: number;
}

export const ValidatorControlRoom: React.FC<ValidatorProps> = ({
  validators,
  slashingEvents,
  currentSlot,
  currentEpoch
}) => {
  const activeValidators = validators.filter(v => v.status === 'VALIDATING' && !v.slashed);
  const totalStaked = validators.reduce((sum, v) => sum + v.stake, 0);

  return (
    <div className="space-y-6">
      {/* Top Banner KPI Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#080809] p-5 border border-[#27272A]">
          <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#71717A]">VALIDATOR NODES</div>
          <div className="mt-3 text-3xl font-extrabold tracking-tighter text-[#F2F2F2]">
            {activeValidators.length} / {validators.length} <span className="text-xs text-[#10B981] font-bold">Active</span>
          </div>
          <div className="font-mono text-[10px] uppercase tracking-widest text-[#71717A] mt-2">21 Institutional Nodes</div>
        </div>

        <div className="bg-[#080809] p-5 border border-[#27272A]">
          <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#71717A]">STAKED CAPITAL</div>
          <div className="mt-3 text-3xl font-extrabold tracking-tighter text-[#F2F2F2]">
            {(totalStaked / 1000000).toFixed(0)}M <span className="text-xs font-mono font-normal text-[#71717A]">RSTAKE</span>
          </div>
          <div className="font-mono text-[10px] uppercase tracking-widest text-[#71717A] mt-2">PoS Security Layer</div>
        </div>

        <div className="bg-[#080809] p-5 border border-[#27272A]">
          <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#71717A]">ATTESTATION RATE</div>
          <div className="mt-3 text-3xl font-extrabold tracking-tighter text-[#10B981]">
            99.9%
          </div>
          <div className="font-mono text-[10px] uppercase tracking-widest text-[#71717A] mt-2">BLS Signature Aggregation</div>
        </div>

        <div className="bg-[#080809] p-5 border border-[#27272A]">
          <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#71717A]">FINALITY STATE</div>
          <div className="mt-3 text-3xl font-extrabold tracking-tighter text-[#10B981]">
            DETERMINISTIC
          </div>
          <div className="font-mono text-[10px] uppercase tracking-widest text-[#71717A] mt-2">Slot #{currentSlot} · Epoch #{currentEpoch}</div>
        </div>
      </div>

      {/* Main Validator Nodes Table */}
      <div className="bg-[#080809] border border-[#27272A] p-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] flex items-center gap-2">
              <Cpu className="w-4 h-4 text-[#F2F2F2]" />
              PROOF-OF-STAKE VALIDATOR MATRIX (21 CONSENSUS NODES)
            </h2>
            <p className="text-xs text-[#71717A] font-mono mt-1">
              PoS determines consensus order, block validation, and finality. Cannot mint coins without Monetary Policy multi-sig authorization.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-[#27272A] text-[#71717A] bg-[#050505]">
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">NODE ID</th>
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">INSTITUTION / BANK NODE NAME</th>
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">PUBLIC KEY</th>
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">STAKE (RSTAKE)</th>
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">UPTIME</th>
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">BLOCKS PROPOSED</th>
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#27272A]">
              {validators.map((val) => (
                <tr key={val.validator_id} className={`hover:bg-[#0F0F12] transition-colors ${val.slashed ? 'bg-[#EF4444]/10' : ''}`}>
                  <td className="py-3 px-3 font-extrabold text-[#F2F2F2]">{val.validator_id}</td>
                  <td className="py-3 px-3 font-bold text-[#F2F2F2] flex items-center gap-2">
                    <span>{val.name}</span>
                    {val.validator_id === 'VAL_01' && (
                      <span className="text-[9px] px-1.5 py-0.5 bg-[#F2F2F2] text-black font-extrabold uppercase tracking-widest">LEAD PROPOSER</span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-[#A1A1AA]">
                    {val.public_key.substring(0, 10)}...{val.public_key.substring(val.public_key.length - 4)}
                  </td>
                  <td className="py-3 px-3 font-extrabold text-[#F2F2F2]">
                    {(val.stake / 1000000).toFixed(1)}M
                  </td>
                  <td className="py-3 px-3 text-[#10B981] font-bold">
                    {val.uptime.toFixed(1)}%
                  </td>
                  <td className="py-3 px-3 text-[#D4D4D8]">
                    {val.proposed_blocks} blocks
                  </td>
                  <td className="py-3 px-3">
                    <span className={`px-2 py-0.5 text-[10px] font-bold font-mono uppercase ${
                      val.slashed ? 'bg-[#EF4444]/10 text-[#EF4444] border border-[#EF4444]/40' :
                      'bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/40'
                    }`}>
                      {val.slashed ? 'SLASHED' : val.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Slashing Event Log Panel */}
      {slashingEvents.length > 0 && (
        <div className="bg-[#080809] border border-[#EF4444]/40 p-6">
          <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#EF4444] mb-4 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-[#EF4444]" />
            SLASHING EVIDENCE & EQUIVOCATION EVENT LOG
          </h3>
          <div className="space-y-2 font-mono text-xs">
            {slashingEvents.map(se => (
              <div key={se.slashing_id} className="p-4 bg-[#050505] border border-[#EF4444]/40 flex justify-between items-center">
                <div>
                  <div className="text-[#EF4444] font-bold text-sm">{se.validator_name} ({se.validator_id}) Slashed!</div>
                  <div className="text-[#A1A1AA] text-xs mt-1">{se.evidence}</div>
                </div>
                <div className="text-right">
                  <div className="text-[#EF4444] font-extrabold">Penalty: -{se.penalty_amount.toLocaleString()} RSTAKE</div>
                  <div className="text-[10px] text-[#71717A] mt-1">Block #{se.block_height} · Slot #{se.slot}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
