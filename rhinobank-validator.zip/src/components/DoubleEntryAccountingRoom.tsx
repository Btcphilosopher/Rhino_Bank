import React, { useState } from 'react';
import { FileSpreadsheet, CheckCircle2, ArrowRight, Landmark, DollarSign, Send } from 'lucide-react';
import { JournalEntry, LedgerAccount } from '../types/rhino';

interface AccountingProps {
  journals: JournalEntry[];
  accounts: LedgerAccount[];
  onTransfer: (senderId: string, recipientId: string, coinId: string, amount: number) => void;
}

export const DoubleEntryAccountingRoom: React.FC<AccountingProps> = ({
  journals,
  accounts,
  onTransfer
}) => {
  const [senderInput, setSenderInput] = useState('ACC_BARCLAYS_INST');
  const [recipientInput, setRecipientInput] = useState('ACC_HSBC_INST');
  const [coinInput, setCoinInput] = useState('RGBP');
  const [amountInput, setAmountInput] = useState('500000');
  const [transferStatus, setTransferStatus] = useState<string | null>(null);

  const handleExecuteTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(amountInput);
    if (!amt || amt <= 0) return;

    onTransfer(senderInput, recipientInput, coinInput, amt);
    setTransferStatus(`Settled £${amt.toLocaleString()} ${coinInput} transfer between ${senderInput} and ${recipientInput}`);
    setTimeout(() => setTransferStatus(null), 5000);
  };

  // Calculate Trial Balance Total
  const totalDebitsSum = journals.reduce((sum, j) => sum + j.total_debits, 0);
  const totalCreditsSum = journals.reduce((sum, j) => sum + j.total_credits, 0);
  const isTrialBalanceEqual = Math.abs(totalDebitsSum - totalCreditsSum) < 0.01;

  return (
    <div className="space-y-6">
      {/* Top Banner KPI Summary */}
      <div className="bg-[#080809] border border-[#27272A] p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#27272A]">
          <div>
            <h2 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-[#F2F2F2]" />
              DOUBLE-ENTRY ACCOUNTING ENGINE & TRIAL BALANCE
            </h2>
            <p className="text-xs text-[#71717A] font-mono mt-1">
              Every monetary event (mint, transfer, burn, fee) produces balanced journal entries where Total Debits strictly equal Total Credits.
            </p>
          </div>

          <div className="flex items-center gap-3 font-mono text-xs">
            <div className="bg-[#050505] p-3 border border-[#27272A] text-center min-w-[130px]">
              <div className="text-[9px] font-mono uppercase tracking-widest text-[#71717A]">CUMULATIVE DEBITS</div>
              <div className="text-base font-extrabold text-[#10B981] mt-0.5">£{totalDebitsSum.toLocaleString()}</div>
            </div>
            <div className="bg-[#050505] p-3 border border-[#27272A] text-center min-w-[130px]">
              <div className="text-[9px] font-mono uppercase tracking-widest text-[#71717A]">CUMULATIVE CREDITS</div>
              <div className="text-base font-extrabold text-[#F2F2F2] mt-0.5">£{totalCreditsSum.toLocaleString()}</div>
            </div>
            <div className="bg-[#050505] p-3 border border-[#27272A] text-center min-w-[130px]">
              <div className="text-[9px] font-mono uppercase tracking-widest text-[#71717A]">TRIAL BALANCE</div>
              <div className={`text-base font-extrabold ${isTrialBalanceEqual ? 'text-[#10B981]' : 'text-[#EF4444]'} mt-0.5`}>
                {isTrialBalanceEqual ? 'BALANCED' : 'IMBALANCE'}
              </div>
            </div>
          </div>
        </div>

        {/* Interbank Settlement Transfer Form */}
        <div className="mt-4 pt-2">
          <h3 className="text-xs font-bold font-mono text-[#F2F2F2] mb-3 flex items-center gap-2 uppercase tracking-widest">
            <Send className="w-3.5 h-3.5 text-[#F2F2F2]" />
            <span>EXECUTE INTERBANK SETTLEMENT TRANSFER</span>
          </h3>

          <form onSubmit={handleExecuteTransfer} className="grid grid-cols-1 md:grid-cols-5 gap-3 font-mono text-xs">
            <div>
              <label className="block text-[10px] text-[#71717A] uppercase tracking-widest mb-1">SENDER BANK NODE</label>
              <select
                value={senderInput}
                onChange={(e) => setSenderInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-3 text-[#F2F2F2] outline-none font-bold"
              >
                {accounts.map(a => (
                  <option key={a.account_id} value={a.account_id}>{a.owner_name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-[#71717A] uppercase tracking-widest mb-1">RECIPIENT BANK NODE</label>
              <select
                value={recipientInput}
                onChange={(e) => setRecipientInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-3 text-[#F2F2F2] outline-none font-bold"
              >
                {accounts.map(a => (
                  <option key={a.account_id} value={a.account_id}>{a.owner_name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-[#71717A] uppercase tracking-widest mb-1">ISSUED COIN</label>
              <select
                value={coinInput}
                onChange={(e) => setCoinInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-3 text-[#F2F2F2] outline-none font-bold"
              >
                <option value="RGBP">RGBP (Rhino Pound)</option>
                <option value="RUSD">RUSD (Rhino Dollar)</option>
                <option value="REUR">REUR (Rhino Euro)</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-[#71717A] uppercase tracking-widest mb-1">AMOUNT</label>
              <input
                type="number"
                value={amountInput}
                onChange={(e) => setAmountInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-3 text-[#F2F2F2] font-extrabold outline-none"
              />
            </div>

            <div className="flex items-end">
              <button
                type="submit"
                className="w-full bg-[#F2F2F2] hover:bg-transparent text-black hover:text-[#F2F2F2] font-bold p-3 border border-[#F2F2F2] cursor-pointer transition-colors uppercase tracking-widest text-xs"
              >
                SETTLE TRANSFER
              </button>
            </div>
          </form>

          {transferStatus && (
            <div className="mt-3 p-3 bg-[#10B981]/10 border border-[#10B981]/40 text-[#10B981] text-xs font-mono font-bold uppercase tracking-wider">
              {transferStatus}
            </div>
          )}
        </div>
      </div>

      {/* Main Grid: Chart of Accounts & Journal Entries Log */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart of Accounts & Balances */}
        <div className="bg-[#080809] border border-[#27272A] p-6">
          <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] mb-4 flex items-center gap-2">
            <Landmark className="w-4 h-4 text-[#F2F2F2]" />
            CHART OF ACCOUNTS & BALANCES
          </h3>

          <div className="space-y-2 font-mono text-xs max-h-[500px] overflow-y-auto pr-1">
            {accounts.map((acc) => (
              <div key={acc.account_id} className="p-3.5 bg-[#050505] border border-[#27272A]">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-extrabold text-[#F2F2F2]">{acc.owner_name}</div>
                    <div className="text-[10px] text-[#71717A] mt-0.5">{acc.account_id} · {acc.type}</div>
                  </div>
                  <span className="text-[9px] px-1.5 py-0.5 bg-[#10B981]/10 text-[#10B981] font-bold uppercase tracking-widest border border-[#10B981]/30">
                    {acc.status}
                  </span>
                </div>

                <div className="mt-3 pt-2 border-t border-[#27272A] flex justify-between text-xs font-extrabold text-[#10B981]">
                  <span>RGBP: £{(acc.balances['RGBP'] || 0).toLocaleString()}</span>
                  <span className="text-[#F2F2F2]">RUSD: ${(acc.balances['RUSD'] || 0).toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Double-Entry Journal Entries Table */}
        <div className="bg-[#080809] border border-[#27272A] p-6 lg:col-span-2">
          <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] mb-4 flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-[#10B981]" />
            BALANCED JOURNAL ENTRIES LEDGER
          </h3>

          <div className="space-y-3 font-mono text-xs max-h-[500px] overflow-y-auto pr-1">
            {journals.map((jrn) => (
              <div key={jrn.entry_id} className="p-4 bg-[#050505] border border-[#27272A] space-y-3">
                <div className="flex justify-between items-center border-b border-[#27272A] pb-2">
                  <div>
                    <span className="font-extrabold text-[#F2F2F2]">{jrn.entry_id}</span>
                    <span className="text-[#A1A1AA] text-xs ml-2 font-mono">({jrn.description})</span>
                  </div>
                  <span className="px-2.5 py-1 text-[10px] font-extrabold font-mono uppercase bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/40 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981]" />
                    <span>BALANCED (DR £{jrn.total_debits.toLocaleString()} = CR £{jrn.total_credits.toLocaleString()})</span>
                  </span>
                </div>

                <div className="space-y-1.5 text-xs">
                  {jrn.postings.map((post, idx) => (
                    <div key={idx} className="flex justify-between bg-[#080809] p-2 border border-[#27272A]">
                      <span className="text-[#D4D4D8] font-bold">{post.account_name} ({post.account_id})</span>
                      <span className="font-extrabold font-mono">
                        {post.debit > 0 ? (
                          <span className="text-[#10B981]">DR £{post.debit.toLocaleString()}</span>
                        ) : (
                          <span className="text-[#F2F2F2]">CR £{post.credit.toLocaleString()}</span>
                        )}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
