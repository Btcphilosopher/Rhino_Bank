import React, { useState } from 'react';
import { Landmark, ArrowRight, ShieldCheck, CheckCircle2, Clock, AlertCircle, PlusCircle, Check, X } from 'lucide-react';
import { IssuanceRequest, ReserveCoverage, LedgerAccount, IssuedCoin } from '../types/rhino';

interface IssuanceProps {
  issuanceRequests: IssuanceRequest[];
  coverage: ReserveCoverage;
  accounts: LedgerAccount[];
  coins: IssuedCoin[];
  onSubmitRequest: (coinId: string, amount: number, beneficiary: string, reserveRef: string, officer: string, reason: string) => void;
  onApproveRequest: (requestId: string, signerOfficerId: string) => void;
}

export const IssuanceControlRoom: React.FC<IssuanceProps> = ({
  issuanceRequests,
  coverage,
  accounts,
  coins,
  onSubmitRequest,
  onApproveRequest
}) => {
  const [selectedCoin, setSelectedCoin] = useState('RGBP');
  const [amountInput, setAmountInput] = useState('5000000');
  const [beneficiaryInput, setBeneficiaryInput] = useState('ACC_BARCLAYS_INST');
  const [reserveRefInput, setReserveRefInput] = useState('RES_BOE_CASH');
  const [officerInput, setOfficerInput] = useState('AUTH_OFFICER_1');
  const [reasonInput, setReasonInput] = useState('Interbank Liquidity Expansion Request');
  const [submitFeedback, setSubmitFeedback] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(amountInput);
    if (!amt || amt <= 0) return;

    onSubmitRequest(selectedCoin, amt, beneficiaryInput, reserveRefInput, officerInput, reasonInput);
    setSubmitFeedback(`Issuance Request submitted successfully. Awaiting multi-sig threshold approvals.`);
    setTimeout(() => setSubmitFeedback(null), 5000);
  };

  // 7-Stage Workflow Nodes Definition
  const pipelineStages = [
    { num: '1', name: 'Reserve Position', status: 'COMPLETE', desc: 'BoE Cash & Gilts Verification' },
    { num: '2', name: 'Capacity Check', status: coverage.excess_reserve > 0 ? 'COMPLETE' : 'ALERT', desc: `£${coverage.excess_reserve.toLocaleString()} Unencumbered` },
    { num: '3', name: 'Policy Engine', status: 'ACTIVE', desc: 'Daily Cap & Per-Tx Limit Passed' },
    { num: '4', name: 'Multi-Sig Approval', status: 'ACTIVE', desc: '2-of-3 Officer Threshold Required' },
    { num: '5', name: 'Mint Queue', status: 'PENDING', desc: 'Deterministic State Transition' },
    { num: '6', name: 'PoS Block Proposal', status: 'PENDING', desc: '21 Validator Committee Attestation' },
    { num: '7', name: 'Finality & Posting', status: 'PENDING', desc: 'Balanced Double-Entry Journal' }
  ];

  return (
    <div className="space-y-6">
      {/* Top Title & 7-Stage Pipeline Diagram */}
      <div className="bg-[#080809] border border-[#27272A] p-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] flex items-center gap-2">
              <Landmark className="w-4 h-4 text-[#F2F2F2]" />
              CONTROLLED MONEY ISSUANCE PIPELINE & MULTI-SIG WORKFLOW
            </h2>
            <p className="text-xs text-[#71717A] font-mono mt-1">
              Strict Separation: Consensus authority cannot mint money. All coin creation requires reserve proof & multi-sig governance signatures.
            </p>
          </div>
          <div className="bg-[#050505] px-3 py-1.5 border border-[#27272A] text-xs font-mono">
            <span className="text-[#71717A] uppercase text-[10px] tracking-wider">RULE: </span>
            <span className="text-[#10B981] font-bold">2-OF-3 OFFICER SIGNATURES</span>
          </div>
        </div>

        {/* 7-Stage Horizontal Pipeline Diagram */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 pt-2">
          {pipelineStages.map((stg, idx) => (
            <div key={stg.num} className="relative flex flex-col justify-between p-3 bg-[#050505] border border-[#27272A] text-center font-mono">
              <div>
                <div className="flex justify-center mb-1">
                  <span className="w-5 h-5 bg-[#F2F2F2] text-black text-[10px] font-extrabold flex items-center justify-center">
                    {stg.num}
                  </span>
                </div>
                <div className="text-xs font-extrabold text-[#F2F2F2] leading-tight mb-1">{stg.name}</div>
                <div className="text-[9px] text-[#71717A] leading-tight">{stg.desc}</div>
              </div>

              {idx < pipelineStages.length - 1 && (
                <div className="hidden lg:block absolute -right-2.5 top-1/2 -translate-y-1/2 z-10 text-[#71717A]">
                  <ArrowRight className="w-3.5 h-3.5 text-[#10B981]" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Main Grid: Submit Form & Pending Approval Queue */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Submit Issuance Request Form */}
        <div className="bg-[#080809] border border-[#27272A] p-6">
          <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] mb-4 flex items-center gap-2">
            <PlusCircle className="w-4 h-4 text-[#10B981]" />
            SUBMIT COIN ISSUANCE REQUEST
          </h3>

          <form onSubmit={handleSubmit} className="space-y-4 font-mono text-xs">
            <div>
              <label className="block text-[10px] font-mono uppercase tracking-widest text-[#71717A] mb-1">TARGET ISSUED COIN</label>
              <select
                value={selectedCoin}
                onChange={(e) => setSelectedCoin(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-2.5 text-[#F2F2F2] focus:border-[#F2F2F2] outline-none font-bold"
              >
                {coins.map(c => (
                  <option key={c.coin_id} value={c.coin_id}>{c.coin_id} — {c.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-mono uppercase tracking-widest text-[#71717A] mb-1">ISSUANCE AMOUNT ({selectedCoin})</label>
              <input
                type="number"
                value={amountInput}
                onChange={(e) => setAmountInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-2.5 text-[#F2F2F2] focus:border-[#F2F2F2] outline-none font-extrabold text-base"
                placeholder="5000000"
              />
            </div>

            <div>
              <label className="block text-[10px] font-mono uppercase tracking-widest text-[#71717A] mb-1">BENEFICIARY LEDGER ACCOUNT</label>
              <select
                value={beneficiaryInput}
                onChange={(e) => setBeneficiaryInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-2.5 text-[#F2F2F2] focus:border-[#F2F2F2] outline-none"
              >
                {accounts.map(acc => (
                  <option key={acc.account_id} value={acc.account_id}>
                    {acc.owner_name} ({acc.account_id})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-mono uppercase tracking-widest text-[#71717A] mb-1">RESERVE BACKING ASSET REFERENCE</label>
              <select
                value={reserveRefInput}
                onChange={(e) => setReserveRefInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-2.5 text-[#F2F2F2] focus:border-[#F2F2F2] outline-none"
              >
                <option value="RES_BOE_CASH">Bank of England Cash Reserve (0% Haircut)</option>
                <option value="RES_UK_GILTS">UK Treasury Bills 0-3M (1% Haircut)</option>
                <option value="RES_FED_CASH">Federal Reserve USD Cash Deposit</option>
                <option value="RES_GOLD_VAULT">Brinks Physical Gold Vault London</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-mono uppercase tracking-widest text-[#71717A] mb-1">INITIATING MONETARY OFFICER</label>
              <select
                value={officerInput}
                onChange={(e) => setOfficerInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-2.5 text-[#F2F2F2] focus:border-[#F2F2F2] outline-none"
              >
                <option value="AUTH_OFFICER_1">Dr. Evelyn Vance (Chief Monetary Officer)</option>
                <option value="AUTH_OFFICER_2">Marcus Brody (Head of Financial Risk)</option>
                <option value="AUTH_OFFICER_3">Lady Helena Sterling (Treasury Controller)</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-mono uppercase tracking-widest text-[#71717A] mb-1">JUSTIFICATION & AUDIT REASON</label>
              <input
                type="text"
                value={reasonInput}
                onChange={(e) => setReasonInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-2.5 text-[#F2F2F2] focus:border-[#F2F2F2] outline-none"
              />
            </div>

            {submitFeedback && (
              <div className="p-3 bg-[#10B981]/10 border border-[#10B981]/40 text-[#10B981] font-mono text-xs font-bold">
                {submitFeedback}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-[#F2F2F2] hover:bg-transparent text-black hover:text-[#F2F2F2] font-bold p-3 uppercase tracking-widest text-xs border border-[#F2F2F2] transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <Landmark className="w-4 h-4" />
              <span>SUBMIT ISSUANCE REQUEST</span>
            </button>
          </form>
        </div>

        {/* Multi-Sig Approval Queue & Active Issuance Records */}
        <div className="bg-[#080809] border border-[#27272A] p-6 lg:col-span-2 space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#10B981]" />
              ISSUANCE AUTHORIZATION QUEUE (MULTI-SIG SIGNING)
            </h3>
            <span className="text-xs font-mono text-[#71717A]">{issuanceRequests.length} Total Requests</span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {issuanceRequests.length === 0 ? (
              <div className="p-6 text-center text-[#71717A] bg-[#050505] border border-[#27272A]">
                No issuance requests submitted. Submit a new request using the form.
              </div>
            ) : (
              issuanceRequests.map((req) => (
                <div key={req.request_id} className="p-4 bg-[#050505] border border-[#27272A] space-y-3">
                  <div className="flex flex-wrap justify-between items-start gap-2 border-b border-[#27272A] pb-3">
                    <div>
                      <div className="font-extrabold text-[#F2F2F2] text-sm flex items-center gap-2">
                        <span>{req.request_id}</span>
                        <span className={`px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                          req.status === 'MINTED' ? 'bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/40' :
                          req.status === 'PENDING' ? 'bg-[#F59E0B]/10 text-[#F59E0B] border border-[#F59E0B]/40' :
                          'bg-[#EF4444]/10 text-[#EF4444] border border-[#EF4444]/40'
                        }`}>
                          {req.status}
                        </span>
                      </div>
                      <div className="text-xs text-[#A1A1AA] mt-1">
                        Amount: <span className="text-[#10B981] font-bold">£{req.amount.toLocaleString()} {req.coin_id}</span> · Beneficiary: <span className="text-[#F2F2F2] font-bold">{req.beneficiary_account}</span>
                      </div>
                    </div>

                    <div className="text-right text-xs text-[#71717A]">
                      <div>Approvals: <span className="text-[#10B981] font-bold">{req.approvals.length} / {req.required_approvals} Required</span></div>
                      {req.mint_tx_hash && <div className="text-[#A1A1AA] text-[10px]">{req.mint_tx_hash}</div>}
                    </div>
                  </div>

                  <div className="text-xs text-[#D4D4D8] bg-[#080809] p-2.5 border border-[#27272A]">
                    <span className="text-[#71717A] uppercase text-[10px] tracking-wider">Reason: </span>{req.reason}
                  </div>

                  {/* Multi-Sig Officer Approval Panel */}
                  {req.status === 'PENDING' && (
                    <div className="pt-2 border-t border-[#27272A]">
                      <div className="text-[10px] font-mono uppercase tracking-widest text-[#71717A] mb-2 font-bold">SIGN AS AUTHORIZED MONETARY OFFICER:</div>
                      <div className="flex flex-wrap gap-2">
                        {[
                          { id: 'AUTH_OFFICER_1', name: 'Dr. Evelyn Vance (Chief Officer)' },
                          { id: 'AUTH_OFFICER_2', name: 'Marcus Brody (Head of Risk)' },
                          { id: 'AUTH_OFFICER_3', name: 'Lady Helena Sterling (Treasury)' }
                        ].map((officer) => {
                          const hasSigned = req.approvals.includes(officer.id);
                          return (
                            <button
                              key={officer.id}
                              onClick={() => !hasSigned && onApproveRequest(req.request_id, officer.id)}
                              disabled={hasSigned}
                              className={`px-3 py-1.5 text-[11px] font-mono font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer transition-colors ${
                                hasSigned
                                  ? 'bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/40 cursor-not-allowed'
                                  : 'bg-[#080809] hover:bg-[#18181B] text-[#F2F2F2] border border-[#3F3F46] hover:border-[#F2F2F2]'
                              }`}
                            >
                              {hasSigned ? <Check className="w-3.5 h-3.5 text-[#10B981]" /> : <PlusCircle className="w-3.5 h-3.5 text-[#F2F2F2]" />}
                              <span>{hasSigned ? `Signed (${officer.id})` : `Sign (${officer.id})`}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
