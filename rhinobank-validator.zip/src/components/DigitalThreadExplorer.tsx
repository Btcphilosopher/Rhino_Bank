import React, { useState } from 'react';
import { Network, Search, ArrowRight, ShieldCheck, CheckCircle2, FileText, Database, Landmark, Lock, Cpu } from 'lucide-react';
import { Block, DigitalThreadTrace } from '../types/rhino';

interface ExplorerProps {
  blocks: Block[];
  onGetTrace: (txId: string) => DigitalThreadTrace | null;
}

export const DigitalThreadExplorer: React.FC<ExplorerProps> = ({ blocks, onGetTrace }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTrace, setActiveTrace] = useState<DigitalThreadTrace | null>(null);

  // Find sample transaction
  const sampleTxId = blocks[0]?.transactions[0]?.transaction_id || 'TX_MINT_RGBP_GENESIS';

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const trace = onGetTrace(searchTerm.trim() || sampleTxId);
    setActiveTrace(trace);
  };

  const handleSelectTx = (txId: string) => {
    setSearchTerm(txId);
    const trace = onGetTrace(txId);
    setActiveTrace(trace);
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Search Bar */}
      <div className="bg-[#080809] border border-[#27272A] p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] flex items-center gap-2">
              <Network className="w-4 h-4 text-[#F2F2F2]" />
              DIGITAL MONEY THREAD & CAUSAL TRACE EXPLORER
            </h2>
            <p className="text-xs text-[#71717A] font-mono mt-1">
              Every unit of issued money is computationally traceable from its Central Bank policy & reserve proof down to block finality and double-entry postings.
            </p>
          </div>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="flex gap-2">
          <div className="relative flex-1 font-mono text-xs">
            <Search className="w-4 h-4 text-[#71717A] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by Transaction ID (e.g. TX_MINT_RGBP...), Block Hash, or Account ID..."
              className="w-full bg-[#050505] border border-[#27272A] pl-9 pr-3 py-3 text-[#F2F2F2] focus:border-[#F2F2F2] outline-none font-bold"
            />
          </div>
          <button
            type="submit"
            className="bg-[#F2F2F2] hover:bg-transparent text-black hover:text-[#F2F2F2] font-mono text-xs font-bold uppercase tracking-widest px-5 py-3 border border-[#F2F2F2] cursor-pointer transition-colors"
          >
            TRACE THREAD
          </button>
        </form>
      </div>

      {/* Active Digital Thread Trace View */}
      {activeTrace ? (
        <div className="bg-[#080809] border border-[#27272A] p-6 space-y-6">
          <div className="flex justify-between items-center border-b border-[#27272A] pb-4">
            <div>
              <span className="text-[10px] font-mono uppercase tracking-[0.3em] text-[#71717A]">DIGITAL MONEY THREAD LINEAGE</span>
              <h3 className="text-xl font-extrabold font-mono text-[#F2F2F2] mt-0.5">
                £{activeTrace.amount.toLocaleString()} {activeTrace.coin_id} Issued & Settled
              </h3>
            </div>
            <span className="px-3 py-1 bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/40 font-mono text-xs font-bold uppercase tracking-widest">
              FINALITY: {activeTrace.finality_status}
            </span>
          </div>

          {/* Complete 8-Step Causal Lineage Visualization */}
          <div className="space-y-4 font-mono text-xs">
            {/* Step 1: Monetary Policy Rule */}
            <div className="p-4 bg-[#050505] border border-[#27272A] flex items-start gap-4 border-l-2 border-l-[#10B981]">
              <div className="w-7 h-7 bg-[#F2F2F2] text-black font-extrabold flex items-center justify-center text-xs shrink-0 mt-0.5">1</div>
              <div className="flex-1">
                <div className="font-extrabold text-[#F2F2F2] flex items-center gap-2 text-sm">
                  <Lock className="w-4 h-4 text-[#F2F2F2]" />
                  <span>MONETARY POLICY RULE & ISSUANCE LIMIT</span>
                </div>
                <div className="text-[#A1A1AA] text-xs mt-1">
                  Policy Version #{activeTrace.policy_check_result.version} · {activeTrace.policy_check_result.reason}
                </div>
              </div>
            </div>

            {/* Step 2: Reserve Backing Assets */}
            <div className="p-4 bg-[#050505] border border-[#27272A] flex items-start gap-4 border-l-2 border-l-[#10B981]">
              <div className="w-7 h-7 bg-[#10B981] text-black font-extrabold flex items-center justify-center text-xs shrink-0 mt-0.5">2</div>
              <div className="flex-1">
                <div className="font-extrabold text-[#F2F2F2] flex items-center gap-2 text-sm">
                  <Database className="w-4 h-4 text-[#10B981]" />
                  <span>CUSTODIAL RESERVE BACKING PROOF</span>
                </div>
                <div className="text-[#A1A1AA] text-xs mt-1 space-y-1">
                  {activeTrace.reserve_assets_backed.map(r => (
                    <div key={r.asset_id} className="text-[#D4D4D8]">
                      · {r.name} ({r.custodian}): <span className="text-[#10B981] font-extrabold">£{r.valuation.toLocaleString()}</span> (Haircut: {(r.haircut*100).toFixed(0)}%)
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Step 3: Multi-Signature Authorization */}
            <div className="p-4 bg-[#050505] border border-[#27272A] flex items-start gap-4 border-l-2 border-l-[#10B981]">
              <div className="w-7 h-7 bg-[#F59E0B] text-black font-extrabold flex items-center justify-center text-xs shrink-0 mt-0.5">3</div>
              <div className="flex-1">
                <div className="font-extrabold text-[#F2F2F2] flex items-center gap-2 text-sm">
                  <Landmark className="w-4 h-4 text-[#F59E0B]" />
                  <span>MULTI-SIG MONETARY AUTHORITY SIGN-OFF (2-OF-3)</span>
                </div>
                <div className="text-[#A1A1AA] text-xs mt-2 flex flex-wrap gap-2">
                  {activeTrace.authorisations.map((auth, idx) => (
                    <span key={idx} className="px-2.5 py-1 bg-[#080809] text-[#F2F2F2] border border-[#3F3F46] uppercase font-bold text-[10px]">
                      ✓ {auth}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Step 4: Mint Transaction */}
            <div className="p-4 bg-[#050505] border border-[#27272A] flex items-start gap-4 border-l-2 border-l-[#10B981]">
              <div className="w-7 h-7 bg-[#F2F2F2] text-black font-extrabold flex items-center justify-center text-xs shrink-0 mt-0.5">4</div>
              <div className="flex-1">
                <div className="font-extrabold text-[#F2F2F2] text-sm">MINT TRANSACTION AUTHORIZATION</div>
                <div className="text-[#A1A1AA] text-xs mt-1 font-mono">
                  TxID: <span className="text-[#F2F2F2] font-bold">{activeTrace.mint_transaction?.transaction_id}</span> · Nonce: #{activeTrace.mint_transaction?.nonce}
                </div>
              </div>
            </div>

            {/* Step 5: PoS Consensus Block & Attestations */}
            <div className="p-4 bg-[#050505] border border-[#27272A] flex items-start gap-4 border-l-2 border-l-[#10B981]">
              <div className="w-7 h-7 bg-[#10B981] text-black font-extrabold flex items-center justify-center text-xs shrink-0 mt-0.5">5</div>
              <div className="flex-1">
                <div className="font-extrabold text-[#F2F2F2] flex items-center gap-2 text-sm">
                  <Cpu className="w-4 h-4 text-[#10B981]" />
                  <span>PROOF-OF-STAKE BLOCK #{activeTrace.block?.height} FINALITY</span>
                </div>
                <div className="text-[#A1A1AA] text-xs mt-1">
                  Block Hash: <span className="text-[#F2F2F2]">{activeTrace.block?.hash}</span> · Proposer: <span className="text-[#F2F2F2] font-bold">{activeTrace.block?.proposer_id}</span>
                </div>
                <div className="text-xs text-[#10B981] font-bold mt-1 uppercase tracking-wider">
                  Attested by {activeTrace.attesting_validators.length} PoS Bank Nodes with BLS Signatures
                </div>
              </div>
            </div>

            {/* Step 6: Double-Entry Journal Entry */}
            <div className="p-4 bg-[#050505] border border-[#27272A] flex items-start gap-4 border-l-2 border-l-[#10B981]">
              <div className="w-7 h-7 bg-[#F2F2F2] text-black font-extrabold flex items-center justify-center text-xs shrink-0 mt-0.5">6</div>
              <div className="flex-1">
                <div className="font-extrabold text-[#F2F2F2] flex items-center gap-2 text-sm">
                  <FileText className="w-4 h-4 text-[#10B981]" />
                  <span>BALANCED DOUBLE-ENTRY JOURNAL ENTRY ({activeTrace.journal_entry?.entry_id})</span>
                </div>
                <div className="mt-3 space-y-1.5 text-xs">
                  {activeTrace.journal_entry?.postings.map((p, idx) => (
                    <div key={idx} className="flex justify-between bg-[#080809] p-2 border border-[#27272A]">
                      <span className="text-[#D4D4D8] font-bold">{p.account_name} ({p.account_id})</span>
                      <span className="font-extrabold">
                        {p.debit > 0 ? <span className="text-[#10B981]">DR £{p.debit.toLocaleString()}</span> : <span className="text-[#F2F2F2]">CR £{p.credit.toLocaleString()}</span>}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-[#080809] border border-[#27272A] p-6">
          <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] mb-4">SELECT TRANSACTION TO TRACE DIGITAL THREAD</h3>
          <div className="space-y-2 font-mono text-xs">
            {blocks[0]?.transactions.map((tx) => (
              <button
                key={tx.transaction_id}
                onClick={() => handleSelectTx(tx.transaction_id)}
                className="w-full text-left p-4 bg-[#050505] hover:bg-[#18181B] border border-[#27272A] hover:border-[#F2F2F2] flex justify-between items-center cursor-pointer transition-colors"
              >
                <div>
                  <div className="font-extrabold text-[#F2F2F2] text-sm">{tx.transaction_id}</div>
                  <div className="text-xs text-[#A1A1AA] mt-1">
                    Type: <span className="text-[#F2F2F2] font-bold">{tx.type}</span> · Amount: <span className="text-[#10B981] font-extrabold">£{tx.amount.toLocaleString()} {tx.coin_id}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-[#F2F2F2] font-bold uppercase tracking-widest text-xs">
                  <span>Trace Thread</span>
                  <ArrowRight className="w-4 h-4 text-[#10B981]" />
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
