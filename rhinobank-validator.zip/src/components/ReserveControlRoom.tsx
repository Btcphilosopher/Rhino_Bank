import React, { useState } from 'react';
import { Database, ShieldCheck, AlertOctagon, Landmark, Plus, FileCheck, DollarSign } from 'lucide-react';
import { ReserveAsset, ReserveCoverage } from '../types/rhino';

interface ReserveProps {
  reserves: ReserveAsset[];
  coverage: ReserveCoverage;
}

export const ReserveControlRoom: React.FC<ReserveProps> = ({ reserves, coverage }) => {
  const [assetName, setAssetName] = useState('Central Bank Reserve Deposit');
  const [assetType, setAssetType] = useState<ReserveAsset['type']>('CENTRAL_BANK_RESERVE');
  const [custodian, setCustodian] = useState('Bank of England');
  const [valuation, setValuation] = useState('10000000');
  const [haircut, setHaircut] = useState('0.00');

  return (
    <div className="space-y-6">
      {/* Top Coverage Status Card */}
      <div className="bg-[#080809] border border-[#27272A] p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#27272A]">
          <div>
            <h2 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] flex items-center gap-2">
              <Database className="w-4 h-4 text-[#10B981]" />
              CENTRAL RESERVE ASSET INVENTORY & SOLVENCY MONITOR
            </h2>
            <p className="text-xs text-[#71717A] font-mono mt-1">
              Authoritative reserve backing records verified against custody accounts. 100%+ collateral ratio required prior to any coin minting.
            </p>
          </div>

          <div className="flex items-center gap-3 font-mono text-xs">
            <div className="bg-[#050505] p-3 border border-[#27272A] text-center min-w-[120px]">
              <div className="text-[9px] font-mono uppercase tracking-widest text-[#71717A]">GROSS RESERVES</div>
              <div className="text-base font-extrabold text-[#F2F2F2] mt-0.5">£{coverage.gross_reserves.toLocaleString()}</div>
            </div>
            <div className="bg-[#050505] p-3 border border-[#27272A] text-center min-w-[140px]">
              <div className="text-[9px] font-mono uppercase tracking-widest text-[#71717A]">NET ELIGIBLE</div>
              <div className="text-base font-extrabold text-[#10B981] mt-0.5">£{coverage.eligible_reserves.toLocaleString()}</div>
            </div>
            <div className="bg-[#050505] p-3 border border-[#27272A] text-center min-w-[110px]">
              <div className="text-[9px] font-mono uppercase tracking-widest text-[#71717A]">COVERAGE</div>
              <div className="text-base font-extrabold text-[#10B981] mt-0.5">{(coverage.coverage_ratio * 100).toFixed(1)}%</div>
            </div>
          </div>
        </div>

        {/* Reserve Asset Inventory Table */}
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-[#27272A] text-[#71717A] bg-[#050505]">
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">ASSET ID</th>
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">RESERVE ASSET NAME</th>
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">TYPE</th>
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">CUSTODIAN</th>
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">VALUATION (GBP)</th>
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">HAIRCUT</th>
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">NET ELIGIBLE VALUE</th>
                <th className="py-3 px-3 font-mono text-[10px] uppercase tracking-widest">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#27272A]">
              {reserves.map((res) => {
                const eligibleVal = res.valuation * (1 - res.haircut);
                return (
                  <tr key={res.asset_id} className="hover:bg-[#0F0F12] transition-colors">
                    <td className="py-3 px-3 font-extrabold text-[#F2F2F2]">{res.asset_id}</td>
                    <td className="py-3 px-3 font-bold text-[#F2F2F2]">{res.name}</td>
                    <td className="py-3 px-3 text-[#A1A1AA]">{res.type}</td>
                    <td className="py-3 px-3 text-[#D4D4D8]">{res.custodian}</td>
                    <td className="py-3 px-3 text-[#F2F2F2] font-extrabold">
                      £{res.valuation.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-[#F59E0B] font-bold">
                      {(res.haircut * 100).toFixed(1)}%
                    </td>
                    <td className="py-3 px-3 text-[#10B981] font-extrabold">
                      £{eligibleVal.toLocaleString()}
                    </td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 text-[10px] font-bold font-mono uppercase bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/40">
                        {res.encumbrance_status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Additional Asset Rules & Reconciliation Panel */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#080809] border border-[#27272A] p-6">
          <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] mb-4 flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-[#F2F2F2]" />
            RESERVE ELIGIBILITY & HAIRCUT RULES
          </h3>
          <div className="space-y-2 text-xs font-mono text-[#A1A1AA]">
            <div className="p-3 bg-[#050505] border border-[#27272A] flex justify-between items-center">
              <span>Central Bank Reserves (BoE / Fed)</span>
              <span className="text-[#10B981] font-bold uppercase text-[10px]">0% HAIRCUT (TIER 1)</span>
            </div>
            <div className="p-3 bg-[#050505] border border-[#27272A] flex justify-between items-center">
              <span>UK Treasury Bills (0-3M)</span>
              <span className="text-[#10B981] font-bold uppercase text-[10px]">1% HAIRCUT (TIER 1)</span>
            </div>
            <div className="p-3 bg-[#050505] border border-[#27272A] flex justify-between items-center">
              <span>Allocated Vault Physical Gold Bullion</span>
              <span className="text-[#F59E0B] font-bold uppercase text-[10px]">5% HAIRCUT (TIER 2)</span>
            </div>
            <div className="p-3 bg-[#050505] border border-[#27272A] flex justify-between items-center">
              <span>Commercial Bank Deposits</span>
              <span className="text-[#F59E0B] font-bold uppercase text-[10px]">2% HAIRCUT (TIER 2)</span>
            </div>
          </div>
        </div>

        <div className="bg-[#080809] border border-[#27272A] p-6">
          <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] mb-4 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#10B981]" />
            SOLVENCY ALERT LEVELS & CIRCUIT BREAKERS
          </h3>
          <div className="space-y-2 text-xs font-mono text-[#A1A1AA]">
            <div className="p-3 bg-[#050505] border border-[#27272A] flex justify-between items-center border-l-2 border-l-[#10B981]">
              <div>
                <div className="text-[#10B981] font-bold uppercase tracking-wider">NORMAL (COVERAGE &gt;= 105%)</div>
                <div className="text-[10px] text-[#71717A]">Standard issuance & redemption active</div>
              </div>
              <span className="text-[#10B981] text-[10px] font-bold px-2 py-0.5 bg-[#10B981]/10 border border-[#10B981]/40 uppercase tracking-widest">CURRENT</span>
            </div>
            <div className="p-3 bg-[#050505] border border-[#27272A] flex justify-between items-center">
              <div>
                <div className="text-[#F59E0B] font-bold uppercase tracking-wider">WATCH (COVERAGE 100% - 105%)</div>
                <div className="text-[10px] text-[#71717A]">Enhanced daily reconciliation audits</div>
              </div>
            </div>
            <div className="p-3 bg-[#050505] border border-[#27272A] flex justify-between items-center">
              <div>
                <div className="text-[#EF4444] font-bold uppercase tracking-wider">CRITICAL (COVERAGE &lt; 100%)</div>
                <div className="text-[10px] text-[#71717A]">Automatic Issuance Circuit Breaker Freeze</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
