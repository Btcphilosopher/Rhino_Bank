import React, { useState } from 'react';
import { Lock, ShieldAlert, AlertTriangle, Key, UserX, PauseCircle, PlayCircle, Settings } from 'lucide-react';
import { MonetaryPolicy, AuditEvent } from '../types/rhino';

interface GovernanceProps {
  policy: MonetaryPolicy;
  auditTrail: AuditEvent[];
  onUpdatePolicy: (partial: Partial<MonetaryPolicy>, operator: string) => void;
}

export const GovernanceEmergencyRoom: React.FC<GovernanceProps> = ({
  policy,
  auditTrail,
  onUpdatePolicy
}) => {
  const [reserveRatioInput, setReserveRatioInput] = useState(policy.min_reserve_ratio.toString());
  const [dailyCapInput, setDailyCapInput] = useState((policy.max_daily_issuance['RGBP'] || 50000000).toString());
  const [freezeAccountInput, setFreezeAccountInput] = useState('');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const handleSavePolicy = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdatePolicy({
      min_reserve_ratio: parseFloat(reserveRatioInput) || 1.0,
      max_daily_issuance: { RGBP: parseFloat(dailyCapInput) || 50000000 }
    }, 'GOVERNANCE_BOARD');
    setStatusMsg('Monetary Policy v' + (policy.version + 1) + ' updated successfully.');
    setTimeout(() => setStatusMsg(null), 4000);
  };

  const toggleEmergencyIssuance = () => {
    onUpdatePolicy({ emergency_issuance_paused: !policy.emergency_issuance_paused }, 'EMERGENCY_OFFICER');
  };

  const toggleEmergencyRedemption = () => {
    onUpdatePolicy({ emergency_redemption_paused: !policy.emergency_redemption_paused }, 'EMERGENCY_OFFICER');
  };

  const toggleEmergencyTransfers = () => {
    onUpdatePolicy({ emergency_transfers_paused: !policy.emergency_transfers_paused }, 'EMERGENCY_OFFICER');
  };

  const handleFreezeAccount = () => {
    if (!freezeAccountInput) return;
    const existing = [...policy.frozen_accounts];
    if (!existing.includes(freezeAccountInput)) {
      existing.push(freezeAccountInput);
      onUpdatePolicy({ frozen_accounts: existing }, 'COMPLIANCE_OFFICER');
      setStatusMsg(`Account ${freezeAccountInput} frozen by Compliance Officer.`);
      setFreezeAccountInput('');
      setTimeout(() => setStatusMsg(null), 4000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Emergency Circuit Breakers Banner */}
      <div className="bg-[#080809] border border-[#EF4444]/40 p-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#EF4444] flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-[#EF4444]" />
              MONETARY GOVERNANCE & EMERGENCY CIRCUIT BREAKERS
            </h2>
            <p className="text-xs text-[#71717A] font-mono mt-1">
              Authorized monetary control operations. All emergency actions produce immutable cryptographic audit events in the governance ledger.
            </p>
          </div>
        </div>

        {/* 3 Circuit Breaker Toggles */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          {/* Breaker 1: Issuance */}
          <div className="p-4 bg-[#050505] border border-[#27272A] flex flex-col justify-between">
            <div>
              <div className="font-extrabold text-[#F2F2F2] mb-1 text-sm uppercase tracking-wider">EMERGENCY ISSUANCE FREEZE</div>
              <div className="text-[10px] text-[#71717A]">Halt all new coin minting requests across all assets</div>
            </div>
            <div className="mt-4 flex justify-between items-center pt-3 border-t border-[#27272A]">
              <span className={`text-[10px] font-extrabold uppercase tracking-widest ${policy.emergency_issuance_paused ? 'text-[#EF4444]' : 'text-[#10B981]'}`}>
                {policy.emergency_issuance_paused ? 'PAUSED' : 'ACTIVE'}
              </span>
              <button
                onClick={toggleEmergencyIssuance}
                className={`px-3 py-1.5 font-extrabold uppercase tracking-widest text-[10px] cursor-pointer transition-colors border ${
                  policy.emergency_issuance_paused
                    ? 'bg-[#10B981] text-black border-[#10B981]'
                    : 'bg-[#EF4444] text-white border-[#EF4444]'
                }`}
              >
                {policy.emergency_issuance_paused ? 'RESUME MINTING' : 'FREEZE MINTING'}
              </button>
            </div>
          </div>

          {/* Breaker 2: Redemption */}
          <div className="p-4 bg-[#050505] border border-[#27272A] flex flex-col justify-between">
            <div>
              <div className="font-extrabold text-[#F2F2F2] mb-1 text-sm uppercase tracking-wider">EMERGENCY REDEMPTION FREEZE</div>
              <div className="text-[10px] text-[#71717A]">Halt coin burning & par 1:1 fiat wire settlement</div>
            </div>
            <div className="mt-4 flex justify-between items-center pt-3 border-t border-[#27272A]">
              <span className={`text-[10px] font-extrabold uppercase tracking-widest ${policy.emergency_redemption_paused ? 'text-[#EF4444]' : 'text-[#10B981]'}`}>
                {policy.emergency_redemption_paused ? 'PAUSED' : 'ACTIVE'}
              </span>
              <button
                onClick={toggleEmergencyRedemption}
                className={`px-3 py-1.5 font-extrabold uppercase tracking-widest text-[10px] cursor-pointer transition-colors border ${
                  policy.emergency_redemption_paused
                    ? 'bg-[#10B981] text-black border-[#10B981]'
                    : 'bg-[#EF4444] text-white border-[#EF4444]'
                }`}
              >
                {policy.emergency_redemption_paused ? 'RESUME REDEMPTION' : 'FREEZE REDEMPTION'}
              </button>
            </div>
          </div>

          {/* Breaker 3: Transfers */}
          <div className="p-4 bg-[#050505] border border-[#27272A] flex flex-col justify-between">
            <div>
              <div className="font-extrabold text-[#F2F2F2] mb-1 text-sm uppercase tracking-wider">NETWORK TRANSFERS HALT</div>
              <div className="text-[10px] text-[#71717A]">Halt interbank & peer transfers in case of emergency</div>
            </div>
            <div className="mt-4 flex justify-between items-center pt-3 border-t border-[#27272A]">
              <span className={`text-[10px] font-extrabold uppercase tracking-widest ${policy.emergency_transfers_paused ? 'text-[#EF4444]' : 'text-[#10B981]'}`}>
                {policy.emergency_transfers_paused ? 'HALTED' : 'ACTIVE'}
              </span>
              <button
                onClick={toggleEmergencyTransfers}
                className={`px-3 py-1.5 font-extrabold uppercase tracking-widest text-[10px] cursor-pointer transition-colors border ${
                  policy.emergency_transfers_paused
                    ? 'bg-[#10B981] text-black border-[#10B981]'
                    : 'bg-[#EF4444] text-white border-[#EF4444]'
                }`}
              >
                {policy.emergency_transfers_paused ? 'RESUME NETWORK' : 'HALT TRANSFERS'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Policy Parameters & Compliance Freezer */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Monetary Policy Parameters Form */}
        <div className="bg-[#080809] border border-[#27272A] p-6">
          <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] mb-4 flex items-center gap-2">
            <Settings className="w-4 h-4 text-[#F2F2F2]" />
            MONETARY POLICY PARAMETERS (v{policy.version})
          </h3>

          <form onSubmit={handleSavePolicy} className="space-y-4 font-mono text-xs">
            <div>
              <label className="block text-[#71717A] uppercase tracking-widest text-[10px] mb-1">MINIMUM RESERVE BACKING RATIO</label>
              <input
                type="number"
                step="0.01"
                value={reserveRatioInput}
                onChange={(e) => setReserveRatioInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-3 text-[#F2F2F2] font-extrabold outline-none"
              />
              <span className="text-[10px] text-[#71717A] mt-1 block">Default: 1.0 = 100% Full Reserve Backing</span>
            </div>

            <div>
              <label className="block text-[#71717A] uppercase tracking-widest text-[10px] mb-1">MAX DAILY ISSUANCE CAP (RGBP)</label>
              <input
                type="number"
                value={dailyCapInput}
                onChange={(e) => setDailyCapInput(e.target.value)}
                className="w-full bg-[#050505] border border-[#27272A] p-3 text-[#F2F2F2] font-extrabold outline-none"
              />
            </div>

            {statusMsg && (
              <div className="p-3 bg-[#10B981]/10 border border-[#10B981]/40 text-[#10B981] text-xs font-mono font-bold uppercase tracking-wider">
                {statusMsg}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-[#F2F2F2] hover:bg-transparent text-black hover:text-[#F2F2F2] font-bold p-3 border border-[#F2F2F2] cursor-pointer transition-colors uppercase tracking-widest text-xs"
            >
              UPDATE POLICY PARAMETERS
            </button>
          </form>
        </div>

        {/* Account Restriction & Freeze Control */}
        <div className="bg-[#080809] border border-[#27272A] p-6">
          <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] mb-4 flex items-center gap-2">
            <UserX className="w-4 h-4 text-[#F59E0B]" />
            ACCOUNT RESTRICTION & COMPLIANCE FREEZE
          </h3>

          <div className="space-y-4 font-mono text-xs">
            <div>
              <label className="block text-[#71717A] uppercase tracking-widest text-[10px] mb-1">TARGET ACCOUNT ID TO FREEZE</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={freezeAccountInput}
                  onChange={(e) => setFreezeAccountInput(e.target.value)}
                  placeholder="e.g. ACC_CUST_BOB"
                  className="flex-1 bg-[#050505] border border-[#27272A] p-3 text-[#F2F2F2] outline-none font-bold"
                />
                <button
                  type="button"
                  onClick={handleFreezeAccount}
                  className="bg-[#F59E0B] hover:bg-[#D97706] text-black font-extrabold px-4 py-3 cursor-pointer uppercase tracking-widest text-xs"
                >
                  FREEZE
                </button>
              </div>
            </div>

            <div>
              <div className="text-[#71717A] text-[10px] uppercase tracking-widest mb-2 font-bold">CURRENTLY FROZEN ACCOUNTS:</div>
              <div className="space-y-1.5">
                {policy.frozen_accounts.length === 0 ? (
                  <div className="p-3 bg-[#050505] text-[#71717A] border border-[#27272A] text-xs">No accounts currently frozen.</div>
                ) : (
                  policy.frozen_accounts.map(acc => (
                    <div key={acc} className="p-3 bg-[#050505] border border-[#EF4444]/40 text-[#EF4444] font-extrabold flex justify-between items-center">
                      <span>{acc}</span>
                      <span className="text-[9px] uppercase tracking-widest border border-[#EF4444]/40 px-2 py-0.5">COMPLIANCE_FREEZE</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Immutable Governance Audit Trail Log */}
      <div className="bg-[#080809] border border-[#27272A] p-6">
        <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] mb-4">IMMUTABLE GOVERNANCE AUDIT TRAIL LOG</h3>
        <div className="space-y-2 font-mono text-xs max-h-60 overflow-y-auto pr-1">
          {auditTrail.map((ev) => (
            <div key={ev.event_id} className="p-3 bg-[#050505] border border-[#27272A] flex justify-between items-center">
              <div>
                <div className="font-extrabold text-[#F2F2F2]">{ev.event_type}</div>
                <div className="text-[10px] text-[#71717A] mt-0.5">Actor: {ev.actor} · Hash: {ev.hash.substring(0, 16)}...</div>
              </div>
              <div className="text-[10px] text-[#71717A] font-mono">
                {new Date(ev.timestamp).toLocaleTimeString()}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
