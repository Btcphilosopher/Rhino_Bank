import React, { useState } from 'react';
import { ShieldAlert, Play, CheckCircle2, AlertOctagon, Terminal, ArrowRight, ShieldCheck } from 'lucide-react';
import { SimulationScenarioResult } from '../types/rhino';

interface SimulatorProps {
  onRunScenario: (key: string) => SimulationScenarioResult;
}

export const MonetarySimulatorRoom: React.FC<SimulatorProps> = ({ onRunScenario }) => {
  const [activeScenario, setActiveScenario] = useState<string>('SCENARIO_A');
  const [simResult, setSimResult] = useState<SimulationScenarioResult | null>(null);

  const scenariosList = [
    { key: 'SCENARIO_A', name: 'Scenario A: Normal Issuance & Settlement', category: 'MONETARY' },
    { key: 'SCENARIO_B', name: 'Scenario B: High Redemption / Bank Run Stress', category: 'MONETARY' },
    { key: 'UNAUTHORIZED_MINT_ATTACK', name: 'Attack Demo 1: Rogue Validator / Unauthorized Mint', category: 'SECURITY_ATTACK' },
    { key: 'DOUBLE_SPEND_PREVENTION', name: 'Attack Demo 2: Attempted Double Spend / Replay Attack', category: 'SECURITY_ATTACK' },
    { key: 'VALIDATOR_SLASHING_EQUIVOCATION', name: 'Attack Demo 3: Validator Double Proposal & Slashing', category: 'CONSENSUS_CHAOS' },
  ];

  const handleRun = (key: string) => {
    setActiveScenario(key);
    const result = onRunScenario(key);
    setSimResult(result);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner Header */}
      <div className="bg-[#080809] border border-[#27272A] p-6">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-[#F59E0B]" />
            MONETARY SIMULATOR & CHAOS / SECURITY FAILURE LAB
          </h2>
          <span className="text-[10px] font-mono text-[#10B981] font-bold uppercase tracking-widest bg-[#10B981]/10 px-3 py-1 border border-[#10B981]/40">
            ISOLATED SIMULATION NETWORK
          </span>
        </div>
        <p className="text-xs text-[#71717A] font-mono mt-1">
          Test economic stress, bank run liquidity contractions, and adversarial attack scenarios. Verify security domain separation (`CONSENSUS AUTHORITY ≠ MONETARY ISSUANCE AUTHORITY`).
        </p>
      </div>

      {/* Main Grid: Scenario Selector Buttons & Live Step Log Console */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Scenario Selectors List */}
        <div className="bg-[#080809] border border-[#27272A] p-6 space-y-3">
          <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2] mb-4">SELECT SIMULATION SCENARIO</h3>

          <div className="space-y-2.5 font-mono text-xs">
            {scenariosList.map((sc) => (
              <button
                key={sc.key}
                onClick={() => handleRun(sc.key)}
                className={`w-full text-left p-3.5 border cursor-pointer transition-all flex justify-between items-center ${
                  activeScenario === sc.key
                    ? 'bg-[#F2F2F2] text-black border-[#F2F2F2] font-extrabold'
                    : 'bg-[#050505] hover:bg-[#121214] border-[#27272A] text-[#D4D4D8]'
                }`}
              >
                <div>
                  <div className="font-bold">{sc.name}</div>
                  <div className={`text-[9px] uppercase tracking-wider mt-1 ${activeScenario === sc.key ? 'text-black/70' : 'text-[#71717A]'}`}>{sc.category}</div>
                </div>
                <Play className={`w-4 h-4 shrink-0 ${activeScenario === sc.key ? 'text-black' : 'text-[#F2F2F2]'}`} />
              </button>
            ))}
          </div>
        </div>

        {/* Live Simulation Execution Terminal Output */}
        <div className="bg-[#080809] border border-[#27272A] p-6 lg:col-span-2 space-y-4">
          <div className="flex justify-between items-center border-b border-[#27272A] pb-4">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-[#F2F2F2]" />
              <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-extrabold text-[#F2F2F2]">SIMULATION EXECUTION LOG</h3>
            </div>
            {simResult && (
              <span className={`px-3 py-1 text-[10px] font-mono font-extrabold uppercase tracking-widest border ${
                simResult.passed ? 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/40' : 'bg-[#EF4444]/10 text-[#EF4444] border-[#EF4444]/40'
              }`}>
                {simResult.final_outcome}
              </span>
            )}
          </div>

          {simResult ? (
            <div className="space-y-4 font-mono text-xs">
              <div>
                <h4 className="font-extrabold text-[#F2F2F2] text-sm uppercase tracking-wider">{simResult.name}</h4>
                <p className="text-[#71717A] text-xs mt-1">{simResult.description}</p>
              </div>

              {/* Step-by-Step Execution Log List */}
              <div className="space-y-3 pt-2">
                {simResult.steps.map((stg, idx) => (
                  <div key={idx} className="p-4 bg-[#050505] border border-[#27272A] space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-extrabold text-[#F2F2F2]">{stg.title}</span>
                      <span className={`px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-widest border ${
                        stg.status === 'SUCCESS' ? 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/40' :
                        stg.status === 'REJECTED_AS_EXPECTED' ? 'bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/40' :
                        'bg-[#EF4444]/10 text-[#EF4444] border-[#EF4444]/40'
                      }`}>
                        {stg.status}
                      </span>
                    </div>
                    <div className="text-[11px] text-[#A1A1AA] bg-[#080809] p-3 border border-[#27272A]">
                      {stg.log}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-[#71717A] font-mono text-xs bg-[#050505] border border-[#27272A]">
              Click any simulation scenario on the left to execute the live causal test.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
