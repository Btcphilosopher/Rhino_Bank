import React from 'react';
import { ShieldCheck, CheckCircle2, AlertTriangle, ArrowUpRight, Cpu, Coins, Lock, Database } from 'lucide-react';
import { IssuedCoin, ReserveCoverage, FormalInvariants, Block } from '../types/rhino';

interface DashboardProps {
  coins: IssuedCoin[];
  coverage: ReserveCoverage;
  invariants: FormalInvariants;
  blocks: Block[];
  pendingIssuanceCount: number;
  pendingRedemptionCount: number;
  onNavigate: (tab: string) => void;
}

export const MonetaryStateDashboard: React.FC<DashboardProps> = ({
  coins,
  coverage,
  invariants,
  blocks,
  pendingIssuanceCount,
  pendingRedemptionCount,
  onNavigate
}) => {
  const rgbp = coins.find(c => c.coin_id === 'RGBP') || coins[0];
  const rusd = coins.find(c => c.coin_id === 'RUSD');
  const reur = coins.find(c => c.coin_id === 'REUR');

  return (
    <div className="space-y-6">
      {/* Top Banner KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Issued Money Supply */}
        <div className="bg-[#080809] p-5 border border-[#27272A] shadow-none">
          <div className="flex justify-between items-start">
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#71717A]">TOTAL ISSUED COINS</span>
            <Coins className="w-4 h-4 text-[#F2F2F2]" />
          </div>
          <div className="mt-3 text-3xl font-extrabold tracking-tighter text-[#F2F2F2]">
            £{(rgbp?.supply || 0).toLocaleString()}
          </div>
          <div className="mt-2 text-xs font-mono text-[#A1A1AA] flex items-center justify-between">
            <span>RGBP Circulating: £{(rgbp?.circulating_supply || 0).toLocaleString()}</span>
            <span className="text-[#10B981] font-bold">1:1 PAR</span>
          </div>
          <div className="mt-3 pt-2 border-t border-[#27272A] flex justify-between text-[11px] font-mono text-[#71717A]">
            <span>$USD: ${(rusd?.supply || 0).toLocaleString()}</span>
            <span>€EUR: €{(reur?.supply || 0).toLocaleString()}</span>
          </div>
        </div>

        {/* Card 2: Reserve Backing Assets */}
        <div className="bg-[#080809] p-5 border border-[#27272A] shadow-none">
          <div className="flex justify-between items-start">
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#71717A]">GROSS RESERVES (CUSTODY)</span>
            <Database className="w-4 h-4 text-[#10B981]" />
          </div>
          <div className="mt-3 text-3xl font-extrabold tracking-tighter text-[#F2F2F2]">
            £{coverage.gross_reserves.toLocaleString()}
          </div>
          <div className="mt-2 text-xs font-mono text-[#A1A1AA] flex items-center justify-between">
            <span>Eligible Post-Haircut:</span>
            <span className="text-[#10B981] font-bold">£{coverage.eligible_reserves.toLocaleString()}</span>
          </div>
          <div className="mt-3 pt-2 border-t border-[#27272A] flex justify-between text-[11px] font-mono text-[#71717A]">
            <span>BoE Cash: £50.0M</span>
            <span>UK Gilts: £35.0M</span>
          </div>
        </div>

        {/* Card 3: Reserve Coverage Ratio */}
        <div className="bg-[#080809] p-5 border border-[#27272A] shadow-none">
          <div className="flex justify-between items-start">
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#71717A]">COVERAGE RATIO</span>
            <ShieldCheck className="w-4 h-4 text-[#10B981]" />
          </div>
          <div className="mt-3 text-3xl font-extrabold tracking-tighter text-[#10B981] flex items-baseline gap-2">
            <span>{(coverage.coverage_ratio * 100).toFixed(1)}%</span>
            <span className="text-xs text-[#71717A] font-mono font-normal">MIN: 100%</span>
          </div>
          <div className="mt-2 text-xs font-mono text-[#A1A1AA] flex items-center justify-between">
            <span>Excess Buffer:</span>
            <span className="text-[#10B981] font-bold">+£{coverage.excess_reserve.toLocaleString()}</span>
          </div>
          <div className="mt-3 pt-2 border-t border-[#27272A] flex justify-between text-[11px] font-mono text-[#71717A]">
            <span>SOLVENCY STATUS:</span>
            <span className="text-[#10B981] font-bold">OVER-COLLATERALIZED</span>
          </div>
        </div>

        {/* Card 4: Action / Queue Status */}
        <div className="bg-[#080809] p-5 border border-[#27272A] shadow-none">
          <div className="flex justify-between items-start">
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#71717A]">MONETARY CONTROL QUEUES</span>
            <Lock className="w-4 h-4 text-[#F59E0B]" />
          </div>
          <div className="mt-3 text-xl font-bold font-mono text-[#F2F2F2] flex gap-2">
            <button 
              onClick={() => onNavigate('issuance')}
              className="bg-[#050505] hover:bg-[#18181B] p-2.5 text-left flex-1 border border-[#3F3F46] hover:border-[#F2F2F2] transition-colors cursor-pointer"
            >
              <div className="text-[9px] font-mono uppercase tracking-widest text-[#71717A]">MINT REQUESTS</div>
              <div className="text-base font-bold text-[#F2F2F2] mt-0.5">{pendingIssuanceCount} Pending</div>
            </button>
            <button 
              onClick={() => onNavigate('redemption')}
              className="bg-[#050505] hover:bg-[#18181B] p-2.5 text-left flex-1 border border-[#3F3F46] hover:border-[#F2F2F2] transition-colors cursor-pointer"
            >
              <div className="text-[9px] font-mono uppercase tracking-widest text-[#71717A]">REDEMPTIONS</div>
              <div className="text-base font-bold text-[#F59E0B] mt-0.5">{pendingRedemptionCount} Pending</div>
            </button>
          </div>
          <div className="mt-3 pt-2 border-t border-[#27272A] flex justify-between text-[11px] font-mono text-[#71717A]">
            <span>MULTI-SIG RULE:</span>
            <span className="text-[#F2F2F2] font-bold">2-OF-3 OFFICERS</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Formal Invariants & Solvency Visualizer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Formal Invariants Verification Panel */}
        <div className="bg-[#080809] border border-[#27272A] p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-bold text-[#F2F2F2] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#10B981]" />
              FORMAL INVARIANTS
            </h3>
            <span className="text-[10px] font-mono uppercase tracking-widest text-[#71717A]">EVERY BLOCK</span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between p-3 bg-[#050505] border-l-2 border-[#10B981]">
              <div>
                <div className="text-[#F2F2F2] font-bold">Σ Balances == Issued Supply</div>
                <div className="text-[10px] text-[#71717A] mt-0.5">Sum of ledger balances equals circulating supply</div>
              </div>
              <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
            </div>

            <div className="flex items-center justify-between p-3 bg-[#050505] border-l-2 border-[#10B981]">
              <div>
                <div className="text-[#F2F2F2] font-bold">Total Debits == Total Credits</div>
                <div className="text-[10px] text-[#71717A] mt-0.5">Double-entry journal strictly balanced</div>
              </div>
              <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
            </div>

            <div className="flex items-center justify-between p-3 bg-[#050505] border-l-2 border-[#10B981]">
              <div>
                <div className="text-[#F2F2F2] font-bold">Eligible Reserves &gt;= Liabilities</div>
                <div className="text-[10px] text-[#71717A] mt-0.5">100%+ collateralized backing verified</div>
              </div>
              <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
            </div>

            <div className="flex items-center justify-between p-3 bg-[#050505] border-l-2 border-[#10B981]">
              <div>
                <div className="text-[#F2F2F2] font-bold">No Negative Balances</div>
                <div className="text-[10px] text-[#71717A] mt-0.5">Non-negative account balances enforced</div>
              </div>
              <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
            </div>

            <div className="flex items-center justify-between p-3 bg-[#050505] border-l-2 border-[#10B981]">
              <div>
                <div className="text-[#F2F2F2] font-bold">Domain Separation</div>
                <div className="text-[10px] text-[#71717A] mt-0.5">Consensus cannot manufacture money</div>
              </div>
              <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
            </div>
          </div>
        </div>

        {/* Reserve vs Liability Solvency Bar Visualizer */}
        <div className="bg-[#080809] border border-[#27272A] p-6 lg:col-span-2">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="font-mono text-xs uppercase tracking-[0.25em] font-bold text-[#F2F2F2]">RESERVE BACKING vs COIN LIABILITIES</h3>
              <p className="text-xs text-[#71717A] font-mono mt-1">Central reserve custody breakdown vs issued RGBP liability</p>
            </div>
            <button 
              onClick={() => onNavigate('reserves')}
              className="text-xs font-mono font-bold uppercase tracking-widest text-[#F2F2F2] hover:text-[#10B981] flex items-center gap-1 cursor-pointer transition-colors"
            >
              <span>Manage Reserves</span>
              <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>

          {/* Solvency Progress Bars */}
          <div className="space-y-5 font-mono text-xs">
            <div>
              <div className="flex justify-between mb-1 text-[#D4D4D8]">
                <span className="text-[#71717A] uppercase text-[10px] tracking-wider">Issued Coin Liabilities (RGBP + RUSD + REUR):</span>
                <span className="font-bold text-[#F2F2F2]">£{coverage.total_coin_liability.toLocaleString()}</span>
              </div>
              <div className="w-full bg-[#050505] h-5 border border-[#27272A] flex p-[1px]">
                <div className="bg-[#D4D4D8] h-full" style={{ width: '35%' }} title="RGBP Supply £25M"></div>
                <div className="bg-[#A1A1AA] h-full" style={{ width: '22%' }} title="RUSD Supply $15M"></div>
                <div className="bg-[#71717A] h-full" style={{ width: '15%' }} title="REUR Supply €10M"></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1 text-[#D4D4D8]">
                <span className="text-[#71717A] uppercase text-[10px] tracking-wider">Unencumbered Eligible Reserves (BoE + Gilts + Vault):</span>
                <span className="font-bold text-[#10B981]">£{coverage.eligible_reserves.toLocaleString()}</span>
              </div>
              <div className="w-full bg-[#050505] h-5 border border-[#27272A] flex p-[1px]">
                <div className="bg-[#10B981] h-full" style={{ width: '45%' }} title="BoE Central Cash £50M"></div>
                <div className="bg-[#059669] h-full" style={{ width: '31%' }} title="UK Short Gilts £34.65M"></div>
                <div className="bg-[#047857] h-full" style={{ width: '15%' }} title="US Fed Cash Deposit £15.38M"></div>
                <div className="bg-[#F59E0B] h-full" style={{ width: '9%' }} title="Gold Vault £11.4M"></div>
              </div>
            </div>

            <div className="p-4 bg-[#050505] border border-[#27272A] grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <div className="text-[10px] font-mono uppercase tracking-widest text-[#71717A]">COVERAGE RATIO</div>
                <div className="text-xl font-extrabold text-[#10B981] mt-0.5">{(coverage.coverage_ratio * 100).toFixed(1)}%</div>
              </div>
              <div>
                <div className="text-[10px] font-mono uppercase tracking-widest text-[#71717A]">EXCESS COVERAGE</div>
                <div className="text-xl font-extrabold text-[#F2F2F2] mt-0.5">+£{coverage.excess_reserve.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-[10px] font-mono uppercase tracking-widest text-[#71717A]">MAX MINT CAPACITY</div>
                <div className="text-xl font-extrabold text-[#F2F2F2] mt-0.5">£{coverage.excess_reserve.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-[10px] font-mono uppercase tracking-widest text-[#71717A]">SOLVENCY BUFFER</div>
                <div className="text-xl font-extrabold text-[#10B981] mt-0.5">SAFE (100%+)</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Blocks Feed */}
      <div className="bg-[#080809] border border-[#27272A] p-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="text-xs font-mono uppercase tracking-[0.25em] font-bold text-[#F2F2F2] flex items-center gap-2">
              <Cpu className="w-4 h-4 text-[#F2F2F2]" />
              RECENT PROOF-OF-STAKE BLOCKS & SETTLEMENT
            </h3>
            <p className="text-xs text-[#71717A] font-mono mt-1">Canonical block stream finalized by 21 BLS validator attestations</p>
          </div>
          <button 
            onClick={() => onNavigate('explorer')}
            className="text-xs font-mono font-bold uppercase tracking-widest text-[#F2F2F2] hover:text-[#10B981] flex items-center gap-1 cursor-pointer transition-colors"
          >
            <span>Open Explorer Thread</span>
            <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-[#27272A] text-[#71717A] bg-[#050505]">
                <th className="py-3 px-4 font-mono text-[10px] uppercase tracking-widest">HEIGHT / SLOT</th>
                <th className="py-3 px-4 font-mono text-[10px] uppercase tracking-widest">BLOCK HASH</th>
                <th className="py-3 px-4 font-mono text-[10px] uppercase tracking-widest">PROPOSER VALIDATOR</th>
                <th className="py-3 px-4 font-mono text-[10px] uppercase tracking-widest">TX COUNT</th>
                <th className="py-3 px-4 font-mono text-[10px] uppercase tracking-widest">ATTESTATIONS</th>
                <th className="py-3 px-4 font-mono text-[10px] uppercase tracking-widest">FINALITY STATE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#27272A]">
              {blocks.slice(0, 5).map((block) => (
                <tr key={block.hash} className="hover:bg-[#0F0F12] transition-colors">
                  <td className="py-3 px-4 font-bold text-[#F2F2F2]">
                    #{block.height} <span className="text-[#71717A] font-normal">/ Slot {block.slot}</span>
                  </td>
                  <td className="py-3 px-4 text-[#A1A1AA] font-mono">
                    {block.hash.substring(0, 12)}...{block.hash.substring(block.hash.length - 6)}
                  </td>
                  <td className="py-3 px-4 text-[#D4D4D8]">
                    <span className="text-[#F2F2F2] font-semibold">{block.proposer_id}</span>
                  </td>
                  <td className="py-3 px-4 text-[#A1A1AA]">
                    {block.transactions.length} txs
                  </td>
                  <td className="py-3 px-4 text-[#10B981] font-bold">
                    {block.attestations.length} / 21 Signatures
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 text-[10px] font-bold font-mono uppercase bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/40">
                      {block.finality_state}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
