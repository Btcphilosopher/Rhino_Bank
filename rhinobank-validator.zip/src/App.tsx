import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { MonetaryStateDashboard } from './components/MonetaryStateDashboard';
import { IssuanceControlRoom } from './components/IssuanceControlRoom';
import { ReserveControlRoom } from './components/ReserveControlRoom';
import { ValidatorControlRoom } from './components/ValidatorControlRoom';
import { DigitalThreadExplorer } from './components/DigitalThreadExplorer';
import { DoubleEntryAccountingRoom } from './components/DoubleEntryAccountingRoom';
import { RedemptionTreasuryRoom } from './components/RedemptionTreasuryRoom';
import { GovernanceEmergencyRoom } from './components/GovernanceEmergencyRoom';
import { MonetarySimulatorRoom } from './components/MonetarySimulatorRoom';

import { rhinoEngine } from './engine/rhinoEngine';
import {
  IssuedCoin,
  ReserveCoverage,
  FormalInvariants,
  IssuanceRequest,
  RedemptionRequest,
  LedgerAccount,
  ReserveAsset,
  Validator,
  Block,
  JournalEntry,
  MonetaryPolicy,
  AuditEvent,
  SlashingEvent
} from './types/rhino';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Local state mirrored from engine / API
  const [coins, setCoins] = useState<IssuedCoin[]>([]);
  const [coverage, setCoverage] = useState<ReserveCoverage>(rhinoEngine.getReserveCoverage());
  const [invariants, setInvariants] = useState<FormalInvariants>(rhinoEngine.checkInvariants());
  const [currentSlot, setCurrentSlot] = useState<number>(10420);
  const [currentEpoch, setCurrentEpoch] = useState<number>(325);
  const [currentBlockHeight, setCurrentBlockHeight] = useState<number>(10420);
  const [issuanceRequests, setIssuanceRequests] = useState<IssuanceRequest[]>([]);
  const [redemptionRequests, setRedemptionRequests] = useState<RedemptionRequest[]>([]);
  const [accounts, setAccounts] = useState<LedgerAccount[]>([]);
  const [reserves, setReserves] = useState<ReserveAsset[]>([]);
  const [validators, setValidators] = useState<Validator[]>([]);
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [journals, setJournals] = useState<JournalEntry[]>([]);
  const [policy, setPolicy] = useState<MonetaryPolicy>(rhinoEngine.getPolicy());
  const [auditTrail, setAuditTrail] = useState<AuditEvent[]>([]);
  const [slashingEvents, setSlashingEvents] = useState<SlashingEvent[]>([]);

  // Refresh local React view from engine
  const refreshState = () => {
    const st = rhinoEngine.getMonetaryState();
    setCoins(st.coins);
    setCoverage(st.reserveCoverage);
    setInvariants(st.invariants);
    setCurrentSlot(st.currentSlot);
    setCurrentEpoch(st.currentEpoch);
    setCurrentBlockHeight(st.currentBlockHeight);
    setIssuanceRequests(rhinoEngine.getIssuanceRequests());
    setRedemptionRequests(rhinoEngine.getRedemptionRequests());
    setAccounts(rhinoEngine.getAccounts());
    setReserves(rhinoEngine.getReserves());
    setValidators(rhinoEngine.getValidators());
    setBlocks(rhinoEngine.getBlocks());
    setJournals(rhinoEngine.getJournals());
    setPolicy(rhinoEngine.getPolicy());
    setAuditTrail(rhinoEngine.getAuditTrail());
    setSlashingEvents(rhinoEngine.getSlashingEvents());
  };

  useEffect(() => {
    refreshState();
  }, []);

  // Handlers
  const handleTickBlock = () => {
    rhinoEngine.produceBlockWithTransactions([]);
    refreshState();
  };

  const handleSubmitIssuance = (
    coinId: string,
    amount: number,
    beneficiary: string,
    reserveRef: string,
    officer: string,
    reason: string
  ) => {
    rhinoEngine.submitIssuanceRequest(coinId, amount, beneficiary, reserveRef, officer, reason);
    refreshState();
  };

  const handleApproveIssuance = (requestId: string, signerOfficerId: string) => {
    rhinoEngine.approveIssuanceRequest(requestId, signerOfficerId);
    refreshState();
  };

  const handleSubmitRedemption = (
    coinId: string,
    amount: number,
    requester: string,
    bankAccount: string,
    reserveId: string
  ) => {
    rhinoEngine.submitRedemptionRequest(coinId, amount, requester, bankAccount, reserveId);
    refreshState();
  };

  const handleTransfer = (senderId: string, recipientId: string, coinId: string, amount: number) => {
    rhinoEngine.executeTransfer(senderId, recipientId, coinId, amount);
    refreshState();
  };

  const handleUpdatePolicy = (partial: Partial<MonetaryPolicy>, operator: string) => {
    rhinoEngine.updatePolicy(partial, operator);
    refreshState();
  };

  const handleRunScenario = (key: string) => {
    const res = rhinoEngine.runScenario(key);
    refreshState();
    return res;
  };

  const handleGetTrace = (txId: string) => {
    return rhinoEngine.getDigitalThreadTrace(txId);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#D4D4D8] font-sans antialiased selection:bg-[#10B981] selection:text-black">
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentSlot={currentSlot}
        currentEpoch={currentEpoch}
        currentBlockHeight={currentBlockHeight}
        coverage={coverage}
        invariants={invariants}
        emergencyPaused={policy.emergency_issuance_paused || policy.emergency_redemption_paused}
        onTickBlock={handleTickBlock}
      />

      <main className="max-w-7xl mx-auto px-4 py-6">
        {activeTab === 'dashboard' && (
          <MonetaryStateDashboard
            coins={coins}
            coverage={coverage}
            invariants={invariants}
            blocks={blocks}
            pendingIssuanceCount={issuanceRequests.filter(r => r.status === 'PENDING').length}
            pendingRedemptionCount={redemptionRequests.filter(r => r.status === 'PENDING').length}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'issuance' && (
          <IssuanceControlRoom
            issuanceRequests={issuanceRequests}
            coverage={coverage}
            accounts={accounts}
            coins={coins}
            onSubmitRequest={handleSubmitIssuance}
            onApproveRequest={handleApproveIssuance}
          />
        )}

        {activeTab === 'reserves' && (
          <ReserveControlRoom
            reserves={reserves}
            coverage={coverage}
          />
        )}

        {activeTab === 'validators' && (
          <ValidatorControlRoom
            validators={validators}
            slashingEvents={slashingEvents}
            currentSlot={currentSlot}
            currentEpoch={currentEpoch}
          />
        )}

        {activeTab === 'explorer' && (
          <DigitalThreadExplorer
            blocks={blocks}
            onGetTrace={handleGetTrace}
          />
        )}

        {activeTab === 'accounting' && (
          <DoubleEntryAccountingRoom
            journals={journals}
            accounts={accounts}
            onTransfer={handleTransfer}
          />
        )}

        {activeTab === 'redemption' && (
          <RedemptionTreasuryRoom
            redemptions={redemptionRequests}
            accounts={accounts}
            reserves={reserves}
            onSubmitRedemption={handleSubmitRedemption}
          />
        )}

        {activeTab === 'governance' && (
          <GovernanceEmergencyRoom
            policy={policy}
            auditTrail={auditTrail}
            onUpdatePolicy={handleUpdatePolicy}
          />
        )}

        {activeTab === 'simulator' && (
          <MonetarySimulatorRoom
            onRunScenario={handleRunScenario}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#27272A] bg-[#050505] py-6 text-center font-mono text-xs text-[#71717A]">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-2">
          <div>
            <span className="text-[#F2F2F2] font-extrabold uppercase tracking-widest">RHINOBANK.VALIDATOR</span> · Sovereign Proof-of-Stake Digital Monetary Infrastructure
          </div>
          <div className="text-[11px] uppercase tracking-wider">
            Domain Boundary: <span className="text-[#10B981] font-bold">CONSENSUS AUTHORITY ≠ MONETARY ISSUANCE AUTHORITY</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
