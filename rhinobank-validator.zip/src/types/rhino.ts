export type CoinStatus = 'ACTIVE' | 'PAUSED' | 'RESTRICTED';

export interface IssuedCoin {
  coin_id: string; // e.g. "RGBP"
  symbol: string;
  name: string;
  issuer: string;
  currency_code: string;
  decimals: number;
  supply: number; // Total minted - burned
  circulating_supply: number;
  treasury_supply: number;
  burned_supply: number;
  reserve_requirement: number; // e.g. 1.0 (100%) or 1.05 (105%)
  issuance_policy: string;
  redemption_policy: string;
  status: CoinStatus;
  creation_timestamp: number;
  revision: number;
  monetary_policy_version: number;
}

export type ReserveAssetType = 
  | 'CASH_DEPOSIT' 
  | 'CENTRAL_BANK_RESERVE' 
  | 'SHORT_TERM_TREASURY' 
  | 'GOLD_RESERVE' 
  | 'ELIGIBLE_COLLATERAL';

export type EncumbranceStatus = 'UNENCUMBERED' | 'PLEDGED' | 'RESTRICTED';

export interface ReserveAsset {
  asset_id: string;
  name: string;
  type: ReserveAssetType;
  quantity: number;
  valuation: number; // In GBP base value
  currency: string;
  custodian: string;
  valuation_timestamp: number;
  eligibility: boolean;
  haircut: number; // Percentage, e.g. 0.02 = 2%
  encumbrance_status: EncumbranceStatus;
}

export type CoverageAlertLevel = 'NORMAL' | 'WATCH' | 'BREACH' | 'CRITICAL';

export interface ReserveCoverage {
  gross_reserves: number;
  eligible_reserves: number;
  encumbered_reserves: number;
  net_reserves: number;
  total_coin_liability: number;
  reserve_ratio: number; // Net reserves / total liabilities
  coverage_ratio: number; // Eligible reserves / liabilities
  excess_reserve: number;
  reserve_deficit: number;
  alert_level: CoverageAlertLevel;
}

export interface JournalPosting {
  account_id: string;
  account_name: string;
  debit: number;
  credit: number;
}

export interface JournalEntry {
  entry_id: string;
  transaction_id: string;
  timestamp: number;
  coin_id: string;
  description: string;
  postings: JournalPosting[];
  total_debits: number;
  total_credits: number;
  balanced: boolean;
}

export type AccountType = 
  | 'CUSTOMER' 
  | 'INSTITUTIONAL' 
  | 'TREASURY' 
  | 'RESERVE_CUSTODY' 
  | 'SETTLEMENT' 
  | 'VALIDATOR_STAKE' 
  | 'FEE_POOL';

export interface LedgerAccount {
  account_id: string;
  owner_name: string;
  type: AccountType;
  balances: Record<string, number>; // coin_id -> balance
  status: 'ACTIVE' | 'FROZEN' | 'RESTRICTED';
  nonce: number;
  created_at: number;
}

export type IssuanceRequestStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'MINTED' | 'EXPIRED';

export interface IssuanceRequest {
  request_id: string;
  coin_id: string;
  amount: number;
  beneficiary_account: string;
  reserve_reference: string;
  authorising_party: string;
  reason: string;
  timestamp: number;
  expiry: number;
  policy_version: number;
  required_approvals: number;
  approvals: string[]; // List of authority public keys/names
  status: IssuanceRequestStatus;
  rejection_reason?: string;
  mint_tx_hash?: string;
}

export type RedemptionStatus = 'PENDING' | 'APPROVED' | 'BURNED' | 'SETTLED' | 'REJECTED';

export interface RedemptionRequest {
  request_id: string;
  coin_id: string;
  amount: number;
  requester_account: string;
  settlement_bank_account: string;
  reserve_asset_id: string;
  approved_amount: number;
  burn_amount: number;
  fee: number;
  timestamp: number;
  status: RedemptionStatus;
  burn_tx_hash?: string;
  rejection_reason?: string;
}

export type ValidatorStatus = 
  | 'REGISTERED' 
  | 'PENDING' 
  | 'ACTIVE' 
  | 'VALIDATING' 
  | 'EXIT_REQUEST' 
  | 'EXITING' 
  | 'WITHDRAWABLE';

export interface Validator {
  validator_id: string;
  name: string;
  public_key: string;
  consensus_key: string;
  withdrawal_key: string;
  stake: number; // Staking tokens (RSTAKE)
  status: ValidatorStatus;
  activation_epoch: number;
  exit_epoch?: number;
  commission: number; // e.g. 0.05 = 5%
  uptime: number; // e.g. 99.8%
  proposed_blocks: number;
  missed_attestations: number;
  slashed: boolean;
}

export type FinalityState = 'PROPOSED' | 'ATTESTED' | 'JUSTIFIED' | 'FINAL';

export type TransactionType = 
  | 'TRANSFER' 
  | 'MINT' 
  | 'BURN' 
  | 'REDEEM' 
  | 'STAKE' 
  | 'UNSTAKE' 
  | 'VALIDATOR_REGISTER' 
  | 'VALIDATOR_EXIT' 
  | 'FEE_PAYMENT' 
  | 'GOVERNANCE'
  | 'EMERGENCY_ACTION';

export interface Transaction {
  transaction_id: string;
  type: TransactionType;
  sender: string;
  recipient: string;
  coin_id: string;
  amount: number;
  nonce: number;
  fee: number;
  timestamp: number;
  payload?: any;
  signature: string;
  status: 'CONFIRMED' | 'REJECTED';
  rejection_reason?: string;
  block_height?: number;
}

export interface Attestation {
  attestation_id: string;
  block_hash: string;
  slot: number;
  validator_id: string;
  signature: string;
  timestamp: number;
}

export interface Block {
  height: number;
  slot: number;
  epoch: number;
  hash: string;
  parent_hash: string;
  state_root: string;
  transaction_root: string;
  receipt_root: string;
  proposer_id: string;
  timestamp: number;
  transactions: Transaction[];
  attestations: Attestation[];
  protocol_version: string;
  finality_state: FinalityState;
}

export interface SlashingEvent {
  slashing_id: string;
  validator_id: string;
  validator_name: string;
  evidence: string;
  block_height: number;
  slot: number;
  penalty_amount: number;
  timestamp: number;
}

export interface MonetaryPolicy {
  policy_id: string;
  version: number;
  max_daily_issuance: Record<string, number>;
  min_reserve_ratio: number; // e.g., 1.0 (100%)
  per_tx_limit: Record<string, number>;
  multi_sig_threshold: { required: number; total: number };
  emergency_issuance_paused: boolean;
  emergency_redemption_paused: boolean;
  emergency_transfers_paused: boolean;
  frozen_accounts: string[];
  frozen_coins: string[];
  last_updated: number;
  updated_by: string;
}

export interface AuditEvent {
  event_id: string;
  event_type: string;
  actor: string;
  details: Record<string, any>;
  timestamp: number;
  hash: string;
}

export interface ReconciliationReport {
  report_id: string;
  timestamp: number;
  matched: boolean;
  total_eligible_reserves: number;
  total_coin_liabilities: number;
  net_coverage_percentage: number;
  sum_account_balances: number;
  outstanding_supply: number;
  supply_reconciled: boolean;
  accounting_balanced: boolean;
  discrepancies: string[];
  audit_notes: string[];
}

export interface FormalInvariants {
  supply_matches_balances: boolean;
  total_debits_equals_credits: boolean;
  reserves_cover_liabilities: boolean;
  no_negative_balances: boolean;
  nonces_sequential: boolean;
  consensus_separated_from_minting: boolean;
  last_checked_timestamp: number;
}

export interface DigitalThreadTrace {
  coin_id: string;
  amount: number;
  issuance_request?: IssuanceRequest;
  reserve_assets_backed: ReserveAsset[];
  policy_check_result: { approved: boolean; reason: string; version: number };
  authorisations: string[];
  mint_transaction?: Transaction;
  block?: Block;
  attesting_validators: Validator[];
  finality_status: FinalityState;
  beneficiary_account?: LedgerAccount;
  journal_entry?: JournalEntry;
}

export interface SimulationScenarioResult {
  scenario_id: string;
  name: string;
  description: string;
  steps: {
    title: string;
    action: string;
    status: 'SUCCESS' | 'REJECTED_AS_EXPECTED' | 'POLICY_BLOCKED' | 'FAILED';
    log: string;
    details?: any;
  }[];
  final_outcome: string;
  passed: boolean;
}
