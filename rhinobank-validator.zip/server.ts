import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { rhinoEngine } from "./src/engine/rhinoEngine";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // -------------------------------------------------------------
  // REST API ENDPOINTS FOR RHINOBANK.VALIDATOR
  // -------------------------------------------------------------

  // 1. Monetary State & Health
  app.get("/api/monetary-state", (req, res) => {
    try {
      const state = rhinoEngine.getMonetaryState();
      res.json({ status: "ok", data: state });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 2. Accounts & Balances
  app.get("/api/accounts", (req, res) => {
    res.json({ accounts: rhinoEngine.getAccounts() });
  });

  // 3. Reserves & Coverage
  app.get("/api/reserves", (req, res) => {
    res.json({
      reserves: rhinoEngine.getReserves(),
      coverage: rhinoEngine.getReserveCoverage()
    });
  });

  // 4. Issuance Requests & Multi-Sig Approval
  app.get("/api/issuance/requests", (req, res) => {
    res.json({ requests: rhinoEngine.getIssuanceRequests() });
  });

  app.post("/api/issuance/request", (req, res) => {
    const { coinId, amount, beneficiaryAccount, reserveReference, authorisingOfficer, reason } = req.body;
    const result = rhinoEngine.submitIssuanceRequest(
      coinId || 'RGBP',
      Number(amount) || 1000000,
      beneficiaryAccount || 'ACC_BARCLAYS_INST',
      reserveReference || 'RES_BOE_CASH',
      authorisingOfficer || 'AUTH_OFFICER_1',
      reason || 'Institutional Issuance Request'
    );
    res.json(result);
  });

  app.post("/api/issuance/approve", (req, res) => {
    const { requestId, signerOfficerId } = req.body;
    const result = rhinoEngine.approveIssuanceRequest(requestId, signerOfficerId);
    res.json(result);
  });

  // 5. Redemption & Burn
  app.get("/api/redemption/requests", (req, res) => {
    res.json({ requests: rhinoEngine.getRedemptionRequests() });
  });

  app.post("/api/redemption/request", (req, res) => {
    const { coinId, amount, requesterAccount, settlementBankAccount, reserveAssetId } = req.body;
    const result = rhinoEngine.submitRedemptionRequest(
      coinId || 'RGBP',
      Number(amount) || 500000,
      requesterAccount || 'ACC_BARCLAYS_INST',
      settlementBankAccount || 'GB99BARC20000012345678',
      reserveAssetId || 'RES_BOE_CASH'
    );
    res.json(result);
  });

  // 6. Interbank Transfer
  app.post("/api/transfer", (req, res) => {
    const { senderId, recipientId, coinId, amount } = req.body;
    const result = rhinoEngine.executeTransfer(
      senderId || 'ACC_BARCLAYS_INST',
      recipientId || 'ACC_HSBC_INST',
      coinId || 'RGBP',
      Number(amount) || 250000
    );
    res.json(result);
  });

  // 7. Proof-of-Stake Validators & Blocks
  app.get("/api/validators", (req, res) => {
    res.json({ validators: rhinoEngine.getValidators() });
  });

  app.get("/api/blocks", (req, res) => {
    res.json({ blocks: rhinoEngine.getBlocks() });
  });

  // 8. Double-Entry Journals & Accounting
  app.get("/api/journals", (req, res) => {
    res.json({ journals: rhinoEngine.getJournals() });
  });

  // 9. Reconciliation & Audit
  app.get("/api/reconciliation", (req, res) => {
    const report = rhinoEngine.triggerReconciliation();
    res.json({ report });
  });

  app.get("/api/audit-trail", (req, res) => {
    res.json({
      auditTrail: rhinoEngine.getAuditTrail(),
      slashingEvents: rhinoEngine.getSlashingEvents()
    });
  });

  // 10. Digital Thread Trace
  app.get("/api/digital-thread/:txId", (req, res) => {
    const trace = rhinoEngine.getDigitalThreadTrace(req.params.txId);
    res.json({ trace });
  });

  // 11. Governance & Policy
  app.get("/api/governance/policy", (req, res) => {
    res.json({ policy: rhinoEngine.getPolicy() });
  });

  app.post("/api/governance/policy", (req, res) => {
    const { policyPartial, operator } = req.body;
    rhinoEngine.updatePolicy(policyPartial || {}, operator || 'GOVERNANCE_BOARD');
    res.json({ success: true, policy: rhinoEngine.getPolicy() });
  });

  // 12. Monetary Simulator & Scenarios
  app.post("/api/simulation/run", (req, res) => {
    const { scenarioKey } = req.body;
    const result = rhinoEngine.runScenario(scenarioKey || 'SCENARIO_A');
    res.json({ result });
  });

  // Advance Slot / Trigger PoS Block Manual Tick
  app.post("/api/consensus/tick", (req, res) => {
    const block = rhinoEngine.produceBlockWithTransactions([]);
    res.json({ success: true, block });
  });

  // -------------------------------------------------------------
  // VITE DEVELOPMENT MIDDLEWARE / PRODUCTION STATIC SERVING
  // -------------------------------------------------------------
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`RhinoBank.Validator running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
