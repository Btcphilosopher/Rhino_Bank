import express from 'express';
import { createServer as createViteServer } from 'vite';
import { createInitialAccountingState, calculateNavMetrics, generateNavWaterfall } from './src/engine/accountingEngine';
import { createInitialMarketState, simulatePriceDiscovery } from './src/engine/marketEngine';
import { calculateRiskMetrics, runStressScenario, runMonteCarloSimulation, FACTOR_EXPOSURES, CORRELATION_MATRIX } from './src/engine/riskAndSim';
import { generateRebalanceProposal, executeBuyback, executeIssuance } from './src/engine/rebalanceAndCapital';
import { evaluateFtseEligibility } from './src/engine/ftseAndListing';
import { generateAccountingStatements, generateAnnualReportSummary } from './src/engine/boardAndReports';

async function startServer() {
  const app = express();
  app.use(express.json());

  // Global simulation state
  let accountingState = createInitialAccountingState();
  const initialNavMetrics = calculateNavMetrics(accountingState).nav_metrics;
  let marketState = createInitialMarketState(accountingState.rhg_share_price_gbp, initialNavMetrics.nav_per_share_gbp);

  // Helper to sync NAV and price
  function getUpdatedState() {
    const { nav_metrics, holdings } = calculateNavMetrics(accountingState);
    const risk_metrics = calculateRiskMetrics(accountingState);
    const ftse = evaluateFtseEligibility(accountingState);
    return { nav_metrics, holdings, risk_metrics, ftse };
  }

  // --- API ENDPOINTS ---

  // 1. Company Endpoints
  app.get('/api/company', (req, res) => {
    const { nav_metrics } = getUpdatedState();
    res.json({
      name: 'RHINO GLOBAL HOLDINGS PLC',
      short_name: 'RHINO GLOBAL',
      ticker: 'RHG',
      security: 'RHG ORDINARY SHARES',
      currency: 'GBP',
      jurisdiction: 'UNITED KINGDOM',
      type: 'PUBLIC INVESTMENT HOLDING COMPANY',
      market_cap_gbp: nav_metrics.rhg_share_price_gbp * accountingState.capital_structure.shares_outstanding,
      nav_gbp: nav_metrics.total_nav_gbp,
      nav_per_share_gbp: nav_metrics.nav_per_share_gbp,
      rhg_share_price_gbp: nav_metrics.rhg_share_price_gbp,
      premium_discount_pct: nav_metrics.premium_discount_pct,
      disclaimer: 'SYNTHETIC INVESTMENT HOLDING COMPANY SIMULATION ENVIRONMENT',
    });
  });

  app.get('/api/company/profile', (req, res) => {
    res.json({
      ticker: 'RHG',
      primary_listing: 'LONDON STOCK EXCHANGE (LSE)',
      sedol: 'B01RHG9',
      isin: 'GB00B01RHG92',
      business_model: 'LONG-TERM GLOBAL EQUITY OWNERSHIP + ACTIVE CAPITAL ALLOCATION + SYNTHETIC GLOBAL EQUITY EXPOSURE',
      established: '1998',
      headquarters: '100 Bishopsgate, London EC2N 4AG, United Kingdom',
    });
  });

  app.get('/api/company/capital', (req, res) => {
    res.json(accountingState.capital_structure);
  });

  app.get('/api/company/financials', (req, res) => {
    const statements = generateAccountingStatements(accountingState);
    res.json(statements);
  });

  // 2. Portfolio Endpoints
  app.get('/api/portfolio', (req, res) => {
    const { nav_metrics, holdings } = getUpdatedState();
    res.json({
      portfolio_market_value_gbp: nav_metrics.portfolio_market_value_gbp,
      cash_gbp: nav_metrics.cash_gbp,
      holdings_count: holdings.length,
      holdings,
    });
  });

  app.get('/api/portfolio/holdings', (req, res) => {
    const { holdings } = getUpdatedState();
    res.json(holdings);
  });

  app.get('/api/portfolio/nav', (req, res) => {
    const { nav_metrics } = getUpdatedState();
    res.json(nav_metrics);
  });

  app.get('/api/portfolio/nav-history', (req, res) => {
    res.json(accountingState.history);
  });

  app.get('/api/portfolio/performance', (req, res) => {
    const { holdings } = getUpdatedState();
    const waterfall = generateNavWaterfall(accountingState, holdings);
    res.json({ waterfall });
  });

  app.get('/api/portfolio/risk', (req, res) => {
    const { risk_metrics } = getUpdatedState();
    res.json(risk_metrics);
  });

  app.get('/api/portfolio/factors', (req, res) => {
    res.json(FACTOR_EXPOSURES);
  });

  app.get('/api/portfolio/correlation', (req, res) => {
    res.json(CORRELATION_MATRIX);
  });

  // 3. Holdings Endpoints
  app.get('/api/holdings', (req, res) => {
    const { holdings } = getUpdatedState();
    res.json(holdings);
  });

  app.get('/api/holdings/:ticker', (req, res) => {
    const ticker = req.params.ticker.toUpperCase();
    const eq = accountingState.equities[ticker];
    if (!eq) return res.status(404).json({ error: 'Holding not found' });
    const { holdings } = getUpdatedState();
    const holding_info = holdings.find((h) => h.ticker === ticker);
    res.json({ equity: eq, holding_info });
  });

  // 4. Synthetic Equities Endpoints
  app.get('/api/synthetic/equities', (req, res) => {
    res.json(Object.values(accountingState.equities));
  });

  app.get('/api/synthetic/equities/:ticker', (req, res) => {
    const ticker = req.params.ticker.toUpperCase();
    const eq = accountingState.equities[ticker];
    if (!eq) return res.status(404).json({ error: 'Synthetic equity not found' });
    res.json(eq);
  });

  app.get('/api/synthetic/equities/:ticker/fundamentals', (req, res) => {
    const ticker = req.params.ticker.toUpperCase();
    const eq = accountingState.equities[ticker];
    if (!eq) return res.status(404).json({ error: 'Synthetic equity not found' });
    res.json({
      revenue: eq.revenue,
      ebitda: eq.ebitda,
      ebit: eq.ebit,
      net_income: eq.net_income,
      eps: eq.eps,
      fcf: eq.fcf,
      dividend_yield: eq.dividend_yield,
      sector_drivers: eq.sector_drivers,
    });
  });

  app.get('/api/synthetic/equities/:ticker/price', (req, res) => {
    const ticker = req.params.ticker.toUpperCase();
    const eq = accountingState.equities[ticker];
    if (!eq) return res.status(404).json({ error: 'Synthetic equity not found' });
    res.json({
      ticker: eq.ticker,
      price_local: eq.price_local,
      price_gbp: eq.price_gbp,
      change_1d_pct: eq.change_1d_pct,
      currency: eq.currency,
    });
  });

  // 5. RHG Quote & Orderbook Endpoints
  app.get('/api/rhg/quote', (req, res) => {
    const { nav_metrics } = getUpdatedState();
    res.json({
      ticker: 'RHG',
      price_gbp: marketState.orderbook.last_price,
      nav_per_share_gbp: nav_metrics.nav_per_share_gbp,
      premium_discount_pct: nav_metrics.premium_discount_pct,
      spread: marketState.orderbook.spread,
      bid: marketState.orderbook.bids[0]?.price ?? marketState.orderbook.last_price - 0.02,
      ask: marketState.orderbook.asks[0]?.price ?? marketState.orderbook.last_price + 0.02,
      volume_24h: marketState.orderbook.volume_24h,
    });
  });

  app.get('/api/rhg/orderbook', (req, res) => {
    res.json(marketState.orderbook);
  });

  app.get('/api/rhg/trades', (req, res) => {
    res.json(marketState.recent_trades);
  });

  app.get('/api/rhg/nav', (req, res) => {
    const { nav_metrics } = getUpdatedState();
    res.json(nav_metrics);
  });

  app.get('/api/rhg/premium-discount', (req, res) => {
    const { nav_metrics } = getUpdatedState();
    res.json({
      rhg_price: marketState.orderbook.last_price,
      nav_per_share: nav_metrics.nav_per_share_gbp,
      premium_discount_pct: nav_metrics.premium_discount_pct,
      status: nav_metrics.premium_discount_pct >= 0 ? 'PREMIUM' : 'DISCOUNT',
    });
  });

  // 6. Action Endpoints
  app.post('/api/orders', (req, res) => {
    const { side, quantity, price, order_type } = req.body;
    const order_qty = Number(quantity || 1000);
    const flow_delta = side === 'BUY' ? order_qty : -order_qty;

    const { nav_metrics } = getUpdatedState();
    const result = simulatePriceDiscovery(marketState, nav_metrics.nav_per_share_gbp, flow_delta);

    marketState = result.updatedMarketState;
    accountingState.rhg_share_price_gbp = result.new_rhg_price;

    res.json({
      success: true,
      executed_price: result.new_rhg_price,
      quantity: order_qty,
      side,
      order_type: order_type || 'MARKET',
      updated_orderbook: marketState.orderbook,
    });
  });

  app.post('/api/rebalance', (req, res) => {
    const { target_weights } = req.body;
    if (target_weights) {
      accountingState.weights = { ...target_weights };
    }
    const proposal = generateRebalanceProposal(accountingState, accountingState.weights);
    res.json(proposal);
  });

  app.post('/api/scenario', (req, res) => {
    const { name } = req.body;
    const scenario_res = runStressScenario(name || 'technology_crash', accountingState);
    res.json(scenario_res);
  });

  app.post('/api/simulation', (req, res) => {
    const { num_simulations, horizon_days } = req.body;
    const mc_res = runMonteCarloSimulation(accountingState, num_simulations || 2000, horizon_days || 252);
    res.json(mc_res);
  });

  app.post('/api/buyback', (req, res) => {
    const { amount_gbp } = req.body;
    const res_buyback = executeBuyback(accountingState, Number(amount_gbp || 25000000));
    accountingState = res_buyback.updatedState;
    res.json(res_buyback);
  });

  app.post('/api/issuance', (req, res) => {
    const { shares_to_issue, price_gbp } = req.body;
    const res_issuance = executeIssuance(
      accountingState,
      Number(shares_to_issue || 10000000),
      Number(price_gbp || accountingState.rhg_share_price_gbp)
    );
    accountingState = res_issuance.updatedState;
    res.json(res_issuance);
  });

  // Mount Vite development server
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Rhino Global Holdings PLC server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
