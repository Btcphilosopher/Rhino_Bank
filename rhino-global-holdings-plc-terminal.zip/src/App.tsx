import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { RhinoRadialGraph } from './components/RhinoRadialGraph';
import { DefiningNavChart } from './components/DefiningNavChart';
import { HoldingsMatrix } from './components/HoldingsMatrix';
import { PerformanceAttribution } from './components/PerformanceAttribution';
import { HoldingDetailModal } from './components/HoldingDetailModal';
import { MarketControlRoom } from './components/MarketControlRoom';
import { CapitalAllocationTerminal } from './components/CapitalAllocationTerminal';
import { RiskAndMonteCarloSuite } from './components/RiskAndMonteCarloSuite';
import { BoardRoomView } from './components/BoardRoomView';
import { FtseListingTerminal } from './components/FtseListingTerminal';
import { SdkTerminal } from './components/SdkTerminal';

import {
  createInitialAccountingState,
  calculateNavMetrics,
  generateNavWaterfall,
} from './engine/accountingEngine';
import {
  createInitialMarketState,
  simulatePriceDiscovery,
} from './engine/marketEngine';
import {
  calculateRiskMetrics,
  runStressScenario,
  runMonteCarloSimulation,
  FACTOR_EXPOSURES,
  CORRELATION_MATRIX,
} from './engine/riskAndSim';
import {
  executeBuyback,
  executeIssuance,
  generateRebalanceProposal,
} from './engine/rebalanceAndCapital';
import { evaluateFtseEligibility } from './engine/ftseAndListing';
import {
  generateAccountingStatements,
  generateAnnualReportSummary,
} from './engine/boardAndReports';
import { SyntheticEquity, PortfolioHolding } from './types/rhino';
import { Zap, Play, RefreshCw, AlertTriangle, ArrowUpRight, ArrowDownRight, Globe } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [selectedHoldingTicker, setSelectedHoldingTicker] = useState<string | null>(null);

  // Accounting and Market Simulation State
  const [accountingState, setAccountingState] = useState(() => createInitialAccountingState());
  const [marketState, setMarketState] = useState(() => {
    const initNav = calculateNavMetrics(createInitialAccountingState()).nav_metrics;
    return createInitialMarketState(12.85, initNav.nav_per_share_gbp);
  });

  const [notification, setNotification] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 4000);
  };

  // Derive live computational metrics
  const { nav_metrics, holdings } = calculateNavMetrics(accountingState);
  const risk_metrics = calculateRiskMetrics(accountingState);
  const ftseReport = evaluateFtseEligibility(accountingState);
  const statements = generateAccountingStatements(accountingState);
  const reportSummary = generateAnnualReportSummary(accountingState);
  const waterfall = generateNavWaterfall(accountingState, holdings);

  // Event 1: NVIDIA +10% Shock Demonstration (Requirement 85)
  const handleNvidiaShock = () => {
    const nvda = accountingState.equities['NVDA'];
    if (!nvda) return;

    const new_local_price = nvda.price_local * 1.10;
    const new_gbp_price = nvda.price_gbp * 1.10;

    const updatedEquities = {
      ...accountingState.equities,
      NVDA: {
        ...nvda,
        price_local: new_local_price,
        price_gbp: new_gbp_price,
        change_1d_pct: nvda.change_1d_pct + 10.0,
      },
    };

    const newAccounting = {
      ...accountingState,
      equities: updatedEquities,
    };

    setAccountingState(newAccounting);

    // Re-run market price discovery
    const newNavPerShare = calculateNavMetrics(newAccounting).nav_metrics.nav_per_share_gbp;
    const marketRes = simulatePriceDiscovery(marketState, newNavPerShare, 150000);
    setMarketState(marketRes.updatedMarketState);
    setAccountingState((prev) => ({ ...prev, rhg_share_price_gbp: marketRes.new_rhg_price }));

    showToast('EVENT EXECUTED: NVIDIA +10.0% -> Corporate NAV & RHG Market Price Updated!');
  };

  // Event 2: Sterling FX +10% Appreciation Shock Demonstration (Requirement 85)
  const handleFxShock = () => {
    const new_usd_gbp = accountingState.fx_rates['USD_GBP'] * 0.90; // Stronger Sterling reduces USD value in GBP
    const new_fx_rates = { ...accountingState.fx_rates, USD_GBP: new_usd_gbp };

    const updatedEquities = { ...accountingState.equities };
    Object.keys(updatedEquities).forEach((t) => {
      const eq = updatedEquities[t];
      if (eq.currency === 'USD') {
        updatedEquities[t] = {
          ...eq,
          price_gbp: eq.price_local * new_usd_gbp,
          fx_change_1d_pct: eq.fx_change_1d_pct - 10.0,
        };
      }
    });

    const newAccounting = {
      ...accountingState,
      fx_rates: new_fx_rates,
      equities: updatedEquities,
    };

    setAccountingState(newAccounting);

    const newNavPerShare = calculateNavMetrics(newAccounting).nav_metrics.nav_per_share_gbp;
    const marketRes = simulatePriceDiscovery(marketState, newNavPerShare, -80000);
    setMarketState(marketRes.updatedMarketState);
    setAccountingState((prev) => ({ ...prev, rhg_share_price_gbp: marketRes.new_rhg_price }));

    showToast('EVENT EXECUTED: GBP +10.0% Appreciation -> Foreign Exchange NAV Adjustment Applied!');
  };

  // Event 3: Tech Sector Crash Demonstration (Requirement 85)
  const handleTechCrashShock = () => {
    const res = runStressScenario('technology_crash', accountingState);
    showToast(`TECH CRASH SHOCK: NAV Impact £${(res.nav_impact_gbp / 1e6).toFixed(1)}m (${res.nav_impact_pct.toFixed(2)}%)`);
  };

  // Update allocation weights
  const handleUpdateWeights = (newWeights: Record<string, number>) => {
    setAccountingState((prev) => ({
      ...prev,
      weights: newWeights,
    }));
    showToast('Target portfolio allocation weights updated!');
  };

  // Place Order
  const handlePlaceOrder = (order: {
    side: 'BUY' | 'SELL';
    quantity: number;
    price?: number;
    order_type: string;
  }) => {
    const flow_delta = order.side === 'BUY' ? order.quantity : -order.quantity;
    const marketRes = simulatePriceDiscovery(marketState, nav_metrics.nav_per_share_gbp, flow_delta);
    setMarketState(marketRes.updatedMarketState);
    setAccountingState((prev) => ({ ...prev, rhg_share_price_gbp: marketRes.new_rhg_price }));
    showToast(`Order Executed: ${order.side} ${order.quantity.toLocaleString()} RHG @ £${marketRes.new_rhg_price.toFixed(2)}`);
  };

  // Execute Share Buyback
  const handleExecuteBuyback = (amount_gbp: number) => {
    const res = executeBuyback(accountingState, amount_gbp);
    setAccountingState(res.updatedState);
    showToast(`Share Buyback Executed: Repurchased ${(res.shares_repurchased / 1e6).toFixed(2)}m shares (${res.accretion_pct >= 0 ? '+' : ''}${res.accretion_pct.toFixed(2)}% Accretive)`);
  };

  // Execute Share Issuance
  const handleExecuteIssuance = (shares: number, price: number) => {
    const res = executeIssuance(accountingState, shares, price);
    setAccountingState(res.updatedState);
    showToast(`Capital Raising Executed: Raised £${(res.cash_raised_gbp / 1e6).toFixed(1)}m cash`);
  };

  const selectedEquity = selectedHoldingTicker ? accountingState.equities[selectedHoldingTicker] ?? null : null;
  const selectedHoldingInfo = selectedHoldingTicker ? holdings.find((h) => h.ticker === selectedHoldingTicker) ?? null : null;

  return (
    <div className="min-h-screen bg-[#080d1a] text-slate-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Toast Notification Banner */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 bg-amber-500 text-amber-950 font-mono font-bold text-xs px-4 py-3 rounded-lg shadow-2xl border border-amber-400 flex items-center gap-2 animate-bounce">
          <Zap className="w-4 h-4 fill-current" />
          <span>{notification}</span>
        </div>
      )}

      {/* Primary Header & Top Bar */}
      <Header
        navMetrics={nav_metrics}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenQuickTrade={() => setActiveTab('market')}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto px-6 py-6 space-y-6">
        {/* Interactive Demonstration Control Bar (Requirement 85) */}
        <div className="bg-[#0b1329] border border-amber-500/30 rounded-xl p-4 shadow-xl flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
          <div className="flex items-center gap-2 text-amber-400 font-bold uppercase tracking-wider">
            <Zap className="w-4 h-4" /> Live Market Event Simulation Trigger Panel:
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleNvidiaShock}
              className="px-3.5 py-1.5 rounded bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/50 text-emerald-300 font-bold flex items-center gap-1.5 transition-colors"
            >
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>NVIDIA +10.0% SHOCK</span>
            </button>

            <button
              onClick={handleFxShock}
              className="px-3.5 py-1.5 rounded bg-sky-950/80 hover:bg-sky-900 border border-sky-500/50 text-sky-300 font-bold flex items-center gap-1.5 transition-colors"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>GBP +10.0% VS USD</span>
            </button>

            <button
              onClick={handleTechCrashShock}
              className="px-3.5 py-1.5 rounded bg-rose-950/80 hover:bg-rose-900 border border-rose-500/50 text-rose-300 font-bold flex items-center gap-1.5 transition-colors"
            >
              <ArrowDownRight className="w-3.5 h-3.5" />
              <span>TECH SECTOR CRASH (-35%)</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Overview & Radial Graph */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <RhinoRadialGraph
              holdings={holdings}
              navMetrics={nav_metrics}
              onSelectHolding={(ticker) => setSelectedHoldingTicker(ticker)}
            />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <DefiningNavChart history={accountingState.history} navMetrics={nav_metrics} />
              <PerformanceAttribution waterfall={waterfall} />
            </div>
          </div>
        )}

        {/* Tab 2: Holdings Matrix */}
        {activeTab === 'holdings' && (
          <HoldingsMatrix
            holdings={holdings}
            equities={accountingState.equities}
            onSelectHolding={(ticker) => setSelectedHoldingTicker(ticker)}
            onUpdateWeights={handleUpdateWeights}
          />
        )}

        {/* Tab 3: NAV & Defining Chart */}
        {activeTab === 'nav_chart' && (
          <DefiningNavChart history={accountingState.history} navMetrics={nav_metrics} />
        )}

        {/* Tab 4: Performance Attribution */}
        {activeTab === 'attribution' && (
          <PerformanceAttribution waterfall={waterfall} />
        )}

        {/* Tab 5: Order Book & Market Control Room */}
        {activeTab === 'market' && (
          <MarketControlRoom
            orderbook={marketState.orderbook}
            marketMakers={marketState.market_makers}
            recentTrades={marketState.recent_trades}
            onPlaceOrder={handlePlaceOrder}
          />
        )}

        {/* Tab 6: Capital Allocation */}
        {activeTab === 'capital' && (
          <CapitalAllocationTerminal
            capitalStructure={accountingState.capital_structure}
            navMetrics={nav_metrics}
            onExecuteBuyback={handleExecuteBuyback}
            onExecuteIssuance={handleExecuteIssuance}
          />
        )}

        {/* Tab 7: Risk & Stress Tests */}
        {activeTab === 'risk' && (
          <RiskAndMonteCarloSuite
            riskMetrics={risk_metrics}
            factors={FACTOR_EXPOSURES}
            correlationMatrix={CORRELATION_MATRIX}
            onRunStressTest={async (sc) => runStressScenario(sc, accountingState)}
            onRunMonteCarlo={async (num) => runMonteCarloSimulation(accountingState, num, 252)}
          />
        )}

        {/* Tab 8: Board & Financials */}
        {activeTab === 'board' && (
          <BoardRoomView
            statements={statements}
            annualReportSummary={reportSummary}
          />
        )}

        {/* Tab 9: FTSE & Listing */}
        {activeTab === 'ftse' && (
          <FtseListingTerminal ftseReport={ftseReport} />
        )}

        {/* Tab 10: API & Python SDK */}
        {activeTab === 'sdk' && <SdkTerminal />}
      </main>

      {/* Holding Detail Modal */}
      {selectedHoldingTicker && (
        <HoldingDetailModal
          equity={selectedEquity}
          holdingInfo={selectedHoldingInfo}
          onClose={() => setSelectedHoldingTicker(null)}
        />
      )}

      {/* Institutional Footer */}
      <footer className="border-t border-slate-800/80 bg-[#060a15] py-6 px-6 mt-12 text-xs font-mono text-slate-500">
        <div className="max-w-[1600px] mx-auto flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className="font-serif text-slate-300 font-bold">RHINO GLOBAL HOLDINGS PLC</span>
            <span className="block text-[11px] text-slate-500">
              Synthetic UK-Listed Global Investment Holding Company Financial Simulation Environment.
            </span>
          </div>

          <div className="text-right text-[11px] text-slate-500">
            <span>Accounting Identity: Corporate NAV = Sum(Portfolio Holdings in GBP) + Cash - Liabilities</span>
            <span className="block text-slate-600">Simulated for institutional quantitative research purposes only.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
