import React from 'react';
import { SyntheticEquity, PortfolioHolding } from '../types/rhino';
import { X, TrendingUp, TrendingDown, DollarSign, Activity, Cpu, ShieldCheck, FileText } from 'lucide-react';

interface HoldingDetailModalProps {
  equity: SyntheticEquity | null;
  holdingInfo: PortfolioHolding | null;
  onClose: () => void;
}

export const HoldingDetailModal: React.FC<HoldingDetailModalProps> = ({
  equity,
  holdingInfo,
  onClose,
}) => {
  if (!equity) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0b1329] border border-amber-500/40 rounded-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 font-sans">
        {/* Modal Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-3">
              <span className="px-2.5 py-1 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 font-mono font-bold text-xs">
                {equity.ticker}
              </span>
              <h2 className="font-serif text-2xl font-bold text-slate-100">
                {equity.company_name}
              </h2>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                {equity.security_type}
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-1">
              RHINO SYNTHETIC EQUITY MODEL · {equity.sector} ({equity.industry}) · {equity.country}
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Key Model Highlights */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 my-6 font-mono text-xs">
          <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase">Model Price</span>
            <span className="text-lg font-bold text-slate-100">
              {equity.currency === 'GBP' ? '£' : '$'}{equity.price_local.toFixed(2)}
            </span>
            <span
              className={`text-[10px] block font-semibold ${
                equity.change_1d_pct >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {equity.change_1d_pct > 0 ? '+' : ''}{equity.change_1d_pct.toFixed(2)}% (1D)
            </span>
          </div>

          <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase">Portfolio Weight</span>
            <span className="text-lg font-bold text-amber-400">
              {holdingInfo ? (holdingInfo.weight * 100).toFixed(1) : '0.0'}%
            </span>
            <span className="text-[10px] block text-slate-400 font-semibold">
              £{holdingInfo ? (holdingInfo.market_value_gbp / 1e6).toFixed(1) : '0'}m Value
            </span>
          </div>

          <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase">NAV Contribution</span>
            <span className="text-lg font-bold text-emerald-400">
              +{holdingInfo ? holdingInfo.contribution_bps.toFixed(0) : '0'} bps
            </span>
            <span className="text-[10px] block text-slate-400 font-semibold">
              Daily Impact
            </span>
          </div>

          <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase">Beta / Volatility</span>
            <span className="text-lg font-bold text-sky-400">
              {equity.beta.toFixed(2)} / {(equity.volatility * 100).toFixed(0)}%
            </span>
            <span className="text-[10px] block text-slate-400 font-semibold">
              Risk Profile
            </span>
          </div>
        </div>

        {/* Sector-Specific Economic Engine Drivers */}
        <div className="mb-6 bg-slate-900/40 border border-slate-800 rounded-lg p-4 font-mono text-xs">
          <h3 className="font-serif text-lg font-bold text-amber-400 mb-3 flex items-center gap-2">
            <Cpu className="w-4 h-4" /> Sector Fundamental Drivers
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {Object.entries(equity.sector_drivers).map(([key, val]) => (
              <div
                key={key}
                className="flex items-center justify-between p-2.5 rounded bg-slate-950/80 border border-slate-800/80"
              >
                <span className="text-slate-400 uppercase text-[10px]">
                  {key.replace(/_/g, ' ')}
                </span>
                <span className="font-bold text-slate-100">
                  {typeof val === 'number' ? val.toLocaleString() : val}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Financial Statement Summary */}
        <div className="mb-6">
          <h3 className="font-serif text-lg font-bold text-slate-100 mb-3 flex items-center gap-2">
            <FileText className="w-4 h-4 text-amber-500" /> Model Financial Statements (Millions USD/Local)
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
            <div className="bg-slate-900/60 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">REVENUE</span>
              <span className="font-bold text-slate-200">${equity.revenue.toLocaleString()}M</span>
            </div>
            <div className="bg-slate-900/60 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">EBITDA</span>
              <span className="font-bold text-slate-200">${equity.ebitda.toLocaleString()}M</span>
            </div>
            <div className="bg-slate-900/60 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">FREE CASH FLOW</span>
              <span className="font-bold text-slate-200">${equity.fcf.toLocaleString()}M</span>
            </div>
            <div className="bg-slate-900/60 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">EPS</span>
              <span className="font-bold text-slate-200">${equity.eps.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Provenance Footer */}
        <div className="p-3 rounded bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-400 flex items-center justify-between">
          <span>Model Version: {equity.model_version}</span>
          <span>Provenance: {equity.provenance}</span>
          <span>Status: {equity.synthetic_status}</span>
        </div>
      </div>
    </div>
  );
};
