import React, { useState } from 'react';
import { AccountingStatements } from '../types/rhino';
import { FileText, ShieldCheck, Award, Printer, Download } from 'lucide-react';

interface BoardRoomViewProps {
  statements: AccountingStatements | null;
  annualReportSummary: {
    title: string;
    disclaimer: string;
    chairmans_statement: string;
    capital_allocation_strategy: string;
  };
}

export const BoardRoomView: React.FC<BoardRoomViewProps> = ({
  statements,
  annualReportSummary,
}) => {
  const [activeSection, setActiveSection] = useState<'papers' | 'balance_sheet' | 'income' | 'cash_flow'>('papers');

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl p-6 shadow-2xl font-sans">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 border-b border-slate-800 pb-4">
        <div>
          <h2 className="font-serif text-2xl font-bold text-slate-100 flex items-center gap-2">
            Simulated Board Room & Annual Report
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            Board papers, Chairman's strategic review, and IFRS/UK GAAP aligned holding company accounting statements.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={() => setActiveSection('papers')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSection === 'papers'
                ? 'bg-amber-500 text-amber-950 font-bold'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            BOARD PAPERS & REPORT
          </button>
          <button
            onClick={() => setActiveSection('balance_sheet')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSection === 'balance_sheet'
                ? 'bg-amber-500 text-amber-950 font-bold'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            BALANCE SHEET
          </button>
          <button
            onClick={() => setActiveSection('income')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSection === 'income'
                ? 'bg-amber-500 text-amber-950 font-bold'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            INCOME STATEMENT
          </button>
        </div>
      </div>

      {activeSection === 'papers' && (
        <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-6 font-serif text-slate-200 space-y-6">
          <div className="border-b border-amber-500/30 pb-4 flex items-center justify-between">
            <div>
              <span className="text-xs font-mono text-amber-400 font-bold block uppercase tracking-wider">
                {annualReportSummary.disclaimer}
              </span>
              <h1 className="text-3xl font-bold text-slate-100 mt-1">
                {annualReportSummary.title}
              </h1>
            </div>
            <FileText className="w-8 h-8 text-amber-500 shrink-0" />
          </div>

          <div>
            <h3 className="text-xl font-bold text-amber-400 mb-2">Chairman's Review</h3>
            <p className="text-sm leading-relaxed text-slate-300 font-sans">
              {annualReportSummary.chairmans_statement}
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-amber-400 mb-2">Capital Allocation Strategy</h3>
            <p className="text-sm leading-relaxed text-slate-300 font-sans">
              {annualReportSummary.capital_allocation_strategy}
            </p>
          </div>
        </div>
      )}

      {activeSection === 'balance_sheet' && statements && (
        <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-6 font-mono text-xs">
          <h3 className="font-serif text-xl font-bold text-amber-400 mb-4 border-b border-slate-800 pb-2">
            Statement of Financial Position (Balance Sheet)
          </h3>

          <div className="space-y-4">
            <div>
              <span className="text-slate-400 uppercase text-[10px] font-bold block mb-2">NON-CURRENT & CURRENT ASSETS</span>
              <div className="space-y-1.5">
                <div className="flex justify-between p-2 rounded bg-slate-900">
                  <span>Investment Holdings (Synthetic Equity Portfolio)</span>
                  <span className="font-bold text-slate-100">£{(statements.balance_sheet.investments_gbp / 1e6).toFixed(1)}m</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-900">
                  <span>Cash & Cash Equivalents</span>
                  <span className="font-bold text-emerald-400">£{(statements.balance_sheet.cash_and_equivalents_gbp / 1e6).toFixed(1)}m</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-900">
                  <span>Other Assets & Receivables</span>
                  <span className="font-bold text-slate-200">£{(statements.balance_sheet.other_assets_gbp / 1e6).toFixed(1)}m</span>
                </div>
                <div className="flex justify-between p-2.5 rounded bg-amber-500/10 border border-amber-500/30 font-bold text-amber-300 text-sm">
                  <span>TOTAL CORPORATE ASSETS</span>
                  <span>£{(statements.balance_sheet.total_assets_gbp / 1e6).toFixed(1)}m</span>
                </div>
              </div>
            </div>

            <div>
              <span className="text-slate-400 uppercase text-[10px] font-bold block mb-2">EQUITY & LIABILITIES</span>
              <div className="space-y-1.5">
                <div className="flex justify-between p-2 rounded bg-slate-900">
                  <span>Share Capital & Reserves</span>
                  <span className="font-bold text-slate-100">£{(statements.balance_sheet.total_equity_gbp / 1e6).toFixed(1)}m</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-900">
                  <span>Trade Liabilities & Payables</span>
                  <span className="font-bold text-slate-300">£{(statements.balance_sheet.total_liabilities_gbp / 1e6).toFixed(1)}m</span>
                </div>
                <div className="flex justify-between p-2.5 rounded bg-amber-500/10 border border-amber-500/30 font-bold text-amber-300 text-sm">
                  <span>TOTAL EQUITY & LIABILITIES</span>
                  <span>£{(statements.balance_sheet.total_assets_gbp / 1e6).toFixed(1)}m</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeSection === 'income' && statements && (
        <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-6 font-mono text-xs">
          <h3 className="font-serif text-xl font-bold text-amber-400 mb-4 border-b border-slate-800 pb-2">
            Corporate Income Statement
          </h3>

          <div className="space-y-2">
            <div className="flex justify-between p-2 rounded bg-slate-900">
              <span>Portfolio Dividend Income Received</span>
              <span className="font-bold text-emerald-400">£{(statements.income_statement.dividend_income_gbp / 1e6).toFixed(1)}m</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-900">
              <span>Net Unrealized Investment Gains</span>
              <span className="font-bold text-emerald-400">£{(statements.income_statement.unrealized_gains_gbp / 1e6).toFixed(1)}m</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-900">
              <span>Operating Management Expenses</span>
              <span className="font-bold text-rose-400">-£{(statements.income_statement.management_expenses_gbp / 1e6).toFixed(1)}m</span>
            </div>
            <div className="flex justify-between p-2.5 rounded bg-emerald-500/10 border border-emerald-500/30 font-bold text-emerald-300 text-sm">
              <span>NET PROFIT BEFORE TAX</span>
              <span>£{(statements.income_statement.net_profit_gbp / 1e6).toFixed(1)}m</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
