import React, { useState } from 'react';
import { PYTHON_SDK_EXAMPLE, R_ANALYTICS_EXAMPLE } from '../engine/sdksAndApi';
import { Terminal, Code, Play, Check } from 'lucide-react';

export const SdkTerminal: React.FC = () => {
  const [language, setLanguage] = useState<'python' | 'r'>('python');
  const [output, setOutput] = useState<string | null>(null);
  const [isRunning, setIsRunning] = useState(false);

  const handleRunCode = () => {
    setIsRunning(true);
    setTimeout(() => {
      if (language === 'python') {
        setOutput(`[RHINO PYTHON SDK EXECUTION RESULT]
Connecting to Rhino Global Holdings PLC API...
SUCCESS: Authenticated.

>>> rhino.nav()
Total Corporate NAV: £2.49B
NAV per share: £12.45
RHG Share Price: £12.85
Premium / Discount: +3.21% PREMIUM

>>> rhino.holdings()
NVDA   Weight: 15.0%  Value: £363.0M  1D Return: +3.20%
GOOGL  Weight: 14.0%  Value: £338.8M  1D Return: +0.85%
AAPL   Weight: 14.0%  Value: £338.8M  1D Return: +1.15%
NFLX   Weight:  8.0%  Value: £193.6M  1D Return: -0.42%
UBER   Weight:  8.0%  Value: £193.6M  1D Return: +1.45%
BP     Weight:  8.0%  Value: £193.6M  1D Return: -0.80%
IBM    Weight:  8.0%  Value: £193.6M  1D Return: +0.35%
MU     Weight:  8.0%  Value: £193.6M  1D Return: +2.10%
AXP    Weight:  7.0%  Value: £169.4M  1D Return: +0.60%
INTC   Weight:  6.0%  Value: £145.2M  1D Return: -1.80%
STRC   Weight:  4.0%  Value: £96.8M   1D Return: +0.20%
`);
      } else {
        setOutput(`[RHINO R ANALYTICS EXECUTION RESULT]
Loading rhinoGlobalR Package v3.6.1...
Connected to endpoint: http://localhost:3000/api

>>> client$correlation()
Matrix [11 x 11] generated.
Highest Pairwise Correlation: NVDA <-> MU (0.82)
Lowest Pairwise Correlation:  NVDA <-> BP (0.05)

>>> client$monte_carlo(10000)
Run completed: 10,000 paths in 142ms.
Daily 95% Value-at-Risk (VaR): £24.8M
Daily 95% Expected Shortfall (CVaR): £31.2M
`);
      }
      setIsRunning(false);
    }, 400);
  };

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl p-6 shadow-2xl font-mono text-xs">
      <div className="flex items-center justify-between mb-6 border-b border-slate-800 pb-4">
        <div>
          <h2 className="font-serif text-2xl font-bold text-slate-100 flex items-center gap-2">
            Developer API & SDK Playground
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            Institutional Python SDK (`rhinoglobal`) & R Analytics (`rhinoGlobalR`) client bindings for quantitative portfolio analysis.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => { setLanguage('python'); setOutput(null); }}
            className={`px-3 py-1.5 rounded transition-colors ${
              language === 'python'
                ? 'bg-amber-500 text-amber-950 font-bold'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            PYTHON SDK
          </button>
          <button
            onClick={() => { setLanguage('r'); setOutput(null); }}
            className={`px-3 py-1.5 rounded transition-colors ${
              language === 'r'
                ? 'bg-amber-500 text-amber-950 font-bold'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            R ANALYTICS
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Code Editor Preview */}
        <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <span className="text-slate-400 font-bold text-[10px] uppercase">
              {language === 'python' ? 'script.py' : 'script.R'}
            </span>
            <button
              onClick={handleRunCode}
              disabled={isRunning}
              className="px-3 py-1 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold flex items-center gap-1.5 transition-colors"
            >
              <Play className="w-3 h-3 fill-current" />
              <span>{isRunning ? 'EXECUTING...' : 'RUN SCRIPT'}</span>
            </button>
          </div>

          <pre className="text-slate-200 overflow-x-auto p-2 bg-slate-900/50 rounded leading-relaxed text-[11px]">
            {language === 'python' ? PYTHON_SDK_EXAMPLE : R_ANALYTICS_EXAMPLE}
          </pre>
        </div>

        {/* Output Console */}
        <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 border-b border-slate-800 pb-2 mb-3 text-slate-400 text-[10px] font-bold uppercase">
              <Terminal className="w-3.5 h-3.5 text-emerald-400" />
              <span>TERMINAL OUTPUT CONSOLE</span>
            </div>

            {output ? (
              <pre className="text-emerald-400 font-mono text-[11px] whitespace-pre-wrap leading-relaxed">
                {output}
              </pre>
            ) : (
              <div className="text-slate-600 italic py-12 text-center">
                Click "RUN SCRIPT" to execute code against the Rhino Global API.
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-slate-800/80 text-[10px] text-slate-500 flex justify-between">
            <span>REST Endpoints: /api/portfolio, /api/rhg/nav</span>
            <span>Auth: Bearer Token</span>
          </div>
        </div>
      </div>
    </div>
  );
};
