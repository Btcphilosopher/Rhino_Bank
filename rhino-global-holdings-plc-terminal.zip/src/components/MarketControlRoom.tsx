import React, { useState } from 'react';
import { OrderBook, MarketMakerQuote } from '../types/rhino';
import { Building2, ArrowUpRight, ArrowDownRight, RefreshCw, Send, ShieldCheck, Zap } from 'lucide-react';

interface MarketControlRoomProps {
  orderbook: OrderBook;
  marketMakers: MarketMakerQuote[];
  recentTrades: Array<{
    id: string;
    price: number;
    quantity: number;
    side: 'BUY' | 'SELL';
    timestamp: string;
  }>;
  onPlaceOrder: (order: {
    side: 'BUY' | 'SELL';
    quantity: number;
    price?: number;
    order_type: 'MARKET' | 'LIMIT' | 'STOP' | 'ICEBERG' | 'BLOCK';
  }) => void;
}

export const MarketControlRoom: React.FC<MarketControlRoomProps> = ({
  orderbook,
  marketMakers,
  recentTrades,
  onPlaceOrder,
}) => {
  const [side, setSide] = useState<'BUY' | 'SELL'>('BUY');
  const [orderType, setOrderType] = useState<'MARKET' | 'LIMIT' | 'STOP' | 'ICEBERG' | 'BLOCK'>('LIMIT');
  const [quantity, setQuantity] = useState<number>(25000);
  const [limitPrice, setLimitPrice] = useState<number>(orderbook.last_price);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onPlaceOrder({
      side,
      quantity,
      price: orderType === 'MARKET' ? orderbook.last_price : limitPrice,
      order_type: orderType,
    });
  };

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl p-6 shadow-2xl">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 border-b border-slate-800 pb-4">
        <div>
          <h2 className="font-serif text-2xl font-bold text-slate-100 flex items-center gap-2">
            RHG Synthetic Market & Order Book Control
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            Level-2 order book depth, synthetic liquidity market makers, and order execution engine for RHG ordinary shares.
          </p>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs">
          <span className="px-3 py-1 rounded bg-slate-900 border border-slate-800 text-emerald-400 font-bold">
            SPREAD: £{orderbook.spread.toFixed(2)}
          </span>
          <span className="px-3 py-1 rounded bg-slate-900 border border-slate-800 text-amber-400 font-bold">
            VWAP: £{orderbook.vwap.toFixed(2)}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono text-xs">
        {/* Level 2 Order Book Depth Table */}
        <div className="lg:col-span-2 bg-slate-950/80 border border-slate-800 rounded-lg p-4">
          <h3 className="font-serif text-lg font-bold text-slate-100 mb-3 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-amber-500" /> Level-2 Order Depth
          </h3>

          <div className="grid grid-cols-2 gap-4">
            {/* ASKS (Sells) */}
            <div>
              <span className="text-[10px] text-rose-400 font-bold uppercase tracking-wider block mb-2">
                ASKS (SELL ORDERS)
              </span>
              <table className="w-full text-left">
                <thead>
                  <tr className="text-slate-500 text-[10px] uppercase border-b border-slate-800">
                    <th className="py-1">Price (£)</th>
                    <th className="py-1 text-right">Size</th>
                    <th className="py-1 text-right">Participant</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40">
                  {orderbook.asks.map((ask) => (
                    <tr key={ask.id} className="text-rose-300 hover:bg-rose-950/20">
                      <td className="py-1.5 font-bold">£{ask.price.toFixed(2)}</td>
                      <td className="py-1.5 text-right font-semibold">{ask.quantity.toLocaleString()}</td>
                      <td className="py-1.5 text-right text-[10px] text-slate-400">{ask.trader_type}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* BIDS (Buys) */}
            <div>
              <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider block mb-2">
                BIDS (BUY ORDERS)
              </span>
              <table className="w-full text-left">
                <thead>
                  <tr className="text-slate-500 text-[10px] uppercase border-b border-slate-800">
                    <th className="py-1">Price (£)</th>
                    <th className="py-1 text-right">Size</th>
                    <th className="py-1 text-right">Participant</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40">
                  {orderbook.bids.map((bid) => (
                    <tr key={bid.id} className="text-emerald-300 hover:bg-emerald-950/20">
                      <td className="py-1.5 font-bold">£{bid.price.toFixed(2)}</td>
                      <td className="py-1.5 text-right font-semibold">{bid.quantity.toLocaleString()}</td>
                      <td className="py-1.5 text-right text-[10px] text-slate-400">{bid.trader_type}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Synthetic Market Makers Panel */}
          <div className="mt-6 pt-4 border-t border-slate-800">
            <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-2">
              Designated Market Maker Liquidity Quotes
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {marketMakers.map((mm) => (
                <div key={mm.mm_id} className="p-2.5 rounded bg-slate-900 border border-slate-800 text-[11px]">
                  <div className="font-bold text-slate-200 flex items-center justify-between">
                    <span>{mm.mm_id.replace('_SYNTHETIC', '')}</span>
                    <span className="text-emerald-400 text-[10px]">{mm.risk_status}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-300 mt-1">
                    <span>Bid: <strong className="text-emerald-400">£{mm.bid.toFixed(2)}</strong> ({mm.bid_size.toLocaleString()})</span>
                    <span>Ask: <strong className="text-rose-400">£{mm.ask.toFixed(2)}</strong> ({mm.ask_size.toLocaleString()})</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Order Placement Form */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-4">
          <h3 className="font-serif text-lg font-bold text-slate-100 mb-3 flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-500" /> Execute RHG Order
          </h3>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Side Selector */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setSide('BUY')}
                className={`py-2 rounded font-bold transition-colors ${
                  side === 'BUY'
                    ? 'bg-emerald-600 text-slate-950 shadow-lg'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                }`}
              >
                BUY RHG
              </button>
              <button
                type="button"
                onClick={() => setSide('SELL')}
                className={`py-2 rounded font-bold transition-colors ${
                  side === 'SELL'
                    ? 'bg-rose-600 text-slate-100 shadow-lg'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                }`}
              >
                SELL RHG
              </button>
            </div>

            {/* Order Type */}
            <div>
              <label className="text-[10px] text-slate-400 block uppercase mb-1">Order Type</label>
              <select
                value={orderType}
                onChange={(e) => setOrderType(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-amber-500"
              >
                <option value="LIMIT">LIMIT ORDER</option>
                <option value="MARKET">MARKET ORDER</option>
                <option value="STOP">STOP ORDER</option>
                <option value="ICEBERG">ICEBERG ORDER</option>
                <option value="BLOCK">BLOCK TRADE</option>
              </select>
            </div>

            {/* Quantity */}
            <div>
              <label className="text-[10px] text-slate-400 block uppercase mb-1">Quantity (Shares)</label>
              <input
                type="number"
                step="1000"
                min="1000"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-slate-200 font-bold focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Price Input */}
            {orderType !== 'MARKET' && (
              <div>
                <label className="text-[10px] text-slate-400 block uppercase mb-1">Limit Price (£)</label>
                <input
                  type="number"
                  step="0.01"
                  value={limitPrice}
                  onChange={(e) => setLimitPrice(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-slate-200 font-bold focus:outline-none focus:border-amber-500"
                />
              </div>
            )}

            {/* Summary */}
            <div className="p-3 bg-slate-900 rounded border border-slate-800 text-[11px] text-slate-300">
              <div className="flex justify-between">
                <span>Estimated Notional:</span>
                <span className="font-bold text-amber-400">
                  £{((orderType === 'MARKET' ? orderbook.last_price : limitPrice) * quantity / 1e6).toFixed(2)}m
                </span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded font-bold text-slate-950 bg-amber-500 hover:bg-amber-400 transition-colors flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" /> SUBMIT ORDER TO MATCHING ENGINE
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
