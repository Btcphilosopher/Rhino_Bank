import React, { useState } from 'react';
import { RhinoNavMetrics } from '../types/rhino';
import { TrendingUp, TrendingDown, Layers, Calendar } from 'lucide-react';

interface DefiningNavChartProps {
  history: Array<{
    timestamp: string;
    nav_gbp: number;
    nav_per_share: number;
    rhg_price: number;
    premium_discount_pct: number;
    portfolio_value_gbp: number;
  }>;
  navMetrics: RhinoNavMetrics;
}

export const DefiningNavChart: React.FC<DefiningNavChartProps> = ({
  history,
  navMetrics,
}) => {
  const [timeRange, setTimeRange] = useState<'1M' | '3M' | '1Y' | '3Y' | '10Y'>('1M');

  // Chart Dimensions
  const width = 800;
  const height = 320;
  const padding = 40;

  if (!history || history.length === 0) return null;

  // Calculate min & max values for scale
  const navValues = history.map((d) => d.nav_per_share);
  const priceValues = history.map((d) => d.rhg_price);
  const allValues = [...navValues, ...priceValues];

  const minVal = Math.min(...allValues) * 0.96;
  const maxVal = Math.max(...allValues) * 1.04;

  // Convert points to SVG coordinates
  const pointsNav = history.map((d, i) => {
    const x = padding + (i / (history.length - 1)) * (width - 2 * padding);
    const y = height - padding - ((d.nav_per_share - minVal) / (maxVal - minVal)) * (height - 2 * padding);
    return `${x},${y}`;
  });

  const pointsPrice = history.map((d, i) => {
    const x = padding + (i / (history.length - 1)) * (width - 2 * padding);
    const y = height - padding - ((d.rhg_price - minVal) / (maxVal - minVal)) * (height - 2 * padding);
    return `${x},${y}`;
  });

  const navPath = `M ${pointsNav.join(' L ')}`;
  const pricePath = `M ${pointsPrice.join(' L ')}`;

  // Area fill between Price & NAV
  const areaPoints = [
    ...pointsPrice,
    ...pointsNav.slice().reverse(),
  ].join(' L ');
  const areaPath = `M ${areaPoints} Z`;

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl p-6 shadow-2xl">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 border-b border-slate-800 pb-4">
        <div>
          <h3 className="font-serif text-2xl font-bold text-slate-100 flex items-center gap-2">
            RHG Share Price vs Corporate NAV
          </h3>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            The defining economic valuation identity of Rhino Global Holdings PLC.
          </p>
        </div>

        <div className="flex items-center gap-4 font-mono text-xs">
          <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-1 rounded-lg">
            {(['1M', '3M', '1Y', '3Y', '10Y'] as const).map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-3 py-1 rounded transition-colors ${
                  timeRange === range
                    ? 'bg-amber-500 text-amber-950 font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {range}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Primary SVG Line Chart */}
      <div className="relative">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto select-none">
          {/* Horizontal Grid lines */}
          {[0, 0.25, 0.5, 0.75, 1.0].map((ratio) => {
            const y = padding + ratio * (height - 2 * padding);
            const val = maxVal - ratio * (maxVal - minVal);
            return (
              <g key={`grid_${ratio}`}>
                <line
                  x1={padding}
                  y1={y}
                  x2={width - padding}
                  y2={y}
                  stroke="#1e293b"
                  strokeDasharray="3 3"
                  strokeWidth="1"
                />
                <text
                  x={padding - 6}
                  y={y + 4}
                  textAnchor="end"
                  className="fill-slate-500 text-[10px] font-mono"
                >
                  £{val.toFixed(2)}
                </text>
              </g>
            );
          })}

          {/* Premium / Discount Area Fill */}
          <path
            d={areaPath}
            fill={navMetrics.premium_discount_pct >= 0 ? '#10b981' : '#f43f5e'}
            fillOpacity="0.12"
          />

          {/* NAV Path (Amber Line) */}
          <path
            d={navPath}
            fill="none"
            stroke="#d97706"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          {/* RHG Share Price Path (Emerald/Cyan Line) */}
          <path
            d={pricePath}
            fill="none"
            stroke="#38bdf8"
            strokeWidth="2"
            strokeDasharray="4 2"
            strokeLinecap="round"
          />

          {/* Latest Data Point Markers */}
          {pointsNav.length > 0 && (
            <>
              {(() => {
                const lastNav = pointsNav[pointsNav.length - 1].split(',');
                const lastPrice = pointsPrice[pointsPrice.length - 1].split(',');
                return (
                  <>
                    <circle cx={lastNav[0]} cy={lastNav[1]} r="4" fill="#d97706" />
                    <circle cx={lastPrice[0]} cy={lastPrice[1]} r="4" fill="#38bdf8" />
                  </>
                );
              })()}
            </>
          )}
        </svg>
      </div>

      {/* Legend & Stats Footer */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6 pt-4 border-t border-slate-800 text-xs font-mono">
        <div className="flex items-center gap-3 bg-slate-900/60 p-3 rounded-lg border border-slate-800">
          <div className="w-3 h-3 rounded-full bg-amber-500 shrink-0" />
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">NAV Per Share</span>
            <span className="font-bold text-slate-100 text-sm">£{navMetrics.nav_per_share_gbp.toFixed(2)}</span>
          </div>
        </div>

        <div className="flex items-center gap-3 bg-slate-900/60 p-3 rounded-lg border border-slate-800">
          <div className="w-3 h-3 rounded-full bg-sky-400 shrink-0" />
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">RHG Market Price</span>
            <span className="font-bold text-sky-400 text-sm">£{navMetrics.rhg_share_price_gbp.toFixed(2)}</span>
          </div>
        </div>

        <div className="flex items-center gap-3 bg-slate-900/60 p-3 rounded-lg border border-slate-800">
          <div
            className={`w-3 h-3 rounded-full shrink-0 ${
              navMetrics.premium_discount_pct >= 0 ? 'bg-emerald-500' : 'bg-rose-500'
            }`}
          />
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Premium / Discount Regime</span>
            <span
              className={`font-bold text-sm ${
                navMetrics.premium_discount_pct >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {navMetrics.premium_discount_pct >= 0 ? '+' : ''}
              {navMetrics.premium_discount_pct.toFixed(2)}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
