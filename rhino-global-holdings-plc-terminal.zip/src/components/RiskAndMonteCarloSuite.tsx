import React, { useState } from 'react';
import { RiskMetrics, StressScenarioResult, MonteCarloSimulationResult, FactorExposure } from '../types/rhino';
import { ShieldAlert, Activity, Play, RefreshCcw, Cpu, Layers } from 'lucide-react';

interface RiskAndMonteCarloSuiteProps {
  riskMetrics: RiskMetrics;
  factors: FactorExposure[];
  correlationMatrix: Record<string, Record<string, number>>;
  onRunStressTest: (scenario: 'technology_crash' | 'energy_shock' | 'global_recession' | 'semiconductor_cycle' | 'fx_shock_gbp_strong' | 'fx_shock_gbp_weak') => Promise<StressScenarioResult>;
  onRunMonteCarlo: (numSims: number) => Promise<MonteCarloSimulationResult>;
}

export const RiskAndMonteCarloSuite: React.FC<RiskAndMonteCarloSuiteProps> = ({
  riskMetrics,
  factors,
  correlationMatrix,
  onRunStressTest,
  onRunMonteCarlo,
}) => {
  const [activeScenario, setActiveScenario] = useState<StressScenarioResult | null>(null);
  const [mcResult, setMcResult] = useState<MonteCarloSimulationResult | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);

  const scenarios = [
    { id: 'technology_crash', label: 'Technology Sector Crash (-35% Semi / -20% Tech)' },
    { id: 'energy_shock', label: 'Energy Crisis Shock (BP +30%, Inflation Drag)' },
    { id: 'global_recession', label: 'Global Stagflation Recession' },
    { id: 'semiconductor_cycle', label: 'Semiconductor Downturn Cycle' },
    { id: 'fx_shock_gbp_strong', label: 'GBP Appreciation Shock (+10% Sterling)' },
    { id: 'fx_shock_gbp_weak', label: 'GBP Depreciation Shock (-10% Sterling)' },
  ] as const;

  const handleScenarioSelect = async (id: any) => {
    const res = await onRunStressTest(id);
    setActiveScenario(res);
  };

  const handleTriggerMonteCarlo = async () => {
    setIsSimulating(true);
    const res = await onRunMonteCarlo(2000);
    setMcResult(res);
    setIsSimulating(false);
  };

  const tickers = Object.keys(correlationMatrix);

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl p-6 shadow-2xl space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="font-serif text-2xl font-bold text-slate-100 flex items-center gap-2">
            Quantitative Risk & Stress Testing Suite
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            Monte Carlo stochastic simulations, historical VaR, portfolio factor exposures, and scenario stress testing.
          </p>
        </div>

        <button
          onClick={handleTriggerMonteCarlo}
          disabled={isSimulating}
          className="px-4 py-2 rounded font-mono text-xs font-bold text-amber-950 bg-amber-500 hover:bg-amber-400 transition-colors flex items-center gap-2 shadow-md disabled:opacity-50"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>{isSimulating ? 'SIMULATING 2,000 PATHS...' : 'RUN MONTE CARLO (2,000 PATHS)'}</span>
        </button>
      </div>

      {/* Top Risk Scorecard */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-slate-950/80 p-3.5 rounded-lg border border-slate-800">
          <span className="text-slate-400 text-[10px] uppercase block">Annualized Volatility</span>
          <span className="text-xl font-bold text-amber-400">
            {(riskMetrics.portfolio_volatility_annualized * 100).toFixed(1)}%
          </span>
        </div>

        <div className="bg-slate-950/80 p-3.5 rounded-lg border border-slate-800">
          <span className="text-slate-400 text-[10px] uppercase block">Daily 95% VaR (Value-at-Risk)</span>
          <span className="text-xl font-bold text-rose-400">
            £{(riskMetrics.var_95_daily_gbp / 1e6).toFixed(1)}m
          </span>
        </div>

        <div className="bg-slate-950/80 p-3.5 rounded-lg border border-slate-800">
          <span className="text-slate-400 text-[10px] uppercase block">Expected Shortfall (CVaR)</span>
          <span className="text-xl font-bold text-rose-300">
            £{(riskMetrics.expected_shortfall_95_gbp / 1e6).toFixed(1)}m
          </span>
        </div>

        <div className="bg-slate-950/80 p-3.5 rounded-lg border border-slate-800">
          <span className="text-slate-400 text-[10px] uppercase block">Effective N Holdings (HHI)</span>
          <span className="text-xl font-bold text-sky-400">
            {riskMetrics.effective_number_holdings}
          </span>
        </div>
      </div>

      {/* Stress Test Scenarios */}
      <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-5">
        <h3 className="font-serif text-lg font-bold text-slate-100 mb-4 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-rose-400" /> Scenario Stress Testing Engine
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6 font-mono text-xs">
          {scenarios.map((sc) => (
            <button
              key={sc.id}
              onClick={() => handleScenarioSelect(sc.id)}
              className={`p-3 text-left rounded-lg border transition-colors ${
                activeScenario?.scenario_id === sc.id
                  ? 'bg-rose-950/40 border-rose-500 text-rose-200 font-bold'
                  : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {sc.label}
            </button>
          ))}
        </div>

        {activeScenario && (
          <div className="p-4 rounded-lg bg-slate-900 border border-rose-500/40 text-xs font-mono space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-rose-400">{activeScenario.scenario_name}</span>
              <span className="font-bold text-slate-100">
                NAV Impact: <span className="text-rose-400">£{(activeScenario.nav_impact_gbp / 1e6).toFixed(1)}m ({activeScenario.nav_impact_pct.toFixed(2)}%)</span>
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
              {activeScenario.holding_impacts.map((hi) => (
                <div key={hi.ticker} className="p-2 rounded bg-slate-950 flex justify-between">
                  <span className="text-slate-400">{hi.ticker}:</span>
                  <span className={hi.price_change_pct >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {hi.price_change_pct > 0 ? '+' : ''}{hi.price_change_pct.toFixed(1)}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Correlation Matrix Heatmap */}
      <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-5">
        <h3 className="font-serif text-lg font-bold text-slate-100 mb-4 flex items-center gap-2">
          <Layers className="w-4 h-4 text-amber-500" /> Holdings Correlation Matrix
        </h3>

        <div className="overflow-x-auto font-mono text-[10px]">
          <table className="w-full border-collapse text-center">
            <thead>
              <tr>
                <th className="p-1.5 text-left text-slate-400">TICKER</th>
                {tickers.map((t) => (
                  <th key={t} className="p-1.5 text-slate-400">{t}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tickers.map((rowT) => (
                <tr key={rowT} className="border-t border-slate-900">
                  <td className="p-1.5 text-left font-bold text-slate-200">{rowT}</td>
                  {tickers.map((colT) => {
                    const val = correlationMatrix[rowT]?.[colT] ?? 1.0;
                    const opacity = Math.abs(val);
                    return (
                      <td
                        key={colT}
                        className="p-1.5 font-bold"
                        style={{
                          backgroundColor: val === 1.0 ? 'rgba(217, 119, 6, 0.25)' : `rgba(56, 189, 248, ${opacity * 0.3})`,
                          color: val === 1.0 ? '#f59e0b' : '#e2e8f0',
                        }}
                      >
                        {val.toFixed(2)}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
