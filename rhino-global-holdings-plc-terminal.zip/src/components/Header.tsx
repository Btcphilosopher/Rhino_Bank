import React from 'react';
import { RhinoNavMetrics } from '../types/rhino';
import { ShieldAlert, TrendingUp, TrendingDown, Clock, Building2 } from 'lucide-react';

interface HeaderProps {
  navMetrics: RhinoNavMetrics;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenQuickTrade: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  navMetrics,
  activeTab,
  setActiveTab,
  onOpenQuickTrade,
}) => {
  const isPremium = navMetrics.premium_discount_pct >= 0;

  const navTabs = [
    { id: 'overview', label: 'Overview & Graph' },
    { id: 'holdings', label: 'Portfolio Holdings' },
    { id: 'nav_chart', label: 'NAV & Price' },
    { id: 'attribution', label: 'Performance Waterfall' },
    { id: 'market', label: 'Order Book & Market' },
    { id: 'capital', label: 'Capital Allocation' },
    { id: 'risk', label: 'Risk & Stress Tests' },
    { id: 'board', label: 'Board & Financials' },
    { id: 'ftse', label: 'FTSE & Listing' },
    { id: 'sdk', label: 'API & Python SDK' },
  ];

  return (
    <header className="border-b border-slate-800 bg-[#080d1a]/95 backdrop-blur-md sticky top-0 z-40">
      {/* Top Bar Contract: Brand - Nav - Action */}
      <div className="max-w-[1600px] mx-auto px-6 h-16 flex items-center justify-between border-b border-slate-800/60">
        {/* Zone 1: Single Brand Title */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-slate-900 border border-amber-600/30 flex items-center justify-center shadow-inner">
            <span className="font-serif font-bold text-amber-500 text-lg">R</span>
          </div>
          <div>
            <span className="font-serif text-xl font-bold tracking-tight text-slate-100 uppercase">
              Rhino Global Holdings PLC
            </span>
            <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
              <span className="text-amber-400 font-semibold">RHG.L</span>
              <span aria-hidden="true">·</span>
              <span>LSE MAIN MARKET (SIMULATED)</span>
            </div>
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden xl:flex items-center gap-1">
          {navTabs.slice(0, 7).map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`px-3 py-1.5 text-xs font-medium transition-colors border-b-2 whitespace-nowrap ${
                activeTab === t.id
                  ? 'border-amber-500 text-amber-400 bg-amber-500/5'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              {t.label}
            </button>
          ))}
          <div className="relative group">
            <button className="px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors">
              More ▾
            </button>
            <div className="absolute right-0 top-full hidden group-hover:block w-48 bg-[#0b1329] border border-slate-800 rounded shadow-xl py-1 z-50">
              {navTabs.slice(7).map((t) => (
                <button
                  key={t.id}
                  onClick={() => setActiveTab(t.id)}
                  className={`w-full text-left px-4 py-2 text-xs transition-colors ${
                    activeTab === t.id ? 'bg-amber-500/10 text-amber-400' : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-3">
          <div className="hidden md:flex items-center gap-2 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-300 font-mono">
            <Clock className="w-3.5 h-3.5 text-amber-500" />
            <span>LON: 10:14:22</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-emerald-400 font-semibold">LIVE SIM</span>
          </div>

          <button
            onClick={onOpenQuickTrade}
            className="px-4 py-2 text-xs font-semibold text-amber-950 bg-amber-500 hover:bg-amber-400 rounded transition-colors shadow-sm flex items-center gap-1.5 font-mono"
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>TRADE RHG</span>
          </button>
        </div>
      </div>

      {/* Hero Financial Ticker Bar */}
      <div className="bg-[#060a15] border-b border-slate-800/80 py-2.5 px-6">
        <div className="max-w-[1600px] mx-auto flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
          <div className="flex items-center gap-6">
            <div>
              <span className="text-slate-400 text-[10px] uppercase block tracking-wider">RHG Share Price</span>
              <div className="flex items-baseline gap-2">
                <span className="text-lg font-bold text-slate-100">
                  £{navMetrics.rhg_share_price_gbp.toFixed(2)}
                </span>
                <span className="text-emerald-400 font-medium flex items-center gap-0.5 text-xs">
                  <TrendingUp className="w-3 h-3" /> +1.82%
                </span>
              </div>
            </div>

            <div className="h-8 w-px bg-slate-800" />

            <div>
              <span className="text-slate-400 text-[10px] uppercase block tracking-wider">NAV Per Share</span>
              <span className="text-base font-semibold text-slate-200">
                £{navMetrics.nav_per_share_gbp.toFixed(2)}
              </span>
            </div>

            <div className="h-8 w-px bg-slate-800" />

            <div>
              <span className="text-slate-400 text-[10px] uppercase block tracking-wider">Prem / Disc to NAV</span>
              <span
                className={`inline-flex items-center gap-1 font-semibold text-xs px-2 py-0.5 rounded border ${
                  isPremium
                    ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                    : 'bg-rose-950/60 text-rose-300 border-rose-800'
                }`}
              >
                {isPremium ? '+' : ''}
                {navMetrics.premium_discount_pct.toFixed(2)}% {isPremium ? 'PREMIUM' : 'DISCOUNT'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-6 text-slate-300">
            <div>
              <span className="text-slate-400 text-[10px] uppercase block tracking-wider">Corporate NAV</span>
              <span className="font-semibold text-slate-200">
                £{(navMetrics.total_nav_gbp / 1e9).toFixed(3)}bn
              </span>
            </div>

            <div className="h-8 w-px bg-slate-800" />

            <div>
              <span className="text-slate-400 text-[10px] uppercase block tracking-wider">Portfolio Market Value</span>
              <span className="font-semibold text-slate-200">
                £{(navMetrics.portfolio_market_value_gbp / 1e9).toFixed(3)}bn
              </span>
            </div>

            <div className="h-8 w-px bg-slate-800" />

            <div>
              <span className="text-slate-400 text-[10px] uppercase block tracking-wider">Cash Reserve</span>
              <span className="font-semibold text-emerald-400">
                £{(navMetrics.cash_gbp / 1e6).toFixed(1)}m
              </span>
            </div>

            <div className="h-8 w-px bg-slate-800" />

            <div>
              <span className="text-slate-400 text-[10px] uppercase block tracking-wider">Dividend Yield</span>
              <span className="font-semibold text-amber-400">2.45%</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
