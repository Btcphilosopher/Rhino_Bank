import React, { useState } from 'react';
import { PortfolioHolding, RhinoNavMetrics } from '../types/rhino';
import { Maximize2, Info, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface RhinoRadialGraphProps {
  holdings: PortfolioHolding[];
  navMetrics: RhinoNavMetrics;
  onSelectHolding: (ticker: string) => void;
}

export const RhinoRadialGraph: React.FC<RhinoRadialGraphProps> = ({
  holdings,
  navMetrics,
  onSelectHolding,
}) => {
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);

  // Layout parameters for SVG graph
  const width = 900;
  const height = 580;
  const centerX = width / 2;
  const centerY = height / 2;
  const radius = 220;

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl p-6 relative shadow-2xl overflow-hidden">
      <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
        <div>
          <h2 className="font-serif text-2xl font-bold text-slate-100 flex items-center gap-2">
            The Great Rhino Graph
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            Architectural visualization of RHINO GLOBAL HOLDINGS PLC, corporate NAV, and underlying synthetic equity holdings.
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800">
            <span className="w-2 h-2 rounded-full bg-emerald-500" /> Positive Contribution
          </span>
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800">
            <span className="w-2 h-2 rounded-full bg-rose-500" /> Negative Contribution
          </span>
        </div>
      </div>

      <div className="relative flex justify-center items-center py-2">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full max-w-[880px] h-auto select-none"
        >
          <defs>
            {/* Radial Gradients */}
            <radialGradient id="centerGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#d97706" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#080d1a" stopOpacity="0" />
            </radialGradient>

            <linearGradient id="lineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#d97706" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#334155" stopOpacity="0.2" />
            </linearGradient>
          </defs>

          {/* Concentric Orbit Rings */}
          <circle
            cx={centerX}
            cy={centerY}
            r={radius}
            fill="none"
            stroke="#1e293b"
            strokeDasharray="4 4"
            strokeWidth="1.5"
          />
          <circle
            cx={centerX}
            cy={centerY}
            r={radius * 0.55}
            fill="none"
            stroke="#334155"
            strokeWidth="1"
          />

          {/* Center Glow */}
          <circle cx={centerX} cy={centerY} r={110} fill="url(#centerGlow)" />

          {/* Node Connecting Rays */}
          {holdings.map((h, index) => {
            const angle = (index / holdings.length) * 2 * Math.PI - Math.PI / 2;
            const x = centerX + radius * Math.cos(angle);
            const y = centerY + radius * Math.sin(angle);
            const isHovered = hoveredNode === h.ticker;

            return (
              <g key={`ray_${h.ticker}`}>
                <line
                  x1={centerX}
                  y1={centerY}
                  x2={x}
                  y2={y}
                  stroke={isHovered ? '#f59e0b' : '#334155'}
                  strokeWidth={isHovered ? 2 : 1}
                  opacity={isHovered ? 0.9 : 0.4}
                  className="transition-all duration-200"
                />
              </g>
            );
          })}

          {/* CENTER NODE: RHINO GLOBAL HOLDINGS PLC */}
          <g className="cursor-pointer">
            <rect
              x={centerX - 110}
              y={centerY - 42}
              width={220}
              height={84}
              rx={12}
              fill="#0f172a"
              stroke="#d97706"
              strokeWidth="2"
              className="shadow-2xl"
            />
            <text
              x={centerX}
              y={centerY - 16}
              textAnchor="middle"
              className="fill-slate-100 text-[11px] font-serif font-bold tracking-wider"
            >
              RHINO GLOBAL HOLDINGS PLC
            </text>
            <text
              x={centerX}
              y={centerY + 4}
              textAnchor="middle"
              className="fill-amber-400 text-xs font-mono font-bold"
            >
              NAV £{(navMetrics.total_nav_gbp / 1e9).toFixed(2)}B | RHG £{navMetrics.rhg_share_price_gbp.toFixed(2)}
            </text>
            <text
              x={centerX}
              y={centerY + 24}
              textAnchor="middle"
              className={`text-[10px] font-mono font-semibold ${
                navMetrics.premium_discount_pct >= 0 ? 'fill-emerald-400' : 'fill-rose-400'
              }`}
            >
              {navMetrics.premium_discount_pct >= 0 ? '+' : ''}
              {navMetrics.premium_discount_pct.toFixed(2)}% Prem/Disc
            </text>
          </g>

          {/* SATELLITE HOLDING NODES */}
          {holdings.map((h, index) => {
            const angle = (index / holdings.length) * 2 * Math.PI - Math.PI / 2;
            const x = centerX + radius * Math.cos(angle);
            const y = centerY + radius * Math.sin(angle);

            const isPositive = h.gbp_return_pct >= 0;
            const nodeRadius = 24 + h.weight * 60; // Node size proportional to portfolio weight
            const isHovered = hoveredNode === h.ticker;

            return (
              <g
                key={h.ticker}
                onClick={() => onSelectHolding(h.ticker)}
                onMouseEnter={() => setHoveredNode(h.ticker)}
                onMouseLeave={() => setHoveredNode(null)}
                className="cursor-pointer group"
              >
                {/* Outer Glow on Hover */}
                {isHovered && (
                  <circle
                    cx={x}
                    cy={y}
                    r={nodeRadius + 8}
                    fill="none"
                    stroke={isPositive ? '#10b981' : '#f43f5e'}
                    strokeWidth="2"
                    strokeDasharray="3 3"
                    className="animate-spin"
                    style={{ animationDuration: '6s' }}
                  />
                )}

                {/* Node Circle */}
                <circle
                  cx={x}
                  cy={y}
                  r={nodeRadius}
                  fill="#0b1329"
                  stroke={isPositive ? '#059669' : '#e11d48'}
                  strokeWidth={isHovered ? 2.5 : 1.5}
                  className="transition-all duration-200"
                />

                {/* Ticker Text */}
                <text
                  x={x}
                  y={y - 4}
                  textAnchor="middle"
                  className="fill-slate-100 text-xs font-mono font-bold"
                >
                  {h.ticker}
                </text>

                {/* Weight Text */}
                <text
                  x={x}
                  y={y + 10}
                  textAnchor="middle"
                  className="fill-slate-400 text-[10px] font-mono"
                >
                  {(h.weight * 100).toFixed(1)}%
                </text>

                {/* Return Badge */}
                <text
                  x={x}
                  y={y + 22}
                  textAnchor="middle"
                  className={`text-[9px] font-mono font-bold ${
                    isPositive ? 'fill-emerald-400' : 'fill-rose-400'
                  }`}
                >
                  {isPositive ? '+' : ''}
                  {h.gbp_return_pct.toFixed(1)}%
                </text>
              </g>
            );
          })}
        </svg>

        {/* Hovered Holding Tooltip Badge */}
        {hoveredNode && (
          <div className="absolute bottom-4 left-6 bg-[#0f172a] border border-amber-500/40 rounded-lg p-3 shadow-xl backdrop-blur-md text-xs font-mono">
            {(() => {
              const h = holdings.find((item) => item.ticker === hoveredNode);
              if (!h) return null;
              return (
                <div>
                  <div className="font-bold text-slate-100 text-sm flex items-center justify-between gap-4">
                    <span>{h.name} ({h.ticker})</span>
                    <span className="text-amber-400">{(h.weight * 100).toFixed(1)}% Weight</span>
                  </div>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1 mt-2 text-slate-300">
                    <div>Market Value: <span className="text-slate-100">£{(h.market_value_gbp / 1e6).toFixed(1)}m</span></div>
                    <div>NAV Contribution: <span className="text-amber-300">+{h.contribution_bps.toFixed(0)} bps</span></div>
                    <div>Local Return: <span className={h.local_return_pct >= 0 ? 'text-emerald-400' : 'text-rose-400'}>{h.local_return_pct > 0 ? '+' : ''}{h.local_return_pct.toFixed(2)}%</span></div>
                    <div>FX Return: <span className={h.fx_return_pct >= 0 ? 'text-emerald-400' : 'text-rose-400'}>{h.fx_return_pct > 0 ? '+' : ''}{h.fx_return_pct.toFixed(2)}%</span></div>
                  </div>
                  <div className="mt-2 text-[10px] text-amber-500/80 uppercase font-semibold">
                    Click node to inspect full synthetic equity model ↗
                  </div>
                </div>
              );
            })()}
          </div>
        )}
      </div>
    </div>
  );
};
