import React, { useState } from 'react';
import { RhinoCapitalStructure, RhinoNavMetrics } from '../types/rhino';
import { Building2, PieChart, Coins, TrendingUp, ShieldAlert, ArrowRight, DollarSign } from 'lucide-react';

interface CapitalAllocationTerminalProps {
  capitalStructure: RhinoCapitalStructure;
  navMetrics: RhinoNavMetrics;
  onExecuteBuyback: (amount_gbp: number) => void;
  onExecuteIssuance: (shares: number, price: number) => void;
}

export const CapitalAllocationTerminal: React.FC<CapitalAllocationTerminalProps> = ({
  capitalStructure,
  navMetrics,
  onExecuteBuyback,
  onExecuteIssuance,
}) => {
  const [buybackAmountM, setBuybackAmountM] = useState<number>(25); // £25m default buyback
  const [issuanceSharesM, setIssuanceSharesM] = useState<number>(10); // 10m shares default
  const [issuancePrice, setIssuancePrice] = useState<number>(navMetrics.rhg_share_price_gbp);

  // Buyback Accretion Calculation
  const buybackCostGbp = buybackAmountM * 1e6;
  const buybackShares = Math.floor(buybackCostGbp / Math.max(0.1, navMetrics.rhg_share_price_gbp));
  const newSharesAfterBuyback = Math.max(1, capitalStructure.shares_outstanding - buybackShares);
  const newNavAfterBuyback = navMetrics.total_nav_gbp - buybackCostGbp;
  const newNavPerShareAfterBuyback = newNavAfterBuyback / newSharesAfterBuyback;
  const buybackAccretionPct = ((newNavPerShareAfterBuyback - navMetrics.nav_per_share_gbp) / navMetrics.nav_per_share_gbp) * 100;

  // Issuance Dilution Calculation
  const issuanceCashRaisedGbp = issuanceSharesM * 1e6 * issuancePrice;
  const newSharesAfterIssuance = capitalStructure.shares_outstanding + issuanceSharesM * 1e6;
  const newNavAfterIssuance = navMetrics.total_nav_gbp + issuanceCashRaisedGbp;
  const newNavPerShareAfterIssuance = newNavAfterIssuance / newSharesAfterIssuance;
  const issuanceDilutionPct = ((newNavPerShareAfterIssuance - navMetrics.nav_per_share_gbp) / navMetrics.nav_per_share_gbp) * 100;

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl p-6 shadow-2xl">
      <div className="flex items-center justify-between mb-6 border-b border-slate-800 pb-4">
        <div>
          <h2 className="font-serif text-2xl font-bold text-slate-100 flex items-center gap-2">
            Board Capital Allocation Terminal
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            Active capital decisions: RHG Share Buybacks, Capital Issuance, Portfolio Leverage, and Accretion Mechanics.
          </p>
        </div>

        <span className="px-3 py-1 rounded bg-slate-900 border border-slate-800 text-xs font-mono text-amber-400 font-bold">
          Rhino Capital Allocation Model
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
        {/* RHG Share Buyback Module */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-2">
            <h3 className="font-serif text-lg font-bold text-slate-100 flex items-center gap-2">
              <Coins className="w-4 h-4 text-emerald-400" /> Share Buyback Engine
            </h3>
            <span className="text-[10px] text-emerald-400 font-bold">NAV ACCRETIVE</span>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-[10px] text-slate-400 uppercase block mb-1">
                Buyback Cash Budget (£ Millions)
              </label>
              <input
                type="number"
                step="5"
                min="5"
                max="100"
                value={buybackAmountM}
                onChange={(e) => setBuybackAmountM(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-slate-100 font-bold text-sm focus:border-emerald-500"
              />
            </div>

            {/* Live Accretion Mechanics */}
            <div className="p-3 bg-slate-900/60 rounded border border-slate-800/80 space-y-1.5 text-slate-300">
              <div className="flex justify-between">
                <span>Shares Repurchased:</span>
                <span className="font-bold text-slate-100">{(buybackShares / 1e6).toFixed(2)}m RHG</span>
              </div>
              <div className="flex justify-between">
                <span>NAV / Share Before:</span>
                <span className="font-bold text-slate-300">£{navMetrics.nav_per_share_gbp.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>NAV / Share Pro-Forma:</span>
                <span className="font-bold text-emerald-400">£{newNavPerShareAfterBuyback.toFixed(2)}</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-800">
                <span>Accretion Effect:</span>
                <span className={`font-bold ${buybackAccretionPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {buybackAccretionPct >= 0 ? '+' : ''}{buybackAccretionPct.toFixed(2)}%
                </span>
              </div>
            </div>

            <button
              onClick={() => onExecuteBuyback(buybackCostGbp)}
              className="w-full py-2.5 rounded font-bold text-slate-950 bg-emerald-500 hover:bg-emerald-400 transition-colors"
            >
              EXECUTE SHARE BUYBACK
            </button>
          </div>
        </div>

        {/* RHG Capital Issuance Module */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-2">
            <h3 className="font-serif text-lg font-bold text-slate-100 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-sky-400" /> Share Capital Issuance
            </h3>
            <span className="text-[10px] text-sky-400 font-bold">CAPITAL RAISING</span>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-slate-400 uppercase block mb-1">Shares (Millions)</label>
                <input
                  type="number"
                  step="1"
                  value={issuanceSharesM}
                  onChange={(e) => setIssuanceSharesM(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-slate-100 font-bold focus:border-sky-500"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 uppercase block mb-1">Price (£)</label>
                <input
                  type="number"
                  step="0.05"
                  value={issuancePrice}
                  onChange={(e) => setIssuancePrice(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-slate-100 font-bold focus:border-sky-500"
                />
              </div>
            </div>

            {/* Live Dilution Mechanics */}
            <div className="p-3 bg-slate-900/60 rounded border border-slate-800/80 space-y-1.5 text-slate-300">
              <div className="flex justify-between">
                <span>Gross Cash Raised:</span>
                <span className="font-bold text-sky-400">£{(issuanceCashRaisedGbp / 1e6).toFixed(1)}m</span>
              </div>
              <div className="flex justify-between">
                <span>Pro-Forma Shares Out:</span>
                <span className="font-bold text-slate-100">{(newSharesAfterIssuance / 1e6).toFixed(1)}m</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-800">
                <span>Dilution Effect:</span>
                <span className={`font-bold ${issuanceDilutionPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {issuanceDilutionPct >= 0 ? '+' : ''}{issuanceDilutionPct.toFixed(2)}%
                </span>
              </div>
            </div>

            <button
              onClick={() => onExecuteIssuance(issuanceSharesM * 1e6, issuancePrice)}
              className="w-full py-2.5 rounded font-bold text-slate-950 bg-sky-400 hover:bg-sky-300 transition-colors"
            >
              EXECUTE CAPITAL ISSUANCE
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
