import React, { useState } from 'react';
import { PortfolioHolding, SyntheticEquity } from '../types/rhino';
import { ExternalLink, Sliders, RotateCcw, Save, Shield, Globe } from 'lucide-react';

interface HoldingsMatrixProps {
  holdings: PortfolioHolding[];
  equities: Record<string, SyntheticEquity>;
  onSelectHolding: (ticker: string) => void;
  onUpdateWeights: (newWeights: Record<string, number>) => void;
}

export const HoldingsMatrix: React.FC<HoldingsMatrixProps> = ({
  holdings,
  equities,
  onSelectHolding,
  onUpdateWeights,
}) => {
  const [isEditingWeights, setIsEditingWeights] = useState(false);
  const [editedWeights, setEditedWeights] = useState<Record<string, number>>(() => {
    const w: Record<string, number> = {};
    holdings.forEach((h) => {
      w[h.ticker] = h.target_weight;
    });
    return w;
  });

  const handleWeightChange = (ticker: string, val: number) => {
    setEditedWeights((prev) => ({
      ...prev,
      [ticker]: Math.max(0, val / 100),
    }));
  };

  const handleSaveWeights = () => {
    onUpdateWeights(editedWeights);
    setIsEditingWeights(false);
  };

  const totalEditedWeight = Object.values(editedWeights).reduce((a, b) => a + b, 0) * 100;

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl p-6 shadow-2xl">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 border-b border-slate-800 pb-4">
        <div>
          <h2 className="font-serif text-2xl font-bold text-slate-100 flex items-center gap-2">
            Concentrated Global Equity Portfolio
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            Synthetic look-through equity exposures, FX impact, local returns, and capital allocation.
          </p>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs">
          {!isEditingWeights ? (
            <button
              onClick={() => setIsEditingWeights(true)}
              className="px-3.5 py-2 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 flex items-center gap-2 transition-colors"
            >
              <Sliders className="w-3.5 h-3.5 text-amber-500" />
              <span>EDIT ALLOCATION WEIGHTS</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <span className={`text-xs ${Math.abs(totalEditedWeight - 100) < 0.1 ? 'text-emerald-400' : 'text-amber-400'}`}>
                Total: {totalEditedWeight.toFixed(1)}%
              </span>
              <button
                onClick={handleSaveWeights}
                className="px-3.5 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold flex items-center gap-1.5 transition-colors"
              >
                <Save className="w-3.5 h-3.5" />
                <span>APPLY REBALANCE</span>
              </button>
              <button
                onClick={() => setIsEditingWeights(false)}
                className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              >
                CANCEL
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Holdings Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs font-mono">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider bg-slate-900/40">
              <th className="py-3 px-4 font-semibold">Asset / Holding</th>
              <th className="py-3 px-4 font-semibold">Sector</th>
              <th className="py-3 px-4 font-semibold">Country / Currency</th>
              <th className="py-3 px-4 font-semibold text-right">Target Weight</th>
              <th className="py-3 px-4 font-semibold text-right">Market Value (GBP)</th>
              <th className="py-3 px-4 font-semibold text-right">Local Price</th>
              <th className="py-3 px-4 font-semibold text-right">1D Local Return</th>
              <th className="py-3 px-4 font-semibold text-right">1D FX Return</th>
              <th className="py-3 px-4 font-semibold text-right">GBP Net Return</th>
              <th className="py-3 px-4 font-semibold text-right">NAV Impact (bps)</th>
              <th className="py-3 px-4 font-semibold text-center">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {holdings.map((h) => {
              const eq = equities[h.ticker];
              const isPositive = h.gbp_return_pct >= 0;

              return (
                <tr
                  key={h.ticker}
                  className="hover:bg-slate-900/60 transition-colors group"
                >
                  {/* Asset / Ticker */}
                  <td className="py-3.5 px-4">
                    <button
                      onClick={() => onSelectHolding(h.ticker)}
                      className="text-left group-hover:text-amber-400 transition-colors flex items-center gap-2 font-bold text-slate-100"
                    >
                      <span className="w-6 h-6 rounded bg-slate-800 border border-slate-700 flex items-center justify-center text-[10px] text-amber-400">
                        {h.ticker.substring(0, 2)}
                      </span>
                      <div>
                        <div className="font-bold">{h.name}</div>
                        <div className="text-[10px] text-slate-500 font-normal">{h.ticker}</div>
                      </div>
                    </button>
                  </td>

                  {/* Sector */}
                  <td className="py-3.5 px-4 text-slate-300">
                    <span className="text-slate-400">{eq?.sector ?? 'General'}</span>
                  </td>

                  {/* Country & FX */}
                  <td className="py-3.5 px-4 text-slate-300">
                    <div className="flex items-center gap-1.5">
                      <Globe className="w-3 h-3 text-slate-500" />
                      <span>{eq?.country ?? 'Global'} ({eq?.currency ?? 'USD'})</span>
                    </div>
                  </td>

                  {/* Weight Slider / Display */}
                  <td className="py-3.5 px-4 text-right">
                    {isEditingWeights ? (
                      <div className="flex items-center justify-end gap-2">
                        <input
                          type="number"
                          step="0.5"
                          min="0"
                          max="50"
                          value={((editedWeights[h.ticker] ?? 0) * 100).toFixed(1)}
                          onChange={(e) => handleWeightChange(h.ticker, parseFloat(e.target.value) || 0)}
                          className="w-16 bg-slate-900 border border-amber-500/50 rounded px-1.5 py-0.5 text-right font-bold text-amber-300 text-xs"
                        />
                        <span className="text-slate-400">%</span>
                      </div>
                    ) : (
                      <span className="font-bold text-slate-200">
                        {(h.weight * 100).toFixed(1)}%
                      </span>
                    )}
                  </td>

                  {/* Market Value */}
                  <td className="py-3.5 px-4 text-right font-semibold text-slate-100">
                    £{(h.market_value_gbp / 1e6).toFixed(1)}m
                  </td>

                  {/* Local Price */}
                  <td className="py-3.5 px-4 text-right text-slate-300">
                    {eq?.currency === 'GBP' ? '£' : '$'}
                    {eq?.price_local.toFixed(2)}
                  </td>

                  {/* 1D Local Return */}
                  <td
                    className={`py-3.5 px-4 text-right font-semibold ${
                      h.local_return_pct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {h.local_return_pct > 0 ? '+' : ''}
                    {h.local_return_pct.toFixed(2)}%
                  </td>

                  {/* FX Return */}
                  <td
                    className={`py-3.5 px-4 text-right ${
                      h.fx_return_pct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {h.fx_return_pct > 0 ? '+' : ''}
                    {h.fx_return_pct.toFixed(2)}%
                  </td>

                  {/* GBP Net Return */}
                  <td
                    className={`py-3.5 px-4 text-right font-bold ${
                      isPositive ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {isPositive ? '+' : ''}
                    {h.gbp_return_pct.toFixed(2)}%
                  </td>

                  {/* Contribution bps */}
                  <td className="py-3.5 px-4 text-right font-bold text-amber-300">
                    +{h.contribution_bps.toFixed(0)} bps
                  </td>

                  {/* Inspect Button */}
                  <td className="py-3.5 px-4 text-center">
                    <button
                      onClick={() => onSelectHolding(h.ticker)}
                      className="p-1.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-amber-400 transition-colors"
                      title="Inspect Synthetic Model"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
