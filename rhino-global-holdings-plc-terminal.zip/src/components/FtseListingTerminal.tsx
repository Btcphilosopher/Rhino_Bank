import React from 'react';
import { FtseEligibilityReport } from '../types/rhino';
import { Award, CheckCircle2, AlertTriangle, Building, Globe } from 'lucide-react';

interface FtseListingTerminalProps {
  ftseReport: FtseEligibilityReport;
}

export const FtseListingTerminal: React.FC<FtseListingTerminalProps> = ({
  ftseReport,
}) => {
  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl p-6 shadow-2xl font-mono text-xs">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 border-b border-slate-800 pb-4">
        <div>
          <h2 className="font-serif text-2xl font-bold text-slate-100 flex items-center gap-2">
            FTSE Russell Index Eligibility Simulator
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            Modelled FTSE 100 / FTSE 250 inclusion criteria check based on LSE admission ground rules.
          </p>
        </div>

        <span
          className={`px-3 py-1.5 rounded font-bold ${
            ftseReport.eligible_ftse_100
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
              : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
          }`}
        >
          {ftseReport.eligible_ftse_100 ? 'MODELLED FTSE 100 CONSTITUENT' : 'MODELLED FTSE 250 CONSTITUENT'}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
          <span className="text-slate-400 block text-[10px] uppercase">UK Market Cap Rank</span>
          <span className="text-2xl font-bold text-amber-400 mt-1 block">
            Rank #{ftseReport.market_cap_rank}
          </span>
          <span className="text-[10px] text-slate-400 mt-1 block">
            (Top 90 threshold for automatic inclusion)
          </span>
        </div>

        <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
          <span className="text-slate-400 block text-[10px] uppercase">Free Float Percentage</span>
          <span className="text-2xl font-bold text-emerald-400 mt-1 block">
            {ftseReport.free_float_pct}%
          </span>
          <span className="text-[10px] text-emerald-400/80 mt-1 block">
            ✓ Passes 25.0% UK minimum requirement
          </span>
        </div>

        <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
          <span className="text-slate-400 block text-[10px] uppercase">Projected Index Weight</span>
          <span className="text-2xl font-bold text-sky-400 mt-1 block">
            {ftseReport.projected_index_weight_pct}%
          </span>
          <span className="text-[10px] text-sky-400/80 mt-1 block">
            In FTSE 100 UK Index
          </span>
        </div>
      </div>

      {/* Assumptions & Criteria Checklist */}
      <div className="bg-slate-950 p-5 rounded-lg border border-slate-800">
        <h3 className="font-serif text-lg font-bold text-slate-100 mb-3">
          FTSE UK Index Ground Rules Audit Trail
        </h3>
        <div className="space-y-2">
          {ftseReport.reasons.map((reason, idx) => (
            <div key={idx} className="flex items-start gap-2.5 p-2 rounded bg-slate-900 border border-slate-800/80">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span className="text-slate-200">{reason}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
