export type SecurityType = 
  | 'COMMON_STOCK'
  | 'PREFERRED_STOCK'
  | 'ETF'
  | 'REIT'
  | 'DEPOSITARY_RECEIPT'
  | 'OTHER'
  | 'SYNTHETIC_SECURITY';

export type ListingStage = 
  | 'PRIVATE'
  | 'PRE-IPO'
  | 'IPO'
  | 'LISTED'
  | 'TRADING'
  | 'CORPORATE_ACTION';

export type Currency = 'GBP' | 'USD' | 'EUR' | 'JPY' | 'CHF' | 'CAD' | 'AUD' | 'HKD';

export interface SyntheticEquity {
  security_id: string;
  company_name: string;
  ticker: string;
  country: string;
  currency: Currency;
  sector: string;
  industry: string;
  security_type: SecurityType;
  price_local: number;
  price_gbp: number;
  shares_outstanding: number;
  market_cap_gbp: number;
  revenue: number; // in Millions USD/local
  ebitda: number;
  ebit: number;
  net_income: number;
  eps: number;
  fcf: number;
  dividend_yield: number;
  cash: number;
  debt: number;
  enterprise_value: number;
  beta: number;
  volatility: number;
  synthetic_status: string;
  model_version: string;
  timestamp: string;
  provenance: 'OBSERVED' | 'SYNTHETIC' | 'MODELLED' | 'FORECAST' | 'SCENARIO';
  
  // Specific economic drivers
  sector_drivers: Record<string, number | string>;
  
  // 1D changes
  change_1d_pct: number;
  fx_change_1d_pct: number;
}

export interface PortfolioHolding {
  ticker: string;
  name: string;
  weight: number; // percentage (0.15 = 15%)
  target_weight: number;
  quantity: number; // shares held by Rhino
  market_value_gbp: number;
  unrealized_pnl_gbp: number;
  contribution_bps: number; // contribution to NAV in basis points
  local_return_pct: number;
  fx_return_pct: number;
  gbp_return_pct: number;
}

export interface RhinoCapitalStructure {
  shares_authorised: number;
  shares_issued: number;
  shares_outstanding: number;
  treasury_shares: number;
  share_price_gbp: number;
  market_cap_gbp: number;
}

export interface RhinoDebtStructure {
  gross_debt_gbp: number;
  bonds_issued_gbp: number;
  weighted_avg_coupon: number;
  interest_coverage_ratio: number;
  ltv_ratio: number;
  portfolio_coverage: number;
}

export interface RhinoNavMetrics {
  portfolio_market_value_gbp: number;
  cash_gbp: number;
  other_assets_gbp: number;
  liabilities_gbp: number;
  total_nav_gbp: number;
  nav_per_share_gbp: number;
  rhg_share_price_gbp: number;
  premium_discount_pct: number; // +3.2 = 3.2% premium, -5.1 = 5.1% discount
  opening_nav_gbp: number;
}

export interface NavWaterfallItem {
  category: string;
  amount_gbp: number;
  bps_impact: number;
  type: 'OPENING' | 'HOLDING' | 'FX' | 'DIVIDEND' | 'COST' | 'BUYBACK' | 'CLOSING';
}

export interface OrderBookEntry {
  id: string;
  price: number;
  quantity: number;
  type: 'BID' | 'ASK';
  trader_type: 'MARKET_MAKER' | 'INSTITUTIONAL' | 'RETAIL' | 'TREASURY';
  timestamp: string;
}

export interface OrderBook {
  bids: OrderBookEntry[];
  asks: OrderBookEntry[];
  last_price: number;
  vwap: number;
  spread: number;
  volume_24h: number;
}

export interface MarketMakerQuote {
  mm_id: string;
  bid: number;
  ask: number;
  bid_size: number;
  ask_size: number;
  inventory_rhg: number;
  risk_status: string;
}

export interface FactorExposure {
  factor: string;
  exposure: number; // -1.0 to +1.0
  benchmark_exposure: number;
}

export interface RiskMetrics {
  portfolio_volatility_annualized: number;
  portfolio_beta_ftse100: number;
  portfolio_beta_sp500: number;
  var_95_daily_gbp: number;
  var_99_daily_gbp: number;
  expected_shortfall_95_gbp: number;
  max_historical_drawdown_pct: number;
  hhi_concentration_index: number;
  effective_number_holdings: number;
  largest_holding_weight: number;
  top_3_concentration: number;
  top_5_concentration: number;
}

export interface StressScenarioResult {
  scenario_id: string;
  scenario_name: string;
  nav_impact_gbp: number;
  nav_impact_pct: number;
  rhg_price_impact_pct: number;
  holding_impacts: Array<{
    ticker: string;
    price_change_pct: number;
    value_change_gbp: number;
  }>;
}

export interface MonteCarloSimulationResult {
  simulations_run: number;
  time_horizon_days: number;
  mean_nav_gbp: number;
  median_nav_gbp: number;
  percentile_5th_gbp: number;
  percentile_95th_gbp: number;
  var_95_gbp: number;
  cvar_95_gbp: number;
  paths: Array<number[]>; // sample 20 paths for plotting
}

export interface PortfolioNewsEvent {
  event_id: string;
  ticker: string;
  company_name: string;
  title: string;
  timestamp: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  fundamental_impact: string;
  price_impact_pct: number;
  nav_impact_bps: number;
  confidence: number;
}

export interface FtseEligibilityReport {
  ticker: string;
  company_name: string;
  market_cap_rank: number;
  free_float_pct: number;
  liquidity_pass: boolean;
  uk_incorporation_pass: boolean;
  listing_category: string;
  eligible_ftse_100: boolean;
  eligible_ftse_250: boolean;
  projected_index_weight_pct: number;
  reasons: string[];
}

export interface AccountingStatements {
  balance_sheet: {
    investments_gbp: number;
    cash_and_equivalents_gbp: number;
    other_assets_gbp: number;
    total_assets_gbp: number;
    debt_gbp: number;
    other_liabilities_gbp: number;
    total_liabilities_gbp: number;
    share_capital_gbp: number;
    retained_earnings_gbp: number;
    total_equity_gbp: number;
  };
  income_statement: {
    dividend_income_gbp: number;
    net_realized_gains_gbp: number;
    unrealized_gains_gbp: number;
    gross_revenue_gbp: number;
    management_expenses_gbp: number;
    finance_costs_gbp: number;
    profit_before_tax_gbp: number;
    taxation_gbp: number;
    net_profit_gbp: number;
  };
  cash_flow: {
    operating_cash_flow_gbp: number;
    investing_cash_flow_gbp: number;
    financing_cash_flow_gbp: number;
    net_cash_change_gbp: number;
  };
}
