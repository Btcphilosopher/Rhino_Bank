import { AccountingStatements } from '../types/rhino';
import { AccountingState, calculateNavMetrics } from './accountingEngine';

export function generateAccountingStatements(state: AccountingState): AccountingStatements {
  const { nav_metrics } = calculateNavMetrics(state);

  const investments_gbp = nav_metrics.portfolio_market_value_gbp;
  const cash_gbp = nav_metrics.cash_gbp;
  const other_assets_gbp = nav_metrics.other_assets_gbp;
  const total_assets_gbp = investments_gbp + cash_gbp + other_assets_gbp;

  const debt_gbp = 0; // 0 leverage currently
  const liabilities_gbp = nav_metrics.liabilities_gbp;
  const total_liabilities_gbp = debt_gbp + liabilities_gbp;

  const total_equity_gbp = total_assets_gbp - total_liabilities_gbp;
  const share_capital_gbp = state.capital_structure.shares_outstanding * 1.0; // £1 par value
  const retained_earnings_gbp = total_equity_gbp - share_capital_gbp;

  return {
    balance_sheet: {
      investments_gbp,
      cash_and_equivalents_gbp: cash_gbp,
      other_assets_gbp,
      total_assets_gbp,
      debt_gbp,
      other_liabilities_gbp: liabilities_gbp,
      total_liabilities_gbp,
      share_capital_gbp,
      retained_earnings_gbp,
      total_equity_gbp,
    },
    income_statement: {
      dividend_income_gbp: 18200000, // £18.2m annual portfolio dividend yield
      net_realized_gains_gbp: 34500000, // £34.5m
      unrealized_gains_gbp: 142000000, // £142m
      gross_revenue_gbp: 194700000,
      management_expenses_gbp: 7200000, // £7.2m operating cost
      finance_costs_gbp: 1100000,
      profit_before_tax_gbp: 186400000,
      taxation_gbp: 2800000,
      net_profit_gbp: 183600000,
    },
    cash_flow: {
      operating_cash_flow_gbp: 11000000,
      investing_cash_flow_gbp: -45000000,
      financing_cash_flow_gbp: -12000000, // dividend paid to shareholders
      net_cash_change_gbp: -46000000,
    },
  };
}

export function generateAnnualReportSummary(state: AccountingState) {
  const { nav_metrics } = calculateNavMetrics(state);

  return {
    title: 'RHINO GLOBAL HOLDINGS PLC - ANNUAL REPORT & ACCOUNTS',
    disclaimer: 'SYNTHETIC / SIMULATED DOCUMENT FOR RHINO GLOBAL HOLDINGS PLC DIGITAL TWIN',
    chairmans_statement: `
During the fiscal period, Rhino Global Holdings PLC maintained its disciplined capital allocation strategy, focusing on concentrated long-term ownership of world-leading technology, energy, and financial equity platforms. Total Net Asset Value (NAV) reached £${(nav_metrics.total_nav_gbp / 1e9).toFixed(2)}bn (£${nav_metrics.nav_per_share_gbp.toFixed(2)} per share). Our synthetic portfolio holdings demonstrated resilient operating performance, driven by strength in AI semiconductor infrastructure and cloud architecture.
    `,
    capital_allocation_strategy: `
Rhino Global operates as an active British investment holding company. We prioritize value creation through three key levers:
1. Selective rebalancing into high-conviction global equity compounding platforms.
2. Opportunistic RHG share buybacks whenever our shares trade at an unjustified discount to corporate NAV.
3. Strict dividend cover discipline ensuring sustainable shareholder distribution.
    `,
  };
}
