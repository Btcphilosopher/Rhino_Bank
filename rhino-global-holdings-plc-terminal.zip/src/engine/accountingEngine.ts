import {
  SyntheticEquity,
  PortfolioHolding,
  RhinoNavMetrics,
  RhinoCapitalStructure,
  NavWaterfallItem,
  Currency,
} from '../types/rhino';
import { INITIAL_UNDERLYING_EQUITIES, DEFAULT_ALLOCATION_WEIGHTS, INITIAL_FX_RATES } from './underlyingHoldings';

export interface AccountingState {
  equities: Record<string, SyntheticEquity>;
  weights: Record<string, number>;
  fx_rates: Record<string, number>; // Local currency -> GBP rate
  cash_gbp: number;
  other_assets_gbp: number;
  liabilities_gbp: number;
  capital_structure: RhinoCapitalStructure;
  rhg_share_price_gbp: number;
  opening_nav_gbp: number;
  history: Array<{
    timestamp: string;
    nav_gbp: number;
    nav_per_share: number;
    rhg_price: number;
    premium_discount_pct: number;
    portfolio_value_gbp: number;
  }>;
}

export function createInitialAccountingState(): AccountingState {
  const initialShares = 200000000; // 200m RHG shares
  const initialNavGbp = 2500000000; // £2.5bn target initial portfolio
  const initialCashGbp = 85000000; // £85m cash

  const capital_structure: RhinoCapitalStructure = {
    shares_authorised: 500000000,
    shares_issued: 200000000,
    shares_outstanding: 200000000,
    treasury_shares: 0,
    share_price_gbp: 12.85, // Market price per share (£12.85)
    market_cap_gbp: 12.85 * 200000000,
  };

  const state: AccountingState = {
    equities: { ...INITIAL_UNDERLYING_EQUITIES },
    weights: { ...DEFAULT_ALLOCATION_WEIGHTS },
    fx_rates: { ...INITIAL_FX_RATES },
    cash_gbp: initialCashGbp,
    other_assets_gbp: 15000000,
    liabilities_gbp: 25000000,
    capital_structure,
    rhg_share_price_gbp: 12.85,
    opening_nav_gbp: 2450000000,
    history: [],
  };

  // Generate 30 days history seed
  const history = [];
  let simulatedNav = 2400000000;
  let simulatedPrice = 12.10;
  const now = new Date();

  for (let i = 30; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 24 * 3600 * 1000);
    simulatedNav = simulatedNav * (1 + (Math.sin(i * 0.4) * 0.008 + 0.0015));
    const navPerShare = simulatedNav / initialShares;
    simulatedPrice = navPerShare * (1 + (Math.cos(i * 0.3) * 0.025 + 0.015)); // slight premium
    
    history.push({
      timestamp: d.toISOString().split('T')[0],
      nav_gbp: simulatedNav,
      nav_per_share: navPerShare,
      rhg_price: simulatedPrice,
      premium_discount_pct: ((simulatedPrice - navPerShare) / navPerShare) * 100,
      portfolio_value_gbp: simulatedNav - initialCashGbp,
    });
  }

  state.history = history;
  return state;
}

export function calculatePortfolioHoldings(
  equities: Record<string, SyntheticEquity>,
  weights: Record<string, number>,
  fx_rates: Record<string, number>,
  target_total_portfolio_value_gbp: number
): { holdings: PortfolioHolding[]; portfolio_market_value_gbp: number } {
  let total_market_value = 0;
  const holdings: PortfolioHolding[] = [];

  // Calculate market value per holding based on weights
  Object.keys(weights).forEach((ticker) => {
    const eq = equities[ticker];
    if (!eq) return;

    const target_weight = weights[ticker];
    const holding_value_gbp = target_total_portfolio_value_gbp * target_weight;
    
    // FX conversion for price
    const fx_rate = fx_rates[`${eq.currency}_GBP`] || 1.0;
    const price_gbp = eq.currency === 'GBP' ? eq.price_local : eq.price_local * fx_rate;
    
    // Number of shares held
    const quantity = Math.floor(holding_value_gbp / Math.max(0.01, price_gbp));
    const actual_market_value_gbp = quantity * price_gbp;

    total_market_value += actual_market_value_gbp;

    // Returns
    const local_ret = eq.change_1d_pct;
    const fx_ret = eq.currency === 'GBP' ? 0 : eq.fx_change_1d_pct;
    // Total GBP Return ≈ Local Return + FX Return + (Local * FX)
    const gbp_ret = local_ret + fx_ret + (local_ret * fx_ret) / 100;

    holdings.push({
      ticker,
      name: eq.company_name,
      weight: target_weight,
      target_weight,
      quantity,
      market_value_gbp: actual_market_value_gbp,
      unrealized_pnl_gbp: actual_market_value_gbp * (gbp_ret / 100),
      contribution_bps: (target_weight * gbp_ret * 100), // bps
      local_return_pct: local_ret,
      fx_return_pct: fx_ret,
      gbp_return_pct: gbp_ret,
    });
  });

  // Re-normalize weights to actual market values
  holdings.forEach((h) => {
    if (total_market_value > 0) {
      h.weight = h.market_value_gbp / total_market_value;
    }
  });

  return { holdings, portfolio_market_value_gbp: total_market_value };
}

export function calculateNavMetrics(state: AccountingState): {
  nav_metrics: RhinoNavMetrics;
  holdings: PortfolioHolding[];
} {
  // Estimated base portfolio value (say £2.42bn)
  const base_portfolio_target = state.history.length > 0 
    ? state.history[state.history.length - 1].portfolio_value_gbp 
    : 2420000000;

  const { holdings, portfolio_market_value_gbp } = calculatePortfolioHoldings(
    state.equities,
    state.weights,
    state.fx_rates,
    base_portfolio_target
  );

  const total_nav_gbp = 
    portfolio_market_value_gbp +
    state.cash_gbp +
    state.other_assets_gbp -
    state.liabilities_gbp;

  const shares_out = Math.max(1, state.capital_structure.shares_outstanding);
  const nav_per_share_gbp = total_nav_gbp / shares_out;

  const premium_discount_pct = 
    ((state.rhg_share_price_gbp - nav_per_share_gbp) / nav_per_share_gbp) * 100;

  const nav_metrics: RhinoNavMetrics = {
    portfolio_market_value_gbp,
    cash_gbp: state.cash_gbp,
    other_assets_gbp: state.other_assets_gbp,
    liabilities_gbp: state.liabilities_gbp,
    total_nav_gbp,
    nav_per_share_gbp,
    rhg_share_price_gbp: state.rhg_share_price_gbp,
    premium_discount_pct,
    opening_nav_gbp: state.opening_nav_gbp,
  };

  return { nav_metrics, holdings };
}

export function generateNavWaterfall(
  state: AccountingState,
  holdings: PortfolioHolding[]
): NavWaterfallItem[] {
  const items: NavWaterfallItem[] = [];

  let current_running = state.opening_nav_gbp;

  items.push({
    category: 'Opening NAV',
    amount_gbp: state.opening_nav_gbp,
    bps_impact: 0,
    type: 'OPENING',
  });

  // Each holding contribution
  holdings.forEach((h) => {
    const amount = h.unrealized_pnl_gbp;
    const bps = (amount / state.opening_nav_gbp) * 10000;
    items.push({
      category: h.ticker,
      amount_gbp: amount,
      bps_impact: bps,
      type: 'HOLDING',
    });
    current_running += amount;
  });

  // FX Impact aggregate
  const total_fx_gbp = holdings.reduce((acc, h) => acc + (h.market_value_gbp * (h.fx_return_pct / 100)), 0);
  items.push({
    category: 'FX Movement (USD/GBP)',
    amount_gbp: total_fx_gbp,
    bps_impact: (total_fx_gbp / state.opening_nav_gbp) * 10000,
    type: 'FX',
  });

  // Dividend Income
  const dividend_inc_gbp = 4200000; // £4.2m
  items.push({
    category: 'Dividends Received',
    amount_gbp: dividend_inc_gbp,
    bps_impact: (dividend_inc_gbp / state.opening_nav_gbp) * 10000,
    type: 'DIVIDEND',
  });

  // Management & Admin Costs
  const admin_costs_gbp = -1800000; // -£1.8m
  items.push({
    category: 'Operating Costs & Fees',
    amount_gbp: admin_costs_gbp,
    bps_impact: (admin_costs_gbp / state.opening_nav_gbp) * 10000,
    type: 'COST',
  });

  // Closing NAV
  const { nav_metrics } = calculateNavMetrics(state);
  items.push({
    category: 'Closing Corporate NAV',
    amount_gbp: nav_metrics.total_nav_gbp,
    bps_impact: ((nav_metrics.total_nav_gbp - state.opening_nav_gbp) / state.opening_nav_gbp) * 10000,
    type: 'CLOSING',
  });

  return items;
}
