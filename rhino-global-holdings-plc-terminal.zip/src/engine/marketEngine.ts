import { OrderBook, OrderBookEntry, MarketMakerQuote } from '../types/rhino';

export interface SyntheticMarketState {
  orderbook: OrderBook;
  market_makers: MarketMakerQuote[];
  sentiment_index: number; // 0.0 (bearish) to 1.0 (bullish), default 0.52
  discount_regime: 'PREMIUM' | 'PAR' | 'DISCOUNT';
  recent_trades: Array<{
    id: string;
    price: number;
    quantity: number;
    side: 'BUY' | 'SELL';
    timestamp: string;
  }>;
}

export function createInitialMarketState(initial_rhg_price: number, nav_per_share: number): SyntheticMarketState {
  const bids: OrderBookEntry[] = [
    { id: 'b1', price: Number((initial_rhg_price - 0.02).toFixed(2)), quantity: 25000, type: 'BID', trader_type: 'MARKET_MAKER', timestamp: new Date().toISOString() },
    { id: 'b2', price: Number((initial_rhg_price - 0.05).toFixed(2)), quantity: 40000, type: 'BID', trader_type: 'INSTITUTIONAL', timestamp: new Date().toISOString() },
    { id: 'b3', price: Number((initial_rhg_price - 0.08).toFixed(2)), quantity: 75000, type: 'BID', trader_type: 'INSTITUTIONAL', timestamp: new Date().toISOString() },
    { id: 'b4', price: Number((initial_rhg_price - 0.12).toFixed(2)), quantity: 120000, type: 'BID', trader_type: 'RETAIL', timestamp: new Date().toISOString() },
  ];

  const asks: OrderBookEntry[] = [
    { id: 'a1', price: Number((initial_rhg_price + 0.02).toFixed(2)), quantity: 22000, type: 'ASK', trader_type: 'MARKET_MAKER', timestamp: new Date().toISOString() },
    { id: 'a2', price: Number((initial_rhg_price + 0.06).toFixed(2)), quantity: 50000, type: 'ASK', trader_type: 'INSTITUTIONAL', timestamp: new Date().toISOString() },
    { id: 'a3', price: Number((initial_rhg_price + 0.10).toFixed(2)), quantity: 80000, type: 'ASK', trader_type: 'RETAIL', timestamp: new Date().toISOString() },
    { id: 'a4', price: Number((initial_rhg_price + 0.15).toFixed(2)), quantity: 150000, type: 'ASK', trader_type: 'INSTITUTIONAL', timestamp: new Date().toISOString() },
  ];

  const spread = Number((asks[0].price - bids[0].price).toFixed(2));

  const market_makers: MarketMakerQuote[] = [
    {
      mm_id: 'MM_PEEL_HUNT_SYNTHETIC',
      bid: Number((initial_rhg_price - 0.02).toFixed(2)),
      ask: Number((initial_rhg_price + 0.02).toFixed(2)),
      bid_size: 25000,
      ask_size: 22000,
      inventory_rhg: 1450000,
      risk_status: 'BALANCED',
    },
    {
      mm_id: 'MM_BARCLAYS_CAPITAL_SYNTHETIC',
      bid: Number((initial_rhg_price - 0.03).toFixed(2)),
      ask: Number((initial_rhg_price + 0.03).toFixed(2)),
      bid_size: 35000,
      ask_size: 30000,
      inventory_rhg: 2100000,
      risk_status: 'LOW_RISK',
    },
  ];

  return {
    orderbook: {
      bids,
      asks,
      last_price: initial_rhg_price,
      vwap: initial_rhg_price,
      spread,
      volume_24h: 1420000, // 1.42m shares
    },
    market_makers,
    sentiment_index: 0.54,
    discount_regime: initial_rhg_price >= nav_per_share ? 'PREMIUM' : 'DISCOUNT',
    recent_trades: [
      { id: 't1', price: initial_rhg_price, quantity: 5000, side: 'BUY', timestamp: new Date(Date.now() - 120000).toISOString() },
      { id: 't2', price: Number((initial_rhg_price - 0.01).toFixed(2)), quantity: 12000, side: 'SELL', timestamp: new Date(Date.now() - 60000).toISOString() },
    ],
  };
}

export function simulatePriceDiscovery(
  marketState: SyntheticMarketState,
  nav_per_share: number,
  order_flow_delta: number // positive = net buy pressure, negative = net sell
): {
  new_rhg_price: number;
  updatedMarketState: SyntheticMarketState;
} {
  // Fundamental NAV anchor
  const nav_anchor = nav_per_share;

  // Sentiment effect
  const sentiment_multiplier = (marketState.sentiment_index - 0.5) * 0.04;

  // Microstructure flow effect
  const flow_multiplier = (order_flow_delta / 100000) * 0.015;

  // Current market price
  const current_price = marketState.orderbook.last_price;

  // Mean reversion to NAV + flow + sentiment
  const target_price = nav_anchor * (1 + sentiment_multiplier) + flow_multiplier;
  
  // Smooth adjustment
  const new_price = Number((current_price * 0.85 + target_price * 0.15).toFixed(2));

  // Re-quote Market Maker
  const new_bids: OrderBookEntry[] = [
    { id: `b_${Date.now()}_1`, price: Number((new_price - 0.02).toFixed(2)), quantity: 30000, type: 'BID', trader_type: 'MARKET_MAKER', timestamp: new Date().toISOString() },
    { id: `b_${Date.now()}_2`, price: Number((new_price - 0.05).toFixed(2)), quantity: 50000, type: 'BID', trader_type: 'INSTITUTIONAL', timestamp: new Date().toISOString() },
    { id: `b_${Date.now()}_3`, price: Number((new_price - 0.09).toFixed(2)), quantity: 90000, type: 'BID', trader_type: 'RETAIL', timestamp: new Date().toISOString() },
  ];

  const new_asks: OrderBookEntry[] = [
    { id: `a_${Date.now()}_1`, price: Number((new_price + 0.02).toFixed(2)), quantity: 28000, type: 'ASK', trader_type: 'MARKET_MAKER', timestamp: new Date().toISOString() },
    { id: `a_${Date.now()}_2`, price: Number((new_price + 0.06).toFixed(2)), quantity: 60000, type: 'ASK', trader_type: 'INSTITUTIONAL', timestamp: new Date().toISOString() },
    { id: `a_${Date.now()}_3`, price: Number((new_price + 0.11).toFixed(2)), quantity: 100000, type: 'ASK', trader_type: 'RETAIL', timestamp: new Date().toISOString() },
  ];

  const updatedMarketState: SyntheticMarketState = {
    ...marketState,
    discount_regime: new_price >= nav_per_share ? 'PREMIUM' : 'DISCOUNT',
    orderbook: {
      bids: new_bids,
      asks: new_asks,
      last_price: new_price,
      vwap: Number(((marketState.orderbook.vwap * 0.9) + (new_price * 0.1)).toFixed(2)),
      spread: Number((new_asks[0].price - new_bids[0].price).toFixed(2)),
      volume_24h: marketState.orderbook.volume_24h + Math.abs(order_flow_delta),
    },
    market_makers: marketState.market_makers.map((mm) => ({
      ...mm,
      bid: Number((new_price - 0.02).toFixed(2)),
      ask: Number((new_price + 0.02).toFixed(2)),
    })),
  };

  return { new_rhg_price: new_price, updatedMarketState };
}
