import {
  StressScenarioResult,
  MonteCarloSimulationResult,
  FactorExposure,
  RiskMetrics,
} from '../types/rhino';
import { AccountingState, calculateNavMetrics } from './accountingEngine';

export const FACTOR_EXPOSURES: FactorExposure[] = [
  { factor: 'MARKET (EQUITY BETA)', exposure: 0.88, benchmark_exposure: 1.00 },
  { factor: 'GROWTH', exposure: 0.65, benchmark_exposure: 0.20 },
  { factor: 'QUALITY', exposure: 0.72, benchmark_exposure: 0.40 },
  { factor: 'SEMICONDUCTORS & HARDWARE', exposure: 0.42, benchmark_exposure: 0.12 },
  { factor: 'VALUE', exposure: -0.15, benchmark_exposure: 0.10 },
  { factor: 'ENERGY & COMMODITIES', exposure: 0.08, benchmark_exposure: 0.06 },
  { factor: 'FINANCIALS & CREDIT', exposure: 0.11, benchmark_exposure: 0.15 },
  { factor: 'MOMENTUM', exposure: 0.48, benchmark_exposure: 0.25 },
];

export const CORRELATION_TICKERS = ['GOOGL', 'NFLX', 'UBER', 'NVDA', 'BP', 'IBM', 'MU', 'AXP', 'AAPL', 'INTC', 'STRC'];

export const CORRELATION_MATRIX: Record<string, Record<string, number>> = {
  GOOGL: { GOOGL: 1.0, NFLX: 0.58, UBER: 0.52, NVDA: 0.68, BP: 0.12, IBM: 0.42, MU: 0.61, AXP: 0.48, AAPL: 0.72, INTC: 0.55, STRC: 0.25 },
  NFLX: { GOOGL: 0.58, NFLX: 1.0, UBER: 0.46, NVDA: 0.54, BP: 0.08, IBM: 0.35, MU: 0.49, AXP: 0.41, AAPL: 0.59, INTC: 0.42, STRC: 0.20 },
  UBER: { GOOGL: 0.52, NFLX: 0.46, UBER: 1.0, NVDA: 0.51, BP: 0.22, IBM: 0.38, MU: 0.47, AXP: 0.58, AAPL: 0.53, INTC: 0.44, STRC: 0.30 },
  NVDA: { GOOGL: 0.68, NFLX: 0.54, UBER: 0.51, NVDA: 1.0, BP: 0.05, IBM: 0.48, MU: 0.82, AXP: 0.42, AAPL: 0.66, INTC: 0.74, STRC: 0.18 },
  BP: { GOOGL: 0.12, NFLX: 0.08, UBER: 0.22, NVDA: 0.05, BP: 1.0, IBM: 0.28, MU: 0.15, AXP: 0.35, AAPL: 0.18, INTC: 0.19, STRC: 0.32 },
  IBM: { GOOGL: 0.42, NFLX: 0.35, UBER: 0.38, NVDA: 0.48, BP: 0.28, IBM: 1.0, MU: 0.45, AXP: 0.49, AAPL: 0.46, INTC: 0.52, STRC: 0.40 },
  MU: { GOOGL: 0.61, NFLX: 0.49, UBER: 0.47, NVDA: 0.82, BP: 0.15, IBM: 0.45, MU: 1.0, AXP: 0.44, AAPL: 0.60, INTC: 0.78, STRC: 0.22 },
  AXP: { GOOGL: 0.48, NFLX: 0.41, UBER: 0.58, NVDA: 0.42, BP: 0.35, IBM: 0.49, MU: 0.44, AXP: 1.0, AAPL: 0.51, INTC: 0.46, STRC: 0.38 },
  AAPL: { GOOGL: 0.72, NFLX: 0.59, UBER: 0.53, NVDA: 0.66, BP: 0.18, IBM: 0.46, MU: 0.60, AXP: 0.51, AAPL: 1.0, INTC: 0.58, STRC: 0.28 },
  INTC: { GOOGL: 0.55, NFLX: 0.42, UBER: 0.44, NVDA: 0.74, BP: 0.19, IBM: 0.52, MU: 0.78, AXP: 0.46, AAPL: 0.58, INTC: 1.0, STRC: 0.24 },
  STRC: { GOOGL: 0.25, NFLX: 0.20, UBER: 0.30, NVDA: 0.18, BP: 0.32, IBM: 0.40, MU: 0.22, AXP: 0.38, AAPL: 0.28, INTC: 0.24, STRC: 1.0 },
};

export function calculateRiskMetrics(state: AccountingState): RiskMetrics {
  const { nav_metrics, holdings } = calculateNavMetrics(state);

  // Top holdings concentration
  const sorted = [...holdings].sort((a, b) => b.weight - a.weight);
  const largest_holding_weight = sorted[0]?.weight ?? 0;
  const top_3_concentration = sorted.slice(0, 3).reduce((acc, h) => acc + h.weight, 0);
  const top_5_concentration = sorted.slice(0, 5).reduce((acc, h) => acc + h.weight, 0);

  // Herfindahl-Hirschman Index (HHI)
  const hhi = holdings.reduce((acc, h) => acc + (h.weight * h.weight * 10000), 0);
  const effective_n = hhi > 0 ? 10000 / hhi : 11;

  // Portfolio volatility (weighted average + correlation factor)
  const base_vol = holdings.reduce((acc, h) => {
    const eq = state.equities[h.ticker];
    return acc + (h.weight * (eq?.volatility ?? 0.20));
  }, 0) * 0.92; // slight diversification benefit

  const var_95 = nav_metrics.total_nav_gbp * base_vol * 1.645 * (1 / Math.sqrt(252));
  const var_99 = nav_metrics.total_nav_gbp * base_vol * 2.326 * (1 / Math.sqrt(252));
  const expected_shortfall = var_95 * 1.25;

  return {
    portfolio_volatility_annualized: base_vol,
    portfolio_beta_ftse100: 0.82,
    portfolio_beta_sp500: 1.04,
    var_95_daily_gbp: var_95,
    var_99_daily_gbp: var_99,
    expected_shortfall_95_gbp: expected_shortfall,
    max_historical_drawdown_pct: 18.4,
    hhi_concentration_index: Math.round(hhi),
    effective_number_holdings: Number(effective_n.toFixed(1)),
    largest_holding_weight,
    top_3_concentration,
    top_5_concentration,
  };
}

export function runStressScenario(
  scenario_type: 'technology_crash' | 'energy_shock' | 'global_recession' | 'semiconductor_cycle' | 'fx_shock_gbp_strong' | 'fx_shock_gbp_weak',
  state: AccountingState
): StressScenarioResult {
  const { nav_metrics, holdings } = calculateNavMetrics(state);

  const price_shocks: Record<string, number> = {
    GOOGL: 0, NFLX: 0, UBER: 0, NVDA: 0, BP: 0, IBM: 0, MU: 0, AXP: 0, AAPL: 0, INTC: 0, STRC: 0
  };

  let scenario_name = 'Custom Shock';

  if (scenario_type === 'technology_crash') {
    scenario_name = 'Technology Sector Crash (-35% Semi / -20% Big Tech)';
    price_shocks.NVDA = -0.35;
    price_shocks.MU = -0.40;
    price_shocks.INTC = -0.35;
    price_shocks.AAPL = -0.20;
    price_shocks.GOOGL = -0.20;
    price_shocks.NFLX = -0.18;
    price_shocks.IBM = -0.10;
    price_shocks.UBER = -0.15;
  } else if (scenario_type === 'energy_shock') {
    scenario_name = 'Energy Crisis Shock (BP +30%, Tech Inflation Drag)';
    price_shocks.BP = 0.30;
    price_shocks.GOOGL = -0.08;
    price_shocks.AAPL = -0.08;
    price_shocks.NVDA = -0.10;
    price_shocks.AXP = -0.05;
    price_shocks.STRC = 0.05;
  } else if (scenario_type === 'global_recession') {
    scenario_name = 'Global Stagflation Recession';
    price_shocks.UBER = -0.25;
    price_shocks.AXP = -0.20;
    price_shocks.NFLX = -0.15;
    price_shocks.AAPL = -0.15;
    price_shocks.GOOGL = -0.12;
    price_shocks.BP = -0.10;
    price_shocks.MU = -0.22;
  } else if (scenario_type === 'semiconductor_cycle') {
    scenario_name = 'Semiconductor Downturn Cycle';
    price_shocks.NVDA = -0.30;
    price_shocks.MU = -0.35;
    price_shocks.INTC = -0.25;
    price_shocks.AAPL = -0.08;
  } else if (scenario_type === 'fx_shock_gbp_strong') {
    scenario_name = 'GBP Appreciation Shock (+10% Sterling Surge)';
    // All USD holdings lose 10% value in GBP terms
    holdings.forEach(h => {
      const eq = state.equities[h.ticker];
      if (eq?.currency === 'USD') price_shocks[h.ticker] = -0.10;
    });
  } else if (scenario_type === 'fx_shock_gbp_weak') {
    scenario_name = 'GBP Depreciation Shock (-10% Sterling Devaluation)';
    holdings.forEach(h => {
      const eq = state.equities[h.ticker];
      if (eq?.currency === 'USD') price_shocks[h.ticker] = +0.10;
    });
  }

  let total_nav_impact_gbp = 0;
  const holding_impacts: StressScenarioResult['holding_impacts'] = [];

  holdings.forEach((h) => {
    const shock = price_shocks[h.ticker] ?? 0;
    const value_change = h.market_value_gbp * shock;
    total_nav_impact_gbp += value_change;

    holding_impacts.push({
      ticker: h.ticker,
      price_change_pct: shock * 100,
      value_change_gbp: value_change,
    });
  });

  const nav_impact_pct = (total_nav_impact_gbp / nav_metrics.total_nav_gbp) * 100;
  // RHG price usually moves ~1.15x NAV in acute stress
  const rhg_price_impact_pct = nav_impact_pct * 1.15;

  return {
    scenario_id: scenario_type,
    scenario_name,
    nav_impact_gbp: total_nav_impact_gbp,
    nav_impact_pct,
    rhg_price_impact_pct,
    holding_impacts,
  };
}

export function runMonteCarloSimulation(
  state: AccountingState,
  num_simulations: number = 2000,
  horizon_days: number = 252
): MonteCarloSimulationResult {
  const { nav_metrics } = calculateNavMetrics(state);
  const initial_nav = nav_metrics.total_nav_gbp;
  const risk = calculateRiskMetrics(state);
  const vol = risk.portfolio_volatility_annualized;
  const mu = 0.08; // 8% expected annual return

  const final_navs: number[] = [];
  const sample_paths: Array<number[]> = [];
  const dt = 1 / 252;

  // Pseudo-random deterministic simulation with seed
  let seed = 42;
  function randomNormal() {
    let u = 0, v = 0;
    while (u === 0) u = (Math.sin(seed++) + 1) / 2;
    while (v === 0) v = (Math.cos(seed++) + 1) / 2;
    return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  }

  for (let sim = 0; sim < num_simulations; sim++) {
    let current = initial_nav;
    const save_path = sim < 15;
    const path: number[] = save_path ? [current] : [];

    for (let day = 1; day <= horizon_days; day++) {
      const z = randomNormal();
      const return_daily = (mu - 0.5 * vol * vol) * dt + vol * Math.sqrt(dt) * z;
      current = current * Math.exp(return_daily);
      if (save_path && day % 12 === 0) {
        path.push(current);
      }
    }

    final_navs.push(current);
    if (save_path) sample_paths.push(path);
  }

  final_navs.sort((a, b) => a - b);

  const mean_nav_gbp = final_navs.reduce((a, b) => a + b, 0) / final_navs.length;
  const median_nav_gbp = final_navs[Math.floor(final_navs.length / 2)];
  const p5 = final_navs[Math.floor(final_navs.length * 0.05)];
  const p95 = final_navs[Math.floor(final_navs.length * 0.95)];

  const var_95_gbp = initial_nav - p5;
  const cvar_95_gbp = initial_nav - (final_navs.slice(0, Math.floor(final_navs.length * 0.05)).reduce((a, b) => a + b, 0) / Math.floor(final_navs.length * 0.05));

  return {
    simulations_run: num_simulations,
    time_horizon_days: horizon_days,
    mean_nav_gbp,
    median_nav_gbp,
    percentile_5th_gbp: p5,
    percentile_95th_gbp: p95,
    var_95_gbp,
    cvar_95_gbp,
    paths: sample_paths,
  };
}
