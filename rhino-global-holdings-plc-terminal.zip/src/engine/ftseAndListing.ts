import { FtseEligibilityReport, ListingStage } from '../types/rhino';
import { AccountingState, calculateNavMetrics } from './accountingEngine';

export function evaluateFtseEligibility(state: AccountingState): FtseEligibilityReport {
  const { nav_metrics } = calculateNavMetrics(state);

  const market_cap_gbp = nav_metrics.rhg_share_price_gbp * state.capital_structure.shares_outstanding;
  
  // Approximate UK Market Cap ranking (e.g. £2.5bn market cap is approx rank ~42-55 in UK universe)
  const market_cap_rank = Math.floor(120 - (market_cap_gbp / 3000000000) * 80);
  const free_float_pct = 78.5; // 78.5% free float
  
  const liquidity_pass = true;
  const uk_incorporation_pass = true;
  const listing_category = 'UK Equity Commercial Companies (Equity Shares / Investment Holding)';

  const eligible_ftse_100 = market_cap_rank <= 90; // Top 90 automatic / top 110 buffer
  const eligible_ftse_250 = !eligible_ftse_100 && market_cap_rank <= 350;

  const reasons: string[] = [
    `Simulated Market Cap of £${(market_cap_gbp / 1e9).toFixed(2)}bn places RHG at UK Rank ~${market_cap_rank}.`,
    `Free float of ${free_float_pct}% satisfies the FTSE Russell minimum 25.0% threshold for UK incorporated entities.`,
    `UK incorporation (England & Wales) and LSE Main Market admission satisfy jurisdiction eligibility.`,
    `Liquidity criteria passed: Median daily trading volume exceeds 0.025% of free float shares monthly.`,
    `Note: Modelled simulation based on FTSE UK Index Ground Rules. Subject to quarterly FTSE Russell Index Committee review.`,
  ];

  return {
    ticker: 'RHG',
    company_name: 'RHINO GLOBAL HOLDINGS PLC',
    market_cap_rank,
    free_float_pct,
    liquidity_pass,
    uk_incorporation_pass,
    listing_category,
    eligible_ftse_100,
    eligible_ftse_250,
    projected_index_weight_pct: eligible_ftse_100 ? 0.28 : 0.0,
    reasons,
  };
}
