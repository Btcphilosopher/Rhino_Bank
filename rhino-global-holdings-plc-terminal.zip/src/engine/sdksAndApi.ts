export const PYTHON_SDK_EXAMPLE = `
from rhinoglobal import RhinoGlobal

# Initialize client connected to Rhino Global Holdings PLC API
rhino = RhinoGlobal(api_url="https://api.rhinoglobal.co.uk")

# Fetch live corporate NAV and share price
nav_data = rhino.nav()
print(f"Total Corporate NAV: £{nav_data.total_nav / 1e9:.2f}B")
print(f"NAV per share: £{nav_data.nav_per_share:.2f}")

# Fetch portfolio holdings look-through
holdings = rhino.holdings()
for h in holdings:
    print(f"{h.ticker:<6} Weight: {h.weight*100:4.1f}%  Value: £{h.market_value/1e6:6.1f}M  1D Return: {h.gbp_return:+5.2f}%")

# Check premium/discount to NAV
pd = rhino.premium_discount()
print(f"RHG Market Price: £{pd.rhg_price:.2f} | Premium/Discount: {pd.premium_discount_pct:+.2f}%")

# Execute scenario stress test
scenario = rhino.scenario(name="technology_crash")
print(f"Tech Crash NAV Impact: £{scenario.nav_impact_gbp / 1e6:.1f}M ({scenario.nav_impact_pct:.2f}%)")
`;

export const R_ANALYTICS_EXAMPLE = `
library(rhinoGlobalR)

# Connect to Rhino Global API
client <- RhinoGlobal$new(endpoint = "http://localhost:3000/api")

# Fetch NAV and Attribution
nav <- client$nav()
attr <- client$nav_attribution()

# Plot Waterfall Performance
plot_waterfall(attr)

# Portfolio Correlation Matrix
cor_matrix <- client$correlation()
heatmap(cor_matrix, main = "Rhino Global Portfolio Correlation Matrix")

# Monte Carlo Risk Simulation
sim <- client$monte_carlo(simulations = 10000, horizon_days = 252)
cat(sprintf("95%% Daily VaR: £%.2fM\\n", sim$var_95 / 1e6))
cat(sprintf("95%% Expected Shortfall: £%.2fM\\n", sim$cvar_95 / 1e6))
`;
