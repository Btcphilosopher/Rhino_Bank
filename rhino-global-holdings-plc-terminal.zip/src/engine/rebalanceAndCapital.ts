import { AccountingState, calculateNavMetrics } from './accountingEngine';

export interface RebalanceProposal {
  current_weights: Record<string, number>;
  target_weights: Record<string, number>;
  drifts: Record<string, number>;
  trades: Array<{
    ticker: string;
    action: 'BUY' | 'SELL';
    amount_gbp: number;
    shares: number;
  }>;
  total_turnover_gbp: number;
  estimated_transaction_costs_gbp: number;
  expected_nav_impact_bps: number;
}

export function generateRebalanceProposal(
  state: AccountingState,
  target_weights: Record<string, number>
): RebalanceProposal {
  const { nav_metrics, holdings } = calculateNavMetrics(state);
  const total_portfolio_val = nav_metrics.portfolio_market_value_gbp;

  const current_weights: Record<string, number> = {};
  const drifts: Record<string, number> = {};
  const trades: RebalanceProposal['trades'] = [];
  let total_turnover_gbp = 0;

  holdings.forEach((h) => {
    current_weights[h.ticker] = h.weight;
    const target_w = target_weights[h.ticker] ?? h.weight;
    const drift = h.weight - target_w;
    drifts[h.ticker] = drift;

    const current_val = h.market_value_gbp;
    const target_val = total_portfolio_val * target_w;
    const diff_val = target_val - current_val;

    if (Math.abs(diff_val) > 100000) { // minimum threshold £100k
      const action = diff_val > 0 ? 'BUY' : 'SELL';
      const eq = state.equities[h.ticker];
      const price_gbp = eq ? eq.price_gbp : 1.0;
      const shares = Math.floor(Math.abs(diff_val) / price_gbp);

      trades.push({
        ticker: h.ticker,
        action,
        amount_gbp: Math.abs(diff_val),
        shares,
      });

      total_turnover_gbp += Math.abs(diff_val);
    }
  });

  // Estimated transaction cost (12 bps institutional broker fee + stamp duty for UK)
  const estimated_transaction_costs_gbp = total_turnover_gbp * 0.0012;
  const expected_nav_impact_bps = - (estimated_transaction_costs_gbp / nav_metrics.total_nav_gbp) * 10000;

  return {
    current_weights,
    target_weights,
    drifts,
    trades,
    total_turnover_gbp,
    estimated_transaction_costs_gbp,
    expected_nav_impact_bps,
  };
}

export function executeBuyback(
  state: AccountingState,
  amount_gbp: number
): {
  updatedState: AccountingState;
  shares_repurchased: number;
  nav_per_share_before: number;
  nav_per_share_after: number;
  accretion_pct: number;
} {
  const { nav_metrics } = calculateNavMetrics(state);
  const nav_per_share_before = nav_metrics.nav_per_share_gbp;

  // Execute buyback at current market share price
  const price = state.rhg_share_price_gbp;
  const shares_repurchased = Math.floor(amount_gbp / price);
  const actual_cost_gbp = shares_repurchased * price;

  const new_cash = state.cash_gbp - actual_cost_gbp;
  const new_shares_out = state.capital_structure.shares_outstanding - shares_repurchased;
  const new_treasury = state.capital_structure.treasury_shares + shares_repurchased;

  const updatedState: AccountingState = {
    ...state,
    cash_gbp: new_cash,
    capital_structure: {
      ...state.capital_structure,
      shares_outstanding: new_shares_out,
      treasury_shares: new_treasury,
    },
  };

  const { nav_metrics: new_nav_metrics } = calculateNavMetrics(updatedState);
  const nav_per_share_after = new_nav_metrics.nav_per_share_gbp;
  const accretion_pct = ((nav_per_share_after - nav_per_share_before) / nav_per_share_before) * 100;

  return {
    updatedState,
    shares_repurchased,
    nav_per_share_before,
    nav_per_share_after,
    accretion_pct,
  };
}

export function executeIssuance(
  state: AccountingState,
  shares_to_issue: number,
  issuance_price_gbp: number
): {
  updatedState: AccountingState;
  cash_raised_gbp: number;
  nav_per_share_before: number;
  nav_per_share_after: number;
  dilution_pct: number;
} {
  const { nav_metrics } = calculateNavMetrics(state);
  const nav_per_share_before = nav_metrics.nav_per_share_gbp;

  const cash_raised_gbp = shares_to_issue * issuance_price_gbp;
  const new_cash = state.cash_gbp + cash_raised_gbp;
  const new_shares_out = state.capital_structure.shares_outstanding + shares_to_issue;
  const new_shares_issued = state.capital_structure.shares_issued + shares_to_issue;

  const updatedState: AccountingState = {
    ...state,
    cash_gbp: new_cash,
    capital_structure: {
      ...state.capital_structure,
      shares_issued: new_shares_issued,
      shares_outstanding: new_shares_out,
    },
  };

  const { nav_metrics: new_nav_metrics } = calculateNavMetrics(updatedState);
  const nav_per_share_after = new_nav_metrics.nav_per_share_gbp;
  const dilution_pct = ((nav_per_share_after - nav_per_share_before) / nav_per_share_before) * 100;

  return {
    updatedState,
    cash_raised_gbp,
    nav_per_share_before,
    nav_per_share_after,
    dilution_pct,
  };
}
