from time import perf_counter_ns
from .core import Fill, OrderStatus, Side
from .orderbook import LimitOrderBook


class SimulatedExchange:
    def __init__(self, symbol):
        self.symbol = symbol
        self.book = LimitOrderBook()
        self.orders = {}
        self.fills = []

    def seed_book(self, mid=100, spread=0.10, depth=100):
        self.book.update(Side.BUY, round(mid - spread / 2, 2), depth)
        self.book.update(Side.SELL, round(mid + spread / 2, 2), depth)

    def submit(self, order):
        now = perf_counter_ns()
        order.status = OrderStatus.ACCEPTED
        order.accepted_ns = now
        self.orders[order.order_id] = order

        best_ask = self.book.best_ask()
        best_bid = self.book.best_bid()

        executable = (
            order.side is Side.BUY and best_ask and order.price >= best_ask.price
        ) or (
            order.side is Side.SELL and best_bid and order.price <= best_bid.price
        )

        if not executable:
            return []

        fill_price = best_ask.price if order.side is Side.BUY else best_bid.price
        fill = Fill(
            order_id=order.order_id,
            symbol=order.symbol,
            side=order.side,
            price=fill_price,
            quantity=order.remaining,
            timestamp_ns=now,
        )
        order.filled_quantity += fill.quantity
        order.status = OrderStatus.FILLED
        order.completed_ns = now
        self.fills.append(fill)
        return [fill]

    def cancel(self, order_id):
        order = self.orders.get(order_id)
        if not order or order.status in (OrderStatus.FILLED, OrderStatus.CANCELLED):
            return False
        order.status = OrderStatus.CANCELLED
        order.completed_ns = perf_counter_ns()
        return True
