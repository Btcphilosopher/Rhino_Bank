from dataclasses import dataclass
from .core import Order, OrderType, Side


@dataclass
class MarketMakerConfig:
    quote_size: float = 10
    minimum_spread: float = 0.02
    inventory_skew: float = 0.01
    max_inventory: float = 100


class SimpleMarketMaker:
    def __init__(self, symbol, config=None):
        self.symbol = symbol
        self.config = config or MarketMakerConfig()
        self.inventory = 0
        self._next_order_id = 1

    def _order(self, side, price):
        order = Order(
            order_id=self._next_order_id,
            symbol=self.symbol,
            side=side,
            quantity=self.config.quote_size,
            price=price,
            order_type=OrderType.LIMIT,
        )
        self._next_order_id += 1
        return order

    def quote(self, features):
        if features.mid is None:
            return []

        spread = max(features.spread or 0, self.config.minimum_spread)
        fair = features.microprice or features.mid
        reservation = fair - self.inventory * self.config.inventory_skew
        half = spread / 2

        orders = []
        if self.inventory < self.config.max_inventory:
            orders.append(self._order(Side.BUY, round(reservation - half, 2)))
        if self.inventory > -self.config.max_inventory:
            orders.append(self._order(Side.SELL, round(reservation + half, 2)))
        return orders

    def on_fill(self, side, quantity):
        self.inventory += quantity if side is Side.BUY else -quantity
