from .core import OrderStatus


class OrderManager:
    def __init__(self):
        self.orders = {}

    def register(self, order):
        if order.order_id in self.orders:
            raise ValueError("Duplicate order id")
        self.orders[order.order_id] = order

    def get(self, order_id):
        return self.orders[order_id]

    def active_orders(self):
        return [
            o for o in self.orders.values()
            if o.status in (
                OrderStatus.NEW,
                OrderStatus.ACCEPTED,
                OrderStatus.PARTIALLY_FILLED,
            )
        ]
