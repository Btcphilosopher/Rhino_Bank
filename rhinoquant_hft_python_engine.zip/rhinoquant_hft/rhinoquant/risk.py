from dataclasses import dataclass
from .core import Side


@dataclass
class RiskLimits:
    max_position: float = 1000
    max_order_quantity: float = 100
    max_notional: float = 100000
    max_orders_per_second: int = 50


class RiskEngine:
    def __init__(self, limits=None):
        self.limits = limits or RiskLimits()
        self.position = {}
        self.order_timestamps_ns = []
        self.kill_switch = False

    def set_kill_switch(self, enabled):
        self.kill_switch = enabled

    def update_position(self, symbol, side, quantity):
        signed = quantity if side is Side.BUY else -quantity
        self.position[symbol] = self.position.get(symbol, 0) + signed

    def check(self, order, now_ns):
        if self.kill_switch:
            return False, "GLOBAL_KILL_SWITCH"
        if order.quantity <= 0:
            return False, "INVALID_QUANTITY"
        if order.quantity > self.limits.max_order_quantity:
            return False, "ORDER_SIZE_LIMIT"
        if order.price is not None and order.quantity * order.price > self.limits.max_notional:
            return False, "NOTIONAL_LIMIT"

        current = self.position.get(order.symbol, 0)
        projected = current + (order.quantity if order.side is Side.BUY else -order.quantity)
        if abs(projected) > self.limits.max_position:
            return False, "POSITION_LIMIT"

        cutoff = now_ns - 1_000_000_000
        self.order_timestamps_ns = [x for x in self.order_timestamps_ns if x >= cutoff]
        if len(self.order_timestamps_ns) >= self.limits.max_orders_per_second:
            return False, "ORDER_RATE_LIMIT"

        self.order_timestamps_ns.append(now_ns)
        return True, "OK"
