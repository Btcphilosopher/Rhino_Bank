from dataclasses import dataclass
from collections import deque
from math import log
from .orderbook import LimitOrderBook


@dataclass(frozen=True)
class BookFeatures:
    mid: float | None
    microprice: float | None
    spread: float | None
    imbalance: float | None
    short_return: float | None
    volatility: float | None


class FeatureEngine:
    def __init__(self, window=50):
        self.prices = deque(maxlen=window)

    def update(self, book: LimitOrderBook):
        mid = book.mid()
        if mid is not None:
            self.prices.append(mid)

        short_return = None
        volatility = None

        if len(self.prices) >= 2:
            short_return = self.prices[-1] / self.prices[0] - 1

        if len(self.prices) >= 3:
            returns = [
                log(self.prices[i] / self.prices[i - 1])
                for i in range(1, len(self.prices))
                if self.prices[i - 1] > 0
            ]
            mean = sum(returns) / len(returns)
            volatility = (
                sum((x - mean) ** 2 for x in returns) / len(returns)
            ) ** 0.5

        return BookFeatures(
            mid=mid,
            microprice=book.microprice(),
            spread=book.spread(),
            imbalance=book.imbalance(),
            short_return=short_return,
            volatility=volatility,
        )
