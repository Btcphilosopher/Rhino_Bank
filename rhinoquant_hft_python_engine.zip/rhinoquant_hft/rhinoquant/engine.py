from dataclasses import dataclass
from time import perf_counter_ns
from .core import LatencyTimer, OrderStatus
from .exchange import SimulatedExchange
from .features import FeatureEngine
from .oms import OrderManager
from .risk import RiskEngine
from .strategy import SimpleMarketMaker


@dataclass
class EngineStats:
    market_events: int = 0
    submitted_orders: int = 0
    accepted_orders: int = 0
    fills: int = 0
    rejected_orders: int = 0


class RhinoHFT:
    def __init__(self, symbol="RHINO", strategy_config=None, risk_limits=None):
        self.symbol = symbol
        self.exchange = SimulatedExchange(symbol)
        self.features = FeatureEngine()
        self.strategy = SimpleMarketMaker(symbol, strategy_config)
        self.risk = RiskEngine(risk_limits)
        self.oms = OrderManager()
        self.stats = EngineStats()
        self.market_latency = LatencyTimer()
        self.strategy_latency = LatencyTimer()
        self.risk_latency = LatencyTimer()

    def seed_book(self, mid=100, spread=0.10, depth=100):
        self.exchange.seed_book(mid, spread, depth)

    def on_market_event(self, event):
        self.stats.market_events += 1

        self.market_latency.start()
        self.exchange.book.update(event.side, event.price, event.quantity)
        feature_state = self.features.update(self.exchange.book)
        self.market_latency.stop()

        self.strategy_latency.start()
        orders = self.strategy.quote(feature_state)
        self.strategy_latency.stop()

        fills = []
        for order in orders:
            self.oms.register(order)
            self.stats.submitted_orders += 1

            self.risk_latency.start()
            allowed, _reason = self.risk.check(order, perf_counter_ns())
            self.risk_latency.stop()

            if not allowed:
                order.status = OrderStatus.REJECTED
                self.stats.rejected_orders += 1
                continue

            self.stats.accepted_orders += 1
            order_fills = self.exchange.submit(order)
            fills.extend(order_fills)

            for fill in order_fills:
                self.stats.fills += 1
                self.risk.update_position(fill.symbol, fill.side, fill.quantity)
                self.strategy.on_fill(fill.side, fill.quantity)

        return fills

    def latency_report(self):
        return {
            "market_path": self.market_latency.summary(),
            "strategy_path": self.strategy_latency.summary(),
            "risk_path": self.risk_latency.summary(),
        }
