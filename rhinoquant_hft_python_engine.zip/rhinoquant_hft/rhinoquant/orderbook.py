from dataclasses import dataclass
from collections import defaultdict
from .core import Side


@dataclass(frozen=True)
class PriceLevel:
    price: float
    quantity: float


class LimitOrderBook:
    def __init__(self):
        self.bids = defaultdict(float)
        self.asks = defaultdict(float)

    def update(self, side, price, quantity):
        book = self.bids if side is Side.BUY else self.asks
        if quantity <= 0:
            book.pop(price, None)
        else:
            book[price] = quantity

    def best_bid(self):
        if not self.bids:
            return None
        p = max(self.bids)
        return PriceLevel(p, self.bids[p])

    def best_ask(self):
        if not self.asks:
            return None
        p = min(self.asks)
        return PriceLevel(p, self.asks[p])

    def mid(self):
        bid, ask = self.best_bid(), self.best_ask()
        if bid is None or ask is None:
            return None
        return (bid.price + ask.price) / 2

    def spread(self):
        bid, ask = self.best_bid(), self.best_ask()
        if bid is None or ask is None:
            return None
        return ask.price - bid.price

    def depth(self, side, levels=5):
        book = self.bids if side is Side.BUY else self.asks
        prices = sorted(book, reverse=(side is Side.BUY))[:levels]
        return [PriceLevel(p, book[p]) for p in prices]

    def total_depth(self, side, levels=5):
        return sum(x.quantity for x in self.depth(side, levels))

    def microprice(self):
        bid, ask = self.best_bid(), self.best_ask()
        if bid is None or ask is None:
            return None
        total = bid.quantity + ask.quantity
        if total <= 0:
            return (bid.price + ask.price) / 2
        return (ask.price * bid.quantity + bid.price * ask.quantity) / total

    def imbalance(self, levels=5):
        b = self.total_depth(Side.BUY, levels)
        a = self.total_depth(Side.SELL, levels)
        if b + a == 0:
            return None
        return (b - a) / (b + a)
