from dataclasses import dataclass, field
from enum import Enum
from time import perf_counter_ns
from typing import Optional


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"

    @property
    def opposite(self):
        return Side.SELL if self is Side.BUY else Side.BUY


class OrderType(str, Enum):
    LIMIT = "LIMIT"
    MARKET = "MARKET"


class OrderStatus(str, Enum):
    NEW = "NEW"
    ACCEPTED = "ACCEPTED"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCEL_PENDING = "CANCEL_PENDING"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"


@dataclass(frozen=True)
class MarketEvent:
    symbol: str
    timestamp_ns: int
    kind: str
    price: float
    quantity: float
    side: Optional[Side] = None


@dataclass
class Order:
    order_id: int
    symbol: str
    side: Side
    quantity: float
    price: Optional[float] = None
    order_type: OrderType = OrderType.LIMIT
    status: OrderStatus = OrderStatus.NEW
    filled_quantity: float = 0.0
    created_ns: int = field(default_factory=perf_counter_ns)
    accepted_ns: Optional[int] = None
    completed_ns: Optional[int] = None

    @property
    def remaining(self):
        return max(0.0, self.quantity - self.filled_quantity)


@dataclass(frozen=True)
class Fill:
    order_id: int
    symbol: str
    side: Side
    price: float
    quantity: float
    timestamp_ns: int


class LatencyTimer:
    def __init__(self):
        self.samples_ns = []
        self._start = None

    def start(self):
        self._start = perf_counter_ns()

    def stop(self):
        if self._start is None:
            raise RuntimeError("Timer was not started")
        value = perf_counter_ns() - self._start
        self.samples_ns.append(value)
        self._start = None
        return value

    def summary(self):
        if not self.samples_ns:
            return {}
        values = sorted(self.samples_ns)

        def pct(p):
            idx = min(len(values) - 1, int(round((p / 100) * (len(values) - 1))))
            return values[idx]

        return {
            "count": len(values),
            "min_ns": values[0],
            "max_ns": values[-1],
            "mean_ns": sum(values) / len(values),
            "p50_ns": pct(50),
            "p95_ns": pct(95),
            "p99_ns": pct(99),
        }
