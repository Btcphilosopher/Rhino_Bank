class MarketReplay:
    def __init__(self, events):
        self.events = sorted(events, key=lambda e: e.timestamp_ns)

    def __iter__(self):
        yield from self.events
