from dataclasses import dataclass


@dataclass(frozen=True)
class PerformanceMetrics:
    total_pnl: float
    trades: int
    win_rate: float


def calculate_metrics(pnls):
    if not pnls:
        return PerformanceMetrics(0, 0, 0)
    wins = sum(1 for x in pnls if x > 0)
    return PerformanceMetrics(sum(pnls), len(pnls), wins / len(pnls))
