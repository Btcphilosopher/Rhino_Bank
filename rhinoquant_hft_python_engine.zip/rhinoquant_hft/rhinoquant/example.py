import random
from time import perf_counter_ns
from .core import MarketEvent, Side
from .engine import RhinoHFT


def run_demo():
    random.seed(7)
    engine = RhinoHFT("RHINO")
    engine.seed_book(mid=100, spread=0.10, depth=250)
    base = perf_counter_ns()

    for i in range(500):
        mid = 100 + random.gauss(0, 0.03)
        bid = round(mid - 0.05, 2)
        ask = round(mid + 0.05, 2)

        events = [
            MarketEvent("RHINO", base + i * 1_000_000, "BOOK", bid, random.uniform(50, 300), Side.BUY),
            MarketEvent("RHINO", base + i * 1_000_001, "BOOK", ask, random.uniform(50, 300), Side.SELL),
        ]
        for event in events:
            engine.on_market_event(event)

    print("RhinoQuant HFT — SYNTHETIC SIMULATION")
    print("--------------------------------------")
    print(engine.stats)
    print("Strategy inventory:", engine.strategy.inventory)
    print("Latency:", engine.latency_report())


if __name__ == "__main__":
    run_demo()
