import unittest
from rhinoquant.core import Side
from rhinoquant.orderbook import LimitOrderBook


class OrderBookTests(unittest.TestCase):
    def test_best_prices(self):
        b = LimitOrderBook()
        b.update(Side.BUY, 99, 10)
        b.update(Side.BUY, 100, 20)
        b.update(Side.SELL, 101, 15)
        self.assertEqual(b.best_bid().price, 100)
        self.assertEqual(b.best_ask().price, 101)
        self.assertEqual(b.mid(), 100.5)

    def test_imbalance(self):
        b = LimitOrderBook()
        b.update(Side.BUY, 100, 75)
        b.update(Side.SELL, 101, 25)
        self.assertAlmostEqual(b.imbalance(), 0.5)


if __name__ == "__main__":
    unittest.main()
