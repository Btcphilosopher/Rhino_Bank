import unittest
from rhinoquant.core import Order, Side
from rhinoquant.risk import RiskEngine, RiskLimits


class RiskTests(unittest.TestCase):
    def test_order_size(self):
        r = RiskEngine(RiskLimits(max_order_quantity=10))
        ok, reason = r.check(Order(1, "R", Side.BUY, 11, 100), 1_000_000_000)
        self.assertFalse(ok)
        self.assertEqual(reason, "ORDER_SIZE_LIMIT")

    def test_kill_switch(self):
        r = RiskEngine()
        r.set_kill_switch(True)
        ok, reason = r.check(Order(1, "R", Side.BUY, 1, 100), 1_000_000_000)
        self.assertFalse(ok)
        self.assertEqual(reason, "GLOBAL_KILL_SWITCH")


if __name__ == "__main__":
    unittest.main()
