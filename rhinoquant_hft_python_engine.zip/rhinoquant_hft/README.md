# RhinoQuant HFT — Python Research & Simulation Engine

Modular research/simulation engine for algorithmic and HFT architecture.

Pipeline:
Market data -> Order book -> Features -> Strategy -> Risk -> OMS -> Simulated exchange

This is deliberately a research/simulation implementation. It does not connect to live exchanges or place real orders. Production latency-critical components would normally be implemented in C++/Rust/FPGA, with Python used for research and orchestration.

Run:
    python -m rhinoquant.example

Tests:
    python -m unittest discover -s tests -v

All example market data and fills are synthetic.
