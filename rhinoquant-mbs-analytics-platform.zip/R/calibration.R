# ==============================================================================
# RhinoQuant Prepayment & Default Econometric Calibration Layer
# ==============================================================================

#' Calibrate Richard & Roll 4-Factor Prepayment Parameters using Historical MBS Data
#'
#' @param historical_mbs_df Data frame containing (cpr_obs, wac, mkt_rate, age, month, prior_incentive)
#' @return Calibrated model parameters and regression diagnostics
#' @export
calibrate_prepayment_model <- function(historical_mbs_df) {
  # 1. Compute Refinancing Incentive in basis points
  historical_mbs_df$refi_spread_bps <- (historical_mbs_df$wac - historical_mbs_df$mkt_rate) * 10000
  
  # 2. Estimate S-curve using non-linear least squares (NLS) or Logistic GLM
  fit <- nls(
    cpr_obs ~ turnover + (max_refi / (1 + exp(-k * (refi_spread_bps - center)))) * 
      pmin(age / 30, 1.0) * (1 / (1 + burnout_factor)^1.2),
    data = historical_mbs_df,
    start = list(turnover = 0.06, max_refi = 0.40, k = 0.015, center = 50.0, burnout_factor = 0.0)
  )
  
  summary_fit <- summary(fit)
  
  list(
    parameters = coef(fit),
    residuals = residuals(fit),
    r_squared = 1 - sum(residuals(fit)^2) / sum((historical_mbs_df$cpr_obs - mean(historical_mbs_df$cpr_obs))^2),
    t_statistics = summary_fit$coefficients[, "t value"],
    p_values = summary_fit$coefficients[, "Pr(>|t|)"]
  )
}

#' Calibrate Logistic Hazard Default Model with Macro & Micro Covariates
#'
#' @param loan_level_defaults_df Loan history with default indicator, FICO, LTV, HPI_shock, DTI
#' @return Logistic regression model for monthly conditional default rate (CDR)
#' @export
calibrate_default_hazard_model <- function(loan_level_defaults_df) {
  glm_fit <- glm(
    default_indicator ~ fico_score + current_ltv + dti_ratio + hpi_shock + loan_age,
    data = loan_level_defaults_df,
    family = binomial(link = "logit")
  )
  
  list(
    model = glm_fit,
    aic = AIC(glm_fit),
    coefficients = summary(glm_fit)$coefficients
  )
}
