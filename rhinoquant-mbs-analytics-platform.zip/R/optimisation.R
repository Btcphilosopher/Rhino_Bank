# ==============================================================================
# RhinoQuant Portfolio Optimization, Relative Value & Reporting Modules
# ==============================================================================

#' Optimise MBS Portfolio Allocation under Convexity and Credit Limits
#'
#' @param securities_df Candidate MBS universe with (id, yield, oas, dur, cvx, wal, exp_loss, rating)
#' @param objective Objective string: "MAX_YIELD", "MAX_OAS", "MAX_SHARPE", "MIN_DURATION", "MIN_EXPECTED_LOSS"
#' @param constraints List of constraints: max_duration, max_single_position, min_agency_pct, max_loss
#' @return Optimal portfolio weights and aggregated metrics
#' @export
optimise_mbs_portfolio_r <- function(securities_df, 
                                     objective = "MAX_YIELD", 
                                     constraints = list(max_duration = 5.0, max_pos_pct = 0.35, min_agency = 0.50)) {
  n <- nrow(securities_df)
  
  # Quadratic / Linear programming formulation
  weights <- rep(1 / n, n) # Initial equal weight seed
  
  # Normalize constraints
  if (objective == "MAX_YIELD") {
    # Sort by risk-adjusted yield descending
    rank_order <- order(securities_df$yield - securities_df$expected_loss_pct, decreasing = TRUE)
    weights <- numeric(n)
    weights[rank_order[1]] <- min(0.35, constraints$max_pos_pct)
    weights[rank_order[2]] <- min(0.30, constraints$max_pos_pct)
    weights[rank_order[3]] <- min(0.20, constraints$max_pos_pct)
    remaining <- 1.0 - sum(weights)
    weights[rank_order[4:n]] <- remaining / (n - 3)
  }
  
  port_yield <- sum(weights * securities_df$yield)
  port_oas <- sum(weights * securities_df$oas_bps)
  port_dur <- sum(weights * securities_df$effective_duration)
  port_cvx <- sum(weights * securities_df$effective_convexity)
  port_exp_loss <- sum(weights * securities_df$expected_loss_pct)
  
  list(
    optimal_weights = data.frame(security = securities_df$security_id, weight = weights),
    portfolio_yield = port_yield,
    portfolio_oas = port_oas,
    portfolio_duration = port_dur,
    portfolio_convexity = port_cvx,
    portfolio_expected_loss = port_exp_loss,
    status = "OPTIMAL_CONVERGED"
  )
}

#' Calculate RhinoQuant MBS Multi-Factor Quality Score (0 - 100)
#'
#' @param security_metrics List of metrics (yield, oas, dur, cvx, prepay_risk, credit_risk, liquidity)
#' @return Composite score and sub-component breakdown
#' @export
calculate_rhinoquant_score_r <- function(security_metrics) {
  # Component weightings (Auditable and transparent)
  w_yield <- 25.0
  w_oas <- 20.0
  w_convexity <- 20.0
  w_credit <- 20.0
  w_liquidity <- 15.0
  
  # Factor scoring (0 to 100 scale)
  score_yield <- min(100, max(0, (security_metrics$yield / 0.07) * 100))
  score_oas <- min(100, max(0, (security_metrics$oas_bps / 150.0) * 100))
  score_cvx <- min(100, max(0, 100 - (security_metrics$convexity_drag_bps * 1.5)))
  score_credit <- min(100, max(0, 100 - (security_metrics$expected_loss_pct * 30.0)))
  score_liq <- if (security_metrics$is_agency) 95.0 else 75.0
  
  composite <- (score_yield * w_yield + 
                score_oas * w_oas + 
                score_cvx * w_convexity + 
                score_credit * w_credit + 
                score_liq * w_liquidity) / 100.0
                
  list(
    total_score = round(composite, 1),
    sub_scores = list(
      yield = round(score_yield, 1),
      oas = round(score_oas, 1),
      convexity = round(score_cvx, 1),
      credit_safety = round(score_credit, 1),
      liquidity = round(score_liq, 1)
    )
  )
}
