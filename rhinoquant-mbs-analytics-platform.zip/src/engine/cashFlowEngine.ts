import { 
  MortgagePool, 
  CashFlowSchedule, 
  CashFlowPeriod, 
  PrepaymentConfig, 
  DefaultConfig, 
  YieldCurve 
} from '../types/mbs';
import { PrepaymentEngine } from './prepaymentEngine';
import { DefaultEngine } from './defaultEngine';
import { YieldCurveEngine } from './yieldCurveEngine';

export class CashFlowEngine {
  /**
   * Generate comprehensive monthly cash flow schedule for a Mortgage Pool
   * Reconciles every period:
   * Beginning Balance -> Scheduled Prin -> Prepay Prin -> Defaulted Prin -> Ending Balance
   */
  public static generatePoolCashFlows(
    pool: MortgagePool,
    prepayConfig: PrepaymentConfig,
    defaultConfig: DefaultConfig,
    yieldCurve: YieldCurve,
    pricingSpreadBps: number = 94,
    curveShiftBps: number = 0,
    maxPeriods: number = 360
  ): CashFlowSchedule {
    let balance = pool.currentPoolBalance;
    const wac = pool.weightedAverageCoupon;
    const netWac = pool.weightedAverageNetCoupon;
    const wam = pool.weightedAverageMaturity;
    const wala = pool.weightedAverageLoanAge;
    const servicingFeeRate = Math.max(0.0020, wac - netWac - 0.0025);
    const guaranteeFeeRate = pool.isAgency ? 0.0025 : 0.0;

    const periods: CashFlowPeriod[] = [];
    let totalSchedPrin = 0;
    let totalPrepay = 0;
    let totalDefaults = 0;
    let totalRecoveries = 0;
    let totalRealizedLosses = 0;
    let totalGrossInt = 0;
    let totalNetInt = 0;
    let totalServicing = 0;
    let totalGfee = 0;
    let totalCf = 0;

    let walNumerator = 0;
    let totalPrinReceived = 0;

    let cumulativeBurnoutFactor = 0;
    const initialBalance = balance;

    // Monthly scheduled level payment calculation on current pool
    const monthlyGrossRate = wac / 12;

    for (let period = 1; period <= maxPeriods && balance > 10.0; period++) {
      const currentAge = wala + period - 1;
      const remainingTerm = Math.max(1, wam - period + 1);
      const beginningBalance = balance;

      // 1. Level pay calculation on remaining balance & term
      let scheduledPayment = 0;
      if (monthlyGrossRate > 1e-9) {
        const factor = Math.pow(1 + monthlyGrossRate, remainingTerm);
        scheduledPayment = beginningBalance * (monthlyGrossRate * factor) / (factor - 1);
      } else {
        scheduledPayment = beginningBalance / remainingTerm;
      }

      // 2. Interest component
      const grossInterest = beginningBalance * (wac / 12);
      const servicingFee = beginningBalance * (servicingFeeRate / 12);
      const guaranteeFee = beginningBalance * (guaranteeFeeRate / 12);
      const netInterest = grossInterest - servicingFee - guaranteeFee;

      // 3. Scheduled Principal
      let scheduledPrincipal = scheduledPayment - grossInterest;
      if (scheduledPrincipal < 0) scheduledPrincipal = 0;
      if (scheduledPrincipal > beginningBalance) scheduledPrincipal = beginningBalance;

      const balanceAfterScheduled = beginningBalance - scheduledPrincipal;

      // 4. Prepayment (SMM) on remaining balance
      // Refi incentive accumulates burnout
      const rateDiff = (wac - prepayConfig.marketMortgageRate) * 10000;
      if (rateDiff > 50) {
        cumulativeBurnoutFactor += (rateDiff / 1000) * 0.08;
      }

      const { smm, cpr } = PrepaymentEngine.getPeriodSmm(
        prepayConfig,
        wac,
        currentAge,
        period,
        cumulativeBurnoutFactor
      );

      const prepaymentPrincipal = Math.min(
        balanceAfterScheduled,
        balanceAfterScheduled * smm
      );

      const balanceAfterPrepay = balanceAfterScheduled - prepaymentPrincipal;

      // 5. Defaults & Recoveries (MDR)
      const { mdr, cdr } = DefaultEngine.getPeriodMdr(
        defaultConfig,
        pool.weightedAverageCurrentLtv,
        pool.weightedAverageFico,
        currentAge
      );

      // Agency MBS: Defaults are bought out at par by Fannie/Freddie guarantee, so investor receives par
      let defaultedPrincipal = 0;
      let recoveryCash = 0;
      let realizedLoss = 0;

      if (pool.isAgency) {
        defaultedPrincipal = balanceAfterPrepay * mdr;
        recoveryCash = defaultedPrincipal; // Bought out at par with 0 loss to investor
        realizedLoss = 0;
      } else {
        defaultedPrincipal = balanceAfterPrepay * mdr;
        const avgPropVal = balanceAfterPrepay / (pool.weightedAverageCurrentLtv / 100 || 0.75);
        const recoveryResult = DefaultEngine.calculateNetRecovery(
          defaultConfig,
          defaultedPrincipal,
          avgPropVal * (defaultedPrincipal / (balanceAfterPrepay || 1))
        );
        recoveryCash = recoveryResult.recoveryCash;
        realizedLoss = recoveryResult.realizedLoss;
      }

      const endingBalance = Math.max(0, balanceAfterPrepay - defaultedPrincipal);
      const totalPrincipal = scheduledPrincipal + prepaymentPrincipal + defaultedPrincipal;

      // Total investor cash flow this period
      const netCashFlow = scheduledPrincipal + prepaymentPrincipal + recoveryCash + netInterest;

      // Discount factor & PV
      const tenorYears = period / 12;
      const df = YieldCurveEngine.getDiscountFactor(yieldCurve, tenorYears, pricingSpreadBps, curveShiftBps);
      const pv = netCashFlow * df;

      // Accumulate totals
      totalSchedPrin += scheduledPrincipal;
      totalPrepay += prepaymentPrincipal;
      totalDefaults += defaultedPrincipal;
      totalRecoveries += recoveryCash;
      totalRealizedLosses += realizedLoss;
      totalGrossInt += grossInterest;
      totalNetInt += netInterest;
      totalServicing += servicingFee;
      totalGfee += guaranteeFee;
      totalCf += netCashFlow;

      const principalReturned = scheduledPrincipal + prepaymentPrincipal + recoveryCash;
      totalPrinReceived += principalReturned;
      walNumerator += tenorYears * principalReturned;

      // Format date label (Month 1, Month 2, etc.)
      const d = new Date(2026, 8 + period - 1, 1);
      const monthDate = `${d.toLocaleString('default', { month: 'short' })} ${d.getFullYear()}`;

      periods.push({
        period,
        monthDate,
        beginningBalance,
        scheduledPrincipal,
        prepaymentPrincipal,
        defaultedPrincipal,
        totalPrincipal,
        grossInterest,
        servicingFee,
        guaranteeFee,
        netInterest,
        recoveryCash,
        realizedLoss,
        netCashFlow,
        endingBalance,
        cprApplied: cpr,
        smmApplied: smm,
        cdrApplied: cdr,
        mdrApplied: mdr,
        discountFactor: df,
        presentValue: pv,
      });

      balance = endingBalance;
    }

    const walYears = totalPrinReceived > 0 
      ? walNumerator / totalPrinReceived 
      : (initialBalance > 0 ? walNumerator / initialBalance : 0);

    return {
      periods,
      totalScheduledPrincipal: totalSchedPrin,
      totalPrepayments: totalPrepay,
      totalDefaults: totalDefaults,
      totalRecoveries: totalRecoveries,
      totalRealizedLosses: totalRealizedLosses,
      totalGrossInterest: totalGrossInt,
      totalNetInterest: totalNetInt,
      totalServicingFees: totalServicing,
      totalGuaranteeFees: totalGfee,
      totalCashFlow: totalCf,
      weightedAverageLifeYears: Math.round(walYears * 100) / 100,
    };
  }
}
