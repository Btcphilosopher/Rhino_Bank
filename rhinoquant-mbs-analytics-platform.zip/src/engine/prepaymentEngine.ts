import { PrepaymentConfig, RichardRollParams } from '../types/mbs';

export class PrepaymentEngine {
  /**
   * Convert annual CPR to monthly SMM
   * SMM = 1 - (1 - CPR)^(1/12)
   */
  public static cprToSmm(cpr: number): number {
    if (cpr <= 0) return 0;
    if (cpr >= 1) return 1;
    return 1 - Math.pow(1 - cpr, 1 / 12);
  }

  /**
   * Convert monthly SMM to annual CPR
   * CPR = 1 - (1 - SMM)^12
   */
  public static smmToCpr(smm: number): number {
    if (smm <= 0) return 0;
    if (smm >= 1) return 1;
    return 1 - Math.pow(1 - smm, 12);
  }

  /**
   * Calculate PSA Benchmark CPR
   * 100% PSA = 0.2% * Age up to 30 months (6% max), constant thereafter
   */
  public static calculatePsaCpr(psaSpeedPct: number, loanAgeMonths: number): number {
    const baseCpr = loanAgeMonths <= 30 
      ? 0.06 * (loanAgeMonths / 30) 
      : 0.06;
    return (psaSpeedPct / 100) * baseCpr;
  }

  /**
   * Richard & Roll 4-Factor Behavioral Prepayment Model
   * Factor 1: Refinancing Incentive (Logistic S-Curve)
   * Factor 2: Seasoning Multiplier (Ramp to 30 months)
   * Factor 3: Seasonality (Monthly housing turnover multiplier)
   * Factor 4: Burnout Effect (Borrower fatigue to rate refinancing)
   */
  public static calculateRichardRollCpr(
    params: RichardRollParams,
    wac: number,
    marketRate: number,
    loanAgeMonths: number,
    calendarMonth1to12: number,
    burnoutFactor: number
  ): number {
    // 1. Refi Incentive in bps
    const rateDiffBps = (wac - marketRate) * 10000;
    let refiEffect = 0;
    if (rateDiffBps > -200) {
      const x = (rateDiffBps - 50) / 70;
      const sCurve = 1 / (1 + Math.exp(-x));
      refiEffect = sCurve * params.refinancingIncentiveCoef;
    }

    // 2. Seasoning Multiplier
    const seasoning = loanAgeMonths >= params.seasoningRampMonths
      ? params.maxSeasoningFactor
      : loanAgeMonths / params.seasoningRampMonths;

    // 3. Seasonality
    const monthIdx = ((calendarMonth1to12 - 1) % 12 + 12) % 12;
    const seasonality = params.seasonalityMultipliers[monthIdx] ?? 1.0;

    // 4. Burnout Multiplier
    const burnout = Math.pow(1 / (1 + burnoutFactor), params.burnoutExponent);

    const totalCpr = params.turnoverRate + (refiEffect * seasoning * seasonality * burnout);
    return Math.min(0.85, Math.max(0.01, totalCpr));
  }

  /**
   * Compute monthly SMM for a specific loan/pool period
   */
  public static getPeriodSmm(
    config: PrepaymentConfig,
    wac: number,
    loanAgeMonths: number,
    periodNumber: number,
    burnoutFactor: number = 0
  ): { smm: number; cpr: number } {
    let cpr = 0.06;

    switch (config.modelType) {
      case 'ConstantCPR':
        cpr = config.cprValue;
        break;
      case 'PSA':
        cpr = this.calculatePsaCpr(config.psaSpeed, loanAgeMonths);
        break;
      case 'RichardRoll4Factor': {
        const calMonth = ((periodNumber - 1) % 12) + 1;
        cpr = this.calculateRichardRollCpr(
          config.richardRoll,
          wac,
          config.marketMortgageRate,
          loanAgeMonths,
          calMonth,
          burnoutFactor
        );
        break;
      }
      case 'CustomVector':
      default:
        cpr = config.cprValue;
        break;
    }

    const smm = this.cprToSmm(cpr);
    return { smm, cpr };
  }
}
