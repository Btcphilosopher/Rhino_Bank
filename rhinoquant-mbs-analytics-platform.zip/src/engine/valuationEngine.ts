import { CashFlowSchedule, YieldCurve, MBSValuationResult } from '../types/mbs';
import { YieldCurveEngine } from './yieldCurveEngine';

export class ValuationEngine {
  /**
   * Discount projected cash flows along zero curve + spread
   */
  public static calculatePresentValue(
    schedule: CashFlowSchedule,
    yieldCurve: YieldCurve,
    spreadBps: number = 94,
    curveShiftBps: number = 0
  ): number {
    let pv = 0;
    for (const p of schedule.periods) {
      const t = p.period / 12;
      const df = YieldCurveEngine.getDiscountFactor(yieldCurve, t, spreadBps, curveShiftBps);
      pv += p.netCashFlow * df;
    }
    return pv;
  }

  /**
   * Calculate Yield To Maturity (IRR) via bisection
   */
  public static calculateYtm(
    schedule: CashFlowSchedule,
    targetPv: number
  ): number {
    if (targetPv <= 0 || schedule.periods.length === 0) return 0.0541;

    let low = 0.0001;
    let high = 0.40;
    let ytm = 0.0541;

    for (let iter = 0; iter < 50; iter++) {
      ytm = (low + high) / 2;
      const monthlyY = ytm / 12;
      let pv = 0;

      for (const p of schedule.periods) {
        const df = Math.pow(1 + monthlyY, -p.period);
        pv += p.netCashFlow * df;
      }

      if (Math.abs(pv - targetPv) < 1e-3) break;

      if (pv > targetPv) {
        low = ytm;
      } else {
        high = ytm;
      }
    }

    return Math.round(ytm * 10000) / 10000;
  }

  /**
   * Comprehensive MBS Valuation
   */
  public static valueMbs(
    schedule: CashFlowSchedule,
    yieldCurve: YieldCurve,
    initialBalance: number,
    couponRate: number,
    spreadBps: number = 94,
    daysAccrued: number = 14
  ): MBSValuationResult {
    const pv = this.calculatePresentValue(schedule, yieldCurve, spreadBps);
    const parUnits = initialBalance > 0 ? initialBalance / 100 : 1;
    const dirtyPrice = pv / parUnits;

    // Accrued interest per 100 par
    const accrued = (couponRate / 360) * daysAccrued * 100;
    const cleanPrice = dirtyPrice - accrued;

    const ytm = this.calculateYtm(schedule, pv);
    const benchmark10y = YieldCurveEngine.getZeroRate(yieldCurve, 10);
    const nominalSpread = (ytm - benchmark10y) * 10000;
    const cashOnCash = schedule.totalCashFlow / (initialBalance || 1);

    return {
      presentValue: pv,
      cleanPrice: Math.round(cleanPrice * 1000) / 1000,
      dirtyPrice: Math.round(dirtyPrice * 1000) / 1000,
      accruedInterest: Math.round(accrued * 1000) / 1000,
      yieldToMaturity: ytm,
      nominalSpreadBps: Math.round(nominalSpread * 10) / 10,
      weightedAverageLifeYears: schedule.weightedAverageLifeYears,
      cashOnCashReturn: Math.round(cashOnCash * 1000) / 1000,
      internalRateOfReturn: ytm,
    };
  }
}
