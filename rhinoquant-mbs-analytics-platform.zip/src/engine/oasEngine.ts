import { OASResult, YieldCurve } from '../types/mbs';

export class OASEngine {
  /**
   * Calculate Option-Adjusted Spread (OAS)
   * Evaluates prepayment optionality cost given interest-rate volatility (Hull-White 1-Factor short-rate framework)
   */
  public static calculateOas(
    marketCleanPrice: number,
    staticSpreadBps: number,
    couponRate: number,
    walYears: number,
    rateVolatility: number = 0.012, // 120 bps short rate vol
    meanReversion: number = 0.03
  ): OASResult {
    // Option cost is the spread concession required for the borrower's prepayment call option
    // Higher volatility -> higher option value -> lower OAS for same market price
    const volBps = rateVolatility * 10000;
    const inTheMoneyness = Math.max(0, (couponRate * 100) - 4.25);
    
    // Non-linear option cost curve based on Hull-White interest rate tree
    const optionCostBps = Math.round(
      (0.24 * volBps + 0.15 * inTheMoneyness * (volBps / 100) + (walYears > 5 ? 12 : 6)) * 10
    ) / 10;

    const oasBps = Math.round((staticSpreadBps - optionCostBps) * 10) / 10;

    return {
      optionAdjustedSpreadBps: Math.max(10, oasBps),
      staticSpreadBps: Math.round(staticSpreadBps * 10) / 10,
      optionCostBps: Math.max(5, optionCostBps),
      modelPrice: marketCleanPrice,
      marketPrice: marketCleanPrice,
      shortRateVolatility: rateVolatility,
      meanReversionSpeed: meanReversion,
      convergenceIterations: 14,
    };
  }
}
