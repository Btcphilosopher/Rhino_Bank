import { MortgagePool, MortgageLoan } from '../types/mbs';

export class PoolEngine {
  public static aggregatePool(loans: MortgageLoan[], poolId: string, poolName: string, assetClass: any, issuer: string, isAgency: boolean): MortgagePool {
    let totalOrig = 0;
    let totalCurr = 0;
    let weightedCouponSum = 0;
    let weightedNetCouponSum = 0;
    let weightedWamSum = 0;
    let weightedWalaSum = 0;
    let weightedOrigLtvSum = 0;
    let weightedCurrLtvSum = 0;
    let weightedFicoSum = 0;

    const geoMap: Record<string, number> = {};
    const typeMap: Record<string, number> = {};
    const ficoMap: Record<string, number> = { '<640': 0, '640-699': 0, '700-759': 0, '760+': 0 };
    const ltvMap: Record<string, number> = { '<60%': 0, '60-75%': 0, '75-80%': 0, '>80%': 0 };

    for (const l of loans) {
      const b = l.currentBalance;
      totalOrig += l.originalBalance;
      totalCurr += b;

      weightedCouponSum += l.grossInterestRate * b;
      weightedNetCouponSum += l.netInterestRate * b;
      weightedWamSum += l.remainingTermMonths * b;
      weightedWalaSum += l.ageMonths * b;
      weightedOrigLtvSum += l.originalLtv * b;
      weightedCurrLtvSum += l.currentLtv * b;
      weightedFicoSum += l.borrower.ficoScore * b;

      geoMap[l.geographyState] = (geoMap[l.geographyState] || 0) + b;
      typeMap[l.loanType] = (typeMap[l.loanType] || 0) + b;

      if (l.borrower.ficoScore < 640) ficoMap['<640'] += b;
      else if (l.borrower.ficoScore < 700) ficoMap['640-699'] += b;
      else if (l.borrower.ficoScore < 760) ficoMap['700-759'] += b;
      else ficoMap['760+'] += b;

      if (l.currentLtv < 60) ltvMap['<60%'] += b;
      else if (l.currentLtv <= 75) ltvMap['60-75%'] += b;
      else if (l.currentLtv <= 80) ltvMap['75-80%'] += b;
      else ltvMap['>80%'] += b;
    }

    const denom = totalCurr > 0 ? totalCurr : 1;
    const wac = weightedCouponSum / denom;
    const netWac = weightedNetCouponSum / denom;
    const wam = weightedWamSum / denom;
    const wala = weightedWalaSum / denom;
    const origLtv = weightedOrigLtvSum / denom;
    const currLtv = weightedCurrLtvSum / denom;
    const avgFico = weightedFicoSum / denom;

    // Convert distribution to percentages
    const geoPct: Record<string, number> = {};
    for (const [k, v] of Object.entries(geoMap)) {
      geoPct[k] = Math.round((v / denom) * 1000) / 10;
    }

    const typePct: Record<string, number> = {};
    for (const [k, v] of Object.entries(typeMap)) {
      typePct[k] = Math.round((v / denom) * 1000) / 10;
    }

    const ficoPct: Record<string, number> = {};
    for (const [k, v] of Object.entries(ficoMap)) {
      ficoPct[k] = Math.round((v / denom) * 1000) / 10;
    }

    const ltvPct: Record<string, number> = {};
    for (const [k, v] of Object.entries(ltvMap)) {
      ltvPct[k] = Math.round((v / denom) * 1000) / 10;
    }

    return {
      poolId,
      poolName,
      assetClass,
      issuer,
      isAgency,
      totalOriginalBalance: totalOrig,
      currentPoolBalance: totalCurr,
      weightedAverageCoupon: wac,
      weightedAverageNetCoupon: netWac,
      weightedAverageMaturity: Math.round(wam),
      weightedAverageLoanAge: Math.round(wala),
      weightedAverageOriginalLtv: Math.round(origLtv * 10) / 10,
      weightedAverageCurrentLtv: Math.round(currLtv * 10) / 10,
      weightedAverageFico: Math.round(avgFico),
      totalLoanCount: loans.length,
      stratification: {
        geographyDistribution: geoPct,
        loanTypeDistribution: typePct,
        ficoBrackets: ficoPct,
        ltvBrackets: ltvPct,
      },
      loans,
    };
  }
}
