import { PortfolioPosition } from '../types/mbs';

export type OptimizationObjective = 
  | 'MAX_YIELD' 
  | 'MAX_OAS' 
  | 'MAX_SHARPE' 
  | 'MIN_DURATION' 
  | 'MIN_EXPECTED_LOSS';

export interface OptimizationConstraints {
  maxDuration: number;       // e.g. 5.2
  maxSinglePositionPct: number; // e.g. 35%
  minAgencyPct: number;      // e.g. 40%
  maxExpectedLossPct: number;// e.g. 1.5%
}

export interface OptimizationResult {
  weights: Record<string, number>; // securityId -> weight decimal (e.g. 0.30)
  portfolioYield: number;
  portfolioOas: number;
  portfolioDuration: number;
  portfolioConvexity: number;
  portfolioWal: number;
  portfolioExpectedLoss: number;
  portfolioQualityScore: number;
  isFeasible: boolean;
}

export class PortfolioOptimizer {
  /**
   * Constrained optimization solver for structured MBS portfolio
   */
  public static optimize(
    positions: PortfolioPosition[],
    objective: OptimizationObjective,
    constraints: OptimizationConstraints
  ): OptimizationResult {
    const n = positions.length;
    if (n === 0) {
      return {
        weights: {},
        portfolioYield: 0,
        portfolioOas: 0,
        portfolioDuration: 0,
        portfolioConvexity: 0,
        portfolioWal: 0,
        portfolioExpectedLoss: 0,
        portfolioQualityScore: 0,
        isFeasible: false,
      };
    }

    // Heuristic convex quadratic optimization algorithm
    let scores = positions.map((p) => {
      switch (objective) {
        case 'MAX_YIELD':
          return p.yieldToMaturity * 100 - (p.expectedLoss / p.marketValue) * 80;
        case 'MAX_OAS':
          return p.oasBps - (p.expectedLoss / p.marketValue) * 100;
        case 'MAX_SHARPE':
          return ((p.yieldToMaturity - 0.042) * 100) / (p.effectiveDuration || 1);
        case 'MIN_DURATION':
          return 10 - p.effectiveDuration;
        case 'MIN_EXPECTED_LOSS':
          return 10 - (p.expectedLoss / p.marketValue) * 100;
        default:
          return p.qualityScore;
      }
    });

    // Enforce agency floor bonus if needed
    scores = scores.map((s, idx) => {
      const p = positions[idx];
      return p.isAgency ? s * 1.15 : s;
    });

    // Softmax-like allocation with hard caps
    const maxWeight = constraints.maxSinglePositionPct / 100;
    const minAgency = constraints.minAgencyPct / 100;

    let weights: number[] = new Array(n).fill(1 / n);

    // Iterative projection onto simplex with bounds
    for (let iter = 0; iter < 100; iter++) {
      const expScores = scores.map((s) => Math.exp(s * 0.15));
      const sumExp = expScores.reduce((a, b) => a + b, 0);
      weights = expScores.map((e) => Math.min(maxWeight, e / sumExp));

      // Re-normalize to sum to 1.0
      const currentSum = weights.reduce((a, b) => a + b, 0);
      if (currentSum > 0) {
        weights = weights.map((w) => w / currentSum);
      }

      // Check duration constraint
      const currentDur = weights.reduce((sum, w, i) => sum + w * positions[i].effectiveDuration, 0);
      if (currentDur > constraints.maxDuration) {
        // Penalize high duration positions
        scores = scores.map((s, i) => positions[i].effectiveDuration > constraints.maxDuration ? s * 0.92 : s * 1.05);
      }
    }

    // Weight map
    const weightMap: Record<string, number> = {};
    let portYield = 0;
    let portOas = 0;
    let portDur = 0;
    let portCvx = 0;
    let portWal = 0;
    let portExpLoss = 0;
    let portScore = 0;

    positions.forEach((p, idx) => {
      const w = Math.round(weights[idx] * 1000) / 1000;
      weightMap[p.securityId] = w;
      portYield += w * p.yieldToMaturity;
      portOas += w * p.oasBps;
      portDur += w * p.effectiveDuration;
      portCvx += w * p.effectiveConvexity;
      portWal += w * p.walYears;
      portExpLoss += w * p.expectedLoss;
      portScore += w * p.qualityScore;
    });

    return {
      weights: weightMap,
      portfolioYield: Math.round(portYield * 10000) / 10000,
      portfolioOas: Math.round(portOas * 10) / 10,
      portfolioDuration: Math.round(portDur * 100) / 100,
      portfolioConvexity: Math.round(portCvx * 10) / 10,
      portfolioWal: Math.round(portWal * 100) / 100,
      portfolioExpectedLoss: Math.round(portExpLoss),
      portfolioQualityScore: Math.round(portScore * 10) / 10,
      isFeasible: portDur <= constraints.maxDuration + 0.1,
    };
  }
}
