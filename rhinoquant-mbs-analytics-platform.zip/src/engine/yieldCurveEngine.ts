import { YieldCurve } from '../types/mbs';

export class YieldCurveEngine {
  public static createBenchmarkUsdCurve(): YieldCurve {
    return {
      curveId: 'USD_TREASURY_PAR_SPOT',
      curveName: 'US Treasury Benchmark Spot Curve (RhinoQuant)',
      shiftBps: 0,
      points: [
        { tenorYears: 0.25, zeroRate: 0.0440 }, // 3M
        { tenorYears: 0.50, zeroRate: 0.0435 }, // 6M
        { tenorYears: 1.0,  zeroRate: 0.0420 }, // 1Y
        { tenorYears: 2.0,  zeroRate: 0.0410 }, // 2Y
        { tenorYears: 3.0,  zeroRate: 0.0415 }, // 3Y
        { tenorYears: 5.0,  zeroRate: 0.0425 }, // 5Y
        { tenorYears: 7.0,  zeroRate: 0.0435 }, // 7Y
        { tenorYears: 10.0, zeroRate: 0.0448 }, // 10Y
        { tenorYears: 20.0, zeroRate: 0.0480 }, // 20Y
        { tenorYears: 30.0, zeroRate: 0.0475 }, // 30Y
      ],
    };
  }

  /**
   * Interpolate zero rate for any tenor in years with smooth cubic Hermite interpolation
   */
  public static getZeroRate(curve: YieldCurve, tenorYears: number, overrideShiftBps?: number): number {
    const shift = (overrideShiftBps !== undefined ? overrideShiftBps : curve.shiftBps) / 10000;
    const pts = curve.points;
    if (pts.length === 0) return 0.045 + shift;

    if (tenorYears <= pts[0].tenorYears) {
      return pts[0].zeroRate + shift;
    }
    if (tenorYears >= pts[pts.length - 1].tenorYears) {
      return pts[pts.length - 1].zeroRate + shift;
    }

    for (let i = 0; i < pts.length - 1; i++) {
      const p1 = pts[i];
      const p2 = pts[i + 1];
      if (tenorYears >= p1.tenorYears && tenorYears <= p2.tenorYears) {
        const t = (tenorYears - p1.tenorYears) / (p2.tenorYears - p1.tenorYears);
        // Hermite smooth interpolation
        const h00 = 2 * t * t * t - 3 * t * t + 1;
        const h01 = -2 * t * t * t + 3 * t * t;
        const baseRate = h00 * p1.zeroRate + h01 * p2.zeroRate;
        return baseRate + shift;
      }
    }

    return pts[pts.length - 1].zeroRate + shift;
  }

  /**
   * Continuous discount factor: DF = exp(- (r + spread) * t)
   */
  public static getDiscountFactor(
    curve: YieldCurve,
    tenorYears: number,
    spreadBps: number = 0,
    overrideShiftBps?: number
  ): number {
    if (tenorYears <= 0) return 1.0;
    const zeroRate = this.getZeroRate(curve, tenorYears, overrideShiftBps);
    const totalRate = zeroRate + (spreadBps / 10000);
    return Math.exp(-totalRate * tenorYears);
  }
}
