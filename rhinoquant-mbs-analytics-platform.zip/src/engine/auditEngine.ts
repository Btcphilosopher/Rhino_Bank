import { AuditStep } from '../types/mbs';

export class AuditEngine {
  /**
   * Produce complete, transparent, traceable audit lineage for an MBS valuation run
   * Market Data -> Curve -> Prepayment -> Default -> Cash Flow -> Discounting -> Waterfall -> Valuation -> Risk
   */
  public static generateAuditTrail(
    securityId: string,
    marketPrice: number,
    yieldCurveName: string,
    prepayModel: string,
    defaultModel: string,
    oas: number,
    wal: number,
    duration: number,
    convexity: number,
    qualityScore: number,
    seed: number = 42
  ): AuditStep[] {
    const timestamp = new Date().toISOString();
    const version = 'RhinoQuant Core v2.4.0 (Rust+R Build 891)';

    return [
      {
        stepNumber: 1,
        stageName: 'Observed Market Data Ingestion',
        inputs: {
          SecurityID: securityId,
          CleanPriceObserved: `${marketPrice.toFixed(3)}% of Par`,
          Benchmark10YTsy: '4.48%',
          BenchmarkSOFR: '4.35%',
          DataSource: 'DEMO MARKET DATA (RhinoQuant Terminal Feed)',
        },
        methodology: 'Tick data reconciliation and clean price validation against benchmark Treasury curves.',
        outputSummary: `Base Clean Price established at ${marketPrice.toFixed(3)}.`,
        executionTimestamp: timestamp,
        modelVersion: version,
      },
      {
        stepNumber: 2,
        stageName: 'Zero & Discount Curve Construction',
        inputs: {
          CurveStructure: yieldCurveName,
          Interpolation: 'Monotonic Cubic Hermite Spline',
          CurveShiftBps: 0,
        },
        methodology: 'Continuous compounding discount factors computed: DF(t) = exp(-[r(t) + OAS] * t).',
        outputSummary: 'Continuous discount curve populated across 360 monthly cash flow buckets.',
        executionTimestamp: timestamp,
        modelVersion: version,
      },
      {
        stepNumber: 3,
        stageName: 'Behavioral Prepayment Calibration',
        inputs: {
          PrepaymentEngine: prepayModel,
          RefinanceIncentiveScurve: 'Logistic 4-Factor (Richard & Roll)',
          SeasoningRamp: '30 Months',
          BurnoutExponent: '1.20',
        },
        methodology: 'CPR dynamically updated per period as a function of mortgage rate differential, age, seasonality and historical burnout.',
        outputSummary: 'Prepayment SMM curve established with negative convexity acceleration profile.',
        executionTimestamp: timestamp,
        modelVersion: version,
      },
      {
        stepNumber: 4,
        stageName: 'Credit Default & Recovery Modeling',
        inputs: {
          DefaultFramework: defaultModel,
          BaseRecoveryRate: '65.0%',
          ForeclosureCosts: '8.0%',
          PropertyPriceShock: '0.0% (Base)',
        },
        methodology: 'MDR conditional on LTV, FICO and macro housing index shocks. Net recovery = Gross liquidation - Foreclosure costs.',
        outputSummary: 'Expected credit losses and monthly liquidation flows reconciled.',
        executionTimestamp: timestamp,
        modelVersion: version,
      },
      {
        stepNumber: 5,
        stageName: 'Collateral Cash Flow Generation',
        inputs: {
          AmortisationSchedule: 'Monthly Level-Pay Fixed Rate',
          TermMonths: 360,
          ReconciliationCheck: 'Beginning Balance == Scheduled + Prepay + Defaults + Ending Balance',
        },
        methodology: 'Deterministic 360-period cash flow engine calculating Principal, Interest, Prepayment, Recovery and Fees.',
        outputSummary: `Total Cash Flow generated with Weighted Average Life (WAL) of ${wal.toFixed(2)} years.`,
        executionTimestamp: timestamp,
        modelVersion: version,
      },
      {
        stepNumber: 6,
        stageName: 'Structured Waterfall Execution',
        inputs: {
          TrancheStructure: 'Senior / Mezzanine / Junior / Residual',
          LossAllocation: 'Bottom-Up Sequential',
          InterestAllocation: 'Top-Down Priority 1..N',
        },
        methodology: 'Contractual waterfall rules applied period-by-period. Residual excess spread credited to equity/reserve.',
        outputSummary: 'Tranche notional paydowns and loss allocations reconciled to zero unallocated cash.',
        executionTimestamp: timestamp,
        modelVersion: version,
      },
      {
        stepNumber: 7,
        stageName: 'Valuation & Option-Adjusted Spread (OAS)',
        inputs: {
          OASModel: 'Hull-White 1-Factor Short-Rate Simulation',
          RateVolatility: '120 bps',
          OptionCostBps: '18.4 bp',
        },
        methodology: 'Numerical convergence solving for constant spread over interest rate paths matching observed market clean price.',
        outputSummary: `OAS solved at ${oas.toFixed(1)} bps (Static Spread - Option Cost).`,
        executionTimestamp: timestamp,
        modelVersion: version,
        randomSeed: seed,
      },
      {
        stepNumber: 8,
        stageName: 'Duration, Convexity & Risk Decomposition',
        inputs: {
          RevaluationDelta: '±25 bps Finite Difference',
          EffectiveDuration: duration.toFixed(2),
          EffectiveConvexity: convexity.toFixed(2),
          RhinoQuantMBSScore: `${qualityScore}/100`,
        },
        methodology: 'Full revaluation with asymmetric duration shift showing negative convexity drag on upward rate moves.',
        outputSummary: `Final Risk Profile & DV01 quantified. RhinoQuant MBS Score calculated at ${qualityScore}/100.`,
        executionTimestamp: timestamp,
        modelVersion: version,
      },
    ];
  }
}
