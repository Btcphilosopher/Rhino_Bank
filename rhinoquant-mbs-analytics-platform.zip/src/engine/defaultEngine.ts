import { DefaultConfig } from '../types/mbs';

export class DefaultEngine {
  /**
   * Convert annual CDR to monthly MDR
   * MDR = 1 - (1 - CDR)^(1/12)
   */
  public static cdrToMdr(cdr: number): number {
    if (cdr <= 0) return 0;
    if (cdr >= 1) return 1;
    return 1 - Math.pow(1 - cdr, 1 / 12);
  }

  /**
   * Convert monthly MDR to annual CDR
   * CDR = 1 - (1 - MDR)^12
   */
  public static mdrToCdr(mdr: number): number {
    if (mdr <= 0) return 0;
    if (mdr >= 1) return 1;
    return 1 - Math.pow(1 - mdr, 12);
  }

  /**
   * Calculate SDA Benchmark CDR
   * 100% SDA: ramps by 0.02%/mo for 30 mos (to 0.6% CDR), constant to 60 mos, drops to 120 mos
   */
  public static calculateSdaCdr(sdaPct: number, loanAgeMonths: number): number {
    let baseCdr = 0.006;
    if (loanAgeMonths <= 30) {
      baseCdr = 0.006 * (loanAgeMonths / 30);
    } else if (loanAgeMonths <= 60) {
      baseCdr = 0.006;
    } else if (loanAgeMonths <= 120) {
      baseCdr = 0.006 - 0.000095 * (loanAgeMonths - 60);
    } else {
      baseCdr = 0.0003;
    }
    return (sdaPct / 100) * Math.max(0, baseCdr);
  }

  /**
   * Adjust CDR for borrower FICO, current LTV, and property price shock
   */
  public static adjustCdrForCreditAndMacro(
    baseCdr: number,
    avgLtv: number,
    avgFico: number,
    propertyPriceShock: number
  ): number {
    const effectiveLtv = propertyPriceShock > -0.9 
      ? avgLtv / (1 + propertyPriceShock) 
      : avgLtv * 2.0;

    let ltvMult = 1.0;
    if (effectiveLtv > 100) {
      ltvMult = 2.4 + (effectiveLtv - 100) * 0.05;
    } else if (effectiveLtv > 80) {
      ltvMult = 1.0 + (effectiveLtv - 80) * 0.04;
    } else {
      ltvMult = Math.max(0.35, effectiveLtv / 80);
    }

    let ficoMult = 1.0;
    if (avgFico < 620) {
      ficoMult = 2.8;
    } else if (avgFico < 680) {
      ficoMult = 1.6;
    } else if (avgFico < 740) {
      ficoMult = 1.0;
    } else {
      ficoMult = 0.55;
    }

    return baseCdr * ltvMult * ficoMult;
  }

  /**
   * Get period MDR and CDR
   */
  public static getPeriodMdr(
    config: DefaultConfig,
    avgLtv: number,
    avgFico: number,
    loanAgeMonths: number
  ): { mdr: number; cdr: number } {
    let rawCdr = config.annualizedCdr;

    if (config.modelType === 'SDA') {
      rawCdr = this.calculateSdaCdr(config.sdaPercentage, loanAgeMonths);
    } else if (config.modelType === 'ModerateStress') {
      rawCdr = 0.025;
    } else if (config.modelType === 'SevereStress') {
      rawCdr = 0.055;
    } else if (config.modelType === 'ExtremeStress') {
      rawCdr = 0.095;
    }

    const adjustedCdr = this.adjustCdrForCreditAndMacro(
      rawCdr,
      avgLtv,
      avgFico,
      config.propertyPriceShock
    );

    const mdr = this.cdrToMdr(adjustedCdr);
    return { mdr, cdr: adjustedCdr };
  }

  /**
   * Calculate recovery cash, realized loss and loss given default (LGD)
   */
  public static calculateNetRecovery(
    config: DefaultConfig,
    defaultedPrincipal: number,
    propertyValue: number
  ): { recoveryCash: number; realizedLoss: number; lossSeverity: number } {
    if (defaultedPrincipal <= 0) {
      return { recoveryCash: 0, realizedLoss: 0, lossSeverity: 0 };
    }

    const shockedValue = propertyValue * Math.max(0.1, 1 + config.propertyPriceShock);
    const grossRecovery = shockedValue * config.baseRecoveryRate;
    const costs = shockedValue * (config.foreclosureCostsPct + 0.03);

    const netRecovery = Math.min(defaultedPrincipal, Math.max(0, grossRecovery - costs));
    const realizedLoss = Math.max(0, defaultedPrincipal - netRecovery);
    const lossSeverity = realizedLoss / defaultedPrincipal;

    return { recoveryCash: netRecovery, realizedLoss, lossSeverity };
  }
}
