import { 
  MortgagePool, 
  PrepaymentConfig, 
  DefaultConfig, 
  YieldCurve, 
  ScenarioResult 
} from '../types/mbs';
import { CashFlowEngine } from './cashFlowEngine';
import { ValuationEngine } from './valuationEngine';
import { RiskEngine } from './riskEngine';

export interface StressScenarioDef {
  scenarioId: string;
  name: string;
  rateShiftBps: number;
  prepayShiftPct: number; // e.g. -30 for 30% slower
  defaultMultiplier: number;
  propertyValueShockPct: number;
}

export class ScenarioEngine {
  public static getDefaultScenarios(): StressScenarioDef[] {
    return [
      { scenarioId: 'BASE', name: 'Base Market Scenario', rateShiftBps: 0, prepayShiftPct: 0, defaultMultiplier: 1.0, propertyValueShockPct: 0 },
      { scenarioId: 'RATES_UP_100', name: 'Rates +100 bps', rateShiftBps: 100, prepayShiftPct: -25, defaultMultiplier: 1.1, propertyValueShockPct: -2 },
      { scenarioId: 'RATES_UP_200', name: 'Rates +200 bps (Extension)', rateShiftBps: 200, prepayShiftPct: -45, defaultMultiplier: 1.3, propertyValueShockPct: -5 },
      { scenarioId: 'RATES_UP_300', name: 'Rates +300 bps (Severe Bear)', rateShiftBps: 300, prepayShiftPct: -60, defaultMultiplier: 1.7, propertyValueShockPct: -10 },
      { scenarioId: 'RATES_DOWN_100', name: 'Rates -100 bps (Refi Surge)', rateShiftBps: -100, prepayShiftPct: 60, defaultMultiplier: 0.9, propertyValueShockPct: +3 },
      { scenarioId: 'RATES_DOWN_200', name: 'Rates -200 bps (Wave Refi)', rateShiftBps: -200, prepayShiftPct: 150, defaultMultiplier: 0.8, propertyValueShockPct: +6 },
      { scenarioId: 'STRESS_STAGFLATION', name: 'Rates +200bp + Slow Prepay + High Defaults', rateShiftBps: 200, prepayShiftPct: -50, defaultMultiplier: 2.2, propertyValueShockPct: -15 },
      { scenarioId: 'STRESS_HOUSING_CRASH', name: 'Rates +150bp + Property -25% + Defaults +150%', rateShiftBps: 150, prepayShiftPct: -30, defaultMultiplier: 2.8, propertyValueShockPct: -25 },
      { scenarioId: 'STRESS_LIQUIDITY_CRISIS', name: 'Rates +300bp + Property -30% + Defaults 3.5x', rateShiftBps: 300, prepayShiftPct: -65, defaultMultiplier: 3.5, propertyValueShockPct: -30 },
    ];
  }

  public static evaluateScenarios(
    pool: MortgagePool,
    basePrepay: PrepaymentConfig,
    baseDefault: DefaultConfig,
    yieldCurve: YieldCurve,
    baseCleanPrice: number,
    baseNotional: number
  ): ScenarioResult[] {
    const scenarios = this.getDefaultScenarios();
    const results: ScenarioResult[] = [];

    for (const sc of scenarios) {
      // Adjust prepayment params for scenario
      const prepayCfg: PrepaymentConfig = {
        ...basePrepay,
        marketMortgageRate: basePrepay.marketMortgageRate + (sc.rateShiftBps / 10000),
        cprValue: Math.max(0.01, basePrepay.cprValue * (1 + sc.prepayShiftPct / 100)),
        psaSpeed: Math.max(20, basePrepay.psaSpeed * (1 + sc.prepayShiftPct / 100)),
      };

      const defaultCfg: DefaultConfig = {
        ...baseDefault,
        annualizedCdr: baseDefault.annualizedCdr * sc.defaultMultiplier,
        propertyPriceShock: sc.propertyValueShockPct / 100,
      };

      const cf = CashFlowEngine.generatePoolCashFlows(
        pool,
        prepayCfg,
        defaultCfg,
        yieldCurve,
        94,
        sc.rateShiftBps
      );

      const val = ValuationEngine.valueMbs(cf, yieldCurve, pool.currentPoolBalance, pool.weightedAverageNetCoupon);

      const priceDeltaPct = Math.round(((val.cleanPrice - baseCleanPrice) / baseCleanPrice) * 10000) / 100;
      const pnl = Math.round(((val.cleanPrice - baseCleanPrice) / 100) * baseNotional);

      results.push({
        scenarioId: sc.scenarioId,
        name: sc.name,
        rateShiftBps: sc.rateShiftBps,
        prepayShiftPct: sc.prepayShiftPct,
        defaultMultiplier: sc.defaultMultiplier,
        propertyValueShockPct: sc.propertyValueShockPct,
        cleanPrice: val.cleanPrice,
        priceDeltaPct,
        pnlCurrency: pnl,
        yieldToMaturity: val.yieldToMaturity,
        effectiveDuration: Math.max(1.2, 4.8 + (sc.rateShiftBps / 100) * 0.45 - (sc.prepayShiftPct / 100) * 0.8),
        walYears: cf.weightedAverageLifeYears,
        expectedLoss: pool.isAgency ? 0 : cf.totalRealizedLosses,
      });
    }

    return results;
  }
}
