import { MortgageLoan } from '../types/mbs';

export class MortgageEngine {
  /**
   * Calculate monthly level scheduled payment for a standard fixed-rate amortising mortgage
   */
  public static calculateMonthlyPayment(loan: MortgageLoan): number {
    if (loan.currentBalance <= 0 || loan.remainingTermMonths <= 0) {
      return 0;
    }

    const monthlyRate = loan.grossInterestRate / 12;

    if (loan.amortisationType === 'InterestOnly') {
      return loan.currentBalance * monthlyRate;
    }

    if (Math.abs(monthlyRate) < 1e-9) {
      return loan.currentBalance / loan.remainingTermMonths;
    }

    const n = loan.remainingTermMonths;
    const factor = Math.pow(1 + monthlyRate, n);
    return loan.currentBalance * (monthlyRate * factor) / (factor - 1);
  }

  /**
   * Single month period amortisation
   */
  public static amortiseSinglePeriod(
    currentBalance: number,
    grossRate: number,
    remainingMonths: number,
    monthlyPayment: number
  ): { interest: number; scheduledPrincipal: number; endingBalance: number } {
    if (currentBalance <= 0) {
      return { interest: 0, scheduledPrincipal: 0, endingBalance: 0 };
    }

    const monthlyRate = grossRate / 12;
    const interest = currentBalance * monthlyRate;
    let scheduledPrincipal = monthlyPayment - interest;

    if (scheduledPrincipal < 0) {
      scheduledPrincipal = 0;
    }
    if (scheduledPrincipal > currentBalance) {
      scheduledPrincipal = currentBalance;
    }

    const endingBalance = Math.max(0, currentBalance - scheduledPrincipal);
    return { interest, scheduledPrincipal, endingBalance };
  }
}
