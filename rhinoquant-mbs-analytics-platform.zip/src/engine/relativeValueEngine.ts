import { PortfolioPosition, RelativeValueScoreBreakdown } from '../types/mbs';

export class RelativeValueEngine {
  /**
   * Calculate RhinoQuant MBS Quality Score (0 to 100)
   * Multi-factor quantitative scoring:
   * - Risk-Adjusted Yield (25%)
   * - OAS spread attractiveness (20%)
   * - Convexity preservation (20%)
   * - Credit protection & LGD safety (20%)
   * - Liquidity & Agency Guarantee (15%)
   */
  public static calculateRhinoQuantScore(
    pos: PortfolioPosition
  ): RelativeValueScoreBreakdown {
    // 1. Yield score (Target benchmark 5.5% -> 80 pts)
    const yieldScore = Math.min(100, Math.max(20, (pos.yieldToMaturity / 0.065) * 85));

    // 2. OAS score (90-110 bps is optimal risk-adjusted reward)
    const oasScore = Math.min(100, Math.max(10, (pos.oasBps / 120) * 90));

    // 3. Convexity score (less negative is better)
    const convexityScore = Math.min(100, Math.max(10, 85 + (pos.effectiveConvexity * 12)));

    // 4. Credit safety (Agency is 98, Non-agency scaled by expected loss)
    const creditSafetyScore = pos.isAgency
      ? 98
      : Math.min(100, Math.max(15, 95 - (pos.expectedLoss / pos.marketValue) * 350));

    // 5. Liquidity
    const liquidityScore = pos.isAgency ? 95 : (pos.assetClass.includes('Prime') ? 80 : 65);

    // 6. Model confidence
    const modelConfidenceScore = 92;

    const totalScore = Math.round(
      yieldScore * 0.25 +
      oasScore * 0.20 +
      convexityScore * 0.20 +
      creditSafetyScore * 0.20 +
      liquidityScore * 0.15
    );

    return {
      totalScore: Math.min(100, Math.max(0, totalScore)),
      yieldScore: Math.round(yieldScore),
      oasScore: Math.round(oasScore),
      convexityScore: Math.round(convexityScore),
      creditSafetyScore: Math.round(creditSafetyScore),
      liquidityScore: Math.round(liquidityScore),
      modelConfidenceScore,
    };
  }

  /**
   * Filter and rank universe of securities
   */
  public static screenSecurities(
    universe: PortfolioPosition[],
    filters: {
      minYield?: number;
      minOas?: number;
      maxDuration?: number;
      maxWal?: number;
      maxExpectedLossPct?: number;
      onlyAgency?: boolean;
    }
  ): PortfolioPosition[] {
    return universe.filter((p) => {
      if (filters.minYield !== undefined && p.yieldToMaturity < filters.minYield) return false;
      if (filters.minOas !== undefined && p.oasBps < filters.minOas) return false;
      if (filters.maxDuration !== undefined && p.effectiveDuration > filters.maxDuration) return false;
      if (filters.maxWal !== undefined && p.walYears > filters.maxWal) return false;
      if (filters.maxExpectedLossPct !== undefined && (p.expectedLoss / p.marketValue) * 100 > filters.maxExpectedLossPct) return false;
      if (filters.onlyAgency && !p.isAgency) return false;
      return true;
    });
  }
}
