import { CashFlowSchedule, Tranche, WaterfallStructure } from '../types/mbs';

export class WaterfallEngine {
  /**
   * Run structured waterfall cash flow routing across tranches
   * Seniority top-down for interest & principal, bottom-up for loss absorption
   */
  public static executeWaterfall(
    structure: WaterfallStructure,
    collateralSchedule: CashFlowSchedule
  ): WaterfallStructure {
    // Clone structure to avoid mutating parameters
    const tranches: Tranche[] = structure.tranches.map(t => ({
      ...t,
      currentNotional: t.originalNotional,
      cashFlows: [],
      totalInterestPaid: 0,
      totalPrincipalPaid: 0,
      totalLossesAllocated: 0,
      walYears: 0,
    }));

    let excessSpreadAccumulated = 0;
    let reserveFundBalance = structure.reserveFundBalance;

    for (const period of collateralSchedule.periods) {
      let availableInterest = period.netInterest;
      let availablePrincipal = period.scheduledPrincipal + period.prepaymentPrincipal + period.recoveryCash;
      let unallocatedLoss = period.realizedLoss;

      // 1. ALLOCATE LOSSES (Bottom-Up: Reverse order of tranches)
      const periodLossAllocated: number[] = new Array(tranches.length).fill(0);
      for (let i = tranches.length - 1; i >= 0; i--) {
        const tr = tranches[i];
        if (tr.currentNotional <= 0 || unallocatedLoss <= 0) continue;

        const lossTaken = Math.min(tr.currentNotional, unallocatedLoss);
        tr.currentNotional -= lossTaken;
        unallocatedLoss -= lossTaken;
        periodLossAllocated[i] = lossTaken;
        tr.totalLossesAllocated += lossTaken;
      }

      // 2. ALLOCATE INTEREST (Top-Down: Senior to Junior)
      const periodInterestPaid: number[] = new Array(tranches.length).fill(0);
      const periodInterestShortfall: number[] = new Array(tranches.length).fill(0);

      for (let i = 0; i < tranches.length; i++) {
        const tr = tranches[i];
        if (tr.currentNotional <= 0) continue;

        const monthlyRate = tr.couponRate / 12;
        const interestDue = tr.currentNotional * monthlyRate;

        const interestPaid = Math.min(interestDue, availableInterest);
        availableInterest -= interestPaid;
        const shortfall = interestDue - interestPaid;

        periodInterestPaid[i] = interestPaid;
        periodInterestShortfall[i] = shortfall;
        tr.totalInterestPaid += interestPaid;
      }

      // 3. ALLOCATE PRINCIPAL (Sequential: Senior gets 100% until retired)
      const periodPrincipalPaid: number[] = new Array(tranches.length).fill(0);

      for (let i = 0; i < tranches.length; i++) {
        const tr = tranches[i];
        if (tr.currentNotional <= 0 || availablePrincipal <= 0) continue;

        const prinToPay = Math.min(tr.currentNotional, availablePrincipal);
        tr.currentNotional -= prinToPay;
        availablePrincipal -= prinToPay;
        periodPrincipalPaid[i] = prinToPay;
        tr.totalPrincipalPaid += prinToPay;
      }

      // 4. EXCESS SPREAD TO RESIDUAL / RESERVE
      if (availableInterest > 0) {
        excessSpreadAccumulated += availableInterest;
      }

      // 5. UPDATE TRANCHE CASH FLOW RECORD
      for (let i = 0; i < tranches.length; i++) {
        const tr = tranches[i];
        const intP = periodInterestPaid[i];
        const prinP = periodPrincipalPaid[i];
        const begBal = tr.currentNotional + prinP + periodLossAllocated[i];

        tr.cashFlows.push({
          period: period.period,
          beginningBalance: begBal,
          interestPaid: intP,
          interestShortfall: periodInterestShortfall[i],
          principalPaid: prinP,
          lossAllocated: periodLossAllocated[i],
          endingBalance: tr.currentNotional,
          totalCashFlow: intP + prinP,
        });
      }
    }

    // Finalize WAL for each tranche
    for (const tr of tranches) {
      let walNumerator = 0;
      let totalPrin = 0;
      for (const cf of tr.cashFlows) {
        const tYears = cf.period / 12;
        walNumerator += tYears * cf.principalPaid;
        totalPrin += cf.principalPaid;
      }
      const denom = totalPrin > 0 ? totalPrin : tr.originalNotional || 1;
      tr.walYears = Math.round((walNumerator / denom) * 100) / 100;
    }

    return {
      dealName: structure.dealName,
      tranches,
      reserveFundBalance,
      targetReserveFund: structure.targetReserveFund,
      excessSpreadAccumulated,
    };
  }
}
