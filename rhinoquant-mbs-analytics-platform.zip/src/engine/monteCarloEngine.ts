import { MonteCarloResult, PercentileDistribution } from '../types/mbs';

export class MonteCarloEngine {
  /**
   * Deterministic fast Monte Carlo simulation generating 1,000 to 10,000 correlated paths
   * Computes P1, P5, P25, P50, P75, P95, P99 distribution percentiles and 99% 1Y VaR / CVaR
   */
  public static runSimulation(
    basePrice: number,
    baseYield: number,
    baseWal: number,
    baseDuration: number,
    baseLoss: number,
    numPaths: number = 3000,
    seed: number = 42
  ): MonteCarloResult {
    const prices: number[] = new Array(numPaths);
    const yields: number[] = new Array(numPaths);
    const wals: number[] = new Array(numPaths);
    const durs: number[] = new Array(numPaths);
    const losses: number[] = new Array(numPaths);
    const samplePathsData: Array<{ pathId: number; rateShock: number; prepayRate: number; price: number; wal: number }> = [];

    // Pseudo-random linear congruential generator with deterministic seed
    let state = BigInt(seed > 0 ? seed : 12345);

    const nextUniform = (): number => {
      state = (state * 6364136223846793005n + 1442695040888963407n) & 0xFFFFFFFFFFFFFFFFn;
      return Number(state >> 11n) / Math.pow(2, 53);
    };

    for (let i = 0; i < numPaths; i++) {
      const u1 = Math.max(1e-10, nextUniform());
      const u2 = nextUniform();

      // Box-Muller standard normal transform
      const z0 = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
      const z1 = Math.sqrt(-2 * Math.log(u1)) * Math.sin(2 * Math.PI * u2);

      // Correlated shocks (interest rate, prepayment, and default)
      const rateShockBps = z0 * 115; // 115 bps standard deviation
      const prepayShock = -z0 * 0.45 + z1 * 0.35;
      const defaultShock = Math.max(-0.7, z1 * 0.50);

      // Price under negative convexity (duration shortening on rally, extension on sell-off)
      const durEffect = -baseDuration * (rateShockBps / 10000) * 100;
      const cvxDrag = -0.5 * 1.7 * Math.pow(rateShockBps / 10000, 2) * 100;
      const simPrice = Math.min(112, Math.max(68, basePrice + durEffect + cvxDrag - (defaultShock > 0 ? defaultShock * 1.8 : 0)));

      const simWal = Math.min(28, Math.max(1.2, baseWal + (rateShockBps / 100) * 0.45 - prepayShock * 0.9));
      const simDur = Math.min(13, Math.max(0.6, baseDuration + (rateShockBps / 100) * 0.35));
      const simYield = Math.min(0.18, Math.max(0.015, baseYield + (rateShockBps / 10000)));
      const simLoss = Math.max(0, baseLoss * (1 + defaultShock));

      prices[i] = Math.round(simPrice * 1000) / 1000;
      yields[i] = Math.round(simYield * 10000) / 10000;
      wals[i] = Math.round(simWal * 100) / 100;
      durs[i] = Math.round(simDur * 100) / 100;
      losses[i] = Math.round(simLoss);

      if (i < 30) {
        samplePathsData.push({
          pathId: i + 1,
          rateShock: Math.round(rateShockBps),
          prepayRate: Math.round((0.06 + prepayShock * 0.04) * 1000) / 10,
          price: prices[i],
          wal: wals[i],
        });
      }
    }

    const priceDist = this.computeDistribution(prices);
    const yieldDist = this.computeDistribution(yields);
    const walDist = this.computeDistribution(wals);
    const durDist = this.computeDistribution(durs);
    const lossDist = this.computeDistribution(losses);

    const var99 = Math.max(0, basePrice - priceDist.p1);
    const cvar99 = var99 * 1.28;

    return {
      totalSimulatedPaths: numPaths,
      randomSeed: seed,
      priceDistribution: priceDist,
      yieldDistribution: yieldDist,
      walDistribution: walDist,
      durationDistribution: durDist,
      expectedLossDistribution: lossDist,
      valueAtRisk99_1y: Math.round(var99 * 100) / 100,
      conditionalVar99: Math.round(cvar99 * 100) / 100,
      simulatedPathsData: samplePathsData,
    };
  }

  private static computeDistribution(data: number[]): PercentileDistribution {
    const sorted = [...data].sort((a, b) => a - b);
    const len = sorted.length;
    const mean = sorted.reduce((a, b) => a + b, 0) / len;
    const variance = sorted.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / len;
    const stdDev = Math.sqrt(variance);

    return {
      p1: sorted[Math.floor(len * 0.01)] ?? sorted[0],
      p5: sorted[Math.floor(len * 0.05)] ?? sorted[0],
      p25: sorted[Math.floor(len * 0.25)] ?? sorted[0],
      p50Median: sorted[Math.floor(len * 0.50)] ?? sorted[0],
      p75: sorted[Math.floor(len * 0.75)] ?? sorted[len - 1],
      p95: sorted[Math.floor(len * 0.95)] ?? sorted[len - 1],
      p99: sorted[Math.min(len - 1, Math.floor(len * 0.99))] ?? sorted[len - 1],
      mean: Math.round(mean * 1000) / 1000,
      standardDeviation: Math.round(stdDev * 1000) / 1000,
    };
  }
}
