export type AmortisationType = 
  | 'FixedRate' 
  | 'VariableRate' 
  | 'AdjustableRate' 
  | 'InterestOnly' 
  | 'Custom';

export type LoanType = 
  | 'AgencyConforming' 
  | 'AgencyJumbo' 
  | 'NonAgencyPrime' 
  | 'NonAgencyAltA' 
  | 'Subprime' 
  | 'CommercialMultiFamily' 
  | 'CommercialRetailOffice';

export type OccupancyType = 'PrimaryResidence' | 'SecondHome' | 'Investor';

export interface BorrowerCredit {
  ficoScore: number;
  dtiRatio: number;
  docType: string;
}

export interface MortgageLoan {
  loanId: string;
  originalBalance: number;
  currentBalance: number;
  grossInterestRate: number; // e.g. 0.0575 for 5.75%
  netInterestRate: number;   // e.g. 0.0525 (after fees)
  servicingFeeRate: number;  // e.g. 0.0025
  guaranteeFeeRate: number;  // e.g. 0.0025
  originalTermMonths: number;
  remainingTermMonths: number;
  ageMonths: number;
  originationDate: string;
  maturityDate: string;
  paymentFrequency: number;  // 12
  amortisationType: AmortisationType;
  propertyValue: number;
  originalLtv: number;
  currentLtv: number;
  borrower: BorrowerCredit;
  geographyState: string;
  occupancy: OccupancyType;
  loanType: LoanType;
}

export interface PoolStratification {
  geographyDistribution: Record<string, number>;
  loanTypeDistribution: Record<string, number>;
  ficoBrackets: Record<string, number>;
  ltvBrackets: Record<string, number>;
}

export interface MortgagePool {
  poolId: string;
  poolName: string;
  assetClass: 'Agency RMBS' | 'Non-Agency RMBS' | 'CMBS' | 'Agency 15Y' | 'CRT Subordinated';
  issuer: string;
  isAgency: boolean;
  totalOriginalBalance: number;
  currentPoolBalance: number;
  weightedAverageCoupon: number;      // WAC (annualized decimal)
  weightedAverageNetCoupon: number;   // WAC net of servicing
  weightedAverageMaturity: number;    // WAM (months)
  weightedAverageLoanAge: number;     // WALA (months)
  weightedAverageOriginalLtv: number;
  weightedAverageCurrentLtv: number;
  weightedAverageFico: number;
  totalLoanCount: number;
  stratification: PoolStratification;
  loans: MortgageLoan[];
}

export interface CashFlowPeriod {
  period: number;
  monthDate: string;
  beginningBalance: number;
  scheduledPrincipal: number;
  prepaymentPrincipal: number;
  defaultedPrincipal: number;
  totalPrincipal: number;
  grossInterest: number;
  servicingFee: number;
  guaranteeFee: number;
  netInterest: number;
  recoveryCash: number;
  realizedLoss: number;
  netCashFlow: number;
  endingBalance: number;
  cprApplied: number;
  smmApplied: number;
  cdrApplied: number;
  mdrApplied: number;
  discountFactor: number;
  presentValue: number;
}

export interface CashFlowSchedule {
  periods: CashFlowPeriod[];
  totalScheduledPrincipal: number;
  totalPrepayments: number;
  totalDefaults: number;
  totalRecoveries: number;
  totalRealizedLosses: number;
  totalGrossInterest: number;
  totalNetInterest: number;
  totalServicingFees: number;
  totalGuaranteeFees: number;
  totalCashFlow: number;
  weightedAverageLifeYears: number;
}

export type PrepaymentModelType = 
  | 'ConstantCPR' 
  | 'PSA' 
  | 'RichardRoll4Factor' 
  | 'CustomVector';

export interface RichardRollParams {
  baseCpr: number;
  turnoverRate: number;
  refinancingIncentiveCoef: number;
  seasoningRampMonths: number;
  maxSeasoningFactor: number;
  seasonalityMultipliers: number[];
  burnoutExponent: number;
  mediaEffectCoef: number;
}

export interface PrepaymentConfig {
  modelType: PrepaymentModelType;
  cprValue: number;          // If ConstantCPR
  psaSpeed: number;         // If PSA (e.g. 100, 150)
  richardRoll: RichardRollParams;
  marketMortgageRate: number;
  priorRefiIncentiveAccumulated: number;
}

export type DefaultModelType = 'Base' | 'ModerateStress' | 'SevereStress' | 'ExtremeStress' | 'SDA' | 'CDR';

export interface DefaultConfig {
  modelType: DefaultModelType;
  annualizedCdr: number;
  sdaPercentage: number;
  baseRecoveryRate: number;
  foreclosureCostsPct: number;
  recoveryLagMonths: number;
  propertyPriceShock: number; // e.g. -0.15 for -15%
}

export type SeniorityLevel = 
  | 'SeniorAAA' 
  | 'SeniorAA' 
  | 'MezzanineA' 
  | 'MezzanineBBB' 
  | 'JuniorBB' 
  | 'JuniorB' 
  | 'SubordinatedResidual';

export interface TrancheCashFlow {
  period: number;
  beginningBalance: number;
  interestPaid: number;
  interestShortfall: number;
  principalPaid: number;
  lossAllocated: number;
  endingBalance: number;
  totalCashFlow: number;
}

export interface Tranche {
  trancheId: string;
  trancheName: string;
  rating: string;
  originalNotional: number;
  currentNotional: number;
  couponRate: number;
  priority: number;
  seniority: SeniorityLevel;
  attachmentPoint: number; // %
  detachmentPoint: number; // %
  paymentRule: 'SequentialPay' | 'ProRata' | 'PAC' | 'Residual';
  lossRule: 'BottomUpSequential' | 'ProRataLoss';
  cashFlows: TrancheCashFlow[];
  totalInterestPaid: number;
  totalPrincipalPaid: number;
  totalLossesAllocated: number;
  walYears: number;
  yieldToMaturity: number;
  cleanPrice: number;
  effectiveDuration: number;
}

export interface WaterfallStructure {
  dealName: string;
  tranches: Tranche[];
  reserveFundBalance: number;
  targetReserveFund: number;
  excessSpreadAccumulated: number;
}

export interface YieldPoint {
  tenorYears: number;
  zeroRate: number;
}

export interface YieldCurve {
  curveId: string;
  curveName: string;
  points: YieldPoint[];
  shiftBps: number;
}

export interface MBSValuationResult {
  presentValue: number;
  cleanPrice: number;
  dirtyPrice: number;
  accruedInterest: number;
  yieldToMaturity: number;
  nominalSpreadBps: number;
  weightedAverageLifeYears: number;
  cashOnCashReturn: number;
  internalRateOfReturn: number;
}

export interface OASResult {
  optionAdjustedSpreadBps: number;
  staticSpreadBps: number;
  optionCostBps: number;
  modelPrice: number;
  marketPrice: number;
  shortRateVolatility: number;
  meanReversionSpeed: number;
  convergenceIterations: number;
}

export interface DurationMetrics {
  effectiveDuration: number;
  modifiedDuration: number;
  macaulayDurationYears: number;
  priceUpShift: number;
  priceDownShift: number;
  dv01: number;
  dv01Currency: number;
}

export interface ConvexityMetrics {
  effectiveConvexity: number;
  isNegativelyConvex: boolean;
  convexityDragBps: number;
  durationShorteningDownRate: number;
  durationExtensionUpRate: number;
}

export interface BucketedDV01Point {
  bucketLabel: string;
  keyRateDuration: number;
  bucketDv01: number;
}

export interface RiskDecomposition {
  totalRiskPct: number;
  interestRateRiskPct: number;
  prepaymentRiskPct: number;
  creditRiskPct: number;
  spreadRiskPct: number;
  liquidityRiskPct: number;
  cs01Currency: number;
  expectedLossCurrency: number;
  stressLossCurrency: number;
}

export interface PercentileDistribution {
  p1: number;
  p5: number;
  p25: number;
  p50Median: number;
  p75: number;
  p95: number;
  p99: number;
  mean: number;
  standardDeviation: number;
}

export interface MonteCarloResult {
  totalSimulatedPaths: number;
  randomSeed: number;
  priceDistribution: PercentileDistribution;
  yieldDistribution: PercentileDistribution;
  walDistribution: PercentileDistribution;
  durationDistribution: PercentileDistribution;
  expectedLossDistribution: PercentileDistribution;
  valueAtRisk99_1y: number;
  conditionalVar99: number;
  simulatedPathsData: Array<{ pathId: number; rateShock: number; prepayRate: number; price: number; wal: number }>;
}

export interface ScenarioResult {
  scenarioId: string;
  name: string;
  rateShiftBps: number;
  prepayShiftPct: number;
  defaultMultiplier: number;
  propertyValueShockPct: number;
  cleanPrice: number;
  priceDeltaPct: number;
  pnlCurrency: number;
  yieldToMaturity: number;
  effectiveDuration: number;
  walYears: number;
  expectedLoss: number;
}

export interface PortfolioPosition {
  positionId: string;
  securityId: string;
  securityName: string;
  assetClass: string;
  isAgency: boolean;
  notionalBalance: number;
  bookValue: number;
  marketPrice: number;
  marketValue: number;
  couponRate: number;
  yieldToMaturity: number;
  oasBps: number;
  effectiveDuration: number;
  effectiveConvexity: number;
  walYears: number;
  dv01: number;
  cs01: number;
  expectedLoss: number;
  stressLoss: number;
  qualityScore: number;
}

export interface PortfolioAnalytics {
  totalMarketValue: number;
  totalBookValue: number;
  weightedYield: number;
  weightedOasBps: number;
  weightedDuration: number;
  weightedConvexity: number;
  weightedWalYears: number;
  totalDv01: number;
  totalCs01: number;
  totalExpectedLoss: number;
  totalStressLoss: number;
  portfolioQualityScore: number;
  riskBreakdown: RiskDecomposition;
  bucketedDv01: BucketedDV01Point[];
}

export interface RelativeValueScoreBreakdown {
  totalScore: number;
  yieldScore: number;
  oasScore: number;
  convexityScore: number;
  creditSafetyScore: number;
  liquidityScore: number;
  modelConfidenceScore: number;
}

export interface AuditStep {
  stepNumber: number;
  stageName: string;
  inputs: Record<string, string | number>;
  methodology: string;
  outputSummary: string;
  executionTimestamp: string;
  modelVersion: string;
  randomSeed?: number;
}
