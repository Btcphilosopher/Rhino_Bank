import React, { useState } from 'react';
import { PortfolioAnalytics, PortfolioPosition } from '../types/mbs';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell 
} from 'recharts';
import { ArrowRight } from 'lucide-react';

interface Props {
  positions: PortfolioPosition[];
  analytics: PortfolioAnalytics;
  onSelectSecurity: (secId: string) => void;
}

const COLORS = ['#F97316', '#3B82F6', '#22C55E', '#8B5CF6', '#EC4899'];

export const PortfolioView: React.FC<Props> = ({ positions, analytics, onSelectSecurity }) => {
  const [selectedAssetClass, setSelectedAssetClass] = useState<string>('ALL');

  // Allocation by Asset Class
  const assetClassData = positions.reduce((acc, p) => {
    const existing = acc.find(item => item.name === p.assetClass);
    if (existing) {
      existing.value += p.marketValue;
    } else {
      acc.push({ name: p.assetClass, value: p.marketValue });
    }
    return acc;
  }, [] as Array<{ name: string; value: number }>);

  // Filtered positions
  const filteredPositions = selectedAssetClass === 'ALL'
    ? positions
    : positions.filter(p => p.assetClass === selectedAssetClass);

  const riskPieData = [
    { name: 'Interest Rate Risk', value: analytics.riskBreakdown.interestRateRiskPct, color: '#F97316' },
    { name: 'Prepayment Risk', value: analytics.riskBreakdown.prepaymentRiskPct, color: '#3B82F6' },
    { name: 'Credit Risk', value: analytics.riskBreakdown.creditRiskPct, color: '#EF4444' },
    { name: 'Spread Risk (CS01)', value: analytics.riskBreakdown.spreadRiskPct, color: '#06B6D4' },
    { name: 'Liquidity Risk', value: analytics.riskBreakdown.liquidityRiskPct, color: '#22C55E' },
  ];

  return (
    <div className="space-y-4">
      {/* Top Allocation & Risk Breakdown Bento Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Asset Class Allocation */}
        <div className="lg:col-span-4 bento-card p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-2 mb-3">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Asset Class Allocation
            </span>
            <span className="text-[10px] font-mono text-slate-400 font-semibold">Total £842.6M</span>
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={assetClassData}
                  cx="50%"
                  cy="50%"
                  innerRadius={46}
                  outerRadius={70}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {assetClassData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(val: number) => [`£${(val / 1_000_000).toFixed(1)}m (${((val / analytics.totalMarketValue) * 100).toFixed(1)}%)`, 'Market Value']}
                  contentStyle={{ backgroundColor: '#11141A', borderColor: '#1E293B', fontSize: '12px', borderRadius: '8px', color: '#fff' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[11px] font-mono mt-2 pt-2 border-t border-slate-800/80">
            {assetClassData.map((item, idx) => (
              <div key={item.name} className="flex items-center gap-1.5 text-slate-300">
                <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: COLORS[idx % COLORS.length] }}></span>
                <span className="truncate text-slate-400">{item.name}:</span>
                <span className="font-bold text-white">
                  {((item.value / analytics.totalMarketValue) * 100).toFixed(0)}%
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Bucketed Key Rate DV01 Profile */}
        <div className="lg:col-span-4 bento-card p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-2 mb-3">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Bucketed DV01 Curve Profile
            </span>
            <span className="text-[10px] font-mono text-orange-400 font-bold">
              Total: £{analytics.totalDv01.toLocaleString()}
            </span>
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics.bucketedDv01} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <XAxis dataKey="bucketLabel" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip 
                  formatter={(val: number) => [`£${val.toLocaleString()}`, 'Key Rate DV01']}
                  contentStyle={{ backgroundColor: '#11141A', borderColor: '#1E293B', fontSize: '12px', borderRadius: '8px', color: '#fff' }}
                />
                <Bar dataKey="bucketDv01" fill="#F97316" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[10px] text-slate-500 mt-2 font-mono pt-2 border-t border-slate-800/80">
            Key Rate Sensitivity concentrated at 5Y tenor (48% of total duration).
          </p>
        </div>

        {/* Total Risk Decomposition Breakdown */}
        <div className="lg:col-span-4 bento-card p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-2 mb-3">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Risk Decomposition
            </span>
            <span className="text-[10px] font-mono text-emerald-400 font-bold">100% Total</span>
          </div>
          <div className="space-y-2.5 my-auto">
            {riskPieData.map((item) => (
              <div key={item.name} className="space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-slate-300">{item.name}</span>
                  <span className="text-white font-bold">{item.value}%</span>
                </div>
                <div className="w-full bg-slate-800/80 rounded-full h-1.5 overflow-hidden">
                  <div 
                    className="h-full rounded-full transition-all duration-300"
                    style={{ width: `${item.value}%`, backgroundColor: item.color }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Positions Bento Table Card */}
      <div className="bento-card overflow-hidden flex flex-col">
        <div className="p-4 sm:p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white tracking-tight">
                MBS Portfolio Holdings Ledger
              </h3>
              <span className="text-[10px] px-2 py-0.5 bg-slate-800 text-orange-400 rounded font-mono font-bold">
                {filteredPositions.length} POSITIONS
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              Institutional Fixed Income Holdings & Quantitative Stratifications
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-400 font-mono">Class:</span>
            <div className="flex gap-1.5 flex-wrap">
              {['ALL', 'Agency RMBS', 'Non-Agency RMBS', 'CMBS', 'CRT Subordinated'].map((cls) => (
                <button
                  key={cls}
                  onClick={() => setSelectedAssetClass(cls)}
                  className={`px-2.5 py-1 rounded text-[10px] font-bold font-mono transition border ${
                    selectedAssetClass === cls
                      ? 'bg-orange-600 text-white border-orange-500'
                      : 'bg-slate-800/60 text-slate-400 hover:text-slate-200 border-slate-700 hover:bg-slate-800'
                  }`}
                >
                  {cls}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-left border-collapse font-mono text-xs">
            <thead className="text-[10px] uppercase text-slate-500 font-bold sticky top-0 bg-[#0E1117] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Security ID</th>
                <th className="py-3 px-4 font-sans">Description</th>
                <th className="py-3 px-4 font-sans">Asset Class</th>
                <th className="py-3 px-4 text-right">Notional</th>
                <th className="py-3 px-4 text-right">Mkt Price</th>
                <th className="py-3 px-4 text-right">Market Value</th>
                <th className="py-3 px-4 text-right">Yield</th>
                <th className="py-3 px-4 text-right">OAS</th>
                <th className="py-3 px-4 text-right">WAL</th>
                <th className="py-3 px-4 text-right">Dur</th>
                <th className="py-3 px-4 text-right">Conv</th>
                <th className="py-3 px-4 text-right">DV01</th>
                <th className="py-3 px-4 text-center">Score</th>
                <th className="py-3 px-4 text-center font-sans">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70">
              {filteredPositions.map((pos) => (
                <tr 
                  key={pos.securityId}
                  className="hover:bg-slate-800/40 transition cursor-pointer"
                  onClick={() => onSelectSecurity(pos.securityId)}
                >
                  <td className="py-3 px-4 font-bold text-orange-400">
                    {pos.securityId}
                  </td>
                  <td className="py-3 px-4 text-slate-200 font-sans font-medium">
                    {pos.securityName}
                    {pos.isAgency && (
                      <span className="ml-2 text-[9px] bg-emerald-950/80 text-emerald-300 px-1.5 py-0.5 rounded border border-emerald-800/40 font-mono font-bold">
                        AGENCY
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-slate-400 font-sans text-xs">
                    {pos.assetClass}
                  </td>
                  <td className="py-3 px-4 text-right text-slate-300">
                    £{(pos.notionalBalance / 1_000_000).toFixed(1)}m
                  </td>
                  <td className="py-3 px-4 text-right text-white font-bold">
                    {pos.marketPrice.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 text-right text-slate-200 font-bold">
                    £{(pos.marketValue / 1_000_000).toFixed(1)}m
                  </td>
                  <td className="py-3 px-4 text-right text-orange-400 font-bold">
                    {(pos.yieldToMaturity * 100).toFixed(2)}%
                  </td>
                  <td className="py-3 px-4 text-right text-emerald-400 font-bold">
                    {pos.oasBps} bp
                  </td>
                  <td className="py-3 px-4 text-right text-cyan-400">
                    {pos.walYears.toFixed(1)}y
                  </td>
                  <td className="py-3 px-4 text-right text-indigo-300 font-bold">
                    {pos.effectiveDuration.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 text-right text-rose-400 font-bold">
                    {pos.effectiveConvexity.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 text-right text-slate-300">
                    £{pos.dv01.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="bg-orange-500/10 text-orange-400 font-bold px-2 py-0.5 rounded border border-orange-500/30">
                      {pos.qualityScore}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center font-sans">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectSecurity(pos.securityId);
                      }}
                      className="text-xs bg-[#11141A] hover:bg-orange-600 hover:text-white text-slate-300 px-2.5 py-1 rounded-md transition border border-slate-700 hover:border-orange-500 flex items-center gap-1 mx-auto"
                    >
                      <span>Analyze</span>
                      <ArrowRight className="h-3 w-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

