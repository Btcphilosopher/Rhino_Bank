import React, { useState } from 'react';
import { PrepaymentConfig } from '../types/mbs';
import { 
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  Legend, BarChart, Bar 
} from 'recharts';
import { Sliders, Flame, Calendar, Activity, Zap, Info } from 'lucide-react';
import { PrepaymentEngine } from '../engine/prepaymentEngine';

interface Props {
  config: PrepaymentConfig;
  onChangeConfig: (newConfig: PrepaymentConfig) => void;
  wac: number;
}

export const PrepaymentLabView: React.FC<Props> = ({ config, onChangeConfig, wac }) => {
  const [marketMortgageRate, setMarketMortgageRate] = useState<number>(config.marketMortgageRate);
  const [modelType, setModelType] = useState<any>(config.modelType);
  const [cprSlider, setCprSlider] = useState<number>(config.cprValue * 100);
  const [psaSlider, setPsaSlider] = useState<number>(config.psaSpeed);
  const [burnoutExp, setBurnoutExp] = useState<number>(config.richardRoll.burnoutExponent);
  const [seasoningMonths, setSeasoningMonths] = useState<number>(config.richardRoll.seasoningRampMonths);

  // Generate S-Curve Data (-300 bps to +300 bps rate spread incentive)
  const sCurveData = [];
  for (let spreadBps = -300; spreadBps <= 300; spreadBps += 25) {
    const spreadPct = spreadBps / 10000;
    const dummyMktRate = wac - spreadPct;
    const testCfg: PrepaymentConfig = {
      ...config,
      marketMortgageRate: dummyMktRate,
      richardRoll: {
        ...config.richardRoll,
        burnoutExponent: burnoutExp,
        seasoningRampMonths: seasoningMonths,
      },
    };
    const { cpr } = PrepaymentEngine.getPeriodSmm(testCfg, wac, 36, 6);
    sCurveData.push({
      spreadBps,
      spreadLabel: `${spreadBps > 0 ? '+' : ''}${spreadBps}bp`,
      cprPct: Math.round(cpr * 1000) / 10,
    });
  }

  // Generate Seasonality Multiplier Chart
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const seasonalityData = config.richardRoll.seasonalityMultipliers.map((mult, idx) => ({
    month: months[idx],
    multiplier: mult,
    cprEquiv: Math.round(config.richardRoll.baseCpr * mult * 1000) / 10,
  }));

  // Seasoning Ramp Data (Months 1 to 60)
  const seasoningData = [];
  for (let m = 1; m <= 60; m += 2) {
    const ramp = Math.min(1.0, m / seasoningMonths);
    seasoningData.push({
      month: `M${m}`,
      ramp: Math.round(ramp * 100) / 100,
      psaCpr: Math.round(Math.min(0.06, 0.06 * (m / 30)) * 1000) / 10,
    });
  }

  const handleApply = () => {
    onChangeConfig({
      ...config,
      modelType,
      marketMortgageRate,
      cprValue: cprSlider / 100,
      psaSpeed: psaSlider,
      richardRoll: {
        ...config.richardRoll,
        burnoutExponent: burnoutExp,
        seasoningRampMonths: seasoningMonths,
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Controller Panel */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-4">
          <div>
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider font-mono flex items-center gap-2">
              <Sliders className="h-4 w-4 text-amber-400" />
              <span>BEHAVIORAL PREPAYMENT LAB (RICHARD & ROLL 4-FACTOR SPECIFICATION)</span>
            </h2>
            <p className="text-xs text-slate-400">
              Interactive tuning for Refinance Incentive S-Curve, Seasoning Ramp, Seasonality, and Burnout Hysteresis
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-slate-300">Model:</span>
            <select
              value={modelType}
              onChange={(e) => setModelType(e.target.value as any)}
              className="bg-slate-800 border border-slate-700 text-xs text-amber-400 font-mono rounded px-3 py-1.5 outline-none focus:border-amber-500 font-bold"
            >
              <option value="RichardRoll4Factor">Richard & Roll 4-Factor (Institutional)</option>
              <option value="ConstantCPR">Constant Prepayment Rate (CPR)</option>
              <option value="PSAStandard">PSA Standard Benchmark (100% PSA = 6% CPR at 30m)</option>
            </select>
          </div>
        </div>

        {/* Sliders Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
          {/* Market Rate Slider */}
          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Current Market Rate:</span>
              <span className="text-amber-400 font-bold">{(marketMortgageRate * 100).toFixed(2)}%</span>
            </div>
            <input
              type="range"
              min="0.03"
              max="0.09"
              step="0.001"
              value={marketMortgageRate}
              onChange={(e) => setMarketMortgageRate(parseFloat(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>Pool WAC: {(wac * 100).toFixed(2)}%</span>
              <span className="text-cyan-400">Spread: {Math.round((wac - marketMortgageRate) * 10000)} bp</span>
            </div>
          </div>

          {/* Constant CPR / Benchmark CPR */}
          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Baseline CPR:</span>
              <span className="text-cyan-400 font-bold">{cprSlider.toFixed(1)}% CPR</span>
            </div>
            <input
              type="range"
              min="1"
              max="50"
              step="0.5"
              value={cprSlider}
              onChange={(e) => setCprSlider(parseFloat(e.target.value))}
              className="w-full accent-cyan-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>Min: 1%</span>
              <span>Max: 50%</span>
            </div>
          </div>

          {/* Seasoning Ramp Months */}
          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Seasoning Ramp:</span>
              <span className="text-indigo-300 font-bold">{seasoningMonths} Months</span>
            </div>
            <input
              type="range"
              min="12"
              max="48"
              step="1"
              value={seasoningMonths}
              onChange={(e) => setSeasoningMonths(parseInt(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>PSA Benchmark: 30m</span>
            </div>
          </div>

          {/* Burnout Exponent */}
          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Burnout Factor (β):</span>
              <span className="text-rose-400 font-bold">{burnoutExp.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="2.5"
              step="0.1"
              value={burnoutExp}
              onChange={(e) => setBurnoutExp(parseFloat(e.target.value))}
              className="w-full accent-rose-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>Hysteresis Sensitivity</span>
            </div>
          </div>
        </div>

        <div className="mt-4 flex justify-end">
          <button
            onClick={handleApply}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold font-mono text-xs px-5 py-2 rounded-lg transition shadow-lg shadow-amber-500/20 flex items-center gap-2"
          >
            <Zap className="h-4 w-4" />
            <span>Apply Calibration to Core Cash Flow Engine</span>
          </button>
        </div>
      </div>

      {/* Behavioral Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* S-Curve Refinance Incentive Chart */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono flex items-center gap-2">
                <Flame className="h-3.5 w-3.5 text-rose-400" />
                <span>Refinance Incentive S-Curve (CPR vs Refi Spread)</span>
              </h3>
              <p className="text-xs text-slate-400">
                Logistic prepayment response: Spread = Pool WAC - Market Rate
              </p>
            </div>
            <span className="text-[11px] font-mono text-amber-400">Richard-Roll S-Curve</span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sCurveData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <XAxis dataKey="spreadLabel" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} unit="%" />
                <Tooltip 
                  formatter={(val: number) => [`${val}% CPR`, 'Projected Prepayment']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
                />
                <Line type="monotone" dataKey="cprPct" stroke="#f59e0b" strokeWidth={2.5} dot={{ r: 2 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-2 bg-slate-950/40 p-2 rounded border border-slate-800/80">
            Current Position: At {(wac * 100).toFixed(2)}% WAC vs {(marketMortgageRate * 100).toFixed(2)}% Mkt Rate (Spread: {Math.round((wac - marketMortgageRate) * 10000)} bps), CPR is running at <strong className="text-amber-400">{(PrepaymentEngine.getPeriodSmm(config, wac, 36, 6).cpr * 100).toFixed(1)}% CPR</strong>.
          </div>
        </div>

        {/* Seasonality Multiplier Chart */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono flex items-center gap-2">
                <Calendar className="h-3.5 w-3.5 text-cyan-400" />
                <span>Monthly Seasonality Multiplier Cycle</span>
              </h3>
              <p className="text-xs text-slate-400">
                Spring/Summer homebuying peak vs Winter seasonal slowdown
              </p>
            </div>
            <span className="text-[11px] font-mono text-cyan-400">June Peak (1.25x)</span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={seasonalityData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <XAxis dataKey="month" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} domain={[0.6, 1.4]} />
                <Tooltip 
                  formatter={(val: number) => [`${val}x multiplier`, 'Seasonality Factor']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
                />
                <Bar dataKey="multiplier" fill="#06b6d4" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-2 bg-slate-950/40 p-2 rounded border border-slate-800/80">
            Prepayment activity peaks in May-July due to family relocations and school calendar cycles (up to +25% over baseline).
          </div>
        </div>
      </div>
    </div>
  );
};
