import React, { useState } from 'react';
import { MortgagePool, PortfolioPosition } from '../types/mbs';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell 
} from 'recharts';
import { Shield, Building2, MapPin, Award, CheckCircle2, Info, ArrowUpRight } from 'lucide-react';

interface Props {
  pools: MortgagePool[];
  positions: PortfolioPosition[];
  selectedPoolId: string;
  onSelectPool: (poolId: string) => void;
  onNavigateToTab: (tab: string) => void;
}

const COLORS = ['#f59e0b', '#3b82f6', '#10b981', '#8b5cf6', '#ec4899', '#06b6d4', '#f43f5e'];

export const SecuritiesView: React.FC<Props> = ({
  pools,
  positions,
  selectedPoolId,
  onSelectPool,
  onNavigateToTab,
}) => {
  const currentPool = pools.find(p => p.poolId === selectedPoolId) || pools[0];
  const currentPosition = positions.find(p => p.securityId === selectedPoolId) || positions[0];

  // Convert Stratifications to arrays for Recharts
  const geoData = Object.entries(currentPool.stratification.geographyDistribution).map(([state, pct]) => ({
    name: state,
    percentage: pct,
  }));

  const ficoData = Object.entries(currentPool.stratification.ficoBrackets).map(([bracket, pct]) => ({
    name: bracket,
    percentage: pct,
  }));

  const ltvData = Object.entries(currentPool.stratification.ltvBrackets).map(([bracket, pct]) => ({
    name: bracket,
    percentage: pct,
  }));

  return (
    <div className="space-y-6">
      {/* Security Selector Bar */}
      <div className="flex flex-wrap items-center gap-2 bg-slate-900/90 border border-slate-800 p-2.5 rounded-xl shadow-lg">
        <span className="text-xs font-bold text-slate-300 uppercase px-2 font-mono">
          SELECT MBS SECURITY:
        </span>
        {pools.map((pool) => {
          const isSelected = pool.poolId === selectedPoolId;
          return (
            <button
              key={pool.poolId}
              onClick={() => onSelectPool(pool.poolId)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition flex items-center gap-2 ${
                isSelected
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
              }`}
            >
              <span>{pool.poolId}</span>
              <span className="text-[10px] opacity-75 font-sans font-normal hidden sm:inline">
                ({pool.assetClass})
              </span>
            </button>
          );
        })}
      </div>

      {/* Security Header Details Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30 font-bold">
                {currentPool.poolId}
              </span>
              <span className="text-xs font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                {currentPool.assetClass}
              </span>
              {currentPool.isAgency && (
                <span className="text-xs font-mono bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800/40 flex items-center gap-1 font-bold">
                  <Shield className="h-3 w-3" />
                  AGENCY GUARANTEED
                </span>
              )}
            </div>
            <h2 className="text-lg font-bold text-slate-100 font-sans">
              {currentPool.poolName}
            </h2>
            <p className="text-xs text-slate-400 font-sans mt-0.5">
              Issuer: <strong className="text-slate-300">{currentPool.issuer}</strong> · Loan Count: <strong className="text-slate-300">{currentPool.totalLoanCount.toLocaleString()} Conforming Collateral</strong>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => onNavigateToTab('CASH_FLOWS')}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-3 py-1.5 rounded-lg border border-slate-700 flex items-center gap-1 transition"
            >
              <span>View Cash Flows</span>
              <ArrowUpRight className="h-3.5 w-3.5 text-amber-400" />
            </button>
            <button
              onClick={() => onNavigateToTab('OAS')}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-3 py-1.5 rounded-lg border border-slate-700 flex items-center gap-1 transition"
            >
              <span>OAS Pricing</span>
              <ArrowUpRight className="h-3.5 w-3.5 text-amber-400" />
            </button>
          </div>
        </div>

        {/* Core Collateral & Valuation Summary Strip (Section 43) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-3 mt-4 text-xs font-mono">
          <div className="bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
            <div className="text-slate-400 text-[10px] uppercase">Market Price</div>
            <div className="text-slate-100 font-bold text-sm mt-0.5">{currentPosition.marketPrice.toFixed(2)}</div>
            <div className="text-[10px] text-slate-400">% of Par</div>
          </div>

          <div className="bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
            <div className="text-slate-400 text-[10px] uppercase">YTM Yield</div>
            <div className="text-emerald-400 font-bold text-sm mt-0.5">{(currentPosition.yieldToMaturity * 100).toFixed(2)}%</div>
            <div className="text-[10px] text-slate-400">IRR to Maturity</div>
          </div>

          <div className="bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
            <div className="text-slate-400 text-[10px] uppercase">Gross WAC</div>
            <div className="text-amber-400 font-bold text-sm mt-0.5">{(currentPool.weightedAverageCoupon * 100).toFixed(2)}%</div>
            <div className="text-[10px] text-slate-400">Net: {(currentPool.weightedAverageNetCoupon * 100).toFixed(2)}%</div>
          </div>

          <div className="bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
            <div className="text-slate-400 text-[10px] uppercase">OAS Spread</div>
            <div className="text-amber-400 font-bold text-sm mt-0.5">{currentPosition.oasBps} bp</div>
            <div className="text-[10px] text-slate-400">Option Adjusted</div>
          </div>

          <div className="bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
            <div className="text-slate-400 text-[10px] uppercase">WAL (Life)</div>
            <div className="text-cyan-400 font-bold text-sm mt-0.5">{currentPosition.walYears.toFixed(1)} yrs</div>
            <div className="text-[10px] text-slate-400">WAM: {currentPool.weightedAverageMaturity}m</div>
          </div>

          <div className="bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
            <div className="text-slate-400 text-[10px] uppercase">Eff Duration</div>
            <div className="text-indigo-300 font-bold text-sm mt-0.5">{currentPosition.effectiveDuration.toFixed(2)}</div>
            <div className="text-[10px] text-slate-400">DV01: £{currentPosition.dv01.toLocaleString()}</div>
          </div>

          <div className="bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
            <div className="text-slate-400 text-[10px] uppercase">Eff Convexity</div>
            <div className="text-rose-400 font-bold text-sm mt-0.5">{currentPosition.effectiveConvexity.toFixed(2)}</div>
            <div className="text-[10px] text-rose-400/80 font-bold">Negative Drag</div>
          </div>

          <div className="bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
            <div className="text-slate-400 text-[10px] uppercase">Quality Score</div>
            <div className="text-amber-300 font-bold text-sm mt-0.5">{currentPosition.qualityScore}/100</div>
            <div className="text-[10px] text-slate-400">RhinoQuant Index</div>
          </div>
        </div>
      </div>

      {/* Collateral Stratifications Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Geographic Distribution */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5 text-amber-400" />
              <span>Geographic Stratification</span>
            </h3>
            <span className="text-[11px] font-mono text-slate-400">% Pool Balance</span>
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={geoData} layout="vertical" margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                <XAxis type="number" stroke="#64748b" fontSize={10} tickLine={false} unit="%" />
                <YAxis dataKey="name" type="category" stroke="#94a3b8" fontSize={11} tickLine={false} width={30} />
                <Tooltip 
                  formatter={(val: number) => [`${val}%`, 'Pool Balance']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
                />
                <Bar dataKey="percentage" fill="#3b82f6" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* FICO Score Distribution */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <Award className="h-3.5 w-3.5 text-emerald-400" />
              <span>Borrower FICO Distribution</span>
            </h3>
            <span className="text-[11px] font-mono text-slate-400">Avg: {currentPool.weightedAverageFico}</span>
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ficoData} margin={{ top: 5, right: 10, left: -15, bottom: 5 }}>
                <XAxis dataKey="name" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} unit="%" />
                <Tooltip 
                  formatter={(val: number) => [`${val}%`, 'FICO Concentration']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
                />
                <Bar dataKey="percentage" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* LTV Distribution */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <Building2 className="h-3.5 w-3.5 text-cyan-400" />
              <span>Current LTV Stratification</span>
            </h3>
            <span className="text-[11px] font-mono text-slate-400">Avg: {currentPool.weightedAverageCurrentLtv}%</span>
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ltvData} margin={{ top: 5, right: 10, left: -15, bottom: 5 }}>
                <XAxis dataKey="name" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} unit="%" />
                <Tooltip 
                  formatter={(val: number) => [`${val}%`, 'LTV Bracket']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
                />
                <Bar dataKey="percentage" fill="#06b6d4" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Loan Sample Inspection Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
          <div>
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
              UNDERLYING LOAN-LEVEL STRATIFICATION SAMPLE ({currentPool.loans.length} LOANS LOADED)
            </h3>
            <p className="text-xs text-slate-400">
              Audit sample showing borrower credit, balance amortisation, geography and rate
            </p>
          </div>
        </div>

        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/40">
                <th className="py-2 px-3">Loan ID</th>
                <th className="py-2 px-3 text-right">Current Balance</th>
                <th className="py-2 px-3 text-right">Original Balance</th>
                <th className="py-2 px-3 text-right">Gross Rate</th>
                <th className="py-2 px-3 text-right">Rem. Term</th>
                <th className="py-2 px-3 text-right">Age (WALA)</th>
                <th className="py-2 px-3 text-right">FICO</th>
                <th className="py-2 px-3 text-right">Curr LTV</th>
                <th className="py-2 px-3 text-center">State</th>
                <th className="py-2 px-3 text-center">Doc Type</th>
                <th className="py-2 px-3 text-center">Occupancy</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {currentPool.loans.slice(0, 8).map((loan) => (
                <tr key={loan.loanId} className="hover:bg-slate-800/40 transition">
                  <td className="py-2 px-3 text-amber-400 font-bold">{loan.loanId}</td>
                  <td className="py-2 px-3 text-right text-slate-200">£{loan.currentBalance.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right text-slate-400">£{loan.originalBalance.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right text-emerald-400 font-bold">{(loan.grossInterestRate * 100).toFixed(2)}%</td>
                  <td className="py-2 px-3 text-right text-slate-300">{loan.remainingTermMonths}m</td>
                  <td className="py-2 px-3 text-right text-slate-300">{loan.ageMonths}m</td>
                  <td className="py-2 px-3 text-right text-slate-100 font-bold">{loan.borrower.ficoScore}</td>
                  <td className="py-2 px-3 text-right text-cyan-400">{loan.currentLtv}%</td>
                  <td className="py-2 px-3 text-center text-slate-300 font-bold">{loan.geographyState}</td>
                  <td className="py-2 px-3 text-center text-slate-400">{loan.borrower.docType}</td>
                  <td className="py-2 px-3 text-center text-slate-400">{loan.occupancy}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
