import React from 'react';
import { PortfolioAnalytics } from '../types/mbs';
import { Shield, TrendingDown, Percent, Clock, AlertTriangle, CheckCircle2, Award, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface Props {
  analytics: PortfolioAnalytics;
  onNavigateTab: (tab: string) => void;
}

export const DashboardMetricsHeader: React.FC<Props> = ({ analytics, onNavigateTab }) => {
  return (
    <div className="mb-6 space-y-4">
      {/* Bento Grid Top Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-4">
        
        {/* Bento Card 1: Core Market Value & Key Metrics (col-span-3) */}
        <div className="lg:col-span-3 bento-card p-5 flex flex-col justify-between relative overflow-hidden">
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Market Value (Base)</span>
              <span className="text-[10px] font-mono bg-orange-950/40 text-orange-400 px-2 py-0.5 rounded border border-orange-800/40">
                ACTIVE
              </span>
            </div>
            <h2 className="text-3xl font-mono font-bold text-white tracking-tight mt-1">
              £{(analytics.totalMarketValue / 1_000_000).toFixed(1)}<span className="text-lg opacity-50 font-normal">M</span>
            </h2>
          </div>

          <div className="grid grid-cols-2 gap-3 mt-4 pt-3 border-t border-slate-800/80">
            <div className="flex flex-col">
              <span className="text-[10px] uppercase text-slate-500 font-bold">Yield</span>
              <span className="text-lg font-mono font-bold text-orange-400">
                {(analytics.weightedYield * 100).toFixed(2)}%
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase text-slate-500 font-bold">OAS</span>
              <span className="text-lg font-mono font-bold text-emerald-400">
                {analytics.weightedOasBps.toFixed(0)} bp
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase text-slate-500 font-bold">Duration</span>
              <span className="text-base font-mono font-bold text-indigo-300">
                {analytics.weightedDuration.toFixed(1)}y
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase text-slate-500 font-bold">Convexity</span>
              <span className="text-base font-mono font-bold text-rose-400">
                {analytics.weightedConvexity.toFixed(1)}
              </span>
            </div>
          </div>
        </div>

        {/* Bento Card 2: Interest Rate & Risk Decomposition (col-span-5) */}
        <div 
          onClick={() => onNavigateTab('CONVEXITY')}
          className="lg:col-span-5 bento-card p-5 flex flex-col justify-between cursor-pointer hover:border-slate-700 transition"
        >
          <div>
            <div className="flex justify-between items-start mb-3">
              <div>
                <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">
                  Interest Rate & Risk Decomposition
                </span>
                <p className="text-xs text-slate-400 mt-0.5">Multi-Factor Portfolio Sensitivity</p>
              </div>
              <div className="flex gap-3 text-[10px] font-mono">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2 h-2 rounded-full bg-orange-500"></span> Rate ({analytics.riskBreakdown.interestRateRiskPct}%)
                </span>
                <span className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2 h-2 rounded-full bg-blue-500"></span> Prepay ({analytics.riskBreakdown.prepaymentRiskPct}%)
                </span>
                <span className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2 h-2 rounded-full bg-rose-500"></span> Credit ({analytics.riskBreakdown.creditRiskPct}%)
                </span>
              </div>
            </div>

            {/* Visual Risk Stacks */}
            <div className="flex items-end gap-3 px-1 h-28 mt-2">
              <div className="w-full h-24 bg-slate-800/30 rounded-t-md relative flex flex-col justify-end overflow-hidden border-b border-slate-700">
                <div className="h-3/4 bg-orange-500/80 w-full" title="Rate Sensitivity: 75%"></div>
                <div className="h-1/4 bg-blue-500/80 w-full" title="Prepay Sensitivity: 25%"></div>
                <div className="h-1/6 bg-rose-500/80 w-full" title="Credit Sensitivity: 15%"></div>
              </div>
              <div className="w-full h-28 bg-slate-800/30 rounded-t-md relative flex flex-col justify-end overflow-hidden border-b border-slate-700">
                <div className="h-2/3 bg-orange-500/80 w-full"></div>
                <div className="h-1/5 bg-blue-500/80 w-full"></div>
              </div>
              <div className="w-full h-20 bg-slate-800/30 rounded-t-md relative flex flex-col justify-end overflow-hidden border-b border-slate-700">
                <div className="h-1/2 bg-orange-500/80 w-full"></div>
                <div className="h-1/3 bg-blue-500/80 w-full"></div>
                <div className="h-1/6 bg-rose-500/80 w-full"></div>
              </div>
              <div className="w-full h-26 bg-slate-800/30 rounded-t-md relative flex flex-col justify-end overflow-hidden border-b border-slate-700">
                <div className="h-4/5 bg-orange-500/80 w-full"></div>
                <div className="h-1/6 bg-blue-500/80 w-full"></div>
              </div>
            </div>
            <div className="flex justify-between mt-2 text-[10px] font-mono text-slate-500 px-1">
              <span>-200bp</span>
              <span className="text-slate-300 font-semibold">Base (£842.6M)</span>
              <span>+200bp</span>
              <span className="text-rose-400">Extreme Stress</span>
            </div>
          </div>
        </div>

        {/* Bento Card 3: Scenario Impact Matrix (col-span-4) */}
        <div 
          onClick={() => onNavigateTab('SCENARIOS')}
          className="lg:col-span-4 bento-card p-5 relative overflow-hidden flex flex-col justify-between cursor-pointer hover:border-slate-700 transition"
        >
          <div>
            <div className="flex justify-between items-center mb-3">
              <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">
                Scenario Impact Matrix
              </span>
              <span className="text-[10px] px-2 py-0.5 bg-slate-800/80 border border-slate-700 text-slate-300 rounded font-mono">
                v2.1 CALIBRATED
              </span>
            </div>

            <div className="space-y-2.5">
              <div className="flex justify-between items-center border-b border-slate-800/80 pb-1.5">
                <span className="text-xs text-slate-400 font-medium">Rates +100bp / PSA 100</span>
                <span className="font-mono text-xs text-rose-400 font-bold flex items-center">
                  <ArrowDownRight className="h-3 w-3 mr-0.5" /> -2.41% P&L
                </span>
              </div>
              <div className="flex justify-between items-center border-b border-slate-800/80 pb-1.5">
                <span className="text-xs text-slate-400 font-medium">Rates -100bp / PSA 250</span>
                <span className="font-mono text-xs text-emerald-400 font-bold flex items-center">
                  <ArrowUpRight className="h-3 w-3 mr-0.5" /> +1.18% P&L
                </span>
              </div>
              <div className="flex justify-between items-center border-b border-slate-800/80 pb-1.5">
                <span className="text-xs text-slate-400 font-medium">Stress Case C (HPI -20%)</span>
                <span className="font-mono text-xs text-rose-400 font-bold flex items-center">
                  <ArrowDownRight className="h-3 w-3 mr-0.5" /> -14.82% P&L
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-400 font-medium">OAS Shift +10bp</span>
                <span className="font-mono text-xs text-slate-400">-0.42% P&L</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bento Grid Second Row: 5 Risk Pillars & Portfolio Risk Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* 1. Rate Risk */}
        <div 
          onClick={() => onNavigateTab('CONVEXITY')}
          className="bento-card hover:border-indigo-500/50 cursor-pointer p-4 transition flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">Rate Risk</span>
            <span className="text-[10px] font-mono bg-indigo-950/80 text-indigo-300 px-1.5 py-0.5 rounded border border-indigo-800/40">
              {analytics.riskBreakdown.interestRateRiskPct}%
            </span>
          </div>
          <div className="my-2">
            <div className="text-xl font-mono font-bold text-indigo-400">
              {analytics.weightedDuration.toFixed(2)}y
            </div>
            <div className="text-[10px] text-slate-500">Effective Duration</div>
          </div>
          <div className="text-[10px] text-slate-400 font-mono flex justify-between border-t border-slate-800/80 pt-1.5">
            <span>DV01:</span>
            <span className="text-slate-200 font-bold">£{analytics.totalDv01.toLocaleString()}</span>
          </div>
        </div>

        {/* 2. Prepayment Risk */}
        <div 
          onClick={() => onNavigateTab('PREPAYMENT')}
          className="bento-card hover:border-orange-500/50 cursor-pointer p-4 transition flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">Prepayment</span>
            <span className="text-[10px] font-mono bg-orange-950/80 text-orange-300 px-1.5 py-0.5 rounded border border-orange-800/40">
              {analytics.riskBreakdown.prepaymentRiskPct}%
            </span>
          </div>
          <div className="my-2">
            <div className="text-xl font-mono font-bold text-orange-400">
              {analytics.weightedConvexity.toFixed(2)}
            </div>
            <div className="text-[10px] text-slate-500">Convexity Asymmetry</div>
          </div>
          <div className="text-[10px] text-slate-400 font-mono flex justify-between border-t border-slate-800/80 pt-1.5">
            <span>Refi Drag:</span>
            <span className="text-orange-300 font-bold">18.5 bps</span>
          </div>
        </div>

        {/* 3. Credit Risk */}
        <div 
          onClick={() => onNavigateTab('CREDIT')}
          className="bento-card hover:border-rose-500/50 cursor-pointer p-4 transition flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">Credit Risk</span>
            <span className="text-[10px] font-mono bg-rose-950/80 text-rose-300 px-1.5 py-0.5 rounded border border-rose-800/40">
              {analytics.riskBreakdown.creditRiskPct}%
            </span>
          </div>
          <div className="my-2">
            <div className="text-xl font-mono font-bold text-rose-400">
              £{(analytics.totalExpectedLoss / 1_000_000).toFixed(1)}m
            </div>
            <div className="text-[10px] text-slate-500">Expected Loss</div>
          </div>
          <div className="text-[10px] text-slate-400 font-mono flex justify-between border-t border-slate-800/80 pt-1.5">
            <span>Stress Loss:</span>
            <span className="text-rose-300 font-bold">£{(analytics.totalStressLoss / 1_000_000).toFixed(1)}m</span>
          </div>
        </div>

        {/* 4. Spread Risk (CS01) */}
        <div 
          onClick={() => onNavigateTab('OAS')}
          className="bento-card hover:border-cyan-500/50 cursor-pointer p-4 transition flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">Spread Risk</span>
            <span className="text-[10px] font-mono bg-cyan-950/80 text-cyan-300 px-1.5 py-0.5 rounded border border-cyan-800/40">
              {analytics.riskBreakdown.spreadRiskPct}%
            </span>
          </div>
          <div className="my-2">
            <div className="text-xl font-mono font-bold text-cyan-400">
              £{analytics.totalCs01.toLocaleString()}
            </div>
            <div className="text-[10px] text-slate-500">CS01 (1bp Move)</div>
          </div>
          <div className="text-[10px] text-slate-400 font-mono flex justify-between border-t border-slate-800/80 pt-1.5">
            <span>OAS Spread:</span>
            <span className="text-cyan-300 font-bold">{analytics.weightedOasBps.toFixed(0)} bps</span>
          </div>
        </div>

        {/* 5. Liquidity Risk */}
        <div 
          onClick={() => onNavigateTab('PORTFOLIO')}
          className="bento-card hover:border-emerald-500/50 cursor-pointer p-4 transition flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">Liquidity</span>
            <span className="text-[10px] font-mono bg-emerald-950/80 text-emerald-300 px-1.5 py-0.5 rounded border border-emerald-800/40">
              {analytics.riskBreakdown.liquidityRiskPct}%
            </span>
          </div>
          <div className="my-2">
            <div className="text-xl font-mono font-bold text-emerald-400">
              48.5%
            </div>
            <div className="text-[10px] text-slate-500">Tier-1 Agency</div>
          </div>
          <div className="text-[10px] text-slate-400 font-mono flex justify-between border-t border-slate-800/80 pt-1.5">
            <span>Non-Agency:</span>
            <span className="text-slate-300 font-bold">51.5%</span>
          </div>
        </div>

        {/* 6. RhinoQuant MBS Score */}
        <div 
          onClick={() => onNavigateTab('RELATIVE_VALUE')}
          className="bento-card hover:border-orange-500/50 cursor-pointer p-4 transition flex flex-col justify-between bg-gradient-to-br from-[#11141A]/80 to-orange-950/20"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-orange-400 uppercase tracking-wider">RQ Score</span>
            <Award className="h-3.5 w-3.5 text-orange-400" />
          </div>
          <div className="my-2">
            <div className="text-2xl font-mono font-bold text-white">
              {Math.round(analytics.portfolioQualityScore)}<span className="text-xs text-slate-500 font-normal">/100</span>
            </div>
            <div className="text-[10px] text-slate-400">Multi-Factor Rating</div>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-red-500 via-orange-500 to-emerald-500 rounded-full" 
              style={{ width: `${analytics.portfolioQualityScore}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Bento Bottom Audit Strip */}
      <div className="bento-card px-5 py-2.5 flex flex-col sm:flex-row justify-between items-center gap-2">
        <div className="flex flex-wrap items-center gap-6 text-[10px] uppercase font-bold tracking-widest text-slate-500 font-mono">
          <span>ENGINE: <strong className="text-slate-300">RUST v3.7.2</strong></span>
          <span>MODEL: <strong className="text-slate-300">R-GLM-CALIB-2024-Q1</strong></span>
          <span>FEED: <strong className="text-slate-300">BLOOMBERG / EIKON BVAL</strong></span>
        </div>
        <div className="text-[10px] font-mono text-slate-400 flex items-center gap-2">
          <div className="status-dot status-dot-green"></div>
          <span className="tracking-wide">SYSTEM AUDITABLE & DETERMINISTIC</span>
        </div>
      </div>
    </div>
  );
};

