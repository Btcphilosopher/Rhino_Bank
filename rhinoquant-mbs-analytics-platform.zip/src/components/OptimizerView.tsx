import React, { useState } from 'react';
import { PortfolioPosition } from '../types/mbs';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  Cell 
} from 'recharts';
import { Sliders, Cpu, Zap, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';
import { PortfolioOptimizer, OptimizationObjective, OptimizationConstraints } from '../engine/portfolioOptimizer';

interface Props {
  positions: PortfolioPosition[];
}

const COLORS = ['#f59e0b', '#3b82f6', '#10b981', '#8b5cf6', '#ec4899'];

export const OptimizerView: React.FC<Props> = ({ positions }) => {
  const [objective, setObjective] = useState<OptimizationObjective>('MAX_SHARPE');
  const [maxDuration, setMaxDuration] = useState<number>(4.8);
  const [maxSinglePosition, setMaxSinglePosition] = useState<number>(35);
  const [minAgency, setMinAgency] = useState<number>(40);
  const [maxLoss, setMaxLoss] = useState<number>(1.5);

  const constraints: OptimizationConstraints = {
    maxDuration,
    maxSinglePositionPct: maxSinglePosition,
    minAgencyPct: minAgency,
    maxExpectedLossPct: maxLoss,
  };

  const optResult = PortfolioOptimizer.optimize(positions, objective, constraints);

  // Allocation Comparison Chart Data (Current vs Optimized)
  const totalCurrMkt = positions.reduce((sum, p) => sum + p.marketValue, 0);
  const comparisonData = positions.map((p, idx) => {
    const currWeightPct = Math.round((p.marketValue / totalCurrMkt) * 1000) / 10;
    const optWeightPct = Math.round((optResult.weights[p.securityId] || 0) * 1000) / 10;
    return {
      securityId: p.securityId,
      name: p.securityName.split(' ')[0] + ' ' + p.securityName.split(' ')[1],
      currentPct: currWeightPct,
      optimizedPct: optWeightPct,
      color: COLORS[idx % COLORS.length],
    };
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30 font-bold">
                CONSTRAINED OPTIMIZER
              </span>
              <span className="text-xs font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                QUADRATIC PROGRAMMING / PROJECTION SOLVER
              </span>
            </div>
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider font-mono">
              PORTFOLIO ALLOCATION OPTIMIZER & CONSTRAINTS SOLVER
            </h2>
            <p className="text-xs text-slate-400">
              Solves for optimal security weights respecting Duration ceilings, Concentration caps, and Agency liquidity requirements
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-slate-300">Objective:</span>
            <select
              value={objective}
              onChange={(e) => setObjective(e.target.value as OptimizationObjective)}
              className="bg-slate-800 border border-slate-700 text-xs text-amber-400 font-mono font-bold rounded px-3 py-1.5 outline-none focus:border-amber-500"
            >
              <option value="MAX_SHARPE">Maximize Risk-Adjusted Sharpe Ratio</option>
              <option value="MAX_YIELD">Maximize Portfolio Yield (YTM)</option>
              <option value="MAX_OAS">Maximize Option-Adjusted Spread (OAS)</option>
              <option value="MIN_DURATION">Minimize Interest Rate Duration</option>
              <option value="MIN_EXPECTED_LOSS">Minimize Expected Credit Loss</option>
            </select>
          </div>
        </div>

        {/* Constraints Sliders */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Max Duration Ceiling:</span>
              <span className="text-indigo-300 font-bold">{maxDuration.toFixed(1)}y</span>
            </div>
            <input
              type="range"
              min="3.5"
              max="6.0"
              step="0.1"
              value={maxDuration}
              onChange={(e) => setMaxDuration(parseFloat(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />
          </div>

          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Max Single Position:</span>
              <span className="text-amber-400 font-bold">{maxSinglePosition}%</span>
            </div>
            <input
              type="range"
              min="20"
              max="50"
              step="1"
              value={maxSinglePosition}
              onChange={(e) => setMaxSinglePosition(parseInt(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Min Agency Floor:</span>
              <span className="text-emerald-400 font-bold">{minAgency}%</span>
            </div>
            <input
              type="range"
              min="20"
              max="70"
              step="5"
              value={minAgency}
              onChange={(e) => setMinAgency(parseInt(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Max Expected Loss:</span>
              <span className="text-rose-400 font-bold">{maxLoss.toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="3.0"
              step="0.1"
              value={maxLoss}
              onChange={(e) => setMaxLoss(parseFloat(e.target.value))}
              className="w-full accent-rose-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Optimized Portfolio Results Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 font-mono text-xs">
        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-lg">
          <div className="text-slate-400 text-[10px] uppercase">Optimized Yield</div>
          <div className="text-emerald-400 font-bold text-sm mt-0.5">
            {(optResult.portfolioYield * 100).toFixed(2)}%
          </div>
          <div className="text-[10px] text-slate-400">Weighted YTM</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-lg">
          <div className="text-slate-400 text-[10px] uppercase">Optimized OAS</div>
          <div className="text-amber-400 font-bold text-sm mt-0.5">
            {optResult.portfolioOas.toFixed(0)} bp
          </div>
          <div className="text-[10px] text-slate-400">Spread Over Tsy</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-lg">
          <div className="text-slate-400 text-[10px] uppercase">Optimized Duration</div>
          <div className="text-indigo-300 font-bold text-sm mt-0.5">
            {optResult.portfolioDuration.toFixed(2)}
          </div>
          <div className="text-[10px] text-slate-400">Target &le; {maxDuration}y</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-lg">
          <div className="text-slate-400 text-[10px] uppercase">Convexity</div>
          <div className="text-rose-400 font-bold text-sm mt-0.5">
            {optResult.portfolioConvexity.toFixed(1)}
          </div>
          <div className="text-[10px] text-slate-400">Negative Drag</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-lg">
          <div className="text-slate-400 text-[10px] uppercase">Expected Loss</div>
          <div className="text-slate-200 font-bold text-sm mt-0.5">
            £{(optResult.portfolioExpectedLoss / 1_000_000).toFixed(2)}m
          </div>
          <div className="text-[10px] text-slate-400">Collateral Loss</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-lg">
          <div className="text-slate-400 text-[10px] uppercase">RhinoQuant Score</div>
          <div className="text-amber-300 font-bold text-sm mt-0.5">
            {optResult.portfolioQualityScore.toFixed(0)}/100
          </div>
          <div className="text-[10px] text-slate-400">Quality Index</div>
        </div>
      </div>

      {/* Allocation Comparison Chart (Current vs Optimized) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div>
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
              SECURITY ALLOCATION COMPARISON: CURRENT WEIGHTS VS OPTIMIZED WEIGHTS (%)
            </h3>
            <p className="text-xs text-slate-400">
              Blue Bars: Current Baseline Allocation · Amber Bars: Optimized Allocation
            </p>
          </div>
        </div>

        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={comparisonData} margin={{ top: 10, right: 20, left: 10, bottom: 20 }}>
              <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
              <YAxis stroke="#64748b" fontSize={10} tickLine={false} unit="%" />
              <Tooltip 
                formatter={(val: number) => [`${val}%`, '']}
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
              />
              <Bar dataKey="currentPct" name="Current Weight %" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="optimizedPct" name="Optimized Weight %" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
