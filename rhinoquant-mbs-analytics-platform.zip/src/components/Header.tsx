import React from 'react';
import { Cpu, Activity, Database, FileText, Code2, RefreshCw } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenReportModal: () => void;
  onOpenCodeModal: () => void;
  onRecalculateAll: () => void;
  isCalculating: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenReportModal,
  onOpenCodeModal,
  onRecalculateAll,
  isCalculating,
}) => {
  const tabs = [
    { id: 'PORTFOLIO', label: 'Portfolio' },
    { id: 'SECURITIES', label: 'Securities' },
    { id: 'CASH_FLOWS', label: 'Cash Flows' },
    { id: 'PREPAYMENT', label: 'Prepayment Lab' },
    { id: 'CREDIT', label: 'Credit & Default' },
    { id: 'WATERFALL', label: 'Structured Waterfall' },
    { id: 'OAS', label: 'OAS & Valuation' },
    { id: 'CONVEXITY', label: 'Negative Convexity' },
    { id: 'SURFACES', label: '3D Surfaces' },
    { id: 'SCENARIOS', label: 'Stress Matrix' },
    { id: 'MONTE_CARLO', label: 'Monte Carlo' },
    { id: 'RELATIVE_VALUE', label: 'Relative Value' },
    { id: 'OPTIMIZER', label: 'Portfolio Optimizer' },
    { id: 'AUDIT', label: 'Audit & Governance' },
  ];

  return (
    <header className="border-b border-slate-800/90 bg-[#070A0F]/90 backdrop-blur-md text-slate-100 sticky top-0 z-40 shadow-2xl">
      {/* Top Ticker & Dual Engine Status Bar */}
      <div className="flex flex-wrap items-center justify-between border-b border-slate-800/80 px-4 sm:px-6 py-2 text-xs text-slate-400 bg-[#090D14]/80">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="status-dot status-dot-green"></div>
            <span className="font-mono font-bold text-xs tracking-wider text-slate-200">RHINOQUANT TERMINAL</span>
          </div>

          <div className="h-4 w-[1px] bg-slate-800 hidden sm:block"></div>

          <div className="hidden sm:flex items-center gap-2">
            <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Rust Core</span>
            <div className="flex items-center gap-1.5 font-mono text-xs">
              <span className="text-emerald-400 font-bold">v3.7.2 ACTIVE</span>
              <div className="status-dot status-dot-green"></div>
            </div>
          </div>

          <div className="h-4 w-[1px] bg-slate-800 hidden md:block"></div>

          <div className="hidden md:flex items-center gap-2">
            <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">R Research</span>
            <div className="flex items-center gap-1.5 font-mono text-xs">
              <span className="text-blue-400 font-bold">v4.3.0 CALIBRATED</span>
              <div className="status-dot status-dot-blue"></div>
            </div>
          </div>

          <div className="h-4 w-[1px] bg-slate-800 hidden lg:block"></div>

          <div className="hidden lg:flex items-center gap-1.5 text-orange-300/90 bg-orange-950/30 px-2 py-0.5 rounded border border-orange-800/40">
            <Database className="h-3 w-3 text-orange-400" />
            <span className="font-mono text-[10px] uppercase font-semibold">Live Market Feed</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden xl:flex items-center gap-3 font-mono text-[11px] text-slate-400">
            <span>10Y Tsy: <strong className="text-slate-200">4.48%</strong></span>
            <span>2Y Tsy: <strong className="text-slate-200">4.10%</strong></span>
            <span>30Y Mtg: <strong className="text-orange-400">6.25%</strong></span>
            <span>SOFR: <strong className="text-slate-200">4.35%</strong></span>
          </div>

          <button
            onClick={onRecalculateAll}
            disabled={isCalculating}
            className="flex items-center gap-1.5 bg-[#11141A] hover:bg-slate-800 text-slate-200 px-3 py-1 rounded-lg text-xs font-medium transition border border-slate-700 disabled:opacity-50"
            title="Recalculate entire portfolio across cash flows, OAS, and Risk engines"
          >
            <RefreshCw className={`h-3 w-3 text-orange-400 ${isCalculating ? 'animate-spin' : ''}`} />
            <span>{isCalculating ? 'Computing...' : 'Recalculate'}</span>
          </button>

          <button
            onClick={onOpenCodeModal}
            className="flex items-center gap-1.5 bg-[#11141A] hover:bg-slate-800 text-blue-300 px-3 py-1 rounded-lg text-xs font-medium transition border border-blue-900/50 hover:border-blue-700/60"
          >
            <Code2 className="h-3 w-3 text-blue-400" />
            <span>Rust & R Code</span>
          </button>

          <button
            onClick={onOpenReportModal}
            className="flex items-center gap-1.5 bg-orange-600/20 hover:bg-orange-600/30 text-orange-300 px-3 py-1 rounded-lg text-xs font-medium transition border border-orange-500/40 shadow-sm"
          >
            <FileText className="h-3 w-3 text-orange-400" />
            <span>Export Report</span>
          </button>
        </div>
      </div>

      {/* Main Terminal Header & Bento Tabs */}
      <div className="px-4 sm:px-6 py-3 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 bg-orange-600 rounded-xl flex items-center justify-center font-bold text-xl italic text-white shadow-lg shadow-orange-600/25 shrink-0">
            RQ
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-white font-sans">
                RHINO<span className="font-light opacity-80">QUANT</span>
              </h1>
              <span className="text-[10px] bg-slate-800/80 text-orange-400 px-2 py-0.5 rounded font-mono font-bold border border-slate-700">
                MBS ENGINE
              </span>
            </div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-semibold">
              Fixed-Income Quantitative Analytics Platform
            </p>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-1 scrollbar-none text-xs">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all duration-150 border ${
                  isActive
                    ? 'bg-orange-600 text-white font-bold border-orange-500 shadow-[0_0_12px_rgba(249,115,22,0.3)]'
                    : 'bg-[#11141A]/60 text-slate-400 hover:text-slate-200 border-slate-800/80 hover:border-slate-700 hover:bg-slate-800/50'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};

