import React, { useState } from 'react';
import { YieldCurve, MortgagePool, PortfolioPosition } from '../types/mbs';
import { 
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  Legend, ReferenceLine 
} from 'recharts';
import { TrendingDown, ArrowDownRight, ArrowUpRight, AlertTriangle, ShieldCheck, Zap } from 'lucide-react';

interface Props {
  position: PortfolioPosition;
  pool: MortgagePool;
}

export const ConvexityView: React.FC<Props> = ({ position, pool }) => {
  const [shiftBps, setShiftBps] = useState<number>(0);

  // Generate Price-Yield Curve comparing MBS (Negatively Convex) vs Bullet Treasury Bond (Positively Convex)
  const priceYieldCurve = [];
  const basePrice = position.marketPrice;
  const baseYield = position.yieldToMaturity * 100;
  const dur = position.effectiveDuration;
  const cvx = position.effectiveConvexity; // e.g. -1.7

  for (let dyBps = -300; dyBps <= 300; dyBps += 25) {
    const dy = dyBps / 10000;
    
    // Bullet Treasury (Positive Convexity +2.5)
    const bulletPrice = basePrice * (1 - dur * dy + 0.5 * 2.5 * Math.pow(dy, 2));

    // MBS with Negative Convexity (Duration shortening when rates drop, extension when rates rise)
    // S-curve prepay dampens upside price gains
    const mbsPrice = basePrice * (1 - dur * dy + 0.5 * cvx * Math.pow(dy, 2));

    // Duration dynamic path
    const dynamicDur = Math.max(1.2, dur + (dyBps / 100) * 0.45);

    priceYieldCurve.push({
      rateShift: `${dyBps > 0 ? '+' : ''}${dyBps}bp`,
      shiftBps: dyBps,
      yieldPct: Math.round((baseYield + dyBps / 100) * 100) / 100,
      mbsPrice: Math.round(mbsPrice * 100) / 100,
      bulletPrice: Math.round(bulletPrice * 100) / 100,
      mbsDuration: Math.round(dynamicDur * 100) / 100,
      bulletDuration: Math.round((dur - (dyBps / 100) * 0.15) * 100) / 100,
    });
  }

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded border border-rose-500/30 font-bold">
                ASYMMETRIC NEGATIVE CONVEXITY
              </span>
              <span className="text-xs font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                EFFECTIVE CONVEXITY: {position.effectiveConvexity.toFixed(2)}
              </span>
            </div>
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider font-mono">
              NEGATIVE CONVEXITY & DURATION EXTENSION / SHORTENING PROFILE
            </h2>
            <p className="text-xs text-slate-400">
              Borrower embedded call option creates capped upside in rate rallies and extended duration in rate sell-offs
            </p>
          </div>

          <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 font-mono text-xs text-right">
            <div className="text-slate-400 text-[10px] uppercase">Convexity Drag</div>
            <div className="text-rose-400 font-bold text-sm">~18.5 bps/yr</div>
            <div className="text-[10px] text-slate-400">Yield Concession Needed</div>
          </div>
        </div>

        {/* 2 Core Asymmetries Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          <div className="bg-slate-950/60 p-4 rounded-xl border border-amber-500/30 flex items-start gap-3">
            <div className="h-8 w-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-base shrink-0">
              ▼
            </div>
            <div>
              <div className="text-amber-300 font-bold uppercase text-xs">
                Rates Drop → Refinancing Surge (Shortening Risk)
              </div>
              <p className="text-slate-400 text-[11px] mt-1 leading-relaxed">
                As mortgage rates fall, borrowers refinance. Prepayments surge (CPR 6% → 35%), returning par cash early. Duration collapses from <strong>{position.effectiveDuration.toFixed(1)}y → 2.1y</strong>, truncating capital gains.
              </p>
            </div>
          </div>

          <div className="bg-slate-950/60 p-4 rounded-xl border border-rose-500/30 flex items-start gap-3">
            <div className="h-8 w-8 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold text-base shrink-0">
              ▲
            </div>
            <div>
              <div className="text-rose-300 font-bold uppercase text-xs">
                Rates Rise → Lock-In Effect (Extension Risk)
              </div>
              <p className="text-slate-400 text-[11px] mt-1 leading-relaxed">
                As mortgage rates rise, borrowers are locked into low rates. Prepayments drop to turnover minimums (CPR ~3%). Duration extends from <strong>{position.effectiveDuration.toFixed(1)}y → 6.8y</strong>, exacerbating capital losses.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Price-Yield & Duration Curves Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Price-Yield Curve (MBS vs Treasury Bullet) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
                PRICE-YIELD CURVE: MBS VS BULLET TREASURY
              </h3>
              <p className="text-xs text-slate-400">
                Notice the characteristic concave downward curve of MBS due to prepayment cap
              </p>
            </div>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={priceYieldCurve} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <XAxis dataKey="rateShift" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} domain={['auto', 'auto']} />
                <Tooltip 
                  formatter={(val: number) => [`${val.toFixed(2)}% Par`, '']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
                />
                <Line type="monotone" dataKey="mbsPrice" name="MBS (Negatively Convex)" stroke="#f43f5e" strokeWidth={2.5} dot={false} />
                <Line type="monotone" dataKey="bulletPrice" name="Bullet Treasury (Positively Convex)" stroke="#3b82f6" strokeWidth={2} strokeDasharray="3 3" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="text-[10px] font-mono text-slate-400 mt-2 flex justify-between">
            <span className="text-rose-400 font-bold">● MBS Price (Capped Upside)</span>
            <span className="text-blue-400 font-bold">--- Bullet Treasury Price</span>
          </div>
        </div>

        {/* Dynamic Duration Extension Curve */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
                DYNAMIC DURATION SHIFT (EXTENSION & SHORTENING)
              </h3>
              <p className="text-xs text-slate-400">
                MBS Duration expands when rates rise (+200bp → +1.5y) and contracts when rates fall
              </p>
            </div>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={priceYieldCurve} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <XAxis dataKey="rateShift" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} domain={[1.0, 8.0]} unit="y" />
                <Tooltip 
                  formatter={(val: number) => [`${val} years`, '']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
                />
                <Line type="monotone" dataKey="mbsDuration" name="MBS Effective Duration" stroke="#f59e0b" strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="text-[10px] font-mono text-amber-400 mt-2">
            ▲ High Rate Risk: In a bear market (+200bp rate hike), MBS portfolio duration extends, inflicting greater mark-to-market loss than anticipated from static duration.
          </div>
        </div>
      </div>
    </div>
  );
};
