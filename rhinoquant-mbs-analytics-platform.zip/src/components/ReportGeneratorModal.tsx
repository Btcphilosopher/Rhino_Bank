import React, { useState } from 'react';
import { PortfolioAnalytics, PortfolioPosition } from '../types/mbs';
import { X, FileText, Download, Printer, CheckCircle2, Shield } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  analytics: PortfolioAnalytics;
  positions: PortfolioPosition[];
}

export const ReportGeneratorModal: React.FC<Props> = ({
  isOpen,
  onClose,
  analytics,
  positions,
}) => {
  const [reportTitle, setReportTitle] = useState('Rhino Bank - MBS Fixed Income Risk & Valuation Committee Report');
  const [preparedBy, setPreparedBy] = useState('RhinoQuant Fixed-Income Structured Credit Analytics Group');
  const [includeStress, setIncludeStress] = useState(true);
  const [includeLineage, setIncludeLineage] = useState(true);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadHtml = () => {
    const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <title>${reportTitle}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; padding: 40px; color: #1e293b; background: #fff; line-height: 1.5; }
    h1 { font-size: 22px; color: #0f172a; margin-bottom: 4px; }
    .subtitle { color: #64748b; font-size: 13px; margin-bottom: 24px; }
    .kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 30px; }
    .kpi-card { border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; background: #f8fafc; }
    .kpi-title { font-size: 11px; text-transform: uppercase; color: #64748b; font-weight: 600; }
    .kpi-val { font-size: 20px; font-weight: bold; color: #0f172a; margin-top: 4px; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 12px; }
    th { text-align: left; background: #f1f5f9; padding: 10px; border-bottom: 2px solid #cbd5e1; font-weight: 600; }
    td { padding: 10px; border-bottom: 1px solid #e2e8f0; }
    .text-right { text-align: right; }
    .footer { margin-top: 50px; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; padding-top: 15px; }
  </style>
</head>
<body>
  <h1>${reportTitle}</h1>
  <div class="subtitle">Prepared by ${preparedBy} · Date: ${new Date().toLocaleDateString()} · Engine: RhinoQuant MBS Core v2.4.0</div>

  <div class="kpi-grid">
    <div class="kpi-card">
      <div class="kpi-title">Market Value</div>
      <div class="kpi-val">£${(analytics.totalMarketValue / 1_000_000).toFixed(1)}m</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-title">Weighted Yield (YTM)</div>
      <div class="kpi-val">${(analytics.weightedYield * 100).toFixed(2)}%</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-title">Portfolio OAS</div>
      <div class="kpi-val">${analytics.weightedOasBps.toFixed(0)} bp</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-title">Effective Duration</div>
      <div class="kpi-val">${analytics.weightedDuration.toFixed(2)}y</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-title">Effective Convexity</div>
      <div class="kpi-val">${analytics.weightedConvexity.toFixed(2)}</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-title">Total DV01</div>
      <div class="kpi-val">£${analytics.totalDv01.toLocaleString()}</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-title">Expected Loss</div>
      <div class="kpi-val">£${(analytics.totalExpectedLoss / 1_000_000).toFixed(1)}m</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-title">RhinoQuant MBS Score</div>
      <div class="kpi-val">${analytics.portfolioQualityScore.toFixed(0)}/100</div>
    </div>
  </div>

  <h2>MBS Portfolio Holdings Schedule</h2>
  <table>
    <thead>
      <tr>
        <th>Security ID</th>
        <th>Description</th>
        <th>Asset Class</th>
        <th class="text-right">Price</th>
        <th class="text-right">Market Value (£)</th>
        <th class="text-right">Yield</th>
        <th class="text-right">OAS</th>
        <th class="text-right">WAL</th>
        <th class="text-right">Duration</th>
        <th class="text-right">Convexity</th>
        <th class="text-right">Score</th>
      </tr>
    </thead>
    <tbody>
      ${positions.map(p => `
        <tr>
          <td><strong>${p.securityId}</strong></td>
          <td>${p.securityName}</td>
          <td>${p.assetClass}</td>
          <td class="text-right">${p.marketPrice.toFixed(2)}</td>
          <td class="text-right">£${(p.marketValue / 1_000_000).toFixed(1)}m</td>
          <td class="text-right">${(p.yieldToMaturity * 100).toFixed(2)}%</td>
          <td class="text-right">${p.oasBps} bp</td>
          <td class="text-right">${p.walYears.toFixed(1)}y</td>
          <td class="text-right">${p.effectiveDuration.toFixed(2)}</td>
          <td class="text-right">${p.effectiveConvexity.toFixed(2)}</td>
          <td class="text-right"><strong>${p.qualityScore}</strong></td>
        </tr>
      `).join('')}
    </tbody>
  </table>

  <div class="footer">
    CONFIDENTIAL & PROPRIETARY — FOR INSTITUTIONAL USE ONLY. Calculated via RhinoQuant Rust+R Mortgage Engine. All results auditable and reproducible under SR 11-7 model risk management guidelines.
  </div>
</body>
</html>
    `;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RhinoQuant_MBS_Report_${new Date().toISOString().split('T')[0]}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-amber-400" />
            <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider font-mono">
              INSTITUTIONAL RISK REPORT GENERATOR
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4 text-xs font-mono">
          <div className="space-y-1">
            <label className="text-slate-300 font-bold">Report Title</label>
            <input
              type="text"
              value={reportTitle}
              onChange={(e) => setReportTitle(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 outline-none focus:border-amber-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-bold">Prepared By / Department</label>
            <input
              type="text"
              value={preparedBy}
              onChange={(e) => setPreparedBy(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 outline-none focus:border-amber-500"
            />
          </div>

          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="text-slate-300 font-bold uppercase text-[11px]">Included Analytical Sections:</div>
            
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="sec-overview"
                checked={true}
                disabled
                className="h-4 w-4 accent-amber-500 rounded"
              />
              <label htmlFor="sec-overview" className="text-slate-300">
                1. Executive Portfolio Valuation & 5-Pillar Risk Metrics Summary
              </label>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="sec-holdings"
                checked={true}
                disabled
                className="h-4 w-4 accent-amber-500 rounded"
              />
              <label htmlFor="sec-holdings" className="text-slate-300">
                2. Detailed Securities & Tranche Breakdown Schedule
              </label>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="sec-stress"
                checked={includeStress}
                onChange={(e) => setIncludeStress(e.target.checked)}
                className="h-4 w-4 accent-amber-500 rounded cursor-pointer"
              />
              <label htmlFor="sec-stress" className="text-slate-300 cursor-pointer">
                3. Multi-Factor Stress Testing Matrix (+300bp / Housing Shock)
              </label>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="sec-lineage"
                checked={includeLineage}
                onChange={(e) => setIncludeLineage(e.target.checked)}
                className="h-4 w-4 accent-amber-500 rounded cursor-pointer"
              />
              <label htmlFor="sec-lineage" className="text-slate-300 cursor-pointer">
                4. Model Governance Lineage & Audit Signature Sign-off (SR 11-7)
              </label>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="text-[11px] text-slate-400 flex items-center gap-1">
            <Shield className="h-3.5 w-3.5 text-emerald-400" />
            <span>Format: High-Res HTML & Print-Ready PDF</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-4 py-2 rounded-lg border border-slate-700 font-mono transition flex items-center gap-1.5"
            >
              <Printer className="h-3.5 w-3.5 text-slate-400" />
              <span>Print PDF</span>
            </button>
            <button
              onClick={handleDownloadHtml}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs px-4 py-2 rounded-lg font-mono transition shadow-lg shadow-amber-500/20 flex items-center gap-1.5"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Download HTML Report</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
