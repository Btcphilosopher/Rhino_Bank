import React, { useState } from 'react';
import { DefaultConfig, MortgagePool } from '../types/mbs';
import { 
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  AreaChart, Area 
} from 'recharts';
import { AlertTriangle, ShieldAlert, TrendingDown, Home, Percent, RefreshCw } from 'lucide-react';
import { DefaultEngine } from '../engine/defaultEngine';

interface Props {
  config: DefaultConfig;
  onChangeConfig: (newConfig: DefaultConfig) => void;
  pool: MortgagePool;
}

export const CreditView: React.FC<Props> = ({ config, onChangeConfig, pool }) => {
  const [annualCdr, setAnnualCdr] = useState<number>(config.annualizedCdr * 100);
  const [sdaPct, setSdaPct] = useState<number>(config.sdaPercentage);
  const [recoveryRate, setRecoveryRate] = useState<number>(config.baseRecoveryRate * 100);
  const [foreclosureCosts, setForeclosureCosts] = useState<number>(config.foreclosureCostsPct * 100);
  const [recoveryLag, setRecoveryLag] = useState<number>(config.recoveryLagMonths);
  const [propertyShock, setPropertyShock] = useState<number>(config.propertyPriceShock * 100);

  // Generate 360-month Default Rate & Cumulative Loss Curves
  const projectionData = [];
  let cumLoss = 0;
  let remainingBal = pool.currentPoolBalance;

  for (let m = 1; m <= 120; m += 2) {
    const testCfg: DefaultConfig = {
      ...config,
      annualizedCdr: annualCdr / 100,
      sdaPercentage: sdaPct,
      baseRecoveryRate: recoveryRate / 100,
      foreclosureCostsPct: foreclosureCosts / 100,
      recoveryLagMonths: recoveryLag,
      propertyPriceShock: propertyShock / 100,
    };

    const { mdr } = DefaultEngine.getPeriodMdr(testCfg, pool.weightedAverageCurrentLtv, pool.weightedAverageFico, m);
    const defBal = remainingBal * mdr;
    const { lossSeverity: lossSev } = DefaultEngine.calculateNetRecovery(testCfg, defBal, remainingBal / (pool.weightedAverageCurrentLtv / 100));
    const loss = pool.isAgency ? 0 : defBal * lossSev;
    
    cumLoss += loss;
    remainingBal = Math.max(0, remainingBal - defBal - remainingBal * 0.005);

    projectionData.push({
      month: `M${m}`,
      mdrPct: Math.round(mdr * 12 * 1000) / 10, // Annualized CDR %
      lossSevPct: Math.round(lossSev * 1000) / 10,
      monthlyLoss: Math.round(loss),
      cumLossMillion: Math.round((cumLoss / 1_000_000) * 100) / 100,
    });
  }

  const handleApply = () => {
    onChangeConfig({
      ...config,
      annualizedCdr: annualCdr / 100,
      sdaPercentage: sdaPct,
      baseRecoveryRate: recoveryRate / 100,
      foreclosureCostsPct: foreclosureCosts / 100,
      recoveryLagMonths: recoveryLag,
      propertyPriceShock: propertyShock / 100,
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Credit Control & Stress Panel */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-4">
          <div>
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider font-mono flex items-center gap-2">
              <ShieldAlert className="h-4 w-4 text-rose-400" />
              <span>CREDIT RISK & LOSS GIVEN DEFAULT (LGD) ENGINE</span>
            </h2>
            <p className="text-xs text-slate-400">
              Macro housing shock simulator, Standard Default Assumption (SDA), and Liquidation Recovery Lag
            </p>
          </div>

          <button
            onClick={handleApply}
            className="bg-rose-600 hover:bg-rose-500 text-white font-bold font-mono text-xs px-4 py-2 rounded-lg transition shadow-lg shadow-rose-600/20 flex items-center gap-2"
          >
            <RefreshCw className="h-4 w-4" />
            <span>Apply Credit Parameters</span>
          </button>
        </div>

        {/* Sliders Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 font-mono text-xs">
          {/* Annual CDR Slider */}
          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Annualized CDR:</span>
              <span className="text-rose-400 font-bold">{annualCdr.toFixed(2)}% CDR</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="15.0"
              step="0.1"
              value={annualCdr}
              onChange={(e) => setAnnualCdr(parseFloat(e.target.value))}
              className="w-full accent-rose-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>Prime Avg: ~0.8%</span>
              <span>Subprime: 8-12%</span>
            </div>
          </div>

          {/* Property Price Shock (-30% to +10%) */}
          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Property Price Shock (HPI):</span>
              <span className={`font-bold ${propertyShock < 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {propertyShock > 0 ? '+' : ''}{propertyShock.toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min="-35"
              max="15"
              step="1"
              value={propertyShock}
              onChange={(e) => setPropertyShock(parseInt(e.target.value))}
              className="w-full accent-rose-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>Severe Crash: -25%</span>
              <span>Effective LTV: {(pool.weightedAverageCurrentLtv / (1 + propertyShock / 100)).toFixed(1)}%</span>
            </div>
          </div>

          {/* Base Recovery Rate (30% to 90%) */}
          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Liquidation Recovery Rate:</span>
              <span className="text-emerald-400 font-bold">{recoveryRate.toFixed(0)}% (LGD: {(100 - recoveryRate).toFixed(0)}%)</span>
            </div>
            <input
              type="range"
              min="30"
              max="90"
              step="1"
              value={recoveryRate}
              onChange={(e) => setRecoveryRate(parseInt(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>Foreclosure Cost: {foreclosureCosts}%</span>
              <span>Net Recovery: {(recoveryRate - foreclosureCosts).toFixed(0)}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Credit Risk Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cumulative Projected Losses */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono flex items-center gap-2">
                <TrendingDown className="h-3.5 w-3.5 text-rose-400" />
                <span>Cumulative Realized Credit Losses (£ Millions)</span>
              </h3>
              <p className="text-xs text-slate-400">
                Total collateral loss absorption path over 120 months
              </p>
            </div>
            <span className="text-[11px] font-mono text-rose-400">
              {pool.isAgency ? 'Agency Insured' : `Total Loss: £${projectionData[projectionData.length - 1]?.cumLossMillion}m`}
            </span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={projectionData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                <XAxis dataKey="month" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} unit="m" />
                <Tooltip 
                  formatter={(val: number) => [`£${val}m`, 'Cumulative Loss']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
                />
                <Area type="monotone" dataKey="cumLossMillion" stroke="#f43f5e" fill="#f43f5e" fillOpacity={0.4} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Annualized Default Curve (CDR) & Severity */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono flex items-center gap-2">
                <Percent className="h-3.5 w-3.5 text-amber-400" />
                <span>Monthly Annualized CDR & Loss Severity (%)</span>
              </h3>
              <p className="text-xs text-slate-400">
                SDA Ramp (peak at month 30) multiplied by macro stress factor
              </p>
            </div>
            <span className="text-[11px] font-mono text-amber-400">SDA 100% Standard</span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={projectionData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <XAxis dataKey="month" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} unit="%" />
                <Tooltip 
                  formatter={(val: number) => [`${val}%`, '']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
                />
                <Line type="monotone" dataKey="mdrPct" name="Annualized CDR %" stroke="#f59e0b" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="lossSevPct" name="Loss Severity %" stroke="#f43f5e" strokeWidth={2} strokeDasharray="3 3" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
