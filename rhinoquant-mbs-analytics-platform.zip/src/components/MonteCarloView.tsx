import React, { useState } from 'react';
import { PortfolioPosition } from '../types/mbs';
import { 
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  BarChart, Bar 
} from 'recharts';
import { Cpu, Zap, Activity, ShieldAlert, Dice5 } from 'lucide-react';
import { MonteCarloEngine } from '../engine/monteCarloEngine';

interface Props {
  position: PortfolioPosition;
}

export const MonteCarloView: React.FC<Props> = ({ position }) => {
  const [numPaths, setNumPaths] = useState<number>(3000);
  const [seed, setSeed] = useState<number>(42);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const [mcResult, setMcResult] = useState(() => 
    MonteCarloEngine.runSimulation(
      position.marketPrice,
      position.yieldToMaturity,
      position.walYears,
      position.effectiveDuration,
      position.expectedLoss,
      3000,
      42
    )
  );

  const handleRunSimulation = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const res = MonteCarloEngine.runSimulation(
        position.marketPrice,
        position.yieldToMaturity,
        position.walYears,
        position.effectiveDuration,
        position.expectedLoss,
        numPaths,
        seed
      );
      setMcResult(res);
      setIsSimulating(false);
    }, 150);
  };

  // Distribution chart data
  const percentileData = [
    { label: 'P1 (Worst 1%)', price: mcResult.priceDistribution.p1, wal: mcResult.walDistribution.p1, dur: mcResult.durationDistribution.p1 },
    { label: 'P5 (Worst 5%)', price: mcResult.priceDistribution.p5, wal: mcResult.walDistribution.p5, dur: mcResult.durationDistribution.p5 },
    { label: 'P25 (25th Pct)', price: mcResult.priceDistribution.p25, wal: mcResult.walDistribution.p25, dur: mcResult.durationDistribution.p25 },
    { label: 'P50 (Median)', price: mcResult.priceDistribution.p50Median, wal: mcResult.walDistribution.p50Median, dur: mcResult.durationDistribution.p50Median },
    { label: 'P75 (75th Pct)', price: mcResult.priceDistribution.p75, wal: mcResult.walDistribution.p75, dur: mcResult.durationDistribution.p75 },
    { label: 'P95 (Top 5%)', price: mcResult.priceDistribution.p95, wal: mcResult.walDistribution.p95, dur: mcResult.durationDistribution.p95 },
    { label: 'P99 (Top 1%)', price: mcResult.priceDistribution.p99, wal: mcResult.walDistribution.p99, dur: mcResult.durationDistribution.p99 },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner & Controller */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded border border-indigo-500/30 font-bold">
                STOCHASTIC ENGINE
              </span>
              <span className="text-xs font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                {mcResult.totalSimulatedPaths.toLocaleString()} PATHS GENERATED
              </span>
            </div>
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider font-mono">
              MONTE CARLO PROBABILITY DISTRIBUTIONS & 99% VALUE AT RISK (VaR)
            </h2>
            <p className="text-xs text-slate-400">
              Correlated interest rate, prepayment and default joint path simulation with deterministic pseudo-random seeds
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleRunSimulation}
              disabled={isSimulating}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold font-mono text-xs px-5 py-2 rounded-lg transition shadow-lg shadow-indigo-600/20 flex items-center gap-2 disabled:opacity-50"
            >
              <Dice5 className={`h-4 w-4 ${isSimulating ? 'animate-spin' : ''}`} />
              <span>{isSimulating ? 'Simulating Paths...' : 'Re-Run Simulation'}</span>
            </button>
          </div>
        </div>

        {/* Configuration Strip */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Simulated Paths:</span>
              <span className="text-indigo-400 font-bold">{numPaths.toLocaleString()}</span>
            </div>
            <input
              type="range"
              min="1000"
              max="10000"
              step="500"
              value={numPaths}
              onChange={(e) => setNumPaths(parseInt(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />
          </div>

          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Deterministic Seed:</span>
              <span className="text-amber-400 font-bold">{seed}</span>
            </div>
            <input
              type="number"
              value={seed}
              onChange={(e) => setSeed(parseInt(e.target.value) || 1)}
              className="w-full bg-slate-900 border border-slate-700 px-2 py-1 rounded text-slate-200"
            />
          </div>

          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-rose-900/40">
            <div className="text-rose-400 uppercase text-[10px] flex items-center gap-1">
              <ShieldAlert className="h-3 w-3" />
              <span>1-Yr 99% VaR (% Par)</span>
            </div>
            <div className="text-rose-300 font-bold text-lg mt-1">
              -{mcResult.valueAtRisk99_1y.toFixed(2)} pts
            </div>
            <div className="text-[10px] text-slate-400">99% Confidence Bound</div>
          </div>

          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-rose-900/40">
            <div className="text-rose-400 uppercase text-[10px] flex items-center gap-1">
              <ShieldAlert className="h-3 w-3" />
              <span>1-Yr 99% CVaR (Expected Shortfall)</span>
            </div>
            <div className="text-rose-300 font-bold text-lg mt-1">
              -{mcResult.conditionalVar99.toFixed(2)} pts
            </div>
            <div className="text-[10px] text-slate-400">Average Tail Loss</div>
          </div>
        </div>
      </div>

      {/* Percentiles Fan Chart & Sample Paths Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Fan Distribution Chart */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
              CLEAN PRICE PERCENTILE DISTRIBUTION (FAN PROFILE)
            </h3>
            <span className="text-[11px] font-mono text-emerald-400">
              Mean: {mcResult.priceDistribution.mean.toFixed(2)} | StdDev: ±{mcResult.priceDistribution.standardDeviation.toFixed(2)}
            </span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={percentileData} margin={{ top: 10, right: 10, left: -10, bottom: 20 }}>
                <XAxis dataKey="label" stroke="#64748b" fontSize={9} tickLine={false} angle={-15} textAnchor="end" />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} domain={[70, 110]} />
                <Tooltip 
                  formatter={(val: number) => [`${val.toFixed(2)}% Par`, 'Price']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
                />
                <Bar dataKey="price" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Percentile Table */}
        <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
              DISTRIBUTION PERCENTILES
            </h3>
          </div>

          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2">Percentile</th>
                  <th className="py-2 text-right">Price</th>
                  <th className="py-2 text-right">Yield</th>
                  <th className="py-2 text-right">WAL</th>
                  <th className="py-2 text-right">Duration</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40">
                <tr>
                  <td className="py-2 text-rose-400 font-bold">P1 (Tail)</td>
                  <td className="py-2 text-right font-bold">{mcResult.priceDistribution.p1.toFixed(2)}</td>
                  <td className="py-2 text-right">{(mcResult.yieldDistribution.p99 * 100).toFixed(2)}%</td>
                  <td className="py-2 text-right">{mcResult.walDistribution.p99.toFixed(1)}y</td>
                  <td className="py-2 text-right">{mcResult.durationDistribution.p99.toFixed(2)}</td>
                </tr>
                <tr>
                  <td className="py-2 text-amber-400">P5</td>
                  <td className="py-2 text-right font-bold">{mcResult.priceDistribution.p5.toFixed(2)}</td>
                  <td className="py-2 text-right">{(mcResult.yieldDistribution.p95 * 100).toFixed(2)}%</td>
                  <td className="py-2 text-right">{mcResult.walDistribution.p95.toFixed(1)}y</td>
                  <td className="py-2 text-right">{mcResult.durationDistribution.p95.toFixed(2)}</td>
                </tr>
                <tr>
                  <td className="py-2 text-slate-300">P25</td>
                  <td className="py-2 text-right">{mcResult.priceDistribution.p25.toFixed(2)}</td>
                  <td className="py-2 text-right">{(mcResult.yieldDistribution.p75 * 100).toFixed(2)}%</td>
                  <td className="py-2 text-right">{mcResult.walDistribution.p75.toFixed(1)}y</td>
                  <td className="py-2 text-right">{mcResult.durationDistribution.p75.toFixed(2)}</td>
                </tr>
                <tr className="bg-slate-800/40">
                  <td className="py-2 text-amber-300 font-bold">P50 (Median)</td>
                  <td className="py-2 text-right font-bold text-amber-300">{mcResult.priceDistribution.p50Median.toFixed(2)}</td>
                  <td className="py-2 text-right text-emerald-400 font-bold">{(mcResult.yieldDistribution.p50Median * 100).toFixed(2)}%</td>
                  <td className="py-2 text-right text-cyan-400 font-bold">{mcResult.walDistribution.p50Median.toFixed(1)}y</td>
                  <td className="py-2 text-right text-indigo-300 font-bold">{mcResult.durationDistribution.p50Median.toFixed(2)}</td>
                </tr>
                <tr>
                  <td className="py-2 text-slate-300">P75</td>
                  <td className="py-2 text-right">{mcResult.priceDistribution.p75.toFixed(2)}</td>
                  <td className="py-2 text-right">{(mcResult.yieldDistribution.p25 * 100).toFixed(2)}%</td>
                  <td className="py-2 text-right">{mcResult.walDistribution.p25.toFixed(1)}y</td>
                  <td className="py-2 text-right">{mcResult.durationDistribution.p25.toFixed(2)}</td>
                </tr>
                <tr>
                  <td className="py-2 text-emerald-400 font-bold">P95</td>
                  <td className="py-2 text-right font-bold">{mcResult.priceDistribution.p95.toFixed(2)}</td>
                  <td className="py-2 text-right">{(mcResult.yieldDistribution.p5 * 100).toFixed(2)}%</td>
                  <td className="py-2 text-right">{mcResult.walDistribution.p5.toFixed(1)}y</td>
                  <td className="py-2 text-right">{mcResult.durationDistribution.p5.toFixed(2)}</td>
                </tr>
                <tr>
                  <td className="py-2 text-emerald-400 font-bold">P99</td>
                  <td className="py-2 text-right font-bold">{mcResult.priceDistribution.p99.toFixed(2)}</td>
                  <td className="py-2 text-right">{(mcResult.yieldDistribution.p1 * 100).toFixed(2)}%</td>
                  <td className="py-2 text-right">{mcResult.walDistribution.p1.toFixed(1)}y</td>
                  <td className="py-2 text-right">{mcResult.durationDistribution.p1.toFixed(2)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
