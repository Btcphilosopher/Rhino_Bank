import React, { useState } from 'react';
import { PortfolioPosition } from '../types/mbs';
import { Layers, Eye, RefreshCw, Compass } from 'lucide-react';

interface Props {
  position: PortfolioPosition;
}

export const SurfacesView: React.FC<Props> = ({ position }) => {
  const [metricMode, setMetricMode] = useState<'PRICE' | 'OAS' | 'WAL'>('PRICE');
  const [viewAngle, setViewAngle] = useState<number>(35); // tilt angle for isometric projection

  // Grid points:
  // Rate shifts: -200bp, -150bp, -100bp, -50bp, 0bp, +50bp, +100bp, +150bp, +200bp
  const rateShifts = [-200, -150, -100, -50, 0, 50, 100, 150, 200];
  // Prepayment CPRs: 4%, 8%, 12%, 16%, 20%, 25%, 30%, 40%
  const prepayCprs = [4, 8, 12, 16, 20, 25, 30, 40];

  const basePrice = position.marketPrice;
  const baseOas = position.oasBps;
  const baseWal = position.walYears;

  // Calculate 2D Matrix of values
  const matrix = rateShifts.map((r) => {
    return prepayCprs.map((c) => {
      // Dynamic model calculation
      const rDec = r / 10000;
      const cDec = c / 100;

      // Price calculation under rate shift and prepay speed
      const price = basePrice * (1 - position.effectiveDuration * rDec - 0.5 * 1.7 * Math.pow(rDec, 2) - (cDec > 0.15 ? (cDec - 0.15) * 12 : 0));
      const oas = Math.max(10, baseOas + (r / 100) * 8 - (c - 6) * 2.2);
      const wal = Math.max(1.2, baseWal + (r / 100) * 0.45 - (c - 6) * 0.15);

      return {
        rateShift: r,
        cpr: c,
        price: Math.round(price * 100) / 100,
        oas: Math.round(oas * 10) / 10,
        wal: Math.round(wal * 10) / 10,
      };
    });
  });

  const [hoveredCell, setHoveredCell] = useState<{ rateShift: number; cpr: number; price: number; oas: number; wal: number } | null>(null);

  const getColor = (val: number, min: number, max: number) => {
    const norm = Math.max(0, Math.min(1, (val - min) / (max - min || 1)));
    if (metricMode === 'PRICE') {
      // Emerald (high) to Rose (low)
      if (norm > 0.6) return `rgba(16, 185, 129, ${0.3 + norm * 0.7})`;
      if (norm > 0.35) return `rgba(245, 158, 11, ${0.3 + norm * 0.7})`;
      return `rgba(244, 63, 94, ${0.3 + (1 - norm) * 0.7})`;
    } else if (metricMode === 'OAS') {
      // Cyan to Indigo
      return `rgba(6, 182, 212, ${0.25 + norm * 0.75})`;
    } else {
      // Indigo to Amber
      return `rgba(99, 102, 241, ${0.25 + norm * 0.75})`;
    }
  };

  const getMetricValue = (cell: { price: number; oas: number; wal: number }) => {
    if (metricMode === 'PRICE') return cell.price;
    if (metricMode === 'OAS') return cell.oas;
    return cell.wal;
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30 font-bold">
                MULTI-DIMENSIONAL VALUATION
              </span>
              <span className="text-xs font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                SECURITY: {position.securityId}
              </span>
            </div>
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider font-mono">
              INTEREST RATE SHIFT × PREPAYMENT SPEED (CPR) VALUATION SURFACE
            </h2>
            <p className="text-xs text-slate-400">
              Interactive 2D/3D Grid showing non-linear price degradation and OAS sensitivity across macro shocks
            </p>
          </div>

          {/* Metric Selector Tabs */}
          <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800 font-mono text-xs">
            <button
              onClick={() => setMetricMode('PRICE')}
              className={`px-3 py-1.5 rounded font-bold transition ${
                metricMode === 'PRICE' ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              Price (% Par)
            </button>
            <button
              onClick={() => setMetricMode('OAS')}
              className={`px-3 py-1.5 rounded font-bold transition ${
                metricMode === 'OAS' ? 'bg-cyan-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              OAS (bps)
            </button>
            <button
              onClick={() => setMetricMode('WAL')}
              className={`px-3 py-1.5 rounded font-bold transition ${
                metricMode === 'WAL' ? 'bg-indigo-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              WAL (Years)
            </button>
          </div>
        </div>

        {/* Hover Coordinate Inspector */}
        <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 font-mono text-xs flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Compass className="h-4 w-4 text-amber-400" />
            <span className="text-slate-300 font-bold">SURFACE COORDINATE INSPECTOR:</span>
          </div>

          {hoveredCell ? (
            <div className="flex items-center gap-4 text-xs">
              <span>Rate Shift: <strong className="text-amber-400">{hoveredCell.rateShift > 0 ? '+' : ''}{hoveredCell.rateShift} bps</strong></span>
              <span>CPR Speed: <strong className="text-cyan-400">{hoveredCell.cpr}% CPR</strong></span>
              <span>Clean Price: <strong className="text-slate-100 font-bold">{hoveredCell.price.toFixed(2)}</strong></span>
              <span>OAS: <strong className="text-amber-300 font-bold">{hoveredCell.oas} bp</strong></span>
              <span>WAL: <strong className="text-indigo-300 font-bold">{hoveredCell.wal}y</strong></span>
            </div>
          ) : (
            <div className="text-slate-500 italic">
              Hover over any surface grid cell to inspect joint sensitivity
            </div>
          )}
        </div>
      </div>

      {/* Surface Heatmap / Matrix Grid Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
            {metricMode === 'PRICE' ? 'MBS CLEAN PRICE MATRIX (% OF PAR)' : metricMode === 'OAS' ? 'OPTION-ADJUSTED SPREAD MATRIX (BPS)' : 'WEIGHTED AVERAGE LIFE MATRIX (YEARS)'}
          </h3>
          <div className="text-[11px] font-mono text-slate-400">
            X-Axis: Prepayment Speed (CPR %) · Y-Axis: Yield Curve Shift (bps)
          </div>
        </div>

        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-center text-xs font-mono border-collapse">
            <thead>
              <tr>
                <th className="p-2.5 text-left text-slate-400 border-b border-r border-slate-800 bg-slate-950 font-bold">
                  Rate Shift \ CPR
                </th>
                {prepayCprs.map((c) => (
                  <th key={c} className="p-2.5 border-b border-slate-800 bg-slate-950/80 text-cyan-400 font-bold">
                    {c}% CPR
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {matrix.map((row, rIdx) => {
                const rateShift = rateShifts[rIdx];
                return (
                  <tr key={rateShift}>
                    <td className="p-2.5 text-left font-bold text-slate-300 border-r border-slate-800 bg-slate-950/60">
                      {rateShift > 0 ? `+${rateShift}` : rateShift} bps
                    </td>
                    {row.map((cell) => {
                      const val = getMetricValue(cell);
                      const min = metricMode === 'PRICE' ? 82 : metricMode === 'OAS' ? 30 : 2.0;
                      const max = metricMode === 'PRICE' ? 106 : metricMode === 'OAS' ? 220 : 12.0;
                      const bgColor = getColor(val, min, max);

                      return (
                        <td
                          key={cell.cpr}
                          onMouseEnter={() => setHoveredCell(cell)}
                          onMouseLeave={() => setHoveredCell(null)}
                          className="p-2.5 font-bold transition-all cursor-crosshair border border-slate-800/40 hover:scale-105 hover:z-10 hover:border-amber-400 hover:shadow-lg"
                          style={{ backgroundColor: bgColor }}
                        >
                          <span className="text-slate-100">
                            {metricMode === 'PRICE' ? val.toFixed(2) : metricMode === 'OAS' ? `${val.toFixed(0)}` : `${val.toFixed(1)}y`}
                          </span>
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
