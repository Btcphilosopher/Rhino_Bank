import React, { useState } from 'react';
import { CashFlowSchedule, MortgagePool } from '../types/mbs';
import { 
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  Legend, BarChart, Bar 
} from 'recharts';
import { Table, Download, CheckCircle, RefreshCw, Layers } from 'lucide-react';

interface Props {
  schedule: CashFlowSchedule;
  pool: MortgagePool;
}

export const CashFlowsView: React.FC<Props> = ({ schedule, pool }) => {
  const [displayCount, setDisplayCount] = useState<number>(36);
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Sample data for charts (downsampled for performance if needed)
  const chartData = schedule.periods.slice(0, 120).map((p) => ({
    period: `M${p.period}`,
    scheduledPrin: Math.round(p.scheduledPrincipal),
    prepayPrin: Math.round(p.prepaymentPrincipal),
    netInterest: Math.round(p.netInterest),
    recoveryCash: Math.round(p.recoveryCash),
    netCashFlow: Math.round(p.netCashFlow),
    endingBalance: Math.round(p.endingBalance),
  }));

  const filteredPeriods = schedule.periods.filter(p => 
    p.period.toString().includes(searchTerm) || p.monthDate.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const exportCsv = () => {
    const headers = [
      'Period', 'MonthDate', 'BeginningBalance', 'ScheduledPrincipal', 'PrepaymentPrincipal',
      'DefaultedPrincipal', 'RecoveryCash', 'RealizedLoss', 'GrossInterest', 'ServicingFee',
      'NetInterest', 'NetCashFlow', 'EndingBalance', 'CPR_Pct', 'CDR_Pct', 'DiscountFactor', 'PV'
    ];
    
    const rows = schedule.periods.map(p => [
      p.period, p.monthDate, p.beginningBalance.toFixed(2), p.scheduledPrincipal.toFixed(2),
      p.prepaymentPrincipal.toFixed(2), p.defaultedPrincipal.toFixed(2), p.recoveryCash.toFixed(2),
      p.realizedLoss.toFixed(2), p.grossInterest.toFixed(2), p.servicingFee.toFixed(2),
      p.netInterest.toFixed(2), p.netCashFlow.toFixed(2), p.endingBalance.toFixed(2),
      (p.cprApplied * 100).toFixed(2), (p.cdrApplied * 100).toFixed(2),
      p.discountFactor.toFixed(6), p.presentValue.toFixed(2)
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `RhinoQuant_CashFlows_${pool.poolId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Cash Flow KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 font-mono text-xs">
        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-lg">
          <div className="text-slate-400 text-[10px] uppercase">Total Cash Flow</div>
          <div className="text-amber-400 font-bold text-sm mt-0.5">
            £{(schedule.totalCashFlow / 1_000_000).toFixed(1)}m
          </div>
          <div className="text-[10px] text-slate-400">Undiscounted Sum</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-lg">
          <div className="text-slate-400 text-[10px] uppercase">Scheduled Principal</div>
          <div className="text-slate-200 font-bold text-sm mt-0.5">
            £{(schedule.totalScheduledPrincipal / 1_000_000).toFixed(1)}m
          </div>
          <div className="text-[10px] text-slate-400">Regular Amortisation</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-lg">
          <div className="text-slate-400 text-[10px] uppercase">Prepayments (CPR)</div>
          <div className="text-cyan-400 font-bold text-sm mt-0.5">
            £{(schedule.totalPrepayments / 1_000_000).toFixed(1)}m
          </div>
          <div className="text-[10px] text-slate-400">Early Payoffs</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-lg">
          <div className="text-slate-400 text-[10px] uppercase">Net Interest Paid</div>
          <div className="text-emerald-400 font-bold text-sm mt-0.5">
            £{(schedule.totalNetInterest / 1_000_000).toFixed(1)}m
          </div>
          <div className="text-[10px] text-slate-400">After Servicing Fees</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-lg">
          <div className="text-slate-400 text-[10px] uppercase">Realized Losses</div>
          <div className="text-rose-400 font-bold text-sm mt-0.5">
            £{(schedule.totalRealizedLosses / 1_000_000).toFixed(1)}m
          </div>
          <div className="text-[10px] text-slate-400">{pool.isAgency ? 'Agency Guarantee: 0' : 'Cumulative Loss'}</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-lg">
          <div className="text-slate-400 text-[10px] uppercase">WAL (Life)</div>
          <div className="text-indigo-300 font-bold text-sm mt-0.5">
            {schedule.weightedAverageLifeYears.toFixed(2)} yrs
          </div>
          <div className="text-[10px] text-slate-400">Duration Anchor</div>
        </div>
      </div>

      {/* Cash Flow Distribution Chart */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3 mb-4">
          <div>
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
              PROJECTED MONTHLY CASH FLOW COMPOSITION (PERIODS 1 - 120)
            </h3>
            <p className="text-xs text-slate-400">
              Stacked breakdown of Scheduled Principal, Prepayments, Recoveries, and Net Interest
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs font-mono">
            <span className="flex items-center gap-1 text-slate-300">
              <span className="h-2.5 w-2.5 bg-blue-500 rounded-sm"></span> Scheduled Prin
            </span>
            <span className="flex items-center gap-1 text-slate-300">
              <span className="h-2.5 w-2.5 bg-cyan-400 rounded-sm"></span> Prepayments
            </span>
            <span className="flex items-center gap-1 text-slate-300">
              <span className="h-2.5 w-2.5 bg-emerald-500 rounded-sm"></span> Net Interest
            </span>
          </div>
        </div>

        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
              <XAxis dataKey="period" stroke="#64748b" fontSize={10} tickLine={false} />
              <YAxis 
                stroke="#64748b" 
                fontSize={10} 
                tickLine={false} 
                tickFormatter={(val) => `£${(val / 1_000_000).toFixed(1)}m`} 
              />
              <Tooltip 
                formatter={(val: number) => [`£${val.toLocaleString()}`, '']}
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
              />
              <Area type="monotone" dataKey="scheduledPrin" name="Scheduled Principal" stackId="1" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.6} />
              <Area type="monotone" dataKey="prepayPrin" name="Prepayment Principal" stackId="1" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.7} />
              <Area type="monotone" dataKey="recoveryCash" name="Recovery Principal" stackId="1" stroke="#a855f7" fill="#a855f7" fillOpacity={0.5} />
              <Area type="monotone" dataKey="netInterest" name="Net Interest" stackId="1" stroke="#10b981" fill="#10b981" fillOpacity={0.6} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Detailed Cash Flow Period Ledger Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3 mb-3">
          <div className="flex items-center gap-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
              PERIOD-BY-PERIOD AMORTISATION SCHEDULE LEDGER ({schedule.periods.length} MONTHS)
            </h3>
            <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800/40 font-mono flex items-center gap-1">
              <CheckCircle className="h-3 w-3" />
              BALANCES RECONCILED (Δ &lt; £0.01)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="Search month / period..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-800 border border-slate-700 text-xs text-slate-200 rounded px-2.5 py-1 outline-none focus:border-amber-500 font-mono w-44"
            />
            <button
              onClick={exportCsv}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-3 py-1 rounded border border-slate-700 flex items-center gap-1 font-mono transition"
            >
              <Download className="h-3 w-3 text-amber-400" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto scrollbar-thin max-h-96">
          <table className="w-full text-left text-xs font-mono">
            <thead className="sticky top-0 z-10 bg-slate-950">
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2 px-2.5">Prd</th>
                <th className="py-2 px-2.5">Date</th>
                <th className="py-2 px-2.5 text-right">Beg. Balance</th>
                <th className="py-2 px-2.5 text-right text-blue-400">Sched Prin</th>
                <th className="py-2 px-2.5 text-right text-cyan-400">Prepay Prin</th>
                <th className="py-2 px-2.5 text-right text-rose-400">Defaults</th>
                <th className="py-2 px-2.5 text-right text-purple-400">Recovery</th>
                <th className="py-2 px-2.5 text-right text-emerald-400">Net Interest</th>
                <th className="py-2 px-2.5 text-right text-amber-400 font-bold">Net Cash Flow</th>
                <th className="py-2 px-2.5 text-right">End Balance</th>
                <th className="py-2 px-2.5 text-right">CPR</th>
                <th className="py-2 px-2.5 text-right">DF</th>
                <th className="py-2 px-2.5 text-right text-slate-300">PV</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40">
              {filteredPeriods.slice(0, displayCount).map((p) => (
                <tr key={p.period} className="hover:bg-slate-800/40 transition">
                  <td className="py-1.5 px-2.5 text-slate-400">{p.period}</td>
                  <td className="py-1.5 px-2.5 text-slate-300 font-sans">{p.monthDate}</td>
                  <td className="py-1.5 px-2.5 text-right text-slate-300">£{Math.round(p.beginningBalance).toLocaleString()}</td>
                  <td className="py-1.5 px-2.5 text-right text-blue-400">£{Math.round(p.scheduledPrincipal).toLocaleString()}</td>
                  <td className="py-1.5 px-2.5 text-right text-cyan-400">£{Math.round(p.prepaymentPrincipal).toLocaleString()}</td>
                  <td className="py-1.5 px-2.5 text-right text-rose-400">£{Math.round(p.defaultedPrincipal).toLocaleString()}</td>
                  <td className="py-1.5 px-2.5 text-right text-purple-400">£{Math.round(p.recoveryCash).toLocaleString()}</td>
                  <td className="py-1.5 px-2.5 text-right text-emerald-400">£{Math.round(p.netInterest).toLocaleString()}</td>
                  <td className="py-1.5 px-2.5 text-right text-amber-400 font-bold">£{Math.round(p.netCashFlow).toLocaleString()}</td>
                  <td className="py-1.5 px-2.5 text-right text-slate-200">£{Math.round(p.endingBalance).toLocaleString()}</td>
                  <td className="py-1.5 px-2.5 text-right text-cyan-300">{(p.cprApplied * 100).toFixed(1)}%</td>
                  <td className="py-1.5 px-2.5 text-right text-slate-400">{p.discountFactor.toFixed(4)}</td>
                  <td className="py-1.5 px-2.5 text-right text-slate-100 font-bold">£{Math.round(p.presentValue).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {displayCount < filteredPeriods.length && (
          <div className="text-center mt-3 pt-2 border-t border-slate-800">
            <button
              onClick={() => setDisplayCount(prev => prev + 48)}
              className="text-xs bg-slate-800 hover:bg-slate-700 text-amber-400 font-mono px-4 py-1.5 rounded transition"
            >
              Load Next 48 Periods (Showing {displayCount} of {filteredPeriods.length})
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
