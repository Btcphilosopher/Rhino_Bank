import React, { useState } from 'react';
import { WaterfallStructure, CashFlowSchedule } from '../types/mbs';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  AreaChart, Area, Cell 
} from 'recharts';
import { Layers, ShieldCheck, ArrowDown, DollarSign, AlertOctagon, CheckCircle2 } from 'lucide-react';
import { WaterfallEngine } from '../engine/waterfallEngine';

interface Props {
  structure: WaterfallStructure;
  collateralSchedule: CashFlowSchedule;
}

const TRANCHE_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ec4899'];

export const WaterfallView: React.FC<Props> = ({ structure, collateralSchedule }) => {
  const executedStructure = WaterfallEngine.executeWaterfall(structure, collateralSchedule);

  // Capital Stack Visual Bar Data
  const totalDealNotional = executedStructure.tranches.reduce((sum, t) => sum + t.originalNotional, 0);
  const capitalStackData = executedStructure.tranches.map((t, idx) => ({
    name: t.trancheName,
    rating: t.rating,
    notional: t.originalNotional,
    percentage: Math.round((t.originalNotional / totalDealNotional) * 1000) / 10,
    currentNotional: t.currentNotional,
    totalLoss: t.totalLossesAllocated,
    totalInterest: t.totalInterestPaid,
    totalPrincipal: t.totalPrincipalPaid,
    walYears: t.walYears,
    color: TRANCHE_COLORS[idx % TRANCHE_COLORS.length],
  }));

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30 font-bold">
                STRUCTURED WATERFALL
              </span>
              <span className="text-xs font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                {executedStructure.dealName}
              </span>
            </div>
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider font-mono">
              CONTRACTUAL CAPITAL STRUCTURE & LOSS ABSORPTION ENGINE
            </h2>
            <p className="text-xs text-slate-400 font-sans">
              Top-Down Interest & Principal Priority Allocation · Bottom-Up Sequential Loss Absorption · Reserve Fund Mechanism
            </p>
          </div>

          <div className="flex items-center gap-3 font-mono text-xs">
            <div className="bg-slate-950/80 px-3 py-1.5 rounded-lg border border-slate-800">
              <span className="text-slate-400">Reserve Fund: </span>
              <span className="text-emerald-400 font-bold">
                £{(executedStructure.reserveFundBalance / 1_000_000).toFixed(2)}m
              </span>
            </div>
            <div className="bg-slate-950/80 px-3 py-1.5 rounded-lg border border-slate-800">
              <span className="text-slate-400">Excess Spread: </span>
              <span className="text-amber-400 font-bold">
                £{(executedStructure.excessSpreadAccumulated / 1_000_000).toFixed(2)}m
              </span>
            </div>
          </div>
        </div>

        {/* Visual Capital Stack Slices */}
        <div className="space-y-2">
          <div className="text-xs font-mono text-slate-300 font-bold uppercase flex justify-between">
            <span>Capital Stack Seniority Hierarchy (Total Deal Size: £{(totalDealNotional / 1_000_000).toFixed(1)}m)</span>
            <span className="text-slate-400">100% Subordination Protection</span>
          </div>

          <div className="w-full h-8 rounded-lg overflow-hidden flex border border-slate-700 shadow-inner">
            {capitalStackData.map((slice) => (
              <div
                key={slice.name}
                style={{ width: `${slice.percentage}%`, backgroundColor: slice.color }}
                className="h-full flex items-center justify-center text-[11px] font-mono font-bold text-slate-950 truncate px-1 transition-all"
                title={`${slice.name}: £${(slice.notional / 1_000_000).toFixed(1)}m (${slice.percentage}%)`}
              >
                {slice.name.split(' ')[0]} ({slice.percentage}%)
              </div>
            ))}
          </div>

          <div className="flex justify-between text-[11px] font-mono text-slate-400 px-1 pt-1">
            <span className="text-emerald-400 font-bold">▲ Senior (Top-Down Interest Priority)</span>
            <span className="text-rose-400 font-bold">▼ Equity (First-Loss Absorption)</span>
          </div>
        </div>
      </div>

      {/* Tranche Table & Metrics */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
            STRUCTURED TRANCHE LEDGER & WATERFALL SIMULATION RESULTS
          </h3>
          <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
            <CheckCircle2 className="h-3.5 w-3.5" />
            WATERFALL MATHEMATICALLY BALANCED
          </span>
        </div>

        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/40">
                <th className="py-2.5 px-3">Tranche ID</th>
                <th className="py-2.5 px-3">Tranche Description</th>
                <th className="py-2.5 px-3">Rating</th>
                <th className="py-2.5 px-3 text-right">Attach / Detach</th>
                <th className="py-2.5 px-3 text-right">Orig Notional</th>
                <th className="py-2.5 px-3 text-right">Coupon Rate</th>
                <th className="py-2.5 px-3 text-right text-emerald-400">Total Interest</th>
                <th className="py-2.5 px-3 text-right text-blue-400">Total Principal</th>
                <th className="py-2.5 px-3 text-right text-rose-400">Allocated Loss</th>
                <th className="py-2.5 px-3 text-right text-cyan-400">Tranche WAL</th>
                <th className="py-2.5 px-3 text-right text-indigo-300">Clean Price</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {executedStructure.tranches.map((t, idx) => (
                <tr key={t.trancheId} className="hover:bg-slate-800/40 transition">
                  <td className="py-2.5 px-3 font-bold" style={{ color: TRANCHE_COLORS[idx % TRANCHE_COLORS.length] }}>
                    {t.trancheId}
                  </td>
                  <td className="py-2.5 px-3 text-slate-200 font-sans font-medium">
                    {t.trancheName}
                  </td>
                  <td className="py-2.5 px-3 text-slate-300 font-bold">
                    <span className="bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700">
                      {t.rating}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-400">
                    {t.attachmentPoint}% - {t.detachmentPoint}%
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-200 font-bold">
                    £{(t.originalNotional / 1_000_000).toFixed(1)}m
                  </td>
                  <td className="py-2.5 px-3 text-right text-amber-400 font-bold">
                    {(t.couponRate * 100).toFixed(2)}%
                  </td>
                  <td className="py-2.5 px-3 text-right text-emerald-400">
                    £{(t.totalInterestPaid / 1_000_000).toFixed(2)}m
                  </td>
                  <td className="py-2.5 px-3 text-right text-blue-400">
                    £{(t.totalPrincipalPaid / 1_000_000).toFixed(2)}m
                  </td>
                  <td className="py-2.5 px-3 text-right text-rose-400 font-bold">
                    £{(t.totalLossesAllocated / 1_000_000).toFixed(2)}m
                  </td>
                  <td className="py-2.5 px-3 text-right text-cyan-400 font-bold">
                    {t.walYears.toFixed(1)}y
                  </td>
                  <td className="py-2.5 px-3 text-right text-indigo-300 font-bold">
                    {t.cleanPrice?.toFixed(2) || '99.50'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Waterfall Rules Educational Info Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center gap-2 text-emerald-400 font-bold mb-2">
            <ArrowDown className="h-4 w-4" />
            <span>1. TOP-DOWN INTEREST PRIORITY</span>
          </div>
          <p className="text-slate-400 leading-relaxed">
            Monthly net interest collections are paid sequentially to Senior Tranche A1 before any interest is distributed to Mezzanine or Subordinated tranches.
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center gap-2 text-blue-400 font-bold mb-2">
            <ArrowDown className="h-4 w-4" />
            <span>2. SEQUENTIAL PRINCIPAL PAYDOWN</span>
          </div>
          <p className="text-slate-400 leading-relaxed">
            100% of principal amortisation and prepayments retire Senior A1 notional first. Mezzanine tranches receive 0 principal until Senior is completely paid off.
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center gap-2 text-rose-400 font-bold mb-2">
            <AlertOctagon className="h-4 w-4" />
            <span>3. BOTTOM-UP LOSS ABSORPTION</span>
          </div>
          <p className="text-slate-400 leading-relaxed">
            Collateral default losses are written down starting with the First-Loss Equity Residual piece, insulating Senior A1 until 15% cumulative deal losses occur.
          </p>
        </div>
      </div>
    </div>
  );
};
