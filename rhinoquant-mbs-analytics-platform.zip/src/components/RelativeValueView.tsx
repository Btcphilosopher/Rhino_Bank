import React, { useState } from 'react';
import { PortfolioPosition, RelativeValueScoreBreakdown } from '../types/mbs';
import { 
  ScatterChart, Scatter, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  ZAxis, Cell 
} from 'recharts';
import { ArrowUpRight } from 'lucide-react';
import { RelativeValueEngine } from '../engine/relativeValueEngine';

interface Props {
  positions: PortfolioPosition[];
  onSelectSecurity: (secId: string) => void;
}

const COLORS = ['#F97316', '#3B82F6', '#22C55E', '#8B5CF6', '#EC4899'];

export const RelativeValueView: React.FC<Props> = ({ positions, onSelectSecurity }) => {
  const [minYield, setMinYield] = useState<number>(0.045);
  const [minOas, setMinOas] = useState<number>(50);
  const [maxDuration, setMaxDuration] = useState<number>(6.5);
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  // Filter universe
  const filteredUniverse = positions.filter(p => {
    if (categoryFilter === 'Agency' && !p.isAgency) return false;
    if (categoryFilter === 'Non-Agency' && p.isAgency) return false;
    if (categoryFilter === 'Commercial' && p.assetClass !== 'CMBS') return false;
    if (p.yieldToMaturity < minYield) return false;
    if (p.oasBps < minOas) return false;
    if (p.effectiveDuration > maxDuration) return false;
    return true;
  });

  // Scatter plot data: X = WAL, Y = OAS, Z = Score
  const scatterData = positions.map((p, idx) => ({
    securityId: p.securityId,
    name: p.securityName,
    wal: p.walYears,
    oas: p.oasBps,
    yield: Math.round(p.yieldToMaturity * 10000) / 100,
    score: p.qualityScore,
    duration: p.effectiveDuration,
    color: COLORS[idx % COLORS.length],
  }));

  return (
    <div className="space-y-4">
      {/* Top Screener Bento Card */}
      <div className="bento-card p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800/80 pb-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">
                R Research Engine
              </span>
              <span className="text-[10px] font-mono bg-orange-950/40 text-orange-400 px-2 py-0.5 rounded border border-orange-800/40 font-bold">
                RELATIVE VALUE
              </span>
            </div>
            <h2 className="text-base font-bold text-white tracking-tight">
              MBS Relative Value Screener & Multi-Factor Quality Index
            </h2>
            <p className="text-xs text-slate-400">
              Scoring Risk-Adjusted Yield, OAS Attractiveness, Convexity Drag, Credit Subordination, and Liquidity
            </p>
          </div>

          {/* Category Filter Pills (matching Design HTML) */}
          <div className="flex gap-2">
            {['ALL', 'Agency', 'Non-Agency', 'Commercial'].map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-3 py-1 rounded-md text-[11px] font-bold font-mono transition border ${
                  categoryFilter === cat
                    ? 'bg-orange-600 text-white border-orange-500 shadow-sm'
                    : 'bg-slate-800/60 text-slate-400 hover:text-slate-200 border-slate-700 hover:bg-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Screener Slider Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
          <div className="bg-[#090D14]/70 p-3 rounded-lg border border-slate-800/80 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Min Yield:</span>
              <span className="text-orange-400 font-bold">{(minYield * 100).toFixed(2)}%</span>
            </div>
            <input
              type="range"
              min="0.04"
              max="0.07"
              step="0.0025"
              value={minYield}
              onChange={(e) => setMinYield(parseFloat(e.target.value))}
              className="w-full accent-orange-500 cursor-pointer"
            />
          </div>

          <div className="bg-[#090D14]/70 p-3 rounded-lg border border-slate-800/80 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Min OAS:</span>
              <span className="text-emerald-400 font-bold">{minOas} bp</span>
            </div>
            <input
              type="range"
              min="30"
              max="150"
              step="5"
              value={minOas}
              onChange={(e) => setMinOas(parseInt(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          <div className="bg-[#090D14]/70 p-3 rounded-lg border border-slate-800/80 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Max Duration:</span>
              <span className="text-indigo-300 font-bold">{maxDuration.toFixed(1)}y</span>
            </div>
            <input
              type="range"
              min="3.0"
              max="8.0"
              step="0.2"
              value={maxDuration}
              onChange={(e) => setMaxDuration(parseFloat(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Scatter Plot Bento Card: OAS vs WAL */}
      <div className="bento-card p-5">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-3">
          <div>
            <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold font-mono">
              RELATIVE VALUE EFFICIENT FRONTIER
            </span>
            <p className="text-xs text-slate-400">
              OAS Spread (bps) vs Weighted Average Life (Years) · Top-Left quadrant indicates high OAS with low extension risk
            </p>
          </div>
        </div>

        <div className="h-60">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 15, right: 20, bottom: 15, left: 10 }}>
              <XAxis dataKey="wal" name="WAL (Years)" stroke="#64748b" fontSize={11} unit="y" domain={[3.0, 9.0]} tickLine={false} />
              <YAxis dataKey="oas" name="OAS (bps)" stroke="#64748b" fontSize={11} unit="bp" domain={[40, 240]} tickLine={false} />
              <ZAxis dataKey="score" range={[100, 400]} />
              <Tooltip 
                formatter={(value: any, name: string) => [value, name]}
                contentStyle={{ backgroundColor: '#11141A', borderColor: '#1E293B', fontSize: '12px', borderRadius: '8px', color: '#fff' }}
              />
              <Scatter name="MBS Universe" data={scatterData}>
                {scatterData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Relative Value Ranked Bento Table */}
      <div className="bento-card overflow-hidden flex flex-col">
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              MBS Relative Value Screener (R Research Engine)
            </span>
            <span className="text-[10px] font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
              {filteredUniverse.length} MATCHING
            </span>
          </div>
          <span className="text-[11px] font-mono text-orange-400 font-bold">Ranked by RhinoQuant Quality Score</span>
        </div>

        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-left border-collapse font-mono text-xs">
            <thead className="text-[10px] uppercase text-slate-500 font-bold sticky top-0 bg-[#0E1117] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Rank</th>
                <th className="py-3 px-4">Security ID</th>
                <th className="py-3 px-4 font-sans">Asset Class</th>
                <th className="py-3 px-4 text-right">Yield</th>
                <th className="py-3 px-4 text-right">OAS</th>
                <th className="py-3 px-4 text-right">WAL</th>
                <th className="py-3 px-4 text-right">Dur</th>
                <th className="py-3 px-4 text-right">Conv</th>
                <th className="py-3 px-4 text-right">Credit Safety</th>
                <th className="py-3 px-4 text-right">Liquidity</th>
                <th className="py-3 px-4 text-right text-orange-400 font-bold">Score</th>
                <th className="py-3 px-4 text-center font-sans">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70">
              {[...filteredUniverse]
                .sort((a, b) => b.qualityScore - a.qualityScore)
                .map((pos, rIdx) => {
                  const breakdown: RelativeValueScoreBreakdown = RelativeValueEngine.calculateRhinoQuantScore(pos);
                  return (
                    <tr key={pos.securityId} className="hover:bg-slate-800/40 transition">
                      <td className="py-3 px-4 font-bold text-slate-400">#{rIdx + 1}</td>
                      <td className="py-3 px-4 font-bold text-orange-400">{pos.securityId}</td>
                      <td className="py-3 px-4 text-slate-300 font-sans">{pos.assetClass}</td>
                      <td className="py-3 px-4 text-right text-slate-200">{(pos.yieldToMaturity * 100).toFixed(2)}%</td>
                      <td className="py-3 px-4 text-right text-emerald-400 font-bold">{pos.oasBps} bp</td>
                      <td className="py-3 px-4 text-right text-cyan-400">{pos.walYears.toFixed(1)}y</td>
                      <td className="py-3 px-4 text-right text-indigo-300">{pos.effectiveDuration.toFixed(1)}</td>
                      <td className="py-3 px-4 text-right text-rose-400">{pos.effectiveConvexity.toFixed(1)}</td>
                      <td className="py-3 px-4 text-right text-slate-300">{breakdown.creditSafetyScore}/20</td>
                      <td className="py-3 px-4 text-right text-slate-300">{breakdown.liquidityScore}/15</td>
                      <td className="py-3 px-4 text-right">
                        <span className="font-bold text-white bg-orange-500/20 text-orange-400 px-2 py-0.5 rounded border border-orange-500/30">
                          {breakdown.totalScore}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center font-sans">
                        <button
                          onClick={() => onSelectSecurity(pos.securityId)}
                          className="text-xs bg-[#11141A] hover:bg-orange-600 hover:text-white text-slate-300 px-2.5 py-1 rounded-md transition border border-slate-700 hover:border-orange-500 flex items-center gap-1 mx-auto"
                        >
                          <span>Analyze</span>
                          <ArrowUpRight className="h-3 w-3" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

