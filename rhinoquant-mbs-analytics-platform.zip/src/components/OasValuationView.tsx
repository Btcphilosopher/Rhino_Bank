import React, { useState } from 'react';
import { YieldCurve, MortgagePool, PortfolioPosition } from '../types/mbs';
import { 
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  Legend, BarChart, Bar 
} from 'recharts';
import { Percent, TrendingUp, Cpu, Sliders, CheckCircle2, Award } from 'lucide-react';
import { OASEngine } from '../engine/oasEngine';
import { YieldCurveEngine } from '../engine/yieldCurveEngine';

interface Props {
  yieldCurve: YieldCurve;
  pool: MortgagePool;
  position: PortfolioPosition;
}

export const OasValuationView: React.FC<Props> = ({ yieldCurve, pool, position }) => {
  const [volBps, setVolBps] = useState<number>(120); // 120 bps short rate volatility
  const [meanReversion, setMeanReversion] = useState<number>(0.03); // 3%
  const [staticSpread, setStaticSpread] = useState<number>(position.oasBps + 18);

  const oasResult = OASEngine.calculateOas(
    position.marketPrice,
    staticSpread,
    pool.weightedAverageNetCoupon,
    position.walYears,
    volBps / 10000,
    meanReversion
  );

  // Discount Curve Visual Points (0 to 30 years)
  const curvePoints = [];
  for (let t = 0.5; t <= 30; t += 0.5) {
    const zeroRate = YieldCurveEngine.getZeroRate(yieldCurve, t);
    const discFactor = YieldCurveEngine.getDiscountFactor(yieldCurve, t, oasResult.optionAdjustedSpreadBps);
    curvePoints.push({
      tenor: `${t}Y`,
      tenorVal: t,
      zeroRatePct: Math.round(zeroRate * 10000) / 100,
      zeroPlusOasPct: Math.round((zeroRate + oasResult.optionAdjustedSpreadBps / 10000) * 10000) / 100,
      discountFactor: Math.round(discFactor * 10000) / 10000,
    });
  }

  return (
    <div className="space-y-6">
      {/* Top Banner & OAS Equation Strip */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30 font-bold">
                OAS VALUATION ENGINE
              </span>
              <span className="text-xs font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                HULL-WHITE 1-FACTOR SHORT-RATE TREE
              </span>
            </div>
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider font-mono">
              OPTION-ADJUSTED SPREAD (OAS) & BENCHMARK DISCOUNTING
            </h2>
            <p className="text-xs text-slate-400">
              Evaluates borrower prepayment call option cost under stochastic interest rate paths
            </p>
          </div>

          <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 font-mono text-xs flex items-center gap-4">
            <div>
              <div className="text-slate-400 text-[10px]">STATIC Z-SPREAD</div>
              <div className="text-slate-200 font-bold text-sm">{oasResult.staticSpreadBps.toFixed(1)} bp</div>
            </div>
            <span className="text-slate-500 text-lg font-bold">−</span>
            <div>
              <div className="text-rose-400 text-[10px]">OPTION COST</div>
              <div className="text-rose-400 font-bold text-sm">{oasResult.optionCostBps.toFixed(1)} bp</div>
            </div>
            <span className="text-slate-500 text-lg font-bold">=</span>
            <div>
              <div className="text-amber-400 text-[10px]">OPTION ADJUSTED (OAS)</div>
              <div className="text-amber-400 font-bold text-base">{oasResult.optionAdjustedSpreadBps.toFixed(1)} bp</div>
            </div>
          </div>
        </div>

        {/* Volatility & Mean Reversion Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono text-xs">
          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Interest Rate Volatility (σ):</span>
              <span className="text-amber-400 font-bold">{volBps} bps</span>
            </div>
            <input
              type="range"
              min="50"
              max="250"
              step="5"
              value={volBps}
              onChange={(e) => setVolBps(parseInt(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>Low Vol: 60 bps</span>
              <span>High Vol: 200 bps</span>
            </div>
          </div>

          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Mean Reversion Speed (a):</span>
              <span className="text-cyan-400 font-bold">{(meanReversion * 100).toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min="0.01"
              max="0.10"
              step="0.005"
              value={meanReversion}
              onChange={(e) => setMeanReversion(parseFloat(e.target.value))}
              className="w-full accent-cyan-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>Standard: 3.0%</span>
            </div>
          </div>

          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Static Z-Spread Target:</span>
              <span className="text-indigo-300 font-bold">{staticSpread} bp</span>
            </div>
            <input
              type="range"
              min="30"
              max="350"
              step="2"
              value={staticSpread}
              onChange={(e) => setStaticSpread(parseInt(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>Observed Clean Price: {position.marketPrice.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Yield Curve & OAS Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Zero Curve vs Zero + OAS Curve */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
                BENCHMARK ZERO CURVE & OAS SPREAD OVERLAY
              </h3>
              <p className="text-xs text-slate-400">
                Monotonic Hermite cubic spline interpolation with continuous compounding
              </p>
            </div>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={curvePoints} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <XAxis dataKey="tenor" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} unit="%" domain={[3.5, 6.0]} />
                <Tooltip 
                  formatter={(val: number) => [`${val}%`, '']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
                />
                <Line type="monotone" dataKey="zeroRatePct" name="Benchmark Zero Curve" stroke="#3b82f6" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="zeroPlusOasPct" name="Discount Curve (Zero + OAS)" stroke="#f59e0b" strokeWidth={2} strokeDasharray="4 4" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Discount Factors along Cash Flow Curve */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
                TERM DISCOUNT FACTORS DF(t)
              </h3>
              <p className="text-xs text-slate-400">
                DF(t) = exp(-[r(t) + OAS] * t) applied to monthly cash flows
              </p>
            </div>
            <span className="text-[11px] font-mono text-cyan-400">Continuous Compounding</span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={curvePoints} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <XAxis dataKey="tenor" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} domain={[0.2, 1.0]} />
                <Tooltip 
                  formatter={(val: number) => [val.toFixed(4), 'Discount Factor']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
                />
                <Line type="monotone" dataKey="discountFactor" stroke="#06b6d4" strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
