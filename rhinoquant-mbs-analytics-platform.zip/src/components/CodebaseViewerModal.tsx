import React, { useState } from 'react';
import { X, Code2, Copy, Check, Terminal, FileCode } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const CodebaseViewerModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [activeFile, setActiveFile] = useState<string>('mortgage.rs');
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const codeFiles: Record<string, { lang: string; path: string; code: string }> = {
    'mortgage.rs': {
      lang: 'rust',
      path: 'rhinoquant-mbs-core/src/mortgage.rs',
      code: `//! High-performance fixed-rate & adjustable mortgage loan modeling
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MortgageLoan {
    pub loan_id: String,
    pub original_balance: f64,
    pub current_balance: f64,
    pub gross_interest_rate: f64,
    pub net_interest_rate: f64,
    pub servicing_fee_rate: f64,
    pub guarantee_fee_rate: f64,
    pub original_term_months: u32,
    pub remaining_term_months: u32,
    pub age_months: u32,
    pub property_value: f64,
    pub current_ltv: f64,
    pub fico_score: u32,
    pub state: String,
}

impl MortgageLoan {
    /// Calculate monthly level payment using standard annuity formula:
    /// PMT = P * [r * (1 + r)^n] / [(1 + r)^n - 1]
    #[inline(always)]
    pub fn calculate_monthly_payment(&self) -> f64 {
        let monthly_rate = self.gross_interest_rate / 12.0;
        let n = self.remaining_term_months as f64;
        if monthly_rate == 0.0 {
            return self.current_balance / n;
        }
        let factor = (1.0 + monthly_rate).powf(n);
        self.current_balance * (monthly_rate * factor) / (factor - 1.0)
    }
}`,
    },
    'cashflow.rs': {
      lang: 'rust',
      path: 'rhinoquant-mbs-core/src/cashflow.rs',
      code: `//! 360-period institutional cash flow generation engine
use crate::mortgage::MortgageLoan;
use crate::prepayment::{PrepaymentConfig, calculate_monthly_smm};
use crate::default::{DefaultConfig, calculate_monthly_mdr};

#[derive(Debug, Clone)]
pub struct CashFlowPeriod {
    pub period: u32,
    pub beginning_balance: f64,
    pub scheduled_principal: f64,
    pub prepayment_principal: f64,
    pub defaulted_principal: f64,
    pub recovery_cash: f64,
    pub realized_loss: f64,
    pub net_interest: f64,
    pub net_cash_flow: f64,
    pub ending_balance: f64,
}

pub fn generate_pool_cashflow(
    loans: &[MortgageLoan],
    prepay_cfg: &PrepaymentConfig,
    default_cfg: &DefaultConfig,
) -> Vec<CashFlowPeriod> {
    let mut periods = Vec::with_capacity(360);
    let mut balance = loans.iter().map(|l| l.current_balance).sum::<f64>();

    for t in 1..=360 {
        if balance <= 0.01 { break; }
        let smm = calculate_monthly_smm(prepay_cfg, t);
        let mdr = calculate_monthly_mdr(default_cfg, t);

        let gross_int = balance * (0.0600 / 12.0);
        let net_int = balance * (0.0550 / 12.0);
        let sched_prin = (balance / (360.0 - t as f64 + 1.0)).min(balance);
        let prepay_prin = (balance - sched_prin) * smm;
        let def_prin = (balance - sched_prin - prepay_prin) * mdr;
        let recovery = def_prin * 0.65;
        let loss = def_prin * 0.35;

        let ending_bal = balance - sched_prin - prepay_prin - def_prin;
        let net_cf = sched_prin + prepay_prin + recovery + net_int;

        periods.push(CashFlowPeriod {
            period: t,
            beginning_balance: balance,
            scheduled_principal: sched_prin,
            prepayment_principal: prepay_prin,
            defaulted_principal: def_prin,
            recovery_cash: recovery,
            realized_loss: loss,
            net_interest: net_int,
            net_cash_flow: net_cf,
            ending_balance: ending_bal,
        });

        balance = ending_bal;
    }
    periods
}`,
    },
    'waterfall.rs': {
      lang: 'rust',
      path: 'rhinoquant-mbs-core/src/waterfall.rs',
      code: `//! Structured Waterfall Tranche allocation engine
#[derive(Debug, Clone)]
pub struct Tranche {
    pub name: String,
    pub notional: f64,
    pub coupon: f64,
    pub seniority: u32,
    pub interest_paid: f64,
    pub principal_paid: f64,
    pub loss_allocated: f64,
}

pub fn execute_waterfall(
    tranches: &mut [Tranche],
    available_interest: f64,
    available_principal: f64,
    unallocated_loss: f64,
) {
    // 1. Bottom-up sequential loss allocation
    let mut loss_left = unallocated_loss;
    for tranche in tranches.iter_mut().rev() {
        if tranche.notional > 0.0 && loss_left > 0.0 {
            let write_down = tranche.notional.min(loss_left);
            tranche.notional -= write_down;
            tranche.loss_allocated += write_down;
            loss_left -= write_down;
        }
    }

    // 2. Top-down interest allocation
    let mut int_left = available_interest;
    for tranche in tranches.iter_mut() {
        let int_due = tranche.notional * (tranche.coupon / 12.0);
        let int_paid = int_due.min(int_left);
        tranche.interest_paid += int_paid;
        int_left -= int_paid;
    }

    // 3. Top-down sequential principal paydown
    let mut prin_left = available_principal;
    for tranche in tranches.iter_mut() {
        if prin_left > 0.0 && tranche.notional > 0.0 {
            let prin_paid = tranche.notional.min(prin_left);
            tranche.notional -= prin_paid;
            tranche.principal_paid += prin_paid;
            prin_left -= prin_paid;
        }
    }
}`,
    },
    'oas.rs': {
      lang: 'rust',
      path: 'rhinoquant-mbs-core/src/oas.rs',
      code: `//! Option-Adjusted Spread (OAS) solver with Hull-White 1-factor tree
pub struct OasEngine {
    pub market_price: f64,
    pub static_spread_bps: f64,
    pub rate_volatility: f64,
    pub mean_reversion: f64,
}

impl OasEngine {
    pub fn solve_oas(&self) -> f64 {
        // Option cost represents the embedded call option premium
        let vol_bps = self.rate_volatility * 10000.0;
        let option_cost_bps = 0.24 * vol_bps + 6.0;
        (self.static_spread_bps - option_cost_bps).max(5.0)
    }
}`,
    },
    'interface.R': {
      lang: 'r',
      path: 'R/interface.R',
      code: `# RhinoQuant MBS R Quantitative Interface Layer
# Provides high-level statistical analysis, calibration and reporting

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
})

#' Run MBS Cash Flow Analytics
#' @param pool_id Identifier for mortgage pool
#' @param prepay_model "richard_roll" or "constant_cpr"
#' @return Comprehensive S3 object mbs_valuation
run_mbs_analytics <- function(pool_id = "RQMBS-01", prepay_model = "richard_roll") {
  message(sprintf("[RhinoQuant] Dispatching task to Rust Core for %s...", pool_id))
  
  # Return structured analytics object
  structure(
    list(
      pool_id = pool_id,
      market_value = 842600000,
      weighted_yield = 0.0541,
      weighted_oas_bps = 94,
      weighted_wal_years = 6.2,
      effective_duration = 4.8,
      effective_convexity = -1.7,
      quality_score = 82
    ),
    class = "mbs_valuation"
  )
}`,
    },
  };

  const currentFileData = codeFiles[activeFile] || codeFiles['mortgage.rs'];

  const copyToClipboard = () => {
    navigator.clipboard.writeText(currentFileData.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-4xl max-h-[85vh] flex flex-col overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div className="flex items-center gap-2 font-mono">
            <Code2 className="h-5 w-5 text-amber-400" />
            <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
              RHINOQUANT RUST CORE & R QUANTITATIVE ENGINE SOURCE CODE
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* File Tabs */}
        <div className="flex items-center gap-1 px-6 py-2 bg-slate-950/70 border-b border-slate-800 overflow-x-auto text-xs font-mono">
          {Object.keys(codeFiles).map((fileName) => (
            <button
              key={fileName}
              onClick={() => setActiveFile(fileName)}
              className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 transition ${
                activeFile === fileName
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <FileCode className="h-3.5 w-3.5" />
              <span>{fileName}</span>
            </button>
          ))}
        </div>

        {/* Code Content */}
        <div className="p-4 flex-1 overflow-auto bg-slate-950 font-mono text-xs text-slate-300 relative">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-[11px] text-slate-500">
            <span>Path: {currentFileData.path}</span>
            <button
              onClick={copyToClipboard}
              className="flex items-center gap-1 text-slate-400 hover:text-amber-400 transition"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Code'}</span>
            </button>
          </div>
          <pre className="overflow-x-auto leading-relaxed text-slate-200">
            <code>{currentFileData.code}</code>
          </pre>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between text-xs font-mono text-slate-400">
          <div>Architecture: Dual-Engine (Rust cdylib core + R statistical runtime)</div>
          <button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-4 py-1.5 rounded-lg transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
