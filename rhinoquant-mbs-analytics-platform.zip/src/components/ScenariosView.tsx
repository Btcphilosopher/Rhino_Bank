import React from 'react';
import { MortgagePool, PrepaymentConfig, DefaultConfig, YieldCurve, ScenarioResult } from '../types/mbs';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  Cell 
} from 'recharts';
import { AlertOctagon, TrendingDown, ArrowUpRight, ArrowDownRight, ShieldAlert } from 'lucide-react';
import { ScenarioEngine } from '../engine/scenarioEngine';

interface Props {
  pool: MortgagePool;
  prepayConfig: PrepaymentConfig;
  defaultConfig: DefaultConfig;
  yieldCurve: YieldCurve;
  marketPrice: number;
  notionalBalance: number;
}

export const ScenariosView: React.FC<Props> = ({
  pool,
  prepayConfig,
  defaultConfig,
  yieldCurve,
  marketPrice,
  notionalBalance,
}) => {
  const scenarioResults: ScenarioResult[] = ScenarioEngine.evaluateScenarios(
    pool,
    prepayConfig,
    defaultConfig,
    yieldCurve,
    marketPrice,
    notionalBalance
  );

  const barChartData = scenarioResults.map(s => ({
    name: s.name.split(' (')[0],
    pnlMillion: Math.round((s.pnlCurrency / 1_000_000) * 10) / 10,
    price: s.cleanPrice,
    wal: s.walYears,
    dur: s.effectiveDuration,
  }));

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded border border-rose-500/30 font-bold">
                INSTITUTIONAL STRESS TESTING
              </span>
              <span className="text-xs font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                PORTFOLIO EXPOSURE: £{(notionalBalance / 1_000_000).toFixed(1)}M
              </span>
            </div>
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider font-mono">
              MULTI-FACTOR STRESS SCENARIO MATRIX & FULL REVALUATION
            </h2>
            <p className="text-xs text-slate-400">
              Joint shocks across interest rate curves, prepayment behavioral speeds, and property collateral declines
            </p>
          </div>
        </div>

        {/* P&L Shock Bar Chart */}
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={barChartData} margin={{ top: 15, right: 20, left: 10, bottom: 25 }}>
              <XAxis dataKey="name" stroke="#64748b" fontSize={10} angle={-15} textAnchor="end" tickLine={false} />
              <YAxis stroke="#64748b" fontSize={10} tickLine={false} tickFormatter={(v) => `£${v}m`} />
              <Tooltip 
                formatter={(val: number) => [`£${val}m`, 'P&L Impact']}
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px', borderRadius: '6px' }}
              />
              <Bar dataKey="pnlMillion" name="P&L Impact (£m)" radius={[4, 4, 0, 0]}>
                {barChartData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={entry.pnlMillion >= 0 ? '#10b981' : '#f43f5e'} 
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Scenario Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
            STRESS TEST REVALUATION SUMMARY TABLE
          </h3>
          <span className="text-[11px] font-mono text-slate-400">9 Core Stress Scenarios</span>
        </div>

        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/40">
                <th className="py-2.5 px-3">Scenario Name</th>
                <th className="py-2.5 px-3 text-right">Rate Shift</th>
                <th className="py-2.5 px-3 text-right">Prepay Shock</th>
                <th className="py-2.5 px-3 text-right">Default Mult</th>
                <th className="py-2.5 px-3 text-right">HPI Shock</th>
                <th className="py-2.5 px-3 text-right">Clean Price</th>
                <th className="py-2.5 px-3 text-right">Price Δ (%)</th>
                <th className="py-2.5 px-3 text-right">P&L Impact (£)</th>
                <th className="py-2.5 px-3 text-right">Yield</th>
                <th className="py-2.5 px-3 text-right">WAL</th>
                <th className="py-2.5 px-3 text-right">Duration</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {scenarioResults.map((sc) => {
                const isPositivePnl = sc.pnlCurrency >= 0;
                return (
                  <tr key={sc.scenarioId} className="hover:bg-slate-800/40 transition">
                    <td className="py-2.5 px-3 font-bold text-slate-200 font-sans">
                      {sc.name}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {sc.rateShiftBps > 0 ? `+${sc.rateShiftBps}` : sc.rateShiftBps} bp
                    </td>
                    <td className="py-2.5 px-3 text-right text-cyan-400">
                      {sc.prepayShiftPct > 0 ? `+${sc.prepayShiftPct}` : sc.prepayShiftPct}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-rose-400">
                      {sc.defaultMultiplier.toFixed(1)}x
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {sc.propertyValueShockPct}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-100 font-bold">
                      {sc.cleanPrice.toFixed(2)}
                    </td>
                    <td className={`py-2.5 px-3 text-right font-bold ${isPositivePnl ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {sc.priceDeltaPct > 0 ? `+${sc.priceDeltaPct}` : sc.priceDeltaPct}%
                    </td>
                    <td className={`py-2.5 px-3 text-right font-bold text-sm ${isPositivePnl ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {isPositivePnl ? '+' : ''}£{(sc.pnlCurrency / 1_000_000).toFixed(2)}m
                    </td>
                    <td className="py-2.5 px-3 text-right text-emerald-400">
                      {(sc.yieldToMaturity * 100).toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-cyan-400 font-bold">
                      {sc.walYears.toFixed(1)}y
                    </td>
                    <td className="py-2.5 px-3 text-right text-indigo-300 font-bold">
                      {sc.effectiveDuration.toFixed(2)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
