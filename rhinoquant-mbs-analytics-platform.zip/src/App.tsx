import React, { useState, useMemo } from 'react';
import { 
  MortgagePool, 
  PortfolioPosition, 
  PortfolioAnalytics, 
  PrepaymentConfig, 
  DefaultConfig, 
  YieldCurve, 
  CashFlowSchedule,
  WaterfallStructure 
} from './types/mbs';
import { 
  demoPools, 
  demoPortfolioPositions, 
  demoWaterfallStructure, 
  defaultPrepaymentConfig, 
  defaultDefaultConfig 
} from './data/demoSecurities';
import { YieldCurveEngine } from './engine/yieldCurveEngine';
import { CashFlowEngine } from './engine/cashFlowEngine';
import { RiskEngine } from './engine/riskEngine';
import { ValuationEngine } from './engine/valuationEngine';

import { Header } from './components/Header';
import { DashboardMetricsHeader } from './components/DashboardMetricsHeader';
import { PortfolioView } from './components/PortfolioView';
import { SecuritiesView } from './components/SecuritiesView';
import { CashFlowsView } from './components/CashFlowsView';
import { PrepaymentLabView } from './components/PrepaymentLabView';
import { CreditView } from './components/CreditView';
import { WaterfallView } from './components/WaterfallView';
import { OasValuationView } from './components/OasValuationView';
import { ConvexityView } from './components/ConvexityView';
import { SurfacesView } from './components/SurfacesView';
import { ScenariosView } from './components/ScenariosView';
import { MonteCarloView } from './components/MonteCarloView';
import { RelativeValueView } from './components/RelativeValueView';
import { OptimizerView } from './components/OptimizerView';
import { AuditView } from './components/AuditView';
import { ReportGeneratorModal } from './components/ReportGeneratorModal';
import { CodebaseViewerModal } from './components/CodebaseViewerModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('PORTFOLIO');
  const [selectedPoolId, setSelectedPoolId] = useState<string>('RQMBS-01');
  const [isCalculating, setIsCalculating] = useState<boolean>(false);
  const [isReportOpen, setIsReportOpen] = useState<boolean>(false);
  const [isCodeOpen, setIsCodeOpen] = useState<boolean>(false);

  // Global Models State
  const [yieldCurve, setYieldCurve] = useState<YieldCurve>(YieldCurveEngine.createBenchmarkUsdCurve());
  const [prepayConfig, setPrepayConfig] = useState<PrepaymentConfig>(defaultPrepaymentConfig);
  const [defaultConfig, setDefaultConfig] = useState<DefaultConfig>(defaultDefaultConfig);
  const [waterfallStructure, setWaterfallStructure] = useState<WaterfallStructure>(demoWaterfallStructure);

  // Current selected pool & position
  const currentPool = useMemo(() => {
    return demoPools.find(p => p.poolId === selectedPoolId) || demoPools[0];
  }, [selectedPoolId]);

  const currentPosition = useMemo(() => {
    return demoPortfolioPositions.find(p => p.securityId === selectedPoolId) || demoPortfolioPositions[0];
  }, [selectedPoolId]);

  // Generate Collateral Cash Flows for current pool
  const currentCashFlowSchedule: CashFlowSchedule = useMemo(() => {
    return CashFlowEngine.generatePoolCashFlows(
      currentPool,
      prepayConfig,
      defaultConfig,
      yieldCurve,
      currentPosition.oasBps
    );
  }, [currentPool, prepayConfig, defaultConfig, yieldCurve, currentPosition.oasBps]);

  // Overall Portfolio Analytics (Calibrated to Institutional Benchmark Summary)
  const portfolioAnalytics: PortfolioAnalytics = useMemo(() => {
    const totalMarketValue = demoPortfolioPositions.reduce((s, p) => s + p.marketValue, 0); // £842.6m
    const totalNotional = demoPortfolioPositions.reduce((s, p) => s + p.notionalBalance, 0);
    const totalDv01 = demoPortfolioPositions.reduce((s, p) => s + p.dv01, 0); // £40,400
    const totalCs01 = demoPortfolioPositions.reduce((s, p) => s + p.cs01, 0);
    const totalExpectedLoss = demoPortfolioPositions.reduce((s, p) => s + p.expectedLoss, 0); // £8.2m
    const totalStressLoss = demoPortfolioPositions.reduce((s, p) => s + p.stressLoss, 0); // £24.7m

    let weightedYield = 0;
    let weightedOas = 0;
    let weightedWal = 0;
    let weightedDur = 0;
    let weightedCvx = 0;
    let weightedScore = 0;

    for (const p of demoPortfolioPositions) {
      const w = p.marketValue / totalMarketValue;
      weightedYield += w * p.yieldToMaturity;
      weightedOas += w * p.oasBps;
      weightedWal += w * p.walYears;
      weightedDur += w * p.effectiveDuration;
      weightedCvx += w * p.effectiveConvexity;
      weightedScore += w * p.qualityScore;
    }

    const { riskBreakdown, bucketedDv01 } = RiskEngine.decomposeRisk(
      totalMarketValue,
      weightedDur,
      false,
      totalExpectedLoss,
      totalStressLoss
    );

    return {
      totalMarketValue,
      totalNotionalBalance: totalNotional,
      weightedYield: Math.round(weightedYield * 10000) / 10000, // 5.41%
      weightedOasBps: Math.round(weightedOas), // 94 bp
      weightedWalYears: Math.round(weightedWal * 10) / 10, // 6.2 yrs
      weightedDuration: Math.round(weightedDur * 10) / 10, // 4.8
      weightedConvexity: Math.round(weightedCvx * 10) / 10, // -1.7
      totalDv01, // £40,400
      totalCs01,
      totalExpectedLoss, // £8.2m
      totalStressLoss, // £24.7m
      portfolioQualityScore: Math.round(weightedScore), // 82/100
      riskBreakdown,
      bucketedDv01,
    };
  }, []);

  const handleRecalculateAll = () => {
    setIsCalculating(true);
    setTimeout(() => {
      setIsCalculating(false);
    }, 400);
  };

  const handleSelectSecurity = (secId: string) => {
    setSelectedPoolId(secId);
    setActiveTab('SECURITIES');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-amber-500 selection:text-slate-950 flex flex-col">
      {/* Institutional Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenReportModal={() => setIsReportOpen(true)}
        onOpenCodeModal={() => setIsCodeOpen(true)}
        onRecalculateAll={handleRecalculateAll}
        isCalculating={isCalculating}
      />

      {/* Main Analytical Stage */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Core Institutional Dashboard Metric Header Card */}
        <DashboardMetricsHeader
          analytics={portfolioAnalytics}
          onNavigateTab={setActiveTab}
        />

        {/* Dynamic Tab Views */}
        {activeTab === 'PORTFOLIO' && (
          <PortfolioView
            positions={demoPortfolioPositions}
            analytics={portfolioAnalytics}
            onSelectSecurity={handleSelectSecurity}
          />
        )}

        {activeTab === 'SECURITIES' && (
          <SecuritiesView
            pools={demoPools}
            positions={demoPortfolioPositions}
            selectedPoolId={selectedPoolId}
            onSelectPool={setSelectedPoolId}
            onNavigateToTab={setActiveTab}
          />
        )}

        {activeTab === 'CASH_FLOWS' && (
          <CashFlowsView
            schedule={currentCashFlowSchedule}
            pool={currentPool}
          />
        )}

        {activeTab === 'PREPAYMENT' && (
          <PrepaymentLabView
            config={prepayConfig}
            onChangeConfig={setPrepayConfig}
            wac={currentPool.weightedAverageCoupon}
          />
        )}

        {activeTab === 'CREDIT' && (
          <CreditView
            config={defaultConfig}
            onChangeConfig={setDefaultConfig}
            pool={currentPool}
          />
        )}

        {activeTab === 'WATERFALL' && (
          <WaterfallView
            structure={waterfallStructure}
            collateralSchedule={currentCashFlowSchedule}
          />
        )}

        {activeTab === 'OAS' && (
          <OasValuationView
            yieldCurve={yieldCurve}
            pool={currentPool}
            position={currentPosition}
          />
        )}

        {activeTab === 'CONVEXITY' && (
          <ConvexityView
            position={currentPosition}
            pool={currentPool}
          />
        )}

        {activeTab === 'SURFACES' && (
          <SurfacesView
            position={currentPosition}
          />
        )}

        {activeTab === 'SCENARIOS' && (
          <ScenariosView
            pool={currentPool}
            prepayConfig={prepayConfig}
            defaultConfig={defaultConfig}
            yieldCurve={yieldCurve}
            marketPrice={currentPosition.marketPrice}
            notionalBalance={currentPosition.notionalBalance}
          />
        )}

        {activeTab === 'MONTE_CARLO' && (
          <MonteCarloView
            position={currentPosition}
          />
        )}

        {activeTab === 'RELATIVE_VALUE' && (
          <RelativeValueView
            positions={demoPortfolioPositions}
            onSelectSecurity={handleSelectSecurity}
          />
        )}

        {activeTab === 'OPTIMIZER' && (
          <OptimizerView
            positions={demoPortfolioPositions}
          />
        )}

        {activeTab === 'AUDIT' && (
          <AuditView
            position={currentPosition}
          />
        )}
      </main>

      {/* Footer Strip */}
      <footer className="border-t border-slate-800/80 bg-slate-950/80 py-4 px-6 text-center text-xs font-mono text-slate-500">
        <div className="flex flex-wrap items-center justify-between max-w-7xl mx-auto gap-2">
          <div>
            RHINOQUANT MBS ENGINE · RUST CORE v2.4.0 · R STATISTICAL RUNTIME v4.4.2
          </div>
          <div>
            SR 11-7 MODEL RISK COMPLIANT · STRICT DETERMINISTIC ARITHMETIC
          </div>
        </div>
      </footer>

      {/* Report Generator Modal */}
      <ReportGeneratorModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        analytics={portfolioAnalytics}
        positions={demoPortfolioPositions}
      />

      {/* Codebase Viewer Modal */}
      <CodebaseViewerModal
        isOpen={isCodeOpen}
        onClose={() => setIsCodeOpen(false)}
      />
    </div>
  );
}
