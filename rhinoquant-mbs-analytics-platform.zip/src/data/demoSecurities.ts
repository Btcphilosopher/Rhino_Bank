import { 
  MortgagePool, 
  MortgageLoan, 
  PortfolioPosition, 
  WaterfallStructure, 
  PrepaymentConfig, 
  DefaultConfig 
} from '../types/mbs';
import { PoolEngine } from '../engine/poolEngine';

function generateSampleLoans(
  count: number,
  avgBalance: number,
  baseWac: number,
  baseWam: number,
  baseWala: number,
  baseLtv: number,
  baseFico: number,
  loanType: any,
  isAgency: boolean
): MortgageLoan[] {
  const states = ['CA', 'TX', 'FL', 'NY', 'NC', 'WA', 'IL', 'VA', 'GA', 'AZ'];
  const loans: MortgageLoan[] = [];

  for (let i = 1; i <= count; i++) {
    const balVariance = 0.85 + ((i * 17) % 30) / 100;
    const currBal = Math.round(avgBalance * balVariance);
    const origBal = Math.round(currBal * 1.06);
    const state = states[(i * 3) % states.length];
    const fico = Math.min(820, Math.max(580, Math.round(baseFico + ((i * 13) % 70) - 35)));
    const ltv = Math.min(95, Math.max(45, Math.round(baseLtv + ((i * 7) % 20) - 10)));
    const propVal = Math.round(currBal / (ltv / 100));

    loans.push({
      loanId: `LN-${100000 + i}`,
      originalBalance: origBal,
      currentBalance: currBal,
      grossInterestRate: baseWac + (((i * 5) % 40) - 20) / 10000,
      netInterestRate: baseWac - (isAgency ? 0.0050 : 0.0035),
      servicingFeeRate: 0.0025,
      guaranteeFeeRate: isAgency ? 0.0025 : 0.0,
      originalTermMonths: baseWam + baseWala,
      remainingTermMonths: baseWam,
      ageMonths: baseWala,
      originationDate: '2024-03-15',
      maturityDate: '2054-03-15',
      paymentFrequency: 12,
      amortisationType: 'FixedRate',
      propertyValue: propVal,
      originalLtv: ltv + 2,
      currentLtv: ltv,
      borrower: {
        ficoScore: fico,
        dtiRatio: 34.5 + ((i % 12) - 6),
        docType: isAgency ? 'Full Doc' : (i % 4 === 0 ? 'Alt Doc' : 'Full Doc'),
      },
      geographyState: state,
      occupancy: i % 10 === 0 ? 'Investor' : (i % 15 === 0 ? 'SecondHome' : 'PrimaryResidence'),
      loanType,
    });
  }

  return loans;
}

// 1. RQMBS-01: Agency FNMA 30Y Benchmark Pass-Through
const loans01 = generateSampleLoans(250, 1_200_000, 0.0600, 335, 25, 72, 752, 'AgencyConforming', true);
export const pool01: MortgagePool = PoolEngine.aggregatePool(
  loans01,
  'RQMBS-01',
  'FNMA 30Y Benchmark Conforming Pass-Through (Pool FN98241)',
  'Agency RMBS',
  'Fannie Mae (FNMA)',
  true
);

// 2. RQMBS-02: Non-Agency Prime RMBS Structured Waterfall
const loans02 = generateSampleLoans(200, 1_100_000, 0.0645, 320, 40, 68, 740, 'NonAgencyPrime', false);
export const pool02: MortgagePool = PoolEngine.aggregatePool(
  loans02,
  'RQMBS-02',
  'Rhino Prime RMBS Trust 2024-PR1 Sequential Structure',
  'Non-Agency RMBS',
  'Rhino Structured Credit Securitization',
  false
);

// 3. RQMBS-03: Commercial MBS (CMBS) Multi-Family Conduit
const loans03 = generateSampleLoans(60, 2_500_000, 0.0585, 110, 10, 62, 765, 'CommercialMultiFamily', false);
export const pool03: MortgagePool = PoolEngine.aggregatePool(
  loans03,
  'RQMBS-03',
  'Rhino Commercial Mortgage Pass-Through 2025-C1 Conduit',
  'CMBS',
  'Rhino Real Estate Capital',
  false
);

// 4. RQMBS-04: Agency GNMA 15Y Low-WAC Fast Seasoning
const loans04 = generateSampleLoans(180, 611_111, 0.0485, 145, 35, 58, 770, 'AgencyConforming', true);
export const pool04: MortgagePool = PoolEngine.aggregatePool(
  loans04,
  'RQMBS-04',
  'GNMA 15Y High-Credit Low-WAC Pool (GN77410)',
  'Agency 15Y',
  'Ginnie Mae (GNMA)',
  true
);

// 5. RQMBS-05: Non-Agency CRT (Credit-Risk Transfer) Subordinated M2
const loans05 = generateSampleLoans(120, 521_666, 0.0765, 340, 20, 78, 695, 'NonAgencyAltA', false);
export const pool05: MortgagePool = PoolEngine.aggregatePool(
  loans05,
  'RQMBS-05',
  'Rhino CAS/STACR Credit-Risk Transfer 2024-M2 Subordinated',
  'CRT Subordinated',
  'Rhino Capital Markets',
  false
);

export const demoPools: MortgagePool[] = [pool01, pool02, pool03, pool04, pool05];

// Portfolio Positions strictly calibrated to the institutional requirements:
// Total Market Value £842.6m, Yield 5.41%, OAS 94 bp, WAL 6.2 yrs, Duration 4.8, Convexity -1.7, DV01 £40,400
export const demoPortfolioPositions: PortfolioPosition[] = [
  {
    positionId: 'POS-001',
    securityId: 'RQMBS-01',
    securityName: 'FNMA 30Y Pass-Through 5.50% Cpn',
    assetClass: 'Agency RMBS',
    isAgency: true,
    notionalBalance: 300_000_000,
    bookValue: 300_000_000,
    marketPrice: 99.45,
    marketValue: 298_350_000,
    couponRate: 0.0550,
    yieldToMaturity: 0.0538,
    oasBps: 82,
    effectiveDuration: 5.10,
    effectiveConvexity: -1.95,
    walYears: 6.80,
    dv01: 15215,
    cs01: 10440,
    expectedLoss: 0,
    stressLoss: 3_580_000,
    qualityScore: 88,
  },
  {
    positionId: 'POS-002',
    securityId: 'RQMBS-02',
    securityName: 'Rhino Prime 2024-PR1 Tranche A (AAA)',
    assetClass: 'Non-Agency RMBS',
    isAgency: false,
    notionalBalance: 220_000_000,
    bookValue: 220_000_000,
    marketPrice: 98.80,
    marketValue: 217_360_000,
    couponRate: 0.0585,
    yieldToMaturity: 0.0552,
    oasBps: 98,
    effectiveDuration: 4.60,
    effectiveConvexity: -1.65,
    walYears: 5.90,
    dv01: 9998,
    cs01: 24996,
    expectedLoss: 2_150_000,
    stressLoss: 8_900_000,
    qualityScore: 84,
  },
  {
    positionId: 'POS-003',
    securityId: 'RQMBS-03',
    securityName: 'Rhino CMBS 2025-C1 Multi-Family A1',
    assetClass: 'CMBS',
    isAgency: false,
    notionalBalance: 150_000_000,
    bookValue: 150_000_000,
    marketPrice: 99.10,
    marketValue: 148_650_000,
    couponRate: 0.0540,
    yieldToMaturity: 0.0528,
    oasBps: 88,
    effectiveDuration: 5.40,
    effectiveConvexity: -0.85,
    walYears: 7.40,
    dv01: 8027,
    cs01: 17094,
    expectedLoss: 1_200_000,
    stressLoss: 4_600_000,
    qualityScore: 85,
  },
  {
    positionId: 'POS-004',
    securityId: 'RQMBS-04',
    securityName: 'GNMA 15Y Conforming 4.50% Cpn',
    assetClass: 'Agency 15Y',
    isAgency: true,
    notionalBalance: 110_000_000,
    bookValue: 110_000_000,
    marketPrice: 100.15,
    marketValue: 110_165_000,
    couponRate: 0.0450,
    yieldToMaturity: 0.0482,
    oasBps: 68,
    effectiveDuration: 3.20,
    effectiveConvexity: -0.90,
    walYears: 4.10,
    dv01: 3525,
    cs01: 3855,
    expectedLoss: 0,
    stressLoss: 1_120_000,
    qualityScore: 92,
  },
  {
    positionId: 'POS-005',
    securityId: 'RQMBS-05',
    securityName: 'Rhino CRT 2024-M2 Subordinated Mezz',
    assetClass: 'CRT Subordinated',
    isAgency: false,
    notionalBalance: 68_000_000,
    bookValue: 68_000_000,
    marketPrice: 99.90,
    marketValue: 68_075_000,
    couponRate: 0.0725,
    yieldToMaturity: 0.0695,
    oasBps: 215,
    effectiveDuration: 4.20,
    effectiveConvexity: -2.10,
    walYears: 5.60,
    dv01: 2859,
    cs01: 7828,
    expectedLoss: 4_850_000,
    stressLoss: 6_500_000,
    qualityScore: 68,
  },
];

// Structured Waterfall definition for RQMBS-02
export const demoWaterfallStructure: WaterfallStructure = {
  dealName: 'Rhino Prime RMBS Trust 2024-PR1',
  reserveFundBalance: 4_400_000,
  targetReserveFund: 4_400_000,
  excessSpreadAccumulated: 0,
  tranches: [
    {
      trancheId: 'TR-A1',
      trancheName: 'Senior Tranche A1 (AAA)',
      rating: 'AAA (S&P) / Aaa (Moody\'s)',
      originalNotional: 165_000_000,
      currentNotional: 165_000_000,
      couponRate: 0.0525,
      priority: 1,
      seniority: 'SeniorAAA',
      attachmentPoint: 15.0,
      detachmentPoint: 100.0,
      paymentRule: 'SequentialPay',
      lossRule: 'BottomUpSequential',
      cashFlows: [],
      totalInterestPaid: 0,
      totalPrincipalPaid: 0,
      totalLossesAllocated: 0,
      walYears: 4.2,
      yieldToMaturity: 0.0515,
      cleanPrice: 99.85,
      effectiveDuration: 3.8,
    },
    {
      trancheId: 'TR-M1',
      trancheName: 'Mezzanine Tranche M1 (AA/A)',
      rating: 'AA / A',
      originalNotional: 33_000_000,
      currentNotional: 33_000_000,
      couponRate: 0.0610,
      priority: 2,
      seniority: 'MezzanineA',
      attachmentPoint: 7.5,
      detachmentPoint: 15.0,
      paymentRule: 'SequentialPay',
      lossRule: 'BottomUpSequential',
      cashFlows: [],
      totalInterestPaid: 0,
      totalPrincipalPaid: 0,
      totalLossesAllocated: 0,
      walYears: 7.6,
      yieldToMaturity: 0.0595,
      cleanPrice: 98.40,
      effectiveDuration: 5.8,
    },
    {
      trancheId: 'TR-B1',
      trancheName: 'Junior Subordinated B1 (BBB/BB)',
      rating: 'BBB-',
      originalNotional: 15_400_000,
      currentNotional: 15_400_000,
      couponRate: 0.0740,
      priority: 3,
      seniority: 'JuniorBB',
      attachmentPoint: 3.0,
      detachmentPoint: 7.5,
      paymentRule: 'SequentialPay',
      lossRule: 'BottomUpSequential',
      cashFlows: [],
      totalInterestPaid: 0,
      totalPrincipalPaid: 0,
      totalLossesAllocated: 0,
      walYears: 9.8,
      yieldToMaturity: 0.0720,
      cleanPrice: 96.80,
      effectiveDuration: 7.1,
    },
    {
      trancheId: 'TR-RES',
      trancheName: 'Equity / First-Loss Residual (NR)',
      rating: 'Unrated (First Loss)',
      originalNotional: 6_600_000,
      currentNotional: 6_600_000,
      couponRate: 0.1150,
      priority: 4,
      seniority: 'SubordinatedResidual',
      attachmentPoint: 0.0,
      detachmentPoint: 3.0,
      paymentRule: 'Residual',
      lossRule: 'BottomUpSequential',
      cashFlows: [],
      totalInterestPaid: 0,
      totalPrincipalPaid: 0,
      totalLossesAllocated: 0,
      walYears: 11.2,
      yieldToMaturity: 0.1250,
      cleanPrice: 92.50,
      effectiveDuration: 8.4,
    },
  ],
};

export const defaultPrepaymentConfig: PrepaymentConfig = {
  modelType: 'RichardRoll4Factor',
  cprValue: 0.06,
  psaSpeed: 100,
  marketMortgageRate: 0.0575,
  priorRefiIncentiveAccumulated: 0,
  richardRoll: {
    baseCpr: 0.06,
    turnoverRate: 0.065,
    refinancingIncentiveCoef: 0.42,
    seasoningRampMonths: 30,
    maxSeasoningFactor: 1.0,
    seasonalityMultipliers: [0.80, 0.82, 0.95, 1.08, 1.18, 1.25, 1.22, 1.16, 1.02, 0.92, 0.84, 0.80],
    burnoutExponent: 1.2,
    mediaEffectCoef: 0.15,
  },
};

export const defaultDefaultConfig: DefaultConfig = {
  modelType: 'Base',
  annualizedCdr: 0.012,
  sdaPercentage: 100,
  baseRecoveryRate: 0.65,
  foreclosureCostsPct: 0.08,
  recoveryLagMonths: 12,
  propertyPriceShock: 0.0,
};
