# ==============================================================================
# RhinoQuant MBS Analytics Unit & Reconciliation Tests
# ==============================================================================

library(testthat)

test_that("CPR to SMM conversion satisfies boundary conditions", {
  cpr_to_smm <- function(cpr) 1 - (1 - cpr)^(1/12)
  smm_to_cpr <- function(smm) 1 - (1 - smm)^12
  
  # Known test value: 6% CPR is approx 0.5143% SMM
  smm_6 <- cpr_to_smm(0.06)
  expect_equal(round(smm_6, 6), 0.005143)
  
  # Identity round-trip
  expect_equal(smm_to_cpr(smm_6), 0.06, tolerance = 1e-7)
  expect_equal(cpr_to_smm(0.0), 0.0)
})

test_that("Mortgage level-pay amortisation reconciles principal and interest balance", {
  calculate_payment <- function(balance, annual_rate, n_months) {
    r <- annual_rate / 12
    balance * (r * (1 + r)^n_months) / ((1 + r)^n_months - 1)
  }
  
  balance <- 400000
  rate <- 0.06
  n <- 360
  pmt <- calculate_payment(balance, rate, n)
  
  # Known benchmark: $400k at 6.00% 30Y has monthly payment of ~$2,398.20
  expect_equal(round(pmt, 2), 2398.20)
})

test_that("Effective duration finite difference is directionally sound", {
  p_base <- 100.0
  p_down <- 102.40 # Yield drops 25 bps
  p_up <- 97.50   # Yield rises 25 bps
  dy <- 0.0025
  
  eff_dur <- (p_down - p_up) / (2 * p_base * dy)
  expect_true(eff_dur > 0)
  expect_equal(round(eff_dur, 2), 9.80)
})
