use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecoveryParams {
    pub base_recovery_rate: f64,    // e.g. 0.65 (65%)
    pub foreclosure_costs_pct: f64, // e.g. 0.08 (8% of property value)
    pub maintenance_costs_pct: f64, // e.g. 0.04
    pub recovery_lag_months: u32,   // e.g. 12 months
}

impl Default for RecoveryParams {
    fn default() -> Self {
        Self {
            base_recovery_rate: 0.65,
            foreclosure_costs_pct: 0.08,
            maintenance_costs_pct: 0.04,
            recovery_lag_months: 12,
        }
    }
}

pub struct RecoveryModel;

impl RecoveryModel {
    /// Calculate net recovery and loss given default (LGD)
    /// LGD = 1 - Net Recovery Rate
    pub fn calculate_net_recovery(
        params: &RecoveryParams,
        defaulted_balance: f64,
        property_value: f64,
        property_price_shock: f64,
    ) -> (f64, f64, f64) {
        if defaulted_balance <= 0.0 {
            return (0.0, 0.0, 0.0);
        }

        let shocked_property_value = property_value * (1.0 + property_price_shock).max(0.1);
        let gross_liquidation = shocked_property_value * params.base_recovery_rate;
        let liquidation_costs = shocked_property_value * (params.foreclosure_costs_pct + params.maintenance_costs_pct);
        
        let net_recovery = (gross_liquidation - liquidation_costs).max(0.0).min(defaulted_balance);
        let realized_loss = (defaulted_balance - net_recovery).max(0.0);
        let loss_severity = realized_loss / defaulted_balance;

        (net_recovery, realized_loss, loss_severity)
    }
}
