use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum PrepaymentModelType {
    ConstantCPR(f64),
    PSA(f64), // e.g. 100.0 for 100% PSA, 150.0 for 150% PSA
    RichardRoll4Factor(RichardRollPrepayment),
    CustomVector(Vec<f64>),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RichardRollPrepayment {
    pub base_cpr: f64,
    pub turnover_rate: f64,
    pub refinancing_incentive_coef: f64,
    pub seasoning_ramp_months: u32,
    pub max_seasoning_factor: f64,
    pub seasonality_multipliers: [f64; 12], // Jan - Dec
    pub burnout_exponent: f64,
    pub media_effect_coef: f64,
}

impl Default for RichardRollPrepayment {
    fn default() -> Self {
        Self {
            base_cpr: 0.06,
            turnover_rate: 0.07,
            refinancing_incentive_coef: 0.85,
            seasoning_ramp_months: 30,
            max_seasoning_factor: 1.0,
            seasonality_multipliers: [
                0.80, 0.82, 0.95, 1.05, 1.15, 1.25, 1.22, 1.18, 1.02, 0.92, 0.84, 0.80,
            ],
            burnout_exponent: 1.2,
            media_effect_coef: 0.15,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PrepaymentParams {
    pub model_type: PrepaymentModelType,
    pub current_market_mortgage_rate: f64,
    pub cumulative_prior_refi_incentive: f64,
}

pub struct PrepaymentModel;

impl PrepaymentModel {
    /// Convert annual CPR (Conditional Prepayment Rate) to monthly SMM (Single Monthly Mortality)
    /// Formula: SMM = 1 - (1 - CPR)^(1/12)
    #[inline]
    pub fn cpr_to_smm(cpr: f64) -> f64 {
        if cpr <= 0.0 {
            return 0.0;
        }
        if cpr >= 1.0 {
            return 1.0;
        }
        1.0 - (1.0 - cpr).powf(1.0 / 12.0)
    }

    /// Convert monthly SMM to annual CPR
    /// Formula: CPR = 1 - (1 - SMM)^12
    #[inline]
    pub fn smm_to_cpr(smm: f64) -> f64 {
        if smm <= 0.0 {
            return 0.0;
        }
        if smm >= 1.0 {
            return 1.0;
        }
        1.0 - (1.0 - smm).powi(12)
    }

    /// Calculate CPR for standard PSA (Public Securities Association) prepayment benchmark
    /// 100% PSA: CPR rises by 0.2% per month for months 1-30 up to 6%, then stays at 6%
    pub fn calculate_psa_cpr(psa_speed: f64, loan_age_months: u32) -> f64 {
        let base_cpr = if loan_age_months <= 30 {
            0.06 * (loan_age_months as f64) / 30.0
        } else {
            0.06
        };
        (psa_speed / 100.0) * base_cpr
    }

    /// Calculate Richard & Roll 4-factor behavioral prepayment rate
    /// CPR = Base + Refi_Incentive * Seasoning * Seasonality * Burnout
    pub fn calculate_richard_roll_cpr(
        model: &RichardRollPrepayment,
        wac: f64,
        market_rate: f64,
        loan_age_months: u32,
        calendar_month: usize, // 1 to 12
        burnout_factor: f64,
    ) -> f64 {
        // 1. Refinancing Incentive (S-Curve)
        let rate_diff_bps = (wac - market_rate) * 10000.0; // e.g. +150 bps
        let refi_effect = if rate_diff_bps > -200.0 {
            let x = (rate_diff_bps - 50.0) / 75.0;
            // Logistic S-curve
            let s_curve = 1.0 / (1.0 + (-x).exp());
            s_curve * model.refinancing_incentive_coef
        } else {
            0.0
        };

        // 2. Seasoning Multiplier (Linear ramp to 30 months)
        let seasoning = if loan_age_months >= model.seasoning_ramp_months {
            model.max_seasoning_factor
        } else {
            (loan_age_months as f64) / (model.seasoning_ramp_months as f64)
        };

        // 3. Seasonality (Housing turnover higher in Summer)
        let month_idx = (calendar_month.saturating_sub(1)) % 12;
        let seasonality = model.seasonality_multipliers[month_idx];

        // 4. Burnout Factor (Borrowers who haven't refinanced despite low rates are less sensitive)
        let burnout = (1.0 / (1.0 + burnout_factor)).powf(model.burnout_exponent);

        let total_cpr = model.turnover_rate + (refi_effect * seasoning * seasonality * burnout);
        total_cpr.clamp(0.01, 0.85)
    }

    /// Get period SMM given model params
    pub fn get_smm(
        params: &PrepaymentParams,
        wac: f64,
        loan_age_months: u32,
        period: u32,
        burnout_factor: f64,
    ) -> f64 {
        let cpr = match &params.model_type {
            PrepaymentModelType::ConstantCPR(c) => *c,
            PrepaymentModelType::PSA(psa) => Self::calculate_psa_cpr(*psa, loan_age_months),
            PrepaymentModelType::RichardRoll4Factor(rr) => {
                let cal_month = ((period - 1) % 12) + 1;
                Self::calculate_richard_roll_cpr(
                    rr,
                    wac,
                    params.current_market_mortgage_rate,
                    loan_age_months,
                    cal_month as usize,
                    burnout_factor,
                )
            }
            PrepaymentModelType::CustomVector(vec) => {
                let idx = (period.saturating_sub(1)) as usize;
                if idx < vec.len() {
                    vec[idx]
                } else {
                    *vec.last().unwrap_or(&0.06)
                }
            }
        };

        Self::cpr_to_smm(cpr)
    }
}
