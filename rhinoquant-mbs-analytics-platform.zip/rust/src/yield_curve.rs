use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum InterpolationMethod {
    Linear,
    LogLinear,
    MonotonicCubic,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct YieldPoint {
    pub tenor_years: f64,
    pub zero_rate: f64, // e.g. 0.0450 for 4.50%
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct YieldCurve {
    pub curve_id: String,
    pub curve_name: String,
    pub points: Vec<YieldPoint>,
    pub interpolation: InterpolationMethod,
    pub shift_bps: f64,
}

impl YieldCurve {
    pub fn new_benchmark_usd_treasury() -> Self {
        Self {
            curve_id: "USD_TSY_BENCHMARK".to_string(),
            curve_name: "US Treasury Benchmark Spot Curve".to_string(),
            points: vec![
                YieldPoint { tenor_years: 0.25, zero_rate: 0.0440 }, // 3M
                YieldPoint { tenor_years: 0.5,  zero_rate: 0.0435 }, // 6M
                YieldPoint { tenor_years: 1.0,  zero_rate: 0.0420 }, // 1Y
                YieldPoint { tenor_years: 2.0,  zero_rate: 0.0410 }, // 2Y
                YieldPoint { tenor_years: 3.0,  zero_rate: 0.0415 }, // 3Y
                YieldPoint { tenor_years: 5.0,  zero_rate: 0.0425 }, // 5Y
                YieldPoint { tenor_years: 7.0,  zero_rate: 0.0435 }, // 7Y
                YieldPoint { tenor_years: 10.0, zero_rate: 0.0448 }, // 10Y
                YieldPoint { tenor_years: 20.0, zero_rate: 0.0480 }, // 20Y
                YieldPoint { tenor_years: 30.0, zero_rate: 0.0475 }, // 30Y
            ],
            interpolation: InterpolationMethod::MonotonicCubic,
            shift_bps: 0.0,
        }
    }

    /// Interpolate zero rate for a specific tenor in years with parallel shift
    pub fn get_zero_rate(&self, tenor_years: f64) -> f64 {
        if self.points.is_empty() {
            return 0.04 + (self.shift_bps / 10000.0);
        }

        let shift = self.shift_bps / 10000.0;

        if tenor_years <= self.points.first().unwrap().tenor_years {
            return self.points.first().unwrap().zero_rate + shift;
        }

        if tenor_years >= self.points.last().unwrap().tenor_years {
            return self.points.last().unwrap().zero_rate + shift;
        }

        // Find surrounding points
        for i in 0..self.points.len() - 1 {
            let p1 = &self.points[i];
            let p2 = &self.points[i + 1];

            if tenor_years >= p1.tenor_years && tenor_years <= p2.tenor_years {
                let t = (tenor_years - p1.tenor_years) / (p2.tenor_years - p1.tenor_years);
                let base_rate = match self.interpolation {
                    InterpolationMethod::Linear => p1.zero_rate + t * (p2.zero_rate - p1.zero_rate),
                    InterpolationMethod::LogLinear => {
                        let df1 = (-p1.zero_rate * p1.tenor_years).exp();
                        let df2 = (-p2.zero_rate * p2.tenor_years).exp();
                        let df = (df1.powf(1.0 - t)) * (df2.powf(t));
                        if tenor_years > 0.0 {
                            -df.ln() / tenor_years
                        } else {
                            p1.zero_rate
                        }
                    }
                    InterpolationMethod::MonotonicCubic => {
                        // Smooth Hermite cubic interpolation
                        let h00 = 2.0 * t * t * t - 3.0 * t * t + 1.0;
                        let h10 = t * t * t - 2.0 * t * t + t;
                        let h01 = -2.0 * t * t * t + 3.0 * t * t;
                        let h11 = t * t * t - t * t;

                        let dt = p2.tenor_years - p1.tenor_years;
                        let m0 = 0.0;
                        let m1 = 0.0;
                        h00 * p1.zero_rate + h10 * dt * m0 + h01 * p2.zero_rate + h11 * dt * m1
                    }
                };
                return base_rate + shift;
            }
        }

        self.points.last().unwrap().zero_rate + shift
    }

    /// Calculate discount factor for cash flow discounting: DF = exp(-r * t)
    pub fn get_discount_factor(&self, tenor_years: f64, spread_bps: f64) -> f64 {
        if tenor_years <= 0.0 {
            return 1.0;
        }
        let zero_rate = self.get_zero_rate(tenor_years);
        let total_discount_rate = zero_rate + (spread_bps / 10000.0);
        (-total_discount_rate * tenor_years).exp()
    }
}
