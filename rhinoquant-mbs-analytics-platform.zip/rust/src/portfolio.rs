use crate::risk::{RiskDecomposition, DV01Profile};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PortfolioPosition {
    pub position_id: String,
    pub security_id: String,
    pub security_name: String,
    pub notional_balance: f64,
    pub book_value: f64,
    pub market_price: f64, // clean price %
    pub market_value: f64,
    pub yield_to_maturity: f64,
    pub oas_bps: f64,
    pub effective_duration: f64,
    pub effective_convexity: f64,
    pub wal_years: f64,
    pub dv01: f64,
    pub cs01: f64,
    pub expected_loss: f64,
    pub stress_loss: f64,
    pub quality_score: f64,
    pub asset_class: String, // Agency RMBS, Non-Agency RMBS, CMBS, CRT
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PortfolioAnalytics {
    pub total_market_value: f64,
    pub total_book_value: f64,
    pub weighted_yield: f64,
    pub weighted_oas_bps: f64,
    pub weighted_duration: f64,
    pub weighted_convexity: f64,
    pub weighted_wal_years: f64,
    pub total_dv01: f64,
    pub total_cs01: f64,
    pub total_expected_loss: f64,
    pub total_stress_loss: f64,
    pub portfolio_mbs_quality_score: f64,
    pub risk_breakdown: RiskDecomposition,
    pub bucketed_dv01: DV01Profile,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MBSPortfolio {
    pub portfolio_name: String,
    pub base_currency: String,
    pub positions: Vec<PortfolioPosition>,
}

impl MBSPortfolio {
    pub fn new(portfolio_name: String, base_currency: String) -> Self {
        Self {
            portfolio_name,
            base_currency,
            positions: Vec::new(),
        }
    }

    /// Aggregate portfolio metrics with rigorous market-value weighting
    pub fn calculate_analytics(&self) -> PortfolioAnalytics {
        let mut tot_mv = 0.0;
        let mut tot_bv = 0.0;
        let mut weighted_yield_sum = 0.0;
        let mut weighted_oas_sum = 0.0;
        let mut weighted_dur_sum = 0.0;
        let mut weighted_cvx_sum = 0.0;
        let mut weighted_wal_sum = 0.0;
        let mut weighted_score_sum = 0.0;
        let mut tot_dv01 = 0.0;
        let mut tot_cs01 = 0.0;
        let mut tot_exp_loss = 0.0;
        let mut tot_stress_loss = 0.0;

        for p in &self.positions {
            tot_mv += p.market_value;
            tot_bv += p.book_value;
            weighted_yield_sum += p.yield_to_maturity * p.market_value;
            weighted_oas_sum += p.oas_bps * p.market_value;
            weighted_dur_sum += p.effective_duration * p.market_value;
            weighted_cvx_sum += p.effective_convexity * p.market_value;
            weighted_wal_sum += p.wal_years * p.market_value;
            weighted_score_sum += p.quality_score * p.market_value;
            tot_dv01 += p.dv01;
            tot_cs01 += p.cs01;
            tot_exp_loss += p.expected_loss;
            tot_stress_loss += p.stress_loss;
        }

        let mv_denom = tot_mv.max(1.0);
        let w_yield = weighted_yield_sum / mv_denom;
        let w_oas = weighted_oas_sum / mv_denom;
        let w_dur = weighted_dur_sum / mv_denom;
        let w_cvx = weighted_cvx_sum / mv_denom;
        let w_wal = weighted_wal_sum / mv_denom;
        let w_score = weighted_score_sum / mv_denom;

        let (risk_decomp, dv01_prof) = crate::risk::RiskEngine::decompose_risk(
            tot_mv,
            w_dur,
            w_cvx,
            w_oas,
            0.015,
            0.45,
            false,
        );

        PortfolioAnalytics {
            total_market_value: tot_mv,
            total_book_value: tot_bv,
            weighted_yield: w_yield,
            weighted_oas_bps: w_oas,
            weighted_duration: w_dur,
            weighted_convexity: w_cvx,
            weighted_wal_years: w_wal,
            total_dv01: tot_dv01,
            total_cs01: tot_cs01,
            total_expected_loss: tot_exp_loss,
            total_stress_loss: tot_stress_loss,
            portfolio_mbs_quality_score: w_score,
            risk_breakdown: risk_decomp,
            bucketed_dv01: dv01_prof,
        }
    }
}
