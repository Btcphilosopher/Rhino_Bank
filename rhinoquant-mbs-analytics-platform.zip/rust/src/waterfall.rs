use crate::cashflow::CashFlowPeriod;
use crate::tranche::Tranche;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WaterfallStructure {
    pub deal_name: String,
    pub tranches: Vec<Tranche>,
    pub reserve_fund_balance: f64,
    pub target_reserve_fund: f64,
    pub excess_spread_accumulated: f64,
}

pub struct WaterfallEngine;

impl WaterfallEngine {
    /// Execute institutional structured finance cash flow and loss waterfall
    /// 1. Allocate collateral interest to tranches in order of seniority (Priority 1 -> N)
    /// 2. Allocate collateral losses bottom-up (Junior / Residual absorbs first)
    /// 3. Allocate available principal (Scheduled + Prepayment + Recovery) sequentially or pro-rata
    /// 4. Route residual excess spread
    pub fn process_period(
        structure: &mut WaterfallStructure,
        cf: &CashFlowPeriod,
    ) {
        let period = cf.period;
        let mut available_interest = cf.net_interest;
        let mut available_principal = cf.scheduled_principal + cf.prepayment_principal + cf.recovery_cash;
        let mut unallocated_loss = cf.realized_loss;

        // 1. LOSS ALLOCATION (Bottom-Up: Highest priority number / lowest seniority first)
        // Sort tranches reverse of seniority for loss distribution
        let tranches_len = structure.tranches.len();
        for i in (0..tranches_len).rev() {
            let tranche = &mut structure.tranches[i];
            if tranche.current_notional <= 0.0 || unallocated_loss <= 0.0 {
                continue;
            }

            let loss_to_take = unallocated_loss.min(tranche.current_notional);
            tranche.current_notional -= loss_to_take;
            unallocated_loss -= loss_to_take;

            // Record loss in latest or temporary field
        }

        // 2. INTEREST ALLOCATION (Top-Down: Priority 1 -> N)
        let mut period_interest_paid = vec![0.0; tranches_len];
        let mut period_interest_shortfall = vec![0.0; tranches_len];

        for (idx, tranche) in structure.tranches.iter_mut().enumerate() {
            if tranche.current_notional <= 0.0 {
                continue;
            }
            let monthly_rate = tranche.coupon_rate / 12.0;
            let interest_due = tranche.current_notional * monthly_rate;

            let interest_paid = interest_due.min(available_interest);
            available_interest -= interest_paid;
            let shortfall = interest_due - interest_paid;

            period_interest_paid[idx] = interest_paid;
            period_interest_shortfall[idx] = shortfall;
        }

        // 3. PRINCIPAL ALLOCATION (Sequential Pay: Senior gets 100% until paid down)
        let mut period_principal_paid = vec![0.0; tranches_len];

        for (idx, tranche) in structure.tranches.iter_mut().enumerate() {
            if tranche.current_notional <= 0.0 || available_principal <= 0.0 {
                continue;
            }

            let principal_to_pay = available_principal.min(tranche.current_notional);
            tranche.current_notional -= principal_to_pay;
            available_principal -= principal_to_pay;
            period_principal_paid[idx] = principal_to_pay;
        }

        // 4. EXCESS SPREAD TO RESIDUAL / RESERVE
        if available_interest > 0.0 {
            structure.excess_spread_accumulated += available_interest;
        }

        // 5. UPDATE TRANCHE CASH FLOW LEDGERS
        for (idx, tranche) in structure.tranches.iter_mut().enumerate() {
            let int_paid = period_interest_paid[idx];
            let prin_paid = period_principal_paid[idx];
            let tot_cf = int_paid + prin_paid;

            tranche.cash_flows.push(crate::tranche::TrancheCashFlow {
                period,
                beginning_balance: tranche.current_notional + prin_paid,
                interest_paid: int_paid,
                interest_shortfall: period_interest_shortfall[idx],
                principal_paid: prin_paid,
                loss_allocated: 0.0,
                ending_balance: tranche.current_notional,
                total_cash_flow: tot_cf,
            });
        }
    }
}
