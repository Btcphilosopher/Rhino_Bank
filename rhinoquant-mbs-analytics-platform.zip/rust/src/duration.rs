use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DurationMetrics {
    pub effective_duration: f64,
    pub modified_duration: f64,
    pub macaulay_duration_years: f64,
    pub price_up_shift: f64,   // Price at yield - 25 bps
    pub price_down_shift: f64, // Price at yield + 25 bps
    pub dv01: f64,             // Dollar Value of 01 per 100 par
    pub dv01_currency: f64,    // Total Dollar Value of 01 on notional balance
}

pub struct DurationCalculator;

impl DurationCalculator {
    /// Calculate Effective Duration using full finite-difference revaluation
    /// Eff_Dur = (Price_Down - Price_Up) / (2 * Price_0 * Delta_y)
    pub fn calculate_effective_duration(
        price_base: f64,
        price_rates_down: f64, // P_minus when rates fall (yield drops by dy)
        price_rates_up: f64,   // P_plus when rates rise (yield rises by dy)
        delta_y: f64,          // e.g. 0.0025 (25 bps)
        notional_balance: f64,
    ) -> DurationMetrics {
        if price_base <= 0.0 || delta_y <= 0.0 {
            return DurationMetrics {
                effective_duration: 0.0,
                modified_duration: 0.0,
                macaulay_duration_years: 0.0,
                price_up_shift: price_base,
                price_down_shift: price_base,
                dv01: 0.0,
                dv01_currency: 0.0,
            };
        }

        let eff_dur = (price_rates_down - price_rates_up) / (2.0 * price_base * delta_y);
        let dv01_per_100 = (price_rates_down - price_rates_up) / (2.0 * (delta_y * 10000.0));
        let total_dv01 = dv01_per_100 * (notional_balance / 100.0);

        DurationMetrics {
            effective_duration: eff_dur,
            modified_duration: eff_dur * 0.98,
            macaulay_duration_years: eff_dur * 1.02,
            price_up_shift: price_rates_up,
            price_down_shift: price_rates_down,
            dv01: dv01_per_100,
            dv01_currency: total_dv01,
        }
    }
}
