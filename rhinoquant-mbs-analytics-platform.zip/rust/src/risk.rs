use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BucketedDV01Point {
    pub bucket_label: String, // e.g. "2Y", "5Y", "10Y", "30Y"
    pub key_rate_duration: f64,
    pub bucket_dv01: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DV01Profile {
    pub total_dv01: f64,
    pub key_rate_buckets: Vec<BucketedDV01Point>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskDecomposition {
    pub total_risk_pct: f64,
    pub interest_rate_risk_pct: f64,
    pub prepayment_risk_pct: f64,
    pub credit_risk_pct: f64,
    pub spread_risk_pct: f64,
    pub liquidity_risk_pct: f64,
    pub cs01_currency: f64, // Spread DV01 (Credit Spread 01 sensitivity)
    pub expected_loss_currency: f64,
    pub stress_loss_currency: f64,
}

pub struct RiskEngine;

impl RiskEngine {
    /// Calculate complete multi-factor risk decomposition
    pub fn decompose_risk(
        market_value: f64,
        eff_duration: f64,
        eff_convexity: f64,
        oas_bps: f64,
        cdr: f64,
        loss_severity: f64,
        is_agency: bool,
    ) -> (RiskDecomposition, DV01Profile) {
        let total_dv01 = (eff_duration * market_value) / 10000.0;
        let cs01 = (market_value * 0.0001) * if is_agency { 0.4 } else { 1.2 };

        let exp_loss = if is_agency {
            0.0 // Agency guarantee protects against principal credit loss
        } else {
            market_value * (cdr * loss_severity * 3.5)
        };

        let stress_loss = if is_agency {
            market_value * 0.012 // Liquidity / discount stress only
        } else {
            market_value * (cdr * 3.0 * (loss_severity + 0.20) * 4.0).min(0.35)
        };

        let (rate_wt, prepay_wt, credit_wt, spread_wt, liq_wt) = if is_agency {
            (52.0, 32.0, 2.0, 10.0, 4.0)
        } else {
            (28.0, 18.0, 34.0, 14.0, 6.0)
        };

        let risk_decomp = RiskDecomposition {
            total_risk_pct: 100.0,
            interest_rate_risk_pct: rate_wt,
            prepayment_risk_pct: prepay_wt,
            credit_risk_pct: credit_wt,
            spread_risk_pct: spread_wt,
            liquidity_risk_pct: liq_wt,
            cs01_currency: cs01,
            expected_loss_currency: exp_loss,
            stress_loss_currency: stress_loss,
        };

        let key_rates = vec![
            BucketedDV01Point { bucket_label: "2Y".to_string(),  key_rate_duration: eff_duration * 0.15, bucket_dv01: total_dv01 * 0.15 },
            BucketedDV01Point { bucket_label: "5Y".to_string(),  key_rate_duration: eff_duration * 0.45, bucket_dv01: total_dv01 * 0.45 },
            BucketedDV01Point { bucket_label: "10Y".to_string(), key_rate_duration: eff_duration * 0.30, bucket_dv01: total_dv01 * 0.30 },
            BucketedDV01Point { bucket_label: "30Y".to_string(), key_rate_duration: eff_duration * 0.10, bucket_dv01: total_dv01 * 0.10 },
        ];

        (risk_decomp, DV01Profile { total_dv01, key_rate_buckets: key_rates })
    }
}
