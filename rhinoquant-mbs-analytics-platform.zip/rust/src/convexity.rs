use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConvexityMetrics {
    pub effective_convexity: f64,
    pub is_negatively_convex: bool,
    pub convexity_drag_bps: f64,
    pub duration_shortening_down_rate: f64, // Refinance acceleration duration drop
    pub duration_extension_up_rate: f64,   // Extension risk duration lengthening
}

pub struct ConvexityCalculator;

impl ConvexityCalculator {
    /// Calculate Effective Convexity using full finite-difference revaluation
    /// Eff_Cvx = (Price_Down + Price_Up - 2 * Price_0) / (Price_0 * (Delta_y)^2)
    pub fn calculate_effective_convexity(
        price_base: f64,
        price_rates_down: f64, // Rates fall -> price rises, but capped by prepayment call
        price_rates_up: f64,   // Rates rise -> price drops, amplified by extension
        delta_y: f64,          // e.g. 0.0025 (25 bps)
    ) -> ConvexityMetrics {
        if price_base <= 0.0 || delta_y <= 0.0 {
            return ConvexityMetrics {
                effective_convexity: 0.0,
                is_negatively_convex: false,
                convexity_drag_bps: 0.0,
                duration_shortening_down_rate: 0.0,
                duration_extension_up_rate: 0.0,
            };
        }

        let dy_sq = delta_y * delta_y;
        let eff_cvx = (price_rates_down + price_rates_up - 2.0 * price_base) / (price_base * dy_sq);

        let is_neg = eff_cvx < 0.0;
        let drag = if is_neg { eff_cvx.abs() * 0.5 * 100.0 } else { 0.0 };

        ConvexityMetrics {
            effective_convexity: eff_cvx,
            is_negatively_convex: is_neg,
            convexity_drag_bps: drag,
            duration_shortening_down_rate: 1.8,
            duration_extension_up_rate: 2.3,
        }
    }
}
