use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PercentileDistribution {
    pub p1: f64,
    pub p5: f64,
    pub p25: f64,
    pub p50_median: f64,
    pub p75: f64,
    pub p95: f64,
    pub p99: f64,
    pub mean: f64,
    pub standard_deviation: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonteCarloSimulationResult {
    pub total_simulated_paths: usize,
    pub random_seed: u64,
    pub price_distribution: PercentileDistribution,
    pub yield_distribution: PercentileDistribution,
    pub wal_distribution: PercentileDistribution,
    pub duration_distribution: PercentileDistribution,
    pub expected_loss_distribution: PercentileDistribution,
    pub value_at_risk_99_1y: f64,
    pub conditional_var_99: f64,
}

pub struct MonteCarloEngine;

impl MonteCarloEngine {
    /// Deterministic Monte Carlo simulation across correlated interest-rate, prepayment, and default paths
    pub fn simulate_mbs_paths(
        base_clean_price: f64,
        base_yield: f64,
        base_wal: f64,
        base_duration: f64,
        base_loss: f64,
        num_paths: usize,
        seed: u64,
    ) -> MonteCarloSimulationResult {
        // High-performance numerical simulation with stable pseudo-random sequences
        let mut prices = Vec::with_capacity(num_paths);
        let mut yields = Vec::with_capacity(num_paths);
        let mut wals = Vec::with_capacity(num_paths);
        let mut durs = Vec::with_capacity(num_paths);
        let mut losses = Vec::with_capacity(num_paths);

        // Linear Congruential pseudo-random generator with Box-Muller normal transform
        let mut state = seed.max(1);

        for _ in 0..num_paths {
            // Pseudo-random uniform pair
            state = state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            let u1 = ((state >> 11) as f64) / ((1u64 << 53) as f64);
            state = state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            let u2 = ((state >> 11) as f64) / ((1u64 << 53) as f64);

            let z0 = (-2.0 * u1.max(1e-10).ln()).sqrt() * (2.0 * std::f64::consts::PI * u2).cos();
            let z1 = (-2.0 * u1.max(1e-10).ln()).sqrt() * (2.0 * std::f64::consts::PI * u2).sin();

            // Interest rate shock (vol 120 bps)
            let rate_shock_bps = z0 * 115.0;
            // Prepayment shock correlated with rate shock
            let prepay_shock = -z0 * 0.45 + z1 * 0.35;
            // Credit default shock
            let default_shock = (z1 * 0.50).max(-0.8);

            // Calculate simulated price with negative convexity drag
            let dur_effect = -base_duration * (rate_shock_bps / 10000.0) * 100.0;
            let cvx_drag = -0.5 * 1.8 * (rate_shock_bps / 10000.0).powi(2) * 100.0;
            let sim_price = (base_clean_price + dur_effect + cvx_drag - default_shock * 1.5).clamp(65.0, 115.0);

            // Simulated WAL (Fast rates down -> Fast prepay -> Low WAL; Rates up -> Slow prepay -> High WAL)
            let sim_wal = (base_wal + (rate_shock_bps / 100.0) * 0.45 - prepay_shock * 0.8).clamp(1.2, 28.0);
            let sim_dur = (base_duration + (rate_shock_bps / 100.0) * 0.35).clamp(0.5, 14.0);
            let sim_yield = (base_yield + (rate_shock_bps / 10000.0)).clamp(0.01, 0.18);
            let sim_loss = (base_loss * (1.0 + default_shock)).max(0.0);

            prices.push(sim_price);
            yields.push(sim_yield);
            wals.push(sim_wal);
            durs.push(sim_dur);
            losses.push(sim_loss);
        }

        let price_dist = Self::calculate_percentiles(&mut prices);
        let yield_dist = Self::calculate_percentiles(&mut yields);
        let wal_dist = Self::calculate_percentiles(&mut wals);
        let dur_dist = Self::calculate_percentiles(&mut durs);
        let loss_dist = Self::calculate_percentiles(&mut losses);

        let var_99 = (base_clean_price - price_dist.p1).max(0.0);
        let cvar_99 = var_99 * 1.25;

        MonteCarloSimulationResult {
            total_simulated_paths: num_paths,
            random_seed: seed,
            price_distribution: price_dist,
            yield_distribution: yield_dist,
            wal_distribution: wal_dist,
            duration_distribution: dur_dist,
            expected_loss_distribution: loss_dist,
            value_at_risk_99_1y: var_99,
            conditional_var_99: cvar_99,
        }
    }

    fn calculate_percentiles(data: &mut [f64]) -> PercentileDistribution {
        data.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        let len = data.len();
        let mean: f64 = data.iter().sum::<f64>() / (len as f64);
        let var: f64 = data.iter().map(|x| (x - mean).powi(2)).sum::<f64>() / (len as f64);
        let std_dev = var.sqrt();

        let p1 = data[(len as f64 * 0.01) as usize];
        let p5 = data[(len as f64 * 0.05) as usize];
        let p25 = data[(len as f64 * 0.25) as usize];
        let p50 = data[(len as f64 * 0.50) as usize];
        let p75 = data[(len as f64 * 0.75) as usize];
        let p95 = data[(len as f64 * 0.95) as usize];
        let p99 = data[(len as f64 * 0.99).min((len - 1) as f64) as usize];

        PercentileDistribution {
            p1,
            p5,
            p25,
            p50_median: p50,
            p75,
            p95,
            p99,
            mean,
            standard_deviation: std_dev,
        }
    }
}
