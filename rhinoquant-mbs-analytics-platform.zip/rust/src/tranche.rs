use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SeniorityLevel {
    SeniorAAA,
    SeniorAA,
    MezzanineA,
    MezzanineBBB,
    JuniorBB,
    JuniorB,
    SubordinatedResidual,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PaymentRule {
    SequentialPay,
    ProRata,
    InterestOnlyStrip,
    PrincipalOnlyStrip,
    PlannedAmortisationClass, // PAC
    SupportTranche,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum LossRule {
    BottomUpSequential, // Subordinated absorbs first
    ProRataLoss,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrancheCashFlow {
    pub period: u32,
    pub beginning_balance: f64,
    pub interest_paid: f64,
    pub interest_shortfall: f64,
    pub principal_paid: f64,
    pub loss_allocated: f64,
    pub ending_balance: f64,
    pub total_cash_flow: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Tranche {
    pub tranche_id: String,
    pub tranche_name: String,
    pub original_notional: f64,
    pub current_notional: f64,
    pub coupon_rate: f64, // e.g. 0.0525
    pub priority: u32,    // Priority 1 = Senior
    pub seniority: SeniorityLevel,
    pub attachment_point: f64,  // % loss at which tranche begins taking losses
    pub detachment_point: f64,  // % loss at which tranche is wiped out
    pub payment_rule: PaymentRule,
    pub loss_rule: LossRule,
    pub cash_flows: Vec<TrancheCashFlow>,
    pub total_interest_paid: f64,
    pub total_principal_paid: f64,
    pub total_losses_allocated: f64,
    pub weighted_average_life: f64,
}

impl Tranche {
    pub fn new(
        tranche_id: String,
        tranche_name: String,
        original_notional: f64,
        coupon_rate: f64,
        priority: u32,
        seniority: SeniorityLevel,
        attachment_point: f64,
        detachment_point: f64,
        payment_rule: PaymentRule,
        loss_rule: LossRule,
    ) -> Self {
        Self {
            tranche_id,
            tranche_name,
            original_notional,
            current_notional: original_notional,
            coupon_rate,
            priority,
            seniority,
            attachment_point,
            detachment_point,
            payment_rule,
            loss_rule,
            cash_flows: Vec::new(),
            total_interest_paid: 0.0,
            total_principal_paid: 0.0,
            total_losses_allocated: 0.0,
            weighted_average_life: 0.0,
        }
    }

    pub fn finalize_metrics(&mut self) {
        let mut wal_numerator = 0.0;
        let mut total_prin = 0.0;
        let mut tot_int = 0.0;
        let mut tot_loss = 0.0;

        for cf in &self.cash_flows {
            tot_int += cf.interest_paid;
            tot_prin += cf.principal_paid;
            tot_loss += cf.loss_allocated;
            let t_years = (cf.period as f64) / 12.0;
            wal_numerator += t_years * cf.principal_paid;
        }

        self.total_interest_paid = tot_int;
        self.total_principal_paid = tot_prin;
        self.total_losses_allocated = tot_loss;

        let denom = if total_prin > 0.0 {
            total_prin
        } else if self.original_notional > 0.0 {
            self.original_notional
        } else {
            1.0
        };

        self.weighted_average_life = wal_numerator / denom;
    }
}
