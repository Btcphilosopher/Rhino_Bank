use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum DefaultScenario {
    Base,
    ModerateStress,
    SevereStress,
    ExtremeStress,
    CustomCDR(f64),
    SDA(f64), // Standard Default Assumption %
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CDRScenario {
    pub name: String,
    pub annualized_cdr: f64,
    pub loss_severity: f64,
    pub recovery_lag_months: u32,
    pub property_price_shock: f64, // e.g. -0.15 for -15%
}

pub struct DefaultModel;

impl DefaultModel {
    /// Convert annual CDR (Conditional Default Rate) to monthly MDR (Monthly Default Rate)
    /// Formula: MDR = 1 - (1 - CDR)^(1/12)
    #[inline]
    pub fn cdr_to_mdr(cdr: f64) -> f64 {
        if cdr <= 0.0 {
            return 0.0;
        }
        if cdr >= 1.0 {
            return 1.0;
        }
        1.0 - (1.0 - cdr).powf(1.0 / 12.0)
    }

    /// Convert monthly MDR to annual CDR
    #[inline]
    pub fn mdr_to_cdr(mdr: f64) -> f64 {
        if mdr <= 0.0 {
            return 0.0;
        }
        if mdr >= 1.0 {
            return 1.0;
        }
        1.0 - (1.0 - mdr).powi(12)
    }

    /// Calculate CDR based on standard SDA curve (Standard Default Assumption)
    /// 100% SDA: ramps up by 0.02% per month for months 1-30 to 0.6% CDR, stays at 0.6% until month 60, then declines by 0.0095% per month to month 120
    pub fn calculate_sda_cdr(sda_percentage: f64, loan_age_months: u32) -> f64 {
        let base_cdr = if loan_age_months <= 30 {
            0.006 * (loan_age_months as f64) / 30.0
        } else if loan_age_months <= 60 {
            0.006
        } else if loan_age_months <= 120 {
            0.006 - 0.000095 * ((loan_age_months - 60) as f64)
        } else {
            0.0003
        };
        (sda_percentage / 100.0) * base_cdr.max(0.0)
    }

    /// Adjust default rate based on macro stress, LTV shift, and FICO
    pub fn adjust_cdr_for_credit(
        base_cdr: f64,
        avg_ltv: f64,
        avg_fico: f64,
        property_value_shock: f64,
    ) -> f64 {
        // Effective LTV after property shock: LTV_new = LTV_old / (1 + shock)
        let effective_ltv = if property_value_shock > -0.9 {
            avg_ltv / (1.0 + property_value_shock)
        } else {
            avg_ltv * 2.0
        };

        let ltv_multiplier = if effective_ltv > 100.0 {
            2.5 + (effective_ltv - 100.0) * 0.05
        } else if effective_ltv > 80.0 {
            1.0 + (effective_ltv - 80.0) * 0.04
        } else {
            (effective_ltv / 80.0).max(0.4)
        };

        let fico_multiplier = if avg_fico < 620.0 {
            2.8
        } else if avg_fico < 680.0 {
            1.6
        } else if avg_fico < 740.0 {
            1.0
        } else {
            0.55
        };

        base_cdr * ltv_multiplier * fico_multiplier
    }
}
