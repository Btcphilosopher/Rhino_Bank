use crate::cashflow::CashFlowSchedule;
use crate::yield_curve::YieldCurve;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MBSValuationResult {
    pub present_value: f64,
    pub clean_price: f64,           // % of par (e.g. 98.50)
    pub dirty_price: f64,           // including accrued interest
    pub accrued_interest: f64,
    pub yield_to_maturity: f64,     // Annualized YTM %
    pub nominal_spread_bps: f64,    // Z-spread / static spread over benchmark curve
    pub weighted_average_life_years: f64,
    pub cash_on_cash_return: f64,
    pub internal_rate_of_return: f64,
}

pub struct ValuationEngine;

impl ValuationEngine {
    /// Calculate Present Value by discounting cash flows along the zero curve + static spread
    pub fn calculate_present_value(
        schedule: &CashFlowSchedule,
        yield_curve: &YieldCurve,
        spread_bps: f64,
    ) -> f64 {
        let mut pv = 0.0;
        for p in &schedule.periods {
            let t = (p.period as f64) / 12.0;
            let df = yield_curve.get_discount_factor(t, spread_bps);
            pv += p.net_cash_flow * df;
        }
        pv
    }

    /// Calculate Yield to Maturity (IRR) numerically via Newton-Raphson / Bisection
    pub fn calculate_ytm(
        schedule: &CashFlowSchedule,
        target_pv: f64,
    ) -> f64 {
        if target_pv <= 0.0 || schedule.periods.is_empty() {
            return 0.0;
        }

        let mut low = 0.0001;
        let mut high = 0.50; // up to 50%
        let mut ytm = 0.05;

        for _ in 0..100 {
            ytm = (low + high) / 2.0;
            let monthly_y = ytm / 12.0;
            let mut pv = 0.0;

            for p in &schedule.periods {
                let df = 1.0 / (1.0 + monthly_y).powi(p.period as i32);
                pv += p.net_cash_flow * df;
            }

            let diff = pv - target_pv;
            if diff.abs() < 1e-4 {
                break;
            }

            if diff > 0.0 {
                // Rate too low -> increase rate
                low = ytm;
            } else {
                // Rate too high -> decrease rate
                high = ytm;
            }
        }

        ytm
    }

    /// Full institutional MBS valuation
    pub fn value_mbs(
        schedule: &CashFlowSchedule,
        yield_curve: &YieldCurve,
        spread_bps: f64,
        initial_balance: f64,
        coupon_rate: f64,
        days_accrued: u32,
    ) -> MBSValuationResult {
        let pv = Self::calculate_present_value(schedule, yield_curve, spread_bps);
        let par_factor = if initial_balance > 0.0 { initial_balance / 100.0 } else { 1.0 };
        let dirty_price = pv / par_factor;

        let accrued = (coupon_rate / 360.0) * (days_accrued as f64) * 100.0;
        let clean_price = dirty_price - accrued;

        let ytm = Self::calculate_ytm(schedule, pv);
        let benchmark_10y = yield_curve.get_zero_rate(10.0);
        let nominal_spread = (ytm - benchmark_10y) * 10000.0;

        let total_return = schedule.total_cash_flow / initial_balance.max(1.0);

        MBSValuationResult {
            present_value: pv,
            clean_price,
            dirty_price,
            accrued_interest: accrued,
            yield_to_maturity: ytm,
            nominal_spread_bps: nominal_spread,
            weighted_average_life_years: schedule.weighted_average_life_years,
            cash_on_cash_return: total_return,
            internal_rate_of_return: ytm,
        }
    }
}
