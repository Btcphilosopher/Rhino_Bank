use crate::mortgage::{Mortgage, LoanType};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PoolStratification {
    pub geography_distribution: HashMap<String, f64>,
    pub loan_type_distribution: HashMap<String, f64>,
    pub fico_brackets: HashMap<String, f64>,
    pub ltv_brackets: HashMap<String, f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MortgagePool {
    pub pool_id: String,
    pub pool_name: String,
    pub loans: Vec<Mortgage>,
    pub total_original_balance: f64,
    pub current_pool_balance: f64,
    pub weighted_average_coupon: f64, // WAC (annual decimal)
    pub weighted_average_net_coupon: f64,
    pub weighted_average_maturity: f64, // WAM in months
    pub weighted_average_loan_age: f64, // WALA in months
    pub weighted_average_original_ltv: f64,
    pub weighted_average_current_ltv: f64,
    pub weighted_average_fico: f64,
    pub total_loan_count: usize,
    pub stratification: PoolStratification,
}

impl MortgagePool {
    pub fn new(pool_id: String, pool_name: String, loans: Vec<Mortgage>) -> Self {
        let mut pool = Self {
            pool_id,
            pool_name,
            total_loan_count: loans.len(),
            loans,
            total_original_balance: 0.0,
            current_pool_balance: 0.0,
            weighted_average_coupon: 0.0,
            weighted_average_net_coupon: 0.0,
            weighted_average_maturity: 0.0,
            weighted_average_loan_age: 0.0,
            weighted_average_original_ltv: 0.0,
            weighted_average_current_ltv: 0.0,
            weighted_average_fico: 0.0,
            stratification: PoolStratification {
                geography_distribution: HashMap::new(),
                loan_type_distribution: HashMap::new(),
                fico_brackets: HashMap::new(),
                ltv_brackets: HashMap::new(),
            },
        };
        pool.recalculate_metrics();
        pool
    }

    pub fn recalculate_metrics(&mut self) {
        if self.loans.is_empty() {
            return;
        }

        let mut total_curr_bal = 0.0;
        let mut total_orig_bal = 0.0;
        let mut weighted_coupon_sum = 0.0;
        let mut weighted_net_coupon_sum = 0.0;
        let mut weighted_wam_sum = 0.0;
        let mut weighted_wala_sum = 0.0;
        let mut weighted_orig_ltv_sum = 0.0;
        let mut weighted_curr_ltv_sum = 0.0;
        let mut weighted_fico_sum = 0.0;

        let mut geo_map: HashMap<String, f64> = HashMap::new();
        let mut type_map: HashMap<String, f64> = HashMap::new();

        for loan in &self.loans {
            let bal = loan.current_balance;
            total_curr_bal += bal;
            total_orig_bal += loan.original_balance;

            weighted_coupon_sum += loan.gross_interest_rate * bal;
            weighted_net_coupon_sum += loan.net_interest_rate * bal;
            weighted_wam_sum += (loan.remaining_term_months as f64) * bal;
            weighted_wala_sum += (loan.age_months as f64) * bal;
            weighted_orig_ltv_sum += loan.original_ltv * bal;
            weighted_curr_ltv_sum += loan.current_ltv * bal;
            weighted_fico_sum += (loan.borrower.fico_score as f64) * bal;

            *geo_map.entry(loan.geography_state.clone()).or_insert(0.0) += bal;
            let type_str = format!("{:?}", loan.loan_type);
            *type_map.entry(type_str).or_insert(0.0) += bal;
        }

        self.current_pool_balance = total_curr_bal;
        self.total_original_balance = total_orig_bal;
        self.total_loan_count = self.loans.len();

        if total_curr_bal > 0.0 {
            self.weighted_average_coupon = weighted_coupon_sum / total_curr_bal;
            self.weighted_average_net_coupon = weighted_net_coupon_sum / total_curr_bal;
            self.weighted_average_maturity = weighted_wam_sum / total_curr_bal;
            self.weighted_average_loan_age = weighted_wala_sum / total_curr_bal;
            self.weighted_average_original_ltv = weighted_orig_ltv_sum / total_curr_bal;
            self.weighted_average_current_ltv = weighted_curr_ltv_sum / total_curr_bal;
            self.weighted_average_fico = weighted_fico_sum / total_curr_bal;

            for (_, v) in geo_map.iter_mut() {
                *v = (*v / total_curr_bal) * 100.0;
            }
            for (_, v) in type_map.iter_mut() {
                *v = (*v / total_curr_bal) * 100.0;
            }
            self.stratification.geography_distribution = geo_map;
            self.stratification.loan_type_distribution = type_map;
        }
    }
}
