use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CashFlowPeriod {
    pub period: u32,
    pub month_date: String,
    pub beginning_balance: f64,
    pub scheduled_principal: f64,
    pub prepayment_principal: f64,
    pub defaulted_principal: f64,
    pub total_principal: f64,
    pub gross_interest: f64,
    pub servicing_fee: f64,
    pub guarantee_fee: f64,
    pub net_interest: f64,
    pub recovery_cash: f64,
    pub realized_loss: f64,
    pub net_cash_flow: f64,
    pub ending_balance: f64,
    pub cpr_applied: f64,
    pub smm_applied: f64,
    pub cdr_applied: f64,
    pub mdr_applied: f64,
    pub discount_factor: f64,
    pub present_value: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CashFlowSchedule {
    pub periods: Vec<CashFlowPeriod>,
    pub total_scheduled_principal: f64,
    pub total_prepayments: f64,
    pub total_defaults: f64,
    pub total_recoveries: f64,
    pub total_realized_losses: f64,
    pub total_gross_interest: f64,
    pub total_net_interest: f64,
    pub total_servicing_fees: f64,
    pub total_guarantee_fees: f64,
    pub total_cash_flow: f64,
    pub weighted_average_life_years: f64,
}

impl CashFlowSchedule {
    pub fn new() -> Self {
        Self {
            periods: Vec::new(),
            total_scheduled_principal: 0.0,
            total_prepayments: 0.0,
            total_defaults: 0.0,
            total_recoveries: 0.0,
            total_realized_losses: 0.0,
            total_gross_interest: 0.0,
            total_net_interest: 0.0,
            total_servicing_fees: 0.0,
            total_guarantee_fees: 0.0,
            total_cash_flow: 0.0,
            weighted_average_life_years: 0.0,
        }
    }

    /// Reconcile and calculate cumulative metrics & WAL
    pub fn finalize(&mut self, initial_balance: f64) {
        let mut sum_sched_prin = 0.0;
        let mut sum_prepay = 0.0;
        let mut sum_default = 0.0;
        let mut sum_recovery = 0.0;
        let mut sum_loss = 0.0;
        let mut sum_gross_int = 0.0;
        let mut sum_net_int = 0.0;
        let mut sum_servicing = 0.0;
        let mut sum_gfee = 0.0;
        let mut sum_cf = 0.0;
        let mut wal_numerator = 0.0;
        let mut total_prin_returned = 0.0;

        for p in &self.periods {
            sum_sched_prin += p.scheduled_principal;
            sum_prepay += p.prepayment_principal;
            sum_default += p.defaulted_principal;
            sum_recovery += p.recovery_cash;
            sum_loss += p.realized_loss;
            sum_gross_int += p.gross_interest;
            sum_net_int += p.net_interest;
            sum_servicing += p.servicing_fee;
            sum_gfee += p.guarantee_fee;
            sum_cf += p.net_cash_flow;

            let principal_cash = p.scheduled_principal + p.prepayment_principal + p.recovery_cash;
            total_prin_returned += principal_cash;
            let time_in_years = (p.period as f64) / 12.0;
            wal_numerator += time_in_years * principal_cash;
        }

        self.total_scheduled_principal = sum_sched_prin;
        self.total_prepayments = sum_prepay;
        self.total_defaults = sum_default;
        self.total_recoveries = sum_recovery;
        self.total_realized_losses = sum_loss;
        self.total_gross_interest = sum_gross_int;
        self.total_net_interest = sum_net_int;
        self.total_servicing_fees = sum_servicing;
        self.total_guarantee_fees = sum_gfee;
        self.total_cash_flow = sum_cf;

        let wal_denom = if total_prin_returned > 0.0 {
            total_prin_returned
        } else if initial_balance > 0.0 {
            initial_balance
        } else {
            1.0
        };

        self.weighted_average_life_years = wal_numerator / wal_denom;
    }
}
