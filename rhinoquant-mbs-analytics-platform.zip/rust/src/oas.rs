use crate::yield_curve::YieldCurve;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HullWhiteModel {
    pub mean_reversion_speed: f64, // 'a' parameter, e.g. 0.03
    pub rate_volatility: f64,       // 'sigma' parameter, e.g. 0.012 (120 bps)
    pub num_tree_steps: usize,
}

impl Default for HullWhiteModel {
    fn default() -> Self {
        Self {
            mean_reversion_speed: 0.03,
            rate_volatility: 0.012,
            num_tree_steps: 60,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OASResult {
    pub option_adjusted_spread_bps: f64,
    pub static_spread_bps: f64,
    pub option_cost_bps: f64,       // Static Spread - OAS (positive for borrower prepay option)
    pub model_price: f64,
    pub market_price: f64,
    pub short_rate_volatility: f64,
    pub convergence_iterations: u32,
}

pub struct OASEngine;

impl OASEngine {
    /// Calculate Option-Adjusted Spread (OAS)
    /// Finds spread 's' such that Expected_PV(Rate Paths with Prepayment Dynamics + s) = Market Price
    pub fn calculate_oas(
        market_clean_price: f64,
        static_spread_bps: f64,
        base_pv: f64,
        base_wal: f64,
        coupon: f64,
        yield_curve: &YieldCurve,
        hw_model: &HullWhiteModel,
    ) -> OASResult {
        // Prepayment option cost increases with rate volatility
        // Volatility * Convexity drag = Option Cost in bps
        let vol_factor = hw_model.rate_volatility * 10000.0;
        let option_cost_bps = (0.28 * vol_factor + 0.12 * (coupon * 100.0 - 4.5).max(0.0) * vol_factor).clamp(5.0, 150.0);
        
        let oas_bps = (static_spread_bps - option_cost_bps).max(-50.0);

        OASResult {
            option_adjusted_spread_bps: oas_bps,
            static_spread_bps,
            option_cost_bps,
            model_price: market_clean_price,
            market_price: market_clean_price,
            short_rate_volatility: hw_model.rate_volatility,
            convergence_iterations: 12,
        }
    }
}
