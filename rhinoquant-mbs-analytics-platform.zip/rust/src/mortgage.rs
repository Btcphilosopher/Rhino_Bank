use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum AmortisationType {
    FixedRate,
    VariableRate,
    AdjustableRate,
    InterestOnly,
    Custom,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum LoanType {
    AgencyConforming,
    AgencyJumbo,
    NonAgencyPrime,
    NonAgencyAltA,
    Subprime,
    CommercialMultiFamily,
    CommercialRetailOffice,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum OccupancyType {
    PrimaryResidence,
    SecondHome,
    Investor,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BorrowerCredit {
    pub fico_score: u16,
    pub dti_ratio: f64,
    pub doc_type: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Mortgage {
    pub loan_id: String,
    pub original_balance: f64,
    pub current_balance: f64,
    pub gross_interest_rate: f64, // Annual decimal, e.g. 0.0575
    pub net_interest_rate: f64,   // After servicing & guarantee fee
    pub servicing_fee_rate: f64,  // e.g. 0.0025 (25 bps)
    pub guarantee_fee_rate: f64,  // e.g. 0.0050 (50 bps)
    pub original_term_months: u32,
    pub remaining_term_months: u32,
    pub age_months: u32,
    pub origination_date: String,
    pub maturity_date: String,
    pub payment_frequency: u32, // 12 for monthly
    pub amortisation_type: AmortisationType,
    pub property_value: f64,
    pub original_ltv: f64,
    pub current_ltv: f64,
    pub borrower: BorrowerCredit,
    pub geography_state: String,
    pub occupancy: OccupancyType,
    pub loan_type: LoanType,
}

impl Mortgage {
    /// Calculate monthly scheduled level payment for a standard fixed-rate amortising mortgage
    pub fn calculate_monthly_payment(&self) -> f64 {
        if self.current_balance <= 0.0 || self.remaining_term_months == 0 {
            return 0.0;
        }

        let monthly_rate = self.gross_interest_rate / 12.0;

        match self.amortisation_type {
            AmortisationType::InterestOnly => self.current_balance * monthly_rate,
            AmortisationType::FixedRate | AmortisationType::AgencyConforming | _ => {
                if monthly_rate.abs() < 1e-9 {
                    self.current_balance / (self.remaining_term_months as f64)
                } else {
                    let n = self.remaining_term_months as f64;
                    let factor = (1.0 + monthly_rate).powf(n);
                    self.current_balance * (monthly_rate * factor) / (factor - 1.0)
                }
            }
        }
    }

    /// Single period standard amortisation calculation
    pub fn amortise_period(&mut self, monthly_payment: f64) -> (f64, f64) {
        if self.current_balance <= 0.0 {
            return (0.0, 0.0);
        }

        let monthly_rate = self.gross_interest_rate / 12.0;
        let interest_due = self.current_balance * monthly_rate;
        let mut principal_due = monthly_payment - interest_due;

        if principal_due < 0.0 {
            principal_due = 0.0;
        }

        if principal_due > self.current_balance {
            principal_due = self.current_balance;
        }

        self.current_balance -= principal_due;
        if self.remaining_term_months > 0 {
            self.remaining_term_months -= 1;
            self.age_months += 1;
        }

        (interest_due, principal_due)
    }

    /// Recalculate LTV after balance amortization and property value change
    pub fn update_ltv(&mut self, property_appreciation: f64) {
        self.property_value *= 1.0 + property_appreciation;
        if self.property_value > 0.0 {
            self.current_ltv = (self.current_balance / self.property_value) * 100.0;
        }
    }
}
