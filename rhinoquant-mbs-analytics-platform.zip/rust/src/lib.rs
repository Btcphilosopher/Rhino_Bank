//! # RhinoQuant MBS Core Quantitative Engine
//!
//! Institutional high-performance Mortgage-Backed Securities (MBS) valuation,
//! cash-flow simulation, OAS, risk decomposition, structured credit waterfall,
//! and Monte Carlo pricing library.

pub mod mortgage;
pub mod pool;
pub mod cashflow;
pub mod prepayment;
pub mod default;
pub mod recovery;
pub mod yield_curve;
pub mod tranche;
pub mod waterfall;
pub mod valuation;
pub mod oas;
pub mod duration;
pub mod convexity;
pub mod risk;
pub mod monte_carlo;
pub mod portfolio;

pub use mortgage::{Mortgage, AmortisationType, LoanType, OccupancyType};
pub use pool::{MortgagePool, PoolStratification};
pub use cashflow::{CashFlowPeriod, CashFlowSchedule};
pub use prepayment::{PrepaymentModel, PrepaymentParams, RichardRollPrepayment};
pub use default::{DefaultModel, DefaultScenario, CDRScenario};
pub use recovery::{RecoveryModel, RecoveryParams};
pub use yield_curve::{YieldCurve, InterpolationMethod};
pub use tranche::{Tranche, SeniorityLevel, PaymentRule, LossRule};
pub use waterfall::{WaterfallEngine, WaterfallStructure};
pub use valuation::{ValuationEngine, MBSValuationResult};
pub use oas::{OASEngine, HullWhiteModel, OASResult};
pub use duration::{DurationCalculator, DurationMetrics};
pub use convexity::{ConvexityCalculator, ConvexityMetrics};
pub use risk::{RiskEngine, RiskDecomposition, DV01Profile};
pub use monte_carlo::{MonteCarloEngine, MonteCarloSimulationResult};
pub use portfolio::{MBSPortfolio, PortfolioPosition, PortfolioAnalytics};

/// RhinoQuant Core Engine Version & Auditing Metadata
pub const ENGINE_VERSION: &str = "2.4.0-institutional";
pub const ENGINE_RELEASE_DATE: &str = "2026-08-20";
