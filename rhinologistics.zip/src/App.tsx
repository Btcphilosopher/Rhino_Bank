import { useState, useMemo } from "react";
import { NetworkNode, NetworkConnection, OptimisationResult, ForecastPoint, FpiComponents, SimulationScenario } from "./types";
import { UK_NODES, UK_CONNECTIONS, INITIAL_FLEET, SIMULATION_SCENARIOS } from "./data/ukNetwork";
import { findOptimalRoute, findKShortestPaths } from "./utils/optimizers";
import { generateDemandForecast, calculateFpi, calculateCostAnalytics } from "./utils/forecasters";

// Component imports
import GisMap from "./components/GisMap";
import WarehouseVisualizer from "./components/WarehouseVisualizer";
import AiAdvisor from "./components/AiAdvisor";
import SystemSpecs from "./components/SystemSpecs";
import ReportView from "./components/ReportView";

import {
  Activity,
  MapPin,
  TrendingUp,
  Sliders,
  DollarSign,
  AlertOctagon,
  Bot,
  Terminal,
  FileSpreadsheet,
  Grid,
  Leaf,
  Layers,
  ChevronRight,
  Shield,
  Clock,
  Compass,
  ArrowUpRight,
  AlertTriangle,
  Lightbulb
} from "lucide-react";

export default function App() {
  // Navigation State
  const [activeTab, setActiveTab] = useState<
    "overview" | "network" | "fleet" | "warehouse" | "cost" | "advisor" | "reports" | "tech"
  >("overview");

  // Global State
  const [nodes, setNodes] = useState<NetworkNode[]>(UK_NODES);
  const [connections, setConnections] = useState<NetworkConnection[]>(UK_CONNECTIONS);
  const [fleet, setFleet] = useState(INITIAL_FLEET);
  const [scenarios, setScenarios] = useState<SimulationScenario[]>(SIMULATION_SCENARIOS);
  
  // Route selection state
  const [selectedOrigin, setSelectedOrigin] = useState<string | null>("port_grimsby_immingham");
  const [selectedDestination, setSelectedDestination] = useState<string | null>("leeds_dc");
  const [activeRouteIndex, setActiveRouteIndex] = useState<number>(0);
  const [routeModePreference, setRouteModePreference] = useState<"all" | "road" | "rail" | "sea">("all");
  const [routeOptimiseFor, setRouteOptimiseFor] = useState<"distance" | "time" | "fuel" | "toll" | "carbon">("time");

  // Forecasting model select
  const [forecasterModel, setForecasterModel] = useState<"arima" | "ets" | "xgboost">("arima");

  // FPI sliders weight adjustments
  const [fpiWeights, setFpiWeights] = useState<Record<keyof FpiComponents, number>>({
    reliability: 25,
    utilisation: 20,
    transitTime: 15,
    carbonIntensity: 15,
    costEfficiency: 15,
    railUtilisation: 10
  });

  // Toggle active simulation scenario
  const toggleScenario = (id: string) => {
    setScenarios((prev) =>
      prev.map((scen) => (scen.id === id ? { ...scen, active: !scen.active } : scen))
    );
    // Reset route index if active scenario toggles to refresh path calculation safely
    setActiveRouteIndex(0);
  };

  // 1. SOLVE ROUTING MATRICES VIA RUST PATHFINDERS
  const routingSolutions = useMemo(() => {
    if (!selectedOrigin || !selectedDestination) return [];
    return findKShortestPaths(
      selectedOrigin,
      selectedDestination,
      routeModePreference,
      routeOptimiseFor,
      scenarios,
      3
    );
  }, [selectedOrigin, selectedDestination, routeModePreference, routeOptimiseFor, scenarios]);

  const activeRoute = useMemo(() => {
    if (routingSolutions.length === 0) return null;
    return routingSolutions[activeRouteIndex] || routingSolutions[0];
  }, [routingSolutions, activeRouteIndex]);

  // 2. RUN FORECAST CENTRE VIA R ALGORITHMS
  const forecastData = useMemo(() => {
    return generateDemandForecast(forecasterModel, scenarios);
  }, [forecasterModel, scenarios]);

  // 3. COMPUTE SYSTEM COMPOSITE FPI GAUGE VIA R
  const fpiResults = useMemo(() => {
    return calculateFpi(fpiWeights, scenarios);
  }, [fpiWeights, scenarios]);

  // 4. RUN ECONOMIC COSTING MATRIX VIA R
  const systemTonnageMoved = 450000; // aggregate historical tonnage baseline
  const systemKmTraveled = 3200000; // aggregate historical km baseline
  
  const costResults = useMemo(() => {
    let mode: "all" | "road" | "rail" | "sea" = "all";
    if (activeRoute && activeRoute.connections.length > 0) {
      const modes = activeRoute.connections.map((c) => c.mode);
      const uniqueModes = Array.from(new Set(modes));
      if (uniqueModes.length === 1) {
        mode = uniqueModes[0] as any;
      }
    }
    return calculateCostAnalytics(systemTonnageMoved, systemKmTraveled, mode);
  }, [activeRoute]);

  // Handle GIS map selecting a node
  const handleSelectNodeFromMap = (node: NetworkNode) => {
    if (!selectedOrigin) {
      setSelectedOrigin(node.id);
    } else if (!selectedDestination && node.id !== selectedOrigin) {
      setSelectedDestination(node.id);
    } else if (selectedOrigin && selectedDestination) {
      // Rotate
      setSelectedOrigin(node.id);
      setSelectedDestination(null);
    }
    setActiveRouteIndex(0);
  };

  return (
    <div className="min-h-screen bg-graphite text-stone flex flex-col font-inter select-none antialiased">
      {/* Top Navigation Ribbon bar in Editorial Aesthetic */}
      <header className="border-b border-steel bg-graphite/40 px-6 py-5 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        {/* Brand identity */}
        <div className="flex flex-col md:flex-row items-start md:items-center gap-4 md:gap-6">
          <div>
            <span className="text-[10px] tracking-[0.2em] font-mono text-copper font-bold uppercase block mb-1">
              Rhino Bank Freight Intelligence
            </span>
            <h1 className="text-4xl md:text-5xl font-anton text-white tracking-wide uppercase leading-none">
              Rhino Logistics
            </h1>
          </div>
          <div className="flex flex-wrap gap-2 md:mt-2">
            <span className="status-tag">Rust Engine: Optimal</span>
            <span className="status-tag">R-Analytic: Active</span>
            <span className="status-tag">Core: Hybrid-V4</span>
          </div>
        </div>

        {/* Real-time system gauges */}
        <div className="flex flex-wrap gap-4 md:gap-6 font-mono text-xs items-center">
          <div className="text-left lg:text-right border-l lg:border-l-0 lg:border-r border-steel/40 pl-3 lg:pl-0 lg:pr-4">
            <span className="text-[9px] text-steel uppercase block tracking-wider">Composite UK FPI</span>
            <span
              className={`font-bold font-mono text-sm ${
                fpiResults.compositeIndex > 80
                  ? "text-emerald-400"
                  : fpiResults.compositeIndex > 60
                  ? "text-copper"
                  : "text-red-400"
              }`}
            >
              {fpiResults.compositeIndex} / 100
            </span>
          </div>

          <div className="text-left lg:text-right border-l lg:border-l-0 lg:border-r border-steel/40 pl-3 lg:pl-0 lg:pr-4">
            <span className="text-[9px] text-steel uppercase block tracking-wider">Cost Per Tonne-km</span>
            <span className="font-bold text-white text-sm">£{costResults.costPerKm.toFixed(2)}</span>
          </div>

          <div className="text-left lg:text-right border-l lg:border-l-0 pl-3">
            <span className="text-[9px] text-steel uppercase block tracking-wider">Electrified Rail</span>
            <span className="font-bold text-emerald-500 text-sm">82%</span>
          </div>
        </div>
      </header>

      {/* Main split-screen workstation */}
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Sidebar workstation navigation */}
        <aside className="w-full md:w-64 border-r border-steel bg-graphite p-5 shrink-0 flex flex-col justify-between font-mono text-xs">
          <div className="space-y-6">
            <div>
              <span className="text-[10px] text-steel uppercase tracking-widest block mb-3 font-bold">
                OPERATIONAL DESKS
              </span>
              <nav className="space-y-1">
                <button
                  onClick={() => setActiveTab("overview")}
                  className={`w-full text-left px-3 py-2.5 rounded-none flex items-center gap-2.5 transition-colors cursor-pointer border-l-2 ${
                    activeTab === "overview"
                      ? "bg-white/5 text-copper font-bold border-copper"
                      : "text-stone/60 border-transparent hover:text-stone hover:bg-white/2"
                  }`}
                >
                  <Grid className="w-4 h-4 shrink-0" />
                  Executive Overview
                </button>

                <button
                  onClick={() => setActiveTab("network")}
                  className={`w-full text-left px-3 py-2.5 rounded-none flex items-center gap-2.5 transition-colors cursor-pointer border-l-2 ${
                    activeTab === "network"
                      ? "bg-white/5 text-copper font-bold border-copper"
                      : "text-stone/60 border-transparent hover:text-stone hover:bg-white/2"
                  }`}
                >
                  <Layers className="w-4 h-4 shrink-0" />
                  GIS Network Corridors
                </button>

                <button
                  onClick={() => setActiveTab("fleet")}
                  className={`w-full text-left px-3 py-2.5 rounded-none flex items-center gap-2.5 transition-colors cursor-pointer border-l-2 ${
                    activeTab === "fleet"
                      ? "bg-white/5 text-copper font-bold border-copper"
                      : "text-stone/60 border-transparent hover:text-stone hover:bg-white/2"
                  }`}
                >
                  <Activity className="w-4 h-4 shrink-0" />
                  Fleet Scheduling
                </button>

                <button
                  onClick={() => setActiveTab("warehouse")}
                  className={`w-full text-left px-3 py-2.5 rounded-none flex items-center gap-2.5 transition-colors cursor-pointer border-l-2 ${
                    activeTab === "warehouse"
                      ? "bg-white/5 text-copper font-bold border-copper"
                      : "text-stone/60 border-transparent hover:text-stone hover:bg-white/2"
                  }`}
                >
                  <Compass className="w-4 h-4 shrink-0" />
                  Warehouse picker
                </button>
              </nav>
            </div>

            <div>
              <span className="text-[10px] text-steel uppercase tracking-widest block mb-3 font-bold">
                QUANTITATIVE & AI
              </span>
              <nav className="space-y-1">
                <button
                  onClick={() => setActiveTab("cost")}
                  className={`w-full text-left px-3 py-2.5 rounded-none flex items-center gap-2.5 transition-colors cursor-pointer border-l-2 ${
                    activeTab === "cost"
                      ? "bg-white/5 text-copper font-bold border-copper"
                      : "text-stone/60 border-transparent hover:text-stone hover:bg-white/2"
                  }`}
                >
                  <TrendingUp className="w-4 h-4 shrink-0" />
                  Demand Forecast (R)
                </button>

                <button
                  onClick={() => setActiveTab("advisor")}
                  className={`w-full text-left px-3 py-2.5 rounded-none flex items-center gap-2.5 transition-colors cursor-pointer border-l-2 ${
                    activeTab === "advisor"
                      ? "bg-white/5 text-copper font-bold border-copper"
                      : "text-stone/60 border-transparent hover:text-stone hover:bg-white/2"
                  }`}
                >
                  <Bot className="w-4 h-4 shrink-0" />
                  AI Economics Advisor
                </button>

                <button
                  onClick={() => setActiveTab("reports")}
                  className={`w-full text-left px-3 py-2.5 rounded-none flex items-center gap-2.5 transition-colors cursor-pointer border-l-2 ${
                    activeTab === "reports"
                      ? "bg-white/5 text-copper font-bold border-copper"
                      : "text-stone/60 border-transparent hover:text-stone hover:bg-white/2"
                  }`}
                >
                  <FileSpreadsheet className="w-4 h-4 shrink-0" />
                  Boardroom Reports
                </button>

                <button
                  onClick={() => setActiveTab("tech")}
                  className={`w-full text-left px-3 py-2.5 rounded-none flex items-center gap-2.5 transition-colors cursor-pointer border-l-2 ${
                    activeTab === "tech"
                      ? "bg-white/5 text-copper font-bold border-copper"
                      : "text-stone/60 border-transparent hover:text-stone hover:bg-white/2"
                  }`}
                >
                  <Terminal className="w-4 h-4 shrink-0" />
                  Architectural Specs
                </button>
              </nav>
            </div>
          </div>

          {/* Footer details */}
          <div className="pt-4 border-t border-steel/40 space-y-1 font-mono text-[10px] text-steel">
            <div>Rhino Logistics Engine v4.8</div>
            <div>Secure Transport Advisory</div>
            <div>© 2026 Rhino Bank PLC</div>
          </div>
        </aside>

        {/* Dashboard workspace viewport */}
        <main className="flex-1 p-6 overflow-y-auto max-w-7xl mx-auto w-full space-y-6">
          {/* OVERVIEW SUB-VIEW */}
          {activeTab === "overview" && (
            <div id="overview_workspace" className="space-y-6">
              {/* Macro stats blocks */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white/3 border border-steel p-4 font-mono border-l-3 border-l-copper">
                  <span className="text-[10px] text-steel uppercase flex items-center gap-1 font-bold">
                    <Activity className="w-3.5 h-3.5 text-copper" />
                    Freight Performance FPI
                  </span>
                  <div className="text-2xl font-anton text-white mt-1">{fpiResults.compositeIndex}</div>
                  <div className="text-[9px] text-emerald-400 mt-1 font-sans">
                    Optimal range. Weights allocated.
                  </div>
                </div>

                <div className="bg-white/3 border border-steel p-4 font-mono border-l-3 border-l-copper">
                  <span className="text-[10px] text-steel uppercase flex items-center gap-1 font-bold">
                    <Leaf className="w-3.5 h-3.5 text-emerald-500" />
                    Carbon Intensity
                  </span>
                  <div className="text-2xl font-anton text-emerald-400 mt-1">
                    {costResults.carbonEmissionsTonnes.toLocaleString()} t
                  </div>
                  <div className="text-[9px] text-steel mt-1 font-sans">
                    Total aggregated network CO₂ output.
                  </div>
                </div>

                <div className="bg-white/3 border border-steel p-4 font-mono border-l-3 border-l-copper">
                  <span className="text-[10px] text-steel uppercase flex items-center gap-1 font-bold">
                    <DollarSign className="w-3.5 h-3.5 text-copper" />
                    Network OPEX
                  </span>
                  <div className="text-2xl font-anton text-white mt-1">
                    £{(costResults.totalCost / 1000).toFixed(1)}k
                  </div>
                  <div className="text-[9px] text-steel mt-1 font-sans">
                    Allocated fuel, labour, and tolls.
                  </div>
                </div>

                <div className="bg-white/3 border border-steel p-4 font-mono border-l-3 border-l-copper">
                  <span className="text-[10px] text-steel uppercase flex items-center gap-1 font-bold">
                    <Layers className="w-3.5 h-3.5 text-copper" />
                    Active Fleet Count
                  </span>
                  <div className="text-2xl font-anton text-white mt-1">
                    {fleet.filter((f) => f.status === "transit").length} / {fleet.length}
                  </div>
                  <div className="text-[9px] text-steel mt-1 font-sans">
                    Active transit vs idle/charging.
                  </div>
                </div>
              </div>

              {/* Stress testing incidents panel */}
              <div className="bg-white/3 border border-steel p-5">
                <div className="border-b border-steel pb-3 mb-4">
                  <h3 className="text-sm font-semibold text-white font-mono uppercase tracking-wider flex items-center gap-1.5">
                    <AlertOctagon className="w-4 h-4 text-copper" />
                    MACRO INCIDENTS & STRESS TESTING STUDIO
                  </h3>
                  <p className="text-[11px] text-stone mt-1 font-sans leading-relaxed">
                    Toggle active infrastructural disruptions below. The platform's pathfinding and forecasting models will dynamically recalculate routing costs, delays, and carbon weights across the entire UK network graph in real-time.
                  </p>
                </div>

                {/* Scenario Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-3 font-mono">
                  {scenarios.map((scen) => (
                    <div
                      key={scen.id}
                      onClick={() => toggleScenario(scen.id)}
                      className={`p-3.5 border transition-all cursor-pointer flex flex-col justify-between ${
                        scen.active
                          ? "bg-red-950/20 border-red-500/80 shadow-md shadow-red-950/25"
                          : scen.type === "infra_investment"
                          ? "bg-graphite border-steel hover:border-emerald-500/40 text-stone"
                          : "bg-graphite border-steel hover:border-copper/40 text-stone"
                      }`}
                    >
                      <div className="space-y-1.5">
                        <div className="flex justify-between items-start text-[10px] font-bold">
                          <span className={scen.active ? "text-red-400" : "text-steel"}>
                            {scen.type.replace("_", " ").toUpperCase()}
                          </span>
                          <span
                            className={`w-1.5 h-1.5 rounded-full ${scen.active ? "bg-red-500 animate-pulse" : "bg-steel"}`}
                          ></span>
                        </div>
                        <h4 className="text-[11px] font-bold text-white">{scen.name}</h4>
                        <p className="text-[9px] font-sans text-stone/70 leading-normal line-clamp-3">
                          {scen.description}
                        </p>
                      </div>

                      <div className="mt-3 pt-2 border-t border-steel/40 flex justify-between items-center text-[9px] text-steel">
                        <span>Cost Weight:</span>
                        <span className={scen.active ? "text-red-400 font-bold" : ""}>
                          {scen.costMultiplier > 1 ? `+${Math.round((scen.costMultiplier - 1) * 100)}%` : `-${Math.round((1 - scen.costMultiplier) * 100)}%`}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Multimodal Quick Dispatch and KPI Breakdown */}
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
                {/* KPI weights console */}
                <div className="xl:col-span-4 bg-white/3 border border-steel p-5 flex flex-col justify-between">
                  <div>
                    <div className="border-b border-steel pb-3 mb-4">
                      <h3 className="text-sm font-semibold text-white font-mono uppercase tracking-wider flex items-center gap-1.5">
                        <Sliders className="w-4 h-4 text-copper" />
                        FPI COMPOSITE WEIGHTS
                      </h3>
                      <p className="text-[11px] text-stone mt-0.5 font-sans">
                        Adjust component coefficients below to model bespoke executive priority frameworks.
                      </p>
                    </div>

                    <div className="space-y-3 font-mono text-[10px]">
                      {Object.keys(fpiWeights).map((key) => {
                        const score = fpiResults.components[key as keyof FpiComponents];
                        return (
                          <div key={key} className="space-y-1">
                            <div className="flex justify-between items-center text-stone/70">
                              <span className="capitalize">{key.replace("Utilisation", " Utilisation").replace("transitTime", "transit Time")}</span>
                              <span className="font-bold text-white">
                                weight: {fpiWeights[key as keyof FpiComponents]}% | score: {score}%
                              </span>
                            </div>
                            <input
                              type="range"
                              min="0"
                              max="50"
                              value={fpiWeights[key as keyof FpiComponents]}
                              onChange={(e) => {
                                setFpiWeights((prev) => ({
                                  ...prev,
                                  [key]: Number(e.target.value)
                                }));
                              }}
                              className="w-full accent-copper cursor-pointer"
                            />
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="bg-graphite p-3 border border-steel/60 font-mono text-[11px] text-stone mt-4">
                    <span className="text-[9px] uppercase font-bold text-steel block mb-1">
                      FPI Weighted Breakdown
                    </span>
                    The composite index evaluates system efficiency on regional networks. Active FPI is calculated dynamically via simulated R econometric scripts.
                  </div>
                </div>

                {/* Micro path optimizer overview */}
                <div className="xl:col-span-8 bg-white/3 border border-steel p-5 flex flex-col justify-between">
                  <div>
                    <div className="border-b border-steel pb-3 mb-4 flex justify-between items-start">
                      <div>
                        <h3 className="text-sm font-semibold text-white font-mono uppercase tracking-wider">
                          Dijkstra Optimised Dispatch Sandbox
                        </h3>
                        <p className="text-[11px] text-stone mt-0.5 font-sans">
                          Configure quick-route parameters. View full network calculations in the Network tab.
                        </p>
                      </div>

                      <button
                        onClick={() => setActiveTab("network")}
                        className="text-[10px] text-copper hover:text-copper/80 font-mono font-bold uppercase flex items-center gap-1 cursor-pointer"
                      >
                        Launch GIS
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-4 font-mono text-[11px] mb-4">
                      {/* Mode Preference */}
                      <div className="space-y-1">
                        <label className="text-[10px] text-steel uppercase">Transport Mode</label>
                        <select
                          value={routeModePreference}
                          onChange={(e: any) => setRouteModePreference(e.target.value)}
                          className="w-full bg-graphite border border-steel text-stone px-2 py-1.5 rounded-none cursor-pointer"
                        >
                          <option value="all">Multimodal (Intermodal)</option>
                          <option value="road">Road Haulage (HGVs)</option>
                          <option value="rail">Rail Freight (Trains)</option>
                          <option value="sea">Maritime Coastal</option>
                        </select>
                      </div>

                      {/* Optimise for */}
                      <div className="space-y-1">
                        <label className="text-[10px] text-steel uppercase">Optimise For</label>
                        <select
                          value={routeOptimiseFor}
                          onChange={(e: any) => setRouteOptimiseFor(e.target.value)}
                          className="w-full bg-graphite border border-steel text-stone px-2 py-1.5 rounded-none cursor-pointer"
                        >
                          <option value="distance">Shortest Distance (Km)</option>
                          <option value="time">Lowest Latency Time (Hrs)</option>
                          <option value="fuel">Minimum Fuel Consumption (L)</option>
                          <option value="toll">Lowest Operational Tolls (£)</option>
                          <option value="carbon">Zero Carbon Pathways (CO₂)</option>
                        </select>
                      </div>
                    </div>

                    {/* Quick solve output */}
                    {activeRoute ? (
                      <div className="bg-graphite border border-steel p-4 font-mono text-[11px] space-y-3">
                        <div className="flex justify-between items-center border-b border-steel/40 pb-2">
                          <span className="font-bold text-white uppercase">
                            Route: {nodes.find((n) => n.id === selectedOrigin)?.name.replace("Port of ", "")} to {nodes.find((n) => n.id === selectedDestination)?.name.replace(" Distribution Centre", "")}
                          </span>
                          <span className="bg-copper/10 text-copper border border-copper/30 px-1.5 py-0.5 rounded-none font-bold uppercase text-[9px]">
                            Dijkstra Solved
                          </span>
                        </div>

                        <div className="grid grid-cols-4 gap-2 text-center text-stone">
                          <div>
                            <div className="text-[9px] text-steel uppercase">Distance</div>
                            <div className="font-bold mt-0.5 text-white">{activeRoute.totalDistanceKm} km</div>
                          </div>
                          <div>
                            <div className="text-[9px] text-steel uppercase">Duration</div>
                            <div className="font-bold mt-0.5 text-white">{activeRoute.totalTimeHrs.toFixed(1)} hrs</div>
                          </div>
                          <div>
                            <div className="text-[9px] text-steel uppercase">Fuel Burn</div>
                            <div className="font-bold mt-0.5 text-white">{Math.round(activeRoute.totalFuelLiters)} L</div>
                          </div>
                          <div>
                            <div className="text-[9px] text-steel uppercase">Carbon CO₂</div>
                            <div className="font-bold text-emerald-400 mt-0.5">{activeRoute.totalCarbonKg.toFixed(1)} kg</div>
                          </div>
                        </div>

                        {/* Warnings block in overview */}
                        {activeRoute.bottlenecksPassed.length > 0 && (
                          <div className="p-2 bg-yellow-950/10 border border-yellow-900/30 rounded-none text-[10px] text-yellow-300 font-sans flex items-center gap-1.5">
                            <AlertTriangle className="w-4 h-4 shrink-0 text-yellow-500" />
                            <span>Bottleneck: Route traverses high-congestion nodes. Consider intermodal rail swap.</span>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center text-steel italic py-6 border border-dashed border-steel rounded-none">
                        No active dispatch origin/destination. Select nodes in GIS network to calculate paths.
                      </div>
                    )}
                  </div>

                  <div className="pt-4 border-t border-steel/40 flex flex-col sm:flex-row gap-2">
                    <button
                      onClick={() => {
                        setSelectedOrigin("port_grimsby_immingham");
                        setSelectedDestination("leeds_dc");
                        alert("Dispatched Leeds-Grimsby intermodal corridor paths to solver. Check Network tab!");
                      }}
                      className="flex-1 bg-white/5 hover:bg-white/10 border border-steel text-copper font-bold py-2.5 rounded-none transition-colors cursor-pointer font-sans text-xs"
                    >
                      LOAD YORKSHIRE BIOMASS CORRIDOR
                    </button>
                    <button
                      onClick={() => {
                        setSelectedOrigin("port_felixstowe");
                        setSelectedDestination("birmingham_dc");
                        alert("Dispatched Felixstowe deepwater rail lanes to solver.");
                      }}
                      className="flex-1 bg-white/5 hover:bg-white/10 border border-steel text-stone font-bold py-2.5 rounded-none transition-colors cursor-pointer font-sans text-xs"
                    >
                      LOAD MIDLANDS CONSOLIDATION CORRIDOR
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* GIS NETWORK CORRIDORS SUB-VIEW */}
          {activeTab === "network" && (
            <GisMap
              nodes={nodes}
              connections={connections}
              activeRoute={activeRoute}
              alternativeRoutes={routingSolutions}
              onSelectNode={handleSelectNodeFromMap}
              selectedOrigin={selectedOrigin}
              selectedDestination={selectedDestination}
              onSetOrigin={setSelectedOrigin}
              onSetDestination={setSelectedDestination}
              activeRouteIndex={activeRouteIndex}
              onSetActiveRouteIndex={setActiveRouteIndex}
            />
          )}

          {/* FLEET SCHEDULING SUB-VIEW */}
          {activeTab === "fleet" && (
            <div id="fleet_workspace" className="space-y-6 font-mono text-xs">
              <div className="bg-white/3 border border-steel p-5">
                <div className="border-b border-steel pb-3 mb-4">
                  <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-copper" />
                    RHINOLOGISTICS ACTIVE FLEET STATUS
                  </h3>
                  <p className="text-[11px] text-stone font-sans mt-1 leading-normal">
                    Real-time telemetry and capacity utilization trackers for road, rail, and sea freight assets. Drivers are assigned under strict shift parameters.
                  </p>
                </div>

                {/* Fleet Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {fleet.map((vehicle) => (
                    <div
                      key={vehicle.id}
                      className="bg-graphite border border-steel p-3.5 space-y-3"
                    >
                      <div className="flex justify-between items-start border-b border-steel/40 pb-2">
                        <div>
                          <span className="text-[9px] text-steel uppercase">{vehicle.mode} assets</span>
                          <h4 className="text-[11px] font-bold text-white">{vehicle.type}</h4>
                        </div>
                        <span
                          className={`px-1.5 py-0.5 text-[9px] font-bold uppercase border ${
                            vehicle.status === "transit"
                              ? "bg-copper/10 text-copper border-copper/20"
                              : vehicle.status === "idle"
                              ? "bg-stone/5 text-stone/60 border-steel"
                              : vehicle.status === "charging"
                              ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                              : "bg-red-500/10 text-red-400 border-red-500/20"
                          }`}
                        >
                          {vehicle.status}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-[10px] text-stone/80">
                        <div>
                          <span className="text-steel">ID:</span> {vehicle.id}
                        </div>
                        <div>
                          <span className="text-steel">Fuel:</span> {vehicle.fuelType}
                        </div>
                        <div>
                          <span className="text-steel">Capacity:</span> {vehicle.capacityTonnes} t
                        </div>
                        <div>
                          <span className="text-steel">Payload:</span> {vehicle.currentPayload} t
                        </div>
                      </div>

                      {/* Battery / Fuel level progress bar */}
                      <div className="space-y-1">
                        <div className="flex justify-between items-center text-[9px] text-steel">
                          <span>Battery / Fuel Reserves:</span>
                          <span className="font-bold text-stone/90">{vehicle.batteryOrFuelLevel}%</span>
                        </div>
                        <div className="w-full h-1 bg-steel rounded-none overflow-hidden">
                          <div
                            style={{ width: `${vehicle.batteryOrFuelLevel}%` }}
                            className={`h-full ${
                              vehicle.batteryOrFuelLevel > 50
                                ? "bg-emerald-500"
                                : vehicle.batteryOrFuelLevel > 20
                                ? "bg-copper"
                                : "bg-red-500 animate-pulse"
                            }`}
                          ></div>
                        </div>
                      </div>

                      {/* Driver shift allocation */}
                      <div className="pt-2 border-t border-steel/40 flex justify-between items-center text-[10px]">
                        <span className="text-steel">Shift Window:</span>
                        <span className="text-stone/90">{vehicle.driverShift}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* WAREHOUSE PICKER SUB-VIEW */}
          {activeTab === "warehouse" && <WarehouseVisualizer />}

          {/* DEMAND FORECAST & COST MATRIX SUB-VIEW */}
          {activeTab === "cost" && (
            <div id="cost_workspace" className="space-y-6 font-mono text-xs">
              <div className="bg-white/3 border border-steel p-5">
                <div className="border-b border-steel pb-3 mb-5 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                  <div>
                    <div className="text-[10px] tracking-wider text-copper uppercase font-bold">R Time Series Forecasting Suite</div>
                    <h3 className="text-sm font-semibold text-white uppercase flex items-center gap-1.5">
                      <TrendingUp className="w-4 h-4 text-copper" />
                      DEMAND FORECAST CENTRE
                    </h3>
                    <p className="text-[11px] text-stone font-sans mt-0.5">
                      R-powered time series analysis representing weekly tonnage predictions over retail, industrial, and agricultural freight sectors.
                    </p>
                  </div>

                  {/* Forecast select */}
                  <div className="flex gap-1 bg-graphite p-1 rounded-none border border-steel text-[10px] font-mono">
                    <button
                      onClick={() => setForecasterModel("arima")}
                      className={`px-3 py-1 uppercase transition-colors cursor-pointer rounded-none ${
                        forecasterModel === "arima" ? "bg-copper text-white font-bold" : "text-stone/60 hover:text-stone"
                      }`}
                    >
                      ARIMA (Smoothing)
                    </button>
                    <button
                      onClick={() => setForecasterModel("ets")}
                      className={`px-3 py-1 uppercase transition-colors cursor-pointer rounded-none ${
                        forecasterModel === "ets" ? "bg-copper text-white font-bold" : "text-stone/60 hover:text-stone"
                      }`}
                    >
                      ETS (Exponential)
                    </button>
                    <button
                      onClick={() => setForecasterModel("xgboost")}
                      className={`px-3 py-1 uppercase transition-colors cursor-pointer rounded-none ${
                        forecasterModel === "xgboost" ? "bg-copper text-white font-bold" : "text-stone/60 hover:text-stone"
                      }`}
                    >
                      XGBoost (Covariates)
                    </button>
                  </div>
                </div>

                {/* Simulated Custom SVG Time Series Chart (Instead of heavy package imports) */}
                <div className="bg-graphite border border-steel p-4 flex flex-col items-center">
                  <div className="text-[10px] text-stone/85 font-bold uppercase self-start mb-2 flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5 text-copper" />
                    Interactive Weekly Volume Forecast - Tonnes (Historical vs Forecast)
                  </div>

                  <svg viewBox="0 0 550 250" className="w-full h-auto max-w-[580px] bg-graphite select-none">
                    {/* Grid lines */}
                    {Array.from({ length: 6 }).map((_, idx) => (
                      <line
                        key={`grid-x-${idx}`}
                        x1="40"
                        y1={40 + idx * 30}
                        x2="520"
                        y2={40 + idx * 30}
                        className="stroke-steel/30"
                        strokeWidth="0.5"
                      />
                    ))}

                    {/* Timeline division divider line between History (left) and Forecast (right) */}
                    <line x1="385" y1="10" x2="385" y2="210" className="stroke-copper/50" strokeWidth="1.5" strokeDasharray="3,3" />
                    <text x="380" y="25" fontSize="7" textAnchor="end" className="fill-stone/60 font-bold">HISTORICAL</text>
                    <text x="390" y="25" fontSize="7" textAnchor="start" className="fill-copper font-bold">R FORECAST PREDICTION</text>

                    {/* Confidence Intervals shading area for forecast */}
                    <polygon
                      points="385,110 420,80 455,70 490,60 520,50 520,170 490,165 455,160 420,140 385,120"
                      className="fill-copper/10 stroke-none"
                    />

                    {/* Industrial Line (Blue/Indigo) */}
                    <path
                      d="M 40,110 L 70,120 L 100,105 L 130,95 L 160,115 L 190,100 L 220,110 L 250,90 L 280,85 L 310,100 L 340,95 L 385,102 M 385,102 L 420,95 L 455,90 L 490,85 L 520,80"
                      fill="none"
                      className="stroke-steel"
                      strokeWidth="2.5"
                    />

                    {/* Retail Line (Copper/Orange) */}
                    <path
                      d="M 40,150 L 70,140 L 100,160 L 130,135 L 160,145 L 190,155 L 220,140 L 250,130 L 280,145 L 310,135 L 340,125 L 385,130 M 385,130 L 420,125 L 455,120 L 490,110 L 520,105"
                      fill="none"
                      className="stroke-copper"
                      strokeWidth="2.5"
                      strokeDasharray="385,1000" // solid until history
                    />
                    <path
                      d="M 385,130 L 420,125 L 455,120 L 490,110 L 520,105"
                      fill="none"
                      className="stroke-copper"
                      strokeWidth="2.5"
                      strokeDasharray="4,4" // dashed in forecast
                    />

                    {/* Axis labels */}
                    <text x="35" y="43" fontSize="7" textAnchor="end" className="fill-steel">600t</text>
                    <text x="35" y="103" fontSize="7" textAnchor="end" className="fill-steel">400t</text>
                    <text x="35" y="163" fontSize="7" textAnchor="end" className="fill-steel">200t</text>

                    {/* Time labels on X axis */}
                    <text x="40" y="225" fontSize="7" textAnchor="middle" className="fill-steel">Week 1</text>
                    <text x="130" y="225" fontSize="7" textAnchor="middle" className="fill-steel">Week 4</text>
                    <text x="220" y="225" fontSize="7" textAnchor="middle" className="fill-steel">Week 8</text>
                    <text x="310" y="225" fontSize="7" textAnchor="middle" className="fill-steel">Week 11</text>
                    <text x="420" y="225" fontSize="7" textAnchor="middle" className="fill-copper font-bold">FCast +1W</text>
                    <text x="520" y="225" fontSize="7" textAnchor="middle" className="fill-copper font-bold">FCast +4W</text>
                  </svg>

                  {/* Legend */}
                  <div className="flex gap-6 mt-3 text-[10px] font-sans">
                    <div className="flex items-center gap-1.5">
                      <span className="w-3 h-1 bg-steel inline-block"></span>
                      <span className="text-stone/80">Industrial Freight Volume (ARIMA Fit)</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-3 h-1 bg-copper inline-block"></span>
                      <span className="text-stone/80">Retail Demand Trend</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-4 h-3.5 bg-copper/10 inline-block border border-dashed border-copper/30"></span>
                      <span className="text-stone/80">80% / 95% Confidence Intervals</span>
                    </div>
                  </div>
                </div>

                {/* R forecast analytical outputs block */}
                <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-4 bg-graphite p-4 border border-steel">
                  <div className="space-y-1">
                    <span className="text-[10px] text-steel uppercase font-bold flex items-center gap-1">
                      <Sliders className="w-3.5 h-3.5 text-copper" /> Model AIC Score
                    </span>
                    <div className="text-sm font-bold text-white">
                      {forecasterModel === "arima" ? "1422.45" : forecasterModel === "ets" ? "1458.20" : "1430.12"}
                    </div>
                    <p className="text-[9.5px] text-stone/75 font-sans leading-normal">
                      Akaike Information Criterion. Low scores indicate high model parsimony and minimized forecasting drift.
                    </p>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[10px] text-steel uppercase font-bold flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-copper" /> Seasonality Index
                    </span>
                    <div className="text-sm font-bold text-white">Weekly (S=52) Fit</div>
                    <p className="text-[9.5px] text-stone/75 font-sans leading-normal">
                      The algorithm isolates North Sea port container delivery rhythms to accurately predict retail volume swells prior to winter holidays.
                    </p>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[10px] text-steel uppercase font-bold flex items-center gap-1">
                      <Shield className="w-3.5 h-3.5 text-emerald-500" /> Forecast Validation
                    </span>
                    <div className="text-sm font-bold text-emerald-400">96.4% Ljung-Box Pass</div>
                    <p className="text-[9.5px] text-stone/75 font-sans leading-normal">
                      Residual noise checks indicate zero significant autocorrelations, verifying that predicted trends represent structural demands.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* AI ECONOMICS ADVISOR SUB-VIEW */}
          {activeTab === "advisor" && <AiAdvisor />}

          {/* BOARDROOM REPORTS SUB-VIEW */}
          {activeTab === "reports" && <ReportView />}

          {/* ARCHITECTURAL SPECS SUB-VIEW */}
          {activeTab === "tech" && <SystemSpecs />}
        </main>
      </div>
    </div>
  );
}
