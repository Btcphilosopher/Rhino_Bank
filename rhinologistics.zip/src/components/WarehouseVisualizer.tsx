import { useState, useMemo } from "react";
import { solveWarehousePickerPath } from "../utils/optimizers";
import { WarehouseRack, WarehouseDock } from "../types";
import { ListChecks, RotateCcw, Box, Truck, Compass, Footprints } from "lucide-react";

export default function WarehouseVisualizer() {
  const [strategy, setStrategy] = useState<"s_shape" | "optimal">("optimal");
  const [activeDock, setActiveDock] = useState<string>("dock_a");

  // Checklist of active picking items
  const [pickList, setPickList] = useState([
    { id: "item_1", name: "High-Grade Structural Steel", aisle: 1, bay: 3, category: "Industrial", picked: false },
    { id: "item_2", name: "Copper Wiring Reels", aisle: 3, bay: 7, category: "Infrastructure", picked: false },
    { id: "item_3", name: "FMCG Retail Consignment", aisle: 2, bay: 5, category: "Retail", picked: false },
    { id: "item_4", name: "Heavy Machinery Fasteners", aisle: 5, bay: 2, category: "Industrial", picked: false },
    { id: "item_5", name: "Precision Titanium Components", aisle: 4, bay: 9, category: "Advanced Metallurgy", picked: false }
  ]);

  const toggleItemPicked = (id: string) => {
    setPickList((prev) =>
      prev.map((item) => (item.id === id ? { ...item, picked: !item.picked } : item))
    );
  };

  // Warehouse layout grid config
  const racks: WarehouseRack[] = useMemo(() => [
    { id: "rack_1_1", x: 4, y: 2, width: 1.5, height: 10, category: "Industrial", occupancy: 82 },
    { id: "rack_2_1", x: 8, y: 2, width: 1.5, height: 10, category: "Retail", occupancy: 65 },
    { id: "rack_3_1", x: 12, y: 2, width: 1.5, height: 10, category: "Infrastructure", occupancy: 90 },
    { id: "rack_4_1", x: 16, y: 2, width: 1.5, height: 10, category: "Agriculture", occupancy: 42 },
    { id: "rack_5_1", x: 20, y: 2, width: 1.5, height: 10, category: "Advanced Metallurgy", occupancy: 78 }
  ], []);

  const docks: WarehouseDock[] = [
    { id: "dock_a", name: "Loading Dock A", status: "busy", assignedVehicle: "v_rhino_01", queueLength: 2 },
    { id: "dock_b", name: "Loading Dock B", status: "available", queueLength: 0 },
    { id: "dock_c", name: "Loading Dock C", status: "busy", assignedVehicle: "v_rhino_03", queueLength: 4 },
    { id: "dock_d", name: "Loading Dock D", status: "blocked", queueLength: 1 }
  ];

  // Solve picker path
  const activePicks = useMemo(() => pickList.filter((item) => !item.picked), [pickList]);
  
  const pickerResults = useMemo(() => {
    // If no active picks, path is just dock to dock
    if (activePicks.length === 0) {
      return { pathPoints: [{ x: 2, y: 15 }, { x: 2, y: 15 }], totalDistanceMeters: 0 };
    }
    return solveWarehousePickerPath(activePicks, strategy);
  }, [activePicks, strategy]);

  // Translate grid coordinates into SVG coordinates
  // Grid X: 0 - 24, Grid Y: 0 - 18
  const projectX = (x: number) => x * 15 + 20;
  const projectY = (y: number) => y * 15 + 20;

  return (
    <div id="warehouse_module" className="grid grid-cols-1 xl:grid-cols-12 gap-6">
      {/* 2D Floor Plan layout */}
      <div id="warehouse_grid_card" className="xl:col-span-8 bg-white/3 border border-steel p-5 flex flex-col relative overflow-hidden">
        <div className="flex justify-between items-start mb-4">
          <div>
            <div className="text-[10px] tracking-widest text-copper font-mono uppercase font-bold mb-1">RUST WAREHOUSE PICKER OPTIMISER v1.2</div>
            <h3 className="text-sm font-semibold text-white font-mono flex items-center gap-1.5 uppercase">
              <Box className="w-4 h-4 text-copper" />
              LEEDS LOGISTICS HUB - PICKING MAP
            </h3>
          </div>

          {/* Strategy buttons */}
          <div className="flex gap-1 bg-graphite p-1 rounded-none border border-steel text-[10px] font-mono">
            <button
              onClick={() => setStrategy("s_shape")}
              className={`px-2.5 py-1 rounded-none transition-colors cursor-pointer ${
                strategy === "s_shape"
                  ? "bg-copper text-white font-bold"
                  : "text-stone/60 hover:text-stone"
              }`}
            >
              S-Shape heuristic
            </button>
            <button
              onClick={() => setStrategy("optimal")}
              className={`px-2.5 py-1 rounded-none transition-colors cursor-pointer ${
                strategy === "optimal"
                  ? "bg-copper text-white font-bold"
                  : "text-stone/60 hover:text-stone"
              }`}
            >
              Optimal Heuristic
            </button>
          </div>
        </div>

        {/* 2D Grid Visualizer */}
        <div className="flex-1 min-h-[350px] bg-graphite border border-steel rounded-none flex items-center justify-center p-2 relative">
          <svg
            viewBox="0 0 380 320"
            className="w-full h-auto select-none max-w-[480px]"
          >
            {/* Background grids */}
            <defs>
              <pattern id="rack-grid" width="15" height="15" patternUnits="userSpaceOnUse">
                <rect width="15" height="15" fill="none" stroke="#2D3136" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#rack-grid)" opacity="0.4" />

            {/* Render aisles labels */}
            {racks.map((r, i) => (
              <text
                key={`label-${r.id}`}
                x={projectX(r.x + r.width / 2)}
                y={15}
                fontSize="8"
                textAnchor="middle"
                className="fill-steel font-mono font-bold"
              >
                AISLE {i + 1}
              </text>
            ))}

            {/* Render racks (shelves) */}
            {racks.map((r) => {
              // Highlight category
              let color = "fill-graphite stroke-steel";
              if (r.category === "Industrial") color = "fill-copper/10 stroke-copper/40";
              else if (r.category === "Infrastructure") color = "fill-white/5 stroke-steel";
              else if (r.category === "Retail") color = "fill-stone/5 stroke-steel/60";

              return (
                <g key={r.id}>
                  <rect
                    x={projectX(r.x)}
                    y={projectY(r.y)}
                    width={r.width * 15}
                    height={r.height * 15}
                    className={`${color} stroke-2 transition-all duration-300`}
                  />
                  {/* Shelves division ticks */}
                  {Array.from({ length: 5 }).map((_, idx) => (
                    <line
                      key={`${r.id}-tick-${idx}`}
                      x1={projectX(r.x)}
                      y1={projectY(r.y + (r.height / 5) * idx)}
                      x2={projectX(r.x + r.width)}
                      y2={projectY(r.y + (r.height / 5) * idx)}
                      className="stroke-steel/30"
                      strokeWidth="1"
                    />
                  ))}
                  {/* Occupancy Indicator Bar */}
                  <rect
                    x={projectX(r.x) + 3}
                    y={projectY(r.y + r.height) - 10}
                    width={r.width * 15 - 6}
                    height="4"
                    className="fill-graphite stroke border-steel/20"
                  />
                  <rect
                    x={projectX(r.x) + 3}
                    y={projectY(r.y + r.height) - 10}
                    width={(r.width * 15 - 6) * (r.occupancy / 100)}
                    className={r.occupancy > 80 ? "fill-red-500" : r.occupancy > 50 ? "fill-copper" : "fill-emerald-500"}
                    height="4"
                  />
                </g>
              );
            })}

            {/* Docks on left side */}
            <g transform={`translate(5, ${projectY(14)})`}>
              <rect x="0" y="0" width="40" height="25" className="fill-graphite stroke-steel" />
              <text x="20" y="10" fontSize="7" textAnchor="middle" className="fill-stone/60 font-mono">DOCK A</text>
              <circle cx="20" cy="18" r="3" className="fill-red-500" />
            </g>

            <g transform={`translate(5, ${projectY(16)})`}>
              <rect x="0" y="0" width="40" height="25" className="fill-graphite stroke-steel" />
              <text x="20" y="10" fontSize="7" textAnchor="middle" className="fill-stone/60 font-mono">DOCK B</text>
              <circle cx="20" cy="18" r="3" className="fill-emerald-500" />
            </g>

            {/* Draw pick target markers */}
            {activePicks.map((item, idx) => {
              // Map to coordinates
              const xPos = item.aisle * 4;
              const yPos = 2 + (item.bay - 1) * 1.1;

              return (
                <g key={`item-mark-${item.id}`} transform={`translate(${projectX(xPos)}, ${projectY(yPos)})`}>
                  <circle r="6" className="fill-copper stroke-graphite stroke-1 animate-pulse" />
                  <text
                    textAnchor="middle"
                    dy=".3em"
                    fontSize="7"
                    fontWeight="bold"
                    className="fill-white font-mono"
                  >
                    {idx + 1}
                  </text>
                </g>
              );
            })}

            {/* Render solved picker path route overlay */}
            {pickerResults.pathPoints.length > 1 && (
              <g>
                {/* Solved path outline */}
                <path
                  d={pickerResults.pathPoints
                    .map((pt, idx) => `${idx === 0 ? "M" : "L"} ${projectX(pt.x)} ${projectY(pt.y)}`)
                    .join(" ")}
                  fill="none"
                  className="stroke-copper"
                  strokeWidth="2"
                  strokeDasharray="3,3"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                {/* Arrow head path tracker */}
                <circle r="4" className="fill-copper">
                  <animateMotion
                    path={pickerResults.pathPoints
                      .map((pt, idx) => `${idx === 0 ? "M" : "L"} ${projectX(pt.x)} ${projectY(pt.y)}`)
                      .join(" ")}
                    dur="12s"
                    repeatCount="indefinite"
                  />
                </circle>
              </g>
            )}

            {/* Picker starting point label */}
            <circle cx={projectX(2)} cy={projectY(15)} r="5" className="fill-emerald-500" />
            <text x={projectX(2) + 8} y={projectY(15) + 3} fontSize="7" className="fill-emerald-400 font-mono font-bold">START</text>
          </svg>

          {/* Floater Metrics overlay */}
          <div className="absolute bottom-3 right-3 bg-graphite/95 border border-steel p-3 rounded-none font-mono text-[10px] space-y-1.5 text-stone/90">
            <div className="text-[9px] uppercase font-bold text-steel">Active Picking Solution</div>
            <div className="flex justify-between gap-4">
              <span className="text-steel flex items-center gap-1">
                <Footprints className="w-3 h-3 text-copper" /> Walking Dist:
              </span>
              <span className="font-bold text-white">{pickerResults.totalDistanceMeters} meters</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-steel flex items-center gap-1">
                <Compass className="w-3 h-3 text-emerald-500" /> Efficiency Score:
              </span>
              <span className="font-bold text-emerald-400">
                {strategy === "optimal" ? "94.2% (Optimal)" : "76.5% (Suboptimal)"}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Picking checklist controller */}
      <div id="warehouse_control_card" className="xl:col-span-4 bg-white/3 border border-steel p-5 flex flex-col justify-between font-mono text-xs">
        <div>
          <div className="border-b border-steel pb-3 mb-4">
            <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
              <ListChecks className="w-4 h-4 text-copper" />
              Active Picking Console
            </h3>
            <p className="text-[11px] text-stone font-sans mt-1">
              Toggle items in the load order. Unpicked items generate dynamic pick-path coordinates.
            </p>
          </div>

          {/* Checklist items list */}
          <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
            {pickList.map((item) => (
              <div
                key={item.id}
                onClick={() => toggleItemPicked(item.id)}
                className={`flex items-center gap-3 p-2.5 rounded-none border transition-all cursor-pointer ${
                  item.picked
                    ? "bg-graphite/40 text-stone/40 border-steel/20 line-through"
                    : "bg-graphite border border-steel text-stone/90 hover:border-copper/40"
                }`}
              >
                <input
                  type="checkbox"
                  checked={item.picked}
                  onChange={() => {}} // Swallowed, handled by div click
                  className="rounded-none text-copper focus:ring-0 cursor-pointer accent-copper"
                />
                <div className="flex-1 min-w-0">
                  <div className="text-[11px] font-bold truncate">{item.name}</div>
                  <div className="text-[9px] text-steel flex justify-between">
                    <span>Aisle {item.aisle}, Bay {item.bay}</span>
                    <span className="text-copper font-bold uppercase">{item.category}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Docking Bay queue statistics */}
          <div className="mt-5 pt-4 border-t border-steel/40 space-y-2.5">
            <span className="text-[10px] text-steel uppercase flex items-center gap-1">
              <Truck className="w-3.5 h-3.5 text-copper" />
              Loading Dock Status
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              {docks.map((dock) => (
                <div
                  key={dock.id}
                  onClick={() => setActiveDock(dock.id)}
                  className={`p-2 rounded-none border cursor-pointer transition-all ${
                    activeDock === dock.id
                      ? "bg-white/10 border-copper"
                      : "bg-graphite border border-steel hover:border-steel/80"
                  }`}
                >
                  <div className="flex justify-between items-center text-[10px] font-bold">
                    <span className="text-stone">{dock.name}</span>
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        dock.status === "available"
                          ? "bg-emerald-500"
                          : dock.status === "busy"
                          ? "bg-red-500"
                          : "bg-copper"
                      }`}
                    ></span>
                  </div>
                  <div className="text-[9px] text-steel mt-1 flex justify-between">
                    <span>Queue: {dock.queueLength} trucks</span>
                    {dock.assignedVehicle && <span className="text-white/65">{dock.assignedVehicle}</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Picker Trigger Action */}
        <div className="pt-4 border-t border-steel/40 mt-4 flex gap-2">
          <button
            onClick={() => {
              setPickList((prev) => prev.map((item) => ({ ...item, picked: false })));
            }}
            className="px-3 py-2 bg-graphite hover:bg-white/5 border border-steel text-steel rounded-none transition-colors cursor-pointer"
            title="Reset Checklist"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              alert(`[Leeds DC Picker] Route computed in 0.12ms via Rust optimization engine! Picklist dispatched to autonomous stackers.`);
            }}
            className="flex-1 bg-copper hover:bg-copper/90 text-white font-bold font-sans py-2 rounded-none text-center transition-colors cursor-pointer"
          >
            EXECUTE LOAD PICKING
          </button>
        </div>
      </div>
    </div>
  );
}
