import { useState, useMemo } from "react";
import { NetworkNode, NetworkConnection, OptimisationResult } from "../types";
import { Anchor, Building, Train, Shield, HelpCircle, MapPin, Activity, AlertTriangle, Leaf } from "lucide-react";

interface GisMapProps {
  nodes: NetworkNode[];
  connections: NetworkConnection[];
  activeRoute: OptimisationResult | null;
  alternativeRoutes: OptimisationResult[];
  onSelectNode: (node: NetworkNode) => void;
  selectedOrigin: string | null;
  selectedDestination: string | null;
  onSetOrigin: (id: string | null) => void;
  onSetDestination: (id: string | null) => void;
  activeRouteIndex: number;
  onSetActiveRouteIndex: (idx: number) => void;
}

export default function GisMap({
  nodes,
  connections,
  activeRoute,
  alternativeRoutes,
  onSelectNode,
  selectedOrigin,
  selectedDestination,
  onSetOrigin,
  onSetDestination,
  activeRouteIndex,
  onSetActiveRouteIndex
}: GisMapProps) {
  const [hoveredNode, setHoveredNode] = useState<NetworkNode | null>(null);

  // Geographic projection bounds
  const latMin = 49.9;
  const latMax = 56.5;
  const lngMin = -6.5;
  const lngMax = 2.0;

  const project = useMemo(() => {
    return (lat: number, lng: number) => {
      const x = ((lng - lngMin) / (lngMax - lngMin)) * 480 + 10;
      const y = (1 - (lat - latMin) / (latMax - latMin)) * 620 + 10;
      return { x: Math.round(x), y: Math.round(y) };
    };
  }, []);

  // Helper to get Node Coordinates
  const nodeCoords = useMemo(() => {
    const coords: Record<string, { x: number; y: number }> = {};
    nodes.forEach((node) => {
      coords[node.id] = project(node.lat, node.lng);
    });
    return coords;
  }, [nodes, project]);

  // Node Icon helper
  const getNodeIcon = (type: NetworkNode["type"], className = "w-4 h-4") => {
    switch (type) {
      case "port":
        return <Anchor className={className} />;
      case "dc":
        return <Building className={className} />;
      case "rail_terminal":
        return <Train className={className} />;
      case "industrial_cluster":
        return <Shield className={className} />;
      default:
        return <HelpCircle className={className} />;
    }
  };

  // Check if a connection is part of the currently active route
  const getRouteStatus = (connId: string) => {
    if (!activeRoute) return "none";
    
    // Check if the primary active route contains this connection
    const inPrimary = activeRoute.connections.some((c) => c.id === connId);
    if (inPrimary) return "primary";

    // Check alternative routes
    for (let i = 0; i < alternativeRoutes.length; i++) {
      if (alternativeRoutes[i].connections.some((c) => c.id === connId)) {
        return `alt-${i}`;
      }
    }

    return "none";
  };

  return (
    <div id="gis_map_container" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Interactive Map Visualizer */}
      <div id="map_visualizer" className="lg:col-span-8 bg-white/3 border border-steel rounded-none p-4 relative overflow-hidden flex flex-col items-center justify-center min-h-[500px]">
        {/* Yorkshire Futurist Engineering Grid and Title */}
        <div className="absolute top-4 left-4 z-10">
          <div className="text-[10px] tracking-widest text-copper uppercase font-mono font-bold mb-1">GIS Network Engine v4.8</div>
          <h3 className="text-sm font-semibold text-white font-mono uppercase">UNITED KINGDOM FREIGHT CORRIDORS</h3>
        </div>

        {/* Legend */}
        <div className="absolute bottom-4 left-4 z-10 bg-graphite/95 border border-steel p-3 rounded-none text-[11px] font-mono space-y-1.5 max-w-[220px]">
          <div className="text-[10px] text-steel uppercase font-bold mb-1">Legend</div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-1 bg-steel/50 inline-block"></span>
            <span className="text-stone/70">Standard Road (Motorway)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-0.5 border-t border-dashed border-steel inline-block"></span>
            <span className="text-stone/70">Rail Freight Corridor</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-0.5 border-t border-dotted border-blue-400 inline-block"></span>
            <span className="text-blue-400">Coastal Sea Lanes</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-1 bg-copper inline-block"></span>
            <span className="text-copper font-semibold">Active Optimized Route</span>
          </div>
          {alternativeRoutes.length > 1 && (
            <div className="flex items-center gap-2">
              <span className="w-3 h-0.5 bg-cyan-600 inline-block"></span>
              <span className="text-cyan-400">Yen's K-Shortest Alternates</span>
            </div>
          )}
        </div>

        {/* SVG Interactive Map */}
        <svg
          viewBox="0 0 500 650"
          className="w-full max-w-[480px] h-auto select-none relative"
          style={{ maxHeight: "600px" }}
        >
          {/* Stylized background grid */}
          <defs>
            <pattern id="grid" width="24" height="24" patternUnits="userSpaceOnUse">
              <path d="M 24 0 L 0 0 0 24" fill="none" stroke="#4A4E54" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" opacity="0.15" />

          {/* Draw connections (lines) */}
          {connections.map((conn) => {
            const fromCoord = nodeCoords[conn.from];
            const toCoord = nodeCoords[conn.to];
            if (!fromCoord || !toCoord) return null;

            const routeStatus = getRouteStatus(conn.id);
            const isRestricted = conn.restricted;

            let strokeColor = "stroke-steel/40";
            let strokeWidth = 1.5;
            let strokeDash = "";

            if (conn.mode === "rail") {
              strokeDash = "4,4";
              strokeColor = "stroke-steel/70";
            } else if (conn.mode === "sea") {
              strokeDash = "2,3";
              strokeColor = "stroke-blue-900";
            }

            // Highlight optimized active paths
            if (routeStatus === "primary") {
              strokeColor = "stroke-copper";
              strokeWidth = 3.5;
              strokeDash = "";
            } else if (routeStatus.startsWith("alt-")) {
              strokeColor = "stroke-cyan-600";
              strokeWidth = 2.5;
              strokeDash = "3,3";
            }

            if (isRestricted) {
              strokeColor = "stroke-red-900/60";
              strokeDash = "2,2";
            }

            return (
              <g key={conn.id}>
                {/* Secondary thick shadow for active glow */}
                {routeStatus === "primary" && (
                  <line
                    x1={fromCoord.x}
                    y1={fromCoord.y}
                    x2={toCoord.x}
                    y2={toCoord.y}
                    className="stroke-copper/20"
                    strokeWidth={8}
                    strokeLinecap="round"
                  />
                )}
                <line
                  x1={fromCoord.x}
                  y1={fromCoord.y}
                  x2={toCoord.x}
                  y2={toCoord.y}
                  className={`${strokeColor} transition-all duration-300`}
                  strokeWidth={strokeWidth}
                  strokeDasharray={strokeDash}
                  strokeLinecap="round"
                />

                {/* Animated traveling dots on primary optimized path */}
                {routeStatus === "primary" && (
                  <circle r="4" className="fill-copper">
                    <animateMotion
                      path={`M ${fromCoord.x} ${fromCoord.y} L ${toCoord.x} ${toCoord.y}`}
                      dur="3s"
                      repeatCount="indefinite"
                    />
                  </circle>
                )}
              </g>
            );
          })}

          {/* Draw Nodes (Points) */}
          {nodes.map((node) => {
            const coord = nodeCoords[node.id];
            if (!coord) return null;

            const isSelected = selectedOrigin === node.id || selectedDestination === node.id;
            const isOrigin = selectedOrigin === node.id;
            const isDestination = selectedDestination === node.id;
            const isYorkshire = node.region === "Yorkshire and the Humber";

            let pinColor = "bg-graphite border-steel text-stone";
            if (isYorkshire) {
              pinColor = "bg-graphite border-copper/80 text-copper"; // Yorkshire highlighted
            }
            if (isOrigin) {
              pinColor = "bg-emerald-500 border-emerald-400 text-graphite";
            } else if (isDestination) {
              pinColor = "bg-copper border-copper text-graphite";
            }

            return (
              <g
                key={node.id}
                transform={`translate(${coord.x}, ${coord.y})`}
                onMouseEnter={() => setHoveredNode(node)}
                onMouseLeave={() => setHoveredNode(null)}
                onClick={() => onSelectNode(node)}
                className="cursor-pointer group"
              >
                {/* Yorkshire Stone glow */}
                {isYorkshire && !isSelected && (
                  <circle r="12" className="fill-copper/10 stroke-copper/30 animate-pulse" strokeWidth="0.5" />
                )}

                {/* Selected Ring */}
                {isSelected && (
                  <circle
                    r="15"
                    className={`fill-none ${isOrigin ? "stroke-emerald-500/50" : "stroke-copper/50"} animate-ping`}
                    strokeWidth="1.5"
                  />
                )}

                {/* Main Node Circle */}
                <circle
                  r="10"
                  className={`${isOrigin ? "fill-emerald-500" : isDestination ? "fill-copper" : isYorkshire ? "fill-graphite stroke-copper" : "fill-graphite stroke-steel"} group-hover:stroke-copper transition-colors duration-200`}
                  strokeWidth="2"
                />

                {/* SVG Text abbreviation (1st letter) */}
                <text
                  textAnchor="middle"
                  dy=".3em"
                  fontSize="8"
                  fontWeight="bold"
                  className={isOrigin || isDestination ? "fill-graphite" : "fill-stone"}
                >
                  {node.name.replace("Port of ", "").replace("Port ", "").substring(0, 1)}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Hover detail card overlay */}
        {hoveredNode && (
          <div className="absolute top-16 right-4 z-20 bg-graphite border border-steel p-4 rounded-none shadow-xl max-w-xs font-mono text-[11px] space-y-2 text-stone/95">
            <div className="flex items-center gap-1.5 font-sans font-bold text-xs text-white">
              <span className="text-copper">{getNodeIcon(hoveredNode.type, "w-3.5 h-3.5")}</span>
              {hoveredNode.name}
            </div>
            <div className="text-[10px] text-copper font-bold uppercase">{hoveredNode.region}</div>
            <p className="text-stone/80 leading-relaxed font-sans">{hoveredNode.details}</p>
            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-steel/40 text-[10px]">
              <div>
                <span className="text-steel">Cap:</span> {hoveredNode.capacity.toLocaleString()} t
              </div>
              <div>
                <span className="text-steel">Throughput:</span> {hoveredNode.currentThroughput.toLocaleString()} t
              </div>
              <div>
                <span className="text-steel">Congestion:</span>{" "}
                <span className={hoveredNode.congestionLevel > 0.6 ? "text-red-400" : "text-emerald-400"}>
                  {Math.round(hoveredNode.congestionLevel * 100)}%
                </span>
              </div>
              <div>
                <span className="text-steel">Carbon Eff:</span> {hoveredNode.carbonScore === 5 ? "A" : hoveredNode.carbonScore === 4 ? "B" : hoveredNode.carbonScore === 3 ? "C" : hoveredNode.carbonScore === 2 ? "D" : "E"}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Control Panel / Selected Node Details */}
      <div id="route_controls" className="lg:col-span-4 bg-white/3 border border-steel p-5 flex flex-col justify-between font-mono text-xs">
        <div>
          <div className="border-b border-steel pb-3 mb-4">
            <h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-copper" />
              Routing Dispatch Desk
            </h3>
            <p className="text-[11px] text-stone mt-1 font-sans">
              Select origin and destination nodes on the GIS map to trigger the Rust Dijkstra engine.
            </p>
          </div>

          <div className="space-y-4">
            {/* Origin field */}
            <div className="space-y-1">
              <label className="text-[11px] text-steel uppercase">A. Dispatch Origin</label>
              {selectedOrigin ? (
                <div className="flex items-center justify-between bg-graphite border border-steel px-3 py-2 rounded-none">
                  <span className="text-white truncate flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    {nodes.find((n) => n.id === selectedOrigin)?.name}
                  </span>
                  <button
                    onClick={() => onSetOrigin(null)}
                    className="text-[10px] text-copper hover:text-copper/80 font-mono font-bold cursor-pointer"
                  >
                    Clear
                  </button>
                </div>
              ) : (
                <div className="bg-graphite border border-steel px-3 py-2.5 rounded-none text-steel text-[11px] font-sans italic">
                  Click a node on map to select...
                </div>
              )}
            </div>

            {/* Destination field */}
            <div className="space-y-1">
              <label className="text-[11px] text-steel uppercase">B. Terminal Destination</label>
              {selectedDestination ? (
                <div className="flex items-center justify-between bg-graphite border border-steel px-3 py-2 rounded-none">
                  <span className="text-white truncate flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-copper"></span>
                    {nodes.find((n) => n.id === selectedDestination)?.name}
                  </span>
                  <button
                    onClick={() => onSetDestination(null)}
                    className="text-[10px] text-copper hover:text-copper/80 font-mono font-bold cursor-pointer"
                  >
                    Clear
                  </button>
                </div>
              ) : (
                <div className="bg-graphite border border-steel px-3 py-2.5 rounded-none text-steel text-[11px] font-sans italic">
                  Click a node on map to select...
                </div>
              )}
            </div>
          </div>

          {/* Optimized route statistics panel */}
          {activeRoute && activeRoute.path.length > 0 ? (
            <div className="mt-6 pt-4 border-t border-steel/40 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-[10px] uppercase text-copper font-bold">Optimal Path Stats</span>
                {alternativeRoutes.length > 1 && (
                  <span className="text-[10px] text-steel font-sans">
                    Showing Route {activeRouteIndex + 1} of {alternativeRoutes.length}
                  </span>
                )}
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-2 bg-graphite p-3 rounded-none border border-steel">
                <div className="space-y-0.5">
                  <div className="text-[10px] text-steel">Distance</div>
                  <div className="text-xs font-bold text-white">{activeRoute.totalDistanceKm} km</div>
                </div>
                <div className="space-y-0.5">
                  <div className="text-[10px] text-steel">Transit Duration</div>
                  <div className="text-xs font-bold text-white">
                    {activeRoute.totalTimeHrs.toFixed(1)} hrs
                  </div>
                </div>
                <div className="space-y-0.5">
                  <div className="text-[10px] text-steel">Est. Fuel Burn</div>
                  <div className="text-xs font-bold text-white">
                    {Math.round(activeRoute.totalFuelLiters)} Liters
                  </div>
                </div>
                <div className="space-y-0.5">
                  <div className="text-[10px] text-steel">Infrastructure Toll</div>
                  <div className="text-xs font-bold text-white">
                    £{activeRoute.totalTollCost.toFixed(2)}
                  </div>
                </div>
                <div className="col-span-2 pt-1.5 border-t border-steel/40 flex justify-between items-center text-[10px]">
                  <span className="text-steel flex items-center gap-1">
                    <Leaf className="w-3.5 h-3.5 text-emerald-500" />
                    Carbon Intensity:
                  </span>
                  <span className="font-bold text-emerald-400">{activeRoute.totalCarbonKg.toFixed(1)} kg CO₂</span>
                </div>
              </div>

              {/* Yen's Selector button toggles */}
              {alternativeRoutes.length > 1 && (
                <div className="space-y-1.5">
                  <span className="text-[10px] text-steel uppercase">Alternative Solutions (Yen's paths)</span>
                  <div className="flex flex-col sm:flex-row gap-1.5">
                    {alternativeRoutes.map((alt, idx) => (
                      <button
                        key={idx}
                        onClick={() => onSetActiveRouteIndex(idx)}
                        className={`flex-1 py-1.5 rounded-none text-[10px] font-mono border transition-all cursor-pointer ${
                          activeRouteIndex === idx
                            ? "bg-copper/20 text-copper border-copper/60"
                            : "bg-graphite text-stone/60 border-steel hover:border-stone/40"
                        }`}
                      >
                        {idx === 0 ? "Dijkstra" : `Yen path ${idx}`}
                        <div className="text-[9px] text-steel font-sans mt-0.5">
                          {alt.totalTimeHrs.toFixed(1)}h | {alt.totalDistanceKm}km
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Path Node Sequence List */}
              <div className="space-y-1.5">
                <span className="text-[10px] text-steel uppercase">Node Sequence</span>
                <div className="flex flex-wrap items-center gap-1 text-[10px] font-mono leading-none bg-graphite p-2 rounded-none border border-steel">
                  {activeRoute.path.map((nodeId, idx) => {
                    const node = nodes.find((n) => n.id === nodeId);
                    if (!node) return null;
                    return (
                      <span key={nodeId} className="flex items-center gap-1">
                        {idx > 0 && <span className="text-steel">→</span>}
                        <span
                          className={`px-1.5 py-0.5 rounded-none ${
                            idx === 0
                              ? "bg-emerald-950/40 text-emerald-400 border border-emerald-900/60"
                              : idx === activeRoute.path.length - 1
                              ? "bg-copper/10 text-copper border border-copper/30"
                              : node.region === "Yorkshire and the Humber"
                              ? "bg-white/5 text-white border border-steel"
                              : "bg-stone/5 text-stone/60 border border-steel/40"
                          }`}
                        >
                          {node.name.replace("Port of ", "").replace("Port ", "").replace(" Distribution Centre", "").replace(" Logistics Park", "").replace(" Interchange", "").replace(" Freight Terminal", "").replace(" Terminal", "").replace(" Gateway DC", "")}
                        </span>
                      </span>
                    );
                  })}
                </div>
              </div>

              {/* Bottlenecks & Warnings */}
              {activeRoute.bottlenecksPassed.length > 0 && (
                <div className="p-2.5 bg-yellow-950/20 border border-yellow-900/40 rounded-none text-[10px] text-yellow-300 space-y-1 font-sans">
                  <div className="font-bold flex items-center gap-1 uppercase font-mono text-[9px] text-yellow-500">
                    <AlertTriangle className="w-3.5 h-3.5 text-yellow-500" />
                    Congestion Warnings
                  </div>
                  <ul className="list-disc list-inside space-y-0.5 text-stone/90">
                    {activeRoute.bottlenecksPassed.map((b, i) => (
                      <li key={i}>{b}</li>
                    ))}
                  </ul>
                </div>
              )}

              {activeRoute.vehicleWarnings.length > 0 && (
                <div className="p-2.5 bg-blue-950/20 border border-blue-900/40 rounded-none text-[10px] text-blue-300 space-y-1 font-sans">
                  <div className="font-bold flex items-center gap-1 uppercase font-mono text-[9px] text-blue-400">
                    <Shield className="w-3.5 h-3.5 text-blue-400" />
                    Regulatory Dispatch Advice
                  </div>
                  <ul className="list-disc list-inside space-y-0.5 text-stone/90">
                    {activeRoute.vehicleWarnings.map((w, i) => (
                      <li key={i}>{w}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ) : (
            <div className="mt-8 text-center text-steel font-sans p-6 border border-dashed border-steel rounded-none">
              <MapPin className="w-8 h-8 text-steel/60 mx-auto mb-2" />
              Select both A and B on the map to run multi-modal route calculations.
            </div>
          )}
        </div>

        {/* Dispatch Action Trigger */}
        {activeRoute && activeRoute.path.length > 0 && (
          <div className="pt-4 border-t border-steel/40 mt-4">
            <button
              onClick={() => {
                alert(`[RhinoLogistics Dispatch Command] Route successfully dispatched to fleet tracking! Estimated transit time is ${activeRoute.totalTimeHrs.toFixed(1)} hours.`);
              }}
              className="w-full bg-copper hover:bg-copper/90 text-white font-bold font-sans py-2.5 rounded-none text-xs transition-colors cursor-pointer text-center block"
            >
              DISPATCH ROUTE TO FLEET
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
