import { useState, useRef, useEffect } from "react";
import { ChatMessage } from "../types";
import { Send, Bot, User, Sparkles, ExternalLink, HelpCircle, Loader } from "lucide-react";

export default function AiAdvisor() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      sender: "ai",
      text: "Greetings. I am your Lead Logistics Advisor and Principal Transport Economist at Rhino Bank. I specialize in freight optimization across the United Kingdom, specifically analyzing cost matrices, port congestions, demand fluctuations, and multimodal networks including the Yorkshire and Humber freight corridors. How can I assist you with transport finance or network routing today?",
      timestamp: new Date().toLocaleTimeString()
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const preloadedQuestions = [
    "What is the impact of a 15% fuel price surge on road haulage margins in the north of England?",
    "Optimize containerised rail paths from Felixstowe Port to Birmingham DC.",
    "Explain the difference between ARIMA and ETS forecasting for seasonal retail demand.",
    "Draft a Yorkshire regional transport finance briefing on the Humber-Pennine Rail electrification."
  ];

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/advisor/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: [...messages, userMsg] })
      });

      if (!response.ok) {
        throw new Error("Failed to communicate with Advisor server.");
      }

      const data = await response.json();

      setMessages((prev) => [
        ...prev,
        {
          id: `ai-${Date.now()}`,
          sender: "ai",
          text: data.text,
          timestamp: new Date().toLocaleTimeString(),
          groundingSources: data.groundingSources || []
        }
      ]);
    } catch (err: any) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: `ai-err-${Date.now()}`,
          sender: "ai",
          text: "I apologize. An error occurred in the server gateway while running the cognitive optimization model. Please verify your connection to the RhinoLogistics API.",
          timestamp: new Date().toLocaleTimeString()
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div id="ai_advisor_section" className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[550px]">
      {/* Preloaded questions sidebar */}
      <div id="advisor_questions" className="lg:col-span-4 bg-white/3 border border-steel p-4 flex flex-col justify-between">
        <div className="space-y-4">
          <div>
            <div className="text-[10px] tracking-widest text-copper font-mono uppercase font-bold mb-1">Rhino Bank Logistics Advisory</div>
            <h3 className="text-sm font-semibold text-white font-mono flex items-center gap-1.5 uppercase">
              <HelpCircle className="w-4 h-4 text-copper" />
              ANALYTICAL PROMPTS
            </h3>
            <p className="text-[11px] text-stone font-sans mt-1">
              Select an institutional-grade query below to run automated econometric forecasts and route simulations.
            </p>
          </div>

          <div className="space-y-2">
            {preloadedQuestions.map((q, idx) => (
              <button
                key={idx}
                disabled={isLoading}
                onClick={() => handleSendMessage(q)}
                className="w-full text-left p-3 rounded-none bg-graphite border border-steel hover:border-copper/40 text-stone/80 hover:text-white transition-all text-[11px] font-sans leading-normal cursor-pointer disabled:opacity-50"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        <div className="pt-3 border-t border-steel/40 text-[10px] text-steel flex items-center gap-1 font-mono">
          <Sparkles className="w-3.5 h-3.5 text-copper/60" />
          Powered by Gemini 2.5 Flash
        </div>
      </div>

      {/* Main chat window */}
      <div id="advisor_chat_window" className="lg:col-span-8 bg-white/3 border border-steel flex flex-col justify-between overflow-hidden">
        {/* Chat Header */}
        <div className="px-4 py-3 border-b border-steel bg-graphite flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-xs font-mono font-bold text-white flex items-center gap-1">
              <Bot className="w-4 h-4 text-copper" />
              RhinoLogistics AI Advisor
            </span>
          </div>
          <span className="text-[10px] font-mono text-steel uppercase">Rhino Bank Transport Desk</span>
        </div>

        {/* Chat Message logs */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 font-mono text-xs">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex gap-3 max-w-[85%] ${m.sender === "user" ? "ml-auto flex-row-reverse" : "mr-auto"}`}
            >
              {/* Profile Icon */}
              <div
                className={`w-7 h-7 rounded-none flex items-center justify-center border shrink-0 ${
                  m.sender === "user" ? "bg-white/10 border-steel text-copper" : "bg-graphite border-steel text-copper"
                }`}
              >
                {m.sender === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              {/* Message text bubble */}
              <div
                className={`p-3.5 rounded-none leading-relaxed border ${
                  m.sender === "user"
                    ? "bg-graphite border-steel text-white"
                    : "bg-graphite border-steel text-stone/90 font-sans"
                }`}
              >
                {m.sender === "user" ? (
                  <p className="whitespace-pre-line font-mono text-[11px]">{m.text}</p>
                ) : (
                  <div className="space-y-3">
                    <p className="whitespace-pre-line text-xs font-sans text-stone/95 leading-relaxed">
                      {m.text}
                    </p>

                    {/* Grounding sources links */}
                    {m.groundingSources && m.groundingSources.length > 0 && (
                      <div className="pt-2.5 border-t border-steel/40 text-[10px] text-steel space-y-1">
                        <div className="font-bold uppercase font-mono text-[9px] text-steel/60">Cognitive Citations & Grounding</div>
                        <div className="flex flex-wrap gap-2 pt-0.5">
                          {m.groundingSources.map((src, i) => (
                            <a
                              key={i}
                              href={src.uri}
                              target="_blank"
                              rel="noreferrer"
                              className="text-copper/90 hover:text-copper flex items-center gap-1 font-mono hover:underline"
                            >
                              <ExternalLink className="w-3 h-3" />
                              {src.title}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
                <div className="text-[8px] text-steel mt-2 font-mono text-right">{m.timestamp}</div>
              </div>
            </div>
          ))}

          {/* Loading Indicator */}
          {isLoading && (
            <div className="flex gap-3 max-w-[80%] mr-auto items-center text-steel text-[11px]">
              <div className="w-7 h-7 rounded-none bg-graphite border border-steel text-copper flex items-center justify-center shrink-0">
                <Loader className="w-4 h-4 animate-spin text-copper" />
              </div>
              <span className="font-mono text-[10px] text-stone italic">Advisor is running Dijkstra matrices and ARIMA forecasting curves...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Text Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage(input);
          }}
          className="p-3 border-t border-steel bg-graphite flex gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isLoading}
            placeholder="Query about road networks, logistics finance, carbon models, Yorkshire corridors..."
            className="flex-1 bg-graphite border border-steel px-3.5 py-2 rounded-none text-xs font-mono text-white placeholder-steel focus:outline-none focus:border-copper/60 disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="bg-copper hover:bg-copper/95 text-white px-3.5 py-2 rounded-none transition-colors flex items-center gap-1 cursor-pointer disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
            <span className="text-xs font-sans font-bold hidden sm:inline">Send</span>
          </button>
        </form>
      </div>
    </div>
  );
}
