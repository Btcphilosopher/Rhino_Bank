import { useState } from "react";
import { LogisticsReport } from "../types";
import { FileText, Printer, Download, Eye, Table, CheckSquare } from "lucide-react";

export default function ReportView() {
  const [activeReportType, setActiveReportType] = useState<"daily" | "board" | "yorkshire">("board");

  const reports: Record<"daily" | "board" | "yorkshire", LogisticsReport> = {
    daily: {
      id: "rep_daily_01",
      title: "Daily Operations & Dispatch Summary",
      type: "daily",
      createdDate: new Date().toLocaleDateString(),
      summary: "High-level summary of active UK freight movements. Peak congestion observed at Dover and Felixstowe ports. Doncaster Rail interchange operating with 100% path capacity. Yorkshire corridors (Leeds DC, Hull) have optimal transit flow.",
      metrics: {
        "Active Dispatches": 45,
        "Total Tonnage Moved": "4,250 tonnes",
        "On-Time Performance": "94.2%",
        "Active Bottlenecks": 2,
        "Daily Carbon Output": "122.5 tonnes CO₂"
      },
      recommendations: [
        "Re-route South-bound road consignments away from Dartford Crossing due to peak congestion queues.",
        "Consolidate bulk steel moves from Sheffield Industrial onto evening Doncaster rail paths to optimize driver shifts."
      ]
    },
    board: {
      id: "rep_board_01",
      title: "Executive Board Quarterly Logistics Briefing",
      type: "board",
      createdDate: new Date().toLocaleDateString(),
      summary: "Rhino Bank Transport Finance review. Multimodal integration of Yorkshire and Humber ports displays strong performance. Shifting bulk agricultural cargo from road to rail on regional routes has successfully compressed structural carbon intensity and mitigated driver labor bottlenecks.",
      metrics: {
        "Freight Performance Index (FPI)": "88.5 / 100",
        "Quarterly Fleet Utilisation": "84.1%",
        "CO₂ Intensity Reduction": "18.2% YoY",
        "Average Transit Delay": "0.4 hrs / 100km",
        "Rail Freight Tonnage Growth": "+12.4%"
      },
      recommendations: [
        "Increase commercial lending exposure to Humber maritime terminal expansion projects.",
        "Advise industrial advisory clients to maintain a 15% contingency reserve in logistics capital accounts for North Sea fuel price shocks."
      ]
    },
    yorkshire: {
      id: "rep_york_01",
      title: "Yorkshire & Humber Regional Infrastructure Planning Brief",
      type: "infra",
      createdDate: new Date().toLocaleDateString(),
      summary: "Advanced planning analysis focusing on Yorkshire and Humber logistics clusters. Includes evaluation of the Port of Grimsby & Immingham capacity, Doncaster Rail interchange bottlenecks, and the M62/A1(M) corridor flow.",
      metrics: {
        "Grimsby/Immingham Daily Capacity": "150,000 tonnes",
        "Doncaster Rail Interchange Paths": "24 / day active",
        "M62 Average Transit Speed": "72.4 km/h",
        "Yorkshire Regional FPI": "91.2 / 100",
        "Electrification Completion": "82%"
      },
      recommendations: [
        "Accelerate funding for the Humber-Pennine rail electrification loop to support zero-emissions intermodal container pathways.",
        "Designate the Leeds DC corridor as an electric HGV priority zone to optimize regional battery charging grid allocations."
      ]
    }
  };

  const activeReport = reports[activeReportType];

  // Actual CSV Exporter
  const handleExportCSV = () => {
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += `Report,${activeReport.title}\n`;
    csvContent += `Date,${activeReport.createdDate}\n`;
    csvContent += `Summary,"${activeReport.summary}"\n\n`;
    csvContent += "Metric,Value\n";

    Object.entries(activeReport.metrics).forEach(([key, val]) => {
      csvContent += `"${key}","${val}"\n`;
    });

    csvContent += "\nRecommendations\n";
    activeReport.recommendations.forEach((rec, idx) => {
      csvContent += `"${idx + 1}","${rec}"\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `rhinologistics_report_${activeReportType}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div id="reporting_module" className="grid grid-cols-1 xl:grid-cols-12 gap-6 font-mono text-xs">
      {/* Report selector cards */}
      <div id="report_categories" className="xl:col-span-4 bg-white/3 border border-steel p-4 flex flex-col gap-4">
        <div>
          <div className="text-[10px] tracking-widest text-copper uppercase font-bold mb-1">Corporate Reporting Desk</div>
          <h3 className="text-sm font-semibold text-white uppercase flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-copper" />
            LOGISTICS BOARDROOM
          </h3>
          <p className="text-[11px] text-stone font-sans mt-1">
            Generate and export fully detailed logistics briefings, operations sheets, and carbon declarations.
          </p>
        </div>

        {/* Report triggers */}
        <div className="space-y-2.5">
          <button
            onClick={() => setActiveReportType("board")}
            className={`w-full text-left p-3 rounded-none border transition-all cursor-pointer flex justify-between items-center ${
              activeReportType === "board"
                ? "bg-copper/10 border-copper text-copper"
                : "bg-graphite border border-steel text-stone/80 hover:border-copper/40"
            }`}
          >
            <div className="min-w-0">
              <div className="font-bold text-[11px]">Executive Board Report</div>
              <div className="text-[9px] text-steel font-sans mt-0.5">Macro financial & carbon metrics.</div>
            </div>
            <Eye className="w-4 h-4 shrink-0 opacity-60" />
          </button>

          <button
            onClick={() => setActiveReportType("daily")}
            className={`w-full text-left p-3 rounded-none border transition-all cursor-pointer flex justify-between items-center ${
              activeReportType === "daily"
                ? "bg-copper/10 border-copper text-copper"
                : "bg-graphite border border-steel text-stone/80 hover:border-copper/40"
            }`}
          >
            <div className="min-w-0">
              <div className="font-bold text-[11px]">Daily Operations Brief</div>
              <div className="text-[9px] text-steel font-sans mt-0.5">Operational dispatch, tolls, delays.</div>
            </div>
            <Eye className="w-4 h-4 shrink-0 opacity-60" />
          </button>

          <button
            onClick={() => setActiveReportType("yorkshire")}
            className={`w-full text-left p-3 rounded-none border transition-all cursor-pointer flex justify-between items-center ${
              activeReportType === "yorkshire"
                ? "bg-copper/10 border-copper text-copper"
                : "bg-graphite border border-steel text-stone/80 hover:border-copper/40"
            }`}
          >
            <div className="min-w-0">
              <div className="font-bold text-[11px]">Yorkshire Infrastructure Planning</div>
              <div className="text-[9px] text-steel font-sans mt-0.5">Regional Grimsby/Doncaster studies.</div>
            </div>
            <Eye className="w-4 h-4 shrink-0 opacity-60" />
          </button>
        </div>
      </div>

      {/* Structured report preview sheet */}
      <div id="report_preview" className="xl:col-span-8 bg-white/3 border border-steel p-6 flex flex-col justify-between overflow-hidden">
        {/* Printable styled page container */}
        <div className="bg-graphite border border-steel p-6 rounded-none text-stone space-y-5 print:bg-white print:text-black">
          {/* Letterhead */}
          <div className="flex justify-between items-start border-b border-steel pb-4">
            <div>
              <div className="text-[10px] uppercase font-bold tracking-widest text-copper print:text-copper">Institutional Decision Support</div>
              <h2 className="text-sm font-bold text-white print:text-black uppercase">{activeReport.title}</h2>
              <div className="text-[9px] text-steel mt-0.5">Ref: RHINOLOGISTICS-{activeReport.id.toUpperCase()}</div>
            </div>
            <div className="text-right">
              <div className="text-[10px] font-bold text-white uppercase font-mono">RHINO BANK PLC</div>
              <div className="text-[9px] text-steel">Corporate Advisory</div>
              <div className="text-[9px] text-steel mt-1">Date: {activeReport.createdDate}</div>
            </div>
          </div>

          {/* Summary Block */}
          <div className="space-y-1.5">
            <span className="text-[10px] text-steel uppercase font-bold flex items-center gap-1">
              <Table className="w-3.5 h-3.5 text-copper" />
              1.0 Executive Narrative
            </span>
            <p className="font-sans text-xs text-stone leading-relaxed print:text-slate-800">
              {activeReport.summary}
            </p>
          </div>

          {/* Metrics List Table */}
          <div className="space-y-2">
            <span className="text-[10px] text-steel uppercase font-bold">2.0 Key Performance Statistics</span>
            <div className="border border-steel rounded-none overflow-hidden bg-white/3">
              <table className="w-full text-[10px]">
                <thead>
                  <tr className="bg-white/5 border-b border-steel text-steel">
                    <th className="text-left p-2.5">Performance Vector</th>
                    <th className="text-right p-2.5">Metric Evaluation</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(activeReport.metrics).map(([key, val]) => (
                    <tr key={key} className="border-b border-steel last:border-0 hover:bg-white/5">
                      <td className="p-2.5 font-sans text-stone">{key}</td>
                      <td className="p-2.5 text-right font-bold text-white">{val}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Recommendations checklist */}
          <div className="space-y-2">
            <span className="text-[10px] text-steel uppercase font-bold flex items-center gap-1">
              <CheckSquare className="w-3.5 h-3.5 text-copper" />
              3.0 Advisory Interventions
            </span>
            <ul className="space-y-1.5 list-none">
              {activeReport.recommendations.map((rec, idx) => (
                <li key={idx} className="flex gap-2.5 items-start text-xs font-sans text-stone leading-relaxed">
                  <span className="w-4 h-4 rounded-none bg-copper/10 text-copper flex items-center justify-center border border-copper/30 font-mono text-[9px] font-bold shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Exporter buttons */}
        <div className="pt-5 border-t border-steel/40 mt-5 flex justify-end gap-3 print:hidden">
          <button
            onClick={handlePrint}
            className="bg-graphite border border-steel hover:border-copper/40 text-stone hover:text-white px-4 py-2 rounded-none font-sans font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Briefing
          </button>
          <button
            onClick={handleExportCSV}
            className="bg-copper hover:bg-copper/90 text-white px-4 py-2 rounded-none font-sans font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            Export Raw CSV
          </button>
        </div>
      </div>
    </div>
  );
}
