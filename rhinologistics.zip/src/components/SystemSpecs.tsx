import { useState } from "react";
import { SystemTestResult } from "../types";
import { Code, Terminal, CheckCircle, Play, Settings2, Cpu } from "lucide-react";

export default function SystemSpecs() {
  const [activeTab, setActiveTab] = useState<"rust" | "r" | "db" | "ops" | "tests">("rust");
  const [testLogs, setTestLogs] = useState<SystemTestResult[]>([]);
  const [isRunningTests, setIsRunningTests] = useState(false);

  // Simulated codebases
  const codeTemplates = {
    rust: `// RhinoLogistics Optimisation Suite - Rust Workspace Core
// file: routing_engine/src/algorithms/dijkstra.rs

use std::collections::{BinaryHeap, HashMap};
use std::cmp::Ordering;

#[derive(Copy, Clone, Eq, PartialEq)]
struct State {
    cost: u32,
    position: usize,
}

impl Ord for State {
    fn cmp(&self, other: &Self) -> Ordering {
        other.cost.cmp(&self.cost) // Min-heap for Dijkstra pathing
    }
}

impl PartialOrd for State {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

pub struct Edge {
    pub node_id: usize,
    pub distance_km: u32,
    pub base_fuel_liters: u32,
    pub carbon_g_co2: u32,
    pub weight_mode: String,
}

pub struct NetworkGraph {
    pub adjacency_list: Vec<Vec<Edge>>,
}

impl NetworkGraph {
    pub fn dijkstra(
        &self, 
        start: usize, 
        goal: usize, 
        optimise_by: &str
    ) -> Option<(Vec<usize>, u32)> {
        let mut dist: Vec<u32> = (0..self.adjacency_list.len()).map(|_| u32::MAX).collect();
        let mut heap = BinaryHeap::new();
        let mut previous: HashMap<usize, usize> = HashMap::new();

        dist[start] = 0;
        heap.push(State { cost: 0, position: start });

        while let Some(State { cost, position }) = heap.pop() {
            if position == goal {
                let mut path = vec![goal];
                let mut curr = goal;
                while let Some(&prev) = previous.get(&curr) {
                    path.push(prev);
                    curr = prev;
                    if curr == start { break; }
                }
                path.reverse();
                return Some((path, cost));
            }

            if cost > dist[position] { continue; }

            for edge in &self.adjacency_list[position] {
                let weight = match optimise_by {
                    "distance" => edge.distance_km,
                    "fuel" => edge.base_fuel_liters,
                    "carbon" => edge.carbon_g_co2,
                    _ => edge.distance_km,
                };

                let next = State { cost: cost + weight, position: edge.node_id };
                if next.cost < dist[next.position] {
                    dist[next.position] = next.cost;
                    previous.insert(next.position, position);
                    heap.push(next);
                }
            }
        }
        None
    }
}`,
    r: `# RhinoLogistics Forecaster - Quantitative Forecasting Layer (R)
# file: r_analytics/models/demand_forecast.R

library(forecast)
library(dplyr)
library(lubridate)
library(xgboost)

#' Fit ARIMA-ETS hybrid forecasting curves for regional weekly tonnage
#' @param history_df data.frame containing date, industrial, retail, agricultural
#' @return list containing forecasting curves and prediction matrices
fit_regional_demand <- function(history_df) {
  # Coerce dates and arrange
  history_df <- history_df %>%
    mutate(date = as.Date(date)) %>%
    arrange(date)
    
  # Convert to weekly Time Series
  retail_ts <- ts(history_df$retail, frequency = 52, start = c(2026, 1))
  industrial_ts <- ts(history_df$industrial, frequency = 52, start = c(2026, 1))
  
  # 1. Fit ARIMA (Auto-Regressive Integrated Moving Average)
  fit_retail_arima <- auto.arima(
    retail_ts, 
    stepwise = TRUE, 
    approximation = FALSE,
    trace = FALSE
  )
  
  # 2. Fit ETS (Exponential Smoothing State Space)
  fit_industrial_ets <- ets(industrial_ts, model = "ZZZ")
  
  # Forecast next 4 periods (Weeks)
  forecast_retail <- forecast(fit_retail_arima, h = 4, level = c(80, 95))
  forecast_industrial <- forecast(fit_industrial_ets, h = 4, level = c(80, 95))
  
  # 3. XGBoost formulation for port volumes (High-frequency covariates)
  port_matrix <- model.matrix(portVolume ~ . - date, data = history_df)
  xgb_train <- xgb.DMatrix(data = port_matrix, label = history_df$portVolume)
  
  xgb_model <- xgboost(
    data = xgb_train,
    max_depth = 4,
    eta = 0.3,
    nrounds = 50,
    objective = "reg:squarederror",
    verbose = 0
  )
  
  return(list(
    retail_forecast = forecast_retail,
    industrial_forecast = forecast_industrial,
    xgb_model = xgb_model
  ))
}`,
    db: `-- PostgreSQL Relational Database Schema
-- file: database/migrations/01_init_logistics_tables.sql

CREATE TABLE IF NOT EXISTS freight_nodes (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(32) CHECK (type IN ('port', 'dc', 'rail_terminal', 'airport', 'industrial_cluster')),
    latitude DECIMAL(9,6) NOT NULL,
    longitude DECIMAL(9,6) NOT NULL,
    region VARCHAR(128) NOT NULL,
    capacity_tonnes_day INTEGER NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS freight_connections (
    id VARCHAR(64) PRIMARY KEY,
    from_node_id VARCHAR(64) REFERENCES freight_nodes(id) ON DELETE CASCADE,
    to_node_id VARCHAR(64) REFERENCES freight_nodes(id) ON DELETE CASCADE,
    mode VARCHAR(16) CHECK (mode IN ('road', 'rail', 'sea', 'air')),
    distance_km NUMERIC(6,2) NOT NULL,
    base_time_hours NUMERIC(4,2) NOT NULL,
    base_toll_cost NUMERIC(8,2) NOT NULL,
    base_fuel_liters NUMERIC(8,2) NOT NULL,
    carbon_emissions_kg NUMERIC(8,2) NOT NULL,
    restricted BOOLEAN DEFAULT FALSE,
    restriction_reason TEXT
);

CREATE TABLE IF NOT EXISTS fleet_registry (
    id VARCHAR(64) PRIMARY KEY,
    vehicle_type VARCHAR(128) NOT NULL,
    mode VARCHAR(16) NOT NULL,
    capacity_tonnes INTEGER NOT NULL,
    fuel_type VARCHAR(32) CHECK (fuel_type IN ('diesel', 'electric', 'LNG', 'hybrid')),
    current_depot_id VARCHAR(64) REFERENCES freight_nodes(id),
    status VARCHAR(32) DEFAULT 'idle'
);

-- Optimize routing queries on nodes and geo bounds
CREATE INDEX IF NOT EXISTS idx_nodes_region ON freight_nodes(region);
CREATE INDEX IF NOT EXISTS idx_connections_from_to ON freight_connections(from_node_id, to_node_id);
CREATE INDEX IF NOT EXISTS idx_fleet_depot ON fleet_registry(current_depot_id);`,
    ops: `# Multi-Stage Dockerfile for High Performance Rust + R Dashboard
# file: devops/Dockerfile

# --- STAGE 1: Build high-performance Rust core ---
FROM rust:1.75-slim as rust-builder
WORKDIR /usr/src/rhinologistics
COPY Cargo.toml Cargo.lock ./
COPY routing_engine/ ./routing_engine
RUN cargo build --release --workspace

# --- STAGE 2: Build advanced R runtime and Shiny ---
FROM rocker/r-ver:4.3.2 as runner
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    libssl-dev \\
    libcurl4-openssl-dev \\
    libxml2-dev \\
    && rm -rf /var/lib/apt/lists/*

# Install analytical R packages
RUN R -e "install.packages(c('forecast', 'dplyr', 'ggplot2', 'xgboost', 'shiny'), repos='https://cloud.r-project.org')"

# Copy compiled Rust binaries from Stage 1
COPY --from=rust-builder /usr/src/rhinologistics/target/release/routing_api /app/bin/routing_api
COPY r_analytics/ /app/r_analytics

EXPOSE 3000
CMD ["/app/bin/routing_api", "--r-path", "/app/r_analytics/app.R"]`
  };

  const runSystemTests = () => {
    setIsRunningTests(true);
    setTestLogs([]);

    const tests: SystemTestResult[] = [
      { id: "t1", name: "test_dijkstra_pathfinding_correctness", engine: "rust", durationMs: 0.12, status: "pending", output: "Running path calculations over M1/M62 network graph..." },
      { id: "t2", name: "test_yens_k_shortest_alternatives_uniqueness", engine: "rust", durationMs: 0.28, status: "pending", output: "Evaluating distinct alternate matrices..." },
      { id: "t3", name: "test_capacitated_vrp_fleet_allocation_greedy", engine: "rust", durationMs: 0.42, status: "pending", output: "Solving CVRP heuristics for 15 nodes, 4 depots..." },
      { id: "t4", name: "test_arima_seasonality_and_drift_convergence", engine: "r", durationMs: 42.15, status: "pending", output: "Fitting auto.arima parameter grids..." },
      { id: "t5", name: "test_ets_exponential_state_smoothing", engine: "r", durationMs: 38.40, status: "pending", output: "Evaluating state space models on 12-week time-series..." },
      { id: "t6", name: "test_postgres_routing_index_hits", engine: "db", durationMs: 1.85, status: "pending", output: "Running EXPLAIN ANALYZE on node distance queries..." },
      { id: "t7", name: "test_rest_grpc_gateway_roundtrip_latency", engine: "api", durationMs: 2.10, status: "pending", output: "Pinging gRPC gateway and checking JSON marshaling..." }
    ];

    let currentIdx = 0;

    const interval = setInterval(() => {
      if (currentIdx < tests.length) {
        setTestLogs((prev) => {
          const updated = [...prev];
          const test = { ...tests[currentIdx], status: "passed" as const };
          test.output = `SUCCESS: ${test.name} passed in ${test.durationMs}ms with 0 failures. code_coverage: 96.8%`;
          updated.push(test);
          return updated;
        });
        currentIdx++;
      } else {
        clearInterval(interval);
        setIsRunningTests(false);
      }
    }, 400);
  };

  return (
    <div id="system_specs_module" className="bg-white/3 border border-steel p-5 flex flex-col font-mono text-xs">
      <div className="border-b border-steel pb-4 mb-5 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
        <div>
          <div className="text-[10px] tracking-widest text-copper uppercase font-bold mb-1">RhinoLogistics Technical Architecture</div>
          <h3 className="text-sm font-semibold text-white uppercase flex items-center gap-1.5">
            <Cpu className="w-4 h-4 text-copper" />
            ENGINE SPECS & BENCHMARKS
          </h3>
          <p className="text-[11px] text-stone font-sans mt-0.5">
            Explore compiled Rust routines, R forecasting algorithms, database schemas, and trigger live performance tests.
          </p>
        </div>

        {/* Tab triggers */}
        <div className="flex flex-wrap gap-1 bg-graphite p-1 rounded-none border border-steel">
          {(["rust", "r", "db", "ops", "tests"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3 py-1 rounded-none text-[10px] font-bold uppercase transition-colors cursor-pointer ${
                activeTab === tab ? "bg-copper text-white" : "text-stone/60 hover:text-stone"
              }`}
            >
              {tab === "ops" ? "Docker/K8s" : tab === "db" ? "PostgreSQL" : tab}
            </button>
          ))}
        </div>
      </div>

      {/* Code Editor Body / Test terminal */}
      <div className="flex-1 bg-graphite border border-steel rounded-none overflow-hidden min-h-[420px] flex flex-col">
        {/* Editor tab bar */}
        <div className="px-4 py-2 border-b border-steel/60 bg-white/5 flex justify-between items-center text-[10px] text-steel">
          <span className="flex items-center gap-1.5 font-bold">
            <Code className="w-3.5 h-3.5 text-copper" />
            {activeTab === "rust"
              ? "routing_engine/src/algorithms/dijkstra.rs (Rust Core)"
              : activeTab === "r"
              ? "r_analytics/models/demand_forecast.R (R Analytics)"
              : activeTab === "db"
              ? "database/migrations/01_init_logistics_tables.sql (PostgreSQL)"
              : activeTab === "ops"
              ? "devops/Dockerfile (Kubernetes CI/CD)"
              : "RhinoLogistics Testing Console & Benchmark Harness"}
          </span>
          <span className="font-mono text-steel/60">UTF-8</span>
        </div>

        {/* Code viewing window / Tests console */}
        <div className="flex-1 p-4 overflow-y-auto max-h-[380px] leading-relaxed text-stone/90 font-mono text-[10.5px]">
          {activeTab !== "tests" ? (
            <pre className="whitespace-pre overflow-x-auto text-stone/90 select-text">
              <code>{codeTemplates[activeTab]}</code>
            </pre>
          ) : (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center bg-white/5 p-3 rounded-none border border-steel gap-2">
                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-white uppercase flex items-center gap-1.5">
                    <Terminal className="w-4 h-4 text-emerald-500" />
                    Rust & R Unit Testing Suite
                  </span>
                  <p className="text-[10px] text-stone font-sans">
                    Execute the local Rust Dijktra pathfinders and R forecast fits in a sandbox container environment to verify execution convergence.
                  </p>
                </div>
                <button
                  onClick={runSystemTests}
                  disabled={isRunningTests}
                  className="bg-copper hover:bg-copper/90 disabled:bg-stone/20 text-white font-sans font-bold px-4 py-2 rounded-none text-xs flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed transition-colors shrink-0"
                >
                  <Play className="w-3.5 h-3.5 fill-white" />
                  {isRunningTests ? "RUNNING..." : "RUN SUITE"}
                </button>
              </div>

              {/* Logs terminal output */}
              <div className="bg-graphite border border-steel p-3 rounded-none min-h-[220px] space-y-1.5 text-stone/60">
                <div className="text-[9px] text-steel font-bold border-b border-steel pb-1 mb-2 uppercase">TERMINAL OUTPUT LOGS</div>
                {testLogs.length === 0 && !isRunningTests && (
                  <div className="text-steel/50 italic text-center pt-8">
                    Press 'RUN SUITE' to trigger cargo test benchmarks and forecast grid convergence.
                  </div>
                )}
                {testLogs.map((log) => (
                  <div key={log.id} className="flex items-start gap-2 text-[10px]">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                    <div className="space-y-0.5">
                      <span className="text-white font-bold">[{log.engine.toUpperCase()}] {log.name}</span>
                      <p className="text-emerald-400 font-mono text-[9px]">{log.output}</p>
                    </div>
                  </div>
                ))}
                {isRunningTests && testLogs.length < 7 && (
                  <div className="text-copper text-[10px] animate-pulse flex items-center gap-1.5 pt-2">
                    <Settings2 className="w-3.5 h-3.5 animate-spin" />
                    Running quantitative constraints checks...
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
