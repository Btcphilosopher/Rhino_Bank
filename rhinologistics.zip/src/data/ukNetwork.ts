import { NetworkNode, NetworkConnection, FleetVehicle, SimulationScenario } from "../types";

export const UK_NODES: NetworkNode[] = [
  {
    id: "port_grimsby_immingham",
    name: "Port of Grimsby & Immingham",
    type: "port",
    lat: 53.6163,
    lng: -0.1947,
    region: "Yorkshire and the Humber",
    capacity: 150000,
    currentThroughput: 132000,
    congestionLevel: 0.15,
    activeFleets: 45,
    carbonScore: 4, // B
    details: "Largest port in the UK by tonnage. Handles dry bulk, liquid fuels, roll-on/roll-off cargo, and major biomass imports for power generation."
  },
  {
    id: "port_hull",
    name: "Port of Hull",
    type: "port",
    lat: 53.7431,
    lng: -0.3349,
    region: "Yorkshire and the Humber",
    capacity: 90000,
    currentThroughput: 72000,
    congestionLevel: 0.25,
    activeFleets: 28,
    carbonScore: 3, // C
    details: "Key North Sea trade hub specializing in timber, steel, agribulks, and chemicals, with high-frequency container services to northern Europe."
  },
  {
    id: "leeds_dc",
    name: "Leeds Distribution Centre",
    type: "dc",
    lat: 53.8008,
    lng: -1.5491,
    region: "Yorkshire and the Humber",
    capacity: 120000,
    currentThroughput: 108000,
    congestionLevel: 0.42,
    activeFleets: 65,
    carbonScore: 2, // D
    details: "Critical central distribution hub. Located adjacent to the M1 and M62 intersection, managing major grocery, retail, and industrial distribution."
  },
  {
    id: "doncaster_rail",
    name: "Doncaster Rail Terminal",
    type: "rail_terminal",
    lat: 53.5228,
    lng: -1.1311,
    region: "Yorkshire and the Humber",
    capacity: 80000,
    currentThroughput: 64000,
    congestionLevel: 0.20,
    activeFleets: 18,
    carbonScore: 5, // A
    details: "Strategic rail freight interchange on the East Coast Main Line. Facilitates high-speed containerised rail freight transfers and locomotive servicing."
  },
  {
    id: "sheffield_industrial",
    name: "Sheffield Industrial Cluster",
    type: "industrial_cluster",
    lat: 53.3811,
    lng: -1.4701,
    region: "Yorkshire and the Humber",
    capacity: 100000,
    currentThroughput: 85000,
    congestionLevel: 0.35,
    activeFleets: 32,
    carbonScore: 2, // D
    details: "Advanced steel, metallurgy, and engineering cluster. Moves heavy manufacturing components, specialized alloys, and industrial machinery."
  },
  {
    id: "port_felixstowe",
    name: "Port of Felixstowe",
    type: "port",
    lat: 51.9631,
    lng: 1.3513,
    region: "East of England",
    capacity: 220000,
    currentThroughput: 212000,
    congestionLevel: 0.78,
    activeFleets: 94,
    carbonScore: 3, // C
    details: "UK's busiest container port, handling over 4 million TEUs per year. Crucial for global deep-sea trade lanes from Asia and the Americas."
  },
  {
    id: "port_southampton",
    name: "Port of Southampton",
    type: "port",
    lat: 50.9097,
    lng: -1.4044,
    region: "South East",
    capacity: 160000,
    currentThroughput: 144000,
    congestionLevel: 0.55,
    activeFleets: 58,
    carbonScore: 4, // B
    details: "Premier automotive export port and major container terminal, equipped with excellent direct rail freight paths to the Midlands and North."
  },
  {
    id: "port_dover",
    name: "Port of Dover",
    type: "port",
    lat: 51.1278,
    lng: 1.3134,
    region: "South East",
    capacity: 180000,
    currentThroughput: 171000,
    congestionLevel: 0.85,
    activeFleets: 82,
    carbonScore: 1, // E
    details: "The world's busiest roll-on/roll-off ferry port. Serves as the primary trade gateway between Great Britain and continental Europe."
  },
  {
    id: "london_gateway",
    name: "London Gateway Logistics Park",
    type: "dc",
    lat: 51.5120,
    lng: 0.4630,
    region: "London & South East",
    capacity: 140000,
    currentThroughput: 121000,
    congestionLevel: 0.48,
    activeFleets: 72,
    carbonScore: 4, // B
    details: "State-of-the-art deep-sea port and co-located logistics park, serving the immense London consumer market with automated rail and road distribution."
  },
  {
    id: "birmingham_dc",
    name: "Birmingham Logistics Hub",
    type: "dc",
    lat: 52.4862,
    lng: -1.8904,
    region: "West Midlands",
    capacity: 160000,
    currentThroughput: 152000,
    congestionLevel: 0.72,
    activeFleets: 88,
    carbonScore: 2, // D
    details: "The heart of the 'Golden Triangle' logistics region. Connected directly to M5, M6, and M42 motorways, distributing across 90% of the UK within 4 hours."
  },
  {
    id: "manchester_dc",
    name: "Manchester Freight Terminal",
    type: "dc",
    lat: 53.4808,
    lng: -2.2426,
    region: "North West",
    capacity: 110000,
    currentThroughput: 94000,
    congestionLevel: 0.50,
    activeFleets: 48,
    carbonScore: 3, // C
    details: "Major multi-modal hub serving the North West industrial belt, combining motorway logistics, rail terminals, and proximity to Manchester Ship Canal."
  },
  {
    id: "bristol_dc",
    name: "Bristol Gateway DC",
    type: "dc",
    lat: 51.4545,
    lng: -2.5879,
    region: "South West",
    capacity: 90000,
    currentThroughput: 78000,
    congestionLevel: 0.30,
    activeFleets: 30,
    carbonScore: 3, // C
    details: "South West logistics gateway linked to the M4/M5 corridor. Manages consumer retail, fresh foods, and aerospace logistics streams."
  },
  {
    id: "newcastle_port",
    name: "Port of Tyne (Newcastle)",
    type: "port",
    lat: 54.9783,
    lng: -1.6178,
    region: "North East",
    capacity: 70000,
    currentThroughput: 53000,
    congestionLevel: 0.18,
    activeFleets: 20,
    carbonScore: 4, // B
    details: "Deepwater port handling car exports, forest products, bulk goods, and supporting offshore green energy fields in the North Sea."
  },
  {
    id: "glasgow_rail",
    name: "Glasgow Euroterminal",
    type: "rail_terminal",
    lat: 55.8642,
    lng: -4.2518,
    region: "Scotland",
    capacity: 75000,
    currentThroughput: 59000,
    congestionLevel: 0.12,
    activeFleets: 15,
    carbonScore: 5, // A
    details: "Principal intermodal rail terminal in Scotland, linking northern industrial and retail flows to the English rail freight network."
  }
];

export const UK_CONNECTIONS: NetworkConnection[] = [
  // --- Road connections (major motorways) ---
  {
    id: "road_leeds_grimsby",
    from: "leeds_dc",
    to: "port_grimsby_immingham",
    mode: "road",
    distanceKm: 112,
    avgTimeHrs: 1.5,
    baseTollCost: 0,
    baseFuelLiters: 38,
    restricted: false,
    carbonEmissionsKg: 102.6
  },
  {
    id: "road_leeds_hull",
    from: "leeds_dc",
    to: "port_hull",
    mode: "road",
    distanceKm: 92,
    avgTimeHrs: 1.2,
    baseTollCost: 2.50, // Humber bridge / minor tolls simulation
    baseFuelLiters: 31,
    restricted: false,
    carbonEmissionsKg: 84.2
  },
  {
    id: "road_leeds_sheffield",
    from: "leeds_dc",
    to: "sheffield_industrial",
    mode: "road",
    distanceKm: 48,
    avgTimeHrs: 0.7,
    baseTollCost: 0,
    baseFuelLiters: 16,
    restricted: false,
    carbonEmissionsKg: 43.5
  },
  {
    id: "road_leeds_doncaster",
    from: "leeds_dc",
    to: "doncaster_rail",
    mode: "road",
    distanceKm: 45,
    avgTimeHrs: 0.6,
    baseTollCost: 0,
    baseFuelLiters: 15,
    restricted: false,
    carbonEmissionsKg: 40.5
  },
  {
    id: "road_doncaster_sheffield",
    from: "doncaster_rail",
    to: "sheffield_industrial",
    mode: "road",
    distanceKm: 32,
    avgTimeHrs: 0.5,
    baseTollCost: 0,
    baseFuelLiters: 11,
    restricted: false,
    carbonEmissionsKg: 29.8
  },
  {
    id: "road_doncaster_grimsby",
    from: "doncaster_rail",
    to: "port_grimsby_immingham",
    mode: "road",
    distanceKm: 78,
    avgTimeHrs: 1.1,
    baseTollCost: 0,
    baseFuelLiters: 26,
    restricted: false,
    carbonEmissionsKg: 70.2
  },
  {
    id: "road_manchester_leeds",
    from: "manchester_dc",
    to: "leeds_dc",
    mode: "road",
    distanceKm: 64,
    avgTimeHrs: 1.1, // High congestion over the Pennines (M62)
    baseTollCost: 0,
    baseFuelLiters: 24,
    restricted: false,
    carbonEmissionsKg: 64.8
  },
  {
    id: "road_birmingham_leeds",
    from: "birmingham_dc",
    to: "leeds_dc",
    mode: "road",
    distanceKm: 185,
    avgTimeHrs: 2.3,
    baseTollCost: 0,
    baseFuelLiters: 63,
    restricted: false,
    carbonEmissionsKg: 170.1
  },
  {
    id: "road_birmingham_manchester",
    from: "birmingham_dc",
    to: "manchester_dc",
    mode: "road",
    distanceKm: 135,
    avgTimeHrs: 1.8,
    baseTollCost: 12.00, // M6 Toll simulation
    baseFuelLiters: 46,
    restricted: false,
    carbonEmissionsKg: 124.2
  },
  {
    id: "road_london_birmingham",
    from: "london_gateway",
    to: "birmingham_dc",
    mode: "road",
    distanceKm: 195,
    avgTimeHrs: 2.5,
    baseTollCost: 0,
    baseFuelLiters: 66,
    restricted: false,
    carbonEmissionsKg: 178.2
  },
  {
    id: "road_london_felixstowe",
    from: "london_gateway",
    to: "port_felixstowe",
    mode: "road",
    distanceKm: 130,
    avgTimeHrs: 1.7,
    baseTollCost: 2.50, // Dartford Crossing simulation
    baseFuelLiters: 44,
    restricted: false,
    carbonEmissionsKg: 118.8
  },
  {
    id: "road_london_dover",
    from: "london_gateway",
    to: "port_dover",
    mode: "road",
    distanceKm: 122,
    avgTimeHrs: 1.6,
    baseTollCost: 0,
    baseFuelLiters: 41,
    restricted: false,
    carbonEmissionsKg: 110.7
  },
  {
    id: "road_london_southampton",
    from: "london_gateway",
    to: "port_southampton",
    mode: "road",
    distanceKm: 155,
    avgTimeHrs: 2.1,
    baseTollCost: 0,
    baseFuelLiters: 53,
    restricted: false,
    carbonEmissionsKg: 143.1
  },
  {
    id: "road_bristol_birmingham",
    from: "bristol_dc",
    to: "birmingham_dc",
    mode: "road",
    distanceKm: 142,
    avgTimeHrs: 1.8,
    baseTollCost: 0,
    baseFuelLiters: 48,
    restricted: false,
    carbonEmissionsKg: 129.6
  },
  {
    id: "road_bristol_london",
    from: "bristol_dc",
    to: "london_gateway",
    mode: "road",
    distanceKm: 198,
    avgTimeHrs: 2.4,
    baseTollCost: 0,
    baseFuelLiters: 67,
    restricted: false,
    carbonEmissionsKg: 180.9
  },
  {
    id: "road_newcastle_leeds",
    from: "newcastle_port",
    to: "leeds_dc",
    mode: "road",
    distanceKm: 158,
    avgTimeHrs: 2.0,
    baseTollCost: 0,
    baseFuelLiters: 54,
    restricted: false,
    carbonEmissionsKg: 145.8
  },
  {
    id: "road_newcastle_glasgow",
    from: "newcastle_port",
    to: "glasgow_rail",
    mode: "road",
    distanceKm: 242,
    avgTimeHrs: 3.1,
    baseTollCost: 0,
    baseFuelLiters: 82,
    restricted: false,
    carbonEmissionsKg: 221.4
  },
  {
    id: "road_manchester_glasgow",
    from: "manchester_dc",
    to: "glasgow_rail",
    mode: "road",
    distanceKm: 345,
    avgTimeHrs: 4.2,
    baseTollCost: 0,
    baseFuelLiters: 117,
    restricted: false,
    carbonEmissionsKg: 315.9
  },

  // --- Rail connections (freight trains, low carbon emissions) ---
  {
    id: "rail_doncaster_grimsby",
    from: "doncaster_rail",
    to: "port_grimsby_immingham",
    mode: "rail",
    distanceKm: 76,
    avgTimeHrs: 1.3,
    baseTollCost: 45, // Rail track access charges simulated
    baseFuelLiters: 200, // Mega diesel locomotive equivalent liters or power draw
    restricted: false,
    carbonEmissionsKg: 22.8 // Extremely low per-tonne-km emissions
  },
  {
    id: "rail_doncaster_london",
    from: "doncaster_rail",
    to: "london_gateway",
    mode: "rail",
    distanceKm: 248,
    avgTimeHrs: 3.2,
    baseTollCost: 150,
    baseFuelLiters: 620,
    restricted: false,
    carbonEmissionsKg: 74.4
  },
  {
    id: "rail_manchester_leeds",
    from: "manchester_dc",
    to: "leeds_dc",
    mode: "rail",
    distanceKm: 62,
    avgTimeHrs: 1.2,
    baseTollCost: 40,
    baseFuelLiters: 155,
    restricted: false,
    carbonEmissionsKg: 18.6
  },
  {
    id: "rail_birmingham_london",
    from: "birmingham_dc",
    to: "london_gateway",
    mode: "rail",
    distanceKm: 188,
    avgTimeHrs: 2.5,
    baseTollCost: 110,
    baseFuelLiters: 470,
    restricted: false,
    carbonEmissionsKg: 56.4
  },
  {
    id: "rail_southampton_birmingham",
    from: "port_southampton",
    to: "birmingham_dc",
    mode: "rail",
    distanceKm: 215,
    avgTimeHrs: 2.8,
    baseTollCost: 130,
    baseFuelLiters: 538,
    restricted: false,
    carbonEmissionsKg: 64.5
  },
  {
    id: "rail_felixstowe_birmingham",
    from: "port_felixstowe",
    to: "birmingham_dc",
    mode: "rail",
    distanceKm: 260,
    avgTimeHrs: 3.5,
    baseTollCost: 160,
    baseFuelLiters: 650,
    restricted: false,
    carbonEmissionsKg: 78.0
  },
  {
    id: "rail_doncaster_glasgow",
    from: "doncaster_rail",
    to: "glasgow_rail",
    mode: "rail",
    distanceKm: 395,
    avgTimeHrs: 4.8,
    baseTollCost: 240,
    baseFuelLiters: 980,
    restricted: false,
    carbonEmissionsKg: 118.5
  },
  {
    id: "rail_doncaster_newcastle",
    from: "doncaster_rail",
    to: "newcastle_port",
    mode: "rail",
    distanceKm: 162,
    avgTimeHrs: 2.1,
    baseTollCost: 100,
    baseFuelLiters: 405,
    restricted: false,
    carbonEmissionsKg: 48.6
  },

  // --- Sea routes (coastal shipping, very slow but massive capacity) ---
  {
    id: "sea_southampton_felixstowe",
    from: "port_southampton",
    to: "port_felixstowe",
    mode: "sea",
    distanceKm: 320,
    avgTimeHrs: 12.0,
    baseTollCost: 350,
    baseFuelLiters: 1800,
    restricted: false,
    carbonEmissionsKg: 144.0
  },
  {
    id: "sea_felixstowe_grimsby",
    from: "port_felixstowe",
    to: "port_grimsby_immingham",
    mode: "sea",
    distanceKm: 280,
    avgTimeHrs: 10.5,
    baseTollCost: 300,
    baseFuelLiters: 1580,
    restricted: false,
    carbonEmissionsKg: 126.0
  },
  {
    id: "sea_hull_newcastle",
    from: "port_hull",
    to: "newcastle_port",
    mode: "sea",
    distanceKm: 195,
    avgTimeHrs: 7.5,
    baseTollCost: 220,
    baseFuelLiters: 1100,
    restricted: false,
    carbonEmissionsKg: 87.8
  },
  {
    id: "sea_grimsby_hull",
    from: "port_grimsby_immingham",
    to: "port_hull",
    mode: "sea",
    distanceKm: 18,
    avgTimeHrs: 1.0,
    baseTollCost: 40,
    baseFuelLiters: 120,
    restricted: false,
    carbonEmissionsKg: 9.6
  }
];

export const INITIAL_FLEET: FleetVehicle[] = [
  { id: "v_rhino_01", type: "Standard HGV (Euro 6)", mode: "road", capacityTonnes: 26, currentPayload: 18, status: "idle", fuelType: "diesel", driverShift: "06:00 - 14:00", batteryOrFuelLevel: 85, depotId: "leeds_dc" },
  { id: "v_rhino_02", type: "Electric Arctic Truck", mode: "road", capacityTonnes: 44, currentPayload: 0, status: "charging", fuelType: "electric", driverShift: "08:00 - 16:00", batteryOrFuelLevel: 42, depotId: "leeds_dc" },
  { id: "v_rhino_03", type: "High-Capacity Bio-LNG Truck", mode: "road", capacityTonnes: 40, currentPayload: 32, status: "transit", fuelType: "LNG", driverShift: "14:00 - 22:00", batteryOrFuelLevel: 92, depotId: "birmingham_dc" },
  { id: "v_rhino_04", type: "Standard HGV (Euro 6)", mode: "road", capacityTonnes: 26, currentPayload: 22, status: "transit", fuelType: "diesel", driverShift: "06:00 - 14:00", batteryOrFuelLevel: 70, depotId: "london_gateway" },
  { id: "v_rhino_05", type: "Hydrogen Hybrid HGV", mode: "road", capacityTonnes: 40, currentPayload: 15, status: "idle", fuelType: "hybrid", driverShift: "18:00 - 02:00", batteryOrFuelLevel: 68, depotId: "manchester_dc" },
  { id: "v_rhino_06", type: "Freight Train (Class 66)", mode: "rail", capacityTonnes: 1200, currentPayload: 850, status: "transit", fuelType: "diesel", driverShift: "04:00 - 12:00", batteryOrFuelLevel: 75, depotId: "doncaster_rail" },
  { id: "v_rhino_07", type: "Electric Freight Train (Class 90)", mode: "rail", capacityTonnes: 1500, currentPayload: 1200, status: "idle", fuelType: "electric", driverShift: "08:00 - 16:00", batteryOrFuelLevel: 100, depotId: "doncaster_rail" },
  { id: "v_rhino_08", type: "Container Vessel (Feeder)", mode: "sea", capacityTonnes: 8000, currentPayload: 6200, status: "transit", fuelType: "diesel", driverShift: "Continuous Marine", batteryOrFuelLevel: 80, depotId: "port_grimsby_immingham" },
  { id: "v_rhino_09", type: "Eco Container Ship", mode: "sea", capacityTonnes: 12000, currentPayload: 0, status: "idle", fuelType: "LNG", driverShift: "Continuous Marine", batteryOrFuelLevel: 95, depotId: "port_felixstowe" }
];

export const SIMULATION_SCENARIOS: SimulationScenario[] = [
  {
    id: "scen_m62_closure",
    name: "Pennine Blizzard (M62 Closure)",
    description: "Heavy snow shuts down the M62 over the Pennines. Road connection between Manchester and Leeds is blocked; drivers must take substantial road diversions or switch to trans-Pennine rail routes.",
    type: "road_closure",
    active: false,
    affectedNodes: ["leeds_dc", "manchester_dc"],
    affectedConnections: ["road_manchester_leeds"],
    costMultiplier: 1.5,
    delayMultiplier: 2.2,
    carbonMultiplier: 1.3
  },
  {
    id: "scen_grimsby_congestion",
    name: "Storm Peak (Port Congestion)",
    description: "Severe North Sea storms cause ship backlogs and quay crane outages at the Port of Grimsby & Immingham. Terminal capacity is slashed by 60%, creating road/rail container delivery queues.",
    type: "port_congestion",
    active: false,
    affectedNodes: ["port_grimsby_immingham"],
    affectedConnections: ["road_leeds_grimsby", "rail_doncaster_grimsby", "road_doncaster_grimsby"],
    costMultiplier: 1.35,
    delayMultiplier: 1.9,
    carbonMultiplier: 1.15
  },
  {
    id: "scen_east_coast_signal",
    name: "ECML Power Failure (Rail Disruption)",
    description: "An overhead power cable collapse near Doncaster halts all electric trains on the East Coast Main Line. Diesel trains can bypass slowly, but electric rail freight is suspended.",
    type: "rail_disruption",
    active: false,
    affectedNodes: ["doncaster_rail"],
    affectedConnections: ["rail_doncaster_london", "rail_doncaster_glasgow", "rail_doncaster_newcastle"],
    costMultiplier: 1.4,
    delayMultiplier: 2.5,
    carbonMultiplier: 1.25
  },
  {
    id: "scen_fuel_price_surge",
    name: "Global Fuel Price Surge (+25%)",
    description: "A sudden supply disruption spikes international crude oil prices. Diesel fuel prices jump by 25%. Slashes margins for diesel trucks and trains, making electric/LNG freight highly competitive.",
    type: "fuel_shock",
    active: false,
    affectedNodes: [],
    affectedConnections: [],
    costMultiplier: 1.25, // Affects diesel-based routing cost
    delayMultiplier: 1.0,
    carbonMultiplier: 1.0
  },
  {
    id: "scen_yorkshire_rail_electrification",
    name: "Humber-Pennine Rail Electrification",
    description: "A major public-private infrastructure investment electrifies the entire rail link from Hull and Immingham through Doncaster and Leeds to Manchester. Slashes carbon by 85% and cuts transit delays.",
    type: "infra_investment",
    active: false,
    affectedNodes: ["port_grimsby_immingham", "port_hull", "leeds_dc", "doncaster_rail", "manchester_dc"],
    affectedConnections: ["rail_doncaster_grimsby", "rail_manchester_leeds"],
    costMultiplier: 0.8, // Decreased cost
    delayMultiplier: 0.85, // Decreased delay
    carbonMultiplier: 0.15 // 85% reduction in carbon emissions
  }
];
