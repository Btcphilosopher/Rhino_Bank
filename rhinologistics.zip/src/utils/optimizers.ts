import { NetworkNode, NetworkConnection, OptimisationResult, SimulationScenario, FleetVehicle } from "../types";
import { UK_NODES, UK_CONNECTIONS } from "../data/ukNetwork";

// Simple Dijkstra & Yen's K-shortest path solver
export function findOptimalRoute(
  startNodeId: string,
  endNodeId: string,
  modePreference: "all" | "road" | "rail" | "sea",
  optimiseFor: "distance" | "time" | "fuel" | "toll" | "carbon",
  activeScenarios: SimulationScenario[]
): OptimisationResult {
  // Filter connections based on mode preference
  let connections = [...UK_CONNECTIONS];
  if (modePreference !== "all") {
    connections = connections.filter((c) => c.mode === modePreference);
  }

  // Adjust connections based on active simulation scenarios
  const adjustedConnections = connections.map((conn) => {
    let costMult = 1.0;
    let delayMult = 1.0;
    let carbonMult = 1.0;
    let restricted = conn.restricted;
    let restrictionReason = conn.restrictionReason;

    for (const scen of activeScenarios) {
      if (scen.active) {
        // If connection itself is affected
        if (scen.affectedConnections.includes(conn.id)) {
          costMult *= scen.costMultiplier;
          delayMult *= scen.delayMultiplier;
          carbonMult *= scen.carbonMultiplier;
          if (scen.type === "road_closure" && conn.mode === "road") {
            restricted = true;
            restrictionReason = scen.name;
          }
          if (scen.type === "rail_disruption" && conn.mode === "rail") {
            restricted = true;
            restrictionReason = scen.name;
          }
        }
        // General fuel price surge affecting diesel haulage costs
        if (scen.type === "fuel_shock" && conn.mode === "road") {
          costMult *= scen.costMultiplier;
        }
      }
    }

    return {
      ...conn,
      distanceKm: conn.distanceKm,
      avgTimeHrs: conn.avgTimeHrs * delayMult,
      baseTollCost: conn.baseTollCost * costMult,
      baseFuelLiters: conn.baseFuelLiters * costMult,
      carbonEmissionsKg: conn.carbonEmissionsKg * carbonMult,
      restricted,
      restrictionReason
    };
  });

  // Dijkstra data structures
  const distances: Record<string, number> = {};
  const previous: Record<string, string | null> = {};
  const prevConnection: Record<string, any | null> = {};
  const unvisited = new Set<string>();

  UK_NODES.forEach((node) => {
    distances[node.id] = Infinity;
    previous[node.id] = null;
    prevConnection[node.id] = null;
    unvisited.add(node.id);
  });

  distances[startNodeId] = 0;

  while (unvisited.size > 0) {
    // Find node with minimum distance
    let currentNodeId: string | null = null;
    let minDistance = Infinity;

    unvisited.forEach((nodeId) => {
      if (distances[nodeId] < minDistance) {
        minDistance = distances[nodeId];
        currentNodeId = nodeId;
      }
    });

    if (currentNodeId === null || currentNodeId === endNodeId || minDistance === Infinity) {
      break;
    }

    unvisited.delete(currentNodeId);

    // Get outgoing connections from current node
    const outgoing = adjustedConnections.filter(
      (c) => c.from === currentNodeId && !c.restricted
    );

    for (const conn of outgoing) {
      const neighborId = conn.to;
      if (!unvisited.has(neighborId)) continue;

      // Determine weight
      let weight = 0;
      switch (optimiseFor) {
        case "distance":
          weight = conn.distanceKm;
          break;
        case "time":
          weight = conn.avgTimeHrs;
          break;
        case "fuel":
          weight = conn.baseFuelLiters;
          break;
        case "toll":
          weight = conn.baseTollCost;
          break;
        case "carbon":
          weight = conn.carbonEmissionsKg;
          break;
      }

      const alt = distances[currentNodeId] + weight;
      if (alt < distances[neighborId]) {
        distances[neighborId] = alt;
        previous[neighborId] = currentNodeId;
        prevConnection[neighborId] = conn;
      }
    }
  }

  // Build path
  const path: string[] = [];
  const pathConnections: NetworkConnection[] = [];
  let u: string | null = endNodeId;

  if (previous[u] !== null || u === startNodeId) {
    while (u !== null) {
      path.unshift(u);
      const conn = prevConnection[u];
      if (conn) {
        pathConnections.unshift(conn);
      }
      u = previous[u];
    }
  }

  // Calculate totals
  let totalDistanceKm = 0;
  let totalTimeHrs = 0;
  let totalFuelLiters = 0;
  let totalTollCost = 0;
  let totalCarbonKg = 0;
  const bottlenecksPassed: string[] = [];
  const vehicleWarnings: string[] = [];

  pathConnections.forEach((conn) => {
    totalDistanceKm += conn.distanceKm;
    totalTimeHrs += conn.avgTimeHrs;
    totalFuelLiters += conn.baseFuelLiters;
    totalTollCost += conn.baseTollCost;
    totalCarbonKg += conn.carbonEmissionsKg;

    // Check node congestion at destinations
    const destNode = UK_NODES.find((n) => n.id === conn.to);
    if (destNode && destNode.congestionLevel > 0.6) {
      bottlenecksPassed.push(`${destNode.name} (${Math.round(destNode.congestionLevel * 100)}% Congestion)`);
    }
  });

  // General constraints checks
  if (modePreference === "road" && totalDistanceKm > 300) {
    vehicleWarnings.push("Long haul road haulage exceeds standard 4.5-hour driver rest limits. Dual driver allocation recommended.");
  }
  if (modePreference === "rail") {
    const electricLines = activeScenarios.find((s) => s.id === "scen_yorkshire_rail_electrification" && s.active);
    if (!electricLines && path.includes("doncaster_rail")) {
      vehicleWarnings.push("Doncaster interchange is non-electrified on specific bypasses. Double check train locomotive class compatibility (Class 66 vs Class 90).");
    }
  }

  return {
    path,
    connections: pathConnections,
    totalDistanceKm,
    totalTimeHrs,
    totalFuelLiters,
    totalTollCost,
    totalCarbonKg,
    bottlenecksPassed: Array.from(new Set(bottlenecksPassed)),
    vehicleWarnings
  };
}

// Simulated Yen's K-Shortest Paths for alternative proposals
export function findKShortestPaths(
  startNodeId: string,
  endNodeId: string,
  modePreference: "all" | "road" | "rail" | "sea",
  optimiseFor: "distance" | "time" | "fuel" | "toll" | "carbon",
  activeScenarios: SimulationScenario[],
  k: number = 3
): OptimisationResult[] {
  const paths: OptimisationResult[] = [];
  const primary = findOptimalRoute(startNodeId, endNodeId, modePreference, optimiseFor, activeScenarios);

  if (primary.path.length === 0) return [];
  paths.push(primary);

  // For Yen's pathfinding, let's create alternate routes by slightly biasing or blocking the primary path's edges
  // to ensure realistic alternatives are generated for the demo
  const forbiddenConnectionIds = new Set<string>();

  for (let i = 1; i < k; i++) {
    // Exclude the most crucial connection from the last path
    const lastPath = paths[paths.length - 1];
    if (lastPath.connections.length === 0) break;

    // Find a connection to block (e.g. the longest or most central one)
    let maxCostConnId = lastPath.connections[0].id;
    let maxCost = -1;

    lastPath.connections.forEach((conn) => {
      if (!forbiddenConnectionIds.has(conn.id) && conn.distanceKm > maxCost) {
        maxCost = conn.distanceKm;
        maxCostConnId = conn.id;
      }
    });

    forbiddenConnectionIds.add(maxCostConnId);

    // Solve route with additional disabled connections
    let connections = [...UK_CONNECTIONS];
    if (modePreference !== "all") {
      connections = connections.filter((c) => c.mode === modePreference);
    }

    const modifiedScenarios = [
      ...activeScenarios,
      {
        id: "yen_block",
        name: "Yen Heuristic Divergence",
        description: "Artificially blocked for alternative routing",
        type: "road_closure" as const,
        active: true,
        affectedNodes: [],
        affectedConnections: Array.from(forbiddenConnectionIds),
        costMultiplier: 3.0,
        delayMultiplier: 3.0,
        carbonMultiplier: 3.0
      }
    ];

    const alternative = findOptimalRoute(startNodeId, endNodeId, modePreference, optimiseFor, modifiedScenarios);
    if (alternative.path.length > 0 && !paths.some((p) => p.path.join("-") === alternative.path.join("-"))) {
      paths.push(alternative);
    }
  }

  return paths;
}

// Capacitated Vehicle Routing Problem (VRP) Solver Simulation
// Groups order packages with weights into specific vehicle capacities and depots
export interface VrpJob {
  id: string;
  destinationNodeId: string;
  weightTonnes: number;
  deliveryWindow: string;
}

export interface VrpRoute {
  vehicleId: string;
  depotId: string;
  assignedJobs: VrpJob[];
  totalLoadTonnes: number;
  routeSequence: string[]; // Node IDs
  estimatedTimeHrs: number;
  fuelType: string;
}

export function solveCapacitatedVrp(
  depotId: string,
  jobs: VrpJob[],
  vehicles: FleetVehicle[]
): VrpRoute[] {
  // Filter vehicles stationed at the active depot and capable of road transport
  const activeVehicles = vehicles.filter(
    (v) => v.depotId === depotId && v.mode === "road" && v.status !== "maintenance"
  );

  if (activeVehicles.length === 0 || jobs.length === 0) return [];

  const routes: VrpRoute[] = activeVehicles.map((v) => ({
    vehicleId: v.id,
    depotId: v.depotId,
    assignedJobs: [],
    totalLoadTonnes: 0,
    routeSequence: [depotId],
    estimatedTimeHrs: 0,
    fuelType: v.fuelType
  }));

  // Simple greedy capacitated allocation
  const sortedJobs = [...jobs].sort((a, b) => b.weightTonnes - a.weightTonnes);

  sortedJobs.forEach((job) => {
    // Find vehicle with most capacity left
    let bestRoute: VrpRoute | null = null;
    let maxRemainingCapacity = -1;

    routes.forEach((r) => {
      const v = activeVehicles.find((veh) => veh.id === r.vehicleId)!;
      const remaining = v.capacityTonnes - r.totalLoadTonnes;
      if (remaining >= job.weightTonnes && remaining > maxRemainingCapacity) {
        maxRemainingCapacity = remaining;
        bestRoute = r;
      }
    });

    if (bestRoute) {
      (bestRoute as VrpRoute).assignedJobs.push(job);
      (bestRoute as VrpRoute).totalLoadTonnes += job.weightTonnes;
      (bestRoute as VrpRoute).routeSequence.push(job.destinationNodeId);
    }
  });

  // Calculate times and wrap back to depot
  routes.forEach((r) => {
    if (r.assignedJobs.length > 0) {
      r.routeSequence.push(depotId);

      // Compute estimated travel time sequentially
      let totalHrs = 0;
      for (let i = 0; i < r.routeSequence.length - 1; i++) {
        const from = r.routeSequence[i];
        const to = r.routeSequence[i + 1];
        const conn = UK_CONNECTIONS.find(
          (c) => (c.from === from && c.to === to) || (c.from === to && c.to === from)
        );
        totalHrs += conn ? conn.avgTimeHrs : 0.8;
      }
      r.estimatedTimeHrs = parseFloat(totalHrs.toFixed(2));
    }
  });

  return routes.filter((r) => r.assignedJobs.length > 0);
}

// Warehouse pick path optimization simulation
// Optimizes standard S-Shape vs Optimal heuristics for warehouse item picking
export function solveWarehousePickerPath(
  itemsToPick: { aisle: number; bay: number; category: string }[],
  strategy: "s_shape" | "optimal"
): { pathPoints: { x: number; y: number }[]; totalDistanceMeters: number } {
  // Simple warehouse grid coordinate calculations
  // Docks at x: 2, y: 15
  const startPoint = { x: 2, y: 15 };
  const points: { x: number; y: number }[] = [startPoint];

  // Aisle positions on X axis: Aisle 1 (x: 4), Aisle 2 (x: 8), Aisle 3 (x: 12), Aisle 4 (x: 16), Aisle 5 (x: 20)
  // Bays on Y axis: Bay 1 to 10 mapped from y: 2 to y: 12
  const mapItemToCoords = (item: { aisle: number; bay: number }) => {
    return {
      x: item.aisle * 4,
      y: 2 + (item.bay - 1) * 1.1
    };
  };

  const itemCoords = itemsToPick.map(mapItemToCoords);

  if (strategy === "s_shape") {
    // S-Shape visits aisles left to right, walking up and down adjacent aisles fully
    const groupedByAisle: Record<number, typeof itemCoords> = {};
    itemCoords.forEach((pt) => {
      const aisleNum = Math.round(pt.x / 4);
      if (!groupedByAisle[aisleNum]) groupedByAisle[aisleNum] = [];
      groupedByAisle[aisleNum].push(pt);
    });

    const sortedAisles = Object.keys(groupedByAisle)
      .map(Number)
      .sort((a, b) => a - b);

    let movingUp = true;
    sortedAisles.forEach((aisle) => {
      const aisleItems = groupedByAisle[aisle];
      // Sort items based on current direction
      aisleItems.sort((a, b) => (movingUp ? a.y - b.y : b.y - a.y));

      // Append entry point, items, then exit point of aisle
      points.push({ x: aisle * 4, y: movingUp ? 1 : 13 });
      aisleItems.forEach((pt) => points.push(pt));
      points.push({ x: aisle * 4, y: movingUp ? 13 : 1 });

      movingUp = !movingUp; // Reverse direction for next aisle
    });
  } else {
    // Optimal strategy (Nearest Neighbor approximation solver)
    const unvisited = [...itemCoords];
    let current = { ...startPoint };

    while (unvisited.length > 0) {
      let nearestIdx = -1;
      let minDistance = Infinity;

      for (let i = 0; i < unvisited.length; i++) {
        const dist = Math.hypot(unvisited[i].x - current.x, unvisited[i].y - current.y);
        if (dist < minDistance) {
          minDistance = dist;
          nearestIdx = i;
        }
      }

      current = unvisited.splice(nearestIdx, 1)[0];
      points.push(current);
    }
  }

  // End back at dock
  points.push(startPoint);

  // Compute Manhattan-style warehouse walking distance
  let totalDistanceMeters = 0;
  for (let i = 0; i < points.length - 1; i++) {
    const dx = Math.abs(points[i + 1].x - points[i].x);
    const dy = Math.abs(points[i + 1].y - points[i].y);
    totalDistanceMeters += (dx + dy) * 4; // Scale grid coords to meters
  }

  return {
    pathPoints: points,
    totalDistanceMeters: Math.round(totalDistanceMeters)
  };
}
