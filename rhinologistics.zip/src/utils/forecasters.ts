import { ForecastPoint, FpiComponents, SimulationScenario } from "../types";

// Generates historical demand and simulated R forecasting results with 80%/95% confidence intervals
export function generateDemandForecast(
  modelType: "arima" | "ets" | "xgboost",
  activeScenarios: SimulationScenario[]
): ForecastPoint[] {
  const data: ForecastPoint[] = [];
  const baseDate = new Date("2026-01-01");

  // Multipliers from active scenarios
  let retailMultiplier = 1.0;
  let industrialMultiplier = 1.0;
  let agriculturalMultiplier = 1.0;
  let portVolumeMultiplier = 1.0;

  activeScenarios.forEach((scen) => {
    if (scen.active) {
      if (scen.type === "demand_surge") {
        retailMultiplier *= 1.35;
        industrialMultiplier *= 1.20;
      }
      if (scen.type === "port_congestion") {
        portVolumeMultiplier *= 0.60; // Port throughput drops due to blockages
      }
      if (scen.type === "infra_investment") {
        industrialMultiplier *= 1.15;
        portVolumeMultiplier *= 1.10;
      }
    }
  });

  // 1. Generate 12 weeks of historical data (Weekly increments)
  for (let i = 0; i < 12; i++) {
    const dateStr = new Date(baseDate.getTime() + i * 7 * 24 * 60 * 60 * 1000)
      .toISOString()
      .split("T")[0];

    // Seasonal cycle: sine wave representing weekly/seasonal fluctuations
    const phase = (i / 12) * Math.PI * 2;
    const seasonality = Math.sin(phase) * 15;

    data.push({
      date: dateStr,
      retail: Math.round((280 + seasonality + Math.random() * 20) * retailMultiplier),
      industrial: Math.round((420 + Math.sin(phase * 1.5) * 25 + Math.random() * 30) * industrialMultiplier),
      agricultural: Math.round((120 + Math.cos(phase) * 40 + Math.random() * 15) * agriculturalMultiplier),
      portVolume: Math.round((650 + Math.sin(phase) * 80 + Math.random() * 50) * portVolumeMultiplier)
    });
  }

  // 2. Generate 4 weeks of future forecasts (R forecasting simulation)
  const lastHistoryDate = new Date(data[data.length - 1].date);

  for (let i = 1; i <= 4; i++) {
    const dateStr = new Date(lastHistoryDate.getTime() + i * 7 * 24 * 60 * 60 * 1000)
      .toISOString()
      .split("T")[0];

    const phase = ((i + 11) / 12) * Math.PI * 2;
    const seasonality = Math.sin(phase) * 15;

    // Base values before forecasting noise
    const rawRetail = 280 + seasonality;
    const rawIndustrial = 420 + Math.sin(phase * 1.5) * 25;
    const rawAgricultural = 120 + Math.cos(phase) * 40;
    const rawPortVolume = 650 + Math.sin(phase) * 80;

    // Apply algorithm differences for visual authenticity of ARIMA vs ETS vs XGBoost
    let algBias = 0;
    let confidenceIntervalWidth = 0.10 * i; // error propagates outward

    if (modelType === "arima") {
      // ARIMA is smoother, represents auto-regressive moving average trends
      algBias = Math.sin(i) * 5;
    } else if (modelType === "ets") {
      // Exponential Smoothing gives heavier weights to recent trends
      algBias = (i - 2.5) * 8;
      confidenceIntervalWidth = 0.08 * i;
    } else {
      // XGBoost catches non-linear seasonal splits, slightly more rugged
      algBias = (i % 2 === 0 ? 12 : -10);
      confidenceIntervalWidth = 0.12 * i;
    }

    const forecastedRetail = Math.round((rawRetail + algBias) * retailMultiplier);
    const forecastedIndustrial = Math.round((rawIndustrial - algBias * 0.5) * industrialMultiplier);
    const forecastedAgricultural = Math.round((rawAgricultural + algBias * 1.2) * agriculturalMultiplier);
    const forecastedPortVolume = Math.round((rawPortVolume + algBias * 1.5) * portVolumeMultiplier);

    data.push({
      date: dateStr,
      retail: 0, // Not available for future
      industrial: 0,
      agricultural: 0,
      portVolume: 0,
      forecastedRetail,
      forecastedIndustrial,
      forecastedAgricultural,
      forecastedPortVolume,
      // Confidence intervals for rendering
      lowerCI: Math.round(forecastedRetail * (1 - confidenceIntervalWidth)),
      upperCI: Math.round(forecastedRetail * (1 + confidenceIntervalWidth))
    });
  }

  return data;
}

// Calculate cost metrics per tonne, km, delivery
export function calculateCostAnalytics(
  totalTonnage: number,
  totalKm: number,
  mode: "road" | "rail" | "sea" | "all"
) {
  let fuelEfficiency = 32.5; // Liters per 100km standard
  let costPerKm = 1.45; // GBP
  let driverLabourHr = 18.50; // GBP
  let carbonGramsPerTonneKm = 62; // Standard road HGV

  if (mode === "rail") {
    fuelEfficiency = 185; // Massive rail haulage draws
    costPerKm = 4.20;
    driverLabourHr = 28.00;
    carbonGramsPerTonneKm = 15; // 76% cleaner than road
  } else if (mode === "sea") {
    fuelEfficiency = 950;
    costPerKm = 8.50;
    driverLabourHr = 42.00;
    carbonGramsPerTonneKm = 8; // Ultra efficient on massive scale
  } else if (mode === "all") {
    fuelEfficiency = 85.0;
    costPerKm = 2.10;
    driverLabourHr = 22.00;
    carbonGramsPerTonneKm = 42;
  }

  const fuelCost = totalKm * (fuelEfficiency / 100) * 1.42; // GBP 1.42 per liter
  const driverCost = (totalKm / 80) * driverLabourHr; // 80 km/h average speed assumed
  const maintenanceCost = totalKm * 0.22;
  const adminAndWarehouse = totalTonnage * 8.50;

  const totalCost = fuelCost + driverCost + maintenanceCost + adminAndWarehouse;

  return {
    totalCost: parseFloat(totalCost.toFixed(2)),
    costPerTonne: parseFloat((totalCost / (totalTonnage || 1)).toFixed(2)),
    costPerKm: parseFloat((totalCost / (totalKm || 1)).toFixed(2)),
    carbonEmissionsTonnes: parseFloat(((totalTonnage * totalKm * carbonGramsPerTonneKm) / 1000000).toFixed(2)),
    fuelCost: parseFloat(fuelCost.toFixed(2)),
    labourCost: parseFloat(driverCost.toFixed(2)),
    maintenanceCost: parseFloat(maintenanceCost.toFixed(2)),
    overheadCost: parseFloat(adminAndWarehouse.toFixed(2))
  };
}

// Compute Freight Performance Index (FPI) composite index based on adjustable weights
export function calculateFpi(
  weights: Record<keyof FpiComponents, number>,
  activeScenarios: SimulationScenario[]
): { compositeIndex: number; components: FpiComponents } {
  // Base values for perfect day
  let reliabilityVal = 97.4;
  let utilisationVal = 82.1;
  let transitTimeVal = 88.5; // inverse penalty score
  let carbonIntensityVal = 92.0; // efficiency
  let costEfficiencyVal = 84.6;
  let railUtilisationVal = 68.2;

  // Apply scenario impacts
  activeScenarios.forEach((scen) => {
    if (scen.active) {
      if (scen.type === "road_closure") {
        reliabilityVal -= 12.5;
        transitTimeVal -= 18.0;
        costEfficiencyVal -= 6.5;
      }
      if (scen.type === "port_congestion") {
        reliabilityVal -= 8.0;
        utilisationVal -= 14.2;
        costEfficiencyVal -= 10.4;
      }
      if (scen.type === "rail_disruption") {
        railUtilisationVal -= 42.0;
        reliabilityVal -= 5.0;
        costEfficiencyVal -= 4.2;
      }
      if (scen.type === "fuel_shock") {
        costEfficiencyVal -= 18.5;
        utilisationVal += 4.5; // consolidate loads to save fuel
      }
      if (scen.type === "infra_investment") {
        carbonIntensityVal += 6.8;
        transitTimeVal += 8.2;
        railUtilisationVal += 12.4;
        costEfficiencyVal += 5.0;
      }
    }
  });

  const components: FpiComponents = {
    reliability: Math.max(0, Math.min(100, parseFloat(reliabilityVal.toFixed(1)))),
    utilisation: Math.max(0, Math.min(100, parseFloat(utilisationVal.toFixed(1)))),
    transitTime: Math.max(0, Math.min(100, parseFloat(transitTimeVal.toFixed(1)))),
    carbonIntensity: Math.max(0, Math.min(100, parseFloat(carbonIntensityVal.toFixed(1)))),
    costEfficiency: Math.max(0, Math.min(100, parseFloat(costEfficiencyVal.toFixed(1)))),
    railUtilisation: Math.max(0, Math.min(100, parseFloat(railUtilisationVal.toFixed(1))))
  };

  // Compute weighted sum
  const totalWeight = Object.values(weights).reduce((sum, w) => sum + w, 0);
  let weightedSum = 0;

  (Object.keys(components) as Array<keyof FpiComponents>).forEach((key) => {
    weightedSum += components[key] * (weights[key] || 0);
  });

  const compositeIndex = parseFloat((weightedSum / (totalWeight || 1)).toFixed(1));

  return {
    compositeIndex,
    components
  };
}
