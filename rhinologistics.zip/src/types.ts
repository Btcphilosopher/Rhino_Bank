export interface NetworkNode {
  id: string;
  name: string;
  type: "port" | "dc" | "rail_terminal" | "airport" | "industrial_cluster";
  lat: number;
  lng: number;
  region: string;
  capacity: number; // in tonnes per day
  currentThroughput: number; // in tonnes per day
  congestionLevel: number; // 0.0 to 1.0
  activeFleets: number;
  carbonScore: number; // A-E or numeric
  details: string;
}

export interface NetworkConnection {
  id: string;
  from: string;
  to: string;
  mode: "road" | "rail" | "sea" | "air";
  distanceKm: number;
  avgTimeHrs: number;
  baseTollCost: number;
  baseFuelLiters: number;
  restricted: boolean;
  restrictionReason?: string;
  carbonEmissionsKg: number;
}

export interface FleetVehicle {
  id: string;
  type: string;
  mode: "road" | "rail" | "sea" | "air";
  capacityTonnes: number;
  currentPayload: number;
  status: "idle" | "transit" | "maintenance" | "charging";
  fuelType: "diesel" | "electric" | "LNG" | "hybrid";
  driverShift: string;
  batteryOrFuelLevel: number; // %
  depotId: string;
  nextRefuelTime?: string;
}

export interface OptimisationResult {
  path: string[]; // Node IDs
  connections: NetworkConnection[];
  totalDistanceKm: number;
  totalTimeHrs: number;
  totalFuelLiters: number;
  totalTollCost: number;
  totalCarbonKg: number;
  bottlenecksPassed: string[];
  vehicleWarnings: string[];
}

export interface ForecastPoint {
  date: string;
  retail: number;
  industrial: number;
  agricultural: number;
  portVolume: number;
  forecastedRetail?: number;
  forecastedIndustrial?: number;
  forecastedAgricultural?: number;
  forecastedPortVolume?: number;
  lowerCI?: number;
  upperCI?: number;
}

export interface FpiComponents {
  reliability: number; // weight & value
  utilisation: number;
  transitTime: number;
  carbonIntensity: number;
  costEfficiency: number;
  railUtilisation: number;
}

export interface WarehouseRack {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  category: string;
  occupancy: number; // %
}

export interface WarehouseDock {
  id: string;
  name: string;
  status: "available" | "busy" | "blocked";
  assignedVehicle?: string;
  queueLength: number;
}

export interface SimulationScenario {
  id: string;
  name: string;
  description: string;
  type: "road_closure" | "port_congestion" | "rail_disruption" | "fuel_shock" | "infra_investment" | "demand_surge";
  active: boolean;
  affectedNodes: string[];
  affectedConnections: string[];
  costMultiplier: number;
  delayMultiplier: number;
  carbonMultiplier: number;
}

export interface ChatMessage {
  id: string;
  sender: "user" | "ai";
  text: string;
  timestamp: string;
  groundingSources?: { uri: string; title: string }[];
}

export interface SystemTestResult {
  id: string;
  name: string;
  engine: "rust" | "r" | "api" | "db";
  durationMs: number;
  status: "passed" | "failed" | "pending";
  output: string;
}

export interface LogisticsReport {
  id: string;
  title: string;
  type: "daily" | "weekly" | "monthly" | "board" | "warehouse" | "rail" | "infra";
  createdDate: string;
  summary: string;
  metrics: Record<string, number | string>;
  recommendations: string[];
}
