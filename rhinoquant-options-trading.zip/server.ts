import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { getMarketQuote, generateOptionChain, getScannerData } from "./src/services/syntheticMarketData";
import { calculateBlackScholes } from "./src/quant/blackScholes";
import { calculateBinomialTree } from "./src/quant/binomialTree";
import { calculateMonteCarlo } from "./src/quant/monteCarlo";
import { solveImpliedVolatility } from "./src/quant/impliedVolatility";
import { generateVolatilitySurface } from "./src/quant/volatilitySurface";
import { evaluateStrategy } from "./src/quant/strategyEngine";
import { calculatePortfolioRisk } from "./src/quant/riskEngine";
import { runBacktest } from "./src/quant/backtestEngine";
import { MockBrokerAdapter } from "./src/services/brokerAdapter";

async function startServer() {
  const app = express();
  const PORT = 3000;
  const broker = new MockBrokerAdapter();
  await broker.connect();

  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ONLINE",
      version: "3.6.0-PROD",
      dataLatencyMs: 0.8,
      engine: "RhinoQuant Analytical Core",
      timestamp: new Date().toISOString(),
    });
  });

  app.get("/api/market/:symbol", (req, res) => {
    const symbol = req.params.symbol;
    const quote = getMarketQuote(symbol);
    res.json(quote);
  });

  app.get("/api/options/:symbol/chain", (req, res) => {
    const symbol = req.params.symbol;
    const chain = generateOptionChain(symbol);
    res.json(chain);
  });

  app.get("/api/volatility/:symbol", (req, res) => {
    const symbol = req.params.symbol;
    const quote = getMarketQuote(symbol);
    const volData = generateVolatilitySurface(symbol, quote.price, quote.iv);
    res.json(volData);
  });

  app.get("/api/scanner", (req, res) => {
    const items = getScannerData();
    res.json(items);
  });

  app.post("/api/pricing/black-scholes", (req, res) => {
    const { type, S, K, T, r, sigma, q } = req.body;
    const result = calculateBlackScholes(
      type || 'call',
      Number(S) || 100,
      Number(K) || 100,
      Number(T) || 0.082,
      Number(r) || 0.045,
      Number(sigma) || 0.25,
      Number(q) || 0
    );
    res.json(result);
  });

  app.post("/api/pricing/binomial", (req, res) => {
    const { type, S, K, T, r, sigma, steps, isAmerican, q } = req.body;
    const result = calculateBinomialTree(
      type || 'call',
      Number(S) || 100,
      Number(K) || 100,
      Number(T) || 0.082,
      Number(r) || 0.045,
      Number(sigma) || 0.25,
      Number(steps) || 50,
      isAmerican !== false,
      Number(q) || 0
    );
    res.json(result);
  });

  app.post("/api/pricing/monte-carlo", (req, res) => {
    const { type, S, K, T, r, sigma, numSimulations, timeSteps, seed } = req.body;
    const result = calculateMonteCarlo(
      type || 'call',
      Number(S) || 100,
      Number(K) || 100,
      Number(T) || 0.082,
      Number(r) || 0.045,
      Number(sigma) || 0.25,
      Number(numSimulations) || 10000,
      Number(timeSteps) || 50,
      Number(seed) || 42
    );
    res.json(result);
  });

  app.post("/api/pricing/iv-solver", (req, res) => {
    const { marketPrice, type, S, K, T, r, q } = req.body;
    const iv = solveImpliedVolatility(
      Number(marketPrice) || 5.0,
      type || 'call',
      Number(S) || 100,
      Number(K) || 100,
      Number(T) || 0.082,
      Number(r) || 0.045,
      Number(q) || 0
    );
    res.json({ impliedVolatility: iv });
  });

  app.post("/api/strategies/analyze", (req, res) => {
    const { symbol, spotPrice, legs, dteShift, volShift } = req.body;
    const evaluation = evaluateStrategy(
      symbol || 'NVDA',
      Number(spotPrice) || 128.50,
      legs || [],
      0.045,
      Number(dteShift) || 0,
      Number(volShift) || 0
    );
    res.json(evaluation);
  });

  app.get("/api/portfolio", async (req, res) => {
    const account = await broker.getAccount();
    const positions = await broker.getPositions();
    const risk = calculatePortfolioRisk(positions, account.portfolioValue);
    res.json({ account, positions, risk });
  });

  app.post("/api/risk/scenario", async (req, res) => {
    const positions = await broker.getPositions();
    const risk = calculatePortfolioRisk(positions);
    res.json(risk);
  });

  app.post("/api/backtest", (req, res) => {
    const config = req.body;
    const result = runBacktest(config);
    res.json(result);
  });

  app.post("/api/orders", async (req, res) => {
    const orderReq = req.body;
    const order = await broker.submitOrder(orderReq);
    res.json(order);
  });

  app.get("/api/orders", async (req, res) => {
    const orders = await broker.getOrders();
    res.json(orders);
  });

  // Vite middleware in Development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[RhinoQuant Terminal Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
