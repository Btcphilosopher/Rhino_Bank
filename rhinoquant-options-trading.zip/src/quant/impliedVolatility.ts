import { calculateBlackScholes } from './blackScholes';

/**
 * Robust Implied Volatility Solver combining Newton-Raphson & Brent's Bisection fallback.
 */
export function solveImpliedVolatility(
  marketPrice: number,
  type: 'call' | 'put',
  S: number,
  K: number,
  T: number,
  r: number,
  q: number = 0,
  initialVolGuess: number = 0.25,
  maxIterations: number = 50,
  tolerance: number = 1e-6
): number {
  if (marketPrice <= 0 || T <= 0) return 0;

  // Intrinsic lower bound check
  const intrinsic = type === 'call' ? Math.max(0, S - K) : Math.max(0, K - S);
  if (marketPrice <= intrinsic) return 0.0001;

  let vol = initialVolGuess;

  // 1. Newton-Raphson Iteration
  for (let i = 0; i < maxIterations; i++) {
    const res = calculateBlackScholes(type, S, K, T, r, vol, q);
    const diff = res.price - marketPrice;

    if (Math.abs(diff) < tolerance) {
      return Math.max(0.0001, vol);
    }

    // Vega is in 1% change, convert to rate dPrice/dVol
    const vegaScale = res.vega * 100;
    if (vegaScale > 1e-7) {
      const nextVol = vol - diff / vegaScale;
      if (nextVol > 0.001 && nextVol < 5.0) {
        vol = nextVol;
        continue;
      }
    }

    // Fallback to bisection if Newton step breaks bounds
    break;
  }

  // 2. Bisection / Brent Fallback Method
  let low = 0.001;
  let high = 5.0;

  for (let step = 0; step < 40; step++) {
    vol = (low + high) / 2;
    const res = calculateBlackScholes(type, S, K, T, r, vol, q);
    const diff = res.price - marketPrice;

    if (Math.abs(diff) < tolerance) {
      return vol;
    }

    if (diff > 0) {
      high = vol;
    } else {
      low = vol;
    }
  }

  return Math.max(0.0001, vol);
}
