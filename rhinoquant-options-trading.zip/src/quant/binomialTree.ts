/**
 * Cox-Ross-Rubinstein American Option Binomial Tree Engine
 */

export interface BinomialTreeResult {
  price: number;
  delta: number;
  gamma: number;
  theta: number;
  steps: number;
  treeNodes: { step: number; spot: number; optionValue: number; exercised: boolean }[];
}

export function calculateBinomialTree(
  type: 'call' | 'put',
  S: number,
  K: number,
  T: number,
  r: number,
  sigma: number,
  steps: number = 50,
  isAmerican: boolean = true,
  q: number = 0
): BinomialTreeResult {
  if (T <= 0 || steps < 1) {
    const payoff = type === 'call' ? Math.max(0, S - K) : Math.max(0, K - S);
    return { price: payoff, delta: 0, gamma: 0, theta: 0, steps, treeNodes: [] };
  }

  const dt = T / steps;
  const u = Math.exp(sigma * Math.sqrt(dt));
  const d = 1 / u;
  const p = (Math.exp((r - q) * dt) - d) / (u - d);
  const discount = Math.exp(-r * dt);

  // Asset prices at expiration
  const assetPrices: number[] = new Array(steps + 1);
  const optionValues: number[] = new Array(steps + 1);

  for (let j = 0; j <= steps; j++) {
    assetPrices[j] = S * Math.pow(u, steps - j) * Math.pow(d, j);
    optionValues[j] = type === 'call'
      ? Math.max(0, assetPrices[j] - K)
      : Math.max(0, K - assetPrices[j]);
  }

  const treeNodes: { step: number; spot: number; optionValue: number; exercised: boolean }[] = [];

  // Backward induction
  let prevStepValues = [...optionValues];
  let twoStepValues: number[] = [];

  for (let i = steps - 1; i >= 0; i--) {
    const currentValues: number[] = new Array(i + 1);
    for (let j = 0; j <= i; j++) {
      const spot = S * Math.pow(u, i - j) * Math.pow(d, j);
      const continuation = discount * (p * optionValues[j] + (1 - p) * optionValues[j + 1]);
      const intrinsic = type === 'call' ? Math.max(0, spot - K) : Math.max(0, K - spot);

      let value = continuation;
      let exercised = false;
      if (isAmerican && intrinsic > continuation) {
        value = intrinsic;
        exercised = true;
      }

      currentValues[j] = value;
      if (i <= 4) { // Keep early step nodes for tree visualization
        treeNodes.push({ step: i, spot, optionValue: value, exercised });
      }
    }

    if (i === 2) {
      twoStepValues = [...currentValues];
    }
    for (let j = 0; j <= i; j++) {
      optionValues[j] = currentValues[j];
    }
  }

  const price = optionValues[0];

  // Calculate Delta, Gamma, Theta from initial tree nodes
  const spotUp = S * u;
  const spotDown = S * d;
  const valUp = prevStepValues[0];
  const valDown = prevStepValues[1];

  const delta = (valUp - valDown) / (spotUp - spotDown);

  let gamma = 0;
  if (twoStepValues.length >= 3) {
    const valUpUp = twoStepValues[0];
    const valUpDown = twoStepValues[1];
    const valDownDown = twoStepValues[2];
    const h1 = S * u * u - S;
    const h2 = S - S * d * d;
    const deltaUp = (valUpUp - valUpDown) / (S * u * u - S);
    const deltaDown = (valUpDown - valDownDown) / (S - S * d * d);
    gamma = 2 * (deltaUp - deltaDown) / (h1 + h2);
  }

  const theta = (twoStepValues[1] - price) / (2 * dt * 365);

  return {
    price,
    delta,
    gamma,
    theta,
    steps,
    treeNodes,
  };
}
