import { PortfolioPosition, RiskScenarioResult } from '../types';

/**
 * Institutional Portfolio Risk & Stress-Testing Subsystem
 */

export interface PortfolioRiskSummary {
  portfolioValue: number;
  netDelta: number;
  netGamma: number;
  netVega: number;
  netTheta: number;
  var95Dollar: number;
  var99Dollar: number;
  expectedShortfall95: number;
  stressScenarios: RiskScenarioResult[];
  riskMatrix: { spotChange: number; volChange: number; pnl: number }[];
  concentrationRisk: { symbol: string; weightPercent: number; deltaContribution: number }[];
}

export function calculatePortfolioRisk(
  positions: PortfolioPosition[],
  portfolioValue: number = 1250000
): PortfolioRiskSummary {
  let netDelta = 0;
  let netGamma = 0;
  let netVega = 0;
  let netTheta = 0;

  const symbolMap: Record<string, { marketValue: number; delta: number }> = {};

  positions.forEach((pos) => {
    netDelta += pos.delta;
    netGamma += pos.gamma;
    netVega += pos.vega;
    netTheta += pos.theta;

    if (!symbolMap[pos.underlyingSymbol]) {
      symbolMap[pos.underlyingSymbol] = { marketValue: 0, delta: 0 };
    }
    symbolMap[pos.underlyingSymbol].marketValue += pos.marketValue;
    symbolMap[pos.underlyingSymbol].delta += pos.delta;
  });

  const concentrationRisk = Object.keys(symbolMap).map((sym) => ({
    symbol: sym,
    weightPercent: Number(((Math.abs(symbolMap[sym].marketValue) / portfolioValue) * 100).toFixed(1)),
    deltaContribution: Number(symbolMap[sym].delta.toFixed(2)),
  }));

  // Historical VaR / Parametric VaR (daily 1-day)
  // Parametric VaR = Z * Portfolio_StdDev
  const dailyVol = 0.015; // 1.5% daily volatility
  const var95Dollar = portfolioValue * 1.645 * dailyVol;
  const var99Dollar = portfolioValue * 2.326 * dailyVol;
  const expectedShortfall95 = var95Dollar * 1.25; // Expected loss given VaR exceeded

  // Stress Scenarios (Spot shock -30% to +30%)
  const priceShocks = [-0.30, -0.20, -0.10, 0.0, 0.10, 0.20, 0.30];
  const stressScenarios: RiskScenarioResult[] = priceShocks.map((pShift) => {
    // Delta-Gamma Taylor series expansion: PnL ≈ Delta * ΔS + 0.5 * Gamma * (ΔS)^2 + Vega * ΔVol + Theta * Δt
    const avgSpot = 500;
    const deltaS = avgSpot * pShift;
    const simPnL = netDelta * deltaS + 0.5 * netGamma * deltaS * deltaS;
    return {
      priceChangePercent: Math.round(pShift * 100),
      volatilityChangePercent: 0,
      timeDecayDays: 0,
      simulatedSpot: avgSpot * (1 + pShift),
      portfolioPnL: Number(simPnL.toFixed(2)),
      portfolioPnLPercent: Number(((simPnL / portfolioValue) * 100).toFixed(2)),
      netDelta: Number((netDelta + netGamma * deltaS).toFixed(2)),
      netGamma: Number(netGamma.toFixed(4)),
      netVega: Number(netVega.toFixed(2)),
      netTheta: Number(netTheta.toFixed(2)),
    };
  });

  // Risk Heatmap Matrix (Spot Changes x Volatility Changes)
  const volShocks = [-0.20, -0.10, 0.0, 0.10, 0.20];
  const riskMatrix: { spotChange: number; volChange: number; pnl: number }[] = [];

  priceShocks.forEach((pShift) => {
    volShocks.forEach((vShift) => {
      const deltaS = 500 * pShift;
      const volDelta = vShift * 100; // Vega is per 1% vol
      const pnl = netDelta * deltaS + 0.5 * netGamma * deltaS * deltaS + netVega * volDelta;
      riskMatrix.push({
        spotChange: Math.round(pShift * 100),
        volChange: Math.round(vShift * 100),
        pnl: Number(pnl.toFixed(2)),
      });
    });
  });

  return {
    portfolioValue,
    netDelta: Number(netDelta.toFixed(2)),
    netGamma: Number(netGamma.toFixed(4)),
    netVega: Number(netVega.toFixed(2)),
    netTheta: Number(netTheta.toFixed(2)),
    var95Dollar: Number(var95Dollar.toFixed(2)),
    var99Dollar: Number(var99Dollar.toFixed(2)),
    expectedShortfall95: Number(expectedShortfall95.toFixed(2)),
    stressScenarios,
    riskMatrix,
    concentrationRisk,
  };
}
