/**
 * Monte Carlo Option Simulation Engine with Convergence Tracking
 */

export interface MonteCarloResult {
  price: number;
  standardError: number;
  confidenceInterval: [number, number];
  simulations: number;
  convergenceData: { pathCount: number; estimatedPrice: number }[];
}

export function calculateMonteCarlo(
  type: 'call' | 'put',
  S: number,
  K: number,
  T: number,
  r: number,
  sigma: number,
  numSimulations: number = 10000,
  timeSteps: number = 50,
  seed: number = 42
): MonteCarloResult {
  if (T <= 0) {
    const payoff = type === 'call' ? Math.max(0, S - K) : Math.max(0, K - S);
    return {
      price: payoff,
      standardError: 0,
      confidenceInterval: [payoff, payoff],
      simulations: numSimulations,
      convergenceData: [],
    };
  }

  // Linear Congruential Generator for reproducible pseudo-random numbers
  let currentSeed = seed;
  const lcg = () => {
    currentSeed = (currentSeed * 1664525 + 1013904223) % 4294967296;
    return currentSeed / 4294967296;
  };

  // Box-Muller transform for standard normal variables
  const randn = () => {
    let u1 = lcg();
    let u2 = lcg();
    while (u1 === 0) u1 = lcg();
    return Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  };

  const dt = T / timeSteps;
  const drift = (r - 0.5 * sigma * sigma) * dt;
  const volSqDt = sigma * Math.sqrt(dt);

  let sumPayoffs = 0;
  let sumSquaredPayoffs = 0;

  const convergenceData: { pathCount: number; estimatedPrice: number }[] = [];
  const checkInterval = Math.max(1, Math.floor(numSimulations / 20));

  for (let sim = 1; sim <= numSimulations; sim++) {
    let currentSpot = S;
    for (let step = 0; step < timeSteps; step++) {
      const z = randn();
      currentSpot *= Math.exp(drift + volSqDt * z);
    }

    const payoff = type === 'call'
      ? Math.max(0, currentSpot - K)
      : Math.max(0, K - currentSpot);

    sumPayoffs += payoff;
    sumSquaredPayoffs += payoff * payoff;

    if (sim % checkInterval === 0 || sim === numSimulations) {
      const discountedMean = Math.exp(-r * T) * (sumPayoffs / sim);
      convergenceData.push({ pathCount: sim, estimatedPrice: discountedMean });
    }
  }

  const meanPayoff = sumPayoffs / numSimulations;
  const discountedPrice = Math.exp(-r * T) * meanPayoff;
  
  const variancePayoff = (sumSquaredPayoffs / numSimulations) - (meanPayoff * meanPayoff);
  const standardError = Math.exp(-r * T) * Math.sqrt(Math.max(0, variancePayoff) / numSimulations);

  // 95% Confidence interval (1.96 * SE)
  const confidenceInterval: [number, number] = [
    Math.max(0, discountedPrice - 1.96 * standardError),
    discountedPrice + 1.96 * standardError,
  ];

  return {
    price: discountedPrice,
    standardError,
    confidenceInterval,
    simulations: numSimulations,
    convergenceData,
  };
}
