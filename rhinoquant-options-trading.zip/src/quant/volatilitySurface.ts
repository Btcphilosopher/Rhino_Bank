import { VolatilitySurfacePoint, VolatilityMetrics } from '../types';

/**
 * Volatility Surface Generator & Parameterized SVI Skew/Term-Structure Solver
 */

export function generateVolatilitySurface(
  symbol: string,
  spotPrice: number,
  baseIV: number = 0.28
): {
  surfacePoints: VolatilitySurfacePoint[];
  expirations: string[];
  strikes: number[];
  metrics: VolatilityMetrics;
} {
  const expirations = ['7D', '14D', '30D', '60D', '90D', '180D'];
  const dteMap: Record<string, number> = {
    '7D': 7,
    '14D': 14,
    '30D': 30,
    '60D': 60,
    '90D': 90,
    '180D': 180,
  };

  const moneynessSteps = [0.80, 0.85, 0.90, 0.95, 1.00, 1.05, 1.10, 1.15, 1.20];
  const strikes = moneynessSteps.map((m) => Math.round(spotPrice * m));

  const surfacePoints: VolatilitySurfacePoint[] = [];

  expirations.forEach((exp) => {
    const dte = dteMap[exp];
    const termFactor = 1.0 + 0.12 * Math.exp(-dte / 45); // Term structure curvature

    moneynessSteps.forEach((m) => {
      const strike = Math.round(spotPrice * m);
      // SVI (Stochastic Volatility Inspired) skew formula approximation
      // Skew is steeper for puts (m < 1.0) and flattens out for higher expiration
      const k = Math.log(m); // Log-moneyness
      const skew = -0.35 * k + 0.85 * k * k; // Put skew curvature
      const iv = baseIV * termFactor * (1.0 + skew);

      const hv = baseIV * 0.88; // Realized vol slightly lower than IV

      surfacePoints.push({
        strike,
        moneyness: Number(m.toFixed(2)),
        expiration: exp,
        dte,
        impliedVolatility: Number(iv.toFixed(4)),
        historicalVolatility: Number(hv.toFixed(4)),
        delta: Number((0.5 + (m - 1.0) * 2.0).toFixed(2)),
      });
    });
  });

  const atm30dIV = surfacePoints.find((p) => p.expiration === '30D' && p.moneyness === 1.00)?.impliedVolatility || baseIV;
  const put25dIV = surfacePoints.find((p) => p.expiration === '30D' && p.moneyness === 0.90)?.impliedVolatility || baseIV * 1.15;
  const call25dIV = surfacePoints.find((p) => p.expiration === '30D' && p.moneyness === 1.10)?.impliedVolatility || baseIV * 0.92;

  const hv30 = baseIV * 0.85;
  const ivRank = Math.round(((atm30dIV - 0.15) / (0.65 - 0.15)) * 100);
  const ivPercentile = Math.min(99, Math.max(1, ivRank + 4));

  const regime: VolatilityMetrics['regime'] =
    atm30dIV < 0.18 ? 'LOW VOL'
    : atm30dIV < 0.32 ? 'NORMAL'
    : atm30dIV < 0.50 ? 'ELEVATED'
    : 'EXTREME';

  const metrics: VolatilityMetrics = {
    symbol,
    spotPrice,
    currentIV: Number(atm30dIV.toFixed(4)),
    hv20: Number((hv30 * 0.95).toFixed(4)),
    hv30: Number(hv30.toFixed(4)),
    hv90: Number((hv30 * 1.05).toFixed(4)),
    ivRank: Math.max(1, Math.min(99, ivRank)),
    ivPercentile: Math.max(1, Math.min(99, ivPercentile)),
    volRiskPremium: Number((atm30dIV - hv30).toFixed(4)),
    expectedMove1Sig: Number((spotPrice * atm30dIV * Math.sqrt(30 / 365)).toFixed(2)),
    expectedMove2Sig: Number((2 * spotPrice * atm30dIV * Math.sqrt(30 / 365)).toFixed(2)),
    skew25Delta: Number(((put25dIV - call25dIV) * 100).toFixed(2)), // percentage points
    termStructureSlope: Number((((surfacePoints.find((p) => p.expiration === '180D' && p.moneyness === 1.0)?.impliedVolatility || baseIV) - atm30dIV) * 100).toFixed(2)),
    regime,
  };

  return { surfacePoints, expirations, strikes, metrics };
}
