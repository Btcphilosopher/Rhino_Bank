import { MultiLegStrategy, OptionLeg } from '../types';
import { calculateBlackScholes } from './blackScholes';
import { cnd } from './blackScholes';

export interface PayoffCurvePoint {
  spot: number;
  expirationPnL: number;
  theoreticalPnL: number;
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
}

export function evaluateStrategy(
  underlyingSymbol: string,
  spotPrice: number,
  legs: OptionLeg[],
  riskFreeRate: number = 0.045,
  simulatedDteShift: number = 0, // Days elapsed from now
  simulatedVolShiftPercent: number = 0 // e.g. +5% IV change
): {
  strategy: MultiLegStrategy;
  payoffCurve: PayoffCurvePoint[];
} {
  let netPremium = 0; // Positive = Credit, Negative = Debit
  let netDelta = 0;
  let netGamma = 0;
  let netTheta = 0;
  let netVega = 0;
  let netRho = 0;
  let marginRequirement = 0;

  legs.forEach((leg) => {
    const qty = leg.action === 'BUY' ? leg.quantity : -leg.quantity;
    const legPremium = leg.entryPrice * qty * 100; // Total dollars
    netPremium -= legPremium; // Buying costs cash (negative premium balance change), selling receives cash

    netDelta += (leg.contract.delta || 0) * qty * 100;
    netGamma += (leg.contract.gamma || 0) * qty * 100;
    netTheta += (leg.contract.theta || 0) * qty * 100;
    netVega += (leg.contract.vega || 0) * qty * 100;
    netRho += (leg.contract.rho || 0) * qty * 100;

    // Standard naked/spread margin calculation
    if (leg.action === 'SELL') {
      const strike = leg.contract.strike;
      if (leg.contract.type === 'call') {
        const nakedCallMargin = Math.max(
          0.20 * spotPrice - Math.max(0, strike - spotPrice),
          0.10 * spotPrice
        ) * 100 * leg.quantity;
        marginRequirement += nakedCallMargin;
      } else {
        const nakedPutMargin = Math.max(
          0.20 * spotPrice - Math.max(0, spotPrice - strike),
          0.10 * strike
        ) * 100 * leg.quantity;
        marginRequirement += nakedPutMargin;
      }
    }
  });

  // Payoff diagram across underlying range (e.g., ±35% from spot)
  const minSpot = Math.max(1, spotPrice * 0.65);
  const maxSpot = spotPrice * 1.35;
  const stepCount = 80;
  const stepSize = (maxSpot - minSpot) / stepCount;

  const payoffCurve: PayoffCurvePoint[] = [];

  let maxProfit = -Infinity;
  let maxLoss = Infinity;
  let breakevens: number[] = [];

  let previousExpPnL: number | null = null;
  let previousSpot: number | null = null;

  for (let i = 0; i <= stepCount; i++) {
    const testSpot = minSpot + i * stepSize;
    let expPnL = netPremium; // Start with net premium collected/paid
    let theoPnL = netPremium;
    let pointDelta = 0;
    let pointGamma = 0;
    let pointVega = 0;
    let pointTheta = 0;

    legs.forEach((leg) => {
      const isLong = leg.action === 'BUY';
      const qty = isLong ? leg.quantity : -leg.quantity;
      const K = leg.contract.strike;

      // Expiration value per contract leg
      const intrinsic = leg.contract.type === 'call'
        ? Math.max(0, testSpot - K)
        : Math.max(0, K - testSpot);
      expPnL += (intrinsic - leg.entryPrice) * qty * 100;

      // Theoretical prior-to-expiration value
      const remainingDte = Math.max(0.001, leg.contract.dte - simulatedDteShift);
      const T = remainingDte / 365;
      const vol = Math.max(0.01, leg.contract.impliedVolatility + simulatedVolShiftPercent / 100);

      const bs = calculateBlackScholes(leg.contract.type, testSpot, K, T, riskFreeRate, vol);
      const theoOptionVal = bs.price;
      theoPnL += (theoOptionVal - leg.entryPrice) * qty * 100;

      pointDelta += bs.delta * qty * 100;
      pointGamma += bs.gamma * qty * 100;
      pointVega += bs.vega * qty * 100;
      pointTheta += bs.theta * qty * 100;
    });

    if (expPnL > maxProfit) maxProfit = expPnL;
    if (expPnL < maxLoss) maxLoss = expPnL;

    // Detect breakeven crossing
    if (previousExpPnL !== null && previousSpot !== null) {
      if ((previousExpPnL < 0 && expPnL >= 0) || (previousExpPnL > 0 && expPnL <= 0)) {
        // Linear interpolation for exact breakeven spot
        const cross = previousSpot + (0 - previousExpPnL) * (testSpot - previousSpot) / (expPnL - previousExpPnL);
        breakevens.push(Number(cross.toFixed(2)));
      }
    }

    previousExpPnL = expPnL;
    previousSpot = testSpot;

    payoffCurve.push({
      spot: Number(testSpot.toFixed(2)),
      expirationPnL: Number(expPnL.toFixed(2)),
      theoreticalPnL: Number(theoPnL.toFixed(2)),
      delta: Number(pointDelta.toFixed(2)),
      gamma: Number(pointGamma.toFixed(4)),
      vega: Number(pointVega.toFixed(2)),
      theta: Number(pointTheta.toFixed(2)),
    });
  }

  // Calculate Probability of Profit (PoP)
  // Approximate using standard normal distribution between breakevens and implied volatility
  let probabilityOfProfit = 50.0;
  if (breakevens.length === 1) {
    const be = breakevens[0];
    const avgDte = legs[0]?.contract.dte || 30;
    const avgVol = legs[0]?.contract.impliedVolatility || 0.25;
    const T = avgDte / 365;
    const z = (Math.log(be / spotPrice)) / (avgVol * Math.sqrt(T));
    probabilityOfProfit = be > spotPrice ? (1 - cnd(z)) * 100 : cnd(z) * 100;
  } else if (breakevens.length === 2) {
    const [be1, be2] = breakevens.sort((a, b) => a - b);
    const avgDte = legs[0]?.contract.dte || 30;
    const avgVol = legs[0]?.contract.impliedVolatility || 0.25;
    const T = avgDte / 365;
    const z1 = (Math.log(be1 / spotPrice)) / (avgVol * Math.sqrt(T));
    const z2 = (Math.log(be2 / spotPrice)) / (avgVol * Math.sqrt(T));
    const popBetween = (cnd(z2) - cnd(z1)) * 100;
    // Check if middle zone is profitable (e.g. Iron Condor)
    const midSpot = (be1 + be2) / 2;
    const midPoint = payoffCurve.find((p) => Math.abs(p.spot - midSpot) < stepSize * 1.5);
    probabilityOfProfit = (midPoint && midPoint.expirationPnL > 0) ? popBetween : (100 - popBetween);
  }

  const riskReward = maxLoss !== 0 ? Math.abs(maxProfit / maxLoss) : 0;
  const expectedValue = (probabilityOfProfit / 100) * maxProfit + ((100 - probabilityOfProfit) / 100) * maxLoss;

  const strategy: MultiLegStrategy = {
    id: `strat-${Date.now()}`,
    name: getStrategyPresetName(legs),
    underlyingSymbol,
    underlyingPrice: spotPrice,
    legs,
    netPremium: Number(netPremium.toFixed(2)),
    maxProfit: Number(maxProfit.toFixed(2)),
    maxLoss: Number(maxLoss.toFixed(2)),
    breakevens,
    probabilityOfProfit: Number(Math.max(1, Math.min(99, probabilityOfProfit)).toFixed(1)),
    marginRequirement: Number(marginRequirement.toFixed(2)),
    riskRewardRatio: Number(riskReward.toFixed(2)),
    expectedValue: Number(expectedValue.toFixed(2)),
    netDelta: Number(netDelta.toFixed(2)),
    netGamma: Number(netGamma.toFixed(4)),
    netTheta: Number(netTheta.toFixed(2)),
    netVega: Number(netVega.toFixed(2)),
    netRho: Number(netRho.toFixed(2)),
  };

  return { strategy, payoffCurve };
}

function getStrategyPresetName(legs: OptionLeg[]): string {
  if (legs.length === 1) {
    const leg = legs[0];
    return `${leg.action} ${leg.contract.type.toUpperCase()} @ ${leg.contract.strike}`;
  }
  if (legs.length === 2) {
    const [l1, l2] = legs;
    if (l1.contract.type === l2.contract.type) {
      if (l1.action !== l2.action) {
        return l1.contract.type === 'call' ? 'Call Vertical Spread' : 'Put Vertical Spread';
      }
      return 'Calendar / Diagonal';
    }
    if (l1.contract.strike === l2.contract.strike && l1.action === l2.action) {
      return l1.action === 'BUY' ? 'Long Straddle' : 'Short Straddle';
    }
    if (l1.action === l2.action) {
      return l1.action === 'BUY' ? 'Long Strangle' : 'Short Strangle';
    }
  }
  if (legs.length === 4) {
    return 'Iron Condor';
  }
  return 'Multi-Leg Custom Strategy';
}
