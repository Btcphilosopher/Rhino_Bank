/**
 * Expected Move Engine based on Straddle Price and Implied Volatility
 */

export interface ExpectedMoveResult {
  spotPrice: number;
  expectedMoveAmount: number;
  expectedMovePercent: number;
  range1SigmaLow: number;
  range1SigmaHigh: number;
  range2SigmaLow: number;
  range2SigmaHigh: number;
  dte: number;
  atmIV: number;
}

export function calculateExpectedMove(
  spotPrice: number,
  atmIV: number,
  dte: number,
  straddlePrice?: number
): ExpectedMoveResult {
  const T = dte / 365;

  let moveAmount = 0;
  if (straddlePrice && straddlePrice > 0) {
    // Standard market rule-of-thumb: Expected move ≈ 0.85 * ATM Straddle
    moveAmount = 0.85 * straddlePrice;
  } else {
    // Theoretical 1-sigma move: S * IV * sqrt(T)
    moveAmount = spotPrice * atmIV * Math.sqrt(Math.max(0.0001, T));
  }

  const movePercent = (moveAmount / spotPrice) * 100;

  return {
    spotPrice,
    expectedMoveAmount: moveAmount,
    expectedMovePercent: movePercent,
    range1SigmaLow: Math.max(0, spotPrice - moveAmount),
    range1SigmaHigh: spotPrice + moveAmount,
    range2SigmaLow: Math.max(0, spotPrice - 2 * moveAmount),
    range2SigmaHigh: spotPrice + 2 * moveAmount,
    dte,
    atmIV,
  };
}
