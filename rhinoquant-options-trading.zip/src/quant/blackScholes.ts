/**
 * Professional Black-Scholes-Merton Pricing and High-Order Greeks Engine
 */

export interface BlackScholesResult {
  price: number;
  delta: number;
  gamma: number;
  theta: number; // Daily theta
  vega: number;  // 1% vol change vega
  rho: number;   // 1% rate change rho
  charm: number; // Delta decay per day
  vanna: number; // Delta sensitivity to vol
  volga: number; // Vega sensitivity to vol
  speed: number; // Gamma sensitivity to spot
  color: number; // Gamma decay per day
  zomma: number; // Gamma sensitivity to vol
  d1: number;
  d2: number;
}

// Standard normal cumulative distribution function (CND) polynomial approximation
export function cnd(x: number): number {
  const a1 = 0.319381530;
  const a2 = -0.356563782;
  const a3 = 1.781477937;
  const a4 = -1.821255978;
  const a5 = 1.330274429;
  const L = Math.abs(x);
  const k = 1.0 / (1.0 + 0.2316419 * L);
  const cndVal = 1.0 - 1.0 / Math.sqrt(2 * Math.PI) * Math.exp(-L * L / 2.0) *
    (a1 * k + a2 * Math.pow(k, 2) + a3 * Math.pow(k, 3) + a4 * Math.pow(k, 4) + a5 * Math.pow(k, 5));
  return x < 0 ? 1.0 - cndVal : cndVal;
}

// Standard normal probability density function (PDF)
export function npdf(x: number): number {
  return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);
}

/**
 * Calculates theoretical option price and all primary + second-order Greeks.
 * @param type 'call' | 'put'
 * @param S Spot price
 * @param K Strike price
 * @param T Time to expiration in years (e.g. 30/365)
 * @param r Risk-free rate (e.g. 0.045 for 4.5%)
 * @param sigma Volatility (e.g. 0.25 for 25%)
 * @param q Continuous dividend yield (default 0.0)
 */
export function calculateBlackScholes(
  type: 'call' | 'put',
  S: number,
  K: number,
  T: number,
  r: number,
  sigma: number,
  q: number = 0
): BlackScholesResult {
  // Edge cases for zero time or zero volatility
  if (T <= 0.0001) {
    const intrinsic = type === 'call' ? Math.max(0, S - K) : Math.max(0, K - S);
    const delta = type === 'call' ? (S >= K ? 1 : 0) : (S <= K ? -1 : 0);
    return {
      price: intrinsic,
      delta,
      gamma: 0,
      theta: 0,
      vega: 0,
      rho: 0,
      charm: 0,
      vanna: 0,
      volga: 0,
      speed: 0,
      color: 0,
      zomma: 0,
      d1: 0,
      d2: 0,
    };
  }

  const vol = Math.max(sigma, 0.0001);
  const sqrtT = Math.sqrt(T);
  const d1 = (Math.log(S / K) + (r - q + 0.5 * vol * vol) * T) / (vol * sqrtT);
  const d2 = d1 - vol * sqrtT;

  const N_d1 = cnd(d1);
  const N_d2 = cnd(d2);
  const N_minus_d1 = cnd(-d1);
  const N_minus_d2 = cnd(-d2);
  const n_d1 = npdf(d1);

  const exp_minus_qT = Math.exp(-q * T);
  const exp_minus_rT = Math.exp(-r * T);

  let price = 0;
  let delta = 0;
  let rho = 0;

  if (type === 'call') {
    price = S * exp_minus_qT * N_d1 - K * exp_minus_rT * N_d2;
    delta = exp_minus_qT * N_d1;
    rho = (K * T * exp_minus_rT * N_d2) / 100; // 1% change
  } else {
    price = K * exp_minus_rT * N_minus_d2 - S * exp_minus_qT * N_minus_d1;
    delta = -exp_minus_qT * N_minus_d1;
    rho = (-K * T * exp_minus_rT * N_minus_d2) / 100;
  }

  // Common Greeks
  const gamma = (exp_minus_qT * n_d1) / (S * vol * sqrtT);
  const vega = (S * exp_minus_qT * n_d1 * sqrtT) / 100; // 1% change in volatility

  // Annualized Theta
  let thetaAnnual = 0;
  if (type === 'call') {
    thetaAnnual = -(S * vol * exp_minus_qT * n_d1) / (2 * sqrtT)
      + q * S * exp_minus_qT * N_d1
      - r * K * exp_minus_rT * N_d2;
  } else {
    thetaAnnual = -(S * vol * exp_minus_qT * n_d1) / (2 * sqrtT)
      - q * S * exp_minus_qT * N_minus_d1
      + r * K * exp_minus_rT * N_minus_d2;
  }
  const theta = thetaAnnual / 365; // Daily theta

  // Second-order Greeks
  // Charm (Delta decay per day)
  let charmAnnual = 0;
  if (type === 'call') {
    charmAnnual = q * exp_minus_qT * N_d1 - exp_minus_qT * n_d1 * (2 * (r - q) * T - d2 * vol * sqrtT) / (2 * T * vol * sqrtT);
  } else {
    charmAnnual = -q * exp_minus_qT * N_minus_d1 - exp_minus_qT * n_d1 * (2 * (r - q) * T - d2 * vol * sqrtT) / (2 * T * vol * sqrtT);
  }
  const charm = charmAnnual / 365;

  // Vanna (dDelta / dVol)
  const vanna = -exp_minus_qT * n_d1 * d2 / vol;

  // Volga / Vomma (dVega / dVol)
  const volga = S * exp_minus_qT * n_d1 * sqrtT * d1 * d2 / vol;

  // Speed (dGamma / dSpot)
  const speed = -gamma / S * (d1 / (vol * sqrtT) + 1);

  // Color (dGamma / dTime)
  const colorAnnual = -gamma * (q + (r - q) * d1 / (vol * sqrtT) + (1 - d1 * d2) / (2 * T));
  const color = colorAnnual / 365;

  // Zomma (dGamma / dVol)
  const zomma = gamma * (d1 * d2 - 1) / vol;

  return {
    price: Math.max(0, price),
    delta,
    gamma,
    theta,
    vega,
    rho,
    charm,
    vanna,
    volga,
    speed,
    color,
    zomma,
    d1,
    d2,
  };
}
