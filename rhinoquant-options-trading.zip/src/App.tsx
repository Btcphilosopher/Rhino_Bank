import React, { useState, useEffect } from 'react';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { CommandPalette } from './components/layout/CommandPalette';
import { AlertsModal } from './components/AlertsModal';

import { TerminalView } from './components/views/TerminalView';
import { OptionsChainView } from './components/views/OptionsChainView';
import { VolatilityView } from './components/views/VolatilityView';
import { StrategyBuilderView } from './components/views/StrategyBuilderView';
import { StrategyLabView } from './components/views/StrategyLabView';
import { PortfolioView } from './components/views/PortfolioView';
import { RiskEngineView } from './components/views/RiskEngineView';
import { BacktestingView } from './components/views/BacktestingView';
import { QuantResearchView } from './components/views/QuantResearchView';
import { MarketScannerView } from './components/views/MarketScannerView';
import { ExecutionView } from './components/views/ExecutionView';
import { DataHealthView } from './components/views/DataHealthView';
import { ReportsSettingsView } from './components/views/ReportsSettingsView';

import { AccountSummary, OptionContract, OptionLeg, PortfolioPosition } from './types';
import { getMarketQuote, generateOptionChain, MarketQuote } from './services/syntheticMarketData';

export default function App() {
  const [selectedSymbol, setSelectedSymbol] = useState<string>('NVDA');
  const [activeTab, setActiveTab] = useState<string>('terminal');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [commandPaletteOpen, setCommandPaletteOpen] = useState<boolean>(false);
  const [alertsModalOpen, setAlertsModalOpen] = useState<boolean>(false);

  const [quote, setQuote] = useState<MarketQuote>(() => getMarketQuote('NVDA'));
  const [chain, setChain] = useState(() => generateOptionChain('NVDA'));

  const [account, setAccount] = useState<AccountSummary>({
    portfolioValue: 1248500.00,
    cashBalance: 482100.00,
    buyingPower: 964200.00,
    todayPnL: 14250.80,
    todayPnLPercent: 1.15,
    unrealizedPnL: 84320.50,
    realizedPnL: 32100.00,
    netDelta: -12.4,
    netGamma: 0.042,
    netTheta: 840.50,
    netVega: 1250.00,
    marginUsed: 298000.00,
    marginAvailable: 666200.00,
    mode: 'PAPER',
  });

  const [positions, setPositions] = useState<PortfolioPosition[]>([
    {
      id: 'pos-1',
      symbol: 'NVDA 2026-09-30 125.0 C',
      underlyingSymbol: 'NVDA',
      assetType: 'OPTION',
      optionType: 'call',
      strike: 125,
      expiration: '2026-09-30',
      quantity: 10,
      avgEntryPrice: 6.80,
      currentPrice: 8.40,
      marketValue: 8400.00,
      unrealizedPnL: 1600.00,
      unrealizedPnLPercent: 23.5,
      realizedPnL: 0,
      delta: 620,
      gamma: 0.038,
      theta: -45.2,
      vega: 82.0,
      sector: 'Semiconductors',
    },
    {
      id: 'pos-2',
      symbol: 'SPY 2026-09-30 Iron Condor',
      underlyingSymbol: 'SPY',
      assetType: 'STRATEGY',
      quantity: 25,
      avgEntryPrice: 2.10,
      currentPrice: 1.25,
      marketValue: -3125.00,
      unrealizedPnL: 2125.00,
      unrealizedPnLPercent: 40.4,
      realizedPnL: 850.00,
      delta: -15,
      gamma: -0.012,
      theta: 125.0,
      vega: -140.0,
      sector: 'ETF Index',
    },
  ]);

  const [builderLegs, setBuilderLegs] = useState<OptionLeg[]>([]);

  // Update market quotes and option chain when symbol changes
  useEffect(() => {
    const q = getMarketQuote(selectedSymbol);
    const c = generateOptionChain(selectedSymbol);
    setQuote(q);
    setChain(c);
  }, [selectedSymbol]);

  const handleAddLegToStrategy = (contract: OptionContract, action: 'BUY' | 'SELL') => {
    const newLeg: OptionLeg = {
      id: `leg-${Date.now()}-${Math.random()}`,
      contract,
      action,
      quantity: 1,
      entryPrice: action === 'BUY' ? contract.ask : contract.bid,
    };
    setBuilderLegs((prev) => [...prev, newLeg]);
    setActiveTab('strategy');
  };

  const handleOpenOrderTicket = (legs: OptionLeg[]) => {
    // Submit order to backend paper trading engine
    fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        symbol: selectedSymbol,
        orderType: 'MULTI_LEG',
        action: 'BUY_TO_OPEN',
        legs,
        quantity: 1,
      }),
    }).catch(() => {});

    setActiveTab('execution');
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0A0A0B] text-slate-100 overflow-hidden font-mono select-none">
      {/* Top Metallic Persistent Header */}
      <Header
        account={account}
        selectedSymbol={selectedSymbol}
        onSymbolChange={setSelectedSymbol}
        onOpenCommandPalette={() => setCommandPaletteOpen(true)}
        onOpenAlerts={() => setAlertsModalOpen(true)}
        activeTab={activeTab}
      />

      {/* Main Body with Sidebar + Tab View */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        />

        {/* View Switcher */}
        <main className="flex-1 flex flex-col min-w-0 bg-[#0A0A0B] overflow-hidden">
          {activeTab === 'terminal' && (
            <TerminalView
              quote={quote}
              chain={chain}
              onAddLegToStrategy={handleAddLegToStrategy}
              onOpenOrderTicket={handleOpenOrderTicket}
            />
          )}

          {activeTab === 'chains' && (
            <OptionsChainView
              quote={quote}
              chain={chain}
              onSelectContract={(contract) => handleAddLegToStrategy(contract, 'BUY')}
            />
          )}

          {activeTab === 'volatility' && <VolatilityView quote={quote} />}

          {activeTab === 'strategy' && (
            <StrategyBuilderView
              quote={quote}
              chain={chain}
              initialLegs={builderLegs}
              onOpenOrderTicket={handleOpenOrderTicket}
            />
          )}

          {activeTab === 'strategylab' && <StrategyLabView quote={quote} />}

          {activeTab === 'portfolio' && (
            <PortfolioView account={account} positions={positions} />
          )}

          {activeTab === 'risk' && <RiskEngineView positions={positions} />}

          {activeTab === 'backtest' && <BacktestingView />}

          {activeTab === 'quant' && <QuantResearchView />}

          {activeTab === 'scanner' && (
            <MarketScannerView
              onSelectSymbol={(sym) => {
                setSelectedSymbol(sym);
                setActiveTab('terminal');
              }}
            />
          )}

          {activeTab === 'execution' && <ExecutionView />}

          {activeTab === 'data' && <DataHealthView />}

          {activeTab === 'reports' && <ReportsSettingsView />}
        </main>
      </div>

      {/* Command Palette Overlay Modal (Cmd+K) */}
      <CommandPalette
        isOpen={commandPaletteOpen}
        onClose={() => setCommandPaletteOpen(false)}
        onSelectSymbol={(sym) => {
          setSelectedSymbol(sym);
          setActiveTab('terminal');
        }}
        onSelectTab={(tabId) => setActiveTab(tabId)}
      />

      {/* Alerts Manager Modal */}
      <AlertsModal
        isOpen={alertsModalOpen}
        onClose={() => setAlertsModalOpen(false)}
        selectedSymbol={selectedSymbol}
      />
    </div>
  );
}
