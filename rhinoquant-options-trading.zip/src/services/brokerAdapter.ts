import { AccountSummary, OrderTicket, PortfolioPosition } from '../types';
import { getMarketQuote, generateOptionChain } from './syntheticMarketData';

export interface BrokerAdapter {
  connect(): Promise<boolean>;
  getAccount(): Promise<AccountSummary>;
  getPositions(): Promise<PortfolioPosition[]>;
  submitOrder(order: Partial<OrderTicket>): Promise<OrderTicket>;
  cancelOrder(orderId: string): Promise<boolean>;
  getOrders(): Promise<OrderTicket[]>;
}

export class MockBrokerAdapter implements BrokerAdapter {
  private isConnected = false;
  private account: AccountSummary = {
    portfolioValue: 1248500.00,
    cashBalance: 482100.00,
    buyingPower: 964200.00,
    todayPnL: 14250.80,
    todayPnLPercent: 1.15,
    unrealizedPnL: 84320.50,
    realizedPnL: 32100.00,
    netDelta: -12.4,
    netGamma: 0.042,
    netTheta: 840.50,
    netVega: 1250.00,
    marginUsed: 298000.00,
    marginAvailable: 666200.00,
    mode: 'PAPER',
  };

  private positions: PortfolioPosition[] = [
    {
      id: 'pos-1',
      symbol: 'NVDA 2026-09-30 125.0 C',
      underlyingSymbol: 'NVDA',
      assetType: 'OPTION',
      optionType: 'call',
      strike: 125,
      expiration: '2026-09-30',
      quantity: 10,
      avgEntryPrice: 6.80,
      currentPrice: 8.40,
      marketValue: 8400.00,
      unrealizedPnL: 1600.00,
      unrealizedPnLPercent: 23.5,
      realizedPnL: 0,
      delta: 620,
      gamma: 0.038,
      theta: -45.2,
      vega: 82.0,
      sector: 'Semiconductors',
    },
    {
      id: 'pos-2',
      symbol: 'SPY 2026-09-30 Iron Condor',
      underlyingSymbol: 'SPY',
      assetType: 'STRATEGY',
      quantity: 25,
      avgEntryPrice: 2.10,
      currentPrice: 1.25,
      marketValue: -3125.00,
      unrealizedPnL: 2125.00,
      unrealizedPnLPercent: 40.4,
      realizedPnL: 850.00,
      delta: -15,
      gamma: -0.012,
      theta: 125.0,
      vega: -140.0,
      sector: 'ETF Index',
    },
    {
      id: 'pos-3',
      symbol: 'AAPL 2026-10-17 220/230 Bull Call',
      underlyingSymbol: 'AAPL',
      assetType: 'STRATEGY',
      quantity: 15,
      avgEntryPrice: 3.80,
      currentPrice: 4.60,
      marketValue: 6900.00,
      unrealizedPnL: 1200.00,
      unrealizedPnLPercent: 21.0,
      realizedPnL: 0,
      delta: 380,
      gamma: 0.024,
      theta: -18.5,
      vega: 42.0,
      sector: 'Technology',
    },
    {
      id: 'pos-4',
      symbol: 'TSLA 2026-09-15 200/230 Strangle',
      underlyingSymbol: 'TSLA',
      assetType: 'STRATEGY',
      quantity: -10, // Short strangle
      avgEntryPrice: 8.50,
      currentPrice: 6.20,
      marketValue: -6200.00,
      unrealizedPnL: 2300.00,
      unrealizedPnLPercent: 27.0,
      realizedPnL: 1200.00,
      delta: 42,
      gamma: -0.018,
      theta: 210.0,
      vega: -280.0,
      sector: 'Automotive / EV',
    },
  ];

  private orders: OrderTicket[] = [
    {
      id: 'ord-101',
      symbol: 'NVDA',
      orderType: 'LIMIT',
      action: 'BUY_TO_OPEN',
      legs: [],
      quantity: 5,
      limitPrice: 8.20,
      status: 'FILLED',
      submittedAt: new Date(Date.now() - 3600000).toISOString(),
      filledAt: new Date(Date.now() - 3500000).toISOString(),
      fillPrice: 8.20,
      commission: 3.25,
      marginImpact: 4100,
      deltaImpact: 280,
    },
  ];

  async connect(): Promise<boolean> {
    this.isConnected = true;
    return true;
  }

  async getAccount(): Promise<AccountSummary> {
    return { ...this.account };
  }

  async getPositions(): Promise<PortfolioPosition[]> {
    return [...this.positions];
  }

  async submitOrder(orderReq: Partial<OrderTicket>): Promise<OrderTicket> {
    const newOrder: OrderTicket = {
      id: `ord-${Date.now()}`,
      symbol: orderReq.symbol || 'SPY',
      orderType: orderReq.orderType || 'MARKET',
      action: orderReq.action || 'BUY_TO_OPEN',
      legs: orderReq.legs || [],
      quantity: orderReq.quantity || 1,
      limitPrice: orderReq.limitPrice,
      status: 'FILLED', // Simulated instant fill
      submittedAt: new Date().toISOString(),
      filledAt: new Date().toISOString(),
      fillPrice: orderReq.limitPrice || 5.40,
      commission: 1.30 * (orderReq.legs?.length || 1),
      marginImpact: 1250,
      deltaImpact: 45,
    };

    this.orders.unshift(newOrder);

    // Update account simulated cash & PnL
    this.account.buyingPower -= newOrder.marginImpact;
    this.account.cashBalance -= (newOrder.fillPrice * newOrder.quantity * 100);

    return newOrder;
  }

  async cancelOrder(orderId: string): Promise<boolean> {
    const ord = this.orders.find((o) => o.id === orderId);
    if (ord && ord.status === 'PENDING') {
      ord.status = 'CANCELLED';
      return true;
    }
    return false;
  }

  async getOrders(): Promise<OrderTicket[]> {
    return [...this.orders];
  }
}
