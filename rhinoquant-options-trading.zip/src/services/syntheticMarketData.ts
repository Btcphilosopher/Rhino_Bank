import { OptionContract, OptionChainExpiration, MarketScannerItem } from '../types';
import { calculateBlackScholes } from '../quant/blackScholes';
import { solveImpliedVolatility } from '../quant/impliedVolatility';

export interface MarketQuote {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  high: number;
  low: number;
  volume: number;
  iv: number;
  ivRank: number;
  ivPercentile: number;
  peRatio: number;
  marketCap: string;
}

export const SUPPORTED_SYMBOLS: Record<string, { name: string; spot: number; iv: number }> = {
  NVDA: { name: 'NVIDIA Corporation', spot: 128.50, iv: 0.42 },
  SPY: { name: 'SPDR S&P 500 ETF Trust', spot: 564.20, iv: 0.145 },
  QQQ: { name: 'Invesco QQQ Trust', spot: 488.10, iv: 0.182 },
  AAPL: { name: 'Apple Inc.', spot: 226.40, iv: 0.225 },
  MSFT: { name: 'Microsoft Corporation', spot: 418.90, iv: 0.210 },
  TSLA: { name: 'Tesla, Inc.', spot: 214.30, iv: 0.585 },
  BTC: { name: 'Bitcoin Index (USD)', spot: 64200.00, iv: 0.520 },
};

export function getMarketQuote(symbol: string): MarketQuote {
  const info = SUPPORTED_SYMBOLS[symbol.toUpperCase()] || { name: `${symbol.toUpperCase()} Corp`, spot: 250.00, iv: 0.28 };
  const changePercent = Number((Math.sin(symbol.length) * 1.8 + 0.4).toFixed(2));
  const change = Number(((info.spot * changePercent) / 100).toFixed(2));

  return {
    symbol: symbol.toUpperCase(),
    name: info.name,
    price: info.spot,
    change,
    changePercent,
    high: Number((info.spot * 1.018).toFixed(2)),
    low: Number((info.spot * 0.985).toFixed(2)),
    volume: 38450000,
    iv: info.iv,
    ivRank: Math.round(((info.iv - 0.12) / (0.65 - 0.12)) * 100),
    ivPercentile: Math.min(99, Math.round(((info.iv - 0.10) / (0.60 - 0.10)) * 100)),
    peRatio: 32.4,
    marketCap: '$3.15T',
  };
}

export function generateOptionChain(symbol: string): OptionChainExpiration[] {
  const quote = getMarketQuote(symbol);
  const spot = quote.price;
  const baseIV = quote.iv;

  const expirationDates = [
    { exp: '2026-09-08', dte: 7 },
    { exp: '2026-09-15', dte: 14 },
    { exp: '2026-09-30', dte: 29 },
    { exp: '2026-10-17', dte: 46 },
    { exp: '2026-11-20', dte: 80 },
    { exp: '2026-12-18', dte: 108 },
  ];

  const r = 0.045; // 4.5% risk free rate

  return expirationDates.map(({ exp, dte }) => {
    const T = dte / 365;

    // Generate strikes around spot (e.g. 15 strikes, step sized relative to spot)
    const step = spot > 1000 ? 50 : spot > 200 ? 5 : spot > 50 ? 2.5 : 1.0;
    const atmStrike = Math.round(spot / step) * step;

    const strikes: number[] = [];
    for (let i = -7; i <= 7; i++) {
      strikes.push(atmStrike + i * step);
    }

    const calls: OptionContract[] = [];
    const puts: OptionContract[] = [];

    strikes.forEach((strike) => {
      // Skew calculation
      const moneyness = strike / spot;
      const skewFactor = 1.0 - 0.3 * Math.log(moneyness) + 0.5 * Math.pow(Math.log(moneyness), 2);
      const iv = Math.max(0.05, baseIV * skewFactor);

      // Black Scholes calls and puts
      const callBS = calculateBlackScholes('call', spot, strike, T, r, iv);
      const putBS = calculateBlackScholes('put', spot, strike, T, r, iv);

      const spread = Math.max(0.05, Math.round(callBS.price * 0.03 * 100) / 100);

      const callBid = Number(Math.max(0.01, callBS.price - spread / 2).toFixed(2));
      const callAsk = Number((callBS.price + spread / 2).toFixed(2));
      const putBid = Number(Math.max(0.01, putBS.price - spread / 2).toFixed(2));
      const putAsk = Number((putBS.price + spread / 2).toFixed(2));

      const isCallITM = spot > strike;
      const isCallATM = Math.abs(spot - strike) <= step / 2;
      const isCallOTM = spot < strike;

      const isPutITM = spot < strike;
      const isPutATM = isCallATM;
      const isPutOTM = spot > strike;

      // Realistic volume & open interest
      const distFromATM = Math.abs(strike - atmStrike) / step;
      const volBase = Math.max(10, Math.round(15000 * Math.exp(-0.4 * distFromATM)));
      const oiBase = Math.max(50, Math.round(45000 * Math.exp(-0.3 * distFromATM)));

      calls.push({
        id: `${symbol}-${exp}-${strike}-C`,
        symbol: symbol.toUpperCase(),
        underlyingPrice: spot,
        strike,
        expiration: exp,
        dte,
        type: 'call',
        bid: callBid,
        ask: callAsk,
        last: Number(((callBid + callAsk) / 2).toFixed(2)),
        volume: volBase + Math.floor(Math.random() * 500),
        openInterest: oiBase + Math.floor(Math.random() * 2000),
        impliedVolatility: Number(iv.toFixed(4)),
        delta: Number(callBS.delta.toFixed(3)),
        gamma: Number(callBS.gamma.toFixed(4)),
        theta: Number(callBS.theta.toFixed(3)),
        vega: Number(callBS.vega.toFixed(3)),
        rho: Number(callBS.rho.toFixed(3)),
        charm: Number(callBS.charm.toFixed(4)),
        vanna: Number(callBS.vanna.toFixed(4)),
        volga: Number(callBS.volga.toFixed(4)),
        theoreticalPrice: Number(callBS.price.toFixed(2)),
        exerciseStyle: 'american',
        settlement: 'physical',
        contractMultiplier: 100,
        isITM: isCallITM,
        isATM: isCallATM,
        isOTM: isCallOTM,
      });

      puts.push({
        id: `${symbol}-${exp}-${strike}-P`,
        symbol: symbol.toUpperCase(),
        underlyingPrice: spot,
        strike,
        expiration: exp,
        dte,
        type: 'put',
        bid: putBid,
        ask: putAsk,
        last: Number(((putBid + putAsk) / 2).toFixed(2)),
        volume: Math.round(volBase * 0.85) + Math.floor(Math.random() * 500),
        openInterest: Math.round(oiBase * 1.1) + Math.floor(Math.random() * 2000),
        impliedVolatility: Number((iv * 1.05).toFixed(4)), // Put skew higher
        delta: Number(putBS.delta.toFixed(3)),
        gamma: Number(putBS.gamma.toFixed(4)),
        theta: Number(putBS.theta.toFixed(3)),
        vega: Number(putBS.vega.toFixed(3)),
        rho: Number(putBS.rho.toFixed(3)),
        charm: Number(putBS.charm.toFixed(4)),
        vanna: Number(putBS.vanna.toFixed(4)),
        volga: Number(putBS.volga.toFixed(4)),
        theoreticalPrice: Number(putBS.price.toFixed(2)),
        exerciseStyle: 'american',
        settlement: 'physical',
        contractMultiplier: 100,
        isITM: isPutITM,
        isATM: isPutATM,
        isOTM: isPutOTM,
      });
    });

    const expectedMove = Number((spot * baseIV * Math.sqrt(dte / 365)).toFixed(2));

    return {
      expiration: exp,
      dte,
      calls,
      puts,
      atmStrike,
      expectedMove,
      ivRank: quote.ivRank,
      ivPercentile: quote.ivPercentile,
    };
  });
}

export function getScannerData(): MarketScannerItem[] {
  return [
    {
      symbol: 'NVDA',
      name: 'NVIDIA Corporation',
      price: 128.50,
      changePercent: 3.45,
      iv: 0.425,
      ivRank: 84,
      ivPercentile: 88,
      volume: 1850000,
      openInterest: 3200000,
      volumeOIRatio: 2.14,
      unusualActivityScore: 92,
      signal: 'UNUSUAL_CALLS',
    },
    {
      symbol: 'TSLA',
      name: 'Tesla Inc',
      price: 214.30,
      changePercent: -2.10,
      iv: 0.585,
      ivRank: 78,
      ivPercentile: 82,
      volume: 1240000,
      openInterest: 2100000,
      volumeOIRatio: 1.85,
      unusualActivityScore: 88,
      signal: 'HIGH_IV_SELL',
    },
    {
      symbol: 'SPY',
      name: 'SPDR S&P 500 ETF',
      price: 564.20,
      changePercent: 0.45,
      iv: 0.145,
      ivRank: 22,
      ivPercentile: 25,
      volume: 4500000,
      openInterest: 12000000,
      volumeOIRatio: 0.95,
      unusualActivityScore: 35,
      signal: 'LOW_IV_BUY',
    },
    {
      symbol: 'AAPL',
      name: 'Apple Inc',
      price: 226.40,
      changePercent: 1.15,
      iv: 0.225,
      ivRank: 45,
      ivPercentile: 50,
      volume: 980000,
      openInterest: 4100000,
      volumeOIRatio: 1.22,
      unusualActivityScore: 62,
      signal: 'SKEW_ANOMALY',
    },
    {
      symbol: 'MSFT',
      name: 'Microsoft Corp',
      price: 418.90,
      changePercent: -0.65,
      iv: 0.210,
      ivRank: 38,
      ivPercentile: 42,
      volume: 620000,
      openInterest: 2800000,
      volumeOIRatio: 1.10,
      unusualActivityScore: 54,
      signal: 'LOW_IV_BUY',
    },
    {
      symbol: 'QQQ',
      name: 'Invesco QQQ Trust',
      price: 488.10,
      changePercent: 0.85,
      iv: 0.182,
      ivRank: 31,
      ivPercentile: 34,
      volume: 2100000,
      openInterest: 8500000,
      volumeOIRatio: 1.05,
      unusualActivityScore: 48,
      signal: 'UNUSUAL_PUTS',
    },
  ];
}
