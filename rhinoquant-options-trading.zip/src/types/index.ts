export type OptionType = 'call' | 'put';
export type ExerciseStyle = 'american' | 'european';
export type SettlementType = 'cash' | 'physical';
export type MarketStatusType = 'OPEN' | 'PRE' | 'POST' | 'CLOSED';

export interface OptionContract {
  id: string;
  symbol: string; // e.g. NVDA
  underlyingPrice: number;
  strike: number;
  expiration: string; // YYYY-MM-DD
  dte: number; // days to expiration
  type: OptionType;
  bid: number;
  ask: number;
  last: number;
  volume: number;
  openInterest: number;
  impliedVolatility: number;
  delta: number;
  gamma: number;
  theta: number;
  vega: number;
  rho: number;
  charm?: number;
  vanna?: number;
  volga?: number;
  speed?: number;
  color?: number;
  zomma?: number;
  theoreticalPrice: number;
  exerciseStyle: ExerciseStyle;
  settlement: SettlementType;
  contractMultiplier: number; // usually 100
  isITM: boolean;
  isATM: boolean;
  isOTM: boolean;
}

export interface OptionChainExpiration {
  expiration: string;
  dte: number;
  calls: OptionContract[];
  puts: OptionContract[];
  atmStrike: number;
  expectedMove: number;
  ivRank: number;
  ivPercentile: number;
}

export interface OptionLeg {
  id: string;
  contract: OptionContract;
  action: 'BUY' | 'SELL';
  quantity: number;
  entryPrice: number;
}

export interface MultiLegStrategy {
  id: string;
  name: string;
  underlyingSymbol: string;
  underlyingPrice: number;
  legs: OptionLeg[];
  netPremium: number; // Positive = credit, Negative = debit
  maxProfit: number;
  maxLoss: number;
  breakevens: number[];
  probabilityOfProfit: number;
  marginRequirement: number;
  riskRewardRatio: number;
  expectedValue: number;
  netDelta: number;
  netGamma: number;
  netTheta: number;
  netVega: number;
  netRho: number;
}

export interface PortfolioPosition {
  id: string;
  symbol: string;
  underlyingSymbol: string;
  assetType: 'EQUITY' | 'OPTION' | 'STRATEGY';
  optionType?: OptionType;
  strike?: number;
  expiration?: string;
  quantity: number;
  avgEntryPrice: number;
  currentPrice: number;
  marketValue: number;
  unrealizedPnL: number;
  unrealizedPnLPercent: number;
  realizedPnL: number;
  delta: number;
  gamma: number;
  theta: number;
  vega: number;
  sector: string;
}

export interface AccountSummary {
  portfolioValue: number;
  cashBalance: number;
  buyingPower: number;
  todayPnL: number;
  todayPnLPercent: number;
  unrealizedPnL: number;
  realizedPnL: number;
  netDelta: number;
  netGamma: number;
  netTheta: number;
  netVega: number;
  marginUsed: number;
  marginAvailable: number;
  mode: 'PAPER' | 'LIVE';
}

export interface VolatilitySurfacePoint {
  strike: number;
  moneyness: number; // Strike / Spot
  expiration: string;
  dte: number;
  impliedVolatility: number;
  historicalVolatility: number;
  delta: number;
}

export interface VolatilityMetrics {
  symbol: string;
  spotPrice: number;
  currentIV: number;
  hv20: number;
  hv30: number;
  hv90: number;
  ivRank: number;
  ivPercentile: number;
  volRiskPremium: number; // IV - HV
  expectedMove1Sig: number;
  expectedMove2Sig: number;
  skew25Delta: number; // Put IV - Call IV
  termStructureSlope: number;
  regime: 'LOW VOL' | 'NORMAL' | 'ELEVATED' | 'EXTREME';
}

export interface RiskScenarioResult {
  priceChangePercent: number;
  volatilityChangePercent: number;
  timeDecayDays: number;
  simulatedSpot: number;
  portfolioPnL: number;
  portfolioPnLPercent: number;
  netDelta: number;
  netGamma: number;
  netVega: number;
  netTheta: number;
}

export interface BacktestConfig {
  symbol: string;
  strategyType: string;
  startDate: string;
  endDate: string;
  initialCapital: number;
  targetDTE: number;
  deltaTarget: number;
  profitTargetPercent: number;
  stopLossPercent: number;
  commissionPerContract: number;
  slippageTicks: number;
}

export interface BacktestTrade {
  id: string;
  entryDate: string;
  exitDate: string;
  symbol: string;
  strategyName: string;
  pnl: number;
  pnlPercent: number;
  holdingDays: number;
  exitReason: 'PROFIT_TARGET' | 'STOP_LOSS' | 'EXPIRATION' | 'DELTA_HEDGE';
}

export interface BacktestResult {
  id: string;
  config: BacktestConfig;
  totalReturn: number;
  cagr: number;
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdown: number;
  winRate: number;
  profitFactor: number;
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  avgTradePnL: number;
  var95: number;
  expectedShortfall: number;
  equityCurve: { date: string; equity: number; drawdown: number }[];
  trades: BacktestTrade[];
}

export interface OrderTicket {
  id: string;
  symbol: string;
  orderType: 'MARKET' | 'LIMIT' | 'STOP' | 'MULTI_LEG';
  action: 'BUY_TO_OPEN' | 'SELL_TO_CLOSE' | 'SELL_TO_OPEN' | 'BUY_TO_CLOSE';
  legs: OptionLeg[];
  quantity: number;
  limitPrice?: number;
  status: 'PENDING' | 'FILLED' | 'CANCELLED' | 'REJECTED';
  submittedAt: string;
  filledAt?: string;
  fillPrice?: number;
  commission: number;
  marginImpact: number;
  deltaImpact: number;
}

export interface MarketScannerItem {
  symbol: string;
  name: string;
  price: number;
  changePercent: number;
  iv: number;
  ivRank: number;
  ivPercentile: number;
  volume: number;
  openInterest: number;
  volumeOIRatio: number;
  unusualActivityScore: number; // 0-100
  signal: 'HIGH_IV_SELL' | 'LOW_IV_BUY' | 'UNUSUAL_CALLS' | 'UNUSUAL_PUTS' | 'SKEW_ANOMALY';
}

export interface Alert {
  id: string;
  symbol: string;
  metric: 'PRICE' | 'IV' | 'IV_RANK' | 'DELTA' | 'VOLUME_OI';
  condition: 'ABOVE' | 'BELOW';
  threshold: number;
  triggered: boolean;
  createdAt: string;
  triggeredAt?: string;
}
