import React, { useState } from 'react';
import { Alert } from '../types';
import { Bell, Plus, Trash2, CheckCircle2, X } from 'lucide-react';

interface AlertsModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedSymbol: string;
}

export const AlertsModal: React.FC<AlertsModalProps> = ({ isOpen, onClose, selectedSymbol }) => {
  const [alerts, setAlerts] = useState<Alert[]>([
    {
      id: 'alt-1',
      symbol: selectedSymbol,
      metric: 'IV_RANK',
      condition: 'ABOVE',
      threshold: 70,
      triggered: false,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'alt-2',
      symbol: 'SPY',
      metric: 'PRICE',
      condition: 'BELOW',
      threshold: 550,
      triggered: false,
      createdAt: new Date().toISOString(),
    },
  ]);

  const [metric, setMetric] = useState<Alert['metric']>('IV_RANK');
  const [condition, setCondition] = useState<'ABOVE' | 'BELOW'>('ABOVE');
  const [threshold, setThreshold] = useState<number>(75);

  if (!isOpen) return null;

  const handleAddAlert = () => {
    const newAlert: Alert = {
      id: `alt-${Date.now()}`,
      symbol: selectedSymbol,
      metric,
      condition,
      threshold,
      triggered: false,
      createdAt: new Date().toISOString(),
    };
    setAlerts([...alerts, newAlert]);
  };

  const handleDelete = (id: string) => {
    setAlerts(alerts.filter((a) => a.id !== id));
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#121214] border border-[#2A2A2E] rounded-sm w-full max-w-lg shadow-2xl p-4 font-mono text-xs text-white">
        <div className="flex items-center justify-between pb-3 border-b border-[#2A2A2E] mb-3">
          <div className="font-bold flex items-center gap-2 text-sm text-white">
            <Bell className="w-4 h-4 text-[#D4AF37]" />
            DERIVATIVE METRIC ALERTS MANAGER
          </div>
          <button onClick={onClose} className="p-1 text-[#666] hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Create Alert Form */}
        <div className="bg-[#1A1A1C] border border-[#2A2A2E] p-3 rounded-sm mb-4 flex flex-col gap-2.5">
          <div className="text-[10px] text-[#D4AF37] font-bold uppercase tracking-wider">CREATE NEW THRESHOLD ALERT FOR {selectedSymbol}</div>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-[10px] text-[#888]">Metric</label>
              <select
                value={metric}
                onChange={(e) => setMetric(e.target.value as any)}
                className="w-full bg-[#0A0A0B] border border-[#2A2A2E] p-1.5 rounded-sm text-white focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="IV_RANK">IV Rank (%)</option>
                <option value="PRICE">Spot Price ($)</option>
                <option value="IV">30D IV (%)</option>
                <option value="DELTA">Portfolio Delta</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] text-[#888]">Condition</label>
              <select
                value={condition}
                onChange={(e) => setCondition(e.target.value as any)}
                className="w-full bg-[#0A0A0B] border border-[#2A2A2E] p-1.5 rounded-sm text-white focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="ABOVE">Above (&gt;)</option>
                <option value="BELOW">Below (&lt;)</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] text-[#888]">Threshold</label>
              <input
                type="number"
                value={threshold}
                onChange={(e) => setThreshold(Number(e.target.value))}
                className="w-full bg-[#0A0A0B] border border-[#2A2A2E] p-1.5 rounded-sm text-white focus:outline-none focus:border-[#D4AF37]"
              />
            </div>
          </div>

          <button
            onClick={handleAddAlert}
            className="w-full py-2 rounded-sm bg-[#D4AF37] hover:bg-[#C49F27] text-[#0A0A0B] font-bold uppercase tracking-widest transition flex items-center justify-center gap-1.5 cursor-pointer mt-1"
          >
            <Plus className="w-4 h-4" /> ADD SYSTEM ALERT
          </button>
        </div>

        {/* Active Alerts List */}
        <div className="flex flex-col gap-2 max-h-48 overflow-y-auto">
          {alerts.map((alt) => (
            <div key={alt.id} className="bg-[#1A1A1C] border border-[#2A2A2E] p-2.5 rounded-sm flex items-center justify-between">
              <div>
                <span className="font-bold text-[#D4AF37]">{alt.symbol}</span> - {alt.metric} {alt.condition === 'ABOVE' ? '>' : '<'} {alt.threshold}
              </div>
              <button onClick={() => handleDelete(alt.id)} className="text-[#666] hover:text-red-400 p-1">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
