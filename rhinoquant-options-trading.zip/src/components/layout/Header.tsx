import React, { useState, useEffect } from 'react';
import {
  Activity,
  Shield,
  Search,
  Bell,
  Cpu,
  TrendingUp,
  Layers,
  ChevronDown,
  Terminal,
  Server,
  Zap,
} from 'lucide-react';
import { AccountSummary } from '../../types';

interface HeaderProps {
  account: AccountSummary;
  selectedSymbol: string;
  onSymbolChange: (symbol: string) => void;
  onOpenCommandPalette: () => void;
  onOpenAlerts: () => void;
  activeTab: string;
}

export const Header: React.FC<HeaderProps> = ({
  account,
  selectedSymbol,
  onSymbolChange,
  onOpenCommandPalette,
  onOpenAlerts,
  activeTab,
}) => {
  const [latency, setLatency] = useState(0.42);
  const [sessionTime, setSessionTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('en-US', {
        timeZone: 'America/New_York',
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      setSessionTime(`${timeStr} EST`);
    };

    updateTime();
    const interval = setInterval(() => {
      updateTime();
      setLatency(Number((0.35 + Math.random() * 0.2).toFixed(2)));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <header className="h-12 bg-[#121214] border-b border-[#2A2A2E] px-4 flex items-center justify-between text-xs select-none sticky top-0 z-40">
      {/* Left section: Logo & Symbol selector */}
      <div className="flex items-center space-x-5">
        <div className="flex items-center space-x-2">
          <div className="w-6 h-6 bg-[#D4AF37] rounded-sm flex items-center justify-center text-[#0A0A0B] font-bold text-xs">
            RQ
          </div>
          <span className="font-bold tracking-tighter text-lg text-white font-sans">
            RHINO<span className="font-light opacity-80 text-[#D4AF37]">QUANT</span>
          </span>
          <span className="text-[9px] px-1.5 py-0.5 rounded-sm bg-[#1A1A1C] text-[#D4AF37] border border-[#2A2A2E] font-mono tracking-widest uppercase">
            PRO v3.6
          </span>
        </div>

        <div className="h-5 w-px bg-[#2A2A2E]" />

        {/* Ticker Search Trigger */}
        <button
          onClick={onOpenCommandPalette}
          className="flex items-center space-x-2 bg-[#1A1A1C] hover:bg-[#222226] border border-[#2A2A2E] px-2.5 py-1 rounded-sm text-[#D1D1D1] font-mono text-xs transition"
        >
          <Search className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span className="font-bold text-white">{selectedSymbol}</span>
          <span className="text-[9px] text-[#666] bg-[#0A0A0B] px-1 py-0.2 rounded-sm border border-[#2A2A2E]">
            ⌘K
          </span>
        </button>

        {/* Market status badge */}
        <div className="hidden lg:flex items-center space-x-3 text-[10px] uppercase tracking-widest font-medium">
          <div className="flex flex-col">
            <span className="text-[#666]">Market</span>
            <span className="text-green-500 font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" /> OPEN
            </span>
          </div>
          <div className="flex flex-col">
            <span className="text-[#666]">Session</span>
            <span className="text-white font-mono">{sessionTime || 'NYSE/ARCA'}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[#666]">Latency</span>
            <span className="text-white font-mono">{latency}ms</span>
          </div>
        </div>
      </div>

      {/* Middle section: Key Portfolio Metrics */}
      <div className="hidden xl:flex items-center space-x-6 text-[10px] uppercase tracking-widest font-mono">
        <div className="text-right">
          <div className="text-[#666] leading-none">Net Liquidation</div>
          <div className="text-sm font-mono text-white font-bold mt-0.5">
            ${account.portfolioValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
        </div>

        <div className="text-right">
          <div className="text-[#666] leading-none">Daily P&L</div>
          <div
            className={`text-sm font-mono font-bold mt-0.5 ${
              account.todayPnL >= 0 ? 'text-green-400' : 'text-red-400'
            }`}
          >
            {account.todayPnL >= 0 ? '+' : ''}${account.todayPnL.toLocaleString()} ({account.todayPnLPercent}%)
          </div>
        </div>

        <div className="flex items-center space-x-3 bg-[#1A1A1C] px-3 py-1.5 rounded-sm border border-[#2A2A2E]">
          <div className="flex flex-col text-right">
            <span className="text-[#666] text-[8px]">NET Δ</span>
            <span className={`font-semibold text-[11px] ${account.netDelta >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {account.netDelta}
            </span>
          </div>
          <div className="w-px h-5 bg-[#2A2A2E]" />
          <div className="flex flex-col text-right">
            <span className="text-[#666] text-[8px]">NET VEGA</span>
            <span className="font-semibold text-cyan-400 text-[11px]">+${account.netVega}</span>
          </div>
          <div className="w-px h-5 bg-[#2A2A2E]" />
          <div className="flex flex-col text-right">
            <span className="text-[#666] text-[8px]">NET THETA</span>
            <span className="font-semibold text-[#D4AF37] text-[11px]">+${account.netTheta}/d</span>
          </div>
        </div>
      </div>

      {/* Right section: Paper/Live Mode & Alerts */}
      <div className="flex items-center space-x-3 font-mono">
        {/* Paper/Live mode */}
        <div className="flex bg-[#1A1A1C] p-0.5 rounded-sm border border-[#2A2A2E]">
          <span
            className={`px-2 py-0.5 rounded-sm text-[9px] font-bold ${
              account.mode === 'PAPER'
                ? 'bg-[#D4AF37] text-[#0A0A0B]'
                : 'text-[#666]'
            }`}
          >
            PAPER
          </span>
          <span
            className={`px-2 py-0.5 rounded-sm text-[9px] font-bold ${
              account.mode === 'LIVE'
                ? 'bg-green-500 text-[#0A0A0B]'
                : 'text-[#666]'
            }`}
          >
            LIVE
          </span>
        </div>

        {/* Alerts button */}
        <button
          onClick={onOpenAlerts}
          className="p-1.5 rounded-sm bg-[#1A1A1C] hover:bg-[#222226] border border-[#2A2A2E] text-white relative transition"
          title="Active System Alerts"
        >
          <Bell className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
        </button>

        {/* User Account Menu */}
        <div className="flex items-center space-x-2 bg-[#1A1A1C] px-2.5 py-1 rounded-sm border border-[#2A2A2E] text-white cursor-pointer hover:border-[#D4AF37] transition">
          <div className="w-5 h-5 rounded-sm bg-[#2A2A2E] border border-[#D4AF37]/50 flex items-center justify-center text-[9px] font-bold text-[#D4AF37]">
            QD
          </div>
          <span className="hidden sm:inline font-semibold text-[#D1D1D1] text-[11px]">QUANT_DESK</span>
          <ChevronDown className="w-3 h-3 text-[#666]" />
        </div>
      </div>
    </header>
  );
};
