import React from 'react';
import {
  Terminal,
  Layers,
  Activity,
  Boxes,
  PieChart,
  ShieldAlert,
  History,
  Code2,
  Filter,
  Play,
  Database,
  FileText,
  Settings,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

export interface SidebarProps {
  activeTab: string;
  onTabChange: (tabId: string) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export const NAV_ITEMS = [
  { id: 'terminal', label: '1. Terminal', icon: Terminal, category: 'TRADING' },
  { id: 'chains', label: '2. Options Chains', icon: Layers, category: 'TRADING' },
  { id: 'volatility', label: '3. Volatility Surface', icon: Activity, category: 'ANALYTICS' },
  { id: 'strategy', label: '4. Strategy Builder', icon: Boxes, category: 'ANALYTICS' },
  { id: 'portfolio', label: '5. Portfolio', icon: PieChart, category: 'MANAGEMENT' },
  { id: 'risk', label: '6. Risk Engine', icon: ShieldAlert, category: 'MANAGEMENT' },
  { id: 'backtest', label: '7. Backtesting', icon: History, category: 'RESEARCH' },
  { id: 'quant', label: '8. Quant Research', icon: Code2, category: 'RESEARCH' },
  { id: 'strategylab', label: '9. Strategy Lab', icon: Play, category: 'RESEARCH' },
  { id: 'scanner', label: '10. Market Scanner', icon: Filter, category: 'MARKET' },
  { id: 'execution', label: '11. Execution', icon: Play, category: 'EXECUTION' },
  { id: 'data', label: '12. System & Data', icon: Database, category: 'SYSTEM' },
  { id: 'reports', label: '13. Reports & Settings', icon: FileText, category: 'SYSTEM' },
];

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  collapsed,
  onToggleCollapse,
}) => {
  return (
    <aside
      className={`bg-[#0E0E10] border-r border-[#2A2A2E] transition-all duration-200 flex flex-col justify-between select-none z-30 ${
        collapsed ? 'w-12' : 'w-56'
      }`}
    >
      <div className="py-2.5 px-1.5 flex flex-col gap-1 overflow-y-auto font-mono text-xs">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex items-center gap-2.5 px-3 py-2 rounded-sm transition ${
                isActive
                  ? 'bg-[#1A1A1C] border border-[#D4AF37] text-[#D4AF37] font-bold shadow-sm'
                  : 'text-[#888] hover:text-white hover:bg-[#1A1A1C] border border-transparent'
              }`}
              title={collapsed ? item.label : undefined}
            >
              <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-[#D4AF37]' : 'text-[#666]'}`} />
              {!collapsed && <span className="truncate text-[11px] tracking-tight">{item.label}</span>}
            </button>
          );
        })}
      </div>

      <div className="p-2 border-t border-[#2A2A2E] flex items-center justify-between bg-[#0E0E10]">
        {!collapsed && (
          <div className="text-[9px] text-[#666] font-mono px-2 uppercase tracking-widest">
            ENV: <span className="text-green-500 font-bold">PROD_HOST</span>
          </div>
        )}
        <button
          onClick={onToggleCollapse}
          className="p-1 rounded-sm bg-[#1A1A1C] hover:bg-[#222226] text-[#888] hover:text-white border border-[#2A2A2E] transition ml-auto"
          title={collapsed ? 'Expand Navigation' : 'Collapse Navigation'}
        >
          {collapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
        </button>
      </div>
    </aside>
  );
};
