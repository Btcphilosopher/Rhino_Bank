import React, { useState, useEffect } from 'react';
import { Search, Terminal, Layers, Activity, ShieldAlert, History, ArrowRight } from 'lucide-react';
import { SUPPORTED_SYMBOLS } from '../../services/syntheticMarketData';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSymbol: (symbol: string) => void;
  onSelectTab: (tabId: string) => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onSelectSymbol,
  onSelectTab,
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else setQuery('');
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const symbols = Object.keys(SUPPORTED_SYMBOLS);

  const filteredSymbols = symbols.filter(
    (sym) =>
      sym.toLowerCase().includes(query.toLowerCase()) ||
      SUPPORTED_SYMBOLS[sym].name.toLowerCase().includes(query.toLowerCase())
  );

  const commands = [
    { id: 'terminal', label: 'Open Options Terminal', icon: Terminal, action: () => onSelectTab('terminal') },
    { id: 'chains', label: 'Open Options Chain Grid', icon: Layers, action: () => onSelectTab('chains') },
    { id: 'volatility', label: 'Inspect Volatility Surface', icon: Activity, action: () => onSelectTab('volatility') },
    { id: 'risk', label: 'Run Risk Stress Engine', icon: ShieldAlert, action: () => onSelectTab('risk') },
    { id: 'backtest', label: 'Open Backtesting Workbench', icon: History, action: () => onSelectTab('backtest') },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-start justify-center pt-20 p-4">
      <div className="bg-[#121214] border border-[#2A2A2E] rounded-sm w-full max-w-xl shadow-2xl overflow-hidden font-mono text-xs">
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-[#2A2A2E] bg-[#1A1A1C]">
          <Search className="w-4 h-4 text-[#D4AF37]" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type ticker (e.g. SPY, NVDA, AAPL) or command..."
            className="w-full bg-transparent text-white placeholder-[#666] focus:outline-none text-sm font-mono"
            autoFocus
          />
          <kbd className="px-2 py-0.5 text-[10px] bg-[#0A0A0B] text-[#888] rounded-sm border border-[#2A2A2E]">
            ESC
          </kbd>
        </div>

        {/* Results Body */}
        <div className="p-3 max-h-96 overflow-y-auto flex flex-col gap-3 bg-[#0A0A0B]">
          {/* Symbols Section */}
          <div>
            <div className="text-[10px] text-[#666] uppercase tracking-wider mb-1.5 px-2 font-semibold">
              Supported Tickers & Market Instruments
            </div>
            <div className="grid grid-cols-1 gap-1">
              {filteredSymbols.map((sym) => {
                const info = SUPPORTED_SYMBOLS[sym];
                return (
                  <button
                    key={sym}
                    onClick={() => {
                      onSelectSymbol(sym);
                      onClose();
                    }}
                    className="flex items-center justify-between px-3 py-2 rounded-sm bg-[#121214] hover:bg-[#1A1A1C] border border-[#2A2A2E] text-slate-200 transition text-left group"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="font-bold text-[#D4AF37] text-sm">{sym}</span>
                      <span className="text-[#888] text-xs">{info.name}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-bold text-white">${info.spot.toFixed(2)}</span>
                      <span className="text-cyan-400 text-[11px]">IV {(info.iv * 100).toFixed(1)}%</span>
                      <ArrowRight className="w-3.5 h-3.5 text-[#666] group-hover:text-[#D4AF37] transition" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick Views */}
          <div>
            <div className="text-[10px] text-[#666] uppercase tracking-wider mb-1.5 px-2 font-semibold">
              Platform Views & Systems
            </div>
            <div className="grid grid-cols-1 gap-1">
              {commands.map((cmd) => {
                const Icon = cmd.icon;
                return (
                  <button
                    key={cmd.id}
                    onClick={() => {
                      cmd.action();
                      onClose();
                    }}
                    className="flex items-center justify-between px-3 py-2 rounded-sm bg-[#121214] hover:bg-[#1A1A1C] border border-[#2A2A2E] text-[#D1D1D1] transition group"
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4 text-[#888] group-hover:text-[#D4AF37] transition" />
                      <span>{cmd.label}</span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-[#666] group-hover:text-[#D4AF37] transition" />
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
