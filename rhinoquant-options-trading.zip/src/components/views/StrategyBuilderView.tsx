import React, { useState } from 'react';
import { MarketQuote } from '../../services/syntheticMarketData';
import { OptionChainExpiration, OptionLeg } from '../../types';
import { evaluateStrategy } from '../../quant/strategyEngine';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
} from 'recharts';
import { Boxes, Sliders, Play, Plus, Trash2, Send, Cpu } from 'lucide-react';

interface StrategyBuilderViewProps {
  quote: MarketQuote;
  chain: OptionChainExpiration[];
  initialLegs?: OptionLeg[];
  onOpenOrderTicket: (legs: OptionLeg[]) => void;
}

export const StrategyBuilderView: React.FC<StrategyBuilderViewProps> = ({
  quote,
  chain,
  initialLegs = [],
  onOpenOrderTicket,
}) => {
  const [legs, setLegs] = useState<OptionLeg[]>(initialLegs);
  const [timeDecayDays, setTimeDecayDays] = useState(0);
  const [volShiftPercent, setVolShiftPercent] = useState(0);
  const [pricingModel, setPricingModel] = useState<'BS' | 'BINOMIAL' | 'MONTE_CARLO'>('BS');

  const currentExp = chain[2] || chain[0]; // 30D default

  // Preset Template loader
  const applyPreset = (presetType: string) => {
    const spot = quote.price;
    const calls = currentExp?.calls || [];
    const puts = currentExp?.puts || [];

    const getStrikeNear = (mult: number) => {
      const target = spot * mult;
      return calls.reduce((prev, curr) =>
        Math.abs(curr.strike - target) < Math.abs(prev.strike - target) ? curr : prev
      );
    };

    if (presetType === 'IRON_CONDOR') {
      const longPut = puts.find((p) => p.strike === getStrikeNear(0.92).strike) || puts[0];
      const shortPut = puts.find((p) => p.strike === getStrikeNear(0.96).strike) || puts[1];
      const shortCall = calls.find((c) => c.strike === getStrikeNear(1.04).strike) || calls[calls.length - 2];
      const longCall = calls.find((c) => c.strike === getStrikeNear(1.08).strike) || calls[calls.length - 1];

      setLegs([
        { id: '1', contract: longPut, action: 'BUY', quantity: 1, entryPrice: longPut.ask },
        { id: '2', contract: shortPut, action: 'SELL', quantity: 1, entryPrice: shortPut.bid },
        { id: '3', contract: shortCall, action: 'SELL', quantity: 1, entryPrice: shortCall.bid },
        { id: '4', contract: longCall, action: 'BUY', quantity: 1, entryPrice: longCall.ask },
      ]);
    } else if (presetType === 'BULL_CALL_SPREAD') {
      const longCall = calls.find((c) => c.strike === getStrikeNear(0.98).strike) || calls[0];
      const shortCall = calls.find((c) => c.strike === getStrikeNear(1.04).strike) || calls[1];

      setLegs([
        { id: '1', contract: longCall, action: 'BUY', quantity: 1, entryPrice: longCall.ask },
        { id: '2', contract: shortCall, action: 'SELL', quantity: 1, entryPrice: shortCall.bid },
      ]);
    } else if (presetType === 'LONG_STRADDLE') {
      const atmCall = calls.find((c) => c.isATM) || calls[0];
      const atmPut = puts.find((p) => p.isATM) || puts[0];

      setLegs([
        { id: '1', contract: atmCall, action: 'BUY', quantity: 1, entryPrice: atmCall.ask },
        { id: '2', contract: atmPut, action: 'BUY', quantity: 1, entryPrice: atmPut.ask },
      ]);
    }
  };

  const { strategy, payoffCurve } = evaluateStrategy(
    quote.symbol,
    quote.price,
    legs,
    0.045,
    timeDecayDays,
    volShiftPercent
  );

  return (
    <div className="flex-1 flex flex-col gap-3 p-3 overflow-y-auto font-mono text-xs bg-[#0A0A0B]">
      {/* Preset Strategy Buttons & Model Switcher */}
      <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-[#666] font-bold text-xs uppercase tracking-wider">PRESET STRATEGIES:</span>
          <button
            onClick={() => applyPreset('IRON_CONDOR')}
            className="px-2.5 py-1 rounded-sm bg-[#1A1A1C] hover:bg-[#222226] hover:text-[#D4AF37] border border-[#2A2A2E] text-white transition"
          >
            Iron Condor
          </button>
          <button
            onClick={() => applyPreset('BULL_CALL_SPREAD')}
            className="px-2.5 py-1 rounded-sm bg-[#1A1A1C] hover:bg-[#222226] hover:text-green-400 border border-[#2A2A2E] text-white transition"
          >
            Bull Call Spread
          </button>
          <button
            onClick={() => applyPreset('LONG_STRADDLE')}
            className="px-2.5 py-1 rounded-sm bg-[#1A1A1C] hover:bg-[#222226] hover:text-cyan-400 border border-[#2A2A2E] text-white transition"
          >
            Long Straddle
          </button>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[#666] font-bold tracking-wider">MODEL:</span>
          <div className="flex bg-[#1A1A1C] p-0.5 rounded-sm border border-[#2A2A2E]">
            {(['BS', 'BINOMIAL', 'MONTE_CARLO'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setPricingModel(m)}
                className={`px-2 py-0.5 rounded-sm text-[10px] font-bold transition ${
                  pricingModel === m
                    ? 'bg-[#D4AF37] text-[#0A0A0B]'
                    : 'text-[#888]'
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Grid: Interactive Payoff Chart & Simulation Sliders */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
        {/* Payoff Chart (2 Columns) */}
        <div className="lg:col-span-2 bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="font-bold text-white flex items-center gap-2 text-xs">
              <Boxes className="w-4 h-4 text-[#D4AF37]" />
              INTERACTIVE MULTI-LEG PAYOFF DIAGRAM ($P&L VS UNDERLYING SPOT)
            </div>
            <div className="flex items-center gap-3 text-[11px]">
              <span className="flex items-center gap-1 text-green-400 font-bold">
                <span className="w-2.5 h-0.5 bg-green-400 inline-block" /> Expiration Payoff
              </span>
              <span className="flex items-center gap-1 text-cyan-400 font-bold">
                <span className="w-2.5 h-0.5 bg-cyan-400 inline-block" /> Theoretical (T+{timeDecayDays}d)
              </span>
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={payoffCurve}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2A2A2E" />
                <XAxis dataKey="spot" stroke="#666" tick={{ fontSize: 10 }} />
                <YAxis stroke="#666" tick={{ fontSize: 10 }} domain={['auto', 'auto']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#121214', borderColor: '#2A2A2E', fontSize: '11px', color: '#fff' }}
                />
                <ReferenceLine y={0} stroke="#444" strokeDasharray="2 2" />
                <ReferenceLine x={quote.price} stroke="#D4AF37" strokeWidth={1.5} label={{ value: 'SPOT', fill: '#D4AF37', fontSize: 10 }} />
                <Line type="monotone" dataKey="expirationPnL" name="Expiration PnL ($)" stroke="#10b981" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="theoreticalPnL" name="Theoretical PnL ($)" stroke="#00d2ff" strokeWidth={2} strokeDasharray="4 4" dot={false} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>

          {/* Time & Volatility Scenario Sliders */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#1A1A1C] p-3 rounded-sm border border-[#2A2A2E]">
            <div>
              <div className="flex justify-between text-[#D1D1D1] font-bold mb-1">
                <span>TIME ELAPSED SLIDER:</span>
                <span className="text-[#D4AF37]">T+{timeDecayDays} Days</span>
              </div>
              <input
                type="range"
                min={0}
                max={45}
                value={timeDecayDays}
                onChange={(e) => setTimeDecayDays(Number(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[#D1D1D1] font-bold mb-1">
                <span>VOLATILITY SHOCK SHIFT:</span>
                <span className="text-cyan-400">{volShiftPercent >= 0 ? '+' : ''}{volShiftPercent}% IV</span>
              </div>
              <input
                type="range"
                min={-20}
                max={20}
                value={volShiftPercent}
                onChange={(e) => setVolShiftPercent(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Calculated Analytics Card */}
        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex flex-col justify-between gap-3 font-mono">
          <div>
            <div className="text-xs font-bold text-white pb-2 border-b border-[#2A2A2E] uppercase tracking-wider mb-3">
              QUANTITATIVE STRATEGY EVALUATION
            </div>

            <div className="flex flex-col gap-2.5">
              <div className="flex justify-between border-b border-[#2A2A2E] pb-1">
                <span className="text-[#888]">NET PREMIUM:</span>
                <span className={`font-bold ${strategy.netPremium >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {strategy.netPremium >= 0 ? 'CREDIT ' : 'DEBIT '}${Math.abs(strategy.netPremium).toFixed(2)}
                </span>
              </div>

              <div className="flex justify-between border-b border-[#2A2A2E] pb-1">
                <span className="text-[#888]">MAX PROFIT:</span>
                <span className="font-bold text-green-400">${strategy.maxProfit}</span>
              </div>

              <div className="flex justify-between border-b border-[#2A2A2E] pb-1">
                <span className="text-[#888]">MAX LOSS:</span>
                <span className="font-bold text-red-400">${strategy.maxLoss}</span>
              </div>

              <div className="flex justify-between border-b border-[#2A2A2E] pb-1">
                <span className="text-[#888]">PROBABILITY OF PROFIT:</span>
                <span className="font-bold text-cyan-400">{strategy.probabilityOfProfit}%</span>
              </div>

              <div className="flex justify-between border-b border-[#2A2A2E] pb-1">
                <span className="text-[#888]">BREAKEVEN POINTS:</span>
                <span className="font-bold text-[#D4AF37]">
                  {strategy.breakevens.length > 0 ? strategy.breakevens.map((b) => `$${b}`).join(' | ') : 'N/A'}
                </span>
              </div>

              <div className="flex justify-between border-b border-[#2A2A2E] pb-1">
                <span className="text-[#888]">NET DELTA:</span>
                <span className="font-bold text-white">{strategy.netDelta}</span>
              </div>

              <div className="flex justify-between border-b border-[#2A2A2E] pb-1">
                <span className="text-[#888]">NET THETA (DAILY):</span>
                <span className="font-bold text-[#D4AF37]">+${strategy.netTheta}/d</span>
              </div>

              <div className="flex justify-between">
                <span className="text-[#888]">NET VEGA:</span>
                <span className="font-bold text-cyan-400">+${strategy.netVega}</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onOpenOrderTicket(legs)}
            disabled={legs.length === 0}
            className={`w-full py-2.5 rounded-sm font-bold text-xs flex items-center justify-center gap-2 transition uppercase tracking-widest ${
              legs.length > 0
                ? 'bg-[#D4AF37] hover:bg-[#C49F27] text-[#0A0A0B] cursor-pointer'
                : 'bg-[#1A1A1C] text-[#666] cursor-not-allowed border border-[#2A2A2E]'
            }`}
          >
            <Send className="w-4 h-4" />
            TRANSMIT STRATEGY TO PAPER TRADING
          </button>
        </div>
      </div>
    </div>
  );
};
