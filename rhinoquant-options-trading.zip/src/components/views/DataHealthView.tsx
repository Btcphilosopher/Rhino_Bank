import React, { useEffect, useState } from 'react';
import { Database, Server, Zap, Activity, CheckCircle2 } from 'lucide-react';

export const DataHealthView: React.FC = () => {
  const [healthData, setHealthData] = useState<any>(null);

  useEffect(() => {
    fetch('/api/health')
      .then((r) => r.json())
      .then((data) => setHealthData(data))
      .catch(() => {});
  }, []);

  return (
    <div className="flex-1 flex flex-col gap-3 p-3 overflow-y-auto font-mono text-xs bg-[#0A0A0B]">
      <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex items-center justify-between">
        <div className="font-bold text-white flex items-center gap-2 uppercase tracking-wider text-xs">
          <Database className="w-4 h-4 text-[#D4AF37]" />
          SYSTEM DIAGNOSTICS & MARKET DATA FEED HEALTH
        </div>
        <div className="text-green-400 font-bold flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
          <CheckCircle2 className="w-4 h-4 text-green-400" /> ALL SYSTEMS OPERATIONAL
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">DATA FEED LATENCY</div>
          <div className="text-xl font-bold text-cyan-400 mt-1">{healthData?.dataLatencyMs || 0.8} ms</div>
          <div className="text-[10px] text-[#888] mt-0.5">Streaming Market Quotes Active</div>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">PRICING ENGINE ENGINE</div>
          <div className="text-xl font-bold text-[#D4AF37] mt-1">Black-Scholes & Binomial CRR</div>
          <div className="text-[10px] text-[#888] mt-0.5">Double-precision Vectorized</div>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">RELATIONAL SCHEMA STATUS</div>
          <div className="text-xl font-bold text-green-400 mt-1">16 Entities Indexed</div>
          <div className="text-[10px] text-[#888] mt-0.5">Postgres / SQLite In-Memory</div>
        </div>
      </div>

      <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex-1">
        <div className="font-bold text-white mb-2 uppercase tracking-wider text-xs">SYSTEM AUDIT LOGS</div>
        <div className="bg-[#1A1A1C] border border-[#2A2A2E] p-3 rounded-sm font-mono text-green-400 text-xs space-y-1">
          <div>[2026-09-01T02:54:19] [INFO] RhinoQuant Engine Initialized</div>
          <div>[2026-09-01T02:54:20] [INFO] MockBrokerAdapter connected to Cloud Engine</div>
          <div>[2026-09-01T02:54:21] [INFO] Option Chains generated for NVDA, SPY, QQQ, AAPL, MSFT, TSLA, BTC</div>
          <div>[2026-09-01T02:54:22] [INFO] Volatility Surface fitted using parameterized SVI model</div>
        </div>
      </div>
    </div>
  );
};
