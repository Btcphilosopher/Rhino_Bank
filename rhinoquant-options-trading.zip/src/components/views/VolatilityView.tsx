import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { MarketQuote } from '../../services/syntheticMarketData';
import { generateVolatilitySurface } from '../../quant/volatilitySurface';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { Activity, RotateCcw, Zap, Compass, ShieldAlert } from 'lucide-react';

interface VolatilityViewProps {
  quote: MarketQuote;
}

export const VolatilityView: React.FC<VolatilityViewProps> = ({ quote }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [wireframe, setWireframe] = useState(false);

  const volData = generateVolatilitySurface(quote.symbol, quote.price, quote.iv);

  // 3D Volatility Surface rendering with Three.js
  useEffect(() => {
    if (!mountRef.current) return;

    const width = mountRef.current.clientWidth;
    const height = mountRef.current.clientHeight || 340;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a0b);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(30, 25, 35);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(window.devicePixelRatio);

    mountRef.current.innerHTML = '';
    mountRef.current.appendChild(renderer.domElement);

    // Create 3D Surface Grid
    const xSegments = 18;
    const ySegments = 12;
    const geometry = new THREE.PlaneGeometry(30, 20, xSegments, ySegments);

    const positions = geometry.attributes.position;
    const colors: number[] = [];

    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i);
      const y = positions.getY(i);

      // Height Z based on SVI implied volatility smile math
      const moneyness = 1.0 + x / 30;
      const termDte = 30 + (y + 10) * 8;
      const termFactor = 1.0 + 0.12 * Math.exp(-termDte / 45);
      const k = Math.log(moneyness);
      const skew = -0.35 * k + 0.85 * k * k;
      const iv = quote.iv * termFactor * (1.0 + skew);

      const zHeight = (iv - 0.1) * 30;
      positions.setZ(i, zHeight);

      // Color gradient based on IV height (Cyan -> Amber -> Crimson)
      if (iv > 0.45) {
        colors.push(0.9, 0.2, 0.3); // High IV red
      } else if (iv > 0.28) {
        colors.push(0.9, 0.6, 0.1); // Amber
      } else {
        colors.push(0.0, 0.8, 0.9); // Cyan
      }
    }

    geometry.computeVertexNormals();
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

    const material = new THREE.MeshBasicMaterial({
      vertexColors: true,
      wireframe: wireframe,
      side: THREE.DoubleSide,
    });

    const mesh = new THREE.Mesh(geometry, material);
    mesh.rotation.x = -Math.PI / 3;
    scene.add(mesh);

    // Add Grid Floor Helpers
    const gridHelper = new THREE.GridHelper(40, 20, 0x334155, 0x1e293b);
    gridHelper.position.y = -2;
    scene.add(gridHelper);

    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      mesh.rotation.z += 0.003; // Gentle rotation
      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!mountRef.current) return;
      const w = mountRef.current.clientWidth;
      const h = mountRef.current.clientHeight || 340;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, [quote, wireframe]);

  const smileData30D = volData.surfacePoints
    .filter((p) => p.expiration === '30D')
    .map((p) => ({
      strike: p.strike,
      iv: Number((p.impliedVolatility * 100).toFixed(1)),
      hv: Number((p.historicalVolatility * 100).toFixed(1)),
    }));

  const termStructureData = volData.surfacePoints
    .filter((p) => p.moneyness === 1.0)
    .map((p) => ({
      expiration: p.expiration,
      dte: p.dte,
      atmIV: Number((p.impliedVolatility * 100).toFixed(1)),
    }));

  return (
    <div className="flex-1 flex flex-col gap-3 p-3 overflow-y-auto font-mono text-xs bg-[#0A0A0B]">
      {/* Metrics & Volatility Intelligence Header */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">ATM IMPLIED VOL (30D)</div>
          <div className="text-xl font-bold text-cyan-400 mt-1">{(volData.metrics.currentIV * 100).toFixed(1)}%</div>
          <div className="text-[10px] text-[#888] mt-0.5">HV30: {(volData.metrics.hv30 * 100).toFixed(1)}%</div>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">IV RANK / PERCENTILE</div>
          <div className="text-xl font-bold text-[#D4AF37] mt-1">
            {volData.metrics.ivRank}% / {volData.metrics.ivPercentile}%
          </div>
          <div className="text-[10px] text-[#888] mt-0.5">Vol Premium: +{(volData.metrics.volRiskPremium * 100).toFixed(1)}%</div>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">25-DELTA SKEW</div>
          <div className="text-xl font-bold text-green-400 mt-1">+{volData.metrics.skew25Delta}%</div>
          <div className="text-[10px] text-[#888] mt-0.5">Put IV - Call IV Spread</div>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">VOLATILITY REGIME</div>
          <div className="text-xs font-bold mt-1 px-2 py-0.5 rounded-sm inline-block bg-[#1A1A1C] text-[#D4AF37] border border-[#D4AF37]">
            {volData.metrics.regime}
          </div>
          <div className="text-[10px] text-[#888] mt-1">Statistical Threshold Active</div>
        </div>
      </div>

      {/* 3D Volatility Surface Renderer Panel */}
      <div className="bg-[#121214] border border-[#2A2A2E] rounded-sm p-3 flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div className="font-bold text-white flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#D4AF37]" />
            3D IMPLIED VOLATILITY SURFACE (STRIKE x EXPIRATION x IV)
          </div>
          <button
            onClick={() => setWireframe(!wireframe)}
            className="px-2.5 py-1 rounded-sm bg-[#1A1A1C] border border-[#2A2A2E] text-[#D1D1D1] text-[11px] hover:border-[#D4AF37]"
          >
            {wireframe ? 'Solid Surface' : 'Wireframe Mode'}
          </button>
        </div>

        <div ref={mountRef} className="w-full h-80 rounded-sm overflow-hidden border border-[#2A2A2E]" />
      </div>

      {/* 2D Volatility Skew & Term Structure Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {/* Volatility Smile Curve */}
        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex flex-col gap-2">
          <div className="font-bold text-white text-xs">VOLATILITY SMILE & SKEW (30D EXPIRATION)</div>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={smileData30D}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2A2A2E" />
                <XAxis dataKey="strike" stroke="#666" tick={{ fontSize: 10 }} />
                <YAxis stroke="#666" tick={{ fontSize: 10 }} domain={['auto', 'auto']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#121214', borderColor: '#2A2A2E', fontSize: '11px', color: '#fff' }}
                />
                <Line type="monotone" dataKey="iv" name="Implied Vol (%)" stroke="#D4AF37" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="hv" name="Historical Vol (%)" stroke="#10b981" strokeWidth={1.5} strokeDasharray="3 3" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Term Structure Curve */}
        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex flex-col gap-2">
          <div className="font-bold text-white text-xs">ATM VOLATILITY TERM STRUCTURE (7D - 180D)</div>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={termStructureData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2A2A2E" />
                <XAxis dataKey="expiration" stroke="#666" tick={{ fontSize: 10 }} />
                <YAxis stroke="#666" tick={{ fontSize: 10 }} domain={['auto', 'auto']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#121214', borderColor: '#2A2A2E', fontSize: '11px', color: '#fff' }}
                />
                <Line type="monotone" dataKey="atmIV" name="ATM IV (%)" stroke="#22d3ee" strokeWidth={2} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
