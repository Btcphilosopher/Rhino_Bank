import React, { useState } from 'react';
import { OptionChainExpiration, OptionContract } from '../../types';
import { MarketQuote } from '../../services/syntheticMarketData';
import { Sliders, Activity, Filter, Eye } from 'lucide-react';

interface OptionsChainViewProps {
  quote: MarketQuote;
  chain: OptionChainExpiration[];
  onSelectContract: (contract: OptionContract) => void;
}

export const OptionsChainView: React.FC<OptionsChainViewProps> = ({
  quote,
  chain,
  onSelectContract,
}) => {
  const [selectedExpIndex, setSelectedExpIndex] = useState(2);
  const [showGreeks, setShowGreeks] = useState(true);
  const [showVolumeOI, setShowVolumeOI] = useState(true);

  const currentExpiration = chain[selectedExpIndex] || chain[0];

  return (
    <div className="flex-1 flex flex-col gap-3 p-3 overflow-y-auto font-mono text-xs bg-[#0A0A0B]">
      {/* Top Filter & Settings Header */}
      <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="text-sm font-bold text-white flex items-center gap-2">
            <span>{quote.symbol} OPTION CHAIN WORKBENCH</span>
            <span className="text-xs font-normal text-[#888]">Spot: ${quote.price.toFixed(2)}</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowGreeks(!showGreeks)}
            className={`px-2.5 py-1 rounded-sm text-xs transition border ${
              showGreeks
                ? 'bg-[#1A1A1C] text-[#D4AF37] border-[#D4AF37]'
                : 'bg-[#1A1A1C] text-[#888] border-[#2A2A2E] hover:text-white'
            }`}
          >
            {showGreeks ? 'Hide Higher Greeks' : 'Show Higher Greeks'}
          </button>

          <button
            onClick={() => setShowVolumeOI(!showVolumeOI)}
            className={`px-2.5 py-1 rounded-sm text-xs transition border ${
              showVolumeOI
                ? 'bg-[#1A1A1C] text-cyan-400 border-cyan-400'
                : 'bg-[#1A1A1C] text-[#888] border-[#2A2A2E] hover:text-white'
            }`}
          >
            {showVolumeOI ? 'Volume / OI Metrics' : 'Hide Vol/OI'}
          </button>
        </div>
      </div>

      {/* Expiration Selector */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {chain.map((expItem, idx) => (
          <button
            key={expItem.expiration}
            onClick={() => setSelectedExpIndex(idx)}
            className={`px-3 py-2 rounded-sm text-xs border transition shrink-0 ${
              idx === selectedExpIndex
                ? 'bg-[#1A1A1C] text-[#D4AF37] border-[#D4AF37] font-bold shadow-sm'
                : 'bg-[#121214] text-[#888] border-[#2A2A2E] hover:bg-[#1A1A1C] hover:text-white'
            }`}
          >
            <div>{expItem.expiration}</div>
            <div className="text-[10px] opacity-75">
              {expItem.dte} DTE | IV {(expItem.calls[0]?.impliedVolatility * 100 || 28).toFixed(1)}%
            </div>
          </button>
        ))}
      </div>

      {/* Comprehensive Option Grid */}
      <div className="bg-[#121214] border border-[#2A2A2E] rounded-sm overflow-hidden flex-1 min-h-[500px]">
        <div className="overflow-x-auto overflow-y-auto max-h-[600px]">
          <table className="w-full text-left text-[11px] border-collapse">
            <thead className="bg-[#1A1A1C] text-[#666] uppercase tracking-wider sticky top-0 z-20 border-b border-[#2A2A2E]">
              <tr>
                <th colSpan={showGreeks ? 10 : 6} className="px-2 py-1.5 text-center text-cyan-400 bg-cyan-950/20 border-r border-[#2A2A2E]">
                  CALL OPTIONS
                </th>
                <th className="px-3 py-1.5 text-center text-[#D4AF37] bg-[#1F1F24] border-r border-[#2A2A2E]">
                  STRIKE
                </th>
                <th colSpan={showGreeks ? 10 : 6} className="px-2 py-1.5 text-center text-rose-400 bg-rose-950/20">
                  PUT OPTIONS
                </th>
              </tr>
              <tr className="border-b border-[#2A2A2E] text-[10px] text-[#666]">
                <th className="px-2 py-1">Bid</th>
                <th className="px-2 py-1">Ask</th>
                <th className="px-2 py-1">Theo</th>
                <th className="px-2 py-1">IV</th>
                <th className="px-2 py-1">Vol</th>
                <th className="px-2 py-1">OI</th>
                <th className="px-2 py-1">Δ</th>
                <th className="px-2 py-1">Γ</th>
                {showGreeks && <th className="px-2 py-1">Charm</th>}
                {showGreeks && <th className="px-2 py-1 border-r border-[#2A2A2E]">Vanna</th>}

                <th className="px-3 py-1 text-center border-r border-[#2A2A2E]">ATM</th>

                <th className="px-2 py-1">Bid</th>
                <th className="px-2 py-1">Ask</th>
                <th className="px-2 py-1">Theo</th>
                <th className="px-2 py-1">IV</th>
                <th className="px-2 py-1">Vol</th>
                <th className="px-2 py-1">OI</th>
                <th className="px-2 py-1">Δ</th>
                <th className="px-2 py-1">Γ</th>
                {showGreeks && <th className="px-2 py-1">Charm</th>}
                {showGreeks && <th className="px-2 py-1">Vanna</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A2A2E]">
              {(currentExpiration?.calls || []).map((call, idx) => {
                const put = (currentExpiration?.puts || [])[idx] || call;
                const isATM = call.isATM;

                return (
                  <tr
                    key={call.strike}
                    onClick={() => onSelectContract(call)}
                    className={`hover:bg-[#1A1A1C] cursor-pointer transition ${
                      isATM ? 'bg-[#1F1F24] font-bold border-y border-[#D4AF37]/40' : ''
                    }`}
                  >
                    <td className={`px-2 py-1.5 text-green-400 ${call.isITM ? 'bg-cyan-950/20' : ''}`}>
                      ${call.bid.toFixed(2)}
                    </td>
                    <td className={`px-2 py-1.5 text-green-300 ${call.isITM ? 'bg-cyan-950/20' : ''}`}>
                      ${call.ask.toFixed(2)}
                    </td>
                    <td className="px-2 py-1.5 text-[#888]">${call.theoreticalPrice.toFixed(2)}</td>
                    <td className="px-2 py-1.5 text-cyan-400">{(call.impliedVolatility * 100).toFixed(1)}%</td>
                    <td className="px-2 py-1.5 text-slate-300">{call.volume}</td>
                    <td className="px-2 py-1.5 text-slate-300">{call.openInterest}</td>
                    <td className="px-2 py-1.5 text-slate-200">{call.delta}</td>
                    <td className="px-2 py-1.5 text-slate-400">{call.gamma}</td>
                    {showGreeks && <td className="px-2 py-1.5 text-[#666]">{call.charm || 0}</td>}
                    {showGreeks && <td className="px-2 py-1.5 text-[#666] border-r border-[#2A2A2E]">{call.vanna || 0}</td>}

                    <td
                      className={`px-3 py-1.5 text-center font-bold border-r border-[#2A2A2E] ${
                        isATM
                          ? 'text-[#0A0A0B] bg-[#D4AF37]'
                          : 'text-white bg-[#121214]'
                      }`}
                    >
                      ${call.strike.toFixed(2)}
                    </td>

                    <td className={`px-2 py-1.5 text-rose-400 ${put.isITM ? 'bg-rose-950/20' : ''}`}>
                      ${put.bid.toFixed(2)}
                    </td>
                    <td className={`px-2 py-1.5 text-rose-300 ${put.isITM ? 'bg-rose-950/20' : ''}`}>
                      ${put.ask.toFixed(2)}
                    </td>
                    <td className="px-2 py-1.5 text-[#888]">${put.theoreticalPrice.toFixed(2)}</td>
                    <td className="px-2 py-1.5 text-cyan-400">{(put.impliedVolatility * 100).toFixed(1)}%</td>
                    <td className="px-2 py-1.5 text-slate-300">{put.volume}</td>
                    <td className="px-2 py-1.5 text-slate-300">{put.openInterest}</td>
                    <td className="px-2 py-1.5 text-slate-200">{put.delta}</td>
                    <td className="px-2 py-1.5 text-slate-400">{put.gamma}</td>
                    {showGreeks && <td className="px-2 py-1.5 text-[#666]">{put.charm || 0}</td>}
                    {showGreeks && <td className="px-2 py-1.5 text-[#666]">{put.vanna || 0}</td>}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
