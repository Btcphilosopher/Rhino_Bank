import React, { useState } from 'react';
import { MarketQuote } from '../../services/syntheticMarketData';
import { Play, Sliders, Shield, TrendingUp, CheckCircle, ArrowRight } from 'lucide-react';

interface StrategyLabViewProps {
  quote: MarketQuote;
}

export const StrategyLabView: React.FC<StrategyLabViewProps> = ({ quote }) => {
  const [isScanning, setIsScanning] = useState(false);
  const [scannedResults, setScannedResults] = useState([
    {
      id: 'lab-1',
      name: 'Delta Neutral 15-Delta Iron Condor',
      symbol: quote.symbol,
      maxProfit: 450,
      maxLoss: 1050,
      pop: 82.4,
      sharpe: 2.14,
      returnOnMargin: 42.8,
      ev: 185.20,
    },
    {
      id: 'lab-2',
      name: '30-45 DTE Bull Put Spread',
      symbol: quote.symbol,
      maxProfit: 320,
      maxLoss: 680,
      pop: 78.1,
      sharpe: 1.88,
      returnOnMargin: 47.0,
      ev: 142.50,
    },
    {
      id: 'lab-3',
      name: 'Calendar Spread (30D/60D ATM)',
      symbol: quote.symbol,
      maxProfit: 620,
      maxLoss: 420,
      pop: 64.5,
      sharpe: 1.62,
      returnOnMargin: 147.6,
      ev: 210.00,
    },
  ]);

  const runScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
    }, 1200);
  };

  return (
    <div className="flex-1 flex flex-col gap-3 p-3 overflow-y-auto font-mono text-xs bg-[#0A0A0B]">
      {/* Scan Config Bar */}
      <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 font-bold text-white">
          <Play className="w-4 h-4 text-[#D4AF37]" />
          QUANTITATIVE STRATEGY LAB & STRIKE MATRIX SCANNER
        </div>

        <button
          onClick={runScan}
          disabled={isScanning}
          className="px-4 py-2 rounded-sm bg-[#D4AF37] hover:bg-[#C49F27] text-[#0A0A0B] font-bold transition flex items-center gap-2 cursor-pointer uppercase tracking-widest text-xs"
        >
          {isScanning ? (
            <span>SCANNING 10,000+ COMBINATIONS...</span>
          ) : (
            <>
              <Play className="w-4 h-4" /> RUN AUTOMATED SCAN
            </>
          )}
        </button>
      </div>

      {/* Scanned Strategy Rankings Table */}
      <div className="bg-[#121214] border border-[#2A2A2E] rounded-sm overflow-hidden flex-1">
        <div className="p-3 border-b border-[#2A2A2E] font-bold text-white tracking-wider uppercase text-xs">
          RANKED STRATEGIES FOR {quote.symbol} (SORTED BY RISK-ADJUSTED SHARPE)
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#1A1A1C] text-[#666] uppercase tracking-wider border-b border-[#2A2A2E]">
              <tr>
                <th className="p-3">Rank & Strategy Name</th>
                <th className="p-3">Max Profit</th>
                <th className="p-3">Max Loss</th>
                <th className="p-3">Prob of Profit (PoP)</th>
                <th className="p-3">Sharpe Ratio</th>
                <th className="p-3">Return on Margin</th>
                <th className="p-3">Expected Value (EV)</th>
                <th className="p-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A2A2E]">
              {scannedResults.map((item, index) => (
                <tr key={item.id} className="hover:bg-[#1A1A1C] transition">
                  <td className="p-3 font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#1A1A1C] text-[#D4AF37] border border-[#D4AF37] flex items-center justify-center text-[10px]">
                      #{index + 1}
                    </span>
                    {item.name}
                  </td>
                  <td className="p-3 text-green-400 font-bold">${item.maxProfit}</td>
                  <td className="p-3 text-red-400 font-bold">${item.maxLoss}</td>
                  <td className="p-3 text-cyan-400 font-bold">{item.pop}%</td>
                  <td className="p-3 text-[#D4AF37] font-bold">{item.sharpe}</td>
                  <td className="p-3 text-green-400 font-bold">{item.returnOnMargin}%</td>
                  <td className="p-3 text-white font-bold">${item.ev}</td>
                  <td className="p-3 text-right">
                    <button className="px-3 py-1 rounded-sm bg-[#1A1A1C] hover:bg-[#222226] border border-[#2A2A2E] text-[#D4AF37] font-bold transition flex items-center gap-1 ml-auto">
                      Send to Backtest <ArrowRight className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
