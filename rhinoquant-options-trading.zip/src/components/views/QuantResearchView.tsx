import React, { useState } from 'react';
import { Code2, Play, CheckCircle2, Terminal } from 'lucide-react';

export const QuantResearchView: React.FC = () => {
  const [outputLogs, setOutputLogs] = useState<string[]>([
    'Loading SPY 30D options dataset...',
    'Fitting SVI volatility surface model [a=0.04, b=0.12, rho=-0.35, m=0.0, sigma=0.10]...',
    'Detecting Volatility Regime: NORMAL (30D IV = 14.5%, HV30 = 12.2%)...',
    'Executing 15-Delta Iron Condor backtest iteration across 252 historical chains...',
    'Calculation Complete. Sharpe Ratio = 2.14, Win Rate = 82.4%.',
  ]);

  const [code, setCode] = useState(`import numpy as np
import rhinoquant as rq

# Load SPY options dataset
spy_chain = rq.load_chain("SPY", dte=30)

# Calculate SVI volatility surface
svi_params = rq.fit_svi_surface(spy_chain)
print(f"SVI Fit Parameters: {svi_params}")

# Detect Volatility Regime
regime = rq.get_vol_regime("SPY")
print(f"Current Regime: {regime}")

# Construct Iron Condor
ic = rq.build_iron_condor("SPY", delta=15, wing_size=5)
results = rq.backtest(ic, start="2025-01-01")
print(f"Sharpe Ratio: {results.sharpe:.2f}")
`);

  const runNotebookCode = () => {
    setOutputLogs([
      'Executing Quantitative Research Cell...',
      'Compiling Vectorized Greeks Engine...',
      'Calculating Heston Stochastic Volatility PDE discretization...',
      'Plotting Implied Volatility Surface residuals...',
      'Output generated successfully in 12ms.',
    ]);
  };

  return (
    <div className="flex-1 flex flex-col gap-3 p-3 overflow-y-auto font-mono text-xs bg-[#0A0A0B]">
      <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex items-center justify-between">
        <div className="flex items-center gap-2 font-bold text-white uppercase tracking-wider text-xs">
          <Code2 className="w-4 h-4 text-[#D4AF37]" />
          QUANT RESEARCH WORKBENCH (PYTHON / NUMERICAL AGENT INTERACTION)
        </div>
        <button
          onClick={runNotebookCode}
          className="px-3 py-1.5 rounded-sm bg-[#D4AF37] hover:bg-[#C49F27] text-[#0A0A0B] font-bold transition flex items-center gap-1.5 cursor-pointer uppercase tracking-widest text-xs"
        >
          <Play className="w-3.5 h-3.5" /> RUN CELL
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 flex-1">
        {/* Interactive Code Editor Cell */}
        <div className="bg-[#121214] border border-[#2A2A2E] rounded-sm p-3 flex flex-col gap-2">
          <div className="text-[10px] text-[#666] font-bold uppercase tracking-wider">Cell [1] - Python / Quant Script</div>
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="w-full flex-1 min-h-[320px] bg-[#1A1A1C] border border-[#2A2A2E] p-3 text-white font-mono text-xs rounded-sm focus:outline-none focus:border-[#D4AF37]"
          />
        </div>

        {/* Execution Output Console */}
        <div className="bg-[#121214] border border-[#2A2A2E] rounded-sm p-3 flex flex-col gap-2">
          <div className="text-[10px] text-[#666] font-bold uppercase tracking-wider flex items-center gap-1.5">
            <Terminal className="w-3.5 h-3.5 text-green-400" /> Execution Console Output
          </div>
          <div className="bg-[#1A1A1C] border border-[#2A2A2E] p-3 rounded-sm flex-1 min-h-[320px] text-green-400 font-mono overflow-y-auto space-y-1">
            {outputLogs.map((log, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className="text-[#666]">&gt;</span>
                <span>{log}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
