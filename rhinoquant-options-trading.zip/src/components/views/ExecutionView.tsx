import React, { useState, useEffect } from 'react';
import { OrderTicket } from '../../types';
import { Send, CheckCircle2, Shield, Play } from 'lucide-react';

export const ExecutionView: React.FC = () => {
  const [orders, setOrders] = useState<OrderTicket[]>([]);

  useEffect(() => {
    fetch('/api/orders')
      .then((r) => r.json())
      .then((data) => setOrders(data))
      .catch(() => {});
  }, []);

  return (
    <div className="flex-1 flex flex-col gap-3 p-3 overflow-y-auto font-mono text-xs bg-[#0A0A0B]">
      <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex items-center justify-between">
        <div className="font-bold text-white flex items-center gap-2 uppercase tracking-wider text-xs">
          <Send className="w-4 h-4 text-[#D4AF37]" />
          BROKER ADAPTER EXECUTION ENGINE & PAPER TRADING AUDIT LOG
        </div>
        <div className="text-[10px] text-green-400 font-bold border border-green-500/40 px-2 py-0.5 rounded-sm bg-green-950/20">
          BROKER ADAPTER: MOCK_PAPER_LIVE_01
        </div>
      </div>

      <div className="bg-[#121214] border border-[#2A2A2E] rounded-sm overflow-hidden flex-1">
        <div className="p-3 border-b border-[#2A2A2E] font-bold text-white uppercase tracking-wider text-xs">
          EXECUTED & PENDING SIMULATED ORDERS
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#1A1A1C] text-[#666] uppercase tracking-wider border-b border-[#2A2A2E]">
              <tr>
                <th className="p-3">Order ID</th>
                <th className="p-3">Symbol</th>
                <th className="p-3">Action</th>
                <th className="p-3">Qty</th>
                <th className="p-3">Fill Price</th>
                <th className="p-3">Status</th>
                <th className="p-3">Commission</th>
                <th className="p-3">Submitted At</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A2A2E]">
              {orders.map((ord) => (
                <tr key={ord.id} className="hover:bg-[#1A1A1C] transition">
                  <td className="p-3 font-bold text-[#D4AF37]">{ord.id}</td>
                  <td className="p-3 font-bold text-white">{ord.symbol}</td>
                  <td className="p-3 font-bold text-green-400">{ord.action}</td>
                  <td className="p-3 text-[#D1D1D1]">{ord.quantity}</td>
                  <td className="p-3 text-white">${ord.fillPrice?.toFixed(2) || 'MKT'}</td>
                  <td className="p-3 font-bold text-green-400">{ord.status}</td>
                  <td className="p-3 text-[#888]">${ord.commission.toFixed(2)}</td>
                  <td className="p-3 text-[#888]">{ord.submittedAt}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
