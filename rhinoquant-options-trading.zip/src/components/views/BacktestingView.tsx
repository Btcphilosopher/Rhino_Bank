import React, { useState } from 'react';
import { BacktestConfig, BacktestResult } from '../../types';
import { runBacktest } from '../../quant/backtestEngine';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { History, Play, CheckCircle, TrendingUp } from 'lucide-react';

export const BacktestingView: React.FC = () => {
  const [symbol, setSymbol] = useState('NVDA');
  const [strategyType, setStrategyType] = useState('Iron Condor');
  const [isRunning, setIsRunning] = useState(false);

  const [result, setResult] = useState<BacktestResult>(() =>
    runBacktest({
      symbol: 'NVDA',
      strategyType: 'Iron Condor',
      startDate: '2025-01-01',
      endDate: '2025-12-31',
      initialCapital: 100000,
      targetDTE: 30,
      deltaTarget: 0.15,
      profitTargetPercent: 50,
      stopLossPercent: 100,
      commissionPerContract: 0.65,
      slippageTicks: 1,
    })
  );

  const handleRunBacktest = () => {
    setIsRunning(true);
    setTimeout(() => {
      const res = runBacktest({
        symbol,
        strategyType,
        startDate: '2025-01-01',
        endDate: '2025-12-31',
        initialCapital: 100000,
        targetDTE: 30,
        deltaTarget: 0.15,
        profitTargetPercent: 50,
        stopLossPercent: 100,
        commissionPerContract: 0.65,
        slippageTicks: 1,
      });
      setResult(res);
      setIsRunning(false);
    }, 800);
  };

  return (
    <div className="flex-1 flex flex-col gap-3 p-3 overflow-y-auto font-mono text-xs bg-[#0A0A0B]">
      {/* Config Bar */}
      <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <History className="w-4 h-4 text-[#D4AF37]" />
          <span className="font-bold text-white text-xs uppercase tracking-wider">HISTORICAL OPTIONS BACKTESTER</span>
          <select
            value={symbol}
            onChange={(e) => setSymbol(e.target.value)}
            className="bg-[#1A1A1C] border border-[#2A2A2E] px-2 py-1 rounded-sm text-white"
          >
            <option value="NVDA">NVDA</option>
            <option value="SPY">SPY</option>
            <option value="QQQ">QQQ</option>
            <option value="TSLA">TSLA</option>
          </select>
          <select
            value={strategyType}
            onChange={(e) => setStrategyType(e.target.value)}
            className="bg-[#1A1A1C] border border-[#2A2A2E] px-2 py-1 rounded-sm text-white"
          >
            <option value="Iron Condor">Iron Condor</option>
            <option value="Bull Call Spread">Bull Call Spread</option>
            <option value="Short Strangle">Short Strangle</option>
          </select>
        </div>

        <button
          onClick={handleRunBacktest}
          disabled={isRunning}
          className="px-4 py-2 rounded-sm bg-[#D4AF37] hover:bg-[#C49F27] text-[#0A0A0B] font-bold transition flex items-center gap-2 cursor-pointer uppercase tracking-widest text-xs"
        >
          {isRunning ? 'SIMULATING HISTORICAL CHAINS...' : 'EXECUTE BACKTEST'}
        </button>
      </div>

      {/* Results Header Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">TOTAL RETURN</div>
          <div className="text-xl font-bold text-green-400 mt-1">+{result.totalReturn}%</div>
          <div className="text-[10px] text-[#888] mt-0.5">CAGR: +{result.cagr}%</div>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">SHARPE / SORTINO RATIO</div>
          <div className="text-xl font-bold text-[#D4AF37] mt-1">
            {result.sharpeRatio} / {result.sortinoRatio}
          </div>
          <div className="text-[10px] text-[#888] mt-0.5">Risk-Adjusted Outperformance</div>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">WIN RATE / PROFIT FACTOR</div>
          <div className="text-xl font-bold text-cyan-400 mt-1">
            {result.winRate}% / {result.profitFactor}x
          </div>
          <div className="text-[10px] text-[#888] mt-0.5">
            {result.winningTrades} W / {result.losingTrades} L
          </div>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">MAX DRAWDOWN</div>
          <div className="text-xl font-bold text-red-400 mt-1">-{result.maxDrawdown}%</div>
          <div className="text-[10px] text-[#888] mt-0.5">Total Trades: {result.totalTrades}</div>
        </div>
      </div>

      {/* Equity Curve Chart */}
      <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex flex-col gap-2">
        <div className="font-bold text-white text-xs">BACKTEST CUMULATIVE EQUITY CURVE ($)</div>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={result.equityCurve}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2A2A2E" />
              <XAxis dataKey="date" stroke="#666" tick={{ fontSize: 10 }} />
              <YAxis stroke="#666" tick={{ fontSize: 10 }} domain={['auto', 'auto']} />
              <Tooltip
                contentStyle={{ backgroundColor: '#121214', borderColor: '#2A2A2E', fontSize: '11px', color: '#fff' }}
              />
              <Line type="monotone" dataKey="equity" name="Portfolio Equity ($)" stroke="#10b981" strokeWidth={2} dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
