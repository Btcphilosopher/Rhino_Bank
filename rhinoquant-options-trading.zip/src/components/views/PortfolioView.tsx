import React from 'react';
import { AccountSummary, PortfolioPosition } from '../../types';
import { PieChart, TrendingUp, ShieldAlert, Layers } from 'lucide-react';

interface PortfolioViewProps {
  account: AccountSummary;
  positions: PortfolioPosition[];
}

export const PortfolioView: React.FC<PortfolioViewProps> = ({ account, positions }) => {
  return (
    <div className="flex-1 flex flex-col gap-3 p-3 overflow-y-auto font-mono text-xs bg-[#0A0A0B]">
      {/* Account Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">PORTFOLIO NET VALUE</div>
          <div className="text-xl font-bold text-white mt-1">
            ${account.portfolioValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-green-400 mt-0.5">Cash: ${account.cashBalance.toLocaleString()}</div>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">UNREALIZED / REALIZED P&L</div>
          <div className="text-xl font-bold text-green-400 mt-1">
            +${account.unrealizedPnL.toLocaleString()} / +${account.realizedPnL.toLocaleString()}
          </div>
          <div className="text-[10px] text-[#888] mt-0.5">Today P&L: +${account.todayPnL}</div>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">BUYING POWER / MARGIN</div>
          <div className="text-xl font-bold text-cyan-400 mt-1">${account.buyingPower.toLocaleString()}</div>
          <div className="text-[10px] text-[#888] mt-0.5">Used: ${account.marginUsed.toLocaleString()}</div>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">PORTFOLIO NET GREEKS</div>
          <div className="text-xs font-bold text-white mt-1 flex items-center justify-between">
            <span>Δ: {account.netDelta}</span>
            <span>Γ: {account.netGamma}</span>
            <span className="text-[#D4AF37]">Θ: +${account.netTheta}/d</span>
          </div>
          <div className="text-[10px] text-cyan-400 mt-1">Net Vega: +${account.netVega}</div>
        </div>
      </div>

      {/* Position Holdings Table */}
      <div className="bg-[#121214] border border-[#2A2A2E] rounded-sm overflow-hidden flex-1">
        <div className="p-3 border-b border-[#2A2A2E] font-bold text-white flex items-center justify-between uppercase tracking-wider text-xs">
          <span>ACTIVE DERIVATIVE & EQUITY POSITIONS</span>
          <span className="text-xs font-normal text-[#888]">{positions.length} Open Positions</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#1A1A1C] text-[#666] uppercase tracking-wider border-b border-[#2A2A2E]">
              <tr>
                <th className="p-3">Symbol / Contract</th>
                <th className="p-3">Asset Type</th>
                <th className="p-3">Qty</th>
                <th className="p-3">Avg Price</th>
                <th className="p-3">Current</th>
                <th className="p-3">Market Value</th>
                <th className="p-3">Unrealized P&L</th>
                <th className="p-3">Delta</th>
                <th className="p-3">Vega</th>
                <th className="p-3">Theta</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A2A2E]">
              {positions.map((pos) => (
                <tr key={pos.id} className="hover:bg-[#1A1A1C] transition">
                  <td className="p-3 font-bold text-white">{pos.symbol}</td>
                  <td className="p-3 text-[#888]">{pos.assetType}</td>
                  <td className="p-3 font-bold text-[#D1D1D1]">{pos.quantity}</td>
                  <td className="p-3 text-[#888]">${pos.avgEntryPrice.toFixed(2)}</td>
                  <td className="p-3 text-[#D1D1D1]">${pos.currentPrice.toFixed(2)}</td>
                  <td className="p-3 font-bold text-white">${pos.marketValue.toLocaleString()}</td>
                  <td
                    className={`p-3 font-bold ${
                      pos.unrealizedPnL >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}
                  >
                    {pos.unrealizedPnL >= 0 ? '+' : ''}${pos.unrealizedPnL.toFixed(2)} ({pos.unrealizedPnLPercent}%)
                  </td>
                  <td className="p-3 text-[#D1D1D1]">{pos.delta}</td>
                  <td className="p-3 text-cyan-400">{pos.vega}</td>
                  <td className="p-3 text-[#D4AF37]">{pos.theta}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
