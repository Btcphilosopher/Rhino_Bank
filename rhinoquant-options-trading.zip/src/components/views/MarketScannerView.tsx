import React, { useState } from 'react';
import { getScannerData } from '../../services/syntheticMarketData';
import { Filter, ArrowUpRight, ArrowDownRight, Zap } from 'lucide-react';

interface MarketScannerViewProps {
  onSelectSymbol: (symbol: string) => void;
}

export const MarketScannerView: React.FC<MarketScannerViewProps> = ({ onSelectSymbol }) => {
  const items = getScannerData();

  return (
    <div className="flex-1 flex flex-col gap-3 p-3 overflow-y-auto font-mono text-xs bg-[#0A0A0B]">
      <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex items-center justify-between">
        <div className="font-bold text-white flex items-center gap-2 uppercase tracking-wider text-xs">
          <Filter className="w-4 h-4 text-[#D4AF37]" />
          REAL-TIME OPTIONS MARKET SCANNER (HIGH IV, UNUSUAL ACTIVITY, SKEW ANOMALIES)
        </div>
        <div className="text-[10px] text-[#888]">Filtering Expression: IV Rank &gt; 30 AND Vol/OI &gt; 1.0</div>
      </div>

      <div className="bg-[#121214] border border-[#2A2A2E] rounded-sm overflow-hidden flex-1">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#1A1A1C] text-[#666] uppercase tracking-wider border-b border-[#2A2A2E]">
              <tr>
                <th className="p-3">Symbol / Name</th>
                <th className="p-3">Spot Price</th>
                <th className="p-3">30D IV</th>
                <th className="p-3">IV Rank</th>
                <th className="p-3">Volume / OI Ratio</th>
                <th className="p-3">Unusual Score</th>
                <th className="p-3">Signal</th>
                <th className="p-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A2A2E]">
              {items.map((item) => (
                <tr key={item.symbol} className="hover:bg-[#1A1A1C] transition">
                  <td className="p-3 font-bold text-white">
                    {item.symbol} <span className="text-[#888] font-normal">({item.name})</span>
                  </td>
                  <td className="p-3 text-[#D1D1D1]">${item.price.toFixed(2)}</td>
                  <td className="p-3 text-cyan-400 font-bold">{(item.iv * 100).toFixed(1)}%</td>
                  <td className="p-3 text-[#D4AF37] font-bold">{item.ivRank}%</td>
                  <td className="p-3 text-white font-bold">{item.volumeOIRatio}x</td>
                  <td className="p-3 font-bold text-green-400">{item.unusualActivityScore}/100</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded-sm text-[10px] bg-[#1A1A1C] text-[#D4AF37] font-bold border border-[#D4AF37]">
                      {item.signal}
                    </span>
                  </td>
                  <td className="p-3 text-right">
                    <button
                      onClick={() => onSelectSymbol(item.symbol)}
                      className="px-2.5 py-1 rounded-sm bg-[#1A1A1C] hover:bg-[#222226] border border-[#2A2A2E] text-[#D4AF37] transition font-bold"
                    >
                      Inspect Chain
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
