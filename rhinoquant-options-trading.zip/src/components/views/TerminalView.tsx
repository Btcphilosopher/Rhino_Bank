import React, { useState } from 'react';
import {
  OptionChainExpiration,
  OptionContract,
  OptionLeg,
} from '../../types';
import { MarketQuote } from '../../services/syntheticMarketData';
import {
  TrendingUp,
  TrendingDown,
  ChevronDown,
  Plus,
  Trash2,
  Send,
  Zap,
  Info,
  Sliders,
  DollarSign,
  Activity,
} from 'lucide-react';
import { evaluateStrategy } from '../../quant/strategyEngine';

interface TerminalViewProps {
  quote: MarketQuote;
  chain: OptionChainExpiration[];
  onAddLegToStrategy: (contract: OptionContract, action: 'BUY' | 'SELL') => void;
  onOpenOrderTicket: (legs: OptionLeg[]) => void;
}

export const TerminalView: React.FC<TerminalViewProps> = ({
  quote,
  chain,
  onAddLegToStrategy,
  onOpenOrderTicket,
}) => {
  const [selectedExpIndex, setSelectedExpIndex] = useState(2); // default 30D
  const [filterMoneyness, setFilterMoneyness] = useState<'ALL' | 'ITM' | 'ATM' | 'OTM'>('ALL');
  const [basketLegs, setBasketLegs] = useState<OptionLeg[]>([]);

  const currentExpiration = chain[selectedExpIndex] || chain[0];

  const handleContractClick = (contract: OptionContract, action: 'BUY' | 'SELL') => {
    const existingIndex = basketLegs.findIndex((l) => l.contract.id === contract.id && l.action === action);
    if (existingIndex >= 0) {
      const updated = [...basketLegs];
      updated[existingIndex].quantity += 1;
      setBasketLegs(updated);
    } else {
      const newLeg: OptionLeg = {
        id: `leg-${Date.now()}-${Math.random()}`,
        contract,
        action,
        quantity: 1,
        entryPrice: action === 'BUY' ? contract.ask : contract.bid,
      };
      setBasketLegs([...basketLegs, newLeg]);
    }
  };

  const removeLeg = (id: string) => {
    setBasketLegs(basketLegs.filter((l) => l.id !== id));
  };

  const evaluation = evaluateStrategy(
    quote.symbol,
    quote.price,
    basketLegs
  );

  const filterContracts = (contracts: OptionContract[]) => {
    if (filterMoneyness === 'ITM') return contracts.filter((c) => c.isITM);
    if (filterMoneyness === 'ATM') return contracts.filter((c) => c.isATM);
    if (filterMoneyness === 'OTM') return contracts.filter((c) => c.isOTM);
    return contracts;
  };

  const filteredCalls = filterContracts(currentExpiration?.calls || []);
  const filteredPuts = filterContracts(currentExpiration?.puts || []);

  return (
    <div className="flex-1 flex flex-col xl:flex-row gap-3 p-3 overflow-y-auto font-mono text-xs bg-[#0A0A0B]">
      {/* Main Center Area: Spot Summary + Options Chain */}
      <div className="flex-1 flex flex-col gap-3 min-w-0">
        {/* Spot Quote Bar */}
        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div>
              <div className="text-lg font-bold text-white flex items-center gap-2">
                {quote.symbol}
                <span className="text-xs text-[#888] font-normal">{quote.name}</span>
              </div>
              <div className="flex items-center gap-2 text-sm mt-0.5">
                <span className="font-bold text-white">${quote.price.toFixed(2)}</span>
                <span
                  className={`font-semibold flex items-center gap-0.5 ${
                    quote.change >= 0 ? 'text-green-400' : 'text-red-400'
                  }`}
                >
                  {quote.change >= 0 ? '+' : ''}
                  {quote.change.toFixed(2)} ({quote.changePercent}%)
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6 text-xs border-l border-[#2A2A2E] pl-4">
            <div>
              <div className="text-[#666] text-[10px] uppercase tracking-wider">30D IV</div>
              <div className="font-bold text-cyan-400">{(quote.iv * 100).toFixed(1)}%</div>
            </div>
            <div>
              <div className="text-[#666] text-[10px] uppercase tracking-wider">IV RANK</div>
              <div className="font-bold text-[#D4AF37]">{quote.ivRank}%</div>
            </div>
            <div>
              <div className="text-[#666] text-[10px] uppercase tracking-wider">IV PERCENTILE</div>
              <div className="font-bold text-green-400">{quote.ivPercentile}%</div>
            </div>
            <div>
              <div className="text-[#666] text-[10px] uppercase tracking-wider">EXPECTED MOVE (30D)</div>
              <div className="font-bold text-[#D1D1D1]">±${currentExpiration?.expectedMove || 12.4}</div>
            </div>
          </div>
        </div>

        {/* Expiration Selector Tabs & Moneyness Filter */}
        <div className="bg-[#121214] border border-[#2A2A2E] p-2.5 rounded-sm flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {chain.map((expItem, idx) => {
              const isSelected = idx === selectedExpIndex;
              return (
                <button
                  key={expItem.expiration}
                  onClick={() => setSelectedExpIndex(idx)}
                  className={`px-3 py-1 rounded-sm text-xs transition flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-[#1A1A1C] text-[#D4AF37] border border-[#D4AF37] font-bold shadow-sm'
                      : 'bg-[#1A1A1C] text-[#888] hover:text-white border border-[#2A2A2E]'
                  }`}
                >
                  <span>{expItem.expiration}</span>
                  <span className="text-[10px] opacity-75">({expItem.dte}d)</span>
                </button>
              );
            })}
          </div>

          {/* Moneyness filter */}
          <div className="flex items-center gap-1 bg-[#1A1A1C] p-1 rounded-sm border border-[#2A2A2E]">
            {(['ALL', 'ITM', 'ATM', 'OTM'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setFilterMoneyness(m)}
                className={`px-2 py-0.5 rounded-sm text-[10px] font-bold transition ${
                  filterMoneyness === m
                    ? 'bg-[#D4AF37] text-[#0A0A0B]'
                    : 'text-[#888] hover:text-white'
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        {/* Live Split Options Chain Table */}
        <div className="bg-[#121214] border border-[#2A2A2E] rounded-sm overflow-hidden flex-1 min-h-[420px] flex flex-col">
          <div className="overflow-x-auto overflow-y-auto flex-1">
            <table className="w-full text-left text-[11px] border-collapse">
              <thead className="bg-[#1A1A1C] text-[#666] uppercase tracking-wider sticky top-0 z-20 border-b border-[#2A2A2E] font-mono">
                <tr>
                  {/* CALLS HEADER */}
                  <th colSpan={7} className="px-2 py-1.5 text-center text-cyan-400 bg-cyan-950/20 border-r border-[#2A2A2E]">
                    CALLS
                  </th>
                  {/* STRIKE HEADER */}
                  <th className="px-3 py-1.5 text-center text-[#D4AF37] bg-[#1F1F24] border-r border-[#2A2A2E]">
                    STRIKE
                  </th>
                  {/* PUTS HEADER */}
                  <th colSpan={7} className="px-2 py-1.5 text-center text-rose-400 bg-rose-950/20">
                    PUTS
                  </th>
                </tr>
                <tr className="border-b border-[#2A2A2E] text-[10px] text-[#666]">
                  <th className="px-2 py-1">Bid</th>
                  <th className="px-2 py-1">Ask</th>
                  <th className="px-2 py-1">Vol</th>
                  <th className="px-2 py-1">OI</th>
                  <th className="px-2 py-1">IV</th>
                  <th className="px-2 py-1">Δ</th>
                  <th className="px-2 py-1 border-r border-[#2A2A2E]">Θ</th>

                  <th className="px-3 py-1 text-center border-r border-[#2A2A2E]">ATM</th>

                  <th className="px-2 py-1">Bid</th>
                  <th className="px-2 py-1">Ask</th>
                  <th className="px-2 py-1">Vol</th>
                  <th className="px-2 py-1">OI</th>
                  <th className="px-2 py-1">IV</th>
                  <th className="px-2 py-1">Δ</th>
                  <th className="px-2 py-1">Θ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#2A2A2E]">
                {filteredCalls.map((call, idx) => {
                  const put = filteredPuts[idx] || filteredCalls[idx];
                  const isATM = call.isATM;

                  return (
                    <tr
                      key={call.strike}
                      className={`hover:bg-[#1A1A1C] transition ${
                        isATM ? 'bg-[#1F1F24] font-bold border-y border-[#D4AF37]/40' : ''
                      }`}
                    >
                      {/* Call Bid/Ask */}
                      <td
                        onClick={() => handleContractClick(call, 'SELL')}
                        className={`px-2 py-1.5 cursor-pointer text-green-400 hover:bg-green-500/20 ${
                          call.isITM ? 'bg-cyan-950/20' : ''
                        }`}
                        title="Click to Sell Call"
                      >
                        ${call.bid.toFixed(2)}
                      </td>
                      <td
                        onClick={() => handleContractClick(call, 'BUY')}
                        className={`px-2 py-1.5 cursor-pointer text-green-300 hover:bg-green-500/20 ${
                          call.isITM ? 'bg-cyan-950/20' : ''
                        }`}
                        title="Click to Buy Call"
                      >
                        ${call.ask.toFixed(2)}
                      </td>
                      <td className="px-2 py-1.5 text-[#888]">{call.volume}</td>
                      <td className="px-2 py-1.5 text-[#888]">{call.openInterest}</td>
                      <td className="px-2 py-1.5 text-cyan-400">{(call.impliedVolatility * 100).toFixed(1)}%</td>
                      <td className="px-2 py-1.5 text-slate-300">{call.delta}</td>
                      <td className="px-2 py-1.5 text-rose-400 border-r border-[#2A2A2E]">{call.theta}</td>

                      {/* STRIKE CENTER COLUMN */}
                      <td
                        className={`px-3 py-1.5 text-center font-bold border-r border-[#2A2A2E] ${
                          isATM
                            ? 'text-[#0A0A0B] bg-[#D4AF37]'
                            : 'text-[#D1D1D1] bg-[#121214]'
                        }`}
                      >
                        ${call.strike.toFixed(2)}
                      </td>

                      {/* Put Bid/Ask */}
                      <td
                        onClick={() => handleContractClick(put, 'SELL')}
                        className={`px-2 py-1.5 cursor-pointer text-rose-400 hover:bg-rose-500/20 ${
                          put.isITM ? 'bg-rose-950/20' : ''
                        }`}
                        title="Click to Sell Put"
                      >
                        ${put.bid.toFixed(2)}
                      </td>
                      <td
                        onClick={() => handleContractClick(put, 'BUY')}
                        className={`px-2 py-1.5 cursor-pointer text-rose-300 hover:bg-rose-500/20 ${
                          put.isITM ? 'bg-rose-950/20' : ''
                        }`}
                        title="Click to Buy Put"
                      >
                        ${put.ask.toFixed(2)}
                      </td>
                      <td className="px-2 py-1.5 text-[#888]">{put.volume}</td>
                      <td className="px-2 py-1.5 text-[#888]">{put.openInterest}</td>
                      <td className="px-2 py-1.5 text-cyan-400">{(put.impliedVolatility * 100).toFixed(1)}%</td>
                      <td className="px-2 py-1.5 text-slate-300">{put.delta}</td>
                      <td className="px-2 py-1.5 text-rose-400">{put.theta}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Right Sidebar: Strategy Order Ticket & Real-Time Basket Evaluator */}
      <div className="w-full xl:w-80 bg-[#121214] border border-[#2A2A2E] rounded-sm p-3 flex flex-col justify-between gap-3">
        <div>
          <div className="flex items-center justify-between pb-2 border-b border-[#2A2A2E] mb-3">
            <div className="font-bold text-white flex items-center gap-1.5 text-xs">
              <Zap className="w-4 h-4 text-[#D4AF37]" />
              STRATEGY BASKET ORDER TICKET
            </div>
            {basketLegs.length > 0 && (
              <button
                onClick={() => setBasketLegs([])}
                className="text-[10px] text-red-400 hover:underline"
              >
                Clear All
              </button>
            )}
          </div>

          {basketLegs.length === 0 ? (
            <div className="p-6 border border-dashed border-[#2A2A2E] rounded-sm text-center text-[#666] text-xs">
              Click any Call or Put Bid/Ask price in the chain to add contracts to your strategy basket.
            </div>
          ) : (
            <div className="flex flex-col gap-2 max-h-56 overflow-y-auto mb-3 pr-1">
              {basketLegs.map((leg) => (
                <div
                  key={leg.id}
                  className="bg-[#1A1A1C] border border-[#2A2A2E] p-2 rounded-sm flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="font-bold flex items-center gap-1.5">
                      <span
                        className={`px-1 py-0.2 rounded-sm text-[10px] ${
                          leg.action === 'BUY'
                            ? 'bg-green-500/20 text-green-400'
                            : 'bg-red-500/20 text-red-400'
                        }`}
                      >
                        {leg.action}
                      </span>
                      <span className="text-white">
                        {leg.contract.strike} {leg.contract.type.toUpperCase()}
                      </span>
                    </div>
                    <div className="text-[10px] text-[#888] mt-0.5">
                      Exp: {leg.contract.expiration} ({leg.contract.dte}d) @ ${leg.entryPrice.toFixed(2)}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="font-bold text-[#D4AF37]">x{leg.quantity}</span>
                    <button
                      onClick={() => removeLeg(leg.id)}
                      className="p-1 text-[#666] hover:text-red-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Real-time Basket Calculated Metrics */}
          {basketLegs.length > 0 && (
            <div className="bg-[#1A1A1C] border border-[#2A2A2E] p-3 rounded-sm flex flex-col gap-2 font-mono text-xs">
              <div className="text-[10px] text-[#D4AF37] uppercase font-bold tracking-wider mb-1">
                Strategy Performance Metrics
              </div>

              <div className="flex justify-between border-b border-[#2A2A2E] pb-1">
                <span className="text-[#888]">NET PREMIUM:</span>
                <span
                  className={`font-bold ${
                    evaluation.strategy.netPremium >= 0 ? 'text-green-400' : 'text-red-400'
                  }`}
                >
                  {evaluation.strategy.netPremium >= 0 ? 'CREDIT ' : 'DEBIT '}$
                  {Math.abs(evaluation.strategy.netPremium).toFixed(2)}
                </span>
              </div>

              <div className="flex justify-between border-b border-[#2A2A2E] pb-1">
                <span className="text-[#888]">MAX PROFIT:</span>
                <span className="font-bold text-green-400">
                  {evaluation.strategy.maxProfit > 100000 ? 'UNLIMITED' : `$${evaluation.strategy.maxProfit}`}
                </span>
              </div>

              <div className="flex justify-between border-b border-[#2A2A2E] pb-1">
                <span className="text-[#888]">MAX LOSS:</span>
                <span className="font-bold text-red-400">
                  {evaluation.strategy.maxLoss < -100000 ? 'UNLIMITED' : `$${evaluation.strategy.maxLoss}`}
                </span>
              </div>

              <div className="flex justify-between border-b border-[#2A2A2E] pb-1">
                <span className="text-[#888]">PROB OF PROFIT (PoP):</span>
                <span className="font-bold text-cyan-400">{evaluation.strategy.probabilityOfProfit}%</span>
              </div>

              <div className="flex justify-between">
                <span className="text-[#888]">MARGIN REQUIRED:</span>
                <span className="font-bold text-white">${evaluation.strategy.marginRequirement}</span>
              </div>
            </div>
          )}
        </div>

        {/* Action Button */}
        <button
          disabled={basketLegs.length === 0}
          onClick={() => onOpenOrderTicket(basketLegs)}
          className={`w-full py-2.5 rounded-sm font-bold text-xs flex items-center justify-center gap-2 transition uppercase tracking-widest ${
            basketLegs.length > 0
              ? 'bg-[#D4AF37] hover:bg-[#C49F27] text-[#0A0A0B] cursor-pointer'
              : 'bg-[#1A1A1C] text-[#666] cursor-not-allowed border border-[#2A2A2E]'
          }`}
        >
          <Send className="w-4 h-4" />
          TRANSMIT MULTI-LEG ORDER
        </button>
      </div>
    </div>
  );
};
