import React from 'react';
import { FileText, Download, ShieldAlert, Settings, Key } from 'lucide-react';

export const ReportsSettingsView: React.FC = () => {
  const exportReport = (format: 'PDF' | 'CSV' | 'JSON') => {
    const dataStr = JSON.stringify({
      platform: 'RhinoQuant',
      version: '3.6.0',
      timestamp: new Date().toISOString(),
      account: { portfolioValue: 1248500, todayPnL: 14250.80 },
    });
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RhinoQuant_Institutional_Report.${format.toLowerCase()}`;
    a.click();
  };

  return (
    <div className="flex-1 flex flex-col gap-3 p-3 overflow-y-auto font-mono text-xs bg-[#0A0A0B]">
      <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex items-center justify-between">
        <div className="font-bold text-white flex items-center gap-2 uppercase tracking-wider text-xs">
          <FileText className="w-4 h-4 text-[#D4AF37]" />
          INSTITUTIONAL REPORT GENERATOR & PLATFORM CONFIGURATION
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="bg-[#121214] border border-[#2A2A2E] p-4 rounded-sm flex flex-col justify-between gap-3">
          <div>
            <div className="font-bold text-white text-sm mb-1 uppercase tracking-wider">Portfolio Risk & Exposure Report</div>
            <div className="text-[#888] text-xs">Full breakdown of holdings, stress scenarios, Delta/Vega heatmaps.</div>
          </div>
          <button
            onClick={() => exportReport('PDF')}
            className="w-full py-2 rounded-sm bg-[#D4AF37] hover:bg-[#C49F27] text-[#0A0A0B] font-bold transition flex items-center justify-center gap-2 cursor-pointer uppercase tracking-widest text-xs"
          >
            <Download className="w-4 h-4" /> EXPORT PDF REPORT
          </button>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-4 rounded-sm flex flex-col justify-between gap-3">
          <div>
            <div className="font-bold text-white text-sm mb-1 uppercase tracking-wider">Backtest & Strategy Report</div>
            <div className="text-[#888] text-xs">Historical trade logs, win rates, Sharpe/Sortino ratios, drawdown analysis.</div>
          </div>
          <button
            onClick={() => exportReport('CSV')}
            className="w-full py-2 rounded-sm bg-green-500 hover:bg-green-400 text-[#0A0A0B] font-bold transition flex items-center justify-center gap-2 cursor-pointer uppercase tracking-widest text-xs"
          >
            <Download className="w-4 h-4" /> EXPORT CSV DATA
          </button>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-4 rounded-sm flex flex-col justify-between gap-3">
          <div>
            <div className="font-bold text-white text-sm mb-1 uppercase tracking-wider">System State Export</div>
            <div className="text-[#888] text-xs">Raw JSON dump of active multi-leg strategies, risk matrices, and order books.</div>
          </div>
          <button
            onClick={() => exportReport('JSON')}
            className="w-full py-2 rounded-sm bg-cyan-500 hover:bg-cyan-400 text-[#0A0A0B] font-bold transition flex items-center justify-center gap-2 cursor-pointer uppercase tracking-widest text-xs"
          >
            <Download className="w-4 h-4" /> EXPORT RAW JSON
          </button>
        </div>
      </div>

      {/* Risk Disclosures */}
      <div className="bg-[#1A1A1C] border border-[#2A2A2E] p-4 rounded-sm text-[#888] text-xs leading-relaxed space-y-2">
        <div className="font-bold text-[#D4AF37] flex items-center gap-1.5 text-xs uppercase tracking-wider">
          <ShieldAlert className="w-4 h-4" /> REGULATORY & RISK DISCLOSURE NOTICE
        </div>
        <p>
          RhinoQuant is a quantitative derivatives intelligence and analytical software platform. Options trading involves substantial risk and is not suitable for all investors. Mathematical model outputs, Monte Carlo simulations, Black-Scholes pricing models, and historical backtests do not guarantee future performance or financial returns.
        </p>
      </div>
    </div>
  );
};
