import React, { useState } from 'react';
import { PortfolioPosition } from '../../types';
import { calculatePortfolioRisk } from '../../quant/riskEngine';
import { ShieldAlert, AlertTriangle, Activity, Zap } from 'lucide-react';

interface RiskEngineViewProps {
  positions: PortfolioPosition[];
}

export const RiskEngineView: React.FC<RiskEngineViewProps> = ({ positions }) => {
  const riskSummary = calculatePortfolioRisk(positions);
  const [selectedCell, setSelectedCell] = useState<{ spotChange: number; volChange: number; pnl: number } | null>(null);

  return (
    <div className="flex-1 flex flex-col gap-3 p-3 overflow-y-auto font-mono text-xs bg-[#0A0A0B]">
      {/* Risk Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">1-DAY VaR (95% CONFIDENCE)</div>
          <div className="text-xl font-bold text-red-400 mt-1">
            -${riskSummary.var95Dollar.toLocaleString()}
          </div>
          <div className="text-[10px] text-[#888] mt-0.5">Value at Risk Threshold</div>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">1-DAY VaR (99% CONFIDENCE)</div>
          <div className="text-xl font-bold text-red-500 mt-1">
            -${riskSummary.var99Dollar.toLocaleString()}
          </div>
          <div className="text-[10px] text-[#888] mt-0.5">Extreme Tail Risk</div>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">EXPECTED SHORTFALL (CVaR 95)</div>
          <div className="text-xl font-bold text-red-400 mt-1">
            -${riskSummary.expectedShortfall95.toLocaleString()}
          </div>
          <div className="text-[10px] text-[#888] mt-0.5">Expected Loss Beyond VaR</div>
        </div>

        <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] uppercase font-semibold tracking-wider">MAX CONCENTRATION RISK</div>
          <div className="text-xl font-bold text-[#D4AF37] mt-1">
            {riskSummary.concentrationRisk[0]?.symbol || 'SPY'} (
            {riskSummary.concentrationRisk[0]?.weightPercent || 24}%)
          </div>
          <div className="text-[10px] text-[#888] mt-0.5">Largest Underlying Position</div>
        </div>
      </div>

      {/* Portfolio Risk Heatmap Matrix (Underlying Spot Shocks x Volatility Shocks) */}
      <div className="bg-[#121214] border border-[#2A2A2E] p-3 rounded-sm flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="font-bold text-white flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-400" />
            STRESS-TEST P&L HEATMAP MATRIX (SPOT PRICE SHOCKS x VOLATILITY SHOCKS)
          </div>
          <div className="text-[10px] text-[#888]">Click any matrix cell to inspect position drivers</div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-center border-collapse text-xs">
            <thead>
              <tr className="bg-[#1A1A1C] text-[#666] border-b border-[#2A2A2E] uppercase tracking-wider text-[10px]">
                <th className="p-2 text-left border-r border-[#2A2A2E]">SPOT SHOCK \ VOL SHOCK</th>
                {[-20, -10, 0, 10, 20].map((v) => (
                  <th key={v} className="p-2 border-r border-[#2A2A2E]">
                    VOL {v >= 0 ? '+' : ''}{v}%
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A2A2E]">
              {[-30, -20, -10, 0, 10, 20, 30].map((pShift) => (
                <tr key={pShift}>
                  <td className="p-2 font-bold text-left bg-[#1A1A1C] text-[#D1D1D1] border-r border-[#2A2A2E]">
                    SPOT {pShift >= 0 ? '+' : ''}{pShift}%
                  </td>

                  {[-20, -10, 0, 10, 20].map((vShift) => {
                    const cell = riskSummary.riskMatrix.find(
                      (m) => m.spotChange === pShift && m.volChange === vShift
                    );
                    const pnl = cell?.pnl || 0;
                    const isPositive = pnl >= 0;

                    let bgClass = 'bg-[#121214] text-[#888]';
                    if (pnl > 10000) bgClass = 'bg-green-950/60 text-green-400 border border-green-500/40';
                    else if (pnl > 0) bgClass = 'bg-green-950/30 text-green-300';
                    else if (pnl < -10000) bgClass = 'bg-red-950/70 text-red-400 border border-red-500/40 font-bold';
                    else if (pnl < 0) bgClass = 'bg-red-950/30 text-red-300';

                    return (
                      <td
                        key={vShift}
                        onClick={() => setSelectedCell(cell || null)}
                        className={`p-2 cursor-pointer transition hover:opacity-80 border-r border-[#2A2A2E] ${bgClass}`}
                      >
                        {isPositive ? '+' : ''}${pnl.toLocaleString()}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {selectedCell && (
          <div className="bg-[#1A1A1C] border border-[#2A2A2E] p-3 rounded-sm text-xs flex justify-between items-center">
            <div>
              <span className="font-bold text-[#D4AF37]">INSPECTED SCENARIO: </span>
              Spot {selectedCell.spotChange >= 0 ? '+' : ''}{selectedCell.spotChange}% | Vol {selectedCell.volChange >= 0 ? '+' : ''}{selectedCell.volChange}%
            </div>
            <div className={`font-bold text-sm ${selectedCell.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              Simulated P&L: {selectedCell.pnl >= 0 ? '+' : ''}${selectedCell.pnl.toLocaleString()}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
