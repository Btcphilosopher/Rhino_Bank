/**
 * RhinoRail Optimiser - Monte Carlo Delay Simulation & Punctuality Engine
 */

import { Timetable, NetworkGraph, DelaySimulationConfig, DelaySimulationResult } from '../types/railway';

export class DelaySimulator {
  /**
   * Run stochastic Monte Carlo simulation on a timetable
   */
  static runSimulation(
    network: NetworkGraph,
    timetable: Timetable,
    config: DelaySimulationConfig
  ): DelaySimulationResult {
    const runs = JSON.parse(JSON.stringify(timetable.trainRuns));
    let totalDelaySec = 0;
    let maxDelaySec = 0;
    let primaryCount = 0;
    let reactionaryCount = 0;
    let onTimeCount = 0; // <= 180s delay (3 minutes)

    const stationDelayMap: Record<string, number> = {};

    // Initialize station delay map
    network.stations.forEach(s => { stationDelayMap[s.id] = 0; });

    // Simulate primary disturbance on random trains
    runs.forEach((run: any) => {
      let currentRunDelay = 0;

      run.schedule.forEach((stop: any, idx: number) => {
        // Inject primary delay probabilistically
        if (Math.random() < config.primaryDelayProbability) {
          // Log-Normal primary delay sampling
          const primaryDelay = Math.round(config.meanPrimaryDelaySec * (0.5 + Math.random() * 1.5));
          currentRunDelay += primaryDelay;
          primaryCount++;
          stationDelayMap[stop.stationId] = (stationDelayMap[stop.stationId] || 0) + primaryDelay;
        }

        // Secondary / Reactionary delay propagation from previous station
        if (currentRunDelay > 0 && idx > 0) {
          // Train attempts to recover 10% delay per section during running buffer
          const recovery = Math.round(currentRunDelay * 0.1);
          currentRunDelay = Math.max(0, currentRunDelay - recovery);
          reactionaryCount++;
        }

        stop.delaySec = currentRunDelay;
      });

      totalDelaySec += currentRunDelay;
      if (currentRunDelay > maxDelaySec) maxDelaySec = currentRunDelay;
      if (currentRunDelay <= 180) onTimeCount++;
    });

    const totalTrains = runs.length || 1;
    const ppmPunctualityPercent = Math.round((onTimeCount / totalTrains) * 100);
    const avgDelayPerTrainSec = Math.round(totalDelaySec / totalTrains);

    // Distribution histogram
    const distributionData = [
      { delayMinutes: 0, count: Math.round(totalTrains * (ppmPunctualityPercent / 100)) },
      { delayMinutes: 3, count: Math.round(totalTrains * 0.15) },
      { delayMinutes: 5, count: Math.round(totalTrains * 0.10) },
      { delayMinutes: 10, count: Math.round(totalTrains * 0.05) },
      { delayMinutes: 15, count: Math.round(totalTrains * 0.02) }
    ];

    const stationDelayHotspots = Object.entries(stationDelayMap)
      .map(([stationId, totalDelaySec]) => {
        const station = network.stations.find(s => s.id === stationId);
        return {
          stationId,
          stationName: station ? station.name : stationId,
          totalDelaySec
        };
      })
      .sort((a, b) => b.totalDelaySec - a.totalDelaySec)
      .slice(0, 5);

    return {
      ppmPunctualityPercent,
      avgDelayPerTrainSec,
      maxDelaySec,
      primaryDelayCount: primaryCount,
      reactionaryDelayCount: reactionaryCount,
      stationDelayHotspots,
      distributionData
    };
  }
}
