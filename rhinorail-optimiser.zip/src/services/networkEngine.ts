/**
 * RhinoRail Optimiser - Network Graph Engine & Operational Calculations
 */

import { Station, TrackSection, NetworkGraph, Timetable, TrainRun } from '../types/railway';

export class NetworkEngine {
  /**
   * Calculate cumulative distance between stations along a given track sequence
   */
  static getRouteDistanceKm(network: NetworkGraph, stationIds: string[]): number {
    let totalDist = 0;
    for (let i = 0; i < stationIds.length - 1; i++) {
      const src = stationIds[i];
      const tgt = stationIds[i + 1];
      const track = network.tracks.find(
        t => (t.sourceStationId === src && t.targetStationId === tgt) ||
             (t.sourceStationId === tgt && t.targetStationId === src)
      );
      if (track) {
        totalDist += track.distanceKm;
      }
    }
    return totalDist;
  }

  /**
   * Calculate physics-based estimated running time between 2 adjacent stations
   * Formula: T = D / V_effective + T_accel_penalty + T_decel_penalty
   */
  static estimateSegmentRunningTimeSec(
    track: TrackSection,
    trainMaxSpeedKmh: number,
    accelMs2: number = 0.6,
    decelMs2: number = 0.8
  ): number {
    const effectiveSpeedKmh = Math.min(track.maxSpeedKmh, trainMaxSpeedKmh);
    const effectiveSpeedMs = (effectiveSpeedKmh * 1000) / 3600;
    const distanceMeters = track.distanceKm * 1000;

    // Time to accelerate from 0 to effectiveSpeed
    const tAccel = effectiveSpeedMs / accelMs2;
    const dAccel = 0.5 * accelMs2 * Math.pow(tAccel, 2);

    // Time to decelerate from effectiveSpeed to 0
    const tDecel = effectiveSpeedMs / decelMs2;
    const dDecel = 0.5 * decelMs2 * Math.pow(tDecel, 2);

    if (distanceMeters > (dAccel + dDecel)) {
      const dCruise = distanceMeters - (dAccel + dDecel);
      const tCruise = dCruise / effectiveSpeedMs;
      return Math.round(tAccel + tCruise + tDecel);
    } else {
      // Short track segment, train cannot reach max speed
      const maxPeakMs = Math.sqrt((2 * accelMs2 * decelMs2 * distanceMeters) / (accelMs2 + decelMs2));
      const tA = maxPeakMs / accelMs2;
      const tD = maxPeakMs / decelMs2;
      return Math.round(tA + tD);
    }
  }

  /**
   * Detect headway and platform conflicts in a timetable
   */
  static detectTimetableConflicts(
    network: NetworkGraph,
    timetable: Timetable,
    minHeadwaySec: number = 120
  ): { runId1: string; runId2: string; stationId: string; type: 'headway' | 'platform'; conflictSec: number; message: string }[] {
    const conflicts: { runId1: string; runId2: string; stationId: string; type: 'headway' | 'platform'; conflictSec: number; message: string }[] = [];
    const runs = timetable.trainRuns;

    for (let i = 0; i < runs.length; i++) {
      for (let j = i + 1; j < runs.length; j++) {
        const run1 = runs[i];
        const run2 = runs[j];

        // Check common stations
        for (const stop1 of run1.schedule) {
          const stop2 = run2.schedule.find(s => s.stationId === stop1.stationId);
          if (!stop2) continue;

          // 1. Platform Occupancy Conflict
          if (stop1.platform === stop2.platform && !stop1.isPassThrough && !stop2.isPassThrough) {
            const overlap = (stop1.departureSec >= stop2.arrivalSec) && (stop2.departureSec >= stop1.arrivalSec);
            if (overlap) {
              const conflictGap = Math.abs(stop1.departureSec - stop2.arrivalSec);
              conflicts.push({
                runId1: run1.id,
                runId2: run2.id,
                stationId: stop1.stationId,
                type: 'platform',
                conflictSec: conflictGap,
                message: `Platform ${stop1.platform} conflict at ${stop1.stationId} between ${run1.trainCode} & ${run2.trainCode}`
              });
            }
          }

          // 2. Departure Headway Conflict
          const depDiff = Math.abs(stop1.departureSec - stop2.departureSec);
          if (depDiff < minHeadwaySec) {
            conflicts.push({
              runId1: run1.id,
              runId2: run2.id,
              stationId: stop1.stationId,
              type: 'headway',
              conflictSec: minHeadwaySec - depDiff,
              message: `Headway gap (${Math.round(depDiff)}s < ${minHeadwaySec}s) at ${stop1.stationId} between ${run1.trainCode} & ${run2.trainCode}`
            });
          }
        }
      }
    }

    return conflicts;
  }

  /**
   * Get station distances from origin along a corridor for Marey String Chart plotting
   */
  static getStationCorridorDistances(network: NetworkGraph): Record<string, number> {
    const distMap: Record<string, number> = {};
    let runningDist = 0;

    network.stations.forEach((station, idx) => {
      if (idx === 0) {
        distMap[station.id] = 0;
      } else {
        const prevStation = network.stations[idx - 1];
        const track = network.tracks.find(
          t => (t.sourceStationId === prevStation.id && t.targetStationId === station.id) ||
               (t.sourceStationId === station.id && t.targetStationId === prevStation.id)
        );
        runningDist += track ? track.distanceKm : 30;
        distMap[station.id] = runningDist;
      }
    });

    return distMap;
  }
}
