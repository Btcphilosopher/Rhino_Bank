/**
 * RhinoRail Optimiser - Main Application Entry Point
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { NavigationTabs, TabKey } from './components/NavigationTabs';
import { ExecutiveDashboard } from './components/ExecutiveDashboard';
import { MareyStringChart } from './components/MareyStringChart';
import { GisNetworkMap } from './components/GisNetworkMap';
import { OptimisationPanel } from './components/OptimisationPanel';
import { CapacityPanel } from './components/CapacityPanel';
import { DelaySimulationPanel } from './components/DelaySimulationPanel';
import { ScenarioComparison } from './components/ScenarioComparison';
import { ReportsPanel } from './components/ReportsPanel';
import { UnitTestingPanel } from './components/UnitTestingPanel';
import { MethodologyDocs } from './components/MethodologyDocs';

import { NetworkGraph, Timetable, Scenario, OptimisationResult } from './types/railway';
import { ALL_NETWORKS, ALL_TIMETABLES } from './data/sampleNetworks';
import { NetworkEngine } from './services/networkEngine';
import { CapacityEngine } from './services/capacityEngine';
import { ReportGenerator } from './services/reportGenerator';
import { Sparkles, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [activeNetwork, setActiveNetwork] = useState<NetworkGraph>(ALL_NETWORKS[0]);
  const [activeTimetable, setActiveTimetable] = useState<Timetable>(ALL_TIMETABLES[ALL_NETWORKS[0].id]);
  const [activeScenario, setActiveScenario] = useState<Scenario | null>(null);
  const [activeTab, setActiveTab] = useState<TabKey>('dashboard');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Show auto-dismiss toast notification
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Switch active network preset
  const handleSelectNetwork = (netId: string) => {
    const net = ALL_NETWORKS.find(n => n.id === netId);
    if (net) {
      setActiveNetwork(net);
      setActiveTimetable(ALL_TIMETABLES[net.id] || ALL_TIMETABLES[ALL_NETWORKS[0].id]);
      setActiveScenario(null);
      showToast(`Switched active network to ${net.name}`);
    }
  };

  // Handle applying MILP optimised timetable
  const handleApplyOptimisedTimetable = (result: OptimisationResult) => {
    setActiveTimetable(result.optimizedTimetable);
    showToast(`Applied MILP Optimised Timetable! Resolved ${result.conflictsResolved} conflicts (+${result.capacityGainPercent}% capacity).`);
    setActiveTab('timetable');
  };

  // Compute live conflicts and UIC 406 results
  const currentConflicts = NetworkEngine.detectTimetableConflicts(activeNetwork, activeTimetable, 120);
  const currentUICResults = CapacityEngine.evaluateUIC406Capacity(activeNetwork, activeTimetable);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Toast Notification Bar */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-amber-500 text-slate-950 px-4 py-3 rounded-xl font-bold text-xs shadow-2xl flex items-center gap-2 animate-bounce">
          <Sparkles className="w-4 h-4 text-slate-950" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Header */}
      <Header
        activeNetwork={activeNetwork}
        activeTimetable={activeTimetable}
        activeScenario={activeScenario}
        onSelectNetwork={handleSelectNetwork}
        onRunOptimizer={() => setActiveTab('optimiser')}
        onQuickExport={() => ReportGenerator.generateExecutivePDF(activeNetwork, activeTimetable)}
      />

      {/* Navigation Tab Bar */}
      <NavigationTabs
        activeTab={activeTab}
        onTabChange={setActiveTab}
        conflictCount={currentConflicts.length}
      />

      {/* Main View Area */}
      <main className="flex-1 pb-12">
        {activeTab === 'dashboard' && (
          <ExecutiveDashboard
            network={activeNetwork}
            timetable={activeTimetable}
            uicResults={currentUICResults}
            conflictCount={currentConflicts.length}
            onNavigateToOptimiser={() => setActiveTab('optimiser')}
            onNavigateToMarey={() => setActiveTab('timetable')}
          />
        )}

        {activeTab === 'timetable' && (
          <MareyStringChart
            network={activeNetwork}
            timetable={activeTimetable}
          />
        )}

        {activeTab === 'gisMap' && (
          <GisNetworkMap
            network={activeNetwork}
            timetable={activeTimetable}
          />
        )}

        {activeTab === 'optimiser' && (
          <OptimisationPanel
            network={activeNetwork}
            timetable={activeTimetable}
            onApplyOptimisedTimetable={handleApplyOptimisedTimetable}
          />
        )}

        {activeTab === 'capacity' && (
          <CapacityPanel
            network={activeNetwork}
            timetable={activeTimetable}
            uicResults={currentUICResults}
          />
        )}

        {activeTab === 'delays' && (
          <DelaySimulationPanel
            network={activeNetwork}
            timetable={activeTimetable}
          />
        )}

        {activeTab === 'scenarios' && (
          <ScenarioComparison
            network={activeNetwork}
            currentTimetable={activeTimetable}
          />
        )}

        {activeTab === 'reports' && (
          <ReportsPanel
            network={activeNetwork}
            timetable={activeTimetable}
          />
        )}

        {activeTab === 'testing' && (
          <UnitTestingPanel
            network={activeNetwork}
            timetable={activeTimetable}
          />
        )}

        {activeTab === 'docs' && (
          <MethodologyDocs />
        )}
      </main>
    </div>
  );
}
