/**
 * RhinoRail Optimiser - Core Railway Types & Data Models
 */

export type TrainCategory = 'HighSpeed' | 'Intercity' | 'Express' | 'Regional' | 'Freight' | 'Suburban';

export interface Station {
  id: string;
  code: string;
  name: string;
  lat: number;
  lng: number;
  platforms: number;
  defaultDwellSec: number;
  isJunction: boolean;
  category: 'Major Terminus' | 'Hub Interchange' | 'Regional Station' | 'Minor Stop';
  elevationMeters?: number;
}

export interface TrackSection {
  id: string;
  name: string;
  sourceStationId: string;
  targetStationId: string;
  distanceKm: number;
  maxSpeedKmh: number;
  tracks: 1 | 2 | 4; // Single, Double, Quad track
  signalingHeadwaySec: number;
  gradientPercent: number; // e.g. +0.8 or -1.2
  electrification: '25kV AC' | '15kV AC' | '750V DC' | 'Non-Electrified';
  capacityMaxPathsPerHour: number;
  currentUtilisationPercent: number;
}

export interface StopRequirement {
  stationId: string;
  dwellSec: number;
  isPassThrough: boolean;
}

export interface TrainServicePattern {
  id: string;
  code: string;
  name: string;
  category: TrainCategory;
  maxSpeedKmh: number;
  accelerationMs2: number; // e.g. 0.5 - 0.9 m/s²
  decelerationMs2: number; // e.g. 0.8 - 1.2 m/s²
  stops: StopRequirement[];
  color: string;
}

export interface TimetableStop {
  stationId: string;
  arrivalSec: number;   // Seconds from 00:00 (e.g., 21600 = 06:00:00)
  departureSec: number; // Seconds from 00:00
  platform: string;
  isPassThrough: boolean;
  delaySec?: number;    // Simulated delay in seconds
}

export interface TrainRun {
  id: string;
  trainCode: string;
  servicePatternId: string;
  category: TrainCategory;
  originStationId: string;
  destinationStationId: string;
  originTimeSec: number;
  schedule: TimetableStop[];
  color: string;
  conflicts?: string[]; // IDs of conflicting runs
}

export interface NetworkGraph {
  id: string;
  name: string;
  description: string;
  stations: Station[];
  tracks: TrackSection[];
  servicePatterns: TrainServicePattern[];
}

export interface Timetable {
  id: string;
  name: string;
  description: string;
  trainRuns: TrainRun[];
  createdDate: string;
}

export type OptimisationObjective = 'journeyTime' | 'punctuality' | 'capacity' | 'connections' | 'balanced';

export interface OptimisationConfig {
  objective: OptimisationObjective;
  minHeadwaySec: number;
  dwellBufferSec: number;
  maxShiftMinutes: number;
  ecoCoastingAllowance: boolean;
  syncInterchangePulse: boolean;
  selectedCorridorIds: string[];
  maxSolverIterations: number;
}

export interface SolverLogMessage {
  iteration: number;
  timestamp: string;
  conflictsFound: number;
  totalDelaySec: number;
  message: string;
  status: 'info' | 'resolving' | 'success' | 'warning';
}

export interface OptimisationResult {
  initialDelayRiskScore: number;
  optimizedDelayRiskScore: number;
  initialTotalJourneyTimeSec: number;
  optimizedTotalJourneyTimeSec: number;
  conflictsFound: number;
  conflictsResolved: number;
  capacityGainPercent: number;
  punctualityImprovementPercent: number;
  logs: SolverLogMessage[];
  optimizedTimetable: Timetable;
  timestamp: string;
}

export interface UIC406Result {
  corridorId: string;
  corridorName: string;
  compressedTimeSec: number;
  totalWindowSec: number;
  capacityConsumptionPercent: number;
  maxPossiblePathsPerHour: number;
  scheduledPathsPerHour: number;
  status: 'Optimal' | 'Heavy Load' | 'Overcapacity Risk';
  bottleneckStation?: string;
}

export interface DelaySimulationConfig {
  primaryDelayProbability: number; // e.g. 0.05
  meanPrimaryDelaySec: number;     // e.g. 180s
  secondaryPropagationWeight: number; // e.g. 0.8
  monteCarloIterations: number;    // e.g. 1000
}

export interface DelaySimulationResult {
  ppmPunctualityPercent: number; // On-time <= 3 min
  avgDelayPerTrainSec: number;
  maxDelaySec: number;
  primaryDelayCount: number;
  reactionaryDelayCount: number;
  stationDelayHotspots: { stationId: string; stationName: string; totalDelaySec: number }[];
  distributionData: { delayMinutes: number; count: number }[];
}

export interface ScenarioMetrics {
  avgJourneyTimeMin: number;
  lineUtilisationPercent: number;
  ppmPunctualityPercent: number;
  totalTrainPathsPerDay: number;
  conflictsCount: number;
  co2EmissionsTonnes: number;
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  network: NetworkGraph;
  timetable: Timetable;
  metrics: ScenarioMetrics;
  isBaseline?: boolean;
}

export interface UnitTestResult {
  id: string;
  category: 'Network' | 'Timetable' | 'Headway' | 'UIC406' | 'Solver';
  name: string;
  passed: boolean;
  message: string;
  executionTimeMs: number;
}
