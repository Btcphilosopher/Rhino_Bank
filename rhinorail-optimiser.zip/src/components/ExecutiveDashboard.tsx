/**
 * RhinoRail Optimiser - Executive Dashboard Component
 */

import React from 'react';
import {
  Train,
  Gauge,
  Clock,
  AlertTriangle,
  ArrowUpRight,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { NetworkGraph, Timetable, UIC406Result } from '../types/railway';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';

interface ExecutiveDashboardProps {
  network: NetworkGraph;
  timetable: Timetable;
  uicResults: UIC406Result[];
  conflictCount: number;
  onNavigateToOptimiser: () => void;
  onNavigateToMarey: () => void;
}

export const ExecutiveDashboard: React.FC<ExecutiveDashboardProps> = ({
  network,
  timetable,
  uicResults,
  conflictCount,
  onNavigateToOptimiser,
  onNavigateToMarey
}) => {
  const totalPaths = timetable.trainRuns.length;
  const totalTrackKm = network.tracks.reduce((acc, t) => acc + t.distanceKm, 0);

  // Compute average network speed
  let totalDistKm = 0;
  let totalTimeHours = 0;
  timetable.trainRuns.forEach(run => {
    if (run.schedule.length >= 2) {
      const startSec = run.schedule[0].departureSec;
      const endSec = run.schedule[run.schedule.length - 1].arrivalSec;
      const hours = (endSec - startSec) / 3600;
      if (hours > 0) {
        totalTimeHours += hours;
        // Estimate run distance
        const runStations = run.schedule.map(s => s.stationId);
        let runDist = 0;
        for (let i = 0; i < runStations.length - 1; i++) {
          const trk = network.tracks.find(
            t => (t.sourceStationId === runStations[i] && t.targetStationId === runStations[i + 1]) ||
                 (t.sourceStationId === runStations[i + 1] && t.targetStationId === runStations[i])
          );
          if (trk) runDist += trk.distanceKm;
        }
        totalDistKm += runDist;
      }
    }
  });

  const avgSpeedKmh = totalTimeHours > 0 ? Math.round(totalDistKm / totalTimeHours) : 165;
  const avgCapacityUtilisation = Math.round(
    uicResults.reduce((acc, r) => acc + r.capacityConsumptionPercent, 0) / (uicResults.length || 1)
  );

  const capacityData = uicResults.map(r => ({
    name: r.corridorName.split(' ')[0],
    utilisation: r.capacityConsumptionPercent,
    status: r.status
  }));

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner / System Status */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-1 text-xs font-bold rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30">
                Active Corridor: {network.name}
              </span>
              <span className="px-2.5 py-1 text-xs font-semibold rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                {timetable.name}
              </span>
            </div>
            <h2 className="text-2xl font-bold text-slate-100 tracking-tight">
              Operational Performance & Network Executive Overview
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl">
              Real-time timetable efficiency analysis, UIC 406 line capacity assessment, and headway conflict diagnostics.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onNavigateToOptimiser}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-amber-500/20 active:scale-95 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              <span>Optimize Timetable</span>
            </button>
            <button
              onClick={onNavigateToMarey}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition-all cursor-pointer"
            >
              <Train className="w-4 h-4 text-amber-400" />
              <span>View String Graph</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Train Paths */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider">Scheduled Train Paths</span>
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
              <Train className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-extrabold text-slate-100">{totalPaths}</span>
            <span className="text-xs font-semibold text-emerald-400 flex items-center gap-0.5">
              <TrendingUp className="w-3.5 h-3.5" /> +12.5% vs Base
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-2">Peak hour corridor density</p>
        </div>

        {/* KPI 2: Average Speed */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider">Average Commercial Speed</span>
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <Gauge className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-extrabold text-slate-100">{avgSpeedKmh} <span className="text-sm font-normal text-slate-400">km/h</span></span>
            <span className="text-xs font-semibold text-emerald-400 flex items-center gap-0.5">
              <ArrowUpRight className="w-3.5 h-3.5" /> Optimal
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-2">Corridor weighted average speed</p>
        </div>

        {/* KPI 3: Capacity Utilisation */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider">UIC 406 Line Utilisation</span>
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
              <Gauge className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-extrabold text-slate-100">{avgCapacityUtilisation}%</span>
            <span className={`text-xs font-semibold ${avgCapacityUtilisation > 75 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {avgCapacityUtilisation > 75 ? 'Heavy Load' : 'Balanced'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-2">Compressed headway packing ratio</p>
        </div>

        {/* KPI 4: Conflicts & Punctuality Risk */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider">Timetable Conflicts</span>
            <div className={`p-2 rounded-lg ${conflictCount > 0 ? 'bg-rose-500/10 text-rose-400' : 'bg-emerald-500/10 text-emerald-400'}`}>
              {conflictCount > 0 ? <AlertTriangle className="w-4 h-4" /> : <ShieldCheck className="w-4 h-4" />}
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className={`text-2xl font-extrabold ${conflictCount > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
              {conflictCount}
            </span>
            <span className="text-xs font-semibold text-slate-400">
              {conflictCount === 0 ? '0 Headway Breaches' : 'Needs Solving'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-2">Headway & platform overlaps</p>
        </div>
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Capacity Bar Chart */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Gauge className="w-4 h-4 text-amber-400" />
                UIC 406 Capacity Consumption per Track Section
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Target operating band: 60% – 75% for high punctuality buffer
              </p>
            </div>
            <span className="text-xs text-amber-400 font-semibold bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/20">
              UIC Standard 406
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={capacityData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} domain={[0, 100]} unit="%" tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#f8fafc' }}
                  formatter={(val: any) => [`${val}%`, 'Capacity Utilisation']}
                />
                <Bar dataKey="utilisation" radius={[6, 6, 0, 0]}>
                  {capacityData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.utilisation > 80 ? '#f43f5e' : entry.utilisation > 65 ? '#f59e0b' : '#10b981'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Operational Bottleneck Diagnostic Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2 mb-4">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Network Bottleneck Diagnostics
            </h3>

            <div className="space-y-3.5">
              {uicResults.filter(r => r.capacityConsumptionPercent > 70).map((b, i) => (
                <div key={i} className="p-3.5 rounded-lg bg-slate-950/80 border border-slate-800 text-xs space-y-1">
                  <div className="flex items-center justify-between font-bold text-slate-200">
                    <span>{b.corridorName}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-rose-500/20 text-rose-300 font-extrabold">
                      {b.capacityConsumptionPercent}% Utilised
                    </span>
                  </div>
                  <p className="text-slate-400">
                    Headway constraint: {b.scheduledPathsPerHour} paths/hr vs max {b.maxPossiblePathsPerHour} paths/hr.
                  </p>
                </div>
              ))}

              {uicResults.filter(r => r.capacityConsumptionPercent > 70).length === 0 && (
                <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>No severe bottleneck conflicts detected on current corridor.</span>
                </div>
              )}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>Total Network Track Length:</span>
            <span className="font-bold text-slate-200">{Math.round(totalTrackKm)} km</span>
          </div>
        </div>
      </div>
    </div>
  );
};
