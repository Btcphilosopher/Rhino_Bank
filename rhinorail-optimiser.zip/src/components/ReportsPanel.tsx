/**
 * RhinoRail Optimiser - Executive Reports & R Code Exporter Component
 */

import React, { useState } from 'react';
import { NetworkGraph, Timetable } from '../types/railway';
import { ReportGenerator } from '../services/reportGenerator';
import { FileSpreadsheet, FileText, Code, Download, Copy, Check } from 'lucide-react';

interface ReportsPanelProps {
  network: NetworkGraph;
  timetable: Timetable;
}

export const ReportsPanel: React.FC<ReportsPanelProps> = ({ network, timetable }) => {
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const rShinyCode = ReportGenerator.generateRShinySourceCode(network);

  const handleCopyRCode = () => {
    navigator.clipboard.writeText(rShinyCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleDownloadRCode = () => {
    const blob = new Blob([rShinyCode], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `app.R`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-100">Reporting Engine & Data Exporter</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Export institutional PDF executive briefings, GTFS timetable packages, Excel workbooks, and native R/Shiny application source code.
            </p>
          </div>
        </div>
      </div>

      {/* Export Cards Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* PDF Exporter */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-rose-500/10 text-rose-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">Executive PDF Briefing</h3>
              <p className="text-xs text-slate-400">Institutional summary report</p>
            </div>
          </div>
          <button
            onClick={() => ReportGenerator.generateExecutivePDF(network, timetable)}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 cursor-pointer transition-all"
          >
            <Download className="w-4 h-4 text-rose-400" />
            <span>Generate Executive PDF</span>
          </button>
        </div>

        {/* Excel Exporter */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">Excel Schedule Matrix</h3>
              <p className="text-xs text-slate-400">Full timetable & infrastructure workbook</p>
            </div>
          </div>
          <button
            onClick={() => ReportGenerator.exportTimetableToExcel(timetable, network)}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 cursor-pointer transition-all"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Export Excel (.xlsx)</span>
          </button>
        </div>

        {/* GTFS Package Exporter */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-blue-500/10 text-blue-400">
              <Code className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">GTFS Transit Package</h3>
              <p className="text-xs text-slate-400">Standard GTFS text files</p>
            </div>
          </div>
          <button
            onClick={() => {
              const gtfsText = ReportGenerator.exportGTFSCSV(timetable, network);
              const blob = new Blob([gtfsText], { type: 'text/plain' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `gtfs_rhinorail_${network.id}.txt`;
              a.click();
              URL.revokeObjectURL(url);
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 cursor-pointer transition-all"
          >
            <Download className="w-4 h-4 text-blue-400" />
            <span>Export GTFS CSV Text</span>
          </button>
        </div>
      </div>

      {/* R & Shiny Source Code Box */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-xl space-y-4 font-mono">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Code className="w-4 h-4 text-amber-400" />
              Generated R / Shiny Source Code (app.R)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Self-contained executable R script using Shiny, data.table, igraph, leaflet, and lpSolve.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyRCode}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-sans font-semibold cursor-pointer"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              <span>{copiedCode ? 'Copied!' : 'Copy Code'}</span>
            </button>
            <button
              onClick={handleDownloadRCode}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-sans font-bold cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download app.R</span>
            </button>
          </div>
        </div>

        <pre className="bg-slate-900 border border-slate-800 rounded-lg p-4 text-xs text-slate-300 overflow-x-auto max-h-80 leading-relaxed">
          {rShinyCode}
        </pre>
      </div>
    </div>
  );
};
