/**
 * RhinoRail Optimiser - Institutional Header Component
 */

import React from 'react';
import { Train, Network, Layers, Sparkles, Download, RefreshCw, Activity } from 'lucide-react';
import { NetworkGraph, Timetable, Scenario } from '../types/railway';
import { ALL_NETWORKS } from '../data/sampleNetworks';

interface HeaderProps {
  activeNetwork: NetworkGraph;
  activeTimetable: Timetable;
  activeScenario: Scenario | null;
  onSelectNetwork: (netId: string) => void;
  onRunOptimizer: () => void;
  onQuickExport: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeNetwork,
  activeTimetable,
  activeScenario,
  onSelectNetwork,
  onRunOptimizer,
  onQuickExport
}) => {
  return (
    <header className="bg-slate-950 border-b border-slate-800 px-6 py-3.5 text-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4 sticky top-0 z-50 backdrop-blur-md bg-opacity-95">
      {/* Brand & Logo */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-amber-600 to-orange-500 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-amber-500/20 ring-1 ring-amber-400/30">
          <Train className="w-6 h-6 stroke-[2.2]" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-slate-100 via-slate-200 to-amber-400 bg-clip-text text-transparent">
              RhinoRail Optimiser
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30">
              R Platform
            </span>
          </div>
          <p className="text-xs text-slate-400 flex items-center gap-1.5 font-medium">
            <Activity className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            Institutional Railway Timetable & Capacity Platform
          </p>
        </div>
      </div>

      {/* Network Preset Switcher & Action Controls */}
      <div className="flex flex-wrap items-center gap-3">
        {/* Network Selector */}
        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5">
          <Network className="w-4 h-4 text-amber-400" />
          <span className="text-xs text-slate-400 font-medium hidden sm:inline">Network:</span>
          <select
            value={activeNetwork.id}
            onChange={(e) => onSelectNetwork(e.target.value)}
            className="bg-transparent text-xs font-semibold text-slate-200 focus:outline-none cursor-pointer"
          >
            {ALL_NETWORKS.map(net => (
              <option key={net.id} value={net.id} className="bg-slate-900 text-slate-200">
                {net.name}
              </option>
            ))}
          </select>
        </div>

        {/* Active Scenario Indicator */}
        {activeScenario && (
          <div className="hidden lg:flex items-center gap-1.5 bg-amber-950/40 border border-amber-700/50 rounded-lg px-2.5 py-1.5 text-xs text-amber-300">
            <Layers className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-semibold truncate max-w-[140px]">{activeScenario.name}</span>
          </div>
        )}

        {/* Optimiser Shortcut Button */}
        <button
          onClick={onRunOptimizer}
          className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs transition-all shadow-md shadow-amber-500/20 active:scale-95 cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-slate-950" />
          <span>Run MILP Solver</span>
        </button>

        {/* Export Button */}
        <button
          onClick={onQuickExport}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
          title="Export PDF Briefing / Excel"
        >
          <Download className="w-4 h-4 text-slate-400" />
          <span className="hidden sm:inline">Export Report</span>
        </button>
      </div>
    </header>
  );
};
