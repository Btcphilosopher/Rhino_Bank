/**
 * RhinoRail Optimiser - Automated Unit Testing & Benchmarking Suite
 */

import React, { useState } from 'react';
import { NetworkGraph, Timetable, UnitTestResult } from '../types/railway';
import { NetworkEngine } from '../services/networkEngine';
import { CapacityEngine } from '../services/capacityEngine';
import { TimetableOptimizer } from '../services/timetableOptimizer';
import { CheckCircle2, XCircle, Play, ShieldCheck, Activity } from 'lucide-react';

interface UnitTestingPanelProps {
  network: NetworkGraph;
  timetable: Timetable;
}

export const UnitTestingPanel: React.FC<UnitTestingPanelProps> = ({ network, timetable }) => {
  const [testResults, setTestResults] = useState<UnitTestResult[]>([]);
  const [isRunningTests, setIsRunningTests] = useState<boolean>(false);

  const runAllTests = () => {
    setIsRunningTests(true);
    const results: UnitTestResult[] = [];

    // Test 1: Graph Connectivity
    const t1Start = performance.now();
    const hasStations = network.stations.length >= 2;
    const hasTracks = network.tracks.length >= 1;
    results.push({
      id: 'TEST_GRAPH_01',
      category: 'Network',
      name: 'Graph Connectivity & Node Validity',
      passed: hasStations && hasTracks,
      message: hasStations && hasTracks ? `Network contains ${network.stations.length} stations and ${network.tracks.length} track sections.` : 'Graph nodes or edges missing!',
      executionTimeMs: Math.round(performance.now() - t1Start)
    });

    // Test 2: Headway Conflict Check
    const t2Start = performance.now();
    const conflicts = NetworkEngine.detectTimetableConflicts(network, timetable, 120);
    results.push({
      id: 'TEST_HEADWAY_02',
      category: 'Headway',
      name: 'Signaling Headway Margin Compliance (&ge; 120s)',
      passed: conflicts.length === 0,
      message: conflicts.length === 0 ? 'All train runs respect minimum 120s signaling headway.' : `Detected ${conflicts.length} headway or platform overlaps.`,
      executionTimeMs: Math.round(performance.now() - t2Start)
    });

    // Test 3: UIC 406 Compression Evaluation
    const t3Start = performance.now();
    const uicRes = CapacityEngine.evaluateUIC406Capacity(network, timetable);
    const uicValid = uicRes.every(r => r.capacityConsumptionPercent <= 100);
    results.push({
      id: 'TEST_UIC_03',
      category: 'UIC406',
      name: 'UIC 406 Capacity Compression Bounds (&le; 100%)',
      passed: uicValid,
      message: uicValid ? 'UIC 406 capacity compression values within theoretical bounds.' : 'Capacity overload detected!',
      executionTimeMs: Math.round(performance.now() - t3Start)
    });

    // Test 4: MILP Solver Feasibility Benchmark
    const t4Start = performance.now();
    const optRes = TimetableOptimizer.optimizeTimetable(network, timetable, {
      objective: 'balanced',
      minHeadwaySec: 120,
      dwellBufferSec: 30,
      maxShiftMinutes: 10,
      ecoCoastingAllowance: true,
      syncInterchangePulse: true,
      selectedCorridorIds: [],
      maxSolverIterations: 10
    });
    const solverPassed = optRes.conflictsResolved >= 0;
    results.push({
      id: 'TEST_SOLVER_04',
      category: 'Solver',
      name: 'MILP Convergence & Heuristic Feasibility',
      passed: solverPassed,
      message: solverPassed ? `MILP Solver converged in ${optRes.logs.length} iterations. Capacity gain: +${optRes.capacityGainPercent}%.` : 'Solver failed to converge!',
      executionTimeMs: Math.round(performance.now() - t4Start)
    });

    setTimeout(() => {
      setTestResults(results);
      setIsRunningTests(false);
    }, 400);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-100">Automated Unit Testing & Benchmarking Suite</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Verification of graph connectivity, headway safety margins, UIC 406 compression rules, and MILP solver convergence.
            </p>
          </div>
        </div>

        <button
          onClick={runAllTests}
          disabled={isRunningTests}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-lg cursor-pointer transition-all disabled:opacity-50"
        >
          <Play className="w-4 h-4 fill-slate-950" />
          <span>{isRunningTests ? 'Executing Tests...' : 'Run All Tests'}</span>
        </button>
      </div>

      {/* Results List */}
      <div className="space-y-3">
        {testResults.map((t) => (
          <div
            key={t.id}
            className={`bg-slate-900 border rounded-xl p-4 shadow-lg flex items-center justify-between gap-4 ${
              t.passed ? 'border-emerald-500/30' : 'border-rose-500/30'
            }`}
          >
            <div className="flex items-center gap-3">
              {t.passed ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              ) : (
                <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
              )}
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-200">{t.name}</span>
                  <span className="px-2 py-0.2 rounded text-[10px] font-bold bg-slate-800 text-slate-400 uppercase">
                    {t.category}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">{t.message}</p>
              </div>
            </div>

            <span className="text-xs font-mono text-slate-500">{t.executionTimeMs} ms</span>
          </div>
        ))}

        {testResults.length === 0 && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-xs text-slate-400">
            Click 'Run All Tests' to execute the automated verification suite.
          </div>
        )}
      </div>
    </div>
  );
};
