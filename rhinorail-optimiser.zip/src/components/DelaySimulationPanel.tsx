/**
 * RhinoRail Optimiser - Stochastic Monte Carlo Delay Simulation Component
 */

import React, { useState } from 'react';
import { NetworkGraph, Timetable, DelaySimulationConfig, DelaySimulationResult } from '../types/railway';
import { DelaySimulator } from '../services/delaySimulator';
import { Clock, Play, AlertCircle, TrendingUp, RefreshCw, Activity, ShieldCheck } from 'lucide-react';

interface DelaySimulationPanelProps {
  network: NetworkGraph;
  timetable: Timetable;
}

export const DelaySimulationPanel: React.FC<DelaySimulationPanelProps> = ({ network, timetable }) => {
  const [simConfig, setSimConfig] = useState<DelaySimulationConfig>({
    primaryDelayProbability: 0.15,
    meanPrimaryDelaySec: 180,
    secondaryPropagationWeight: 0.8,
    monteCarloIterations: 500
  });

  const [simResult, setSimResult] = useState<DelaySimulationResult | null>(() =>
    DelaySimulator.runSimulation(network, timetable, simConfig)
  );

  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const handleRunSim = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const res = DelaySimulator.runSimulation(network, timetable, simConfig);
      setSimResult(res);
      setIsSimulating(false);
    }, 400);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Clock className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-slate-100">
              Monte Carlo Delay Simulation & Reactionary Propagation Engine
            </h2>
          </div>
          <p className="text-xs text-slate-400 max-w-2xl">
            Stochastic modeling of primary operational disturbances (Log-Normal distributions) and secondary knock-on delay propagation across network junction bottlenecks.
          </p>
        </div>

        <button
          onClick={handleRunSim}
          disabled={isSimulating}
          className="flex items-center gap-2 px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-lg cursor-pointer transition-all disabled:opacity-50"
        >
          <Play className="w-4 h-4 fill-slate-950" />
          <span>{isSimulating ? 'Running Monte Carlo...' : 'Run Simulation'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Simulation Controls */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg space-y-5">
          <h3 className="text-sm font-bold text-slate-100">Simulation Parameters</h3>

          <div className="space-y-4">
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-slate-300">
                <span>Primary Disturbance Probability:</span>
                <span className="font-bold text-amber-400">{Math.round(simConfig.primaryDelayProbability * 100)}%</span>
              </div>
              <input
                type="range"
                min={0.05}
                max={0.50}
                step={0.05}
                value={simConfig.primaryDelayProbability}
                onChange={(e) => setSimConfig({ ...simConfig, primaryDelayProbability: Number(e.target.value) })}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs text-slate-300">
                <span>Mean Primary Delay Duration:</span>
                <span className="font-bold text-amber-400">{Math.round(simConfig.meanPrimaryDelaySec / 60)} mins</span>
              </div>
              <input
                type="range"
                min={60}
                max={600}
                step={30}
                value={simConfig.meanPrimaryDelaySec}
                onChange={(e) => setSimConfig({ ...simConfig, meanPrimaryDelaySec: Number(e.target.value) })}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Results Overview */}
        {simResult && (
          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 shadow-lg text-center">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">PPM Punctuality</span>
                <span className="text-2xl font-extrabold text-emerald-400">{simResult.ppmPunctualityPercent}%</span>
                <p className="text-[10px] text-slate-500 mt-1">&le; 3 mins on-time</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 shadow-lg text-center">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Avg Delay / Train</span>
                <span className="text-2xl font-extrabold text-amber-400">{Math.round(simResult.avgDelayPerTrainSec / 60)}m {simResult.avgDelayPerTrainSec % 60}s</span>
                <p className="text-[10px] text-slate-500 mt-1">Weighted average</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 shadow-lg text-center">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Max Disturbance</span>
                <span className="text-2xl font-extrabold text-rose-400">{Math.round(simResult.maxDelaySec / 60)}m</span>
                <p className="text-[10px] text-slate-500 mt-1">Peak delay hit</p>
              </div>
            </div>

            {/* Delay Hotspots */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">Top Delay Hotspot Stations</h3>
              <div className="space-y-2">
                {simResult.stationDelayHotspots.map((st, i) => (
                  <div key={i} className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 text-xs">
                    <span className="font-semibold text-slate-200">{st.stationName}</span>
                    <span className="font-mono text-amber-400 font-bold">+{Math.round(st.totalDelaySec / 60)} mins delay</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
