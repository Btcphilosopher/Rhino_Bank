/**
 * RhinoRail Optimiser - MILP & Constraint Satisfaction Optimisation Module
 */

import React, { useState } from 'react';
import { NetworkGraph, Timetable, OptimisationConfig, OptimisationResult, SolverLogMessage } from '../types/railway';
import { TimetableOptimizer } from '../services/timetableOptimizer';
import { Sparkles, Sliders, CheckCircle2, AlertTriangle, ArrowRight, Activity, RotateCcw, Save } from 'lucide-react';

interface OptimisationPanelProps {
  network: NetworkGraph;
  timetable: Timetable;
  onApplyOptimisedTimetable: (result: OptimisationResult) => void;
}

export const OptimisationPanel: React.FC<OptimisationPanelProps> = ({
  network,
  timetable,
  onApplyOptimisedTimetable
}) => {
  const [config, setConfig] = useState<OptimisationConfig>({
    objective: 'balanced',
    minHeadwaySec: 120,
    dwellBufferSec: 45,
    maxShiftMinutes: 10,
    ecoCoastingAllowance: true,
    syncInterchangePulse: true,
    selectedCorridorIds: network.tracks.map(t => t.id),
    maxSolverIterations: 12
  });

  const [isSolving, setIsSolving] = useState<boolean>(false);
  const [solverResult, setSolverResult] = useState<OptimisationResult | null>(null);
  const [solverLogs, setSolverLogs] = useState<SolverLogMessage[]>([]);

  const handleRunSolver = () => {
    setIsSolving(true);
    setSolverLogs([]);

    setTimeout(() => {
      const result = TimetableOptimizer.optimizeTimetable(network, timetable, config, (log) => {
        setSolverLogs(prev => [...prev, log]);
      });

      setSolverResult(result);
      setIsSolving(false);
    }, 600);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-slate-100">
              Institutional MILP Timetable Optimiser & Conflict Solver
            </h2>
          </div>
          <p className="text-xs text-slate-400 max-w-2xl">
            Mathematical optimization engine for resolving signaling headway conflicts, synchronizing hub transfers, and compressing timetable margins under UIC 406 standards.
          </p>
        </div>

        <button
          onClick={handleRunSolver}
          disabled={isSolving}
          className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
        >
          <Sparkles className="w-4 h-4 text-slate-950" />
          <span>{isSolving ? 'Solving MILP Equations...' : 'Execute MILP Solver'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Solver Configuration Form */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg space-y-5">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            Optimisation Parameters & Objective
          </h3>

          {/* Objective Selection */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Optimization Primary Objective</label>
            <select
              value={config.objective}
              onChange={(e) => setConfig({ ...config, objective: e.target.value as any })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 focus:outline-none focus:border-amber-500 cursor-pointer"
            >
              <option value="balanced">Balanced Multi-Objective (Punctuality + Journey Time)</option>
              <option value="journeyTime">Minimize Total Passenger Journey Time</option>
              <option value="punctuality">Maximize Punctuality Resilience Buffer</option>
              <option value="capacity">Maximize UIC 406 Path Capacity</option>
              <option value="connections">Synchronize Hub Transfer Pulse (Taktfahrplan)</option>
            </select>
          </div>

          {/* Sliders */}
          <div className="space-y-4 pt-2">
            {/* Min Headway */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-medium text-slate-300">
                <span>Min Signaling Headway Buffer:</span>
                <span className="font-bold text-amber-400">{config.minHeadwaySec}s</span>
              </div>
              <input
                type="range"
                min={60}
                max={240}
                step={10}
                value={config.minHeadwaySec}
                onChange={(e) => setConfig({ ...config, minHeadwaySec: Number(e.target.value) })}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Dwell Buffer */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-medium text-slate-300">
                <span>Station Dwell Buffer:</span>
                <span className="font-bold text-amber-400">{config.dwellBufferSec}s</span>
              </div>
              <input
                type="range"
                min={15}
                max={120}
                step={5}
                value={config.dwellBufferSec}
                onChange={(e) => setConfig({ ...config, dwellBufferSec: Number(e.target.value) })}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Max Shift */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-medium text-slate-300">
                <span>Max Allowable Train Shift:</span>
                <span className="font-bold text-amber-400">{config.maxShiftMinutes} mins</span>
              </div>
              <input
                type="range"
                min={2}
                max={30}
                step={1}
                value={config.maxShiftMinutes}
                onChange={(e) => setConfig({ ...config, maxShiftMinutes: Number(e.target.value) })}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>
          </div>

          {/* Toggles */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={config.syncInterchangePulse}
                onChange={(e) => setConfig({ ...config, syncInterchangePulse: e.target.checked })}
                className="accent-amber-500 rounded cursor-pointer"
              />
              <span>Pulsed Clockface Interchange Alignment</span>
            </label>

            <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={config.ecoCoastingAllowance}
                onChange={(e) => setConfig({ ...config, ecoCoastingAllowance: e.target.checked })}
                className="accent-amber-500 rounded cursor-pointer"
              />
              <span>Include Eco-Coasting Energy Reserves</span>
            </label>
          </div>
        </div>

        {/* Live Solver Results & Execution Console */}
        <div className="lg:col-span-2 space-y-6">
          {/* Results Summary Cards */}
          {solverResult ? (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  MILP Optimisation Results
                </h3>
                <button
                  onClick={() => onApplyOptimisedTimetable(solverResult)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-all shadow-md cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Apply Optimised Timetable</span>
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2">
                <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 text-center">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Conflicts Resolved</span>
                  <span className="text-xl font-extrabold text-emerald-400">{solverResult.conflictsResolved}</span>
                </div>

                <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 text-center">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Capacity Gain</span>
                  <span className="text-xl font-extrabold text-amber-400">+{solverResult.capacityGainPercent}%</span>
                </div>

                <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 text-center">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Punctuality Score</span>
                  <span className="text-xl font-extrabold text-blue-400">+{solverResult.punctualityImprovementPercent}%</span>
                </div>

                <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 text-center">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Delay Risk Index</span>
                  <span className="text-xl font-extrabold text-slate-200">{solverResult.optimizedDelayRiskScore}</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center space-y-3">
              <Activity className="w-8 h-8 text-amber-400 mx-auto animate-bounce" />
              <h3 className="text-base font-bold text-slate-200">Ready to Solve Railway Timetable Equations</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Click 'Execute MILP Solver' to trigger the constraint-satisfaction heuristic engine.
              </p>
            </div>
          )}

          {/* Solver Progress Logs Console */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 shadow-lg font-mono text-xs space-y-2">
            <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-2 mb-2">
              <span className="font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                MILP Iteration Log Stream
              </span>
              <span>{solverLogs.length} events logged</span>
            </div>

            <div className="h-48 overflow-y-auto space-y-1.5 pr-2">
              {solverLogs.map((log, idx) => (
                <div key={idx} className="flex items-start gap-2 text-slate-300">
                  <span className="text-slate-500 font-semibold">{log.timestamp}</span>
                  <span className={`px-1.5 py-0.2 rounded text-[10px] ${
                    log.status === 'success' ? 'bg-emerald-500/20 text-emerald-400' :
                    log.status === 'resolving' ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-800 text-slate-300'
                  }`}>
                    [ITR #{log.iteration}]
                  </span>
                  <span className="flex-1">{log.message}</span>
                </div>
              ))}
              {solverLogs.length === 0 && (
                <span className="text-slate-600 italic">No solver events recorded yet. Execute solver to begin stream.</span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
