/**
 * RhinoRail Optimiser - Interactive Leaflet GIS Network Map
 */

import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { NetworkGraph, Timetable } from '../types/railway';
import { formatSecondsToTime } from '../data/sampleNetworks';
import { Play, Pause, RotateCcw, Map, Zap, AlertCircle } from 'lucide-react';

interface GisNetworkMapProps {
  network: NetworkGraph;
  timetable: Timetable;
}

export const GisNetworkMap: React.FC<GisNetworkMapProps> = ({ network, timetable }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  const [simTimeSec, setSimTimeSec] = useState<number>(25200); // 07:00:00 default
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [activeLayer, setActiveLayer] = useState<'speed' | 'capacity' | 'tracks'>('speed');

  // Animation Loop
  useEffect(() => {
    let interval: any = null;
    if (isPlaying) {
      interval = setInterval(() => {
        setSimTimeSec(prev => (prev >= 43200 ? 21600 : prev + 30));
      }, 500);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  // Leaflet Map Initialization & Rendering
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      // Calculate network center lat/lng
      const avgLat = network.stations.reduce((acc, s) => acc + s.lat, 0) / (network.stations.length || 1);
      const avgLng = network.stations.reduce((acc, s) => acc + s.lng, 0) / (network.stations.length || 1);

      const map = L.map(mapContainerRef.current).setView([avgLat, avgLng], 8);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;

    // Clear existing markers & polylines
    map.eachLayer((layer) => {
      if (layer instanceof L.Marker || layer instanceof L.Polyline || layer instanceof L.CircleMarker) {
        map.removeLayer(layer);
      }
    });

    // 1. Draw Track Lines
    network.tracks.forEach(track => {
      const srcSt = network.stations.find(s => s.id === track.sourceStationId);
      const tgtSt = network.stations.find(s => s.id === track.targetStationId);

      if (srcSt && tgtSt) {
        let lineColor = '#3b82f6';
        if (activeLayer === 'speed') {
          lineColor = track.maxSpeedKmh >= 200 ? '#a855f7' : track.maxSpeedKmh >= 160 ? '#3b82f6' : '#f59e0b';
        } else if (activeLayer === 'capacity') {
          lineColor = track.currentUtilisationPercent > 80 ? '#f43f5e' : track.currentUtilisationPercent > 65 ? '#f59e0b' : '#10b981';
        }

        const poly = L.polyline(
          [[srcSt.lat, srcSt.lng], [tgtSt.lat, tgtSt.lng]],
          { color: lineColor, weight: track.tracks === 4 ? 6 : track.tracks === 2 ? 4 : 2, opacity: 0.85 }
        ).addTo(map);

        poly.bindPopup(`
          <div class="p-2 text-xs font-sans text-slate-100">
            <h4 class="font-bold text-amber-400 text-sm">${track.name}</h4>
            <p>Distance: ${track.distanceKm} km | Speed: ${track.maxSpeedKmh} km/h</p>
            <p>Tracks: ${track.tracks} | Headway: ${track.signalingHeadwaySec}s</p>
            <p>Utilisation: ${track.currentUtilisationPercent}% | Electrification: ${track.electrification}</p>
          </div>
        `);
      }
    });

    // 2. Draw Station Nodes
    network.stations.forEach(station => {
      const circle = L.circleMarker([station.lat, station.lng], {
        radius: station.category === 'Major Terminus' ? 9 : 6,
        fillColor: station.isJunction ? '#f59e0b' : '#38bdf8',
        color: '#0f172a',
        weight: 2,
        fillOpacity: 0.9
      }).addTo(map);

      circle.bindPopup(`
        <div class="p-2 text-xs font-sans text-slate-100">
          <h4 class="font-bold text-amber-400 text-sm">${station.name} (${station.code})</h4>
          <p>Category: ${station.category}</p>
          <p>Platforms: ${station.platforms} | Default Dwell: ${station.defaultDwellSec}s</p>
        </div>
      `);
    });

    // 3. Draw Active Simulated Trains at Current simTimeSec
    timetable.trainRuns.forEach(run => {
      // Find where train is at simTimeSec
      for (let i = 0; i < run.schedule.length - 1; i++) {
        const stop1 = run.schedule[i];
        const stop2 = run.schedule[i + 1];

        if (simTimeSec >= stop1.departureSec && simTimeSec <= stop2.arrivalSec) {
          const st1 = network.stations.find(s => s.id === stop1.stationId);
          const st2 = network.stations.find(s => s.id === stop2.stationId);

          if (st1 && st2) {
            const ratio = (simTimeSec - stop1.departureSec) / Math.max(1, stop2.arrivalSec - stop1.departureSec);
            const trainLat = st1.lat + (st2.lat - st1.lat) * ratio;
            const trainLng = st1.lng + (st2.lng - st1.lng) * ratio;

            const trainMarker = L.circleMarker([trainLat, trainLng], {
              radius: 7,
              fillColor: run.color || '#ef4444',
              color: '#ffffff',
              weight: 2,
              fillOpacity: 1
            }).addTo(map);

            trainMarker.bindPopup(`
              <div class="p-1 text-xs font-sans">
                <span class="font-bold text-amber-400">${run.trainCode}</span> (${run.category})<br/>
                Next Stop: ${st2.name} at ${formatSecondsToTime(stop2.arrivalSec)}
              </div>
            `);
          }
          break;
        }
      }
    });

  }, [network, timetable, simTimeSec, activeLayer]);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Map Control Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4 shadow-lg">
        {/* Layer Switcher */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-semibold">Map Layer:</span>
          <button
            onClick={() => setActiveLayer('speed')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
              activeLayer === 'speed' ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300'
            }`}
          >
            Line Speed Limits
          </button>
          <button
            onClick={() => setActiveLayer('capacity')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
              activeLayer === 'capacity' ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300'
            }`}
          >
            Capacity Load %
          </button>
        </div>

        {/* Live Playback Simulation Controls */}
        <div className="flex items-center gap-3 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2">
          <span className="text-xs text-slate-400 font-mono font-bold">
            Sim Clock: <span className="text-amber-400 text-sm">{formatSecondsToTime(simTimeSec)}</span>
          </span>

          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-2 rounded-lg bg-amber-500 text-slate-950 hover:bg-amber-400 cursor-pointer transition-all"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-slate-950" />}
          </button>

          <button
            onClick={() => setSimTimeSec(21600)}
            className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <input
            type="range"
            min={21600}
            max={43200}
            step={300}
            value={simTimeSec}
            onChange={(e) => setSimTimeSec(Number(e.target.value))}
            className="w-32 accent-amber-500 cursor-pointer"
          />
        </div>
      </div>

      {/* GIS Leaflet Map Container */}
      <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl relative h-[600px] dark-map">
        <div ref={mapContainerRef} className="w-full h-full z-10" />
      </div>
    </div>
  );
};
