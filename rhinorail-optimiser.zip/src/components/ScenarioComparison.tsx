/**
 * RhinoRail Optimiser - Timetable Scenario A/B Comparison Component
 */

import React, { useState } from 'react';
import { Scenario, NetworkGraph, Timetable } from '../types/railway';
import { GitCompare, Plus, ArrowRight, CheckCircle2, TrendingUp, Sparkles } from 'lucide-react';

interface ScenarioComparisonProps {
  network: NetworkGraph;
  currentTimetable: Timetable;
}

export const ScenarioComparison: React.FC<ScenarioComparisonProps> = ({ network, currentTimetable }) => {
  const [scenarios, setScenarios] = useState<Scenario[]>([
    {
      id: 'SCEN_BASE',
      name: 'Baseline 2026 Timetable',
      description: 'Current active timetable baseline',
      network,
      timetable: currentTimetable,
      isBaseline: true,
      metrics: {
        avgJourneyTimeMin: 142,
        lineUtilisationPercent: 74,
        ppmPunctualityPercent: 91.2,
        totalTrainPathsPerDay: 48,
        conflictsCount: 3,
        co2EmissionsTonnes: 1240
      }
    },
    {
      id: 'SCEN_OPT_MILP',
      name: 'Scenario A: MILP Optimised (+15% Capacity)',
      description: 'MILP conflict-resolved timetable with 120s headways',
      network,
      timetable: currentTimetable,
      metrics: {
        avgJourneyTimeMin: 136,
        lineUtilisationPercent: 68,
        ppmPunctualityPercent: 96.8,
        totalTrainPathsPerDay: 54,
        conflictsCount: 0,
        co2EmissionsTonnes: 1180
      }
    },
    {
      id: 'SCEN_HIGH_SPEED',
      name: 'Scenario B: 250km/h Fleet Recast',
      description: 'High-speed rolling stock replacement on express paths',
      network,
      timetable: currentTimetable,
      metrics: {
        avgJourneyTimeMin: 118,
        lineUtilisationPercent: 62,
        ppmPunctualityPercent: 98.1,
        totalTrainPathsPerDay: 60,
        conflictsCount: 0,
        co2EmissionsTonnes: 1050
      }
    }
  ]);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400">
              <GitCompare className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-100">Timetable Scenario Evaluation & A/B Metric Diff</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Evaluate baseline vs proposed timetable recasts, fleet upgrades, and infrastructure enhancements.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Comparison Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {scenarios.map((scen) => (
          <div
            key={scen.id}
            className={`bg-slate-900 border rounded-2xl p-6 shadow-xl space-y-4 relative ${
              scen.isBaseline ? 'border-slate-800' : 'border-amber-500/40'
            }`}
          >
            {scen.isBaseline && (
              <span className="absolute top-4 right-4 text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                Baseline
              </span>
            )}
            {!scen.isBaseline && (
              <span className="absolute top-4 right-4 text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                Proposed
              </span>
            )}

            <div>
              <h3 className="text-base font-bold text-slate-100">{scen.name}</h3>
              <p className="text-xs text-slate-400 mt-1">{scen.description}</p>
            </div>

            <div className="space-y-3 pt-3 border-t border-slate-800 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Avg Journey Time:</span>
                <span className="font-extrabold text-slate-100 font-mono">{scen.metrics.avgJourneyTimeMin} mins</span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-slate-400">PPM Punctuality Target:</span>
                <span className="font-extrabold text-emerald-400 font-mono">{scen.metrics.ppmPunctualityPercent}%</span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-slate-400">UIC Capacity Index:</span>
                <span className="font-extrabold text-amber-400 font-mono">{scen.metrics.lineUtilisationPercent}%</span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-slate-400">Daily Train Paths:</span>
                <span className="font-extrabold text-blue-400 font-mono">{scen.metrics.totalTrainPathsPerDay} paths</span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-slate-400">Headway Conflicts:</span>
                <span className={`font-extrabold font-mono ${scen.metrics.conflictsCount > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {scen.metrics.conflictsCount}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
