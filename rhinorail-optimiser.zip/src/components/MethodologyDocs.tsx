/**
 * RhinoRail Optimiser - R Methodology & Documentation Component
 */

import React from 'react';
import { BookOpen, Code, Gauge, Sparkles, Terminal } from 'lucide-react';

export const MethodologyDocs: React.FC = () => {
  return (
    <div className="p-6 space-y-8 max-w-5xl mx-auto text-slate-200">
      {/* Title */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-2">
        <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
          <BookOpen className="w-4 h-4" />
          <span>Documentation & Operations Research Methodology</span>
        </div>
        <h2 className="text-2xl font-extrabold text-slate-100 tracking-tight">
          RhinoRail Optimiser — Mathematical Methodology & R Engine Reference
        </h2>
        <p className="text-xs text-slate-400 leading-relaxed">
          Institutional reference guide on graph network modelling, multi-objective linear programming (MILP), UIC Leaflet 406 capacity compression rules, and R / Shiny implementation architecture.
        </p>
      </div>

      {/* Section 1: MILP Formulation */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg space-y-4">
        <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400" />
          1. Multi-Objective Linear Programming (MILP) Formulation
        </h3>

        <div className="text-xs text-slate-300 space-y-3 leading-relaxed">
          <p>
            The timetable optimization engine models train path selection and departure shifts as a Mixed-Integer Linear Program (MILP) or constraint-satisfaction heuristic under the following formal objective function:
          </p>

          <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 font-mono text-amber-300">
            Min Z = &alpha; &middot; &sum; (T_journey,i) + &beta; &middot; &sum; (&Delta;_departure,i) + &gamma; &middot; &sum; (P_conflict,i,j)
          </div>

          <ul className="list-disc list-inside space-y-1.5 text-slate-400 pl-2">
            <li><strong>Subject to Signaling Headway Constraint:</strong> T_dep,j - T_dep,i &ge; H_min for all train pairs (i, j) on the same track section.</li>
            <li><strong>Station Dwell Buffer Constraint:</strong> T_dep,i,s - T_arr,i,s &ge; Dwell_i,s + Buffer_dwell.</li>
            <li><strong>Pulsed Taktfahrplan Connection Window:</strong> | T_arr,i,hub - T_dep,j,hub | &le; Window_interchange.</li>
          </ul>
        </div>
      </div>

      {/* Section 2: UIC 406 Capacity Compression */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg space-y-4">
        <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
          <Gauge className="w-4 h-4 text-amber-400" />
          2. UIC Leaflet 406 Capacity Compression Method
        </h3>

        <div className="text-xs text-slate-300 space-y-3 leading-relaxed">
          <p>
            The UIC 406 Compression Method evaluates line capacity by pushing train paths together in time until they touch at minimum signaling headways, stripping away non-essential buffer times:
          </p>

          <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 font-mono text-amber-300">
            Capacity Consumption Ratio (%) = ( T_compressed / T_total_window ) &times; 100%
          </div>

          <p className="text-slate-400">
            According to UIC guidelines, peak hour commercial corridors should maintain a capacity consumption ratio between <strong>60% and 75%</strong> to preserve sufficient operational elasticity against primary disturbance propagation.
          </p>
        </div>
      </div>

      {/* Section 3: R Shiny Package Integration */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg space-y-4">
        <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
          <Code className="w-4 h-4 text-amber-400" />
          3. Executable R Package Dependencies
        </h3>

        <div className="text-xs text-slate-300 space-y-2">
          <p>The exported R Shiny platform leverages institutional R libraries:</p>
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 font-mono text-xs text-slate-300 space-y-1">
            <p><span className="text-amber-400">data.table:</span> High-performance in-memory tabular manipulation of large GTFS stop times.</p>
            <p><span className="text-amber-400">igraph / tidygraph:</span> Topological graph algorithms for shortest path and network routing.</p>
            <p><span className="text-amber-400">lpSolve / ompr:</span> Solvers for Mixed-Integer Linear Programming models.</p>
            <p><span className="text-amber-400">leaflet / plotly:</span> Publication-quality interactive spatial and string diagram rendering.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
