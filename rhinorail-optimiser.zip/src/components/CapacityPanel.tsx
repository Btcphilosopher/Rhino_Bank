/**
 * RhinoRail Optimiser - UIC 406 Capacity & Corridor Analysis Component
 */

import React from 'react';
import { NetworkGraph, Timetable, UIC406Result } from '../types/railway';
import { Gauge, AlertTriangle, CheckCircle2, Train, ArrowUpRight } from 'lucide-react';

interface CapacityPanelProps {
  network: NetworkGraph;
  timetable: Timetable;
  uicResults: UIC406Result[];
}

export const CapacityPanel: React.FC<CapacityPanelProps> = ({ network, timetable, uicResults }) => {
  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400">
            <Gauge className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-100">
              UIC Leaflet 406 Capacity Compression & Path Packing Analysis
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              International Union of Railways (UIC) standard methodology for measuring railway line capacity consumption and identifying infrastructure bottlenecks.
            </p>
          </div>
        </div>
      </div>

      {/* Corridor Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-100">Corridor Track Section UIC 406 Breakdown</h3>
          <span className="text-xs text-slate-400">Target Peak Band: 60% – 75%</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-bold uppercase tracking-wider">
              <tr>
                <th className="p-3.5">Corridor Track Section</th>
                <th className="p-3.5">Scheduled Paths/hr</th>
                <th className="p-3.5">Max Theoretical Paths/hr</th>
                <th className="p-3.5">Compressed Time Window</th>
                <th className="p-3.5">UIC Capacity Index %</th>
                <th className="p-3.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {uicResults.map((res, idx) => (
                <tr key={idx} className="hover:bg-slate-800/50">
                  <td className="p-3.5 font-bold text-slate-100">{res.corridorName}</td>
                  <td className="p-3.5 font-mono">{res.scheduledPathsPerHour} paths/hr</td>
                  <td className="p-3.5 font-mono">{res.maxPossiblePathsPerHour} paths/hr</td>
                  <td className="p-3.5">{Math.round(res.compressedTimeSec / 60)} mins</td>
                  <td className="p-3.5">
                    <div className="flex items-center gap-2">
                      <div className="w-24 bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                        <div
                          className={`h-full ${
                            res.capacityConsumptionPercent > 80 ? 'bg-rose-500' :
                            res.capacityConsumptionPercent > 65 ? 'bg-amber-500' : 'bg-emerald-500'
                          }`}
                          style={{ width: `${res.capacityConsumptionPercent}%` }}
                        />
                      </div>
                      <span className="font-bold text-slate-100">{res.capacityConsumptionPercent}%</span>
                    </div>
                  </td>
                  <td className="p-3.5">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                      res.status === 'Overcapacity Risk' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                      res.status === 'Heavy Load' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                      'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    }`}>
                      {res.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
