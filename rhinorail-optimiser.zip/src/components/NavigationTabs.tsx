/**
 * RhinoRail Optimiser - Navigation Tabs Component
 */

import React from 'react';
import {
  BarChart3,
  GitCommit,
  MapPin,
  Sparkles,
  Gauge,
  Clock,
  GitCompare,
  FileSpreadsheet,
  CheckCircle2,
  BookOpen
} from 'lucide-react';

export type TabKey =
  | 'dashboard'
  | 'timetable'
  | 'gisMap'
  | 'optimiser'
  | 'capacity'
  | 'delays'
  | 'scenarios'
  | 'reports'
  | 'testing'
  | 'docs';

interface NavigationTabsProps {
  activeTab: TabKey;
  onTabChange: (tab: TabKey) => void;
  conflictCount: number;
}

export const NavigationTabs: React.FC<NavigationTabsProps> = ({
  activeTab,
  onTabChange,
  conflictCount
}) => {
  const tabs: { key: TabKey; label: string; icon: React.ComponentType<any>; badge?: string | number }[] = [
    { key: 'dashboard', label: 'Executive Dashboard', icon: BarChart3 },
    { key: 'timetable', label: 'Marey String Diagram', icon: GitCommit },
    { key: 'gisMap', label: 'GIS Network Map', icon: MapPin },
    { key: 'optimiser', label: 'MILP Optimiser', icon: Sparkles, badge: conflictCount > 0 ? `${conflictCount} conflicts` : 'Ready' },
    { key: 'capacity', label: 'UIC 406 Capacity', icon: Gauge },
    { key: 'delays', label: 'Delay Simulation', icon: Clock },
    { key: 'scenarios', label: 'Scenario A/B', icon: GitCompare },
    { key: 'reports', label: 'Reports & R Exporter', icon: FileSpreadsheet },
    { key: 'testing', label: 'Unit Tests', icon: CheckCircle2 },
    { key: 'docs', label: 'R Methodology', icon: BookOpen }
  ];

  return (
    <nav className="bg-slate-900 border-b border-slate-800 px-4 pt-2 overflow-x-auto scrollbar-none sticky top-[65px] z-40 backdrop-blur">
      <div className="flex items-center gap-1 min-w-max pb-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => onTabChange(tab.key)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer select-none ${
                isActive
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border border-transparent'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
              {tab.badge && (
                <span
                  className={`px-1.5 py-0.5 text-[10px] rounded-full font-bold ${
                    typeof tab.badge === 'string' && tab.badge.includes('conflicts')
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                      : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
