/**
 * RhinoRail Optimiser - Marey Train String Diagram Component (Distance vs Time)
 */

import React, { useState } from 'react';
import { NetworkGraph, Timetable, TrainRun, Station } from '../types/railway';
import { formatSecondsToTime, parseTimeToSeconds } from '../data/sampleNetworks';
import { NetworkEngine } from '../services/networkEngine';
import { Filter, Clock, ZoomIn, ZoomOut, AlertCircle, Edit3 } from 'lucide-react';

interface MareyStringChartProps {
  network: NetworkGraph;
  timetable: Timetable;
  onUpdateRun?: (updatedRun: TrainRun) => void;
}

export const MareyStringChart: React.FC<MareyStringChartProps> = ({
  network,
  timetable,
  onUpdateRun
}) => {
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [selectedRun, setSelectedRun] = useState<TrainRun | null>(null);
  const [startTimeWindowSec, setStartTimeWindowSec] = useState<number>(21600); // 06:00
  const [endTimeWindowSec, setEndTimeWindowSec] = useState<number>(39600);   // 11:00
  const [isEditingRun, setIsEditingRun] = useState<boolean>(false);

  const stationDistances = NetworkEngine.getStationCorridorDistances(network);
  const maxDistanceKm = Math.max(...Object.values(stationDistances), 100);

  // Filter train runs
  const filteredRuns = timetable.trainRuns.filter(run => {
    if (categoryFilter !== 'ALL' && run.category !== categoryFilter) return false;
    // Check if run falls in time window
    const firstStopSec = run.schedule[0]?.departureSec || 0;
    const lastStopSec = run.schedule[run.schedule.length - 1]?.arrivalSec || 86400;
    return lastStopSec >= startTimeWindowSec && firstStopSec <= endTimeWindowSec;
  });

  // Convert distance and time to SVG canvas coordinates
  const svgWidth = 900;
  const svgHeight = 550;
  const paddingLeft = 140;
  const paddingRight = 40;
  const paddingTop = 40;
  const paddingBottom = 50;

  const chartWidth = svgWidth - paddingLeft - paddingRight;
  const chartHeight = svgHeight - paddingTop - paddingBottom;

  const timeToX = (sec: number): number => {
    const ratio = (sec - startTimeWindowSec) / (endTimeWindowSec - startTimeWindowSec);
    return paddingLeft + Math.min(Math.max(ratio, 0), 1) * chartWidth;
  };

  const distToY = (distKm: number): number => {
    const ratio = distKm / maxDistanceKm;
    return paddingTop + ratio * chartHeight;
  };

  // Time ticks (every 30 mins)
  const timeTicks: number[] = [];
  for (let t = startTimeWindowSec; t <= endTimeWindowSec; t += 1800) {
    timeTicks.push(t);
  }

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4 shadow-lg">
        <div className="flex flex-wrap items-center gap-3">
          {/* Category Filter */}
          <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs">
            <Filter className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400 font-medium">Train Category:</span>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="bg-transparent text-slate-200 font-bold focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-slate-900">All Categories</option>
              <option value="HighSpeed" className="bg-slate-900">HighSpeed</option>
              <option value="Intercity" className="bg-slate-900">Intercity</option>
              <option value="Regional" className="bg-slate-900">Regional</option>
              <option value="Freight" className="bg-slate-900">Freight</option>
            </select>
          </div>

          {/* Time Window Buttons */}
          <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-800 rounded-lg p-1 text-xs">
            <Clock className="w-3.5 h-3.5 text-slate-400 ml-1.5" />
            <button
              onClick={() => { setStartTimeWindowSec(21600); setEndTimeWindowSec(39600); }}
              className={`px-2.5 py-1 rounded text-xs font-semibold cursor-pointer ${
                startTimeWindowSec === 21600 ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              Morning Peak (06-11)
            </button>
            <button
              onClick={() => { setStartTimeWindowSec(43200); setEndTimeWindowSec(61200); }}
              className={`px-2.5 py-1 rounded text-xs font-semibold cursor-pointer ${
                startTimeWindowSec === 43200 ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              Afternoon (12-17)
            </button>
            <button
              onClick={() => { setStartTimeWindowSec(0); setEndTimeWindowSec(86400); }}
              className={`px-2.5 py-1 rounded text-xs font-semibold cursor-pointer ${
                startTimeWindowSec === 0 ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              Full Day (24h)
            </button>
          </div>
        </div>

        <div className="text-xs text-slate-400 flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block" /> HighSpeed
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block ml-2" /> Regional
          <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block ml-2" /> Freight
        </div>
      </div>

      {/* Marey Chart SVG Canvas */}
      <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 shadow-2xl relative overflow-x-auto">
        <div className="min-w-[800px]">
          <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-auto select-none">
            {/* Background Grid Lines */}
            <g className="string-chart-grid">
              {/* Horizontal station distance lines */}
              {network.stations.map((station) => {
                const dist = stationDistances[station.id] || 0;
                const y = distToY(dist);
                return (
                  <g key={`st-grid-${station.id}`}>
                    <line x1={paddingLeft} y1={y} x2={svgWidth - paddingRight} y2={y} stroke="#1e293b" strokeWidth={1} />
                    <text x={paddingLeft - 12} y={y + 4} textAnchor="end" fill="#94a3b8" fontSize={10} fontWeight="bold">
                      {station.name} ({Math.round(dist)}km)
                    </text>
                  </g>
                );
              })}

              {/* Vertical time grid lines */}
              {timeTicks.map((t) => {
                const x = timeToX(t);
                const timeStr = formatSecondsToTime(t).substring(0, 5);
                return (
                  <g key={`time-grid-${t}`}>
                    <line x1={x} y1={paddingTop} x2={x} y2={svgHeight - paddingBottom} stroke="#1e293b" strokeWidth={1} strokeDasharray="3 3" />
                    <text x={x} y={svgHeight - paddingBottom + 18} textAnchor="middle" fill="#64748b" fontSize={10} fontWeight="600">
                      {timeStr}
                    </text>
                  </g>
                );
              })}
            </g>

            {/* Train String Paths */}
            <g>
              {filteredRuns.map((run) => {
                // Generate path string connecting stop points
                const points: { x: number; y: number }[] = [];
                run.schedule.forEach((stop) => {
                  const dist = stationDistances[stop.stationId];
                  if (dist !== undefined) {
                    const xArr = timeToX(stop.arrivalSec);
                    const xDep = timeToX(stop.departureSec);
                    const y = distToY(dist);

                    if (stop.arrivalSec !== stop.departureSec) {
                      points.push({ x: xArr, y });
                    }
                    points.push({ x: xDep, y });
                  }
                });

                if (points.length < 2) return null;

                const pathData = points.reduce((acc, p, idx) => {
                  return `${acc} ${idx === 0 ? 'M' : 'L'} ${p.x} ${p.y}`;
                }, '');

                const isSelected = selectedRun?.id === run.id;
                const hasConflict = run.conflicts && run.conflicts.length > 0;

                return (
                  <g key={`run-path-${run.id}`} className="cursor-pointer" onClick={() => setSelectedRun(run)}>
                    {/* Shadow / Highlight line */}
                    <path
                      d={pathData}
                      fill="none"
                      stroke={isSelected ? '#fbbf24' : hasConflict ? '#f43f5e' : run.color || '#3b82f6'}
                      strokeWidth={isSelected ? 4 : hasConflict ? 3 : 2}
                      strokeOpacity={isSelected ? 1 : 0.85}
                      className="transition-all hover:stroke-width-4"
                    />

                    {/* Station stop node circles */}
                    {points.map((p, pIdx) => (
                      <circle
                        key={`node-${run.id}-${pIdx}`}
                        cx={p.x}
                        cy={p.y}
                        r={isSelected ? 4 : 2.5}
                        fill={isSelected ? '#fbbf24' : run.color || '#3b82f6'}
                      />
                    ))}

                    {/* Train Code Label */}
                    <text
                      x={points[0].x + 4}
                      y={points[0].y - 6}
                      fill={hasConflict ? '#f43f5e' : run.color || '#3b82f6'}
                      fontSize={10}
                      fontWeight="bold"
                    >
                      {run.trainCode}
                    </text>
                  </g>
                );
              })}
            </g>
          </svg>
        </div>
      </div>

      {/* Selected Run Details Inspector */}
      {selectedRun && (
        <div className="bg-slate-900 border border-amber-500/30 rounded-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: selectedRun.color }} />
              <h3 className="text-base font-bold text-slate-100">
                Train Run Inspector — {selectedRun.trainCode} ({selectedRun.category})
              </h3>
            </div>
            <button
              onClick={() => setSelectedRun(null)}
              className="text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
            >
              Close
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left text-slate-300">
              <thead className="bg-slate-950 text-slate-400 font-bold uppercase tracking-wider">
                <tr>
                  <th className="p-2.5">Station</th>
                  <th className="p-2.5">Arrival</th>
                  <th className="p-2.5">Departure</th>
                  <th className="p-2.5">Platform</th>
                  <th className="p-2.5">Dwell Time</th>
                  <th className="p-2.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {selectedRun.schedule.map((stop, sIdx) => {
                  const station = network.stations.find(s => s.id === stop.stationId);
                  const dwellSec = stop.departureSec - stop.arrivalSec;
                  return (
                    <tr key={sIdx} className="hover:bg-slate-800/50">
                      <td className="p-2.5 font-bold text-slate-100">{station ? station.name : stop.stationId}</td>
                      <td className="p-2.5">{formatSecondsToTime(stop.arrivalSec)}</td>
                      <td className="p-2.5">{formatSecondsToTime(stop.departureSec)}</td>
                      <td className="p-2.5 font-mono text-amber-400 font-bold">{stop.platform}</td>
                      <td className="p-2.5">{stop.isPassThrough ? 'Pass' : `${dwellSec}s`}</td>
                      <td className="p-2.5">
                        {stop.isPassThrough ? (
                          <span className="text-slate-500">Non-Stop</span>
                        ) : (
                          <span className="text-emerald-400 font-semibold">Scheduled</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
