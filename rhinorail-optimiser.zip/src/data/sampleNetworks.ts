/**
 * RhinoRail Optimiser - Pre-loaded Institutional Railway Networks & Timetables
 */

import { NetworkGraph, Timetable, TrainRun, Station, TrackSection, TrainServicePattern } from '../types/railway';

// Format seconds into HH:MM:SS string helper
export function formatSecondsToTime(sec: number): string {
  const hours = Math.floor(sec / 3600) % 24;
  const mins = Math.floor((sec % 3600) / 60);
  const secs = Math.floor(sec % 60);
  return `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

export function parseTimeToSeconds(timeStr: string): number {
  const parts = timeStr.split(':').map(Number);
  if (parts.length === 2) return parts[0] * 3600 + parts[1] * 60;
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  return 0;
}

// -------------------------------------------------------------------
// 1. UK WEST COAST MAIN LINE (WCML CORRIDOR)
// -------------------------------------------------------------------

const wcmlStations: Station[] = [
  { id: 'EUS', code: 'EUS', name: 'London Euston', lat: 51.5282, lng: -0.1337, platforms: 18, defaultDwellSec: 180, isJunction: true, category: 'Major Terminus', elevationMeters: 35 },
  { id: 'WFJ', code: 'WFJ', name: 'Watford Junction', lat: 51.6636, lng: -0.3965, platforms: 10, defaultDwellSec: 60, isJunction: true, category: 'Hub Interchange', elevationMeters: 62 },
  { id: 'MKC', code: 'MKC', name: 'Milton Keynes Central', lat: 52.0344, lng: -0.7741, platforms: 6, defaultDwellSec: 90, isJunction: false, category: 'Hub Interchange', elevationMeters: 98 },
  { id: 'RUG', code: 'RUG', name: 'Rugby', lat: 52.3783, lng: -1.2536, platforms: 6, defaultDwellSec: 60, isJunction: true, category: 'Hub Interchange', elevationMeters: 105 },
  { id: 'COV', code: 'COV', name: 'Coventry', lat: 52.4008, lng: -1.5132, platforms: 4, defaultDwellSec: 90, isJunction: false, category: 'Regional Station', elevationMeters: 92 },
  { id: 'BHM', code: 'BHM', name: 'Birmingham New Street', lat: 52.4778, lng: -1.8988, platforms: 12, defaultDwellSec: 240, isJunction: true, category: 'Major Terminus', elevationMeters: 140 },
  { id: 'CRE', code: 'CRE', name: 'Crewe', lat: 53.0894, lng: -2.4331, platforms: 12, defaultDwellSec: 180, isJunction: true, category: 'Hub Interchange', elevationMeters: 48 },
  { id: 'PRE', code: 'PRE', name: 'Preston', lat: 53.7554, lng: -2.7073, platforms: 7, defaultDwellSec: 120, isJunction: true, category: 'Hub Interchange', elevationMeters: 38 },
  { id: 'CAR', code: 'CAR', name: 'Carlisle', lat: 54.8906, lng: -2.9328, platforms: 8, defaultDwellSec: 120, isJunction: true, category: 'Hub Interchange', elevationMeters: 22 },
  { id: 'GLC', code: 'GLC', name: 'Glasgow Central', lat: 55.8591, lng: -4.2581, platforms: 15, defaultDwellSec: 300, isJunction: true, category: 'Major Terminus', elevationMeters: 12 }
];

const wcmlTracks: TrackSection[] = [
  { id: 'T_EUS_WFJ', name: 'Euston - Watford Jct Fast', sourceStationId: 'EUS', targetStationId: 'WFJ', distanceKm: 28.1, maxSpeedKmh: 200, tracks: 4, signalingHeadwaySec: 120, gradientPercent: 0.3, electrification: '25kV AC', capacityMaxPathsPerHour: 24, currentUtilisationPercent: 78 },
  { id: 'T_WFJ_MKC', name: 'Watford Jct - Milton Keynes', sourceStationId: 'WFJ', targetStationId: 'MKC', distanceKm: 45.4, maxSpeedKmh: 200, tracks: 4, signalingHeadwaySec: 120, gradientPercent: 0.1, electrification: '25kV AC', capacityMaxPathsPerHour: 24, currentUtilisationPercent: 82 },
  { id: 'T_MKC_RUG', name: 'Milton Keynes - Rugby', sourceStationId: 'MKC', targetStationId: 'RUG', distanceKm: 51.2, maxSpeedKmh: 200, tracks: 4, signalingHeadwaySec: 130, gradientPercent: 0.4, electrification: '25kV AC', capacityMaxPathsPerHour: 22, currentUtilisationPercent: 74 },
  { id: 'T_RUG_COV', name: 'Rugby - Coventry', sourceStationId: 'RUG', targetStationId: 'COV', distanceKm: 18.2, maxSpeedKmh: 160, tracks: 2, signalingHeadwaySec: 150, gradientPercent: -0.2, electrification: '25kV AC', capacityMaxPathsPerHour: 18, currentUtilisationPercent: 89 },
  { id: 'T_COV_BHM', name: 'Coventry - Birmingham New St', sourceStationId: 'COV', targetStationId: 'BHM', distanceKm: 30.5, maxSpeedKmh: 160, tracks: 2, signalingHeadwaySec: 150, gradientPercent: 0.5, electrification: '25kV AC', capacityMaxPathsPerHour: 18, currentUtilisationPercent: 92 },
  { id: 'T_RUG_CRE', name: 'Trent Valley Bypass (Rugby-Crewe)', sourceStationId: 'RUG', targetStationId: 'CRE', distanceKm: 121.3, maxSpeedKmh: 200, tracks: 2, signalingHeadwaySec: 140, gradientPercent: 0.0, electrification: '25kV AC', capacityMaxPathsPerHour: 16, currentUtilisationPercent: 71 },
  { id: 'T_BHM_CRE', name: 'Birmingham - Crewe', sourceStationId: 'BHM', targetStationId: 'CRE', distanceKm: 86.0, maxSpeedKmh: 160, tracks: 2, signalingHeadwaySec: 160, gradientPercent: 0.2, electrification: '25kV AC', capacityMaxPathsPerHour: 14, currentUtilisationPercent: 85 },
  { id: 'T_CRE_PRE', name: 'Crewe - Preston', sourceStationId: 'CRE', targetStationId: 'PRE', distanceKm: 82.5, maxSpeedKmh: 200, tracks: 4, signalingHeadwaySec: 130, gradientPercent: -0.1, electrification: '25kV AC', capacityMaxPathsPerHour: 20, currentUtilisationPercent: 68 },
  { id: 'T_PRE_CAR', name: 'Preston - Carlisle (Shap Summit)', sourceStationId: 'PRE', targetStationId: 'CAR', distanceKm: 144.8, maxSpeedKmh: 200, tracks: 2, signalingHeadwaySec: 180, gradientPercent: 1.3, electrification: '25kV AC', capacityMaxPathsPerHour: 12, currentUtilisationPercent: 84 },
  { id: 'T_CAR_GLC', name: 'Carlisle - Glasgow Central', sourceStationId: 'CAR', targetStationId: 'GLC', distanceKm: 164.2, maxSpeedKmh: 200, tracks: 2, signalingHeadwaySec: 180, gradientPercent: 0.8, electrification: '25kV AC', capacityMaxPathsPerHour: 12, currentUtilisationPercent: 62 }
];

const wcmlPatterns: TrainServicePattern[] = [
  {
    id: 'P_AVANTI_GLASGOW',
    code: '1S00',
    name: 'Avanti West Coast Express (Euston-Glasgow)',
    category: 'HighSpeed',
    maxSpeedKmh: 200,
    accelerationMs2: 0.65,
    decelerationMs2: 0.85,
    color: '#3b82f6',
    stops: [
      { stationId: 'EUS', dwellSec: 0, isPassThrough: false },
      { stationId: 'MKC', dwellSec: 90, isPassThrough: false },
      { stationId: 'RUG', dwellSec: 0, isPassThrough: true },
      { stationId: 'CRE', dwellSec: 120, isPassThrough: false },
      { stationId: 'PRE', dwellSec: 120, isPassThrough: false },
      { stationId: 'CAR', dwellSec: 120, isPassThrough: false },
      { stationId: 'GLC', dwellSec: 0, isPassThrough: false }
    ]
  },
  {
    id: 'P_AVANTI_BIRMINGHAM',
    code: '1B00',
    name: 'Avanti West Coast (Euston-Birmingham)',
    category: 'HighSpeed',
    maxSpeedKmh: 200,
    accelerationMs2: 0.70,
    decelerationMs2: 0.90,
    color: '#06b6d4',
    stops: [
      { stationId: 'EUS', dwellSec: 0, isPassThrough: false },
      { stationId: 'WFJ', dwellSec: 60, isPassThrough: false },
      { stationId: 'MKC', dwellSec: 90, isPassThrough: false },
      { stationId: 'RUG', dwellSec: 60, isPassThrough: false },
      { stationId: 'COV', dwellSec: 90, isPassThrough: false },
      { stationId: 'BHM', dwellSec: 0, isPassThrough: false }
    ]
  },
  {
    id: 'P_LNW_SEMI_FAST',
    code: '2L00',
    name: 'LNW Semi-Fast Commuter',
    category: 'Regional',
    maxSpeedKmh: 160,
    accelerationMs2: 0.85,
    decelerationMs2: 1.0,
    color: '#10b981',
    stops: [
      { stationId: 'EUS', dwellSec: 0, isPassThrough: false },
      { stationId: 'WFJ', dwellSec: 90, isPassThrough: false },
      { stationId: 'MKC', dwellSec: 90, isPassThrough: false },
      { stationId: 'RUG', dwellSec: 90, isPassThrough: false },
      { stationId: 'COV', dwellSec: 90, isPassThrough: false },
      { stationId: 'BHM', dwellSec: 0, isPassThrough: false }
    ]
  },
  {
    id: 'P_FREIGHT_CONTAINER',
    code: '4M00',
    name: 'Intermodal Container Freight',
    category: 'Freight',
    maxSpeedKmh: 120,
    accelerationMs2: 0.25,
    decelerationMs2: 0.45,
    color: '#f59e0b',
    stops: [
      { stationId: 'EUS', dwellSec: 0, isPassThrough: false },
      { stationId: 'WFJ', dwellSec: 0, isPassThrough: true },
      { stationId: 'MKC', dwellSec: 0, isPassThrough: true },
      { stationId: 'RUG', dwellSec: 300, isPassThrough: false },
      { stationId: 'CRE', dwellSec: 600, isPassThrough: false },
      { stationId: 'PRE', dwellSec: 0, isPassThrough: true },
      { stationId: 'CAR', dwellSec: 0, isPassThrough: true },
      { stationId: 'GLC', dwellSec: 0, isPassThrough: false }
    ]
  }
];

export const wcmlNetwork: NetworkGraph = {
  id: 'NET_WCML',
  name: 'UK West Coast Main Line (WCML Corridor)',
  description: 'Primary UK mixed-traffic trunk line combining 200km/h high-speed Pendolino expresses, suburban commuters, and 120km/h intermodal freight.',
  stations: wcmlStations,
  tracks: wcmlTracks,
  servicePatterns: wcmlPatterns
};

// Generate realistic Timetable runs for WCML
export const wcmlTimetable: Timetable = {
  id: 'TT_WCML_BASELINE',
  name: 'WCML 2026 Peak Operational Timetable',
  description: 'Baseline 06:00 - 10:00 morning peak timetable featuring 14 intercity, regional, and freight train paths.',
  createdDate: '2026-08-05',
  trainRuns: [
    // 06:30 Glasgow Express
    {
      id: 'RUN_1S01',
      trainCode: '1S01',
      servicePatternId: 'P_AVANTI_GLASGOW',
      category: 'HighSpeed',
      originStationId: 'EUS',
      destinationStationId: 'GLC',
      originTimeSec: parseTimeToSeconds('06:30:00'),
      color: '#3b82f6',
      schedule: [
        { stationId: 'EUS', arrivalSec: parseTimeToSeconds('06:30:00'), departureSec: parseTimeToSeconds('06:30:00'), platform: 'P1', isPassThrough: false },
        { stationId: 'MKC', arrivalSec: parseTimeToSeconds('06:58:00'), departureSec: parseTimeToSeconds('06:59:30'), platform: 'P3', isPassThrough: false },
        { stationId: 'CRE', arrivalSec: parseTimeToSeconds('07:54:00'), departureSec: parseTimeToSeconds('07:56:00'), platform: 'P5', isPassThrough: false },
        { stationId: 'PRE', arrivalSec: parseTimeToSeconds('08:24:00'), departureSec: parseTimeToSeconds('08:26:00'), platform: 'P4', isPassThrough: false },
        { stationId: 'CAR', arrivalSec: parseTimeToSeconds('09:14:00'), departureSec: parseTimeToSeconds('09:16:00'), platform: 'P3', isPassThrough: false },
        { stationId: 'GLC', arrivalSec: parseTimeToSeconds('10:18:00'), departureSec: parseTimeToSeconds('10:18:00'), platform: 'P2', isPassThrough: false }
      ]
    },
    // 06:40 Birmingham Express
    {
      id: 'RUN_1B01',
      trainCode: '1B01',
      servicePatternId: 'P_AVANTI_BIRMINGHAM',
      category: 'HighSpeed',
      originStationId: 'EUS',
      destinationStationId: 'BHM',
      originTimeSec: parseTimeToSeconds('06:40:00'),
      color: '#06b6d4',
      schedule: [
        { stationId: 'EUS', arrivalSec: parseTimeToSeconds('06:40:00'), departureSec: parseTimeToSeconds('06:40:00'), platform: 'P2', isPassThrough: false },
        { stationId: 'WFJ', arrivalSec: parseTimeToSeconds('06:53:00'), departureSec: parseTimeToSeconds('06:54:00'), platform: 'P6', isPassThrough: false },
        { stationId: 'MKC', arrivalSec: parseTimeToSeconds('07:11:00'), departureSec: parseTimeToSeconds('07:12:30'), platform: 'P2', isPassThrough: false },
        { stationId: 'RUG', arrivalSec: parseTimeToSeconds('07:31:00'), departureSec: parseTimeToSeconds('07:32:00'), platform: 'P2', isPassThrough: false },
        { stationId: 'COV', arrivalSec: parseTimeToSeconds('07:44:00'), departureSec: parseTimeToSeconds('07:45:30'), platform: 'P1', isPassThrough: false },
        { stationId: 'BHM', arrivalSec: parseTimeToSeconds('08:02:00'), departureSec: parseTimeToSeconds('08:02:00'), platform: 'P3', isPassThrough: false }
      ]
    },
    // 06:45 LNW Semi-Fast (Overlaps with 06:40 Express near Watford/Milton Keynes -> potential conflict!)
    {
      id: 'RUN_2L01',
      trainCode: '2L01',
      servicePatternId: 'P_LNW_SEMI_FAST',
      category: 'Regional',
      originStationId: 'EUS',
      destinationStationId: 'BHM',
      originTimeSec: parseTimeToSeconds('06:45:00'),
      color: '#10b981',
      conflicts: ['RUN_1B01'],
      schedule: [
        { stationId: 'EUS', arrivalSec: parseTimeToSeconds('06:45:00'), departureSec: parseTimeToSeconds('06:45:00'), platform: 'P3', isPassThrough: false },
        { stationId: 'WFJ', arrivalSec: parseTimeToSeconds('07:01:00'), departureSec: parseTimeToSeconds('07:02:30'), platform: 'P7', isPassThrough: false },
        { stationId: 'MKC', arrivalSec: parseTimeToSeconds('07:23:00'), departureSec: parseTimeToSeconds('07:24:30'), platform: 'P4', isPassThrough: false },
        { stationId: 'RUG', arrivalSec: parseTimeToSeconds('07:48:00'), departureSec: parseTimeToSeconds('07:49:30'), platform: 'P3', isPassThrough: false },
        { stationId: 'COV', arrivalSec: parseTimeToSeconds('08:03:00'), departureSec: parseTimeToSeconds('08:04:30'), platform: 'P2', isPassThrough: false },
        { stationId: 'BHM', arrivalSec: parseTimeToSeconds('08:24:00'), departureSec: parseTimeToSeconds('08:24:00'), platform: 'P5', isPassThrough: false }
      ]
    },
    // 06:50 Intermodal Freight
    {
      id: 'RUN_4M01',
      trainCode: '4M01',
      servicePatternId: 'P_FREIGHT_CONTAINER',
      category: 'Freight',
      originStationId: 'EUS',
      destinationStationId: 'GLC',
      originTimeSec: parseTimeToSeconds('06:50:00'),
      color: '#f59e0b',
      schedule: [
        { stationId: 'EUS', arrivalSec: parseTimeToSeconds('06:50:00'), departureSec: parseTimeToSeconds('06:50:00'), platform: 'P15', isPassThrough: false },
        { stationId: 'WFJ', arrivalSec: parseTimeToSeconds('07:12:00'), departureSec: parseTimeToSeconds('07:12:00'), platform: 'P10', isPassThrough: true },
        { stationId: 'MKC', arrivalSec: parseTimeToSeconds('07:41:00'), departureSec: parseTimeToSeconds('07:41:00'), platform: 'P6', isPassThrough: true },
        { stationId: 'RUG', arrivalSec: parseTimeToSeconds('08:14:00'), departureSec: parseTimeToSeconds('08:19:00'), platform: 'P6', isPassThrough: false },
        { stationId: 'CRE', arrivalSec: parseTimeToSeconds('09:35:00'), departureSec: parseTimeToSeconds('09:45:00'), platform: 'P11', isPassThrough: false },
        { stationId: 'PRE', arrivalSec: parseTimeToSeconds('10:32:00'), departureSec: parseTimeToSeconds('10:32:00'), platform: 'P7', isPassThrough: true },
        { stationId: 'CAR', arrivalSec: parseTimeToSeconds('11:58:00'), departureSec: parseTimeToSeconds('11:58:00'), platform: 'P8', isPassThrough: true },
        { stationId: 'GLC', arrivalSec: parseTimeToSeconds('13:30:00'), departureSec: parseTimeToSeconds('13:30:00'), platform: 'P12', isPassThrough: false }
      ]
    },
    // 07:00 Glasgow Express
    {
      id: 'RUN_1S02',
      trainCode: '1S02',
      servicePatternId: 'P_AVANTI_GLASGOW',
      category: 'HighSpeed',
      originStationId: 'EUS',
      destinationStationId: 'GLC',
      originTimeSec: parseTimeToSeconds('07:00:00'),
      color: '#3b82f6',
      schedule: [
        { stationId: 'EUS', arrivalSec: parseTimeToSeconds('07:00:00'), departureSec: parseTimeToSeconds('07:00:00'), platform: 'P1', isPassThrough: false },
        { stationId: 'MKC', arrivalSec: parseTimeToSeconds('07:28:00'), departureSec: parseTimeToSeconds('07:29:30'), platform: 'P3', isPassThrough: false },
        { stationId: 'CRE', arrivalSec: parseTimeToSeconds('08:24:00'), departureSec: parseTimeToSeconds('08:26:00'), platform: 'P5', isPassThrough: false },
        { stationId: 'PRE', arrivalSec: parseTimeToSeconds('08:54:00'), departureSec: parseTimeToSeconds('08:56:00'), platform: 'P4', isPassThrough: false },
        { stationId: 'CAR', arrivalSec: parseTimeToSeconds('09:44:00'), departureSec: parseTimeToSeconds('09:46:00'), platform: 'P3', isPassThrough: false },
        { stationId: 'GLC', arrivalSec: parseTimeToSeconds('10:48:00'), departureSec: parseTimeToSeconds('10:48:00'), platform: 'P2', isPassThrough: false }
      ]
    },
    // 07:15 Birmingham Express
    {
      id: 'RUN_1B02',
      trainCode: '1B02',
      servicePatternId: 'P_AVANTI_BIRMINGHAM',
      category: 'HighSpeed',
      originStationId: 'EUS',
      destinationStationId: 'BHM',
      originTimeSec: parseTimeToSeconds('07:15:00'),
      color: '#06b6d4',
      schedule: [
        { stationId: 'EUS', arrivalSec: parseTimeToSeconds('07:15:00'), departureSec: parseTimeToSeconds('07:15:00'), platform: 'P2', isPassThrough: false },
        { stationId: 'WFJ', arrivalSec: parseTimeToSeconds('07:28:00'), departureSec: parseTimeToSeconds('07:29:00'), platform: 'P6', isPassThrough: false },
        { stationId: 'MKC', arrivalSec: parseTimeToSeconds('07:46:00'), departureSec: parseTimeToSeconds('07:47:30'), platform: 'P2', isPassThrough: false },
        { stationId: 'RUG', arrivalSec: parseTimeToSeconds('08:06:00'), departureSec: parseTimeToSeconds('08:07:00'), platform: 'P2', isPassThrough: false },
        { stationId: 'COV', arrivalSec: parseTimeToSeconds('08:19:00'), departureSec: parseTimeToSeconds('08:20:30'), platform: 'P1', isPassThrough: false },
        { stationId: 'BHM', arrivalSec: parseTimeToSeconds('08:37:00'), departureSec: parseTimeToSeconds('08:37:00'), platform: 'P3', isPassThrough: false }
      ]
    }
  ]
};

// -------------------------------------------------------------------
// 2. NORDIC HIGH-SPEED TRUNK (STOCKHOLM - GOTHENBURG)
// -------------------------------------------------------------------

const nordicStations: Station[] = [
  { id: 'CST', code: 'CST', name: 'Stockholm Central', lat: 59.3300, lng: 18.0583, platforms: 19, defaultDwellSec: 240, isJunction: true, category: 'Major Terminus', elevationMeters: 15 },
  { id: 'SÖD', code: 'SÖD', name: 'Södertälje Syd', lat: 59.1622, lng: 17.6521, platforms: 4, defaultDwellSec: 60, isJunction: true, category: 'Hub Interchange', elevationMeters: 38 },
  { id: 'KTR', code: 'KTR', name: 'Katrineholm C', lat: 58.9959, lng: 16.2081, platforms: 4, defaultDwellSec: 90, isJunction: true, category: 'Hub Interchange', elevationMeters: 46 },
  { id: 'HLS', code: 'HLS', name: 'Hallsberg C', lat: 59.0667, lng: 15.1083, platforms: 8, defaultDwellSec: 120, isJunction: true, category: 'Hub Interchange', elevationMeters: 52 },
  { id: 'SKV', code: 'SKV', name: 'Skövde Central', lat: 58.3903, lng: 13.8453, platforms: 4, defaultDwellSec: 90, isJunction: false, category: 'Regional Station', elevationMeters: 145 },
  { id: 'HER', code: 'HER', name: 'Herrljunga C', lat: 58.0772, lng: 13.0275, platforms: 5, defaultDwellSec: 60, isJunction: true, category: 'Hub Interchange', elevationMeters: 122 },
  { id: 'GÖT', code: 'GÖT', name: 'Göteborg Central', lat: 57.7089, lng: 11.9733, platforms: 16, defaultDwellSec: 300, isJunction: true, category: 'Major Terminus', elevationMeters: 5 }
];

const nordicTracks: TrackSection[] = [
  { id: 'T_CST_SÖD', name: 'Stockholm - Södertälje HSL', sourceStationId: 'CST', targetStationId: 'SÖD', distanceKm: 37.5, maxSpeedKmh: 200, tracks: 4, signalingHeadwaySec: 120, gradientPercent: 0.1, electrification: '15kV AC', capacityMaxPathsPerHour: 24, currentUtilisationPercent: 81 },
  { id: 'T_SÖD_KTR', name: 'Södertälje - Katrineholm', sourceStationId: 'SÖD', targetStationId: 'KTR', distanceKm: 86.2, maxSpeedKmh: 250, tracks: 2, signalingHeadwaySec: 110, gradientPercent: 0.0, electrification: '15kV AC', capacityMaxPathsPerHour: 20, currentUtilisationPercent: 65 },
  { id: 'T_KTR_HLS', name: 'Katrineholm - Hallsberg', sourceStationId: 'KTR', targetStationId: 'HLS', distanceKm: 60.1, maxSpeedKmh: 250, tracks: 2, signalingHeadwaySec: 110, gradientPercent: 0.2, electrification: '15kV AC', capacityMaxPathsPerHour: 20, currentUtilisationPercent: 70 },
  { id: 'T_HLS_SKV', name: 'Hallsberg - Skövde', sourceStationId: 'HLS', targetStationId: 'SKV', distanceKm: 98.4, maxSpeedKmh: 250, tracks: 2, signalingHeadwaySec: 110, gradientPercent: 0.1, electrification: '15kV AC', capacityMaxPathsPerHour: 20, currentUtilisationPercent: 58 },
  { id: 'T_SKV_HER', name: 'Skövde - Herrljunga', sourceStationId: 'SKV', targetStationId: 'HER', distanceKm: 68.3, maxSpeedKmh: 200, tracks: 2, signalingHeadwaySec: 130, gradientPercent: 0.3, electrification: '15kV AC', capacityMaxPathsPerHour: 18, currentUtilisationPercent: 62 },
  { id: 'T_HER_GÖT', name: 'Herrljunga - Göteborg', sourceStationId: 'HER', targetStationId: 'GÖT', distanceKm: 80.5, maxSpeedKmh: 200, tracks: 2, signalingHeadwaySec: 130, gradientPercent: -0.2, electrification: '15kV AC', capacityMaxPathsPerHour: 18, currentUtilisationPercent: 77 }
];

const nordicPatterns: TrainServicePattern[] = [
  {
    id: 'P_SJ_X2000',
    code: 'X2000',
    name: 'SJ X2000 Tilting High-Speed',
    category: 'HighSpeed',
    maxSpeedKmh: 250,
    accelerationMs2: 0.75,
    decelerationMs2: 0.95,
    color: '#8b5cf6',
    stops: [
      { stationId: 'CST', dwellSec: 0, isPassThrough: false },
      { stationId: 'SÖD', dwellSec: 0, isPassThrough: true },
      { stationId: 'KTR', dwellSec: 60, isPassThrough: false },
      { stationId: 'HLS', dwellSec: 0, isPassThrough: true },
      { stationId: 'SKV', dwellSec: 90, isPassThrough: false },
      { stationId: 'HER', dwellSec: 0, isPassThrough: true },
      { stationId: 'GÖT', dwellSec: 0, isPassThrough: false }
    ]
  },
  {
    id: 'P_VR_INTERCITY',
    code: 'IC',
    name: 'InterCity Regional Express',
    category: 'Intercity',
    maxSpeedKmh: 200,
    accelerationMs2: 0.60,
    decelerationMs2: 0.80,
    color: '#ec4899',
    stops: [
      { stationId: 'CST', dwellSec: 0, isPassThrough: false },
      { stationId: 'SÖD', dwellSec: 60, isPassThrough: false },
      { stationId: 'KTR', dwellSec: 90, isPassThrough: false },
      { stationId: 'HLS', dwellSec: 120, isPassThrough: false },
      { stationId: 'SKV', dwellSec: 90, isPassThrough: false },
      { stationId: 'HER', dwellSec: 60, isPassThrough: false },
      { stationId: 'GÖT', dwellSec: 0, isPassThrough: false }
    ]
  }
];

export const nordicNetwork: NetworkGraph = {
  id: 'NET_NORDIC',
  name: 'Nordic High-Speed Trunk (Stockholm - Gothenburg)',
  description: 'Västra Stambanan trunk corridor supporting 250km/h SJ X2000 tilting trains and regional commuter traffic.',
  stations: nordicStations,
  tracks: nordicTracks,
  servicePatterns: nordicPatterns
};

export const nordicTimetable: Timetable = {
  id: 'TT_NORDIC_BASELINE',
  name: 'Nordic Express 2026 Morning Clockface Timetable',
  description: 'Pulsed clockface timetable with hourly 250km/h departures.',
  createdDate: '2026-08-05',
  trainRuns: [
    {
      id: 'RUN_X501',
      trainCode: 'X501',
      servicePatternId: 'P_SJ_X2000',
      category: 'HighSpeed',
      originStationId: 'CST',
      destinationStationId: 'GÖT',
      originTimeSec: parseTimeToSeconds('07:10:00'),
      color: '#8b5cf6',
      schedule: [
        { stationId: 'CST', arrivalSec: parseTimeToSeconds('07:10:00'), departureSec: parseTimeToSeconds('07:10:00'), platform: 'P10', isPassThrough: false },
        { stationId: 'SÖD', arrivalSec: parseTimeToSeconds('07:23:00'), departureSec: parseTimeToSeconds('07:23:00'), platform: 'P2', isPassThrough: true },
        { stationId: 'KTR', arrivalSec: parseTimeToSeconds('07:47:00'), departureSec: parseTimeToSeconds('07:48:00'), platform: 'P1', isPassThrough: false },
        { stationId: 'HLS', arrivalSec: parseTimeToSeconds('08:05:00'), departureSec: parseTimeToSeconds('08:05:00'), platform: 'P3', isPassThrough: true },
        { stationId: 'SKV', arrivalSec: parseTimeToSeconds('08:32:00'), departureSec: parseTimeToSeconds('08:33:30'), platform: 'P2', isPassThrough: false },
        { stationId: 'HER', arrivalSec: parseTimeToSeconds('08:57:00'), departureSec: parseTimeToSeconds('08:57:00'), platform: 'P1', isPassThrough: true },
        { stationId: 'GÖT', arrivalSec: parseTimeToSeconds('09:24:00'), departureSec: parseTimeToSeconds('09:24:00'), platform: 'P5', isPassThrough: false }
      ]
    },
    {
      id: 'RUN_IC601',
      trainCode: 'IC601',
      servicePatternId: 'P_VR_INTERCITY',
      category: 'Intercity',
      originStationId: 'CST',
      destinationStationId: 'GÖT',
      originTimeSec: parseTimeToSeconds('07:25:00'),
      color: '#ec4899',
      schedule: [
        { stationId: 'CST', arrivalSec: parseTimeToSeconds('07:25:00'), departureSec: parseTimeToSeconds('07:25:00'), platform: 'P11', isPassThrough: false },
        { stationId: 'SÖD', arrivalSec: parseTimeToSeconds('07:41:00'), departureSec: parseTimeToSeconds('07:42:00'), platform: 'P3', isPassThrough: false },
        { stationId: 'KTR', arrivalSec: parseTimeToSeconds('08:11:00'), departureSec: parseTimeToSeconds('08:12:30'), platform: 'P2', isPassThrough: false },
        { stationId: 'HLS', arrivalSec: parseTimeToSeconds('08:33:00'), departureSec: parseTimeToSeconds('08:35:00'), platform: 'P4', isPassThrough: false },
        { stationId: 'SKV', arrivalSec: parseTimeToSeconds('09:08:00'), departureSec: parseTimeToSeconds('09:09:30'), platform: 'P1', isPassThrough: false },
        { stationId: 'HER', arrivalSec: parseTimeToSeconds('09:34:00'), departureSec: parseTimeToSeconds('09:35:00'), platform: 'P2', isPassThrough: false },
        { stationId: 'GÖT', arrivalSec: parseTimeToSeconds('10:05:00'), departureSec: parseTimeToSeconds('10:05:00'), platform: 'P6', isPassThrough: false }
      ]
    }
  ]
};

export const ALL_NETWORKS: NetworkGraph[] = [wcmlNetwork, nordicNetwork];
export const ALL_TIMETABLES: Record<string, Timetable> = {
  [wcmlNetwork.id]: wcmlTimetable,
  [nordicNetwork.id]: nordicTimetable
};
