import React, { useState } from 'react';
import { Navbar, ModuleTab } from './components/Navbar';
import { WorldOverview } from './components/WorldOverview';
import { WorldMap } from './components/WorldMap';
import { CountryProfiles } from './components/CountryProfiles';
import { BilateralCorridors } from './components/BilateralCorridors';
import { ProductsSectors } from './components/ProductsSectors';
import { CommodityEngine } from './components/CommodityEngine';
import { SupplyChainEngine } from './components/SupplyChainEngine';
import { TariffScenarioLab } from './components/TariffScenarioLab';
import { ShippingLogistics } from './components/ShippingLogistics';
import { NetworkGraph } from './components/NetworkGraph';
import { GravityEconometrics } from './components/GravityEconometrics';
import { ForecastEngine } from './components/ForecastEngine';
import { UniversalXYEngine } from './components/UniversalXYEngine';
import { ScreenerAnomaly } from './components/ScreenerAnomaly';
import { ResearchWorkspace } from './components/ResearchWorkspace';
import { DataQualityEngine } from './components/DataQualityEngine';

export default function App() {
  const [activeTab, setActiveTab] = useState<ModuleTab>('WORLD');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCountryCode, setSelectedCountryCode] = useState<string>('USA');
  const [selectedCorridorKey, setSelectedCorridorKey] = useState<string>('USA-MEX');

  const handleSelectCountry = (code: string) => {
    setSelectedCountryCode(code);
    setActiveTab('COUNTRIES');
  };

  const handleSelectCorridor = (corridor: string) => {
    setSelectedCorridorKey(corridor);
    setActiveTab('CORRIDORS');
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Institutional Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      {/* Main Analytical Content Workspace */}
      <main className="flex-1 overflow-y-auto">
        {activeTab === 'WORLD' && (
          <WorldOverview
            onSelectCountry={handleSelectCountry}
            onSelectCorridor={handleSelectCorridor}
          />
        )}
        {activeTab === 'MAP' && (
          <WorldMap
            onSelectCountry={handleSelectCountry}
            onSelectCorridor={handleSelectCorridor}
          />
        )}
        {activeTab === 'COUNTRIES' && (
          <CountryProfiles
            initialCountry={selectedCountryCode}
            onSelectCorridor={handleSelectCorridor}
          />
        )}
        {activeTab === 'CORRIDORS' && (
          <BilateralCorridors initialCorridor={selectedCorridorKey} />
        )}
        {activeTab === 'PRODUCTS' && <ProductsSectors />}
        {activeTab === 'COMMODITIES' && <CommodityEngine />}
        {activeTab === 'SUPPLY_CHAINS' && <SupplyChainEngine />}
        {activeTab === 'TARIFFS' && <TariffScenarioLab />}
        {activeTab === 'SHIPPING' && <ShippingLogistics />}
        {activeTab === 'NETWORK' && <NetworkGraph />}
        {activeTab === 'GRAVITY' && <GravityEconometrics />}
        {activeTab === 'FORECASTS' && <ForecastEngine />}
        {activeTab === 'UNIVERSAL_XY' && <UniversalXYEngine />}
        {activeTab === 'SCREENER' && <ScreenerAnomaly />}
        {activeTab === 'RESEARCH' && <ResearchWorkspace />}
        {activeTab === 'DATA_QUALITY' && <DataQualityEngine />}
      </main>

      {/* Institutional Footer */}
      <footer className="bg-white border-t border-slate-200 px-6 py-2.5 text-[11px] font-mono text-slate-500 flex flex-wrap justify-between items-center gap-2">
        <div>
          <span>RHINOQUANT GLOBAL TRADE ENGINE v3.7 • PROPRIETARY INSTITUTIONAL TERMINAL</span>
        </div>
        <div className="flex gap-4 text-[10px]">
          <span>UN COMTRADE / IMF / WTO / SEABORNE BENCHMARKS</span>
          <span>DATA QUALITY SCORE: <strong className="text-emerald-600">98.2%</strong></span>
        </div>
      </footer>
    </div>
  );
}
