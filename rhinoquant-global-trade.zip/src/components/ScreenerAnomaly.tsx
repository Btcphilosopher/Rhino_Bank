import React, { useState } from 'react';
import { RHINO_COUNTRIES } from '../data/tradeData';
import { Compass, AlertTriangle, CheckCircle2, Search, Sliders, Shield } from 'lucide-react';

export const ScreenerAnomaly: React.FC = () => {
  const [minOpenness, setMinOpenness] = useState<number>(30);
  const [maxHHI, setMaxHHI] = useState<number>(0.35);
  const [activeTab, setActiveTab] = useState<'SCREENER' | 'ANOMALIES'>('SCREENER');

  const filteredCountries = RHINO_COUNTRIES.filter(c => {
    return c.tradeOpenness >= minOpenness && c.exportHHI <= maxHHI;
  });

  const anomalies = [
    { country: 'TWN', type: 'High Product Concentration Spikes', severity: 'HIGH', detail: 'Advanced Semiconductor export share exceeded 78% of total electronics.' },
    { country: 'CHN', type: 'Rare Earth Seaborne Volume Shift', severity: 'MODERATE', detail: 'Export unit value for heavy rare earth oxides surged +14.2% YoY.' },
    { country: 'SAU', type: 'Oil Export Value Volatility', severity: 'MODERATE', detail: 'Energy trade balance ratio shifted -6.2% on Crude price pullback.' },
  ];

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div>
          <h2 className="text-base font-bold font-mono text-slate-900 flex items-center gap-2">
            <Compass className="w-5 h-5 text-emerald-600" /> UNIVERSAL TRADE SCREENER & ANOMALY ENGINE
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Execute complex boolean filter predicates across global trade metrics and detect statistical export/import anomalies.
          </p>
        </div>

        {/* Tab Toggle */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={() => setActiveTab('SCREENER')}
            className={`px-3 py-1.5 rounded font-bold transition-all cursor-pointer ${
              activeTab === 'SCREENER' ? 'bg-emerald-700 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            UNIVERSAL SCREENER
          </button>
          <button
            onClick={() => setActiveTab('ANOMALIES')}
            className={`px-3 py-1.5 rounded font-bold transition-all cursor-pointer ${
              activeTab === 'ANOMALIES' ? 'bg-rose-600 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            ANOMALY DETECTOR
          </button>
        </div>
      </div>

      {activeTab === 'SCREENER' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
          {/* Controls */}
          <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider border-b border-slate-100 pb-2">
              BOOLEAN FILTER PREDICATES
            </h3>

            <div className="space-y-4 text-xs">
              <div>
                <div className="flex justify-between text-slate-700 font-bold mb-1">
                  <span>MIN TRADE OPENNESS (% GDP):</span>
                  <span className="text-emerald-700 font-bold">≥ {minOpenness}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="150"
                  value={minOpenness}
                  onChange={(e) => setMinOpenness(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-700 font-bold mb-1">
                  <span>MAX EXPORT HHI CONCENTRATION:</span>
                  <span className="text-cyan-700 font-bold">≤ {maxHHI}</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.70"
                  step="0.01"
                  value={maxHHI}
                  onChange={(e) => setMaxHHI(Number(e.target.value))}
                  className="w-full accent-cyan-600 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Screener Results Table */}
          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-lg p-5 shadow-sm">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider border-b border-slate-100 pb-2 mb-3">
              MATCHED NATIONS ({filteredCountries.length} RESULTS)
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] border-b border-slate-200 font-bold">
                  <tr>
                    <th className="p-2.5">Country</th>
                    <th className="p-2.5">Region</th>
                    <th className="p-2.5">Openness (% GDP)</th>
                    <th className="p-2.5">Export HHI</th>
                    <th className="p-2.5">Trade Balance ($B)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredCountries.map((c) => (
                    <tr key={c.code} className="hover:bg-slate-50">
                      <td className="p-2.5 text-slate-900 font-bold flex items-center gap-1.5">
                        <span>{c.flag}</span>
                        <span>{c.name} ({c.code})</span>
                      </td>
                      <td className="p-2.5 text-slate-500">{c.region}</td>
                      <td className="p-2.5 text-amber-600 font-bold">{c.tradeOpenness}%</td>
                      <td className="p-2.5 text-cyan-700 font-bold">{c.exportHHI}</td>
                      <td className={`p-2.5 font-bold ${c.tradeBalance >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                        ${c.tradeBalance}B
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        /* Anomaly Detector View */
        <div className="bg-white border border-slate-200 rounded-lg p-5 font-mono shadow-sm space-y-3">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider border-b border-slate-100 pb-2">
            DETECTED STATISTICAL TRADE FLOW ANOMALIES
          </h3>

          <div className="space-y-2 text-xs">
            {anomalies.map((anom, idx) => (
              <div key={idx} className="p-3 rounded bg-slate-50 border border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-slate-900 font-bold block">{anom.country}: {anom.type}</span>
                  <p className="text-[11px] text-slate-500 mt-0.5">{anom.detail}</p>
                </div>
                <span className="bg-rose-50 text-rose-700 border border-rose-200 px-2.5 py-1 rounded text-[10px] font-bold">
                  {anom.severity} SEVERITY
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
