import React, { useState } from 'react';
import { RHINO_NETWORK_NODES, RHINO_NETWORK_EDGES } from '../data/tradeData';
import { Activity, Share2, ShieldAlert, Cpu, Award, Zap, RefreshCw } from 'lucide-react';

export const NetworkGraph: React.FC = () => {
  const [removedNode, setRemovedNode] = useState<string | null>(null);
  const [selectedNodeId, setSelectedNodeId] = useState<string>('CHN');

  const activeNodes = RHINO_NETWORK_NODES.filter(n => n.id !== removedNode);
  const activeEdges = RHINO_NETWORK_EDGES.filter(e => e.source !== removedNode && e.target !== removedNode);

  const selectedNode = RHINO_NETWORK_NODES.find(n => n.id === selectedNodeId) || RHINO_NETWORK_NODES[0];

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div>
          <h2 className="text-base font-bold font-mono text-slate-900 flex items-center gap-2">
            <Activity className="w-5 h-5 text-emerald-600" /> GLOBAL TRADE NETWORK CENTRALITY & STRESS TEST ENGINE
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Graph-theoretic quantitative decomposition of global commerce: Eigenvector, Betweenness, Degree centrality, and systemic node removal shock simulator.
          </p>
        </div>

        {removedNode && (
          <button
            onClick={() => setRemovedNode(null)}
            className="flex items-center gap-2 bg-emerald-50 text-emerald-800 border border-emerald-300 px-3 py-1.5 rounded font-mono text-xs hover:bg-emerald-100 font-bold transition-all cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" /> RESTORE REMOVED NODE ({removedNode})
          </button>
        )}
      </div>

      {/* Network Overview Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">NETWORK NODES COUNT</span>
          <span className="text-xl font-bold text-slate-900 mt-1 block">{activeNodes.length} Hubs</span>
          <span className="text-[11px] text-slate-500 mt-1 block">Active Trade Nations</span>
        </div>

        <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">NETWORK DENSITY</span>
          <span className="text-xl font-bold text-slate-900 mt-1 block">0.785</span>
          <span className="text-[11px] text-slate-500 mt-1 block">Highly Interconnected</span>
        </div>

        <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">SYSTEMIC CENTRAL NODE</span>
          <span className="text-xl font-bold text-emerald-700 mt-1 block">China (CHN)</span>
          <span className="text-[11px] text-slate-500 mt-1 block">Eigenvector: 1.00</span>
        </div>

        <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">AVG CLUSTERING COEFFICIENT</span>
          <span className="text-xl font-bold text-slate-900 mt-1 block">0.642</span>
          <span className="text-[11px] text-slate-500 mt-1 block">Regional Trading Blocs</span>
        </div>
      </div>

      {/* Main Interactive Graph Visualizer & Node Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
        {/* Network Canvas Schematic */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-lg p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between mb-3 border-b border-slate-100 pb-2">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              GRAPH TOPOLOGY VISUALIZER
            </h3>
            <span className="text-[10px] text-slate-500">Node size = Eigenvector Centrality</span>
          </div>

          <svg viewBox="0 0 600 350" className="w-full h-auto bg-slate-50 rounded border border-slate-200">
            {/* Edges */}
            {activeEdges.map((edge, idx) => {
              const sourceNode = activeNodes.find(n => n.id === edge.source);
              const targetNode = activeNodes.find(n => n.id === edge.target);
              if (!sourceNode || !targetNode) return null;

              // Compute simple circular layout for nodes
              const sourceIdx = activeNodes.indexOf(sourceNode);
              const targetIdx = activeNodes.indexOf(targetNode);
              const total = activeNodes.length;

              const x1 = 300 + 220 * Math.cos((2 * Math.PI * sourceIdx) / total);
              const y1 = 175 + 130 * Math.sin((2 * Math.PI * sourceIdx) / total);
              const x2 = 300 + 220 * Math.cos((2 * Math.PI * targetIdx) / total);
              const y2 = 175 + 130 * Math.sin((2 * Math.PI * targetIdx) / total);

              return (
                <line
                  key={idx}
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke="#cbd5e1"
                  strokeWidth={edge.weight * 2}
                  strokeOpacity="0.8"
                />
              );
            })}

            {/* Nodes */}
            {activeNodes.map((node, idx) => {
              const total = activeNodes.length;
              const cx = 300 + 220 * Math.cos((2 * Math.PI * idx) / total);
              const cy = 175 + 130 * Math.sin((2 * Math.PI * idx) / total);
              const r = Math.max(8, node.eigenvectorCentrality * 20);
              const isSelected = selectedNodeId === node.id;

              return (
                <g
                  key={node.id}
                  transform={`translate(${cx}, ${cy})`}
                  className="cursor-pointer group"
                  onClick={() => setSelectedNodeId(node.id)}
                >
                  <circle
                    r={r + 3}
                    fill="none"
                    stroke={isSelected ? '#059669' : '#94a3b8'}
                    strokeWidth="1.5"
                    className="opacity-50 group-hover:opacity-100"
                  />
                  <circle
                    r={r}
                    fill={isSelected ? '#059669' : '#ffffff'}
                    stroke={isSelected ? '#047857' : '#64748b'}
                    strokeWidth="2"
                  />
                  <text
                    y={r + 12}
                    textAnchor="middle"
                    fill={isSelected ? '#047857' : '#334155'}
                    fontSize="10"
                    fontFamily="monospace"
                    fontWeight="bold"
                  >
                    {node.id}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Selected Node Details & Centrality Table */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm space-y-4 font-mono">
          <div className="border-b border-slate-100 pb-2 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-emerald-700 font-bold uppercase block">NODE CENTRALITY METRICS</span>
              <h3 className="text-lg font-bold text-slate-900">{selectedNode.name} ({selectedNode.id})</h3>
            </div>
            <button
              onClick={() => setRemovedNode(selectedNode.id)}
              className="bg-rose-50 text-rose-700 border border-rose-200 px-2.5 py-1 rounded text-xs font-bold hover:bg-rose-100 transition-all cursor-pointer"
            >
              SIMULATE SHOCK REMOVAL
            </button>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500 font-medium">EIGENVECTOR CENTRALITY:</span>
              <span className="text-slate-900 font-bold">{selectedNode.eigenvectorCentrality}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500 font-medium">BETWEENNESS CENTRALITY:</span>
              <span className="text-slate-900 font-bold">{selectedNode.betweennessCentrality}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500 font-medium">DEGREE CENTRALITY:</span>
              <span className="text-slate-900 font-bold">{selectedNode.degreeCentrality}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500 font-medium">CLUSTERING COEFFICIENT:</span>
              <span className="text-slate-900 font-bold">{selectedNode.clusteringCoefficient}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
