import React, { useState } from 'react';
import { RHINO_PRODUCTS } from '../data/tradeData';
import { Boxes, Layers, ChevronRight, TrendingUp, AlertTriangle, ArrowUpRight } from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from 'recharts';

export const ProductsSectors: React.FC = () => {
  const [selectedHsCode, setSelectedHsCode] = useState<string>('HS-85');

  const activeProduct = RHINO_PRODUCTS.find(p => p.hsCode === selectedHsCode) || RHINO_PRODUCTS[0];

  const exporterChartData = activeProduct.topExporters.map(e => ({
    country: e.countryCode,
    share: Number((e.share * 100).toFixed(1)),
  }));

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div>
          <h2 className="text-base font-bold font-mono text-slate-900 flex items-center gap-2">
            <Boxes className="w-5 h-5 text-emerald-600" /> HARMONIZED SYSTEM (HS) PRODUCT DRILLDOWN ENGINE
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Granular product hierarchy taxonomy (HS Section → Chapter → Heading), exporter market shares, unit values, and strategic dependency indices.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-500 font-bold">SELECT PRODUCT:</span>
          <select
            value={selectedHsCode}
            onChange={(e) => setSelectedHsCode(e.target.value)}
            className="bg-slate-50 border border-slate-200 text-slate-900 font-bold px-3 py-1.5 rounded focus:outline-none"
          >
            {RHINO_PRODUCTS.map(p => (
              <option key={p.hsCode} value={p.hsCode}>
                {p.hsCode}: {p.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* HS Hierarchy Breadcrumb & Details */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 font-mono shadow-sm space-y-4">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-slate-600 bg-slate-50 border border-slate-200 px-3 py-2 rounded">
          <span className="text-slate-500 font-bold uppercase">SECTION:</span>
          <span className="text-slate-900 font-bold">{activeProduct.section}</span>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-slate-500 font-bold uppercase">CHAPTER {activeProduct.chapter}:</span>
          <span className="text-emerald-700 font-bold">{activeProduct.name}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
          <div className="bg-slate-50 border border-slate-100 p-3.5 rounded">
            <span className="text-slate-500 text-[10px] uppercase font-bold block">GLOBAL TRADE VALUE</span>
            <span className="text-xl font-bold text-slate-900 mt-1 block">
              ${activeProduct.globalTradeValue.toLocaleString()} B
            </span>
            <span className="text-[11px] text-emerald-600 font-bold mt-1 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" /> +{activeProduct.growthYoY}% YoY
            </span>
          </div>

          <div className="bg-slate-50 border border-slate-100 p-3.5 rounded">
            <span className="text-slate-500 text-[10px] uppercase font-bold block">UNIT VALUE ($ / KG)</span>
            <span className="text-xl font-bold text-slate-900 mt-1 block">
              ${activeProduct.unitValueUSDPerKg} / kg
            </span>
            <span className="text-[11px] text-slate-500 mt-1 block">High Value Density</span>
          </div>

          <div className="bg-slate-50 border border-slate-100 p-3.5 rounded">
            <span className="text-slate-500 text-[10px] uppercase font-bold block">PRODUCT CONCENTRATION (HHI)</span>
            <span className="text-xl font-bold text-indigo-600 mt-1 block">
              {activeProduct.hhiConcentration}
            </span>
            <span className="text-[11px] text-slate-500 mt-1 block">
              {activeProduct.hhiConcentration > 0.25 ? 'High Market Concentration' : 'Moderate Competition'}
            </span>
          </div>

          <div className="bg-slate-50 border border-slate-100 p-3.5 rounded">
            <span className="text-slate-500 text-[10px] uppercase font-bold block">STRATEGIC CRITICALITY</span>
            <span className="text-xl font-bold text-rose-600 mt-1 block">
              {activeProduct.criticalCategory || 'Industrial'}
            </span>
            <span className="text-[11px] text-amber-600 font-semibold mt-1 block">Critical Supply Chain Good</span>
          </div>
        </div>
      </div>

      {/* Exporter Market Share Breakdown Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono">
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm">
          <div className="border-b border-slate-100 pb-2 mb-4">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              DOMINANT EXPORTERS MARKET SHARE (%) — {activeProduct.hsCode}
            </h3>
            <p className="text-xs text-slate-500">Percentage of total global export volume</p>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={exporterChartData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                <XAxis dataKey="country" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} domain={[0, 40]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '6px', fontSize: '12px', fontFamily: 'monospace', color: '#0f172a', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
                  formatter={(val: any) => [`${val}%`, 'Global Share']}
                />
                <Bar dataKey="share" radius={[4, 4, 0, 0]}>
                  {exporterChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === 0 ? '#10b981' : '#0284c7'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Product Catalog Grid */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm space-y-3">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider border-b border-slate-100 pb-2">
            ALL MONITORED HS SECTOR HEADINGS
          </h3>

          <div className="space-y-2 text-xs">
            {RHINO_PRODUCTS.map((prod) => (
              <div
                key={prod.hsCode}
                onClick={() => setSelectedHsCode(prod.hsCode)}
                className={`p-2.5 rounded border transition-all cursor-pointer flex items-center justify-between ${
                  prod.hsCode === selectedHsCode
                    ? 'bg-emerald-50 border-emerald-500 font-bold text-slate-900'
                    : 'bg-slate-50 border-slate-100 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div>
                  <span className="block font-bold">{prod.hsCode}: {prod.name}</span>
                  <span className="text-[10px] text-slate-500 font-normal">{prod.section}</span>
                </div>
                <div className="text-right">
                  <span className="block font-bold">${prod.globalTradeValue}B</span>
                  <span className="text-[10px] text-emerald-600 font-semibold">+{prod.growthYoY}% YoY</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
