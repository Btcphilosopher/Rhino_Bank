import React, { useState } from 'react';
import { RHINO_CORRIDORS, RHINO_COUNTRIES } from '../data/tradeData';
import { TrendingUp, ArrowRightLeft, Shield, MapPin, Search, Filter } from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from 'recharts';

interface BilateralCorridorsProps {
  initialCorridor?: string;
}

export const BilateralCorridors: React.FC<BilateralCorridorsProps> = ({ initialCorridor }) => {
  const [selectedCorridorIndex, setSelectedCorridorIndex] = useState<number>(0);
  const [filterRegion, setFilterRegion] = useState<string>('ALL');

  const activeCorridor = RHINO_CORRIDORS[selectedCorridorIndex] || RHINO_CORRIDORS[0];
  const ctryA = RHINO_COUNTRIES.find(c => c.code === activeCorridor.countryA);
  const ctryB = RHINO_COUNTRIES.find(c => c.code === activeCorridor.countryB);

  const corridorChartData = [
    { name: `Export ${activeCorridor.countryA} → ${activeCorridor.countryB}`, value: activeCorridor.exportAtoB },
    { name: `Export ${activeCorridor.countryB} → ${activeCorridor.countryA}`, value: activeCorridor.exportBtoA },
  ];

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div>
          <h2 className="text-base font-bold font-mono text-slate-900 flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5 text-indigo-600" /> TRADE CORRIDOR & REORIENTATION ENGINE
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Quantitative bilateral trade route analytics, flow imbalances, trade agreement exposure, and structural reorientation vectors.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-500 font-bold">SELECT ROUTE:</span>
          <select
            value={selectedCorridorIndex}
            onChange={(e) => setSelectedCorridorIndex(Number(e.target.value))}
            className="bg-slate-50 border border-slate-200 text-slate-900 font-bold px-3 py-1.5 rounded focus:outline-none"
          >
            {RHINO_CORRIDORS.map((c, i) => (
              <option key={i} value={i}>
                {c.countryA} ↔ {c.countryB} (${c.totalTrade}B)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Selected Corridor Overview Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
        {/* Active Corridor Card */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-3">
              <span className="text-3xl">{ctryA?.flag}</span>
              <span className="text-slate-400 font-bold">↔</span>
              <span className="text-3xl">{ctryB?.flag}</span>
            </div>
            <span className="text-xs bg-indigo-50 text-indigo-700 border border-indigo-200 px-2.5 py-1 rounded font-bold">
              {activeCorridor.tradeAgreement}
            </span>
          </div>

          <h3 className="text-xl font-bold text-slate-900">
            {ctryA?.name} ↔ {ctryB?.name}
          </h3>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">TOTAL BILATERAL TRADE:</span>
              <span className="text-slate-900 font-bold">${activeCorridor.totalTrade} Billion</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">EXPORT {activeCorridor.countryA} → {activeCorridor.countryB}:</span>
              <span className="text-emerald-700 font-bold">${activeCorridor.exportAtoB} Billion</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">EXPORT {activeCorridor.countryB} → {activeCorridor.countryA}:</span>
              <span className="text-slate-900 font-bold">${activeCorridor.exportBtoA} Billion</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">NET TRADE IMBALANCE:</span>
              <span className="text-rose-600 font-bold">${activeCorridor.balanceAtoB} Billion</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">CORRIDOR DISTANCE:</span>
              <span className="text-slate-800">{activeCorridor.distanceKm} km</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">CORRIDOR HHI CONCENTRATION:</span>
              <span className="text-amber-600 font-semibold">{activeCorridor.hhi}</span>
            </div>
          </div>

          <div>
            <span className="text-slate-500 text-[10px] uppercase font-bold block mb-1">DOMINANT PRODUCTS:</span>
            <div className="flex flex-wrap gap-1">
              {activeCorridor.topProducts.map((p, idx) => (
                <span key={idx} className="bg-slate-50 border border-slate-200 text-slate-700 text-[10px] px-2 py-0.5 rounded font-medium">
                  {p}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Trade Balance Decomposition Chart */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-lg p-5 shadow-sm">
          <div className="border-b border-slate-100 pb-2 mb-4">
            <h3 className="text-xs font-bold font-mono text-slate-700 uppercase tracking-wider">
              BILATERAL FLOW SYMMETRY (${activeCorridor.countryA} vs ${activeCorridor.countryB})
            </h3>
            <p className="text-xs text-slate-500 font-mono">Export value comparison in USD Billions</p>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={corridorChartData} layout="vertical" margin={{ top: 10, right: 30, left: 20, bottom: 5 }}>
                <XAxis type="number" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis type="category" dataKey="name" stroke="#475569" fontSize={11} tickLine={false} width={180} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '6px', fontSize: '12px', fontFamily: 'monospace', color: '#0f172a', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
                  formatter={(val: any) => [`$${val} Billion`, 'Trade Flow']}
                />
                <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                  <Cell fill="#10b981" />
                  <Cell fill="#0284c7" />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Global Corridor Ranking Table */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm font-mono">
        <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3 border-b border-slate-100 pb-2">
          GLOBAL TOP TRADE CORRIDORS RANKING
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] border-b border-slate-200">
              <tr>
                <th className="p-2">Rank</th>
                <th className="p-2">Corridor Route</th>
                <th className="p-2">Total Trade ($B)</th>
                <th className="p-2">Exp A → B ($B)</th>
                <th className="p-2">Exp B → A ($B)</th>
                <th className="p-2">Imbalance ($B)</th>
                <th className="p-2">YoY Growth</th>
                <th className="p-2">Agreement</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {RHINO_CORRIDORS.map((c, i) => (
                <tr
                  key={i}
                  onClick={() => setSelectedCorridorIndex(i)}
                  className={`hover:bg-slate-50 cursor-pointer transition-all ${
                    i === selectedCorridorIndex ? 'bg-emerald-50/60 font-bold text-slate-900' : ''
                  }`}
                >
                  <td className="p-2 text-slate-400">#{i + 1}</td>
                  <td className="p-2 text-slate-900 font-bold">{c.countryA} ↔ {c.countryB}</td>
                  <td className="p-2 text-slate-900 font-bold">${c.totalTrade}</td>
                  <td className="p-2 text-emerald-700 font-medium">${c.exportAtoB}</td>
                  <td className="p-2 text-slate-900 font-medium">${c.exportBtoA}</td>
                  <td className="p-2 text-rose-600 font-medium">${c.balanceAtoB}</td>
                  <td className="p-2 text-emerald-600 font-semibold">+{c.growthYoY}%</td>
                  <td className="p-2 text-slate-500 text-[11px]">{c.tradeAgreement}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
