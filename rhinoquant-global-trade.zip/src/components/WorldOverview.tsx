import React from 'react';
import {
  RHINO_COUNTRIES,
  RHINO_PRODUCTS,
  RHINO_COMMODITIES,
  RHINO_CORRIDORS,
  RHINO_HISTORICAL_SERIES,
} from '../data/tradeData';
import {
  TrendingUp,
  TrendingDown,
  Globe,
  Activity,
  ShieldAlert,
  ArrowUpRight,
  Boxes,
  Zap,
  BarChart3,
  Layers,
  Sparkles,
  PieChart as PieChartIcon,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
  Cell,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
} from 'recharts';

interface WorldOverviewProps {
  onSelectCountry?: (code: string) => void;
  onSelectCorridor?: (corridor: string) => void;
}

export const WorldOverview: React.FC<WorldOverviewProps> = ({
  onSelectCountry,
  onSelectCorridor,
}) => {
  // Calculated Top Exporters & Importers
  const topExporters = [...RHINO_COUNTRIES].sort((a, b) => b.exports - a.exports).slice(0, 6);
  const topImporters = [...RHINO_COUNTRIES].sort((a, b) => b.imports - a.imports).slice(0, 6);
  const largestSurpluses = [...RHINO_COUNTRIES].sort((a, b) => b.tradeBalance - a.tradeBalance).slice(0, 5);
  const largestDeficits = [...RHINO_COUNTRIES].sort((a, b) => a.tradeBalance - b.tradeBalance).slice(0, 5);

  const stressRadarData = [
    { metric: 'Shipping Freight', value: 58 },
    { metric: 'Tariff Volatility', value: 65 },
    { metric: 'Supplier HHI', value: 72 },
    { metric: 'FX Volatility', value: 44 },
    { metric: 'Geopolitical Risk', value: 68 },
    { metric: 'Commodity Inflation', value: 50 },
  ];

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Hero Executive Status Banner */}
      <div className="bg-[#0F172A] border border-slate-800 rounded-lg p-5 shadow-sm text-white relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 font-bold uppercase tracking-wider mb-1">
              <Globe className="w-4 h-4" /> RHINOQUANT GLOBAL TRADE SYSTEM • INSTITUTIONAL MACRO MONITOR
            </div>
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-white font-mono">
              Global Commerce & Trade Matrix
            </h1>
            <p className="text-slate-300 text-xs md:text-sm mt-1 max-w-3xl">
              Real-time quantitative decomposition of global merchandise trade flows, commodity linkages, supply chain concentration, and econometric shock propagation.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="bg-slate-900 border border-slate-700 px-3 py-2 rounded font-mono text-xs">
              <div className="text-slate-400 text-[10px] uppercase font-bold">REGIME CLASSIFICATION</div>
              <div className="text-emerald-400 font-bold flex items-center gap-1.5 mt-0.5">
                <Sparkles className="w-3.5 h-3.5" /> ACCELERATION & REORIENTATION
              </div>
            </div>
            <div className="bg-slate-900 border border-slate-700 px-3 py-2 rounded font-mono text-xs">
              <div className="text-slate-400 text-[10px] uppercase font-bold">TRADE FRICTION INDEX</div>
              <div className="text-amber-400 font-bold mt-0.5">12.8% (STABLE)</div>
            </div>
          </div>
        </div>
      </div>

      {/* 14 Key Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3 font-mono text-xs">
        <div className="bg-white border border-slate-200 p-3.5 rounded shadow-sm">
          <span className="text-slate-500 text-[10px] uppercase font-bold block">GLOBAL TRADE VAL</span>
          <span className="text-lg font-bold text-slate-900 mt-1 block">$32.40 T</span>
          <span className="text-[11px] text-emerald-600 font-bold flex items-center gap-0.5 mt-1">
            <TrendingUp className="w-3 h-3" /> +4.5% YoY
          </span>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded shadow-sm">
          <span className="text-slate-500 text-[10px] uppercase font-bold block">GLOBAL EXPORTS</span>
          <span className="text-lg font-bold text-slate-900 mt-1 block">$16.25 T</span>
          <span className="text-[11px] text-slate-500 mt-1 block">Volume: 14.8B Tons</span>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded shadow-sm">
          <span className="text-slate-500 text-[10px] uppercase font-bold block">GLOBAL IMPORTS</span>
          <span className="text-lg font-bold text-slate-900 mt-1 block">$16.15 T</span>
          <span className="text-[11px] text-slate-500 mt-1 block">CIF/FOB Margin: 0.6%</span>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded shadow-sm">
          <span className="text-slate-500 text-[10px] uppercase font-bold block">TRADE OPENNESS</span>
          <span className="text-lg font-bold text-emerald-600 mt-1 block">58.4 %</span>
          <span className="text-[11px] text-slate-500 mt-1 block">Trade / World GDP</span>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded shadow-sm">
          <span className="text-slate-500 text-[10px] uppercase font-bold block">SUPPLY STRESS INDEX</span>
          <span className="text-lg font-bold text-rose-600 mt-1 block">54.2</span>
          <span className="text-[11px] text-amber-600 mt-1 font-semibold">High Concentration</span>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded shadow-sm">
          <span className="text-slate-500 text-[10px] uppercase font-bold block">AVG TARIFF RATE</span>
          <span className="text-lg font-bold text-slate-800 mt-1 block">4.85 %</span>
          <span className="text-[11px] text-rose-600 mt-1 block">+0.4% Policy Bump</span>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded shadow-sm">
          <span className="text-slate-500 text-[10px] uppercase font-bold block">REER VOLATILITY</span>
          <span className="text-lg font-bold text-indigo-600 mt-1 block">7.2 %</span>
          <span className="text-[11px] text-slate-500 mt-1 block">FX Pass-Through</span>
        </div>
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Global Trade Trend 2018-2026 */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-lg p-5 shadow-sm">
          <div className="flex items-center justify-between mb-3 border-b border-slate-100 pb-2">
            <div>
              <h2 className="text-xs font-bold font-mono text-slate-700 uppercase tracking-wider flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-emerald-600" /> GLOBAL MERCHANDISE TRADE VOLUME ($ TRILLIONS)
              </h2>
              <p className="text-xs text-slate-500 font-mono">Historical volume trajectory & projected trend (2018 - 2026)</p>
            </div>
            <span className="text-xs font-mono text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded font-bold">
              +4.3% CAGR
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={RHINO_HISTORICAL_SERIES} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="tradeGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="year" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} domain={[15, 40]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '6px', fontSize: '12px', fontFamily: 'monospace', color: '#0f172a', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
                  formatter={(val: any) => [`$${val} Trillion`, 'Global Trade']}
                />
                <Area type="monotone" dataKey="globalTrade" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#tradeGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Trade Stress Index Radar */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm">
          <div className="border-b border-slate-100 pb-2 mb-3">
            <h2 className="text-xs font-bold font-mono text-slate-700 uppercase tracking-wider flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-600" /> SYSTEMIC TRADE STRESS RADAR
            </h2>
            <p className="text-xs text-slate-500 font-mono">Multivariate trade friction decomposition (0-100 scale)</p>
          </div>

          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={stressRadarData}>
                <PolarGrid stroke="#cbd5e1" />
                <PolarAngleAxis dataKey="metric" stroke="#475569" fontSize={10} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#94a3b8" fontSize={9} />
                <Radar name="Stress Score" dataKey="value" stroke="#ef4444" fill="#ef4444" fillOpacity={0.25} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Exporters / Importers / Corridors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 font-mono">
        {/* Top Exporters */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-sm">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3 flex items-center gap-1.5 border-b border-slate-100 pb-2">
            <ArrowUpRight className="w-4 h-4 text-emerald-600" /> LARGEST GLOBAL EXPORTERS
          </h3>
          <div className="space-y-2 text-xs">
            {topExporters.map((ctry, idx) => (
              <div
                key={ctry.code}
                onClick={() => onSelectCountry && onSelectCountry(ctry.code)}
                className="flex items-center justify-between p-2.5 rounded bg-slate-50 hover:bg-slate-100 transition-all cursor-pointer border border-slate-100"
              >
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 w-4 font-bold">#{idx + 1}</span>
                  <span className="text-lg">{ctry.flag}</span>
                  <div>
                    <span className="text-slate-900 font-bold block">{ctry.name}</span>
                    <span className="text-[10px] text-slate-500">Share: {((ctry.exports / 16250) * 100).toFixed(1)}% of World</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-emerald-700 font-bold block">${ctry.exports.toLocaleString()} B</span>
                  <span className="text-[10px] text-slate-500">Bal: +${ctry.tradeBalance.toLocaleString()}B</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Importers */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-sm">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3 flex items-center gap-1.5 border-b border-slate-100 pb-2">
            <Boxes className="w-4 h-4 text-cyan-600" /> LARGEST GLOBAL IMPORTERS
          </h3>
          <div className="space-y-2 text-xs">
            {topImporters.map((ctry, idx) => (
              <div
                key={ctry.code}
                onClick={() => onSelectCountry && onSelectCountry(ctry.code)}
                className="flex items-center justify-between p-2.5 rounded bg-slate-50 hover:bg-slate-100 transition-all cursor-pointer border border-slate-100"
              >
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 w-4 font-bold">#{idx + 1}</span>
                  <span className="text-lg">{ctry.flag}</span>
                  <div>
                    <span className="text-slate-900 font-bold block">{ctry.name}</span>
                    <span className="text-[10px] text-slate-500">Openness: {ctry.tradeOpenness}%</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-slate-900 font-bold block">${ctry.imports.toLocaleString()} B</span>
                  <span className={`text-[10px] font-medium ${ctry.tradeBalance >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                    Bal: ${ctry.tradeBalance.toLocaleString()}B
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Key Corridors & Reorientation */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-sm">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3 flex items-center gap-1.5 border-b border-slate-100 pb-2">
            <Zap className="w-4 h-4 text-indigo-600" /> FASTEST-GROWING TRADE CORRIDORS
          </h3>
          <div className="space-y-2 text-xs">
            {RHINO_CORRIDORS.map((corridor, idx) => (
              <div
                key={idx}
                onClick={() => onSelectCorridor && onSelectCorridor(`${corridor.countryA}-${corridor.countryB}`)}
                className="flex items-center justify-between p-2.5 rounded bg-slate-50 hover:bg-slate-100 transition-all cursor-pointer border border-slate-100"
              >
                <div>
                  <span className="text-slate-900 font-bold block">
                    {corridor.countryA} ↔ {corridor.countryB}
                  </span>
                  <span className="text-[10px] text-slate-500">{corridor.tradeAgreement} • {corridor.distanceKm} km</span>
                </div>
                <div className="text-right">
                  <span className="text-slate-900 font-bold block">${corridor.totalTrade} B</span>
                  <span className="text-[10px] text-emerald-600 font-semibold">+{corridor.growthYoY}% YoY</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
