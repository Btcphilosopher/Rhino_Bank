import React, { useState } from 'react';
import { RHINO_SUPPLY_CHAIN_NODES } from '../data/tradeData';
import { Share2, AlertTriangle, ShieldAlert, Cpu, Layers, ChevronRight, CheckCircle2 } from 'lucide-react';

export const SupplyChainEngine: React.FC = () => {
  const [selectedNodeId, setSelectedNodeId] = useState<string>('sc-4');

  const activeNode = RHINO_SUPPLY_CHAIN_NODES.find(n => n.id === selectedNodeId) || RHINO_SUPPLY_CHAIN_NODES[0];

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div>
          <h2 className="text-base font-bold font-mono text-slate-900 flex items-center gap-2">
            <Share2 className="w-5 h-5 text-emerald-600" /> MULTI-TIER SUPPLY CHAIN & CRITICAL GOODS ENGINE
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Supply chain bottleneck mapping from upstream raw material mining through wafer substrate refining, component assembly, and final systems integration.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-500 font-bold">SELECT STAGE:</span>
          <select
            value={selectedNodeId}
            onChange={(e) => setSelectedNodeId(e.target.value)}
            className="bg-slate-50 border border-slate-200 text-slate-900 font-bold px-3 py-1.5 rounded focus:outline-none"
          >
            {RHINO_SUPPLY_CHAIN_NODES.map(n => (
              <option key={n.id} value={n.id}>
                [{n.stage}] {n.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Multi-tier Pipeline Hierarchy Visualizer */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 font-mono shadow-sm space-y-4">
        <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider border-b border-slate-100 pb-2">
          GLOBAL ADVANCED TECH SUPPLY CHAIN VALUE CHAIN PIPELINE
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
          {RHINO_SUPPLY_CHAIN_NODES.map((node, i) => {
            const isSelected = node.id === selectedNodeId;
            return (
              <div
                key={node.id}
                onClick={() => setSelectedNodeId(node.id)}
                className={`p-3 rounded border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-emerald-50 border-emerald-500 text-slate-900 shadow-sm font-bold'
                    : 'bg-slate-50 border-slate-100 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div>
                  <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1">STAGE {i + 1}</span>
                  <span className="text-xs font-bold block leading-tight">{node.stage}</span>
                  <p className="text-[10px] text-slate-500 mt-1 font-normal line-clamp-2">{node.name}</p>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-200 flex items-center justify-between">
                  <span className="text-[10px] text-slate-500 font-normal">Hub: {node.dominantCountry}</span>
                  <span className={`text-[10px] font-bold ${node.vulnerabilityIndex > 80 ? 'text-rose-600' : 'text-amber-600'}`}>
                    HHI {node.supplierHHI}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Supply Stage Detail Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-lg p-5 shadow-sm space-y-4">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <div>
              <span className="text-xs text-emerald-700 font-bold uppercase block">{activeNode.stage} STAGE DETAIL</span>
              <h3 className="text-lg font-bold text-slate-900">{activeNode.name}</h3>
            </div>
            <div className="bg-rose-50 text-rose-700 border border-rose-200 px-3 py-1 rounded text-xs font-bold">
              VULNERABILITY INDEX: {activeNode.vulnerabilityIndex} / 100
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="bg-slate-50 p-3.5 rounded border border-slate-100">
              <span className="text-slate-500 uppercase text-[10px] font-bold block">DOMINANT PRODUCTION HUB</span>
              <span className="text-lg font-bold text-slate-900 mt-1 block">{activeNode.dominantCountry}</span>
              <span className="text-[10px] text-slate-500 mt-1 block">Geographic Concentration</span>
            </div>

            <div className="bg-slate-50 p-3.5 rounded border border-slate-100">
              <span className="text-slate-500 uppercase text-[10px] font-bold block">SUPPLIER HHI CONCENTRATION</span>
              <span className="text-lg font-bold text-amber-600 mt-1 block">{activeNode.supplierHHI}</span>
              <span className="text-[10px] text-slate-500 mt-1 block">High Bottleneck Risk</span>
            </div>

            <div className="bg-slate-50 p-3.5 rounded border border-slate-100">
              <span className="text-slate-500 uppercase text-[10px] font-bold block">CRITICAL GOODS SHARE</span>
              <span className="text-lg font-bold text-rose-600 mt-1 block">{activeNode.criticalGoodsShare}%</span>
              <span className="text-[10px] text-slate-500 mt-1 block">Systemic Exposure</span>
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded border border-slate-200 space-y-2 text-xs">
            <span className="text-slate-500 text-[10px] uppercase font-bold block">ALTERNATIVE / SECONDARY SUPPLIERS:</span>
            <div className="flex flex-wrap gap-2">
              {activeNode.altSuppliers.map((alt, idx) => (
                <span key={idx} className="bg-white border border-slate-200 text-slate-800 px-2.5 py-1 rounded font-bold shadow-xs">
                  {alt}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Critical Goods Category Matrix */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm space-y-3 font-mono">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider border-b border-slate-100 pb-2">
            CRITICAL GOODS RISK TAXONOMY
          </h3>

          <div className="space-y-2 text-xs">
            {[
              { category: 'Semiconductors & Lithography', risk: 'Extreme (HHI 0.65)', color: 'text-rose-600 font-bold' },
              { category: 'Rare Earth Oxides & Lithium', risk: 'Extreme (HHI 0.68)', color: 'text-rose-600 font-bold' },
              { category: 'Pharmaceutical Active Ingredients', risk: 'High (HHI 0.42)', color: 'text-amber-600 font-bold' },
              { category: 'Precision Industrial Robotics', risk: 'Moderate (HHI 0.35)', color: 'text-emerald-600 font-bold' },
              { category: 'LNG & Mineral Fuels', risk: 'Moderate (HHI 0.28)', color: 'text-emerald-600 font-bold' },
            ].map((item, idx) => (
              <div key={idx} className="p-2.5 rounded bg-slate-50 border border-slate-100 flex items-center justify-between">
                <span className="text-slate-800 font-semibold">{item.category}</span>
                <span className={`text-[11px] ${item.color}`}>{item.risk}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
