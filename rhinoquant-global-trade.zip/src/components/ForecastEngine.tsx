import React, { useState } from 'react';
import { Zap, TrendingUp, Calendar, AlertCircle } from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
} from 'recharts';

export const ForecastEngine: React.FC = () => {
  const [modelType, setModelType] = useState<'ARIMA' | 'VAR' | 'ETS'>('ARIMA');

  const forecastSeries = [
    { year: 2020, actual: 22.6, forecast: 22.6, upper95: 22.6, lower95: 22.6 },
    { year: 2021, actual: 28.5, forecast: 28.5, upper95: 28.5, lower95: 28.5 },
    { year: 2022, actual: 32.1, forecast: 32.1, upper95: 32.1, lower95: 32.1 },
    { year: 2023, actual: 31.0, forecast: 31.0, upper95: 31.0, lower95: 31.0 },
    { year: 2024, actual: 32.4, forecast: 32.4, upper95: 32.4, lower95: 32.4 },
    { year: 2025, forecast: 33.8, upper95: 35.2, lower95: 32.4 },
    { year: 2026, forecast: 35.2, upper95: 37.5, lower95: 33.0 },
    { year: 2027, forecast: 36.8, upper95: 39.8, lower95: 33.8 },
    { year: 2028, forecast: 38.5, upper95: 42.4, lower95: 34.6 },
  ];

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div>
          <h2 className="text-base font-bold font-mono text-slate-900 flex items-center gap-2">
            <Zap className="w-5 h-5 text-emerald-600" /> GLOBAL TRADE OUTLOOK & TIME SERIES FORECAST ENGINE
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Econometric time series projections with 80% and 95% fan chart confidence bands (2025 - 2028).
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-500 font-bold">MODEL SPEC:</span>
          <select
            value={modelType}
            onChange={(e: any) => setModelType(e.target.value)}
            className="bg-slate-50 border border-slate-200 text-slate-900 font-bold px-3 py-1.5 rounded focus:outline-none"
          >
            <option value="ARIMA">Auto-ARIMA (2,1,1) Structural</option>
            <option value="VAR">Vector Autoregression (VAR)</option>
            <option value="ETS">Exponential Smoothing (ETS)</option>
          </select>
        </div>
      </div>

      {/* Main Fan Chart */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 font-mono shadow-sm">
        <div className="border-b border-slate-100 pb-2 mb-4 flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
            GLOBAL MERCHANDISE TRADE FORECAST ($ TRILLIONS)
          </h3>
          <span className="text-xs text-emerald-700 font-bold">+4.1% Projected Annual Growth</span>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={forecastSeries} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="fanGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <XAxis dataKey="year" stroke="#64748b" fontSize={11} tickLine={false} />
              <YAxis stroke="#64748b" fontSize={11} tickLine={false} domain={[20, 45]} />
              <Tooltip
                contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '6px', fontSize: '12px', fontFamily: 'monospace', color: '#0f172a', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
              />
              <Area type="monotone" dataKey="upper95" stroke="#0284c7" strokeDasharray="3 3" fill="url(#fanGrad)" name="Upper 95% CI" />
              <Area type="monotone" dataKey="forecast" stroke="#059669" strokeWidth={2.5} fill="none" name="Point Forecast" />
              <Area type="monotone" dataKey="lower95" stroke="#0284c7" strokeDasharray="3 3" fill="none" name="Lower 95% CI" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
