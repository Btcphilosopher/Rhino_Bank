import React from 'react';
import { auditDataQuality } from '../utils/tradeMath';
import { Database, ShieldCheck, CheckCircle2, AlertTriangle, Layers, FileCode } from 'lucide-react';

export const DataQualityEngine: React.FC = () => {
  const audit = auditDataQuality();

  const rEngineFiles = [
    'R/trade_engine.R',
    'R/country_engine.R',
    'R/bilateral_trade.R',
    'R/product_engine.R',
    'R/commodity_engine.R',
    'R/balance_engine.R',
    'R/rca_engine.R',
    'R/concentration.R',
    'R/network_engine.R',
    'R/supply_chain.R',
    'R/tariff_engine.R',
    'R/shipping_engine.R',
    'R/currency_engine.R',
    'R/gravity_model.R',
    'R/elasticity.R',
    'R/forecast_engine.R',
    'R/scenario_engine.R',
    'R/stress_engine.R',
    'R/regime_engine.R',
    'R/anomaly_engine.R',
    'R/data_engine.R',
  ];

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div>
          <h2 className="text-base font-bold font-mono text-slate-900 flex items-center gap-2">
            <Database className="w-5 h-5 text-emerald-600" /> DATA QUALITY ENGINE & PROPRIETARY R ARCHITECTURE
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Automated dataset integrity checks, mirror trade data discrepancy audit, unit value anomaly scoring, and R package module registry.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded">
          <ShieldCheck className="w-4 h-4 text-emerald-700" />
          <span className="text-emerald-800 font-bold">DATA QUALITY SCORE: {audit.overallScore} / 100</span>
        </div>
      </div>

      {/* Audit Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 font-mono text-xs">
        <div className="bg-white border border-slate-200 p-3 rounded shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] block font-bold">MISSING VALUE RATE</span>
          <span className="text-lg font-bold text-emerald-700 mt-1 block">{audit.missingValuePct}%</span>
          <span className="text-[11px] text-slate-500 mt-1 block font-medium">Near Zero Gaps</span>
        </div>

        <div className="bg-white border border-slate-200 p-3 rounded shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] block font-bold">MIRROR DISCREPANCY</span>
          <span className="text-lg font-bold text-amber-600 mt-1 block">{audit.mirrorDiscrepancyPct}%</span>
          <span className="text-[11px] text-slate-500 mt-1 block font-medium">Reporter vs Partner</span>
        </div>

        <div className="bg-white border border-slate-200 p-3 rounded shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] block font-bold">NEGATIVE QTY ERRORS</span>
          <span className="text-lg font-bold text-emerald-700 mt-1 block">{audit.negativeQtyCount}</span>
          <span className="text-[11px] text-slate-500 mt-1 block font-medium">Clean Sanitization</span>
        </div>

        <div className="bg-white border border-slate-200 p-3 rounded shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] block font-bold">STALE RECORDS RATE</span>
          <span className="text-lg font-bold text-cyan-700 mt-1 block">{audit.staleRecordPct}%</span>
          <span className="text-[11px] text-slate-500 mt-1 block font-medium">Live Synchronization</span>
        </div>

        <div className="bg-white border border-slate-200 p-3 rounded shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] block font-bold">UNIT VALUE AUDIT SCORE</span>
          <span className="text-lg font-bold text-slate-800 mt-1 block">{audit.unitValueAnomalyScore}</span>
          <span className="text-[11px] text-slate-500 mt-1 block font-medium">Price Validation</span>
        </div>
      </div>

      {/* R Package Structure Viewer */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 font-mono shadow-sm space-y-3">
        <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-2">
          <FileCode className="w-4 h-4 text-emerald-600" /> PROPRIETARY R PACKAGE MODULE REGISTRY (`rhinoquant-global-trade/R/*.R`)
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5 text-xs">
          {rEngineFiles.map((file, idx) => (
            <div key={idx} className="p-2.5 rounded bg-slate-50 border border-slate-150 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCode className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-slate-800 font-bold">{file}</span>
              </div>
              <span className="text-[10px] text-emerald-700 font-bold">LOADED</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
