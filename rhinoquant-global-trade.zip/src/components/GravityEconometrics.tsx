import React, { useState } from 'react';
import { RHINO_GRAVITY_DATA } from '../data/tradeData';
import { computeGravityTrade } from '../utils/tradeMath';
import { LineChart, Calculator, CheckCircle2, TrendingUp, AlertCircle, BarChart2 } from 'lucide-react';

export const GravityEconometrics: React.FC = () => {
  const [selectedCorridorIdx, setSelectedCorridorIdx] = useState<number>(0);

  const activePoint = RHINO_GRAVITY_DATA[selectedCorridorIdx] || RHINO_GRAVITY_DATA[0];

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div>
          <h2 className="text-base font-bold font-mono text-slate-900 flex items-center gap-2">
            <LineChart className="w-5 h-5 text-emerald-600" /> TRADE GRAVITY MODEL & ECONOMETRIC POTENTIAL ENGINE
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Log-linear structural gravity specification: ln(Trade_ij) = b0 + b1*ln(GDP_i) + b2*ln(GDP_j) - b3*ln(Dist_ij) + b4*RTA_ij.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs bg-slate-50 border border-slate-200 px-3 py-1.5 rounded">
          <span className="text-slate-500 font-semibold">MODEL GOODNESS OF FIT:</span>
          <span className="text-emerald-700 font-bold">R² = 0.842 (p &lt; 0.001)</span>
        </div>
      </div>

      {/* Regression Coefficients Table & Model Specs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
        {/* Estimated Coefficients Card */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm space-y-3">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-2">
            <Calculator className="w-4 h-4 text-emerald-600" /> ESTIMATED REGRESSION COEFFICIENTS
          </h3>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between p-2 bg-slate-50 rounded border border-slate-100">
              <span className="text-slate-700 font-medium">Intercept (beta_0)</span>
              <span className="text-slate-900 font-bold">-4.200 (SE: 0.18) ***</span>
            </div>
            <div className="flex justify-between p-2 bg-slate-50 rounded border border-slate-100">
              <span className="text-slate-700 font-medium">ln GDP_i (Reporter GDP)</span>
              <span className="text-emerald-700 font-bold">+0.850 (SE: 0.04) ***</span>
            </div>
            <div className="flex justify-between p-2 bg-slate-50 rounded border border-slate-100">
              <span className="text-slate-700 font-medium">ln GDP_j (Partner GDP)</span>
              <span className="text-cyan-700 font-bold">+0.800 (SE: 0.05) ***</span>
            </div>
            <div className="flex justify-between p-2 bg-slate-50 rounded border border-slate-100">
              <span className="text-slate-700 font-medium">ln Distance_ij</span>
              <span className="text-rose-600 font-bold">-0.620 (SE: 0.06) ***</span>
            </div>
            <div className="flex justify-between p-2 bg-slate-50 rounded border border-slate-100">
              <span className="text-slate-700 font-medium">Contiguity (Border)</span>
              <span className="text-slate-900 font-bold">+0.350 (SE: 0.08) **</span>
            </div>
            <div className="flex justify-between p-2 bg-slate-50 rounded border border-slate-100">
              <span className="text-slate-700 font-medium">Trade Agreement (RTA)</span>
              <span className="text-amber-600 font-bold">+0.280 (SE: 0.07) **</span>
            </div>
          </div>
        </div>

        {/* Selected Corridor Actual vs Predicted Gravity Gap */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-lg p-5 shadow-sm space-y-4">
          <div className="border-b border-slate-100 pb-2 flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              CORRIDOR GRAVITY POTENTIAL & GAP ANALYSIS
            </h3>
            <span className="text-xs text-slate-500 font-semibold">N = 420 Bilateral Pairs</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700">
              <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] border-b border-slate-200 font-bold">
                <tr>
                  <th className="p-2.5">Corridor Route</th>
                  <th className="p-2.5">Actual Trade ($B)</th>
                  <th className="p-2.5">Predicted Trade ($B)</th>
                  <th className="p-2.5">Trade Gap ($B)</th>
                  <th className="p-2.5">Residual (epsilon)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {RHINO_GRAVITY_DATA.map((g, idx) => (
                  <tr
                    key={idx}
                    onClick={() => setSelectedCorridorIdx(idx)}
                    className={`hover:bg-slate-50 cursor-pointer transition-all ${
                      idx === selectedCorridorIdx ? 'bg-emerald-50/60 font-bold' : ''
                    }`}
                  >
                    <td className="p-2.5 text-slate-900 font-bold">{g.corridor}</td>
                    <td className="p-2.5 text-slate-800">${g.actualTrade}</td>
                    <td className="p-2.5 text-slate-600">${g.predictedTrade}</td>
                    <td className={`p-2.5 font-bold ${g.tradeGap >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                      {g.tradeGap >= 0 ? '+' : ''}${g.tradeGap}B
                    </td>
                    <td className="p-2.5 text-slate-500 font-mono">{g.residual}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
