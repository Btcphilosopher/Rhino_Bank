import React, { useState } from 'react';
import { RHINO_COUNTRIES, RHINO_CORRIDORS } from '../data/tradeData';
import { Globe, Filter, Layers, ArrowRight, ShieldCheck } from 'lucide-react';

interface CountryMapCoords {
  [code: string]: { x: number; y: number; label: string };
}

// Normalized 2D projected coordinates for major trade hubs on SVG canvas
const HUB_COORDINATES: CountryMapCoords = {
  USA: { x: 220, y: 160, label: 'United States' },
  CAN: { x: 210, y: 110, label: 'Canada' },
  MEX: { x: 195, y: 215, label: 'Mexico' },
  BRA: { x: 330, y: 320, label: 'Brazil' },
  DEU: { x: 490, y: 135, label: 'Germany' },
  GBR: { x: 450, y: 130, label: 'United Kingdom' },
  FRA: { x: 465, y: 150, label: 'France' },
  NLD: { x: 475, y: 130, label: 'Netherlands' },
  CHN: { x: 740, y: 185, label: 'China' },
  JPN: { x: 830, y: 175, label: 'Japan' },
  KOR: { x: 795, y: 175, label: 'South Korea' },
  TWN: { x: 785, y: 210, label: 'Taiwan' },
  VNM: { x: 750, y: 235, label: 'Vietnam' },
  IND: { x: 670, y: 220, label: 'India' },
  SAU: { x: 575, y: 215, label: 'Saudi Arabia' },
  AUS: { x: 820, y: 340, label: 'Australia' },
  CHE: { x: 480, y: 145, label: 'Switzerland' },
  SGP: { x: 740, y: 265, label: 'Singapore' },
};

interface WorldMapProps {
  onSelectCountry?: (code: string) => void;
  onSelectCorridor?: (corridor: string) => void;
}

export const WorldMap: React.FC<WorldMapProps> = ({
  onSelectCountry,
  onSelectCorridor,
}) => {
  const [metricFilter, setMetricFilter] = useState<'value' | 'balance' | 'growth'>('value');
  const [productFilter, setProductFilter] = useState<string>('ALL');
  const [selectedHub, setSelectedHub] = useState<string | null>(null);

  const filteredCorridors = RHINO_CORRIDORS.filter(c => {
    if (selectedHub) {
      return c.countryA === selectedHub || c.countryB === selectedHub;
    }
    return true;
  });

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-4">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div>
          <h2 className="text-base font-bold font-mono text-slate-900 flex items-center gap-2">
            <Globe className="w-5 h-5 text-emerald-600" /> GLOBAL BILATERAL TRADE VECTOR MAP
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Interactive network map of international merchandise trade corridors. Arc stroke width indicates trade value intensity.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-3 font-mono text-xs">
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-2.5 py-1.5 rounded">
            <Filter className="w-3.5 h-3.5 text-emerald-600" />
            <span className="text-slate-500 font-bold">METRIC:</span>
            <select
              value={metricFilter}
              onChange={(e: any) => setMetricFilter(e.target.value)}
              className="bg-transparent text-slate-900 font-bold focus:outline-none"
            >
              <option value="value">Bilateral Trade Value ($B)</option>
              <option value="balance">Trade Surplus / Deficit</option>
              <option value="growth">YoY Growth (%)</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-2.5 py-1.5 rounded">
            <Layers className="w-3.5 h-3.5 text-cyan-600" />
            <span className="text-slate-500 font-bold">SECTOR:</span>
            <select
              value={productFilter}
              onChange={(e) => setProductFilter(e.target.value)}
              className="bg-transparent text-slate-900 font-bold focus:outline-none"
            >
              <option value="ALL">All Sectors & Goods</option>
              <option value="HS-85">Electronics & Semiconductors</option>
              <option value="HS-27">Mineral Crude Oil & LNG</option>
              <option value="HS-87">Automobiles & Vehicles</option>
              <option value="HS-30">Pharmaceuticals</option>
            </select>
          </div>

          {selectedHub && (
            <button
              onClick={() => setSelectedHub(null)}
              className="bg-emerald-50 text-emerald-700 border border-emerald-200 px-2.5 py-1.5 rounded hover:bg-emerald-100 transition-all font-bold"
            >
              RESET HUB ({selectedHub})
            </button>
          )}
        </div>
      </div>

      {/* Interactive Map Visualizer */}
      <div className="bg-white border border-slate-200 rounded-lg p-3 relative overflow-hidden shadow-sm">
        {/* World Grid Map Canvas */}
        <div className="relative w-full overflow-x-auto">
          <svg viewBox="0 0 960 460" className="w-full h-auto max-h-[550px] bg-[#0F172A] rounded border border-slate-800">
            <defs>
              <linearGradient id="arcGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.85" />
                <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.85" />
              </linearGradient>
              <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
            </defs>

            {/* Background Map Grid Lines */}
            <g stroke="#1e293b" strokeWidth="0.5" strokeDasharray="3 3">
              {[60, 120, 180, 240, 300, 360, 420].map(y => (
                <line key={y} x1="0" y1={y} x2="960" y2={y} />
              ))}
              {[150, 300, 450, 600, 750, 900].map(x => (
                <line key={x} x1={x} y1="0" x2={x} y2="460" />
              ))}
            </g>

            {/* Continental Schematics */}
            <path
              d="M 120 100 Q 200 80 260 120 T 240 240 T 160 220 Z M 300 240 Q 360 280 340 390 T 290 350 Z M 440 90 Q 520 80 540 180 T 440 200 Z M 520 200 Q 600 240 580 340 Z M 640 80 Q 880 70 860 260 T 680 280 Z M 780 300 Q 860 320 840 400 Z"
              fill="#1e293b"
              stroke="#334155"
              strokeWidth="1"
            />

            {/* Trade Corridor Flow Arcs */}
            {filteredCorridors.map((corridor, idx) => {
              const posA = HUB_COORDINATES[corridor.countryA];
              const posB = HUB_COORDINATES[corridor.countryB];
              if (!posA || !posB) return null;

              // Quadratic Bezier Curve for smooth curved arc
              const midX = (posA.x + posB.x) / 2;
              const midY = (posA.y + posB.y) / 2 - Math.abs(posA.x - posB.x) * 0.15;
              const strokeW = Math.max(1.5, Math.min(8, corridor.totalTrade / 100));

              return (
                <g key={idx} className="hover:opacity-100 cursor-pointer group">
                  <path
                    d={`M ${posA.x} ${posA.y} Q ${midX} ${midY} ${posB.x} ${posB.y}`}
                    fill="none"
                    stroke="url(#arcGrad)"
                    strokeWidth={strokeW}
                    strokeLinecap="round"
                    className="opacity-75 group-hover:opacity-100 transition-all duration-300"
                    onClick={() => onSelectCorridor && onSelectCorridor(`${corridor.countryA}-${corridor.countryB}`)}
                  />
                  {/* Flow Animation Dot */}
                  <circle r={strokeW > 4 ? 3 : 2} fill="#34d399">
                    <animateMotion
                      path={`M ${posA.x} ${posA.y} Q ${midX} ${midY} ${posB.x} ${posB.y}`}
                      dur={`${Math.max(2, 8 - corridor.totalTrade / 100)}s`}
                      repeatCount="indefinite"
                    />
                  </circle>
                </g>
              );
            })}

            {/* Country Hub Nodes */}
            {Object.entries(HUB_COORDINATES).map(([code, coords]) => {
              const ctryData = RHINO_COUNTRIES.find(c => c.code === code);
              const isSelected = selectedHub === code;
              const nodeRadius = ctryData ? Math.max(6, Math.min(18, ctryData.gdp / 2000)) : 8;

              return (
                <g
                  key={code}
                  transform={`translate(${coords.x}, ${coords.y})`}
                  className="cursor-pointer group"
                  onClick={() => {
                    setSelectedHub(code);
                    if (onSelectCountry) onSelectCountry(code);
                  }}
                >
                  <circle
                    r={nodeRadius + 4}
                    fill="none"
                    stroke={isSelected ? '#10b981' : '#38bdf8'}
                    strokeWidth="1.5"
                    className="opacity-40 group-hover:opacity-100 animate-pulse"
                  />
                  <circle
                    r={nodeRadius}
                    fill={isSelected ? '#10b981' : '#0f172a'}
                    stroke={isSelected ? '#a7f3d0' : '#38bdf8'}
                    strokeWidth="2"
                    filter="url(#glow)"
                  />
                  <text
                    y={nodeRadius + 12}
                    textAnchor="middle"
                    fill="#f8fafc"
                    fontSize="10"
                    fontFamily="monospace"
                    fontWeight="bold"
                    className="pointer-events-none drop-shadow-md"
                  >
                    {code}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Corridor Data Summary Cards overlay */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 font-mono text-xs">
          {filteredCorridors.slice(0, 4).map((c, i) => (
            <div
              key={i}
              className="bg-slate-50 border border-slate-200 p-2.5 rounded hover:bg-slate-100 transition-all cursor-pointer shadow-sm"
              onClick={() => onSelectCorridor && onSelectCorridor(`${c.countryA}-${c.countryB}`)}
            >
              <div className="flex items-center justify-between text-slate-900 font-bold">
                <span>{c.countryA} ↔ {c.countryB}</span>
                <span className="text-emerald-700 font-bold">${c.totalTrade}B</span>
              </div>
              <div className="text-[11px] text-slate-500 mt-1 flex justify-between">
                <span>Exp {c.countryA}: ${c.exportAtoB}B</span>
                <span className="text-emerald-600 font-semibold">+{c.growthYoY}% YoY</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
