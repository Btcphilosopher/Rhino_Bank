import React, { useState } from 'react';
import { RHINO_COUNTRIES } from '../data/tradeData';
import { Sliders, Sparkles, TrendingUp, Filter } from 'lucide-react';
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  Tooltip,
} from 'recharts';

type MetricKey =
  | 'gdp'
  | 'exports'
  | 'imports'
  | 'tradeBalance'
  | 'tradeOpenness'
  | 'exportHHI'
  | 'importHHI'
  | 'termsOfTrade'
  | 'reer'
  | 'tariffAverage'
  | 'stressScore';

interface MetricOpt {
  key: MetricKey;
  label: string;
}

const METRICS: MetricOpt[] = [
  { key: 'tradeOpenness', label: 'Trade Openness (% GDP)' },
  { key: 'gdp', label: 'Nominal GDP ($ Billions)' },
  { key: 'exports', label: 'Merchandise Exports ($ Billions)' },
  { key: 'imports', label: 'Merchandise Imports ($ Billions)' },
  { key: 'tradeBalance', label: 'Trade Balance ($ Billions)' },
  { key: 'exportHHI', label: 'Export Concentration (HHI)' },
  { key: 'termsOfTrade', label: 'Terms of Trade Index' },
  { key: 'reer', label: 'Real Effective Exchange Rate (REER)' },
  { key: 'tariffAverage', label: 'Average Tariff Rate (%)' },
  { key: 'stressScore', label: 'Trade Stress Index (0-100)' },
];

export const UniversalXYEngine: React.FC = () => {
  const [xAxisKey, setXAxisKey] = useState<MetricKey>('tradeOpenness');
  const [yAxisKey, setYAxisKey] = useState<MetricKey>('stressScore');

  const scatterData = RHINO_COUNTRIES.map(c => ({
    name: c.name,
    code: c.code,
    flag: c.flag,
    x: c[xAxisKey] as number,
    y: c[yAxisKey] as number,
    z: c.gdp,
  }));

  const xLabel = METRICS.find(m => m.key === xAxisKey)?.label || 'X Variable';
  const yLabel = METRICS.find(m => m.key === yAxisKey)?.label || 'Y Variable';

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div>
          <h2 className="text-base font-bold font-mono text-slate-900 flex items-center gap-2">
            <Sliders className="w-5 h-5 text-emerald-600" /> UNIVERSAL X / Y QUANTITATIVE SCATTER ENGINE
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Flagship RhinoQuant analytical feature. Select arbitrary macro, tariff, trade flow, or concentration variables for X, Y, and Z axes.
          </p>
        </div>

        {/* Axis Selector Controls */}
        <div className="flex flex-wrap items-center gap-3 font-mono text-xs">
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-2.5 py-1.5 rounded">
            <span className="text-slate-500 font-bold">X AXIS:</span>
            <select
              value={xAxisKey}
              onChange={(e: any) => setXAxisKey(e.target.value)}
              className="bg-transparent text-slate-900 font-bold focus:outline-none cursor-pointer"
            >
              {METRICS.map(m => (
                <option key={m.key} value={m.key}>{m.label}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-2.5 py-1.5 rounded">
            <span className="text-slate-500 font-bold">Y AXIS:</span>
            <select
              value={yAxisKey}
              onChange={(e: any) => setYAxisKey(e.target.value)}
              className="bg-transparent text-slate-900 font-bold focus:outline-none cursor-pointer"
            >
              {METRICS.map(m => (
                <option key={m.key} value={m.key}>{m.label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Scatter Chart Container */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 font-mono shadow-sm">
        <div className="border-b border-slate-100 pb-2 mb-4 flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
            SCATTER CORRELATION ({xLabel} vs {yLabel})
          </h3>
          <span className="text-xs text-slate-500">Bubble Size = Nominal GDP</span>
        </div>

        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 20, right: 30, bottom: 20, left: 10 }}>
              <XAxis dataKey="x" name={xLabel} stroke="#64748b" fontSize={11} tickLine={false} />
              <YAxis dataKey="y" name={yLabel} stroke="#64748b" fontSize={11} tickLine={false} />
              <ZAxis dataKey="z" range={[60, 400]} name="GDP ($B)" />
              <Tooltip
                cursor={{ strokeDasharray: '3 3' }}
                contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '6px', fontSize: '12px', fontFamily: 'monospace', color: '#0f172a', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
                formatter={(val: any, name: any) => [`${val}`, name]}
              />
              <Scatter name="Nations" data={scatterData} fill="#059669" />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
