import React from 'react';
import { Anchor, ShieldAlert, Navigation, Layers, TrendingUp, Clock, AlertTriangle } from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
} from 'recharts';

export const ShippingLogistics: React.FC = () => {
  const freightIndexHistory = [
    { month: 'Jan', SCFI: 1420, BDI: 1100, DelaysDays: 2.1 },
    { month: 'Feb', SCFI: 1550, BDI: 1250, DelaysDays: 2.8 },
    { month: 'Mar', SCFI: 1680, BDI: 1400, DelaysDays: 3.4 },
    { month: 'Apr', SCFI: 1720, BDI: 1380, DelaysDays: 3.1 },
    { month: 'May', SCFI: 1845, BDI: 1520, DelaysDays: 4.2 },
    { month: 'Jun', SCFI: 1910, BDI: 1650, DelaysDays: 4.8 },
  ];

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div>
          <h2 className="text-base font-bold font-mono text-slate-900 flex items-center gap-2">
            <Anchor className="w-5 h-5 text-emerald-600" /> GLOBAL SEABORNE SHIPPING & LOGISTICS TERMINAL
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Freight rate benchmarks (SCFI / BDI), container vs dry bulk vs crude tanker seaborne flows, port dwell times, and choke point congestion metrics.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs bg-slate-50 border border-emerald-200 px-3 py-1.5 rounded">
          <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
          <span className="text-emerald-800 font-bold">GLOBAL SEABORNE BOTTLENECK SCORE: 34.2 (STABLE)</span>
        </div>
      </div>

      {/* Key Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">SCFI FREIGHT INDEX</span>
          <span className="text-xl font-bold text-slate-900 mt-1 block">1,845 pt</span>
          <span className="text-[11px] text-emerald-700 font-semibold mt-1 flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" /> +4.2% MoM
          </span>
        </div>

        <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">BALTIC DRY INDEX (BDI)</span>
          <span className="text-xl font-bold text-slate-900 mt-1 block">1,520 pt</span>
          <span className="text-[11px] text-emerald-700 font-semibold mt-1 flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" /> +8.5% MoM
          </span>
        </div>

        <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">AVG PORT DWELL TIME</span>
          <span className="text-xl font-bold text-slate-900 mt-1 block">4.2 Days</span>
          <span className="text-[11px] text-slate-500 mt-1 block">LA / LB & Ningbo Hubs</span>
        </div>

        <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">SUEZ CANAL TRANSIT VOLUME</span>
          <span className="text-xl font-bold text-rose-600 mt-1 block">42.8 M Tons/wk</span>
          <span className="text-[11px] text-slate-500 mt-1 block">Red Sea Route Rerouting</span>
        </div>
      </div>

      {/* Charts & Port Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-lg p-5 shadow-sm">
          <div className="border-b border-slate-100 pb-2 mb-4">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              CONTAINER (SCFI) vs DRY BULK (BDI) FREIGHT RATE TRAJECTORY
            </h3>
            <p className="text-xs text-slate-500">Monthly index points comparison</p>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={freightIndexHistory} margin={{ top: 10, right: 30, left: 10, bottom: 0 }}>
                <XAxis dataKey="month" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} domain={[800, 2200]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '6px', fontSize: '12px', fontFamily: 'monospace', color: '#0f172a', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
                />
                <Line type="monotone" dataKey="SCFI" stroke="#10b981" strokeWidth={2.5} name="SCFI Container" />
                <Line type="monotone" dataKey="BDI" stroke="#0284c7" strokeWidth={2.5} name="BDI Dry Bulk" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Port Congestion Monitor */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm space-y-3">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider border-b border-slate-100 pb-2">
            KEY STRATEGIC PORT CONGESTION
          </h3>

          <div className="space-y-2 text-xs">
            {[
              { port: 'Ningbo-Zhoushan (CHN)', status: 'Optimal', delay: '1.8 Days', color: 'text-emerald-700 font-bold' },
              { port: 'Rotterdam Europort (NLD)', status: 'Optimal', delay: '2.1 Days', color: 'text-emerald-700 font-bold' },
              { port: 'Los Angeles / Long Beach (USA)', status: 'Moderate', delay: '4.5 Days', color: 'text-amber-600 font-bold' },
              { port: 'Singapore Transshipment (SGP)', status: 'Optimal', delay: '1.4 Days', color: 'text-emerald-700 font-bold' },
              { port: 'Bab-el-Mandeb / Red Sea', status: 'Congested', delay: '12.4 Days', color: 'text-rose-600 font-bold' },
            ].map((p, idx) => (
              <div key={idx} className="p-2.5 rounded bg-slate-50 border border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-slate-900 font-bold block">{p.port}</span>
                  <span className="text-[10px] text-slate-500">Wait: {p.delay}</span>
                </div>
                <span className={`text-[11px] ${p.color}`}>{p.status}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
