import React, { useState } from 'react';
import { RHINO_COUNTRIES, RHINO_PRODUCTS, RHINO_CORRIDORS } from '../data/tradeData';
import {
  Globe,
  TrendingUp,
  TrendingDown,
  BarChart2,
  PieChart as PieChartIcon,
  ShieldCheck,
  Search,
  ArrowRightLeft,
  Award,
  DollarSign,
  Activity,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
} from 'recharts';

interface CountryProfilesProps {
  initialCountry?: string;
  onSelectCorridor?: (corridor: string) => void;
}

export const CountryProfiles: React.FC<CountryProfilesProps> = ({
  initialCountry = 'USA',
  onSelectCorridor,
}) => {
  const [selectedCode, setSelectedCode] = useState<string>(initialCountry);

  const country = RHINO_COUNTRIES.find(c => c.code === selectedCode) || RHINO_COUNTRIES[0];

  // Country specific bilateral corridors
  const countryCorridors = RHINO_CORRIDORS.filter(
    c => c.countryA === country.code || c.countryB === country.code
  );

  const rcaChartData = country.rcaTopProducts.map(item => ({
    subject: item.name.length > 18 ? item.name.substring(0, 18) + '...' : item.name,
    RCA: item.rca,
    Benchmark: 1.0,
  }));

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Country Selector Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div className="flex items-center gap-3">
          <span className="text-4xl">{country.flag}</span>
          <div>
            <div className="flex items-center gap-2 font-mono text-xs text-emerald-700 font-bold">
              <span>ISO-3: {country.code}</span> • <span>REGION: {country.region}</span>
            </div>
            <h1 className="text-2xl font-bold font-mono text-slate-900">{country.name} Trade Profile</h1>
          </div>
        </div>

        {/* Selector Dropdown */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-500 font-bold">SELECT COUNTRY:</span>
          <select
            value={country.code}
            onChange={(e) => setSelectedCode(e.target.value)}
            className="bg-slate-50 border border-slate-200 text-slate-900 font-bold px-3 py-1.5 rounded focus:outline-none"
          >
            {RHINO_COUNTRIES.map(c => (
              <option key={c.code} value={c.code}>
                {c.flag} {c.name} ({c.code})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Primary Key Stats Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-xs">
        <div className="bg-white border border-slate-200 p-3.5 rounded shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">NOMINAL GDP</span>
          <span className="text-lg font-bold text-slate-900 mt-1 block">${country.gdp.toLocaleString()} B</span>
          <span className="text-[11px] text-slate-500 mt-1 block">${country.gdpPerCapita.toLocaleString()}/cap</span>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">TOTAL MERCH EXPORTS</span>
          <span className="text-lg font-bold text-emerald-700 mt-1 block">${country.exports.toLocaleString()} B</span>
          <span className="text-[11px] text-slate-500 mt-1 block">HHI: {country.exportHHI}</span>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">TOTAL MERCH IMPORTS</span>
          <span className="text-lg font-bold text-slate-900 mt-1 block">${country.imports.toLocaleString()} B</span>
          <span className="text-[11px] text-slate-500 mt-1 block">HHI: {country.importHHI}</span>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">TRADE BALANCE</span>
          <span className={`text-lg font-bold mt-1 block ${country.tradeBalance >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
            ${country.tradeBalance.toLocaleString()} B
          </span>
          <span className="text-[11px] text-slate-500 mt-1 block">
            {((country.tradeBalance / country.gdp) * 100).toFixed(1)}% of GDP
          </span>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">TRADE OPENNESS</span>
          <span className="text-lg font-bold text-emerald-600 mt-1 block">{country.tradeOpenness}%</span>
          <span className="text-[11px] text-slate-500 mt-1 block">(Exp + Imp)/GDP</span>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">TERMS OF TRADE</span>
          <span className="text-lg font-bold text-indigo-600 mt-1 block">{country.termsOfTrade}</span>
          <span className="text-[11px] text-slate-500 mt-1 block">Base 100 Index</span>
        </div>
      </div>

      {/* Section 2: RCA Radar + Partner Corridors */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* RCA Radar */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm">
          <div className="border-b border-slate-100 pb-2 mb-3">
            <h3 className="text-xs font-bold font-mono text-slate-700 uppercase tracking-wider flex items-center gap-2">
              <Award className="w-4 h-4 text-emerald-600" /> REVEALED COMPARATIVE ADVANTAGE (RCA) INDEX
            </h3>
            <p className="text-xs text-slate-500 font-mono">
              Products where {country.name} exhibits significant comparative export specialization (RCA &gt; 1.0)
            </p>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={rcaChartData}>
                <PolarGrid stroke="#cbd5e1" />
                <PolarAngleAxis dataKey="subject" stroke="#475569" fontSize={10} />
                <PolarRadiusAxis angle={30} domain={[0, 8]} stroke="#94a3b8" fontSize={9} />
                <Radar name="RCA Score" dataKey="RCA" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top Partner Trade Corridors */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm font-mono">
          <div className="border-b border-slate-100 pb-2 mb-3 flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                <ArrowRightLeft className="w-4 h-4 text-cyan-600" /> TOP BILATERAL TRADE PARTNERS
              </h3>
              <p className="text-xs text-slate-500">Key trading corridors for {country.name}</p>
            </div>
          </div>

          <div className="space-y-2 text-xs">
            {countryCorridors.length > 0 ? (
              countryCorridors.map((c, idx) => {
                const partnerCode = c.countryA === country.code ? c.countryB : c.countryA;
                const partnerData = RHINO_COUNTRIES.find(item => item.code === partnerCode);
                return (
                  <div
                    key={idx}
                    onClick={() => onSelectCorridor && onSelectCorridor(`${c.countryA}-${c.countryB}`)}
                    className="flex items-center justify-between p-2.5 rounded bg-slate-50 border border-slate-100 hover:bg-slate-100 cursor-pointer transition-all"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{partnerData?.flag || '🌐'}</span>
                      <div>
                        <span className="text-slate-900 font-bold block">{partnerData?.name || partnerCode}</span>
                        <span className="text-[10px] text-slate-500">{c.tradeAgreement}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-slate-900 font-bold block">${c.totalTrade} B</span>
                      <span className="text-[10px] text-emerald-600 font-semibold">+{c.growthYoY}% YoY</span>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="text-slate-500 text-xs py-8 text-center">
                Detailed bilateral matrix for {country.name} available in Trade Corridor module.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
