import React from 'react';
import {
  Globe,
  Map,
  TrendingUp,
  Boxes,
  Layers,
  Zap,
  ShieldAlert,
  Anchor,
  DollarSign,
  Share2,
  LineChart,
  Sliders,
  Compass,
  Search,
  BookOpen,
  Database,
  BarChart2,
  Activity,
  Award
} from 'lucide-react';

export type ModuleTab =
  | 'WORLD'
  | 'MAP'
  | 'COUNTRIES'
  | 'CORRIDORS'
  | 'PRODUCTS'
  | 'COMMODITIES'
  | 'SUPPLY_CHAINS'
  | 'TARIFFS'
  | 'SHIPPING'
  | 'NETWORK'
  | 'GRAVITY'
  | 'FORECASTS'
  | 'UNIVERSAL_XY'
  | 'SCREENER'
  | 'RESEARCH'
  | 'DATA_QUALITY';

interface NavbarProps {
  activeTab: ModuleTab;
  setActiveTab: (tab: ModuleTab) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  searchQuery,
  setSearchQuery,
}) => {
  const tabs: Array<{ id: ModuleTab; label: string; icon: React.ReactNode }> = [
    { id: 'WORLD', label: 'WORLD TERMINAL', icon: <Globe className="w-3.5 h-3.5" /> },
    { id: 'MAP', label: 'TRADE MAP', icon: <Map className="w-3.5 h-3.5" /> },
    { id: 'COUNTRIES', label: 'COUNTRIES', icon: <BarChart2 className="w-3.5 h-3.5" /> },
    { id: 'CORRIDORS', label: 'CORRIDORS', icon: <TrendingUp className="w-3.5 h-3.5" /> },
    { id: 'PRODUCTS', label: 'PRODUCTS & HS', icon: <Boxes className="w-3.5 h-3.5" /> },
    { id: 'COMMODITIES', label: 'COMMODITIES', icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'SUPPLY_CHAINS', label: 'SUPPLY CHAINS', icon: <Share2 className="w-3.5 h-3.5" /> },
    { id: 'TARIFFS', label: 'TARIFFS & SHOCKS', icon: <ShieldAlert className="w-3.5 h-3.5" /> },
    { id: 'SHIPPING', label: 'SHIPPING', icon: <Anchor className="w-3.5 h-3.5" /> },
    { id: 'NETWORK', label: 'NETWORK GRAPH', icon: <Activity className="w-3.5 h-3.5" /> },
    { id: 'GRAVITY', label: 'GRAVITY MODEL', icon: <LineChart className="w-3.5 h-3.5" /> },
    { id: 'FORECASTS', label: 'OUTLOOK', icon: <Zap className="w-3.5 h-3.5" /> },
    { id: 'UNIVERSAL_XY', label: 'UNIVERSAL X/Y', icon: <Sliders className="w-3.5 h-3.5" /> },
    { id: 'SCREENER', label: 'SCREENER', icon: <Compass className="w-3.5 h-3.5" /> },
    { id: 'RESEARCH', label: 'RESEARCH & R', icon: <BookOpen className="w-3.5 h-3.5" /> },
    { id: 'DATA_QUALITY', label: 'DATA ENGINE', icon: <Database className="w-3.5 h-3.5" /> },
  ];

  return (
    <header className="bg-[#0F172A] text-white border-b border-slate-800 select-none sticky top-0 z-50 shadow-md">
      {/* Top Telemetry Header Bar */}
      <div className="px-6 py-3 flex flex-wrap items-center justify-between gap-3 text-xs border-b border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-emerald-500 flex items-center justify-center font-bold text-slate-900 rounded-sm font-mono text-sm shadow">
            RQ
          </div>
          <h1 className="text-lg font-semibold tracking-tight text-white flex items-center gap-2">
            RHINOQUANT <span className="text-slate-400 font-normal">GLOBAL TRADE v3.7</span>
          </h1>
        </div>

        {/* Ticker Key Stats */}
        <div className="hidden lg:flex items-center space-x-6 text-xs font-medium">
          <div className="flex items-center text-emerald-400 font-mono">
            <span className="w-2 h-2 bg-emerald-400 rounded-full mr-2 animate-pulse"></span>
            <span>LIVE MARKET</span>
          </div>
          <div className="flex items-center space-x-4 border-l border-slate-700 pl-6 text-slate-300 font-mono">
            <span>
              $32.41T <small className="text-slate-500">TOTAL VALUE</small>
            </span>
            <span className="text-emerald-400">
              +2.41% <small className="text-slate-500">YOY</small>
            </span>
            <span className="text-slate-400 border-l border-slate-700 pl-4">
              STRESS: <strong className="text-amber-400">12.8%</strong>
            </span>
            <span className="text-slate-400">
              CHN <strong className="text-cyan-400">$3.38T</strong>
            </span>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative w-48 sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search country, product, corridor..."
            className="w-full bg-slate-900 border border-slate-700 rounded pl-8 pr-3 py-1.5 text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-emerald-500 font-mono"
          />
        </div>
      </div>

      {/* Module Navigation Tabs */}
      <nav className="bg-white border-b border-slate-200 px-6 py-2 flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-slate-500 overflow-x-auto scrollbar-none">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-slate-900 text-white font-bold shadow-sm border-b-2 border-emerald-500'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
};
