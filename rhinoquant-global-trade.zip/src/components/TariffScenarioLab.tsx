import React, { useState } from 'react';
import { RHINO_CORRIDORS, RHINO_COUNTRIES } from '../data/tradeData';
import { runScenarioLab } from '../utils/tradeMath';
import { RhinoScenarioInput } from '../types';
import { ShieldAlert, Zap, Sliders, Play, RefreshCw, ArrowRight, Activity } from 'lucide-react';

export const TariffScenarioLab: React.FC = () => {
  const [tariffChangePct, setTariffChangePct] = useState<number>(10);
  const [oilPriceChangePct, setOilPriceChangePct] = useState<number>(25);
  const [fxDepreciationPct, setFxDepreciationPct] = useState<number>(15);
  const [shippingCostChangePct, setShippingCostChangePct] = useState<number>(50);
  const [supplierDisruptionPct, setSupplierDisruptionPct] = useState<number>(-20);
  const [demandShockPct, setDemandShockPct] = useState<number>(-10);

  const scenarioInputs: RhinoScenarioInput = {
    tariffChangePct,
    oilPriceChangePct,
    fxDepreciationPct,
    shippingCostChangePct,
    supplierDisruptionPct,
    demandShockPct,
  };

  const results = runScenarioLab(scenarioInputs, RHINO_CORRIDORS, RHINO_COUNTRIES);

  const resetScenarios = () => {
    setTariffChangePct(0);
    setOilPriceChangePct(0);
    setFxDepreciationPct(0);
    setShippingCostChangePct(0);
    setSupplierDisruptionPct(0);
    setDemandShockPct(0);
  };

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div>
          <h2 className="text-base font-bold font-mono text-slate-900 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-600" /> TARIFF SCENARIO LAB & TRADE SHOCK SIMULATOR
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Econometric general equilibrium scenario simulation. Model systemic propagation of statutory tariffs, FX shocks, freight spikes, and supplier supply disruptions.
          </p>
        </div>

        <button
          onClick={resetScenarios}
          className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-800 px-3 py-1.5 rounded font-mono text-xs transition-all border border-slate-300 font-semibold cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" /> RESET ALL SHOCKS TO BASELINE
        </button>
      </div>

      {/* Main Grid: Controls vs Results */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
        {/* Shock Sliders Controls */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm space-y-4">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-emerald-600" /> SCENARIO INPUT CONTROLS
          </h3>

          <div className="space-y-4 text-xs">
            {/* Tariff Slider */}
            <div>
              <div className="flex justify-between text-slate-700 font-bold mb-1">
                <span>STATUTORY TARIFF RATE ADJUSTMENT:</span>
                <span className="text-rose-600 font-bold">+{tariffChangePct}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="50"
                value={tariffChangePct}
                onChange={(e) => setTariffChangePct(Number(e.target.value))}
                className="w-full accent-rose-600 cursor-pointer"
              />
            </div>

            {/* FX Depreciation Slider */}
            <div>
              <div className="flex justify-between text-slate-700 font-bold mb-1">
                <span>TRADE-WEIGHTED FX SHOCK:</span>
                <span className="text-amber-600 font-bold">+{fxDepreciationPct}%</span>
              </div>
              <input
                type="range"
                min="-20"
                max="30"
                value={fxDepreciationPct}
                onChange={(e) => setFxDepreciationPct(Number(e.target.value))}
                className="w-full accent-amber-600 cursor-pointer"
              />
            </div>

            {/* Oil Price Slider */}
            <div>
              <div className="flex justify-between text-slate-700 font-bold mb-1">
                <span>CRUDE OIL COMMODITY SHOCK:</span>
                <span className="text-emerald-700 font-bold">+{oilPriceChangePct}%</span>
              </div>
              <input
                type="range"
                min="-50"
                max="100"
                value={oilPriceChangePct}
                onChange={(e) => setOilPriceChangePct(Number(e.target.value))}
                className="w-full accent-emerald-600 cursor-pointer"
              />
            </div>

            {/* Shipping Freight Slider */}
            <div>
              <div className="flex justify-between text-slate-700 font-bold mb-1">
                <span>FREIGHT & CONTAINER COST SHOCK:</span>
                <span className="text-cyan-700 font-bold">+{shippingCostChangePct}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="200"
                value={shippingCostChangePct}
                onChange={(e) => setShippingCostChangePct(Number(e.target.value))}
                className="w-full accent-cyan-600 cursor-pointer"
              />
            </div>

            {/* Supplier Disruption Slider */}
            <div>
              <div className="flex justify-between text-slate-700 font-bold mb-1">
                <span>CRITICAL SUPPLIER AVAILABILITY:</span>
                <span className="text-purple-700 font-bold">{supplierDisruptionPct}%</span>
              </div>
              <input
                type="range"
                min="-50"
                max="0"
                value={supplierDisruptionPct}
                onChange={(e) => setSupplierDisruptionPct(Number(e.target.value))}
                className="w-full accent-purple-600 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* System Impact Results Display */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-lg p-5 shadow-sm space-y-4">
          <div className="border-b border-slate-100 pb-2 flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
              <Zap className="w-4 h-4 text-emerald-600" /> SIMULATED SYSTEM IMPACT RESULTS
            </h3>
            <span className="text-[10px] text-slate-500 font-semibold">ARMINGTON ELASTICITY MODEL V3.7</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="bg-slate-50 p-3.5 rounded border border-slate-100">
              <span className="text-slate-500 uppercase text-[10px] font-bold block">TOTAL TRADE VALUE IMPACT</span>
              <span className={`text-2xl font-bold mt-1 block ${results.tradeValueImpactPct >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                {results.tradeValueImpactPct >= 0 ? '+' : ''}{results.tradeValueImpactPct}%
              </span>
              <span className="text-[10px] text-slate-500 mt-1 block">Global Nominal Flow</span>
            </div>

            <div className="bg-slate-50 p-3.5 rounded border border-slate-100">
              <span className="text-slate-500 uppercase text-[10px] font-bold block">REAL TRADE VOLUME IMPACT</span>
              <span className={`text-2xl font-bold mt-1 block ${results.tradeVolumeImpactPct >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                {results.tradeVolumeImpactPct >= 0 ? '+' : ''}{results.tradeVolumeImpactPct}%
              </span>
              <span className="text-[10px] text-slate-500 mt-1 block">Tonnage Quantity</span>
            </div>

            <div className="bg-slate-50 p-3.5 rounded border border-slate-100">
              <span className="text-slate-500 uppercase text-[10px] font-bold block">IMPORT PRICE INFLATION</span>
              <span className="text-2xl font-bold text-amber-600 mt-1 block">
                +{results.globalPriceImpactPct}%
              </span>
              <span className="text-[10px] text-slate-500 mt-1 block">Consumer Pass-through</span>
            </div>
          </div>

          {/* Trade Diversion & Corridor Redirections Table */}
          <div className="bg-slate-50 p-4 rounded border border-slate-200 space-y-3">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              TRADE DIVERSION & CORRIDOR REDIRECTIONS
            </h4>

            <div className="space-y-2 text-xs">
              {results.topCorridorRedirections.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between p-2.5 rounded bg-white border border-slate-200 shadow-xs">
                  <span className="text-slate-900 font-bold">{item.corridor}</span>
                  <div className="flex items-center gap-3">
                    <span className="text-slate-400 line-through">${item.originalValue}B</span>
                    <ArrowRight className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-slate-900 font-bold">${item.shockedValue}B</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
