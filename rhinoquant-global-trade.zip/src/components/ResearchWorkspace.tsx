import React, { useState } from 'react';
import { BookOpen, Code, Download, FileText, Check, Copy } from 'lucide-react';

export const ResearchWorkspace: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'REPORTS' | 'R_CODE' | 'BOOKMARKS'>('R_CODE');
  const [copied, setCopied] = useState(false);

  const sampleRCode = `# ==============================================================================
# RHINOQUANT GLOBAL TRADE - PROPRIETARY R ANALYTICAL ENGINE
# File: R/trade_engine.R & R/gravity_model.R
# ==============================================================================

library(data.table)
library(dplyr)
library(fixest)
library(igraph)

#' Compute Revealed Comparative Advantage (RCA)
#' @param trade_df data.frame containing reporter, hs_code, export_val
compute_rca <- function(trade_df) {
  world_total <- sum(trade_df$export_val, na.rm = TRUE)
  world_by_hs <- trade_df %>%
    group_by(hs_code) %>%
    summarise(world_product_val = sum(export_val))
    
  country_totals <- trade_df %>%
    group_by(reporter) %>%
    summarise(country_total = sum(export_val))
    
  rca_df <- trade_df %>%
    inner_join(world_by_hs, by = "hs_code") %>%
    inner_join(country_totals, by = "reporter") %>%
    mutate(
      country_share = export_val / country_total,
      world_share = world_product_val / world_total,
      rca = country_share / world_share
    )
    
  return(rca_df)
}

#' Estimate Structural Gravity Model
#' @param bilateral_df data.frame containing trade_val, gdp_i, gdp_j, dist_ij, rta
estimate_gravity <- function(bilateral_df) {
  model <- feols(
    log(trade_val) ~ log(gdp_i) + log(gdp_j) - log(dist_ij) + contig + rta,
    data = bilateral_df,
    vcov = "HC1"
  )
  return(summary(model))
}

#' Calculate Systemic Network Centrality
#' @param edge_list data.frame of source, target, weight
compute_trade_network_centrality <- function(edge_list) {
  g <- graph_from_data_frame(edge_list, directed = TRUE)
  
  centrality_df <- data.frame(
    country = V(g)$name,
    degree = degree(g, mode = "all"),
    betweenness = betweenness(g, normalized = TRUE),
    eigenvector = eigen_centrality(g)$vector
  )
  
  return(centrality_df)
}
`;

  const copyCode = () => {
    navigator.clipboard.writeText(sampleRCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div>
          <h2 className="text-base font-bold font-mono text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-emerald-600" /> RHINO RESEARCH & REPRODUCIBLE R ENGINE EXPORTER
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Export institutional global trade research briefs, saved bookmarks, and reproducible pure R source code (`rhinoquant-global-trade/R/*.R`).
          </p>
        </div>

        {/* Sub Navigation */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={() => setActiveSubTab('R_CODE')}
            className={`px-3 py-1.5 rounded font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeSubTab === 'R_CODE' ? 'bg-emerald-700 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Code className="w-3.5 h-3.5" /> R SOURCE CODE
          </button>
          <button
            onClick={() => setActiveSubTab('REPORTS')}
            className={`px-3 py-1.5 rounded font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeSubTab === 'REPORTS' ? 'bg-emerald-700 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" /> INSTITUTIONAL REPORT
          </button>
        </div>
      </div>

      {activeSubTab === 'R_CODE' ? (
        <div className="bg-white border border-slate-200 rounded-lg p-5 font-mono shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <div>
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                R ANALYTICAL PACKAGE SOURCE CODE (`R/trade_engine.R`)
              </h3>
              <p className="text-[11px] text-slate-500">
                100% reproducible R functions for RCA, Structural Gravity estimation, and Network Centrality.
              </p>
            </div>

            <button
              onClick={copyCode}
              className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 px-3 py-1 rounded text-xs font-bold transition-all cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Copy className="w-3.5 h-3.5 text-slate-600" />}
              <span>{copied ? 'COPIED TO CLIPBOARD' : 'COPY R SCRIPT'}</span>
            </button>
          </div>

          <pre className="bg-slate-50 border border-slate-200 rounded p-4 text-xs font-mono text-slate-800 overflow-x-auto leading-relaxed">
            <code>{sampleRCode}</code>
          </pre>
        </div>
      ) : (
        /* Institutional Report Generator view */
        <div className="bg-white border border-slate-200 rounded-lg p-6 font-mono shadow-sm space-y-4">
          <div className="border-b border-slate-100 pb-3 flex justify-between items-center">
            <div>
              <span className="text-xs text-emerald-700 font-bold uppercase block">RHINOBANK INSTITUTIONAL RESEARCH BRIEF</span>
              <h1 className="text-xl font-bold text-slate-900">Global Trade Macro Outlook 2026</h1>
            </div>
            <button className="flex items-center gap-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-3 py-1.5 rounded text-xs transition-all shadow-xs cursor-pointer">
              <Download className="w-3.5 h-3.5" /> EXPORT PDF / MARKDOWN
            </button>
          </div>

          <div className="space-y-3 text-xs text-slate-700 leading-relaxed max-w-4xl">
            <p>
              <strong>Executive Summary:</strong> Global merchandise trade is expanding at an annualized rate of <strong>+4.5% YoY</strong>, reaching <strong>$32.4 Trillion</strong>. The global trading system continues to undergo structural reorientation, characterized by rapid growth in nearshoring corridors such as <strong>Mexico ↔ United States ($798.5B)</strong> and <strong>Vietnam ↔ United States ($142.8B)</strong>.
            </p>
            <p>
              <strong>Supply Chain Bottlenecks:</strong> Advanced Semiconductors (HS-85) and Rare Earth Oxides (HS-28) exhibit extreme supplier concentration (HHI &gt; 0.65), presenting strategic vulnerability to global technology manufacturing hubs in Taiwan, South Korea, and China.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
