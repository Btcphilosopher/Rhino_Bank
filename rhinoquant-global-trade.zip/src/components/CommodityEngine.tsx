import React, { useState } from 'react';
import { RHINO_COMMODITIES } from '../data/tradeData';
import { decomposePriceQuantity } from '../utils/tradeMath';
import { Layers, Flame, Zap, TrendingUp, TrendingDown, DollarSign, PieChart as PieChartIcon } from 'lucide-react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
} from 'recharts';

export const CommodityEngine: React.FC = () => {
  const [selectedCommodityId, setSelectedCommodityId] = useState<string>('brent-crude');

  const commodity = RHINO_COMMODITIES.find(c => c.id === selectedCommodityId) || RHINO_COMMODITIES[0];

  // Price x Quantity calculation demo
  const p0 = commodity.priceUSD * (1 - commodity.priceChangeYoY / 100);
  const q0 = commodity.globalExportVolume * 0.95;
  const pt = commodity.priceUSD;
  const qt = commodity.globalExportVolume;

  const decomp = decomposePriceQuantity(p0, q0, pt, qt);

  const pieData = [
    { name: 'Price Effect (% of Change)', value: commodity.priceEffectPct, color: '#10b981' },
    { name: 'Quantity Effect (% of Change)', value: commodity.quantityEffectPct, color: '#0284c7' },
  ];

  return (
    <div className="p-4 md:p-6 bg-[#F8FAFC] text-slate-900 font-sans space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <div>
          <h2 className="text-base font-bold font-mono text-slate-900 flex items-center gap-2">
            <Layers className="w-5 h-5 text-emerald-600" /> COMMODITY TRADE & PRICE-QUANTITY LINKAGE ENGINE
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Econometric price x volume decomposition of raw material exports, commodity terms of trade, and physical energy/mineral flows.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-500 font-bold">SELECT COMMODITY:</span>
          <select
            value={selectedCommodityId}
            onChange={(e) => setSelectedCommodityId(e.target.value)}
            className="bg-slate-50 border border-slate-200 text-slate-900 font-bold px-3 py-1.5 rounded focus:outline-none"
          >
            {RHINO_COMMODITIES.map(c => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.category})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Primary Key Stats Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">CURRENT SPOT PRICE</span>
          <span className="text-xl font-bold text-slate-900 mt-1 block">
            ${commodity.priceUSD.toLocaleString()} / {commodity.unit}
          </span>
          <span className={`text-[11px] mt-1 font-semibold flex items-center gap-1 ${commodity.priceChangeYoY >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
            {commodity.priceChangeYoY >= 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
            {commodity.priceChangeYoY}% YoY
          </span>
        </div>

        <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">GLOBAL EXPORT VOLUME</span>
          <span className="text-xl font-bold text-slate-900 mt-1 block">
            {commodity.globalExportVolume} M {commodity.unit}
          </span>
          <span className="text-[11px] text-slate-500 mt-1 block">Annualized Seaborne Flow</span>
        </div>

        <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">TOTAL TRADE VALUE</span>
          <span className="text-xl font-bold text-emerald-700 mt-1 block">
            ${commodity.globalExportValue} Billion
          </span>
          <span className="text-[11px] text-slate-500 mt-1 block">Global Revenue</span>
        </div>

        <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
          <span className="text-slate-500 uppercase text-[10px] font-bold block">DOMINANT EXPORTER BLOC</span>
          <span className="text-xl font-bold text-indigo-600 mt-1 block">
            {commodity.majorExporters.join(', ')}
          </span>
          <span className="text-[11px] text-slate-500 mt-1 block">Top Exporters</span>
        </div>
      </div>

      {/* Decomposition Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono">
        {/* Price vs Quantity Effect Decomposition */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm space-y-4">
          <div className="border-b border-slate-100 pb-2">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
              <Zap className="w-4 h-4 text-emerald-600" /> TRADE VALUE CHANGE DECOMPOSITION (PRICE vs VOLUME)
            </h3>
            <p className="text-xs text-slate-500">
              Econometric attribution of {commodity.name} export value fluctuations: Price Effect ($P \cdot \Delta Q$) vs Quantity Effect ($Q \cdot \Delta P$).
            </p>
          </div>

          <div className="h-56 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '6px', fontSize: '12px', fontFamily: 'monospace', color: '#0f172a', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
                  formatter={(val: any) => [`${val}%`, 'Effect Contribution']}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded border border-slate-200">
            <div>
              <span className="text-slate-500 uppercase text-[10px] font-bold block">PRICE EFFECT CONTRIBUTION</span>
              <span className="text-emerald-700 font-bold text-sm block">{commodity.priceEffectPct}%</span>
            </div>
            <div>
              <span className="text-slate-500 uppercase text-[10px] font-bold block">QUANTITY EFFECT CONTRIBUTION</span>
              <span className="text-cyan-700 font-bold text-sm block">{commodity.quantityEffectPct}%</span>
            </div>
          </div>
        </div>

        {/* Commodity Trading Blocs Matrix */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm space-y-4">
          <div className="border-b border-slate-100 pb-2">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">MAJOR COMMODITY SUPPLY & DEMAND HUBS</h3>
            <p className="text-xs text-slate-500">Key net exporting vs importing nations for {commodity.name}</p>
          </div>

          <div className="space-y-3 text-xs">
            <div className="bg-slate-50 p-3.5 rounded border border-slate-200">
              <span className="text-slate-500 text-[10px] uppercase font-bold block mb-1">MAJOR EXPORTING NATIONS:</span>
              <div className="flex flex-wrap gap-1.5">
                {commodity.majorExporters.map(code => (
                  <span key={code} className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded font-bold">
                    {code}
                  </span>
                ))}
              </div>
            </div>

            <div className="bg-slate-50 p-3.5 rounded border border-slate-200">
              <span className="text-slate-500 text-[10px] uppercase font-bold block mb-1">MAJOR IMPORTING NATIONS:</span>
              <div className="flex flex-wrap gap-1.5">
                {commodity.majorImporters.map(code => (
                  <span key={code} className="bg-slate-100 text-slate-800 border border-slate-200 px-2 py-0.5 rounded font-bold">
                    {code}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
