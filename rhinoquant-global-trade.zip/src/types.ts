/**
 * RhinoQuant Global Trade Engine Types
 */

export interface RhinoCountry {
  code: string; // ISO 3-letter e.g. "USA"
  name: string;
  flag: string;
  region: 'North America' | 'Europe' | 'Asia-Pacific' | 'Latin America' | 'Middle East' | 'Africa';
  gdp: number; // in USD Billions
  population: number; // Millions
  gdpPerCapita: number; // USD
  exports: number; // USD Billions
  imports: number; // USD Billions
  tradeBalance: number; // USD Billions
  tradeOpenness: number; // (Exports + Imports) / GDP * 100
  exportHHI: number; // 0 to 1
  importHHI: number; // 0 to 1
  rcaTopProducts: Array<{ hsCode: string; name: string; rca: number }>;
  termsOfTrade: number; // Base 100
  reer: number; // Real Effective Exchange Rate base 100
  tariffAverage: number; // %
  stressScore: number; // 0-100
}

export interface RhinoProduct {
  hsCode: string; // e.g., "HS-85"
  name: string;
  section: string;
  chapter: string;
  globalTradeValue: number; // USD Billions
  growthYoY: number; // %
  topExporters: Array<{ countryCode: string; share: number }>;
  topImporters: Array<{ countryCode: string; share: number }>;
  unitValueUSDPerKg: number;
  criticalCategory?: 'Energy' | 'Food' | 'Semiconductors' | 'Pharmaceuticals' | 'Rare Earths' | 'Machinery' | 'Metals' | 'Industrial Components';
  hhiConcentration: number;
}

export interface RhinoCommodity {
  id: string;
  name: string;
  category: 'Energy' | 'Metals' | 'Agriculture' | 'Tech Materials';
  unit: string; // e.g. "bbl", "MT", "oz"
  priceUSD: number;
  priceChangeYoY: number;
  globalExportVolume: number;
  globalExportValue: number;
  priceEffectPct: number;
  quantityEffectPct: number;
  majorExporters: string[];
  majorImporters: string[];
}

export interface RhinoTradeFlow {
  id: string;
  reporter: string; // ISO 3
  partner: string; // ISO 3
  year: number;
  quarter?: string;
  month?: number;
  hsCode: string;
  productName: string;
  exportValue: number; // USD Millions
  importValue: number; // USD Millions
  exportQty: number; // Metric Tons
  unitValue: number; // USD per ton
  transportMode: 'Sea' | 'Air' | 'Overland' | 'Pipeline';
  tariffRate: number; // %
}

export interface RhinoCorridor {
  countryA: string;
  countryB: string;
  totalTrade: number; // USD Billions
  exportAtoB: number;
  exportBtoA: number;
  balanceAtoB: number;
  growthYoY: number; // %
  topProducts: string[];
  distanceKm: number;
  tradeAgreement: string;
  hhi: number;
}

export interface RhinoSupplyChainNode {
  id: string;
  name: string;
  stage: 'Raw Material' | 'Intermediate Product' | 'Component' | 'Manufacturing' | 'Assembly' | 'Final Product';
  dominantCountry: string;
  supplierHHI: number;
  criticalGoodsShare: number; // %
  vulnerabilityIndex: number; // 0-100
  altSuppliers: string[];
}

export interface RhinoTariffSchedule {
  reporter: string;
  partner: string;
  hsCode: string;
  productName: string;
  statutoryRate: number; // %
  effectiveRate: number; // %
  weightedRate: number; // %
  tradeAgreementActive: boolean;
}

export interface RhinoNetworkNode {
  id: string; // Country code
  name: string;
  region: string;
  totalTrade: number;
  degreeCentrality: number;
  betweennessCentrality: number;
  eigenvectorCentrality: number;
  clusteringCoefficient: number;
}

export interface RhinoNetworkEdge {
  source: string;
  target: string;
  value: number; // Trade volume USD Billions
  weight: number;
}

export interface RhinoScenarioInput {
  tariffChangePct: number; // e.g. +10%
  oilPriceChangePct: number; // e.g. +25%
  fxDepreciationPct: number; // e.g. +15%
  shippingCostChangePct: number; // e.g. +50%
  supplierDisruptionPct: number; // e.g. -20%
  demandShockPct: number; // e.g. -10%
}

export interface RhinoScenarioOutput {
  tradeValueImpactPct: number;
  tradeVolumeImpactPct: number;
  globalPriceImpactPct: number;
  topCorridorRedirections: Array<{ corridor: string; originalValue: number; shockedValue: number }>;
  countryBalImpact: Array<{ country: string; origBal: number; newBal: number }>;
}

export interface RhinoGravityPoint {
  corridor: string;
  reporter: string;
  partner: string;
  actualTrade: number; // Billions
  predictedTrade: number; // Billions
  tradeGap: number; // Actual - Predicted
  gdpA: number;
  gdpB: number;
  distance: number;
  commonLanguage: boolean;
  contiguity: boolean;
  rta: boolean;
  residual: number;
}

export interface RhinoDataQualityAudit {
  missingValuePct: number;
  mirrorDiscrepancyPct: number;
  negativeQtyCount: number;
  staleRecordPct: number;
  unitValueAnomalyScore: number;
  overallScore: number; // 0 - 100
}

export interface RhinoScreenerResult {
  countryCode: string;
  countryName: string;
  exportGrowth: number;
  tradeOpenness: number;
  exportHHI: number;
  importDependency: number;
  tariffExposure: number;
  stressScore: number;
  matchesFilter: boolean;
}

export interface RhinoResearchBookmark {
  id: string;
  title: string;
  timestamp: string;
  category: string;
  notes: string;
  params: Record<string, any>;
}
