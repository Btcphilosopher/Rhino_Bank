'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useHumber } from '@/lib/humber-context';
import { 
  Anchor, 
  Search, 
  Briefcase, 
  Truck, 
  History, 
  FileText, 
  Info, 
  ShoppingCart, 
  X, 
  Plus, 
  Minus, 
  TrendingUp, 
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  Flame,
  Dribbble
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LayoutShellProps {
  children: React.ReactNode;
}

export default function LayoutShell({ children }: LayoutShellProps) {
  const pathname = usePathname();
  const router = useRouter();
  const { 
    products, 
    tickerProducts, 
    cart, 
    customer, 
    updateCartQty, 
    removeFromCart, 
    getPriceForQty, 
    placeOrder 
  } = useHumber();

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Cart calculations
  const cartItemKeys = Object.keys(cart);
  const totalCases = cartItemKeys.reduce((sum, key) => sum + cart[key], 0);
  
  const totalWeightKg = cartItemKeys.reduce((sum, key) => {
    const prod = products.find(p => p.id === key);
    if (!prod) return sum;
    return sum + (cart[key] * prod.caseWeightKg);
  }, 0);

  const cartSubtotal = cartItemKeys.reduce((sum, key) => {
    const prod = products.find(p => p.id === key);
    if (!prod) return sum;
    const itemWeight = cart[key] * prod.caseWeightKg;
    const pricePerKg = getPriceForQty(prod, itemWeight);
    return sum + (itemWeight * pricePerKg);
  }, 0);

  // Search results
  const filteredSearchProducts = searchQuery ? products.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.scientificName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.origin.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.traceabilityRef.toLowerCase().includes(searchQuery.toLowerCase())
  ) : [];

  const handlePlaceOrder = () => {
    const order = placeOrder();
    setIsCartOpen(false);
    router.push(`/delivery`);
  };

  return (
    <div className="flex flex-col min-h-screen text-slate-100 font-sans selection:bg-orange-600 selection:text-white">
      
      {/* SECTION CEILING / DISMISSIBLE TOP BANNER */}
      <div className="h-10 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-6 text-xs text-slate-400 font-mono overflow-hidden">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse shrink-0"></span>
            PORT OPERATIONS: ACTIVE
          </span>
          <span className="hidden md:inline text-slate-600">|</span>
          <span className="hidden md:inline">LAST LANDING: {products[0]?.vesselName || 'Polar Prince'}</span>
        </div>
        <div className="flex items-center gap-4 font-semibold text-orange-500">
          <span>NEXT BULK SHIPMENT CUT-OFF: 17:00 GMT</span>
        </div>
      </div>

      {/* TOP NAVIGATION BAR CONTRACT (Exhaustive 3-Zone Contract) */}
      <header className="sticky top-0 z-40 w-full bg-slate-950/90 backdrop-blur-md border-b border-slate-800 px-6 py-4 flex items-center justify-between">
        
        {/* Zone 1: Brand Wordmark (Single Text Element) */}
        <Link href="/" className="text-xl font-bold tracking-tight text-slate-100 hover:text-orange-500 transition-colors font-mono uppercase">
          HUMBER FISH
        </Link>

        {/* Zone 2: Navigation Links (4-6 links) */}
        <nav className="hidden lg:flex items-center gap-6 xl:gap-8 text-xs font-mono tracking-widest text-slate-400 uppercase">
          <Link 
            href="/shop" 
            className={`transition-colors hover:text-slate-100 hover:underline underline-offset-4 decoration-orange-500 ${pathname === '/shop' ? 'text-slate-100 underline decoration-2' : ''}`}
          >
            CATALOGUE
          </Link>
          <Link 
            href="/today" 
            className={`transition-colors hover:text-slate-100 hover:underline underline-offset-4 decoration-orange-500 ${pathname === '/today' ? 'text-slate-100 underline decoration-2' : ''}`}
          >
            TODAY'S MARKET
          </Link>
          <Link 
            href="/trace" 
            className={`transition-colors hover:text-slate-100 hover:underline underline-offset-4 decoration-orange-500 ${pathname.startsWith('/trace') ? 'text-slate-100 underline decoration-2' : ''}`}
          >
            TRACEABILITY
          </Link>
          <Link 
            href="/delivery" 
            className={`transition-colors hover:text-slate-100 hover:underline underline-offset-4 decoration-orange-500 ${pathname === '/delivery' ? 'text-slate-100 underline decoration-2' : ''}`}
          >
            LOGISTICS
          </Link>
          <Link 
            href="/trade" 
            className={`transition-colors hover:text-slate-100 hover:underline underline-offset-4 decoration-orange-500 ${pathname === '/trade' ? 'text-slate-100 underline decoration-2' : ''}`}
          >
            TRADE PORTAL
          </Link>
          <Link 
            href="/about" 
            className={`transition-colors hover:text-slate-100 hover:underline underline-offset-4 decoration-orange-500 ${pathname === '/about' ? 'text-slate-100 underline decoration-2' : ''}`}
          >
            ABOUT
          </Link>
        </nav>

        {/* Zone 3: Actions (1-2 primary actions) */}
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsSearchOpen(true)}
            className="p-2 text-slate-400 hover:text-slate-100 transition-colors rounded-md"
            aria-label="Search seafood directory"
          >
            <Search className="w-5 h-5" />
          </button>
          
          {/* Cart Indicator / Order Builder Opener */}
          <button 
            onClick={() => setIsCartOpen(true)}
            className="flex items-center gap-2 p-2 px-3 bg-slate-900 border border-slate-800 text-xs font-mono text-slate-200 hover:border-orange-500 hover:text-slate-100 transition-all rounded-md"
            aria-label="Open load builder"
          >
            <ShoppingCart className="w-4 h-4 text-orange-500" />
            <span className="hidden sm:inline">LOAD BUILDER</span>
            <span className="bg-orange-600 text-white font-semibold text-[10px] px-1.5 py-0.5 rounded tabular-nums shrink-0">
              {totalWeightKg > 0 ? `${totalWeightKg} KG` : 'EMPTY'}
            </span>
          </button>
        </div>
      </header>

      {/* LIVE CATCH / STOCK STRIP TICKER */}
      <div className="bg-slate-900/60 border-b border-slate-800 text-[11px] py-2 overflow-hidden whitespace-nowrap">
        <div className="flex select-none">
          {/* Repeated container to ensure continuous scrolling */}
          <div className="flex gap-16 items-center shrink-0 uppercase text-slate-400 font-mono tracking-wider animate-marquee">
            {tickerProducts.map(p => (
              <div key={`ticker-1-${p.id}`} className="flex items-center gap-2">
                <span className="text-slate-100 font-semibold">{p.name}</span>
                <span className="text-slate-600">/</span>
                <span className="text-orange-500 font-bold tabular-nums">£{p.basePricePerKg.toFixed(2)} / KG</span>
                <span className="text-slate-600">/</span>
                <span className="text-slate-300 tabular-nums font-semibold">{p.availableCases} CASES AVAILABLE</span>
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse"></span>
              </div>
            ))}
          </div>
          <div className="flex gap-16 items-center shrink-0 uppercase text-slate-400 font-mono tracking-wider animate-marquee">
            {tickerProducts.map(p => (
              <div key={`ticker-2-${p.id}`} className="flex items-center gap-2">
                <span className="text-slate-100 font-semibold">{p.name}</span>
                <span className="text-slate-600">/</span>
                <span className="text-orange-500 font-bold tabular-nums">£{p.basePricePerKg.toFixed(2)} / KG</span>
                <span className="text-slate-600">/</span>
                <span className="text-slate-300 tabular-nums font-semibold">{p.availableCases} CASES AVAILABLE</span>
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse"></span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 bg-slate-950 flex flex-col relative">
        {children}
      </main>

      {/* GLOBAL FOOTER */}
      <footer className="bg-slate-950 border-t border-slate-900 py-12 px-6 mt-auto">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 text-xs font-mono text-slate-400">
          <div className="flex flex-col gap-3">
            <span className="text-base font-bold text-slate-100 tracking-wider">HUMBER FISH</span>
            <p className="text-slate-500 uppercase leading-relaxed text-[11px]">
              Commercial Seafood Exchange & Logistics Facility.<br />
              Landed, Graded, Packed, Delivered.<br />
              Humber Estuary, Hull, UK.
            </p>
            <div className="mt-2 text-slate-600 text-[10px]">
              © {new Date().getFullYear()} HUMBER FISH LTD. ALL RIGHTS RESERVED.
            </div>
          </div>
          <div>
            <span className="text-slate-200 uppercase font-semibold block mb-3">PORT OPERATIONS</span>
            <ul className="space-y-2 text-[11px]">
              <li>DAILY LANDINGS INDEX: <span className="text-slate-200 font-semibold">05:42 - 12:00</span></li>
              <li>COMMERCIAL EXCHANGE DESK: <span className="text-slate-200 font-semibold">Net 30/60</span></li>
              <li>LOGISTICS FREQUENCY: <span className="text-slate-200 font-semibold">NEXT DAY DELIVERY</span></li>
              <li>COLD CHAIN COMPLIANCE: <span className="text-orange-500 font-semibold">BS EN 12830 / ISO 9001</span></li>
            </ul>
          </div>
          <div>
            <span className="text-slate-200 uppercase font-semibold block mb-3">EXCHANGE DIRECTORY</span>
            <ul className="space-y-2 text-[11px] uppercase">
              <li><Link href="/shop" className="hover:text-slate-200">B2B Product Catalogue</Link></li>
              <li><Link href="/today" className="hover:text-slate-200">Live Port Ticker Board</Link></li>
              <li><Link href="/trace" className="hover:text-slate-200">Seafood Traceability Ledger</Link></li>
              <li><Link href="/delivery" className="hover:text-slate-200">Logistics Track & Telemetry</Link></li>
            </ul>
          </div>
          <div>
            <span className="text-slate-200 uppercase font-semibold block mb-3">TRADE TERMS</span>
            <p className="text-slate-500 uppercase leading-relaxed text-[11px] mb-2">
              Supplying fishmongers, caterers, wholesalers, and institutional kitchens. Wholesale account registration required for contracted rates.
            </p>
            <div className="flex items-center gap-3 mt-4 text-slate-300">
              <span className="border border-slate-800 px-2 py-1 text-[10px] uppercase rounded">STRICT COLD CHAIN</span>
              <span className="border border-slate-800 px-2 py-1 text-[10px] uppercase rounded">B2B ONLY</span>
            </div>
          </div>
        </div>
      </footer>

      {/* GLOBAL ORDER BUILDER SLIDE-OVER DRAWER */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black/60 z-50 backdrop-blur-sm"
            />

            {/* Panel */}
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween', duration: 0.3 }}
              className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-slate-900 border-l border-slate-800 p-6 z-50 flex flex-col justify-between overflow-y-auto"
            >
              <div>
                <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                  <div className="flex flex-col">
                    <span className="text-sm font-semibold tracking-wider font-mono text-slate-400">HF // PROCUREMENT</span>
                    <h2 className="text-lg font-bold font-mono tracking-tight text-slate-100 uppercase">LOAD BUILDER</h2>
                  </div>
                  <button 
                    onClick={() => setIsCartOpen(false)}
                    className="p-1 text-slate-400 hover:text-slate-100 rounded-md"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Account details */}
                <div className="bg-slate-950 p-4 border border-slate-800 mb-6 flex flex-col gap-1 text-xs font-mono uppercase">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-500">CLIENT</span>
                    <span className="text-slate-300 text-right">{customer.companyName}</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-500">TIER RATE</span>
                    <span className="text-orange-500 font-semibold">{customer.tier} ({customer.tier === 'TRADE' ? '-10%' : customer.tier === 'WHOLESALE' ? '-20%' : customer.tier === 'CONTRACT' ? '-25%' : 'BASE'})</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-500">CREDIT AVAILABLE</span>
                    <span className="text-slate-300">£{(customer.creditLimit - customer.creditUsed).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                  </div>
                </div>

                {/* Cart Items List */}
                {cartItemKeys.length === 0 ? (
                  <div className="py-20 text-center font-mono">
                    <ShoppingCart className="w-10 h-10 text-slate-700 mx-auto mb-4" />
                    <p className="text-xs text-slate-500 uppercase">LOAD IS EMPTY.</p>
                    <p className="text-[10px] text-slate-600 uppercase mt-1">ADD CASES FROM CATALOGUE TO ASSEMBLE SHIPMENT.</p>
                  </div>
                ) : (
                  <div className="space-y-4 max-h-[45vh] overflow-y-auto pr-1">
                    {cartItemKeys.map(key => {
                      const prod = products.find(p => p.id === key);
                      if (!prod) return null;
                      const cases = cart[key];
                      const itemWeight = cases * prod.caseWeightKg;
                      const pricePerKg = getPriceForQty(prod, itemWeight);
                      const totalItemCost = itemWeight * pricePerKg;

                      return (
                        <div key={key} className="p-3 bg-slate-950 border border-slate-800 relative hover:border-slate-700 transition-colors">
                          <div className="flex justify-between font-mono">
                            <div>
                              <span className="text-xs font-bold text-slate-100">{prod.name}</span>
                              <div className="text-[10px] text-slate-400 uppercase mt-1">
                                {prod.form} / {prod.sizeRange}
                              </div>
                            </div>
                            <button 
                              onClick={() => removeFromCart(prod.id)}
                              className="text-[10px] text-red-500 hover:text-red-400 uppercase absolute top-3 right-3 font-semibold"
                            >
                              REMOVE
                            </button>
                          </div>

                          {/* Control row */}
                          <div className="mt-4 flex items-center justify-between font-mono">
                            <div className="flex items-center bg-slate-900 border border-slate-800 px-1 py-0.5 rounded">
                              <button 
                                onClick={() => updateCartQty(prod.id, cases - 1)}
                                className="p-1 hover:text-slate-100 text-slate-400"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="px-3 text-xs text-slate-200 font-semibold tabular-nums">
                                {cases}
                              </span>
                              <button 
                                onClick={() => updateCartQty(prod.id, cases + 1)}
                                className="p-1 hover:text-slate-100 text-slate-400"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            <div className="text-right text-[11px] uppercase">
                              <span className="text-slate-500 block text-[10px]">
                                {cases} CASES × {prod.caseWeightKg}KG = {itemWeight}KG
                              </span>
                              <span className="text-slate-300 tabular-nums">
                                £{pricePerKg.toFixed(2)}/KG
                              </span>
                              <span className="text-orange-500 block font-semibold tabular-nums mt-0.5">
                                £{totalItemCost.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Summary and CTAs */}
              {cartItemKeys.length > 0 && (
                <div className="border-t border-slate-800 pt-6 mt-6">
                  <div className="space-y-2 font-mono text-xs uppercase mb-6">
                    <div className="flex justify-between">
                      <span className="text-slate-500">TOTAL COMBINED WEIGHT</span>
                      <span className="text-slate-200 font-semibold tabular-nums">{totalWeightKg} KG</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">SUBTOTAL (ZERO-RATED VAT)</span>
                      <span className="text-slate-200 font-semibold tabular-nums">
                        £{cartSubtotal.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </div>
                    <div className="flex justify-between border-t border-slate-800 pt-2 text-sm">
                      <span className="text-slate-300 font-bold">ESTIMATED TOTAL</span>
                      <span className="text-orange-500 font-bold tabular-nums">
                        £{cartSubtotal.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <button 
                      onClick={handlePlaceOrder}
                      className="w-full py-3 bg-orange-600 hover:bg-orange-500 text-slate-100 text-xs font-mono font-bold tracking-widest uppercase transition-colors flex items-center justify-center gap-2 rounded-md"
                    >
                      <span>PLACE B2B EXCHANGE ORDER</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => {
                        alert(`Quote Request Sent to Grimsby Logistics Coordinator for ${totalWeightKg} KG Load.`);
                        setIsCartOpen(false);
                      }}
                      className="w-full py-3 border border-slate-700 hover:border-slate-500 text-slate-300 text-xs font-mono uppercase tracking-wider transition-colors rounded-md"
                    >
                      REQUEST SPOT QUOTE
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* SEARCH SYSTEM DIALOG/OVERLAY */}
      <AnimatePresence>
        {isSearchOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-950/95 z-50 p-6 flex flex-col"
          >
            <div className="max-w-4xl mx-auto w-full flex-1 flex flex-col">
              
              {/* Header */}
              <div className="flex justify-between items-center border-b border-slate-800 pb-4 mb-8">
                <span className="font-mono text-xs tracking-wider text-slate-500 uppercase">HUMBER SEAFOOD DIRECTORY SEARCH</span>
                <button 
                  onClick={() => {
                    setIsSearchOpen(false);
                    setSearchQuery('');
                  }}
                  className="p-2 text-slate-400 hover:text-slate-100 transition-colors border border-slate-800 hover:border-slate-600 font-mono text-[10px] uppercase rounded-md"
                >
                  [CLOSE SEARCH]
                </button>
              </div>

              {/* Main input */}
              <div className="relative mb-8">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-6 h-6 text-slate-500" />
                <input 
                  type="text"
                  placeholder="SEARCH SPECIES, SCIENTIFIC NAME, VESSEL, ORIGIN, OR BATCH ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-900 border-2 border-slate-800 focus:border-orange-500 focus:outline-none p-4 pl-14 font-mono text-base uppercase placeholder-slate-600 text-slate-100 rounded-lg tracking-wider"
                  autoFocus
                />
              </div>

              {/* Results */}
              <div className="flex-1 overflow-y-auto">
                {!searchQuery ? (
                  <div className="py-12">
                    <span className="font-mono text-xs text-slate-500 uppercase tracking-widest block mb-4">RECOMMENDED SEARCH DIRECTORIES</span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 font-mono text-xs">
                      {['North Sea Cod', 'Haddock Fillets', 'Bridlington Crab', 'Grimsby Smoked', 'BATCH-CD-048-A', 'FV Polar Prince'].map(item => (
                        <button 
                          key={item}
                          onClick={() => setSearchQuery(item)}
                          className="p-3 bg-slate-900/60 border border-slate-800 hover:border-orange-500 text-slate-300 hover:text-slate-100 text-left uppercase transition-colors rounded"
                        >
                          → {item}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : filteredSearchProducts.length === 0 ? (
                  <div className="text-center py-20 font-mono">
                    <p className="text-sm text-slate-500 uppercase">NO EXCHANGE DATA RECONCILED FOR "{searchQuery.toUpperCase()}"</p>
                    <p className="text-xs text-slate-600 uppercase mt-2">CHECK SPELLING OR TRY SEARCHING SPECIES CODES DIRECTLY (E.G. COD, HADDOCK, BATCH-CD)</p>
                  </div>
                ) : (
                  <div>
                    <span className="font-mono text-xs text-slate-500 uppercase block mb-4 tabular-nums">
                      {filteredSearchProducts.length} RECORDS FOUND
                    </span>
                    <div className="space-y-4">
                      {filteredSearchProducts.map(p => (
                        <div 
                          key={p.id}
                          onClick={() => {
                            router.push(`/shop`);
                            setIsSearchOpen(false);
                            setSearchQuery('');
                          }}
                          className="p-4 bg-slate-900/40 border border-slate-800 hover:border-orange-500 transition-all cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4"
                        >
                          <div className="font-mono">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold text-slate-100 uppercase">{p.name}</span>
                              <span className="text-slate-600 text-xs">·</span>
                              <span className="text-[10px] text-slate-400 italic font-normal lowercase">{p.scientificName}</span>
                            </div>
                            <div className="text-[11px] text-slate-400 uppercase mt-1">
                              Origin: {p.origin} · Landing: {p.landingLocation} · Vessel: {p.vesselName}
                            </div>
                            <div className="text-[10px] text-slate-500 uppercase mt-0.5">
                              BATCH REF: {p.traceabilityRef} · CATCH METHOD: {p.catchMethod}
                            </div>
                          </div>
                          
                          <div className="text-right font-mono flex items-center md:flex-col justify-between md:justify-center gap-4 shrink-0">
                            <span className="text-sm font-bold text-orange-500 tabular-nums">
                              £{p.basePricePerKg.toFixed(2)} / KG
                            </span>
                            <span className="px-2 py-0.5 border border-slate-800 text-[10px] text-slate-300 uppercase rounded">
                              {p.availableCases} Cases
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
