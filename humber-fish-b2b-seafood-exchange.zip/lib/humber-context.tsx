'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Product type representing B2B seafood commercial records
export interface Product {
  id: string;
  name: string;
  scientificName: string;
  origin: string;
  landingLocation: string;
  grade: 'A' | 'B';
  sizeRange: string;
  form: string;
  basePricePerKg: number;
  availableCases: number;
  caseWeightKg: number; // typically 5kg or 10kg
  faoArea: string;
  catchMethod: string;
  shelfLifeDays: number;
  allergenInfo: string;
  traceabilityRef: string;
  image?: string;
  vesselName: string;
}

// Order item structure
export interface OrderItem {
  productId: string;
  quantityCases: number;
  pricePerKgAtOrder: number;
}

// B2B Customer Trade Account Tiers
export type CustomerTier = 'STANDARD' | 'TRADE' | 'WHOLESALE' | 'CONTRACT';

export interface TradeAccount {
  companyName: string;
  contactName: string;
  email: string;
  accountNumber: string;
  tier: CustomerTier;
  creditLimit: number;
  creditUsed: number;
  terms: string; // e.g. "Net 30"
  deliveryAddress: string;
}

// Delivery tracking timeline stages
export type DeliveryStage = 'ORDER_CONFIRMED' | 'PACKING' | 'COLD_STORAGE' | 'DISPATCHED' | 'IN_TRANSIT' | 'DELIVERED';

export interface DeliveryTracker {
  id: string;
  orderId: string;
  stage: DeliveryStage;
  vehicleReg: string;
  temperatureCelsius: number;
  tempStatus: 'STABLE' | 'WARNING' | 'CRITICAL';
  estimatedDeliveryWindow: string;
  destination: string;
  weightKg: number;
  operator: string;
  stagesLog: { stage: DeliveryStage; timestamp: string; note: string }[];
}

export interface Order {
  id: string;
  date: string;
  items: OrderItem[];
  totalWeightKg: number;
  subtotal: number;
  vat: number;
  total: number;
  status: 'PENDING' | 'CONFIRMED' | 'DISPATCHED' | 'DELIVERED' | 'CANCELLED';
  deliveryTracker?: DeliveryTracker;
}

export interface Invoice {
  id: string;
  orderId: string;
  invoiceDate: string;
  dueDate: string;
  subtotal: number;
  vat: number;
  total: number;
  status: 'PAID' | 'UNPAID' | 'OVERDUE';
}

export interface LandingEvent {
  id: string;
  timestamp: string;
  vessel: string;
  species: string;
  cases: number;
  port: 'HULL DOCKS' | 'GRIMSBY DOCKS' | 'BRIDLINGTON HARBOUR';
  grade: 'A' | 'B';
}

// Traceability Event sequence
export interface TraceabilityEvent {
  stage: string;
  location: string;
  timestamp: string;
  operator: string;
  batchId: string;
  description: string;
  tempCelsius?: number;
}

interface HumberContextType {
  products: Product[];
  tickerProducts: Product[]; // dedicated slow animated changes
  landings: LandingEvent[];
  cart: { [productId: string]: number }; // productId -> quantity cases
  customer: TradeAccount;
  orders: Order[];
  invoices: Invoice[];
  activeDelivery: DeliveryTracker | null;
  addToCart: (productId: string, cases: number) => void;
  updateCartQty: (productId: string, cases: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  placeOrder: (notes?: string) => Order;
  reorderAll: (orderId: string) => void;
  setCustomerTier: (tier: CustomerTier) => void;
  getDiscountedPrice: (product: Product) => number;
  getPriceForQty: (product: Product, totalKg: number) => number;
  traceBatch: (batchId: string) => TraceabilityEvent[];
}

const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'cod-northsea-01',
    name: 'North Sea Cod',
    scientificName: 'Gadus morhua',
    origin: 'North Sea (Subarea 4)',
    landingLocation: 'Hull Docks, UK',
    grade: 'A',
    sizeRange: '3–5 kg',
    form: 'Fillets / Skinless',
    basePricePerKg: 8.90,
    availableCases: 148,
    caseWeightKg: 5,
    faoArea: 'FAO 27 (Atlantic, Northeast)',
    catchMethod: 'Demersal Otter Trawl',
    shelfLifeDays: 8,
    allergenInfo: 'Fish',
    traceabilityRef: 'BATCH-CD-048-A',
    vesselName: 'FV Polar Prince',
  },
  {
    id: 'haddock-humber-02',
    name: 'Humber Haddock',
    scientificName: 'Melanogrammus aeglefinus',
    origin: 'North Sea (Fladen Ground)',
    landingLocation: 'Grimsby Docks, UK',
    grade: 'A',
    sizeRange: '1–2 kg',
    form: 'Fillets / Skin-on',
    basePricePerKg: 9.80,
    availableCases: 184,
    caseWeightKg: 5,
    faoArea: 'FAO 27',
    catchMethod: 'Single Seine Net',
    shelfLifeDays: 7,
    allergenInfo: 'Fish',
    traceabilityRef: 'BATCH-HD-112-A',
    vesselName: 'FV Northern Spirit',
  },
  {
    id: 'smoked-haddock-03',
    name: 'Grimsby Smoked Haddock',
    scientificName: 'Melanogrammus aeglefinus',
    origin: 'North Sea / Processed Hull',
    landingLocation: 'Humber Facility, Hull',
    grade: 'A',
    sizeRange: '500g–1kg',
    form: 'Cold Smoked Fillets (Undyed)',
    basePricePerKg: 12.40,
    availableCases: 61,
    caseWeightKg: 5,
    faoArea: 'FAO 27',
    catchMethod: 'Traditional Oak-Smokehouse',
    shelfLifeDays: 10,
    allergenInfo: 'Fish',
    traceabilityRef: 'BATCH-SH-053-S',
    vesselName: 'FV Grimsby Crest',
  },
  {
    id: 'plaice-flamborough-04',
    name: 'Flamborough Plaice',
    scientificName: 'Pleuronectes platessa',
    origin: 'Humber Estuary Waters',
    landingLocation: 'Bridlington Harbour, UK',
    grade: 'A',
    sizeRange: '600g–1kg',
    form: 'Whole / Gutted',
    basePricePerKg: 7.50,
    availableCases: 76,
    caseWeightKg: 10,
    faoArea: 'FAO 27',
    catchMethod: 'Beam Trawl',
    shelfLifeDays: 6,
    allergenInfo: 'Fish',
    traceabilityRef: 'BATCH-PL-224-A',
    vesselName: 'FV Galtis',
  },
  {
    id: 'mackerel-northsea-05',
    name: 'North Sea Mackerel',
    scientificName: 'Scomber scombrus',
    origin: 'Northern North Sea',
    landingLocation: 'Hull Docks, UK',
    grade: 'A',
    sizeRange: '300g–500g',
    form: 'Whole',
    basePricePerKg: 5.20,
    availableCases: 212,
    caseWeightKg: 10,
    faoArea: 'FAO 27',
    catchMethod: 'Pelagic Trawl',
    shelfLifeDays: 5,
    allergenInfo: 'Fish',
    traceabilityRef: 'BATCH-MK-909-B',
    vesselName: 'FV Polar Prince',
  },
  {
    id: 'sole-humber-06',
    name: 'Humber Estuary Sole',
    scientificName: 'Solea solea',
    origin: 'Southern North Sea',
    landingLocation: 'Grimsby Docks, UK',
    grade: 'A',
    sizeRange: '400g–800g',
    form: 'Fillets / Skinless',
    basePricePerKg: 16.50,
    availableCases: 43,
    caseWeightKg: 5,
    faoArea: 'FAO 27',
    catchMethod: 'Demersal Trawl',
    shelfLifeDays: 7,
    allergenInfo: 'Fish',
    traceabilityRef: 'BATCH-SL-302-A',
    vesselName: 'FV Northern Spirit',
  },
  {
    id: 'crab-bridlington-07',
    name: 'Bridlington Brown Crab',
    scientificName: 'Cancer pagurus',
    origin: 'Yorkshire Coast Reefs',
    landingLocation: 'Bridlington Harbour, UK',
    grade: 'A',
    sizeRange: '1–2 kg',
    form: 'Whole Cooked / Chilled',
    basePricePerKg: 11.20,
    availableCases: 38,
    caseWeightKg: 5,
    faoArea: 'FAO 27.4',
    catchMethod: 'Pot / Creel',
    shelfLifeDays: 5,
    allergenInfo: 'Crustaceans',
    traceabilityRef: 'BATCH-CR-774-C',
    vesselName: 'FV Sovereign',
  },
  {
    id: 'lemonsole-northsea-08',
    name: 'North Sea Lemon Sole',
    scientificName: 'Microstomus kitt',
    origin: 'Central North Sea',
    landingLocation: 'Hull Docks, UK',
    grade: 'A',
    sizeRange: '500g–1kg',
    form: 'Fillets / Skin-on',
    basePricePerKg: 14.80,
    availableCases: 54,
    caseWeightKg: 5,
    faoArea: 'FAO 27',
    catchMethod: 'Otter Trawl',
    shelfLifeDays: 7,
    allergenInfo: 'Fish',
    traceabilityRef: 'BATCH-LS-190-A',
    vesselName: 'FV Grimsby Crest',
  },
  {
    id: 'herring-whitby-09',
    name: 'Whitby Herring',
    scientificName: 'Clupea harengus',
    origin: 'Dogger Bank Waters',
    landingLocation: 'Grimsby Docks, UK',
    grade: 'B',
    sizeRange: '200g–300g',
    form: 'Whole / Round',
    basePricePerKg: 4.10,
    availableCases: 115,
    caseWeightKg: 10,
    faoArea: 'FAO 27.4.b',
    catchMethod: 'Purse Seine',
    shelfLifeDays: 6,
    allergenInfo: 'Fish',
    traceabilityRef: 'BATCH-HR-003-B',
    vesselName: 'FV Galtis',
  }
];

const INITIAL_LANDINGS: LandingEvent[] = [
  { id: 'lnd-1', timestamp: '05:42', vessel: 'FV Polar Prince', species: 'North Sea Cod', cases: 42, port: 'HULL DOCKS', grade: 'A' },
  { id: 'lnd-2', timestamp: '06:15', vessel: 'FV Northern Spirit', species: 'Humber Haddock', cases: 65, port: 'GRIMSBY DOCKS', grade: 'A' },
  { id: 'lnd-3', timestamp: '07:30', vessel: 'FV Galtis', species: 'Flamborough Plaice', cases: 28, port: 'BRIDLINGTON HARBOUR', grade: 'A' },
  { id: 'lnd-4', timestamp: '08:12', vessel: 'FV Sovereign', species: 'Bridlington Crab', cases: 18, port: 'BRIDLINGTON HARBOUR', grade: 'A' },
  { id: 'lnd-5', timestamp: '09:05', vessel: 'FV Grimsby Crest', species: 'North Sea Lemon Sole', cases: 22, port: 'HULL DOCKS', grade: 'A' }
];

const HumberContext = createContext<HumberContextType | undefined>(undefined);

export function HumberProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [tickerProducts, setTickerProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [landings, setLandings] = useState<LandingEvent[]>(INITIAL_LANDINGS);
  const [cart, setCart] = useState<{ [productId: string]: number }>({});
  
  const [customer, setCustomer] = useState<TradeAccount>({
    companyName: 'Northern Caterers Ltd',
    contactName: 'Tom Harrison',
    email: 'tom@ahyx.org',
    accountNumber: 'HF-89024-X',
    tier: 'TRADE',
    creditLimit: 15000,
    creditUsed: 4235.80,
    terms: 'Net 30',
    deliveryAddress: 'Unit B4, Dockside Trading Estate, Hull, HU9 1TD'
  });

  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'ORD-9842',
      date: '2026-09-22',
      items: [
        { productId: 'cod-northsea-01', quantityCases: 8, pricePerKgAtOrder: 8.90 },
        { productId: 'haddock-humber-02', quantityCases: 5, pricePerKgAtOrder: 9.80 }
      ],
      totalWeightKg: 65,
      subtotal: 588.00,
      vat: 0.00, // Zero-rated seafood in UK
      total: 588.00,
      status: 'DELIVERED',
      deliveryTracker: {
        id: 'TRK-9842',
        orderId: 'ORD-9842',
        stage: 'DELIVERED',
        vehicleReg: 'HU26 FSO',
        temperatureCelsius: 1.6,
        tempStatus: 'STABLE',
        estimatedDeliveryWindow: '2026-09-23 08:30 - 10:30',
        destination: 'Unit B4, Dockside Trading Estate, Hull, HU9 1TD',
        weightKg: 65,
        operator: 'J. Patterson (Cold Logistics)',
        stagesLog: [
          { stage: 'ORDER_CONFIRMED', timestamp: '2026-09-22 15:40', note: 'Procurement confirmed by Northern Caterers' },
          { stage: 'PACKING', timestamp: '2026-09-22 17:30', note: 'Packed at Humber Cold Facility, Temp: +1.2°C' },
          { stage: 'COLD_STORAGE', timestamp: '2026-09-22 19:15', note: 'Stored in Cold Room #3, Temp: +1.5°C' },
          { stage: 'DISPATCHED', timestamp: '2026-09-23 04:30', note: 'Loaded onto refrigerated truck vehicle HU26 FSO' },
          { stage: 'IN_TRANSIT', timestamp: '2026-09-23 06:15', note: 'In transit via A1033. Telemetry active.' },
          { stage: 'DELIVERED', timestamp: '2026-09-23 09:12', note: 'Delivered and verified by client. Core temp: +1.6°C' }
        ]
      }
    },
    {
      id: 'ORD-9751',
      date: '2026-09-15',
      items: [
        { productId: 'plaice-flamborough-04', quantityCases: 4, pricePerKgAtOrder: 7.50 },
        { productId: 'mackerel-northsea-05', quantityCases: 10, pricePerKgAtOrder: 5.20 }
      ],
      totalWeightKg: 140,
      subtotal: 820.00,
      vat: 0.00,
      total: 820.00,
      status: 'DELIVERED',
      deliveryTracker: {
        id: 'TRK-9751',
        orderId: 'ORD-9751',
        stage: 'DELIVERED',
        vehicleReg: 'HU26 FRZ',
        temperatureCelsius: 1.9,
        tempStatus: 'STABLE',
        estimatedDeliveryWindow: '2026-09-16 09:00 - 11:00',
        destination: 'Unit B4, Dockside Trading Estate, Hull, HU9 1TD',
        weightKg: 140,
        operator: 'D. Grealish (Logistics)',
        stagesLog: [
          { stage: 'ORDER_CONFIRMED', timestamp: '2026-09-15 11:15', note: 'Order Confirmed' },
          { stage: 'PACKING', timestamp: '2026-09-15 14:00', note: 'Port grading completed' },
          { stage: 'COLD_STORAGE', timestamp: '2026-09-15 16:30', note: 'Cold room hold' },
          { stage: 'DISPATCHED', timestamp: '2026-09-16 05:00', note: 'Dispatched on vehicle HU26 FRZ' },
          { stage: 'IN_TRANSIT', timestamp: '2026-09-16 07:45', note: 'En route' },
          { stage: 'DELIVERED', timestamp: '2026-09-16 09:55', note: 'Delivered and signed.' }
        ]
      }
    }
  ]);

  const [invoices, setInvoices] = useState<Invoice[]>([
    { id: 'INV-9842', orderId: 'ORD-9842', invoiceDate: '2026-09-23', dueDate: '2026-10-23', subtotal: 588.00, vat: 0.00, total: 588.00, status: 'PAID' },
    { id: 'INV-9751', orderId: 'ORD-9751', invoiceDate: '2026-09-16', dueDate: '2026-10-16', subtotal: 820.00, vat: 0.00, total: 820.00, status: 'PAID' }
  ]);

  const [activeDelivery, setActiveDelivery] = useState<DeliveryTracker | null>(null);

  // Deterministic live simulator for B2B market prices & inventory levels
  useEffect(() => {
    const interval = setInterval(() => {
      // 1. Slowly update product price/stocks slightly to simulate a living exchange board
      setProducts(prevProducts => {
        return prevProducts.map(product => {
          // Slight price fluctuation (between -2p and +3p)
          const priceChange = (Math.random() - 0.4) * 0.06;
          const newBasePrice = parseFloat(Math.max(2.0, product.basePricePerKg + priceChange).toFixed(2));
          
          // Slight stock change: occasionally small sales depletion, occasionally fresh landings
          let stockChange = 0;
          const rand = Math.random();
          if (rand > 0.85) {
            stockChange = -Math.floor(Math.random() * 3) - 1; // deplete 1-3 cases
          } else if (rand < 0.08) {
            stockChange = Math.floor(Math.random() * 5) + 3; // add 3-8 cases from fresh landings
          }
          
          const newAvailableCases = Math.max(5, product.availableCases + stockChange);
          
          return {
            ...product,
            basePricePerKg: newBasePrice,
            availableCases: newAvailableCases
          };
        });
      });

      // Flashing ticker list behaves similarly but independent to keep elements dynamic
      setTickerProducts(prevTicker => {
        return prevTicker.map(p => {
          const change = (Math.random() - 0.5) * 0.04;
          return {
            ...p,
            basePricePerKg: parseFloat(Math.max(2.0, p.basePricePerKg + change).toFixed(2))
          };
        });
      });

      // 2. Occasionally add a fresh landing event
      const portNames: ('HULL DOCKS' | 'GRIMSBY DOCKS' | 'BRIDLINGTON HARBOUR')[] = ['HULL DOCKS', 'GRIMSBY DOCKS', 'BRIDLINGTON HARBOUR'];
      if (Math.random() > 0.92) {
        setLandings(prevLandings => {
          const randomProduct = INITIAL_PRODUCTS[Math.floor(Math.random() * INITIAL_PRODUCTS.length)];
          const randomPort = portNames[Math.floor(Math.random() * portNames.length)];
          const now = new Date();
          const hour = String(now.getHours()).padStart(2, '0');
          const min = String(now.getMinutes()).padStart(2, '0');
          
          const newLanding: LandingEvent = {
            id: `lnd-${Date.now()}`,
            timestamp: `${hour}:${min}`,
            vessel: randomProduct.vesselName,
            species: randomProduct.name,
            cases: Math.floor(Math.random() * 30) + 10,
            port: randomPort,
            grade: Math.random() > 0.15 ? 'A' : 'B'
          };
          // Keep max 8 landings
          return [newLanding, ...prevLandings.slice(0, 7)];
        });
      }

      // 3. Update temperature readings on active delivery tracker to simulate real-time cold chain telemetry
      setActiveDelivery(prevTracker => {
        if (!prevTracker || prevTracker.stage === 'DELIVERED') return prevTracker;
        
        // Minor fluctuation
        const tempChange = (Math.random() - 0.5) * 0.2;
        const newTemp = parseFloat(Math.max(0.5, Math.min(3.5, prevTracker.temperatureCelsius + tempChange)).toFixed(1));
        const status = newTemp > 2.8 ? 'WARNING' : newTemp > 3.2 ? 'CRITICAL' : 'STABLE';
        
        return {
          ...prevTracker,
          temperatureCelsius: newTemp,
          tempStatus: status
        };
      });

      // Same updates for any active orders containing a delivery tracker
      setOrders(prevOrders => {
        return prevOrders.map(order => {
          if (!order.deliveryTracker || order.status === 'DELIVERED') return order;
          const trk = order.deliveryTracker;
          const tempChange = (Math.random() - 0.5) * 0.2;
          const newTemp = parseFloat(Math.max(0.5, Math.min(3.5, trk.temperatureCelsius + tempChange)).toFixed(1));
          const status = newTemp > 2.8 ? 'WARNING' : newTemp > 3.2 ? 'CRITICAL' : 'STABLE';
          
          return {
            ...order,
            deliveryTracker: {
              ...trk,
              temperatureCelsius: newTemp,
              tempStatus: status
            }
          };
        });
      });

    }, 6000); // every 6 seconds

    return () => clearInterval(interval);
  }, []);

  // Price strategies based on tier
  const getDiscountedPrice = (product: Product): number => {
    let multiplier = 1.0;
    switch (customer.tier) {
      case 'TRADE': multiplier = 0.90; break;     // 10% off
      case 'WHOLESALE': multiplier = 0.80; break; // 20% off
      case 'CONTRACT': multiplier = 0.75; break;  // 25% off
      case 'STANDARD':
      default: multiplier = 1.0;
    }
    return parseFloat((product.basePricePerKg * multiplier).toFixed(2));
  };

  // Pricing interface with quantity tiers: e.g. 5kg, 20kg (4 cases), 50kg (10 cases), 100kg (20 cases)
  const getPriceForQty = (product: Product, totalKg: number): number => {
    const discountedBase = getDiscountedPrice(product);
    let qtyDiscountMultiplier = 1.0;
    
    if (totalKg >= 100) {
      qtyDiscountMultiplier = 0.90; // extra 10% off for 100kg+ bulk
    } else if (totalKg >= 50) {
      qtyDiscountMultiplier = 0.95; // extra 5% off for 50kg+ bulk
    } else if (totalKg >= 20) {
      qtyDiscountMultiplier = 0.98; // extra 2% off for 20kg+ bulk
    }
    
    return parseFloat((discountedBase * qtyDiscountMultiplier).toFixed(2));
  };

  const addToCart = (productId: string, cases: number) => {
    setCart(prev => ({
      ...prev,
      [productId]: (prev[productId] || 0) + cases
    }));
  };

  const updateCartQty = (productId: string, cases: number) => {
    if (cases <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev => ({
      ...prev,
      [productId]: cases
    }));
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => {
      const copy = { ...prev };
      delete copy[productId];
      return copy;
    });
  };

  const clearCart = () => setCart({});

  const placeOrder = (notes?: string) => {
    const orderId = `ORD-${Math.floor(1000 + Math.random() * 9000)}`;
    const nowStr = new Date().toISOString().split('T')[0];
    
    let totalWeight = 0;
    let orderSubtotal = 0;
    
    const items: OrderItem[] = Object.keys(cart).map(pId => {
      const prod = products.find(p => p.id === pId)!;
      const cases = cart[pId];
      const itemWeight = cases * prod.caseWeightKg;
      const pricePerKg = getPriceForQty(prod, itemWeight);
      
      totalWeight += itemWeight;
      orderSubtotal += itemWeight * pricePerKg;
      
      return {
        productId: pId,
        quantityCases: cases,
        pricePerKgAtOrder: pricePerKg
      };
    });

    const vat = 0.0; // Food products zero-rated in UK
    const totalVal = orderSubtotal + vat;

    const deliveryTrackerId = `TRK-${Math.floor(1000 + Math.random() * 9000)}`;
    
    // Create modern delivery tracking screen record
    const newDeliveryTracker: DeliveryTracker = {
      id: deliveryTrackerId,
      orderId: orderId,
      stage: 'ORDER_CONFIRMED',
      vehicleReg: 'HU26 FS' + String.fromCharCode(65 + Math.floor(Math.random() * 26)) + String.fromCharCode(65 + Math.floor(Math.random() * 26)),
      temperatureCelsius: 1.8,
      tempStatus: 'STABLE',
      estimatedDeliveryWindow: 'Next-day shipment (tomorrow 08:00 - 12:00)',
      destination: customer.deliveryAddress,
      weightKg: totalWeight,
      operator: 'R. Sissons (Grimsby Logistics)',
      stagesLog: [
        { stage: 'ORDER_CONFIRMED', timestamp: `${nowStr} 13:20`, note: 'Procurement order built and processed.' },
        { stage: 'PACKING', timestamp: `${nowStr} 14:10`, note: 'Cold-room packing schedule initialized.' }
      ]
    };

    const newOrder: Order = {
      id: orderId,
      date: nowStr,
      items: items,
      totalWeightKg: totalWeight,
      subtotal: parseFloat(orderSubtotal.toFixed(2)),
      vat: vat,
      total: parseFloat(totalVal.toFixed(2)),
      status: 'CONFIRMED',
      deliveryTracker: newDeliveryTracker
    };

    const newInvoice: Invoice = {
      id: `INV-${orderId.substring(4)}`,
      orderId: orderId,
      invoiceDate: nowStr,
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // Net 30
      subtotal: newOrder.subtotal,
      vat: vat,
      total: newOrder.total,
      status: 'UNPAID'
    };

    setOrders(prev => [newOrder, ...prev]);
    setInvoices(prev => [newInvoice, ...prev]);
    setActiveDelivery(newDeliveryTracker);
    setCart({}); // clear cart

    // update credit usage
    setCustomer(prev => ({
      ...prev,
      creditUsed: parseFloat((prev.creditUsed + totalVal).toFixed(2))
    }));

    // Trigger synthetic delivery sequence simulation
    setTimeout(() => {
      setOrders(prev => prev.map(o => {
        if (o.id !== orderId) return o;
        const updatedTracker = { ...o.deliveryTracker! };
        updatedTracker.stage = 'PACKING';
        updatedTracker.stagesLog.push({
          stage: 'PACKING',
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
          note: 'Box packing and sorting complete. Core product graded A.'
        });
        return { ...o, status: 'CONFIRMED', deliveryTracker: updatedTracker };
      }));
    }, 20000);

    return newOrder;
  };

  const reorderAll = (orderId: string) => {
    const historicalOrder = orders.find(o => o.id === orderId);
    if (!historicalOrder) return;
    
    const newCart: { [pId: string]: number } = {};
    historicalOrder.items.forEach(item => {
      newCart[item.productId] = item.quantityCases;
    });
    setCart(newCart);
  };

  const setCustomerTier = (tier: CustomerTier) => {
    setCustomer(prev => ({
      ...prev,
      tier: tier
    }));
  };

  // Traceability timelines mapping
  const traceBatch = (batchId: string): TraceabilityEvent[] => {
    const defaultBatch = [
      { stage: 'SEA', location: 'Dogger Bank, North Sea (FAO 27.4.b)', timestamp: '2026-09-21 02:45', operator: 'Vessel Crew - Polar Prince', batchId, description: 'Harvested cod school, average core temp on catch -0.5°C.', tempCelsius: -0.5 },
      { stage: 'LANDING', location: 'Albert Dock, Hull', timestamp: '2026-09-22 05:15', operator: 'A. Miller (Port Lead)', batchId, description: 'Landed at commercial quay. Verified weight: 1.2 tonnes.', tempCelsius: 1.1 },
      { stage: 'HUMBER FACILITY', location: 'Humber Processing Plant #2, Hull', timestamp: '2026-09-22 06:40', operator: 'S. Jenkins (Quality Assurance)', batchId, description: 'Offloaded to cold intake. Checked for freshness, rigor state: High quality grade A.', tempCelsius: 1.4 },
      { stage: 'PROCESSING', location: 'Humber Processing Plant #2, Hull', timestamp: '2026-09-22 08:15', operator: 'H. Thompson (Grade Team B)', batchId, description: 'Deboned, filleted, and portioned on sterile stainless steel line.', tempCelsius: 1.8 },
      { stage: 'PACKING', location: 'Logistics Bay 4, Hull', timestamp: '2026-09-22 10:30', operator: 'K. O\'Connor (Packing Supervisor)', batchId, description: 'Packed into 5kg insulated expanded polystyrene containers with crushed ice layers.', tempCelsius: 1.2 },
      { stage: 'COLD STORE', location: 'Humber Central Cold Store Room 3', timestamp: '2026-09-22 11:15', operator: 'T. Vance (Warehouse Lead)', batchId, description: 'Palletized and scanned into RFID storage cell C-41.', tempCelsius: 1.5 },
      { stage: 'CUSTOMER', location: 'En Route to Northern Caterers Ltd', timestamp: '2026-09-23 04:30', operator: 'Logistics Dispatch', batchId, description: 'Loaded into vehicle HU26 FSO for next-day distribution.', tempCelsius: 1.8 }
    ];

    // Customize per batch to feel extremely real and detailed
    if (batchId.includes('HD')) {
      return defaultBatch.map(e => ({
        ...e,
        vessel: 'FV Northern Spirit',
        operator: e.operator.replace('Polar Prince', 'Northern Spirit'),
        location: e.location.replace('Albert Dock', 'Grimsby Fish Quay').replace('Plant #2', 'Grimsby Plant #1'),
        description: e.description.replace('cod', 'haddock')
      }));
    } else if (batchId.includes('SH')) {
      return defaultBatch.map(e => ({
        ...e,
        vessel: 'FV Grimsby Crest',
        operator: e.operator.replace('Polar Prince', 'Grimsby Crest'),
        location: e.location.replace('Albert Dock', 'Grimsby Port Quay'),
        description: e.description.replace('cod', 'haddock').replace('Deboned, filleted', 'Oak smokehouse processing. Smoked for 12 hours over traditional oak sawdust.')
      }));
    } else if (batchId.includes('PL')) {
      return defaultBatch.map(e => ({
        ...e,
        vessel: 'FV Galtis',
        operator: e.operator.replace('Polar Prince', 'Galtis'),
        location: e.location.replace('Albert Dock', 'Bridlington Harbour Quay'),
        description: e.description.replace('cod', 'plaice').replace('Fillets', 'Whole gutting and grading.')
      }));
    }
    
    return defaultBatch;
  };

  return (
    <HumberContext.Provider value={{
      products,
      tickerProducts,
      landings,
      cart,
      customer,
      orders,
      invoices,
      activeDelivery,
      addToCart,
      updateCartQty,
      removeFromCart,
      clearCart,
      placeOrder,
      reorderAll,
      setCustomerTier,
      getDiscountedPrice,
      getPriceForQty,
      traceBatch
    }}>
      {children}
    </HumberContext.Provider>
  );
}

export function useHumber() {
  const context = useContext(HumberContext);
  if (context === undefined) {
    throw new Error('useHumber must be used within a HumberProvider');
  }
  return context;
}
