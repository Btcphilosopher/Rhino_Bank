'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { useHumber, CustomerTier } from '@/lib/humber-context';
import LayoutShell from '@/components/layout-shell';
import { 
  Briefcase, 
  ShieldCheck, 
  TrendingUp, 
  Scale, 
  History, 
  FileText, 
  ArrowRight, 
  Zap, 
  CreditCard,
  Building,
  User,
  Star,
  Plus
} from 'lucide-react';
import { motion } from 'motion/react';

export default function TradePortalPage() {
  const router = useRouter();
  const { customer, orders, setCustomerTier, reorderAll, products, addToCart } = useHumber();

  const handleReorder = (orderId: string) => {
    reorderAll(orderId);
    alert(`Historical order ${orderId} successfully reloaded into the Load Builder! Opening builder...`);
  };

  const handleTierChange = (tier: CustomerTier) => {
    setCustomerTier(tier);
    alert(`Customer tier rate modified to ${tier}! Prices across the catalogue and live board have adjusted.`);
  };

  return (
    <LayoutShell>
      <div className="p-6 xl:p-8 max-w-6xl mx-auto w-full flex-1 flex flex-col gap-8">
        
        {/* HEADER */}
        <div className="border-b border-slate-900 pb-4 font-mono">
          <span className="text-xs text-slate-500 tracking-widest uppercase block mb-1">
            B2B ACCOUNTS MANAGEMENT
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-slate-100 uppercase">
            TRADE PROCUREMENT SUITE
          </h1>
          <p className="text-xs text-slate-400 uppercase tracking-wider mt-1">
            ACCOUNT HOLDER: <strong className="text-orange-500">{customer.companyName} // HF-89024-X</strong>
          </p>
        </div>

        {/* ACCOUNT PROFILE INFO AND CREDIT STATUS */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 font-mono text-xs uppercase">
          
          {/* Company Brief Card */}
          <div className="md:col-span-6 bg-slate-900/30 border border-slate-900 p-5 space-y-4">
            <span className="text-[10px] text-slate-500 font-bold block border-b border-slate-950 pb-2">
              COMMERCIAL PROFILE DATA
            </span>
            
            <div className="space-y-2 text-[11px] text-slate-400">
              <div className="flex justify-between">
                <span className="text-slate-500">CORP NAME:</span>
                <strong className="text-slate-200">{customer.companyName}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">DIRECTOR NAME:</span>
                <strong className="text-slate-200">{customer.contactName}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">EMAIL REGISTER:</span>
                <strong className="text-slate-200 lowercase">{customer.email}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">QUAYSIDE ADDR:</span>
                <strong className="text-slate-200 text-right truncate max-w-[180px]">{customer.deliveryAddress}</strong>
              </div>
            </div>
          </div>

          {/* Credit limit / Terms Card */}
          <div className="md:col-span-6 bg-slate-900/30 border border-slate-900 p-5 space-y-4">
            <span className="text-[10px] text-slate-500 font-bold block border-b border-slate-950 pb-2">
              CREDIT PROFILE STATUS
            </span>

            <div className="space-y-2 text-[11px] text-slate-400">
              <div className="flex justify-between">
                <span className="text-slate-500">CREDIT TERMS:</span>
                <strong className="text-slate-200">{customer.terms} NET ACCOUNT</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">APPROVED LIMIT:</span>
                <strong className="text-slate-200">£{customer.creditLimit.toLocaleString()}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">CREDIT IN USE:</span>
                <strong className="text-red-400">£{customer.creditUsed.toLocaleString()}</strong>
              </div>
              <div className="flex justify-between border-t border-slate-950 pt-2 text-xs">
                <span className="text-slate-400 font-semibold">REMAINING CREDIT:</span>
                <strong className="text-green-500 font-bold">
                  £{(customer.creditLimit - customer.creditUsed).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </strong>
              </div>
            </div>
          </div>

        </div>

        {/* CUSTOMER TIER CONFIGURATION INTERACTIVE */}
        <div className="bg-slate-950 border border-slate-900 p-6 font-mono text-xs uppercase space-y-4">
          <div>
            <span className="text-[10px] text-orange-500 font-bold block tracking-wider mb-1">
              INTERACTIVE TIER SYSTEM SELECTOR
            </span>
            <h2 className="text-sm font-bold text-slate-200">
              ADJUST CONTRACTED MARGINS
            </h2>
            <p className="text-[10px] text-slate-500 normal-case leading-normal font-sans mt-1">
              Toggle between synthetic customer categories to simulate wholesale contract margin pricing. Price lists, cart builders, and exchange boards will instantly adjust to these custom parameters.
            </p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 text-center">
            {[
              { tier: 'STANDARD', label: 'STANDARD TIER', discount: 'BASE RATE', desc: 'Shorthand catering accounts' },
              { tier: 'TRADE', label: 'TRADE MEMBER', discount: '10% DISCOUNT', desc: 'Regional restaurants & pubs' },
              { tier: 'WHOLESALE', label: 'WHOLESALE RATE', discount: '20% DISCOUNT', desc: 'Supermarkets & large caterers' },
              { tier: 'CONTRACT', label: 'CONTRACT PARITY', discount: '25% DISCOUNT', desc: 'Exporters & national supply' }
            ].map(item => {
              const isActive = customer.tier === item.tier;
              return (
                <button
                  key={item.tier}
                  onClick={() => handleTierChange(item.tier as CustomerTier)}
                  className={`p-4 border text-left flex flex-col justify-between transition-all ${
                    isActive 
                      ? 'border-orange-500 bg-slate-900/60 shadow-lg shadow-orange-950/10' 
                      : 'border-slate-800 hover:border-slate-700 bg-slate-950/40'
                  }`}
                >
                  <div className="flex justify-between items-start w-full">
                    <span className={`text-[11px] font-bold ${isActive ? 'text-slate-100' : 'text-slate-400'}`}>
                      {item.label}
                    </span>
                    {isActive && (
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
                    )}
                  </div>
                  <strong className="text-orange-500 font-bold text-xs mt-3 block">{item.discount}</strong>
                  <span className="text-[9px] text-slate-500 normal-case italic mt-1 font-sans block leading-tight">{item.desc}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* PREVIOUS ORDERS & SAVED TEMPLATES */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 font-mono text-xs uppercase">
          
          {/* Reorder ledger (left) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="flex items-center gap-2 text-slate-300">
              <History className="w-4 h-4 text-orange-500" />
              <h2 className="font-bold">REORDER PREVIOUS CONSIGNMENTS</h2>
            </div>

            <div className="space-y-3">
              {orders.map(order => (
                <div 
                  key={order.id} 
                  className="p-4 bg-slate-950 border border-slate-900 hover:border-slate-800 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <strong className="text-slate-200">{order.id}</strong>
                      <span className="text-slate-600">·</span>
                      <span className="text-slate-500 font-semibold">{order.date}</span>
                    </div>
                    <div className="text-[10px] text-slate-400 mt-1">
                      {order.totalWeightKg} KG Load · STATUS: <span className="text-green-500 font-bold">{order.status}</span>
                    </div>
                  </div>

                  <div className="flex gap-2 shrink-0">
                    <button 
                      onClick={() => handleReorder(order.id)}
                      className="px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[10px] text-slate-200 rounded font-semibold transition-colors"
                    >
                      REORDER ALL ITEMS
                    </button>
                    <button 
                      onClick={() => router.push(`/orders?id=${order.id}`)}
                      className="px-3 py-2 border border-slate-900 hover:border-slate-850 text-[10px] text-slate-400 hover:text-slate-200 transition-colors"
                    >
                      VIEW AUDIT SUMMARY
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Favourites Directory (right) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-2 text-slate-300">
              <Star className="w-4 h-4 text-orange-500 shrink-0" />
              <h2 className="font-bold">FAVOURITE B2B COMMODITIES</h2>
            </div>

            <div className="bg-slate-950 border border-slate-900 p-4 space-y-3">
              {products.slice(0, 3).map(p => (
                <div 
                  key={`fav-${p.id}`} 
                  className="flex justify-between items-center text-[11px] border-b border-slate-900 pb-2 last:border-0 last:pb-0"
                >
                  <div>
                    <strong className="text-slate-200 block">{p.name}</strong>
                    <span className="text-[9px] text-slate-500 lowercase italic font-sans">{p.scientificName}</span>
                  </div>
                  <button 
                    onClick={() => {
                      addToCart(p.id, 2);
                      alert(`Added 2 Cases of ${p.name} (10 KG) to Load Builder.`);
                    }}
                    className="p-1 px-2.5 bg-slate-900 hover:bg-slate-800 text-[9px] font-bold text-orange-500 rounded border border-slate-800 flex items-center gap-1 uppercase"
                  >
                    <Plus className="w-3 h-3" />
                    <span>ADD 2 CASES</span>
                  </button>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* QUICK DIRECTORY OF GENERAL ACCOUNT VIEWS */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs text-center">
          <button 
            onClick={() => router.push('/orders')}
            className="p-4 border border-slate-900 hover:border-slate-800 bg-slate-900/10 text-slate-300 uppercase rounded transition-colors"
          >
            ORDER HISTORY
          </button>
          <button 
            onClick={() => router.push('/invoices')}
            className="p-4 border border-slate-900 hover:border-slate-800 bg-slate-900/10 text-slate-300 uppercase rounded transition-colors"
          >
            INVOICE STATS
          </button>
          <button 
            onClick={() => router.push('/delivery')}
            className="p-4 border border-slate-900 hover:border-slate-800 bg-slate-900/10 text-slate-300 uppercase rounded transition-colors"
          >
            LOGISTICS TELEMETRY
          </button>
          <button 
            onClick={() => router.push('/shop')}
            className="p-4 border border-slate-900 hover:border-orange-500 bg-slate-900/10 text-slate-300 hover:text-slate-200 uppercase rounded transition-colors"
          >
            COMMODITIES INDEX
          </button>
        </div>

      </div>
    </LayoutShell>
  );
}
