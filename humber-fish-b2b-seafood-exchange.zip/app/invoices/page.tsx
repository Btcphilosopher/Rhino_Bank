'use client';

import React from 'react';
import { useHumber } from '@/lib/humber-context';
import LayoutShell from '@/components/layout-shell';
import { 
  FileText, 
  CheckCircle2, 
  Clock, 
  ArrowDownToLine, 
  ExternalLink,
  ShieldCheck,
  Briefcase
} from 'lucide-react';

export default function InvoicesPage() {
  const { invoices } = useHumber();

  const handleDownload = (id: string) => {
    alert(`Initializing PDF render generator for Invoice ${id}... Download triggered to local system files.`);
  };

  const handleView = (id: string) => {
    alert(`Opening invoice paper specimen preview of ${id} for quayside accounting audit.`);
  };

  return (
    <LayoutShell>
      <div className="p-6 xl:p-8 max-w-5xl mx-auto w-full flex-1 flex flex-col gap-8">
        
        {/* HEADER */}
        <div className="border-b border-slate-900 pb-4 font-mono">
          <span className="text-xs text-slate-500 tracking-widest uppercase block mb-1">
            ACCOUNTS PAYABLE DESK
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-slate-100 uppercase">
            B2B COMMERCIAL INVOICES LEDGER
          </h1>
          <p className="text-xs text-slate-400 uppercase tracking-wider mt-1">
            CREDIT SYSTEM TERMS: <strong className="text-orange-500">NET 30 / DIRECT CREDIT ACCREDITED</strong>
          </p>
        </div>

        {/* LEDGER GRID (DESKTOP / TABLET) */}
        <div className="border border-slate-900 overflow-hidden bg-slate-950 font-mono text-xs uppercase">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-900/60 border-b border-slate-900 text-slate-500 text-[10px] tracking-wider">
                <th className="py-4 px-4 font-semibold">INVOICE ID / DATE</th>
                <th className="py-4 px-4 font-semibold">ASSOCIATED ORDER</th>
                <th className="py-4 px-4 font-semibold">DUE DATE</th>
                <th className="py-4 px-4 font-semibold">BILLING VALUE</th>
                <th className="py-4 px-4 font-semibold">PAYMENT STATUS</th>
                <th className="py-4 px-4 font-semibold text-right">DOCUMENTATION</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map(invoice => {
                const isPaid = invoice.status === 'PAID';
                return (
                  <tr 
                    key={invoice.id}
                    className="border-b border-slate-900 hover:bg-slate-900/10 transition-colors"
                  >
                    <td className="py-4 px-4">
                      <strong className="text-slate-200 block">{invoice.id}</strong>
                      <span className="text-[10px] text-slate-500">{invoice.invoiceDate}</span>
                    </td>
                    <td className="py-4 px-4 text-slate-400 font-semibold">
                      {invoice.orderId}
                    </td>
                    <td className="py-4 px-4 text-slate-400">
                      {invoice.dueDate}
                    </td>
                    <td className="py-4 px-4 text-slate-100 font-bold tabular-nums">
                      £{invoice.total.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-4 px-4">
                      <span className={`px-2 py-0.5 border text-[9px] font-bold rounded ${
                        isPaid 
                          ? 'border-green-900 bg-green-950/20 text-green-400' 
                          : 'border-orange-900 bg-orange-950/20 text-orange-400 animate-pulse'
                      }`}>
                        {invoice.status}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right space-x-2 shrink-0">
                      <button 
                        onClick={() => handleView(invoice.id)}
                        className="p-1 px-2.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[10px] text-slate-300 hover:text-slate-100 rounded font-semibold transition-colors uppercase"
                      >
                        VIEW
                      </button>
                      <button 
                        onClick={() => handleDownload(invoice.id)}
                        className="p-1 px-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[10px] text-orange-500 hover:text-orange-400 rounded font-semibold transition-colors uppercase inline-flex items-center gap-1"
                        aria-label="Download Invoice PDF"
                      >
                        <ArrowDownToLine className="w-3.5 h-3.5" />
                        <span>PDF</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* BOTTOM GENERAL INFO BLOCK */}
        <div className="bg-slate-900/10 border border-slate-900 p-5 font-mono text-xs uppercase text-slate-500 space-y-2 leading-relaxed">
          <p className="text-slate-300 font-bold">COMPLIANCE ACCOUNTS AUDITING REMINDER</p>
          <p className="text-[10px] max-w-xl">
            Under the UK VAT Act 1994, supplies of fresh, unprocessed seafood for human consumption are zero-rated (0% VAT). All B2B exports to secondary manufacturers carry the appropriate quayside catch document codes. For clearing or extending accounts payable terms, contact the Humber Finance Office.
          </p>
        </div>

      </div>
    </LayoutShell>
  );
}
