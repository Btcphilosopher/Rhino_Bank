'use client';

import React from 'react';
import Image from 'next/image';
import LayoutShell from '@/components/layout-shell';
import { 
  Anchor, 
  MapPin, 
  Compass, 
  Layers, 
  ShieldCheck, 
  Check, 
  Activity,
  ArrowRight
} from 'lucide-react';

export default function AboutPage() {
  return (
    <LayoutShell>
      <div className="p-6 xl:p-8 max-w-5xl mx-auto w-full flex-1 flex flex-col gap-12">
        
        {/* HEADER */}
        <div className="border-b border-slate-900 pb-4 font-mono">
          <span className="text-xs text-slate-500 tracking-widest uppercase block mb-1">
            PORT STATEMENT & OPERATIONS
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-slate-100 uppercase">
            HUMBER ESTUARY PORT FACILITY
          </h1>
          <p className="text-xs text-slate-400 uppercase tracking-wider mt-1">
            ESTABLISHED: <strong className="text-orange-500">HULL HARBOUR TRADING REGISTER // EST. 1846</strong>
          </p>
        </div>

        {/* IMAGE BREAK & CAPTION */}
        <div className="relative aspect-video bg-slate-900 border border-slate-900 overflow-hidden">
          <Image 
            src="/src/assets/images/humber_port_docks_1790367606903.jpg"
            alt="Hull docks crane and shipping"
            fill
            sizes="100vw"
            className="object-cover filter grayscale-[30%] brightness-[40%] contrast-[110%]"
            referrerPolicy="no-referrer"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
          <div className="absolute bottom-6 left-6 font-mono text-[10px] uppercase text-slate-400">
            HULL ALBERT COMMERICAL DOCK / ACTIVE OUTBOUND LOGISTICS GRID
          </div>
        </div>

        {/* EDITORIAL PROSE */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 font-sans text-xs uppercase tracking-wide">
          
          <div className="md:col-span-4 font-mono space-y-4">
            <span className="text-orange-500 font-bold block text-[10px]">
              01. INDUSTRIAL HERITAGE
            </span>
            <h2 className="text-sm font-bold text-slate-100 leading-tight">
              A PORT THAT NEVER SLEEPS
            </h2>
            <div className="text-[11px] text-slate-500 leading-normal">
              Hull has always been defined by the muddy waters of the Humber and the freezing gales of the North Sea. We operate in this historic commercial quayside corridors, trading with modern engineering.
            </div>
          </div>

          <div className="md:col-span-8 space-y-4 text-slate-400 leading-relaxed normal-case font-sans text-xs">
            <p>
              Humber Fish operates as a modern seafood procurement exchange and logistics coordinator based directly at the commercial docks of Hull, UK. We purchase raw material across all primary North Sea catch zones, grading and packing under strict cold-chain compliance parameters.
            </p>
            <p>
              By bypassing consumer retail middle-layers and focusing entirely on high-volume B2B supply, we guarantee that hotels, caterers, schools, food manufacturers, and wholesalers receive raw fillets within hours of landing. Every specimen is stamped with verified quayside catch telemetry, providing complete traceability from the vessel’s hold to your kitchen storage.
            </p>
          </div>

        </div>

        {/* FACILITY CAPABILITIES STATISTICS */}
        <div className="border border-slate-900 p-6 bg-slate-900/10 font-mono text-xs uppercase grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="border-b md:border-b-0 md:border-r border-slate-800 pb-4 md:pb-0 md:pr-6 space-y-2">
            <span className="text-slate-500 text-[10px] block">01. PROCESSING YIELD</span>
            <strong className="text-slate-100 text-sm">40,000 SQ. FT. COLD FACILITY</strong>
            <p className="text-[10px] text-slate-500 normal-case font-sans">
              Equipped with computerized grade sensors and high-accuracy skinless conveyor tables.
            </p>
          </div>

          <div className="border-b md:border-b-0 md:border-r border-slate-800 pb-4 md:pb-0 md:pr-6 space-y-2">
            <span className="text-slate-500 text-[10px] block">02. TEMPERATURE HOLDS</span>
            <strong className="text-green-500 text-sm">+1.5°C CONSTANT INTEGRITY</strong>
            <p className="text-[10px] text-slate-500 normal-case font-sans">
              Monitored by RFID temperature sensors with automated quayside alerting mechanisms.
            </p>
          </div>

          <div className="space-y-2">
            <span className="text-slate-500 text-[10px] block">03. LOGISTICS DISPATCH</span>
            <strong className="text-slate-100 text-sm">85 TONNES DAILY CAPACITY</strong>
            <p className="text-[10px] text-slate-500 normal-case font-sans">
              Refrigerated 18-tonne commercial vehicle fleet supplying Britain's merchants.
            </p>
          </div>
        </div>

      </div>
    </LayoutShell>
  );
}
