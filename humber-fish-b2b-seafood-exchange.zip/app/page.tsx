'use client';

import React, { useState, useEffect, useRef } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useHumber } from '@/lib/humber-context';
import LayoutShell from '@/components/layout-shell';
import { 
  Anchor, 
  ArrowRight, 
  ChevronRight, 
  Compass, 
  MapPin, 
  Thermometer, 
  Layers, 
  Clock, 
  Sliders, 
  ChevronDown, 
  Check, 
  Briefcase,
  ExternalLink,
  ShieldCheck,
  Zap,
  Activity
} from 'lucide-react';
import { motion, useScroll, useTransform, AnimatePresence } from 'motion/react';

export default function HomePage() {
  const router = useRouter();
  const { products, addToCart, getDiscountedPrice } = useHumber();
  const [booting, setBooting] = useState(true);
  const [bootStep, setBootStep] = useState(0);

  // Parallax / Scroll animations
  const targetRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: targetRef,
    offset: ["start start", "end end"]
  });

  const heroScale = useTransform(scrollYProgress, [0, 0.5], [1, 1.05]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.4], [1, 0.4]);

  // Port Simulation Interactive State
  const [activePortNode, setActivePortNode] = useState<string>('landing');
  const [shipmentsProcessed, setShipmentsProcessed] = useState(14892);

  // Simulate active dispatch logs
  useEffect(() => {
    const timer = setInterval(() => {
      setShipmentsProcessed(prev => prev + Math.floor(Math.random() * 2) + 1);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  // Boot sequence steps
  useEffect(() => {
    if (!booting) return;
    const timers = [
      setTimeout(() => setBootStep(1), 600),   // lines appear
      setTimeout(() => setBootStep(2), 1200),  // image starts sliding
      setTimeout(() => setBootStep(3), 2000),  // image locks / brand appears
      setTimeout(() => setBooting(false), 3200) // boot finished
    ];
    return () => timers.forEach(clearTimeout);
  }, [booting]);

  const featuredCod = products.find(p => p.id === 'cod-northsea-01');

  return (
    <>
      {/* 1. INDUSTRIAL BOOTING SEQUENCER */}
      <AnimatePresence>
        {booting && (
          <motion.div 
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, transition: { duration: 0.6, ease: 'easeInOut' } }}
            className="fixed inset-0 bg-slate-950 z-[9999] flex flex-col justify-between p-8 font-mono select-none"
          >
            {/* Top info */}
            <div className="flex justify-between text-[11px] text-slate-500 tracking-wider">
              <span>HUMBER ESTUARY // NORTH SEA // AREA IV</span>
              <span className="tabular-nums">SYS_BOOT: 2026-09-25 // 05:42:19</span>
            </div>

            {/* Central visual core */}
            <div className="flex-1 flex flex-col items-center justify-center relative w-full max-w-4xl mx-auto">
              {/* Thin lines */}
              {bootStep >= 1 && (
                <motion.div 
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ duration: 0.6 }}
                  className="absolute w-full h-[1px] bg-slate-800"
                />
              )}
              {bootStep >= 1 && (
                <motion.div 
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ duration: 0.8, delay: 0.2 }}
                  className="absolute w-full h-[1px] bg-slate-800 translate-y-32"
                />
              )}

              {/* Fragmented image sliding into place */}
              {bootStep >= 2 && (
                <motion.div 
                  initial={{ opacity: 0, y: 20, filter: 'grayscale(1) brightness(0.4)' }}
                  animate={{ opacity: 0.45, y: 16, filter: 'grayscale(0.5) brightness(0.6)' }}
                  transition={{ duration: 0.8, ease: 'easeOut' }}
                  className="absolute w-[80%] h-44 border border-slate-800/50 overflow-hidden"
                >
                  <Image 
                    src="/src/assets/images/hero_humber_facility_1790367580925.jpg"
                    alt="Humber Facility Cargo"
                    fill
                    sizes="80vw"
                    className="object-cover object-center"
                    referrerPolicy="no-referrer"
                    priority
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-transparent to-slate-950" />
                </motion.div>
              )}

              {/* Text locks into place */}
              <div className="z-10 text-center flex flex-col items-center">
                {bootStep >= 3 && (
                  <motion.h1 
                    initial={{ opacity: 0, letterSpacing: '0.4em' }}
                    animate={{ opacity: 1, letterSpacing: '0.15em' }}
                    transition={{ duration: 0.6, ease: 'easeOut' }}
                    className="text-4xl md:text-5xl font-bold font-mono text-slate-100 tracking-wider mb-2"
                  >
                    HUMBER FISH
                  </motion.h1>
                )}
                {bootStep >= 3 && (
                  <motion.p 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3 }}
                    className="text-xs font-mono text-orange-500 tracking-widest uppercase"
                  >
                    FRESH FISH. SERIOUSLY SUPPLIED.
                  </motion.p>
                )}
              </div>
            </div>

            {/* Bottom load sequence info */}
            <div className="flex flex-col md:flex-row md:items-center justify-between text-[10px] text-slate-500 gap-2 font-mono">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-orange-600 animate-ping"></span>
                <span className="uppercase text-slate-400">CONNECTING COMMERCIAL INTAKE MODULE...</span>
              </div>
              <button 
                onClick={() => setBooting(false)}
                className="text-slate-400 hover:text-slate-100 text-[11px] underline underline-offset-4 decoration-orange-500"
              >
                [SKIP INITIALIZATION]
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <LayoutShell>
        {/* 2. THE HERO (Physical, kinetic, industrial backdrop) */}
        <div ref={targetRef} className="relative h-[85vh] md:h-[90vh] flex flex-col justify-between overflow-hidden bg-slate-950 border-b border-slate-800">
          
          {/* Background image container with scroll-driven parallax scales */}
          <motion.div 
            style={{ scale: heroScale, opacity: heroOpacity }}
            className="absolute inset-0 z-0"
          >
            <Image 
              src="/src/assets/images/hero_humber_facility_1790367580925.jpg"
              alt="Humber Seafood Terminal, Hull"
              fill
              sizes="100vw"
              priority
              className="object-cover object-center filter grayscale-[30%] brightness-[40%] contrast-[110%]"
              referrerPolicy="no-referrer"
            />
            {/* Soft grid overlay or gradient mesh */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/45 to-transparent" />
          </motion.div>

          {/* Technical top-left label */}
          <div className="relative z-10 px-8 pt-8 font-mono text-slate-400 max-w-xl">
            <span className="text-[10px] tracking-widest text-orange-500 uppercase font-semibold block mb-1">
              ESTUARY PORT TERMINAL / HULL / UNITED KINGDOM
            </span>
            <div className="flex gap-2 text-[11px] text-slate-500 uppercase border-l-2 border-slate-800 pl-3">
              <span>LAT: 53.7444° N</span>
              <span>·</span>
              <span>LNG: 0.3325° W</span>
              <span>·</span>
              <span>DEP_ZONE: NORTH SEA AREA IV</span>
            </div>
          </div>

          {/* Large display titles */}
          <div className="relative z-10 px-8 md:px-12 w-full max-w-4xl mt-auto pb-16">
            <div className="space-y-4">
              <span className="font-mono text-xs text-slate-400 tracking-widest block uppercase">
                COMMERCIAL WHOLESALE EXCHANGE
              </span>
              <h1 className="text-4xl md:text-6xl font-bold font-mono tracking-tight text-slate-100 uppercase leading-none text-wrap-balance max-w-2xl">
                FROM THE HUMBER.<br className="hidden md:inline"/> TO YOUR KITCHEN.
              </h1>
              <p className="font-mono text-xs md:text-sm text-slate-400 uppercase tracking-wider max-w-xl border-t border-slate-800 pt-4 leading-relaxed">
                We buy, process, grade, pack and distribute premium species of fish and shellfish from the cold North Sea. Reconciled and shipped daily to Britain's food commercial sector.
              </p>
            </div>

            <div className="flex flex-wrap gap-4 mt-8 font-mono text-xs">
              <Link 
                href="/shop" 
                className="bg-orange-600 hover:bg-orange-500 text-slate-100 font-bold px-6 py-3 tracking-widest uppercase transition-all flex items-center gap-2 rounded shadow-lg shadow-orange-950/20"
              >
                <span>ENTER PRODUCT CATALOGUE</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link 
                href="/today" 
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-200 px-6 py-3 tracking-wider uppercase transition-colors rounded"
              >
                LIVE PORT TICKER
              </Link>
            </div>
          </div>

          {/* Bottom data summary footer inside hero */}
          <div className="relative z-10 bg-slate-900/40 backdrop-blur-sm border-t border-slate-800 py-3 px-8 text-[11px] font-mono text-slate-400 flex flex-wrap justify-between gap-4 items-center uppercase">
            <span>VESSELS AT DOCK: <strong className="text-slate-100">4 ACTIVE</strong></span>
            <span className="hidden md:inline">·</span>
            <span>NEXT DISPATCH RUN: <strong className="text-slate-100">04:30 NEXT DAY</strong></span>
            <span className="hidden md:inline">·</span>
            <span>ESTUARY DISPATCH CAPACITY: <strong className="text-slate-100">85% CHILLED</strong></span>
            <span className="hidden md:inline">·</span>
            <span>CORE TEMP LOCK: <strong className="text-green-500">+1.5°C LOCKED</strong></span>
          </div>
        </div>

        {/* 3. SIGNATURE VISUAL SECTION (Featured "Today's Fish" - North Sea Cod) */}
        <section className="py-24 px-8 max-w-7xl mx-auto w-full border-b border-slate-900">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Visual Column */}
            <div className="lg:col-span-7 flex flex-col">
              <span className="font-mono text-xs text-slate-500 tracking-widest uppercase block mb-2">
                01. INDIVIDUAL SPECIES SPOTLIGHT
              </span>
              <h2 className="text-3xl font-bold font-mono tracking-tight text-slate-100 uppercase mb-8">
                TODAY'S SIGNATURE CATCH
              </h2>

              <div className="relative aspect-[4/3] bg-slate-900 border border-slate-800 overflow-hidden group">
                <Image 
                  src="/src/assets/images/todays_fish_cod_1790367594701.jpg"
                  alt="Fresh whole North Sea Cod on Ice"
                  fill
                  sizes="(max-width: 1024px) 100vw, 55vw"
                  className="object-cover group-hover:scale-[1.03] transition-transform duration-700 filter contrast-[105%]"
                  referrerPolicy="no-referrer"
                />
                
                {/* Visual technical overlay scrim */}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent p-6 flex justify-between items-end">
                  <div className="font-mono text-xs uppercase text-slate-300">
                    <span className="text-[10px] text-slate-500 block">SPECIMEN SPEC</span>
                    NORTH SEA COD / GRADE A
                  </div>
                  <div className="font-mono text-xs text-orange-500 font-bold tabular-nums">
                    EST. COLD RUN: -1.0°C to +2.0°C
                  </div>
                </div>
              </div>
            </div>

            {/* Metadata / Purchase Block */}
            <div className="lg:col-span-5 flex flex-col justify-center border-t lg:border-t-0 lg:border-l border-slate-800 lg:pl-12 pt-8 lg:pt-0">
              <div className="font-mono uppercase space-y-4">
                <div className="border-b border-slate-800 pb-2">
                  <span className="text-[10px] text-slate-500 block">PRIMARY FAMILY</span>
                  <h3 className="text-2xl font-bold text-slate-100">NORTH SEA COD</h3>
                  <span className="text-xs text-slate-400 italic lowercase block font-sans">Gadus morhua</span>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-slate-500 block text-[10px]">ORIGIN</span>
                    <strong className="text-slate-300 text-[11px]">{featuredCod?.origin || 'North Sea'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">LANDING ZONE</span>
                    <strong className="text-slate-300 text-[11px]">{featuredCod?.landingLocation || 'Hull Docks'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">COMMERCIAL GRADE</span>
                    <strong className="text-slate-300 text-[11px]">GRADE {featuredCod?.grade || 'A'} (DEMERSAL)</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">PACK WEIGHT</span>
                    <strong className="text-slate-300 text-[11px]">{featuredCod?.caseWeightKg || 5}KG CASES</strong>
                  </div>
                </div>

                <div className="bg-slate-900 border border-slate-850 p-4 space-y-3">
                  <div className="flex justify-between items-baseline">
                    <span className="text-slate-500 text-[11px]">CONTRACT TIER RATE</span>
                    <div className="text-right">
                      <span className="text-slate-500 line-through text-[10px] block">
                        £{featuredCod?.basePricePerKg.toFixed(2)}/KG
                      </span>
                      <strong className="text-lg text-orange-500 tabular-nums">
                        £{(featuredCod ? getDiscountedPrice(featuredCod) : 8.01).toFixed(2)} / KG
                      </strong>
                    </div>
                  </div>
                  <div className="text-[10px] text-slate-500 leading-normal border-t border-slate-800 pt-2">
                    Minimum order 2 Cases (10 KG). Real-time supply updates every 60s. High yield fillets skinless.
                  </div>
                </div>

                <div className="flex flex-col gap-2 pt-2">
                  <button 
                    onClick={() => {
                      if (featuredCod) {
                        addToCart(featuredCod.id, 2);
                        alert(`Added 2 Cases of North Sea Cod (10 KG) to Load Builder.`);
                      }
                    }}
                    className="w-full bg-slate-100 hover:bg-slate-200 text-slate-950 py-3 font-bold text-xs tracking-wider uppercase transition-colors text-center rounded-md"
                  >
                    ADD 2 CASES TO LOAD (£{((featuredCod ? getDiscountedPrice(featuredCod) : 8.01) * 10).toFixed(2)})
                  </button>
                  <Link 
                    href="/shop" 
                    className="w-full py-3 border border-slate-800 hover:border-slate-700 text-center text-xs tracking-wider text-slate-400 hover:text-slate-200 transition-colors rounded-md"
                  >
                    VIEW ALL SPECIFICATIONS
                  </Link>
                </div>
              </div>
            </div>

          </div>
        </section>

        {/* 4. THE PORT ANIMATION / SCROLL LOGISTICS SIMULATOR */}
        <section className="bg-slate-900/30 border-b border-slate-900 py-24 px-8">
          <div className="max-w-7xl mx-auto w-full">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="font-mono text-xs text-slate-500 tracking-widest uppercase block mb-1">
                02. INTERACTIVE COLD CHAIN DIAGRAM
              </span>
              <h2 className="text-3xl font-bold font-mono tracking-tight text-slate-100 uppercase">
                ESTUARY LOGISTICS TERMINAL
              </h2>
              <p className="font-mono text-[11px] text-slate-400 uppercase tracking-wider mt-4">
                Follow the physical flow of seafood from North Sea arrival to final B2B delivery at your cold hold. Click nodes below to audit standard protocols.
              </p>
            </div>

            {/* Logistics Grid Simulation */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
              
              {/* Interactive Nodes list (left) */}
              <div className="lg:col-span-5 flex flex-col gap-3 font-mono">
                {[
                  {
                    id: 'landing',
                    label: '01. Landing Quay Arrival',
                    subtitle: 'QUAYSIDE GRADING & SENSORS',
                    desc: 'Vessels berth at Hull/Grimsby. Catch is transferred immediately to temperature-regulated quayside halls. Grade verified.',
                    stat: 'CORE TEMP: +1.2°C'
                  },
                  {
                    id: 'process',
                    label: '02. Humber Processing',
                    subtitle: 'STERILE FILLETING & SKINNING',
                    desc: 'Deboned and prepared on stainless steel conveyor tables. Monitored strictly in sterile cold rooms for high yield.',
                    stat: 'STAFF STATUS: AA LEVEL'
                  },
                  {
                    id: 'pack',
                    label: '03. Graded Packing Hold',
                    subtitle: 'INSULATED EPS CONTAINERS',
                    desc: 'Packed in food-grade EPS cases with layers of fine-crushed ice to preserve tissue density during regional transit.',
                    stat: 'ICE WATER COMPLIANCE'
                  },
                  {
                    id: 'load',
                    label: '04. Refrigerated Dispatch',
                    subtitle: 'NEXT-DAY LOGISTICS NETWORK',
                    desc: 'Loaded onto 18-tonne refrigerated trucks. Active GPS telemetry tracking and thermal logs online.',
                    stat: 'VEHICLES: HU26 DOCK'
                  }
                ].map(node => (
                  <button 
                    key={node.id}
                    onClick={() => setActivePortNode(node.id)}
                    className={`p-4 border text-left transition-all relative ${
                      activePortNode === node.id 
                        ? 'border-orange-500 bg-slate-900/90' 
                        : 'border-slate-800 hover:border-slate-700 bg-slate-950/40'
                    }`}
                  >
                    {activePortNode === node.id && (
                      <div className="absolute left-0 top-0 bottom-0 w-1 bg-orange-500" />
                    )}
                    <div className="flex justify-between items-start mb-1">
                      <span className={`text-xs font-bold ${activePortNode === node.id ? 'text-slate-100' : 'text-slate-300'}`}>
                        {node.label}
                      </span>
                      <span className="text-[9px] text-slate-500 font-bold tracking-tight">
                        {node.stat}
                      </span>
                    </div>
                    <span className="text-[10px] text-orange-500 font-bold block mb-2">{node.subtitle}</span>
                    <p className="text-[11px] text-slate-400 uppercase leading-normal">
                      {node.desc}
                    </p>
                  </button>
                ))}
              </div>

              {/* Graphic Simulator Canvas (right) */}
              <div className="lg:col-span-7 bg-slate-950 border border-slate-850 p-6 flex flex-col justify-between font-mono relative overflow-hidden min-h-[350px]">
                
                {/* Visual schematic representing the selected node */}
                <div className="absolute inset-0 bg-radial-gradient from-slate-900 via-transparent to-transparent opacity-60 z-0 pointer-events-none" />
                
                {/* Schematic header */}
                <div className="z-10 flex justify-between items-center text-[10px] text-slate-500 border-b border-slate-900 pb-3">
                  <span>SCHEMATIC // CORE MODEL: ACTIVE</span>
                  <span className="text-slate-400">TELEMETRY_REF: TRK-HULL-902</span>
                </div>

                <div className="z-10 flex-1 flex flex-col justify-center items-center py-8">
                  {/* Rotating grid based on selected node */}
                  {activePortNode === 'landing' && (
                    <div className="text-center max-w-md">
                      <div className="w-16 h-16 rounded-full border border-orange-500 border-dashed flex items-center justify-center mx-auto mb-4 animate-spin [animation-duration:15s]">
                        <Compass className="w-8 h-8 text-orange-500" />
                      </div>
                      <span className="text-sm font-bold text-slate-100 uppercase tracking-widest block mb-2">QUAYSIDE INTAKE AUDIT</span>
                      <p className="text-[11px] text-slate-400 leading-relaxed uppercase">
                        Scanning barcode telemetry and verifying digital landing records against port declarations. Temperature sensor log reads <strong className="text-green-500">+1.2°C</strong>.
                      </p>
                    </div>
                  )}

                  {activePortNode === 'process' && (
                    <div className="text-center max-w-md">
                      <div className="w-16 h-16 rounded-full border border-slate-800 flex items-center justify-center mx-auto mb-4">
                        <Sliders className="w-8 h-8 text-blue-400 animate-pulse" />
                      </div>
                      <span className="text-sm font-bold text-slate-100 uppercase tracking-widest block mb-2">YIELD ANALYSIS & PORTIONING</span>
                      <p className="text-[11px] text-slate-400 leading-relaxed uppercase">
                        Automated deboning line calibration active. Grade A verification complete. Core product density check passing quality control standard BS-4902.
                      </p>
                    </div>
                  )}

                  {activePortNode === 'pack' && (
                    <div className="text-center max-w-md">
                      <div className="w-16 h-16 rounded-full border border-slate-800 flex items-center justify-center mx-auto mb-4">
                        <Layers className="w-8 h-8 text-green-400" />
                      </div>
                      <span className="text-sm font-bold text-slate-100 uppercase tracking-widest block mb-2">THERMAL ISOLATION PACKAGING</span>
                      <p className="text-[11px] text-slate-400 leading-relaxed uppercase">
                        Placing core fillets on high-absorption ice padding. Sealed using industrial pressure lids to guarantee strict chilled parameters of <strong className="text-green-500">2.0°C maximum hold</strong>.
                      </p>
                    </div>
                  )}

                  {activePortNode === 'load' && (
                    <div className="text-center max-w-md">
                      <div className="w-16 h-16 rounded-full border border-orange-500 flex items-center justify-center mx-auto mb-4 animate-pulse">
                        <Thermometer className="w-8 h-8 text-orange-500" />
                      </div>
                      <span className="text-sm font-bold text-slate-100 uppercase tracking-widest block mb-2">REFRIGERATED REGIONAL DISPATCH</span>
                      <p className="text-[11px] text-slate-400 leading-relaxed uppercase">
                        Securing trailer thermal lock. Vehicle reg <strong className="text-slate-200">HU26 FSO</strong> en route to distribution zones. Estimated cold integrity: stable 1.8°C core.
                      </p>
                    </div>
                  )}
                </div>

                {/* Simulated live indicators at bottom of terminal schematic */}
                <div className="z-10 pt-4 border-t border-slate-900 grid grid-cols-3 text-center text-[10px] text-slate-500 gap-4">
                  <div>
                    <span className="block text-slate-600">SCHEMATIC COMPLIANCE</span>
                    <strong className="text-green-500">99.82%</strong>
                  </div>
                  <div>
                    <span className="block text-slate-600">SHIPMENTS TODAY</span>
                    <strong className="text-slate-200 tabular-nums">{shipmentsProcessed.toLocaleString()}</strong>
                  </div>
                  <div>
                    <span className="block text-slate-600">CORE ALGORITHM</span>
                    <strong className="text-slate-200">HUMBER_LOG_V3</strong>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </section>

        {/* 5. EDITORIAL SECTIONS: "FROM THE HUMBER" (Port docks landscape) */}
        <section className="relative min-h-[600px] flex flex-col justify-center py-24 px-8 border-b border-slate-900 overflow-hidden">
          {/* Background editorial shot */}
          <div className="absolute inset-0 z-0">
            <Image 
              src="/src/assets/images/humber_port_docks_1790367606903.jpg"
              alt="Hull Docks along the Humber Estuary"
              fill
              sizes="100vw"
              className="object-cover object-center filter grayscale-[40%] brightness-[25%] contrast-[105%]"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/70 to-slate-950" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-6 font-mono uppercase space-y-6">
              <span className="text-xs text-orange-500 tracking-widest block font-bold">
                03. HULL HARBOUR & DOCKS REGIONAL INTEGRITY
              </span>
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-slate-100 leading-tight">
                FROM THE HUMBER.<br className="hidden md:inline" /> TO BRITAIN'S MERCHANTS.
              </h2>
              <p className="text-xs md:text-sm text-slate-400 normal-case leading-relaxed tracking-wider font-sans">
                Hull was once the world’s most active deep-sea commercial fishing port. Today, we honor that industrial grit by engineering the nation’s most sophisticated quayside fish processing and distribution infrastructure. No quaint coastal nostalgia; this is serious British logistics feeding independent businesses.
              </p>
              
              <div className="grid grid-cols-2 gap-4 text-xs pt-4">
                <div className="border-l-2 border-slate-800 pl-4">
                  <span className="text-slate-500 block text-[10px]">TOTAL GRADING QUAY</span>
                  <strong className="text-slate-200 text-sm">40,000 SQ. FT.</strong>
                </div>
                <div className="border-l-2 border-slate-800 pl-4">
                  <span className="text-slate-500 block text-[10px]">DISTRIBUTION CAPACITY</span>
                  <strong className="text-slate-200 text-sm">85 TONNES DAILY</strong>
                </div>
              </div>

              <div className="pt-4">
                <Link 
                  href="/about" 
                  className="inline-flex items-center gap-2 text-xs font-bold text-slate-100 hover:text-orange-500 transition-colors underline underline-offset-4 decoration-orange-500 decoration-2"
                >
                  <span>READ OUR PORT INFRASTRUCTURE STATEMENT</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>

            <div className="lg:col-span-6 hidden lg:flex flex-col items-center justify-center p-8">
              <div className="border-2 border-slate-800 bg-slate-900/40 p-8 w-full max-w-md font-mono text-xs uppercase space-y-4">
                <div className="flex items-center gap-2 text-[10px] text-orange-500">
                  <span className="w-2 h-2 rounded-full bg-orange-500 animate-ping" />
                  <span>LIVE PORT MONITOR</span>
                </div>
                <span className="text-sm font-bold text-slate-100 block border-b border-slate-800 pb-2">
                  DOCK_BERTH_ALLOCATION
                </span>
                
                <div className="space-y-2 text-[11px] text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-500">FV POLAR PRINCE</span>
                    <span className="text-green-500">DOCK_A (DISPATCHED)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">FV NORTHERN SPIRIT</span>
                    <span className="text-orange-500">BERTH_3 (OFFLOADING)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">FV GRIMSBY CREST</span>
                    <span className="text-slate-500">WAIT_ZONE (ANCHORED)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">FV GALTIS</span>
                    <span className="text-slate-500">OUTBOUND (SEA_AREA_4)</span>
                  </div>
                </div>

                <div className="text-[10px] text-slate-500 border-t border-slate-800 pt-3 flex justify-between">
                  <span>REFRESH FREQ: 10S</span>
                  <span>SYSTEM_STABLE</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 6. CALL TO ACTION GRID: DIRECT PATHS */}
        <section className="py-24 px-8 max-w-7xl mx-auto w-full">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            
            {/* Box 1: Browse Products */}
            <div className="bg-slate-900/40 border border-slate-800 p-8 flex flex-col justify-between font-mono relative group hover:border-slate-700 transition-colors">
              <div className="space-y-4">
                <span className="text-[10px] text-orange-500 tracking-wider font-bold uppercase block">
                  HF_CATALOGUE
                </span>
                <h3 className="text-xl font-bold uppercase text-slate-100">
                  WHOLESALE SEAFOOD EXCHANGE
                </h3>
                <p className="text-xs text-slate-400 normal-case leading-relaxed font-sans">
                  Browse our complete line of fresh and smoked seafood. Real-time box quantities and tiered price listings. Assemble your customized load immediately for prompt next-day distribution.
                </p>
              </div>
              <div className="mt-8">
                <Link 
                  href="/shop" 
                  className="inline-flex items-center gap-2 text-xs font-bold text-slate-100 group-hover:text-orange-500 transition-colors"
                >
                  <span>BROWSE SPECIFICATIONS</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </div>

            {/* Box 2: Register Account */}
            <div className="bg-slate-900/40 border border-slate-800 p-8 flex flex-col justify-between font-mono relative group hover:border-slate-700 transition-colors">
              <div className="space-y-4">
                <span className="text-[10px] text-orange-500 tracking-wider font-bold uppercase block">
                  HF_CREDIT_FACILITY
                </span>
                <h3 className="text-xl font-bold uppercase text-slate-100">
                  REGISTER COMMERCIAL TRADE ACCOUNT
                </h3>
                <p className="text-xs text-slate-400 normal-case leading-relaxed font-sans">
                  Apply online for commercial trading accounts with Net 30/60 payment limits up to £25,000. Access customized tier margins, previous load logs, FAVS, and repeat-order automation.
                </p>
              </div>
              <div className="mt-8">
                <Link 
                  href="/trade" 
                  className="inline-flex items-center gap-2 text-xs font-bold text-slate-100 group-hover:text-orange-500 transition-colors"
                >
                  <span>ACCESS PROCUREMENT SUITE</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </div>

          </div>
        </section>

      </LayoutShell>
    </>
  );
}
