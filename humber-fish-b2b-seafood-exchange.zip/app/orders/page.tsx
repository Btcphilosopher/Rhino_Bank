'use client';

import React, { useState, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { useHumber } from '@/lib/humber-context';
import LayoutShell from '@/components/layout-shell';
import { 
  History, 
  ChevronRight, 
  CheckCircle2, 
  Truck, 
  Scale, 
  FileText, 
  TrendingUp,
  X,
  Plus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

function OrdersPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { orders, products, reorderAll } = useHumber();

  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  useEffect(() => {
    const id = searchParams.get('id');
    if (id && orders.some(o => o.id === id)) {
      setSelectedOrderId(id);
    } else if (orders.length > 0 && !selectedOrderId) {
      setSelectedOrderId(orders[0].id);
    }
  }, [searchParams, orders]);

  const activeOrder = orders.find(o => o.id === selectedOrderId) || orders[0];

  const handleReorder = (id: string) => {
    reorderAll(id);
    alert(`Consignment ${id} items successfully loaded into Load Builder.`);
  };

  return (
    <LayoutShell>
      <div className="flex-1 flex flex-col lg:flex-row h-full">
        
        {/* LEFT COLUMN: CONSIGNMENTS LIST */}
        <div className="flex-1 p-6 xl:p-8 border-r border-slate-900 lg:max-w-[55%] flex flex-col justify-between overflow-y-auto">
          <div>
            <div className="border-b border-slate-900 pb-4 mb-6">
              <span className="font-mono text-xs text-slate-500 tracking-widest uppercase block mb-1">
                B2B ACCOUNTS LEDGER
              </span>
              <h1 className="text-2xl font-bold font-mono tracking-tight text-slate-100 uppercase">
                CONSIGNMENT ORDER ARCHIVE
              </h1>
              <p className="text-xs font-mono text-slate-400 uppercase tracking-wider mt-1">
                RECONCILED CONSIGNMENTS: <strong className="text-orange-500">{orders.length} REGISTERED LOADS</strong>
              </p>
            </div>

            {/* List */}
            <div className="space-y-4">
              {orders.map(order => {
                const isSelected = selectedOrderId === order.id;
                return (
                  <div
                    key={order.id}
                    onClick={() => {
                      setSelectedOrderId(order.id);
                      // update URL Search param quietly
                      const params = new URLSearchParams(window.location.search);
                      params.set('id', order.id);
                      router.replace(`${window.location.pathname}?${params.toString()}`);
                    }}
                    className={`p-4 border transition-all cursor-pointer font-mono text-xs uppercase flex items-center justify-between gap-4 ${
                      isSelected 
                        ? 'border-orange-500 bg-slate-900/40 shadow-md shadow-orange-950/5' 
                        : 'border-slate-900 bg-slate-950 hover:border-slate-800'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <strong className="text-slate-100 text-sm">{order.id}</strong>
                        <span className="text-slate-600">·</span>
                        <span className="text-slate-500 font-semibold">{order.date}</span>
                      </div>
                      
                      <div className="text-[10px] text-slate-400 mt-2 flex items-center gap-2 flex-wrap">
                        <span>{order.totalWeightKg} KG</span>
                        <span className="text-slate-700">·</span>
                        <span>{order.items.length} ITEMS</span>
                        <span className="text-slate-700">·</span>
                        <span className="text-green-500 font-semibold">{order.status}</span>
                      </div>
                    </div>

                    <div className="text-right flex items-center gap-3 shrink-0">
                      <div className="text-right">
                        <span className="text-[9px] text-slate-500 block">TOTAL VALUE</span>
                        <strong className="text-slate-300 font-bold tabular-nums">
                          £{order.total.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </strong>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-600" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-8 border-t border-slate-900 pt-4 text-[10px] font-mono text-slate-500 uppercase flex justify-between">
            <span>AUDIT_LOG_STATUS: SECURED</span>
            <span>SHOWING ALL LOADS</span>
          </div>
        </div>

        {/* RIGHT COLUMN: ORDER DETAILS SUMMARY */}
        <div className="flex-1 bg-slate-900/50 p-6 xl:p-8 lg:max-w-[45%] border-t lg:border-t-0 border-slate-900 flex flex-col justify-between overflow-y-auto">
          {activeOrder ? (
            <div className="space-y-6">
              
              {/* Header */}
              <div className="border-b border-slate-800 pb-4">
                <div className="flex justify-between items-start text-xs font-mono uppercase">
                  <div>
                    <span className="text-[10px] text-slate-500 block">CONSIGNMENT RECORD</span>
                    <strong className="text-slate-100 text-base">{activeOrder.id}</strong>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-500 block">DISPATCH DATE</span>
                    <span className="text-slate-300 tabular-nums">{activeOrder.date}</span>
                  </div>
                </div>
              </div>

              {/* Items Table */}
              <div className="space-y-3 font-mono text-xs uppercase">
                <span className="text-[10px] text-slate-500 font-bold block">ITEMIZED COMMODITIES SPEC</span>
                
                <div className="space-y-2.5">
                  {activeOrder.items.map(item => {
                    const prod = products.find(p => p.id === item.productId);
                    if (!prod) return null;
                    const itemWeight = item.quantityCases * prod.caseWeightKg;
                    const totalCost = itemWeight * item.pricePerKgAtOrder;

                    return (
                      <div key={item.productId} className="p-3 bg-slate-950 border border-slate-900">
                        <div className="flex justify-between items-start">
                          <div>
                            <strong className="text-slate-200">{prod.name}</strong>
                            <div className="text-[10px] text-slate-500 mt-0.5">
                              {prod.form} / {prod.sizeRange}
                            </div>
                          </div>
                          <div className="text-right text-slate-300 font-semibold tabular-nums">
                            £{totalCost.toFixed(2)}
                          </div>
                        </div>

                        <div className="mt-3 text-[10px] text-slate-500 flex justify-between">
                          <span>{item.quantityCases} CASES × {prod.caseWeightKg}KG = {itemWeight}KG</span>
                          <span>RATE: £{item.pricePerKgAtOrder.toFixed(2)}/KG</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Totals */}
              <div className="border-t border-slate-800 pt-4 space-y-2 font-mono text-xs uppercase">
                <div className="flex justify-between text-slate-500">
                  <span>TOTAL COMBINED WEIGHT:</span>
                  <span className="text-slate-300 font-semibold tabular-nums">{activeOrder.totalWeightKg} KG</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>VAT ZERO-RATED:</span>
                  <span className="text-slate-300 tabular-nums">£0.00</span>
                </div>
                <div className="flex justify-between text-sm border-t border-slate-850 pt-2 font-bold">
                  <span className="text-slate-300">CONSIGNMENT GRAND TOTAL:</span>
                  <strong className="text-orange-500 tabular-nums">
                    £{activeOrder.total.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </strong>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-col gap-2 font-mono">
                <button
                  onClick={() => handleReorder(activeOrder.id)}
                  className="w-full bg-slate-100 hover:bg-slate-200 text-slate-950 py-3 text-xs font-bold tracking-wider uppercase transition-colors rounded-md text-center"
                >
                  REORDER ALL CONSIGNMENT ITEMS
                </button>
                {activeOrder.deliveryTracker && (
                  <button
                    onClick={() => router.push(`/delivery`)}
                    className="w-full py-2.5 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200 text-xs uppercase tracking-wider transition-colors rounded-md"
                  >
                    TRACK TRANSIT TELEMETRY ({activeOrder.deliveryTracker.vehicleReg})
                  </button>
                )}
              </div>

            </div>
          ) : (
            <div className="py-24 text-center font-mono">
              <span className="text-slate-600">NO CONSIGNMENT SELECTED</span>
            </div>
          )}

          <div className="mt-8 border-t border-slate-800 pt-4 text-[10px] font-mono text-slate-500 uppercase flex justify-between">
            <span>BILLING TERMS: NET 30</span>
            <span>SYSTEM SECURE</span>
          </div>
        </div>

      </div>
    </LayoutShell>
  );
}

export default function OrdersPage() {
  return (
    <React.Suspense fallback={
      <LayoutShell>
        <div className="p-12 text-center font-mono max-w-md mx-auto my-16 text-slate-500 uppercase text-xs">
          Loading Order Ledger...
        </div>
      </LayoutShell>
    }>
      <OrdersPageContent />
    </React.Suspense>
  );
}
