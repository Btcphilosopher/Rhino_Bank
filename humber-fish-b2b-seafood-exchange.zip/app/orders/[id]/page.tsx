import { redirect } from 'next/navigation';

interface OrderPageProps {
  params: Promise<{
    id: string;
  }>;
}

export default async function OrderDetailPage({ params }: OrderPageProps) {
  const resolvedParams = await params;
  // Redirect to the main Orders list with the requested ID pre-loaded
  redirect(`/orders?id=${resolvedParams.id}`);
}
