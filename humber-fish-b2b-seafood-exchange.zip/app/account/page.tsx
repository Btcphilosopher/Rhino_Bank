'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { useHumber } from '@/lib/humber-context';
import LayoutShell from '@/components/layout-shell';
import { 
  User, 
  Building, 
  Mail, 
  MapPin, 
  ShieldCheck, 
  CreditCard, 
  Settings,
  ArrowRight
} from 'lucide-react';

export default function AccountSettingsPage() {
  const router = useRouter();
  const { customer } = useHumber();

  return (
    <LayoutShell>
      <div className="p-6 xl:p-8 max-w-4xl mx-auto w-full flex-1 flex flex-col gap-8">
        
        {/* HEADER */}
        <div className="border-b border-slate-900 pb-4 font-mono">
          <span className="text-xs text-slate-500 tracking-widest uppercase block mb-1">
            CLIENT SECURITY PREFERENCES
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-slate-100 uppercase">
            COMMERCIAL ACCOUNT SETTINGS
          </h1>
          <p className="text-xs text-slate-400 uppercase tracking-wider mt-1">
            REGISTRY REFERENCE: <strong className="text-orange-500">HF-89024-X // VERIFIED PROFILING</strong>
          </p>
        </div>

        {/* DETAILS LIST CONTAINER */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 font-mono text-xs uppercase">
          
          <div className="md:col-span-8 space-y-4 bg-slate-950 border border-slate-900 p-6">
            <span className="text-[10px] text-slate-500 font-bold block mb-4 border-b border-slate-900 pb-2">
              QUAYSIDE COMPANY CONTACT CREDENTIALS
            </span>

            <div className="space-y-4 text-[11px] text-slate-400">
              <div className="flex items-center gap-3">
                <Building className="w-4 h-4 text-slate-500 shrink-0" />
                <div className="flex-1 flex justify-between border-b border-slate-900 pb-1.5">
                  <span className="text-slate-500">REGISTERED CO:</span>
                  <strong className="text-slate-200">{customer.companyName}</strong>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <User className="w-4 h-4 text-slate-500 shrink-0" />
                <div className="flex-1 flex justify-between border-b border-slate-900 pb-1.5">
                  <span className="text-slate-500">DIRECTOR NAME:</span>
                  <strong className="text-slate-200">{customer.contactName}</strong>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-slate-500 shrink-0" />
                <div className="flex-1 flex justify-between border-b border-slate-900 pb-1.5">
                  <span className="text-slate-500">EMAIL CONTACT:</span>
                  <strong className="text-slate-200 lowercase">{customer.email}</strong>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <MapPin className="w-4 h-4 text-slate-500 shrink-0" />
                <div className="flex-1 flex justify-between">
                  <span className="text-slate-500">DELIVERY DEPOT:</span>
                  <strong className="text-slate-200 text-right truncate max-w-[220px]">{customer.deliveryAddress}</strong>
                </div>
              </div>
            </div>
          </div>

          <div className="md:col-span-4 bg-slate-900/30 border border-slate-900 p-6 flex flex-col justify-between">
            <div className="space-y-3">
              <span className="text-[10px] text-slate-500 font-bold block border-b border-slate-950 pb-2">
                EXCHANGE CONTROLS
              </span>
              <p className="text-[10px] text-slate-500 normal-case leading-normal font-sans">
                Review contracted margins or modify billing addresses inside the main procurement console.
              </p>
            </div>

            <div className="pt-6">
              <button 
                onClick={() => router.push('/trade')}
                className="w-full py-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 font-bold text-slate-200 hover:text-slate-100 transition-colors flex items-center justify-center gap-2 rounded"
              >
                <span>OPEN PORTAL</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>

      </div>
    </LayoutShell>
  );
}
