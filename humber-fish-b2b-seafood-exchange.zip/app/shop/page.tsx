'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { useSearchParams, useRouter } from 'next/navigation';
import { useHumber, Product } from '@/lib/humber-context';
import LayoutShell from '@/components/layout-shell';
import { 
  Anchor, 
  Search, 
  SlidersHorizontal, 
  Check, 
  Plus, 
  Minus, 
  ShoppingCart, 
  FileText, 
  ShieldCheck, 
  Compass, 
  Clock, 
  TrendingUp,
  X,
  Scale,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

function ShopPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { products, cart, addToCart, getDiscountedPrice, getPriceForQty, customer } = useHumber();

  // Filters state
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecies, setSelectedSpecies] = useState('ALL');
  const [selectedPort, setSelectedPort] = useState('ALL');
  const [selectedGrade, setSelectedGrade] = useState('ALL');
  const [selectedForm, setSelectedForm] = useState('ALL');

  // Selected Product for split-screen PDP
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  
  // Local state for pricing calculation in PDP
  const [pdpCases, setPdpCases] = useState<number>(2); // default minimum of 2 cases (10kg)

  // Sync selected product from URL if present
  useEffect(() => {
    const id = searchParams.get('id');
    if (id && products.some(p => p.id === id)) {
      setSelectedProductId(id);
    } else if (products.length > 0 && !selectedProductId) {
      // Default to first product for Bloomberg-style split terminal
      setSelectedProductId(products[0].id);
    }
  }, [searchParams, products]);

  // Reset PDP cases if product changes
  useEffect(() => {
    setPdpCases(2);
  }, [selectedProductId]);

  const activeProduct = products.find(p => p.id === selectedProductId) || products[0];

  // Extraction of filter options
  const speciesList = ['ALL', ...Array.from(new Set(products.map(p => p.name.split(' ')[p.name.split(' ').length - 1])))];
  const portList = ['ALL', 'HULL DOCKS', 'GRIMSBY DOCKS', 'BRIDLINGTON HARBOUR'];
  const gradeList = ['ALL', 'A', 'B'];
  const formList = ['ALL', 'FILLETS', 'WHOLE', 'SMOKED'];

  // Match forms loosely
  const matchForm = (formType: string, selected: string) => {
    if (selected === 'ALL') return true;
    if (selected === 'FILLETS') return formType.toLowerCase().includes('fillet');
    if (selected === 'WHOLE') return formType.toLowerCase().includes('whole');
    if (selected === 'SMOKED') return formType.toLowerCase().includes('smoked');
    return true;
  };

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.scientificName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.traceabilityRef.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSpecies = selectedSpecies === 'ALL' || p.name.toLowerCase().includes(selectedSpecies.toLowerCase());
    const matchesPort = selectedPort === 'ALL' || p.landingLocation.toUpperCase().includes(selectedPort);
    const matchesGrade = selectedGrade === 'ALL' || p.grade === selectedGrade;
    const matchesForm = matchForm(p.form, selectedForm);

    return matchesSearch && matchesSpecies && matchesPort && matchesGrade && matchesForm;
  });

  const handleSelectProduct = (id: string) => {
    setSelectedProductId(id);
    // update URL quietly
    const params = new URLSearchParams(window.location.search);
    params.set('id', id);
    router.replace(`${window.location.pathname}?${params.toString()}`);
  };

  // PDP Quantity pricing metrics
  const pdpWeight = pdpCases * (activeProduct?.caseWeightKg || 5);
  const pdpUnitPrice = activeProduct ? getPriceForQty(activeProduct, pdpWeight) : 0;
  const pdpTotal = pdpWeight * pdpUnitPrice;

  return (
    <LayoutShell>
      <div className="flex-1 flex flex-col xl:flex-row h-full">
        
        {/* LEFT COLUMN: FILTER CONTROLS & STOCK LIST */}
        <div className="flex-1 p-6 xl:p-8 border-r border-slate-900 xl:max-w-[62%] flex flex-col justify-between overflow-y-auto">
          <div>
            {/* Header section */}
            <div className="border-b border-slate-900 pb-4 mb-6">
              <span className="font-mono text-xs text-slate-500 uppercase tracking-widest block mb-1">
                SEAFOOD DIRECTORY INDEX
              </span>
              <h1 className="text-2xl font-bold font-mono tracking-tight text-slate-100 uppercase">
                B2B SEAFOOD EXCHANGE
              </h1>
              <p className="text-xs font-mono text-slate-400 uppercase tracking-wider mt-1">
                EXCHANGE RATE TIER: <strong className="text-orange-500">{customer.tier} TIER RATE ACTIVE</strong>
              </p>
            </div>

            {/* Direct Instant Search Bar */}
            <div className="relative mb-6">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input 
                type="text" 
                placeholder="FAST EXCHANGE SEARCH (E.G. COD, HADDOCK, BATCH-CD...)"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 p-3 pl-11 font-mono text-xs uppercase placeholder-slate-600 text-slate-200 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 rounded"
              />
            </div>

            {/* Compact Filter Control Rows (Zero-Pill compliant segmented design) */}
            <div className="space-y-4 bg-slate-900/30 border border-slate-900 p-4 font-mono text-xs mb-8">
              
              {/* Species Filter */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-slate-500 w-24 shrink-0 uppercase tracking-wider text-[10px]">SPECIES:</span>
                <div className="flex flex-wrap gap-1">
                  {speciesList.map(species => (
                    <button
                      key={species}
                      onClick={() => setSelectedSpecies(species)}
                      className={`px-2.5 py-1 text-[10px] rounded uppercase font-semibold transition-colors ${
                        selectedSpecies === species 
                          ? 'bg-orange-600 text-white' 
                          : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {species}
                    </button>
                  ))}
                </div>
              </div>

              {/* Landing Port Filter */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-slate-500 w-24 shrink-0 uppercase tracking-wider text-[10px]">LANDING QUAY:</span>
                <div className="flex flex-wrap gap-1">
                  {portList.map(port => (
                    <button
                      key={port}
                      onClick={() => setSelectedPort(port)}
                      className={`px-2.5 py-1 text-[10px] rounded uppercase font-semibold transition-colors ${
                        selectedPort === port 
                          ? 'bg-orange-600 text-white' 
                          : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {port.replace(' DOCKS', '').replace(' HARBOUR', '')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Form Filter */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-slate-500 w-24 shrink-0 uppercase tracking-wider text-[10px]">FORM TYPE:</span>
                <div className="flex flex-wrap gap-1">
                  {formList.map(form => (
                    <button
                      key={form}
                      onClick={() => setSelectedForm(form)}
                      className={`px-2.5 py-1 text-[10px] rounded uppercase font-semibold transition-colors ${
                        selectedForm === form 
                          ? 'bg-orange-600 text-white' 
                          : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {form}
                    </button>
                  ))}
                </div>
              </div>

              {/* Grade Filter */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-slate-500 w-24 shrink-0 uppercase tracking-wider text-[10px]">GRADE RATING:</span>
                <div className="flex flex-wrap gap-1">
                  {gradeList.map(grade => (
                    <button
                      key={grade}
                      onClick={() => setSelectedGrade(grade)}
                      className={`px-2.5 py-1 text-[10px] rounded uppercase font-semibold transition-colors ${
                        selectedGrade === grade 
                          ? 'bg-orange-600 text-white' 
                          : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {grade === 'ALL' ? 'ALL' : `GRADE ${grade}`}
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* List grid */}
            {filteredProducts.length === 0 ? (
              <div className="py-20 text-center font-mono border border-dashed border-slate-800">
                <SlidersHorizontal className="w-8 h-8 text-slate-700 mx-auto mb-3" />
                <p className="text-xs text-slate-500 uppercase tracking-wider">NO SEAFOOD MATCHES CURRENT CRITERIA.</p>
                <button 
                  onClick={() => {
                    setSearchTerm('');
                    setSelectedSpecies('ALL');
                    setSelectedPort('ALL');
                    setSelectedGrade('ALL');
                    setSelectedForm('ALL');
                  }}
                  className="mt-4 text-[10px] text-orange-500 hover:underline uppercase"
                >
                  [RESET ALL EXCHANGE FILTERS]
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredProducts.map(prod => {
                  const isSelected = selectedProductId === prod.id;
                  const discountPrice = getDiscountedPrice(prod);
                  return (
                    <div
                      key={prod.id}
                      onClick={() => handleSelectProduct(prod.id)}
                      className={`p-4 border transition-all duration-200 cursor-pointer flex flex-col justify-between font-mono relative hover:translate-y-[-2px] ${
                        isSelected 
                          ? 'border-orange-500 bg-slate-900/40 shadow-md shadow-orange-950/5' 
                          : 'border-slate-900 bg-slate-950 hover:border-slate-700'
                      }`}
                    >
                      {/* Badge in top right */}
                      <span className="absolute top-4 right-4 text-[9px] font-bold tracking-tight text-slate-500 uppercase">
                        {prod.availableCases} CASES AVAILABLE
                      </span>

                      <div>
                        {/* Title Kicker */}
                        <span className="text-[9px] text-orange-500 font-semibold uppercase block tracking-wider mb-0.5">
                          {prod.origin.replace(' (Subarea 4)', '')}
                        </span>
                        
                        <h3 className="text-sm font-bold uppercase tracking-tight text-slate-100 max-w-[70%]">
                          {prod.name}
                        </h3>
                        
                        <div className="text-[10px] text-slate-500 lowercase italic mb-3">
                          {prod.scientificName}
                        </div>

                        {/* Flat metadata text with dot separators */}
                        <div className="text-[10px] text-slate-400 uppercase flex items-center gap-1.5 flex-wrap">
                          <span>{prod.form.split(' / ')[0]}</span>
                          <span className="text-slate-600">·</span>
                          <span>GRADE {prod.grade}</span>
                          <span className="text-slate-600">·</span>
                          <span>{prod.sizeRange}</span>
                        </div>
                      </div>

                      {/* Pricing Footer */}
                      <div className="border-t border-slate-900 mt-4 pt-3 flex items-center justify-between">
                        <div className="text-left">
                          <span className="text-[9px] text-slate-500 block uppercase font-semibold">B2B QUOTE RATE</span>
                          <span className="text-slate-100 font-bold tabular-nums text-sm">
                            £{discountPrice.toFixed(2)}<span className="text-[10px] text-slate-400 font-normal">/KG</span>
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400 hover:text-orange-500 transition-colors flex items-center gap-1 uppercase">
                          <span>AUDIT RECORD</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="mt-8 border-t border-slate-900 pt-6 text-[10px] font-mono text-slate-500 flex justify-between items-center uppercase">
            <span>DOCK_REGISTRY_VERIFIED // BS 12830</span>
            <span>SHOWING {filteredProducts.length} OF {products.length} COMMODITIES</span>
          </div>
        </div>

        {/* RIGHT COLUMN: SPLIT SCREEN PDP (Stable Contiguous Purchase Module) */}
        <div className="flex-1 bg-slate-900/50 p-6 xl:p-8 xl:max-w-[38%] border-t xl:border-t-0 border-slate-900 flex flex-col justify-between overflow-y-auto">
          {activeProduct ? (
            <div className="flex flex-col gap-6">
              
              {/* Product Header */}
              <div className="border-b border-slate-800 pb-4">
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-[10px] font-semibold text-orange-500 font-mono uppercase tracking-wider">
                    {activeProduct.vesselName}
                  </span>
                  <span className="text-slate-600 text-xs font-mono">·</span>
                  <span className="text-[10px] font-mono text-slate-400 uppercase">
                    {activeProduct.traceabilityRef}
                  </span>
                </div>
                <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 uppercase">
                  {activeProduct.name}
                </h2>
                <div className="text-xs font-sans text-slate-400 italic lowercase block mt-0.5">
                  {activeProduct.scientificName}
                </div>
              </div>

              {/* Image box */}
              <div className="relative aspect-[16/10] bg-slate-950 border border-slate-800 overflow-hidden">
                {activeProduct.id === 'cod-northsea-01' ? (
                  <Image 
                    src="/src/assets/images/todays_fish_cod_1790367594701.jpg"
                    alt={activeProduct.name}
                    fill
                    sizes="(max-width: 1280px) 100vw, 35vw"
                    className="object-cover contrast-[105%] filter brightness-[90%]"
                    referrerPolicy="no-referrer"
                    priority
                  />
                ) : (
                  // Blueprint/Technical Fallback container for other products as per design guideline
                  <div className="absolute inset-0 flex flex-col justify-between p-4 bg-slate-950 border border-slate-900">
                    <div className="flex justify-between items-start text-[9px] text-slate-600 font-mono uppercase">
                      <span>CAD SCHEMATIC DESIGN</span>
                      <span>FAO ZONE: {activeProduct.faoArea}</span>
                    </div>
                    
                    <div className="flex flex-col items-center justify-center gap-2 py-4 text-center">
                      <Scale className="w-10 h-10 text-slate-800 animate-pulse" />
                      <span className="text-xs text-slate-600 font-mono uppercase font-semibold">
                        {activeProduct.name} Specimen Geometry
                      </span>
                      <span className="text-[9px] text-slate-700 font-mono uppercase font-normal">
                        Core density chilled standard BSA-290
                      </span>
                    </div>

                    <div className="text-[9px] text-slate-600 font-mono uppercase flex justify-between border-t border-slate-900 pt-2">
                      <span>FORM: {activeProduct.form}</span>
                      <span>SHELF LIFE: {activeProduct.shelfLifeDays}D</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Live Wholesale Pricing Tiers Recalculator */}
              <div className="bg-slate-950 border border-slate-800 p-4 font-mono">
                <span className="text-[10px] text-orange-500 font-bold block uppercase tracking-wider mb-3">
                  LIVE B2B WHOLESALE PRICING MATRIX
                </span>
                
                {/* Visual table grid demonstrating interpolating tiers */}
                <div className="grid grid-cols-4 border-b border-slate-850 pb-2 mb-3 text-[10px] text-slate-500 text-center">
                  <div>
                    <span className="block">1 CASE</span>
                    <strong className="text-slate-300">£{getDiscountedPrice(activeProduct).toFixed(2)}/kg</strong>
                  </div>
                  <div>
                    <span className="block">4 CASES (20kg)</span>
                    <strong className="text-slate-300">£{getPriceForQty(activeProduct, 20).toFixed(2)}/kg</strong>
                  </div>
                  <div>
                    <span className="block">10 CASES (50kg)</span>
                    <strong className="text-slate-300">£{getPriceForQty(activeProduct, 50).toFixed(2)}/kg</strong>
                  </div>
                  <div>
                    <span className="block">20 CASES (100kg+)</span>
                    <strong className="text-slate-300 text-orange-500 font-bold">£{getPriceForQty(activeProduct, 100).toFixed(2)}/kg</strong>
                  </div>
                </div>

                {/* Interactive calculator */}
                <div className="space-y-4 pt-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400 font-bold uppercase">ORDER QUANTITY CASES:</span>
                    <div className="flex items-center bg-slate-900 border border-slate-800 px-1 py-0.5 rounded">
                      <button 
                        onClick={() => setPdpCases(prev => Math.max(2, prev - 1))}
                        className="p-1.5 hover:text-slate-100 text-slate-400"
                        aria-label="Decrease cases"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-4 text-xs font-bold text-slate-200 tabular-nums w-8 text-center">
                        {pdpCases}
                      </span>
                      <button 
                        onClick={() => setPdpCases(prev => Math.min(activeProduct.availableCases, prev + 1))}
                        className="p-1.5 hover:text-slate-100 text-slate-400"
                        aria-label="Increase cases"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Calculations feedback */}
                  <div className="border-t border-slate-850 pt-3 space-y-1.5 text-xs uppercase text-slate-400">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Total Net Weight</span>
                      <span className="text-slate-200 font-semibold tabular-nums">{pdpWeight} KG</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Calculated Rate</span>
                      <span className="text-slate-200 font-semibold tabular-nums">£{pdpUnitPrice.toFixed(2)} / KG</span>
                    </div>
                    {pdpWeight >= 100 && (
                      <div className="text-[10px] text-green-500 font-semibold flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 shrink-0" />
                        MAX BULK DISCOUNT APPLIED (10% VOL DISCOUNT)
                      </div>
                    )}
                    <div className="flex justify-between border-t border-slate-850 pt-2 text-sm">
                      <span className="text-slate-300 font-bold">Estimated Cost</span>
                      <strong className="text-orange-500 font-bold tabular-nums">
                        £{pdpTotal.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </strong>
                    </div>
                  </div>
                </div>
              </div>

              {/* Spec sheet detail dropdown */}
              <div className="border border-slate-800 p-4 font-mono text-[11px] text-slate-300 space-y-2 uppercase bg-slate-950/20">
                <span className="text-[10px] text-slate-500 font-bold block mb-2">QUAYSIDE DECLARATION CODES</span>
                <div className="grid grid-cols-2 gap-x-6 gap-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-500">FAO REGION:</span>
                    <span className="text-slate-200 text-right truncate max-w-[120px]">{activeProduct.faoArea}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">CATCH TYPE:</span>
                    <span className="text-slate-200 text-right truncate max-w-[120px]">{activeProduct.catchMethod}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">SHELF LIFE:</span>
                    <span className="text-slate-200">{activeProduct.shelfLifeDays} DAYS HOLD</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">ALLERGENS:</span>
                    <span className="text-red-500">{activeProduct.allergenInfo}</span>
                  </div>
                </div>
              </div>

              {/* CTA Row */}
              <div className="flex flex-col gap-2 font-mono">
                <button
                  onClick={() => {
                    addToCart(activeProduct.id, pdpCases);
                    alert(`Added ${pdpCases} Cases of ${activeProduct.name} (${pdpWeight} KG) to Load Builder.`);
                  }}
                  className="w-full bg-orange-600 hover:bg-orange-500 text-slate-100 py-3.5 text-xs font-bold tracking-widest uppercase transition-colors rounded shadow-lg shadow-orange-950/20"
                >
                  ADD {pdpCases} CASES TO BUILDER (£{pdpTotal.toFixed(2)})
                </button>
                
                <button
                  onClick={() => router.push(`/trace?batch=${activeProduct.traceabilityRef}`)}
                  className="w-full py-2.5 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200 text-xs uppercase tracking-wider transition-colors rounded"
                >
                  TRACE THIS BATCH ({activeProduct.traceabilityRef})
                </button>
              </div>

            </div>
          ) : (
            <div className="py-24 text-center font-mono">
              <span className="text-slate-600 block mb-2">SELECT SPECIES ON GRID</span>
              <span className="text-slate-700 text-[11px] block uppercase">No exchange specimen selected</span>
            </div>
          )}

          <div className="mt-8 border-t border-slate-800 pt-4 flex items-center justify-between text-[10px] font-mono text-slate-500 uppercase">
            <span>VESSEL: {activeProduct?.vesselName || 'POLAR PRINCE'}</span>
            <span>SYSTEM LOCKED</span>
          </div>
        </div>

      </div>
    </LayoutShell>
  );
}

export default function ShopPage() {
  return (
    <React.Suspense fallback={
      <LayoutShell>
        <div className="p-12 text-center font-mono max-w-md mx-auto my-16 text-slate-500 uppercase text-xs">
          Loading Seafood Directory...
        </div>
      </LayoutShell>
    }>
      <ShopPageContent />
    </React.Suspense>
  );
}
