import { redirect } from 'next/navigation';

interface ProductPageProps {
  params: Promise<{
    product: string;
  }>;
}

export default async function ProductDetailPage({ params }: ProductPageProps) {
  const resolvedParams = await params;
  // Redirect directly to the high-density trading view at /shop, highlighting the selected product
  redirect(`/shop?id=${resolvedParams.product}`);
}
