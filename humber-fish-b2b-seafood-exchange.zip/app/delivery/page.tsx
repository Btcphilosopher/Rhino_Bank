'use client';

import React, { useState } from 'react';
import { useHumber, DeliveryStage } from '@/lib/humber-context';
import LayoutShell from '@/components/layout-shell';
import { 
  Truck, 
  Thermometer, 
  ShieldCheck, 
  Clock, 
  MapPin, 
  Activity, 
  ChevronRight, 
  Check, 
  AlertTriangle,
  History,
  Scale,
  User,
  Compass
} from 'lucide-react';
import { motion } from 'motion/react';

export default function DeliveryTrackingPage() {
  const { orders, activeDelivery } = useHumber();

  // If there's an active dispatch order in the context, trace it! Otherwise, fall back on their latest historical order (ORD-9842)
  const defaultOrder = orders.find(o => o.id === 'ORD-9842') || orders[0];
  const tracker = activeDelivery || defaultOrder?.deliveryTracker;

  if (!tracker) {
    return (
      <LayoutShell>
        <div className="p-12 text-center font-mono max-w-md mx-auto my-16">
          <Truck className="w-12 h-12 text-slate-700 mx-auto mb-4" />
          <h2 className="text-sm font-bold uppercase text-slate-300">NO DELIVERIES REGISTERED</h2>
          <p className="text-xs text-slate-500 uppercase mt-2">
            Assemble a seafood load in the Load Builder and check out to instantiate active cold chain fleet tracking.
          </p>
        </div>
      </LayoutShell>
    );
  }

  // Stages definition for timeline progression
  const STAGES: { stage: DeliveryStage; label: string; desc: string }[] = [
    { stage: 'ORDER_CONFIRMED', label: 'CONFIRMED', desc: 'Sourcing quayside' },
    { stage: 'PACKING', label: 'PACKED', desc: 'EPS ice insulated' },
    { stage: 'COLD_STORAGE', label: 'COLD STORAGE', desc: 'Hold room #3' },
    { stage: 'DISPATCHED', label: 'DISPATCHED', desc: 'Cargo loaded' },
    { stage: 'IN_TRANSIT', label: 'IN TRANSIT', desc: 'Fleet telemetry' },
    { stage: 'DELIVERED', label: 'DELIVERED', desc: 'Handover complete' }
  ];

  // Helper to find index of current stage to light up timeline
  const currentStageIndex = STAGES.findIndex(s => s.stage === tracker.stage);

  return (
    <LayoutShell>
      <div className="p-6 xl:p-8 max-w-6xl mx-auto w-full flex-1 flex flex-col gap-8">
        
        {/* HEADER */}
        <div className="border-b border-slate-900 pb-4 flex flex-col md:flex-row justify-between items-start md:items-end gap-4 font-mono">
          <div>
            <span className="text-xs text-slate-500 tracking-widest uppercase block mb-1">
              FLEET TELEMETRY NETWORK
            </span>
            <h1 className="text-2xl font-bold tracking-tight text-slate-100 uppercase">
              COLD CHAIN LOGISTICS SYSTEM
            </h1>
            <p className="text-xs text-slate-400 uppercase tracking-wider mt-1">
              TRACKING DISPATCH: <strong className="text-orange-500">{tracker.orderId} // VEHICLE {tracker.vehicleReg}</strong>
            </p>
          </div>
          
          <div className="flex items-center gap-3">
            {/* Real-time telemetry temperature status bubble */}
            <div className={`p-2.5 border font-mono text-[11px] uppercase flex items-center gap-2 rounded ${
              tracker.tempStatus === 'STABLE' 
                ? 'bg-green-950/20 border-green-900/60 text-green-400' 
                : 'bg-red-950/20 border-red-900/60 text-red-400'
            }`}>
              <Thermometer className="w-4 h-4 shrink-0" />
              <span>COLD CHAIN: {tracker.temperatureCelsius.toFixed(1)}°C {tracker.tempStatus}</span>
            </div>
          </div>
        </div>

        {/* HORIZONTAL LOGISTICS TIMELINE */}
        <div className="bg-slate-950 border border-slate-900 p-6 font-mono text-xs uppercase overflow-x-auto">
          <span className="text-[10px] text-slate-500 font-bold block mb-6">FLEET TRANSIT SEQUENCE STATE</span>
          
          <div className="flex justify-between items-stretch gap-4 min-w-[800px] relative pb-2">
            {/* Connecting background tracking line */}
            <div className="absolute left-[8%] right-[8%] top-5 h-[2px] bg-slate-900 z-0" />

            {STAGES.map((s, idx) => {
              const isPast = idx < currentStageIndex;
              const isCurrent = idx === currentStageIndex;
              const isFuture = idx > currentStageIndex;

              return (
                <div key={s.stage} className="flex-1 flex flex-col items-center text-center z-10 relative">
                  
                  {/* Outer circle status indicator */}
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-3 transition-colors ${
                    isPast 
                      ? 'bg-slate-900 border-2 border-green-500 text-green-500' 
                      : isCurrent 
                        ? 'bg-orange-600 border-2 border-orange-500 text-white animate-pulse' 
                        : 'bg-slate-950 border-2 border-slate-900 text-slate-600'
                  }`}>
                    {isPast ? (
                      <Check className="w-5 h-5 shrink-0" />
                    ) : (
                      <span className="font-bold text-[11px] tabular-nums">{idx + 1}</span>
                    )}
                  </div>

                  <span className={`text-[11px] font-bold ${isCurrent ? 'text-orange-500' : isFuture ? 'text-slate-600' : 'text-slate-300'}`}>
                    {s.label}
                  </span>
                  <span className="text-[9px] text-slate-500 lowercase italic mt-0.5 font-sans">
                    {s.desc}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* DETAILED FLEET TELEMETRY GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 font-mono text-xs uppercase">
          
          {/* Tracking Ledger (left) */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            
            {/* Basic Spec Sheet */}
            <div className="bg-slate-900/30 border border-slate-900 p-5 space-y-3">
              <span className="text-[10px] text-slate-500 font-bold block mb-2">FLEET TELEMETRY MANIFEST</span>
              
              <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-[11px]">
                <div className="flex justify-between border-b border-slate-950 pb-1.5 col-span-2">
                  <span className="text-slate-500">CARGO VALUE OWNER:</span>
                  <span className="text-slate-200">TOM HARRISON</span>
                </div>
                <div className="flex justify-between border-b border-slate-950 pb-1.5 col-span-2">
                  <span className="text-slate-500">DELIVERY DESTINATION:</span>
                  <span className="text-slate-200 text-right truncate max-w-[180px]">{tracker.destination}</span>
                </div>
                <div className="flex justify-between border-b border-slate-950 pb-1.5">
                  <span className="text-slate-500">VEHICLE REG:</span>
                  <span className="text-slate-200 font-bold">{tracker.vehicleReg}</span>
                </div>
                <div className="flex justify-between border-b border-slate-950 pb-1.5">
                  <span className="text-slate-500">TOTAL WEIGHT:</span>
                  <span className="text-slate-200">{tracker.weightKg} KG</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">FLEET CONDUCTOR:</span>
                  <span className="text-slate-200 truncate max-w-[100px]">{tracker.operator.split(' ')[0]}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">ETA WINDOW:</span>
                  <span className="text-orange-500 font-bold text-[10px] truncate max-w-[110px]">{tracker.estimatedDeliveryWindow}</span>
                </div>
              </div>
            </div>

            {/* Stages log chronicle */}
            <div className="bg-slate-950 border border-slate-900 p-5 flex-1 flex flex-col justify-between">
              <div>
                <span className="text-[10px] text-slate-500 font-bold block mb-4">CHRONOLOGICAL DISPATCH LOGS</span>
                <div className="space-y-4 max-h-[220px] overflow-y-auto pr-2">
                  {tracker.stagesLog.map((log, lIdx) => (
                    <div key={lIdx} className="flex gap-3 text-[11px] border-l border-slate-900 pl-3 relative">
                      <div className="absolute left-[-4.5px] top-1 w-2 h-2 rounded-full bg-slate-100" />
                      <div className="flex-1">
                        <div className="flex justify-between text-[10px] text-slate-500 font-bold mb-1">
                          <span>{log.stage.replace('_', ' ')}</span>
                          <span>{log.timestamp.split(' ')[1] || log.timestamp}</span>
                        </div>
                        <p className="text-slate-400 leading-normal normal-case font-sans">
                          {log.note}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="text-[9px] text-slate-600 border-t border-slate-900 pt-3 mt-4 text-center">
                LOG STREAM SYNC_OK // CLK: 2026-09-25
              </div>
            </div>

          </div>

          {/* Graphical Map Diagram (right) */}
          <div className="lg:col-span-7 bg-slate-950 border border-slate-900 p-6 flex flex-col justify-between min-h-[400px] relative overflow-hidden">
            
            {/* Background design lines */}
            <div className="absolute inset-0 z-0 opacity-15 bg-[linear-gradient(rgba(148,163,184,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(148,163,184,0.05)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none" />

            <div className="z-10 flex justify-between items-center text-[10px] text-slate-500 border-b border-slate-900 pb-3">
              <span>HUMBER LOGISTICS GEOMETRY COORDINATOR</span>
              <span className="text-slate-400">MODEL ID: ESTUARY-MAP-V4</span>
            </div>

            {/* Simulated route diagram */}
            <div className="z-10 flex-1 flex flex-col justify-center items-center py-6 relative">
              
              {/* Central Map diagram */}
              <div className="w-full max-w-sm aspect-video border border-slate-900 bg-slate-900/10 p-4 rounded relative flex items-center justify-center">
                
                {/* Humber river shape represented abstractly */}
                <div className="absolute left-0 right-0 h-4 bg-slate-900/60 skew-y-[-15deg] blur-[1px] z-0" />
                
                {/* Docks node */}
                <div className="absolute left-8 top-12 z-10 flex flex-col items-center">
                  <div className="w-5 h-5 bg-slate-900 border border-slate-700 flex items-center justify-center rounded">
                    <Compass className="w-3 h-3 text-slate-400" />
                  </div>
                  <span className="text-[8px] text-slate-500 mt-1">DOCK_HULL</span>
                </div>

                {/* Central processing facility node */}
                <div className="absolute left-24 top-1/2 -translate-y-1/2 z-10 flex flex-col items-center">
                  <div className="w-6 h-6 bg-slate-950 border border-slate-700 flex items-center justify-center rounded-full">
                    <Activity className="w-3.5 h-3.5 text-orange-500 animate-pulse" />
                  </div>
                  <span className="text-[8px] text-orange-500 mt-1 font-bold">HUMBER_BASE</span>
                </div>

                {/* Grimsby node */}
                <div className="absolute right-28 bottom-6 z-10 flex flex-col items-center">
                  <div className="w-5 h-5 bg-slate-900 border border-slate-700 flex items-center justify-center rounded">
                    <Compass className="w-3 h-3 text-slate-400" />
                  </div>
                  <span className="text-[8px] text-slate-500 mt-1">GRIMSBY_PORT</span>
                </div>

                {/* Active truck vector en route */}
                <div className="absolute right-12 top-10 z-20 flex flex-col items-center bg-slate-950/90 border border-orange-500/50 p-1 rounded shadow-lg animate-pulse">
                  <div className="flex items-center gap-1">
                    <Truck className="w-4.5 h-4.5 text-orange-500" />
                    <span className="text-[8px] text-slate-100 font-bold">{tracker.vehicleReg}</span>
                  </div>
                  <span className="text-[6px] text-orange-400 mt-0.5">EN ROUTE // {tracker.temperatureCelsius.toFixed(1)}°C</span>
                </div>

                {/* Client Node destination */}
                <div className="absolute right-4 bottom-14 z-10 flex flex-col items-center">
                  <div className="w-5 h-5 bg-green-950 border border-green-800 flex items-center justify-center rounded-full">
                    <Check className="w-3 h-3 text-green-500" />
                  </div>
                  <span className="text-[8px] text-green-500 mt-1 font-bold">CLIENT_HOLD</span>
                </div>

                {/* Dot routes */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none z-0 opacity-40">
                  {/* Quayside to Base */}
                  <line x1="15%" y1="40%" x2="30%" y2="50%" stroke="#475569" strokeWidth="1" strokeDasharray="3,3" />
                  {/* Grimsby to Base */}
                  <line x1="68%" y1="80%" x2="30%" y2="50%" stroke="#475569" strokeWidth="1" strokeDasharray="3,3" />
                  {/* Base to Client (Active) */}
                  <line x1="30%" y1="50%" x2="88%" y2="60%" stroke="#ea580c" strokeWidth="1.5" />
                </svg>

              </div>

              <div className="mt-4 text-center max-w-sm">
                <span className="text-slate-100 font-semibold block text-[11px] uppercase tracking-wide">
                  ACTIVE ROUTE PATHWAY: A1033 / TRANSIT ZONE IV
                </span>
                <p className="text-[10px] text-slate-500 lowercase italic leading-relaxed mt-1 font-sans">
                  The vehicle is traversing the Hull quayside logistics corridors. Continuous real-time RF reporting is passing integrity tests successfully.
                </p>
              </div>

            </div>

            {/* Indicators summary at bottom */}
            <div className="z-10 pt-4 border-t border-slate-900 grid grid-cols-3 text-center text-[10px] text-slate-500 gap-4">
              <div>
                <span className="block text-slate-600">RF TELEMETRY STATUS</span>
                <strong className="text-green-500">SYNC_OK (100%)</strong>
              </div>
              <div>
                <span className="block text-slate-600">STREET POSITION</span>
                <strong className="text-slate-200">53.7431° N, 0.2812° W</strong>
              </div>
              <div>
                <span className="block text-slate-600">EST. CONSIGNMENT RANGE</span>
                <strong className="text-slate-200">22.8 MILES</strong>
              </div>
            </div>

          </div>

        </div>

      </div>
    </LayoutShell>
  );
}
