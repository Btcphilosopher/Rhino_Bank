'use client';

import React, { useState, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { useHumber } from '@/lib/humber-context';
import LayoutShell from '@/components/layout-shell';
import { 
  ShieldCheck, 
  Search, 
  MapPin, 
  Clock, 
  Compass, 
  Database, 
  Anchor, 
  Thermometer, 
  TrendingUp,
  FileText,
  Ship,
  Truck,
  Forklift,
  Layers,
  Activity
} from 'lucide-react';
import { motion } from 'motion/react';

function TraceabilityPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { products, traceBatch } = useHumber();

  const [searchBatchId, setSearchBatchId] = useState('');
  const [activeBatchId, setActiveBatchId] = useState('');

  // Sync batch from URL search param if present
  useEffect(() => {
    const batch = searchParams.get('batch');
    if (batch) {
      setActiveBatchId(batch.toUpperCase());
      setSearchBatchId(batch.toUpperCase());
    } else if (products.length > 0 && !activeBatchId) {
      // Default to the first product's batch
      setActiveBatchId(products[0].traceabilityRef);
      setSearchBatchId(products[0].traceabilityRef);
    }
  }, [searchParams, products]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchBatchId.trim()) {
      setActiveBatchId(searchBatchId.toUpperCase().trim());
      // update URL
      const params = new URLSearchParams(window.location.search);
      params.set('batch', searchBatchId.trim());
      router.replace(`${window.location.pathname}?${params.toString()}`);
    }
  };

  const selectedProduct = products.find(p => p.traceabilityRef === activeBatchId);
  const timeline = traceBatch(activeBatchId || 'BATCH-CD-048-A');

  return (
    <LayoutShell>
      <div className="p-6 xl:p-8 max-w-5xl mx-auto w-full flex-1 flex flex-col gap-8">
        
        {/* HEADER */}
        <div className="border-b border-slate-900 pb-4 font-mono">
          <span className="text-xs text-slate-500 tracking-widest uppercase block mb-1">
            REGULATORY COMPLIANCE LEDGER
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-slate-100 uppercase">
            B2B SEAFOOD TRACEABILITY AUDIT
          </h1>
          <p className="text-xs text-slate-400 uppercase tracking-wider mt-1">
            STANDARDS RATIFIED: <strong className="text-green-500">FAO GMDN / HACCP BS EN ISO 9001</strong>
          </p>
        </div>

        {/* SEARCH & QUICK CHOOSE ROW */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 font-mono text-xs">
          
          {/* Custom Search Form */}
          <form onSubmit={handleSearchSubmit} className="md:col-span-6 relative flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input 
                type="text" 
                placeholder="ENTER VESSEL BATCH ID (E.G. BATCH-CD-048-A...)"
                value={searchBatchId}
                onChange={(e) => setSearchBatchId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 p-3 pl-11 uppercase placeholder-slate-600 text-slate-200 focus:outline-none focus:border-orange-500 rounded"
              />
            </div>
            <button 
              type="submit"
              className="bg-orange-600 hover:bg-orange-500 text-white font-bold px-4 uppercase rounded transition-colors"
            >
              TRACE
            </button>
          </form>

          {/* Quick Select Specimen dropdown */}
          <div className="md:col-span-6 flex items-center bg-slate-900/30 border border-slate-900 p-2.5 rounded gap-3">
            <span className="text-slate-500 uppercase tracking-wider text-[10px] shrink-0 font-bold">
              ACTIVE BATCHES:
            </span>
            <div className="flex flex-wrap gap-1.5 overflow-x-auto max-w-full">
              {products.slice(0, 4).map(p => (
                <button
                  key={p.id}
                  onClick={() => {
                    setSearchBatchId(p.traceabilityRef);
                    setActiveBatchId(p.traceabilityRef);
                    router.replace(`/trace?batch=${p.traceabilityRef}`);
                  }}
                  className={`px-2 py-1 text-[10px] uppercase font-semibold rounded transition-colors ${
                    activeBatchId === p.traceabilityRef 
                      ? 'bg-slate-100 text-slate-950 font-bold' 
                      : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {p.traceabilityRef}
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* ACTIVE BATCH PROFILE BRIEF */}
        {selectedProduct ? (
          <div className="bg-slate-900/30 border border-slate-900 p-6 font-mono text-xs uppercase grid grid-cols-1 md:grid-cols-12 gap-6">
            
            <div className="md:col-span-6 border-b md:border-b-0 md:border-r border-slate-800 pb-4 md:pb-0 md:pr-6 space-y-2">
              <span className="text-slate-500 text-[10px] block">AUDITED SPECIES CHARACTERISTICS</span>
              <div className="text-sm font-bold text-slate-100">
                {selectedProduct.name} ({selectedProduct.scientificName})
              </div>
              <div className="text-slate-400">
                Landing Harbor: <strong className="text-slate-200">{selectedProduct.landingLocation}</strong>
              </div>
              <div className="text-slate-400">
                Vessel: <strong className="text-slate-200">{selectedProduct.vesselName}</strong>
              </div>
            </div>

            <div className="md:col-span-6 space-y-2">
              <span className="text-slate-500 text-[10px] block">HARVEST & REGULATORY PROFILE</span>
              <div className="text-slate-400">
                Catching Method: <strong className="text-slate-200">{selectedProduct.catchMethod}</strong>
              </div>
              <div className="text-slate-400">
                FAO Geographic Area: <strong className="text-slate-200">{selectedProduct.faoArea}</strong>
              </div>
              <div className="text-slate-400 flex items-center gap-1">
                <span>Verification State:</span>
                <span className="text-green-500 font-bold flex items-center gap-1">
                  <ShieldCheck className="w-4 h-4 shrink-0" />
                  AUTHENTICATED RECORD
                </span>
              </div>
            </div>

          </div>
        ) : (
          <div className="bg-slate-900/10 border border-slate-900 p-4 font-mono text-xs uppercase text-slate-500 text-center">
            CUSTOM BATCH TELEMETRY REGISTERED FOR TRACING ({activeBatchId})
          </div>
        )}

        {/* VERTICAL / HORIZONTAL AUDIT TIMELINE */}
        <div className="relative font-mono">
          {/* Vertical connecting line */}
          <div className="absolute left-6 md:left-[50%] top-4 bottom-4 w-0.5 bg-slate-900 z-0" />

          <div className="space-y-12">
            {timeline.map((event, idx) => {
              const isEven = idx % 2 === 0;
              
              // Custom icons for stages to look highly polished
              let stageIcon = <Anchor className="w-4 h-4" />;
              if (event.stage === 'SEA') stageIcon = <Ship className="w-4 h-4 text-blue-400" />;
              if (event.stage === 'LANDING') stageIcon = <Anchor className="w-4 h-4 text-orange-500" />;
              if (event.stage === 'HUMBER FACILITY') stageIcon = <Layers className="w-4 h-4 text-slate-300" />;
              if (event.stage === 'PROCESSING') stageIcon = <Activity className="w-4 h-4 text-red-400" />;
              if (event.stage === 'PACKING') stageIcon = <Layers className="w-4 h-4 text-green-400" />;
              if (event.stage === 'COLD STORE') stageIcon = <Forklift className="w-4 h-4 text-blue-500" />;
              if (event.stage === 'CUSTOMER') stageIcon = <Truck className="w-4 h-4 text-orange-500 animate-pulse" />;

              return (
                <div 
                  key={event.stage}
                  className={`relative flex flex-col md:flex-row items-start md:items-center justify-between gap-4 md:gap-0 ${
                    isEven ? 'md:flex-row-reverse' : ''
                  }`}
                >
                  
                  {/* Circle indicator on line */}
                  <div className="absolute left-6 md:left-[50%] -translate-x-[50%] z-10 w-8 h-8 rounded-full bg-slate-950 border-2 border-slate-800 flex items-center justify-center text-slate-300">
                    {stageIcon}
                  </div>

                  {/* Card Block */}
                  <div className={`w-full md:w-[45%] pl-14 md:pl-0 ${isEven ? 'md:text-right' : 'md:text-left'}`}>
                    <div className="p-5 bg-slate-950 border border-slate-900 hover:border-slate-800 transition-colors">
                      <div className="flex flex-wrap items-center md:justify-start gap-2 text-[10px] text-slate-500 font-bold mb-2">
                        <span className="text-orange-500">{event.stage}</span>
                        <span>·</span>
                        <span>{event.timestamp}</span>
                      </div>

                      <h3 className="text-xs font-bold text-slate-200 uppercase mb-1">
                        {event.location}
                      </h3>
                      <p className="text-[11px] text-slate-400 normal-case leading-relaxed font-sans mb-3">
                        {event.description}
                      </p>

                      {/* Micro metadata row */}
                      <div className={`text-[10px] text-slate-500 flex flex-wrap gap-2 uppercase border-t border-slate-900 pt-3 ${
                        isEven ? 'md:justify-end' : 'md:justify-start'
                      }`}>
                        <span>OP: {event.operator}</span>
                        {event.tempCelsius !== undefined && (
                          <>
                            <span className="text-slate-700">|</span>
                            <span className="flex items-center gap-0.5 font-bold text-green-500">
                              <Thermometer className="w-3 h-3 shrink-0" />
                              {event.tempCelsius}°C
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Empty spacer block for alignment on desktop */}
                  <div className="hidden md:block w-[45%]" />

                </div>
              );
            })}
          </div>
        </div>

        {/* BOTTOM METRIC */}
        <div className="mt-12 bg-slate-900/20 border border-slate-900 p-6 rounded text-center font-mono text-xs uppercase text-slate-500 space-y-2">
          <ShieldCheck className="w-8 h-8 text-green-500 mx-auto mb-2" />
          <p className="text-slate-300 font-bold">BLOCKCHAINED RECORD ASSURED</p>
          <p className="text-[10px] leading-relaxed max-w-xl mx-auto">
            This shipment is stamped with cryptographic port credentials. Any temperature deviation or delay in quayside intake instantly registers and alerts compliance coordinators.
          </p>
        </div>

      </div>
    </LayoutShell>
  );
}

export default function TraceabilityPage() {
  return (
    <React.Suspense fallback={
      <LayoutShell>
        <div className="p-12 text-center font-mono max-w-md mx-auto my-16 text-slate-500 uppercase text-xs">
          Loading Traceability Ledger...
        </div>
      </LayoutShell>
    }>
      <TraceabilityPageContent />
    </React.Suspense>
  );
}
