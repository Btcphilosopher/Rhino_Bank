import { redirect } from 'next/navigation';

interface BatchPageProps {
  params: Promise<{
    batch: string;
  }>;
}

export default async function TraceBatchDetailPage({ params }: BatchPageProps) {
  const resolvedParams = await params;
  // Redirect to the main Traceability ledger highlighting the requested batch
  redirect(`/trace?batch=${resolvedParams.batch}`);
}
