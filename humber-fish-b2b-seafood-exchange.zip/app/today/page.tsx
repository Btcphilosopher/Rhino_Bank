'use client';

import React, { useState, useEffect } from 'react';
import { useHumber, Product } from '@/lib/humber-context';
import LayoutShell from '@/components/layout-shell';
import { 
  TrendingUp, 
  TrendingDown, 
  ShoppingCart, 
  Activity, 
  AlertTriangle,
  Clock,
  Compass,
  Zap,
  ArrowUpRight,
  Plus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function TodayMarketPage() {
  const { products, landings, addToCart, getDiscountedPrice } = useHumber();
  const [lastUpdated, setLastUpdated] = useState<string>('');
  
  // Track previous prices and stocks to highlight changes in the board
  const [prevProductStates, setPrevProductStates] = useState<{ [id: string]: { price: number, stock: number } }>({});
  const [flashStates, setFlashStates] = useState<{ [id: string]: 'price-up' | 'price-down' | 'stock-up' | 'stock-down' | null }>({});

  useEffect(() => {
    const now = new Date();
    setLastUpdated(now.toTimeString().split(' ')[0]);
  }, [products]);

  // Handle flash highlights when the synthetic simulator updates states
  useEffect(() => {
    const newFlashes: typeof flashStates = {};
    let hasChanges = false;

    products.forEach(p => {
      const prev = prevProductStates[p.id];
      if (prev) {
        if (p.basePricePerKg > prev.price) {
          newFlashes[p.id] = 'price-up';
          hasChanges = true;
        } else if (p.basePricePerKg < prev.price) {
          newFlashes[p.id] = 'price-down';
          hasChanges = true;
        } else if (p.availableCases > prev.stock) {
          newFlashes[p.id] = 'stock-up';
          hasChanges = true;
        } else if (p.availableCases < prev.stock) {
          newFlashes[p.id] = 'stock-down';
          hasChanges = true;
        }
      }
    });

    if (hasChanges) {
      setFlashStates(newFlashes);
      // Fade flash after 1.5 seconds
      const timer = setTimeout(() => {
        setFlashStates({});
      }, 1500);
      
      // Update cache
      const nextCache: typeof prevProductStates = {};
      products.forEach(p => {
        nextCache[p.id] = { price: p.basePricePerKg, stock: p.availableCases };
      });
      setPrevProductStates(nextCache);

      return () => clearTimeout(timer);
    } else if (Object.keys(prevProductStates).length === 0) {
      // First run cache seeding
      const initialCache: typeof prevProductStates = {};
      products.forEach(p => {
        initialCache[p.id] = { price: p.basePricePerKg, stock: p.availableCases };
      });
      setPrevProductStates(initialCache);
    }
  }, [products]);

  return (
    <LayoutShell>
      <div className="p-6 xl:p-8 max-w-7xl mx-auto w-full flex-1 flex flex-col gap-8">
        
        {/* PAGE HEADER */}
        <div className="border-b border-slate-900 pb-4 flex flex-col md:flex-row justify-between items-start md:items-end gap-4 font-mono">
          <div>
            <span className="text-xs text-slate-500 tracking-widest uppercase block mb-1">
              PORT MARKET TELEMETRY
            </span>
            <h1 className="text-2xl font-bold tracking-tight text-slate-100 uppercase">
              LIVE MARKET LEDGER BOARD
            </h1>
            <p className="text-xs text-slate-400 uppercase tracking-wider mt-1">
              CORE EXCHANGE STATUS: <strong className="text-green-500">TRADING DESK ACTIVE</strong>
            </p>
          </div>
          
          <div className="flex items-center gap-4 text-xs text-slate-500 uppercase">
            <span>LAST SYNCHRONIZED: <strong className="text-slate-200 tabular-nums">{lastUpdated}</strong></span>
            <span className="hidden md:inline">|</span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              FREQUENCY: 6S REFRESH
            </span>
          </div>
        </div>

        {/* METADATA OVERVIEW BANNER */}
        <div className="grid grid-cols-2 md:grid-cols-4 border border-slate-900 bg-slate-900/10 p-4 font-mono text-[11px] text-slate-500 gap-4 uppercase text-center">
          <div>
            <span className="block text-[10px] text-slate-600">ESTUARY VESSELS DOCKED</span>
            <strong className="text-slate-200 font-bold text-sm">4 SHIPS</strong>
          </div>
          <div>
            <span className="block text-[10px] text-slate-600">AVERAGE CORE CONVERGENCY</span>
            <strong className="text-green-500 font-bold text-sm">+1.5°C STABLE</strong>
          </div>
          <div>
            <span className="block text-[10px] text-slate-600">GRADED LOTS RESOLVED</span>
            <strong className="text-slate-200 font-bold text-sm">1,249 CASES</strong>
          </div>
          <div>
            <span className="block text-[10px] text-slate-600">EXCHANGE SPREAD TIER</span>
            <strong className="text-orange-500 font-bold text-sm">WHOLESALE LIQUID</strong>
          </div>
        </div>

        {/* LIVE COMMODITIES EXCHANGE BOARD (DESKTOP) */}
        <div className="hidden md:block border border-slate-900 overflow-hidden bg-slate-950">
          <table className="w-full font-mono text-xs uppercase text-left border-collapse">
            <thead>
              <tr className="bg-slate-900/60 border-b border-slate-900 text-slate-500 text-[10px] tracking-wider">
                <th className="py-4 px-4 font-semibold">SPECIES CODE / LATIN</th>
                <th className="py-4 px-4 font-semibold">LANDING POINT / ORIGIN</th>
                <th className="py-4 px-4 font-semibold">GRADE</th>
                <th className="py-4 px-4 font-semibold">CASE SPEC</th>
                <th className="py-4 px-4 font-semibold text-right">AVAILABLE CASES</th>
                <th className="py-4 px-4 font-semibold text-right">WHOLESALE RATE/KG</th>
                <th className="py-4 px-4 font-semibold text-right">ACTION</th>
              </tr>
            </thead>
            <tbody>
              {products.map(p => {
                const discountPrice = getDiscountedPrice(p);
                const flash = flashStates[p.id];
                
                // Highlight classes based on simulated change
                let stockClass = "text-slate-300";
                let priceClass = "text-orange-500 font-semibold";
                
                if (flash === 'stock-up') stockClass = "text-green-400 bg-green-950/20 font-bold";
                if (flash === 'stock-down') stockClass = "text-red-400 bg-red-950/20 font-bold";
                if (flash === 'price-up') priceClass = "text-red-500 bg-red-950/20 font-bold";
                if (flash === 'price-down') priceClass = "text-green-400 bg-green-950/20 font-bold";

                return (
                  <tr 
                    key={p.id} 
                    className="border-b border-slate-900 hover:bg-slate-900/25 transition-colors"
                  >
                    <td className="py-4 px-4">
                      <div className="font-bold text-slate-100">{p.name}</div>
                      <div className="text-[10px] text-slate-500 lowercase italic font-sans">{p.scientificName}</div>
                    </td>
                    <td className="py-4 px-4 text-slate-400">
                      <div>{p.landingLocation.replace(', UK', '')}</div>
                      <div className="text-[10px] text-slate-600 font-mono">{p.origin.replace(' (Subarea 4)', '')}</div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="px-2 py-0.5 border border-slate-800 text-[10px] text-slate-300 rounded font-bold">
                        {p.grade}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-slate-400">
                      <div>{p.form.split(' / ')[0]}</div>
                      <div className="text-[10px] text-slate-600">{p.caseWeightKg}KG CASES</div>
                    </td>
                    <td className={`py-4 px-4 text-right tabular-nums transition-all ${stockClass}`}>
                      {p.availableCases} CASES
                    </td>
                    <td className={`py-4 px-4 text-right tabular-nums transition-all ${priceClass}`}>
                      £{discountPrice.toFixed(2)}
                    </td>
                    <td className="py-4 px-4 text-right">
                      <button 
                        onClick={() => {
                          addToCart(p.id, 2);
                          alert(`Added 2 Cases of ${p.name} (10 KG) to Load Builder.`);
                        }}
                        className="p-2 px-3 bg-slate-900 border border-slate-800 hover:border-orange-500 hover:text-slate-100 text-[11px] text-slate-300 rounded uppercase font-semibold transition-colors flex items-center gap-1.5 ml-auto"
                      >
                        <ShoppingCart className="w-3.5 h-3.5 text-orange-500" />
                        <span>ADD 2 CASES</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* MOBILE CARD LIST VERSION */}
        <div className="md:hidden space-y-4">
          {products.map(p => {
            const discountPrice = getDiscountedPrice(p);
            const flash = flashStates[p.id];
            
            let cardBorder = "border-slate-900";
            if (flash === 'stock-up' || flash === 'price-down') cardBorder = "border-green-500";
            if (flash === 'stock-down' || flash === 'price-up') cardBorder = "border-red-500";

            return (
              <div 
                key={`mobile-${p.id}`} 
                className={`p-4 bg-slate-950 border font-mono text-xs uppercase space-y-3 transition-colors ${cardBorder}`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <strong className="text-slate-100 block text-sm">{p.name}</strong>
                    <span className="text-[10px] text-slate-500 italic lowercase block font-sans">{p.scientificName}</span>
                  </div>
                  <span className="bg-slate-900 px-2 py-0.5 border border-slate-800 text-[10px] text-slate-300 rounded font-bold">
                    GRADE {p.grade}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400">
                  <div>
                    <span className="text-slate-600 text-[9px] block">ORIGIN</span>
                    {p.origin.replace(' (Subarea 4)', '')}
                  </div>
                  <div>
                    <span className="text-slate-600 text-[9px] block">LANDING</span>
                    {p.landingLocation.replace(', UK', '')}
                  </div>
                  <div>
                    <span className="text-slate-600 text-[9px] block">FORM / CASE</span>
                    {p.form.split(' / ')[0]} · {p.caseWeightKg}KG
                  </div>
                  <div>
                    <span className="text-slate-600 text-[9px] block">STOCK LEVEL</span>
                    <span className={flash ? 'text-orange-500 font-bold' : 'text-slate-200'}>
                      {p.availableCases} Cases
                    </span>
                  </div>
                </div>

                <div className="border-t border-slate-900 pt-3 flex justify-between items-center">
                  <div>
                    <span className="text-slate-600 text-[9px] block">B2B RATE</span>
                    <strong className="text-orange-500 text-sm tabular-nums">£{discountPrice.toFixed(2)}/KG</strong>
                  </div>
                  <button 
                    onClick={() => {
                      addToCart(p.id, 2);
                      alert(`Added 2 Cases of ${p.name} (10 KG) to Load Builder.`);
                    }}
                    className="py-1.5 px-3 bg-slate-900 border border-slate-800 text-[10px] text-slate-200 rounded font-semibold uppercase flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>ADD 2 CASES</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* LIVE LANDINGS CHRONOLOGY STREAM */}
        <div className="mt-8 border border-slate-900 p-6 bg-slate-900/10 font-mono">
          <div className="flex items-center gap-2 mb-6 text-xs text-orange-500 font-bold">
            <Activity className="w-4 h-4 animate-pulse shrink-0" />
            <h2 className="uppercase tracking-widest">LIVE HARBOUR LANDINGS LEDGER</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {landings.map(landing => (
              <div 
                key={landing.id} 
                className="p-3.5 bg-slate-950 border border-slate-900 text-[11px] uppercase space-y-1 hover:border-slate-800 transition-colors"
              >
                <div className="flex justify-between items-center text-[10px] text-slate-500">
                  <span className="font-semibold text-slate-400">{landing.timestamp} GMT</span>
                  <span className="text-slate-600">{landing.id.toUpperCase()}</span>
                </div>
                <strong className="text-slate-200 block truncate">{landing.vessel}</strong>
                <div className="text-slate-400 font-medium">{landing.species}</div>
                <div className="text-slate-500 text-[10px] mt-2 flex justify-between border-t border-slate-900 pt-1.5">
                  <span>DISCHARGED {landing.cases} CASES</span>
                  <span className="text-orange-500 font-semibold">{landing.port.replace(' HARBOUR', '').replace(' DOCKS', '')}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </LayoutShell>
  );
}
