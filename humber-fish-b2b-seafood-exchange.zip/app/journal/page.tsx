'use client';

import React from 'react';
import LayoutShell from '@/components/layout-shell';
import { FileText, Clock, ArrowRight, ShieldCheck } from 'lucide-react';

export default function JournalPage() {
  const articles = [
    {
      id: 'JRN-102',
      date: '2026-09-24',
      title: 'NORTH SEA COD STOCKS RECONCILED AGAINST NEW FAO QUOTA',
      desc: 'The marine observatory has ratified and adjusted catch limits for Area IV, ensuring stable demersal supply for Humber merchants throughout the coming autumn season.',
      tag: 'REGULATORY COMPLIANCE'
    },
    {
      id: 'JRN-101',
      date: '2026-09-18',
      title: 'HULL COLD INFRASTRUCTURE ADOPTS NEXT-GEN RF TEMPERATURE SENSORS',
      desc: 'Humber Processing Facility Room #3 has been upgraded to a continuous RFID telemetry grid, guaranteeing live cold chain updates within 0.1°C margins.',
      tag: 'PORT INFRASTRUCTURE'
    },
    {
      id: 'JRN-100',
      date: '2026-09-11',
      title: 'TRADITIONAL OAK-SMOKING METHODS SUSTAINED IN GRIMSBY HARBOUR',
      desc: 'Despite modern automation, our cold smoked haddock lots continue to rely on traditional oak-sawdust smoking rooms, preserving Grimsby\'s unique culinary texture.',
      tag: 'CRAFT & SPECIES'
    }
  ];

  return (
    <LayoutShell>
      <div className="p-6 xl:p-8 max-w-4xl mx-auto w-full flex-1 flex flex-col gap-8">
        
        {/* HEADER */}
        <div className="border-b border-slate-900 pb-4 font-mono">
          <span className="text-xs text-slate-500 tracking-widest uppercase block mb-1">
            PORT DISPATCH BROADCASTS
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-slate-100 uppercase">
            HUMBER COMMERCIAL JOURNAL
          </h1>
          <p className="text-xs text-slate-400 uppercase tracking-wider mt-1">
            FREQUENCY: <strong className="text-orange-500">WEEKLY COMMERCIAL SHIFT LOGS</strong>
          </p>
        </div>

        {/* ARTICLES LIST */}
        <div className="space-y-8">
          {articles.map(article => (
            <div 
              key={article.id}
              className="p-6 bg-slate-950 border border-slate-900 hover:border-slate-800 transition-colors font-mono uppercase text-xs space-y-3"
            >
              <div className="flex justify-between items-center text-[10px] text-slate-500">
                <span>{article.date} GMT</span>
                <span className="text-orange-500 font-semibold">{article.tag}</span>
              </div>
              
              <h2 className="text-sm font-bold text-slate-100 tracking-tight leading-tight">
                {article.title}
              </h2>
              
              <p className="text-slate-400 normal-case leading-relaxed font-sans text-xs">
                {article.desc}
              </p>

              <div className="border-t border-slate-900 pt-3 flex justify-between items-center">
                <span className="text-slate-600 text-[10px]">{article.id}</span>
                <button 
                  onClick={() => alert(`Opening full broadsheet paper log ${article.id}...`)}
                  className="text-orange-500 hover:text-orange-400 font-bold tracking-wider hover:underline text-[11px] inline-flex items-center gap-1"
                >
                  <span>READ BROADSHEET ARTICLE</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </LayoutShell>
  );
}
