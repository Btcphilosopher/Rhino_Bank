import type {Metadata} from 'next';
import './globals.css'; // Global styles
import { HumberProvider } from '@/lib/humber-context';

export const metadata: Metadata = {
  title: 'Humber Fish | B2B Commercial Seafood Exchange',
  description: 'High-fidelity, industrial B2B commerce and logistics platform for Humber & North Sea seafood distribution. Landed, Graded, Packed, Delivered.',
  openGraph: {
    title: 'Humber Fish | B2B Commercial Seafood Exchange',
    description: 'Fresh fish from the Humber. Supplied to Britain. Commercial seafood trading, processing, and next-day logistics.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Humber Fish | B2B Commercial Seafood Exchange',
    description: 'Fresh fish from the Humber. Supplied to Britain. Commercial seafood trading, processing, and next-day logistics.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="bg-slate-950 text-slate-100">
      <body suppressHydrationWarning className="bg-slate-950 text-slate-100 min-h-screen selection:bg-orange-500 selection:text-white">
        <HumberProvider>
          {children}
        </HumberProvider>
      </body>
    </html>
  );
}
