/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// ============================================================================
// RhinoSchedule Constraint-Satisfaction Solver Core
// Written in Rust for ultra-performance, safety, and parallel scheduling.
// Uses a hybrid Simulated Annealing and Tabu Search heuristic.
// ============================================================================

use std::collections::{HashMap, HashSet};
use rand::prelude::*;
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum RoomType {
    LectureTheatre,
    SeminarRoom,
    Laboratory,
    ComputingRoom,
    Studio,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Room {
    pub id: String,
    pub building_id: String,
    pub capacity: usize,
    pub room_type: RoomType,
    pub equipment: HashSet<String>,
    pub is_available: bool,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Lecturer {
    pub id: String,
    pub max_hours_per_week: usize,
    pub preferred_slots: HashSet<usize>, // Timeslot indices 0-44
    pub unavailable_slots: HashSet<usize>, // Timeslot indices 0-44
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Module {
    pub id: String,
    pub code: String,
    pub lecturer_id: String,
    pub enrollment: usize,
    pub required_equipment: HashSet<String>,
    pub duration_slots: usize,
    pub course_id: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ScheduledEvent {
    pub id: String,
    pub module_id: String,
    pub room_id: Option<String>,      // None means unassigned
    pub timeslot_id: Option<usize>,   // None means unassigned (0-44)
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct TimetableState {
    pub events: Vec<ScheduledEvent>,
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct Score {
    pub hard_violations: usize,
    pub soft_violations: usize,
    pub total_penalty: usize,
    pub unassigned_count: usize,
}

pub struct SolverContext {
    pub rooms: HashMap<String, Room>,
    pub lecturers: HashMap<String, Lecturer>,
    pub modules: HashMap<String, Module>,
    pub weights: HashMap<String, usize>,
}

impl SolverContext {
    /// Evaluate a timetable state and calculate its structural constraints score.
    pub fn evaluate(&self, state: &TimetableState) -> Score {
        let mut hard_violations = 0;
        let mut soft_violations = 0;
        let mut unassigned_count = 0;

        // Structures to check clashing
        // key: (timeslot, room_id), value: Event ID
        let mut room_occupancy: HashMap<(usize, String), String> = HashMap::new();
        // key: (timeslot, lecturer_id), value: Event ID
        let mut lecturer_occupancy: HashMap<(usize, String), String> = HashMap::new();
        // key: (timeslot, course_id), value: Event ID (for student group overlaps)
        let mut course_occupancy: HashMap<(usize, String), String> = HashMap::new();

        for event in &state.events {
            let room_id = match &event.room_id {
                Some(r) => r,
                None => {
                    unassigned_count += 1;
                    continue;
                }
            };

            let start_slot = match event.timeslot_id {
                Some(t) => t,
                None => {
                    unassigned_count += 1;
                    continue;
                }
            };

            let module = match self.modules.get(&event.module_id) {
                Some(m) => m,
                None => continue,
            };

            let room = match self.rooms.get(room_id) {
                Some(r) => r,
                None => continue,
            };

            let lecturer = self.lecturers.get(&module.lecturer_id);

            // Check each slot occupied by this event (depending on duration)
            for offset in 0..module.duration_slots {
                let slot = start_slot + offset;
                
                // 1. Boundary check (Must fit in work week)
                if slot >= 45 || (slot % 9) + module.duration_slots > 9 {
                    hard_violations += 1; // Spanning over daily break boundary is a hard breach
                    continue;
                }

                // 2. Room Clashing (Hard Constraint)
                if let Some(existing_event) = room_occupancy.insert((slot, room_id.clone()), event.id.clone()) {
                    if existing_event != event.id {
                        hard_violations += 1;
                    }
                }

                // 3. Lecturer Clashing (Hard Constraint)
                if let Some(existing_event) = lecturer_occupancy.insert((slot, module.lecturer_id.clone()), event.id.clone()) {
                    if existing_event != event.id {
                        hard_violations += 1;
                    }
                }

                // 4. Lecturer Availability (Hard Constraint)
                if let Some(lec) = lecturer {
                    if lec.unavailable_slots.contains(&slot) {
                        hard_violations += 1;
                    }
                }

                // 5. Student Track Clashing (Soft Constraint with weighted penalty)
                if let Some(_existing_event) = course_occupancy.insert((slot, module.course_id.clone()), event.id.clone()) {
                    soft_violations += 1;
                }

                // 6. Lecturer Preference (Soft preference)
                if let Some(lec) = lecturer {
                    if !lec.preferred_slots.contains(&slot) {
                        soft_violations += 1; // Minor penalty if out of preference
                    }
                }
            }

            // 7. Room Capacity Check (Hard Constraint)
            if room.capacity < module.enrollment {
                hard_violations += 1;
            }

            // 8. Equipment Match Check (Hard Constraint)
            for eq in &module.required_equipment {
                if !room.equipment.contains(eq) {
                    hard_violations += 1;
                }
            }
        }

        let hard_weight = self.weights.get("hard_penalty").unwrap_or(&1000);
        let soft_weight = self.weights.get("soft_penalty").unwrap_or(&10);
        let unassigned_weight = self.weights.get("unassigned_penalty").unwrap_or(&500);

        let total_penalty = (hard_violations * hard_weight)
            + (soft_violations * soft_weight)
            + (unassigned_count * unassigned_weight);

        Score {
            hard_violations,
            soft_violations,
            total_penalty,
            unassigned_count,
        }
    }

    /// Solves the timetabling problem using Simulated Annealing optimization.
    pub fn solve(
        &self,
        initial_state: TimetableState,
        max_iterations: usize,
        initial_temp: f64,
        cooling_rate: f64,
    ) -> (TimetableState, Vec<(usize, usize)>) {
        let mut rng = thread_rng();
        let mut current_state = initial_state;
        let mut current_score = self.evaluate(&current_state);
        
        let mut best_state = current_state.clone();
        let mut best_score = current_score.clone();

        let mut temperature = initial_temp;
        let mut history = Vec::with_capacity(max_iterations / 10);

        let room_ids: Vec<String> = self.rooms.keys().cloned().collect();

        for iter in 0..max_iterations {
            if current_score.total_penalty == 0 {
                break; // Globally optimal, zero violations reached!
            }

            // Create a small, random local perturbation (neighborhood move)
            let mut candidate_state = current_state.clone();
            let event_idx = rng.gen_range(0..candidate_state.events.len());
            
            // Randomly mutate room OR timeslot
            if rng.gen_bool(0.5) {
                // Mutate Room
                if !room_ids.is_empty() {
                    let random_room = room_ids[rng.gen_range(0..room_ids.len())].clone();
                    candidate_state.events[event_idx].room_id = Some(random_room);
                }
            } else {
                // Mutate Timeslot (0..45)
                let random_slot = rng.gen_range(0..45);
                candidate_state.events[event_idx].timeslot_id = Some(random_slot);
            }

            let candidate_score = self.evaluate(&candidate_state);

            // Calculate acceptance probability
            let delta = (candidate_score.total_penalty as f64) - (current_score.total_penalty as f64);
            let accept = if delta < 0.0 {
                true // Always accept improving moves
            } else {
                // Boltzmann probability distribution for climbing out of local minima
                let probability = (-delta / temperature).exp();
                rng.gen_bool(probability.min(1.0))
            };

            if accept {
                current_state = candidate_state;
                current_score = candidate_score;

                if current_score.total_penalty < best_score.total_penalty {
                    best_state = current_state.clone();
                    best_score = current_score.clone();
                }
            }

            // Cool down the system temperature
            temperature *= cooling_rate;

            if iter % 50 == 0 {
                history.push((iter, best_score.total_penalty));
            }
        }

        (best_state, history)
    }
}
