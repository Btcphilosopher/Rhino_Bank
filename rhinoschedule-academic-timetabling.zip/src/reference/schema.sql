-- ============================================================================
-- RhinoSchedule PostgreSQL Schema
-- Institutional-Grade University Timetabling & Resource Optimisation
-- ============================================================================

-- Enable UUID extension for robust distributed identifiers if needed
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ----------------------------------------------------------------------------
-- 1. Infrastructure & Estates
-- ----------------------------------------------------------------------------

CREATE TABLE buildings (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(10) NOT NULL UNIQUE,
    latitude DECIMAL(9,6) NOT NULL,
    longitude DECIMAL(9,6) NOT NULL,
    address TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE rooms (
    id VARCHAR(50) PRIMARY KEY,
    building_id VARCHAR(50) NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    capacity INT NOT NULL CHECK (capacity > 0),
    type VARCHAR(50) NOT NULL CHECK (type IN ('LectureTheatre', 'SeminarRoom', 'Laboratory', 'ComputingRoom', 'Studio')),
    equipment TEXT[] DEFAULT '{}', -- Array of required features (e.g., {'projector', 'microscope'})
    is_accessible BOOLEAN DEFAULT TRUE,
    is_available BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Index for room searches by capacity and type
CREATE INDEX idx_rooms_lookup ON rooms(type, capacity) WHERE is_available = TRUE;

-- ----------------------------------------------------------------------------
-- 2. People & Academics
-- ----------------------------------------------------------------------------

CREATE TABLE staff (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    department VARCHAR(100) NOT NULL,
    max_hours_per_week INT NOT NULL DEFAULT 40 CHECK (max_hours_per_week >= 0),
    preferred_timeslots INT[] DEFAULT '{}', -- List of preferred timeslot indexes (0-44)
    unavailable_timeslots INT[] DEFAULT '{}', -- List of hard unavailable timeslot indexes (0-44)
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE students (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------------------------------------------------------
-- 3. Academic Structure & Programmes
-- ----------------------------------------------------------------------------

CREATE TABLE courses (
    id VARCHAR(50) PRIMARY KEY,
    code VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    department VARCHAR(100) NOT NULL,
    total_students INT NOT NULL DEFAULT 0 CHECK (total_students >= 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE modules (
    id VARCHAR(50) PRIMARY KEY,
    code VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    course_id VARCHAR(50) NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    lecturer_id VARCHAR(50) REFERENCES staff(id) ON DELETE SET NULL,
    enrollment INT NOT NULL CHECK (enrollment >= 0),
    required_equipment TEXT[] DEFAULT '{}',
    type VARCHAR(20) NOT NULL CHECK (type IN ('lecture', 'lab', 'seminar')),
    duration_slots INT NOT NULL DEFAULT 1 CHECK (duration_slots BETWEEN 1 AND 4),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Many-to-many relationship mapping students to modules (enrollments)
CREATE TABLE student_module_enrollments (
    student_id VARCHAR(50) REFERENCES students(id) ON DELETE CASCADE,
    module_id VARCHAR(50) REFERENCES modules(id) ON DELETE CASCADE,
    PRIMARY KEY (student_id, module_id)
);

CREATE INDEX idx_enrollment_module ON student_module_enrollments(module_id);

-- ----------------------------------------------------------------------------
-- 4. Active Timetable & Scheduled Events
-- ----------------------------------------------------------------------------

CREATE TABLE scheduled_events (
    id VARCHAR(50) PRIMARY KEY,
    module_id VARCHAR(50) NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
    type VARCHAR(20) NOT NULL CHECK (type IN ('lecture', 'lab', 'seminar')),
    duration INT NOT NULL DEFAULT 1 CHECK (duration >= 1),
    room_id VARCHAR(50) REFERENCES rooms(id) ON DELETE SET NULL,
    timeslot_id INT CHECK (timeslot_id BETWEEN 0 AND 44), -- 0 to 44 mapping Monday 9am - Friday 5pm
    version_id INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Unique constraint preventing room double booking
CREATE UNIQUE INDEX idx_unique_room_timeslot 
ON scheduled_events (room_id, timeslot_id) 
WHERE room_id IS NOT NULL AND timeslot_id IS NOT NULL;

-- Index for quick lookups of a lecturer's schedule
CREATE INDEX idx_events_by_lecturer ON scheduled_events(timeslot_id) INCLUDE (room_id);

-- ----------------------------------------------------------------------------
-- 5. Examinations Scheduling
-- ----------------------------------------------------------------------------

CREATE TABLE examinations (
    id VARCHAR(50) PRIMARY KEY,
    module_id VARCHAR(50) NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
    duration_hours INT NOT NULL DEFAULT 2 CHECK (duration_hours BETWEEN 1 AND 4),
    room_id VARCHAR(50) REFERENCES rooms(id) ON DELETE SET NULL,
    timeslot_id INT CHECK (timeslot_id BETWEEN 0 AND 44),
    invigilator_id VARCHAR(50) REFERENCES staff(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Index to prevent invigilator double-bookings
CREATE UNIQUE INDEX idx_unique_invigilator_timeslot
ON examinations (invigilator_id, timeslot_id)
WHERE invigilator_id IS NOT NULL AND timeslot_id IS NOT NULL;

-- Index to prevent room double-bookings during exams
CREATE UNIQUE INDEX idx_unique_exam_room_timeslot
ON examinations (room_id, timeslot_id)
WHERE room_id IS NOT NULL AND timeslot_id IS NOT NULL;

-- ----------------------------------------------------------------------------
-- 6. Optimization Constraints & Configuration
-- ----------------------------------------------------------------------------

CREATE TABLE constraints_config (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL,
    severity VARCHAR(10) NOT NULL CHECK (severity IN ('HARD', 'SOFT')),
    weight INT NOT NULL DEFAULT 1 CHECK (weight >= 0),
    is_enabled BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------------------------------------------------------
-- 7. Audit Logging & Revision Control
-- ----------------------------------------------------------------------------

CREATE TABLE audit_logs (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    username VARCHAR(100) NOT NULL,
    action VARCHAR(255) NOT NULL,
    details TEXT
);

-- ----------------------------------------------------------------------------
-- Seed Data for Default Configuration
-- ----------------------------------------------------------------------------

INSERT INTO constraints_config (id, name, description, type, severity, weight, is_enabled) VALUES
('room_clash', 'Prevent Room Double-Booking', 'Enforces that a single classroom can host at most one teaching event at any timeslot.', 'room_clash', 'HARD', 1000, true),
('lecturer_clash', 'Prevent Lecturer Overlaps', 'Ensures a lecturer is not scheduled to teach multiple overlapping sessions simultaneously.', 'lecturer_clash', 'HARD', 1000, true),
('room_capacity', 'Respect Classroom Capacities', 'Requires that the size of the room must equal or exceed the enrollment size of the module.', 'room_capacity', 'HARD', 500, true),
('lecturer_availability', 'Respect Lecturer Teaching Leave', 'Restricts classes from being scheduled during timeslots marked as unavailable by academics.', 'lecturer_availability', 'HARD', 400, true),
('equipment_match', 'Match Specialist Equipment Requirements', 'Requires that the scheduled classroom contains all equipment specified by the module (e.g. chemical bench, computers).', 'equipment_match', 'HARD', 300, true),
('student_track_clash', 'Minimize Course Track Clashes (Program Coherence)', 'Penalizes scheduling compulsory modules within the same course/year in overlapping timeslots.', 'student_track_clash', 'SOFT', 100, true);
