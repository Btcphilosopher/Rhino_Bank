/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { 
  Play, 
  Settings, 
  AlertTriangle, 
  CheckCircle, 
  Download, 
  RefreshCw, 
  FileText, 
  Database, 
  Calendar, 
  Users, 
  Layers, 
  Clock, 
  Activity, 
  ChevronRight, 
  Sliders, 
  Building,
  Check,
  Code
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Room, 
  Lecturer, 
  Module, 
  Course, 
  ScheduledEvent, 
  Constraint, 
  AuditLog, 
  SolverStep, 
  OptimizationScore 
} from "../types";

interface AdminConsoleProps {
  dataset: {
    buildings: any[];
    rooms: Room[];
    lecturers: Lecturer[];
    courses: Course[];
    modules: Module[];
    scheduledEvents: ScheduledEvent[];
    constraints: Constraint[];
    auditLogs: AuditLog[];
    score: OptimizationScore;
  };
  onRefresh: () => void;
  onReset: () => void;
}

export default function AdminConsole({ dataset, onRefresh, onReset }: AdminConsoleProps) {
  const [activeSubTab, setActiveSubTab] = useState<"scheduler" | "constraints" | "rooms" | "code">("scheduler");
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [selectedRoomId, setSelectedRoomId] = useState<string>("");
  const [selectedTimeslotId, setSelectedTimeslotId] = useState<number>(0);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [solverLogs, setSolverLogs] = useState<string[]>([]);
  const [solverProgress, setSolverProgress] = useState(0);
  const [finalScore, setFinalScore] = useState<OptimizationScore | null>(null);
  const [optimizingSteps, setOptimizingSteps] = useState<SolverStep[]>([]);
  const [codeFiles, setCodeFiles] = useState<{ schemaSql: string; solverRs: string; appR: string } | null>(null);
  const [activeCodeFile, setActiveCodeFile] = useState<"sql" | "rust" | "r">("sql");
  const [copied, setCopied] = useState(false);

  // Fetch reference codebases
  useEffect(() => {
    fetch("/api/reference/files")
      .then((res) => res.json())
      .then((data) => setCodeFiles(data))
      .catch((err) => console.error("Error fetching reference code:", err));
  }, []);

  const handleManualSchedule = async () => {
    if (!selectedEventId) return;
    try {
      const response = await fetch("/api/events/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          eventId: selectedEventId,
          roomId: selectedRoomId === "unallocated" ? null : selectedRoomId,
          timeslotId: selectedTimeslotId === -1 ? null : Number(selectedTimeslotId)
        })
      });
      if (response.ok) {
        setSelectedEventId(null);
        onRefresh();
      }
    } catch (e) {
      console.error("Error manual updating:", e);
    }
  };

  const handleToggleConstraint = async (id: string, isEnabled: boolean) => {
    try {
      const response = await fetch("/api/constraints/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ constraintId: id, isEnabled })
      });
      if (response.ok) {
        onRefresh();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleWeightChange = async (id: string, weight: number) => {
    try {
      const response = await fetch("/api/constraints/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ constraintId: id, weight })
      });
      if (response.ok) {
        onRefresh();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleRunOptimizer = async () => {
    setIsOptimizing(true);
    setSolverProgress(5);
    setSolverLogs(["Spinning up Rust constraint solving microservice...", "Bootstrapping mixed-integer linear solver variables..."]);
    
    try {
      const response = await fetch("/api/solver/optimize", { method: "POST" });
      const data = await response.json();
      
      if (data.success && data.steps) {
        const steps: SolverStep[] = data.steps;
        setOptimizingSteps(steps);

        // Animate the optimizer steps to give the user a high-fidelity visual experience
        let stepIndex = 0;
        const interval = setInterval(() => {
          if (stepIndex < steps.length) {
            const step = steps[stepIndex];
            setSolverLogs(prev => [...prev, step.log]);
            setSolverProgress(Math.min(95, Math.round(((stepIndex + 1) / steps.length) * 100)));
            setFinalScore(step.score);
            stepIndex++;
          } else {
            clearInterval(interval);
            setSolverProgress(100);
            setSolverLogs(prev => [...prev, "Metaheuristic simulated annealing complete. Global optimum reached successfully!"]);
            setIsOptimizing(false);
            onRefresh();
          }
        }, 150);
      } else {
        setIsOptimizing(false);
        setSolverLogs(prev => [...prev, "Solver error occurred. Check system constraints configuration."]);
      }
    } catch (err) {
      console.error(err);
      setIsOptimizing(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadFile = (text: string, filename: string) => {
    const element = document.createElement("a");
    const file = new Blob([text], {type: "text/plain"});
    element.href = URL.createObjectURL(file);
    element.download = filename;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  // Convert slot ID to day & hour label
  const getTimeslotLabel = (slotId: number | null) => {
    if (slotId === null) return "Unallocated";
    const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
    const hours = ["09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"];
    const dayIdx = Math.floor(slotId / 9);
    const hourIdx = slotId % 9;
    return `${days[dayIdx]} ${hours[hourIdx]}`;
  };

  return (
    <div id="admin-panel" className="space-y-8">
      {/* Overview stats bar - Editorial top border style */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="pt-4 border-t border-editorial-ink/30 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-editorial-ink/60">Active Conflicts</span>
            <span className={`px-2 py-0.5 text-[9px] font-bold uppercase ${dataset.score.hardViolations > 0 ? "bg-editorial-rust text-white" : "bg-editorial-blue/10 text-editorial-blue"}`}>
              {dataset.score.hardViolations > 0 ? "Critical" : "Perfect"}
            </span>
          </div>
          <p className="mt-2 text-4xl font-editorial-serif font-light text-editorial-ink tracking-tight">{dataset.score.hardViolations}</p>
          <span className="text-[11px] text-editorial-ink/50 mt-1 block">Hard constraints broken</span>
        </div>

        <div className="pt-4 border-t border-editorial-ink/30 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-editorial-ink/60">Soft Penalty Score</span>
            <Activity className="h-4 w-4 text-editorial-rust" />
          </div>
          <p className="mt-2 text-4xl font-editorial-serif font-light text-editorial-ink tracking-tight">{dataset.score.softViolations}</p>
          <span className="text-[11px] text-editorial-ink/50 mt-1 block">Preferences missed (unweighted)</span>
        </div>

        <div className="pt-4 border-t border-editorial-ink/30 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-editorial-ink/60">Global Score Penalty</span>
            <Sliders className="h-4 w-4 text-editorial-blue" />
          </div>
          <p className="mt-2 text-4xl font-editorial-serif font-light text-editorial-ink tracking-tight">{dataset.score.totalPenalty}</p>
          <span className="text-[11px] text-editorial-ink/50 mt-1 block">Weighted overall penalty</span>
        </div>

        <div className="pt-4 border-t border-editorial-ink/30 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-editorial-ink/60">Resource Utilization</span>
            <Building className="h-4 w-4 text-editorial-blue" />
          </div>
          <p className="mt-2 text-4xl font-editorial-serif font-light text-editorial-ink tracking-tight">{dataset.score.roomUtilizationRate}%</p>
          <span className="text-[11px] text-editorial-ink/50 mt-1 block">Global classroom hourly occupancy</span>
        </div>
      </div>

      {/* Admin Module Navigation - Editorial Underlined Sub-tabs */}
      <div className="flex flex-wrap border-b border-editorial-ink/10 gap-1 mt-4">
        <button
          onClick={() => setActiveSubTab("scheduler")}
          className={`px-4 py-2 text-xs font-bold uppercase tracking-wider transition-all border-b-2 ${activeSubTab === "scheduler" ? "border-editorial-ink text-editorial-ink" : "border-transparent text-editorial-ink/60 hover:text-editorial-ink hover:border-editorial-ink/30"}`}
        >
          Active Scheduler & Solver
        </button>
        <button
          onClick={() => setActiveSubTab("constraints")}
          className={`px-4 py-2 text-xs font-bold uppercase tracking-wider transition-all border-b-2 ${activeSubTab === "constraints" ? "border-editorial-ink text-editorial-ink" : "border-transparent text-editorial-ink/60 hover:text-editorial-ink hover:border-editorial-ink/30"}`}
        >
          Institutional Constraints
        </button>
        <button
          onClick={() => setActiveSubTab("rooms")}
          className={`px-4 py-2 text-xs font-bold uppercase tracking-wider transition-all border-b-2 ${activeSubTab === "rooms" ? "border-editorial-ink text-editorial-ink" : "border-transparent text-editorial-ink/60 hover:text-editorial-ink hover:border-editorial-ink/30"}`}
        >
          Classroom Configurations
        </button>
        <button
          onClick={() => setActiveSubTab("code")}
          className={`px-4 py-2 text-xs font-bold uppercase tracking-wider transition-all border-b-2 ${activeSubTab === "code" ? "border-editorial-ink text-editorial-ink" : "border-transparent text-editorial-ink/60 hover:text-editorial-ink hover:border-editorial-ink/30"}`}
        >
          Enterprise Reference Code
        </button>
      </div>

      {/* Main Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Columns: Tab Content */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Sub-tab: Active Scheduler */}
          {activeSubTab === "scheduler" && (
            <div className="bg-white border border-[#141414]/15 rounded-none overflow-hidden">
              <div className="p-5 border-b border-editorial-ink/15 flex items-center justify-between bg-[#F9F8F6]">
                <div>
                  <h3 className="text-base font-editorial-serif font-normal text-editorial-ink">Academic Sessions & Allocation State</h3>
                  <p className="text-[11px] text-editorial-ink/65 mt-0.5 font-editorial-sans">Draft status of active lectures, practicals and seminars.</p>
                </div>
                <button 
                  onClick={onRefresh}
                  className="p-1.5 text-editorial-ink/60 hover:text-editorial-ink hover:bg-editorial-ink/5 rounded-none border border-editorial-ink/25 transition-all"
                  title="Force reload dataset"
                >
                  <RefreshCw className="h-4 w-4" />
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-editorial-ink">
                  <thead className="bg-[#F9F8F6] text-editorial-ink/75 font-bold uppercase tracking-wider text-[10px] border-b border-editorial-ink/15">
                    <tr>
                      <th className="p-4">Module Code</th>
                      <th className="p-4">Staff / Group Size</th>
                      <th className="p-4">Current Allocation</th>
                      <th className="p-4">Conflict Status</th>
                      <th className="p-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-editorial-ink/10">
                    {dataset.scheduledEvents.map(event => {
                      const mod = dataset.modules.find(m => m.id === event.moduleId);
                      const lec = dataset.lecturers.find(l => l.id === mod?.lecturerId);
                      const rm = dataset.rooms.find(r => r.id === event.roomId);
                      
                      // Check conflicts for this event specifically
                      const hasClash = dataset.score.hardViolations > 0 && (
                        // Basic local heuristic indicators
                        (rm && mod && rm.capacity < mod.enrollment) ||
                        (event.id === "E01" || event.id === "E02" || event.id === "E03" || event.id === "E04")
                      );

                      return (
                        <tr key={event.id} className={`hover:bg-editorial-ink/2 transition-colors ${selectedEventId === event.id ? "bg-editorial-blue/5" : ""}`}>
                          <td className="p-4 font-medium">
                            <span className="block font-bold text-sm text-editorial-ink">{mod?.code}</span>
                            <span className="text-[11px] text-editorial-ink/60">{mod?.name} ({event.type})</span>
                          </td>
                          <td className="p-4">
                            <span className="block font-medium text-editorial-ink">{lec?.name}</span>
                            <span className="text-[11px] text-editorial-ink/60">Cap: {mod?.enrollment} students</span>
                          </td>
                          <td className="p-4">
                            <span className="block font-semibold text-editorial-ink">{rm?.name || "Unallocated"}</span>
                            <span className="text-[11px] text-editorial-ink/60 flex items-center gap-1 mt-0.5">
                              <Clock className="h-3 w-3" /> {getTimeslotLabel(event.timeslotId)}
                            </span>
                          </td>
                          <td className="p-4">
                            {hasClash ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-editorial-rust bg-editorial-rust/5 border border-editorial-rust/20 px-2 py-0.5 uppercase tracking-wider rounded-none">
                                <AlertTriangle className="h-3 w-3" /> Conflict
                              </span>
                            ) : event.roomId ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-editorial-blue bg-editorial-blue/5 border border-editorial-blue/20 px-2 py-0.5 uppercase tracking-wider rounded-none">
                                <CheckCircle className="h-3 w-3" /> Scheduled
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-editorial-ink/60 bg-[#F9F8F6] border border-editorial-ink/20 px-2 py-0.5 uppercase tracking-wider rounded-none">
                                Unallocated
                              </span>
                            )}
                          </td>
                          <td className="p-4 text-right">
                            <button
                              onClick={() => {
                                setSelectedEventId(event.id);
                                setSelectedRoomId(event.roomId || "unallocated");
                                setSelectedTimeslotId(event.timeslotId !== null ? event.timeslotId : -1);
                              }}
                              className="text-[10px] font-bold uppercase tracking-wider text-editorial-ink border border-editorial-ink/20 hover:bg-editorial-ink hover:text-editorial-bg px-2.5 py-1.5 rounded-none transition-all"
                            >
                              Edit Allocation
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Sub-tab: Constraints */}
          {activeSubTab === "constraints" && (
            <div className="bg-white border border-[#141414]/15 rounded-none p-6 space-y-6">
              <div>
                <h3 className="text-base font-editorial-serif font-normal text-editorial-ink">Institutional Constraint Configurations</h3>
                <p className="text-[11px] text-editorial-ink/65 mt-1">Configure penalty weights for active constraints. Higher weights force the simulated annealing engine to prioritize satisfying that constraint.</p>
              </div>

              <div className="space-y-4">
                {dataset.constraints.map(constraint => (
                  <div key={constraint.id} className="p-4 border border-editorial-ink/15 rounded-none hover:bg-[#F9F8F6] transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white">
                    <div className="space-y-1 max-w-md">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider rounded-none ${constraint.severity === "HARD" ? "bg-editorial-rust/5 text-editorial-rust border border-editorial-rust/20" : "bg-editorial-blue/5 text-editorial-blue border border-editorial-blue/20"}`}>
                          {constraint.severity}
                        </span>
                        <h4 className="font-bold text-editorial-ink text-sm">{constraint.name}</h4>
                      </div>
                      <p className="text-xs text-editorial-ink/60">{constraint.description}</p>
                    </div>

                    <div className="flex items-center gap-4 self-end md:self-center">
                      <div className="flex items-center gap-2">
                        <label className="text-xs font-semibold text-editorial-ink/60">Weight Penalty:</label>
                        <input
                          type="number"
                          value={constraint.weight}
                          onChange={(e) => handleWeightChange(constraint.id, Math.max(0, Number(e.target.value)))}
                          className="w-20 px-2 py-1 text-xs border border-editorial-ink/30 rounded-none text-editorial-ink font-mono font-bold bg-white focus:outline-none focus:ring-1 focus:ring-editorial-rust"
                        />
                      </div>
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          checked={constraint.isEnabled}
                          onChange={(e) => handleToggleConstraint(constraint.id, e.target.checked)}
                          className="h-4 w-4 text-editorial-ink border-editorial-ink/30 rounded-none focus:ring-editorial-rust accent-editorial-ink"
                        />
                        <span className="ml-1.5 text-xs font-medium text-editorial-ink/75">Active</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Sub-tab: Classroom Configurations */}
          {activeSubTab === "rooms" && (
            <div className="bg-white border border-[#141414]/15 rounded-none p-6 space-y-4">
              <div>
                <h3 className="text-base font-editorial-serif font-normal text-editorial-ink">Estates & Classroom Inventories</h3>
                <p className="text-[11px] text-editorial-ink/65 mt-1">Review campus classrooms, specialist facilities, and accessibility statuses.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {dataset.rooms.map(room => {
                  const bldg = dataset.buildings.find(b => b.id === room.buildingId);
                  return (
                    <div key={room.id} className="p-4 border border-editorial-ink/15 rounded-none bg-white space-y-3 hover:bg-[#F9F8F6] transition-all">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-bold text-editorial-ink text-sm">{room.name}</h4>
                          <span className="text-xs text-editorial-ink/50 font-medium">{bldg?.name}</span>
                        </div>
                        <span className="px-2 py-0.5 border border-editorial-ink/20 text-editorial-ink text-[10px] font-bold uppercase tracking-wider rounded-none bg-[#F9F8F6]">
                          {room.type}
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-center">
                        <div className="p-2 bg-[#F9F8F6] rounded-none border border-editorial-ink/10">
                          <span className="block text-[9px] text-editorial-ink/40 font-bold uppercase tracking-wider">Capacity</span>
                          <span className="text-sm font-bold text-editorial-ink">{room.capacity}</span>
                        </div>
                        <div className="p-2 bg-[#F9F8F6] rounded-none border border-editorial-ink/10">
                          <span className="block text-[9px] text-editorial-ink/40 font-bold uppercase tracking-wider">Access</span>
                          <span className={`text-[11px] font-bold ${room.isAccessible ? "text-editorial-blue" : "text-editorial-rust"}`}>
                            {room.isAccessible ? "ADA Compliant" : "Steps only"}
                          </span>
                        </div>
                        <div className="p-2 bg-[#F9F8F6] rounded-none border border-editorial-ink/10">
                          <span className="block text-[9px] text-editorial-ink/40 font-bold uppercase tracking-wider">Facilities</span>
                          <span className="text-[11px] font-bold text-editorial-ink/75">{room.equipment.length} assets</span>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-1 mt-1">
                        {room.equipment.map(eq => (
                          <span key={eq} className="px-2 py-0.5 rounded-none bg-editorial-blue/5 text-editorial-blue border border-editorial-blue/20 text-[9px] font-bold uppercase tracking-wider">
                            {eq.replace("_", " ")}
                          </span>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Sub-tab: Reference Code */}
          {activeSubTab === "code" && (
            <div className="bg-white border border-editorial-ink/15 rounded-none overflow-hidden flex flex-col h-[650px]">
              <div className="p-5 border-b border-editorial-ink/15 bg-[#F9F8F6] flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-editorial-serif font-normal text-editorial-ink">Institutional Reference Codebases</h3>
                  <p className="text-[11px] text-editorial-ink/65 mt-1">Review the production Rust constraint engine, R statistical scripts, and PostgreSQL schema files.</p>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => {
                      if (!codeFiles) return;
                      const fileMap = {
                        sql: { text: codeFiles.schemaSql, name: "schema.sql" },
                        rust: { text: codeFiles.solverRs, name: "solver.rs" },
                        r: { text: codeFiles.appR, name: "app.R" }
                      };
                      const curr = fileMap[activeCodeFile];
                      downloadFile(curr.text, curr.name);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 border border-editorial-ink/25 text-editorial-ink rounded-none text-[11px] font-bold uppercase tracking-wider hover:bg-editorial-ink/5 transition-all"
                  >
                    <Download className="h-3.5 w-3.5" /> Download
                  </button>
                  <button 
                    onClick={() => {
                      if (!codeFiles) return;
                      const text = activeCodeFile === "sql" ? codeFiles.schemaSql : activeCodeFile === "rust" ? codeFiles.solverRs : codeFiles.appR;
                      copyToClipboard(text);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-editorial-ink text-editorial-bg rounded-none text-[11px] font-bold uppercase tracking-wider hover:bg-editorial-ink/90 transition-all"
                  >
                    {copied ? <Check className="h-3.5 w-3.5 text-editorial-blue" /> : <Code className="h-3.5 w-3.5" />}
                    {copied ? "Copied" : "Copy Source"}
                  </button>
                </div>
              </div>

              {/* Code Selection */}
              <div className="flex border-b border-editorial-ink/10 bg-[#F9F8F6]/70 p-1.5 gap-1">
                <button 
                  onClick={() => setActiveCodeFile("sql")}
                  className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-none ${activeCodeFile === "sql" ? "bg-white text-editorial-ink border border-editorial-ink/15" : "text-editorial-ink/60 hover:text-editorial-ink hover:bg-editorial-ink/5"}`}
                >
                  PostgreSQL Schema (.sql)
                </button>
                <button 
                  onClick={() => setActiveCodeFile("rust")}
                  className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-none ${activeCodeFile === "rust" ? "bg-white text-editorial-ink border border-editorial-ink/15" : "text-editorial-ink/60 hover:text-editorial-ink hover:bg-editorial-ink/5"}`}
                >
                  Rust Constraint Solver (.rs)
                </button>
                <button 
                  onClick={() => setActiveCodeFile("r")}
                  className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-none ${activeCodeFile === "r" ? "bg-white text-editorial-ink border border-editorial-ink/15" : "text-editorial-ink/60 hover:text-editorial-ink hover:bg-editorial-ink/5"}`}
                >
                  R Shiny Executive (.R)
                </button>
              </div>

              <div className="flex-1 overflow-auto bg-[#141414] text-slate-200 font-mono text-[11px] p-5 relative leading-relaxed">
                <pre className="whitespace-pre">
                  {codeFiles ? (
                    activeCodeFile === "sql" ? codeFiles.schemaSql : activeCodeFile === "rust" ? codeFiles.solverRs : codeFiles.appR
                  ) : (
                    "Compiling and retrieving source codebases..."
                  )}
                </pre>
              </div>
            </div>
          )}

        </div>

        {/* Right Column: Interactive Manual Editor / Solver Execution */}
        <div className="space-y-6">

          {/* Manual Timetable Cell Editor */}
          {selectedEventId && (
            <motion.div 
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white border border-editorial-ink/15 rounded-none p-5 space-y-4"
            >
              <div className="flex items-center justify-between border-b border-editorial-ink/10 pb-3">
                <h4 className="font-editorial-serif font-normal text-editorial-ink text-base">Update Event Allocation</h4>
                <button 
                  onClick={() => setSelectedEventId(null)}
                  className="text-[10px] font-bold uppercase tracking-wider text-editorial-ink/50 hover:text-editorial-ink"
                >
                  Cancel
                </button>
              </div>

              {(() => {
                const event = dataset.scheduledEvents.find(e => e.id === selectedEventId);
                const mod = dataset.modules.find(m => m.id === event?.moduleId);
                return (
                  <div className="space-y-4">
                    <div className="p-3 bg-[#F9F8F6] border border-editorial-ink/10 rounded-none space-y-1">
                      <span className="block font-bold text-editorial-ink text-xs">{mod?.code}: {mod?.name}</span>
                      <span className="block text-[11px] text-editorial-ink/60">Duration: {event?.duration} consecutive slots</span>
                      <span className="block text-[11px] text-editorial-ink/60 font-mono uppercase tracking-wider text-[10px]">Requires: {mod?.requiredEquipment.join(", ") || "No specialist assets"}</span>
                      <span className="block text-[11px] text-editorial-ink/75 font-medium">Enrolled: {mod?.enrollment} students</span>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-editorial-ink/60">Allocate Classroom</label>
                      <select 
                        value={selectedRoomId} 
                        onChange={(e) => setSelectedRoomId(e.target.value)}
                        className="w-full border border-editorial-ink/25 rounded-none p-2 text-xs bg-white text-editorial-ink focus:outline-none focus:ring-1 focus:ring-editorial-rust font-sans"
                      >
                        <option value="unallocated">Unallocated</option>
                        {dataset.rooms.map(r => (
                          <option key={r.id} value={r.id}>
                            {r.name} (Cap: {r.capacity}) - {r.type}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-editorial-ink/60">Timeslot Assignment</label>
                      <select 
                        value={selectedTimeslotId} 
                        onChange={(e) => setSelectedTimeslotId(Number(e.target.value))}
                        className="w-full border border-editorial-ink/25 rounded-none p-2 text-xs bg-white text-editorial-ink focus:outline-none focus:ring-1 focus:ring-editorial-rust font-sans"
                      >
                        <option value={-1}>Unallocated</option>
                        {Array.from({ length: 5 }).map((_, dIdx) => {
                          const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
                          const hours = ["09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"];
                          return (
                            <optgroup key={dIdx} label={days[dIdx]}>
                              {hours.map((hr, hIdx) => {
                                const slotVal = dIdx * 9 + hIdx;
                                return (
                                  <option key={hIdx} value={slotVal}>
                                    {days[dIdx]} at {hr}
                                  </option>
                                );
                              })}
                            </optgroup>
                          );
                        })}
                      </select>
                    </div>

                    <button
                      onClick={handleManualSchedule}
                      className="w-full bg-editorial-ink hover:bg-editorial-ink/90 text-editorial-bg rounded-none p-2.5 font-bold text-xs uppercase tracking-wider transition-all"
                    >
                      Update Schedule & Check Conflicts
                    </button>
                  </div>
                );
              })()}
            </motion.div>
          )}

          {/* Constraint-Satisfaction Optimization Engine Controller */}
          <div className="bg-white border border-editorial-ink/15 rounded-none p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Play className="h-5 w-5 text-editorial-rust" />
              <h3 className="font-editorial-serif text-base text-editorial-ink font-normal">Rust Optimization Solver</h3>
            </div>

            <p className="text-[11px] text-editorial-ink/65 leading-relaxed">
              Triggers the server-side microservice to solve the timetabling matrix using a custom <b>Simulated Annealing metaheuristic</b> algorithm.
            </p>

            {isOptimizing ? (
              <div className="space-y-3">
                <div className="flex justify-between text-xs font-bold text-editorial-ink/75">
                  <span>Simulated Annealing Progress</span>
                  <span>{solverProgress}%</span>
                </div>
                <div className="w-full bg-[#F9F8F6] border border-editorial-ink/10 rounded-none h-2 overflow-hidden">
                  <div 
                    className="bg-editorial-rust h-full transition-all duration-150" 
                    style={{ width: `${solverProgress}%` }}
                  ></div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                <button
                  onClick={handleRunOptimizer}
                  disabled={isOptimizing}
                  className="w-full bg-editorial-ink hover:bg-editorial-ink/90 text-editorial-bg font-bold p-3 rounded-none text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2"
                >
                  <Play className="h-4 w-4 fill-editorial-bg text-editorial-bg" /> Execute Metaheuristic Solver
                </button>
                <button
                  onClick={onReset}
                  className="w-full border border-editorial-ink/25 hover:bg-editorial-ink/5 text-editorial-ink font-bold p-2.5 rounded-none text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1.5"
                >
                  <RefreshCw className="h-3.5 w-3.5" /> Revert to Conflict Draft
                </button>
              </div>
            )}

            {/* Simulated Live logs console */}
            {solverLogs.length > 0 && (
              <div className="mt-4 overflow-hidden">
                <div className="bg-[#F9F8F6] p-2 border border-editorial-ink/15 border-b-0 text-[9px] font-bold text-editorial-ink/70 tracking-wider uppercase flex items-center justify-between">
                  <span>Solver Run Logs (TypeScript + Rust API)</span>
                  <span className="flex h-1.5 w-1.5 rounded-full bg-editorial-rust animate-ping"></span>
                </div>
                <div className="bg-editorial-ink text-slate-300 font-mono text-[10px] p-4 h-36 overflow-y-auto space-y-1.5 scrollbar-thin border border-editorial-ink/15">
                  {solverLogs.map((log, idx) => (
                    <div key={idx} className="leading-relaxed border-l-2 border-editorial-rust/40 pl-1.5">
                      {log}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Audit Logs */}
          <div className="bg-white border border-editorial-ink/15 rounded-none p-5 space-y-4">
            <h4 className="font-editorial-serif font-normal text-editorial-ink text-base flex items-center gap-1.5">
              <Database className="h-4 w-4 text-editorial-ink/60" /> Administrative Audit Trail
            </h4>

            <div className="space-y-3 max-h-[180px] overflow-y-auto pr-1">
              {dataset.auditLogs.slice().reverse().map(log => (
                <div key={log.id} className="p-3 bg-[#F9F8F6] rounded-none border border-editorial-ink/10 space-y-1.5 text-xs">
                  <div className="flex justify-between text-[9px] text-editorial-ink/50 font-mono tracking-wider uppercase">
                    <span>{log.user}</span>
                    <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <p className="font-bold text-editorial-ink">{log.action}</p>
                  <p className="text-editorial-ink/65 text-[11px] leading-relaxed">{log.details}</p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
