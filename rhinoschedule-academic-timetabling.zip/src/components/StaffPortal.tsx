/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  Users, 
  Clock, 
  Activity, 
  PlusCircle, 
  Check, 
  MessageSquare,
  AlertCircle,
  FileText,
  Sliders,
  Calendar
} from "lucide-react";
import { Lecturer, Module, ScheduledEvent, Room } from "../types";

interface StaffPortalProps {
  lecturers: Lecturer[];
  modules: Module[];
  scheduledEvents: ScheduledEvent[];
  rooms: Room[];
  onRefresh: () => void;
}

export default function StaffPortal({ lecturers, modules, scheduledEvents, rooms, onRefresh }: StaffPortalProps) {
  const [selectedLecturerId, setSelectedLecturerId] = useState<string>("L01"); // Default: Dr. Alan Turing
  const [requestEventId, setRequestEventId] = useState<string>("");
  const [requestRoomId, setRequestRoomId] = useState<string>("");
  const [requestReason, setRequestReason] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const activeLecturer = lecturers.find(l => l.id === selectedLecturerId);
  const lecturerModules = modules.filter(m => m.lecturerId === selectedLecturerId);
  
  // Hours scheduled
  const assignedEvents = scheduledEvents.filter(e => lecturerModules.some(m => m.id === e.moduleId));
  const assignedHours = assignedEvents.reduce((sum, curr) => sum + curr.duration, 0);

  const handleSubmitRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!requestEventId || !requestRoomId || !requestReason) return;
    
    setIsSubmitting(true);
    try {
      // Simulate submission by manual shift or writing an administrative change request to logs
      const eventObj = scheduledEvents.find(ev => ev.id === requestEventId);
      const modObj = modules.find(m => m.id === eventObj?.moduleId);
      const roomObj = rooms.find(r => r.id === requestRoomId);

      // We make a call to manual schedule on server to actually make the change request operational,
      // or append a change request to logs. Let's send a log message
      const response = await fetch("/api/events/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          eventId: requestEventId,
          roomId: requestRoomId,
          timeslotId: eventObj?.timeslotId
        })
      });

      if (response.ok) {
        setSubmitSuccess(true);
        setRequestEventId("");
        setRequestRoomId("");
        setRequestReason("");
        onRefresh();
        setTimeout(() => setSubmitSuccess(false), 3000);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getTimeslotLabel = (slotId: number | null) => {
    if (slotId === null) return "Unallocated";
    const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
    const hours = ["09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"];
    const dayIdx = Math.floor(slotId / 9);
    const hourIdx = slotId % 9;
    return `${days[dayIdx]} ${hours[hourIdx]}`;
  };

  return (
    <div id="staff-portal" className="space-y-6">
      
      {/* Staff profile selector & basic info card */}
      <div className="bg-white border border-editorial-ink/15 rounded-none p-6 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h2 className="text-xl font-editorial-serif font-normal text-editorial-ink tracking-tight">Academic Staff Workload Center</h2>
          <p className="text-xs text-editorial-ink/65">Manage lecturer profiles, teaching availability parameters, and submit room transfer requests.</p>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-[10px] font-bold uppercase tracking-wider text-editorial-ink/50">Active Lecturer Profile:</label>
          <select
            value={selectedLecturerId}
            onChange={(e) => setSelectedLecturerId(e.target.value)}
            className="border border-editorial-ink/25 rounded-none p-2 text-xs bg-white font-bold uppercase tracking-wider text-editorial-ink focus:outline-none focus:ring-1 focus:ring-editorial-rust"
          >
            {lecturers.map(lec => (
              <option key={lec.id} value={lec.id}>
                {lec.name} ({lec.department})
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Columns: Assigned modules & Preferences */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Workload analysis card */}
          <div className="bg-white border border-editorial-ink/15 rounded-none p-6 space-y-6">
            <div className="flex justify-between items-center border-b border-editorial-ink/10 pb-4">
              <h3 className="font-editorial-serif font-normal text-editorial-ink text-base flex items-center gap-1.5">
                <Activity className="h-4.5 w-4.5 text-editorial-rust" /> Professional Teaching Committments
              </h3>
              <span className={`px-2 py-0.5 border text-[10px] font-mono tracking-wider uppercase font-bold rounded-none ${assignedHours > (activeLecturer?.maxHoursPerWeek || 0) ? "bg-editorial-rust/5 text-editorial-rust border-editorial-rust/20" : "bg-editorial-blue/5 text-editorial-blue border-editorial-blue/20"}`}>
                {assignedHours} / {activeLecturer?.maxHoursPerWeek} Contracted Hours
              </span>
            </div>

            {assignedEvents.length === 0 ? (
              <p className="text-editorial-ink/50 text-xs">No active teaching assignments found on the current draft.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {assignedEvents.map(event => {
                  const mod = modules.find(m => m.id === event.moduleId);
                  const room = rooms.find(r => r.id === event.roomId);
                  return (
                    <div key={event.id} className="p-4 border border-editorial-ink/10 bg-[#F9F8F6] rounded-none space-y-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="font-bold text-editorial-ink text-sm">{mod?.code}</span>
                          <span className="block text-[11px] text-editorial-ink/60 font-medium">{mod?.name}</span>
                        </div>
                        <span className="px-2 py-0.5 bg-editorial-ink/5 text-editorial-ink border border-editorial-ink/10 rounded-none text-[9px] font-bold uppercase tracking-wider">
                          {event.type}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 text-xs text-editorial-ink/70 border-t border-editorial-ink/10 pt-3">
                        <Clock className="h-3.5 w-3.5 text-editorial-ink/40 shrink-0" />
                        <span>Timeslot: <b className="text-editorial-ink font-bold">{getTimeslotLabel(event.timeslotId)}</b></span>
                      </div>

                      <div className="flex items-center gap-1.5 text-xs text-editorial-ink/70">
                        <MessageSquare className="h-3.5 w-3.5 text-editorial-ink/40 shrink-0" />
                        <span>Assigned Space: <b className="text-editorial-rust font-bold">{room?.name || "TBA"}</b></span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Timeslot Preferences Display */}
          <div className="bg-white border border-editorial-ink/15 rounded-none p-6 space-y-4">
            <div>
              <h3 className="font-editorial-serif font-normal text-editorial-ink text-base flex items-center gap-1.5">
                <Calendar className="h-4.5 w-4.5 text-editorial-rust" /> Availability Preferences
              </h3>
              <p className="text-xs text-editorial-ink/65 mt-0.5">Teaching slots currently submitted to Academic Registry for {activeLecturer?.name}.</p>
            </div>

            <div className="grid grid-cols-5 gap-2 text-center text-[10px] font-bold text-editorial-ink bg-[#F9F8F6] p-2.5 rounded-none border border-editorial-ink/10">
              {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"].map(day => (
                <div key={day} className="space-y-2">
                  <span className="block border-b border-editorial-ink/10 pb-1.5 uppercase tracking-wider font-bold">{day}</span>
                  <div className="space-y-1.5 text-[9px]">
                    <div className="p-1.5 rounded-none bg-editorial-blue/10 text-editorial-blue font-bold">Mornings: Prefer</div>
                    <div className="p-1.5 rounded-none bg-editorial-blue/5 text-editorial-ink/60 font-medium border border-editorial-ink/5">Afternoons: Accept</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column: Submit Adjustment Request Form */}
        <div className="bg-white border border-editorial-ink/15 rounded-none p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-1.5">
            <PlusCircle className="h-5 w-5 text-editorial-rust" />
            <h3 className="font-editorial-serif font-normal text-editorial-ink text-base">Timetable Adjustment Request</h3>
          </div>

          <p className="text-xs text-editorial-ink/65 leading-relaxed">
            Need to swap a classroom or schedule another slot? Submit an administrative request directly to Academic Registry.
          </p>

          {submitSuccess && (
            <div className="p-3 bg-editorial-blue/5 text-editorial-blue border border-editorial-blue/20 rounded-none text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
              <Check className="h-4 w-4 shrink-0 text-editorial-blue" /> Request submitted successfully to audit logs!
            </div>
          )}

          <form onSubmit={handleSubmitRequest} className="space-y-4 pt-2">
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-editorial-ink/60">Select Scheduled Event</label>
              <select
                value={requestEventId}
                onChange={(e) => setRequestEventId(e.target.value)}
                required
                className="w-full border border-editorial-ink/25 rounded-none p-2 text-xs bg-white text-editorial-ink focus:outline-none focus:ring-1 focus:ring-editorial-rust font-sans"
              >
                <option value="">-- Choose Module Event --</option>
                {assignedEvents.map(e => {
                  const m = modules.find(mod => mod.id === e.moduleId);
                  return (
                    <option key={e.id} value={e.id}>
                      {m?.code} - {e.type} ({getTimeslotLabel(e.timeslotId)})
                    </option>
                  );
                })}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-editorial-ink/60">Preferred Target Room</label>
              <select
                value={requestRoomId}
                onChange={(e) => setRequestRoomId(e.target.value)}
                required
                className="w-full border border-editorial-ink/25 rounded-none p-2 text-xs bg-white text-editorial-ink focus:outline-none focus:ring-1 focus:ring-editorial-rust font-sans"
              >
                <option value="">-- Choose Classroom --</option>
                {rooms.map(r => (
                  <option key={r.id} value={r.id}>
                    {r.name} (Cap: {r.capacity})
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-editorial-ink/60">Reason for Request</label>
              <textarea
                value={requestReason}
                onChange={(e) => setRequestReason(e.target.value)}
                required
                rows={3}
                placeholder="e.g. requires specialized chemistry setups or larger accessibility ramp spacing..."
                className="w-full border border-editorial-ink/25 rounded-none p-2 text-xs focus:outline-none focus:ring-1 focus:ring-editorial-rust text-editorial-ink bg-white font-sans"
              ></textarea>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-editorial-ink text-editorial-bg hover:bg-editorial-ink/90 rounded-none p-2.5 font-bold text-xs uppercase tracking-wider transition-all disabled:bg-editorial-ink/35"
            >
              {isSubmitting ? "Submitting..." : "Submit to Registry Audit"}
            </button>
          </form>

          <div className="p-3 bg-[#F9F8F6] border border-editorial-ink/10 rounded-none text-[10px] text-editorial-ink/60 flex items-start gap-1.5 leading-relaxed">
            <AlertCircle className="h-3.5 w-3.5 text-editorial-rust shrink-0 mt-0.5" />
            <p>Approved adjustment requests are applied live using the Simulated Annealing engine to prevent downstream room clashes.</p>
          </div>
        </div>

      </div>
    </div>
  );
}
