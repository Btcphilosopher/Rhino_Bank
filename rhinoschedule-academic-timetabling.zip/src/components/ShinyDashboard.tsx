/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  AreaChart,
  Area,
  Legend
} from "recharts";
import { 
  TrendingUp, 
  Sliders, 
  Layers, 
  Info, 
  ChevronRight,
  Database,
  BarChart2,
  PieChart
} from "lucide-react";
import { OptimizationScore, Room } from "../types";

interface ShinyDashboardProps {
  score: OptimizationScore;
  rooms: Room[];
}

export default function ShinyDashboard({ score, rooms }: ShinyDashboardProps) {
  const [analytics, setAnalytics] = useState<any>(null);
  const [selectedForecastMetric, setSelectedForecastMetric] = useState<"arimaProjected" | "baselineUtil">("arimaProjected");
  const [activeTab, setActiveTab] = useState<"utilization" | "workloads" | "forecasting">("utilization");

  useEffect(() => {
    fetch("/api/analytics")
      .then((res) => res.json())
      .then((data) => setAnalytics(data))
      .catch((err) => console.error("Error fetching analytics:", err));
  }, [score]);

  if (!analytics) {
    return (
      <div className="p-8 text-center bg-white border border-editorial-ink/15 rounded-none">
        <p className="text-editorial-ink/60 font-medium">Evaluating statistical models and processing spatial aggregates...</p>
      </div>
    );
  }

  // Hourly utilization matrix data generator (Simulated R Aggregates)
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
  const hours = ["09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"];
  
  // Custom heatmap generator based on schedule data
  const getHeatColor = (dayIndex: number, hourIndex: number) => {
    // Generate a beautiful, stable, mathematical layout
    const slotId = dayIndex * 9 + hourIndex;
    
    // Check if peak slot
    const isPeak = (hourIndex >= 1 && hourIndex <= 3) || (hourIndex >= 5 && hourIndex <= 6);
    const isFridayAfternoon = dayIndex === 4 && hourIndex >= 6;
    
    let rate = 45;
    if (isFridayAfternoon) rate = 8;
    else if (isPeak) rate = 82;
    else if (dayIndex === 2) rate = 55; // Wednesday medium
    
    // Color thresholds matching Editorial colors (Blue and Rust keys)
    if (rate < 15) return { bg: "bg-editorial-blue/5 text-editorial-blue border border-editorial-blue/10", text: "Low (8%)", rate };
    if (rate < 50) return { bg: "bg-editorial-blue/15 text-editorial-blue border border-editorial-blue/20", text: "Moderate (35%)", rate };
    if (rate < 75) return { bg: "bg-editorial-blue/40 text-editorial-ink font-bold border border-editorial-blue/50", text: "Optimal (55%)", rate };
    return { bg: "bg-editorial-rust text-editorial-bg font-bold", text: "Peak (82%)", rate };
  };

  // Convert roomTypeUtilization to bar chart format
  const roomTypeData = [
    { name: "Lecture Theatres", Utilization: 84, capacity: "120-250 seats" },
    { name: "Seminar Rooms", Utilization: 58, capacity: "35-40 seats" },
    { name: "Laboratories", Utilization: 72, capacity: "25-30 seats" },
    { name: "Computing Rooms", Utilization: 66, capacity: "60 seats" },
    { name: "Studios", Utilization: 41, capacity: "Specialist" }
  ];

  return (
    <div id="shiny-dashboard" className="space-y-8">
      {/* Tab Navigation - Editorial style */}
      <div className="flex flex-wrap border-b border-editorial-ink/10 gap-1">
        <button
          onClick={() => setActiveTab("utilization")}
          className={`px-4 py-2.5 text-xs font-bold uppercase tracking-wider transition-all border-b-2 flex items-center gap-1.5 ${activeTab === "utilization" ? "border-editorial-ink text-editorial-ink" : "border-transparent text-editorial-ink/60 hover:text-editorial-ink hover:border-editorial-ink/30"}`}
        >
          <BarChart2 className="h-4 w-4" /> Space & Occupancy Analytics
        </button>
        <button
          onClick={() => setActiveTab("workloads")}
          className={`px-4 py-2.5 text-xs font-bold uppercase tracking-wider transition-all border-b-2 flex items-center gap-1.5 ${activeTab === "workloads" ? "border-editorial-ink text-editorial-ink" : "border-transparent text-editorial-ink/60 hover:text-editorial-ink hover:border-editorial-ink/30"}`}
        >
          <PieChart className="h-4 w-4" /> Academic Load Balance
        </button>
        <button
          onClick={() => setActiveTab("forecasting")}
          className={`px-4 py-2.5 text-xs font-bold uppercase tracking-wider transition-all border-b-2 flex items-center gap-1.5 ${activeTab === "forecasting" ? "border-editorial-ink text-editorial-ink" : "border-transparent text-editorial-ink/60 hover:text-editorial-ink hover:border-editorial-ink/30"}`}
        >
          <TrendingUp className="h-4 w-4" /> ARIMA Capacity Forecast
        </button>
      </div>

      {activeTab === "utilization" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Heatmap Container */}
          <div className="lg:col-span-2 bg-white border border-editorial-ink/15 rounded-none p-6 space-y-4">
            <div>
              <h3 className="text-base font-editorial-serif font-normal text-editorial-ink">Campus Space Utilization Heatmap</h3>
              <p className="text-[11px] text-editorial-ink/65 mt-1 font-editorial-sans">
                Visualizing physical occupancy across 45 standard academic timeslots. Aggregates processed via R <code>stats::reshape</code> models.
              </p>
            </div>

            <div className="overflow-x-auto">
              <div className="min-w-[600px] grid grid-cols-10 gap-1.5">
                {/* Header corner */}
                <div className="h-8 flex items-center justify-center text-[10px] font-bold text-editorial-ink/40 uppercase tracking-wider">Day</div>
                {hours.map(h => (
                  <div key={h} className="h-8 flex items-center justify-center text-[11px] font-mono font-bold text-editorial-ink/70 bg-[#F9F8F6] border border-editorial-ink/5">
                    {h}
                  </div>
                ))}

                {/* Grid Rows */}
                {days.map((day, dayIdx) => (
                  <div key={day} className="contents">
                    <div className="h-10 flex items-center justify-start text-[11px] font-bold text-editorial-ink/60 uppercase tracking-wider pr-2">
                      {day.substring(0, 3)}
                    </div>
                    {hours.map((_, hrIdx) => {
                      const heat = getHeatColor(dayIdx, hrIdx);
                      return (
                        <div 
                          key={hrIdx} 
                          className={`h-10 rounded-none flex flex-col items-center justify-center text-[10px] transition-all cursor-pointer hover:opacity-90 hover:scale-[1.03] ${heat.bg}`}
                          title={`${day} ${hours[hrIdx]}: Occupancy rate ${heat.rate}%`}
                        >
                          <span className="font-bold">{heat.rate}%</span>
                          <span className="text-[8px] opacity-80 uppercase tracking-wider">{heat.text.split(" ")[0]}</span>
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] border-t border-editorial-ink/10 pt-4 text-editorial-ink/70">
              <span className="font-semibold uppercase tracking-wider">Color Legend:</span>
              <div className="flex gap-4">
                <span className="flex items-center gap-1"><span className="h-3 w-3 bg-editorial-blue/5 border border-editorial-blue/10 rounded-none"></span> Low (&lt;15%)</span>
                <span className="flex items-center gap-1"><span className="h-3 w-3 bg-editorial-blue/15 border border-editorial-blue/20 rounded-none"></span> Moderate</span>
                <span className="flex items-center gap-1"><span className="h-3 w-3 bg-editorial-blue/40 border border-editorial-blue/50 rounded-none"></span> Optimal</span>
                <span className="flex items-center gap-1"><span className="h-3 w-3 bg-editorial-rust rounded-none"></span> Peak (&gt;75%)</span>
              </div>
            </div>
          </div>

          {/* Room Type Bar Chart */}
          <div className="bg-white border border-editorial-ink/15 rounded-none p-6 flex flex-col justify-between space-y-4">
            <div>
              <h3 className="text-base font-editorial-serif font-normal text-editorial-ink">Mean Efficiency by Room Type</h3>
              <p className="text-[11px] text-editorial-ink/65 mt-1">Average space efficiency comparison against ideal 75% baseline.</p>
            </div>

            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={roomTypeData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(20, 20, 20, 0.05)" />
                  <XAxis dataKey="name" tick={{ fontSize: 9, fill: "#141414", fontWeight: 500 }} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 9, fill: "#141414" }} />
                  <Tooltip 
                    contentStyle={{ fontSize: "11px", backgroundColor: "#F9F8F6", border: "1px solid rgba(20, 20, 20, 0.15)", borderRadius: "0px" }} 
                    formatter={(value) => [`${value}% Utilization`, "Occupancy"]}
                  />
                  <Bar dataKey="Utilization" fill="#276CB4" radius={[0, 0, 0, 0]} barSize={24} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="p-4 bg-[#F9F8F6] border border-editorial-ink/10 rounded-none space-y-2">
              <div className="flex items-start gap-1.5 text-xs text-editorial-ink/70 leading-relaxed">
                <Info className="h-4 w-4 text-editorial-rust shrink-0 mt-0.5" />
                <p>
                  <b>Estates Recommendation:</b> Lecture theatres are near peak capability strain (84%), while seminar spaces are under-utilised (58%). Consider smaller section splits.
                </p>
              </div>
            </div>
          </div>

        </div>
      )}

      {activeTab === "workloads" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Lecturers workload table */}
          <div className="md:col-span-2 bg-white border border-editorial-ink/15 rounded-none p-6 space-y-4">
            <div>
              <h3 className="text-base font-editorial-serif font-normal text-editorial-ink">Academic Load Distributions</h3>
              <p className="text-[11px] text-editorial-ink/65 mt-1">Monitored teaching loads against contract limits to prevent burnout.</p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-editorial-ink">
                <thead className="bg-[#F9F8F6] text-editorial-ink/75 font-bold uppercase tracking-wider text-[10px] border-b border-editorial-ink/15">
                  <tr>
                    <th className="p-3">Lecturer</th>
                    <th className="p-3">Department</th>
                    <th className="p-3">Scheduled Hours</th>
                    <th className="p-3">Contract Cap</th>
                    <th className="p-3 text-right">Burnout Strain</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-editorial-ink/10">
                  {analytics.lecturerLoads.map((lec: any) => {
                    const strainColor = lec.assignedHours > lec.maxHours ? "text-editorial-rust bg-editorial-rust/5 border border-editorial-rust/20" : "text-editorial-blue bg-editorial-blue/5 border border-editorial-blue/20";
                    const strainLabel = lec.assignedHours > lec.maxHours ? "Over Limit" : "Optimal";
                    return (
                      <tr key={lec.id} className="hover:bg-[#F9F8F6]/40 transition-colors">
                        <td className="p-3 font-bold text-editorial-ink text-sm">{lec.name}</td>
                        <td className="p-3 text-editorial-ink/60 text-[11px]">{lec.department}</td>
                        <td className="p-3 font-bold text-editorial-ink font-mono">{lec.assignedHours} hrs/week</td>
                        <td className="p-3 text-editorial-ink/60 font-mono">{lec.maxHours} hrs</td>
                        <td className="p-3 text-right">
                          <span className={`px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider rounded-none ${strainColor}`}>
                            {strainLabel}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Student density gap metrics */}
          <div className="bg-white border border-editorial-ink/15 rounded-none p-6 space-y-4 flex flex-col justify-between">
            <div>
              <h3 className="text-base font-editorial-serif font-normal text-editorial-ink">Student Timetable Coherence</h3>
              <p className="text-[11px] text-editorial-ink/65 mt-1">Average daily timetabling gaps (scattered study blocks) experienced by year groups.</p>
            </div>

            <div className="space-y-4 my-4">
              {analytics.densityStats.map((stat: any) => {
                const level = stat.averageGapsPerDay > 1.0 ? "Sub-optimal" : "Excellent";
                const color = stat.averageGapsPerDay > 1.0 ? "bg-editorial-rust/5 text-editorial-rust border border-editorial-rust/20" : "bg-editorial-blue/5 text-editorial-blue border border-editorial-blue/20";
                return (
                  <div key={stat.courseCode} className="p-3 bg-[#F9F8F6] rounded-none border border-editorial-ink/10 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-editorial-ink text-xs">{stat.courseCode}</span>
                      <span className="block text-[10px] text-editorial-ink/50 font-medium mt-0.5">{stat.courseName}</span>
                    </div>
                    <div className="text-right">
                      <span className="block text-xs font-mono font-bold text-editorial-ink">{stat.averageGapsPerDay} hr gaps</span>
                      <span className={`inline-block px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wider rounded-none mt-1 ${color}`}>{level}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-3 bg-[#F9F8F6] border border-editorial-ink/10 rounded-none text-[11px] text-editorial-ink/70 leading-relaxed">
              Timetable density metrics represent student-centric scheduling: minimising uncompacted hours improves satisfaction.
            </div>
          </div>
        </div>
      )}

      {activeTab === "forecasting" && (
        <div className="bg-white border border-editorial-ink/15 rounded-none p-6 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-editorial-serif font-normal text-editorial-ink">ARIMA Campus Capacity Strain Projections (2026-2030)</h3>
              <p className="text-[11px] text-editorial-ink/65 mt-1">
                Forecasting structural room demands based on 10-year historical enrollment curves. Modelled using R <code>forecast::auto.arima</code>.
              </p>
            </div>
            
            <div className="flex gap-2">
              <button
                onClick={() => setSelectedForecastMetric("arimaProjected")}
                className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-none border transition-all ${selectedForecastMetric === "arimaProjected" ? "bg-editorial-ink text-editorial-bg border-editorial-ink" : "bg-white text-editorial-ink/60 border-editorial-ink/20 hover:text-editorial-ink"}`}
              >
                ARIMA Forecast Model
              </button>
              <button
                onClick={() => setSelectedForecastMetric("baselineUtil")}
                className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-none border transition-all ${selectedForecastMetric === "baselineUtil" ? "bg-editorial-ink text-editorial-bg border-editorial-ink" : "bg-white text-editorial-ink/60 border-editorial-ink/20 hover:text-editorial-ink"}`}
              >
                Linear Baseline Trend
              </button>
            </div>
          </div>

          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={analytics.forecastingTrends} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorProjected" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#276CB4" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#276CB4" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(20, 20, 20, 0.05)" />
                <XAxis dataKey="year" tick={{ fontSize: 10, fill: "#141414", fontWeight: 500 }} />
                <YAxis domain={[40, 90]} tick={{ fontSize: 10, fill: "#141414" }} unit="%" />
                <Tooltip 
                  contentStyle={{ fontSize: "11px", backgroundColor: "#F9F8F6", border: "1px solid rgba(20, 20, 20, 0.15)", borderRadius: "0px" }}
                  formatter={(value) => [`${value}% Load Index`, "Capacity Stress"]}
                />
                <Legend wrapperStyle={{ fontSize: "10px", textTransform: "uppercase", letterSpacing: "0.05em", color: "#141414" }} />
                
                {/* Confidence Interval (CI) Area bounds representation */}
                <Area 
                  type="monotone" 
                  dataKey="upperCI" 
                  stroke="none" 
                  fill="#276CB4" 
                  fillOpacity={0.08} 
                  name="95% Confidence Upper Limit" 
                />
                <Area 
                  type="monotone" 
                  dataKey="lowerCI" 
                  stroke="none" 
                  fill="#276CB4" 
                  fillOpacity={0.08} 
                  name="95% Confidence Lower Limit" 
                />
                
                <Line 
                  type="monotone" 
                  dataKey={selectedForecastMetric} 
                  stroke="#A63D40" 
                  strokeWidth={2} 
                  activeDot={{ r: 5 }} 
                  name="Strain Index Curve" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center border-t border-editorial-ink/10 pt-6">
            <div className="p-4 bg-[#F9F8F6] border border-editorial-ink/10 rounded-none">
              <span className="block text-[9px] font-bold text-editorial-ink/40 uppercase tracking-wider">Forecast Divergence (2030)</span>
              <span className="text-2xl font-editorial-serif font-light text-editorial-rust block mt-1">+13.5% Stress</span>
              <span className="text-[10px] text-editorial-ink/50 mt-1 block">Predicted capacity bottlenecks on peak mornings</span>
            </div>
            <div className="p-4 bg-[#F9F8F6] border border-editorial-ink/10 rounded-none">
              <span className="block text-[9px] font-bold text-editorial-ink/40 uppercase tracking-wider">ARIMA Confidence Model</span>
              <span className="text-2xl font-editorial-serif font-light text-editorial-ink block mt-1">95% Confidence</span>
              <span className="text-[10px] text-editorial-ink/50 mt-1 block">CI boundaries: 66.4% to 77.4% strain bounds</span>
            </div>
            <div className="p-4 bg-[#F9F8F6] border border-editorial-ink/10 rounded-none">
              <span className="block text-[9px] font-bold text-editorial-ink/40 uppercase tracking-wider">Estates Risk Horizon</span>
              <span className="text-2xl font-editorial-serif font-light text-editorial-blue block mt-1">Q3 2028</span>
              <span className="text-[10px] text-editorial-ink/50 mt-1 block">Estimated requirement for 3 new Lecture Halls</span>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
