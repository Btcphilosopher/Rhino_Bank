/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { 
  Calendar, 
  Search, 
  Download, 
  MapPin, 
  BookOpen, 
  Check, 
  Activity, 
  User, 
  Info,
  Clock
} from "lucide-react";
import { Room, Course, Module, ScheduledEvent } from "../types";

interface StudentPortalProps {
  rooms: Room[];
  courses: Course[];
  modules: Module[];
  scheduledEvents: ScheduledEvent[];
  lecturers: any[];
}

export default function StudentPortal({ rooms, courses, modules, scheduledEvents, lecturers }: StudentPortalProps) {
  const [selectedCourseId, setSelectedCourseId] = useState<string>("C01"); // Default: Computer Science
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [roomFilter, setRoomFilter] = useState<string>("");
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Filter events belonging to selected course
  const courseModules = modules.filter(m => m.courseId === selectedCourseId);
  const filteredEvents = scheduledEvents.filter(e => {
    const isOfCourse = courseModules.some(m => m.id === e.moduleId);
    const mod = modules.find(m => m.id === e.moduleId);
    const matchesSearch = searchQuery === "" || (
      mod?.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mod?.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    return isOfCourse && matchesSearch;
  });

  // Days and hours lists
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
  const hours = ["09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"];

  // Generate standard iCalendar (.ics) content for the course schedule
  const generateICS = () => {
    let icsContent = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//RhinoSchedule//Academic Timetabling Platform//EN",
      "CALSCALE:GREGORIAN",
      "METHOD:PUBLISH"
    ];

    filteredEvents.forEach(event => {
      const mod = modules.find(m => m.id === event.moduleId);
      const room = rooms.find(r => r.id === event.roomId);
      const lecturer = lecturers.find(l => l.id === mod?.lecturerId);

      if (event.timeslotId === null || !mod) return;

      const dayIdx = Math.floor(event.timeslotId / 9);
      const hourIdx = event.timeslotId % 9;
      
      // Calculate fake dates starting next Mon (for realistic ics files)
      const dayOffset = dayIdx; // Mon=0, Tue=1, etc.
      const startTimeHour = 9 + hourIdx;
      const endTimeHour = startTimeHour + event.duration;

      // Construct dates: e.g. 20260803T090000Z (Mon 3rd August 2026)
      const dateStr = `202608${String(3 + dayOffset).padStart(2, "0")}`;
      const tStart = `${dateStr}T${String(startTimeHour).padStart(2, "0")}0000`;
      const tEnd = `${dateStr}T${String(endTimeHour).padStart(2, "0")}0000`;

      icsContent.push(
        "BEGIN:VEVENT",
        `SUMMARY:${mod.code} - ${mod.name}`,
        `LOCATION:${room ? room.name : "TBA"}`,
        `DESCRIPTION:Module code: ${mod.code}\\nLecturer: ${lecturer ? lecturer.name : "Staff"}\\nType: ${event.type}`,
        `DTSTART:${tStart}`,
        `DTEND:${tEnd}`,
        `UID:${event.id}-2026@rhinoschedule.ac.uk`,
        "END:VEVENT"
      );
    });

    icsContent.push("END:VCALENDAR");
    return icsContent.join("\r\n");
  };

  const handleExportCalendar = () => {
    const icsText = generateICS();
    const blob = new Blob([icsText], { type: "text/calendar;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `RhinoSchedule_${selectedCourseId}.ics`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  // Check if an event sits at a particular day and hour timeslot index
  const getEventAtTimeslot = (dayIdx: number, hourIdx: number) => {
    const targetSlot = dayIdx * 9 + hourIdx;
    return filteredEvents.find(e => {
      if (e.timeslotId === null) return false;
      // An event occupies timeslots from timeslotId to timeslotId + duration - 1
      return targetSlot >= e.timeslotId && targetSlot < e.timeslotId + e.duration;
    });
  };

  return (
    <div id="student-portal" className="space-y-6">
      {/* Top Banner & Select Course */}
      <div className="bg-white border border-editorial-ink/15 rounded-none p-6 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1.5">
          <h2 className="text-xl font-editorial-serif font-normal text-editorial-ink tracking-tight">Personalized Student Schedules</h2>
          <p className="text-xs text-editorial-ink/65">Access and export conflict-free module timetables for your active study programme.</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <select
            value={selectedCourseId}
            onChange={(e) => setSelectedCourseId(e.target.value)}
            className="border border-editorial-ink/25 rounded-none p-2 text-xs bg-white font-bold uppercase tracking-wider text-editorial-ink focus:outline-none focus:ring-1 focus:ring-editorial-rust"
          >
            {courses.map(course => (
              <option key={course.id} value={course.id}>
                {course.name} ({course.code})
              </option>
            ))}
          </select>

          <button
            onClick={handleExportCalendar}
            className="flex items-center justify-center gap-1.5 px-4 py-2 bg-editorial-ink text-editorial-bg hover:bg-editorial-ink/90 text-xs font-bold uppercase tracking-wider rounded-none transition-all"
          >
            {downloadSuccess ? <Check className="h-4 w-4 text-editorial-blue" /> : <Download className="h-4 w-4" />}
            {downloadSuccess ? "Calendar Downloaded" : "Export to Calendar (.ics)"}
          </button>
        </div>
      </div>

      {/* Grid Filter Search bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Timetable Grid Column (Left 2 columns) */}
        <div className="md:col-span-2 bg-white border border-editorial-ink/15 rounded-none p-6 space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-editorial-ink/10 pb-4">
            <h3 className="font-editorial-serif font-normal text-editorial-ink text-base flex items-center gap-1.5">
              <Calendar className="h-4.5 w-4.5 text-editorial-rust" /> Weekly Schedule Matrix
            </h3>
            <div className="relative w-full sm:w-60">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-editorial-ink/40" />
              <input
                type="text"
                placeholder="Search modules..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-xs border border-editorial-ink/25 rounded-none focus:outline-none focus:ring-1 focus:ring-editorial-rust bg-[#F9F8F6]/50 text-editorial-ink"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <div className="min-w-[650px] border border-editorial-ink/10 rounded-none overflow-hidden">
              {/* Day headers */}
              <div className="grid grid-cols-6 bg-[#F9F8F6] border-b border-editorial-ink/15 text-center font-bold text-editorial-ink text-[11px] uppercase tracking-wider py-2.5">
                <div>Time</div>
                {days.map(d => <div key={d}>{d}</div>)}
              </div>

              {/* Grid rows */}
              {hours.map((hour, hrIdx) => (
                <div key={hour} className="grid grid-cols-6 border-b border-editorial-ink/10 text-center text-xs divide-x divide-editorial-ink/10 min-h-16">
                  {/* Time label */}
                  <div className="flex items-center justify-center font-bold font-mono text-editorial-ink/50 bg-[#F9F8F6]/20">
                    {hour}
                  </div>

                  {/* Day cells */}
                  {days.map((day, dIdx) => {
                    const event = getEventAtTimeslot(dIdx, hrIdx);
                    if (!event) {
                      return <div key={day} className="bg-white hover:bg-[#F9F8F6]/20 transition-all"></div>;
                    }

                    // Check if this timeslot matches the event's start hour specifically
                    const isStart = event.timeslotId === (dIdx * 9 + hrIdx);
                    const mod = modules.find(m => m.id === event.moduleId);
                    const rm = rooms.find(r => r.id === event.roomId);
                    const bldgName = rm ? rm.name : "TBA";

                    // Prevent duplicates in span cells by only rendering in the start cell
                    if (!isStart) {
                      return (
                        <div key={day} className="bg-editorial-blue/5 border-t border-b border-editorial-ink/5 transition-all flex items-center justify-center">
                          <span className="block text-[8px] text-editorial-blue/40 font-semibold opacity-40">...</span>
                        </div>
                      );
                    }

                    return (
                      <div 
                        key={day} 
                        className="p-2 bg-editorial-blue/10 border border-editorial-blue/30 rounded-none m-1 text-left flex flex-col justify-between transition-all hover:scale-[1.02]"
                      >
                        <div>
                          <span className="font-bold text-editorial-ink block tracking-tight text-[11px] leading-tight">{mod?.code}</span>
                          <span className="text-[9px] text-editorial-ink/75 block leading-normal font-medium mt-0.5">{mod?.name}</span>
                        </div>
                        <div className="mt-1.5 flex items-center gap-1 text-[9px] text-editorial-blue font-bold border-t border-editorial-blue/20 pt-1">
                          <MapPin className="h-3 w-3 text-editorial-blue/75 shrink-0" /> {bldgName}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Room Finder / Availability tool (Right column) */}
        <div className="bg-white border border-editorial-ink/15 rounded-none p-6 space-y-4 flex flex-col justify-between">
          <div className="space-y-1">
            <h3 className="font-editorial-serif font-normal text-editorial-ink text-base flex items-center gap-1.5">
              <MapPin className="h-4.5 w-4.5 text-editorial-rust" /> Classroom Occupancy Guide
            </h3>
            <p className="text-xs text-editorial-ink/65">Find real-time classroom statuses, accessible entrances, and available study spaces on campus.</p>
          </div>

          <div className="relative mt-2">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-editorial-ink/40" />
            <input
              type="text"
              placeholder="Filter rooms by name..."
              value={roomFilter}
              onChange={(e) => setRoomFilter(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs border border-editorial-ink/25 rounded-none focus:outline-none focus:ring-1 focus:ring-editorial-rust bg-[#F9F8F6]/50 text-editorial-ink"
            />
          </div>

          <div className="space-y-2.5 overflow-y-auto max-h-80 pr-1 my-3 flex-1 scrollbar-thin">
            {rooms.filter(r => roomFilter === "" || r.name.toLowerCase().includes(roomFilter.toLowerCase())).map(room => {
              // Simulate current real-time room status based on scheduled events
              const isCurrentlyBusy = scheduledEvents.some(e => e.roomId === room.id && e.timeslotId !== null && (e.timeslotId % 9 === 2 || e.timeslotId % 9 === 3)); // simulate slot 2,3 active
              
              return (
                <div key={room.id} className="p-3 border border-editorial-ink/10 rounded-none hover:border-editorial-ink/20 bg-[#F9F8F6]/60 transition-all space-y-1.5">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-editorial-ink text-xs">{room.name}</span>
                    <span className={`inline-block h-2 w-2 rounded-full ${isCurrentlyBusy ? "bg-editorial-rust" : "bg-editorial-blue"}`}></span>
                  </div>

                  <div className="flex justify-between items-center text-[9px] font-bold uppercase tracking-wider text-editorial-ink/55">
                    <span>{room.type}</span>
                    <span className={isCurrentlyBusy ? "text-editorial-rust" : "text-editorial-blue"}>
                      {isCurrentlyBusy ? "Active Class" : "Vacant / Study Space"}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-[10px] text-editorial-ink/60 pt-1 border-t border-editorial-ink/10">
                    <span>Cap: {room.capacity} seats</span>
                    <span>{room.isAccessible ? "Accessible Access" : "Stairs Access"}</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-3 bg-[#F9F8F6] border border-editorial-ink/10 rounded-none text-[10px] text-editorial-ink/60 flex items-start gap-1.5 leading-relaxed">
            <Info className="h-3.5 w-3.5 text-editorial-rust shrink-0 mt-0.5" />
            <p>Vacant rooms are available for open student study outside scheduled teaching blocks. Ensure you respect active exam windows.</p>
          </div>
        </div>

      </div>
    </div>
  );
}
