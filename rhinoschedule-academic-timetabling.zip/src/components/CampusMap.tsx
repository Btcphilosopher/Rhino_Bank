/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { 
  MapPin, 
  Building, 
  Info, 
  Activity, 
  Navigation,
  Accessibility
} from "lucide-react";
import { Room } from "../types";

interface CampusMapProps {
  buildings: any[];
  rooms: Room[];
}

export default function CampusMap({ buildings, rooms }: CampusMapProps) {
  const [hoveredBldg, setHoveredBldg] = useState<any>(null);
  const [selectedBldgId, setSelectedBldgId] = useState<string>("B01"); // Default Turing bldg

  const activeBldg = buildings.find(b => b.id === selectedBldgId);
  const activeRooms = rooms.filter(r => r.buildingId === selectedBldgId);

  // Simple SVG projection for Manchester Oxford Road campus area
  const scaleX = (lon: number) => {
    // Mapping bounds: -2.236 to -2.230
    return ((lon - (-2.236)) / ( -2.230 - (-2.236) )) * 400 + 40;
  };

  const scaleY = (lat: number) => {
    // Mapping bounds: 53.465 to 53.470
    return (1 - (lat - 53.465) / ( 53.470 - 53.465 )) * 300 + 40;
  };

  return (
    <div id="campus-map" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* 2-Columns: SVG Map Layout */}
      <div className="lg:col-span-2 bg-white border border-editorial-ink/15 rounded-none p-6 space-y-4 flex flex-col justify-between h-[520px]">
        <div>
          <h3 className="font-editorial-serif font-normal text-editorial-ink text-base flex items-center gap-1.5">
            <Building className="h-4.5 w-4.5 text-editorial-rust" /> Interactive Campus & Estates Map
          </h3>
          <p className="text-xs text-editorial-ink/65">Vector projection of university teaching infrastructure. Hover over nodes to inspect capacities.</p>
        </div>

        {/* SVG Projection Panel */}
        <div className="bg-[#F9F8F6] border border-editorial-ink/10 rounded-none flex-1 relative overflow-hidden flex items-center justify-center p-4">
          <svg className="w-full h-full max-w-[500px] max-h-[350px]" viewBox="0 0 480 380">
            {/* Background routes */}
            <path d="M 40,40 L 440,340" stroke="rgba(20, 20, 20, 0.08)" strokeWidth="4" strokeLinecap="round" strokeDasharray="3,6" fill="none" />
            <path d="M 40,300 L 440,100" stroke="rgba(20, 20, 20, 0.06)" strokeWidth="3" strokeLinecap="round" fill="none" />
            <path d="M 240,20 L 240,360" stroke="rgba(20, 20, 20, 0.04)" strokeWidth="6" fill="none" />
            
            {/* Oxford Road spine */}
            <text x="245" y="30" fill="rgba(20, 20, 20, 0.3)" fontSize="8" fontWeight="bold" letterSpacing="0.15em" transform="rotate(90, 245, 30)">OXFORD ROAD CORRIDOR</text>

            {/* Building pins */}
            {buildings.map(bldg => {
              const cx = scaleX(bldg.longitude);
              const cy = scaleY(bldg.latitude);
              const isSelected = bldg.id === selectedBldgId;

              return (
                <g 
                  key={bldg.id}
                  onClick={() => setSelectedBldgId(bldg.id)}
                  onMouseEnter={() => setHoveredBldg(bldg)}
                  onMouseLeave={() => setHoveredBldg(null)}
                  className="cursor-pointer transition-all"
                >
                  <circle 
                    cx={cx} 
                    cy={cy} 
                    r={isSelected ? "13" : "9"} 
                    className={`${isSelected ? "fill-editorial-rust stroke-editorial-rust/20 stroke-[3px]" : "fill-editorial-ink stroke-white stroke-2"} transition-all hover:opacity-90`} 
                  />
                  <text 
                    x={cx} 
                    y={cy + 3} 
                    fill="white" 
                    fontSize={isSelected ? "8" : "7"} 
                    fontWeight="bold" 
                    textAnchor="middle"
                    className="font-mono"
                  >
                    {bldg.code}
                  </text>
                </g>
              );
            })}
          </svg>

          {/* Floating Hover Indicator */}
          {hoveredBldg && (
            <div className="absolute top-4 right-4 bg-editorial-ink text-editorial-bg p-3 rounded-none text-xs shadow-lg space-y-1 z-10 border border-editorial-ink/10 max-w-[200px]">
              <p className="font-editorial-serif font-normal text-editorial-bg text-sm leading-tight">{hoveredBldg.name}</p>
              <p className="text-[10px] text-editorial-bg/60 leading-normal">{hoveredBldg.address}</p>
              <p className="text-[9px] text-editorial-rust font-bold uppercase tracking-wider mt-1 block">Click node to inspect</p>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between text-[9px] uppercase tracking-wider text-editorial-ink/50 font-bold border-t border-editorial-ink/10 pt-4">
          <span className="flex items-center gap-1"><Navigation className="h-3.5 w-3.5 text-editorial-blue" /> Walkways mapped with accessibility route tags</span>
          <span className="flex items-center gap-1"><Accessibility className="h-3.5 w-3.5 text-editorial-rust" /> ADA compliant ramp pathways</span>
        </div>
      </div>

      {/* 1-Column: Selected Building Estates detail */}
      <div className="bg-white border border-editorial-ink/15 rounded-none p-6 shadow-xs flex flex-col justify-between space-y-4 h-[520px]">
        <div className="space-y-1.5 flex flex-col items-start">
          <span className="inline-block px-2 py-0.5 bg-editorial-ink/5 text-editorial-ink border border-editorial-ink/10 text-[9px] font-bold uppercase tracking-wider rounded-none">
            Selected Node: {activeBldg?.code}
          </span>
          <h3 className="font-editorial-serif font-normal text-editorial-ink text-lg mt-1">{activeBldg?.name}</h3>
          <p className="text-xs text-editorial-ink/65 leading-relaxed">{activeBldg?.address}</p>
        </div>

        <div className="flex-1 overflow-y-auto pr-1 space-y-3 scrollbar-thin my-4">
          <h4 className="text-[10px] font-bold text-editorial-ink/40 uppercase tracking-wider">Classrooms Inside</h4>

          {activeRooms.map(room => (
            <div key={room.id} className="p-3 bg-[#F9F8F6] border border-editorial-ink/10 rounded-none space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="font-bold text-editorial-ink">{room.name}</span>
                <span className="text-[9px] bg-editorial-ink/5 border border-editorial-ink/10 font-bold text-editorial-ink px-1.5 py-0.5 rounded-none uppercase">
                  {room.type}
                </span>
              </div>

              <div className="flex items-center justify-between text-[10px] text-editorial-ink/50 font-bold uppercase tracking-wide">
                <span>Cap: {room.capacity} seats</span>
                <span>{room.isAccessible ? "Accessible compliant" : "Steps only"}</span>
              </div>

              <div className="flex flex-wrap gap-1">
                {room.equipment.map(eq => (
                  <span key={eq} className="px-1.5 py-0.5 bg-editorial-blue/10 text-editorial-blue rounded-none text-[9px] font-bold uppercase tracking-wider border border-editorial-blue/20">
                    {eq.replace("_", " ")}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 bg-[#F9F8F6] border border-editorial-ink/10 rounded-none space-y-2 text-xs">
          <p className="font-bold text-editorial-ink">Coordinates Metadata</p>
          <div className="grid grid-cols-2 gap-2 text-[10px] text-editorial-ink/50 font-semibold font-mono">
            <span>Lat: {activeBldg?.latitude}</span>
            <span>Lon: {activeBldg?.longitude}</span>
          </div>
        </div>
      </div>

    </div>
  );
}
