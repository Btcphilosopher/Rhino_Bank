/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum RoomType {
  LectureTheatre = "LectureTheatre",
  SeminarRoom = "SeminarRoom",
  Laboratory = "Laboratory",
  ComputingRoom = "ComputingRoom",
  Studio = "Studio"
}

export interface Building {
  id: string;
  name: string;
  code: string;
  latitude: number;
  longitude: number;
  address: string;
}

export interface Room {
  id: string;
  buildingId: string;
  name: string;
  capacity: number;
  type: RoomType;
  equipment: string[];
  isAccessible: boolean;
  isAvailable: boolean;
  maintenanceHours: number[]; // Timeslots undergoing maintenance
}

export interface Lecturer {
  id: string;
  name: string;
  email: string;
  department: string;
  maxHoursPerWeek: number;
  preferredTimes: number[]; // List of timeslot indices (0-44)
  unavailableTimes: number[]; // List of timeslot indices (0-44)
}

export interface Module {
  id: string;
  code: string;
  name: string;
  lecturerId: string;
  enrollment: number;
  requiredEquipment: string[];
  type: "lecture" | "lab" | "seminar";
  durationSlots: number; // consecutive hours
  courseId: string; // Course/Programme reference
}

export interface Course {
  id: string;
  code: string;
  name: string;
  department: string;
  totalStudents: number;
}

export interface Timeslot {
  id: number; // 0 to 44
  day: string; // "Monday", "Tuesday", etc.
  timeLabel: string; // "09:00", "10:00", etc.
}

export interface ScheduledEvent {
  id: string;
  moduleId: string;
  type: "lecture" | "lab" | "seminar";
  duration: number; // in slots
  roomId: string | null; // Null if unscheduled
  timeslotId: number | null; // Null if unscheduled (0-44)
}

export enum ConstraintSeverity {
  HARD = "HARD", // Must be satisfied
  SOFT = "SOFT"  // Prefer to satisfy, weighted penalty
}

export interface Constraint {
  id: string;
  name: string;
  description: string;
  type: "room_capacity" | "lecturer_clash" | "room_clash" | "lecturer_availability" | "equipment_match" | "student_track_clash";
  severity: ConstraintSeverity;
  weight: number; // Penalty weight for SOFT, high weight for HARD
  isEnabled: boolean;
}

export interface OptimizationScore {
  hardViolations: number;
  softViolations: number;
  totalPenalty: number;
  unassignedEvents: number;
  roomUtilizationRate: number; // percentage
  staffSatisfactionRate: number; // percentage
}

export interface SolverStep {
  iteration: number;
  temperature: number;
  score: OptimizationScore;
  timestamp: string;
  log: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  details: string;
}

export interface Examination {
  id: string;
  moduleId: string;
  durationHours: number;
  roomId: string | null;
  timeslotId: number | null;
  invigilatorId: string | null;
}
