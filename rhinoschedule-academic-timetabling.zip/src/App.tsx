/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { 
  Calendar, 
  Layout, 
  BarChart2, 
  Users, 
  MapPin, 
  Layers, 
  Activity, 
  FileText,
  Settings,
  Grid,
  TrendingUp,
  Sliders,
  CheckCircle,
  HelpCircle
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

import AdminConsole from "./components/AdminConsole";
import ShinyDashboard from "./components/ShinyDashboard";
import StudentPortal from "./components/StudentPortal";
import StaffPortal from "./components/StaffPortal";
import CampusMap from "./components/CampusMap";

import { 
  Room, 
  Lecturer, 
  Module, 
  Course, 
  ScheduledEvent, 
  Constraint, 
  AuditLog, 
  OptimizationScore 
} from "./types";

export default function App() {
  const [activeTab, setActiveTab] = useState<"admin" | "shiny" | "student" | "staff" | "map">("admin");
  const [dataset, setDataset] = useState<any>(null);
  const [isResetting, setIsResetting] = useState(false);

  const fetchDataset = () => {
    fetch("/api/dataset")
      .then((res) => {
        if (!res.ok) throw new Error("API Network error");
        return res.json();
      })
      .then((data) => {
        setDataset(data);
      })
      .catch((err) => {
        console.error("Error loading timetabling dataset:", err);
      });
  };

  useEffect(() => {
    fetchDataset();
  }, []);

  const handleReset = async () => {
    setIsResetting(true);
    try {
      const res = await fetch("/api/dataset/reset", { method: "POST" });
      if (res.ok) {
        fetchDataset();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsResetting(false);
    }
  };

  if (!dataset) {
    return (
      <div className="min-h-screen bg-[#F9F8F6] flex flex-col items-center justify-center p-6 text-center space-y-4">
        <Activity className="h-8 w-8 text-editorial-rust animate-pulse" />
        <p className="text-editorial-ink font-editorial-serif text-3xl tracking-tight">RhinoSchedule</p>
        <p className="text-editorial-ink/60 text-xs font-mono uppercase tracking-widest">Evaluating operations research constraint matrices...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F9F8F6] text-editorial-ink flex flex-col antialiased font-editorial-sans selection:bg-editorial-rust/20">
      {/* Enterprise-grade high-contrast editorial header */}
      <header className="bg-[#F9F8F6] border-b border-[#141414]/15 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 bg-editorial-ink rounded-none flex items-center justify-center text-editorial-bg font-editorial-serif font-bold text-base tracking-tighter">
              RS
            </div>
            <div>
              <h1 className="text-lg font-editorial-serif text-editorial-ink tracking-tight leading-none">RhinoSchedule</h1>
              <span className="text-[9px] font-bold text-editorial-ink/50 tracking-widest uppercase block mt-1 font-editorial-sans">Academic Resource Optimiser</span>
            </div>
          </div>

          {/* Primary View Navigation (Editorial Underlined style) */}
          <nav className="flex flex-wrap gap-1 border-b border-[#141414]/10 md:border-b-0 pb-2 md:pb-0">
            <button
              onClick={() => setActiveTab("admin")}
              className={`flex items-center gap-1.5 px-3 py-2 text-[11px] font-bold tracking-wider uppercase transition-all border-b-2 ${activeTab === "admin" ? "border-editorial-rust text-editorial-ink" : "border-transparent text-editorial-ink/60 hover:text-editorial-ink hover:border-editorial-ink/30"}`}
            >
              <Layout className="h-3.5 w-3.5" /> Administrative Console
            </button>
            <button
              onClick={() => setActiveTab("shiny")}
              className={`flex items-center gap-1.5 px-3 py-2 text-[11px] font-bold tracking-wider uppercase transition-all border-b-2 ${activeTab === "shiny" ? "border-editorial-rust text-editorial-ink" : "border-transparent text-editorial-ink/60 hover:text-editorial-ink hover:border-editorial-ink/30"}`}
            >
              <BarChart2 className="h-3.5 w-3.5" /> R-Shiny Analytics
            </button>
            <button
              onClick={() => setActiveTab("student")}
              className={`flex items-center gap-1.5 px-3 py-2 text-[11px] font-bold tracking-wider uppercase transition-all border-b-2 ${activeTab === "student" ? "border-editorial-rust text-editorial-ink" : "border-transparent text-editorial-ink/60 hover:text-editorial-ink hover:border-editorial-ink/30"}`}
            >
              <Grid className="h-3.5 w-3.5" /> Student Portal
            </button>
            <button
              onClick={() => setActiveTab("staff")}
              className={`flex items-center gap-1.5 px-3 py-2 text-[11px] font-bold tracking-wider uppercase transition-all border-b-2 ${activeTab === "staff" ? "border-editorial-rust text-editorial-ink" : "border-transparent text-editorial-ink/60 hover:text-editorial-ink hover:border-editorial-ink/30"}`}
            >
              <Users className="h-3.5 w-3.5" /> Staff Commitments
            </button>
            <button
              onClick={() => setActiveTab("map")}
              className={`flex items-center gap-1.5 px-3 py-2 text-[11px] font-bold tracking-wider uppercase transition-all border-b-2 ${activeTab === "map" ? "border-editorial-rust text-editorial-ink" : "border-transparent text-editorial-ink/60 hover:text-editorial-ink hover:border-editorial-ink/30"}`}
            >
              <MapPin className="h-3.5 w-3.5" /> Campus Map
            </button>
          </nav>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 md:p-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            transition={{ duration: 0.12 }}
          >
            {activeTab === "admin" && (
              <AdminConsole 
                dataset={dataset} 
                onRefresh={fetchDataset} 
                onReset={handleReset} 
              />
            )}
            
            {activeTab === "shiny" && (
              <ShinyDashboard 
                score={dataset.score} 
                rooms={dataset.rooms} 
              />
            )}

            {activeTab === "student" && (
              <StudentPortal 
                rooms={dataset.rooms} 
                courses={dataset.courses} 
                modules={dataset.modules} 
                scheduledEvents={dataset.scheduledEvents}
                lecturers={dataset.lecturers}
              />
            )}

            {activeTab === "staff" && (
              <StaffPortal 
                lecturers={dataset.lecturers} 
                modules={dataset.modules} 
                scheduledEvents={dataset.scheduledEvents}
                rooms={dataset.rooms}
                onRefresh={fetchDataset}
              />
            )}

            {activeTab === "map" && (
              <CampusMap 
                buildings={dataset.buildings} 
                rooms={dataset.rooms} 
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Corporate/Institutional Footer */}
      <footer className="bg-[#F9F8F6] border-t border-[#141414]/10 py-8 text-center text-xs text-editorial-ink/50 font-medium tracking-wide">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <span>&copy; 2026 RhinoSchedule System Platform. Designed for research-intensive university estates.</span>
          <div className="flex gap-4">
            <span className="flex items-center gap-1 font-bold text-editorial-blue"><CheckCircle className="h-3.5 w-3.5 text-editorial-blue" /> Solved optimally</span>
            <span>Version 4.12.2-stable</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
