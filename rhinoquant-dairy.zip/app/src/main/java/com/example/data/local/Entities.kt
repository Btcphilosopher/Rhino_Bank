package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val orderId: String,
    val instrumentId: String,
    val side: String,
    val price: Double,
    val quantityMt: Double,
    val filledQuantityMt: Double,
    val deliveryWindow: String,
    val location: String,
    val participant: String,
    val timestamp: Long,
    val status: String
)

@Entity(tableName = "trades")
data class TradeEntity(
    @PrimaryKey val tradeId: String,
    val instrumentId: String,
    val productName: String,
    val price: Double,
    val quantityMt: Double,
    val delivery: String,
    val buyer: String,
    val seller: String,
    val timestamp: Long,
    val tradeType: String
)

@Entity(tableName = "lots")
data class LotEntity(
    @PrimaryKey val lotId: String,
    val commodityName: String,
    val grade: String,
    val quantityMt: Double,
    val origin: String,
    val packaging: String,
    val deliveryBasis: String,
    val deliveryWindow: String,
    val warehouseLocation: String,
    val ageDays: Int,
    val status: String
)

@Entity(tableName = "rfqs")
data class RfqEntity(
    @PrimaryKey val rfqId: String,
    val commodityName: String,
    val quantityMt: Double,
    val specSummary: String,
    val deliveryBasis: String,
    val deliveryWindow: String,
    val buyerName: String,
    val status: String,
    val quotesJson: String
)

@Entity(tableName = "positions")
data class PositionEntity(
    @PrimaryKey val instrumentId: String,
    val productName: String,
    val physicalInventoryMt: Double,
    val financialPositionMt: Double,
    val netExposureMt: Double,
    val averagePrice: Double,
    val markPrice: Double,
    val unrealizedPnl: Double,
    val var95: Double
)
