package com.example.data.repository

import com.example.data.local.*
import com.example.data.simulation.MarketDataSeeds
import com.example.domain.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class MarketRepository(
    private val marketDao: MarketDao,
    private val scope: CoroutineScope
) {
    // Mutable state holders for in-memory market structures
    private val _instruments = MutableStateFlow(MarketDataSeeds.INITIAL_INSTRUMENTS)
    val instruments: StateFlow<List<Instrument>> = _instruments.asStateFlow()

    private val _selectedInstrumentId = MutableStateFlow("DAIRY-UK-BUTTER-82-UNSALTED")
    val selectedInstrumentId: StateFlow<String> = _selectedInstrumentId.asStateFlow()

    private val _benchmarks = MutableStateFlow(MarketDataSeeds.INITIAL_BENCHMARKS)
    val benchmarks: StateFlow<List<BenchmarkData>> = _benchmarks.asStateFlow()

    private val _forwardCurves = MutableStateFlow(MarketDataSeeds.INITIAL_FORWARD_CURVES)
    val forwardCurves: StateFlow<List<ForwardCurvePoint>> = _forwardCurves.asStateFlow()

    private val _butterCrush = MutableStateFlow(ButterCrushModel())
    val butterCrush: StateFlow<ButterCrushModel> = _butterCrush.asStateFlow()

    private val _cheeseNetback = MutableStateFlow(CheeseNetbackModel())
    val cheeseNetback: StateFlow<CheeseNetbackModel> = _cheeseNetback.asStateFlow()

    // Replay & Simulation state
    private val _isReplayPlaying = MutableStateFlow(true)
    val isReplayPlaying: StateFlow<Boolean> = _isReplayPlaying.asStateFlow()

    private val _replaySpeed = MutableStateFlow(1) // 1x, 5x, 20x, 100x
    val replaySpeed: StateFlow<Int> = _replaySpeed.asStateFlow()

    private val _replayTickCount = MutableStateFlow(10482)
    val replayTickCount: StateFlow<Int> = _replayTickCount.asStateFlow()

    private val _activeScenario = MutableStateFlow<ScenarioImpact?>(null)
    val activeScenario: StateFlow<ScenarioImpact?> = _activeScenario.asStateFlow()

    private val _apiKey = MutableStateFlow("rq_live_sec_993814028391")
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    // Flow from Room Database
    val ordersFlow: Flow<List<OrderBookEntry>> = marketDao.getAllOrders().map { list ->
        list.map { it.toDomain() }
    }

    val tradesFlow: Flow<List<TradeRecord>> = marketDao.getAllTrades().map { list ->
        list.map { it.toDomain() }
    }

    val lotsFlow: Flow<List<PhysicalLot>> = marketDao.getAllLots().map { list ->
        list.map { it.toDomain() }
    }

    val rfqsFlow: Flow<List<RfqItem>> = marketDao.getAllRfqs().map { list ->
        list.map { it.toDomain() }
    }

    val positionsFlow: Flow<List<PositionItem>> = marketDao.getAllPositions().map { list ->
        list.map { it.toDomain() }
    }

    init {
        // Seed database if empty
        scope.launch(Dispatchers.IO) {
            seedDatabaseIfNecessary()
            startSimulationLoop()
        }
    }

    private suspend fun seedDatabaseIfNecessary() {
        val existingOrders = marketDao.getAllOrders().firstOrNull()
        if (existingOrders.isNullOrEmpty()) {
            marketDao.insertOrders(MarketDataSeeds.INITIAL_ORDERS.map { it.toEntity() })
            marketDao.insertLots(MarketDataSeeds.INITIAL_LOTS.map { it.toEntity() })
            marketDao.insertPositions(MarketDataSeeds.INITIAL_POSITIONS.map { it.toEntity() })
            for (trade in MarketDataSeeds.INITIAL_TRADES) {
                marketDao.insertTrade(trade.toEntity())
            }
            for (rfq in MarketDataSeeds.INITIAL_RFQS) {
                marketDao.insertRfq(rfq.toEntity())
            }
        }
    }

    fun selectInstrument(id: String) {
        _selectedInstrumentId.value = id
    }

    fun setReplayPlaying(playing: Boolean) {
        _isReplayPlaying.value = playing
    }

    fun setReplaySpeed(speed: Int) {
        _replaySpeed.value = speed
    }

    fun updateButterCrushCreamPrice(newCreamPrice: Double) {
        val curr = _butterCrush.value
        val newTheoretical = newCreamPrice * 2.15 + 100.0 // yield relationship
        val newMargin = curr.butterPricePerMt - newCreamPrice - curr.churningCostPerMt - curr.storageCostPerMt
        _butterCrush.value = curr.copy(
            creamPricePerMt = newCreamPrice,
            theoreticalButterValue = newTheoretical,
            indicativeCrushMargin = newMargin
        )
    }

    fun updateCheeseNetbackPrice(newCheesePrice: Double) {
        val curr = _cheeseNetback.value
        val impliedPpl = (newCheesePrice * (curr.cheeseYieldPct / 100.0) + curr.wheyValuePerMtMilk - curr.processingCostPerMtMilk) / 10.0
        _cheeseNetback.value = curr.copy(
            cheddarPricePerMt = newCheesePrice,
            impliedMilkPricePpl = impliedPpl
        )
    }

    fun applyScenario(scenario: ScenarioImpact?) {
        _activeScenario.value = scenario
        if (scenario != null) {
            val mult = 1.0 + (scenario.butterPricePct / 100.0)
            _instruments.update { list ->
                list.map { inst ->
                    if (inst.commodityType == CommodityType.UNSALTED_BUTTER) {
                        inst.copy(lastPrice = inst.lastPrice * mult, changePercent = scenario.butterPricePct)
                    } else inst
                }
            }
        } else {
            _instruments.value = MarketDataSeeds.INITIAL_INSTRUMENTS
        }
    }

    suspend fun submitOrder(
        instrumentId: String,
        side: OrderSide,
        price: Double,
        quantityMt: Double,
        deliveryWindow: String,
        participant: String = "RHINO-TRADER-01"
    ) {
        val orderId = "ORD-${System.currentTimeMillis().toString().takeLast(5)}"
        val newOrder = OrderBookEntry(
            orderId = orderId,
            instrumentId = instrumentId,
            side = side,
            price = price,
            quantityMt = quantityMt,
            filledQuantityMt = 0.0,
            deliveryWindow = deliveryWindow,
            location = "EX-STORE UK",
            participant = participant,
            timestamp = System.currentTimeMillis(),
            status = OrderStatus.OPEN
        )

        marketDao.insertOrder(newOrder.toEntity())
        attemptMatch(newOrder)
    }

    private suspend fun attemptMatch(incomingOrder: OrderBookEntry) {
        val openOrders = marketDao.getOpenOrdersForInstrument(incomingOrder.instrumentId).firstOrNull() ?: return
        val currentInst = _instruments.value.find { it.instrumentId == incomingOrder.instrumentId } ?: return

        val oppositeOrders = openOrders.filter {
            if (incomingOrder.side == OrderSide.BID) {
                it.side == "ASK" && it.price <= incomingOrder.price
            } else {
                it.side == "BID" && it.price >= incomingOrder.price
            }
        }.sortedWith(
            if (incomingOrder.side == OrderSide.BID) {
                compareBy<OrderEntity> { it.price }.thenBy { it.timestamp }
            } else {
                compareByDescending<OrderEntity> { it.price }.thenBy { it.timestamp }
            }
        )

        var remainingQty = incomingOrder.quantityMt - incomingOrder.filledQuantityMt

        for (oppEntity in oppositeOrders) {
            if (remainingQty <= 0) break

            val oppQtyRemaining = oppEntity.quantityMt - oppEntity.filledQuantityMt
            val matchQty = min(remainingQty, oppQtyRemaining)
            val matchPrice = oppEntity.price // Maker price priority

            remainingQty -= matchQty
            val newFilledQtyIncoming = incomingOrder.quantityMt - remainingQty
            val newFilledQtyOpp = oppEntity.filledQuantityMt + matchQty

            // Update Maker order
            val oppStatus = if (newFilledQtyOpp >= oppEntity.quantityMt) "FILLED" else "PARTIALLY_FILLED"
            marketDao.updateOrderStatus(oppEntity.orderId, oppStatus, newFilledQtyOpp)

            // Execute Trade
            val tradeId = "TRD-${System.currentTimeMillis().toString().takeLast(5)}"
            val buyer = if (incomingOrder.side == OrderSide.BID) incomingOrder.participant else oppEntity.participant
            val seller = if (incomingOrder.side == OrderSide.BID) oppEntity.participant else incomingOrder.participant

            val trade = TradeRecord(
                tradeId = tradeId,
                instrumentId = incomingOrder.instrumentId,
                productName = currentInst.name,
                price = matchPrice,
                quantityMt = matchQty,
                delivery = incomingOrder.deliveryWindow,
                buyer = buyer,
                seller = seller,
                timestamp = System.currentTimeMillis(),
                tradeType = "EXECUTED_MATCH"
            )

            marketDao.insertTrade(trade.toEntity())

            // Update Instrument Market Data
            _instruments.update { list ->
                list.map { inst ->
                    if (inst.instrumentId == incomingOrder.instrumentId) {
                        val newVol = inst.volumeMt + matchQty
                        val newVwap = ((inst.vwap * inst.volumeMt) + (matchPrice * matchQty)) / newVol
                        inst.copy(
                            lastPrice = matchPrice,
                            high = max(inst.high, matchPrice),
                            low = min(inst.low, matchPrice),
                            vwap = newVwap,
                            volumeMt = newVol,
                            bid = if (incomingOrder.side == OrderSide.BID) max(inst.bid, matchPrice - 5) else inst.bid,
                            ask = if (incomingOrder.side == OrderSide.ASK) min(inst.ask, matchPrice + 5) else inst.ask
                        )
                    } else inst
                }
            }

            // Update Benchmark
            _benchmarks.update { list ->
                list.map { b ->
                    if (b.benchmarkId.contains("BUTTER") && incomingOrder.instrumentId.contains("BUTTER")) {
                        b.copy(calculatedValue = matchPrice, observationCount = b.observationCount + 1)
                    } else b
                }
            }
        }

        val incomingStatus = if (remainingQty <= 0) "FILLED" else if (remainingQty < incomingOrder.quantityMt) "PARTIALLY_FILLED" else "OPEN"
        marketDao.updateOrderStatus(incomingOrder.orderId, incomingStatus, incomingOrder.quantityMt - remainingQty)
    }

    suspend fun awardRfq(rfqId: String, quoteId: String) {
        val rfqs = marketDao.getAllRfqs().firstOrNull() ?: return
        val rfqEntity = rfqs.find { it.rfqId == rfqId } ?: return
        val rfq = rfqEntity.toDomain()
        val quote = rfq.quotes.find { it.quoteId == quoteId } ?: return

        // Mark RFQ Awarded
        marketDao.updateRfqStatus(rfqId, "AWARDED")

        // Create Execution Trade
        val tradeId = "TRD-RFQ-${System.currentTimeMillis().toString().takeLast(4)}"
        val trade = TradeRecord(
            tradeId = tradeId,
            instrumentId = "DAIRY-UK-BUTTER-82-UNSALTED",
            productName = rfq.commodityName,
            price = quote.pricePerMt,
            quantityMt = rfq.quantityMt,
            delivery = rfq.deliveryBasis,
            buyer = rfq.buyerName,
            seller = quote.supplierName,
            timestamp = System.currentTimeMillis(),
            tradeType = "RFQ_AWARD"
        )
        marketDao.insertTrade(trade.toEntity())

        // Create Physical Lot
        val newLot = PhysicalLot(
            lotId = "RQD-LOT-${System.currentTimeMillis().toString().takeLast(5)}",
            commodityName = rfq.commodityName,
            grade = "SPEC-MATCHED 100%",
            quantityMt = rfq.quantityMt,
            origin = quote.origin,
            packaging = "STANDARD BULK",
            deliveryBasis = rfq.deliveryBasis,
            deliveryWindow = rfq.deliveryWindow,
            warehouseLocation = "RHINO APPROVED WAREHOUSE",
            ageDays = 1,
            status = LotStatus.RESERVED
        )
        marketDao.insertLot(newLot.toEntity())
    }

    suspend fun createRfq(commodityName: String, quantityMt: Double, deliveryWindow: String, specSummary: String) {
        val rfqId = "RFQ-2026-${Random.nextInt(100, 999)}"
        val quotes = listOf(
            RfqQuote("Q-10", "NORTHFIELD DAIRY", 3460.0, 99.0, "DELIVERED", "NET 30", "UK (SOMERSET)"),
            RfqQuote("Q-11", "BRITANNIA INGREDIENTS", 3475.0, 97.5, "EX-STORE", "NET 14", "UK (CHESHIRE)"),
            RfqQuote("Q-12", "MERIDIAN FOODS", 3455.0, 96.0, "DELIVERED", "NET 30", "UK (DEVON)")
        )
        val rfq = RfqItem(
            rfqId = rfqId,
            commodityName = commodityName,
            quantityMt = quantityMt,
            specSummary = specSummary,
            deliveryBasis = "DELIVERED",
            deliveryWindow = deliveryWindow,
            buyerName = "RHINO QUANT TRADING",
            status = RfqStatus.QUOTING,
            quotes = quotes
        )
        marketDao.insertRfq(rfq.toEntity())
    }

    private suspend fun startSimulationLoop() {
        while (true) {
            val isPlaying = _isReplayPlaying.value
            val speed = _replaySpeed.value
            val delayMs = (2000 / speed).toLong().coerceAtLeast(100)

            delay(delayMs)

            if (isPlaying) {
                _replayTickCount.update { it + 1 }
                generateSyntheticMarketTick()
            }
        }
    }

    private suspend fun generateSyntheticMarketTick() {
        val instList = _instruments.value
        val targetInst = instList.random()
        val delta = (Random.nextDouble(-10.0, 10.0)).let { Math.round(it * 2.0) / 2.0 }
        val newPrice = max(100.0, targetInst.lastPrice + delta)

        _instruments.update { list ->
            list.map { inst ->
                if (inst.instrumentId == targetInst.instrumentId) {
                    inst.copy(
                        lastPrice = newPrice,
                        high = max(inst.high, newPrice),
                        low = min(inst.low, newPrice),
                        bid = newPrice - 10.0,
                        ask = newPrice + 10.0
                    )
                } else inst
            }
        }

        // Occasionally insert a synthetic order or trade
        if (Random.nextInt(10) < 3) {
            val side = if (Random.nextBoolean()) OrderSide.BID else OrderSide.ASK
            val counterparty = listOf("NORTHFIELD DAIRY", "MERIDIAN FOODS", "BRITANNIA INGREDIENTS", "EUROPA INGREDIENTS").random()
            val synthOrder = OrderBookEntry(
                orderId = "ORD-SYN-${Random.nextInt(1000, 9999)}",
                instrumentId = targetInst.instrumentId,
                side = side,
                price = if (side == OrderSide.BID) newPrice - 5 else newPrice + 5,
                quantityMt = (Random.nextInt(1, 5) * 25).toDouble(),
                deliveryWindow = "15-31 OCT 2026",
                participant = counterparty,
                timestamp = System.currentTimeMillis()
            )
            marketDao.insertOrder(synthOrder.toEntity())
        }
    }

    // Helper mappings
    private fun OrderEntity.toDomain() = OrderBookEntry(
        orderId = orderId,
        instrumentId = instrumentId,
        side = OrderSide.valueOf(side),
        price = price,
        quantityMt = quantityMt,
        filledQuantityMt = filledQuantityMt,
        deliveryWindow = deliveryWindow,
        location = location,
        participant = participant,
        timestamp = timestamp,
        status = OrderStatus.valueOf(status)
    )

    private fun OrderBookEntry.toEntity() = OrderEntity(
        orderId = orderId,
        instrumentId = instrumentId,
        side = side.name,
        price = price,
        quantityMt = quantityMt,
        filledQuantityMt = filledQuantityMt,
        deliveryWindow = deliveryWindow,
        location = location,
        participant = participant,
        timestamp = timestamp,
        status = status.name
    )

    private fun TradeEntity.toDomain() = TradeRecord(
        tradeId = tradeId,
        instrumentId = instrumentId,
        productName = productName,
        price = price,
        quantityMt = quantityMt,
        delivery = delivery,
        buyer = buyer,
        seller = seller,
        timestamp = timestamp,
        tradeType = tradeType
    )

    private fun TradeRecord.toEntity() = TradeEntity(
        tradeId = tradeId,
        instrumentId = instrumentId,
        productName = productName,
        price = price,
        quantityMt = quantityMt,
        delivery = delivery,
        buyer = buyer,
        seller = seller,
        timestamp = timestamp,
        tradeType = tradeType
    )

    private fun LotEntity.toDomain() = PhysicalLot(
        lotId = lotId,
        commodityName = commodityName,
        grade = grade,
        quantityMt = quantityMt,
        origin = origin,
        packaging = packaging,
        deliveryBasis = deliveryBasis,
        deliveryWindow = deliveryWindow,
        warehouseLocation = warehouseLocation,
        ageDays = ageDays,
        status = LotStatus.valueOf(status)
    )

    private fun PhysicalLot.toEntity() = LotEntity(
        lotId = lotId,
        commodityName = commodityName,
        grade = grade,
        quantityMt = quantityMt,
        origin = origin,
        packaging = packaging,
        deliveryBasis = deliveryBasis,
        deliveryWindow = deliveryWindow,
        warehouseLocation = warehouseLocation,
        ageDays = ageDays,
        status = status.name
    )

    private fun RfqEntity.toDomain(): RfqItem {
        val quoteList = mutableListOf<RfqQuote>()
        if (quotesJson.contains("NORTHFIELD")) {
            quoteList.add(RfqQuote("Q-01", "NORTHFIELD DAIRY", 3460.0, 99.0, "DELIVERED", "NET 30", "UK"))
            quoteList.add(RfqQuote("Q-02", "MERIDIAN FOODS", 3475.0, 97.5, "EX-STORE", "NET 14", "UK"))
        }
        return RfqItem(
            rfqId = rfqId,
            commodityName = commodityName,
            quantityMt = quantityMt,
            specSummary = specSummary,
            deliveryBasis = deliveryBasis,
            deliveryWindow = deliveryWindow,
            buyerName = buyerName,
            status = RfqStatus.valueOf(status),
            quotes = quoteList
        )
    }

    private fun RfqItem.toEntity() = RfqEntity(
        rfqId = rfqId,
        commodityName = commodityName,
        quantityMt = quantityMt,
        specSummary = specSummary,
        deliveryBasis = deliveryBasis,
        deliveryWindow = deliveryWindow,
        buyerName = buyerName,
        status = status.name,
        quotesJson = quotes.joinToString { "${it.supplierName}:${it.pricePerMt}" }
    )

    private fun PositionEntity.toDomain() = PositionItem(
        instrumentId = instrumentId,
        productName = productName,
        physicalInventoryMt = physicalInventoryMt,
        financialPositionMt = financialPositionMt,
        netExposureMt = netExposureMt,
        averagePrice = averagePrice,
        markPrice = markPrice,
        unrealizedPnl = unrealizedPnl,
        var95 = var95
    )

    private fun PositionItem.toEntity() = PositionEntity(
        instrumentId = instrumentId,
        productName = productName,
        physicalInventoryMt = physicalInventoryMt,
        financialPositionMt = financialPositionMt,
        netExposureMt = netExposureMt,
        averagePrice = averagePrice,
        markPrice = markPrice,
        unrealizedPnl = unrealizedPnl,
        var95 = var95
    )
}
