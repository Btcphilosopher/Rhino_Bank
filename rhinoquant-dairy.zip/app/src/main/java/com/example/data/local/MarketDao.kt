package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MarketDao {
    // Orders
    @Query("SELECT * FROM orders WHERE instrumentId = :instrumentId AND status IN ('OPEN', 'PARTIALLY_FILLED') ORDER BY price DESC, timestamp ASC")
    fun getOpenOrdersForInstrument(instrumentId: String): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders ORDER BY timestamp DESC LIMIT 200")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrders(orders: List<OrderEntity>)

    @Query("UPDATE orders SET status = :status, filledQuantityMt = :filledQty WHERE orderId = :orderId")
    suspend fun updateOrderStatus(orderId: String, status: String, filledQty: Double)

    // Trades
    @Query("SELECT * FROM trades WHERE instrumentId = :instrumentId ORDER BY timestamp DESC LIMIT 50")
    fun getTradesForInstrument(instrumentId: String): Flow<List<TradeEntity>>

    @Query("SELECT * FROM trades ORDER BY timestamp DESC LIMIT 100")
    fun getAllTrades(): Flow<List<TradeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrade(trade: TradeEntity)

    // Lots
    @Query("SELECT * FROM lots ORDER BY ageDays ASC")
    fun getAllLots(): Flow<List<LotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLot(lot: LotEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLots(lots: List<LotEntity>)

    @Query("UPDATE lots SET status = :status WHERE lotId = :lotId")
    suspend fun updateLotStatus(lotId: String, status: String)

    // RFQs
    @Query("SELECT * FROM rfqs ORDER BY rfqId DESC")
    fun getAllRfqs(): Flow<List<RfqEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRfq(rfq: RfqEntity)

    @Query("UPDATE rfqs SET status = :status WHERE rfqId = :rfqId")
    suspend fun updateRfqStatus(rfqId: String, status: String)

    // Positions
    @Query("SELECT * FROM positions")
    fun getAllPositions(): Flow<List<PositionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPositions(positions: List<PositionEntity>)
}
