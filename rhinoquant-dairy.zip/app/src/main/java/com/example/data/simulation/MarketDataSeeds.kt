package com.example.data.simulation

import com.example.domain.model.*

object MarketDataSeeds {

    val INITIAL_INSTRUMENTS = listOf(
        Instrument(
            instrumentId = "DAIRY-UK-BUTTER-82-UNSALTED",
            symbol = "RQ-UK-BUTTER-SPOT",
            name = "UK Unsalted Butter 82%",
            commodityGroup = CommodityGroup.FATS,
            commodityType = CommodityType.UNSALTED_BUTTER,
            market = "UK_PHYSICAL",
            currency = "GBP",
            unit = "GBP_PER_TONNE",
            deliveryBasis = "EX_STORE",
            lastPrice = 3470.0,
            bid = 3460.0,
            ask = 3480.0,
            changePercent = 1.2,
            vwap = 3469.0,
            volumeMt = 425.0,
            high = 3520.0,
            low = 3440.0,
            spec = ProductSpecification(fatPct = 82.0, moisturePct = 16.0, origin = "UNITED KINGDOM", packaging = "25 KG BLOCK")
        ),
        Instrument(
            instrumentId = "DAIRY-UK-SMP-26-FOOD",
            symbol = "RQ-UK-SMP-SPOT",
            name = "UK Skimmed Milk Powder",
            commodityGroup = CommodityGroup.PROTEINS,
            commodityType = CommodityType.SMP,
            market = "UK_PHYSICAL",
            currency = "GBP",
            unit = "GBP_PER_TONNE",
            deliveryBasis = "EX_STORE",
            lastPrice = 2510.0,
            bid = 2500.0,
            ask = 2520.0,
            changePercent = 0.8,
            vwap = 2508.0,
            volumeMt = 680.0,
            high = 2540.0,
            low = 2490.0,
            spec = ProductSpecification(fatPct = 1.2, proteinPct = 34.0, moisturePct = 4.0, origin = "UNITED KINGDOM", packaging = "25 KG BAG")
        ),
        Instrument(
            instrumentId = "DAIRY-UK-CHEDDAR-MILD",
            symbol = "RQ-UK-CHEDDAR-SPOT",
            name = "UK Mild Cheddar Block",
            commodityGroup = CommodityGroup.CHEESE,
            commodityType = CommodityType.MILD_CHEDDAR,
            market = "UK_PHYSICAL",
            currency = "GBP",
            unit = "GBP_PER_TONNE",
            deliveryBasis = "DELIVERED",
            lastPrice = 3080.0,
            bid = 3070.0,
            ask = 3090.0,
            changePercent = 0.4,
            vwap = 3078.0,
            volumeMt = 310.0,
            high = 3110.0,
            low = 3060.0,
            spec = ProductSpecification(fatPct = 34.5, moisturePct = 37.0, ageMonths = 3, blockWeightKg = 20.0)
        ),
        Instrument(
            instrumentId = "DAIRY-UK-CREAM-BULK",
            symbol = "RQ-UK-CREAM-SPOT",
            name = "UK Bulk Sweet Cream 40%",
            commodityGroup = CommodityGroup.LIQUID_DAIRY,
            commodityType = CommodityType.CREAM,
            market = "UK_PHYSICAL",
            currency = "GBP",
            unit = "GBP_PER_TONNE",
            deliveryBasis = "PROCESSOR_GATE",
            lastPrice = 1640.0,
            bid = 1630.0,
            ask = 1650.0,
            changePercent = 1.1,
            vwap = 1638.0,
            volumeMt = 890.0,
            high = 1670.0,
            low = 1620.0,
            spec = ProductSpecification(fatPct = 40.0, moisturePct = 54.0, storage = "CHILLED TANKER (4°C)")
        ),
        Instrument(
            instrumentId = "DAIRY-EU-BUTTER-SALTED",
            symbol = "RQ-EU-BUTTER-SPOT",
            name = "EU Salted Butter 80%",
            commodityGroup = CommodityGroup.FATS,
            commodityType = CommodityType.SALTED_BUTTER,
            market = "EU_PHYSICAL",
            currency = "EUR",
            unit = "EUR_PER_TONNE",
            deliveryBasis = "EX_STORE",
            lastPrice = 3980.0,
            bid = 3970.0,
            ask = 3995.0,
            changePercent = -0.3,
            vwap = 3978.0,
            volumeMt = 540.0,
            high = 4020.0,
            low = 3950.0,
            spec = ProductSpecification(fatPct = 80.0, saltPct = 2.0, origin = "NETHERLANDS")
        ),
        Instrument(
            instrumentId = "DAIRY-EU-AMF-99.8",
            symbol = "RQ-EU-AMF-SPOT",
            name = "Anhydrous Milk Fat 99.8%",
            commodityGroup = CommodityGroup.FATS,
            commodityType = CommodityType.AMF,
            market = "EU_PHYSICAL",
            currency = "EUR",
            unit = "EUR_PER_TONNE",
            deliveryBasis = "EX_STORE",
            lastPrice = 4850.0,
            bid = 4830.0,
            ask = 4870.0,
            changePercent = 1.6,
            vwap = 4845.0,
            volumeMt = 210.0,
            high = 4890.0,
            low = 4810.0,
            spec = ProductSpecification(fatPct = 99.8, moisturePct = 0.1, packaging = "200 KG DRUM")
        ),
        Instrument(
            instrumentId = "DAIRY-UK-WHEY-POWDER",
            symbol = "RQ-UK-WHEY-SPOT",
            name = "Sweet Whey Powder",
            commodityGroup = CommodityGroup.PROTEINS,
            commodityType = CommodityType.WHEY_POWDER,
            market = "UK_PHYSICAL",
            currency = "GBP",
            unit = "GBP_PER_TONNE",
            deliveryBasis = "EX_STORE",
            lastPrice = 890.0,
            bid = 880.0,
            ask = 900.0,
            changePercent = -0.5,
            vwap = 888.0,
            volumeMt = 1120.0,
            high = 910.0,
            low = 875.0,
            spec = ProductSpecification(proteinPct = 11.0, fatPct = 1.0, moisturePct = 4.5)
        ),
        Instrument(
            instrumentId = "DAIRY-UK-RAW-MILK",
            symbol = "RQ-UK-FARMGATE-MILK",
            name = "UK Farmgate Raw Milk",
            commodityGroup = CommodityGroup.LIQUID_DAIRY,
            commodityType = CommodityType.RAW_MILK,
            market = "UK_PHYSICAL",
            currency = "GBP",
            unit = "GBP_PER_TONNE",
            deliveryBasis = "PROCESSOR_GATE",
            lastPrice = 415.0, // ~41.5 p/L
            bid = 410.0,
            ask = 420.0,
            changePercent = 0.2,
            vwap = 414.5,
            volumeMt = 3400.0,
            high = 425.0,
            low = 408.0,
            spec = ProductSpecification(fatPct = 4.1, proteinPct = 3.4, storage = "FARM TANK (3°C)")
        )
    )

    val INITIAL_LOTS = listOf(
        PhysicalLot(
            lotId = "RQD-UK-2026-004182",
            commodityName = "UNSALTED BUTTER 82%",
            grade = "GRADE A - PREMIUM",
            quantityMt = 25.0,
            origin = "UNITED KINGDOM (SOMERSET)",
            packaging = "25 KG BLOCK IN LINED CARTON",
            deliveryBasis = "EX-STORE",
            deliveryWindow = "01–15 OCT 2026",
            warehouseLocation = "RHINO-LOGISTICS COLD STORE #4 (BRISTOL)",
            ageDays = 14,
            status = LotStatus.AVAILABLE
        ),
        PhysicalLot(
            lotId = "RQD-UK-2026-004183",
            commodityName = "UNSALTED BUTTER 82%",
            grade = "GRADE A",
            quantityMt = 50.0,
            origin = "UNITED KINGDOM (CHESHIRE)",
            packaging = "25 KG BLOCK",
            deliveryBasis = "EX-STORE",
            deliveryWindow = "15–31 OCT 2026",
            warehouseLocation = "RHINO-LOGISTICS COLD STORE #2 (MANCHESTER)",
            ageDays = 22,
            status = LotStatus.AVAILABLE
        ),
        PhysicalLot(
            lotId = "RQD-UK-2026-004190",
            commodityName = "SKIMMED MILK POWDER",
            grade = "EXTRA GRADE LOW HEAT",
            quantityMt = 100.0,
            origin = "UNITED KINGDOM (CUMBRIA)",
            packaging = "1000 KG TOTE BAG",
            deliveryBasis = "DELIVERED",
            deliveryWindow = "01–10 NOV 2026",
            warehouseLocation = "WEST COUNTRY DRY WAREHOUSE #1",
            ageDays = 35,
            status = LotStatus.RESERVED
        ),
        PhysicalLot(
            lotId = "RQD-UK-2026-004195",
            commodityName = "MILD CHEDDAR BLOCK",
            grade = "MATURED 90 DAYS",
            quantityMt = 40.0,
            origin = "UNITED KINGDOM (DEVON)",
            packaging = "20 KG BLOCK VACUUM SEALED",
            deliveryBasis = "EX-STORE",
            deliveryWindow = "01–15 OCT 2026",
            warehouseLocation = "SOUTH WEST CHEESE VAULT",
            ageDays = 78,
            status = LotStatus.AVAILABLE
        ),
        PhysicalLot(
            lotId = "RQD-UK-2026-004201",
            commodityName = "BULK SWEET CREAM 40%",
            grade = "FRESH PASTEURISED",
            quantityMt = 30.0,
            origin = "UNITED KINGDOM (YORKSHIRE)",
            packaging = "ISO TANKER",
            deliveryBasis = "PROCESSOR GATE",
            deliveryWindow = "26–28 SEP 2026",
            warehouseLocation = "PENNINE PROCESSING PLANT GATE B",
            ageDays = 2,
            status = LotStatus.IN_TRANSIT
        )
    )

    val INITIAL_ORDERS = listOf(
        OrderBookEntry("ORD-8801", "DAIRY-UK-BUTTER-82-UNSALTED", OrderSide.ASK, 3520.0, 25.0, 0.0, "01–15 OCT 2026", "BRISTOL COLD STORE", "MERIDIAN FOODS", System.currentTimeMillis() - 120000),
        OrderBookEntry("ORD-8802", "DAIRY-UK-BUTTER-82-UNSALTED", OrderSide.ASK, 3500.0, 50.0, 0.0, "01–15 OCT 2026", "MANCHESTER COLD STORE", "BRITANNIA INGREDIENTS", System.currentTimeMillis() - 90000),
        OrderBookEntry("ORD-8803", "DAIRY-UK-BUTTER-82-UNSALTED", OrderSide.ASK, 3485.0, 25.0, 0.0, "01–15 OCT 2026", "SOMERSET WAREHOUSE", "EUROPA INGREDIENTS", System.currentTimeMillis() - 45000),
        OrderBookEntry("ORD-8804", "DAIRY-UK-BUTTER-82-UNSALTED", OrderSide.BID, 3460.0, 25.0, 0.0, "01–15 OCT 2026", "EX-STORE UK", "NORTHFIELD DAIRY", System.currentTimeMillis() - 30000),
        OrderBookEntry("ORD-8805", "DAIRY-UK-BUTTER-82-UNSALTED", OrderSide.BID, 3445.0, 50.0, 0.0, "01–15 OCT 2026", "EX-STORE UK", "PENNINE MILK CO-OP", System.currentTimeMillis() - 20000),
        OrderBookEntry("ORD-8806", "DAIRY-UK-BUTTER-82-UNSALTED", OrderSide.BID, 3420.0, 75.0, 0.0, "01–15 OCT 2026", "EX-STORE UK", "WEST COUNTRY DAIRY", System.currentTimeMillis() - 10000),

        // SMP Orders
        OrderBookEntry("ORD-8901", "DAIRY-UK-SMP-26-FOOD", OrderSide.ASK, 2530.0, 100.0, 0.0, "OCT 2026", "CUMBRIA DRY STORE", "BRITANNIA INGREDIENTS", System.currentTimeMillis() - 80000),
        OrderBookEntry("ORD-8902", "DAIRY-UK-SMP-26-FOOD", OrderSide.ASK, 2520.0, 50.0, 0.0, "OCT 2026", "MANCHESTER DRY STORE", "EUROPA INGREDIENTS", System.currentTimeMillis() - 60000),
        OrderBookEntry("ORD-8903", "DAIRY-UK-SMP-26-FOOD", OrderSide.BID, 2500.0, 75.0, 0.0, "OCT 2026", "EX-STORE UK", "NORTH SEA FOODS", System.currentTimeMillis() - 50000),
        OrderBookEntry("ORD-8904", "DAIRY-UK-SMP-26-FOOD", OrderSide.BID, 2485.0, 150.0, 0.0, "OCT 2026", "EX-STORE UK", "MERIDIAN FOODS", System.currentTimeMillis() - 25000)
    )

    val INITIAL_TRADES = listOf(
        TradeRecord("TRD-88421", "DAIRY-UK-BUTTER-82-UNSALTED", "UK Unsalted Butter 82%", 3470.0, 25.0, "UK / OCT", "NORTHFIELD DAIRY", "MERIDIAN FOODS", System.currentTimeMillis() - 300000, "EXECUTED_MATCH"),
        TradeRecord("TRD-88420", "DAIRY-UK-BUTTER-82-UNSALTED", "UK Unsalted Butter 82%", 3465.0, 50.0, "UK / OCT", "PENNINE MILK CO-OP", "EUROPA INGREDIENTS", System.currentTimeMillis() - 900000, "EXECUTED_MATCH"),
        TradeRecord("TRD-88419", "DAIRY-UK-SMP-26-FOOD", "UK Skimmed Milk Powder", 2510.0, 100.0, "UK / NOV", "BRITANNIA INGREDIENTS", "NORTH SEA FOODS", System.currentTimeMillis() - 1500000, "EXECUTED_MATCH"),
        TradeRecord("TRD-88418", "DAIRY-UK-CREAM-BULK", "UK Bulk Sweet Cream 40%", 1640.0, 30.0, "UK / IMMEDIATE", "WEST COUNTRY DAIRY", "MERIDIAN FOODS", System.currentTimeMillis() - 2400000, "RFQ_AWARD"),
        TradeRecord("TRD-88417", "DAIRY-UK-CHEDDAR-MILD", "UK Mild Cheddar Block", 3080.0, 20.0, "UK / OCT", "NORTHFIELD DAIRY", "PENNINE MILK CO-OP", System.currentTimeMillis() - 3600000, "EXECUTED_MATCH")
    )

    val INITIAL_BENCHMARKS = listOf(
        BenchmarkData("RQ-UK-BUTTER-SPOT", "RhinoQuant UK Butter Spot Benchmark", "VOLUME_WEIGHTED", "GBP", "GBP_PER_TONNE", "UNITED KINGDOM", 3469.0, observationCount = 58),
        BenchmarkData("RQ-UK-SMP-SPOT", "RhinoQuant UK SMP Spot Benchmark", "VOLUME_WEIGHTED", "GBP", "GBP_PER_TONNE", "UNITED KINGDOM", 2508.0, observationCount = 44),
        BenchmarkData("RQ-UK-CREAM-SPOT", "RhinoQuant UK Cream Spot Benchmark", "TRIMMED_MEAN", "GBP", "GBP_PER_TONNE", "UNITED KINGDOM", 1638.0, observationCount = 32),
        BenchmarkData("RQ-UK-CHEDDAR-SPOT", "RhinoQuant UK Cheddar Spot Benchmark", "SIMPLE_AVERAGE", "GBP", "GBP_PER_TONNE", "UNITED KINGDOM", 3078.0, observationCount = 26),
        BenchmarkData("RQ-EU-BUTTER", "RhinoQuant EU Butter Index", "VOLUME_WEIGHTED", "EUR", "EUR_PER_TONNE", "EUROPEAN UNION", 3978.0, observationCount = 82)
    )

    val INITIAL_FORWARD_CURVES = listOf(
        ForwardCurvePoint("SPOT", 3470.0, 42.0, 425.0, 1250.0, 0.0, "FLAT"),
        ForwardCurvePoint("OCT 2026", 3485.0, 15.0, 310.0, 2100.0, 15.0, "CONTANGO"),
        ForwardCurvePoint("NOV 2026", 3510.0, 25.0, 280.0, 2850.0, 40.0, "CONTANGO"),
        ForwardCurvePoint("DEC 2026", 3560.0, 50.0, 410.0, 3400.0, 90.0, "CONTANGO"),
        ForwardCurvePoint("JAN 2027", 3540.0, -20.0, 190.0, 2900.0, 70.0, "BACKWARDATION"),
        ForwardCurvePoint("FEB 2027", 3490.0, -50.0, 150.0, 2100.0, 20.0, "BACKWARDATION"),
        ForwardCurvePoint("MAR 2027", 3430.0, -60.0, 220.0, 1850.0, -40.0, "BACKWARDATION")
    )

    val INITIAL_RFQS = listOf(
        RfqItem(
            rfqId = "RFQ-2026-089",
            commodityName = "UNSALTED BUTTER 82%",
            quantityMt = 25.0,
            specSummary = "Fat >= 82%, Moisture <= 16%, UK Origin, 25kg Block",
            deliveryBasis = "DELIVERED TO PROCESSOR",
            deliveryWindow = "10–20 OCT 2026",
            buyerName = "MERIDIAN FOODS PROC",
            status = RfqStatus.QUOTING,
            quotes = listOf(
                RfqQuote("Q-01", "PENNINE MILK CO-OP", 3465.0, 98.5, "DELIVERED", "NET 30", "UK (CHESHIRE)"),
                RfqQuote("Q-02", "NORTHFIELD DAIRY", 3480.0, 100.0, "EX-STORE", "NET 14", "UK (SOMERSET)"),
                RfqQuote("Q-03", "WEST COUNTRY DAIRY", 3450.0, 95.0, "DELIVERED", "NET 30", "UK (DEVON)")
            )
        ),
        RfqItem(
            rfqId = "RFQ-2026-090",
            commodityName = "SKIMMED MILK POWDER",
            quantityMt = 100.0,
            specSummary = "Protein >= 34%, Extra Grade, Low Heat",
            deliveryBasis = "EX-STORE WAREHOUSE",
            deliveryWindow = "01–15 NOV 2026",
            buyerName = "BRITANNIA INGREDIENTS",
            status = RfqStatus.PUBLISHED,
            quotes = emptyList()
        )
    )

    val INITIAL_POSITIONS = listOf(
        PositionItem("DAIRY-UK-BUTTER-82-UNSALTED", "UK Unsalted Butter 82%", physicalInventoryMt = 250.0, financialPositionMt = 50.0, netExposureMt = 300.0, averagePrice = 3420.0, markPrice = 3470.0, unrealizedPnl = 15000.0, var95 = 12400.0),
        PositionItem("DAIRY-UK-SMP-26-FOOD", "UK Skimmed Milk Powder", physicalInventoryMt = 180.0, financialPositionMt = -30.0, netExposureMt = 150.0, averagePrice = 2490.0, markPrice = 2510.0, unrealizedPnl = 3000.0, var95 = 8200.0),
        PositionItem("DAIRY-UK-CHEDDAR-MILD", "UK Mild Cheddar Block", physicalInventoryMt = 120.0, financialPositionMt = 0.0, netExposureMt = 120.0, averagePrice = 3060.0, markPrice = 3080.0, unrealizedPnl = 2400.0, var95 = 5100.0),
        PositionItem("DAIRY-UK-CREAM-BULK", "UK Bulk Sweet Cream 40%", physicalInventoryMt = 45.0, financialPositionMt = 0.0, netExposureMt = 45.0, averagePrice = 1625.0, markPrice = 1640.0, unrealizedPnl = 675.0, var95 = 2800.0)
    )

    val SCENARIOS = listOf(
        ScenarioImpact(
            scenarioId = "SCENARIO-01",
            title = "UK SPRING FLUSH SUPPLY SHOCK (-8%)",
            description = "Unseasonal drought reduces milk yields across UK producing regions by 8%, tightening fat and protein availability.",
            supplyShockPct = -8.0,
            energyShockPct = 5.0,
            demandShockPct = 2.0,
            rawMilkPricePct = 12.4,
            butterPricePct = 15.8,
            creamPricePct = 18.2,
            smpPricePct = 9.5,
            cheddarPricePct = 11.0
        ),
        ScenarioImpact(
            scenarioId = "SCENARIO-02",
            title = "ENERGY & PROCESSING COST SPIKE (+20%)",
            description = "Gas and electricity price increases drive spray-drying (SMP/WMP) and churning energy overheads up 20%.",
            supplyShockPct = 0.0,
            energyShockPct = 20.0,
            demandShockPct = -1.5,
            rawMilkPricePct = -2.5,
            butterPricePct = 6.2,
            creamPricePct = 4.0,
            smpPricePct = 8.9,
            cheddarPricePct = 5.1
        ),
        ScenarioImpact(
            scenarioId = "SCENARIO-03",
            title = "GLOBAL EXPORT DEMAND CONTRACTION (-4%)",
            description = "Reduced import demand in East Asia leads to powder accumulation in European cold stores.",
            supplyShockPct = 0.0,
            energyShockPct = 0.0,
            demandShockPct = -4.0,
            rawMilkPricePct = -6.8,
            butterPricePct = -8.2,
            creamPricePct = -5.4,
            smpPricePct = -11.5,
            cheddarPricePct = -4.8
        )
    )
}
