package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        OrderEntity::class,
        TradeEntity::class,
        LotEntity::class,
        RfqEntity::class,
        PositionEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class RhinoQuantDatabase : RoomDatabase() {
    abstract fun marketDao(): MarketDao

    companion object {
        @Volatile
        private var INSTANCE: RhinoQuantDatabase? = null

        fun getDatabase(context: Context): RhinoQuantDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RhinoQuantDatabase::class.java,
                    "rhinoquant_dairy_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
