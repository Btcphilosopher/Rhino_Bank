package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.DataLineageModal
import com.example.ui.components.MarketHeaderBar
import com.example.ui.components.QuickOrderModal
import com.example.ui.screens.*
import com.example.ui.theme.RhinoQuantTheme
import com.example.ui.theme.RqBlack
import com.example.ui.viewmodel.RhinoQuantViewModel
import com.example.ui.viewmodel.TerminalTab

class MainActivity : ComponentActivity() {

    private val viewModel: RhinoQuantViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            RhinoQuantTheme {
                val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
                val instruments by viewModel.instruments.collectAsStateWithLifecycle()
                val selectedInstrument by viewModel.selectedInstrument.collectAsStateWithLifecycle()
                val openOrders by viewModel.openOrdersForSelected.collectAsStateWithLifecycle()
                val tradesForSelected by viewModel.tradesForSelected.collectAsStateWithLifecycle()
                val forwardCurves by viewModel.forwardCurves.collectAsStateWithLifecycle()
                val butterCrush by viewModel.butterCrush.collectAsStateWithLifecycle()
                val cheeseNetback by viewModel.cheeseNetback.collectAsStateWithLifecycle()
                val lots by viewModel.lots.collectAsStateWithLifecycle()
                val rfqs by viewModel.rfqs.collectAsStateWithLifecycle()
                val positions by viewModel.positions.collectAsStateWithLifecycle()
                val isReplayPlaying by viewModel.isReplayPlaying.collectAsStateWithLifecycle()
                val replaySpeed by viewModel.replaySpeed.collectAsStateWithLifecycle()
                val replayTickCount by viewModel.replayTickCount.collectAsStateWithLifecycle()
                val activeScenario by viewModel.activeScenario.collectAsStateWithLifecycle()
                val apiKey by viewModel.apiKey.collectAsStateWithLifecycle()
                val benchmarks by viewModel.benchmarks.collectAsStateWithLifecycle()
                val showQuickOrderModal by viewModel.showQuickOrderModal.collectAsStateWithLifecycle()
                val activeLineage by viewModel.activeLineage.collectAsStateWithLifecycle()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = RqBlack,
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(RqBlack)
                    ) {
                        MarketHeaderBar(
                            instruments = instruments,
                            selectedTab = selectedTab,
                            onTabSelected = { viewModel.selectTab(it) },
                            isReplayPlaying = isReplayPlaying,
                            onToggleReplay = { viewModel.setReplayPlaying(!isReplayPlaying) },
                            replaySpeed = replaySpeed,
                            onSetReplaySpeed = { viewModel.setReplaySpeed(it) },
                            replayTickCount = replayTickCount,
                            onOpenLineage = {
                                benchmarks.firstOrNull()?.let { b -> viewModel.showDataLineage(b) }
                            }
                        )

                        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
                            when (selectedTab) {
                                TerminalTab.MARKET_TERMINAL -> {
                                    MarketTerminalScreen(
                                        instruments = instruments,
                                        selectedInstrument = selectedInstrument,
                                        onSelectInstrument = { viewModel.selectInstrument(it) },
                                        orders = openOrders,
                                        trades = tradesForSelected,
                                        forwardCurves = forwardCurves,
                                        onOpenQuickOrder = { viewModel.toggleQuickOrderModal(true) }
                                    )
                                }
                                TerminalTab.DAIRY_COMPLEX -> {
                                    DairyComplexScreen(
                                        butterCrush = butterCrush,
                                        onUpdateCreamPrice = { viewModel.updateButterCrushCreamPrice(it) },
                                        cheeseNetback = cheeseNetback,
                                        onUpdateCheesePrice = { viewModel.updateCheeseNetbackPrice(it) }
                                    )
                                }
                                TerminalTab.CURVES_AND_BASIS -> {
                                    CurvesAndBasisScreen(
                                        forwardCurves = forwardCurves,
                                        instruments = instruments
                                    )
                                }
                                TerminalTab.PHYSICAL_LOTS_RFQ -> {
                                    PhysicalLotsAndRfqScreen(
                                        lots = lots,
                                        rfqs = rfqs,
                                        onAwardRfq = { rfqId, quoteId -> viewModel.awardRfq(rfqId, quoteId) },
                                        onCreateRfq = { comm, qty, win, spec -> viewModel.createRfq(comm, qty, win, spec) }
                                    )
                                }
                                TerminalTab.RISK_AND_POSITIONS -> {
                                    RiskAndPositionsScreen(
                                        positions = positions,
                                        activeScenario = activeScenario,
                                        onApplyScenario = { viewModel.applyScenario(it) }
                                    )
                                }
                                TerminalTab.REPLAY_SIMULATOR -> {
                                    ReplaySimulatorScreen(
                                        isReplayPlaying = isReplayPlaying,
                                        onToggleReplay = { viewModel.setReplayPlaying(!isReplayPlaying) },
                                        replaySpeed = replaySpeed,
                                        onSetReplaySpeed = { viewModel.setReplaySpeed(it) },
                                        replayTickCount = replayTickCount
                                    )
                                }
                                TerminalTab.DEVELOPER_API_LAB -> {
                                    ApiConsoleAndLabScreen(
                                        apiKey = apiKey,
                                        instruments = instruments,
                                        benchmarks = benchmarks
                                    )
                                }
                            }

                            if (showQuickOrderModal && selectedInstrument != null) {
                                QuickOrderModal(
                                    instrument = selectedInstrument!!,
                                    onDismiss = { viewModel.toggleQuickOrderModal(false) },
                                    onSubmitOrder = { side, price, qty, win ->
                                        viewModel.submitOrder(side, price, qty, win)
                                    }
                                )
                            }

                            activeLineage?.let { lineage ->
                                DataLineageModal(
                                    lineage = lineage,
                                    onDismiss = { viewModel.dismissDataLineage() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
