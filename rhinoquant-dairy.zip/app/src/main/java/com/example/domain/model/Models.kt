package com.example.domain.model

enum class CommodityGroup {
    LIQUID_DAIRY, FATS, PROTEINS, CHEESE, OTHER
}

enum class CommodityType {
    RAW_MILK, LIQUID_MILK, CREAM, CONCENTRATED_CREAM,
    UNSALTED_BUTTER, SALTED_BUTTER, AMF, BUTTER_OIL,
    SMP, WMP, WHEY_POWDER, WPC, WPI,
    MILD_CHEDDAR, MATURE_CHEDDAR, MOZZARELLA, GOUDA, BUTTERKASE, CHEESE_CURD,
    MILK_CONCENTRATE, PERMEATE, LACTOSE, CASEIN, CASEINATE
}

enum class LotStatus {
    AVAILABLE, RESERVED, PARTIALLY_ALLOCATED, SOLD, IN_TRANSIT, DELIVERED, REJECTED, CANCELLED
}

enum class OrderSide {
    BID, ASK
}

enum class OrderStatus {
    NEW, OPEN, PARTIALLY_FILLED, FILLED, CANCELLED, EXPIRED, REJECTED
}

enum class RfqStatus {
    DRAFT, PUBLISHED, QUOTING, AWARDED, PARTIALLY_AWARDED, EXPIRED, CANCELLED
}

data class ProductSpecification(
    val fatPct: Double = 82.0,
    val moisturePct: Double = 16.0,
    val proteinPct: Double = 1.0,
    val nonFatMilkSolidsPct: Double = 1.0,
    val saltPct: Double = 0.0,
    val packaging: String = "25 KG BLOCK",
    val origin: String = "UNITED KINGDOM",
    val storage: String = "COLD STORE (-18°C)",
    val shelfLifeDays: Int = 365,
    val microbiologyGrade: String = "STANDARD ISO 22000",
    val blockWeightKg: Double = 25.0,
    val ageMonths: Int = 1
)

data class Instrument(
    val instrumentId: String,
    val symbol: String,
    val name: String,
    val commodityGroup: CommodityGroup,
    val commodityType: CommodityType,
    val market: String,
    val currency: String,
    val unit: String,
    val deliveryBasis: String,
    val lastPrice: Double,
    val bid: Double,
    val ask: Double,
    val changePercent: Double,
    val vwap: Double,
    val volumeMt: Double,
    val high: Double,
    val low: Double,
    val spec: ProductSpecification = ProductSpecification()
)

data class PhysicalLot(
    val lotId: String,
    val commodityName: String,
    val grade: String,
    val quantityMt: Double,
    val origin: String,
    val packaging: String,
    val deliveryBasis: String,
    val deliveryWindow: String,
    val warehouseLocation: String,
    val ageDays: Int,
    val status: LotStatus
)

data class OrderBookEntry(
    val orderId: String,
    val instrumentId: String,
    val side: OrderSide,
    val price: Double,
    val quantityMt: Double,
    val filledQuantityMt: Double = 0.0,
    val deliveryWindow: String = "15-31 OCT 2026",
    val location: String = "UK / EX-STORE",
    val participant: String = "ANONYMOUS",
    val timestamp: Long = System.currentTimeMillis(),
    val status: OrderStatus = OrderStatus.OPEN
)

data class TradeRecord(
    val tradeId: String,
    val instrumentId: String,
    val productName: String,
    val price: Double,
    val quantityMt: Double,
    val delivery: String,
    val buyer: String,
    val seller: String,
    val timestamp: Long = System.currentTimeMillis(),
    val tradeType: String = "EXECUTED_MATCH"
)

data class BenchmarkData(
    val benchmarkId: String,
    val name: String,
    val methodology: String,
    val currency: String,
    val unit: String,
    val geography: String,
    val calculatedValue: Double,
    val dataStatus: String = "SYNTHETIC",
    val source: String = "RHINOQUANT DEMO SPOT MARKET",
    val confidence: String = "HIGH (100% EXECUTED)",
    val observationCount: Int = 42,
    val timestampIso: String = "2026-09-26T00:22:00Z"
)

data class ForwardCurvePoint(
    val period: String,
    val price: Double,
    val change: Double,
    val volumeMt: Double,
    val openInterestMt: Double,
    val basisVsSpot: Double,
    val marketStructure: String
)

data class RfqQuote(
    val quoteId: String,
    val supplierName: String,
    val pricePerMt: Double,
    val qualityMatchPct: Double,
    val deliveryTerms: String,
    val paymentTerms: String,
    val origin: String
)

data class RfqItem(
    val rfqId: String,
    val commodityName: String,
    val quantityMt: Double,
    val specSummary: String,
    val deliveryBasis: String,
    val deliveryWindow: String,
    val buyerName: String,
    val status: RfqStatus,
    val quotes: List<RfqQuote> = emptyList()
)

data class PositionItem(
    val instrumentId: String,
    val productName: String,
    val physicalInventoryMt: Double,
    val financialPositionMt: Double,
    val netExposureMt: Double,
    val averagePrice: Double,
    val markPrice: Double,
    val unrealizedPnl: Double,
    val var95: Double
)

data class ButterCrushModel(
    val creamPricePerMt: Double = 1640.0,
    val butterPricePerMt: Double = 3470.0,
    val theoreticalButterValue: Double = 3620.0,
    val churningCostPerMt: Double = 180.0,
    val storageCostPerMt: Double = 45.0,
    val indicativeCrushMargin: Double = 275.0
)

data class CheeseNetbackModel(
    val cheddarPricePerMt: Double = 3080.0,
    val milkFatPct: Double = 4.1,
    val milkProteinPct: Double = 3.4,
    val cheeseYieldPct: Double = 10.2,
    val wheyValuePerMtMilk: Double = 38.0,
    val processingCostPerMtMilk: Double = 65.0,
    val impliedMilkPricePpl: Double = 41.8
)

data class ScenarioImpact(
    val scenarioId: String,
    val title: String,
    val description: String,
    val supplyShockPct: Double,
    val energyShockPct: Double,
    val demandShockPct: Double,
    val rawMilkPricePct: Double,
    val butterPricePct: Double,
    val creamPricePct: Double,
    val smpPricePct: Double,
    val cheddarPricePct: Double
)
