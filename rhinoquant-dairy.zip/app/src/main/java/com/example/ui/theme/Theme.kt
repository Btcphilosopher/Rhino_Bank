package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val RqDarkColorScheme = darkColorScheme(
    primary = RqIce,
    onPrimary = RqBlack,
    primaryContainer = RqRhinoBlue,
    onPrimaryContainer = RqIce,
    secondary = RqSteel,
    onSecondary = RqBlack,
    tertiary = RqAmber,
    onTertiary = RqBlack,
    background = RqBlack,
    onBackground = RqTextPrimary,
    surface = RqGraphite,
    onSurface = RqTextPrimary,
    surfaceVariant = RqSurfaceVariant,
    onSurfaceVariant = RqTextSecondary,
    outline = RqSteel,
    error = RqMarketRed,
    onError = RqTextPrimary
)

private val RqLightColorScheme = lightColorScheme(
    primary = RqRhinoBlue,
    onPrimary = RqPaper,
    primaryContainer = RqIce,
    onPrimaryContainer = RqBlack,
    secondary = RqSteel,
    onSecondary = RqPaper,
    tertiary = RqAmber,
    onTertiary = RqBlack,
    background = RqPaper,
    onBackground = RqBlack,
    surface = RqPaper,
    onSurface = RqBlack,
    surfaceVariant = RqIce,
    onSurfaceVariant = RqGraphite,
    outline = RqSteel,
    error = RqMarketRed
)

@Composable
fun RhinoQuantTheme(
    darkTheme: Boolean = true, // Institutional terminal default is dark
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) RqDarkColorScheme else RqLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

