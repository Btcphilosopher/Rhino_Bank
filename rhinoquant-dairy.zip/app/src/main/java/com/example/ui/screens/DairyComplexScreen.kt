package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ButterCrushModel
import com.example.domain.model.CheeseNetbackModel
import com.example.ui.theme.*

@Composable
fun DairyComplexScreen(
    butterCrush: ButterCrushModel,
    onUpdateCreamPrice: (Double) -> Unit,
    cheeseNetback: CheeseNetbackModel,
    onUpdateCheesePrice: (Double) -> Unit
) {
    var creamPriceInput by remember { mutableStateOf(butterCrush.creamPricePerMt.toString()) }
    var cheesePriceInput by remember { mutableStateOf(cheeseNetback.cheddarPricePerMt.toString()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBlack)
            .padding(10.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // TITLE HEADER
        Text(
            text = "DAIRY COMMODITY COMPLEX & VALUE EQUIVALENCE ENGINE",
            color = RqPaper,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
        Text(
            text = "MILK → FAT → PROTEIN → POWDER → CHEESE → CRUSH MARGINS",
            color = RqSteel,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(12.dp))

        // VISUAL NETWORK CARD
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RqGraphite)
                .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "QUANTITATIVE DAIRY PRODUCT MATRIX NETWORK",
                    color = RqAmber,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(10.dp))

                // MILK NODE
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(RqRhinoBlue)
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "RAW MILK (100% Volume @ 4.1% Fat, 3.4% Protein)",
                        color = RqPaper,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(text = "│\n┌─────────────┼─────────────┐\n↓             ↓             ↓", color = RqSteel, fontSize = 11.sp, fontFamily = FontFamily.Monospace)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(RqSurfaceVariant)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "CREAM (40% Fat)", color = RqIce, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "£1,640 / MT", color = RqPaper, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(RqSurfaceVariant)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "CHEESE (Cheddar)", color = RqIce, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "£3,080 / MT", color = RqPaper, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(RqSurfaceVariant)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "SMP (34% Protein)", color = RqIce, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "£2,510 / MT", color = RqPaper, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                Text(text = "│             │             │\n↓             ↓             ↓", color = RqSteel, fontSize = 11.sp, fontFamily = FontFamily.Monospace)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(RqRhinoBlue)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(text = "BUTTER 82% (£3,470)", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(RqRhinoBlue)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(text = "WHEY POWDER (£890)", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(RqRhinoBlue)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(text = "WPC / WPI / PERMEATE", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // TWO MODELS ROW
        Row(modifier = Modifier.fillMaxWidth()) {
            // BUTTER / CREAM CRUSH CALCULATOR (50%)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(RqGraphite)
                    .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "BUTTER / CREAM CRUSH MODEL",
                        color = RqPaper,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Churning Economics & Indicative Margin",
                        color = RqSteel,
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = creamPriceInput,
                        onValueChange = {
                            creamPriceInput = it
                            it.toDoubleOrNull()?.let { p -> onUpdateCreamPrice(p) }
                        },
                        label = { Text("CREAM INPUT COST (£/MT)", color = RqSteel, fontSize = 9.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RqAmber,
                            unfocusedBorderColor = RqSurfaceVariant,
                            focusedTextColor = RqPaper,
                            unfocusedTextColor = RqPaper
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "BUTTER SPOT PRICE:", color = RqSteel, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "£${String.format("%.0f", butterCrush.butterPricePerMt)} / MT", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "THEORETICAL BUTTER VAL:", color = RqSteel, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "£${String.format("%.0f", butterCrush.theoreticalButterValue)} / MT", color = RqAmber, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "CHURNING + STORAGE:", color = RqSteel, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "-£${String.format("%.0f", butterCrush.churningCostPerMt + butterCrush.storageCostPerMt)} / MT", color = RqMarketRed, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }

                    Divider(color = RqSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "INDICATIVE CRUSH MARGIN:", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text(
                            text = "£${String.format("%.0f", butterCrush.indicativeCrushMargin)} / MT",
                            color = if (butterCrush.indicativeCrushMargin >= 0) RqMarketGreen else RqMarketRed,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // CHEESE NETBACK MODEL (50%)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(RqGraphite)
                    .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "CHEESE MILK NETBACK EQUIVALENT",
                        color = RqPaper,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Implied Farmgate Milk Value from Cheddar",
                        color = RqSteel,
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = cheesePriceInput,
                        onValueChange = {
                            cheesePriceInput = it
                            it.toDoubleOrNull()?.let { p -> onUpdateCheesePrice(p) }
                        },
                        label = { Text("CHEDDAR CHEESE PRICE (£/MT)", color = RqSteel, fontSize = 9.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RqAmber,
                            unfocusedBorderColor = RqSurfaceVariant,
                            focusedTextColor = RqPaper,
                            unfocusedTextColor = RqPaper
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "CHEESE YIELD ESTIMATE:", color = RqSteel, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "${cheeseNetback.cheeseYieldPct}%", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "WHEY CREDIT / TONNE MILK:", color = RqSteel, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "+£${cheeseNetback.wheyValuePerMtMilk}", color = RqMarketGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "PROCESSING COST / TONNE:", color = RqSteel, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "-£${cheeseNetback.processingCostPerMtMilk}", color = RqMarketRed, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }

                    Divider(color = RqSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "IMPLIED MILK VALUE:", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text(
                            text = "${String.format("%.1f", cheeseNetback.impliedMilkPricePpl)} p / Litre",
                            color = RqAmber,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
