package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// RHINOQUANT INSTITUTIONAL PALETTE
val RqBlack = Color(0xFF111313)
val RqGraphite = Color(0xFF202426)
val RqSurfaceVariant = Color(0xFF2B3033)
val RqPaper = Color(0xFFE9E7DF)
val RqSteel = Color(0xFF727977)
val RqRhinoBlue = Color(0xFF294A59)
val RqMarketGreen = Color(0xFF3F7354)
val RqMarketRed = Color(0xFF9B4038)
val RqAmber = Color(0xFFB38A42)
val RqIce = Color(0xFFC7D2D1)
val RqTextPrimary = Color(0xFFF2F4F3)
val RqTextSecondary = Color(0xFFA1A8A6)

