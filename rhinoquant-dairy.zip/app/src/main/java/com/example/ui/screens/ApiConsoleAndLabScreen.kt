package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.BenchmarkData
import com.example.domain.model.Instrument
import com.example.ui.theme.*

@Composable
fun ApiConsoleAndLabScreen(
    apiKey: String,
    instruments: List<Instrument>,
    benchmarks: List<BenchmarkData>
) {
    var selectedEndpoint by remember { mutableStateOf("/v1/instruments") }
    var responseJson by remember {
        mutableStateOf(
            """
{
  "data": [
    {
      "instrumentId": "DAIRY-UK-BUTTER-82-UNSALTED",
      "symbol": "RQ-UK-BUTTER-SPOT",
      "name": "UK Unsalted Butter 82%",
      "lastPrice": 3470.0,
      "currency": "GBP",
      "unit": "GBP_PER_TONNE",
      "deliveryBasis": "EX_STORE"
    }
  ],
  "meta": {
    "timestamp": "2026-09-26T00:22:00Z",
    "source": "RHINOQUANT_SYNTHETIC",
    "version": "v1.4.2",
    "dataQuality": "HIGH_PROVENANCE"
  }
}
            """.trimIndent()
        )
    }

    val endpoints = listOf(
        "/v1/instruments",
        "/v1/prices/DAIRY-UK-BUTTER-82-UNSALTED",
        "/v1/trades",
        "/v1/curves/BUTTER",
        "/v1/benchmarks",
        "/v1/rfq",
        "/v1/risk/positions"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBlack)
            .padding(10.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "RHINOQUANT DEVELOPER API LAB & INTERACTIVE CONSOLE",
            color = RqPaper,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
        Text(
            text = "INSTITUTIONAL REST & WEBSOCKET ENGINE │ OPENAPI SPEC │ AUTHORIZATION & ADMIN CONTROLS",
            color = RqSteel,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(12.dp))

        // API KEY & HEADER BADGE
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RqGraphite)
                .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "API KEY AUTHORIZATION", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text(text = apiKey, color = RqAmber, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }

                Row {
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(RqMarketGreen.copy(alpha = 0.2f)).padding(6.dp)) {
                        Text(text = "ROLE: INSTITUTIONAL_TRADER", color = RqMarketGreen, fontWeight = FontWeight.Bold, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(RqRhinoBlue).padding(6.dp)) {
                        Text(text = "RATE LIMIT: 10,000 REQ/MIN", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // ENDPOINT SELECTOR & EXECUTION
        Row(modifier = Modifier.fillMaxWidth()) {
            // ENDPOINTS LIST (35%)
            Box(
                modifier = Modifier
                    .weight(0.8f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(RqGraphite)
                    .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                Column {
                    Text(text = "SELECT REST ENDPOINT", color = RqPaper, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)

                    Spacer(modifier = Modifier.height(6.dp))

                    endpoints.forEach { ep ->
                        val isSel = selectedEndpoint == ep
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSel) RqRhinoBlue else RqSurfaceVariant)
                                .clickable {
                                    selectedEndpoint = ep
                                    responseJson = when {
                                        ep.contains("instruments") -> """{"data":${instruments.map { "{\"id\":\"${it.instrumentId}\",\"symbol\":\"${it.symbol}\",\"price\":${it.lastPrice}}" }},"meta":{"source":"RHINOQUANT_SYNTHETIC"}}"""
                                        ep.contains("benchmarks") -> """{"data":${benchmarks.map { "{\"id\":\"${it.benchmarkId}\",\"val\":${it.calculatedValue}}" }},"meta":{"source":"RHINOQUANT_SYNTHETIC"}}"""
                                        else -> """{"data":[],"meta":{"source":"RHINOQUANT_SYNTHETIC","status":"200 OK"}}"""
                                    }
                                }
                                .padding(horizontal = 6.dp, vertical = 6.dp)
                        ) {
                            Text(text = ep, color = if (isSel) RqPaper else RqTextPrimary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // RESPONSE INSPECTOR (65%)
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(RqGraphite)
                    .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "RESPONSE INSPECTOR [200 OK │ 12ms]", color = RqMarketGreen, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Button(
                            onClick = {},
                            colors = ButtonDefaults.buttonColors(containerColor = RqMarketGreen, contentColor = RqPaper),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("RUN GET", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(RqBlack)
                            .padding(8.dp)
                    ) {
                        Text(text = responseJson, color = RqIce, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // ADMIN MARKET CONTROL
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RqGraphite)
                .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Column {
                Text(
                    text = "ADMINISTRATIVE MARKET CONTROL PANEL",
                    color = RqMarketRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = RqMarketRed)) {
                        Text("EMERGENCY MARKET HALT", fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                    }
                    Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = RqRhinoBlue)) {
                        Text("SEED SYNTHETIC LIQUIDITY", fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                    }
                    Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = RqSurfaceVariant)) {
                        Text("PUBLISH BENCHMARK INDEX", fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}
