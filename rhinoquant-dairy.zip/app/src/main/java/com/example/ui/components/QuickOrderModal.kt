package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.model.Instrument
import com.example.domain.model.OrderSide
import com.example.ui.theme.*

@Composable
fun QuickOrderModal(
    instrument: Instrument,
    onDismiss: () -> Unit,
    onSubmitOrder: (side: OrderSide, price: Double, qtyMt: Double, window: String) -> Unit
) {
    var side by remember { mutableStateOf(OrderSide.BID) }
    var priceText by remember { mutableStateOf(instrument.lastPrice.toString()) }
    var qtyText by remember { mutableStateOf("25.0") }
    var windowText by remember { mutableStateOf("01–15 OCT 2026") }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(RqGraphite)
                .border(1.dp, RqSteel, RoundedCornerShape(8.dp))
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "INSTITUTIONAL SPOT ORDER ENTRY",
                        color = RqPaper,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = RqSteel)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "${instrument.name} (${instrument.symbol})",
                    color = RqAmber,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(12.dp))

                // SIDE SELECTOR
                Row(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (side == OrderSide.BID) RqMarketGreen else RqSurfaceVariant)
                            .clickable { side = OrderSide.BID }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "BUY (BID)", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (side == OrderSide.ASK) RqMarketRed else RqSurfaceVariant)
                            .clickable { side = OrderSide.ASK }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "SELL (ASK)", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("LIMIT PRICE (${instrument.currency}/MT)", color = RqSteel, fontSize = 10.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RqAmber,
                        unfocusedBorderColor = RqSurfaceVariant,
                        focusedTextColor = RqPaper,
                        unfocusedTextColor = RqPaper
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = qtyText,
                    onValueChange = { qtyText = it },
                    label = { Text("QUANTITY (METRIC TONNES)", color = RqSteel, fontSize = 10.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RqAmber,
                        unfocusedBorderColor = RqSurfaceVariant,
                        focusedTextColor = RqPaper,
                        unfocusedTextColor = RqPaper
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = windowText,
                    onValueChange = { windowText = it },
                    label = { Text("DELIVERY WINDOW / BASIS", color = RqSteel, fontSize = 10.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RqAmber,
                        unfocusedBorderColor = RqSurfaceVariant,
                        focusedTextColor = RqPaper,
                        unfocusedTextColor = RqPaper
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val p = priceText.toDoubleOrNull() ?: instrument.lastPrice
                        val q = qtyText.toDoubleOrNull() ?: 25.0
                        onSubmitOrder(side, p, q, windowText)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (side == OrderSide.BID) RqMarketGreen else RqMarketRed,
                        contentColor = RqPaper
                    ),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth().height(42.dp)
                ) {
                    Text(
                        text = "SUBMIT SPOT ORDER → PRICE-TIME MATCH",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
