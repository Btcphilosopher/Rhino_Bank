package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.PhysicalLot
import com.example.domain.model.RfqItem
import com.example.ui.theme.*

@Composable
fun PhysicalLotsAndRfqScreen(
    lots: List<PhysicalLot>,
    rfqs: List<RfqItem>,
    onAwardRfq: (rfqId: String, quoteId: String) -> Unit,
    onCreateRfq: (commodity: String, qtyMt: Double, window: String, spec: String) -> Unit
) {
    var showCreateRfqModal by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBlack)
            .padding(10.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PHYSICAL LOTS, COLD STORE LOGISTICS & RFQ MARKET",
                    color = RqPaper,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "PHYSICAL LOT SPECIFICATIONS │ WAREHOUSE AGING │ RFQ INSTITUTIONAL QUOTATION",
                    color = RqSteel,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Button(
                onClick = { showCreateRfqModal = true },
                colors = ButtonDefaults.buttonColors(containerColor = RqRhinoBlue, contentColor = RqPaper),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.height(34.dp)
            ) {
                Text(text = "+ CREATE RFQ", fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // COLD STORE WAREHOUSE INVENTORY AGING
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RqGraphite)
                .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Column {
                Text(
                    text = "COLD STORE & DRY WAREHOUSE INVENTORY AGING (MT)",
                    color = RqAmber,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(4.dp)).background(RqSurfaceVariant).padding(8.dp)) {
                        Column {
                            Text(text = "0–30 DAYS", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "420 MT (FRESH)", color = RqMarketGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(4.dp)).background(RqSurfaceVariant).padding(8.dp)) {
                        Column {
                            Text(text = "31–60 DAYS", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "280 MT", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(4.dp)).background(RqSurfaceVariant).padding(8.dp)) {
                        Column {
                            Text(text = "61–90 DAYS", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "115 MT", color = RqAmber, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(4.dp)).background(RqSurfaceVariant).padding(8.dp)) {
                        Column {
                            Text(text = "90+ DAYS", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "42 MT (INSPECT)", color = RqMarketRed, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // PHYSICAL LOTS MASTER TABLE
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RqGraphite)
                .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Column {
                Text(
                    text = "PHYSICAL LOTS INVENTORY MASTER",
                    color = RqPaper,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RqSurfaceVariant)
                        .padding(horizontal = 4.dp, vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "LOT ID", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                    Text(text = "COMMODITY / GRADE", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                    Text(text = "QTY", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                    Text(text = "ORIGIN / LOCATION", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.6f))
                    Text(text = "STATUS", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(4.dp))

                lots.forEach { lot ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = lot.lotId, color = RqAmber, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                        Text(text = "${lot.commodityName}\n${lot.grade}", color = RqPaper, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                        Text(text = "${lot.quantityMt.toInt()} MT", color = RqIce, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                        Text(text = "${lot.origin}\n${lot.warehouseLocation.take(22)}", color = RqSteel, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.6f))
                        Text(
                            text = lot.status.name,
                            color = if (lot.status.name == "AVAILABLE") RqMarketGreen else RqAmber,
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Divider(color = RqSurfaceVariant, thickness = 0.5.dp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // RFQ MARKET & QUOTES
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RqGraphite)
                .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Column {
                Text(
                    text = "INSTITUTIONAL RFQ MARKET & SUPPLIER QUOTATIONS",
                    color = RqPaper,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                rfqs.forEach { rfq ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(RqSurfaceVariant)
                            .padding(8.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${rfq.rfqId} │ ${rfq.commodityName} (${rfq.quantityMt.toInt()} MT)",
                                    color = RqAmber,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "STATUS: ${rfq.status.name}",
                                    color = if (rfq.status.name == "AWARDED") RqMarketGreen else RqIce,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(text = "SPEC: ${rfq.specSummary} │ BUYER: ${rfq.buyerName}", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)

                            if (rfq.quotes.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(text = "RECEIVED QUOTES:", color = RqPaper, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)

                                rfq.quotes.forEach { quote ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 2.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = "${quote.supplierName} (${quote.origin})", color = RqPaper, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                        Text(text = "£${quote.pricePerMt.toInt()} / MT", color = RqMarketGreen, fontWeight = FontWeight.Bold, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                                        Text(text = "MATCH: ${quote.qualityMatchPct}%", color = RqIce, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)

                                        if (rfq.status.name != "AWARDED") {
                                            Button(
                                                onClick = { onAwardRfq(rfq.rfqId, quote.quoteId) },
                                                colors = ButtonDefaults.buttonColors(containerColor = RqRhinoBlue, contentColor = RqPaper),
                                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                                shape = RoundedCornerShape(2.dp),
                                                modifier = Modifier.height(24.dp)
                                            ) {
                                                Text(text = "AWARD", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateRfqModal) {
        var commInput by remember { mutableStateOf("UNSALTED BUTTER 82%") }
        var qtyInput by remember { mutableStateOf("50.0") }
        var specInput by remember { mutableStateOf("Fat >= 82%, Moisture <= 16%, UK Origin") }

        AlertDialog(
            onDismissRequest = { showCreateRfqModal = false },
            title = { Text("CREATE INSTITUTIONAL RFQ", color = RqPaper, fontSize = 12.sp, fontFamily = FontFamily.Monospace) },
            text = {
                Column {
                    OutlinedTextField(value = commInput, onValueChange = { commInput = it }, label = { Text("COMMODITY", color = RqSteel, fontSize = 10.sp) })
                    OutlinedTextField(value = qtyInput, onValueChange = { qtyInput = it }, label = { Text("TONNAGE (MT)", color = RqSteel, fontSize = 10.sp) })
                    OutlinedTextField(value = specInput, onValueChange = { specInput = it }, label = { Text("SPECIFICATION SUMMARY", color = RqSteel, fontSize = 10.sp) })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val q = qtyInput.toDoubleOrNull() ?: 50.0
                        onCreateRfq(commInput, q, "01–15 NOV 2026", specInput)
                        showCreateRfqModal = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RqRhinoBlue)
                ) {
                    Text("PUBLISH RFQ", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            },
            dismissButton = {
                Button(onClick = { showCreateRfqModal = false }, colors = ButtonDefaults.buttonColors(containerColor = RqSurfaceVariant)) {
                    Text("CANCEL", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            },
            containerColor = RqGraphite
        )
    }
}
