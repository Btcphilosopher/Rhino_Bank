package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.OrderBookEntry
import com.example.domain.model.OrderSide
import com.example.ui.theme.*

@Composable
fun OrderBookView(
    modifier: Modifier = Modifier,
    orders: List<OrderBookEntry>,
    lastPrice: Double,
    currencySymbol: String = "£",
    onOpenQuickOrder: () -> Unit
) {
    val asks = orders.filter { it.side == OrderSide.ASK }.sortedBy { it.price }.take(6)
    val bids = orders.filter { it.side == OrderSide.BID }.sortedByDescending { it.price }.take(6)

    val bestBid = bids.firstOrNull()?.price ?: (lastPrice - 10.0)
    val bestAsk = asks.firstOrNull()?.price ?: (lastPrice + 10.0)
    val spread = bestAsk - bestBid

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(RqGraphite)
            .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SPOT ORDER BOOK",
                color = RqPaper,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Button(
                onClick = onOpenQuickOrder,
                colors = ButtonDefaults.buttonColors(containerColor = RqRhinoBlue, contentColor = RqPaper),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.height(28.dp)
            ) {
                Text(text = "+ ENTRY", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Table Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(RqSurfaceVariant)
                .padding(horizontal = 4.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "PRICE", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
            Text(text = "QTY (MT)", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
            Text(text = "PARTICIPANT", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Asks (Sells)
        Column {
            asks.reversed().forEach { ask ->
                val fillRatio = ((ask.quantityMt / 100.0)).coerceIn(0.1, 1.0)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 1.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(fillRatio.toFloat())
                            .height(18.dp)
                            .background(RqMarketRed.copy(alpha = 0.2f))
                            .align(Alignment.CenterEnd)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "$currencySymbol${String.format("%.0f", ask.price)}", color = RqMarketRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text(text = "${ask.quantityMt.toInt()} MT", color = RqPaper, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text(text = ask.participant.take(12), color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    }
                }
            }
        }

        // Spread Indicator Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .background(RqSurfaceVariant)
                .padding(vertical = 4.dp, horizontal = 6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LAST: $currencySymbol${String.format("%.0f", lastPrice)}",
                    color = RqPaper,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "SPREAD: $currencySymbol${String.format("%.0f", spread)}",
                    color = RqAmber,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Bids (Buys)
        Column {
            bids.forEach { bid ->
                val fillRatio = ((bid.quantityMt / 100.0)).coerceIn(0.1, 1.0)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 1.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(fillRatio.toFloat())
                            .height(18.dp)
                            .background(RqMarketGreen.copy(alpha = 0.2f))
                            .align(Alignment.CenterStart)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "$currencySymbol${String.format("%.0f", bid.price)}", color = RqMarketGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text(text = "${bid.quantityMt.toInt()} MT", color = RqPaper, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text(text = bid.participant.take(12), color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    }
                }
            }
        }
    }
}
