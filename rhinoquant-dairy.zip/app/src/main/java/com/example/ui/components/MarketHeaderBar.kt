package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Instrument
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalTab

@Composable
fun MarketHeaderBar(
    instruments: List<Instrument>,
    selectedTab: TerminalTab,
    onTabSelected: (TerminalTab) -> Unit,
    isReplayPlaying: Boolean,
    onToggleReplay: () -> Unit,
    replaySpeed: Int,
    onSetReplaySpeed: (Int) -> Unit,
    replayTickCount: Int,
    onOpenLineage: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(RqBlack)
            .border(width = 1.dp, color = RqGraphite)
    ) {
        // TOP BANNER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(RqRhinoBlue)
                        .border(1.dp, RqIce, RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "RQ",
                        color = RqPaper,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "RHINOQUANT DAIRY",
                        color = RqPaper,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        letterSpacing = 1.2.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "INSTITUTIONAL SPOT MARKET & COMMODITY ENGINE",
                        color = RqSteel,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 0.8.sp
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Replay Controls
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(RqGraphite)
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onToggleReplay,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = if (isReplayPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Replay",
                            tint = RqIce,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = "#$replayTickCount",
                        color = RqTextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                    listOf(1, 5, 20, 100).forEach { speed ->
                        Text(
                            text = "${speed}X",
                            color = if (replaySpeed == speed) RqPaper else RqSteel,
                            fontSize = 9.sp,
                            fontWeight = if (replaySpeed == speed) FontWeight.Bold else FontWeight.Normal,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (replaySpeed == speed) RqRhinoBlue else Color.Transparent)
                                .clickable { onSetReplaySpeed(speed) }
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))
                DataProvenanceBadge(onClick = onOpenLineage)
            }
        }

        Divider(color = RqGraphite, thickness = 1.dp)

        // TICKER SCROLL ROW
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .background(RqGraphite)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            instruments.forEach { inst ->
                Row(
                    modifier = Modifier
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = inst.symbol.replace("RQ-", ""),
                        color = RqSteel,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${if (inst.currency == "GBP") "£" else "€"}${String.format("%.0f", inst.lastPrice)}",
                        color = RqPaper,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "${if (inst.changePercent >= 0) "+" else ""}${String.format("%.1f", inst.changePercent)}%",
                        color = if (inst.changePercent >= 0) RqMarketGreen else RqMarketRed,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(text = "│", color = RqSurfaceVariant, fontSize = 10.sp)
            }
        }

        Divider(color = RqGraphite, thickness = 1.dp)

        // NAVIGATION TABS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .background(RqBlack)
                .padding(horizontal = 4.dp)
        ) {
            TerminalTab.values().forEach { tab ->
                val isSelected = selectedTab == tab
                val title = when (tab) {
                    TerminalTab.MARKET_TERMINAL -> "SPOT MARKET"
                    TerminalTab.DAIRY_COMPLEX -> "DAIRY COMPLEX"
                    TerminalTab.CURVES_AND_BASIS -> "CURVES & BASIS"
                    TerminalTab.PHYSICAL_LOTS_RFQ -> "LOTS & RFQ"
                    TerminalTab.RISK_AND_POSITIONS -> "RISK & POSITIONS"
                    TerminalTab.REPLAY_SIMULATOR -> "REPLAY"
                    TerminalTab.DEVELOPER_API_LAB -> "API LAB"
                }

                Box(
                    modifier = Modifier
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 10.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = title,
                            color = if (isSelected) RqPaper else RqSteel,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .height(2.dp)
                                .width(if (isSelected) 24.dp else 0.dp)
                                .background(if (isSelected) RqAmber else Color.Transparent)
                        )
                    }
                }
            }
        }
    }
}
