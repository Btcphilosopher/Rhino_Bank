package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun ReplaySimulatorScreen(
    isReplayPlaying: Boolean,
    onToggleReplay: () -> Unit,
    replaySpeed: Int,
    onSetReplaySpeed: (Int) -> Unit,
    replayTickCount: Int
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBlack)
            .padding(10.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "MARKET REPLAY & DETERMINISTIC SIMULATOR CONTROLLER",
            color = RqPaper,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
        Text(
            text = "SYNTHETIC MARKET GENERATION │ EVENT STREAM RECORDING │ HISTORICAL SESSION REPLAY",
            color = RqSteel,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(12.dp))

        // REPLAY CONTROLLER BOX
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RqGraphite)
                .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column {
                Text(
                    text = "DETERMINISTIC SESSION REPLAY CONTROLS",
                    color = RqAmber,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onToggleReplay,
                        colors = ButtonDefaults.buttonColors(containerColor = if (isReplayPlaying) RqAmber else RqMarketGreen),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.height(40.dp)
                    ) {
                        Text(
                            text = if (isReplayPlaying) "PAUSE SESSION REPLAY" else "START SESSION REPLAY",
                            color = RqBlack,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "REPLAY SPEED: ", color = RqSteel, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        listOf(1, 5, 20, 100).forEach { speed ->
                            Button(
                                onClick = { onSetReplaySpeed(speed) },
                                colors = ButtonDefaults.buttonColors(containerColor = if (replaySpeed == speed) RqRhinoBlue else RqSurfaceVariant),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.height(32.dp).padding(horizontal = 2.dp)
                            ) {
                                Text(text = "${speed}X", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(4.dp)).background(RqSurfaceVariant).padding(8.dp)) {
                        Column {
                            Text(text = "CURRENT TICK COUNTER", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "#$replayTickCount TIK", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(4.dp)).background(RqSurfaceVariant).padding(8.dp)) {
                        Column {
                            Text(text = "MATCHING ENGINE LATENCY", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "0.82 ms (LOCAL JVM)", color = RqMarketGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(4.dp)).background(RqSurfaceVariant).padding(8.dp)) {
                        Column {
                            Text(text = "DETERMINISTIC SEED", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "0x981A4B0F22", color = RqIce, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // EXPORT EVENT RECORDER
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RqGraphite)
                .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column {
                Text(
                    text = "MARKET EVENT RECORDER & EXPORT ENGINE",
                    color = RqPaper,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Export immutable event stream of order submissions, trade executions, and benchmark calculations",
                    color = RqSteel,
                    fontSize = 9.5.sp,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = RqSurfaceVariant)) {
                        Text("EXPORT CSV (50k TRADES)", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = RqSurfaceVariant)) {
                        Text("EXPORT JSON EVENT TAPE", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = RqSurfaceVariant)) {
                        Text("EXPORT PARQUET DATASET", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}
