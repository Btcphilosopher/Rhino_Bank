package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ForwardCurvePoint
import com.example.domain.model.Instrument
import com.example.domain.model.OrderBookEntry
import com.example.domain.model.TradeRecord
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun MarketTerminalScreen(
    instruments: List<Instrument>,
    selectedInstrument: Instrument?,
    onSelectInstrument: (String) -> Unit,
    orders: List<OrderBookEntry>,
    trades: List<TradeRecord>,
    forwardCurves: List<ForwardCurvePoint>,
    onOpenQuickOrder: () -> Unit
) {
    if (selectedInstrument == null) return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBlack)
            .padding(6.dp)
    ) {
        // TOP INSTRUMENT STATS BAR
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RqGraphite)
                .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = selectedInstrument.name,
                            color = RqPaper,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = selectedInstrument.symbol,
                            color = RqAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = "MARKET: ${selectedInstrument.market} │ BASIS: ${selectedInstrument.deliveryBasis} │ CURRENCY: ${selectedInstrument.currency}",
                        color = RqSteel,
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${if (selectedInstrument.currency == "GBP") "£" else "€"}${String.format("%.0f", selectedInstrument.lastPrice)}",
                            color = RqPaper,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "VWAP: ${if (selectedInstrument.currency == "GBP") "£" else "€"}${String.format("%.0f", selectedInstrument.vwap)} │ VOL: ${selectedInstrument.volumeMt.toInt()} MT",
                            color = RqIce,
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = onOpenQuickOrder,
                        colors = ButtonDefaults.buttonColors(containerColor = RqMarketGreen, contentColor = RqPaper),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.height(38.dp)
                    ) {
                        Text(text = "SPOT TRADE", fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // MAIN CONTENT GRID
        Row(modifier = Modifier.fillMaxWidth().weight(1f)) {
            // LEFT COLUMN: INSTRUMENT SELECTOR (25% Width)
            Column(
                modifier = Modifier
                    .weight(0.9f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(6.dp))
                    .background(RqGraphite)
                    .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                    .padding(6.dp)
            ) {
                Text(
                    text = "INSTRUMENT MASTER",
                    color = RqPaper,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(4.dp)
                )

                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(instruments) { inst ->
                        val isSelected = inst.instrumentId == selectedInstrument.instrumentId
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) RqRhinoBlue else RqSurfaceVariant)
                                .clickable { onSelectInstrument(inst.instrumentId) }
                                .padding(horizontal = 6.dp, vertical = 6.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = inst.symbol.replace("RQ-", ""),
                                        color = if (isSelected) RqPaper else RqTextPrimary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "${if (inst.currency == "GBP") "£" else "€"}${String.format("%.0f", inst.lastPrice)}",
                                        color = if (isSelected) RqIce else RqAmber,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Text(
                                    text = inst.name,
                                    color = if (isSelected) RqPaper.copy(alpha = 0.8f) else RqSteel,
                                    fontSize = 8.5.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            // CENTER COLUMN: CHARTS & DOM (38% Width)
            Column(
                modifier = Modifier
                    .weight(1.3f)
                    .fillMaxHeight()
            ) {
                DepthChartCanvas(
                    orders = orders,
                    lastPrice = selectedInstrument.lastPrice,
                    modifier = Modifier.fillMaxWidth().height(140.dp)
                )
                Spacer(modifier = Modifier.height(6.dp))
                PriceCurveCanvas(
                    curvePoints = forwardCurves,
                    currencySymbol = if (selectedInstrument.currency == "GBP") "£" else "€",
                    modifier = Modifier.fillMaxWidth().weight(1f)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // RIGHT COLUMN: ORDER BOOK & TRADE TAPE (37% Width)
            Column(
                modifier = Modifier
                    .weight(1.3f)
                    .fillMaxHeight()
            ) {
                OrderBookView(
                    orders = orders,
                    lastPrice = selectedInstrument.lastPrice,
                    currencySymbol = if (selectedInstrument.currency == "GBP") "£" else "€",
                    onOpenQuickOrder = onOpenQuickOrder,
                    modifier = Modifier.fillMaxWidth().weight(1f)
                )
                Spacer(modifier = Modifier.height(6.dp))
                TradeTapeView(
                    trades = trades,
                    currencySymbol = if (selectedInstrument.currency == "GBP") "£" else "€",
                    modifier = Modifier.fillMaxWidth().weight(1f)
                )
            }
        }
    }
}
