package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.RhinoQuantDatabase
import com.example.data.repository.MarketRepository
import com.example.domain.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class TerminalTab {
    MARKET_TERMINAL,
    DAIRY_COMPLEX,
    CURVES_AND_BASIS,
    PHYSICAL_LOTS_RFQ,
    RISK_AND_POSITIONS,
    REPLAY_SIMULATOR,
    DEVELOPER_API_LAB
}

data class LineageInfo(
    val benchmarkId: String,
    val name: String,
    val source: String = "RHINOQUANT DEMO SPOT MARKET",
    val status: String = "SYNTHETIC",
    val pipelineSteps: List<String> = listOf(
        "1. PHYSICAL LOT & ORDER TAPE INGESTION (100% EXECUTED TRADES)",
        "2. OUTLIER FILTERING (TRIMMED MEAN 5% TAILS)",
        "3. VOLUME WEIGHTING BY MATCHED TONNAGE",
        "4. BENCHMARK CALCULATION & TIMESTAMP CERTIFICATION",
        "5. PUBLISHED BENCHMARK INDEX RECORD"
    )
)

class RhinoQuantViewModel(application: Application) : AndroidViewModel(application) {

    private val db = RhinoQuantDatabase.getDatabase(application)
    val repository = MarketRepository(db.marketDao(), viewModelScope)

    private val _selectedTab = MutableStateFlow(TerminalTab.MARKET_TERMINAL)
    val selectedTab: StateFlow<TerminalTab> = _selectedTab.asStateFlow()

    private val _showQuickOrderModal = MutableStateFlow(false)
    val showQuickOrderModal: StateFlow<Boolean> = _showQuickOrderModal.asStateFlow()

    private val _activeLineage = MutableStateFlow<LineageInfo?>(null)
    val activeLineage: StateFlow<LineageInfo?> = _activeLineage.asStateFlow()

    val instruments = repository.instruments
    val selectedInstrumentId = repository.selectedInstrumentId

    val selectedInstrument: StateFlow<Instrument?> = combine(
        instruments,
        selectedInstrumentId
    ) { list, id ->
        list.find { it.instrumentId == id } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val openOrdersForSelected: StateFlow<List<OrderBookEntry>> = combine(
        repository.ordersFlow,
        selectedInstrumentId
    ) { orders, id ->
        orders.filter { it.instrumentId == id && (it.status == OrderStatus.OPEN || it.status == OrderStatus.PARTIALLY_FILLED) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tradesForSelected: StateFlow<List<TradeRecord>> = combine(
        repository.tradesFlow,
        selectedInstrumentId
    ) { trades, id ->
        trades.filter { it.instrumentId == id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTrades = repository.tradesFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val benchmarks = repository.benchmarks
    val forwardCurves = repository.forwardCurves
    val butterCrush = repository.butterCrush
    val cheeseNetback = repository.cheeseNetback
    val lots = repository.lotsFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val rfqs = repository.rfqsFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val positions = repository.positionsFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val isReplayPlaying = repository.isReplayPlaying
    val replaySpeed = repository.replaySpeed
    val replayTickCount = repository.replayTickCount
    val activeScenario = repository.activeScenario
    val apiKey = repository.apiKey

    fun selectTab(tab: TerminalTab) {
        _selectedTab.value = tab
    }

    fun selectInstrument(id: String) {
        repository.selectInstrument(id)
    }

    fun toggleQuickOrderModal(show: Boolean) {
        _showQuickOrderModal.value = show
    }

    fun showDataLineage(benchmark: BenchmarkData) {
        _activeLineage.value = LineageInfo(
            benchmarkId = benchmark.benchmarkId,
            name = benchmark.name,
            source = benchmark.source,
            status = benchmark.dataStatus
        )
    }

    fun dismissDataLineage() {
        _activeLineage.value = null
    }

    fun submitOrder(side: OrderSide, price: Double, quantityMt: Double, deliveryWindow: String) {
        viewModelScope.launch {
            val instId = selectedInstrumentId.value
            repository.submitOrder(instId, side, price, quantityMt, deliveryWindow)
            _showQuickOrderModal.value = false
        }
    }

    fun updateButterCrushCreamPrice(price: Double) {
        repository.updateButterCrushCreamPrice(price)
    }

    fun updateCheeseNetbackPrice(price: Double) {
        repository.updateCheeseNetbackPrice(price)
    }

    fun awardRfq(rfqId: String, quoteId: String) {
        viewModelScope.launch {
            repository.awardRfq(rfqId, quoteId)
        }
    }

    fun createRfq(commodityName: String, quantityMt: Double, deliveryWindow: String, specSummary: String) {
        viewModelScope.launch {
            repository.createRfq(commodityName, quantityMt, deliveryWindow, specSummary)
        }
    }

    fun applyScenario(scenario: ScenarioImpact?) {
        repository.applyScenario(scenario)
    }

    fun setReplayPlaying(playing: Boolean) {
        repository.setReplayPlaying(playing)
    }

    fun setReplaySpeed(speed: Int) {
        repository.setReplaySpeed(speed)
    }
}
