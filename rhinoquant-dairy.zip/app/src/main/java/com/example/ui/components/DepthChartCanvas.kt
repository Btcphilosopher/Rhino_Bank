package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.OrderBookEntry
import com.example.domain.model.OrderSide
import com.example.ui.theme.*

@Composable
fun DepthChartCanvas(
    modifier: Modifier = Modifier,
    orders: List<OrderBookEntry>,
    lastPrice: Double
) {
    val bids = orders.filter { it.side == OrderSide.BID }.sortedByDescending { it.price }
    val asks = orders.filter { it.side == OrderSide.ASK }.sortedBy { it.price }

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(RqGraphite)
            .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
            .padding(8.dp)
    ) {
        Text(
            text = "DEPTH OF MARKET (DOM)",
            color = RqPaper,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(4.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
        ) {
            val width = size.width
            val height = size.height
            val midX = width / 2f

            // Mid Line
            drawLine(
                color = RqSteel.copy(alpha = 0.5f),
                start = Offset(midX, 0f),
                end = Offset(midX, height),
                strokeWidth = 1f
            )

            // Cumulative Bids Path (Green)
            val bidPath = Path()
            bidPath.moveTo(midX, height)

            var cumBid = 0.0
            val maxCum = 300.0

            bids.forEachIndexed { idx, order ->
                cumBid += order.quantityMt
                val x = midX - ((idx + 1) * (midX / 6f))
                val y = height - ((cumBid / maxCum) * height).toFloat().coerceIn(0f, height)
                bidPath.lineTo(x, y)
            }
            bidPath.lineTo(0f, height)
            bidPath.close()

            drawPath(path = bidPath, color = RqMarketGreen.copy(alpha = 0.3f))
            drawPath(path = bidPath, color = RqMarketGreen, style = Stroke(width = 2f))

            // Cumulative Asks Path (Red)
            val askPath = Path()
            askPath.moveTo(midX, height)

            var cumAsk = 0.0
            asks.forEachIndexed { idx, order ->
                cumAsk += order.quantityMt
                val x = midX + ((idx + 1) * (midX / 6f))
                val y = height - ((cumAsk / maxCum) * height).toFloat().coerceIn(0f, height)
                askPath.lineTo(x, y)
            }
            askPath.lineTo(width, height)
            askPath.close()

            drawPath(path = askPath, color = RqMarketRed.copy(alpha = 0.3f))
            drawPath(path = askPath, color = RqMarketRed, style = Stroke(width = 2f))
        }
    }
}
