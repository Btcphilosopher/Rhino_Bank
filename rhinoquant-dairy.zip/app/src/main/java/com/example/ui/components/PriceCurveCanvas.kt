package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ForwardCurvePoint
import com.example.ui.theme.*

@Composable
fun PriceCurveCanvas(
    modifier: Modifier = Modifier,
    curvePoints: List<ForwardCurvePoint>,
    currencySymbol: String = "£"
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(RqGraphite)
            .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "DAIRY FORWARD CURVE",
                color = RqPaper,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            val spot = curvePoints.find { it.period == "SPOT" }?.price ?: 3470.0
            val m12 = curvePoints.lastOrNull()?.price ?: 3430.0
            val isContango = m12 >= spot
            Text(
                text = if (isContango) "STRUCTURE: CONTANGO" else "STRUCTURE: BACKWARDATION",
                color = if (isContango) RqMarketGreen else RqAmber,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
        ) {
            if (curvePoints.isEmpty()) return@Canvas

            val width = size.width
            val height = size.height

            val minPrice = curvePoints.minOf { it.price } * 0.98
            val maxPrice = curvePoints.maxOf { it.price } * 1.02
            val priceRange = (maxPrice - minPrice).coerceAtLeast(1.0)

            val points = curvePoints.mapIndexed { idx, pt ->
                val x = (idx.toFloat() / (curvePoints.size - 1).coerceAtLeast(1)) * width
                val y = height - (((pt.price - minPrice) / priceRange) * height).toFloat()
                Offset(x, y)
            }

            // Gridlines
            drawLine(color = RqSurfaceVariant, start = Offset(0f, height * 0.25f), end = Offset(width, height * 0.25f))
            drawLine(color = RqSurfaceVariant, start = Offset(0f, height * 0.75f), end = Offset(width, height * 0.75f))

            // Curve Line
            val curvePath = Path()
            points.forEachIndexed { i, pt ->
                if (i == 0) curvePath.moveTo(pt.x, pt.y) else curvePath.lineTo(pt.x, pt.y)
            }

            drawPath(path = curvePath, color = RqRhinoBlue, style = Stroke(width = 3f))

            // Draw Point Circles
            points.forEach { pt ->
                drawCircle(color = RqAmber, radius = 4f, center = pt)
                drawCircle(color = RqPaper, radius = 2f, center = pt)
            }
        }
    }
}
