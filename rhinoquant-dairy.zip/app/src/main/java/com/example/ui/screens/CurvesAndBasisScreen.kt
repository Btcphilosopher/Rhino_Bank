package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ForwardCurvePoint
import com.example.domain.model.Instrument
import com.example.ui.components.PriceCurveCanvas
import com.example.ui.theme.*

@Composable
fun CurvesAndBasisScreen(
    forwardCurves: List<ForwardCurvePoint>,
    instruments: List<Instrument>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBlack)
            .padding(10.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "DAIRY FORWARD CURVES, BASIS & CROSS-COMMODITY MATRIX",
            color = RqPaper,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
        Text(
            text = "TERM STRUCTURE analytics │ REGIONAL SPREADS │ CROSS-COMMODITY MATRIX",
            color = RqSteel,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(12.dp))

        // FORWARD CURVE CHART & TABLE
        Row(modifier = Modifier.fillMaxWidth()) {
            PriceCurveCanvas(
                curvePoints = forwardCurves,
                modifier = Modifier
                    .weight(1.2f)
                    .height(200.dp)
            )

            Spacer(modifier = Modifier.width(10.dp))

            // FORWARD CURVE TABLE (48%)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(RqGraphite)
                    .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                Column {
                    Text(
                        text = "TERM STRUCTURE DETAILS",
                        color = RqPaper,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RqSurfaceVariant)
                            .padding(horizontal = 4.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "PERIOD", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text(text = "PRICE", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text(text = "BASIS", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text(text = "STRUCTURE", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    forwardCurves.forEach { pt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp, vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = pt.period, color = RqPaper, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            Text(text = "£${pt.price.toInt()}", color = RqIce, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            Text(text = "${if (pt.basisVsSpot >= 0) "+" else ""}£${pt.basisVsSpot.toInt()}", color = RqAmber, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            Text(
                                text = pt.marketStructure,
                                color = if (pt.marketStructure == "CONTANGO") RqMarketGreen else if (pt.marketStructure == "BACKWARDATION") RqMarketRed else RqSteel,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1.2f)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // REGIONAL BASIS MATRIX
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RqGraphite)
                .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column {
                Text(
                    text = "REGIONAL & INTER-COMMODITY BASIS MATRIX (UK VS EU / CREAM VS BUTTER)",
                    color = RqAmber,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(RqSurfaceVariant)
                            .padding(8.dp)
                    ) {
                        Column {
                            Text(text = "UK BUTTER vs EU BUTTER BASIS", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "-€460 / MT (UK DISCOUNT)", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(RqSurfaceVariant)
                            .padding(8.dp)
                    ) {
                        Column {
                            Text(text = "UK CREAM vs BUTTER RATIO", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "0.472x (NORMAL RANGE 0.45x-0.50x)", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(RqSurfaceVariant)
                            .padding(8.dp)
                    ) {
                        Column {
                            Text(text = "30D BUTTER ↔ CREAM CORRELATION", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "+0.82 (HIGH CO-INTEGRATION)", color = RqMarketGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // CROSS-COMMODITY MATRIX
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RqGraphite)
                .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column {
                Text(
                    text = "CROSS-COMMODITY PERFORMANCE MATRIX",
                    color = RqPaper,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RqSurfaceVariant)
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "COMMODITY", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
                    Text(text = "SPOT PRICE", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text(text = "1D %", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                    Text(text = "1W %", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                    Text(text = "1M %", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                    Text(text = "YTD %", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                }

                instruments.forEach { inst ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = inst.name, color = RqPaper, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
                        Text(text = "${if (inst.currency == "GBP") "£" else "€"}${String.format("%.0f", inst.lastPrice)}", color = RqIce, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text(text = "${if (inst.changePercent >= 0) "+" else ""}${String.format("%.1f", inst.changePercent)}%", color = if (inst.changePercent >= 0) RqMarketGreen else RqMarketRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                        Text(text = "+1.8%", color = RqMarketGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                        Text(text = "+4.2%", color = RqMarketGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                        Text(text = "+12.5%", color = RqAmber, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                    }
                    Divider(color = RqSurfaceVariant, thickness = 0.5.dp)
                }
            }
        }
    }
}
