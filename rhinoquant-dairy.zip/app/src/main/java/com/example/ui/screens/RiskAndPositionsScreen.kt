package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.simulation.MarketDataSeeds
import com.example.domain.model.PositionItem
import com.example.domain.model.ScenarioImpact
import com.example.ui.theme.*

@Composable
fun RiskAndPositionsScreen(
    positions: List<PositionItem>,
    activeScenario: ScenarioImpact?,
    onApplyScenario: (ScenarioImpact?) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBlack)
            .padding(10.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "POSITION LEDGER, RISK ANALYTICS & OPTIONS ENGINE",
            color = RqPaper,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
        Text(
            text = "PHYSICAL vs FINANCIAL EXPOSURE │ MARK-TO-MARKET │ VaR 95% │ BLACK-76 OPTIONS │ STRESS TESTING",
            color = RqSteel,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(12.dp))

        // POSITIONS LEDGER TABLE
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RqGraphite)
                .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Column {
                Text(
                    text = "INSTITUTIONAL POSITION LEDGER & MARK-TO-MARKET P&L",
                    color = RqPaper,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RqSurfaceVariant)
                        .padding(horizontal = 4.dp, vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "COMMODITY", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                    Text(text = "PHYS (MT)", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                    Text(text = "NET EXP", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                    Text(text = "AVG / MARK", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                    Text(text = "UNREAL P&L", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text(text = "VaR (95%)", color = RqSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                }

                Spacer(modifier = Modifier.height(4.dp))

                var totalPnl = 0.0
                var totalVar = 0.0

                positions.forEach { pos ->
                    totalPnl += pos.unrealizedPnl
                    totalVar += pos.var95

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = pos.productName, color = RqPaper, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                        Text(text = "${pos.physicalInventoryMt.toInt()} MT", color = RqIce, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                        Text(text = "${pos.netExposureMt.toInt()} MT", color = RqAmber, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                        Text(text = "£${pos.averagePrice.toInt()} / £${pos.markPrice.toInt()}", color = RqSteel, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                        Text(
                            text = "${if (pos.unrealizedPnl >= 0) "+" else ""}£${pos.unrealizedPnl.toInt()}",
                            color = if (pos.unrealizedPnl >= 0) RqMarketGreen else RqMarketRed,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1f)
                        )
                        Text(text = "£${pos.var95.toInt()}", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                    }
                    Divider(color = RqSurfaceVariant, thickness = 0.5.dp)
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth().background(RqSurfaceVariant).padding(6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "TOTAL PORTFOLIO MTM P&L:", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = "+£${totalPnl.toInt()} (VaR 95%: £${totalVar.toInt()})",
                        color = RqMarketGreen,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // BLACK-76 OPTIONS DEMONSTRATION ENGINE
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RqGraphite)
                .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Column {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        text = "BLACK-76 OPTIONS PRICING DEMONSTRATION ENGINE",
                        color = RqAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(text = "MODELLED VALUE - NOT MARKET QUOTE", color = RqSteel, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(4.dp)).background(RqSurfaceVariant).padding(8.dp)) {
                        Column {
                            Text(text = "BUTTER CALL £3,500 (DEC 26)", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "PREMIUM: £142 / MT", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "DELTA: 0.54 │ VEGA: 8.2 │ THETA: -1.2", color = RqIce, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(4.dp)).background(RqSurfaceVariant).padding(8.dp)) {
                        Column {
                            Text(text = "SMP PUT £2,450 (NOV 26)", color = RqSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "PREMIUM: £88 / MT", color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "DELTA: -0.41 │ VEGA: 6.1 │ THETA: -0.9", color = RqIce, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // MARKET SCENARIO STRESS TESTER
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RqGraphite)
                .border(1.dp, RqSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Column {
                Text(
                    text = "MARKET SCENARIO STRESS TESTING ENGINE",
                    color = RqPaper,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                MarketDataSeeds.SCENARIOS.forEach { scenario ->
                    val isActive = activeScenario?.scenarioId == scenario.scenarioId

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isActive) RqRhinoBlue else RqSurfaceVariant)
                            .clickable { onApplyScenario(if (isActive) null else scenario) }
                            .padding(8.dp)
                    ) {
                        Column {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = scenario.title, color = RqPaper, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                Text(
                                    text = if (isActive) "SCENARIO APPLIED" else "CLICK TO STRESS TEST",
                                    color = if (isActive) RqAmber else RqSteel,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(text = scenario.description, color = RqTextSecondary, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "SIMULATED PRICE IMPACT: BUTTER ${if (scenario.butterPricePct >= 0) "+" else ""}${scenario.butterPricePct}% │ SMP ${if (scenario.smpPricePct >= 0) "+" else ""}${scenario.smpPricePct}% │ CREAM ${if (scenario.creamPricePct >= 0) "+" else ""}${scenario.creamPricePct}%",
                                color = if (scenario.butterPricePct >= 0) RqMarketGreen else RqMarketRed,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
