/**
 * RhinoStocks - Institutional Equity Analytics Engine Types
 * RhinoBank Proprietary Equity Market Intelligence System
 */

export type Region = 'Americas' | 'EMEA' | 'APAC' | 'Emerging';

export type Sector =
  | 'Technology'
  | 'Financials'
  | 'Healthcare'
  | 'Energy'
  | 'Industrials'
  | 'Consumer Discretionary'
  | 'Consumer Staples'
  | 'Materials'
  | 'Utilities'
  | 'Real Estate'
  | 'Communication Services';

export type MarketCapBucket = 'Mega Cap' | 'Large Cap' | 'Mid Cap' | 'Small Cap' | 'Micro Cap';

export type TrendClassification =
  | 'STRONG UPTREND'
  | 'UPTREND'
  | 'NEUTRAL'
  | 'DOWNTREND'
  | 'STRONG DOWNTREND';

export type MarketRegimeType =
  | 'BULL'
  | 'BEAR'
  | 'SIDEWAYS'
  | 'HIGH VOLATILITY'
  | 'LOW VOLATILITY'
  | 'RISK-ON'
  | 'RISK-OFF'
  | 'RECOVERY'
  | 'LATE-CYCLE'
  | 'CRISIS';

export type SectorRotationState = 'LEADING' | 'IMPROVING' | 'WEAKENING' | 'LAGGING';

export interface PriceBar {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  adjustedClose: number;
  volume: number;
  returnPct: number;
  sma20?: number;
  sma50?: number;
  sma200?: number;
  ema20?: number;
  rsi?: number;
  macd?: number;
  macdSignal?: number;
  macdHist?: number;
  bbUpper?: number;
  bbLower?: number;
  bbMiddle?: number;
  atr?: number;
}

export interface IncomeStatement {
  year: number;
  revenue: number;
  grossProfit: number;
  operatingIncome: number;
  ebitda: number;
  ebit: number;
  netIncome: number;
  eps: number;
  revenueGrowth: number;
  epsGrowth: number;
}

export interface BalanceSheet {
  year: number;
  assets: number;
  liabilities: number;
  equity: number;
  cash: number;
  debt: number;
  workingCapital: number;
  debtToEquity: number;
  currentRatio: number;
}

export interface CashFlowStatement {
  year: number;
  operatingCashFlow: number;
  capex: number;
  freeCashFlow: number;
  financingCashFlow: number;
  dividendsPaid: number;
  shareRepurchases: number;
  fcfGrowth: number;
}

export interface EarningsQuarter {
  quarter: string;
  date: string;
  actualEps: number;
  estimatedEps: number;
  surprisePct: number;
  actualRevenue: number;
  estimatedRevenue: number;
  revisionChangePct: number;
}

export interface FactorExposures {
  value: number;       // Z-score [-3, 3]
  growth: number;
  momentum: number;
  quality: number;
  size: number;
  lowVolatility: number;
  profitability: number;
  dividend: number;
  leverage: number;
}

export interface RhinoStock {
  ticker: string;
  isin: string;
  company: string;
  exchange: string;
  country: string;
  region: Region;
  currency: string;
  sector: Sector;
  industry: string;
  marketCap: number; // in USD Billions
  marketCapBucket: MarketCapBucket;
  sharesOutstanding: number; // in Millions
  freeFloatPct: number;
  
  // Pricing
  price: number;
  adjustedPrice: number;
  change1D: number;
  changePct1D: number;
  volume: number;
  avgVolume30D: number;
  high52W: number;
  low52W: number;
  
  // Return Horizons
  returns: {
    '1D': number;
    '5D': number;
    '1M': number;
    '3M': number;
    '6M': number;
    'YTD': number;
    '1Y': number;
    '3Y': number;
    '5Y': number;
    '10Y': number;
  };

  // Price Series
  history: PriceBar[];

  // Fundamentals & Multiples
  fundamentals: {
    revenue: number;
    revenueGrowth: number;
    grossProfit: number;
    ebitda: number;
    ebit: number;
    netIncome: number;
    eps: number;
    epsGrowth: number;
    assets: number;
    debt: number;
    cash: number;
    equity: number;
    operatingCashFlow: number;
    capex: number;
    fcf: number;
    fcfYield: number;
    fcfGrowth: number;
    
    // Margins
    grossMargin: number;
    operatingMargin: number;
    netMargin: number;
    
    // Profitability
    roe: number;
    roa: number;
    roic: number;
    debtToEquity: number;
    currentRatio: number;
  };

  // Financial History
  incomeHistory: IncomeStatement[];
  balanceHistory: BalanceSheet[];
  cashFlowHistory: CashFlowStatement[];
  earningsHistory: EarningsQuarter[];

  // Valuation
  valuation: {
    pe: number;
    forwardPe: number;
    peg: number;
    pb: number;
    ps: number;
    evToSales: number;
    evToEbitda: number;
    evToEbit: number;
    evToFcf: number;
    dividendYield: number;
    payoutRatio: number;
    pe5YAvg: number;
    pe10YAvg: number;
    pePercentile: number;
    peZScore: number;
    pb5YAvg: number;
    pbPercentile: number;
    evEbitda5YAvg: number;
    evEbitdaPercentile: number;
  };

  // Dividends & Buybacks
  dividends: {
    yield: number;
    growth5Y: number;
    payoutRatio: number;
    consistencyYears: number;
    fcfCoverage: number;
    qualityScore: number; // 0-100
    buybackYield: number;
    netShareIssuanceRate: number;
    dilutionRate: number;
  };

  // Momentum & Trend
  momentum: {
    m1: number;
    m3: number;
    m6: number;
    m12: number;
    riskAdjustedM12: number;
    relativeToSector1Y: number;
    relativeToMarket1Y: number;
    trend: TrendClassification;
    trendSlope: number;
    maAlignmentScore: number; // 0-100
    distanceFrom50DMA: number;
    distanceFrom200DMA: number;
    breakoutStrength: number;
    persistenceScore: number;
  };

  // Technical Indicators
  technicals: {
    sma20: number;
    sma50: number;
    sma200: number;
    ema20: number;
    rsi14: number;
    macd: number;
    macdSignal: number;
    macdHist: number;
    stochasticK: number;
    stochasticD: number;
    adx14: number;
    atr14: number;
    bollingerUpper: number;
    bollingerLower: number;
    supportLevel: number;
    resistanceLevel: number;
  };

  // Risk & Volatility
  risk: {
    realizedVol30D: number;
    realizedVol90D: number;
    realizedVol1Y: number;
    downsideVol: number;
    upsideVol: number;
    volPercentile: number;
    ewmaVol: number;
    maxDrawdown: number;
    currentDrawdown: number;
    recoveryTimeDays: number;
    betaMarket: number;
    betaSector: number;
    alpha1Y: number;
    rSquared: number;
    trackingError: number;
    sharpeRatio: number;
    sortinoRatio: number;
    informationRatio: number;
    skewness: number;
    kurtosis: number;
    var95: number;
    cvar95: number;
  };

  // Factor Model Exposures
  factors: FactorExposures;

  // Earnings Revisions
  revisions: {
    epsEstimate: number;
    revenueEstimate: number;
    estimateChange30D: number;
    analystCount: number;
    upgradesCount: number;
    downgradesCount: number;
    revisionMomentumScore: number; // -100 to 100
  };

  // Anomaly Engine
  anomaly: {
    score: number; // 0-100
    isAnomaly: boolean;
    flags: string[];
    zScore: number;
    priceAnomalyZ?: number;
    volumeAnomalyZ?: number;
    volatilityAnomalyZ?: number;
    valuationDislocationZ?: number;
  };

  // Composite Rhino Equity Score
  equityScore: {
    composite: number; // 0-100
    valueSubscore: number;
    momentumSubscore: number;
    qualitySubscore: number;
    growthSubscore: number;
    volatilitySubscore: number;
  };

  updatedAt: string;
}

export interface GlobalIndex {
  symbol: string;
  name: string;
  region: Region;
  country: string;
  value: number;
  change1D: number;
  changePct1D: number;
  returnYTD: number;
  return1Y: number;
  volatility1Y: number;
  peRatio: number;
  divYield: number;
  constituentsCount: number;
  history: { date: string; close: number; returnPct: number }[];
  sectorWeights: { sector: Sector; weight: number; contribution1Y: number }[];
  topConstituents: { ticker: string; company: string; weight: number; return1Y: number }[];
}

export interface MarketBreadth {
  advancers: number;
  decliners: number;
  unchanged: number;
  adRatio: number;
  adLine: { date: string; value: number }[];
  new52WHighs: number;
  new52WLows: number;
  pctAbove50DMA: number;
  pctAbove200DMA: number;
  bullishPercentage: number;
  volumeBreadthRatio: number;
}

export interface MarketRegimeState {
  currentRegime: MarketRegimeType;
  probability: number;
  historicalFrequency: number;
  durationDays: number;
  volatilityCondition: 'LOW' | 'MEDIUM' | 'HIGH' | 'EXTREME';
  breadthCondition: 'STRONG' | 'NEUTRAL' | 'WEAK' | 'DIVERGENT';
  macroCondition: 'EXPANSION' | 'SLOWDOWN' | 'CONTRACTION' | 'RECOVERY';
  transitionMatrix: { [key in MarketRegimeType]?: number };
}

export interface SectorMetric {
  sector: Sector;
  return1D: number;
  return1M: number;
  return3M: number;
  return1Y: number;
  returnYTD: number;
  volatility1Y: number;
  momentumScore: number;
  peRatio: number;
  pbRatio: number;
  evToEbitda: number;
  dividendYield: number;
  earningsGrowth: number;
  breadthPctAbove50DMA: number;
  marketCapTotal: number;
  rotationState: SectorRotationState;
  rotationCoordinates: { x: number; y: number }; // RS-Ratio (x), RS-Momentum (y)
  constituentCount: number;
}

export interface CountryMetric {
  country: string;
  region: Region;
  code: string;
  marketCapTotal: number;
  return1Y: number;
  returnYTD: number;
  volatility1Y: number;
  peRatio: number;
  dividendYield: number;
  earningsGrowth: number;
  stockCount: number;
  topStockTicker: string;
}

export interface MarketConcentration {
  top5WeightPct: number;
  top10WeightPct: number;
  top20WeightPct: number;
  top5ReturnContributionPct: number;
  top10ReturnContributionPct: number;
  herfindahlIndex: number; // HHI
  equalWeight1YReturn: number;
  capWeight1YReturn: number;
  weightReturnSpread: number;
}

export interface AnomalyItem {
  ticker: string;
  company: string;
  sector: Sector;
  score: number;
  primaryReason: string;
  flags: string[];
  priceChange1D: number;
  volumeRatio: number;
  zScore: number;
}

export interface EventStudyCase {
  ticker: string;
  eventName: string;
  eventDate: string;
  eventType: 'EARNINGS' | 'DIVIDEND_HIKE' | 'ACQUISITION' | 'INDEX_INCLUSION' | 'SPLIT';
  preEventReturn5D: number;
  eventDayReturn: number;
  postEventReturn5D: number;
  abnormalReturn: number;
  cumulativeAbnormalReturn: number;
  history: { dayOffset: number; car: number; benchmarkReturn: number; stockReturn: number }[];
}

export interface ResearchWorkspaceItem {
  id: string;
  title: string;
  analyst: string;
  role: string;
  createdAt: string;
  updatedAt: string;
  modelVersion: string;
  dataHash: string;
  tags: string[];
  type: 'SCREENER' | 'PORTFOLIO' | 'NOTE' | 'MODEL' | 'SCENARIO';
  content: any;
}

export type RoleType =
  | 'EQUITY RESEARCH'
  | 'QUANT'
  | 'PORTFOLIO'
  | 'MARKET STRATEGY'
  | 'RISK'
  | 'MACRO'
  | 'DIVIDENDS'
  | 'FACTOR RESEARCH';
