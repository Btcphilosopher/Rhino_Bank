/**
 * RhinoStocks - Institutional Primary Navigation Bar
 * RhinoBank Stock Market Division
 */

import React from 'react';
import {
  BarChart3,
  TrendingUp,
  Search,
  PieChart,
  Layers,
  Activity,
  ShieldAlert,
  Sliders,
  Scale,
  Terminal,
  Grid,
  Box,
} from 'lucide-react';

export type ActiveTab =
  | 'TERMINAL'
  | 'XYZ_ENGINE'
  | 'SECURITY_DEEP_DIVE'
  | 'SECTORS_INDUSTRIES'
  | 'FACTOR_RESEARCH'
  | 'CORRELATION_RISK'
  | 'REGIME_ANOMALY'
  | 'SCREENER_SCORING'
  | 'COMPARISON_PORTFOLIO'
  | 'R_CONSOLE_RESEARCH';

interface NavigationProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  selectedStockTicker: string;
}

interface NavItem {
  id: ActiveTab;
  label: string;
  sublabel?: string;
  icon: React.ReactNode;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  selectedStockTicker,
}) => {
  const navItems: NavItem[] = [
    {
      id: 'TERMINAL',
      label: 'GLOBAL TERMINAL',
      sublabel: 'Market Overview & Breadth',
      icon: <Grid className="w-4 h-4" />,
    },
    {
      id: 'XYZ_ENGINE',
      label: 'X/Y/Z ANALYTICS',
      sublabel: 'Universal 2D/3D Engine',
      icon: <Box className="w-4 h-4" />,
    },
    {
      id: 'SECURITY_DEEP_DIVE',
      label: `SECURITY: ${selectedStockTicker}`,
      sublabel: 'Technicals & Valuation',
      icon: <Activity className="w-4 h-4 text-cyan-400" />,
    },
    {
      id: 'SECTORS_INDUSTRIES',
      label: 'SECTORS & RRG',
      sublabel: 'Rotation & Industries',
      icon: <PieChart className="w-4 h-4" />,
    },
    {
      id: 'FACTOR_RESEARCH',
      label: 'FACTORS & PCA',
      sublabel: 'Multi-Factor & Loadings',
      icon: <Layers className="w-4 h-4" />,
    },
    {
      id: 'CORRELATION_RISK',
      label: 'CORRELATION & RISK',
      sublabel: 'Matrix, VaR, Drawdowns',
      icon: <BarChart3 className="w-4 h-4" />,
    },
    {
      id: 'REGIME_ANOMALY',
      label: 'REGIMES & ANOMALIES',
      sublabel: 'Markov Matrix & Outliers',
      icon: <ShieldAlert className="w-4 h-4" />,
    },
    {
      id: 'SCREENER_SCORING',
      label: 'SCREENER & SCORES',
      sublabel: 'Multi-Filter & Weighting',
      icon: <Sliders className="w-4 h-4" />,
    },
    {
      id: 'COMPARISON_PORTFOLIO',
      label: 'COMPARISON & PORTFOLIO',
      sublabel: 'Peer Lab & Research Basket',
      icon: <Scale className="w-4 h-4" />,
    },
    {
      id: 'R_CONSOLE_RESEARCH',
      label: 'R REPL & GOVERNANCE',
      sublabel: 'R Kernel & Provenance',
      icon: <Terminal className="w-4 h-4" />,
    },
  ];

  return (
    <nav className="flex items-stretch bg-[#0F172A] border-b border-[#1E293B] text-[11px] font-bold uppercase tracking-wider overflow-x-auto scrollbar-none select-none">
      {navItems.map((item) => {
        const isActive = activeTab === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onSelectTab(item.id)}
            className={`flex items-center space-x-2 px-4 py-2.5 transition-colors whitespace-nowrap cursor-pointer ${
              isActive
                ? 'border-b-2 border-[#00E5FF] text-white bg-[#1E293B]/40 font-bold'
                : 'border-b-2 border-transparent text-[#94A3B8] hover:bg-[#1E293B] hover:text-white'
            }`}
          >
            <span className={isActive ? 'text-[#00E5FF]' : 'text-[#64748B]'}>
              {item.icon}
            </span>
            <span className="font-sans text-[11px] tracking-wider">{item.label}</span>
          </button>
        );
      })}

      <button
        onClick={() => onSelectTab('SCREENER_SCORING')}
        className="ml-auto px-4 py-2 bg-[#00E5FF] text-[#0B0F19] hover:bg-white font-bold cursor-pointer transition-colors flex items-center gap-1.5 whitespace-nowrap text-[11px] uppercase tracking-wider"
      >
        <Sliders className="w-3.5 h-3.5" />
        <span>Screener [F4]</span>
      </button>
    </nav>
  );
};
