/**
 * RhinoStocks - Institutional Header & Ticker Tape
 * RhinoBank Stock Market Division
 */

import React, { useState } from 'react';
import { GlobalIndex, RhinoStock, RoleType } from '../types';
import {
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  Search,
  Sliders,
  Terminal,
  Activity,
  Cpu,
  Database,
  Globe,
  BarChart4,
  Layers,
  ChevronDown,
} from 'lucide-react';

interface HeaderProps {
  indices: GlobalIndex[];
  stocks: RhinoStock[];
  currentRole: RoleType;
  onSelectRole: (role: RoleType) => void;
  onSelectStock: (ticker: string) => void;
}

const ROLES: RoleType[] = [
  'EQUITY RESEARCH',
  'QUANT',
  'PORTFOLIO',
  'MARKET STRATEGY',
  'RISK',
  'MACRO',
  'DIVIDENDS',
  'FACTOR RESEARCH',
];

export const Header: React.FC<HeaderProps> = ({
  indices,
  stocks,
  currentRole,
  onSelectRole,
  onSelectStock,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);

  const filteredStocks = searchQuery.trim()
    ? stocks.filter(
        (s) =>
          s.ticker.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.sector.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.country.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 8)
    : [];

  return (
    <header className="bg-[#0F172A] border-b border-[#1E293B] text-[#CBD5E1] select-none sticky top-0 z-50 shadow-md">
      {/* Upper Tier: Branding, Role Workspaces, Search & System Status */}
      <div className="px-4 py-2 flex flex-wrap items-center justify-between gap-4 border-b border-[#1E293B]">
        {/* Brand & Division */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <div className="w-2 h-8 bg-[#00E5FF] mr-3"></div>
            <span className="text-lg font-bold tracking-tighter text-white font-sans">RHINOSTOCKS</span>
          </div>
          <div className="h-4 w-px bg-[#334155] mx-2"></div>
          <span className="text-[10px] uppercase tracking-widest text-[#94A3B8] font-semibold font-sans">
            RhinoBank Equity Division
          </span>
        </div>

        {/* Center: Universal Security Quick Finder */}
        <div className="relative flex-1 max-w-sm lg:max-w-md">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#64748B]" />
            <input
              type="text"
              placeholder="Search ticker, company, sector (e.g. NVDA, AAPL, Tech)..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setIsSearchOpen(true);
              }}
              onFocus={() => setIsSearchOpen(true)}
              className="w-full pl-9 pr-8 py-1.5 bg-[#0B0F19] border border-[#334155] rounded-sm text-xs text-[#CBD5E1] placeholder-[#64748B] focus:outline-none focus:border-[#00E5FF] focus:ring-1 focus:ring-[#00E5FF] font-mono transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setIsSearchOpen(false);
                }}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#94A3B8] hover:text-white text-xs font-mono"
              >
                ✕
              </button>
            )}
          </div>

          {/* Instant Search Results Dropdown */}
          {isSearchOpen && filteredStocks.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-[#0F172A] border border-[#1E293B] rounded-sm shadow-2xl z-50 overflow-hidden font-mono text-xs">
              <div className="px-3 py-1.5 bg-[#0B0F19] border-b border-[#1E293B] text-[10px] text-[#64748B] font-bold uppercase tracking-wider flex justify-between">
                <span>SECURITY MATCHES</span>
                <span>ESC to Close</span>
              </div>
              <div className="max-h-64 overflow-y-auto divide-y divide-[#1E293B]">
                {filteredStocks.map((stock) => (
                  <button
                    key={stock.ticker}
                    onClick={() => {
                      onSelectStock(stock.ticker);
                      setSearchQuery('');
                      setIsSearchOpen(false);
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-[#1E293B] flex items-center justify-between transition-colors group"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-[#00E5FF] group-hover:text-white w-16">
                        {stock.ticker}
                      </span>
                      <span className="text-[#CBD5E1] truncate max-w-[180px]">{stock.company}</span>
                      <span className="text-[10px] text-[#64748B]">({stock.country})</span>
                    </div>
                    <div className="flex items-center gap-3 text-right">
                      <span className="text-[#CBD5E1]">${stock.price.toFixed(2)}</span>
                      <span
                        className={`text-[11px] font-semibold ${
                          stock.changePct1D >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'
                        }`}
                      >
                        {stock.changePct1D >= 0 ? '+' : ''}
                        {stock.changePct1D.toFixed(2)}%
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right: Sleek Status Readouts & Role Switcher */}
        <div className="flex items-center space-x-6 text-[11px] font-mono">
          <div className="hidden sm:flex flex-col items-end">
            <span className="text-[#64748B] text-[10px] tracking-wider uppercase font-sans font-semibold">SYSTEM STATUS</span>
            <span className="text-[#10B981] font-bold">OPERATIONAL</span>
          </div>

          <div className="hidden md:flex flex-col items-end">
            <span className="text-[#64748B] text-[10px] tracking-wider uppercase font-sans font-semibold">MARKET TIME</span>
            <span className="text-white">14:32:05 GMT</span>
          </div>

          <div className="hidden lg:flex flex-col items-end">
            <span className="text-[#64748B] text-[10px] tracking-wider uppercase font-sans font-semibold">DATA LATENCY</span>
            <span className="text-white">12ms</span>
          </div>

          {/* Role Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
              className="flex items-center gap-2 px-3 py-1.5 bg-[#0B0F19] border border-[#334155] rounded-sm text-xs font-mono text-[#00E5FF] hover:border-[#00E5FF] transition-all"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span className="hidden xl:inline text-[#94A3B8]">ROLE:</span>
              <span className="font-semibold text-white">{currentRole}</span>
              <ChevronDown className="w-3.5 h-3.5 text-[#94A3B8]" />
            </button>

            {isRoleDropdownOpen && (
              <div className="absolute right-0 mt-1 w-56 bg-[#0F172A] border border-[#1E293B] rounded-sm shadow-xl z-50 font-mono text-xs overflow-hidden divide-y divide-[#1E293B]">
                <div className="px-3 py-1.5 bg-[#0B0F19] text-[10px] text-[#64748B] font-bold uppercase tracking-wider">
                  DIVISION ANALYST WORKSPACES
                </div>
                {ROLES.map((role) => (
                  <button
                    key={role}
                    onClick={() => {
                      onSelectRole(role);
                      setIsRoleDropdownOpen(false);
                    }}
                    className={`w-full px-3 py-2 text-left hover:bg-[#1E293B] transition-colors flex items-center justify-between ${
                      currentRole === role ? 'bg-[#1E293B]/60 text-[#00E5FF] font-bold border-l-2 border-[#00E5FF]' : 'text-[#CBD5E1]'
                    }`}
                  >
                    <span>{role}</span>
                    {currentRole === role && <span className="text-[10px] text-[#00E5FF]">ACTIVE</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Lower Tier: Live Global Indices Ticker Tape */}
      <div className="px-4 py-1.5 bg-[#0B0F19] overflow-x-auto flex items-center gap-6 text-[11px] font-mono whitespace-nowrap scrollbar-none">
        <div className="flex items-center gap-1.5 text-[#64748B] font-bold tracking-widest text-[10px] uppercase">
          <Globe className="w-3 h-3 text-[#00E5FF]" />
          <span>INDICES:</span>
        </div>

        {indices.map((idx) => {
          const isUp = idx.changePct1D >= 0;
          return (
            <div
              key={idx.symbol}
              className="flex items-center gap-2 px-2 py-0.5 rounded-xs hover:bg-[#0F172A] cursor-pointer transition-colors"
            >
              <span className="text-[#CBD5E1] font-semibold">{idx.name}</span>
              <span className="text-[#94A3B8]">{idx.value.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 1 })}</span>
              <span className={`flex items-center text-[10px] font-bold ${isUp ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                {isUp ? <TrendingUp className="w-3 h-3 inline mr-0.5" /> : <TrendingDown className="w-3 h-3 inline mr-0.5" />}
                {isUp ? '+' : ''}
                {idx.changePct1D.toFixed(2)}%
              </span>
            </div>
          );
        })}

        <div className="flex items-center gap-3 pl-4 border-l border-[#1E293B] text-[10px] text-[#64748B]">
          <span>US 10Y: <span className="text-white font-semibold">4.28%</span></span>
          <span className="text-[#334155]">|</span>
          <span>BRENT: <span className="text-white font-semibold">$78.4</span></span>
          <span className="text-[#334155]">|</span>
          <span>GOLD: <span className="text-white font-semibold">$2,480</span></span>
        </div>
      </div>
    </header>
  );
};
