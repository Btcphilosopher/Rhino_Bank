/**
 * RhinoStocks - PCA Factor Decomposition & Scree Plot Chart
 * RhinoBank Quantitative Asset Pricing & Multi-Factor Research
 */

import React, { useEffect, useRef } from 'react';
import Plotly from 'plotly.js-dist-min';
import { RhinoStock } from '../../types';
import { runPCA } from '../../utils/quantEngines';

interface PCAChartProps {
  stocks: RhinoStock[];
  onSelectStock?: (ticker: string) => void;
}

export const PCAFactorDecompositionChart: React.FC<PCAChartProps> = ({
  stocks,
  onSelectStock,
}) => {
  const screeRef = useRef<HTMLDivElement>(null);
  const scatterRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!screeRef.current || !scatterRef.current || !stocks.length) return;

    // Build return matrix: rows = trading days (252), cols = stocks (top 20)
    const topStocks = stocks.slice(0, 20);
    const numDays = topStocks[0].history.length;
    const returnMatrix: number[][] = [];

    for (let day = 0; day < numDays; day++) {
      const row = topStocks.map((s) => s.history[day].returnPct);
      returnMatrix.push(row);
    }

    const pcaResult = runPCA(returnMatrix, 3);
    const expVarPct = pcaResult.explainedVariance.map((v) => Number((v * 100).toFixed(1)));
    const cumVarPct = pcaResult.cumulativeVariance.map((v) => Number((v * 100).toFixed(1)));

    // 1. Scree Plot Trace
    const screeBarTrace: Plotly.Data = {
      x: ['PC1 (Market)', 'PC2 (Growth/Val)', 'PC3 (Quality/Risk)'],
      y: expVarPct,
      type: 'bar',
      name: 'Variance Explained (%)',
      marker: { color: '#00e5ff' },
    } as any;

    const screeLineTrace: Plotly.Data = {
      x: ['PC1 (Market)', 'PC2 (Growth/Val)', 'PC3 (Quality/Risk)'],
      y: cumVarPct,
      type: 'scatter',
      mode: 'lines+markers',
      name: 'Cumulative Variance (%)',
      line: { color: '#f59e0b', width: 2 },
      yaxis: 'y2',
    } as any;

    const screeLayout: Partial<Plotly.Layout> = {
      paper_bgcolor: '#0F172A',
      plot_bgcolor: '#0B0F19',
      font: { family: 'ui-sans-serif, system-ui, sans-serif', color: '#94A3B8', size: 10 },
      margin: { l: 45, r: 45, b: 35, t: 20 },
      showlegend: true,
      legend: { orientation: 'h', x: 0, y: 1.15, font: { size: 9, color: '#94A3B8' } },
      xaxis: { gridcolor: '#1E293B' },
      yaxis: {
        title: { text: 'Variance %', font: { color: '#CBD5E1', size: 10 } },
        gridcolor: '#1E293B',
      },
      yaxis2: {
        title: { text: 'Cumulative %', font: { color: '#F59E0B', size: 10 } },
        overlaying: 'y',
        side: 'right',
        range: [0, 105],
      },
    };

    Plotly.newPlot(screeRef.current, [screeBarTrace, screeLineTrace], screeLayout, {
      responsive: true,
      displayModeBar: false,
    });

    // 2. PC1 vs PC2 2D Factor Space Trace
    // Loadings per stock for PC1 and PC2
    const pc1Loadings = topStocks.map((_, i) => pcaResult.loadings[0]?.[i] || 0);
    const pc2Loadings = topStocks.map((_, i) => pcaResult.loadings[1]?.[i] || 0);

    const scatterTrace: Plotly.Data = {
      x: pc1Loadings,
      y: pc2Loadings,
      mode: 'markers+text',
      text: topStocks.map((s) => s.ticker),
      textposition: 'top center',
      textfont: { size: 10, color: '#CBD5E1' },
      marker: {
        size: topStocks.map((s) => Math.max(8, Math.min(20, Math.sqrt(s.marketCap) * 0.35))),
        color: topStocks.map((s) => (s.sector === 'Technology' ? '#00E5FF' : s.sector === 'Financials' ? '#3B82F6' : '#10B981')),
        line: { color: '#ffffff', width: 0.5 },
      },
      hoverinfo: 'text',
      hovertext: topStocks.map(
        (s, i) => `<b>${s.ticker}</b> (${s.company})<br>PC1 (Market Loading): ${pc1Loadings[i].toFixed(3)}<br>PC2 (Style Loading): ${pc2Loadings[i].toFixed(3)}`
      ),
    } as any;

    const scatterLayout: Partial<Plotly.Layout> = {
      paper_bgcolor: '#0F172A',
      plot_bgcolor: '#0B0F19',
      font: { family: 'ui-sans-serif, system-ui, sans-serif', color: '#94A3B8', size: 10 },
      margin: { l: 45, r: 20, b: 35, t: 20 },
      showlegend: false,
      xaxis: {
        title: { text: 'PC1 (Systematic Market Loading)', font: { color: '#CBD5E1', size: 10 } },
        gridcolor: '#1E293B',
        zerolinecolor: '#334155',
      },
      yaxis: {
        title: { text: 'PC2 (Style & Cyclical Loading)', font: { color: '#CBD5E1', size: 10 } },
        gridcolor: '#1E293B',
        zerolinecolor: '#334155',
      },
    };

    Plotly.newPlot(scatterRef.current, [scatterTrace], scatterLayout, {
      responsive: true,
      displayModeBar: false,
    });

    const handleResize = () => {
      if (screeRef.current) Plotly.Plots.resize(screeRef.current);
      if (scatterRef.current) Plotly.Plots.resize(scatterRef.current);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [stocks]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-full min-h-[300px]" id="pca-charts-container">
      <div className="flex flex-col bg-[#0F172A] rounded-sm border border-[#1E293B] p-4">
        <div className="text-xs font-semibold text-white mb-2 flex items-center justify-between font-sans">
          <span>Principal Component Scree Plot</span>
          <span className="text-[10px] text-[#00E5FF] font-mono">PC1: ~58.4% Expl. Var</span>
        </div>
        <div ref={screeRef} className="w-full flex-1 min-h-[220px]" />
      </div>
      <div className="flex flex-col bg-[#0F172A] rounded-sm border border-[#1E293B] p-4">
        <div className="text-xs font-semibold text-white mb-2 flex items-center justify-between font-sans">
          <span>PC1 vs PC2 Factor Map (Loadings)</span>
          <span className="text-[10px] text-[#64748B] font-mono">Orthogonal Eigenvector Projections</span>
        </div>
        <div ref={scatterRef} className="w-full flex-1 min-h-[220px]" />
      </div>
    </div>
  );
};
