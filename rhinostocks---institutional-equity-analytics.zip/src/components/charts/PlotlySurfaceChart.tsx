/**
 * RhinoStocks - Plotly Universal X/Y/Z Chart Component
 * Supports 2D Cross-Sectional Scatter with Regression & 3D Interactive Surfaces
 */

import React, { useEffect, useRef, useState } from 'react';
import Plotly from 'plotly.js-dist-min';
import { RhinoStock, Sector } from '../../types';

interface PlotlyChartProps {
  stocks: RhinoStock[];
  xAxisKey: keyof RhinoStock | string;
  yAxisKey: keyof RhinoStock | string;
  zAxisKey?: string;
  xAxisLabel: string;
  yAxisLabel: string;
  zAxisLabel?: string;
  is3D?: boolean;
  onSelectStock?: (ticker: string) => void;
  selectedTicker?: string;
}

// Color map for GICS sectors matching institutional palette
const SECTOR_COLORS: Record<Sector, string> = {
  Technology: '#00e5ff',
  Financials: '#3b82f6',
  Healthcare: '#10b981',
  Energy: '#f59e0b',
  Industrials: '#8b5cf6',
  'Consumer Discretionary': '#ec4899',
  'Consumer Staples': '#06b6d4',
  Materials: '#eab308',
  Utilities: '#14b8a6',
  'Real Estate': '#a855f7',
  'Communication Services': '#6366f1',
};

export const PlotlyUniversalChart: React.FC<PlotlyChartProps> = ({
  stocks,
  xAxisKey,
  yAxisKey,
  zAxisKey,
  xAxisLabel,
  yAxisLabel,
  zAxisLabel,
  is3D = false,
  onSelectStock,
  selectedTicker,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Helper to extract nested numerical values
  const getVal = (stock: RhinoStock, key: string): number => {
    if (key === 'price') return stock.price;
    if (key === 'marketCap') return stock.marketCap;
    if (key === 'return1D') return stock.returns['1D'];
    if (key === 'return1M') return stock.returns['1M'];
    if (key === 'return3M') return stock.returns['3M'];
    if (key === 'return1Y') return stock.returns['1Y'];
    if (key === 'returnYTD') return stock.returns['YTD'];
    if (key === 'pe') return stock.valuation.pe;
    if (key === 'pb') return stock.valuation.pb;
    if (key === 'evToEbitda') return stock.valuation.evToEbitda;
    if (key === 'fcfYield') return stock.fundamentals.fcfYield;
    if (key === 'dividendYield') return stock.valuation.dividendYield;
    if (key === 'roe') return stock.fundamentals.roe;
    if (key === 'roic') return stock.fundamentals.roic;
    if (key === 'grossMargin') return stock.fundamentals.grossMargin;
    if (key === 'revenueGrowth') return stock.fundamentals.revenueGrowth;
    if (key === 'epsGrowth') return stock.fundamentals.epsGrowth;
    if (key === 'debtToEquity') return stock.fundamentals.debtToEquity;
    if (key === 'realizedVol1Y') return stock.risk.realizedVol1Y;
    if (key === 'realizedVol30D') return stock.risk.realizedVol30D;
    if (key === 'beta') return stock.risk.betaMarket;
    if (key === 'sharpe') return stock.risk.sharpeRatio;
    if (key === 'maxDrawdown') return Math.abs(stock.risk.maxDrawdown);
    if (key === 'momentum12M') return stock.momentum.m12;
    if (key === 'rhinoScore') return stock.equityScore.composite;
    if (key === 'factorValue') return stock.factors.value;
    if (key === 'factorGrowth') return stock.factors.growth;
    if (key === 'factorMomentum') return stock.factors.momentum;
    if (key === 'factorQuality') return stock.factors.quality;
    return stock.returns['1Y'];
  };

  useEffect(() => {
    if (!containerRef.current || !stocks.length) return;

    if (is3D && zAxisKey) {
      // 3D SCATTER / SURFACE VISUALIZATION
      const traces: Plotly.Data[] = [];
      const sectors = Array.from(new Set(stocks.map((s) => s.sector)));

      sectors.forEach((sec) => {
        const secStocks = stocks.filter((s) => s.sector === sec);
        traces.push({
          x: secStocks.map((s) => getVal(s, xAxisKey)),
          y: secStocks.map((s) => getVal(s, yAxisKey)),
          z: secStocks.map((s) => getVal(s, zAxisKey)),
          text: secStocks.map(
            (s) =>
              `<b>${s.ticker}</b> (${s.company})<br>${xAxisLabel}: ${getVal(s, xAxisKey).toFixed(2)}<br>${yAxisLabel}: ${getVal(s, yAxisKey).toFixed(2)}<br>${zAxisLabel}: ${getVal(s, zAxisKey).toFixed(2)}`
          ),
          mode: 'markers+text',
          name: sec,
          type: 'scatter3d',
          textposition: 'top center',
          textfont: { size: 10, color: '#94a3b8' },
          marker: {
            size: secStocks.map((s) => Math.max(5, Math.min(18, Math.sqrt(s.marketCap) * 0.35))),
            color: SECTOR_COLORS[sec as Sector] || '#00e5ff',
            opacity: 0.85,
            line: {
              color: '#ffffff',
              width: 0.5,
            },
          },
          hoverinfo: 'text',
        } as any);
      });

      const layout: Partial<Plotly.Layout> = {
        paper_bgcolor: '#0F172A',
        plot_bgcolor: '#0B0F19',
        font: { family: 'ui-sans-serif, system-ui, sans-serif', color: '#94A3B8', size: 11 },
        margin: { l: 0, r: 0, b: 0, t: 30 },
        showlegend: true,
        legend: {
          x: 0,
          y: 1,
          font: { color: '#CBD5E1', size: 10 },
          bgcolor: 'rgba(15, 23, 42, 0.8)',
        },
        scene: {
          xaxis: {
            title: { text: xAxisLabel, font: { color: '#00E5FF', size: 12 } },
            backgroundcolor: '#0B0F19',
            gridcolor: '#1E293B',
            showbackground: true,
            zerolinecolor: '#334155',
          },
          yaxis: {
            title: { text: yAxisLabel, font: { color: '#38BDF8', size: 12 } },
            backgroundcolor: '#0B0F19',
            gridcolor: '#1E293B',
            showbackground: true,
            zerolinecolor: '#334155',
          },
          zaxis: {
            title: { text: zAxisLabel || 'Z-Axis', font: { color: '#A855F7', size: 12 } },
            backgroundcolor: '#0B0F19',
            gridcolor: '#1E293B',
            showbackground: true,
            zerolinecolor: '#334155',
          },
          camera: {
            eye: { x: 1.5, y: 1.5, z: 1.2 },
          },
        },
      };

      Plotly.newPlot(containerRef.current, traces, layout, {
        responsive: true,
        displayModeBar: true,
        modeBarButtonsToRemove: ['toImage'],
      });
    } else {
      // 2D UNIVERSAL CROSS-SECTIONAL SCATTER + REGRESSION LINE
      const traces: Plotly.Data[] = [];
      const sectors = Array.from(new Set(stocks.map((s) => s.sector)));

      // Collect all x, y for overall linear regression line
      const allX = stocks.map((s) => getVal(s, xAxisKey));
      const allY = stocks.map((s) => getVal(s, yAxisKey));

      // Calculate regression
      const n = allX.length;
      const sumX = allX.reduce((a, b) => a + b, 0);
      const sumY = allY.reduce((a, b) => a + b, 0);
      const meanX = sumX / n;
      const meanY = sumY / n;
      let num = 0;
      let den = 0;
      for (let i = 0; i < n; i++) {
        num += (allX[i] - meanX) * (allY[i] - meanY);
        den += Math.pow(allX[i] - meanX, 2);
      }
      const slope = den !== 0 ? num / den : 0;
      const intercept = meanY - slope * meanX;

      const minX = Math.min(...allX);
      const maxX = Math.max(...allX);

      // Regression trendline trace
      traces.push({
        x: [minX, maxX],
        y: [minX * slope + intercept, maxX * slope + intercept],
        mode: 'lines',
        name: `OLS Fit (Slope: ${slope.toFixed(2)})`,
        line: { color: 'rgba(148, 163, 184, 0.4)', width: 1.5, dash: 'dot' },
        hoverinfo: 'none',
      } as any);

      // Sector scatter points
      sectors.forEach((sec) => {
        const secStocks = stocks.filter((s) => s.sector === sec);
        traces.push({
          x: secStocks.map((s) => getVal(s, xAxisKey)),
          y: secStocks.map((s) => getVal(s, yAxisKey)),
          hovertext: secStocks.map(
            (s) =>
              `<b>${s.ticker}</b> (${s.company})<br>${s.sector} | ${s.country}<br>${xAxisLabel}: ${getVal(s, xAxisKey).toFixed(2)}<br>${yAxisLabel}: ${getVal(s, yAxisKey).toFixed(2)}<br>Mkt Cap: $${s.marketCap}B`
          ),
          customdata: secStocks.map((s) => s.ticker),
          mode: 'markers+text',
          name: sec,
          type: 'scatter',
          text: secStocks.map((s) => s.ticker),
          textposition: 'top center',
          textfont: { size: 10, color: '#CBD5E1' },
          marker: {
            size: secStocks.map((s) => (s.ticker === selectedTicker ? 22 : Math.max(8, Math.min(24, Math.sqrt(s.marketCap) * 0.38)))),
            color: SECTOR_COLORS[sec as Sector] || '#00E5FF',
            opacity: 0.82,
            line: {
              color: secStocks.map((s) => (s.ticker === selectedTicker ? '#ffffff' : '#0F172A')),
              width: secStocks.map((s) => (s.ticker === selectedTicker ? 3 : 1)),
            },
          },
          hoverinfo: 'text',
        } as any);
      });

      const layout: Partial<Plotly.Layout> = {
        paper_bgcolor: '#0F172A',
        plot_bgcolor: '#0B0F19',
        font: { family: 'ui-sans-serif, system-ui, sans-serif', color: '#94A3B8', size: 11 },
        margin: { l: 60, r: 20, b: 50, t: 20 },
        showlegend: true,
        legend: {
          orientation: 'h',
          x: 0,
          y: -0.15,
          font: { color: '#94A3B8', size: 10 },
        },
        xaxis: {
          title: { text: xAxisLabel, font: { color: '#CBD5E1', size: 12 } },
          gridcolor: '#1E293B',
          zerolinecolor: '#334155',
          tickfont: { color: '#94A3B8' },
        },
        yaxis: {
          title: { text: yAxisLabel, font: { color: '#CBD5E1', size: 12 } },
          gridcolor: '#1E293B',
          zerolinecolor: '#334155',
          tickfont: { color: '#94A3B8' },
        },
        hoverlabel: {
          bgcolor: '#0B0F19',
          bordercolor: '#00E5FF',
          font: { color: '#F8FAFC', size: 11 },
        },
      };

      Plotly.newPlot(containerRef.current, traces, layout, {
        responsive: true,
        displayModeBar: true,
        modeBarButtonsToRemove: ['lasso2d', 'select2d'],
      });

      // Handle point clicks to drill down into security
      const plotEl = containerRef.current as any;
      if (plotEl && plotEl.on) {
        plotEl.on('plotly_click', (data: any) => {
          if (data.points && data.points[0] && onSelectStock) {
            const point = data.points[0];
            const ticker = point.text || point.customdata;
            if (ticker && typeof ticker === 'string') {
              onSelectStock(ticker.replace(/<[^>]*>?/gm, '').split(' ')[0]);
            }
          }
        });
      }
    }

    const handleResize = () => {
      if (containerRef.current) {
        Plotly.Plots.resize(containerRef.current);
      }
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [stocks, xAxisKey, yAxisKey, zAxisKey, xAxisLabel, yAxisLabel, zAxisLabel, is3D, selectedTicker]);

  return <div ref={containerRef} className="w-full h-full min-h-[460px]" id="plotly-universal-container" />;
};
