/**
 * RhinoStocks - Sector Rotation (RRG) & Correlation Heatmap Components
 * RhinoBank Proprietary Equity Market Intelligence
 */

import React, { useEffect, useRef } from 'react';
import Plotly from 'plotly.js-dist-min';
import { SectorMetric, RhinoStock, Sector } from '../../types';

interface SectorRotationChartProps {
  sectors: SectorMetric[];
  onSelectSector?: (sector: Sector) => void;
}

export const SectorRotationChart: React.FC<SectorRotationChartProps> = ({
  sectors,
  onSelectSector,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current || !sectors.length) return;

    const traces: Plotly.Data[] = [];

    // Quadrant background shapes or quadrant references
    // 100, 100 center point
    const colors: Record<string, string> = {
      LEADING: '#10b981',   // Green
      IMPROVING: '#38bdf8', // Light blue
      WEAKENING: '#f59e0b', // Amber
      LAGGING: '#ef4444',   // Red
    };

    sectors.forEach((sec) => {
      const x = sec.rotationCoordinates.x;
      const y = sec.rotationCoordinates.y;

      // Draw synthetic short historical trail (3 points)
      const trailX = [x - (sec.momentumScore - 50) * 0.04, x - (sec.momentumScore - 50) * 0.02, x];
      const trailY = [y - (sec.return1M - 2) * 0.4, y - (sec.return1M - 2) * 0.2, y];

      traces.push({
        x: trailX,
        y: trailY,
        mode: 'lines',
        line: { color: colors[sec.rotationState] || '#00e5ff', width: 1.5, dash: 'dot' },
        showlegend: false,
        hoverinfo: 'none',
      } as any);

      traces.push({
        x: [x],
        y: [y],
        mode: 'markers+text',
        name: sec.sector,
        text: [sec.sector],
        textposition: 'top center',
        textfont: { size: 10, color: '#e2e8f0' },
        marker: {
          size: Math.max(10, Math.min(22, Math.sqrt(sec.marketCapTotal) * 0.35)),
          color: colors[sec.rotationState] || '#00e5ff',
          opacity: 0.9,
          line: { color: '#ffffff', width: 1 },
        },
        hoverinfo: 'text',
        hovertext: `<b>${sec.sector}</b><br>State: <b>${sec.rotationState}</b><br>RS-Ratio: ${x.toFixed(2)}<br>RS-Momentum: ${y.toFixed(2)}<br>1Y Ret: ${sec.return1Y}%<br>P/E: ${sec.peRatio}x`,
      } as any);
    });

    const layout: Partial<Plotly.Layout> = {
      paper_bgcolor: '#0F172A',
      plot_bgcolor: '#0B0F19',
      font: { family: 'ui-sans-serif, system-ui, sans-serif', color: '#94A3B8', size: 10 },
      margin: { l: 50, r: 20, b: 40, t: 20 },
      showlegend: false,
      xaxis: {
        title: { text: 'Relative Strength Ratio (RS-Ratio)', font: { color: '#CBD5E1', size: 11 } },
        gridcolor: '#1E293B',
        zeroline: true,
        zerolinecolor: '#334155',
        zerolinewidth: 1.5,
        range: [94, 106],
      },
      yaxis: {
        title: { text: 'Relative Strength Momentum (RS-Momentum)', font: { color: '#CBD5E1', size: 11 } },
        gridcolor: '#1E293B',
        zeroline: true,
        zerolinecolor: '#334155',
        zerolinewidth: 1.5,
        range: [94, 106],
      },
      shapes: [
        // Vertical divider at 100
        { type: 'line', x0: 100, x1: 100, y0: 90, y1: 110, line: { color: '#334155', width: 1.5, dash: 'dash' } },
        // Horizontal divider at 100
        { type: 'line', x0: 90, x1: 110, y0: 100, y1: 100, line: { color: '#334155', width: 1.5, dash: 'dash' } },
      ],
      annotations: [
        { x: 104.5, y: 104.5, text: '<b>LEADING</b>', showarrow: false, font: { color: 'rgba(16, 185, 129, 0.5)', size: 14 } },
        { x: 95.5, y: 104.5, text: '<b>IMPROVING</b>', showarrow: false, font: { color: 'rgba(0, 229, 255, 0.5)', size: 14 } },
        { x: 104.5, y: 95.5, text: '<b>WEAKENING</b>', showarrow: false, font: { color: 'rgba(245, 158, 11, 0.5)', size: 14 } },
        { x: 95.5, y: 95.5, text: '<b>LAGGING</b>', showarrow: false, font: { color: 'rgba(239, 68, 68, 0.5)', size: 14 } },
      ],
      hoverlabel: {
        bgcolor: '#0B0F19',
        bordercolor: '#00E5FF',
        font: { color: '#F8FAFC', size: 11 },
      },
    };

    Plotly.newPlot(containerRef.current, traces, layout, {
      responsive: true,
      displayModeBar: false,
    });

    const handleResize = () => {
      if (containerRef.current) Plotly.Plots.resize(containerRef.current);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [sectors]);

  return <div ref={containerRef} className="w-full h-full min-h-[420px]" id="sector-rotation-canvas" />;
};

interface CorrelationMatrixProps {
  items: { ticker: string; returns: number[] }[];
  type?: 'PEARSON' | 'SPEARMAN';
}

export const CorrelationMatrixHeatmap: React.FC<CorrelationMatrixProps> = ({
  items,
  type = 'PEARSON',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current || !items.length) return;

    const labels = items.map((it) => it.ticker);
    const zMatrix: number[][] = [];

    for (let i = 0; i < items.length; i++) {
      const row: number[] = [];
      for (let j = 0; j < items.length; j++) {
        if (i === j) {
          row.push(1.0);
        } else {
          // Calculate correlation
          const r1 = items[i].returns;
          const r2 = items[j].returns;
          const n = Math.min(r1.length, r2.length);
          const avg1 = r1.reduce((a, b) => a + b, 0) / n;
          const avg2 = r2.reduce((a, b) => a + b, 0) / n;
          let cov = 0;
          let v1 = 0;
          let v2 = 0;
          for (let k = 0; k < n; k++) {
            cov += (r1[k] - avg1) * (r2[k] - avg2);
            v1 += Math.pow(r1[k] - avg1, 2);
            v2 += Math.pow(r2[k] - avg2, 2);
          }
          const denom = Math.sqrt(v1 * v2);
          const r = denom > 0 ? cov / denom : 0;
          row.push(Number(r.toFixed(2)));
        }
      }
      zMatrix.push(row);
    }

    const trace: Plotly.Data = {
      z: zMatrix,
      x: labels,
      y: labels,
      type: 'heatmap',
      colorscale: [
        [0.0, '#1e3a8a'],  // Deep blue (-1.0)
        [0.5, '#0f172a'],  // Slate (0.0)
        [0.75, '#0e7490'], // Cyan
        [1.0, '#10b981'],  // Emerald (+1.0)
      ],
      zmin: -1.0,
      zmax: 1.0,
      hoverongaps: false,
      colorbar: {
        title: `${type === 'PEARSON' ? 'Pearson ρ' : 'Spearman r'}`,
        tickfont: { color: '#94a3b8', size: 10 },
        titlefont: { color: '#cbd5e1', size: 11 },
        thickness: 12,
        len: 0.9,
      },
    } as any;

    const layout: Partial<Plotly.Layout> = {
      paper_bgcolor: '#0F172A',
      plot_bgcolor: '#0B0F19',
      font: { family: 'ui-sans-serif, system-ui, sans-serif', color: '#94A3B8', size: 10 },
      margin: { l: 60, r: 30, b: 60, t: 20 },
      xaxis: { tickfont: { color: '#94A3B8', size: 9 }, tickangle: -45 },
      yaxis: { tickfont: { color: '#94A3B8', size: 9 }, autorange: 'reversed' },
    };

    Plotly.newPlot(containerRef.current, [trace], layout, {
      responsive: true,
      displayModeBar: false,
    });

    const handleResize = () => {
      if (containerRef.current) Plotly.Plots.resize(containerRef.current);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [items, type]);

  return <div ref={containerRef} className="w-full h-full min-h-[400px]" id="correlation-heatmap-canvas" />;
};
