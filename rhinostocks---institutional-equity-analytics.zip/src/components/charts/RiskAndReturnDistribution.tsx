/**
 * RhinoStocks - Return Distribution, VaR, CVaR & Underwater Drawdown Charts
 * RhinoBank Quantitative Risk Laboratory
 */

import React, { useEffect, useRef } from 'react';
import Plotly from 'plotly.js-dist-min';
import { PriceBar } from '../../types';

interface ReturnDistributionChartProps {
  history: PriceBar[];
  var95: number;
  cvar95: number;
  skewness: number;
  kurtosis: number;
}

export const ReturnDistributionChart: React.FC<ReturnDistributionChartProps> = ({
  history,
  var95,
  cvar95,
  skewness,
  kurtosis,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current || !history.length) return;

    const returns = history.map((b) => b.returnPct);

    // Distribution Histogram trace
    const histTrace: Plotly.Data = {
      x: returns,
      type: 'histogram',
      name: 'Daily Returns (%)',
      nbinsx: 35,
      marker: {
        color: 'rgba(56, 189, 248, 0.65)',
        line: { color: '#0284c7', width: 1 },
      },
      opacity: 0.85,
    } as any;

    const layout: Partial<Plotly.Layout> = {
      paper_bgcolor: '#0F172A',
      plot_bgcolor: '#0B0F19',
      font: { family: 'ui-sans-serif, system-ui, sans-serif', color: '#94A3B8', size: 10 },
      margin: { l: 45, r: 20, b: 35, t: 20 },
      showlegend: false,
      xaxis: {
        title: { text: 'Daily Return (%)', font: { color: '#CBD5E1', size: 10 } },
        gridcolor: '#1E293B',
        zerolinecolor: '#334155',
      },
      yaxis: {
        title: { text: 'Frequency (Days)', font: { color: '#CBD5E1', size: 10 } },
        gridcolor: '#1E293B',
      },
      shapes: [
        // VaR 95% Cutoff line
        {
          type: 'line',
          x0: -var95,
          x1: -var95,
          y0: 0,
          y1: 1,
          yref: 'paper',
          line: { color: '#EF4444', width: 2, dash: 'dash' },
        },
        // CVaR 95% Expected Shortfall line
        {
          type: 'line',
          x0: -cvar95,
          x1: -cvar95,
          y0: 0,
          y1: 1,
          yref: 'paper',
          line: { color: '#DC2626', width: 2, dash: 'dot' },
        },
      ],
      annotations: [
        {
          x: -var95,
          y: 0.9,
          yref: 'paper',
          text: `VaR (95%): -${var95.toFixed(2)}%`,
          showarrow: true,
          arrowhead: 2,
          arrowcolor: '#EF4444',
          font: { color: '#EF4444', size: 9 },
          bgcolor: 'rgba(15, 23, 42, 0.9)',
        },
      ],
    };

    Plotly.newPlot(containerRef.current, [histTrace], layout, {
      responsive: true,
      displayModeBar: false,
    });

    const handleResize = () => {
      if (containerRef.current) Plotly.Plots.resize(containerRef.current);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [history, var95, cvar95]);

  return <div ref={containerRef} className="w-full h-full min-h-[220px]" id="return-dist-canvas" />;
};

interface UnderwaterChartProps {
  history: PriceBar[];
}

export const UnderwaterDrawdownChart: React.FC<UnderwaterChartProps> = ({ history }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current || !history.length) return;

    let peak = history[0].close;
    const dates = history.map((b) => b.date);
    const drawdowns = history.map((b) => {
      if (b.close > peak) peak = b.close;
      return Number((((b.close - peak) / peak) * 100).toFixed(2));
    });

    const trace: Plotly.Data = {
      x: dates,
      y: drawdowns,
      type: 'scatter',
      mode: 'lines',
      name: 'Drawdown (%)',
      fill: 'tozeroy',
      fillcolor: 'rgba(239, 68, 68, 0.18)',
      line: { color: '#EF4444', width: 1.5 },
    } as any;

    const layout: Partial<Plotly.Layout> = {
      paper_bgcolor: '#0F172A',
      plot_bgcolor: '#0B0F19',
      font: { family: 'ui-sans-serif, system-ui, sans-serif', color: '#94A3B8', size: 10 },
      margin: { l: 45, r: 20, b: 35, t: 20 },
      showlegend: false,
      xaxis: {
        gridcolor: '#1E293B',
        zerolinecolor: '#334155',
      },
      yaxis: {
        title: { text: 'Drawdown from Peak (%)', font: { color: '#CBD5E1', size: 10 } },
        gridcolor: '#1E293B',
        zerolinecolor: '#334155',
      },
    };

    Plotly.newPlot(containerRef.current, [trace], layout, {
      responsive: true,
      displayModeBar: false,
    });

    const handleResize = () => {
      if (containerRef.current) Plotly.Plots.resize(containerRef.current);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [history]);

  return <div ref={containerRef} className="w-full h-full min-h-[220px]" id="underwater-chart-canvas" />;
};
