/**
 * RhinoStocks - Financial Technicals & Candlestick Chart Engine
 * RhinoBank Proprietary Quantitative Charting
 */

import React, { useEffect, useRef, useState } from 'react';
import Plotly from 'plotly.js-dist-min';
import { PriceBar } from '../../types';
import { TrendingUp, Activity, BarChart2, Eye } from 'lucide-react';

interface CandlestickChartProps {
  ticker: string;
  companyName: string;
  history: PriceBar[];
}

export const CandlestickChart: React.FC<CandlestickChartProps> = ({
  ticker,
  companyName,
  history,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [chartType, setChartType] = useState<'candlestick' | 'ohlc' | 'line' | 'area'>('candlestick');
  const [showSMA20, setShowSMA20] = useState(true);
  const [showSMA50, setShowSMA50] = useState(true);
  const [showSMA200, setShowSMA200] = useState(true);
  const [showBB, setShowBB] = useState(false);
  const [subIndicator, setSubIndicator] = useState<'VOLUME_MACD' | 'VOLUME_RSI' | 'ATR' | 'VOLUME_ONLY'>('VOLUME_MACD');

  useEffect(() => {
    if (!containerRef.current || !history.length) return;

    const dates = history.map((b) => b.date);
    const opens = history.map((b) => b.open);
    const highs = history.map((b) => b.high);
    const lows = history.map((b) => b.low);
    const closes = history.map((b) => b.close);
    const volumes = history.map((b) => b.volume);

    const traces: Plotly.Data[] = [];

    // Main Price Trace
    if (chartType === 'candlestick') {
      traces.push({
        x: dates,
        open: opens,
        high: highs,
        low: lows,
        close: closes,
        type: 'candlestick',
        name: ticker,
        increasing: { line: { color: '#10b981', width: 1 }, fillcolor: '#10b981' },
        decreasing: { line: { color: '#ef4444', width: 1 }, fillcolor: '#ef4444' },
        yaxis: 'y1',
        hoverinfo: 'x+y',
      } as any);
    } else if (chartType === 'ohlc') {
      traces.push({
        x: dates,
        open: opens,
        high: highs,
        low: lows,
        close: closes,
        type: 'ohlc',
        name: ticker,
        increasing: { line: { color: '#10b981' } },
        decreasing: { line: { color: '#ef4444' } },
        yaxis: 'y1',
      } as any);
    } else if (chartType === 'area') {
      traces.push({
        x: dates,
        y: closes,
        type: 'scatter',
        mode: 'lines',
        name: ticker,
        fill: 'tozeroy',
        fillcolor: 'rgba(0, 229, 255, 0.08)',
        line: { color: '#00e5ff', width: 2 },
        yaxis: 'y1',
      } as any);
    } else {
      traces.push({
        x: dates,
        y: closes,
        type: 'scatter',
        mode: 'lines',
        name: ticker,
        line: { color: '#00e5ff', width: 2 },
        yaxis: 'y1',
      } as any);
    }

    // Moving Averages
    if (showSMA20) {
      traces.push({
        x: dates,
        y: history.map((b) => b.sma20),
        type: 'scatter',
        mode: 'lines',
        name: 'SMA 20',
        line: { color: '#38bdf8', width: 1.2 },
        yaxis: 'y1',
      } as any);
    }
    if (showSMA50) {
      traces.push({
        x: dates,
        y: history.map((b) => b.sma50),
        type: 'scatter',
        mode: 'lines',
        name: 'SMA 50',
        line: { color: '#f59e0b', width: 1.4 },
        yaxis: 'y1',
      } as any);
    }
    if (showSMA200) {
      traces.push({
        x: dates,
        y: history.map((b) => b.sma200),
        type: 'scatter',
        mode: 'lines',
        name: 'SMA 200',
        line: { color: '#a855f7', width: 1.6 },
        yaxis: 'y1',
      } as any);
    }

    // Bollinger Bands
    if (showBB) {
      traces.push({
        x: dates,
        y: history.map((b) => b.bbUpper),
        type: 'scatter',
        mode: 'lines',
        name: 'BB Upper',
        line: { color: 'rgba(148, 163, 184, 0.5)', width: 1, dash: 'dot' },
        yaxis: 'y1',
      } as any);
      traces.push({
        x: dates,
        y: history.map((b) => b.bbLower),
        type: 'scatter',
        mode: 'lines',
        name: 'BB Lower',
        line: { color: 'rgba(148, 163, 184, 0.5)', width: 1, dash: 'dot' },
        fill: 'tonexty',
        fillcolor: 'rgba(148, 163, 184, 0.05)',
        yaxis: 'y1',
      } as any);
    }

    // Sub-Indicator Plot 1: Volume
    const volumeColors = history.map((b, i) =>
      i === 0 || b.close >= history[i - 1].close ? 'rgba(16, 185, 129, 0.4)' : 'rgba(239, 68, 68, 0.4)'
    );

    traces.push({
      x: dates,
      y: volumes,
      type: 'bar',
      name: 'Volume',
      marker: { color: volumeColors },
      yaxis: 'y2',
    } as any);

    // Sub-Indicator Plot 2: Secondary oscillator
    if (subIndicator === 'VOLUME_MACD') {
      traces.push({
        x: dates,
        y: history.map((b) => b.macd),
        type: 'scatter',
        mode: 'lines',
        name: 'MACD (12,26)',
        line: { color: '#00e5ff', width: 1.2 },
        yaxis: 'y3',
      } as any);
      traces.push({
        x: dates,
        y: history.map((b) => b.macdSignal),
        type: 'scatter',
        mode: 'lines',
        name: 'Signal (9)',
        line: { color: '#f59e0b', width: 1.2 },
        yaxis: 'y3',
      } as any);
      traces.push({
        x: dates,
        y: history.map((b) => b.macdHist),
        type: 'bar',
        name: 'Histogram',
        marker: {
          color: history.map((b) => ((b.macdHist || 0) >= 0 ? '#10b981' : '#ef4444')),
        },
        yaxis: 'y3',
      } as any);
    } else if (subIndicator === 'VOLUME_RSI') {
      traces.push({
        x: dates,
        y: history.map((b) => b.rsi),
        type: 'scatter',
        mode: 'lines',
        name: 'RSI (14)',
        line: { color: '#a855f7', width: 1.5 },
        yaxis: 'y3',
      } as any);
      // Overbought 70 & Oversold 30 reference lines
      traces.push({
        x: [dates[0], dates[dates.length - 1]],
        y: [70, 70],
        type: 'scatter',
        mode: 'lines',
        name: 'Overbought (70)',
        line: { color: 'rgba(239, 68, 68, 0.4)', dash: 'dot', width: 1 },
        yaxis: 'y3',
      } as any);
      traces.push({
        x: [dates[0], dates[dates.length - 1]],
        y: [30, 30],
        type: 'scatter',
        mode: 'lines',
        name: 'Oversold (30)',
        line: { color: 'rgba(16, 185, 129, 0.4)', dash: 'dot', width: 1 },
        yaxis: 'y3',
      } as any);
    } else if (subIndicator === 'ATR') {
      traces.push({
        x: dates,
        y: history.map((b) => b.atr),
        type: 'scatter',
        mode: 'lines',
        name: 'ATR (14)',
        line: { color: '#eab308', width: 1.5 },
        yaxis: 'y3',
      } as any);
    }

    const hasSubOscillator = subIndicator !== 'VOLUME_ONLY';

    const layout: Partial<Plotly.Layout> = {
      paper_bgcolor: '#0F172A',
      plot_bgcolor: '#0B0F19',
      font: { family: 'ui-sans-serif, system-ui, sans-serif', color: '#94A3B8', size: 10 },
      margin: { l: 50, r: 20, b: 35, t: 25 },
      showlegend: true,
      legend: {
        orientation: 'h',
        x: 0,
        y: 1.06,
        font: { color: '#CBD5E1', size: 10 },
      },
      grid: {
        rows: hasSubOscillator ? 3 : 2,
        columns: 1,
        subplots: hasSubOscillator ? [['xy1'], ['xy2'], ['xy3']] : [['xy1'], ['xy2']],
        roworder: 'top to bottom',
      },
      xaxis: {
        rangeslider: { visible: false },
        gridcolor: '#1E293B',
        zerolinecolor: '#334155',
        tickfont: { color: '#94A3B8' },
      },
      yaxis: {
        title: { text: 'Price (USD)', font: { color: '#CBD5E1', size: 11 } },
        gridcolor: '#1E293B',
        zerolinecolor: '#334155',
        domain: hasSubOscillator ? [0.45, 1.0] : [0.3, 1.0],
        tickfont: { color: '#94A3B8' },
      },
      yaxis2: {
        title: { text: 'Vol', font: { color: '#64748B', size: 9 } },
        gridcolor: '#1E293B',
        domain: hasSubOscillator ? [0.25, 0.42] : [0.0, 0.28],
        showticklabels: true,
        tickfont: { color: '#64748B' },
      },
      ...(hasSubOscillator && {
        yaxis3: {
          title: {
            text: subIndicator === 'VOLUME_MACD' ? 'MACD' : subIndicator === 'VOLUME_RSI' ? 'RSI' : 'ATR',
            font: { color: '#64748B', size: 9 },
          },
          gridcolor: '#1E293B',
          domain: [0.0, 0.22],
          tickfont: { color: '#64748B' },
        },
      }),
      hovermode: 'x unified',
      hoverlabel: {
        bgcolor: '#0B0F19',
        bordercolor: '#00E5FF',
        font: { color: '#F8FAFC', size: 11 },
      },
    };

    Plotly.newPlot(containerRef.current, traces, layout, {
      responsive: true,
      displayModeBar: true,
      modeBarButtonsToRemove: ['lasso2d', 'select2d'],
      displaylogo: false,
    });

    const handleResize = () => {
      if (containerRef.current) {
        Plotly.Plots.resize(containerRef.current);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [ticker, history, chartType, showSMA20, showSMA50, showSMA200, showBB, subIndicator]);

  return (
    <div className="flex flex-col h-full bg-[#0F172A] rounded-sm border border-[#1E293B] p-4" id="candlestick-chart-wrapper">
      {/* Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-[#1E293B] text-xs font-mono">
        <div className="flex items-center gap-1 bg-[#0B1222] p-1 rounded-xs border border-[#1E293B]">
          <span className="text-[#64748B] font-mono px-1 font-semibold text-[11px]">Type:</span>
          {(['candlestick', 'ohlc', 'line', 'area'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setChartType(t)}
              className={`px-2 py-0.5 rounded-xs uppercase text-[10px] tracking-wider transition-colors ${
                chartType === t ? 'bg-[#00E5FF]/20 text-[#00E5FF] font-bold border border-[#00E5FF]/40' : 'text-[#94A3B8] hover:text-white'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3 bg-[#0B1222] px-2.5 py-1 rounded-xs border border-[#1E293B]">
          <span className="text-[#64748B] font-mono text-[11px]">Overlays:</span>
          <label className="flex items-center gap-1 cursor-pointer text-[#00E5FF]">
            <input type="checkbox" checked={showSMA20} onChange={(e) => setShowSMA20(e.target.checked)} className="rounded-xs accent-[#00E5FF]" />
            <span>SMA20</span>
          </label>
          <label className="flex items-center gap-1 cursor-pointer text-[#F59E0B]">
            <input type="checkbox" checked={showSMA50} onChange={(e) => setShowSMA50(e.target.checked)} className="rounded-xs accent-[#F59E0B]" />
            <span>SMA50</span>
          </label>
          <label className="flex items-center gap-1 cursor-pointer text-[#A855F7]">
            <input type="checkbox" checked={showSMA200} onChange={(e) => setShowSMA200(e.target.checked)} className="rounded-xs accent-[#A855F7]" />
            <span>SMA200</span>
          </label>
          <label className="flex items-center gap-1 cursor-pointer text-[#CBD5E1]">
            <input type="checkbox" checked={showBB} onChange={(e) => setShowBB(e.target.checked)} className="rounded-xs accent-[#94A3B8]" />
            <span>Bollinger</span>
          </label>
        </div>

        <div className="flex items-center gap-1 bg-[#0B1222] p-1 rounded-xs border border-[#1E293B]">
          <span className="text-[#64748B] font-mono px-1 text-[11px]">Sub-Oscillator:</span>
          {[
            { id: 'VOLUME_MACD', label: 'MACD (12,26)' },
            { id: 'VOLUME_RSI', label: 'RSI (14)' },
            { id: 'ATR', label: 'ATR (14)' },
            { id: 'VOLUME_ONLY', label: 'Vol Only' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setSubIndicator(item.id as any)}
              className={`px-2 py-0.5 rounded-xs text-[10px] uppercase transition-colors ${
                subIndicator === item.id ? 'bg-[#00E5FF]/20 text-[#00E5FF] font-bold border border-[#00E5FF]/40' : 'text-[#94A3B8] hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Chart Container */}
      <div ref={containerRef} className="w-full flex-1 min-h-[460px]" id="plotly-candlestick-canvas" />
    </div>
  );
};
