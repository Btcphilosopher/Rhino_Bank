/**
 * RHINOSTOCKS
 * RHINOBANK PROPRIETARY EQUITY MARKET ANALYTICS SYSTEM
 * Flagship Institutional Workspace
 */

import React, { useState, useMemo } from 'react';
import { MarketDataStore } from './services/marketData';
import { ActiveTab, Navigation } from './components/Navigation';
import { Header } from './components/Header';
import { GlobalTerminalView } from './views/GlobalTerminalView';
import { UniversalXYZEngineView } from './views/UniversalXYZEngineView';
import { SecurityDeepDiveView } from './views/SecurityDeepDiveView';
import { SectorsIndustriesView } from './views/SectorsIndustriesView';
import { FactorResearchView } from './views/FactorResearchView';
import { CorrelationRiskView } from './views/CorrelationRiskView';
import { RegimeAnomalyView } from './views/RegimeAnomalyView';
import { ScreenerScoringView } from './views/ScreenerScoringView';
import { ComparisonPortfolioView } from './views/ComparisonPortfolioView';
import { RConsoleResearchView } from './views/RConsoleResearchView';
import { RoleType, Sector } from './types';
import { ShieldCheck, Cpu, Database, Server, RefreshCw } from 'lucide-react';

export default function App() {
  const store = MarketDataStore;

  const [activeTab, setActiveTab] = useState<ActiveTab>('TERMINAL');
  const [selectedStockTicker, setSelectedStockTicker] = useState<string>('NVDA');
  const [selectedSector, setSelectedSector] = useState<Sector>('Technology');
  const [currentRole, setCurrentRole] = useState<RoleType>('EQUITY RESEARCH');

  const stocks = store.getStocks();
  const indices = store.getIndices();
  const breadth = store.getBreadth();
  const regime = store.getRegime();
  const sectors = store.getSectors();
  const countries = store.getCountries();
  const concentration = store.getConcentration();
  const anomalies = store.getAnomalies();

  const selectedStock = store.getStockByTicker(selectedStockTicker) || stocks[0];

  // Handler to select and immediately navigate to a security
  const handleSelectStock = (ticker: string) => {
    setSelectedStockTicker(ticker);
    setActiveTab('SECURITY_DEEP_DIVE');
  };

  // Handler to select and navigate to a sector
  const handleSelectSector = (sector: Sector) => {
    setSelectedSector(sector);
    setActiveTab('SECTORS_INDUSTRIES');
  };

  // Switch tabs when role changes
  const handleSelectRole = (role: RoleType) => {
    setCurrentRole(role);
    if (role === 'QUANT') setActiveTab('XYZ_ENGINE');
    else if (role === 'EQUITY RESEARCH') setActiveTab('SECURITY_DEEP_DIVE');
    else if (role === 'RISK') setActiveTab('CORRELATION_RISK');
    else if (role === 'MACRO' || role === 'MARKET STRATEGY') setActiveTab('REGIME_ANOMALY');
    else if (role === 'FACTOR RESEARCH') setActiveTab('FACTOR_RESEARCH');
    else if (role === 'PORTFOLIO') setActiveTab('COMPARISON_PORTFOLIO');
    else if (role === 'DIVIDENDS') setActiveTab('SCREENER_SCORING');
    else setActiveTab('TERMINAL');
  };

  return (
    <div className="min-h-screen bg-[#0B0F19] text-[#CBD5E1] font-sans flex flex-col selection:bg-[#00E5FF] selection:text-[#0B0F19]">
      {/* Institutional Top Header */}
      <Header
        indices={indices}
        stocks={stocks}
        currentRole={currentRole}
        onSelectRole={handleSelectRole}
        onSelectStock={handleSelectStock}
      />

      {/* Primary Division Navigation Bar */}
      <Navigation
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        selectedStockTicker={selectedStockTicker}
      />

      {/* Main Analytical View Area */}
      <main className="flex-1 w-full pb-8">
        {activeTab === 'TERMINAL' && (
          <GlobalTerminalView
            indices={indices}
            stocks={stocks}
            breadth={breadth}
            regime={regime}
            sectors={sectors}
            countries={countries}
            concentration={concentration}
            anomalies={anomalies}
            onSelectStock={handleSelectStock}
            onSelectSector={handleSelectSector}
          />
        )}

        {activeTab === 'XYZ_ENGINE' && (
          <UniversalXYZEngineView
            stocks={stocks}
            onSelectStock={handleSelectStock}
            selectedStockTicker={selectedStockTicker}
          />
        )}

        {activeTab === 'SECURITY_DEEP_DIVE' && (
          <SecurityDeepDiveView
            stock={selectedStock}
            allStocks={stocks}
            onSelectStock={handleSelectStock}
          />
        )}

        {activeTab === 'SECTORS_INDUSTRIES' && (
          <SectorsIndustriesView
            sectors={sectors}
            stocks={stocks}
            selectedSector={selectedSector}
            onSelectSector={setSelectedSector}
            onSelectStock={handleSelectStock}
          />
        )}

        {activeTab === 'FACTOR_RESEARCH' && (
          <FactorResearchView
            stocks={stocks}
            onSelectStock={handleSelectStock}
          />
        )}

        {activeTab === 'CORRELATION_RISK' && (
          <CorrelationRiskView
            stocks={stocks}
            onSelectStock={handleSelectStock}
          />
        )}

        {activeTab === 'REGIME_ANOMALY' && (
          <RegimeAnomalyView
            regime={regime}
            anomalies={anomalies}
            stocks={stocks}
            onSelectStock={handleSelectStock}
          />
        )}

        {activeTab === 'SCREENER_SCORING' && (
          <ScreenerScoringView
            stocks={stocks}
            onSelectStock={handleSelectStock}
          />
        )}

        {activeTab === 'COMPARISON_PORTFOLIO' && (
          <ComparisonPortfolioView
            stocks={stocks}
            onSelectStock={handleSelectStock}
          />
        )}

        {activeTab === 'R_CONSOLE_RESEARCH' && (
          <RConsoleResearchView />
        )}
      </main>

      {/* Sleek Institutional Audit & Provenance Footer */}
      <footer className="flex flex-wrap items-center justify-between px-4 py-2 bg-[#0F172A] border-t border-[#1E293B] text-[10px] text-[#64748B] font-mono select-none">
        <div className="flex flex-wrap items-center space-x-4">
          <span>MODEL: RHINO-Q-CORE-V4.2</span>
          <span className="text-[#334155]">|</span>
          <span>UNIVERSE: GLOBAL-EQUITY-L1 (60 ASSETS)</span>
          <span className="text-[#334155]">|</span>
          <span>LAST RECALC: 14:32:00 GMT</span>
          <span className="text-[#334155]">|</span>
          <span>LOOKBACK: 252 TRADING DAYS</span>
        </div>

        <div className="flex items-center space-x-4">
          <span>USER: ANALYST_742</span>
          <span className="text-[#334155]">|</span>
          <span className="text-[#10B981] font-bold">● CONNECTION SECURE</span>
        </div>
      </footer>
    </div>
  );
}
