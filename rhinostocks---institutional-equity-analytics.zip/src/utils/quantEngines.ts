/**
 * RhinoStocks - Quantitative Analytics Engine
 * RhinoBank Proprietary Financial Mathematics, Econometrics & Risk Algorithms
 */

import { PriceBar, FactorExposures, MarketRegimeType, Sector } from '../types';

// ==========================================
// 1. BASIC STATISTICS & REGRESSION
// ==========================================

export function mean(values: number[]): number {
  if (!values.length) return 0;
  return values.reduce((sum, v) => sum + v, 0) / values.length;
}

export function median(values: number[]): number {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

export function variance(values: number[], sample = true): number {
  if (values.length <= 1) return 0;
  const avg = mean(values);
  const sumSq = values.reduce((acc, v) => acc + Math.pow(v - avg, 2), 0);
  return sumSq / (values.length - (sample ? 1 : 0));
}

export function standardDeviation(values: number[], sample = true): number {
  return Math.sqrt(variance(values, sample));
}

export function skewness(values: number[]): number {
  if (values.length < 3) return 0;
  const avg = mean(values);
  const sd = standardDeviation(values);
  if (sd === 0) return 0;
  const n = values.length;
  const m3 = values.reduce((acc, v) => acc + Math.pow(v - avg, 3), 0) / n;
  return (m3 / Math.pow(sd, 3)) * (Math.sqrt(n * (n - 1)) / (n - 2));
}

export function kurtosis(values: number[]): number {
  if (values.length < 4) return 0;
  const avg = mean(values);
  const sd = standardDeviation(values);
  if (sd === 0) return 0;
  const n = values.length;
  const m4 = values.reduce((acc, v) => acc + Math.pow(v - avg, 4), 0) / n;
  // Excess kurtosis (relative to normal distribution = 0)
  return (m4 / Math.pow(sd, 4)) - 3;
}

export function covariance(x: number[], y: number[]): number {
  const n = Math.min(x.length, y.length);
  if (n <= 1) return 0;
  const avgX = mean(x.slice(0, n));
  const avgY = mean(y.slice(0, n));
  let sum = 0;
  for (let i = 0; i < n; i++) {
    sum += (x[i] - avgX) * (y[i] - avgY);
  }
  return sum / (n - 1);
}

export function pearsonCorrelation(x: number[], y: number[]): number {
  const n = Math.min(x.length, y.length);
  if (n <= 1) return 0;
  const sdX = standardDeviation(x.slice(0, n));
  const sdY = standardDeviation(y.slice(0, n));
  if (sdX === 0 || sdY === 0) return 0;
  const cov = covariance(x, y);
  const r = cov / (sdX * sdY);
  return Math.max(-1, Math.min(1, r));
}

export function spearmanCorrelation(x: number[], y: number[]): number {
  const n = Math.min(x.length, y.length);
  if (n <= 1) return 0;

  const rank = (arr: number[]) => {
    const sorted = arr.map((v, i) => ({ v, i })).sort((a, b) => a.v - b.v);
    const ranks = new Array(arr.length);
    for (let r = 0; r < sorted.length; r++) {
      ranks[sorted[r].i] = r + 1;
    }
    return ranks;
  };

  const rx = rank(x.slice(0, n));
  const ry = rank(y.slice(0, n));
  return pearsonCorrelation(rx, ry);
}

export function linearRegression(x: number[], y: number[]): { slope: number; intercept: number; r2: number } {
  const n = Math.min(x.length, y.length);
  if (n <= 1) return { slope: 0, intercept: 0, r2: 0 };
  const avgX = mean(x.slice(0, n));
  const avgY = mean(y.slice(0, n));
  const cov = covariance(x, y);
  const varX = variance(x.slice(0, n));
  if (varX === 0) return { slope: 0, intercept: avgY, r2: 0 };
  const slope = cov / varX;
  const intercept = avgY - slope * avgX;
  const r = pearsonCorrelation(x, y);
  return { slope, intercept, r2: Math.pow(r, 2) };
}

// ==========================================
// 2. RISK, VOLATILITY & DRAWDOWN
// ==========================================

export function calculateRealizedVol(returns: number[], periodsPerYear = 252): number {
  if (returns.length < 2) return 0;
  return standardDeviation(returns) * Math.sqrt(periodsPerYear);
}

export function calculateDownsideVol(returns: number[], target = 0, periodsPerYear = 252): number {
  const downside = returns.filter((r) => r < target).map((r) => Math.pow(r - target, 2));
  if (!downside.length) return 0;
  const meanDownside = downside.reduce((a, b) => a + b, 0) / returns.length;
  return Math.sqrt(meanDownside) * Math.sqrt(periodsPerYear);
}

export function calculateEWMAVol(returns: number[], lambda = 0.94, periodsPerYear = 252): number {
  if (returns.length < 2) return 0;
  let variance = Math.pow(returns[0], 2);
  for (let i = 1; i < returns.length; i++) {
    variance = lambda * variance + (1 - lambda) * Math.pow(returns[i], 2);
  }
  return Math.sqrt(variance) * Math.sqrt(periodsPerYear);
}

export function calculateDrawdown(prices: number[]): {
  drawdowns: number[];
  maxDrawdown: number;
  currentDrawdown: number;
  peakIndex: number;
  troughIndex: number;
} {
  if (!prices.length) return { drawdowns: [], maxDrawdown: 0, currentDrawdown: 0, peakIndex: 0, troughIndex: 0 };
  let peak = prices[0];
  let peakIdx = 0;
  let maxDD = 0;
  let maxPeakIdx = 0;
  let maxTroughIdx = 0;
  const drawdowns: number[] = [];

  for (let i = 0; i < prices.length; i++) {
    if (prices[i] > peak) {
      peak = prices[i];
      peakIdx = i;
    }
    const dd = (prices[i] - peak) / peak;
    drawdowns.push(dd);
    if (dd < maxDD) {
      maxDD = dd;
      maxPeakIdx = peakIdx;
      maxTroughIdx = i;
    }
  }

  const currentDrawdown = drawdowns[drawdowns.length - 1];
  return {
    drawdowns,
    maxDrawdown: maxDD,
    currentDrawdown,
    peakIndex: maxPeakIdx,
    troughIndex: maxTroughIdx,
  };
}

export function calculateVaR(returns: number[], confidence = 0.95): { parametricVaR: number; historicalVaR: number; cvar: number } {
  if (!returns.length) return { parametricVaR: 0, historicalVaR: 0, cvar: 0 };
  const sorted = [...returns].sort((a, b) => a - b);
  const index = Math.floor((1 - confidence) * sorted.length);
  const historicalVaR = Math.abs(sorted[index] || 0);

  // Expected Shortfall (CVaR)
  const tail = sorted.slice(0, Math.max(1, index));
  const cvar = Math.abs(mean(tail));

  // Parametric normal distribution approximation (1.645 for 95%, 2.326 for 99%)
  const z = confidence === 0.99 ? 2.326 : 1.645;
  const avg = mean(returns);
  const sd = standardDeviation(returns);
  const parametricVaR = Math.max(0, z * sd - avg);

  return { parametricVaR, historicalVaR, cvar };
}

export function calculatePerformanceMetrics(
  returns: number[],
  benchmarkReturns: number[],
  riskFreeRate = 0.04
): {
  beta: number;
  alpha: number;
  r2: number;
  sharpe: number;
  sortino: number;
  trackingError: number;
  informationRatio: number;
} {
  const n = Math.min(returns.length, benchmarkReturns.length);
  if (n < 5) {
    return { beta: 1, alpha: 0, r2: 0, sharpe: 0, sortino: 0, trackingError: 0, informationRatio: 0 };
  }

  const stockR = returns.slice(-n);
  const benchR = benchmarkReturns.slice(-n);

  const reg = linearRegression(benchR, stockR);
  const annualizedMean = mean(stockR) * 252;
  const annualizedBenchMean = mean(benchR) * 252;
  const annualizedVol = standardDeviation(stockR) * Math.sqrt(252);
  const downsideVol = calculateDownsideVol(stockR, 0, 252);

  // Sharpe & Sortino
  const sharpe = annualizedVol > 0 ? (annualizedMean - riskFreeRate) / annualizedVol : 0;
  const sortino = downsideVol > 0 ? (annualizedMean - riskFreeRate) / downsideVol : 0;

  // Tracking Error & Information Ratio
  const excessReturns = stockR.map((r, i) => r - benchR[i]);
  const trackingError = standardDeviation(excessReturns) * Math.sqrt(252);
  const excessMean = annualizedMean - annualizedBenchMean;
  const informationRatio = trackingError > 0 ? excessMean / trackingError : 0;

  // Jensen's Alpha (annualized)
  const alpha = annualizedMean - (riskFreeRate + reg.slope * (annualizedBenchMean - riskFreeRate));

  return {
    beta: Number(reg.slope.toFixed(3)),
    alpha: Number((alpha * 100).toFixed(2)),
    r2: Number(reg.r2.toFixed(3)),
    sharpe: Number(sharpe.toFixed(2)),
    sortino: Number(sortino.toFixed(2)),
    trackingError: Number((trackingError * 100).toFixed(2)),
    informationRatio: Number(informationRatio.toFixed(2)),
  };
}

// ==========================================
// 3. TECHNICAL INDICATORS
// ==========================================

export function calculateSMA(data: number[], period: number): number[] {
  const result: number[] = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      result.push(data[i]);
    } else {
      const window = data.slice(i - period + 1, i + 1);
      result.push(mean(window));
    }
  }
  return result;
}

export function calculateEMA(data: number[], period: number): number[] {
  const result: number[] = [];
  const k = 2 / (period + 1);
  let prevEMA = data[0] || 0;
  for (let i = 0; i < data.length; i++) {
    if (i === 0) {
      result.push(data[0]);
    } else {
      const currentEMA = data[i] * k + prevEMA * (1 - k);
      result.push(currentEMA);
      prevEMA = currentEMA;
    }
  }
  return result;
}

export function calculateRSI(closes: number[], period = 14): number[] {
  const rsi: number[] = [];
  if (closes.length < period) return closes.map(() => 50);

  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {
    const change = closes[i] - closes[i - 1];
    if (change >= 0) gains += change;
    else losses += Math.abs(change);
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  for (let i = 0; i < period; i++) {
    rsi.push(50);
  }

  let rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
  rsi.push(100 - 100 / (1 + rs));

  for (let i = period + 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    const gain = change >= 0 ? change : 0;
    const loss = change < 0 ? Math.abs(change) : 0;

    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;

    rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
    rsi.push(100 - 100 / (1 + rs));
  }

  return rsi;
}

export function calculateMACD(
  closes: number[],
  fastPeriod = 12,
  slowPeriod = 26,
  signalPeriod = 9
): { macd: number[]; signal: number[]; hist: number[] } {
  const fastEMA = calculateEMA(closes, fastPeriod);
  const slowEMA = calculateEMA(closes, slowPeriod);
  const macdLine = fastEMA.map((f, i) => f - slowEMA[i]);
  const signalLine = calculateEMA(macdLine, signalPeriod);
  const hist = macdLine.map((m, i) => m - signalLine[i]);

  return { macd: macdLine, signal: signalLine, hist };
}

export function calculateBollingerBands(
  closes: number[],
  period = 20,
  stdDevMult = 2
): { upper: number[]; middle: number[]; lower: number[] } {
  const middle = calculateSMA(closes, period);
  const upper: number[] = [];
  const lower: number[] = [];

  for (let i = 0; i < closes.length; i++) {
    if (i < period - 1) {
      upper.push(closes[i]);
      lower.push(closes[i]);
    } else {
      const window = closes.slice(i - period + 1, i + 1);
      const sd = standardDeviation(window);
      upper.push(middle[i] + stdDevMult * sd);
      lower.push(middle[i] - stdDevMult * sd);
    }
  }

  return { upper, middle, lower };
}

export function calculateATR(highs: number[], lows: number[], closes: number[], period = 14): number[] {
  const tr: number[] = [highs[0] - lows[0]];
  for (let i = 1; i < highs.length; i++) {
    const highLow = highs[i] - lows[i];
    const highPrevClose = Math.abs(highs[i] - closes[i - 1]);
    const lowPrevClose = Math.abs(lows[i] - closes[i - 1]);
    tr.push(Math.max(highLow, highPrevClose, lowPrevClose));
  }
  return calculateEMA(tr, period);
}

// ==========================================
// 4. PRINCIPAL COMPONENT ANALYSIS (PCA)
// ==========================================

export function runPCA(
  matrix: number[][], // rows = observations, cols = variables (e.g. stock return series)
  numComponents = 3
): {
  eigenvalues: number[];
  explainedVariance: number[];
  cumulativeVariance: number[];
  loadings: number[][]; // components x variables
  scores: number[][]; // observations x components
} {
  const numObs = matrix.length;
  if (!numObs) return { eigenvalues: [], explainedVariance: [], cumulativeVariance: [], loadings: [], scores: [] };
  const numVars = matrix[0].length;

  // Standardize columns
  const means: number[] = [];
  const sds: number[] = [];
  for (let j = 0; j < numVars; j++) {
    const col = matrix.map((row) => row[j]);
    means.push(mean(col));
    sds.push(standardDeviation(col) || 1);
  }

  const standardized: number[][] = matrix.map((row) =>
    row.map((val, j) => (val - means[j]) / sds[j])
  );

  // Compute Correlation Matrix
  const corrMatrix: number[][] = Array(numVars)
    .fill(0)
    .map(() => Array(numVars).fill(0));

  for (let i = 0; i < numVars; i++) {
    for (let j = i; j < numVars; j++) {
      if (i === j) {
        corrMatrix[i][j] = 1.0;
      } else {
        const colI = standardized.map((r) => r[i]);
        const colJ = standardized.map((r) => r[j]);
        const r = pearsonCorrelation(colI, colJ);
        corrMatrix[i][j] = r;
        corrMatrix[j][i] = r;
      }
    }
  }

  // Power iteration method to approximate top Eigenvectors
  const eigenvalues: number[] = [];
  const loadings: number[][] = [];
  let deflatedMatrix = corrMatrix.map((r) => [...r]);

  for (let comp = 0; comp < Math.min(numComponents, numVars); comp++) {
    let vec = Array(numVars).fill(1 / Math.sqrt(numVars));
    for (let iter = 0; iter < 40; iter++) {
      // Multiply deflatedMatrix * vec
      const nextVec: number[] = Array(numVars).fill(0);
      for (let i = 0; i < numVars; i++) {
        for (let j = 0; j < numVars; j++) {
          nextVec[i] += deflatedMatrix[i][j] * vec[j];
        }
      }
      // Normalize
      const norm = Math.sqrt(nextVec.reduce((acc, v) => acc + v * v, 0)) || 1;
      vec = nextVec.map((v) => v / norm);
    }

    // Compute Eigenvalue
    let eigenvalue = 0;
    for (let i = 0; i < numVars; i++) {
      for (let j = 0; j < numVars; j++) {
        eigenvalue += vec[i] * deflatedMatrix[i][j] * vec[j];
      }
    }
    eigenvalues.push(Math.max(0, eigenvalue));
    loadings.push(vec);

    // Deflate matrix: A_next = A - lambda * v * v^T
    for (let i = 0; i < numVars; i++) {
      for (let j = 0; j < numVars; j++) {
        deflatedMatrix[i][j] -= eigenvalue * vec[i] * vec[j];
      }
    }
  }

  const totalVar = numVars;
  const explainedVariance = eigenvalues.map((ev) => ev / totalVar);
  let cum = 0;
  const cumulativeVariance = explainedVariance.map((ev) => {
    cum += ev;
    return cum;
  });

  // Calculate scores (Standardized * Loadings^T)
  const scores: number[][] = standardized.map((row) =>
    loadings.map((loading) => loading.reduce((acc, l, j) => acc + l * row[j], 0))
  );

  return { eigenvalues, explainedVariance, cumulativeVariance, loadings, scores };
}

// ==========================================
// 5. SECTOR ROTATION & RELATIVE STRENGTH (RRG)
// ==========================================

export function calculateSectorRotationMetrics(
  sectorPrices: { [key in Sector]?: number[] },
  benchmarkPrices: number[]
): { [key in Sector]?: { rsRatio: number; rsMomentum: number; state: 'LEADING' | 'IMPROVING' | 'WEAKENING' | 'LAGGING' } } {
  const result: { [key in Sector]?: { rsRatio: number; rsMomentum: number; state: 'LEADING' | 'IMPROVING' | 'WEAKENING' | 'LAGGING' } } = {};
  const len = benchmarkPrices.length;
  if (len < 30) return result;

  Object.entries(sectorPrices).forEach(([sec, prices]) => {
    if (!prices || prices.length < 30) return;
    const relPrices = prices.map((p, i) => (p / (benchmarkPrices[i] || 1)) * 100);
    const rsMA = calculateSMA(relPrices, 14);
    const currRel = relPrices[len - 1];
    const currMA = rsMA[len - 1];
    const rsRatio = 100 + ((currRel - currMA) / currMA) * 100;

    // RS-Momentum: Rate of change of RS-Ratio
    const prevRel = relPrices[len - 10];
    const prevMA = rsMA[len - 10];
    const prevRSRatio = 100 + ((prevRel - prevMA) / prevMA) * 100;
    const rsMomentum = 100 + (rsRatio - prevRSRatio) * 2;

    let state: 'LEADING' | 'IMPROVING' | 'WEAKENING' | 'LAGGING' = 'LEADING';
    if (rsRatio >= 100 && rsMomentum >= 100) state = 'LEADING';
    else if (rsRatio < 100 && rsMomentum >= 100) state = 'IMPROVING';
    else if (rsRatio >= 100 && rsMomentum < 100) state = 'WEAKENING';
    else state = 'LAGGING';

    result[sec as Sector] = {
      rsRatio: Number(rsRatio.toFixed(2)),
      rsMomentum: Number(rsMomentum.toFixed(2)),
      state,
    };
  });

  return result;
}

// ==========================================
// 6. ANOMALY DETECTION ENGINE
// ==========================================

export function evaluateAnomaly(stock: {
  change1D: number;
  changePct1D: number;
  volume: number;
  avgVolume30D: number;
  realizedVol30D: number;
  realizedVol1Y: number;
  pe: number;
  pe5YAvg: number;
  revisionsScore: number;
}): { score: number; isAnomaly: boolean; flags: string[]; zScore: number } {
  const flags: string[] = [];
  let score = 0;

  // 1. Volume spike anomaly
  const volumeRatio = stock.avgVolume30D > 0 ? stock.volume / stock.avgVolume30D : 1;
  if (volumeRatio > 3.0) {
    flags.push(`Extreme Volume Spike (${volumeRatio.toFixed(1)}x 30D avg)`);
    score += 30;
  } else if (volumeRatio > 2.0) {
    flags.push(`Elevated Volume (${volumeRatio.toFixed(1)}x avg)`);
    score += 15;
  }

  // 2. Daily Price Return Outlier
  if (Math.abs(stock.changePct1D) > 6.0) {
    flags.push(`Extreme 1D Price Move (${stock.changePct1D > 0 ? '+' : ''}${stock.changePct1D.toFixed(2)}%)`);
    score += 35;
  } else if (Math.abs(stock.changePct1D) > 3.5) {
    flags.push(`Substantial Price Move (${stock.changePct1D.toFixed(2)}%)`);
    score += 15;
  }

  // 3. Volatility dislocation
  if (stock.realizedVol1Y > 0 && stock.realizedVol30D / stock.realizedVol1Y > 2.2) {
    flags.push(`Volatility Dislocation (30D Vol > 2.2x 1Y Baseline)`);
    score += 20;
  }

  // 4. Valuation Dislocation
  if (stock.pe5YAvg > 0 && Math.abs(stock.pe - stock.pe5YAvg) / stock.pe5YAvg > 0.6) {
    flags.push(`Valuation Dislocation (>60% deviation from 5Y Mean)`);
    score += 15;
  }

  // 5. Revisions divergence
  if (Math.abs(stock.revisionsScore) > 60) {
    flags.push(`Aggressive Analyst Revisions (${stock.revisionsScore > 0 ? 'Bullish' : 'Bearish'} Momentum)`);
    score += 15;
  }

  const finalScore = Math.min(100, score);
  const zScore = Number(((finalScore - 20) / 18).toFixed(2));

  return {
    score: finalScore,
    isAnomaly: finalScore >= 45,
    flags,
    zScore,
  };
}

// ==========================================
// 7. COMPOSITE RHINO EQUITY SCORE
// ==========================================

export interface ScoreWeights {
  value: number;       // default 0.25
  momentum: number;    // default 0.25
  quality: number;     // default 0.25
  growth: number;      // default 0.15
  volatility: number;  // default 0.10
}

export const DEFAULT_WEIGHTS: ScoreWeights = {
  value: 0.25,
  momentum: 0.25,
  quality: 0.25,
  growth: 0.15,
  volatility: 0.10,
};

export function calculateRhinoEquityScore(
  factors: FactorExposures,
  weights: ScoreWeights = DEFAULT_WEIGHTS
): {
  composite: number;
  valueSubscore: number;
  momentumSubscore: number;
  qualitySubscore: number;
  growthSubscore: number;
  volatilitySubscore: number;
} {
  // Convert Z-scores (-3 to +3) to percentile-like score (0-100)
  const zToScore = (z: number) => Math.max(0, Math.min(100, 50 + z * 16.6));

  const valueSubscore = Number(zToScore(factors.value).toFixed(1));
  const momentumSubscore = Number(zToScore(factors.momentum).toFixed(1));
  const qualitySubscore = Number(zToScore(factors.quality).toFixed(1));
  const growthSubscore = Number(zToScore(factors.growth).toFixed(1));
  const volatilitySubscore = Number(zToScore(factors.lowVolatility).toFixed(1));

  const totalWeight = weights.value + weights.momentum + weights.quality + weights.growth + weights.volatility || 1;

  const composite =
    (valueSubscore * weights.value +
      momentumSubscore * weights.momentum +
      qualitySubscore * weights.quality +
      growthSubscore * weights.growth +
      volatilitySubscore * weights.volatility) /
    totalWeight;

  return {
    composite: Number(composite.toFixed(1)),
    valueSubscore,
    momentumSubscore,
    qualitySubscore,
    growthSubscore,
    volatilitySubscore,
  };
}
