/**
 * RhinoStocks - R Quantitative REPL & Governance View
 * Interactive R Script Execution, Quantitative Backtesting & Provenance Verification
 */

import React, { useState } from 'react';
import { executeRhinoRScript } from '../services/marketData';
import {
  Terminal,
  Play,
  RotateCcw,
  ShieldCheck,
  Code,
  FileCode,
  CheckCircle2,
  Clock,
  Cpu,
} from 'lucide-react';

interface RTemplate {
  name: string;
  script: string;
}

const R_TEMPLATES: RTemplate[] = [
  {
    name: '1. Multi-Factor Cross-Sectional OLS Regression',
    script: `# RhinoBank Quantitative Equity Research Division
# Script: factor_regression.R
library(rhino.quant)
library(rhino.data)

# Load cross-sectional 252D equity universe
universe <- load_rhino_universe(universe = "GLOBAL_60")

# Estimate cross-sectional multi-factor OLS model
# Return_1Y ~ Value_Z + Mom_Z + Qual_Z + Growth_Z + Size_Z
model <- lm(return_1y ~ factor_val + factor_mom + factor_qual + factor_growth + factor_size, 
            data = universe)

summary(model)

# Compute Newey-West HAC robust standard errors
hac_se <- coeftest(model, vcov = NeweyWest(model, lag = 5))
print(hac_se)
`,
  },
  {
    name: '2. Cornish-Fisher VaR & Tail Risk Decomposition',
    script: `# RhinoBank Risk Analytics Laboratory
# Script: tail_risk_var.R
library(rhino.risk)

tickers <- c("NVDA", "AAPL", "MSFT", "LLY", "ASML", "BHP")
returns_matrix <- get_returns(tickers, lookback = 252)

# Compute 1st through 4th statistical distribution moments
moments <- apply(returns_matrix, 2, function(r) {
  c(Mean = mean(r), 
    Vol = sd(r) * sqrt(252), 
    Skew = e1071::skewness(r), 
    Kurt = e1071::kurtosis(r))
})
print("=== STATISTICAL RETURN MOMENTS ===")
print(t(moments))

# Calculate Parametric vs Cornish-Fisher 95% 1-Day VaR
cf_var <- rhino.risk::var_cornish_fisher(returns_matrix, alpha = 0.05)
print("=== 95% CORNISH-FISHER VALUE-AT-RISK ===")
print(cf_var)
`,
  },
  {
    name: '3. Hidden Markov Model (HMM) Transition Estimator',
    script: `# RhinoBank Macro Strategy & Regime Modeling
# Script: hmm_regime_fit.R
library(rhino.macro)

spx_data <- get_index_series("SPX", lookback = 1000)

# Fit 5-state Hidden Markov Model with Gaussian emission
hmm_model <- depmix(returns ~ 1, nstates = 5, data = spx_data, family = gaussian())
fitted_hmm <- fit(hmm_model, verbose = FALSE)

# Extract transition probability matrix
trans_mat <- summary(fitted_hmm, which = "transition")
print("=== 5-STATE TRANSITION PROBABILITY MATRIX ===")
print(trans_mat)

# Filter active latent state probability
curr_state <- posterior(fitted_hmm)[nrow(spx_data), ]
print("=== CURRENT REGIME STATE DISTRIBUTION ===")
print(curr_state)
`,
  },
  {
    name: '4. Cumulative Abnormal Return (CAR) Event Study',
    script: `# RhinoBank Event Study Analytics
# Script: car_event_study.R
library(rhino.event)

# Analyze NVDA Blackwell Architecture Announcement
event <- run_event_study(
  ticker = "NVDA",
  event_date = "2024-03-18",
  estimation_window = c(-120, -11),
  event_window = c(-10, 10)
)

print(paste("CAR [-10, +10]:", round(event$car * 100, 2), "%"))
print(paste("t-statistic:", round(event$t_stat, 3)))
print(paste("p-value:", format.pval(event$p_val)))
`,
  },
];

export const RConsoleResearchView: React.FC = () => {
  const [currentScript, setCurrentScript] = useState<string>(R_TEMPLATES[0].script);
  const [consoleOutput, setConsoleOutput] = useState<string>(
    `RhinoBank R Quantitative REPL Kernel v3.7.0 (2026-04-15)\nPlatform: x86_64-rhinobank-linux-gnu (64-bit)\nAudit: Real-time Compliance Verification Active\n\nReady for input. Type code or select institutional template.\n> `
  );
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [executionTime, setExecutionTime] = useState<number | null>(null);
  const [provenanceHash, setProvenanceHash] = useState<string>('c9f8a3e7b102948572d8a6b4c1e0938f2a1b5c4d');

  const handleExecute = () => {
    setIsRunning(true);
    const start = performance.now();

    setTimeout(() => {
      const res = executeRhinoRScript(currentScript);
      const elapsed = Math.round(performance.now() - start);
      setExecutionTime(elapsed);
      setProvenanceHash(res.provenanceHash);
      setConsoleOutput(res.output);
      setIsRunning(false);
    }, 350);
  };

  return (
    <div className="p-4 space-y-4 max-w-[1800px] mx-auto text-[#CBD5E1] font-sans" id="r-console-view">
      {/* Header Banner */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 font-mono text-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 mb-3 border-b border-[#1E293B]">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-[#00E5FF]" />
            <span className="font-bold text-white font-sans text-sm tracking-wide">
              RHINOBANK R QUANTITATIVE RESEARCH CONSOLE & AUDIT PROVENANCE
            </span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-[#64748B]">
            <div className="flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-[#00E5FF]" />
              <span>R Engine: <b className="text-white">v3.7 Multi-Core</b></span>
            </div>
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-[#10B981]" />
              <span>Hash: <b className="text-[#10B981] font-mono text-[10px]">{provenanceHash.slice(0, 12)}...</b></span>
            </div>
          </div>
        </div>

        {/* Script Templates Quick Selector */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <span className="text-[10px] text-[#64748B] font-bold whitespace-nowrap uppercase tracking-widest">
            PRE-COMPILED TEMPLATES:
          </span>
          {R_TEMPLATES.map((tmpl) => (
            <button
              key={tmpl.name}
              onClick={() => setCurrentScript(tmpl.script)}
              className="px-3 py-1.5 bg-[#0B1222] hover:bg-[#1E293B] border border-[#1E293B] rounded-xs text-[#CBD5E1] text-[11px] whitespace-nowrap transition-colors flex items-center gap-1.5"
            >
              <FileCode className="w-3 h-3 text-[#00E5FF]" />
              <span>{tmpl.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main REPL Editor & Terminal Output Split */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 font-mono text-xs">
        {/* R Script Editor */}
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 flex flex-col min-h-[500px]">
          <div className="flex items-center justify-between pb-3 border-b border-[#1E293B]">
            <span className="font-bold text-[#00E5FF] flex items-center gap-1.5 font-sans tracking-wide">
              <Code className="w-4 h-4 text-[#00E5FF]" />
              R SCRIPT EDITOR
            </span>
            <button
              onClick={handleExecute}
              disabled={isRunning}
              className="px-3.5 py-1.5 bg-[#00E5FF] hover:bg-[#00E5FF]/80 text-[#0B0F19] font-bold rounded-xs flex items-center gap-1.5 transition-all disabled:opacity-50 font-sans text-xs"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{isRunning ? 'EXECUTING...' : 'RUN SCRIPT (Ctrl+Enter)'}</span>
            </button>
          </div>

          <textarea
            value={currentScript}
            onChange={(e) => setCurrentScript(e.target.value)}
            className="flex-1 w-full mt-3 p-3 bg-[#0B0F19] border border-[#1E293B] rounded-xs text-[#CBD5E1] font-mono text-xs focus:outline-none focus:border-[#00E5FF] resize-none leading-relaxed"
            spellCheck={false}
          />
        </div>

        {/* Formatted R Stdout / Stderr Terminal Output */}
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 flex flex-col min-h-[500px]">
          <div className="flex items-center justify-between pb-3 border-b border-[#1E293B]">
            <span className="font-bold text-white flex items-center gap-1.5 font-sans tracking-wide">
              <Terminal className="w-4 h-4 text-[#10B981]" />
              R STDOUT / EXECUTION CONSOLE
            </span>
            {executionTime && (
              <span className="text-[10px] text-[#64748B] flex items-center gap-1">
                <Clock className="w-3 h-3 text-[#00E5FF]" />
                Execution time: <b className="text-[#00E5FF]">{executionTime}ms</b>
              </span>
            )}
          </div>

          <pre className="flex-1 w-full mt-3 p-3 bg-[#0B0F19] border border-[#1E293B] rounded-xs text-[#10B981] font-mono text-[11px] overflow-auto whitespace-pre-wrap leading-relaxed">
            {consoleOutput}
          </pre>
        </div>
      </div>
    </div>
  );
};
