/**
 * RhinoStocks - Multi-Stock Comparison & Research Portfolio View
 * Cross-Sectional Matrix Comparison & Hypothetical Research Basket Analytics
 */

import React, { useState } from 'react';
import { RhinoStock } from '../types';
import {
  Scale,
  Plus,
  Trash2,
  PieChart,
  TrendingUp,
  ShieldCheck,
  BarChart2,
  Activity,
} from 'lucide-react';

interface ComparisonPortfolioViewProps {
  stocks: RhinoStock[];
  onSelectStock: (ticker: string) => void;
}

interface PortfolioPosition {
  ticker: string;
  weight: number;
}

export const ComparisonPortfolioView: React.FC<ComparisonPortfolioViewProps> = ({
  stocks,
  onSelectStock,
}) => {
  // Selected comparison tickers
  const [compTickers, setCompTickers] = useState<string[]>(['NVDA', 'AAPL', 'MSFT', 'LLY']);

  // Research Portfolio positions
  const [portfolio, setPortfolio] = useState<PortfolioPosition[]>([
    { ticker: 'NVDA', weight: 30 },
    { ticker: 'MSFT', weight: 25 },
    { ticker: 'LLY', weight: 25 },
    { ticker: 'ASML', weight: 20 },
  ]);

  const [newTickerToAdd, setNewTickerToAdd] = useState<string>('BHP');

  const compStocks = compTickers
    .map((t) => stocks.find((s) => s.ticker === t))
    .filter((s): s is RhinoStock => !!s);

  // Portfolio analytics calculation
  const totalWeight = portfolio.reduce((sum, p) => sum + p.weight, 0);
  const normalizedPositions = portfolio.map((p) => ({
    ...p,
    normWeight: totalWeight > 0 ? p.weight / totalWeight : 0,
    stock: stocks.find((s) => s.ticker === p.ticker),
  }));

  const weighted1YReturn = normalizedPositions.reduce(
    (sum, p) => sum + (p.stock?.returns['1Y'] || 0) * p.normWeight,
    0
  );

  const weightedPE = normalizedPositions.reduce(
    (sum, p) => sum + (p.stock?.valuation.pe || 0) * p.normWeight,
    0
  );

  const weightedROIC = normalizedPositions.reduce(
    (sum, p) => sum + (p.stock?.fundamentals.roic || 0) * p.normWeight,
    0
  );

  const weightedVol = normalizedPositions.reduce(
    (sum, p) => sum + (p.stock?.risk.realizedVol1Y || 0) * p.normWeight,
    0
  );

  // Approximate portfolio Sharpe (Rf=4%)
  const portfolioSharpe = weightedVol > 0 ? (weighted1YReturn - 4.0) / weightedVol : 0;

  const handleAddStockToComp = (ticker: string) => {
    if (!compTickers.includes(ticker) && compTickers.length < 6) {
      setCompTickers([...compTickers, ticker]);
    }
  };

  const handleRemoveComp = (ticker: string) => {
    setCompTickers(compTickers.filter((t) => t !== ticker));
  };

  const handleAddPortfolio = (ticker: string) => {
    if (!portfolio.some((p) => p.ticker === ticker)) {
      setPortfolio([...portfolio, { ticker, weight: 15 }]);
    }
  };

  const handleUpdateWeight = (ticker: string, weight: number) => {
    setPortfolio(
      portfolio.map((p) => (p.ticker === ticker ? { ...p, weight: Math.max(0, weight) } : p))
    );
  };

  const handleRemovePortfolio = (ticker: string) => {
    setPortfolio(portfolio.filter((p) => p.ticker !== ticker));
  };

  return (
    <div className="p-4 space-y-4 max-w-[1800px] mx-auto text-[#CBD5E1] font-sans" id="comparison-portfolio-view">
      {/* SECTION 1: SIDE-BY-SIDE MULTI-STOCK COMPARISON MATRIX */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 font-mono text-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1E293B] pb-3">
          <div className="flex items-center gap-2">
            <Scale className="w-4 h-4 text-[#00E5FF]" />
            <span className="font-bold text-white font-sans text-sm tracking-wide">
              CROSS-SECTIONAL MULTI-EQUITY PEER MATRIX COMPARISON
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] text-[#64748B] uppercase font-bold tracking-widest">Add Security:</span>
            <select
              value={newTickerToAdd}
              onChange={(e) => setNewTickerToAdd(e.target.value)}
              className="bg-[#0B0F19] border border-[#334155] rounded-xs px-2.5 py-1 text-[#CBD5E1] text-xs focus:outline-none focus:border-[#00E5FF]"
            >
              {stocks.map((s) => (
                <option key={s.ticker} value={s.ticker} className="bg-[#0B0F19]">
                  {s.ticker} - {s.company}
                </option>
              ))}
            </select>
            <button
              onClick={() => handleAddStockToComp(newTickerToAdd)}
              className="px-3 py-1 bg-[#00E5FF]/10 text-[#00E5FF] hover:bg-[#00E5FF]/20 border border-[#00E5FF]/40 rounded-xs font-bold transition-colors flex items-center gap-1 text-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Peer</span>
            </button>
          </div>
        </div>

        {/* Matrix Comparison Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs border border-[#1E293B]">
            <thead>
              <tr className="bg-[#0B0F19] text-[#64748B] text-[10px] uppercase tracking-widest font-bold">
                <th className="py-2.5 px-3 border-r border-[#1E293B] w-52">METRIC / DIMENSION</th>
                {compStocks.map((s) => (
                  <th key={s.ticker} className="py-2.5 px-3 border-r border-[#1E293B] text-center last:border-r-0">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#00E5FF] text-xs">{s.ticker}</span>
                      <button
                        onClick={() => handleRemoveComp(s.ticker)}
                        className="text-[#64748B] hover:text-[#EF4444] text-xs transition-colors"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="text-[10px] text-[#94A3B8] truncate max-w-[130px] font-normal font-sans text-left">
                      {s.company}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E293B]">
              <tr className="hover:bg-[#1E293B]/20">
                <td className="py-2 px-3 font-semibold text-[#94A3B8] bg-[#0B1222] border-r border-[#1E293B]">Sector & Country</td>
                {compStocks.map((s) => (
                  <td key={s.ticker} className="py-2 px-3 text-center text-[#CBD5E1] border-r border-[#1E293B] last:border-r-0">
                    {s.sector} ({s.country})
                  </td>
                ))}
              </tr>
              <tr className="hover:bg-[#1E293B]/20">
                <td className="py-2 px-3 font-semibold text-[#94A3B8] bg-[#0B1222] border-r border-[#1E293B]">Market Cap ($B)</td>
                {compStocks.map((s) => (
                  <td key={s.ticker} className="py-2 px-3 text-center font-bold text-white border-r border-[#1E293B] last:border-r-0">
                    ${s.marketCap}B
                  </td>
                ))}
              </tr>
              <tr className="hover:bg-[#1E293B]/20">
                <td className="py-2 px-3 font-semibold text-[#94A3B8] bg-[#0B1222] border-r border-[#1E293B]">P/E Multiple (TTM)</td>
                {compStocks.map((s) => (
                  <td key={s.ticker} className="py-2 px-3 text-center text-[#CBD5E1] border-r border-[#1E293B] last:border-r-0">
                    {s.valuation.pe}x
                  </td>
                ))}
              </tr>
              <tr className="hover:bg-[#1E293B]/20">
                <td className="py-2 px-3 font-semibold text-[#94A3B8] bg-[#0B1222] border-r border-[#1E293B]">EV / EBITDA</td>
                {compStocks.map((s) => (
                  <td key={s.ticker} className="py-2 px-3 text-center text-[#CBD5E1] border-r border-[#1E293B] last:border-r-0">
                    {s.valuation.evToEbitda}x
                  </td>
                ))}
              </tr>
              <tr className="hover:bg-[#1E293B]/20">
                <td className="py-2 px-3 font-semibold text-[#94A3B8] bg-[#0B1222] border-r border-[#1E293B]">Return on Invested Capital (ROIC)</td>
                {compStocks.map((s) => (
                  <td key={s.ticker} className="py-2 px-3 text-center font-bold text-[#10B981] border-r border-[#1E293B] last:border-r-0">
                    {s.fundamentals.roic}%
                  </td>
                ))}
              </tr>
              <tr className="hover:bg-[#1E293B]/20">
                <td className="py-2 px-3 font-semibold text-[#94A3B8] bg-[#0B1222] border-r border-[#1E293B]">Free Cash Flow Yield</td>
                {compStocks.map((s) => (
                  <td key={s.ticker} className="py-2 px-3 text-center text-[#CBD5E1] border-r border-[#1E293B] last:border-r-0">
                    {s.fundamentals.fcfYield}%
                  </td>
                ))}
              </tr>
              <tr className="hover:bg-[#1E293B]/20">
                <td className="py-2 px-3 font-semibold text-[#94A3B8] bg-[#0B1222] border-r border-[#1E293B]">1-Year Total Return</td>
                {compStocks.map((s) => (
                  <td key={s.ticker} className="py-2 px-3 text-center font-bold text-[#10B981] border-r border-[#1E293B] last:border-r-0">
                    +{s.returns['1Y']}%
                  </td>
                ))}
              </tr>
              <tr className="hover:bg-[#1E293B]/20">
                <td className="py-2 px-3 font-semibold text-[#94A3B8] bg-[#0B1222] border-r border-[#1E293B]">1-Year Realized Volatility</td>
                {compStocks.map((s) => (
                  <td key={s.ticker} className="py-2 px-3 text-center text-[#94A3B8] border-r border-[#1E293B] last:border-r-0">
                    {s.risk.realizedVol1Y}%
                  </td>
                ))}
              </tr>
              <tr className="hover:bg-[#1E293B]/20">
                <td className="py-2 px-3 font-semibold text-[#94A3B8] bg-[#0B1222] border-r border-[#1E293B]">Value at Risk (VaR 95%)</td>
                {compStocks.map((s) => (
                  <td key={s.ticker} className="py-2 px-3 text-center text-[#EF4444] font-semibold border-r border-[#1E293B] last:border-r-0">
                    -{s.risk.var95}%
                  </td>
                ))}
              </tr>
              <tr className="hover:bg-[#1E293B]/20">
                <td className="py-2 px-3 font-semibold text-[#94A3B8] bg-[#0B1222] border-r border-[#1E293B]">Rhino Composite Score</td>
                {compStocks.map((s) => (
                  <td key={s.ticker} className="py-2 px-3 text-center font-bold text-[#00E5FF] border-r border-[#1E293B] last:border-r-0">
                    {s.equityScore.composite}/100
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* SECTION 2: HYPOTHETICAL RESEARCH BASKET / PORTFOLIO LAB */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 font-mono text-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1E293B] pb-3">
          <div className="flex items-center gap-2">
            <PieChart className="w-4 h-4 text-[#10B981]" />
            <span className="font-bold text-white font-sans text-sm tracking-wide">
              HYPOTHETICAL QUANTITATIVE RESEARCH BASKET SIMULATOR
            </span>
          </div>

          <button
            onClick={() => handleAddPortfolio(newTickerToAdd)}
            className="px-3 py-1 bg-[#10B981]/10 text-[#10B981] hover:bg-[#10B981]/20 border border-[#10B981]/40 rounded-xs font-bold transition-colors flex items-center gap-1 text-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add to Basket ({newTickerToAdd})</span>
          </button>
        </div>

        {/* Portfolio Summary Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-[#0B1222] border border-[#1E293B] rounded-sm p-3">
            <span className="text-[#64748B] text-[10px] block uppercase font-bold tracking-widest">BASKET 1Y EXP. RETURN</span>
            <span className="text-xl font-bold text-[#10B981] mt-1 block">+{weighted1YReturn.toFixed(1)}%</span>
          </div>
          <div className="bg-[#0B1222] border border-[#1E293B] rounded-sm p-3">
            <span className="text-[#64748B] text-[10px] block uppercase font-bold tracking-widest">BASKET REALIZED VOLATILITY</span>
            <span className="text-xl font-bold text-white mt-1 block">{weightedVol.toFixed(1)}%</span>
          </div>
          <div className="bg-[#0B1222] border border-[#1E293B] rounded-sm p-3">
            <span className="text-[#64748B] text-[10px] block uppercase font-bold tracking-widest">BASKET SHARPE RATIO</span>
            <span className="text-xl font-bold text-[#00E5FF] mt-1 block">{portfolioSharpe.toFixed(2)}</span>
          </div>
          <div className="bg-[#0B1222] border border-[#1E293B] rounded-sm p-3">
            <span className="text-[#64748B] text-[10px] block uppercase font-bold tracking-widest">WEIGHTED ROIC</span>
            <span className="text-xl font-bold text-[#10B981] mt-1 block">{weightedROIC.toFixed(1)}%</span>
          </div>
        </div>

        {/* Positions & Weight Allocations */}
        <div className="space-y-2">
          {normalizedPositions.map((pos) => {
            if (!pos.stock) return null;
            return (
              <div
                key={pos.ticker}
                className="flex items-center justify-between p-3 rounded-sm bg-[#0B1222] border border-[#1E293B]"
              >
                <div className="flex items-center gap-3">
                  <span className="font-bold text-[#00E5FF] w-16 text-sm">{pos.ticker}</span>
                  <span className="text-white font-medium">{pos.stock.company}</span>
                  <span className="text-[10px] text-[#64748B]">({pos.stock.sector})</span>
                </div>

                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <span className="text-[#64748B] text-[10px] uppercase font-bold">Weight:</span>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={pos.weight}
                      onChange={(e) => handleUpdateWeight(pos.ticker, Number(e.target.value))}
                      className="w-16 bg-[#0B0F19] border border-[#334155] rounded-xs px-2 py-0.5 text-right text-white text-xs focus:outline-none focus:border-[#00E5FF]"
                    />
                    <span className="text-[#64748B]">%</span>
                    <span className="text-[10px] text-[#00E5FF] font-semibold">
                      ({(pos.normWeight * 100).toFixed(1)}% eff.)
                    </span>
                  </div>

                  <button
                    onClick={() => handleRemovePortfolio(pos.ticker)}
                    className="text-[#64748B] hover:text-[#EF4444] transition-colors p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
