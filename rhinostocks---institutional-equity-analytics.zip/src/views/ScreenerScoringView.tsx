/**
 * RhinoStocks - Screener & Configurable Equity Scoring View
 * Multi-Variable Screening Engine & Dynamic Rhino Score Weight Customizer
 */

import React, { useState, useMemo } from 'react';
import { RhinoStock } from '../types';
import { calculateRhinoEquityScore } from '../utils/quantEngines';
import {
  Sliders,
  Filter,
  Download,
  RotateCcw,
  Sparkles,
  ArrowUpDown,
  CheckCircle,
  FileSpreadsheet,
} from 'lucide-react';

interface ScreenerScoringViewProps {
  stocks: RhinoStock[];
  onSelectStock: (ticker: string) => void;
}

export const ScreenerScoringView: React.FC<ScreenerScoringViewProps> = ({
  stocks,
  onSelectStock,
}) => {
  // Configurable Weights
  const [valWeight, setValWeight] = useState(30);
  const [qualWeight, setQualWeight] = useState(30);
  const [momWeight, setMomWeight] = useState(20);
  const [groWeight, setGroWeight] = useState(20);

  // Filters
  const [selectedSector, setSelectedSector] = useState('ALL');
  const [selectedCountry, setSelectedCountry] = useState('ALL');
  const [maxPE, setMaxPE] = useState<number>(100);
  const [minROIC, setMinROIC] = useState<number>(0);
  const [minFCFYield, setMinFCFYield] = useState<number>(-5);
  const [min1YReturn, setMin1YReturn] = useState<number>(-50);
  const [minScore, setMinScore] = useState<number>(0);

  // Sorting
  const [sortKey, setSortKey] = useState<string>('customScore');
  const [sortAsc, setSortAsc] = useState<boolean>(false);

  // Recalculate custom scores for all stocks
  const stocksWithCustomScore = useMemo(() => {
    const totalWeight = valWeight + qualWeight + momWeight + groWeight || 1;
    const wVal = valWeight / totalWeight;
    const wQual = qualWeight / totalWeight;
    const wMom = momWeight / totalWeight;
    const wGro = groWeight / totalWeight;

    return stocks.map((s) => {
      const customVal = Math.min(100, Math.max(0, 100 - (s.valuation.pe / 60) * 100));
      const customQual = Math.min(100, Math.max(0, s.fundamentals.roic * 2.5));
      const customMom = Math.min(100, Math.max(0, 50 + s.momentum.m12 * 0.8));
      const customGro = Math.min(100, Math.max(0, s.fundamentals.epsGrowth * 2.2));

      const customScore = Math.round(
        customVal * wVal + customQual * wQual + customMom * wMom + customGro * wGro
      );

      return {
        ...s,
        customScore,
      };
    });
  }, [stocks, valWeight, qualWeight, momWeight, groWeight]);

  // Filtered and sorted stocks
  const filteredStocks = useMemo(() => {
    return stocksWithCustomScore
      .filter((s) => {
        if (selectedSector !== 'ALL' && s.sector !== selectedSector) return false;
        if (selectedCountry !== 'ALL' && s.country !== selectedCountry) return false;
        if (s.valuation.pe > maxPE) return false;
        if (s.fundamentals.roic < minROIC) return false;
        if (s.fundamentals.fcfYield < minFCFYield) return false;
        if (s.returns['1Y'] < min1YReturn) return false;
        if (s.customScore < minScore) return false;
        return true;
      })
      .sort((a: any, b: any) => {
        const valA = a[sortKey] ?? a.valuation?.[sortKey] ?? a.fundamentals?.[sortKey] ?? a.returns?.[sortKey] ?? 0;
        const valB = b[sortKey] ?? b.valuation?.[sortKey] ?? b.fundamentals?.[sortKey] ?? b.returns?.[sortKey] ?? 0;
        return sortAsc ? valA - valB : valB - valA;
      });
  }, [
    stocksWithCustomScore,
    selectedSector,
    selectedCountry,
    maxPE,
    minROIC,
    minFCFYield,
    min1YReturn,
    minScore,
    sortKey,
    sortAsc,
  ]);

  const handleExportCSV = () => {
    const headers = 'Ticker,Company,Sector,Country,Price,PE,ROIC,FCFYield,1YReturn,CustomScore\n';
    const rows = filteredStocks
      .map(
        (s) =>
          `${s.ticker},"${s.company}",${s.sector},${s.country},${s.price},${s.valuation.pe},${s.fundamentals.roic},${s.fundamentals.fcfYield},${s.returns['1Y']},${s.customScore}`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rhinobank_screener_${Date.now()}.csv`;
    a.click();
  };

  return (
    <div className="p-4 space-y-4 max-w-[1800px] mx-auto text-[#CBD5E1] font-sans" id="screener-scoring-view">
      {/* Top Banner: Weighting Configuration Engine */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 font-mono text-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1E293B] pb-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#00E5FF]" />
            <span className="font-bold text-white font-sans text-sm tracking-wide">
              CUSTOM RHINO EQUITY SCORING ENGINE (REAL-TIME RE-RANKING)
            </span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => {
                setValWeight(30);
                setQualWeight(30);
                setMomWeight(20);
                setGroWeight(20);
              }}
              className="px-3 py-1.5 bg-[#0B1222] hover:bg-[#1E293B] border border-[#1E293B] rounded-xs text-[#CBD5E1] flex items-center gap-1.5 transition-colors font-sans text-xs"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#64748B]" />
              <span>Reset Default Weights</span>
            </button>

            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 bg-[#00E5FF] hover:bg-[#00E5FF]/80 text-[#0B0F19] font-bold rounded-xs flex items-center gap-1.5 transition-colors font-sans text-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Screener CSV</span>
            </button>
          </div>
        </div>

        {/* Sliders for Weights */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 pt-1">
          <div>
            <div className="flex justify-between text-[11px] mb-1.5">
              <span className="text-[#64748B] font-bold uppercase tracking-widest text-[10px]">Valuation Weight:</span>
              <span className="font-bold text-[#00E5FF]">{valWeight}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="60"
              value={valWeight}
              onChange={(e) => setValWeight(Number(e.target.value))}
              className="w-full accent-[#00E5FF] bg-[#0B0F19]"
            />
          </div>

          <div>
            <div className="flex justify-between text-[11px] mb-1.5">
              <span className="text-[#64748B] font-bold uppercase tracking-widest text-[10px]">Quality / ROIC Weight:</span>
              <span className="font-bold text-[#10B981]">{qualWeight}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="60"
              value={qualWeight}
              onChange={(e) => setQualWeight(Number(e.target.value))}
              className="w-full accent-[#10B981] bg-[#0B0F19]"
            />
          </div>

          <div>
            <div className="flex justify-between text-[11px] mb-1.5">
              <span className="text-[#64748B] font-bold uppercase tracking-widest text-[10px]">Price Momentum Weight:</span>
              <span className="font-bold text-[#00E5FF]">{momWeight}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="60"
              value={momWeight}
              onChange={(e) => setMomWeight(Number(e.target.value))}
              className="w-full accent-[#00E5FF] bg-[#0B0F19]"
            />
          </div>

          <div>
            <div className="flex justify-between text-[11px] mb-1.5">
              <span className="text-[#64748B] font-bold uppercase tracking-widest text-[10px]">Earnings Growth Weight:</span>
              <span className="font-bold text-[#F59E0B]">{groWeight}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="60"
              value={groWeight}
              onChange={(e) => setGroWeight(Number(e.target.value))}
              className="w-full accent-[#F59E0B] bg-[#0B0F19]"
            />
          </div>
        </div>
      </div>

      {/* Multi-Factor Filter Bar */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 font-mono text-xs">
        <div className="font-bold text-white mb-3 flex items-center gap-2 font-sans text-xs tracking-wide">
          <Filter className="w-3.5 h-3.5 text-[#00E5FF]" />
          <span>MULTI-FACTOR CRITERIA FILTERS</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
          <div>
            <label className="block text-[10px] text-[#64748B] uppercase font-bold tracking-widest mb-1">Sector</label>
            <select
              value={selectedSector}
              onChange={(e) => setSelectedSector(e.target.value)}
              className="w-full bg-[#0B0F19] border border-[#334155] rounded-xs px-2.5 py-1.5 text-[#CBD5E1] text-xs focus:outline-none focus:border-[#00E5FF]"
            >
              <option value="ALL">All Sectors</option>
              {Array.from(new Set(stocks.map((s) => s.sector))).map((sec) => (
                <option key={sec} value={sec}>
                  {sec}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] text-[#64748B] uppercase font-bold tracking-widest mb-1">Max P/E Multiple</label>
            <select
              value={maxPE}
              onChange={(e) => setMaxPE(Number(e.target.value))}
              className="w-full bg-[#0B0F19] border border-[#334155] rounded-xs px-2.5 py-1.5 text-[#CBD5E1] text-xs focus:outline-none focus:border-[#00E5FF]"
            >
              <option value={100}>Any P/E (&lt;100)</option>
              <option value={40}>P/E &lt; 40x</option>
              <option value={25}>P/E &lt; 25x</option>
              <option value={15}>P/E &lt; 15x (Deep Value)</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] text-[#64748B] uppercase font-bold tracking-widest mb-1">Min ROIC (%)</label>
            <select
              value={minROIC}
              onChange={(e) => setMinROIC(Number(e.target.value))}
              className="w-full bg-[#0B0F19] border border-[#334155] rounded-xs px-2.5 py-1.5 text-[#CBD5E1] text-xs focus:outline-none focus:border-[#00E5FF]"
            >
              <option value={0}>Any ROIC (&gt;0%)</option>
              <option value={12}>ROIC &gt; 12%</option>
              <option value={20}>ROIC &gt; 20% (Elite)</option>
              <option value={30}>ROIC &gt; 30% (Exceptional)</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] text-[#64748B] uppercase font-bold tracking-widest mb-1">Min FCF Yield (%)</label>
            <select
              value={minFCFYield}
              onChange={(e) => setMinFCFYield(Number(e.target.value))}
              className="w-full bg-[#0B0F19] border border-[#334155] rounded-xs px-2.5 py-1.5 text-[#CBD5E1] text-xs focus:outline-none focus:border-[#00E5FF]"
            >
              <option value={-5}>Any FCF Yield</option>
              <option value={3}>FCF Yield &gt; 3%</option>
              <option value={5}>FCF Yield &gt; 5%</option>
              <option value={8}>FCF Yield &gt; 8%</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] text-[#64748B] uppercase font-bold tracking-widest mb-1">Min 1Y Return (%)</label>
            <select
              value={min1YReturn}
              onChange={(e) => setMin1YReturn(Number(e.target.value))}
              className="w-full bg-[#0B0F19] border border-[#334155] rounded-xs px-2.5 py-1.5 text-[#CBD5E1] text-xs focus:outline-none focus:border-[#00E5FF]"
            >
              <option value={-50}>Any Return</option>
              <option value={0}>Positive 1Y Return (&gt;0%)</option>
              <option value={20}>1Y Return &gt; 20%</option>
              <option value={40}>1Y Return &gt; 40%</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] text-[#64748B] uppercase font-bold tracking-widest mb-1">Min Rhino Score</label>
            <select
              value={minScore}
              onChange={(e) => setMinScore(Number(e.target.value))}
              className="w-full bg-[#0B0F19] border border-[#334155] rounded-xs px-2.5 py-1.5 text-[#CBD5E1] text-xs focus:outline-none focus:border-[#00E5FF]"
            >
              <option value={0}>All Scores (0+)</option>
              <option value={60}>Score &gt; 60</option>
              <option value={75}>Score &gt; 75 (Top Tier)</option>
              <option value={85}>Score &gt; 85 (Conviction)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Screened Securities Results Table */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 font-mono text-xs">
        <div className="font-bold text-white text-xs border-b border-[#1E293B] pb-3 mb-3 flex items-center justify-between font-sans">
          <span className="tracking-wide">SCREENING RESULTS ({filteredStocks.length} EQUITIES MATCHED)</span>
          <span className="text-[10px] text-[#00E5FF] font-mono">Sorted by: {sortKey} ({sortAsc ? 'Asc' : 'Desc'})</span>
        </div>

        <div className="overflow-x-auto max-h-[500px]">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-[#1E293B] text-[10px] text-[#64748B] uppercase tracking-widest font-bold sticky top-0 bg-[#0F172A]">
                <th className="py-2 px-2">Ticker</th>
                <th className="py-2 px-2">Company</th>
                <th className="py-2 px-2">Sector</th>
                <th className="py-2 px-2 text-right">Price</th>
                <th className="py-2 px-2 text-right cursor-pointer hover:text-[#00E5FF]" onClick={() => { setSortKey('pe'); setSortAsc(!sortAsc); }}>
                  P/E Multiple
                </th>
                <th className="py-2 px-2 text-right cursor-pointer hover:text-[#00E5FF]" onClick={() => { setSortKey('roic'); setSortAsc(!sortAsc); }}>
                  ROIC (%)
                </th>
                <th className="py-2 px-2 text-right cursor-pointer hover:text-[#00E5FF]" onClick={() => { setSortKey('fcfYield'); setSortAsc(!sortAsc); }}>
                  FCF Yield
                </th>
                <th className="py-2 px-2 text-right cursor-pointer hover:text-[#00E5FF]" onClick={() => { setSortKey('return1Y'); setSortAsc(!sortAsc); }}>
                  1Y Return
                </th>
                <th className="py-2 px-2 text-right cursor-pointer hover:text-[#00E5FF]" onClick={() => { setSortKey('customScore'); setSortAsc(!sortAsc); }}>
                  Rhino Score (Custom)
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E293B]/60">
              {filteredStocks.map((s) => (
                <tr
                  key={s.ticker}
                  onClick={() => onSelectStock(s.ticker)}
                  className="hover:bg-[#1E293B]/40 cursor-pointer transition-colors"
                >
                  <td className="py-2 px-2 font-bold text-[#00E5FF]">{s.ticker}</td>
                  <td className="py-2 px-2 text-white">{s.company}</td>
                  <td className="py-2 px-2 text-[#94A3B8]">{s.sector}</td>
                  <td className="py-2 px-2 text-right font-semibold text-white">${s.price.toFixed(2)}</td>
                  <td className="py-2 px-2 text-right text-[#CBD5E1]">{s.valuation.pe}x</td>
                  <td className="py-2 px-2 text-right font-semibold text-[#10B981]">{s.fundamentals.roic}%</td>
                  <td className="py-2 px-2 text-right text-[#CBD5E1]">{s.fundamentals.fcfYield}%</td>
                  <td className={`py-2 px-2 text-right font-bold ${s.returns['1Y'] >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                    {s.returns['1Y'] >= 0 ? '+' : ''}{s.returns['1Y']}%
                  </td>
                  <td className="py-2 px-2 text-right">
                    <span className="px-2.5 py-0.5 rounded-xs font-bold text-[#00E5FF] bg-[#00E5FF]/10 border border-[#00E5FF]/30">
                      {s.customScore}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
