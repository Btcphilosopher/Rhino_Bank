/**
 * RhinoStocks - Sectors & Industries View
 * RRG Sector Rotation Graph, Industry Drill-Down & Constituent Attribution
 */

import React, { useState } from 'react';
import { SectorMetric, RhinoStock, Sector } from '../types';
import { SectorRotationChart } from '../components/charts/SectorRotationChart';
import {
  PieChart,
  Activity,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  Filter,
  BarChart2,
} from 'lucide-react';

interface SectorsIndustriesViewProps {
  sectors: SectorMetric[];
  stocks: RhinoStock[];
  selectedSector: Sector;
  onSelectSector: (sector: Sector) => void;
  onSelectStock: (ticker: string) => void;
}

export const SectorsIndustriesView: React.FC<SectorsIndustriesViewProps> = ({
  sectors,
  stocks,
  selectedSector,
  onSelectSector,
  onSelectStock,
}) => {
  const currentSectorData = sectors.find((s) => s.sector === selectedSector) || sectors[0];
  const sectorConstituents = stocks.filter((s) => s.sector === selectedSector);

  return (
    <div className="p-4 space-y-4 max-w-[1800px] mx-auto text-[#CBD5E1] font-sans" id="sectors-industries-view">
      {/* Top Header & Sector Selector */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 mb-3 border-b border-[#1E293B] font-mono text-xs">
          <div className="flex items-center gap-2">
            <PieChart className="w-4 h-4 text-[#00E5FF]" />
            <span className="font-bold text-white font-sans text-sm tracking-wide">
              GICS SECTOR ROTATION & RELATIVE STRENGTH (RRG)
            </span>
          </div>
          <div className="text-[11px] text-[#64748B]">
            JdG Relative Strength Rotation Model (Benchmark: MSCI World Index)
          </div>
        </div>

        {/* Sector Quick Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 font-mono text-xs scrollbar-none">
          {sectors.map((sec) => {
            const isSelected = sec.sector === selectedSector;
            const isLeading = sec.rotationState === 'LEADING';
            const isLagging = sec.rotationState === 'LAGGING';
            const stateDot = isLeading ? 'bg-[#10B981]' : isLagging ? 'bg-[#EF4444]' : 'bg-[#F59E0B]';

            return (
              <button
                key={sec.sector}
                onClick={() => onSelectSector(sec.sector)}
                className={`px-3 py-1.5 rounded-xs text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-2 ${
                  isSelected
                    ? 'bg-[#00E5FF]/20 text-[#00E5FF] font-bold border border-[#00E5FF]/50'
                    : 'bg-[#0B1222] text-[#94A3B8] hover:text-white hover:bg-[#1E293B] border border-[#1E293B]'
                }`}
              >
                <span className={`w-2 h-2 rounded-full ${stateDot}`} />
                <span>{sec.sector}</span>
                <span className="text-[10px] text-[#64748B] font-normal">+{sec.return1Y}%</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* RRG Chart and Sector Detail Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 font-mono text-xs">
        {/* RRG Rotation Graph */}
        <div className="lg:col-span-7 bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-[#1E293B]">
            <span className="font-bold text-white font-sans text-xs tracking-wide">RRG RELATIVE ROTATION GRAPH (RS-RATIO vs RS-MOMENTUM)</span>
            <span className="text-[10px] text-[#00E5FF]">Center: Benchmark (100, 100)</span>
          </div>
          <div className="flex-1 w-full mt-3 min-h-[440px]">
            <SectorRotationChart sectors={sectors} onSelectSector={onSelectSector} />
          </div>
        </div>

        {/* Selected Sector Deep Profile */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
              <div>
                <span className="text-base font-bold text-[#00E5FF] font-sans">{currentSectorData.sector}</span>
                <span className="text-[11px] text-[#64748B] block mt-0.5">
                  Market Cap: <b className="text-white">${((currentSectorData.marketCapTotal || 12000) / 1000).toFixed(1)}T</b>
                </span>
              </div>
              <span className={`px-2.5 py-1 rounded-xs text-xs font-bold ${
                currentSectorData.rotationState === 'LEADING'
                  ? 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/40'
                  : currentSectorData.rotationState === 'LAGGING'
                  ? 'bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/40'
                  : 'bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/40'
              }`}>
                {currentSectorData.rotationState}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-[#0B1222] p-3 rounded-xs border border-[#1E293B]">
                <span className="text-[#64748B] text-[10px] block font-bold uppercase tracking-widest">P/E MULTIPLE</span>
                <span className="text-base font-bold text-white mt-1 block">{currentSectorData.peRatio}x</span>
              </div>
              <div className="bg-[#0B1222] p-3 rounded-xs border border-[#1E293B]">
                <span className="text-[#64748B] text-[10px] block font-bold uppercase tracking-widest">DIVIDEND YIELD</span>
                <span className="text-base font-bold text-[#10B981] mt-1 block">{currentSectorData.dividendYield}%</span>
              </div>
              <div className="bg-[#0B1222] p-3 rounded-xs border border-[#1E293B]">
                <span className="text-[#64748B] text-[10px] block font-bold uppercase tracking-widest">1Y TOTAL RETURN</span>
                <span className="text-base font-bold text-[#10B981] mt-1 block">+{currentSectorData.return1Y}%</span>
              </div>
              <div className="bg-[#0B1222] p-3 rounded-xs border border-[#1E293B]">
                <span className="text-[#64748B] text-[10px] block font-bold uppercase tracking-widest">1Y REALIZED VOL</span>
                <span className="text-base font-bold text-white mt-1 block">{currentSectorData.volatility1Y}%</span>
              </div>
            </div>

            {/* Industry Group Breakdown */}
            <div className="pt-3 border-t border-[#1E293B]">
              <div className="font-bold text-white mb-2 text-[11px] font-sans tracking-wide">
                KEY INDUSTRY GROUPS
              </div>
              <div className="flex flex-wrap gap-1.5">
                {((currentSectorData as any).topIndustries || [
                  'Semiconductors & Equipment',
                  'Software & Cloud Infrastructure',
                  'Hardware & Storage Devices'
                ]).map((ind: string) => (
                  <span
                    key={ind}
                    className="bg-[#0B1222] text-[#CBD5E1] px-2.5 py-1 rounded-xs text-[10px] border border-[#1E293B]"
                  >
                    {ind}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Constituent Stocks */}
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4">
            <div className="font-bold text-white text-xs border-b border-[#1E293B] pb-3 mb-3 flex items-center justify-between font-sans">
              <span className="tracking-wide">{currentSectorData.sector.toUpperCase()} CONSTITUENTS</span>
              <span className="text-[10px] text-[#64748B] font-mono">{sectorConstituents.length} Equities</span>
            </div>

            <div className="space-y-2 max-h-56 overflow-y-auto">
              {sectorConstituents.map((s) => (
                <div
                  key={s.ticker}
                  onClick={() => onSelectStock(s.ticker)}
                  className="p-2.5 rounded-xs bg-[#0B1222] hover:bg-[#1E293B] border border-[#1E293B]/60 cursor-pointer transition-colors flex items-center justify-between group"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="font-bold text-[#00E5FF] w-16 group-hover:text-[#00E5FF]">{s.ticker}</span>
                    <span className="text-white truncate max-w-[130px] font-sans">{s.company}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-[#10B981]">+{s.returns['1Y']}%</span>
                    <span className="text-[10px] text-[#64748B] block">${s.price.toFixed(2)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
