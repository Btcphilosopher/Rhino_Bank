/**
 * RhinoStocks - Institutional Security Deep-Dive View
 * Universal Security Drill-Down: Technicals, Valuation, Fundamentals, Risk, Factors, Event Studies
 */

import React, { useState } from 'react';
import { RhinoStock, PriceBar } from '../types';
import { MarketDataStore } from '../services/marketData';
import { CandlestickChart } from '../components/charts/CandlestickChart';
import {
  ReturnDistributionChart,
  UnderwaterDrawdownChart,
} from '../components/charts/RiskAndReturnDistribution';
import {
  Activity,
  TrendingUp,
  TrendingDown,
  DollarSign,
  PieChart,
  Layers,
  ShieldAlert,
  BarChart2,
  Calendar,
  Award,
  ArrowUpRight,
  ArrowDownRight,
  FileText,
  Share2,
} from 'lucide-react';

interface SecurityDeepDiveViewProps {
  stock: RhinoStock;
  allStocks: RhinoStock[];
  onSelectStock: (ticker: string) => void;
}

type SubTab =
  | 'CHART_TECHNICALS'
  | 'VALUATION'
  | 'FUNDAMENTALS_EARNINGS'
  | 'DIVIDENDS_BUYBACKS'
  | 'RISK_VOLATILITY'
  | 'FACTOR_EXPOSURE'
  | 'EVENT_STUDIES';

export const SecurityDeepDiveView: React.FC<SecurityDeepDiveViewProps> = ({
  stock,
  allStocks,
  onSelectStock,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<SubTab>('CHART_TECHNICALS');

  const is1DUp = stock.changePct1D >= 0;
  const is1YUp = stock.returns['1Y'] >= 0;

  // Find sector peers for relative valuation
  const peers = allStocks
    .filter((s) => s.sector === stock.sector && s.ticker !== stock.ticker)
    .slice(0, 5);

  const avgSectorPE = peers.length
    ? peers.reduce((sum, p) => sum + p.valuation.pe, 0) / peers.length
    : stock.valuation.pe;

  return (
    <div className="p-4 space-y-4 max-w-[1800px] mx-auto text-[#CBD5E1] font-sans" id="security-deep-dive-view">
      {/* Top Banner: Security Master Details & Rhino Equity Score */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 font-mono text-xs">
        <div className="flex flex-wrap items-start justify-between gap-4">
          {/* Left: Security Identifiers */}
          <div>
            <div className="flex items-center gap-3">
              <span className="text-2xl font-bold text-[#00E5FF] font-mono tracking-tight">
                {stock.ticker}
              </span>
              <span className="text-lg text-white font-sans font-semibold">
                {stock.company}
              </span>
              <span className="bg-[#0B0F19] text-[#94A3B8] px-2 py-0.5 rounded-xs text-[10px] border border-[#334155]">
                {stock.exchange}
              </span>
              <span className="bg-[#0B0F19] text-[#94A3B8] px-2 py-0.5 rounded-xs text-[10px] border border-[#334155]">
                {stock.currency}
              </span>
            </div>

            <div className="flex items-center gap-2 mt-1.5 text-[11px] text-[#64748B]">
              <span className="text-[#CBD5E1]">{stock.sector}</span>
              <span>•</span>
              <span>{stock.industry}</span>
              <span>•</span>
              <span>{stock.country}</span>
              <span>•</span>
              <span>ISIN: <b className="text-white">{stock.isin}</b></span>
            </div>
          </div>

          {/* Center: Live Quote & 52W Range */}
          <div className="flex items-center gap-6">
            <div>
              <div className="text-2xl font-bold text-white tracking-tight">
                ${stock.price.toFixed(2)}
              </div>
              <div className={`flex items-center text-xs font-bold ${is1DUp ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                {is1DUp ? <TrendingUp className="w-3.5 h-3.5 mr-0.5 inline" /> : <TrendingDown className="w-3.5 h-3.5 mr-0.5 inline" />}
                {is1DUp ? '+' : ''}${stock.change1D.toFixed(2)} ({is1DUp ? '+' : ''}
                {stock.changePct1D.toFixed(2)}%)
              </div>
            </div>

            <div className="border-l border-[#1E293B] pl-4 space-y-1">
              <div className="text-[10px] text-[#64748B] uppercase tracking-widest font-bold">52-WEEK RANGE</div>
              <div className="flex items-center gap-2 text-[11px]">
                <span className="text-[#64748B]">${stock.week52Low.toFixed(1)}</span>
                <div className="w-24 h-1.5 rounded-none bg-[#1E293B] overflow-hidden relative">
                  <div
                    style={{
                      left: `${Math.min(100, Math.max(0, ((stock.price - stock.week52Low) / (stock.week52High - stock.week52Low || 1)) * 100))}%`,
                    }}
                    className="absolute top-0 bottom-0 w-1.5 bg-[#00E5FF] -ml-0.5"
                  />
                </div>
                <span className="text-[#64748B]">${stock.week52High.toFixed(1)}</span>
              </div>
            </div>
          </div>

          {/* Right: Rhino Proprietary Composite Equity Score */}
          <div className="bg-[#0B1222] border border-[#1E293B] rounded-sm p-3 flex items-center gap-3">
            <div className="text-center">
              <div className="text-[9px] text-[#64748B] font-bold uppercase tracking-widest">
                RHINO SCORE
              </div>
              <div className="text-2xl font-bold text-[#00E5FF]">
                {stock.equityScore.composite}
                <span className="text-xs text-[#64748B] font-normal">/100</span>
              </div>
              <div className="text-[9px] font-bold text-[#10B981]">
                {stock.equityScore.recommendation}
              </div>
            </div>

            <div className="border-l border-[#1E293B] pl-3 grid grid-cols-2 gap-x-3 gap-y-0.5 text-[10px]">
              <div>Valuation: <b className="text-white">{stock.equityScore.valuationScore}</b></div>
              <div>Quality: <b className="text-white">{stock.equityScore.qualityScore}</b></div>
              <div>Momentum: <b className="text-white">{stock.equityScore.momentumScore}</b></div>
              <div>Growth: <b className="text-white">{stock.equityScore.growthScore}</b></div>
            </div>
          </div>
        </div>

        {/* Quick Horizon Returns Strip */}
        <div className="mt-3 pt-3 border-t border-[#1E293B] flex flex-wrap items-center justify-between gap-4 text-[11px]">
          <div className="flex items-center gap-4">
            <span className="text-[#64748B] font-bold tracking-wider">RETURNS:</span>
            <span>1D: <b className={stock.returns['1D'] >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}>{stock.returns['1D'] >= 0 ? '+' : ''}{stock.returns['1D']}%</b></span>
            <span>1W: <b className={stock.returns['1W'] >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}>{stock.returns['1W'] >= 0 ? '+' : ''}{stock.returns['1W']}%</b></span>
            <span>1M: <b className={stock.returns['1M'] >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}>{stock.returns['1M'] >= 0 ? '+' : ''}{stock.returns['1M']}%</b></span>
            <span>3M: <b className={stock.returns['3M'] >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}>{stock.returns['3M'] >= 0 ? '+' : ''}{stock.returns['3M']}%</b></span>
            <span>YTD: <b className={stock.returns['YTD'] >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}>{stock.returns['YTD'] >= 0 ? '+' : ''}{stock.returns['YTD']}%</b></span>
            <span>1Y: <b className={stock.returns['1Y'] >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}>{stock.returns['1Y'] >= 0 ? '+' : ''}{stock.returns['1Y']}%</b></span>
            <span>3Y (Ann): <b className={stock.returns['3Y_ANN'] >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}>+{stock.returns['3Y_ANN']}%</b></span>
          </div>

          <div className="flex items-center gap-3 text-[#64748B]">
            <span>Mkt Cap: <b className="text-white">${stock.marketCap}B</b></span>
            <span>•</span>
            <span>Beta: <b className="text-white">{stock.risk.betaMarket}</b></span>
            <span>•</span>
            <span>1Y Vol: <b className="text-white">{stock.risk.realizedVol1Y}%</b></span>
            <span>•</span>
            <span>Sharpe: <b className="text-[#10B981]">{stock.risk.sharpeRatio}</b></span>
          </div>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-1 border-b border-[#1E293B] font-mono text-xs overflow-x-auto scrollbar-none">
        {[
          { id: 'CHART_TECHNICALS', label: '1. TECHNICALS & CHART', icon: <Activity className="w-3.5 h-3.5" /> },
          { id: 'VALUATION', label: '2. VALUATION & MULTIPLES', icon: <DollarSign className="w-3.5 h-3.5" /> },
          { id: 'FUNDAMENTALS_EARNINGS', label: '3. EARNINGS & FUNDAMENTALS', icon: <BarChart2 className="w-3.5 h-3.5" /> },
          { id: 'DIVIDENDS_BUYBACKS', label: '4. DIVIDENDS & CAPITAL RETURN', icon: <Award className="w-3.5 h-3.5" /> },
          { id: 'RISK_VOLATILITY', label: '5. RISK, VaR & DRAWDOWN', icon: <ShieldAlert className="w-3.5 h-3.5" /> },
          { id: 'FACTOR_EXPOSURE', label: '6. FACTOR RADAR & PEERS', icon: <Layers className="w-3.5 h-3.5" /> },
          { id: 'EVENT_STUDIES', label: '7. EVENT STUDIES (CAR)', icon: <Calendar className="w-3.5 h-3.5" /> },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id as SubTab)}
            className={`flex items-center gap-1.5 px-3 py-2 border-b-2 whitespace-nowrap transition-all ${
              activeSubTab === tab.id
                ? 'border-[#00E5FF] text-[#00E5FF] font-bold bg-[#00E5FF]/10'
                : 'border-transparent text-[#94A3B8] hover:text-white hover:bg-[#1E293B]/40'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab 1: Interactive Candlestick Chart & Technicals */}
      {activeSubTab === 'CHART_TECHNICALS' && (
        <div className="space-y-4">
          <CandlestickChart
            ticker={stock.ticker}
            companyName={stock.company}
            history={stock.history}
          />

          {/* Technical Levels Table */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 font-mono text-xs">
            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">TREND MOMENTUM</div>
              <div className="text-[#10B981] font-bold text-sm my-1">
                {stock.momentum.trendState}
              </div>
              <div className="text-[11px] text-[#94A3B8]">
                12M Mom: <b className="text-white">+{stock.momentum.m12}%</b> | 6M: <b className="text-white">+{stock.momentum.m6}%</b>
              </div>
            </div>

            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">MOVING AVERAGES</div>
              <div className="text-white font-bold text-sm my-1">
                SMA50: ${stock.history[stock.history.length - 1]?.sma50.toFixed(2)}
              </div>
              <div className="text-[11px] text-[#94A3B8]">
                SMA200: <b className="text-white">${stock.history[stock.history.length - 1]?.sma200.toFixed(2)}</b> (
                {stock.price > (stock.history[stock.history.length - 1]?.sma200 || 0) ? (
                  <span className="text-[#10B981]">Above +{(((stock.price - (stock.history[stock.history.length - 1]?.sma200 || 1)) / (stock.history[stock.history.length - 1]?.sma200 || 1)) * 100).toFixed(1)}%</span>
                ) : (
                  <span className="text-[#EF4444]">Below</span>
                )}
                )
              </div>
            </div>

            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">RSI & OSCILLATORS</div>
              <div className="text-[#00E5FF] font-bold text-sm my-1">
                RSI (14): {stock.history[stock.history.length - 1]?.rsi.toFixed(1)}
              </div>
              <div className="text-[11px] text-[#94A3B8]">
                {stock.history[stock.history.length - 1]?.rsi! > 70 ? (
                  <span className="text-[#F59E0B]">Overbought Territory</span>
                ) : stock.history[stock.history.length - 1]?.rsi! < 30 ? (
                  <span className="text-[#10B981]">Oversold Territory</span>
                ) : (
                  <span className="text-[#CBD5E1]">Neutral Range</span>
                )}
              </div>
            </div>

            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">VOLATILITY & ATR</div>
              <div className="text-[#F59E0B] font-bold text-sm my-1">
                ATR (14): ${stock.history[stock.history.length - 1]?.atr.toFixed(2)}
              </div>
              <div className="text-[11px] text-[#94A3B8]">
                Daily Avg Move: <b className="text-white">{((stock.history[stock.history.length - 1]?.atr! / stock.price) * 100).toFixed(2)}%</b>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Valuation Multiples & Peer Benchmarking */}
      {activeSubTab === 'VALUATION' && (
        <div className="space-y-4 font-mono text-xs">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Multiples Card */}
            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 space-y-3">
              <div className="font-bold text-[#00E5FF] text-xs border-b border-[#1E293B] pb-2 flex items-center justify-between font-sans">
                <span className="tracking-wide">VALUATION MULTIPLES (TTM / FWD)</span>
                <span className="text-[10px] text-[#64748B]">Rhino Model</span>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between py-1.5 border-b border-[#1E293B]">
                  <span className="text-[#94A3B8]">Price / Earnings (TTM)</span>
                  <span className="font-bold text-white">{stock.valuation.pe}x</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-[#1E293B]">
                  <span className="text-[#94A3B8]">Forward P/E</span>
                  <span className="font-bold text-white">{stock.valuation.forwardPe}x</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-[#1E293B]">
                  <span className="text-[#94A3B8]">Price / Book (P/B)</span>
                  <span className="font-bold text-white">{stock.valuation.pb}x</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-[#1E293B]">
                  <span className="text-[#94A3B8]">EV / EBITDA</span>
                  <span className="font-bold text-white">{stock.valuation.evToEbitda}x</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-[#1E293B]">
                  <span className="text-[#94A3B8]">EV / Sales</span>
                  <span className="font-bold text-white">{stock.valuation.evToSales}x</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-[#1E293B]">
                  <span className="text-[#94A3B8]">Free Cash Flow Yield</span>
                  <span className="font-bold text-[#10B981]">{stock.fundamentals.fcfYield}%</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-[#94A3B8]">Dividend Yield</span>
                  <span className="font-bold text-white">{stock.valuation.dividendYield}%</span>
                </div>
              </div>
            </div>

            {/* Peer Relative Multiple Comparison */}
            <div className="md:col-span-2 bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 space-y-3">
              <div className="font-bold text-white text-xs border-b border-[#1E293B] pb-2 flex items-center justify-between font-sans">
                <span className="tracking-wide">SECTOR PEER COMPARATIVE VALUATION ({stock.sector.toUpperCase()})</span>
                <span className="text-[10px] text-[#00E5FF]">Sector Avg P/E: {avgSectorPE.toFixed(1)}x</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left font-mono text-xs">
                  <thead>
                    <tr className="border-b border-[#1E293B] text-[10px] text-[#64748B] uppercase tracking-widest font-bold">
                      <th className="py-2 px-2">Ticker</th>
                      <th className="py-2 px-2">Company</th>
                      <th className="py-2 px-2 text-right">P/E</th>
                      <th className="py-2 px-2 text-right">P/B</th>
                      <th className="py-2 px-2 text-right">EV/EBITDA</th>
                      <th className="py-2 px-2 text-right">ROIC</th>
                      <th className="py-2 px-2 text-right">1Y Return</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1E293B]/60">
                    <tr className="bg-[#00E5FF]/10 font-bold">
                      <td className="py-2 px-2 text-[#00E5FF]">{stock.ticker} (Target)</td>
                      <td className="py-2 px-2 text-white">{stock.company}</td>
                      <td className="py-2 px-2 text-right text-[#00E5FF]">{stock.valuation.pe}x</td>
                      <td className="py-2 px-2 text-right text-white">{stock.valuation.pb}x</td>
                      <td className="py-2 px-2 text-right text-white">{stock.valuation.evToEbitda}x</td>
                      <td className="py-2 px-2 text-right text-[#10B981]">{stock.fundamentals.roic}%</td>
                      <td className="py-2 px-2 text-right text-[#10B981]">+{stock.returns['1Y']}%</td>
                    </tr>
                    {peers.map((peer) => (
                      <tr
                        key={peer.ticker}
                        onClick={() => onSelectStock(peer.ticker)}
                        className="hover:bg-[#1E293B]/40 cursor-pointer transition-colors"
                      >
                        <td className="py-2 px-2 font-bold text-[#CBD5E1]">{peer.ticker}</td>
                        <td className="py-2 px-2 text-[#94A3B8]">{peer.company}</td>
                        <td className="py-2 px-2 text-right text-white">{peer.valuation.pe}x</td>
                        <td className="py-2 px-2 text-right text-[#CBD5E1]">{peer.valuation.pb}x</td>
                        <td className="py-2 px-2 text-right text-[#CBD5E1]">{peer.valuation.evToEbitda}x</td>
                        <td className="py-2 px-2 text-right text-[#CBD5E1]">{peer.fundamentals.roic}%</td>
                        <td className="py-2 px-2 text-right text-[#10B981]">+{peer.returns['1Y']}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Fundamentals & Earnings History */}
      {activeSubTab === 'FUNDAMENTALS_EARNINGS' && (
        <div className="space-y-4 font-mono text-xs">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">PROFITABILITY MARGINS</div>
              <div className="text-[#10B981] font-bold text-base my-1">
                {stock.fundamentals.netMargin}% Net Margin
              </div>
              <div className="text-[11px] text-[#94A3B8]">
                Gross: <b className="text-white">{stock.fundamentals.grossMargin}%</b> | Op: <b className="text-white">{stock.fundamentals.operatingMargin}%</b>
              </div>
            </div>

            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">CAPITAL RETURNS</div>
              <div className="text-[#00E5FF] font-bold text-base my-1">
                {stock.fundamentals.roic}% ROIC
              </div>
              <div className="text-[11px] text-[#94A3B8]">
                ROE: <b className="text-white">{stock.fundamentals.roe}%</b> | Assets: <b className="text-white">{stock.fundamentals.roa}%</b>
              </div>
            </div>

            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">GROWTH RATES (YoY)</div>
              <div className="text-[#10B981] font-bold text-base my-1">
                +{stock.fundamentals.revenueGrowth}% Rev Growth
              </div>
              <div className="text-[11px] text-[#94A3B8]">
                EPS Growth: <b className="text-[#10B981]">+{stock.fundamentals.epsGrowth}%</b>
              </div>
            </div>

            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">BALANCE SHEET SOLVENCY</div>
              <div className="text-white font-bold text-base my-1">
                {stock.fundamentals.debtToEquity}x Debt/Equity
              </div>
              <div className="text-[11px] text-[#94A3B8]">
                Interest Coverage: <b className="text-[#10B981]">{stock.fundamentals.interestCoverage}x</b>
              </div>
            </div>
          </div>

          {/* Quarterly Earnings Performance */}
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4">
            <div className="font-bold text-white text-xs border-b border-[#1E293B] pb-3 mb-3 flex items-center justify-between font-sans">
              <span className="tracking-wide">QUARTERLY EARNINGS & CONSENSUS SURPRISE HISTORY</span>
              <span className="text-[10px] text-[#10B981] font-bold">Consecutive Beats: 4/4</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs">
                <thead>
                  <tr className="border-b border-[#1E293B] text-[10px] text-[#64748B] uppercase tracking-widest font-bold">
                    <th className="py-2 px-2">Quarter</th>
                    <th className="py-2 px-2 text-right">Revenue ($B)</th>
                    <th className="py-2 px-2 text-right">EPS Actual</th>
                    <th className="py-2 px-2 text-right">EPS Consensus</th>
                    <th className="py-2 px-2 text-right">Surprise %</th>
                    <th className="py-2 px-2 text-right">Stock 1D Post</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1E293B]/60">
                  {stock.earningsHistory.map((q) => {
                    const isBeat = q.surprisePct >= 0;
                    return (
                      <tr key={q.quarter} className="hover:bg-[#1E293B]/40">
                        <td className="py-2 px-2 font-bold text-white">{q.quarter}</td>
                        <td className="py-2 px-2 text-right font-semibold text-[#CBD5E1]">${q.revenue}B</td>
                        <td className="py-2 px-2 text-right font-bold text-[#00E5FF]">${q.epsActual.toFixed(2)}</td>
                        <td className="py-2 px-2 text-right text-[#94A3B8]">${q.epsEstimate.toFixed(2)}</td>
                        <td className={`py-2 px-2 text-right font-bold ${isBeat ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                          {isBeat ? '+' : ''}{q.surprisePct.toFixed(1)}%
                        </td>
                        <td className={`py-2 px-2 text-right font-semibold ${q.postEarningsMove1D >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                          {q.postEarningsMove1D >= 0 ? '+' : ''}{q.postEarningsMove1D.toFixed(1)}%
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Dividends & Buybacks */}
      {activeSubTab === 'DIVIDENDS_BUYBACKS' && (
        <div className="space-y-4 font-mono text-xs">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">DIVIDEND YIELD</div>
              <div className="text-[#10B981] font-bold text-base my-1">
                {stock.valuation.dividendYield}%
              </div>
              <div className="text-[11px] text-[#94A3B8]">Annualized Dividend</div>
            </div>

            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">5Y DIVIDEND CAGR</div>
              <div className="text-[#00E5FF] font-bold text-base my-1">
                +{stock.dividends.cagr5Y}%
              </div>
              <div className="text-[11px] text-[#94A3B8]">5-Year Growth Rate</div>
            </div>

            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">PAYOUT RATIO</div>
              <div className="text-white font-bold text-base my-1">
                {stock.dividends.payoutRatio}%
              </div>
              <div className="text-[11px] text-[#94A3B8]">Coverage: {(100 / (stock.dividends.payoutRatio || 1)).toFixed(1)}x</div>
            </div>

            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">BUYBACK YIELD</div>
              <div className="text-[#F59E0B] font-bold text-base my-1">
                {stock.dividends.buybackYield}%
              </div>
              <div className="text-[11px] text-[#94A3B8]">
                Total Yield: <b className="text-[#10B981]">{(stock.valuation.dividendYield + stock.dividends.buybackYield).toFixed(2)}%</b>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Risk, VaR & Underwater Drawdowns */}
      {activeSubTab === 'RISK_VOLATILITY' && (
        <div className="space-y-4 font-mono text-xs">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">VALUE AT RISK (95% 1D)</div>
              <div className="text-[#EF4444] font-bold text-base my-1">
                -{stock.risk.var95}%
              </div>
              <div className="text-[11px] text-[#94A3B8]">
                CVaR 95%: <b className="text-[#EF4444]">-{stock.risk.cvar95}%</b>
              </div>
            </div>

            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">MAX HISTORICAL DRAWDOWN</div>
              <div className="text-[#EF4444] font-bold text-base my-1">
                {stock.risk.maxDrawdown}%
              </div>
              <div className="text-[11px] text-[#94A3B8]">From 52W Peak</div>
            </div>

            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">SHARPE & SORTINO RATIOS</div>
              <div className="text-[#10B981] font-bold text-base my-1">
                Sharpe: {stock.risk.sharpeRatio}
              </div>
              <div className="text-[11px] text-[#94A3B8]">
                Sortino: <b className="text-[#10B981]">{stock.risk.sortinoRatio}</b> | Info: <b className="text-white">{stock.risk.informationRatio}</b>
              </div>
            </div>

            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-3">
              <div className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">DISTRIBUTION MOMENTS</div>
              <div className="text-white font-bold text-base my-1">
                Skew: {stock.risk.skewness}
              </div>
              <div className="text-[11px] text-[#94A3B8]">
                Kurtosis: <b className="text-white">{stock.risk.kurtosis}</b> (Fat Tails)
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4">
              <div className="text-xs font-bold text-white mb-3 font-sans tracking-wide">
                DAILY RETURN PROBABILITY DISTRIBUTION & VaR CUTOFF
              </div>
              <ReturnDistributionChart
                history={stock.history}
                var95={stock.risk.var95}
                cvar95={stock.risk.cvar95}
                skewness={stock.risk.skewness}
                kurtosis={stock.risk.kurtosis}
              />
            </div>

            <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4">
              <div className="text-xs font-bold text-white mb-3 font-sans tracking-wide">
                HISTORICAL UNDERWATER DRAWDOWN CURVE
              </div>
              <UnderwaterDrawdownChart history={stock.history} />
            </div>
          </div>
        </div>
      )}

      {/* Tab 6: Factor Exposures Radar */}
      {activeSubTab === 'FACTOR_EXPOSURE' && (
        <div className="space-y-4 font-mono text-xs">
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4">
            <div className="font-bold text-white text-xs border-b border-[#1E293B] pb-3 mb-3 font-sans tracking-wide">
              BARRA-STYLE MULTI-FACTOR EXPOSURE RADAR (Z-SCORES)
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
              {[
                { name: 'VALUE', z: stock.factors.value, desc: 'P/E, P/B, FCF Yield' },
                { name: 'MOMENTUM', z: stock.factors.momentum, desc: '12-1M Price Trend' },
                { name: 'QUALITY', z: stock.factors.quality, desc: 'ROIC, Margins, Leverage' },
                { name: 'GROWTH', z: stock.factors.growth, desc: 'EPS & Sales Expansion' },
                { name: 'LOW VOLATILITY', z: stock.factors.lowVolatility, desc: 'Idiosyncratic Variance' },
                { name: 'SIZE', z: stock.factors.size, desc: 'Log Market Cap' },
              ].map((f) => (
                <div key={f.name} className="bg-[#0B1222] border border-[#1E293B] rounded-sm p-3 text-center">
                  <div className="text-[10px] text-[#64748B] font-bold uppercase tracking-widest">{f.name}</div>
                  <div className={`text-xl font-bold my-1.5 ${f.z >= 0 ? 'text-[#00E5FF]' : 'text-[#EF4444]'}`}>
                    {f.z >= 0 ? '+' : ''}{f.z.toFixed(2)}σ
                  </div>
                  <div className="text-[9px] text-[#94A3B8]">{f.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 7: Event Studies (CAR) */}
      {activeSubTab === 'EVENT_STUDIES' && (
        <div className="space-y-4 font-mono text-xs">
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4">
            <div className="font-bold text-white text-xs border-b border-[#1E293B] pb-3 mb-3 flex items-center justify-between font-sans">
              <span className="tracking-wide">QUANTITATIVE EVENT STUDIES & CUMULATIVE ABNORMAL RETURNS (CAR)</span>
              <span className="text-[10px] text-[#64748B]">[-10, +10] Day Event Window</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs">
                <thead>
                  <tr className="border-b border-[#1E293B] text-[10px] text-[#64748B] uppercase tracking-widest font-bold">
                    <th className="py-2 px-2">Ticker</th>
                    <th className="py-2 px-2">Event Date</th>
                    <th className="py-2 px-2">Event Type</th>
                    <th className="py-2 px-2">Event Description</th>
                    <th className="py-2 px-2 text-right">Event Day Move</th>
                    <th className="py-2 px-2 text-right">CAR (+10D)</th>
                    <th className="py-2 px-2 text-right">Pre-Event 5D</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1E293B]/60">
                  {MarketDataStore.getEventStudies()
                    .filter((ev) => ev.ticker === stock.ticker || true)
                    .slice(0, 8)
                    .map((ev, idx) => (
                      <tr key={idx} className={ev.ticker === stock.ticker ? 'bg-[#00E5FF]/10 font-bold' : 'hover:bg-[#1E293B]/40'}>
                        <td className="py-2 px-2 font-bold text-[#00E5FF]">{ev.ticker}</td>
                        <td className="py-2 px-2 text-[#94A3B8]">{ev.eventDate}</td>
                        <td className="py-2 px-2 font-semibold text-white">{ev.eventType}</td>
                        <td className="py-2 px-2 text-[#CBD5E1]">{ev.eventName}</td>
                        <td className={`py-2 px-2 text-right font-bold ${ev.eventDayReturn >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                          {ev.eventDayReturn >= 0 ? '+' : ''}{ev.eventDayReturn.toFixed(2)}%
                        </td>
                        <td className={`py-2 px-2 text-right font-bold ${ev.cumulativeAbnormalReturn >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                          {ev.cumulativeAbnormalReturn >= 0 ? '+' : ''}{ev.cumulativeAbnormalReturn.toFixed(2)}%
                        </td>
                        <td className="py-2 px-2 text-right text-[#CBD5E1]">{ev.preEventReturn5D.toFixed(2)}%</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
