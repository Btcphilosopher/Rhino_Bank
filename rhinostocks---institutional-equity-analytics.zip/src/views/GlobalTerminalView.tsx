/**
 * RhinoStocks - Global Equity Terminal View
 * Primary Opening Dashboard & Market Intelligence Overview
 */

import React, { useState } from 'react';
import {
  GlobalIndex,
  RhinoStock,
  MarketBreadth,
  MarketRegimeState,
  SectorMetric,
  CountryMetric,
  MarketConcentration,
  AnomalyItem,
  Sector,
} from '../types';
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Globe,
  PieChart,
  Layers,
  ShieldAlert,
  ArrowUpRight,
  ArrowDownRight,
  Filter,
  Eye,
  BarChart2,
  Info,
} from 'lucide-react';

interface GlobalTerminalViewProps {
  indices: GlobalIndex[];
  stocks: RhinoStock[];
  breadth: MarketBreadth;
  regime: MarketRegimeState;
  sectors: SectorMetric[];
  countries: CountryMetric[];
  concentration: MarketConcentration;
  anomalies: AnomalyItem[];
  onSelectStock: (ticker: string) => void;
  onSelectSector: (sector: Sector) => void;
}

export const GlobalTerminalView: React.FC<GlobalTerminalViewProps> = ({
  indices,
  stocks,
  breadth,
  regime,
  sectors,
  countries,
  concentration,
  anomalies,
  onSelectStock,
  onSelectSector,
}) => {
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'REGIONS' | 'CONCENTRATION' | 'ANOMALIES'>('OVERVIEW');
  const [selectedRegionFilter, setSelectedRegionFilter] = useState<string>('ALL');

  const topRisers = [...stocks].sort((a, b) => b.changePct1D - a.changePct1D).slice(0, 5);
  const topFallers = [...stocks].sort((a, b) => a.changePct1D - b.changePct1D).slice(0, 5);
  const mostActive = [...stocks].sort((a, b) => b.volume * b.price - a.volume * a.price).slice(0, 5);

  const filteredCountries = selectedRegionFilter === 'ALL'
    ? countries
    : countries.filter((c) => c.region === selectedRegionFilter);

  return (
    <div className="p-4 space-y-4 max-w-[1800px] mx-auto text-[#CBD5E1] font-sans" id="global-terminal-view">
      {/* Top Level Summary Banner */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 font-mono text-xs">
        {/* 1. Market Regime Banner */}
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-[#64748B] uppercase tracking-widest">RHINO MARKET REGIME</span>
            <span className="px-1.5 py-0.5 rounded-sm text-[10px] font-bold bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/30">
              PROB: {(regime.probability * 100).toFixed(0)}%
            </span>
          </div>
          <div className="my-2 flex items-baseline justify-between">
            <span className="text-xl font-bold tracking-tight text-[#10B981] font-sans">{regime.currentRegime}</span>
            <span className="text-[11px] text-[#94A3B8]">Duration: {regime.durationDays}d</span>
          </div>
          <div className="flex items-center justify-between text-[11px] pt-2 border-t border-[#1E293B] text-[#94A3B8]">
            <span>Vol: <b className="text-white">{regime.volatilityCondition}</b></span>
            <span>Breadth: <b className="text-[#10B981]">{regime.breadthCondition}</b></span>
            <span>Macro: <b className="text-white">{regime.macroCondition}</b></span>
          </div>
        </div>

        {/* 2. Market Breadth */}
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-[#64748B] uppercase tracking-widest">MARKET BREADTH</span>
            <span className="text-[10px] text-[#94A3B8]">A/D Ratio: <b className="text-[#10B981]">{breadth.adRatio}x</b></span>
          </div>
          <div className="my-2 flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-[#10B981] font-bold text-sm">
              <span>{breadth.advancers} Adv</span>
            </div>
            <div className="flex-1 mx-3 h-1.5 rounded-none bg-[#1E293B] overflow-hidden flex">
              <div
                style={{ width: `${(breadth.advancers / (breadth.advancers + breadth.decliners || 1)) * 100}%` }}
                className="bg-[#10B981] h-full"
              />
              <div
                style={{ width: `${(breadth.decliners / (breadth.advancers + breadth.decliners || 1)) * 100}%` }}
                className="bg-[#EF4444] h-full"
              />
            </div>
            <div className="flex items-center gap-1.5 text-[#EF4444] font-bold text-sm">
              <span>{breadth.decliners} Dec</span>
            </div>
          </div>
          <div className="flex items-center justify-between text-[11px] pt-2 border-t border-[#1E293B] text-[#94A3B8]">
            <span>&gt;50 DMA: <b className="text-[#00E5FF]">{breadth.pctAbove50DMA}%</b></span>
            <span>&gt;200 DMA: <b className="text-[#00E5FF]">{breadth.pctAbove200DMA}%</b></span>
            <span>52W Highs: <b className="text-[#10B981]">{breadth.new52WHighs}</b></span>
          </div>
        </div>

        {/* 3. Market Concentration (HHI) */}
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-[#64748B] uppercase tracking-widest">CONCENTRATION (HHI)</span>
            <span className="text-[10px] text-[#F59E0B] font-bold">HHI: {concentration.herfindahlIndex}</span>
          </div>
          <div className="my-2 flex items-baseline justify-between">
            <span className="text-sm font-semibold text-white">
              Top 5: <b className="text-[#00E5FF]">{concentration.top5WeightPct}%</b> weight
            </span>
            <span className="text-xs text-[#94A3B8]">
              Contrib: <b className="text-[#10B981]">+{concentration.top5ReturnContributionPct}%</b>
            </span>
          </div>
          <div className="flex items-center justify-between text-[11px] pt-2 border-t border-[#1E293B] text-[#94A3B8]">
            <span>Cap-Wt 1Y: <b className="text-[#10B981]">+{concentration.capWeight1YReturn}%</b></span>
            <span>Eq-Wt 1Y: <b className="text-white">+{concentration.equalWeight1YReturn}%</b></span>
            <span>Spread: <b className="text-[#00E5FF]">+{concentration.weightReturnSpread}%</b></span>
          </div>
        </div>

        {/* 4. Statistical Anomalies Count */}
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-[#64748B] uppercase tracking-widest">RHINO ANOMALY SCAN</span>
            <span className="text-[10px] text-[#EF4444] font-bold flex items-center gap-1">
              <ShieldAlert className="w-3 h-3" />
              {anomalies.length} FLAGGED
            </span>
          </div>
          <div className="my-2 flex items-center justify-between">
            <div className="text-xs text-[#CBD5E1] truncate max-w-[180px]">
              Top Outlier: <b className="text-[#00E5FF]">{anomalies[0]?.ticker || 'NVDA'}</b>
            </div>
            <span className="px-1.5 py-0.5 rounded-sm text-[10px] font-bold bg-[#EF4444]/10 text-[#EF4444] border border-[#EF4444]/30">
              Z-Score: {anomalies[0]?.zScore || '3.4'}
            </span>
          </div>
          <div className="text-[11px] pt-2 border-t border-[#1E293B] text-[#94A3B8] truncate">
            {anomalies[0]?.primaryReason || 'Volume spike with aggressive revision'}
          </div>
        </div>
      </div>

      {/* Main Multi-Panel Workspace Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column (2/3 width on desktop): Global Indices & Regional Equity Markets */}
        <div className="lg:col-span-2 space-y-4">
          {/* Global Indices Matrix */}
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#1E293B] text-xs font-mono">
              <div className="flex items-center gap-2 font-bold text-white font-sans">
                <Globe className="w-4 h-4 text-[#00E5FF]" />
                <span className="tracking-wide">GLOBAL EQUITY BENCHMARKS & MULTIPLES</span>
              </div>
              <span className="text-[#64748B] text-[11px]">Real-time index valuation & momentum</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs">
                <thead>
                  <tr className="border-b border-[#1E293B] text-[10px] text-[#64748B] uppercase tracking-widest font-bold">
                    <th className="py-2 px-2">Index</th>
                    <th className="py-2 px-2">Region</th>
                    <th className="py-2 px-2 text-right">Value</th>
                    <th className="py-2 px-2 text-right">1D %</th>
                    <th className="py-2 px-2 text-right">YTD %</th>
                    <th className="py-2 px-2 text-right">1Y %</th>
                    <th className="py-2 px-2 text-right">1Y Vol</th>
                    <th className="py-2 px-2 text-right">P/E</th>
                    <th className="py-2 px-2 text-right">Div Yld</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1E293B]/60">
                  {indices.map((idx) => {
                    const is1DUp = idx.changePct1D >= 0;
                    return (
                      <tr key={idx.symbol} className="hover:bg-[#1E293B]/40 transition-colors">
                        <td className="py-2 px-2 font-bold text-[#00E5FF]">
                          {idx.name}
                          <span className="text-[10px] text-[#64748B] block font-normal">{idx.symbol}</span>
                        </td>
                        <td className="py-2 px-2 text-[#94A3B8]">{idx.country}</td>
                        <td className="py-2 px-2 text-right font-semibold text-white">
                          {idx.value.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 1 })}
                        </td>
                        <td className={`py-2 px-2 text-right font-bold ${is1DUp ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                          {is1DUp ? '+' : ''}
                          {idx.changePct1D.toFixed(2)}%
                        </td>
                        <td className="py-2 px-2 text-right text-[#CBD5E1]">+{idx.returnYTD.toFixed(1)}%</td>
                        <td className="py-2 px-2 text-right font-semibold text-[#10B981]">+{idx.return1Y.toFixed(1)}%</td>
                        <td className="py-2 px-2 text-right text-[#94A3B8]">{idx.volatility1Y.toFixed(1)}%</td>
                        <td className="py-2 px-2 text-right text-[#CBD5E1]">{idx.peRatio.toFixed(1)}x</td>
                        <td className="py-2 px-2 text-right text-[#CBD5E1]">{idx.divYield.toFixed(2)}%</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Regional Country Equity Breakdown */}
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-[#1E293B] text-xs font-mono">
              <div className="flex items-center gap-2 font-bold text-white font-sans">
                <Globe className="w-4 h-4 text-[#10B981]" />
                <span className="tracking-wide">RHINO GLOBAL GEOGRAPHIC EQUITY MAP</span>
              </div>
              <div className="flex items-center gap-1 bg-[#0B0F19] p-0.5 rounded-sm border border-[#334155] text-[10px]">
                {['ALL', 'Americas', 'EMEA', 'APAC'].map((r) => (
                  <button
                    key={r}
                    onClick={() => setSelectedRegionFilter(r)}
                    className={`px-2 py-0.5 rounded-xs uppercase font-semibold transition-colors ${
                      selectedRegionFilter === r ? 'bg-[#00E5FF] text-[#0B0F19]' : 'text-[#94A3B8] hover:text-white'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 font-mono text-xs">
              {filteredCountries.map((c) => (
                <div
                  key={c.country}
                  className="bg-[#0B1222] border border-[#1E293B] hover:border-[#00E5FF]/60 rounded-sm p-3 transition-all flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white font-sans">{c.country}</span>
                      <span className="text-[10px] text-[#64748B] ml-1.5">({c.code})</span>
                    </div>
                    <span className="text-[10px] text-[#00E5FF] font-bold">${c.marketCapTotal}B</span>
                  </div>

                  <div className="my-2.5 grid grid-cols-2 gap-1.5 text-[11px]">
                    <div>
                      <span className="text-[#64748B] block text-[9px] uppercase">1Y RETURN</span>
                      <span className="font-bold text-[#10B981]">+{c.return1Y}%</span>
                    </div>
                    <div>
                      <span className="text-[#64748B] block text-[9px] uppercase">1Y VOLATILITY</span>
                      <span className="text-[#CBD5E1]">{c.volatility1Y}%</span>
                    </div>
                    <div>
                      <span className="text-[#64748B] block text-[9px] uppercase">P/E MULTIPLE</span>
                      <span className="text-[#CBD5E1]">{c.peRatio}x</span>
                    </div>
                    <div>
                      <span className="text-[#64748B] block text-[9px] uppercase">DIVIDEND YIELD</span>
                      <span className="text-[#CBD5E1]">{c.dividendYield}%</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-[#1E293B] flex items-center justify-between text-[10px]">
                    <span className="text-[#64748B]">{c.stockCount} tracked equities</span>
                    <button
                      onClick={() => onSelectStock(c.topStockTicker)}
                      className="text-[#00E5FF] hover:underline font-bold"
                    >
                      Top: {c.topStockTicker} →
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (1/3 width on desktop): Sector Rotation, Risers/Fallers, Top Anomalies */}
        <div className="space-y-4 font-mono text-xs">
          {/* GICS Sector Rotation & Valuation Summary */}
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#1E293B] text-xs font-bold text-white font-sans">
              <div className="flex items-center gap-2">
                <PieChart className="w-4 h-4 text-[#00E5FF]" />
                <span className="tracking-wide">SECTOR PERFORMANCE & CYCLE</span>
              </div>
              <span className="text-[10px] text-[#64748B] font-normal">Click to drill down</span>
            </div>

            <div className="space-y-2">
              {sectors.map((sec) => {
                const isLeading = sec.rotationState === 'LEADING';
                const isLagging = sec.rotationState === 'LAGGING';
                const stateColor = isLeading ? 'text-[#10B981]' : isLagging ? 'text-[#EF4444]' : 'text-[#F59E0B]';
                return (
                  <div
                    key={sec.sector}
                    onClick={() => onSelectSector(sec.sector)}
                    className="p-2.5 rounded-sm bg-[#0B1222] hover:bg-[#1E293B]/60 border border-[#1E293B] transition-colors cursor-pointer flex items-center justify-between group"
                  >
                    <div>
                      <div className="font-semibold text-white group-hover:text-[#00E5FF] font-sans">
                        {sec.sector}
                      </div>
                      <div className="text-[10px] text-[#64748B] flex items-center gap-2 mt-0.5">
                        <span>P/E: <b className="text-[#CBD5E1]">{sec.peRatio}x</b></span>
                        <span>•</span>
                        <span>Div: <b className="text-[#CBD5E1]">{sec.dividendYield}%</b></span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="font-bold text-[#10B981]">+{sec.return1Y}%</div>
                      <div className={`text-[10px] font-bold ${stateColor}`}>
                        {sec.rotationState}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Movers Tabs: Top Risers / Top Fallers */}
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#1E293B] font-bold text-white font-sans">
              <span className="tracking-wide">UNIVERSE MOVERS (1D)</span>
            </div>

            <div className="space-y-3">
              <div className="text-[11px] text-[#10B981] font-bold flex items-center gap-1 uppercase tracking-wider">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>TOP ADVANCERS</span>
              </div>
              <div className="space-y-1.5">
                {topRisers.map((s) => (
                  <div
                    key={s.ticker}
                    onClick={() => onSelectStock(s.ticker)}
                    className="flex items-center justify-between p-2 rounded-sm bg-[#0B1222] hover:bg-[#1E293B] cursor-pointer transition-colors border-l-2 border-[#10B981]"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-[#00E5FF] w-14">{s.ticker}</span>
                      <span className="text-[#CBD5E1] truncate max-w-[110px]">{s.company}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-[#10B981]">+{s.changePct1D.toFixed(2)}%</span>
                      <span className="text-[10px] text-[#64748B] block">${s.price.toFixed(2)}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="text-[11px] text-[#EF4444] font-bold flex items-center gap-1 pt-3 border-t border-[#1E293B] uppercase tracking-wider">
                <TrendingDown className="w-3.5 h-3.5" />
                <span>TOP DECLINERS</span>
              </div>
              <div className="space-y-1.5">
                {topFallers.map((s) => (
                  <div
                    key={s.ticker}
                    onClick={() => onSelectStock(s.ticker)}
                    className="flex items-center justify-between p-2 rounded-sm bg-[#0B1222] hover:bg-[#1E293B] cursor-pointer transition-colors border-l-2 border-[#EF4444]"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-[#00E5FF] w-14">{s.ticker}</span>
                      <span className="text-[#CBD5E1] truncate max-w-[110px]">{s.company}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-[#EF4444]">{s.changePct1D.toFixed(2)}%</span>
                      <span className="text-[10px] text-[#64748B] block">${s.price.toFixed(2)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
