/**
 * RhinoStocks - Correlation Matrix & Risk Laboratory View
 * Interactive Heatmap, Risk Decomposition, Moments & Value-at-Risk
 */

import React, { useState } from 'react';
import { RhinoStock } from '../types';
import { CorrelationMatrixHeatmap } from '../components/charts/SectorRotationChart';
import {
  BarChart3,
  ShieldAlert,
  Sliders,
  Layers,
  Activity,
  Download,
} from 'lucide-react';

interface CorrelationRiskViewProps {
  stocks: RhinoStock[];
  onSelectStock: (ticker: string) => void;
}

export const CorrelationRiskView: React.FC<CorrelationRiskViewProps> = ({
  stocks,
  onSelectStock,
}) => {
  const [corrType, setCorrType] = useState<'PEARSON' | 'SPEARMAN'>('PEARSON');
  const [subsetCount, setSubsetCount] = useState<number>(12);

  const selectedStocks = stocks.slice(0, subsetCount);
  const items = selectedStocks.map((s) => ({
    ticker: s.ticker,
    returns: s.history.map((b) => b.returnPct),
  }));

  return (
    <div className="p-4 space-y-4 max-w-[1800px] mx-auto text-[#CBD5E1] font-sans" id="correlation-risk-view">
      {/* Header & Controls Bar */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 font-mono text-xs">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-[#00E5FF]" />
            <span className="font-bold text-white font-sans text-sm tracking-wide">
              INTERACTIVE RETURN CORRELATION & RISK DECOMPOSITION MATRIX
            </span>
          </div>

          <div className="flex items-center gap-4">
            {/* Correlation Mode */}
            <div className="flex items-center gap-1 bg-[#0B0F19] p-0.5 rounded-xs border border-[#334155]">
              <button
                onClick={() => setCorrType('PEARSON')}
                className={`px-3 py-1 rounded-xs text-xs font-semibold transition-colors ${
                  corrType === 'PEARSON'
                    ? 'bg-[#00E5FF]/20 text-[#00E5FF] font-bold border border-[#00E5FF]/40'
                    : 'text-[#94A3B8] hover:text-white'
                }`}
              >
                Pearson Linear (ρ)
              </button>
              <button
                onClick={() => setCorrType('SPEARMAN')}
                className={`px-3 py-1 rounded-xs text-xs font-semibold transition-colors ${
                  corrType === 'SPEARMAN'
                    ? 'bg-[#00E5FF]/20 text-[#00E5FF] font-bold border border-[#00E5FF]/40'
                    : 'text-[#94A3B8] hover:text-white'
                }`}
              >
                Spearman Rank (r)
              </button>
            </div>

            {/* Matrix Size Slider/Select */}
            <div className="flex items-center gap-2 text-xs text-[#64748B]">
              <span className="uppercase font-bold tracking-widest text-[10px]">Matrix Size:</span>
              <select
                value={subsetCount}
                onChange={(e) => setSubsetCount(Number(e.target.value))}
                className="bg-[#0B0F19] border border-[#334155] rounded-xs px-2.5 py-1 text-[#CBD5E1] focus:outline-none focus:border-[#00E5FF]"
              >
                <option value={8}>Top 8 Securities</option>
                <option value={12}>Top 12 Securities</option>
                <option value={16}>Top 16 Securities</option>
                <option value={20}>Top 20 Securities</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Heatmap & Risk Summary Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 font-mono text-xs">
        {/* Heatmap Visualizer */}
        <div className="lg:col-span-7 bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-[#1E293B]">
            <span className="font-bold text-white font-sans text-xs tracking-wide">PAIRWISE 252-DAY RETURN CORRELATION MATRIX</span>
            <span className="text-[10px] text-[#00E5FF]">Range: [-1.0 Deep Blue, +1.0 Deep Emerald]</span>
          </div>
          <div className="flex-1 w-full mt-3 min-h-[440px]">
            <CorrelationMatrixHeatmap items={items} type={corrType} />
          </div>
        </div>

        {/* Cross-Sectional Risk & VaR Metrics Table */}
        <div className="lg:col-span-5 bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 flex flex-col">
          <div className="font-bold text-white text-xs border-b border-[#1E293B] pb-3 mb-3 flex items-center justify-between font-sans">
            <span className="tracking-wide">RISK & VALUE-AT-RISK (VaR) LEADERBOARD</span>
            <span className="text-[10px] text-[#64748B]">95% Conf (1-Day Horizon)</span>
          </div>

          <div className="overflow-x-auto flex-1 max-h-[460px]">
            <table className="w-full text-left font-mono text-xs">
              <thead>
                <tr className="border-b border-[#1E293B] text-[10px] text-[#64748B] uppercase tracking-widest font-bold sticky top-0 bg-[#0F172A]">
                  <th className="py-2 px-2">Ticker</th>
                  <th className="py-2 px-2 text-right">1Y Vol</th>
                  <th className="py-2 px-2 text-right">VaR 95%</th>
                  <th className="py-2 px-2 text-right">CVaR 95%</th>
                  <th className="py-2 px-2 text-right">Max DD</th>
                  <th className="py-2 px-2 text-right">Sharpe</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B]/60">
                {selectedStocks.map((s) => (
                  <tr
                    key={s.ticker}
                    onClick={() => onSelectStock(s.ticker)}
                    className="hover:bg-[#1E293B]/40 cursor-pointer transition-colors"
                  >
                    <td className="py-2 px-2 font-bold text-[#00E5FF]">{s.ticker}</td>
                    <td className="py-2 px-2 text-right text-[#CBD5E1]">{s.risk.realizedVol1Y}%</td>
                    <td className="py-2 px-2 text-right font-semibold text-[#EF4444]">-{s.risk.var95}%</td>
                    <td className="py-2 px-2 text-right text-[#EF4444]">-{s.risk.cvar95}%</td>
                    <td className="py-2 px-2 text-right text-[#EF4444]">{s.risk.maxDrawdown}%</td>
                    <td className="py-2 px-2 text-right font-bold text-[#10B981]">{s.risk.sharpeRatio}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
