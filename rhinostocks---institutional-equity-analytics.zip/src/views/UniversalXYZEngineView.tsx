/**
 * RhinoStocks - Universal X/Y/Z Analytics Engine View
 * Flagship Multi-Dimensional Quantitative Market Engine & 3D Interactive Surfaces
 */

import React, { useState } from 'react';
import { RhinoStock, Sector } from '../types';
import { PlotlyUniversalChart } from '../components/charts/PlotlySurfaceChart';
import {
  Box,
  Layers,
  Sliders,
  Sparkles,
  TrendingUp,
  Filter,
  BarChart2,
  Maximize2,
  RotateCcw,
  CheckCircle2,
} from 'lucide-react';

interface UniversalXYZEngineViewProps {
  stocks: RhinoStock[];
  onSelectStock: (ticker: string) => void;
  selectedStockTicker: string;
}

interface MetricOption {
  key: string;
  label: string;
  category: 'VALUATION' | 'PERFORMANCE' | 'PROFITABILITY' | 'RISK' | 'FACTOR';
}

const AVAILABLE_METRICS: MetricOption[] = [
  // Valuation
  { key: 'pe', label: 'P/E Multiple (TTM)', category: 'VALUATION' },
  { key: 'pb', label: 'Price to Book (P/B)', category: 'VALUATION' },
  { key: 'evToEbitda', label: 'EV / EBITDA', category: 'VALUATION' },
  { key: 'fcfYield', label: 'Free Cash Flow Yield (%)', category: 'VALUATION' },
  { key: 'dividendYield', label: 'Dividend Yield (%)', category: 'VALUATION' },

  // Performance & Growth
  { key: 'return1Y', label: '1-Year Total Return (%)', category: 'PERFORMANCE' },
  { key: 'return3M', label: '3-Month Return (%)', category: 'PERFORMANCE' },
  { key: 'returnYTD', label: 'Year-to-Date Return (%)', category: 'PERFORMANCE' },
  { key: 'revenueGrowth', label: 'Revenue Growth YoY (%)', category: 'PERFORMANCE' },
  { key: 'epsGrowth', label: 'EPS Growth YoY (%)', category: 'PERFORMANCE' },
  { key: 'marketCap', label: 'Market Capitalization ($B)', category: 'PERFORMANCE' },
  { key: 'momentum12M', label: '12M Price Momentum (%)', category: 'PERFORMANCE' },

  // Profitability & Quality
  { key: 'roe', label: 'Return on Equity (ROE %)', category: 'PROFITABILITY' },
  { key: 'roic', label: 'Return on Invested Capital (ROIC %)', category: 'PROFITABILITY' },
  { key: 'grossMargin', label: 'Gross Profit Margin (%)', category: 'PROFITABILITY' },
  { key: 'debtToEquity', label: 'Debt to Equity Ratio (D/E)', category: 'PROFITABILITY' },

  // Risk & Volatility
  { key: 'realizedVol1Y', label: '1-Year Realized Volatility (%)', category: 'RISK' },
  { key: 'realizedVol30D', label: '30-Day Realized Volatility (%)', category: 'RISK' },
  { key: 'beta', label: 'Market Beta (to SPX)', category: 'RISK' },
  { key: 'sharpe', label: 'Sharpe Ratio (Rf=4%)', category: 'RISK' },
  { key: 'maxDrawdown', label: 'Maximum Drawdown (%)', category: 'RISK' },

  // Factor Models & Scoring
  { key: 'rhinoScore', label: 'Rhino Equity Score (0-100)', category: 'FACTOR' },
  { key: 'factorValue', label: 'Value Factor Z-Score', category: 'FACTOR' },
  { key: 'factorGrowth', label: 'Growth Factor Z-Score', category: 'FACTOR' },
  { key: 'factorMomentum', label: 'Momentum Factor Z-Score', category: 'FACTOR' },
  { key: 'factorQuality', label: 'Quality Factor Z-Score', category: 'FACTOR' },
];

interface PresetConfig {
  name: string;
  description: string;
  xKey: string;
  yKey: string;
  zKey?: string;
  is3D: boolean;
}

const PRESETS: PresetConfig[] = [
  {
    name: 'Valuation vs Growth',
    description: 'P/E Multiple vs Earnings Growth YoY (GARP Analysis)',
    xKey: 'pe',
    yKey: 'epsGrowth',
    is3D: false,
  },
  {
    name: 'Risk vs Return',
    description: '1Y Realized Volatility vs 1Y Total Return (Capital Market Line)',
    xKey: 'realizedVol1Y',
    yKey: 'return1Y',
    is3D: false,
  },
  {
    name: 'Capital Efficiency',
    description: 'ROIC vs Free Cash Flow Yield (Buffett Quality Screen)',
    xKey: 'roic',
    yKey: 'fcfYield',
    is3D: false,
  },
  {
    name: 'Value vs Momentum',
    description: 'Factor Space: Value Z-Score vs Momentum Z-Score',
    xKey: 'factorValue',
    yKey: 'factorMomentum',
    is3D: false,
  },
  {
    name: 'Size vs Performance',
    description: 'Market Cap ($B) vs 1Y Return (%)',
    xKey: 'marketCap',
    yKey: 'return1Y',
    is3D: false,
  },
  {
    name: '3D: Valuation / Growth / ROIC',
    description: 'Interactive 3D Surface: P/E (X), EPS Growth (Y), ROIC (Z)',
    xKey: 'pe',
    yKey: 'epsGrowth',
    zKey: 'roic',
    is3D: true,
  },
  {
    name: '3D: Size / Return / Volatility',
    description: 'Interactive 3D Surface: Market Cap (X), 1Y Return (Y), Volatility (Z)',
    xKey: 'marketCap',
    yKey: 'return1Y',
    zKey: 'realizedVol1Y',
    is3D: true,
  },
];

export const UniversalXYZEngineView: React.FC<UniversalXYZEngineViewProps> = ({
  stocks,
  onSelectStock,
  selectedStockTicker,
}) => {
  const [xAxisKey, setXAxisKey] = useState<string>('pe');
  const [yAxisKey, setYAxisKey] = useState<string>('epsGrowth');
  const [zAxisKey, setZAxisKey] = useState<string>('roic');
  const [is3DMode, setIs3DMode] = useState<boolean>(false);
  const [selectedSector, setSelectedSector] = useState<string>('ALL');

  const xOption = AVAILABLE_METRICS.find((m) => m.key === xAxisKey) || AVAILABLE_METRICS[0];
  const yOption = AVAILABLE_METRICS.find((m) => m.key === yAxisKey) || AVAILABLE_METRICS[5];
  const zOption = AVAILABLE_METRICS.find((m) => m.key === zAxisKey) || AVAILABLE_METRICS[12];

  const filteredStocks = selectedSector === 'ALL'
    ? stocks
    : stocks.filter((s) => s.sector === selectedSector);

  const applyPreset = (p: PresetConfig) => {
    setXAxisKey(p.xKey);
    setYAxisKey(p.yKey);
    if (p.zKey) setZAxisKey(p.zKey);
    setIs3DMode(p.is3D);
  };

  return (
    <div className="p-4 space-y-4 max-w-[1800px] mx-auto text-[#CBD5E1] font-sans" id="xyz-engine-view">
      {/* Top Configuration Bar */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1E293B] pb-3 font-mono text-xs">
          <div className="flex items-center gap-2">
            <Box className="w-4 h-4 text-[#00E5FF]" />
            <span className="font-bold text-white font-sans text-sm tracking-wide">
              UNIVERSAL X/Y/Z QUANTITATIVE ANALYTICS ENGINE
            </span>
          </div>

          {/* 2D / 3D Mode Toggle */}
          <div className="flex items-center gap-2">
            <span className="text-[#64748B] text-[11px] uppercase tracking-wider font-semibold">Visualization:</span>
            <div className="flex bg-[#0B0F19] p-0.5 rounded-sm border border-[#334155]">
              <button
                onClick={() => setIs3DMode(false)}
                className={`px-3 py-1 rounded-xs text-xs font-semibold transition-colors ${
                  !is3DMode ? 'bg-[#00E5FF] text-[#0B0F19] font-bold' : 'text-[#94A3B8] hover:text-white'
                }`}
              >
                2D Cross-Section (OLS Fit)
              </button>
              <button
                onClick={() => setIs3DMode(true)}
                className={`px-3 py-1 rounded-xs text-xs font-semibold transition-colors flex items-center gap-1 ${
                  is3DMode ? 'bg-[#00E5FF] text-[#0B0F19] font-bold' : 'text-[#94A3B8] hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                3D Interactive Surface
              </button>
            </div>
          </div>
        </div>

        {/* Dimension Selectors */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 font-mono text-xs">
          {/* X Axis Selector */}
          <div>
            <label className="block text-[#64748B] text-[10px] uppercase font-bold tracking-widest mb-1.5 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#00E5FF]" />
              X-AXIS METRIC
            </label>
            <select
              value={xAxisKey}
              onChange={(e) => setXAxisKey(e.target.value)}
              className="w-full bg-[#0B0F19] border border-[#334155] rounded-sm px-2.5 py-1.5 text-xs text-[#CBD5E1] font-mono focus:border-[#00E5FF] focus:outline-none"
            >
              {AVAILABLE_METRICS.map((m) => (
                <option key={m.key} value={m.key}>
                  [{m.category}] {m.label}
                </option>
              ))}
            </select>
          </div>

          {/* Y Axis Selector */}
          <div>
            <label className="block text-[#64748B] text-[10px] uppercase font-bold tracking-widest mb-1.5 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#10B981]" />
              Y-AXIS METRIC
            </label>
            <select
              value={yAxisKey}
              onChange={(e) => setYAxisKey(e.target.value)}
              className="w-full bg-[#0B0F19] border border-[#334155] rounded-sm px-2.5 py-1.5 text-xs text-[#CBD5E1] font-mono focus:border-[#00E5FF] focus:outline-none"
            >
              {AVAILABLE_METRICS.map((m) => (
                <option key={m.key} value={m.key}>
                  [{m.category}] {m.label}
                </option>
              ))}
            </select>
          </div>

          {/* Z Axis Selector (when 3D enabled) */}
          <div className={!is3DMode ? 'opacity-40' : ''}>
            <label className="block text-[#64748B] text-[10px] uppercase font-bold tracking-widest mb-1.5 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#F59E0B]" />
              Z-AXIS METRIC {is3DMode ? '(3D Surface)' : '(Inactive in 2D)'}
            </label>
            <select
              disabled={!is3DMode}
              value={zAxisKey}
              onChange={(e) => setZAxisKey(e.target.value)}
              className="w-full bg-[#0B0F19] border border-[#334155] rounded-sm px-2.5 py-1.5 text-xs text-[#CBD5E1] font-mono focus:border-[#00E5FF] focus:outline-none"
            >
              {AVAILABLE_METRICS.map((m) => (
                <option key={m.key} value={m.key}>
                  [{m.category}] {m.label}
                </option>
              ))}
            </select>
          </div>

          {/* Sector Filter */}
          <div>
            <label className="block text-[#64748B] text-[10px] uppercase font-bold tracking-widest mb-1.5 flex items-center gap-1.5">
              <Filter className="w-3 h-3 text-[#64748B]" />
              SECTOR FILTER
            </label>
            <select
              value={selectedSector}
              onChange={(e) => setSelectedSector(e.target.value)}
              className="w-full bg-[#0B0F19] border border-[#334155] rounded-sm px-2.5 py-1.5 text-xs text-[#CBD5E1] font-mono focus:border-[#00E5FF] focus:outline-none"
            >
              <option value="ALL">All Sectors ({stocks.length} Stocks)</option>
              {Array.from(new Set(stocks.map((s) => s.sector))).map((sec) => (
                <option key={sec} value={sec}>
                  {sec} ({stocks.filter((s) => s.sector === sec).length})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Curated Institutional Research Presets */}
        <div className="flex items-center gap-2 overflow-x-auto pt-2 pb-0.5 text-xs font-mono scrollbar-none border-t border-[#1E293B]">
          <span className="text-[#64748B] text-[10px] font-bold uppercase tracking-widest whitespace-nowrap">
            PRESETS:
          </span>
          {PRESETS.map((p) => {
            const isSelected =
              xAxisKey === p.xKey && yAxisKey === p.yKey && is3DMode === p.is3D;
            return (
              <button
                key={p.name}
                onClick={() => applyPreset(p)}
                className={`px-2.5 py-1 rounded-xs text-[11px] whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-[#00E5FF] text-[#0B0F19] font-bold'
                    : 'bg-[#0B0F19] text-[#94A3B8] hover:text-white hover:bg-[#1E293B] border border-[#334155]'
                }`}
              >
                {p.is3D && <Layers className="w-3 h-3 text-[#F59E0B]" />}
                <span>{p.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Interactive Chart Container */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 flex flex-col min-h-[560px]">
        <div className="flex items-center justify-between pb-3 border-b border-[#1E293B] font-mono text-xs">
          <div className="text-[#CBD5E1]">
            Active Space: <b className="text-[#00E5FF]">{xOption.label}</b> (X) vs{' '}
            <b className="text-[#10B981]">{yOption.label}</b> (Y)
            {is3DMode && (
              <>
                {' '}
                vs <b className="text-[#F59E0B]">{zOption.label}</b> (Z)
              </>
            )}
          </div>
          <div className="text-[11px] text-[#64748B]">
            {is3DMode ? 'Drag to rotate 3D orbit • Scroll to zoom' : 'Click any security bubble to open deep-dive terminal'}
          </div>
        </div>

        <div className="flex-1 w-full mt-3">
          <PlotlyUniversalChart
            stocks={filteredStocks}
            xAxisKey={xAxisKey}
            yAxisKey={yAxisKey}
            zAxisKey={zAxisKey}
            xAxisLabel={xOption.label}
            yAxisLabel={yOption.label}
            zAxisLabel={zOption.label}
            is3D={is3DMode}
            onSelectStock={onSelectStock}
            selectedTicker={selectedStockTicker}
          />
        </div>
      </div>
    </div>
  );
};
