/**
 * RhinoStocks - Market Regime & Statistical Anomalies View
 * Hidden Markov Models, Transition Matrices & Statistical Outlier Scanner
 */

import React, { useState } from 'react';
import { MarketRegimeState, AnomalyItem, RhinoStock } from '../types';
import {
  ShieldAlert,
  Activity,
  Layers,
  TrendingUp,
  AlertTriangle,
  Zap,
  Filter,
  CheckCircle,
} from 'lucide-react';

interface RegimeAnomalyViewProps {
  regime: MarketRegimeState;
  anomalies: AnomalyItem[];
  stocks: RhinoStock[];
  onSelectStock: (ticker: string) => void;
}

export const RegimeAnomalyView: React.FC<RegimeAnomalyViewProps> = ({
  regime,
  anomalies,
  stocks,
  onSelectStock,
}) => {
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>('ALL');

  const filteredAnomalies = selectedTypeFilter === 'ALL'
    ? anomalies
    : anomalies.filter((a) => a.anomalyType === selectedTypeFilter);

  const regimeLabels = [
    'Bull Momentum',
    'Volatile Correction',
    'Stagflation',
    'Low Vol Compression',
    'High Stress Panic',
  ];

  return (
    <div className="p-4 space-y-4 max-w-[1800px] mx-auto text-[#CBD5E1] font-sans" id="regime-anomaly-view">
      {/* Top Banner: Hidden Markov Model (HMM) Active State */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 font-mono text-xs">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#1E293B]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xs bg-[#00E5FF]/10 border border-[#00E5FF]/30 flex items-center justify-center text-[#00E5FF]">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-bold text-white font-sans tracking-wide">
                  RHINO HIDDEN MARKOV REGIME CLASSIFIER (HMM)
                </span>
                <span className="bg-[#10B981]/20 text-[#10B981] text-[10px] px-2.5 py-0.5 rounded-xs border border-[#10B981]/40 font-bold">
                  ACTIVE: {regime.currentRegime.toUpperCase()}
                </span>
              </div>
              <div className="text-[11px] text-[#64748B] mt-0.5">
                Gaussian Mixture Emission Model • 5-State Latent Macro System
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div>
              <span className="text-[#64748B] text-[10px] block font-bold uppercase tracking-widest">REGIME PROBABILITY</span>
              <span className="text-xl font-bold text-[#00E5FF]">{(regime.probability * 100).toFixed(1)}%</span>
            </div>
            <div className="border-l border-[#1E293B] pl-5">
              <span className="text-[#64748B] text-[10px] block font-bold uppercase tracking-widest">PERSISTENCE (DAYS)</span>
              <span className="text-xl font-bold text-white">{regime.durationDays} Days</span>
            </div>
            <div className="border-l border-[#1E293B] pl-5">
              <span className="text-[#64748B] text-[10px] block font-bold uppercase tracking-widest">VOLATILITY REGIME</span>
              <span className="text-sm font-bold text-[#10B981] mt-1 block">{regime.volatilityCondition}</span>
            </div>
          </div>
        </div>

        {/* 5-State Markov Transition Probability Matrix */}
        <div className="mt-4">
          <div className="font-bold text-white mb-3 flex items-center justify-between font-sans text-xs">
            <span className="tracking-wide">5-STATE MARKOV TRANSITION PROBABILITY MATRIX [P(S_t | S_t-1)]</span>
            <span className="text-[10px] text-[#64748B] font-mono">Rows: Current State (t) • Columns: Next State (t+1)</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-center font-mono text-xs border border-[#1E293B]">
              <thead>
                <tr className="bg-[#0B1222] text-[#64748B] text-[10px] uppercase font-bold tracking-widest">
                  <th className="py-2 px-3 text-left border-r border-[#1E293B]">State (t) \ State (t+1)</th>
                  {regimeLabels.map((lbl) => (
                    <th key={lbl} className="py-2 px-2 border-r border-[#1E293B]">
                      {lbl}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B]">
                {regime.transitionMatrix.map((row, i) => (
                  <tr key={regimeLabels[i]} className={regimeLabels[i] === regime.currentRegime ? 'bg-[#00E5FF]/10 font-bold' : 'hover:bg-[#1E293B]/20'}>
                    <td className="py-2 px-3 text-left font-semibold text-[#CBD5E1] border-r border-[#1E293B]">
                      {regimeLabels[i]}
                    </td>
                    {row.map((prob, j) => {
                      const isDiagonal = i === j;
                      const opacity = Math.max(0.1, prob);
                      return (
                        <td
                          key={j}
                          style={{
                            backgroundColor: isDiagonal
                              ? `rgba(0, 229, 255, ${opacity * 0.25})`
                              : prob > 0.15
                              ? `rgba(245, 158, 11, ${opacity * 0.2})`
                              : 'transparent',
                          }}
                          className={`py-2 px-2 border-r border-[#1E293B] ${isDiagonal ? 'text-[#00E5FF] font-bold' : 'text-[#94A3B8]'}`}
                        >
                          {(prob * 100).toFixed(1)}%
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Statistical Anomaly Detection Scanner */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 font-mono text-xs space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#1E293B]">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-[#EF4444]" />
            <span className="font-bold text-white font-sans text-xs tracking-wide">CROSS-SECTIONAL STATISTICAL ANOMALY & OUTLIER RADAR</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[#64748B] text-[10px] uppercase font-bold tracking-widest">Filter Anomaly:</span>
            <select
              value={selectedTypeFilter}
              onChange={(e) => setSelectedTypeFilter(e.target.value)}
              className="bg-[#0B0F19] border border-[#334155] rounded-xs px-2.5 py-1 text-[#CBD5E1] text-xs focus:outline-none focus:border-[#00E5FF]"
            >
              <option value="ALL">All Flagged Anomalies ({anomalies.length})</option>
              <option value="VOLUME_SHOCK">Volume Shocks</option>
              <option value="VOLATILITY_CLUSTER">Volatility Clusters</option>
              <option value="VALUATION_OUTLIER">Valuation Outliers</option>
              <option value="MOMENTUM_BREAKDOWN">Momentum Breakdowns</option>
            </select>
          </div>
        </div>

        {/* Anomalies Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredAnomalies.map((anom) => (
            <div
              key={anom.ticker}
              onClick={() => onSelectStock(anom.ticker)}
              className="bg-[#0B1222] border border-[#1E293B] hover:border-[#00E5FF]/50 rounded-sm p-4 cursor-pointer transition-all flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-[#00E5FF] group-hover:text-[#00E5FF]">
                      {anom.ticker}
                    </span>
                    <span className="text-xs text-white font-sans">{anom.company}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-xs text-[10px] font-bold bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/40">
                    Z: {anom.zScore.toFixed(2)}σ
                  </span>
                </div>

                <div className="text-[11px] font-semibold text-[#EF4444] my-2 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-[#EF4444]" />
                  <span>{anom.anomalyType || anom.flags?.[0] || 'Statistical Outlier'}</span>
                </div>

                <p className="text-[11px] text-[#94A3B8] leading-relaxed">
                  {anom.primaryReason}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-[#1E293B] flex items-center justify-between text-[10px]">
                <span className="text-[#64748B]">{anom.sector}</span>
                <span className="text-[#00E5FF] group-hover:underline font-bold">
                  Open Terminal →
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
