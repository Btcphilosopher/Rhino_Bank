/**
 * RhinoStocks - Factor Research & PCA Decomposition View
 * Multi-Factor Equity Models, Barra Z-Scores & Principal Component Analysis
 */

import React from 'react';
import { RhinoStock } from '../types';
import { PCAFactorDecompositionChart } from '../components/charts/PCAChart';
import { Layers, Activity, TrendingUp, Sliders, BarChart2, ShieldCheck, Zap } from 'lucide-react';

interface FactorResearchViewProps {
  stocks: RhinoStock[];
  onSelectStock: (ticker: string) => void;
}

interface FactorModelSummary {
  name: string;
  code: string;
  description: string;
  return1Y: number;
  returnYTD: number;
  sharpe: number;
  volatility: number;
  spreadLongShort: number;
}

const FACTORS: FactorModelSummary[] = [
  {
    name: 'MOMENTUM (12-1M)',
    code: 'MOM',
    description: '12-month cross-sectional price return excluding latest month',
    return1Y: 24.8,
    returnYTD: 14.2,
    sharpe: 1.62,
    volatility: 15.3,
    spreadLongShort: 18.4,
  },
  {
    name: 'QUALITY (ROIC/FCF)',
    code: 'QUAL',
    description: 'High return on invested capital, low leverage & robust margins',
    return1Y: 19.5,
    returnYTD: 11.8,
    sharpe: 1.54,
    volatility: 12.6,
    spreadLongShort: 14.1,
  },
  {
    name: 'GROWTH (SALES/EPS)',
    code: 'GRO',
    description: 'Top quintile forward consensus revenue and earnings revisions',
    return1Y: 21.2,
    returnYTD: 13.0,
    sharpe: 1.35,
    volatility: 16.8,
    spreadLongShort: 15.6,
  },
  {
    name: 'LOW VOLATILITY',
    code: 'LOWV',
    description: 'Minimum idiosyncratic return variance over 252 trading days',
    return1Y: 12.4,
    returnYTD: 7.2,
    sharpe: 1.28,
    volatility: 9.7,
    spreadLongShort: 8.9,
  },
  {
    name: 'VALUE (PE/FCF YLD)',
    code: 'VAL',
    description: 'Composite ranking of high earnings yield, book value & cash flow',
    return1Y: 14.1,
    returnYTD: 8.5,
    sharpe: 0.98,
    volatility: 14.4,
    spreadLongShort: 9.7,
  },
  {
    name: 'SIZE (LOG MKT CAP)',
    code: 'SIZE',
    description: 'Small vs Large Cap premium (SMB factor spread)',
    return1Y: 8.6,
    returnYTD: 4.1,
    sharpe: 0.65,
    volatility: 16.2,
    spreadLongShort: 5.2,
  },
];

export const FactorResearchView: React.FC<FactorResearchViewProps> = ({
  stocks,
  onSelectStock,
}) => {
  return (
    <div className="p-4 space-y-4 max-w-[1800px] mx-auto text-[#CBD5E1] font-sans" id="factor-research-view">
      {/* Header Banner */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-[#1E293B] font-mono text-xs">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#00E5FF]" />
            <span className="font-bold text-white font-sans text-sm tracking-wide">
              BARRA MULTI-FACTOR PREMIA & EIGENVECTOR DECOMPOSITION
            </span>
          </div>
          <div className="text-[11px] text-[#64748B]">
            Fama-French & Carhart Style Factors • Long/Short Quintile Performance
          </div>
        </div>

        {/* Factor Performance Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-xs">
          {FACTORS.map((f) => (
            <div key={f.code} className="bg-[#0B1222] border border-[#1E293B] rounded-sm p-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#00E5FF] text-xs">{f.code}</span>
                  <span className="text-[10px] text-[#64748B]">Sharpe: <b className="text-[#10B981]">{f.sharpe}</b></span>
                </div>
                <div className="text-[10px] text-white font-semibold my-1.5 truncate">{f.name}</div>
              </div>

              <div className="pt-2 border-t border-[#1E293B] text-[11px]">
                <div className="flex justify-between">
                  <span className="text-[#64748B] text-[10px]">1Y Premia:</span>
                  <span className="font-bold text-[#10B981]">+{f.return1Y}%</span>
                </div>
                <div className="flex justify-between text-[10px] mt-0.5">
                  <span className="text-[#64748B]">L/S Spread:</span>
                  <span className="text-[#CBD5E1]">+{f.spreadLongShort}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* PCA Decomposition Engine Section */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 space-y-3 font-mono text-xs">
        <div className="flex items-center justify-between pb-3 border-b border-[#1E293B]">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-[#F59E0B]" />
            <span className="font-bold text-white font-sans text-xs tracking-wide">PRINCIPAL COMPONENT ANALYSIS (PCA) COVARIANCE DECOMPOSITION</span>
          </div>
          <span className="text-[10px] text-[#00E5FF]">Top 3 Eigenvectors Explain &gt;76% of Cross-Sectional Return Variance</span>
        </div>

        <PCAFactorDecompositionChart stocks={stocks} onSelectStock={onSelectStock} />
      </div>

      {/* Cross-Sectional Factor Leaders Table */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-sm p-4 font-mono text-xs">
        <div className="font-bold text-white text-xs border-b border-[#1E293B] pb-3 mb-3 flex items-center justify-between font-sans">
          <span className="tracking-wide">CROSS-SECTIONAL FACTOR EXPOSURES (TOP 10 EQUITIES)</span>
          <span className="text-[10px] text-[#64748B]">Barra Standardized Z-Scores (Mean = 0.0σ, StDev = 1.0σ)</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-[#1E293B] text-[10px] text-[#64748B] uppercase tracking-widest font-bold">
                <th className="py-2 px-2">Ticker</th>
                <th className="py-2 px-2">Company</th>
                <th className="py-2 px-2">Sector</th>
                <th className="py-2 px-2 text-right">Value (Z)</th>
                <th className="py-2 px-2 text-right">Momentum (Z)</th>
                <th className="py-2 px-2 text-right">Quality (Z)</th>
                <th className="py-2 px-2 text-right">Growth (Z)</th>
                <th className="py-2 px-2 text-right">Low Vol (Z)</th>
                <th className="py-2 px-2 text-right">Rhino Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E293B]/60">
              {stocks.slice(0, 10).map((s) => (
                <tr
                  key={s.ticker}
                  onClick={() => onSelectStock(s.ticker)}
                  className="hover:bg-[#1E293B]/40 cursor-pointer transition-colors"
                >
                  <td className="py-2 px-2 font-bold text-[#00E5FF]">{s.ticker}</td>
                  <td className="py-2 px-2 text-white">{s.company}</td>
                  <td className="py-2 px-2 text-[#94A3B8]">{s.sector}</td>
                  <td className={`py-2 px-2 text-right font-semibold ${s.factors.value >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                    {s.factors.value >= 0 ? '+' : ''}{s.factors.value.toFixed(2)}
                  </td>
                  <td className={`py-2 px-2 text-right font-semibold ${s.factors.momentum >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                    {s.factors.momentum >= 0 ? '+' : ''}{s.factors.momentum.toFixed(2)}
                  </td>
                  <td className={`py-2 px-2 text-right font-semibold ${s.factors.quality >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                    {s.factors.quality >= 0 ? '+' : ''}{s.factors.quality.toFixed(2)}
                  </td>
                  <td className={`py-2 px-2 text-right font-semibold ${s.factors.growth >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                    {s.factors.growth >= 0 ? '+' : ''}{s.factors.growth.toFixed(2)}
                  </td>
                  <td className={`py-2 px-2 text-right font-semibold ${(s.factors.lowVolatility ?? 0) >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                    {(s.factors.lowVolatility ?? 0) >= 0 ? '+' : ''}{(s.factors.lowVolatility ?? 0).toFixed(2)}
                  </td>
                  <td className="py-2 px-2 text-right font-bold text-[#00E5FF]">
                    {s.equityScore.composite}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
