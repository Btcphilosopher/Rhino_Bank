# RhinoQuant Core

A headless, modular quantitative research, backtesting, simulation and
paper-trading **engine** — the computational heart underneath an existing
RhinoQuant frontend. This repository contains **no UI, no browser
dependency, no presentation logic**. It runs entirely from the command
line or as a library, and returns data/state/events/errors for a frontend
(or any other caller) to render however it likes.

```text
                     EXISTING RHINOQUANT FRONTEND
                               |
                        API / IPC / SDK
                               |
                               v
                     RHINOQUANT CORE ENGINE
                               |
         +---------------------+---------------------+
         |                     |                     |
         v                     v                     v
    MARKET DATA          QUANT ENGINE           OPERATIONS
         |                     |                     |
         v                     v                     v
    ORDER BOOK            ALPHA ENGINE          AUDIT LOG / METRICS
         |                     |
         +----------+----------+
                    v
             STRATEGY ENGINE -> RISK ENGINE -> OMS -> EXECUTION ENGINE
                                                            |
                                                    SimulatedExchange
```

## Quickstart

```bash
# from the repository root
pip install -e ".[dev]"          # numpy/scipy/polars/pandas/pyarrow/pydantic/pyyaml + pytest/hypothesis
python -m rhinoquant health
python -m rhinoquant validate
python -m rhinoquant simulate --events 50000
python -m rhinoquant benchmark
```

Optional extras:

```bash
pip install -e ".[ml]"        # scikit-learn, for rhinoquant.ml
pip install -e ".[duckdb]"    # duckdb, for the DuckDB storage backend
```

Optional Rust-accelerated order book:

```bash
pip install maturin
cd rust/rhinoquant-core
maturin develop --release      # builds + installs `rhinoquant_core` into the active venv
cd ../..
python -m rhinoquant benchmark  # now reports rust numbers alongside python
```

The engine is **fully functional without building the Rust extension** —
`rhinoquant.orderbook.get_order_book()` falls back to the pure-Python
reference implementation automatically when `rhinoquant_core` isn't
importable.

Python 3.11+ is required (3.12+ is recommended and is what `pyproject.toml`
targets going forward; this build was developed and tested against 3.11).

## CLI

```text
python -m rhinoquant simulate    run the full synthetic simulation workflow (section 52)
python -m rhinoquant backtest    event-driven backtest replay (same engine, same causal ordering)
python -m rhinoquant benchmark   order book throughput, Python vs Rust, measured on this host
python -m rhinoquant validate    self-checks: config, risk rejection, kill switch, determinism, API schemas
python -m rhinoquant health      health/readiness/liveness + system status
```

Every command accepts `--json` for machine-readable output and `--config
path/to/file.yaml` to load a specific `EngineConfig` (see `configs/`).

**All `simulate`/`backtest` output is generated from a synthetic, seeded
market — it is explicitly labelled `SYNTHETIC SIMULATION` and must never be
read as a claim about real-market performance, real exchange latency, or
future profitability.**

## Project layout

```text
rhinoquant-core/
├── python/rhinoquant/     the engine (see module docstrings for each subsystem)
│   ├── core/              events, event bus, lifecycle, errors, structured logging, ids
│   ├── schemas/            the frontend contract (section 6): pydantic, JSON-serialisable, versioned
│   ├── marketdata/         synthetic generator, normaliser, provider interface
│   ├── orderbook/          Python reference limit order book (+ optional Rust backend)
│   ├── features/           streaming microstructure/statistical/cross-asset feature engine
│   ├── alpha/               alpha model interface + research models + combiner
│   ├── strategies/         Strategy plugin base + market making / stat-arb / momentum
│   ├── execution_algos/    TWAP / VWAP / POV / Implementation Shortfall / Adaptive
│   ├── risk/               risk engine (reason-coded rejections) + independent kill switches
│   ├── oms/                order state machine + persistence
│   ├── execution/          ExecutionEngine interface, simulator/paper backends, live-adapter stub
│   ├── simulation/         SimulatedExchange (matching, queue position, latency, fees)
│   ├── backtest/           event-driven, causally-ordered backtest engine
│   ├── portfolio/          positions, exposures, cash
│   ├── analytics/          P&L accounting, performance metrics, latency engine, TCA
│   ├── optimisation/       grid/random/genetic/Bayesian search, Pareto fronts
│   ├── research/           train/val/test + walk-forward splits, bootstrap/Monte Carlo, regime analysis
│   ├── ml/                 optional scikit-learn-backed prediction interfaces (leakage-safe)
│   ├── storage/            Parquet/CSV/JSONL/DuckDB-backed domain stores
│   ├── monitoring/         metrics registry, health checks
│   ├── audit/              hash-chained append-only audit log
│   ├── api/                RhinoQuantAPI: the versioned engine <-> frontend contract
│   ├── config.py           typed YAML configuration + environment safeguards
│   ├── engine.py           RhinoQuantEngine orchestrator
│   └── cli.py / __main__.py
├── rust/rhinoquant-core/   PyO3 order book extension (optional; see its README)
├── cpp/execution-interface/  declaration-only future hot-path interface (not built/linked)
├── configs/                development/research/backtest/simulation/paper/production YAML
├── tests/                  pytest + hypothesis
├── benchmarks/             Python vs Rust throughput, measured on this host
├── examples/               programmatic usage (no CLI)
├── docs/                   architecture, language boundaries
└── pyproject.toml
```

## The frontend contract

`rhinoquant.api.RhinoQuantAPI` is a plain Python class — no HTTP framework
bundled — whose methods correspond 1:1 to the engine's endpoint list:
`/system/status`, `/system/health`, `/market[/{symbol}]`,
`/orderbook/{symbol}`, `/features/{symbol}`, `/strategies[/{id}]`,
`/signals`, `/orders[/{id}]`, `/fills`, `/positions`, `/portfolio`,
`/pnl`, `/risk`, `/backtests`, `/simulations`, `/analytics`, `/latency`,
`/metrics`. Every method returns a plain JSON-serialisable dict wrapping a
versioned schema (`{"api_version": "v1", "data": {...}}`) — see
`python/rhinoquant/api/service.py`'s module docstring for how a thin
HTTP/IPC layer would wrap each method as one endpoint.

## Configuration and environments

Six environments are supported (`development`, `research`, `backtest`,
`simulation`, `paper`, `production`), each with its own YAML in
`configs/`. Risk limits, execution mode, and latency parameters are never
hard-coded inside a strategy — they come from `EngineConfig`
(`python/rhinoquant/config.py`), and that type enforces production
safeguards structurally: `environment: production` requires
`execution.mode: live`, which itself requires an explicit
`execution.allow_live: true` — a research config can never accidentally
reach live execution, and `execution.mode: live` is *rejected* everywhere
except `environment: production`.

**No live exchange connectivity is implemented** — that was explicitly out
of scope for this release (spec section 20). `rhinoquant.execution.adapter.ExchangeAdapter`
exists as an interface stub whose every method raises `NotImplementedError`.

## Testing and verification

```bash
python -m pytest tests/ -v
python -m rhinoquant validate     # runtime self-check: config, risk, kill switch, determinism, API schemas
python benchmarks/bench_orderbook.py
```

See `docs/VERIFICATION.md` for the full pre-delivery verification log (what
was actually run, and its actual output).

## Honesty notes (spec section 53)

- Every simulate/backtest result is generated from synthetic, seeded data
  and is labelled as such (`is_synthetic_data: true` in
  `BacktestResult`); nothing here claims real-market or production
  performance.
- Latency figures are software/simulation timings measured on whatever
  host ran the engine — see `rhinoquant.schemas.latency.LatencyReport`'s
  `note` field, which is included verbatim in every latency report.
- Benchmark numbers are measured on the host that ran them, this run
  only, and never presented as a portable or hardware-independent claim.
- Optimisation search results (`rhinoquant.optimisation`) report the best
  point *found by that search*, never a guarantee about unseen data.
