"""Example: drive :class:`BacktestEngine` directly (bypassing
``RhinoQuantEngine``) for a two-symbol run with a pairs-trading strategy,
and read the frontend-facing schemas back out of it.

    python examples/run_backtest_example.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))

from rhinoquant.backtest.engine import BacktestEngine  # noqa: E402
from rhinoquant.config import EngineConfig, Environment  # noqa: E402
from rhinoquant.marketdata.synthetic import SyntheticMarketConfig, SyntheticMarketGenerator  # noqa: E402
from rhinoquant.strategies.stat_arb import PairsTradingConfig, PairsTradingStrategy  # noqa: E402


def main() -> None:
    config = EngineConfig.default(environment=Environment.BACKTEST)

    providers = {
        "RHINO_A": SyntheticMarketGenerator(SyntheticMarketConfig(symbol="RHINO_A", seed=1, n_events=5_000)),
        "RHINO_B": SyntheticMarketGenerator(SyntheticMarketConfig(symbol="RHINO_B", seed=2, n_events=5_000)),
    }
    strategy = PairsTradingStrategy("RHINO_A", "RHINO_B", config=PairsTradingConfig())

    bt = BacktestEngine(config=config, providers=providers, strategies=[strategy])
    result = bt.run()

    print(f"events processed: {bt.events_processed}")
    print(f"orders submitted: {result.orders_submitted}")
    print(f"portfolio state:  {bt.portfolio.state().to_json_dict()}")
    print(f"latency report stages: {[s.stage for s in bt.latency_engine.report(bt.run_id).stages]}")


if __name__ == "__main__":
    main()
