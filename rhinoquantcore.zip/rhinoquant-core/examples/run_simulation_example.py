"""Example: run the engine programmatically instead of via the CLI.

    python examples/run_simulation_example.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))

from rhinoquant.config import EngineConfig, Environment  # noqa: E402
from rhinoquant.engine import RhinoQuantEngine, SimulationOptions  # noqa: E402


def main() -> None:
    config = EngineConfig.default(environment=Environment.SIMULATION)
    engine = RhinoQuantEngine(config)

    bt, report = engine.run_simulation(SimulationOptions(symbol="RHINO", n_events=20_000))

    print("SYNTHETIC SIMULATION")
    print(f"events processed:  {bt.events_processed}")
    print(f"orders submitted:  {report.result.orders_submitted}")
    print(f"orders filled:     {report.result.orders_filled}")
    print(f"net P&L:           {report.result.net_pnl:.2f}")
    print(f"risk status:       {report.risk_state.status}")
    print(f"deterministic_hash:{report.result.deterministic_hash}")


if __name__ == "__main__":
    main()
