"""Example: write your own :class:`Strategy` plugin (section 13/49) and
run it through the standard engine — risk, OMS and execution are wired in
by the engine, never by the strategy itself.

    python examples/custom_strategy_example.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))

from rhinoquant.config import EngineConfig, Environment  # noqa: E402
from rhinoquant.engine import RhinoQuantEngine, SimulationOptions  # noqa: E402
from rhinoquant.features.engine import FeatureSnapshot  # noqa: E402
from rhinoquant.schemas.orders import Side  # noqa: E402
from rhinoquant.strategies.base import OrderIntent, Strategy  # noqa: E402


class SpreadCaptureStrategy(Strategy):
    """A minimal custom strategy: buy one clip whenever the spread widens
    past a threshold (liquidity looks cheap to provide), do nothing
    otherwise. Demonstrates the smallest possible Strategy subclass — one
    hook, one intent, no state machine of its own.
    """

    strategy_id = "spread_capture_example"
    portfolio_id = "example"

    def __init__(self, symbol: str, spread_ticks_threshold: float = 3.0, tick_size: float = 0.01) -> None:
        super().__init__()
        self.symbol = symbol
        self.spread_ticks_threshold = spread_ticks_threshold
        self.tick_size = tick_size

    def on_features(self, features: FeatureSnapshot) -> None:
        if features.spread_ticks is not None and features.spread_ticks >= self.spread_ticks_threshold:
            self._submit(
                OrderIntent(
                    strategy_id=self.strategy_id,
                    portfolio_id=self.portfolio_id,
                    symbol=self.symbol,
                    side=Side.BUY,
                    quantity=10.0,
                    price=features.best_bid,
                    tag="wide_spread_bid",
                )
            )


def main() -> None:
    config = EngineConfig.default(environment=Environment.SIMULATION)
    engine = RhinoQuantEngine(config)

    strategy = SpreadCaptureStrategy(symbol="RHINO", spread_ticks_threshold=2.0)
    bt, report = engine.run_simulation(SimulationOptions(symbol="RHINO", n_events=20_000, strategy=strategy))

    print(f"orders submitted: {report.result.orders_submitted}")
    print(f"orders filled:    {report.result.orders_filled}")
    print(f"risk status:      {report.risk_state.status}")


if __name__ == "__main__":
    main()
