# rhinoquant-core (Rust)

Latency-sensitive infrastructure for RhinoQuant Core (spec section 4): today,
an order book hot path exposed to Python via [PyO3](https://pyo3.rs) /
[maturin](https://www.maturin.rs). This is the natural home for a future
binary-protocol market-data parser, a concurrent event queue and a
persistence layer, without changing the Python-facing API.

## Why a separate `extension-module` feature

`pyo3`'s `extension-module` feature tells it *not* to link `libpython`
directly (the symbols are provided by the embedding Python process at
`dlopen` time). That's correct for the compiled wheel maturin produces, but
it breaks a plain `cargo test`/`cargo build` binary, which has no Python
process to supply those symbols. So `extension-module` is gated behind a
crate feature here, off by default:

- `cargo test` / `cargo build` — plain Rust unit tests, links normal `libpython`.
- `maturin build` / `maturin develop` — enables `extension-module` via this
  crate's `pyproject.toml` (`[tool.maturin] features = ["extension-module"]`).

## Build

```bash
# run the Rust unit tests (no Python needed)
cargo test --release

# build + install the extension into the active virtualenv
pip install maturin
maturin develop --release

# or build a wheel without installing it
maturin build --release
```

## Python usage

```python
from rhinoquant_core import OrderBook

book = OrderBook()
book.update_bid(price=100.25, quantity=500)
book.update_ask(price=100.27, quantity=400)

book.best_bid()      # 100.25
book.best_ask()      # 100.27
book.mid()           # 100.26
book.microprice()    # imbalance-weighted mid
book.imbalance(1)    # (bid_qty - ask_qty) / (bid_qty + ask_qty)
book.depth(5)        # (bids, asks) up to 5 levels each
```

`rhinoquant.orderbook.get_order_book()` (Python package) prefers this
backend automatically when it is importable, and falls back transparently
to the pure-Python reference implementation otherwise — the engine remains
fully functional if this extension is never built.

## Scope of this crate today

Implemented: best bid/ask, mid, spread, microprice, N-level depth,
N-level imbalance, crossed/locked-book detection and counters.

Not yet in Rust (present only in the Python reference book): sequence-gap
detection, duplicate-message detection, and own-order queue-position
tracking for the execution simulator. These operate at research/simulation
speed today and were kept in Python for now; porting them here is
straightforward future work and does not change any public API.

## Benchmarks

`benchmarks/bench_orderbook.py` at the repo root drives *this* compiled
extension side-by-side with the pure-Python reference book and prints
measured update throughput for both, on this host, so the comparison is a
real measurement rather than a claim (section 44: no cross-machine or
production HFT performance claims are made anywhere in this repo).
