//! Latency-sensitive limit order book core (section 4 / 10).
//!
//! This mirrors the public surface of the Python reference implementation
//! (`rhinoquant.orderbook.book.LimitOrderBook`) so the two backends are
//! interchangeable from Python's point of view. Price levels are kept in a
//! `BTreeMap` ordered by price, giving O(log n) inserts/removals and O(1)
//! best-of-book reads (front/back of the map) instead of the O(n) list
//! shifting a naive Python level store would require at large depth.
//!
//! Sequence-gap detection, crossed/locked-book detection and own-order
//! queue tracking (used by the execution simulator) remain in the Python
//! reference implementation for now; this crate focuses on the hot
//! best-of-book / feature-input path called on every market data update.

use std::cmp::Ordering;
use std::collections::BTreeMap;

use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;

/// Total-ordering wrapper around `f64` so prices can key a `BTreeMap`.
/// Prices are always validated to be finite and positive before use, so
/// `total_cmp` (which orders NaN consistently) is safe here.
#[derive(Debug, Clone, Copy, PartialEq)]
struct Price(f64);

impl Eq for Price {}

impl Ord for Price {
    fn cmp(&self, other: &Self) -> Ordering {
        self.0.total_cmp(&other.0)
    }
}

impl PartialOrd for Price {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[pyclass]
pub struct OrderBook {
    bids: BTreeMap<Price, f64>,
    asks: BTreeMap<Price, f64>,
    strict: bool,
    crossed_count: u64,
    locked_count: u64,
}

impl OrderBook {
    fn set_level(book: &mut BTreeMap<Price, f64>, price: f64, quantity: f64) {
        let key = Price(price);
        if quantity <= 0.0 {
            book.remove(&key);
        } else {
            book.insert(key, quantity);
        }
    }

    fn validate(price: f64, quantity: f64) -> PyResult<()> {
        if !price.is_finite() || price <= 0.0 {
            return Err(PyValueError::new_err(format!("invalid price: {price}")));
        }
        if !quantity.is_finite() || quantity < 0.0 {
            return Err(PyValueError::new_err(format!(
                "invalid negative quantity: {quantity}"
            )));
        }
        Ok(())
    }
}

#[pymethods]
impl OrderBook {
    #[new]
    #[pyo3(signature = (strict=true))]
    fn new(strict: bool) -> Self {
        OrderBook {
            bids: BTreeMap::new(),
            asks: BTreeMap::new(),
            strict,
            crossed_count: 0,
            locked_count: 0,
        }
    }

    /// Insert/replace/remove (quantity == 0) a bid price level.
    fn update_bid(&mut self, price: f64, quantity: f64) -> PyResult<()> {
        Self::validate(price, quantity)?;
        Self::set_level(&mut self.bids, price, quantity);
        self.check_integrity()
    }

    /// Insert/replace/remove (quantity == 0) an ask price level.
    fn update_ask(&mut self, price: f64, quantity: f64) -> PyResult<()> {
        Self::validate(price, quantity)?;
        Self::set_level(&mut self.asks, price, quantity);
        self.check_integrity()
    }

    fn best_bid(&self) -> Option<f64> {
        self.bids.keys().next_back().map(|p| p.0)
    }

    fn best_ask(&self) -> Option<f64> {
        self.asks.keys().next().map(|p| p.0)
    }

    fn best_bid_quantity(&self) -> Option<f64> {
        self.bids.iter().next_back().map(|(_, q)| *q)
    }

    fn best_ask_quantity(&self) -> Option<f64> {
        self.asks.iter().next().map(|(_, q)| *q)
    }

    fn mid(&self) -> Option<f64> {
        match (self.best_bid(), self.best_ask()) {
            (Some(b), Some(a)) => Some((b + a) / 2.0),
            _ => None,
        }
    }

    fn spread(&self) -> Option<f64> {
        match (self.best_bid(), self.best_ask()) {
            (Some(b), Some(a)) => Some(a - b),
            _ => None,
        }
    }

    fn microprice(&self) -> Option<f64> {
        let (bb, ba) = (self.best_bid()?, self.best_ask()?);
        let bq = self.best_bid_quantity().unwrap_or(0.0);
        let aq = self.best_ask_quantity().unwrap_or(0.0);
        let total = bq + aq;
        if total <= 0.0 {
            return self.mid();
        }
        Some((bb * aq + ba * bq) / total)
    }

    #[pyo3(signature = (levels=1))]
    fn imbalance(&self, levels: usize) -> Option<f64> {
        let levels = levels.max(1);
        let bid_qty: f64 = self.bids.iter().rev().take(levels).map(|(_, q)| *q).sum();
        let ask_qty: f64 = self.asks.iter().take(levels).map(|(_, q)| *q).sum();
        let total = bid_qty + ask_qty;
        if total <= 0.0 {
            return None;
        }
        Some((bid_qty - ask_qty) / total)
    }

    #[pyo3(signature = (levels=5))]
    fn depth(&self, levels: usize) -> (Vec<(f64, f64)>, Vec<(f64, f64)>) {
        let bids: Vec<(f64, f64)> = self
            .bids
            .iter()
            .rev()
            .take(levels)
            .map(|(p, q)| (p.0, *q))
            .collect();
        let asks: Vec<(f64, f64)> = self
            .asks
            .iter()
            .take(levels)
            .map(|(p, q)| (p.0, *q))
            .collect();
        (bids, asks)
    }

    fn is_crossed(&self) -> bool {
        matches!((self.best_bid(), self.best_ask()), (Some(b), Some(a)) if b > a)
    }

    fn is_locked(&self) -> bool {
        matches!((self.best_bid(), self.best_ask()), (Some(b), Some(a)) if b == a)
    }

    #[getter]
    fn crossed_count(&self) -> u64 {
        self.crossed_count
    }

    #[getter]
    fn locked_count(&self) -> u64 {
        self.locked_count
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn best_bid_ask_mid_spread() {
        let mut book = OrderBook::new(true);
        book.update_bid(100.25, 500.0).unwrap();
        book.update_ask(100.27, 400.0).unwrap();
        assert_eq!(book.best_bid(), Some(100.25));
        assert_eq!(book.best_ask(), Some(100.27));
        assert!((book.mid().unwrap() - 100.26).abs() < 1e-9);
        assert!((book.spread().unwrap() - 0.02).abs() < 1e-9);
    }

    #[test]
    fn microprice_weights_toward_thin_side() {
        let mut book = OrderBook::new(true);
        book.update_bid(100.00, 100.0).unwrap();
        book.update_ask(100.10, 900.0).unwrap();
        // heavier ask liquidity => microprice should sit closer to the bid
        let mp = book.microprice().unwrap();
        assert!(mp < book.mid().unwrap());
    }

    #[test]
    fn zero_quantity_removes_level() {
        let mut book = OrderBook::new(true);
        book.update_bid(100.0, 10.0).unwrap();
        assert_eq!(book.best_bid(), Some(100.0));
        book.update_bid(100.0, 0.0).unwrap();
        assert_eq!(book.best_bid(), None);
    }

    #[test]
    fn crossed_book_rejected_in_strict_mode() {
        let mut book = OrderBook::new(true);
        book.update_bid(100.0, 10.0).unwrap();
        book.update_ask(100.05, 10.0).unwrap();
        let err = book.update_bid(100.10, 10.0);
        assert!(err.is_err());
    }

    #[test]
    fn crossed_book_counted_not_rejected_when_not_strict() {
        let mut book = OrderBook::new(false);
        book.update_bid(100.0, 10.0).unwrap();
        book.update_ask(100.05, 10.0).unwrap();
        book.update_bid(100.10, 10.0).unwrap();
        assert!(book.is_crossed());
        assert_eq!(book.crossed_count(), 1);
    }

    #[test]
    fn negative_quantity_rejected() {
        let mut book = OrderBook::new(true);
        assert!(book.update_bid(100.0, -5.0).is_err());
    }

    #[test]
    fn imbalance_and_depth_multi_level() {
        let mut book = OrderBook::new(true);
        book.update_bid(100.00, 100.0).unwrap();
        book.update_bid(99.99, 200.0).unwrap();
        book.update_ask(100.01, 50.0).unwrap();
        book.update_ask(100.02, 50.0).unwrap();
        let (bids, asks) = book.depth(2);
        assert_eq!(bids, vec![(100.00, 100.0), (99.99, 200.0)]);
        assert_eq!(asks, vec![(100.01, 50.0), (100.02, 50.0)]);
        let imb = book.imbalance(2).unwrap();
        assert!(imb > 0.0); // more bid depth than ask depth
    }
}

impl OrderBook {
    fn check_integrity(&mut self) -> PyResult<()> {
        if let (Some(b), Some(a)) = (self.best_bid(), self.best_ask()) {
            if b > a {
                self.crossed_count += 1;
                if self.strict {
                    return Err(PyValueError::new_err(format!(
                        "crossed book: best_bid={b} > best_ask={a}"
                    )));
                }
            } else if b == a {
                self.locked_count += 1;
                if self.strict {
                    return Err(PyValueError::new_err(format!(
                        "locked book: best_bid == best_ask == {b}"
                    )));
                }
            }
        }
        Ok(())
    }
}
