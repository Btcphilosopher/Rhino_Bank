//! RhinoQuant Core - Rust latency-sensitive infrastructure.
//!
//! Exposes a Python extension module (`rhinoquant_core`) built with PyO3 /
//! maturin. Today this covers the order book hot path (section 4/10); the
//! same crate is the natural home for a future binary-protocol parser,
//! concurrent event queue and persistence layer (section 4), without
//! changing the Python-facing API.

use pyo3::prelude::*;

mod orderbook;

pub use orderbook::OrderBook;

/// Rust crate / extension module version, exposed to Python so the engine
/// can report which backend (Python fallback vs. compiled Rust) is active.
#[pyfunction]
fn version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}

#[pymodule]
fn rhinoquant_core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<OrderBook>()?;
    m.add_function(wrap_pyfunction!(version, m)?)?;
    Ok(())
}
