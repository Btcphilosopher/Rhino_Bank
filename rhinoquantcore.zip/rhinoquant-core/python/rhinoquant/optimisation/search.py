"""Optimisation engine (section 29).

Every search method takes an ``objective_fn: dict -> float`` the caller
builds from whatever a run actually measured (a
:class:`~rhinoquant.analytics.performance.PerformanceReport`, a
:class:`~rhinoquant.schemas.backtest.BacktestResult`, a latency report,
...). Nothing here scores a parameter set against a value it did not
itself compute, and no result is labelled as more than what it is: the
best point *found by this search*, not a guaranteed optimum, and never a
promise about unseen future data (section 29: "Do not allow optimisation
results to be represented as guaranteed future performance.").
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass
from itertools import product
from typing import Callable, Optional

ParamGrid = dict[str, list]
ParamSpace = dict[str, tuple[float, float]]
Objective = Callable[[dict], float]


@dataclass
class SearchResult:
    params: dict
    score: float


@dataclass
class SearchReport:
    results: list[SearchResult]
    best: Optional[SearchResult]
    method: str
    maximize: bool


def _sort(results: list[SearchResult], maximize: bool) -> list[SearchResult]:
    return sorted(results, key=lambda r: r.score, reverse=maximize)


def grid_search(param_grid: ParamGrid, objective_fn: Objective, maximize: bool = True) -> SearchReport:
    keys = list(param_grid.keys())
    results = []
    for combo in product(*(param_grid[k] for k in keys)):
        params = dict(zip(keys, combo))
        results.append(SearchResult(params=params, score=objective_fn(params)))
    results = _sort(results, maximize)
    return SearchReport(results=results, best=results[0] if results else None, method="grid_search", maximize=maximize)


def random_search(
    param_space: ParamSpace,
    objective_fn: Objective,
    n_iter: int = 50,
    seed: int = 42,
    maximize: bool = True,
) -> SearchReport:
    rng = random.Random(seed)
    results = []
    for _ in range(n_iter):
        params = {k: rng.uniform(lo, hi) for k, (lo, hi) in param_space.items()}
        results.append(SearchResult(params=params, score=objective_fn(params)))
    results = _sort(results, maximize)
    return SearchReport(results=results, best=results[0] if results else None, method="random_search", maximize=maximize)


def genetic_search(
    param_space: ParamSpace,
    objective_fn: Objective,
    population_size: int = 20,
    generations: int = 15,
    mutation_rate: float = 0.2,
    mutation_scale: float = 0.1,
    seed: int = 42,
    maximize: bool = True,
) -> SearchReport:
    """A minimal real-valued genetic algorithm: tournament selection,
    blend crossover, Gaussian mutation clipped back into bounds."""
    rng = random.Random(seed)
    keys = list(param_space.keys())

    def random_individual() -> dict:
        return {k: rng.uniform(lo, hi) for k, (lo, hi) in param_space.items()}

    def mutate(ind: dict) -> dict:
        out = dict(ind)
        for k, (lo, hi) in param_space.items():
            if rng.random() < mutation_rate:
                span = hi - lo
                out[k] = min(hi, max(lo, out[k] + rng.gauss(0, mutation_scale * span)))
        return out

    def crossover(a: dict, b: dict) -> dict:
        t = rng.random()
        return {k: a[k] * t + b[k] * (1 - t) for k in keys}

    def tournament(scored: list[SearchResult]) -> dict:
        a, b = rng.sample(scored, 2)
        better = a if (a.score > b.score) == maximize else b
        return better.params

    population = [random_individual() for _ in range(population_size)]
    all_results: list[SearchResult] = []

    for _ in range(generations):
        scored = [SearchResult(params=ind, score=objective_fn(ind)) for ind in population]
        all_results.extend(scored)
        next_population = [_sort(scored, maximize)[0].params]  # elitism: keep the best
        while len(next_population) < population_size:
            child = mutate(crossover(tournament(scored), tournament(scored)))
            next_population.append(child)
        population = next_population

    all_results = _sort(all_results, maximize)
    return SearchReport(
        results=all_results, best=all_results[0] if all_results else None, method="genetic_search", maximize=maximize
    )


def bayesian_search(
    param_space: ParamSpace,
    objective_fn: Objective,
    n_init: int = 5,
    n_iter: int = 20,
    seed: int = 42,
    maximize: bool = True,
    length_scale: Optional[float] = None,
    noise: float = 1e-6,
) -> SearchReport:
    """A compact, dependency-light Bayesian optimiser: a Gaussian-process
    surrogate (RBF kernel, exact GP posterior via Cholesky) with expected-
    improvement acquisition, maximised by evaluating EI over random
    candidate points rather than gradient ascent. Intended for a handful
    of continuous hyperparameters over tens of iterations — a research
    tool, not a production-grade optimiser for high-dimensional spaces.
    """
    import numpy as np

    rng = np.random.default_rng(seed)
    keys = list(param_space.keys())
    bounds = np.array([param_space[k] for k in keys])
    dim = len(keys)
    ls = length_scale or math.sqrt(dim)

    def to_vec(params: dict) -> "np.ndarray":
        return np.array([params[k] for k in keys], dtype=float)

    def to_params(vec) -> dict:
        return {k: float(v) for k, v in zip(keys, vec)}

    def sample_uniform(n: int):
        return rng.uniform(bounds[:, 0], bounds[:, 1], size=(n, dim))

    def rbf_kernel(a, b):
        sq = ((a[:, None, :] - b[None, :, :]) ** 2).sum(-1)
        return np.exp(-sq / (2 * ls**2))

    X = sample_uniform(n_init)
    y = np.array([objective_fn(to_params(x)) for x in X])
    sign = 1.0 if maximize else -1.0

    for _ in range(n_iter):
        K = rbf_kernel(X, X) + noise * np.eye(len(X))
        L = np.linalg.cholesky(K)
        alpha = np.linalg.solve(L.T, np.linalg.solve(L, sign * y))

        candidates = sample_uniform(max(200, 20 * dim))
        K_s = rbf_kernel(candidates, X)
        mu = K_s @ alpha
        v = np.linalg.solve(L, K_s.T)
        var = 1.0 - np.sum(v**2, axis=0)
        var = np.clip(var, 1e-12, None)
        std = np.sqrt(var)

        best_so_far = (sign * y).max()
        improvement = mu - best_so_far
        z = improvement / std
        from scipy.stats import norm

        ei = improvement * norm.cdf(z) + std * norm.pdf(z)
        ei = np.where(std > 1e-9, ei, 0.0)

        next_x = candidates[int(np.argmax(ei))]
        next_y = objective_fn(to_params(next_x))
        X = np.vstack([X, next_x])
        y = np.append(y, next_y)

    results = [SearchResult(params=to_params(x), score=float(v)) for x, v in zip(X, y)]
    results = _sort(results, maximize)
    return SearchReport(results=results, best=results[0] if results else None, method="bayesian_search", maximize=maximize)


def pareto_front(candidates: list[tuple[dict, dict[str, float]]], directions: dict[str, str]) -> list[dict]:
    """Multi-objective optimisation (section 29): extracts the
    non-dominated (Pareto-optimal) subset of ``candidates``, each a
    ``(params, objectives)`` pair. ``directions`` maps each objective name
    to ``"max"`` or ``"min"``. A candidate is dominated if another
    candidate is at least as good on every objective and strictly better
    on at least one.
    """

    def dominates(a: dict[str, float], b: dict[str, float]) -> bool:
        at_least_as_good = True
        strictly_better = False
        for key, direction in directions.items():
            av, bv = a[key], b[key]
            if direction == "min":
                av, bv = -av, -bv
            if av < bv:
                at_least_as_good = False
            if av > bv:
                strictly_better = True
        return at_least_as_good and strictly_better

    front = []
    for i, (params_i, obj_i) in enumerate(candidates):
        dominated = any(dominates(obj_j, obj_i) for j, (_, obj_j) in enumerate(candidates) if j != i)
        if not dominated:
            front.append({"params": params_i, "objectives": obj_i})
    return front
