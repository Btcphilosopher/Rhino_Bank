"""``RhinoQuantAPI`` (section 7): the engine's service boundary.

The frontend is already built (per the task brief) and only needs a
stable contract to call, not a Python import of this repo's internals —
so every method here takes plain arguments and returns plain,
JSON-serialisable ``dict``/``list[dict]`` (schemas serialised via
``.to_json_dict()``), never a live engine object. A thin HTTP/IPC layer
(FastAPI, gRPC, a Unix socket protocol — whatever the existing frontend
already speaks) can wrap each method as one endpoint from section 7's list
with no further translation. No HTTP framework is bundled here: adding
one is exactly the kind of "controlled dependency" decision section 3
asks to defer to when it's actually needed, not before.

Endpoints implemented (section 7): ``/system/status``, ``/system/health``,
``/market``, ``/market/{symbol}``, ``/orderbook/{symbol}``,
``/features/{symbol}``, ``/strategies``, ``/strategies/{id}``,
``/signals``, ``/orders``, ``/orders/{id}``, ``/fills``, ``/positions``,
``/portfolio``, ``/pnl``, ``/risk``, ``/backtests``, ``/simulations``,
``/analytics``, ``/latency``, ``/metrics``.
"""
from __future__ import annotations

import dataclasses
from typing import Any, Optional

from rhinoquant.analytics.performance import compute_performance
from rhinoquant.api.versioning import API_VERSION
from rhinoquant.backtest.engine import BacktestEngine
from rhinoquant.core.errors import ValidationError
from rhinoquant.engine import RhinoQuantEngine
from rhinoquant.risk.engine import RiskContext
from rhinoquant.schemas.market import MarketSnapshot
from rhinoquant.schemas.orderbook import OrderBookSnapshot, PriceLevel


def _envelope(data: Any) -> dict[str, Any]:
    return {"api_version": API_VERSION, "data": data}


class RhinoQuantAPI:
    """Reads state off the engine's most recently completed run
    (``engine.last_backtest_engine``) unless a specific
    :class:`~rhinoquant.backtest.engine.BacktestEngine` is passed in —
    the API never mutates that run, it only reports on it.
    """

    def __init__(self, engine: RhinoQuantEngine, run: Optional[BacktestEngine] = None) -> None:
        self.engine = engine
        self._run = run

    def bind_run(self, run: BacktestEngine) -> None:
        self._run = run

    def _require_run(self) -> BacktestEngine:
        run = self._run or self.engine.last_backtest_engine
        if run is None:
            raise ValidationError("no simulation/backtest has been run yet in this engine instance")
        return run

    def _require_symbol(self, run: BacktestEngine, symbol: str) -> None:
        if symbol not in run.books:
            raise ValidationError(f"unknown symbol {symbol!r}", details={"known_symbols": sorted(run.books)})

    # -- /system -------------------------------------------------------- #
    def system_status(self) -> dict:
        return _envelope(self.engine.system_status().to_json_dict())

    def system_health(self) -> dict:
        return _envelope(self.engine.health.run().to_json_dict())

    # -- /market ---------------------------------------------------------#
    def market(self, symbol: Optional[str] = None) -> dict:
        run = self._require_run()
        symbols = [symbol] if symbol else sorted(run.books)
        snapshots = []
        for sym in symbols:
            self._require_symbol(run, sym)
            book = run.books[sym]
            snapshots.append(
                MarketSnapshot(
                    symbol=sym,
                    timestamp_ns=run.last_timestamp_ns or 0,
                    best_bid=book.best_bid(),
                    best_ask=book.best_ask(),
                    best_bid_quantity=book.best_bid_quantity(),
                    best_ask_quantity=book.best_ask_quantity(),
                ).to_json_dict()
            )
        return _envelope(snapshots if symbol is None else snapshots[0])

    # -- /orderbook/{symbol} --------------------------------------------#
    def orderbook(self, symbol: str, levels: int = 10) -> dict:
        run = self._require_run()
        self._require_symbol(run, symbol)
        book = run.books[symbol]
        depth = book.depth(levels)
        snap = OrderBookSnapshot(
            symbol=symbol,
            timestamp_ns=run.last_timestamp_ns or 0,
            sequence_number=run.events_processed,
            bids=[PriceLevel(price=p, quantity=q) for p, q in depth["bids"]],
            asks=[PriceLevel(price=p, quantity=q) for p, q in depth["asks"]],
            best_bid=book.best_bid(),
            best_ask=book.best_ask(),
            mid=book.mid(),
            microprice=book.microprice(),
            spread=book.spread(),
            imbalance=book.imbalance(1),
        )
        return _envelope(snap.to_json_dict())

    # -- /features/{symbol} ---------------------------------------------#
    def features(self, symbol: str) -> dict:
        run = self._require_run()
        self._require_symbol(run, symbol)
        snap = run.feature_engines[symbol].snapshot()
        return _envelope(dataclasses.asdict(snap) if snap else None)

    # -- /strategies -------------------------------------------------------#
    def strategies(self, strategy_id: Optional[str] = None) -> dict:
        run = self._require_run()
        rows = [{"strategy_id": s.strategy_id, "portfolio_id": s.portfolio_id, "type": type(s).__name__} for s in run.strategies]
        if strategy_id is None:
            return _envelope(rows)
        matches = [r for r in rows if r["strategy_id"] == strategy_id]
        if not matches:
            raise ValidationError(f"unknown strategy_id {strategy_id!r}")
        return _envelope(matches[0])

    # -- /signals ---------------------------------------------------------#
    def signals(self) -> dict:
        """Rule-based reference strategies (market making, momentum,
        pairs trading) act directly on features rather than emitting
        :class:`~rhinoquant.schemas.signals.Signal` objects, so there is
        nothing to report here for those; a strategy built on the alpha
        engine (:mod:`rhinoquant.alpha`) that records its combined signals
        onto a ``signals_log`` attribute will have that history surfaced
        automatically.
        """
        run = self._require_run()
        out = []
        for strat in run.strategies:
            log = getattr(strat, "signals_log", None)
            if log:
                out.extend(s.to_json_dict() for s in log)
        return _envelope(out)

    # -- /orders -----------------------------------------------------------#
    def orders(self, client_order_id: Optional[str] = None) -> dict:
        run = self._require_run()
        if client_order_id is None:
            return _envelope([o.to_json_dict() for o in run.oms.all_orders()])
        order = run.oms.get(client_order_id)
        if order is None:
            raise ValidationError(f"unknown client_order_id {client_order_id!r}")
        return _envelope(order.to_json_dict())

    # -- /fills -------------------------------------------------------------#
    def fills(self) -> dict:
        run = self._require_run()
        return _envelope([f.to_json_dict() for f in run.fills])

    # -- /positions ----------------------------------------------------------#
    def positions(self) -> dict:
        run = self._require_run()
        return _envelope([p.to_json_dict() for p in run.portfolio.state().positions])

    # -- /portfolio ----------------------------------------------------------#
    def portfolio(self) -> dict:
        run = self._require_run()
        return _envelope(run.portfolio.state().to_json_dict())

    # -- /pnl ------------------------------------------------------------------#
    def pnl(self) -> dict:
        run = self._require_run()
        return _envelope(run.portfolio.pnl_snapshot().to_json_dict())

    # -- /risk -----------------------------------------------------------------#
    def risk(self) -> dict:
        run = self._require_run()
        context = RiskContext(
            portfolio_state=run.portfolio.state(),
            strategy_realised_pnl=run.portfolio.strategy_realised_pnl(),
            daily_pnl=run.portfolio.realised_pnl() + run.portfolio.unrealised_pnl(),
        )
        return _envelope(run.risk_engine.risk_state(context).to_json_dict())

    # -- /backtests, /simulations ------------------------------------------------#
    def backtests(self) -> dict:
        run = self._require_run()
        return _envelope(run.build_result().to_json_dict())

    def simulations(self) -> dict:
        """Identical underlying mechanism to ``/backtests`` in this engine
        — both replay a synthetic (or, in the future, historical) event
        stream through the same causal pipeline; the distinction the
        frontend contract draws is about *intent* (a labelled research
        backtest vs. an ad-hoc simulation run), not a different engine.
        """
        return self.backtests()

    # -- /analytics --------------------------------------------------------------#
    def analytics(self) -> dict:
        run = self._require_run()
        realisations = [r for a in run.portfolio.all_accounts() for r in a.realisations]
        duration_s = ((run.finished_ns or 0) - (run.started_ns or 0)) / 1e9
        perf = compute_performance(
            equity_curve=run.equity_curve or [run.options.starting_cash],
            realisations=realisations,
            gross_pnl=run.portfolio.realised_pnl() + run.portfolio.unrealised_pnl(),
            net_pnl=run.portfolio.realised_pnl()
            + run.portfolio.unrealised_pnl()
            - run.portfolio.total_fees()
            + run.portfolio.total_rebates(),
            starting_equity=run.options.starting_cash,
            total_traded_notional=run.total_traded_notional,
            order_counters=run.order_counters,
            duration_seconds=duration_s,
        )
        return _envelope(dataclasses.asdict(perf))

    # -- /latency ------------------------------------------------------------------#
    def latency(self) -> dict:
        run = self._require_run()
        return _envelope(run.latency_engine.report(run.run_id).to_json_dict())

    # -- /metrics ------------------------------------------------------------------#
    def metrics(self) -> dict:
        return _envelope(self.engine.metrics.export())
