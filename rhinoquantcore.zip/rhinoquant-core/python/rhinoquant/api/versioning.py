"""API versioning (section 46).

``API_VERSION`` is the version stamped on every :class:`RhinoQuantAPI`
response envelope and echoed by ``/system/status``. Internal refactoring
inside the engine must never change what a given ``API_VERSION`` means to
callers — a breaking change bumps this constant (and, going forward,
keeps the previous version's behaviour reachable) rather than mutating the
contract a shipped frontend already depends on.
"""
from __future__ import annotations

API_VERSION = "v1"
