"""Structured error contract (section 40).

Every error that can cross the engine API boundary derives from
``RhinoQuantError`` and carries a stable ``error_code``, a human message,
the originating ``component``, a timestamp, and (when available) a
correlation ID so the frontend / caller can trace the failure back through
the engine logs (section 41).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from rhinoquant.core.ids import now_ns


@dataclass
class ErrorEnvelope:
    error_code: str
    message: str
    component: str
    timestamp_ns: int = field(default_factory=now_ns)
    correlation_id: Optional[str] = None
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "error_code": self.error_code,
            "message": self.message,
            "component": self.component,
            "timestamp_ns": self.timestamp_ns,
            "correlation_id": self.correlation_id,
            "details": self.details,
        }


class RhinoQuantError(Exception):
    """Base class for every structured engine error."""

    error_code: str = "ENGINE_ERROR"
    component: str = "engine"

    def __init__(
        self,
        message: str,
        *,
        correlation_id: Optional[str] = None,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.envelope = ErrorEnvelope(
            error_code=self.error_code,
            message=message,
            component=self.component,
            correlation_id=correlation_id,
            details=details or {},
        )

    def to_dict(self) -> dict[str, Any]:
        return self.envelope.to_dict()


class RiskViolation(RhinoQuantError):
    error_code = "RISK_VIOLATION"
    component = "risk_engine"


class MarketDataError(RhinoQuantError):
    error_code = "MARKET_DATA_ERROR"
    component = "marketdata"


class SequenceGapError(MarketDataError):
    error_code = "SEQUENCE_GAP"
    component = "orderbook"


class OrderStateError(RhinoQuantError):
    error_code = "ORDER_STATE_ERROR"
    component = "oms"


class ExecutionError(RhinoQuantError):
    error_code = "EXECUTION_ERROR"
    component = "execution"


class ConfigurationError(RhinoQuantError):
    error_code = "CONFIGURATION_ERROR"
    component = "config"


class SimulationError(RhinoQuantError):
    error_code = "SIMULATION_ERROR"
    component = "simulation"


class ValidationError(RhinoQuantError):
    error_code = "VALIDATION_ERROR"
    component = "schemas"
