"""Small shared helpers.

:func:`enum_value` exists because of one pydantic v2 subtlety used
throughout the schema layer: :class:`~rhinoquant.schemas.base.RhinoQuantSchema`
sets ``use_enum_values=True`` so JSON-serialised schemas carry plain string
enum values rather than ``Enum`` members (frontend-friendly JSON without a
custom encoder). That means an enum-typed field read back off a
*pydantic* model instance is already a plain ``str`` — but the same field
on a plain ``dataclass`` (e.g. :class:`~rhinoquant.strategies.base.OrderIntent`)
is still a real ``Enum`` member, since dataclasses do no such coercion.
``enum_value`` normalises either case to its plain string value so
comparisons and dict keys stay correct regardless of which kind of object
handed it to you.
"""
from __future__ import annotations

from enum import Enum
from typing import Union


def enum_value(x: Union[Enum, str, None]) -> str | None:
    if x is None:
        return None
    return x.value if isinstance(x, Enum) else x
