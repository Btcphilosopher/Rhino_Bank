"""ID generation utilities: monotonically-increasing sequence numbers,
correlation IDs, and event/order/client IDs.

Correlation IDs (section 41) let an externally-initiated operation be traced
through Strategy -> Risk -> OMS -> Execution -> Fill across engine logs.
"""
from __future__ import annotations

import itertools
import os
import threading
import time
import uuid

_seq_lock = threading.Lock()
_seq_counter = itertools.count(1)


def next_sequence_number() -> int:
    """Process-wide monotonically increasing sequence number."""
    with _seq_lock:
        return next(_seq_counter)


def new_event_id() -> str:
    return f"evt_{uuid.uuid4().hex}"


def new_correlation_id() -> str:
    return f"cor_{uuid.uuid4().hex}"


def new_order_id() -> str:
    return f"ord_{uuid.uuid4().hex[:16]}"


def new_client_order_id() -> str:
    return f"cli_{uuid.uuid4().hex[:16]}"


def new_run_id() -> str:
    return f"run_{uuid.uuid4().hex[:12]}"


def now_ns() -> int:
    """Wall-clock nanosecond timestamp (receive-side timestamping).

    This is a *software* clock reading (``time.time_ns``), not a hardware
    PTP/NIC timestamp. It is suitable for research, simulation and paper
    trading. It must never be presented as exchange-grade timestamping.
    """
    return time.time_ns()


PID = os.getpid()
