"""Structured, machine-readable logging (section 33).

Every log record is emitted as a single-line JSON object so it can be
parsed by log aggregation tooling without regexing free-text messages.
"""
from __future__ import annotations

import json
import logging
import sys
from typing import Any

from rhinoquant.core.ids import now_ns


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp_ns": now_ns(),
            "level": record.levelname,
            "component": getattr(record, "component", record.name),
            "message": record.getMessage(),
        }
        extra = getattr(record, "extra_fields", None)
        if extra:
            payload.update(extra)
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def get_logger(component: str) -> logging.LoggerAdapter:
    logger = logging.getLogger(f"rhinoquant.{component}")
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(JsonFormatter())
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        logger.propagate = False
    return logging.LoggerAdapter(logger, {"component": component})


def log_event(logger: logging.LoggerAdapter, event_type: str, severity: str = "INFO", **fields: Any) -> None:
    level = getattr(logging, severity.upper(), logging.INFO)
    logger.log(level, event_type, extra={"extra_fields": {"event_type": event_type, "severity": severity, **fields}})
