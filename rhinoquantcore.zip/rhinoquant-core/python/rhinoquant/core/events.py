"""Canonical event model (section 8) and internal event bus (section 26).

Every event carries: event_id, timestamp_ns (engine receive time),
exchange_timestamp_ns (source timestamp, when known), receive_timestamp_ns,
sequence_number, symbol, venue, event_type and a payload.

The bus supports a deterministic synchronous mode (used by the backtester
and simulator, guaranteeing causal, look-ahead-free ordering) and can later
back a concurrent production dispatcher without changing subscriber code.
"""
from __future__ import annotations

import heapq
import itertools
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional

from rhinoquant.core.ids import new_event_id, next_sequence_number, now_ns


class EventType(str, Enum):
    MARKET = "MARKET"
    TRADE = "TRADE"
    QUOTE = "QUOTE"
    BOOK_UPDATE = "BOOK_UPDATE"
    BOOK_SNAPSHOT = "BOOK_SNAPSHOT"
    AUCTION = "AUCTION"
    INSTRUMENT = "INSTRUMENT"
    SIGNAL = "SIGNAL"
    ORDER = "ORDER"
    RISK = "RISK"
    FILL = "FILL"
    POSITION = "POSITION"
    PNL = "PNL"
    SYSTEM = "SYSTEM"
    TIMER = "TIMER"


@dataclass
class Event:
    """Base canonical event envelope. Concrete events set ``event_type`` and
    place their specific fields in ``payload``.
    """

    event_type: EventType
    symbol: Optional[str] = None
    venue: Optional[str] = None
    payload: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=new_event_id)
    sequence_number: int = field(default_factory=next_sequence_number)
    timestamp_ns: int = field(default_factory=now_ns)
    exchange_timestamp_ns: Optional[int] = None
    receive_timestamp_ns: int = field(default_factory=now_ns)
    correlation_id: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_id": self.event_id,
            "event_type": self.event_type.value,
            "symbol": self.symbol,
            "venue": self.venue,
            "sequence_number": self.sequence_number,
            "timestamp_ns": self.timestamp_ns,
            "exchange_timestamp_ns": self.exchange_timestamp_ns,
            "receive_timestamp_ns": self.receive_timestamp_ns,
            "correlation_id": self.correlation_id,
            "payload": self.payload,
        }


def make_event(event_type: EventType, **kwargs: Any) -> Event:
    return Event(event_type=event_type, **kwargs)


Handler = Callable[[Event], None]


class EventBus:
    """Synchronous, deterministic-by-default event bus.

    In ``deterministic`` mode (the default, and the only mode used by the
    backtester/simulator) events dispatched at the same simulated timestamp
    are ordered by their insertion sequence number, guaranteeing
    reproducible, causal delivery: subscribers for event N always finish
    before event N+1 is dispatched. This is what section 42 (deterministic
    simulation) and section 22 (no look-ahead bias) depend on.
    """

    def __init__(self, deterministic: bool = True) -> None:
        self.deterministic = deterministic
        self._subscribers: dict[EventType, list[Handler]] = {}
        self._global_subscribers: list[Handler] = []
        self._queue: list[tuple[int, int, Event]] = []
        self._tie_breaker = itertools.count()
        self._dispatched_count = 0

    def subscribe(self, event_type: EventType, handler: Handler) -> None:
        self._subscribers.setdefault(event_type, []).append(handler)

    def subscribe_all(self, handler: Handler) -> None:
        self._global_subscribers.append(handler)

    def publish(self, event: Event) -> None:
        """Enqueue an event. Call :meth:`drain` (or :meth:`publish_now`) to
        dispatch. Ordering key is (timestamp_ns, tie_breaker) so that
        same-timestamp events preserve publish order deterministically.
        """
        heapq.heappush(self._queue, (event.timestamp_ns, next(self._tie_breaker), event))

    def publish_now(self, event: Event) -> None:
        """Publish and immediately dispatch a single event, bypassing the
        ordering queue. Used for synchronous request/response style calls
        (e.g. an API-triggered SystemEvent) where strict time-ordering
        against the replay stream does not apply.
        """
        self._dispatch(event)

    def drain(self) -> int:
        """Dispatch every currently queued event in timestamp order.
        Returns the number of events dispatched.
        """
        dispatched = 0
        while self._queue:
            _, _, event = heapq.heappop(self._queue)
            self._dispatch(event)
            dispatched += 1
        return dispatched

    def _dispatch(self, event: Event) -> None:
        self._dispatched_count += 1
        for handler in self._global_subscribers:
            handler(event)
        for handler in self._subscribers.get(event.event_type, []):
            handler(event)

    @property
    def dispatched_count(self) -> int:
        return self._dispatched_count

    def pending(self) -> int:
        return len(self._queue)
