"""Engine lifecycle state machine (section 47) exposed to the frontend via
SystemStatus (section 6 / 38).
"""
from __future__ import annotations

from enum import Enum


class EngineState(str, Enum):
    INITIALISING = "INITIALISING"
    READY = "READY"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    DEGRADED = "DEGRADED"
    STOPPING = "STOPPING"
    STOPPED = "STOPPED"
    FAILED = "FAILED"


_ALLOWED_TRANSITIONS: dict[EngineState, set[EngineState]] = {
    EngineState.INITIALISING: {EngineState.READY, EngineState.FAILED},
    EngineState.READY: {EngineState.RUNNING, EngineState.STOPPING, EngineState.FAILED},
    EngineState.RUNNING: {
        EngineState.READY,  # a one-shot run (simulate/backtest) completing idles back to READY
        EngineState.PAUSED,
        EngineState.DEGRADED,
        EngineState.STOPPING,
        EngineState.FAILED,
    },
    EngineState.PAUSED: {EngineState.RUNNING, EngineState.STOPPING, EngineState.FAILED},
    EngineState.DEGRADED: {
        EngineState.RUNNING,
        EngineState.STOPPING,
        EngineState.FAILED,
    },
    EngineState.STOPPING: {EngineState.STOPPED, EngineState.FAILED},
    EngineState.STOPPED: set(),
    EngineState.FAILED: set(),
}


class InvalidTransition(Exception):
    pass


class LifecycleController:
    """Tracks the engine's current state and enforces legal transitions."""

    def __init__(self) -> None:
        self._state = EngineState.INITIALISING
        self._history: list[EngineState] = [self._state]

    @property
    def state(self) -> EngineState:
        return self._state

    @property
    def history(self) -> list[EngineState]:
        return list(self._history)

    def transition(self, new_state: EngineState) -> None:
        allowed = _ALLOWED_TRANSITIONS[self._state]
        if new_state not in allowed:
            raise InvalidTransition(
                f"cannot transition from {self._state.value} to {new_state.value}"
            )
        self._state = new_state
        self._history.append(new_state)

    def is_operational(self) -> bool:
        return self._state in (EngineState.RUNNING, EngineState.DEGRADED)
