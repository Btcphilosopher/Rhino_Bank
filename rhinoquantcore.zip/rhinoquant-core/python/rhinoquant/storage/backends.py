"""Concrete storage backends (section 27). Parquet/Arrow is the preferred
format for historical quantitative research (columnar, compressed,
schema-carrying); CSV/JSONL are provided for interoperability and human
inspection; DuckDB is an optional analytical-query layer over the same
Parquet files.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

from rhinoquant.storage.base import StorageBackend


class ParquetStorageBackend(StorageBackend):
    """Preferred backend for historical research data (section 27)."""

    name = "parquet"

    def write_records(self, path: str, records: list[dict]) -> None:
        import polars as pl

        Path(path).parent.mkdir(parents=True, exist_ok=True)
        pl.DataFrame(records).write_parquet(path)

    def read_records(self, path: str) -> list[dict]:
        import polars as pl

        return pl.read_parquet(path).to_dicts()


class CSVStorageBackend(StorageBackend):
    name = "csv"

    def write_records(self, path: str, records: list[dict]) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        if not records:
            Path(path).write_text("")
            return
        fieldnames = list(records[0].keys())
        with open(path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in records:
                writer.writerow({k: json.dumps(v) if isinstance(v, (dict, list)) else v for k, v in row.items()})

    def read_records(self, path: str) -> list[dict]:
        with open(path, newline="") as f:
            return list(csv.DictReader(f))


class JSONLStorageBackend(StorageBackend):
    name = "jsonl"

    def write_records(self, path: str, records: list[dict]) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            for row in records:
                f.write(json.dumps(row, default=str) + "\n")

    def read_records(self, path: str) -> list[dict]:
        with open(path) as f:
            return [json.loads(line) for line in f if line.strip()]


class DuckDBStorageBackend(StorageBackend):
    """Analytical-query convenience layer: writes the same Parquet files as
    :class:`ParquetStorageBackend` and answers ad-hoc SQL over them via an
    in-process DuckDB connection (optional dependency: ``duckdb``).
    """

    name = "duckdb"

    def __init__(self) -> None:
        self._parquet = ParquetStorageBackend()

    def write_records(self, path: str, records: list[dict]) -> None:
        self._parquet.write_records(path, records)

    def read_records(self, path: str) -> list[dict]:
        return self._parquet.read_records(path)

    def query(self, sql: str, path: str):
        import duckdb

        return duckdb.query(sql.replace("{path}", path)).fetchall()
