"""Domain stores (section 27):
``MarketDataStore``, ``FeatureStore``, ``TradeStore``, ``OrderStore``,
``ExperimentStore``. Each is a thin, typed convenience layer over a
:class:`~rhinoquant.storage.base.StorageBackend` — Parquet by default.
"""
from __future__ import annotations

import dataclasses
from pathlib import Path
from typing import Optional

from rhinoquant.features.engine import FeatureSnapshot
from rhinoquant.schemas.backtest import BacktestResult
from rhinoquant.schemas.base import RhinoQuantSchema
from rhinoquant.schemas.fills import Fill
from rhinoquant.schemas.market import MarketSnapshot
from rhinoquant.schemas.orders import Order
from rhinoquant.storage.backends import ParquetStorageBackend
from rhinoquant.storage.base import StorageBackend

_EXTENSION_BY_BACKEND = {"parquet": "parquet", "csv": "csv", "jsonl": "jsonl", "duckdb": "parquet"}


class DomainStore:
    def __init__(self, root_path: str, backend: Optional[StorageBackend] = None) -> None:
        self.root_path = Path(root_path)
        self.backend = backend or ParquetStorageBackend()

    def _path(self, name: str) -> str:
        ext = _EXTENSION_BY_BACKEND.get(self.backend.name, "parquet")
        return str(self.root_path / f"{name}.{ext}")

    def save_schemas(self, name: str, records: list[RhinoQuantSchema]) -> str:
        path = self._path(name)
        self.backend.write_records(path, [r.to_json_dict() for r in records])
        return path

    def save_dicts(self, name: str, records: list[dict]) -> str:
        path = self._path(name)
        self.backend.write_records(path, records)
        return path

    def load(self, name: str) -> list[dict]:
        return self.backend.read_records(self._path(name))


class MarketDataStore(DomainStore):
    def save_snapshots(self, symbol: str, snapshots: list[MarketSnapshot]) -> str:
        return self.save_schemas(f"market/{symbol}", snapshots)


class FeatureStore(DomainStore):
    def save_features(self, symbol: str, snapshots: list[FeatureSnapshot]) -> str:
        # FeatureSnapshot is a plain dataclass (not a pydantic schema) so
        # the streaming feature engine has zero pydantic-validation
        # overhead on the hot path; convert at the storage boundary only.
        return self.save_dicts(f"features/{symbol}", [dataclasses.asdict(s) for s in snapshots])


class TradeStore(DomainStore):
    def save_fills(self, portfolio_id: str, fills: list[Fill]) -> str:
        return self.save_schemas(f"fills/{portfolio_id}", fills)


class OrderStore(DomainStore):
    def save_orders(self, portfolio_id: str, orders: list[Order]) -> str:
        return self.save_schemas(f"orders/{portfolio_id}", orders)


class ExperimentStore(DomainStore):
    def save_backtest_result(self, result: BacktestResult) -> str:
        return self.save_schemas(f"backtests/{result.backtest_id}", [result])

    def save_search_report(self, name: str, report_dicts: list[dict]) -> str:
        return self.save_dicts(f"experiments/{name}", report_dicts)
