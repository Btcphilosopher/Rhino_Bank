"""Storage backend interface (section 27).

Every backend reads/writes plain lists of JSON-compatible dicts — callers
serialise their own pydantic schemas (``[obj.to_json_dict() for obj in
records]``) before writing and reconstruct them after reading. Keeping the
backend interface schema-agnostic is what lets
:class:`~rhinoquant.storage.stores.MarketDataStore`/``FeatureStore``/etc.
share one small set of backends (section 49: pluggable ``StorageBackend``).
"""
from __future__ import annotations

import abc


class StorageBackend(abc.ABC):
    name: str = "base"

    @abc.abstractmethod
    def write_records(self, path: str, records: list[dict]) -> None:
        raise NotImplementedError

    @abc.abstractmethod
    def read_records(self, path: str) -> list[dict]:
        raise NotImplementedError
