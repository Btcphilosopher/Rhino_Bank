"""Independent kill-switch mechanisms (section 18).

Each kind of kill switch is keyed independently (a strategy kill for
``market_maker`` does not affect any other strategy; a venue kill for
``SIM`` does not affect other venues), and a :class:`KillSwitchEngine`
tracks which are currently active. A kill switch **prevents new orders**
from passing the risk gate (see :mod:`rhinoquant.risk.engine`); cancelling
orders already resting at a venue is out of scope for the current
simulator/paper execution adapters and is left as an explicit extension
point on :class:`~rhinoquant.execution.base.ExecutionEngine` for a future
live adapter (section 18: "Future execution adapters should support
cancellation of existing orders.").
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from rhinoquant.core.ids import now_ns


class KillSwitchKind(str, Enum):
    STRATEGY = "STRATEGY"
    PORTFOLIO = "PORTFOLIO"
    VENUE = "VENUE"
    GLOBAL = "GLOBAL"
    CONNECTIVITY = "CONNECTIVITY"
    STALE_DATA = "STALE_DATA"
    LOSS_LIMIT = "LOSS_LIMIT"
    RISK_BREACH = "RISK_BREACH"


@dataclass
class KillSwitchRecord:
    kind: KillSwitchKind
    key: str
    reason: str
    activated_ns: int
    active: bool = True
    deactivated_ns: Optional[int] = None

    def label(self) -> str:
        return f"{self.kind.value}:{self.key}"


class KillSwitchEngine:
    def __init__(self) -> None:
        self._records: dict[tuple[KillSwitchKind, str], KillSwitchRecord] = {}

    def activate(self, kind: KillSwitchKind, key: str, reason: str) -> KillSwitchRecord:
        record = KillSwitchRecord(kind=kind, key=key, reason=reason, activated_ns=now_ns())
        self._records[(kind, key)] = record
        return record

    def deactivate(self, kind: KillSwitchKind, key: str) -> None:
        record = self._records.get((kind, key))
        if record is not None:
            record.active = False
            record.deactivated_ns = now_ns()

    def is_active(self, kind: KillSwitchKind, key: str) -> bool:
        record = self._records.get((kind, key))
        return bool(record and record.active)

    def any_active_for(self, strategy_id: str, portfolio_id: str, venue: str) -> Optional[KillSwitchRecord]:
        """Returns the first active switch (in priority order GLOBAL >
        CONNECTIVITY > STALE_DATA > VENUE > PORTFOLIO > STRATEGY >
        LOSS_LIMIT > RISK_BREACH) blocking a new order for this
        strategy/portfolio/venue combination, or None if nothing blocks it.
        """
        for kind, key in (
            (KillSwitchKind.GLOBAL, "GLOBAL"),
            (KillSwitchKind.CONNECTIVITY, venue),
            (KillSwitchKind.STALE_DATA, venue),
            (KillSwitchKind.VENUE, venue),
            (KillSwitchKind.PORTFOLIO, portfolio_id),
            (KillSwitchKind.STRATEGY, strategy_id),
            (KillSwitchKind.LOSS_LIMIT, strategy_id),
            (KillSwitchKind.RISK_BREACH, strategy_id),
        ):
            if self.is_active(kind, key):
                return self._records[(kind, key)]
        return None

    def active_switches(self) -> list[str]:
        return [r.label() for r in self._records.values() if r.active]
