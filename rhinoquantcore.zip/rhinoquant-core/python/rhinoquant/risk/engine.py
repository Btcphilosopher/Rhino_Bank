"""Risk engine (section 17).

Positioned strictly between strategy and OMS:

    Strategy -> Risk Engine -> Order Validation -> OMS -> Execution

:meth:`RiskEngine.evaluate` is the only gate an :class:`OrderIntent` passes
through before becoming an :class:`Order`. Every rejection carries an
explicit :class:`~rhinoquant.schemas.risk.RiskRejectReason` code — never a
bare boolean.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Optional

from rhinoquant.config import RiskConfig
from rhinoquant.core.ids import now_ns
from rhinoquant.risk.kill_switch import KillSwitchEngine
from rhinoquant.schemas.portfolio import PortfolioState
from rhinoquant.schemas.orders import Side
from rhinoquant.schemas.risk import RiskDecision, RiskRejectReason, RiskState, RiskStatusLevel
from rhinoquant.strategies.base import OrderIntent


@dataclass
class RiskContext:
    """Everything the risk engine needs to know about current state to
    evaluate one order intent. Positions/P&L are owned by the portfolio
    engine (section 16) and passed in here read-only — risk never computes
    P&L itself, it only checks it against limits.
    """

    portfolio_state: Optional[PortfolioState] = None
    strategy_realised_pnl: dict[str, float] = field(default_factory=dict)
    daily_pnl: float = 0.0
    reference_price: Optional[float] = None
    market_data_age_ns: int = 0
    venue_exposure: dict[str, float] = field(default_factory=dict)
    equity: float = 1.0


class RiskEngine:
    def __init__(self, config: RiskConfig, kill_switches: Optional[KillSwitchEngine] = None) -> None:
        self.config = config
        self.kill_switches = kill_switches or KillSwitchEngine()
        self._order_timestamps: dict[str, deque] = {}
        self._cancel_timestamps: dict[str, deque] = {}
        self._recent_fingerprints: dict[tuple, int] = {}
        self.decisions_log: list[RiskDecision] = []

    # ------------------------------------------------------------------ #
    def evaluate(self, intent: OrderIntent, context: RiskContext, timestamp_ns: Optional[int] = None) -> RiskDecision:
        ts = timestamp_ns if timestamp_ns is not None else now_ns()
        reason, detail = self._first_violation(intent, context, ts)
        decision = RiskDecision(
            order_client_id=intent.correlation_id,
            accepted=reason is None,
            reason=reason,
            detail=detail,
            timestamp_ns=ts,
            correlation_id=intent.correlation_id,
        )
        self.decisions_log.append(decision)
        if decision.accepted:
            self._record_order(intent, ts)
        return decision

    def record_cancel(self, strategy_id: str, timestamp_ns: Optional[int] = None) -> None:
        ts = timestamp_ns if timestamp_ns is not None else now_ns()
        dq = self._cancel_timestamps.setdefault(strategy_id, deque())
        dq.append(ts)

    def risk_state(self, context: RiskContext, strategy_id: Optional[str] = None, timestamp_ns: Optional[int] = None) -> RiskState:
        ts = timestamp_ns if timestamp_ns is not None else now_ns()
        active = self.kill_switches.active_switches()
        breaches = []
        if context.daily_pnl <= -self.config.max_daily_loss:
            breaches.append("DAILY_LOSS_LIMIT")
        if active:
            status = RiskStatusLevel.KILLED
        elif breaches:
            status = RiskStatusLevel.BREACH
        else:
            status = RiskStatusLevel.NORMAL
        return RiskState(
            status=status,
            strategy_id=strategy_id,
            portfolio_id=context.portfolio_state.portfolio_id if context.portfolio_state else None,
            current_position=self._position_for(context, strategy_id),
            current_notional=context.portfolio_state.gross_exposure if context.portfolio_state else 0.0,
            current_leverage=context.portfolio_state.leverage if context.portfolio_state else 0.0,
            daily_pnl=context.daily_pnl,
            breaches=breaches,
            kill_switches_active=active,
            timestamp_ns=ts,
        )

    # ------------------------------------------------------------------ #
    def _first_violation(
        self, intent: OrderIntent, context: RiskContext, ts: int
    ) -> tuple[Optional[RiskRejectReason], Optional[str]]:
        cfg = self.config

        kill = self.kill_switches.any_active_for(intent.strategy_id, intent.portfolio_id, "SIM")
        if kill is not None:
            return RiskRejectReason.RISK_REJECT_KILL_SWITCH, f"active kill switch: {kill.label()} ({kill.reason})"

        if context.market_data_age_ns > cfg.stale_market_ms * 1_000_000:
            return (
                RiskRejectReason.RISK_REJECT_STALE_MARKET,
                f"market data age {context.market_data_age_ns / 1e6:.1f}ms exceeds {cfg.stale_market_ms}ms",
            )

        fingerprint = (intent.strategy_id, intent.symbol, intent.side, intent.price, intent.quantity)
        last_seen = self._recent_fingerprints.get(fingerprint)
        dedupe_window_ns = 50_000_000  # 50ms
        if last_seen is not None and ts - last_seen < dedupe_window_ns:
            return RiskRejectReason.RISK_REJECT_DUPLICATE_ORDER, "identical order resubmitted within dedupe window"
        self._recent_fingerprints[fingerprint] = ts

        if intent.quantity <= 0:
            return RiskRejectReason.RISK_REJECT_ORDER_SIZE_LIMIT, "order quantity must be positive"
        if intent.quantity > cfg.max_order_quantity:
            return (
                RiskRejectReason.RISK_REJECT_ORDER_SIZE_LIMIT,
                f"quantity {intent.quantity} exceeds max_order_quantity {cfg.max_order_quantity}",
            )

        ref_price = context.reference_price
        if intent.price is not None and ref_price:
            deviation_bps = abs(intent.price - ref_price) / ref_price * 10_000
            # check the more severe condition first: an order that far
            # outside the collar is a probable fat-finger, not merely a
            # collar breach, and must be classified as such rather than
            # being caught (and mis-labelled) by the coarser collar check.
            if deviation_bps > cfg.price_collar_bps * 5:
                return (
                    RiskRejectReason.RISK_REJECT_FAT_FINGER,
                    f"order price {intent.price} implausibly far ({deviation_bps:.0f}bps) from reference {ref_price}",
                )
            if deviation_bps > cfg.price_collar_bps:
                return (
                    RiskRejectReason.RISK_REJECT_PRICE_COLLAR,
                    f"order price {intent.price} deviates {deviation_bps:.0f}bps from reference {ref_price}",
                )

        price_for_notional = intent.price or ref_price
        if price_for_notional:
            notional = intent.quantity * price_for_notional
            if notional > cfg.max_notional:
                return (
                    RiskRejectReason.RISK_REJECT_NOTIONAL_LIMIT,
                    f"notional {notional:.2f} exceeds max_notional {cfg.max_notional}",
                )

        current_position = self._position_for(context, intent.strategy_id)
        signed_qty = intent.quantity if intent.side == Side.BUY else -intent.quantity
        prospective_position = current_position + signed_qty
        if abs(prospective_position) > cfg.max_position:
            return (
                RiskRejectReason.RISK_REJECT_POSITION_LIMIT,
                f"prospective position {prospective_position} exceeds max_position {cfg.max_position}",
            )

        if context.equity > 0 and context.portfolio_state:
            leverage = context.portfolio_state.gross_exposure / context.equity
            if leverage > cfg.max_leverage:
                return (
                    RiskRejectReason.RISK_REJECT_LEVERAGE_LIMIT,
                    f"leverage {leverage:.2f}x exceeds max_leverage {cfg.max_leverage}x",
                )

        if context.daily_pnl <= -cfg.max_daily_loss:
            return RiskRejectReason.RISK_REJECT_DAILY_LOSS_LIMIT, f"daily pnl {context.daily_pnl:.2f} breaches limit"

        strategy_pnl = context.strategy_realised_pnl.get(intent.strategy_id, 0.0)
        if strategy_pnl <= -cfg.max_strategy_loss:
            return (
                RiskRejectReason.RISK_REJECT_STRATEGY_LOSS_LIMIT,
                f"strategy {intent.strategy_id} pnl {strategy_pnl:.2f} breaches limit",
            )

        venue_exp = context.venue_exposure.get("SIM", 0.0)
        if venue_exp > cfg.max_venue_exposure:
            return (
                RiskRejectReason.RISK_REJECT_VENUE_EXPOSURE_LIMIT,
                f"venue exposure {venue_exp:.2f} exceeds max_venue_exposure {cfg.max_venue_exposure}",
            )

        if self._rate_exceeded(self._order_timestamps, intent.strategy_id, ts, cfg.max_order_rate_per_sec):
            return RiskRejectReason.RISK_REJECT_RATE_LIMIT, "order submission rate limit exceeded"
        if self._rate_exceeded(self._cancel_timestamps, intent.strategy_id, ts, cfg.max_cancel_rate_per_sec):
            return RiskRejectReason.RISK_REJECT_CANCEL_RATE_LIMIT, "cancel rate limit exceeded"

        return None, None

    @staticmethod
    def _position_for(context: RiskContext, strategy_id: Optional[str]) -> float:
        if not context.portfolio_state or not strategy_id:
            return 0.0
        return sum(
            p.quantity for p in context.portfolio_state.positions if p.strategy_id == strategy_id
        )

    def _record_order(self, intent: OrderIntent, ts: int) -> None:
        dq = self._order_timestamps.setdefault(intent.strategy_id, deque())
        dq.append(ts)

    @staticmethod
    def _rate_exceeded(store: dict[str, deque], key: str, ts: int, max_per_sec: float) -> bool:
        dq = store.setdefault(key, deque())
        window_ns = 1_000_000_000
        while dq and ts - dq[0] > window_ns:
            dq.popleft()
        return len(dq) >= max_per_sec
