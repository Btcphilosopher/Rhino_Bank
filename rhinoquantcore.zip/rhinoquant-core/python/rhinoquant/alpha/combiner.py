"""Alpha combiner (section 12):

    Order Flow Alpha
    Momentum Alpha
    Mean Reversion Alpha
    Cross Asset Alpha
    Volatility Alpha
             |
    Signal Normalisation
             |
    Alpha Combiner
             |
    Portfolio Optimisation

Signals are first normalised to a directional score in [-1, 1]
(``direction_value * confidence``), then combined as a confidence-weighted
average. A non-directional model (e.g. :class:`VolatilityAlpha`) still
contributes through its ``risk`` field, which is combined via a simple max
(the more cautious estimate wins) rather than averaged away.
"""
from __future__ import annotations

from typing import Optional

from rhinoquant.core.ids import new_correlation_id
from rhinoquant.schemas.signals import Signal, SignalDirection

_DIRECTION_VALUE = {
    SignalDirection.LONG: 1.0,
    SignalDirection.SHORT: -1.0,
    SignalDirection.FLAT: 0.0,
}


class AlphaCombiner:
    def __init__(self, weights: Optional[dict[str, float]] = None, flat_threshold: float = 0.05) -> None:
        self.weights = weights or {}
        self.flat_threshold = flat_threshold

    def combine(self, symbol: str, signals: list[Optional[Signal]], timestamp_ns: int) -> Optional[Signal]:
        active = [s for s in signals if s is not None]
        if not active:
            return None

        total_weight = 0.0
        weighted_score = 0.0
        weighted_return = 0.0
        max_risk = 0.0
        weighted_holding = 0.0

        for sig in active:
            w = self.weights.get(sig.source_model, 1.0)
            score = _DIRECTION_VALUE[sig.direction] * sig.confidence
            weighted_score += w * score
            weighted_return += w * sig.confidence * sig.expected_return
            max_risk = max(max_risk, sig.risk)
            weighted_holding += w * sig.confidence * sig.holding_period_ns
            total_weight += w * sig.confidence if sig.confidence > 0 else w * 0.01

        if total_weight <= 0:
            return None

        combined_score = weighted_score / len(active)
        if abs(combined_score) < self.flat_threshold:
            direction = SignalDirection.FLAT
        else:
            direction = SignalDirection.LONG if combined_score > 0 else SignalDirection.SHORT

        return Signal(
            signal_id=new_correlation_id(),
            strategy_id="alpha_combiner",
            symbol=symbol,
            timestamp_ns=timestamp_ns,
            direction=direction,
            confidence=min(abs(combined_score), 1.0),
            expected_return=weighted_return / total_weight,
            holding_period_ns=int(weighted_holding / total_weight) if total_weight > 0 else 0,
            risk=max_risk,
            source_model="alpha_combiner",
        )
