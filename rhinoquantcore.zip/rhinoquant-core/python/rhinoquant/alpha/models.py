"""Research alpha models (section 12 combiner inputs / section 14).

These are intentionally simple, transparent models — the point of this
engine is a correct, auditable pipeline from features to signal to
combined alpha to portfolio optimisation, not a claim of predictive edge.
"""
from __future__ import annotations

from typing import Optional

from rhinoquant.alpha.base import AlphaModel
from rhinoquant.features.engine import FeatureSnapshot
from rhinoquant.schemas.portfolio import PortfolioState
from rhinoquant.schemas.signals import Signal, SignalDirection


class OrderFlowAlpha(AlphaModel):
    """Signals in the direction of order-flow / depth imbalance."""

    name = "order_flow_alpha"

    def __init__(self, threshold: float = 0.15, holding_period_ns: int = 2_000_000_000) -> None:
        self.threshold = threshold
        self.holding_period_ns = holding_period_ns

    def evaluate(self, *, symbol, features: FeatureSnapshot, portfolio=None) -> Optional[Signal]:
        imb = features.imbalance_l1
        if imb is None or features.mid is None or features.spread is None:
            return None
        if abs(imb) < self.threshold:
            return None
        direction = SignalDirection.LONG if imb > 0 else SignalDirection.SHORT
        confidence = min(abs(imb), 1.0)
        expected_return = imb * (features.spread / features.mid) * 0.5
        return self._make_signal(
            symbol, direction, confidence, expected_return,
            risk=features.realised_volatility or 0.0,
            holding_period_ns=self.holding_period_ns,
            timestamp_ns=features.timestamp_ns,
        )


class MomentumAlpha(AlphaModel):
    """Short-term momentum: continues the direction of the recent move."""

    name = "momentum_alpha"

    def __init__(self, threshold: float = 0.0005, holding_period_ns: int = 5_000_000_000) -> None:
        self.threshold = threshold
        self.holding_period_ns = holding_period_ns

    def evaluate(self, *, symbol, features: FeatureSnapshot, portfolio=None) -> Optional[Signal]:
        mom = features.short_term_momentum
        if mom is None or abs(mom) < self.threshold:
            return None
        direction = SignalDirection.LONG if mom > 0 else SignalDirection.SHORT
        confidence = min(abs(mom) / (self.threshold * 5), 1.0)
        return self._make_signal(
            symbol, direction, confidence, expected_return=mom * 0.3,
            risk=features.realised_volatility or 0.0,
            holding_period_ns=self.holding_period_ns,
            timestamp_ns=features.timestamp_ns,
        )


class MeanReversionAlpha(AlphaModel):
    """Fades short-term z-score extremes back toward the rolling mean."""

    name = "mean_reversion_alpha"

    def __init__(self, z_threshold: float = 1.5, holding_period_ns: int = 3_000_000_000) -> None:
        self.z_threshold = z_threshold
        self.holding_period_ns = holding_period_ns

    def evaluate(self, *, symbol, features: FeatureSnapshot, portfolio=None) -> Optional[Signal]:
        z = features.mean_reversion_zscore
        if z is None or abs(z) < self.z_threshold:
            return None
        direction = SignalDirection.SHORT if z > 0 else SignalDirection.LONG
        confidence = min(abs(z) / (self.z_threshold * 2), 1.0)
        expected_return = -z * 0.0005
        return self._make_signal(
            symbol, direction, confidence, expected_return,
            risk=features.realised_volatility or 0.0,
            holding_period_ns=self.holding_period_ns,
            timestamp_ns=features.timestamp_ns,
        )


class VolatilityAlpha(AlphaModel):
    """Not directional: raises ``risk`` (used by the combiner/optimiser to
    scale down position size) when realised vol is elevated relative to
    its own recent history (vol-of-vol)."""

    name = "volatility_alpha"

    def evaluate(self, *, symbol, features: FeatureSnapshot, portfolio=None) -> Optional[Signal]:
        rv = features.realised_volatility
        vov = features.volatility_of_volatility
        if rv is None:
            return None
        risk = rv * (1.0 + (vov or 0.0))
        return self._make_signal(
            symbol, SignalDirection.FLAT, confidence=0.0, expected_return=0.0,
            risk=risk, holding_period_ns=0, timestamp_ns=features.timestamp_ns,
        )
