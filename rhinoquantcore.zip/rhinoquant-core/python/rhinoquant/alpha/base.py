"""Alpha model interface (section 12).

    signal = alpha_engine.evaluate(
        market_state=market_state,
        features=features,
        portfolio=portfolio,
    )

Every concrete model returns a :class:`~rhinoquant.schemas.signals.Signal`
(direction, confidence, expected_return, holding_period, risk, timestamp)
or ``None`` when it has nothing to say this update.
"""
from __future__ import annotations

import abc
from typing import Optional

from rhinoquant.core.ids import new_correlation_id
from rhinoquant.features.engine import FeatureSnapshot
from rhinoquant.schemas.portfolio import PortfolioState
from rhinoquant.schemas.signals import Signal, SignalDirection


class AlphaModel(abc.ABC):
    """Base class every alpha model implements (section 49: replaceable
    plugin)."""

    name: str = "base_alpha"

    @abc.abstractmethod
    def evaluate(
        self,
        *,
        symbol: str,
        features: FeatureSnapshot,
        portfolio: Optional[PortfolioState] = None,
    ) -> Optional[Signal]:
        raise NotImplementedError

    def _make_signal(
        self,
        symbol: str,
        direction: SignalDirection,
        confidence: float,
        expected_return: float,
        risk: float,
        holding_period_ns: int,
        timestamp_ns: int,
    ) -> Signal:
        return Signal(
            signal_id=new_correlation_id(),
            strategy_id=self.name,
            symbol=symbol,
            timestamp_ns=timestamp_ns,
            direction=direction,
            confidence=max(0.0, min(1.0, confidence)),
            expected_return=expected_return,
            holding_period_ns=holding_period_ns,
            risk=max(0.0, risk),
            source_model=self.name,
        )
