"""Event-driven backtest engine (section 22).

Enforces strict causal ordering — a single ``for`` loop over a
timestamp-merged event stream, with every downstream effect of event N
(strategy decisions, risk checks, orders, fills, portfolio/feature state)
fully applied before event N+1 is even read off the stream. There is no
concurrency and no peeking ahead in the stream, so there is no code path
that could look ahead (section 22: "Never introduce look-ahead bias.").

The same engine drives both ``python -m rhinoquant backtest`` (replaying a
configured synthetic dataset) and ``python -m rhinoquant simulate`` (a
live-looking synthetic run) — "backtest" and "simulate" differ only in
which market data provider and which downstream execution backend
(:class:`~rhinoquant.execution.simulator.SimulatorExecution` for both,
today) are wired in, not in the causal-ordering guarantee itself.
"""
from __future__ import annotations

import hashlib
import heapq
from dataclasses import dataclass, field
from typing import Iterator, Optional

from rhinoquant.analytics.latency import LatencyEngine
from rhinoquant.analytics.performance import OrderCounters, compute_performance
from rhinoquant.config import EngineConfig
from rhinoquant.core.events import Event, EventType
from rhinoquant.core.ids import new_run_id, now_ns
from rhinoquant.execution.simulator import SimulatorExecution
from rhinoquant.features.engine import FeatureEngine
from rhinoquant.marketdata.provider import MarketDataProvider
from rhinoquant.oms.manager import OrderManager
from rhinoquant.orderbook.book import LimitOrderBook
from rhinoquant.portfolio.engine import PortfolioEngine
from rhinoquant.risk.engine import RiskContext, RiskEngine
from rhinoquant.schemas.backtest import BacktestResult
from rhinoquant.schemas.orders import OrderStatus
from rhinoquant.simulation.exchange import ExchangeFeeConfig, SimulatedExchange
from rhinoquant.strategies.base import Strategy


@dataclass
class BacktestRunOptions:
    max_events: Optional[int] = None
    timer_interval_events: int = 200
    equity_sample_interval_events: int = 500
    starting_cash: float = 1_000_000.0
    fees: ExchangeFeeConfig = field(default_factory=ExchangeFeeConfig)


class BacktestEngine:
    def __init__(
        self,
        config: EngineConfig,
        providers: dict[str, MarketDataProvider],
        strategies: list[Strategy],
        options: Optional[BacktestRunOptions] = None,
        run_id: Optional[str] = None,
    ) -> None:
        self.config = config
        self.providers = providers
        self.strategies = strategies
        self.options = options or BacktestRunOptions()
        self.run_id = run_id or new_run_id()

        self.books: dict[str, LimitOrderBook] = {s: LimitOrderBook(symbol=s) for s in providers}
        self.feature_engines: dict[str, FeatureEngine] = {s: FeatureEngine(symbol=s) for s in providers}
        self.exchanges: dict[str, SimulatedExchange] = {
            s: SimulatedExchange(s, self.books[s], latency=config.latency, fees=self.options.fees) for s in providers
        }
        self.execution = SimulatorExecution(self.exchanges)
        self.oms = OrderManager()
        self.risk_engine = RiskEngine(config.risk)
        self.portfolio = PortfolioEngine("main", starting_cash=self.options.starting_cash)
        self.latency_engine = LatencyEngine()
        self.order_counters = OrderCounters()

        self._last_market_ns: dict[str, int] = {}
        self.fills: list = []  # full fill history, for the API/storage layer (section 7 `/fills`)
        self.equity_curve: list[float] = []
        self.equity_timestamps: list[int] = []
        self.events_processed = 0
        self._total_traded_notional = 0.0
        self._started_ns: Optional[int] = None
        self._finished_ns: Optional[int] = None
        self._first_ts: Optional[int] = None
        self._last_ts: Optional[int] = None

    # ------------------------------------------------------------------ #
    def run(self) -> BacktestResult:
        self._started_ns = now_ns()
        for event in self._merged_events():
            if self.options.max_events is not None and self.events_processed >= self.options.max_events:
                break
            self._process_event(event)
            self.events_processed += 1
        self._finished_ns = now_ns()
        return self.build_result()

    # -- public read-only accessors for the API/CLI layer ---------------- #
    @property
    def last_timestamp_ns(self) -> Optional[int]:
        return self._last_ts

    @property
    def started_ns(self) -> Optional[int]:
        return self._started_ns

    @property
    def finished_ns(self) -> Optional[int]:
        return self._finished_ns

    @property
    def total_traded_notional(self) -> float:
        return self._total_traded_notional

    def _merged_events(self) -> Iterator[Event]:
        iterators = {symbol: provider.events() for symbol, provider in self.providers.items()}
        heap: list[tuple[int, int, str, Event]] = []
        tie = 0
        for symbol, it in iterators.items():
            first = next(it, None)
            if first is not None:
                heap.append((first.timestamp_ns, tie, symbol, first))
                tie += 1
        heapq.heapify(heap)
        while heap:
            ts, _, symbol, event = heapq.heappop(heap)
            yield event
            nxt = next(iterators[symbol], None)
            if nxt is not None:
                heapq.heappush(heap, (nxt.timestamp_ns, tie, symbol, nxt))
                tie += 1

    # ------------------------------------------------------------------ #
    def _process_event(self, event: Event) -> None:
        symbol = event.symbol
        if symbol is None or symbol not in self.books:
            return
        ts = event.timestamp_ns
        if self._first_ts is None:
            self._first_ts = ts
        self._last_ts = ts
        self._last_market_ns[symbol] = ts
        book = self.books[symbol]
        fe = self.feature_engines[symbol]
        pipeline_ts: dict[str, int] = {"market_data_arrival": ts}

        if event.event_type == EventType.QUOTE:
            bid_levels = event.payload.get("bid_levels") or [(event.payload["bid_price"], event.payload["bid_quantity"])]
            ask_levels = event.payload.get("ask_levels") or [(event.payload["ask_price"], event.payload["ask_quantity"])]
            book.apply_snapshot(bid_levels, ask_levels)
            pipeline_ts["book_update"] = ts
            snapshot = fe.on_book(book, ts)
            pipeline_ts["feature_calculation"] = ts

            mid = book.mid()
            if mid is not None:
                self.portfolio.mark_price(symbol, mid)

            for strat in self.strategies:
                if hasattr(strat, "on_features"):
                    strat.on_features(snapshot)
                strat.on_book_update(book, ts)
            pipeline_ts["strategy_decision"] = ts
            self._route_intents(pipeline_ts, ts)

        elif event.event_type == EventType.TRADE:
            price = event.payload["price"]
            quantity = event.payload["quantity"]
            side = event.payload["aggressor_side"]
            fe.on_trade(price, quantity, side, ts)
            fills = self.exchanges[symbol].on_market_trade(price, quantity, side, ts)
            for strat in self.strategies:
                strat.on_trade(event)
            self._apply_fills(fills, ts)

        if self.events_processed % self.options.timer_interval_events == 0:
            for strat in self.strategies:
                strat.on_timer(ts)
            self._route_intents(pipeline_ts, ts)

        if self.events_processed % self.options.equity_sample_interval_events == 0:
            state = self.portfolio.state(ts)
            self.equity_curve.append(state.cash + state.net_exposure)
            self.equity_timestamps.append(ts)

    def _route_intents(self, pipeline_ts: dict[str, int], ts: int) -> None:
        for strat in self.strategies:
            for cancel in strat.generate_cancels():
                self._process_cancel(cancel, ts)
            for intent in strat.generate_orders():
                self.order_counters.submitted += 1
                book = self.books.get(intent.symbol)
                state = self.portfolio.state(ts)
                equity = state.cash + state.net_exposure
                context = RiskContext(
                    portfolio_state=state,
                    strategy_realised_pnl=self.portfolio.strategy_realised_pnl(),
                    daily_pnl=self.portfolio.realised_pnl() + self.portfolio.unrealised_pnl(),
                    reference_price=book.mid() if book else None,
                    market_data_age_ns=ts - self._last_market_ns.get(intent.symbol, ts),
                    venue_exposure=state.venue_exposure,
                    equity=equity if equity > 0 else 1.0,
                )
                stage_ts = dict(pipeline_ts)
                stage_ts["risk_check"] = ts
                decision = self.risk_engine.evaluate(intent, context, ts)
                if not decision.accepted:
                    self.order_counters.rejected += 1
                    continue
                self.order_counters.accepted += 1

                order = self.oms.create_order(intent, ts)
                stage_ts["order_creation"] = ts
                report = self.execution.submit(order, ts)
                stage_ts["submission"] = ts
                if not report.accepted:
                    self.oms.reject(order.client_order_id, report.reject_reason or "execution_reject", ts)
                    continue
                ack_ts = report.ack_timestamp_ns if report.ack_timestamp_ns is not None else ts
                acked_order = self.oms.ack(order.client_order_id, report.exchange_order_id or "", ack_ts)
                stage_ts["acknowledgement"] = ack_ts
                # on_order_ack fires before any fills from this same submit
                # are applied, so a strategy tracking its own resting order
                # by client_order_id (e.g. MarketMakingStrategy) sees the id
                # in time to recognise an immediate marketable-order fill on
                # the very order it was just assigned.
                for s in self.strategies:
                    if s.strategy_id == intent.strategy_id:
                        s.on_order_ack(acked_order)
                if report.fills:
                    stage_ts["fill"] = report.fills[-1].timestamp_ns
                self._apply_fills(report.fills, ack_ts)
                self.latency_engine.record_pipeline(stage_ts)

    def _process_cancel(self, cancel, ts: int) -> None:
        order = self.oms.get(cancel.client_order_id)
        if order is None or order.status not in ("NEW", "ACK", "PARTIAL_FILL"):
            return  # unknown or already-terminal order: nothing to cancel
        report = self.execution.cancel(order, ts)
        if not report.accepted:
            return
        self.oms.cancel_request(cancel.client_order_id, ts)
        self.oms.cancel_ack(cancel.client_order_id, ts)
        self.order_counters.cancelled += 1
        self.risk_engine.record_cancel(cancel.strategy_id, ts)

    def _apply_fills(self, fills, ts: int) -> None:
        for fill in fills:
            self.portfolio.apply_fill(fill)
            self.fills.append(fill)
            self._total_traded_notional += fill.price * fill.quantity
            order = self.oms.apply_fill(fill.client_order_id, fill.quantity, fill.timestamp_ns)
            if order.status == OrderStatus.FILL:
                self.order_counters.filled += 1
            for strat in self.strategies:
                strat.on_fill(fill)

    # ------------------------------------------------------------------ #
    def build_result(self) -> BacktestResult:
        realisations = []
        for account in self.portfolio.all_accounts():
            realisations.extend(account.realisations)

        duration_seconds = ((self._finished_ns or 0) - (self._started_ns or 0)) / 1e9
        perf = compute_performance(
            equity_curve=self.equity_curve or [self.options.starting_cash],
            realisations=realisations,
            gross_pnl=self.portfolio.realised_pnl() + self.portfolio.unrealised_pnl(),
            net_pnl=self.portfolio.realised_pnl()
            + self.portfolio.unrealised_pnl()
            - self.portfolio.total_fees()
            + self.portfolio.total_rebates(),
            starting_equity=self.options.starting_cash,
            total_traded_notional=self._total_traded_notional,
            order_counters=self.order_counters,
            duration_seconds=duration_seconds,
        )

        digest_input = (
            f"{self.config.seed}|{self.events_processed}|{self.order_counters.submitted}|"
            f"{self.order_counters.filled}|{round(perf.net_pnl, 6)}|{round(self.portfolio.cash(), 6)}"
        ).encode()
        deterministic_hash = hashlib.sha256(digest_input).hexdigest()

        return BacktestResult(
            backtest_id=f"bt_{self.run_id}",
            run_id=self.run_id,
            strategy_id=",".join(sorted({s.strategy_id for s in self.strategies})) or "none",
            symbols=sorted(self.providers.keys()),
            started_ns=self._started_ns or 0,
            finished_ns=self._finished_ns or 0,
            events_processed=self.events_processed,
            orders_submitted=self.order_counters.submitted,
            orders_filled=self.order_counters.filled,
            orders_rejected=self.order_counters.rejected,
            total_return=perf.total_return,
            gross_pnl=perf.gross_pnl,
            net_pnl=perf.net_pnl,
            fees=self.portfolio.total_fees(),
            sharpe=perf.sharpe,
            sortino=perf.sortino,
            max_drawdown=perf.max_drawdown,
            volatility=perf.volatility,
            turnover=perf.turnover,
            hit_rate=perf.hit_rate,
            deterministic_hash=deterministic_hash,
            is_synthetic_data=True,
        )
