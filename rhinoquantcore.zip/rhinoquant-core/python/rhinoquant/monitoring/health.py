"""Health / readiness / liveness checks (section 48), machine-readable via
:class:`~rhinoquant.schemas.system.HealthCheck`.
"""
from __future__ import annotations

from typing import Callable

from rhinoquant.core.ids import now_ns
from rhinoquant.schemas.system import HealthCheck


class HealthChecker:
    def __init__(self) -> None:
        self._checks: dict[str, Callable[[], bool]] = {}

    def register(self, name: str, check_fn: Callable[[], bool]) -> None:
        self._checks[name] = check_fn

    def run(self) -> HealthCheck:
        dependencies: dict[str, str] = {}
        for name, check in self._checks.items():
            try:
                ok = bool(check())
            except Exception as exc:  # a failing health check is DOWN, not a crash
                ok = False
                dependencies[name] = f"DOWN ({exc})"
                continue
            dependencies[name] = "UP" if ok else "DOWN"
        healthy = all(v == "UP" for v in dependencies.values()) if dependencies else True
        return HealthCheck(healthy=healthy, ready=healthy, live=True, dependencies=dependencies, timestamp_ns=now_ns())
