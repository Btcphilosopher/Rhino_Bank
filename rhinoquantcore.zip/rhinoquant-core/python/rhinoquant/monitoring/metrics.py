"""Machine-readable metrics registry (section 33 / 48).

Counters, gauges and histograms, each keyed by name + sorted label tuple
so ``orders_submitted{strategy_id=market_maker}`` and
``orders_submitted{strategy_id=momentum}`` are tracked independently.
:meth:`MetricsRegistry.export` returns a plain JSON-serialisable dict —
the ``/metrics`` engine endpoint (section 7) is just this dict.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any

import numpy as np


def _key(name: str, labels: dict[str, Any]) -> tuple:
    return (name, tuple(sorted(labels.items())))


class MetricsRegistry:
    def __init__(self) -> None:
        self._counters: dict[tuple, float] = defaultdict(float)
        self._gauges: dict[tuple, float] = {}
        self._histograms: dict[tuple, list[float]] = defaultdict(list)

    def incr(self, name: str, value: float = 1.0, **labels: Any) -> None:
        self._counters[_key(name, labels)] += value

    def set_gauge(self, name: str, value: float, **labels: Any) -> None:
        self._gauges[_key(name, labels)] = value

    def observe(self, name: str, value: float, **labels: Any) -> None:
        self._histograms[_key(name, labels)].append(value)

    def export(self) -> dict[str, Any]:
        def render(key: tuple) -> dict[str, Any]:
            name, labels = key
            return {"name": name, "labels": dict(labels)}

        counters = [{**render(k), "value": v} for k, v in self._counters.items()]
        gauges = [{**render(k), "value": v} for k, v in self._gauges.items()]
        histograms = []
        for k, values in self._histograms.items():
            arr = np.asarray(values, dtype=float)
            histograms.append(
                {
                    **render(k),
                    "count": len(arr),
                    "mean": float(arr.mean()) if len(arr) else None,
                    "p50": float(np.percentile(arr, 50)) if len(arr) else None,
                    "p99": float(np.percentile(arr, 99)) if len(arr) else None,
                }
            )
        return {"counters": counters, "gauges": gauges, "histograms": histograms}
