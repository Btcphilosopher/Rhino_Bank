"""Portfolio engine (section 16).

Aggregates per (strategy, symbol) :class:`PnLAccount` accounting into the
frontend-facing :class:`~rhinoquant.schemas.portfolio.PortfolioState`:
positions, cash, gross/net exposure, leverage, and exposure broken down by
currency / instrument / venue / strategy.
"""
from __future__ import annotations

from typing import Optional

from rhinoquant.analytics.pnl import PnLAccount
from rhinoquant.core.ids import now_ns
from rhinoquant.schemas.fills import Fill
from rhinoquant.schemas.pnl import PnlSnapshot
from rhinoquant.schemas.portfolio import PortfolioState
from rhinoquant.schemas.positions import Position


class PortfolioEngine:
    def __init__(self, portfolio_id: str, starting_cash: float = 1_000_000.0, currency: str = "USD", venue: str = "SIM") -> None:
        self.portfolio_id = portfolio_id
        self.starting_cash = starting_cash
        self.currency = currency
        self.venue = venue
        self._accounts: dict[tuple[str, str], PnLAccount] = {}
        self._mark_prices: dict[str, float] = {}

    def mark_price(self, symbol: str, price: float) -> None:
        self._mark_prices[symbol] = price

    def apply_fill(self, fill: Fill) -> PnLAccount:
        key = (fill.strategy_id, fill.symbol)
        account = self._accounts.setdefault(key, PnLAccount(strategy_id=fill.strategy_id, symbol=fill.symbol))
        account.apply_fill(fill)
        return account

    def account(self, strategy_id: str, symbol: str) -> Optional[PnLAccount]:
        return self._accounts.get((strategy_id, symbol))

    def all_accounts(self) -> list[PnLAccount]:
        return list(self._accounts.values())

    def cash(self) -> float:
        return self.starting_cash + sum(a.cash_flow for a in self._accounts.values())

    def realised_pnl(self) -> float:
        return sum(a.realised_pnl for a in self._accounts.values())

    def unrealised_pnl(self) -> float:
        return sum(a.unrealised_pnl(self._mark_prices.get(a.symbol)) for a in self._accounts.values())

    def total_fees(self) -> float:
        return sum(a.fees for a in self._accounts.values())

    def total_rebates(self) -> float:
        return sum(a.rebates for a in self._accounts.values())

    # ------------------------------------------------------------------ #
    def state(self, timestamp_ns: Optional[int] = None) -> PortfolioState:
        ts = timestamp_ns if timestamp_ns is not None else now_ns()
        positions: list[Position] = []
        instrument_exposure: dict[str, float] = {}
        strategy_exposure: dict[str, float] = {}
        gross_exposure = 0.0
        net_exposure = 0.0

        for (strategy_id, symbol), account in self._accounts.items():
            mark = self._mark_prices.get(symbol)
            market_value = account.quantity * mark if mark else 0.0
            positions.append(
                Position(
                    strategy_id=strategy_id,
                    portfolio_id=self.portfolio_id,
                    symbol=symbol,
                    venue=self.venue,
                    quantity=account.quantity,
                    average_price=account.average_price,
                    realised_pnl=account.realised_pnl,
                    unrealised_pnl=account.unrealised_pnl(mark),
                    timestamp_ns=ts,
                )
            )
            instrument_exposure[symbol] = instrument_exposure.get(symbol, 0.0) + market_value
            strategy_exposure[strategy_id] = strategy_exposure.get(strategy_id, 0.0) + market_value
            gross_exposure += abs(market_value)
            net_exposure += market_value

        cash = self.cash()
        equity = cash + net_exposure
        leverage = (gross_exposure / equity) if equity > 0 else 0.0

        return PortfolioState(
            portfolio_id=self.portfolio_id,
            timestamp_ns=ts,
            positions=positions,
            cash=cash,
            gross_exposure=gross_exposure,
            net_exposure=net_exposure,
            leverage=leverage,
            currency_exposure={self.currency: net_exposure},
            instrument_exposure=instrument_exposure,
            venue_exposure={self.venue: gross_exposure},
            strategy_exposure=strategy_exposure,
        )

    def pnl_snapshot(self, timestamp_ns: Optional[int] = None) -> PnlSnapshot:
        ts = timestamp_ns if timestamp_ns is not None else now_ns()
        realised = self.realised_pnl()
        unrealised = self.unrealised_pnl()
        fees = self.total_fees()
        rebates = self.total_rebates()
        return PnlSnapshot(
            portfolio_id=self.portfolio_id,
            timestamp_ns=ts,
            realised_pnl=realised,
            unrealised_pnl=unrealised,
            fees=fees,
            rebates=rebates,
            financing=0.0,
            total_pnl=realised + unrealised - fees + rebates,
        )

    def strategy_realised_pnl(self) -> dict[str, float]:
        totals: dict[str, float] = {}
        for (strategy_id, _symbol), account in self._accounts.items():
            totals[strategy_id] = totals.get(strategy_id, 0.0) + account.realised_pnl
        return totals
