"""Transaction cost engine (section 23).

Decomposes the *realised* cost of a parent order (measured against its
arrival price) into a half-spread cost, residual slippage, fees and
rebates — all from actual recorded fills, not assumed constants. A
model-implied market-impact estimate (using the feature engine's Kyle's-
lambda-style ``price_impact``) is reported alongside for comparison, but
labelled as an estimate: separating true market impact from slippage
requires a counterfactual no-trade price this engine does not have.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class TransactionCostBreakdown:
    arrival_price: float
    average_fill_price: float
    quantity: float
    side_sign: float  # +1.0 buy, -1.0 sell
    half_spread_cost: float
    slippage: float
    market_impact_estimate: Optional[float]
    fees: float
    rebates: float
    total_cost: float
    total_cost_bps: Optional[float]


def compute_tca(
    arrival_price: float,
    arrival_spread: Optional[float],
    average_fill_price: float,
    quantity: float,
    side_sign: float,
    fees: float,
    rebates: float,
    price_impact_coefficient: Optional[float] = None,
) -> TransactionCostBreakdown:
    half_spread_cost = (arrival_spread / 2.0) * quantity if arrival_spread else 0.0
    raw_cost = (average_fill_price - arrival_price) * side_sign * quantity
    slippage = raw_cost - half_spread_cost
    market_impact_estimate = (
        price_impact_coefficient * quantity * quantity if price_impact_coefficient is not None else None
    )
    total_cost = raw_cost + fees - rebates
    total_cost_bps = (total_cost / (arrival_price * quantity) * 10_000) if arrival_price and quantity else None

    return TransactionCostBreakdown(
        arrival_price=arrival_price,
        average_fill_price=average_fill_price,
        quantity=quantity,
        side_sign=side_sign,
        half_spread_cost=half_spread_cost,
        slippage=slippage,
        market_impact_estimate=market_impact_estimate,
        fees=fees,
        rebates=rebates,
        total_cost=total_cost,
        total_cost_bps=total_cost_bps,
    )
