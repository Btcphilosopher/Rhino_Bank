"""Deterministic P&L accounting (section 32).

Average-cost position accounting: adding to a position blends the average
price; reducing or flipping realises P&L on the closed portion. Every
:class:`~rhinoquant.schemas.fills.Fill` is processed **exactly once** —
:meth:`PnLAccount.apply_fill` raises if the same ``fill_id`` is replayed,
which is the reconciliation check section 32 calls for.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from rhinoquant.core.errors import RhinoQuantError
from rhinoquant.schemas.fills import Fill
from rhinoquant.schemas.orders import Side


class DuplicateFillError(RhinoQuantError):
    error_code = "DUPLICATE_FILL"
    component = "pnl"


@dataclass
class PnLAccount:
    """Cash + average-cost position accounting for one (strategy, symbol)
    pair. Cash flow convention: buying decreases cash by price*quantity
    (plus fees, less rebates); selling increases it symmetrically.
    """

    strategy_id: str
    symbol: str
    quantity: float = 0.0
    average_price: float = 0.0
    realised_pnl: float = 0.0
    fees: float = 0.0
    rebates: float = 0.0
    cash_flow: float = 0.0
    realisations: list = field(default_factory=list)  # realised P&L booked per closing fill (section 24 hit-rate/profit-factor input)
    _processed_fill_ids: set = field(default_factory=set)

    def apply_fill(self, fill: Fill) -> None:
        if fill.fill_id in self._processed_fill_ids:
            raise DuplicateFillError(f"fill {fill.fill_id} already processed for {self.strategy_id}/{self.symbol}")
        self._processed_fill_ids.add(fill.fill_id)

        signed_qty = fill.quantity if fill.side == Side.BUY else -fill.quantity
        self.cash_flow += -signed_qty * fill.price - fill.fee + fill.rebate
        self.fees += fill.fee
        self.rebates += fill.rebate

        old_qty = self.quantity
        new_qty = old_qty + signed_qty

        if old_qty == 0:
            self.average_price = fill.price
            self.quantity = new_qty
            return

        same_direction = (old_qty > 0) == (signed_qty > 0)
        if same_direction:
            self.average_price = (old_qty * self.average_price + signed_qty * fill.price) / new_qty
            self.quantity = new_qty
            return

        # reducing or flipping
        closing_qty = min(abs(signed_qty), abs(old_qty))
        direction = 1.0 if old_qty > 0 else -1.0
        realised_delta = closing_qty * (fill.price - self.average_price) * direction
        self.realised_pnl += realised_delta
        self.realisations.append(realised_delta)

        self.quantity = new_qty
        if abs(signed_qty) > abs(old_qty):
            # flipped through zero: remainder opens a fresh position at the fill price
            self.average_price = fill.price
        elif new_qty == 0:
            self.average_price = 0.0
        # else: partially closed, average_price of the remaining same-direction position is unchanged

    def unrealised_pnl(self, mark_price: float | None) -> float:
        if mark_price is None or self.quantity == 0:
            return 0.0
        return self.quantity * (mark_price - self.average_price)

    def total_pnl(self, mark_price: float | None) -> float:
        return self.realised_pnl + self.unrealised_pnl(mark_price) - self.fees + self.rebates
