"""Latency engine (section 25).

Records a timestamp at every named stage of the pipeline

    market-data arrival -> book update -> feature calculation ->
    strategy decision -> risk check -> order creation -> submission ->
    acknowledgement -> fill

and reports p50/p90/p95/p99/p99.9/max per consecutive stage-to-stage gap
plus overall end-to-end, all computed from timestamps actually recorded
during this run.

These are software/simulation timings measured on whatever host ran the
engine — never real network or exchange latency, and the resulting
:class:`~rhinoquant.schemas.latency.LatencyReport` says so explicitly
(section 25: "Never fabricate latency. Clearly distinguish: software
benchmark, simulation latency, network latency, exchange latency,
real-world measured latency.").
"""
from __future__ import annotations

from collections import defaultdict
from typing import Optional

import numpy as np

from rhinoquant.core.ids import now_ns
from rhinoquant.schemas.latency import LatencyReport, StageLatencyStats

STAGE_SEQUENCE = [
    "market_data_arrival",
    "book_update",
    "feature_calculation",
    "strategy_decision",
    "risk_check",
    "order_creation",
    "submission",
    "acknowledgement",
    "fill",
]


class LatencyEngine:
    def __init__(self) -> None:
        self._samples: dict[str, list[float]] = defaultdict(list)

    def record(self, stage: str, latency_ns: float) -> None:
        if latency_ns < 0:
            return  # a negative gap means the caller's clock/ordering is broken; drop rather than fabricate
        self._samples[stage].append(latency_ns)

    def record_pipeline(self, stage_timestamps_ns: dict[str, int]) -> None:
        """Given ``{stage_name: timestamp_ns}`` for one event's full
        pipeline (any subset of :data:`STAGE_SEQUENCE`, in order), records
        every consecutive gap present plus ``end_to_end``.
        """
        present = [s for s in STAGE_SEQUENCE if s in stage_timestamps_ns]
        for a, b in zip(present, present[1:]):
            gap = stage_timestamps_ns[b] - stage_timestamps_ns[a]
            self.record(f"{a}_to_{b}", gap)
        if len(present) >= 2:
            self.record("end_to_end", stage_timestamps_ns[present[-1]] - stage_timestamps_ns[present[0]])

    def stats_for(self, stage: str) -> Optional[StageLatencyStats]:
        samples = self._samples.get(stage)
        if not samples:
            return None
        arr = np.asarray(samples, dtype=float)
        return StageLatencyStats(
            stage=stage,
            count=len(arr),
            p50_ns=float(np.percentile(arr, 50)),
            p90_ns=float(np.percentile(arr, 90)),
            p95_ns=float(np.percentile(arr, 95)),
            p99_ns=float(np.percentile(arr, 99)),
            p999_ns=float(np.percentile(arr, 99.9)),
            max_ns=float(arr.max()),
        )

    def report(self, run_id: str) -> LatencyReport:
        stages = [s for s in (self.stats_for(name) for name in self._samples) if s is not None]
        stages.sort(key=lambda s: s.stage)
        return LatencyReport(run_id=run_id, timestamp_ns=now_ns(), stages=stages)
