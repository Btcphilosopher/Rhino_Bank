"""Performance analytics (section 24).

Every figure here is computed from data the caller actually recorded
during a run (an equity curve, realised-P&L events, order counters) —
nothing is a placeholder constant. Where a metric's definition depends on
a sampling-frequency choice the caller must make (Sharpe/Sortino
annualisation), the function takes an explicit ``periods_per_year`` rather
than silently assuming daily bars, since this engine's native data is
tick-level synthetic events, not daily OHLC.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import numpy as np


@dataclass
class OrderCounters:
    submitted: int = 0
    accepted: int = 0
    rejected: int = 0
    filled: int = 0  # orders that reached terminal FILL
    cancelled: int = 0
    replaced: int = 0


@dataclass
class PerformanceReport:
    total_return: float
    gross_pnl: float
    net_pnl: float
    sharpe: Optional[float]
    sortino: Optional[float]
    max_drawdown: float
    volatility: Optional[float]
    turnover: float
    hit_rate: Optional[float]
    average_trade: Optional[float]
    profit_factor: Optional[float]
    tail_loss_95: Optional[float]
    fill_ratio: Optional[float]
    cancel_ratio: Optional[float]
    quote_to_trade_ratio: Optional[float]
    orders_per_sec: Optional[float]
    fills_per_sec: Optional[float]
    messages_per_sec: Optional[float]


def _returns(equity_curve: list[float]) -> np.ndarray:
    arr = np.asarray(equity_curve, dtype=float)
    if len(arr) < 2:
        return np.array([])
    prev = arr[:-1]
    # guard against a zero/negative equity value (would make % return undefined)
    safe = np.where(prev == 0, np.nan, prev)
    return (arr[1:] - prev) / safe


def max_drawdown(equity_curve: list[float]) -> float:
    if not equity_curve:
        return 0.0
    arr = np.asarray(equity_curve, dtype=float)
    running_max = np.maximum.accumulate(arr)
    drawdowns = np.divide(
        arr - running_max, running_max, out=np.zeros_like(arr), where=running_max != 0
    )
    return float(drawdowns.min())


def sharpe_ratio(returns: np.ndarray, periods_per_year: Optional[float] = None) -> Optional[float]:
    if returns.size < 2:
        return None
    returns = returns[~np.isnan(returns)]
    if returns.size < 2 or returns.std(ddof=1) == 0:
        return None
    ratio = returns.mean() / returns.std(ddof=1)
    if periods_per_year:
        ratio *= math.sqrt(periods_per_year)
    return float(ratio)


def sortino_ratio(returns: np.ndarray, periods_per_year: Optional[float] = None) -> Optional[float]:
    if returns.size < 2:
        return None
    returns = returns[~np.isnan(returns)]
    downside = returns[returns < 0]
    if downside.size < 2 or downside.std(ddof=1) == 0:
        return None
    ratio = returns.mean() / downside.std(ddof=1)
    if periods_per_year:
        ratio *= math.sqrt(periods_per_year)
    return float(ratio)


def compute_performance(
    equity_curve: list[float],
    realisations: list[float],
    gross_pnl: float,
    net_pnl: float,
    starting_equity: float,
    total_traded_notional: float,
    order_counters: OrderCounters,
    duration_seconds: float,
    periods_per_year: Optional[float] = None,
) -> PerformanceReport:
    returns = _returns(equity_curve)
    total_return = (equity_curve[-1] - starting_equity) / starting_equity if equity_curve and starting_equity else 0.0

    wins = [r for r in realisations if r > 0]
    losses = [r for r in realisations if r < 0]
    hit_rate = len(wins) / len(realisations) if realisations else None
    average_trade = float(np.mean(realisations)) if realisations else None
    profit_factor = (sum(wins) / abs(sum(losses))) if losses else (float("inf") if wins else None)

    tail_loss_95 = float(np.percentile(returns[~np.isnan(returns)], 5)) if returns.size >= 5 else None

    fill_ratio = order_counters.filled / order_counters.accepted if order_counters.accepted else None
    cancel_ratio = order_counters.cancelled / order_counters.submitted if order_counters.submitted else None
    quote_to_trade = order_counters.submitted / order_counters.filled if order_counters.filled else None

    orders_per_sec = order_counters.submitted / duration_seconds if duration_seconds > 0 else None
    fills_per_sec = order_counters.filled / duration_seconds if duration_seconds > 0 else None
    messages_per_sec = (
        (order_counters.submitted + order_counters.accepted + order_counters.filled + order_counters.cancelled)
        / duration_seconds
        if duration_seconds > 0
        else None
    )

    return PerformanceReport(
        total_return=total_return,
        gross_pnl=gross_pnl,
        net_pnl=net_pnl,
        sharpe=sharpe_ratio(returns, periods_per_year),
        sortino=sortino_ratio(returns, periods_per_year),
        max_drawdown=max_drawdown(equity_curve),
        volatility=float(returns[~np.isnan(returns)].std(ddof=1)) if returns.size >= 2 else None,
        turnover=(total_traded_notional / starting_equity) if starting_equity else 0.0,
        hit_rate=hit_rate,
        average_trade=average_trade,
        profit_factor=profit_factor,
        tail_loss_95=tail_loss_95,
        fill_ratio=fill_ratio,
        cancel_ratio=cancel_ratio,
        quote_to_trade_ratio=quote_to_trade,
        orders_per_sec=orders_per_sec,
        fills_per_sec=fills_per_sec,
        messages_per_sec=messages_per_sec,
    )


def markout(fill_price: float, fill_side_sign: float, future_mid_prices: list[float]) -> list[float]:
    """Adverse-selection markout: signed P&L per unit if marked to each of
    ``future_mid_prices`` (e.g. the mid 1, 5, 20 events after the fill).
    Positive means the market moved in the filled side's favour after the
    trade; consistently negative markouts are the standard sign of adverse
    selection on resting (maker) orders.
    """
    return [(m - fill_price) * fill_side_sign for m in future_mid_prices]
