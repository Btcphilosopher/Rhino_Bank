"""Command-line engine (section 51).

    python -m rhinoquant simulate
    python -m rhinoquant backtest
    python -m rhinoquant benchmark
    python -m rhinoquant validate
    python -m rhinoquant health

These are engine commands only — no GUI, no browser, nothing that talks
to the (separately maintained) frontend. Every command also accepts
``--json`` to print its machine-readable result instead of the
human-readable report, for scripting/CI use.
"""
from __future__ import annotations

import argparse
import json
import sys
import time

from rhinoquant.config import Environment, EngineConfig
from rhinoquant.engine import ENGINE_VERSION, RhinoQuantEngine, SimulationOptions
from rhinoquant.marketdata.synthetic import MarketRegime, RegimeSegment
from rhinoquant.orderbook.book import LimitOrderBook
from rhinoquant.orderbook import rust_backend_available


def _load_config(args: argparse.Namespace) -> EngineConfig:
    if getattr(args, "config", None):
        return EngineConfig.load(args.config)
    return EngineConfig.default(environment=Environment.SIMULATION)


def _demo_regimes(n_events: int) -> list[RegimeSegment]:
    """A short, varied regime schedule so a default run exercises more
    than one market condition (used by both ``simulate`` and
    ``backtest`` unless the caller supplies their own)."""
    quarter = max(1, n_events // 4)
    remainder = n_events - quarter * 3
    return [
        RegimeSegment(MarketRegime.MEAN_REVERTING, quarter),
        RegimeSegment(MarketRegime.TREND_UP, quarter),
        RegimeSegment(MarketRegime.HIGH_VOLATILITY, quarter),
        RegimeSegment(MarketRegime.LOW_LIQUIDITY, remainder),
    ]


def _print_simulation_report(config: EngineConfig, bt, report) -> None:
    result = report.result
    portfolio = report.portfolio_state
    risk = report.risk_state
    latency = report.latency_report
    strategy_names = ", ".join(sorted({s.strategy_id for s in bt.strategies})) or "none"
    inventory = sum(p.quantity for p in portfolio.positions)
    symbol = result.symbols[0] if result.symbols else "?"
    book = bt.books.get(symbol)

    def stage(name: str):
        return next((s for s in latency.stages if s.stage == name), None)

    md = stage("market_data_arrival_to_book_update")
    strat = stage("feature_calculation_to_strategy_decision")
    risk_stage = stage("strategy_decision_to_risk_check")
    e2e = stage("end_to_end")

    print("RHINOQUANT CORE ENGINE")
    print("=" * 22)
    print()
    print(f"Environment: {config.environment.value.upper()}")
    print()
    print("Market:")
    print(f"Instrument: {symbol}")
    print(f"Best Bid: {book.best_bid() if book else 'n/a'}")
    print(f"Best Ask: {book.best_ask() if book else 'n/a'}")
    print()
    print("Strategy:")
    print(f"Active: {strategy_names}")
    print()
    print("Orders:")
    print(f"Submitted: {result.orders_submitted}")
    print(f"Accepted: {result.orders_submitted - result.orders_rejected}")
    print(f"Rejected: {result.orders_rejected}")
    print(f"Filled: {result.orders_filled}")
    print()
    print("Risk:")
    print(f"Status: {risk.status}")
    print()
    print("Portfolio:")
    print(f"Inventory: {inventory:+.0f}")
    print()
    print("Performance:")
    print(f"Gross P&L: {result.gross_pnl:.2f}")
    print(f"Fees: {result.fees:.2f}")
    print(f"Net P&L: {result.net_pnl:.2f}")
    print(f"Turnover: {result.turnover:.4f}")
    print()
    print("Latency (software/simulation timings measured on this host — NOT network/exchange latency):")
    print(f"Market Data (arrival->book) p50: {md.p50_ns:.0f}ns" if md else "Market Data p50: n/a")
    print(f"Strategy Decision p50: {strat.p50_ns:.0f}ns" if strat else "Strategy p50: n/a")
    print(f"Risk Check p50: {risk_stage.p50_ns:.0f}ns" if risk_stage else "Risk p50: n/a")
    print(f"End-to-End p99: {e2e.p99_ns:.0f}ns" if e2e else "End-to-End p99: n/a")
    print()
    print("SYNTHETIC SIMULATION — all figures generated from synthetic, seeded market data.")
    print(f"deterministic_hash: {result.deterministic_hash}")


def cmd_simulate(args: argparse.Namespace) -> int:
    config = _load_config(args)
    engine = RhinoQuantEngine(config)
    options = SimulationOptions(symbol=args.symbol, n_events=args.events, regimes=_demo_regimes(args.events))
    bt, report = engine.run_simulation(options)

    if args.json:
        print(json.dumps({"result": report.result.to_json_dict(), "portfolio": report.portfolio_state.to_json_dict()}, indent=2))
    else:
        _print_simulation_report(config, bt, report)
    return 0


def cmd_backtest(args: argparse.Namespace) -> int:
    # Same causal, event-driven engine as `simulate` (section 22); the
    # distinction is purely the intent/labelling of the run, and — once a
    # real historical MarketDataProvider is wired in — which provider
    # feeds it. There is no historical data source in this build, so
    # `backtest` replays the same synthetic, seeded dataset as `simulate`.
    return cmd_simulate(args)


def cmd_benchmark(args: argparse.Namespace) -> int:
    from rhinoquant.orderbook import get_order_book

    n = args.iterations

    def bench_python_book() -> float:
        book = LimitOrderBook("BENCH")
        start = time.perf_counter()
        price = 100.0
        for i in range(n):
            price += (0.01 if i % 2 == 0 else -0.01)
            book.update_bid(round(price - 0.01, 2), 100 + (i % 50))
            book.update_ask(round(price + 0.01, 2), 100 + (i % 50))
            book.update_bid(round(price - 0.02, 2), 0)  # evict stale level, keep book bounded
            book.update_ask(round(price + 0.02, 2), 0)
        elapsed = time.perf_counter() - start
        return n / elapsed

    results = {"python_orderbook_updates_per_sec": bench_python_book(), "rust_backend_available": rust_backend_available()}

    if rust_backend_available():
        rust_book = get_order_book("BENCH", prefer_rust=True)
        start = time.perf_counter()
        price = 100.0
        for i in range(n):
            price += (0.01 if i % 2 == 0 else -0.01)
            rust_book.update_bid(round(price - 0.01, 2), 100 + (i % 50))
            rust_book.update_ask(round(price + 0.01, 2), 100 + (i % 50))
            rust_book.update_bid(round(price - 0.02, 2), 0)
            rust_book.update_ask(round(price + 0.02, 2), 0)
        elapsed = time.perf_counter() - start
        results["rust_orderbook_updates_per_sec"] = n / elapsed

    results["note"] = "measured on this host, this run only — not a portable HFT performance claim (section 44/53)"
    print(json.dumps(results, indent=2))
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    from rhinoquant.risk.engine import RiskContext, RiskEngine
    from rhinoquant.risk.kill_switch import KillSwitchKind
    from rhinoquant.strategies.base import OrderIntent
    from rhinoquant.schemas.orders import Side

    checks: list[tuple[str, bool, str]] = []

    # 1. config loads and round-trips
    try:
        cfg = _load_config(args)
        EngineConfig.model_validate(cfg.to_dict())
        checks.append(("config_loads", True, ""))
    except Exception as exc:
        checks.append(("config_loads", False, str(exc)))
        cfg = EngineConfig.default()

    # 2. risk engine rejects an oversized order
    try:
        risk_engine = RiskEngine(cfg.risk)
        intent = OrderIntent("val", "val", "RHINO", Side.BUY, quantity=cfg.risk.max_order_quantity * 100)
        decision = risk_engine.evaluate(intent, RiskContext())
        checks.append(("risk_rejects_oversized_order", not decision.accepted, str(decision.reason)))
    except Exception as exc:
        checks.append(("risk_rejects_oversized_order", False, str(exc)))

    # 3. kill switch blocks new orders
    try:
        risk_engine.kill_switches.activate(KillSwitchKind.GLOBAL, "GLOBAL", "validate smoke test")
        intent2 = OrderIntent("val", "val", "RHINO", Side.BUY, quantity=1)
        decision2 = risk_engine.evaluate(intent2, RiskContext())
        checks.append(("kill_switch_blocks_new_orders", not decision2.accepted, str(decision2.reason)))
    except Exception as exc:
        checks.append(("kill_switch_blocks_new_orders", False, str(exc)))

    # 4. deterministic backtest: same seed => same hash
    try:
        engine_a = RhinoQuantEngine(cfg)
        _, report_a = engine_a.run_simulation(SimulationOptions(symbol="RHINO", n_events=500))
        engine_b = RhinoQuantEngine(cfg)
        _, report_b = engine_b.run_simulation(SimulationOptions(symbol="RHINO", n_events=500))
        deterministic = report_a.result.deterministic_hash == report_b.result.deterministic_hash
        checks.append(("deterministic_replay_same_seed", deterministic, report_a.result.deterministic_hash))
    except Exception as exc:
        checks.append(("deterministic_replay_same_seed", False, str(exc)))

    # 5. API schemas serialise cleanly
    try:
        from rhinoquant.api.service import RhinoQuantAPI

        api = RhinoQuantAPI(engine_a, run=engine_a.last_backtest_engine)
        for method in ("system_status", "system_health", "portfolio", "pnl", "risk", "backtests", "latency", "metrics"):
            getattr(api, method)()
        checks.append(("api_schemas_serialise", True, ""))
    except Exception as exc:
        checks.append(("api_schemas_serialise", False, str(exc)))

    passed = sum(1 for _, ok, _ in checks if ok)
    for name, ok, detail in checks:
        print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))
    print(f"\n{passed}/{len(checks)} checks passed")
    return 0 if passed == len(checks) else 1


def cmd_health(args: argparse.Namespace) -> int:
    config = _load_config(args)
    engine = RhinoQuantEngine(config)
    status = engine.system_status()
    health = engine.health.run()
    if args.json:
        print(json.dumps({"status": status.to_json_dict(), "health": health.to_json_dict()}, indent=2))
    else:
        print(f"engine_version: {ENGINE_VERSION}")
        print(f"status: {status.status}")
        print(f"environment: {status.environment}")
        print(f"healthy: {health.healthy}")
        for name, state in health.dependencies.items():
            print(f"  - {name}: {state}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="rhinoquant", description="RhinoQuant Core Engine (headless)")
    parser.add_argument("--config", help="path to a YAML EngineConfig file")
    parser.add_argument("--json", action="store_true", help="print machine-readable JSON instead of a text report")
    sub = parser.add_subparsers(dest="command", required=True)

    p_sim = sub.add_parser("simulate", help="run the full synthetic simulation workflow (section 52)")
    p_sim.add_argument("--symbol", default="RHINO")
    p_sim.add_argument("--events", type=int, default=100_000)
    p_sim.set_defaults(func=cmd_simulate)

    p_bt = sub.add_parser("backtest", help="event-driven backtest replay (section 22)")
    p_bt.add_argument("--symbol", default="RHINO")
    p_bt.add_argument("--events", type=int, default=100_000)
    p_bt.set_defaults(func=cmd_backtest)

    p_bench = sub.add_parser("benchmark", help="order book update throughput, Python vs Rust (section 44)")
    p_bench.add_argument("--iterations", type=int, default=50_000)
    p_bench.set_defaults(func=cmd_benchmark)

    p_val = sub.add_parser("validate", help="run engine self-checks (config, risk, kill switch, determinism, API)")
    p_val.set_defaults(func=cmd_validate)

    p_health = sub.add_parser("health", help="print engine health/readiness/liveness")
    p_health.set_defaults(func=cmd_health)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
