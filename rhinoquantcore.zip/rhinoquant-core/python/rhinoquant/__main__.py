"""Entry point for ``python -m rhinoquant`` (section 51)."""
from __future__ import annotations

import sys

from rhinoquant.cli import main

if __name__ == "__main__":
    sys.exit(main())
