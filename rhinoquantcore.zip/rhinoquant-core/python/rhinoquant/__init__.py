"""RhinoQuant Core: a headless quantitative research, backtesting,
simulation and paper-trading engine.

See ``python -m rhinoquant --help`` for the command-line entry point, and
``rhinoquant.api.RhinoQuantAPI`` for the programmatic frontend contract.
"""
from __future__ import annotations

__version__ = "0.1.0"

from rhinoquant.config import EngineConfig
from rhinoquant.engine import ENGINE_VERSION, RhinoQuantEngine, SimulationOptions

__all__ = ["__version__", "EngineConfig", "ENGINE_VERSION", "RhinoQuantEngine", "SimulationOptions"]
