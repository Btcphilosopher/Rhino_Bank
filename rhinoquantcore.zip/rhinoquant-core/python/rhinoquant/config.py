"""Typed configuration engine (section 35) with environment separation
(section 36).

Risk limits, execution mode and latency parameters are never hard-coded
inside strategies: they are loaded here from YAML and injected into the
engine. Production requires an explicit ``allow_live`` safeguard so a
research configuration can never accidentally reach live execution.
"""
from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Any, Optional

import yaml
from pydantic import BaseModel, Field, model_validator

from rhinoquant.core.errors import ConfigurationError


class Environment(str, Enum):
    DEVELOPMENT = "development"
    RESEARCH = "research"
    BACKTEST = "backtest"
    SIMULATION = "simulation"
    PAPER = "paper"
    PRODUCTION = "production"


class ExecutionMode(str, Enum):
    SIMULATOR = "simulator"
    PAPER = "paper"
    LIVE = "live"


class RiskConfig(BaseModel):
    max_position: float = 1000
    max_order_quantity: float = 100
    max_notional: float = 100_000
    max_leverage: float = 5.0
    max_loss: float = 50_000
    max_daily_loss: float = 25_000
    max_strategy_loss: float = 10_000
    max_venue_exposure: float = 500_000
    max_order_rate_per_sec: float = 50
    max_cancel_rate_per_sec: float = 100
    price_collar_bps: float = 200
    stale_market_ms: float = 5000


class ExecutionConfig(BaseModel):
    mode: ExecutionMode = ExecutionMode.SIMULATOR
    allow_live: bool = False

    @model_validator(mode="after")
    def _guard_live(self) -> "ExecutionConfig":
        if self.mode == ExecutionMode.LIVE and not self.allow_live:
            raise ValueError(
                "execution.mode=live requires execution.allow_live=true; "
                "refusing to silently enable live execution"
            )
        return self


class LatencyConfig(BaseModel):
    market_data_us: float = 50
    strategy_us: float = 20
    risk_us: float = 10
    order_submit_us: float = 30
    exchange_ack_us: float = 100
    cancel_us: float = 30


class StorageConfig(BaseModel):
    backend: str = "parquet"
    root_path: str = "./data"


class EngineConfig(BaseModel):
    """Root typed configuration object."""

    environment: Environment = Environment.RESEARCH
    risk: RiskConfig = Field(default_factory=RiskConfig)
    execution: ExecutionConfig = Field(default_factory=ExecutionConfig)
    latency: LatencyConfig = Field(default_factory=LatencyConfig)
    storage: StorageConfig = Field(default_factory=StorageConfig)
    seed: int = 42
    symbols: list[str] = Field(default_factory=lambda: ["RHINO"])

    @model_validator(mode="after")
    def _guard_production(self) -> "EngineConfig":
        if self.environment == Environment.PRODUCTION:
            if self.execution.mode != ExecutionMode.LIVE:
                raise ValueError(
                    "environment=production requires execution.mode=live "
                    "(a production environment must not run in simulation)"
                )
            if not self.execution.allow_live:
                raise ValueError(
                    "environment=production requires execution.allow_live=true"
                )
        else:
            if self.execution.mode == ExecutionMode.LIVE:
                raise ValueError(
                    f"execution.mode=live is not permitted outside environment="
                    f"production (current environment={self.environment.value}); "
                    "this prevents an accidental research configuration from "
                    "reaching live execution"
                )
        return self

    @classmethod
    def load(cls, path: str | Path) -> "EngineConfig":
        p = Path(path)
        if not p.exists():
            raise ConfigurationError(f"config file not found: {p}")
        try:
            raw = yaml.safe_load(p.read_text()) or {}
        except yaml.YAMLError as exc:
            raise ConfigurationError(f"invalid YAML in {p}: {exc}") from exc
        try:
            return cls.model_validate(raw)
        except Exception as exc:  # pydantic ValidationError
            raise ConfigurationError(f"invalid configuration in {p}: {exc}") from exc

    @classmethod
    def default(cls, environment: Environment = Environment.SIMULATION) -> "EngineConfig":
        return cls(environment=environment)

    def to_dict(self) -> dict[str, Any]:
        return self.model_dump(mode="json")
