"""Synthetic market generator (section 31).

Generates a fully labelled ``SYNTHETIC`` stream of quotes, trades and
order-book updates, with configurable volatility regimes, liquidity
regimes, trend / mean-reverting regimes, and occasional shocks. This is
used to exercise the rest of the engine (order book, features, strategy,
risk, execution, backtest) end-to-end without any real market connection.

Nothing produced here may ever be presented as real market data: every
event and every downstream schema derived from it must carry
``is_synthetic=True`` / a ``SYNTHETIC`` label (section 53).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Iterator, Optional

import numpy as np

from rhinoquant.core.events import Event, EventType
from rhinoquant.marketdata.provider import MarketDataProvider

SYNTHETIC_LABEL = "SYNTHETIC"


class MarketRegime(str, Enum):
    TREND_UP = "TREND_UP"
    TREND_DOWN = "TREND_DOWN"
    MEAN_REVERTING = "MEAN_REVERTING"
    HIGH_VOLATILITY = "HIGH_VOLATILITY"
    LOW_VOLATILITY = "LOW_VOLATILITY"
    LOW_LIQUIDITY = "LOW_LIQUIDITY"
    SHOCK = "SHOCK"


@dataclass
class RegimeSegment:
    regime: MarketRegime
    n_events: int


@dataclass
class SyntheticMarketConfig:
    symbol: str = "RHINO"
    venue: str = "SIM"
    seed: int = 42
    starting_price: float = 100.25
    tick_size: float = 0.01
    base_spread_ticks: int = 2
    base_quantity: float = 300.0
    mean_arrival_ns: int = 250_000  # ~250 microseconds between events
    n_events: int = 20_000
    depth_levels: int = 3
    regimes: list[RegimeSegment] = field(default_factory=list)


_REGIME_PARAMS: dict[MarketRegime, dict[str, float]] = {
    MarketRegime.TREND_UP: {"drift": 0.15, "vol": 1.0, "liquidity": 1.0, "shock_prob": 0.0},
    MarketRegime.TREND_DOWN: {"drift": -0.15, "vol": 1.0, "liquidity": 1.0, "shock_prob": 0.0},
    MarketRegime.MEAN_REVERTING: {"drift": 0.0, "vol": 0.6, "liquidity": 1.0, "shock_prob": 0.0, "mean_reversion": 0.02},
    MarketRegime.HIGH_VOLATILITY: {"drift": 0.0, "vol": 2.5, "liquidity": 0.8, "shock_prob": 0.0},
    MarketRegime.LOW_VOLATILITY: {"drift": 0.0, "vol": 0.3, "liquidity": 1.2, "shock_prob": 0.0},
    MarketRegime.LOW_LIQUIDITY: {"drift": 0.0, "vol": 1.0, "liquidity": 0.35, "shock_prob": 0.0},
    MarketRegime.SHOCK: {"drift": 0.0, "vol": 1.0, "liquidity": 1.0, "shock_prob": 0.02, "shock_size": 25.0},
}


class SyntheticMarketGenerator(MarketDataProvider):
    """Deterministic (seeded) synthetic order-flow generator.

    Produces alternating QUOTE (top-of-book + depth) and TRADE events over
    a configurable sequence of market regimes. Fully reproducible given the
    same seed and configuration (section 42).
    """

    name = "synthetic"

    def __init__(self, config: Optional[SyntheticMarketConfig] = None) -> None:
        self.config = config or SyntheticMarketConfig()
        if not self.config.regimes:
            self.config.regimes = [RegimeSegment(MarketRegime.MEAN_REVERTING, self.config.n_events)]
        self._rng = np.random.default_rng(self.config.seed)
        self._mid = self.config.starting_price
        self._t_ns = 0
        self._reference_price = self.config.starting_price

    def _regime_stream(self) -> Iterator[MarketRegime]:
        for segment in self.config.regimes:
            for _ in range(segment.n_events):
                yield segment.regime

    def events(self) -> Iterator[Event]:
        cfg = self.config
        rng = self._rng
        tick = cfg.tick_size

        for regime in self._regime_stream():
            params = _REGIME_PARAMS[regime]
            drift = params["drift"] * tick
            vol = params["vol"] * tick
            liquidity = params["liquidity"]

            # advance simulated clock by a random inter-arrival time
            self._t_ns += int(rng.exponential(cfg.mean_arrival_ns))

            step = rng.normal(loc=drift, scale=vol)
            if "mean_reversion" in params:
                step += params["mean_reversion"] * (self._reference_price - self._mid)
            if params.get("shock_prob", 0.0) and rng.random() < params["shock_prob"]:
                step += rng.choice([-1.0, 1.0]) * params.get("shock_size", 10.0) * tick

            self._mid = max(tick, self._mid + step)
            self._mid = round(self._mid / tick) * tick

            spread_ticks = max(1, int(round(cfg.base_spread_ticks / max(liquidity, 1e-6))))
            half_spread = (spread_ticks * tick) / 2.0
            best_bid = round((self._mid - half_spread) / tick) * tick
            best_ask = round((self._mid + half_spread) / tick) * tick
            if best_ask <= best_bid:
                best_ask = best_bid + tick

            qty_scale = max(liquidity, 0.1)
            bid_levels = []
            ask_levels = []
            for lvl in range(cfg.depth_levels):
                bid_levels.append(
                    (
                        round(best_bid - lvl * tick, 10),
                        max(1.0, cfg.base_quantity * qty_scale * rng.uniform(0.5, 1.5) * (1.0 - 0.15 * lvl)),
                    )
                )
                ask_levels.append(
                    (
                        round(best_ask + lvl * tick, 10),
                        max(1.0, cfg.base_quantity * qty_scale * rng.uniform(0.5, 1.5) * (1.0 - 0.15 * lvl)),
                    )
                )

            yield Event(
                event_type=EventType.QUOTE,
                symbol=cfg.symbol,
                venue=cfg.venue,
                timestamp_ns=self._t_ns,
                exchange_timestamp_ns=self._t_ns,
                receive_timestamp_ns=self._t_ns,
                payload={
                    "bid_price": bid_levels[0][0],
                    "bid_quantity": bid_levels[0][1],
                    "ask_price": ask_levels[0][0],
                    "ask_quantity": ask_levels[0][1],
                    "bid_levels": bid_levels,
                    "ask_levels": ask_levels,
                    "regime": regime.value,
                    "label": SYNTHETIC_LABEL,
                },
            )

            # roughly one trade for every ~3 quote updates, crossing the
            # spread on the side implied by the most recent price move
            if rng.random() < 0.35:
                aggressor_side = "BUY" if step >= 0 else "SELL"
                trade_price = best_ask if aggressor_side == "BUY" else best_bid
                trade_qty = max(1.0, cfg.base_quantity * qty_scale * rng.uniform(0.05, 0.6))
                yield Event(
                    event_type=EventType.TRADE,
                    symbol=cfg.symbol,
                    venue=cfg.venue,
                    timestamp_ns=self._t_ns,
                    exchange_timestamp_ns=self._t_ns,
                    receive_timestamp_ns=self._t_ns,
                    payload={
                        "price": trade_price,
                        "quantity": trade_qty,
                        "aggressor_side": aggressor_side,
                        "label": SYNTHETIC_LABEL,
                    },
                )
