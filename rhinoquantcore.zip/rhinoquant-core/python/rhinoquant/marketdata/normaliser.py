"""Raw market data -> canonical event normalisation (section 9).

    raw market data -> parser -> normaliser -> canonical event -> order book

This module is the "normaliser" stage: it takes loosely-typed raw messages
(as a real feed handler or the Rust parser would hand them to Python) and
turns them into canonical, validated :class:`Event` objects. It rejects
malformed input (negative price/quantity, missing fields) rather than
silently passing it downstream into the order book.
"""
from __future__ import annotations

from typing import Any

from rhinoquant.core.errors import MarketDataError
from rhinoquant.core.events import Event, EventType
from rhinoquant.core.ids import now_ns


_RAW_TYPE_TO_EVENT_TYPE = {
    "trade": EventType.TRADE,
    "quote": EventType.QUOTE,
    "book_update": EventType.BOOK_UPDATE,
    "book_snapshot": EventType.BOOK_SNAPSHOT,
    "auction": EventType.AUCTION,
    "instrument": EventType.INSTRUMENT,
}


class Normaliser:
    """Stateless normaliser from raw dict messages to canonical events."""

    def normalise(self, raw: dict[str, Any]) -> Event:
        raw_type = raw.get("type")
        event_type = _RAW_TYPE_TO_EVENT_TYPE.get(raw_type)
        if event_type is None:
            raise MarketDataError(f"unknown raw message type: {raw_type!r}", details={"raw": raw})

        symbol = raw.get("symbol")
        if not symbol:
            raise MarketDataError("raw message missing 'symbol'", details={"raw": raw})

        self._validate_numeric_fields(raw, event_type)

        payload = {k: v for k, v in raw.items() if k not in ("type", "symbol", "venue", "exchange_timestamp_ns")}
        return Event(
            event_type=event_type,
            symbol=symbol,
            venue=raw.get("venue", "SIM"),
            payload=payload,
            exchange_timestamp_ns=raw.get("exchange_timestamp_ns"),
            receive_timestamp_ns=now_ns(),
        )

    @staticmethod
    def _validate_numeric_fields(raw: dict[str, Any], event_type: EventType) -> None:
        for field in ("price", "bid_price", "ask_price"):
            if field in raw and raw[field] is not None and raw[field] <= 0:
                raise MarketDataError(
                    f"invalid non-positive price in field '{field}'", details={"raw": raw}
                )
        for field in ("quantity", "bid_quantity", "ask_quantity"):
            if field in raw and raw[field] is not None and raw[field] < 0:
                raise MarketDataError(
                    f"invalid negative quantity in field '{field}'", details={"raw": raw}
                )
        if event_type in (EventType.QUOTE, EventType.BOOK_UPDATE):
            bid = raw.get("bid_price")
            ask = raw.get("ask_price")
            if bid is not None and ask is not None and bid > ask:
                raise MarketDataError(
                    "crossed quote: bid_price > ask_price", details={"raw": raw}
                )
