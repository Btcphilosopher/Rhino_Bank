"""``MarketDataProvider`` plugin interface (section 49).

Concrete providers (synthetic generator today; a real feed adapter in the
future) implement :meth:`events` as a generator of canonical
:class:`~rhinoquant.core.events.Event` objects. The rest of the engine only
depends on this interface, never on a specific provider, so the active
implementation can be swapped without the frontend or any downstream
subsystem knowing which one is in use.
"""
from __future__ import annotations

import abc
from typing import Iterator

from rhinoquant.core.events import Event


class MarketDataProvider(abc.ABC):
    name: str = "base"

    @abc.abstractmethod
    def events(self) -> Iterator[Event]:
        """Yield canonical market events in non-decreasing timestamp order."""
        raise NotImplementedError

    def close(self) -> None:  # pragma: no cover - default no-op
        pass
