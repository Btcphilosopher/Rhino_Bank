"""Market-making research strategies (section 14).

A single, configurable :class:`MarketMakingStrategy` implements every
listed variant as a parameter combination rather than five copies of the
same quoting loop:

+------------------------------+---------------------------------------------+
| Variant                      | Configuration                                |
+------------------------------+---------------------------------------------+
| symmetric market making      | inventory_skew=0, vol_spread_coeff=0,        |
|                               | use_microprice=False                         |
| inventory-aware market making | inventory_skew>0                             |
| volatility-adjusted MM        | vol_spread_coeff>0                           |
| spread-adaptive MM            | adaptive_spread=True                         |
| microprice market making      | use_microprice=True                          |
+------------------------------+---------------------------------------------+

Each side (bid/ask) manages one live resting order at a time: a price
change cancels the stale quote and posts the new one instead of leaving
old quotes resting forever and flooding the risk engine's duplicate-order
protection with repeated identical submissions at an unchanged price
(section 17/19: proper order lifecycle management, not submit-and-forget).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from rhinoquant.features.engine import FeatureSnapshot
from rhinoquant.orderbook.book import LimitOrderBook
from rhinoquant.schemas.fills import Fill
from rhinoquant.schemas.orders import Order, OrderType, Side
from rhinoquant.strategies.base import OrderIntent, Strategy


@dataclass
class MarketMakingConfig:
    quote_size: float = 100.0
    base_half_spread_ticks: float = 1.0
    tick_size: float = 0.01
    max_inventory: float = 500.0
    inventory_skew_coeff: float = 0.5  # ticks of skew per unit of (inventory / max_inventory)
    vol_spread_coeff: float = 0.0  # additional half-spread ticks per unit of realised_volatility
    adaptive_spread: bool = True  # widen to at least half the observed market spread
    use_microprice: bool = True
    requote_min_ticks: float = 1.0  # only requote a side once its target price moves at least this many ticks
    pending_retry_ns: int = 200_000_000  # if a quote is neither acked nor cancellable after this long, retry it


@dataclass
class _LiveQuote:
    correlation_id: str
    price: float
    submitted_ns: int
    client_order_id: Optional[str] = None


class MarketMakingStrategy(Strategy):
    strategy_id = "market_maker"

    def __init__(self, symbol: str, portfolio_id: str = "mm", config: Optional[MarketMakingConfig] = None) -> None:
        super().__init__()
        self.symbol = symbol
        self.portfolio_id = portfolio_id
        self.config = config or MarketMakingConfig()
        self.inventory = 0.0
        self._features: Optional[FeatureSnapshot] = None
        self._live_bid: Optional[_LiveQuote] = None
        self._live_ask: Optional[_LiveQuote] = None

    def on_features(self, features: FeatureSnapshot) -> None:
        self._features = features

    def on_fill(self, fill: Fill) -> None:
        signed = fill.quantity if fill.side == Side.BUY else -fill.quantity
        self.inventory += signed
        # the resting order behind a filled slot no longer reflects live
        # book state (even a partial fill changes its remaining queue
        # position) — clear it so the next book update posts a fresh quote
        # instead of assuming a stale, already-(partially-)filled order is
        # still sitting untouched at its old price.
        if self._live_bid is not None and self._live_bid.client_order_id == fill.client_order_id:
            self._live_bid = None
        if self._live_ask is not None and self._live_ask.client_order_id == fill.client_order_id:
            self._live_ask = None

    def on_order_ack(self, order: Order) -> None:
        for live in (self._live_bid, self._live_ask):
            if live is not None and live.correlation_id == order.correlation_id:
                live.client_order_id = order.client_order_id

    def on_book_update(self, book: LimitOrderBook, timestamp_ns: int) -> None:
        cfg = self.config
        mid = book.mid()
        if mid is None:
            return

        fair_value = book.microprice() if cfg.use_microprice else mid
        if fair_value is None:
            fair_value = mid

        half_spread_ticks = cfg.base_half_spread_ticks
        if cfg.vol_spread_coeff and self._features and self._features.realised_volatility:
            half_spread_ticks += cfg.vol_spread_coeff * (self._features.realised_volatility / cfg.tick_size)
        if cfg.adaptive_spread:
            market_spread = book.spread()
            if market_spread is not None:
                half_spread_ticks = max(half_spread_ticks, (market_spread / cfg.tick_size) / 2.0)

        inventory_ratio = self.inventory / cfg.max_inventory if cfg.max_inventory else 0.0
        skew_ticks = -cfg.inventory_skew_coeff * inventory_ratio  # long inventory -> skew quotes down

        half_spread = half_spread_ticks * cfg.tick_size
        skew = skew_ticks * cfg.tick_size

        bid_price = round((fair_value + skew - half_spread) / cfg.tick_size) * cfg.tick_size
        ask_price = round((fair_value + skew + half_spread) / cfg.tick_size) * cfg.tick_size
        if ask_price <= bid_price:
            ask_price = bid_price + cfg.tick_size

        self._live_bid = self._requote(
            side=Side.BUY,
            live=self._live_bid,
            target_price=bid_price,
            want_quote=self.inventory < cfg.max_inventory,
            timestamp_ns=timestamp_ns,
            tag="mm_bid",
        )
        self._live_ask = self._requote(
            side=Side.SELL,
            live=self._live_ask,
            target_price=ask_price,
            want_quote=self.inventory > -cfg.max_inventory,
            timestamp_ns=timestamp_ns,
            tag="mm_ask",
        )

    def _requote(
        self,
        side: Side,
        live: Optional[_LiveQuote],
        target_price: float,
        want_quote: bool,
        timestamp_ns: int,
        tag: str,
    ) -> Optional[_LiveQuote]:
        cfg = self.config

        if not want_quote:
            if live is not None and live.client_order_id is not None:
                self._cancel(live.client_order_id)
            return None

        if live is not None:
            moved_enough = abs(target_price - live.price) >= cfg.requote_min_ticks * cfg.tick_size
            if not moved_enough:
                return live  # still quoting close enough to the target price
            if live.client_order_id is None and timestamp_ns - live.submitted_ns < cfg.pending_retry_ns:
                return live  # give a very recent submission a chance to ack before replacing it
            if live.client_order_id is not None:
                self._cancel(live.client_order_id)

        intent = OrderIntent(
            strategy_id=self.strategy_id,
            portfolio_id=self.portfolio_id,
            symbol=self.symbol,
            side=side,
            quantity=cfg.quote_size,
            order_type=OrderType.LIMIT,
            price=target_price,
            tag=tag,
        )
        self._submit(intent)
        return _LiveQuote(correlation_id=intent.correlation_id, price=target_price, submitted_ns=timestamp_ns)
