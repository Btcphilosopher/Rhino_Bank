"""Strategy plugin architecture (section 13).

    class Strategy:
        def on_market_event(self, event): ...
        def on_book_update(self, book): ...
        def on_trade(self, trade): ...
        def on_timer(self, timestamp): ...
        def on_fill(self, fill): ...
        def generate_orders(self): ...

A strategy never talks to the OMS or execution engine directly — it can
only *propose* :class:`OrderIntent` objects via :meth:`Strategy.generate_orders`.
The engine orchestrator is what routes those intents through the risk
engine before they ever reach the OMS (section 17: "Risk must be
positioned between strategy and execution."), so a strategy implementation
has no code path that could bypass risk even if it tried.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Optional

from rhinoquant.core.events import Event
from rhinoquant.core.ids import new_correlation_id
from rhinoquant.orderbook.book import LimitOrderBook
from rhinoquant.schemas.fills import Fill
from rhinoquant.schemas.orders import Order, OrderType, Side, TimeInForce


@dataclass
class OrderIntent:
    """A strategy's *request* to trade — not yet an :class:`Order`. The
    OMS assigns the client_order_id/timestamps once risk has approved it.
    """

    strategy_id: str
    portfolio_id: str
    symbol: str
    side: Side
    quantity: float
    order_type: OrderType = OrderType.LIMIT
    price: Optional[float] = None
    time_in_force: TimeInForce = TimeInForce.DAY
    correlation_id: str = field(default_factory=new_correlation_id)
    tag: Optional[str] = None


@dataclass
class CancelIntent:
    """A strategy's request to cancel one of its own still-open orders,
    identified by ``client_order_id`` (learned from :meth:`Strategy.on_order_ack`).
    Like :class:`OrderIntent`, this only ever reaches the OMS/execution
    layer through the engine orchestrator, never directly.
    """

    strategy_id: str
    client_order_id: str


class Strategy(abc.ABC):
    strategy_id: str = "base_strategy"
    portfolio_id: str = "default"

    def __init__(self) -> None:
        self._pending: list[OrderIntent] = []
        self._pending_cancels: list[CancelIntent] = []

    # -- event hooks (override any subset) ------------------------------ #
    def on_market_event(self, event: Event) -> None:
        pass

    def on_book_update(self, book: LimitOrderBook, timestamp_ns: int) -> None:
        pass

    def on_trade(self, event: Event) -> None:
        pass

    def on_timer(self, timestamp_ns: int) -> None:
        pass

    def on_fill(self, fill: Fill) -> None:
        pass

    def on_order_ack(self, order: Order) -> None:
        """Optional hook (not part of the minimal section-13 interface,
        but needed by any strategy that manages its own resting-order
        lifecycle — e.g. a market maker cancelling a stale quote before
        posting a new one): called once an order this strategy submitted
        has been acknowledged, so the strategy can learn its
        ``client_order_id`` (matched via ``order.correlation_id`` against
        the id it set on the originating :class:`OrderIntent`)."""
        pass

    # -- order/cancel intent queues -------------------------------------- #
    def _submit(self, intent: OrderIntent) -> None:
        self._pending.append(intent)

    def _cancel(self, client_order_id: str) -> None:
        self._pending_cancels.append(CancelIntent(strategy_id=self.strategy_id, client_order_id=client_order_id))

    def generate_orders(self) -> list[OrderIntent]:
        """Drain and return every :class:`OrderIntent` queued since the
        last call. The default implementation is a FIFO queue fed by
        :meth:`_submit`; override only if a strategy needs different
        batching semantics.
        """
        intents, self._pending = self._pending, []
        return intents

    def generate_cancels(self) -> list[CancelIntent]:
        """Drain and return every :class:`CancelIntent` queued via
        :meth:`_cancel` since the last call. Processed by the engine
        orchestrator before that round's :meth:`generate_orders`."""
        cancels, self._pending_cancels = self._pending_cancels, []
        return cancels
