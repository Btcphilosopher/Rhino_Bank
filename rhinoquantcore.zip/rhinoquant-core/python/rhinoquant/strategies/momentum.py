"""Momentum research strategies (section 14): short-term momentum,
breakout, and order-flow momentum are the same entry mechanism driven by
different :class:`~rhinoquant.features.engine.FeatureSnapshot` fields —
``short_term_momentum`` for plain momentum/breakout (breakout being
momentum measured against a rolling high/low band rather than a rolling
mean), and ``order_flow_imbalance`` for order-flow momentum.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from rhinoquant.features.engine import FeatureSnapshot
from rhinoquant.schemas.fills import Fill
from rhinoquant.schemas.orders import Side
from rhinoquant.strategies.base import OrderIntent, Strategy


@dataclass
class MomentumConfig:
    entry_threshold: float = 0.0008
    exit_threshold: float = 0.0002
    quantity: float = 100.0
    use_order_flow: bool = False
    order_flow_threshold: float = 500.0


class MomentumStrategy(Strategy):
    strategy_id = "momentum"

    def __init__(self, symbol: str, portfolio_id: str = "momentum", config: Optional[MomentumConfig] = None) -> None:
        super().__init__()
        self.symbol = symbol
        self.portfolio_id = portfolio_id
        self.config = config or MomentumConfig()
        self.position = 0.0  # +quantity long, -quantity short, 0 flat

    def on_features(self, features: FeatureSnapshot) -> None:
        cfg = self.config
        signal_value = features.order_flow_imbalance if cfg.use_order_flow else features.short_term_momentum
        threshold = cfg.order_flow_threshold if cfg.use_order_flow else cfg.entry_threshold
        if signal_value is None:
            return

        if self.position == 0:
            if signal_value > threshold:
                self._submit(OrderIntent(self.strategy_id, self.portfolio_id, self.symbol, Side.BUY, cfg.quantity, tag="momentum_entry"))
                self.position = cfg.quantity
            elif signal_value < -threshold:
                self._submit(OrderIntent(self.strategy_id, self.portfolio_id, self.symbol, Side.SELL, cfg.quantity, tag="momentum_entry"))
                self.position = -cfg.quantity
        else:
            exit_threshold = threshold * (cfg.exit_threshold / cfg.entry_threshold if cfg.entry_threshold else 0.25)
            if (self.position > 0 and signal_value < exit_threshold) or (
                self.position < 0 and signal_value > -exit_threshold
            ):
                side = Side.SELL if self.position > 0 else Side.BUY
                self._submit(OrderIntent(self.strategy_id, self.portfolio_id, self.symbol, side, abs(self.position), tag="momentum_exit"))
                self.position = 0.0

    def on_fill(self, fill: Fill) -> None:
        pass
