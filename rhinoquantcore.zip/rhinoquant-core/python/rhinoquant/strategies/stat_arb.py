"""Statistical arbitrage research strategies (section 14):
pairs trading, mean reversion, residual trading, z-score entries/exits —
all driven by the same z-scored-spread signal, entered/exited at
configurable thresholds. "Pairs trading", "residual trading" and "z-score
strategies" are the same mechanism (trade the residual/spread z-score
between two priced legs); a single-symbol mean-reversion variant is just
the pair-trading engine with ``symbol_b`` priced against its own rolling
mean instead of a second instrument.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from rhinoquant.features.cross_asset import CrossAssetFeatureEngine
from rhinoquant.orderbook.book import LimitOrderBook
from rhinoquant.schemas.fills import Fill
from rhinoquant.schemas.orders import Side
from rhinoquant.strategies.base import OrderIntent, Strategy


@dataclass
class PairsTradingConfig:
    entry_zscore: float = 2.0
    exit_zscore: float = 0.5
    quantity_a: float = 100.0
    quantity_b: float = 100.0


class PairsTradingStrategy(Strategy):
    """Trades the beta-hedged spread between two symbols back toward its
    rolling mean. Long the spread means long ``symbol_a`` / short
    ``symbol_b``ed at the current hedge ratio (approximated at fixed
    ``quantity_a``/``quantity_b`` here for simplicity — a production
    version would size ``quantity_b`` by the live hedge ratio).
    """

    strategy_id = "pairs_trading"

    def __init__(
        self,
        symbol_a: str,
        symbol_b: str,
        portfolio_id: str = "stat_arb",
        config: Optional[PairsTradingConfig] = None,
    ) -> None:
        super().__init__()
        self.symbol_a = symbol_a
        self.symbol_b = symbol_b
        self.portfolio_id = portfolio_id
        self.config = config or PairsTradingConfig()
        self.cross_asset = CrossAssetFeatureEngine(symbol_a, symbol_b)
        self.position_state = "FLAT"  # FLAT | LONG_SPREAD | SHORT_SPREAD

    def on_book_update(self, book: LimitOrderBook, timestamp_ns: int) -> None:
        """Standard section-13 hook: figures out which leg just updated
        from ``book.symbol`` and forwards its mid price to
        :meth:`on_prices` (the other leg's price is left ``None`` for this
        call — :class:`CrossAssetFeatureEngine` retains the last known
        value for whichever leg didn't move)."""
        if book.symbol == self.symbol_a:
            self.on_prices(price_a=book.mid(), price_b=None)
        elif book.symbol == self.symbol_b:
            self.on_prices(price_a=None, price_b=book.mid())

    def on_prices(self, price_a: Optional[float], price_b: Optional[float]) -> None:
        snap = self.cross_asset.push(price_a, price_b)
        z = snap.spread_zscore
        if z is None:
            return

        cfg = self.config
        if self.position_state == "FLAT":
            if z > cfg.entry_zscore:
                self._enter("SHORT_SPREAD")
            elif z < -cfg.entry_zscore:
                self._enter("LONG_SPREAD")
        elif abs(z) < cfg.exit_zscore:
            self._exit()

    def _enter(self, direction: str) -> None:
        cfg = self.config
        # LONG_SPREAD: buy A, sell B. SHORT_SPREAD: sell A, buy B.
        a_side = Side.BUY if direction == "LONG_SPREAD" else Side.SELL
        b_side = Side.SELL if direction == "LONG_SPREAD" else Side.BUY
        self._submit(OrderIntent(self.strategy_id, self.portfolio_id, self.symbol_a, a_side, cfg.quantity_a, tag="stat_arb_entry"))
        self._submit(OrderIntent(self.strategy_id, self.portfolio_id, self.symbol_b, b_side, cfg.quantity_b, tag="stat_arb_entry"))
        self.position_state = direction

    def _exit(self) -> None:
        if self.position_state == "FLAT":
            return
        cfg = self.config
        a_side = Side.SELL if self.position_state == "LONG_SPREAD" else Side.BUY
        b_side = Side.BUY if self.position_state == "LONG_SPREAD" else Side.SELL
        self._submit(OrderIntent(self.strategy_id, self.portfolio_id, self.symbol_a, a_side, cfg.quantity_a, tag="stat_arb_exit"))
        self._submit(OrderIntent(self.strategy_id, self.portfolio_id, self.symbol_b, b_side, cfg.quantity_b, tag="stat_arb_exit"))
        self.position_state = "FLAT"

    def on_fill(self, fill: Fill) -> None:
        pass
