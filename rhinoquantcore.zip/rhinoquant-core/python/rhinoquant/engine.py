"""``RhinoQuantEngine``: the top-level orchestrator (section 56).

Wires configuration, lifecycle, kill switches, audit log, metrics and
health checks into one object the CLI and the API service both sit on top
of. Running a synthetic simulation or backtest is exposed as one call
(:meth:`run_simulation`) returning both the underlying
:class:`~rhinoquant.backtest.engine.BacktestEngine` (whose ``oms``,
``portfolio``, ``risk_engine`` and ``latency_engine`` attributes carry
everything the frontend contract (section 6) exposes as state/results) and
a :class:`SimulationReport` bundling the schemas the API/CLI actually
render.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from rhinoquant.audit.log import AuditLog
from rhinoquant.backtest.engine import BacktestEngine, BacktestRunOptions
from rhinoquant.config import EngineConfig
from rhinoquant.core.ids import new_run_id, now_ns
from rhinoquant.core.lifecycle import EngineState, LifecycleController
from rhinoquant.marketdata.provider import MarketDataProvider
from rhinoquant.marketdata.synthetic import RegimeSegment, SyntheticMarketConfig, SyntheticMarketGenerator
from rhinoquant.monitoring.health import HealthChecker
from rhinoquant.monitoring.metrics import MetricsRegistry
from rhinoquant.risk.engine import RiskContext
from rhinoquant.risk.kill_switch import KillSwitchEngine, KillSwitchKind
from rhinoquant.schemas.backtest import BacktestResult
from rhinoquant.schemas.latency import LatencyReport
from rhinoquant.schemas.pnl import PnlSnapshot
from rhinoquant.schemas.portfolio import PortfolioState
from rhinoquant.schemas.risk import RiskState
from rhinoquant.schemas.system import SystemStatus
from rhinoquant.strategies.base import Strategy
from rhinoquant.strategies.market_making import MarketMakingConfig, MarketMakingStrategy

ENGINE_VERSION = "0.1.0"


@dataclass
class SimulationOptions:
    symbol: str = "RHINO"
    n_events: int = 20_000
    regimes: Optional[list[RegimeSegment]] = None
    strategy: Optional[Strategy] = None
    run_options: BacktestRunOptions = field(default_factory=BacktestRunOptions)


@dataclass
class SimulationReport:
    """The machine-readable bundle a CLI/API caller actually wants back
    from one simulation/backtest run — every schema listed in section 6
    that a single run produces."""

    result: BacktestResult
    portfolio_state: PortfolioState
    pnl_snapshot: PnlSnapshot
    risk_state: RiskState
    latency_report: LatencyReport


class RhinoQuantEngine:
    def __init__(self, config: Optional[EngineConfig] = None) -> None:
        self.config = config or EngineConfig.default()
        self.lifecycle = LifecycleController()
        self.kill_switches = KillSwitchEngine()
        self.audit = AuditLog()
        self.metrics = MetricsRegistry()
        self.health = HealthChecker()
        self._started_ns = now_ns()
        self._register_health_checks()
        self.lifecycle.transition(EngineState.READY)
        self.audit.record("system_events", {"event": "engine_ready", "environment": self.config.environment})
        self.last_backtest_engine: Optional[BacktestEngine] = None

    def _register_health_checks(self) -> None:
        self.health.register("configuration", lambda: self.config is not None)
        self.health.register("risk_engine", lambda: True)
        self.health.register(
            "kill_switches", lambda: not self.kill_switches.is_active(KillSwitchKind.GLOBAL, "GLOBAL")
        )

    # ------------------------------------------------------------------ #
    def system_status(self) -> SystemStatus:
        return SystemStatus(
            status=self.lifecycle.state.value,
            environment=self.config.environment.value,
            engine_version=ENGINE_VERSION,
            api_version="v1",
            uptime_ns=now_ns() - self._started_ns,
            components={
                "market_data": "SYNTHETIC",
                "execution": self.config.execution.mode.value,
                "risk": "ARMED",
            },
        )

    def run_simulation(self, options: Optional[SimulationOptions] = None) -> tuple[BacktestEngine, SimulationReport]:
        """Runs the full synthetic workflow described in section 52:
        Synthetic Market -> Market Data -> Order Book -> Features ->
        Strategy -> Risk -> OMS -> Simulated Exchange -> Fills ->
        Portfolio -> P&L -> Metrics -> machine-readable result.
        """
        opts = options or SimulationOptions()
        self.lifecycle.transition(EngineState.RUNNING)
        self.audit.record("system_events", {"event": "simulation_start", "symbol": opts.symbol, "n_events": opts.n_events})

        market_config = SyntheticMarketConfig(
            symbol=opts.symbol,
            seed=self.config.seed,
            n_events=opts.n_events,
            regimes=opts.regimes or [],
        )
        provider: MarketDataProvider = SyntheticMarketGenerator(market_config)
        strategy = opts.strategy or MarketMakingStrategy(opts.symbol, config=MarketMakingConfig())

        bt = BacktestEngine(
            config=self.config,
            providers={opts.symbol: provider},
            strategies=[strategy],
            options=opts.run_options,
            run_id=new_run_id(),
        )
        result = bt.run()
        self.last_backtest_engine = bt

        for decision in bt.risk_engine.decisions_log:
            if not decision.accepted:
                self.audit.record(
                    "risk_decisions",
                    {"reason": decision.reason, "detail": decision.detail},
                    correlation_id=decision.correlation_id,
                    timestamp_ns=decision.timestamp_ns,
                )

        self.metrics.set_gauge("orders_submitted", bt.order_counters.submitted)
        self.metrics.set_gauge("orders_accepted", bt.order_counters.accepted)
        self.metrics.set_gauge("orders_rejected", bt.order_counters.rejected)
        self.metrics.set_gauge("orders_filled", bt.order_counters.filled)
        self.metrics.set_gauge("net_pnl", result.net_pnl)

        self.lifecycle.transition(EngineState.READY)
        self.audit.record("system_events", {"event": "simulation_end", "events_processed": bt.events_processed})

        portfolio_state = bt.portfolio.state()
        risk_state = bt.risk_engine.risk_state(
            context=RiskContext(
                portfolio_state=portfolio_state,
                daily_pnl=bt.portfolio.realised_pnl() + bt.portfolio.unrealised_pnl(),
            ),
        )
        report = SimulationReport(
            result=result,
            portfolio_state=portfolio_state,
            pnl_snapshot=bt.portfolio.pnl_snapshot(),
            risk_state=risk_state,
            latency_report=bt.latency_engine.report(bt.run_id),
        )
        return bt, report
