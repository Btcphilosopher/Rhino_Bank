"""Research engine: Monte Carlo / bootstrap / sensitivity / regime
analysis (section 28), all operating on a return series the caller
already measured (a backtest's per-period returns) — nothing here invents
data, it resamples or perturbs what actually happened.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np


@dataclass
class ResamplingReport:
    mean: float
    std: float
    percentile_5: float
    percentile_95: float
    paths: int


def bootstrap_metric(returns: list[float], metric_fn: Callable[[np.ndarray], float], n_samples: int = 1000, seed: int = 42) -> ResamplingReport:
    """IID bootstrap of a return series: resample *with replacement* and
    recompute ``metric_fn`` each time, reporting the distribution of that
    metric across resamples (a standard way to put a confidence band
    around e.g. Sharpe without assuming a parametric return distribution).
    """
    rng = np.random.default_rng(seed)
    arr = np.asarray(returns, dtype=float)
    n = len(arr)
    values = np.empty(n_samples)
    for i in range(n_samples):
        sample = rng.choice(arr, size=n, replace=True)
        values[i] = metric_fn(sample)
    return ResamplingReport(
        mean=float(values.mean()),
        std=float(values.std(ddof=1)),
        percentile_5=float(np.percentile(values, 5)),
        percentile_95=float(np.percentile(values, 95)),
        paths=n_samples,
    )


def monte_carlo_equity_paths(returns: list[float], starting_equity: float, n_paths: int = 500, seed: int = 42) -> np.ndarray:
    """Monte Carlo simulation of terminal equity by resampling the
    observed per-period return series (block-free IID resampling) into
    ``n_paths`` alternate equity trajectories of the same length. Returns
    an ``(n_paths, len(returns)+1)`` array of equity levels.
    """
    rng = np.random.default_rng(seed)
    arr = np.asarray(returns, dtype=float)
    n = len(arr)
    paths = np.empty((n_paths, n + 1))
    paths[:, 0] = starting_equity
    for i in range(n_paths):
        sampled_returns = rng.choice(arr, size=n, replace=True)
        paths[i, 1:] = starting_equity * np.cumprod(1 + sampled_returns)
    return paths


def sensitivity_analysis(
    objective_fn: Callable[[dict], float], base_params: dict, param_ranges: dict[str, list]
) -> dict[str, list[tuple]]:
    """One-at-a-time sensitivity sweep: for each parameter, vary it across
    ``param_ranges[name]`` while holding every other parameter at its
    ``base_params`` value, recording ``(value, objective)`` pairs.
    """
    results: dict[str, list[tuple]] = {}
    for name, values in param_ranges.items():
        sweep = []
        for v in values:
            params = dict(base_params)
            params[name] = v
            sweep.append((v, objective_fn(params)))
        results[name] = sweep
    return results


@dataclass
class RegimeBucket:
    label: str
    count: int
    mean_return: float
    volatility: float


def regime_analysis(returns: list[float], vol_window: int = 20, high_vol_multiple: float = 1.5) -> list[RegimeBucket]:
    """Classifies each return by trailing realised volatility relative to
    the series' overall volatility (>``high_vol_multiple``x = HIGH_VOL,
    otherwise LOW_VOL) and reports per-regime mean return/volatility — a
    simple, transparent regime split rather than a fitted hidden-Markov
    model (which would be a natural extension point here).
    """
    arr = np.asarray(returns, dtype=float)
    if len(arr) < vol_window + 1:
        return []
    overall_vol = arr.std(ddof=1)
    labels = []
    for i in range(len(arr)):
        window = arr[max(0, i - vol_window) : i + 1]
        local_vol = window.std(ddof=1) if len(window) > 1 else 0.0
        labels.append("HIGH_VOL" if local_vol > high_vol_multiple * overall_vol else "LOW_VOL")

    buckets = []
    for label in ("HIGH_VOL", "LOW_VOL"):
        mask = np.array([l == label for l in labels])
        if mask.sum() == 0:
            continue
        subset = arr[mask]
        buckets.append(
            RegimeBucket(
                label=label,
                count=int(mask.sum()),
                mean_return=float(subset.mean()),
                volatility=float(subset.std(ddof=1)) if mask.sum() > 1 else 0.0,
            )
        )
    return buckets
