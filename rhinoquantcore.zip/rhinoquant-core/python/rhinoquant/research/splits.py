"""Research engine: train/validation/test separation and walk-forward
windowing (section 28).

Every split here operates on plain index ranges over an ordered dataset
(a list of events, an equity curve, a return series — whatever the caller
is slicing) so it is agnostic to what's actually stored at each index, but
always respects time order: a "test" range's indices are always >= the
"train" range's, and walk-forward windows never let a later fold's data
leak into an earlier fold's training set.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class Split:
    train: range
    validation: range
    test: range


def train_validation_test_split(n: int, train_frac: float = 0.6, validation_frac: float = 0.2) -> Split:
    if not (0 < train_frac < 1) or not (0 <= validation_frac < 1) or train_frac + validation_frac >= 1:
        raise ValueError("train_frac and validation_frac must be in (0,1) and sum to < 1")
    train_end = int(n * train_frac)
    val_end = train_end + int(n * validation_frac)
    return Split(train=range(0, train_end), validation=range(train_end, val_end), test=range(val_end, n))


@dataclass
class WalkForwardWindow:
    index: int
    train: range
    test: range


def walk_forward_windows(n: int, train_size: int, test_size: int, step: Optional[int] = None) -> list[WalkForwardWindow]:
    """Anchored (expanding is achieved by setting ``step`` = ``test_size``
    and reusing index 0 as the perpetual train start externally) rolling
    walk-forward windows: window i trains on
    ``[i*step, i*step + train_size)`` and tests on the immediately
    following ``[i*step + train_size, i*step + train_size + test_size)``,
    never overlapping future data into the training range.
    """
    step = step or test_size
    windows = []
    start = 0
    i = 0
    while start + train_size + test_size <= n:
        train = range(start, start + train_size)
        test = range(start + train_size, start + train_size + test_size)
        windows.append(WalkForwardWindow(index=i, train=train, test=test))
        start += step
        i += 1
    return windows
