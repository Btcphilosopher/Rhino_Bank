"""Future live-exchange adapter interface (section 20 / 36).

    "Do not implement live exchange connectivity unless explicitly
    requested."

``ExchangeAdapter`` exists so the shape of a live venue connection is part
of the engine contract from day one, but every method deliberately raises
:class:`NotImplementedError` — there is no code path anywhere in this
repository that can reach a real exchange. Wiring a real venue here later
requires an explicit :class:`~rhinoquant.config.EngineConfig` with
``environment=production`` *and* ``execution.allow_live=true`` (see
``config.py``), so a research configuration can never accidentally end up
here (section 36).
"""
from __future__ import annotations

from typing import Optional

from rhinoquant.execution.base import ExecutionEngine, ExecutionReport
from rhinoquant.schemas.orders import Order


class ExchangeAdapter(ExecutionEngine):
    name = "exchange_adapter"

    def __init__(self, venue: str) -> None:
        self.venue = venue

    def submit(self, order: Order, timestamp_ns: Optional[int] = None) -> ExecutionReport:
        raise NotImplementedError(
            f"live connectivity to venue={self.venue!r} is not implemented in this engine; "
            "this adapter is an interface stub only (section 20/36 of the spec)"
        )

    def cancel(self, order: Order, timestamp_ns: Optional[int] = None) -> ExecutionReport:
        raise NotImplementedError(f"live connectivity to venue={self.venue!r} is not implemented")

    def replace(
        self,
        order: Order,
        new_price: Optional[float] = None,
        new_quantity: Optional[float] = None,
        timestamp_ns: Optional[int] = None,
    ) -> ExecutionReport:
        raise NotImplementedError(f"live connectivity to venue={self.venue!r} is not implemented")
