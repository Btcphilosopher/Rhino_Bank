"""``SimulatorExecution`` (section 20): the :class:`ExecutionEngine`
backend used by the backtester and by ``python -m rhinoquant simulate``.
Routes each order to the per-symbol
:class:`~rhinoquant.simulation.exchange.SimulatedExchange`.
"""
from __future__ import annotations

from typing import Optional

from rhinoquant.core.ids import now_ns
from rhinoquant.execution.base import ExecutionEngine, ExecutionReport
from rhinoquant.schemas.orders import Order
from rhinoquant.simulation.exchange import SimulatedExchange


class SimulatorExecution(ExecutionEngine):
    name = "simulator"

    def __init__(self, exchanges: dict[str, SimulatedExchange]) -> None:
        self.exchanges = exchanges

    def submit(self, order: Order, timestamp_ns: Optional[int] = None) -> ExecutionReport:
        ts = timestamp_ns if timestamp_ns is not None else now_ns()
        exchange = self.exchanges.get(order.symbol)
        if exchange is None:
            return ExecutionReport(accepted=False, reject_reason=f"no simulated exchange configured for symbol {order.symbol!r}")
        return exchange.submit(order, ts)

    def cancel(self, order: Order, timestamp_ns: Optional[int] = None) -> ExecutionReport:
        ts = timestamp_ns if timestamp_ns is not None else now_ns()
        exchange = self.exchanges.get(order.symbol)
        if exchange is None or not order.exchange_order_id:
            return ExecutionReport(accepted=False, reject_reason="unknown symbol or order was never acknowledged")
        return exchange.cancel(order.exchange_order_id, ts)

    def replace(
        self,
        order: Order,
        new_price: Optional[float] = None,
        new_quantity: Optional[float] = None,
        timestamp_ns: Optional[int] = None,
    ) -> ExecutionReport:
        ts = timestamp_ns if timestamp_ns is not None else now_ns()
        exchange = self.exchanges.get(order.symbol)
        if exchange is None or not order.exchange_order_id:
            return ExecutionReport(accepted=False, reject_reason="unknown symbol or order was never acknowledged")
        return exchange.replace(order.exchange_order_id, ts, new_price, new_quantity)
