"""Execution engine interface (section 20).

    execution.submit(order)
    execution.cancel(order)
    execution.replace(order)

Three concrete backends implement this interface:
:class:`~rhinoquant.execution.simulator.SimulatorExecution` (drives the
:class:`~rhinoquant.simulation.exchange.SimulatedExchange`),
:class:`~rhinoquant.execution.paper.PaperExecution` (same matching engine,
tagged as paper-trading intent so downstream accounting/labels reflect
that this is not a backtest), and
:class:`~rhinoquant.execution.adapter.ExchangeAdapter` (an explicit,
*unimplemented* extension point for a future live venue — see its
docstring for why).
"""
from __future__ import annotations

import abc
from dataclasses import dataclass
from typing import Optional

from rhinoquant.schemas.fills import Fill
from rhinoquant.schemas.orders import Order


@dataclass
class ExecutionReport:
    """What an execution backend hands back synchronously from
    :meth:`ExecutionEngine.submit`/``cancel``/``replace`` — the OMS applies
    the resulting transitions/fills, the execution backend never mutates
    Order state directly."""

    accepted: bool
    exchange_order_id: Optional[str] = None
    reject_reason: Optional[str] = None
    ack_timestamp_ns: Optional[int] = None
    fills: list[Fill] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.fills is None:
            self.fills = []


class ExecutionEngine(abc.ABC):
    name: str = "base_execution"

    @abc.abstractmethod
    def submit(self, order: Order, timestamp_ns: Optional[int] = None) -> ExecutionReport:
        """``timestamp_ns`` is optional in the public signature (matching
        the ``execution.submit(order)`` example in section 20) but the
        backtester and simulator always pass the current simulated time
        explicitly — determinism (section 42) depends on never falling
        back to wall-clock time mid-replay. Only paper/live-adjacent
        callers should omit it and let a backend default to ``now_ns()``.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def cancel(self, order: Order, timestamp_ns: Optional[int] = None) -> ExecutionReport:
        raise NotImplementedError

    @abc.abstractmethod
    def replace(
        self,
        order: Order,
        new_price: Optional[float] = None,
        new_quantity: Optional[float] = None,
        timestamp_ns: Optional[int] = None,
    ) -> ExecutionReport:
        raise NotImplementedError
