"""``PaperExecution`` (section 20): identical matching mechanics to
:class:`~rhinoquant.execution.simulator.SimulatorExecution`, distinguished
only by ``name`` (so downstream accounting/labels can tell a paper run
from a backtest) and by defaulting to wall-clock time when the caller
does not supply ``timestamp_ns`` — a paper session runs against real time,
unlike a backtest replaying historical/synthetic time.
"""
from __future__ import annotations

from rhinoquant.execution.simulator import SimulatorExecution


class PaperExecution(SimulatorExecution):
    name = "paper"
