"""Order-book-specific structured errors (section 10 detection list)."""
from __future__ import annotations

from rhinoquant.core.errors import RhinoQuantError


class OrderBookError(RhinoQuantError):
    error_code = "ORDERBOOK_ERROR"
    component = "orderbook"


class SequenceGapError(OrderBookError):
    error_code = "SEQUENCE_GAP"


class CrossedBookError(OrderBookError):
    error_code = "CROSSED_BOOK"


class LockedBookError(OrderBookError):
    error_code = "LOCKED_BOOK"


class NegativeQuantityError(OrderBookError):
    error_code = "NEGATIVE_QUANTITY"


class InvalidPriceError(OrderBookError):
    error_code = "INVALID_PRICE"


class DuplicateMessageError(OrderBookError):
    error_code = "DUPLICATE_MESSAGE"


class InvalidUpdateError(OrderBookError):
    error_code = "INVALID_UPDATE"
