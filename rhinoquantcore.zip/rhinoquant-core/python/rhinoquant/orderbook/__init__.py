"""Order book engine package.

Exposes :class:`LimitOrderBook`, the pure-Python reference implementation,
plus :func:`rust_backend_available` / :func:`get_order_book` which prefer
the compiled Rust extension (``rhinoquant_core.OrderBook``) when it has
been built with maturin, falling back transparently to the Python
implementation otherwise. Both backends expose the identical public API
described in section 4 of the spec.
"""
from __future__ import annotations

from rhinoquant.orderbook.book import LimitOrderBook
from rhinoquant.orderbook import errors

_rust_module = None
try:
    import rhinoquant_core as _rust_module  # type: ignore
except ImportError:
    _rust_module = None


def rust_backend_available() -> bool:
    return _rust_module is not None


def get_order_book(symbol: str = "UNKNOWN", prefer_rust: bool = True, strict: bool = True) -> LimitOrderBook:
    """Return an order book instance.

    When the Rust extension is built and ``prefer_rust`` is True, the
    accelerated backend is returned (it implements the same
    best_bid/best_ask/mid/microprice/imbalance surface). Otherwise the pure
    Python reference implementation is returned. Sequence-gap/crossed-book
    detection and own-order queue tracking are currently only implemented
    in the Python reference backend.
    """
    if prefer_rust and _rust_module is not None:
        return _rust_module.OrderBook()
    return LimitOrderBook(symbol=symbol, strict=strict)


__all__ = ["LimitOrderBook", "errors", "rust_backend_available", "get_order_book"]
