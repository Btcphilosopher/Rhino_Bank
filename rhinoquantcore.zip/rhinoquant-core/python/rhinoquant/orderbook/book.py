"""High-performance-oriented (in this Python fallback: correctness-first)
limit order book (section 10).

This pure-Python implementation is the reference/fallback backend. When the
compiled Rust extension (``rhinoquant_core``) is available and importable,
:func:`rhinoquant.orderbook.get_order_book_backend` prefers it for
latency-sensitive paths; both expose the identical public API so callers
never need to know which backend is active (section 49).
"""
from __future__ import annotations

import bisect
from dataclasses import dataclass, field
from typing import Optional

from rhinoquant.orderbook.errors import (
    CrossedBookError,
    DuplicateMessageError,
    InvalidPriceError,
    LockedBookError,
    NegativeQuantityError,
    SequenceGapError,
)


@dataclass
class OwnOrderQueueEntry:
    order_id: str
    side: str
    price: float
    quantity: float
    ahead_quantity: float


class LimitOrderBook:
    """Price-priority L2 limit order book keyed by price level.

    Levels are stored as ``price -> quantity`` dicts with a sorted price
    index per side (bids descending, asks ascending) to keep best-of-book
    and depth queries cheap. This is a market-by-price (MBP) abstraction; a
    market-by-order (MBO) book can be layered on top by tracking individual
    order IDs at each level (see :class:`OwnOrderQueueEntry` for the
    simulator-facing subset actually needed by execution simulation).
    """

    def __init__(self, symbol: str = "UNKNOWN", strict: bool = True) -> None:
        self.symbol = symbol
        self.strict = strict

        self._bid_prices: list[float] = []  # ascending; best bid = last
        self._ask_prices: list[float] = []  # ascending; best ask = first
        self._bids: dict[float, float] = {}
        self._asks: dict[float, float] = {}

        self._last_sequence: Optional[int] = None
        self._seen_sequences: set[int] = set()

        self._own_orders: dict[str, OwnOrderQueueEntry] = {}

        self.crossed_count = 0
        self.locked_count = 0
        self.sequence_gap_count = 0

    # ------------------------------------------------------------------ #
    # Updates
    # ------------------------------------------------------------------ #
    def update_bid(self, price: float, quantity: float, sequence_number: Optional[int] = None) -> None:
        self._check_sequence(sequence_number)
        self._validate(price, quantity)
        self._set_level(self._bids, self._bid_prices, price, quantity, ascending=True)
        self._check_book_integrity()

    def update_ask(self, price: float, quantity: float, sequence_number: Optional[int] = None) -> None:
        self._check_sequence(sequence_number)
        self._validate(price, quantity)
        self._set_level(self._asks, self._ask_prices, price, quantity, ascending=True)
        self._check_book_integrity()

    def apply_snapshot(
        self,
        bids: list[tuple[float, float]],
        asks: list[tuple[float, float]],
        sequence_number: Optional[int] = None,
    ) -> None:
        self._bids.clear()
        self._asks.clear()
        self._bid_prices.clear()
        self._ask_prices.clear()
        for price, qty in bids:
            self.update_bid(price, qty)
        for price, qty in asks:
            self.update_ask(price, qty)
        if sequence_number is not None:
            self._last_sequence = sequence_number

    def on_trade(self, price: float, quantity: float, aggressor_side: str) -> None:
        """Deplete resting liquidity (including our own queued orders) at
        ``price`` on the passive side implied by the aggressor.
        """
        if quantity < 0:
            raise NegativeQuantityError(f"trade quantity cannot be negative: {quantity}")
        passive_book = self._asks if aggressor_side == "BUY" else self._bids
        passive_prices = self._ask_prices if aggressor_side == "BUY" else self._bid_prices
        remaining = passive_book.get(price)
        if remaining is not None:
            new_qty = max(0.0, remaining - quantity)
            self._set_level(passive_book, passive_prices, price, new_qty, ascending=True)

        for entry in self._own_orders.values():
            if entry.price == price and entry.side != aggressor_side:
                entry.ahead_quantity = max(0.0, entry.ahead_quantity - quantity)

    # ------------------------------------------------------------------ #
    # Own-order queue tracking (for execution simulation)
    # ------------------------------------------------------------------ #
    def register_own_order(self, order_id: str, side: str, price: float, quantity: float) -> float:
        level_book = self._bids if side == "BUY" else self._asks
        resting = level_book.get(price, 0.0)
        ahead = resting + sum(
            e.quantity for e in self._own_orders.values() if e.side == side and e.price == price
        )
        self._own_orders[order_id] = OwnOrderQueueEntry(order_id, side, price, quantity, ahead)
        return ahead

    def queue_position(self, order_id: str) -> float:
        entry = self._own_orders.get(order_id)
        if entry is None:
            raise KeyError(f"unknown own order_id: {order_id}")
        return entry.ahead_quantity

    def remove_own_order(self, order_id: str) -> None:
        self._own_orders.pop(order_id, None)

    # ------------------------------------------------------------------ #
    # Queries
    # ------------------------------------------------------------------ #
    def best_bid(self) -> Optional[float]:
        return self._bid_prices[-1] if self._bid_prices else None

    def best_ask(self) -> Optional[float]:
        return self._ask_prices[0] if self._ask_prices else None

    def best_bid_quantity(self) -> Optional[float]:
        p = self.best_bid()
        return self._bids.get(p) if p is not None else None

    def best_ask_quantity(self) -> Optional[float]:
        p = self.best_ask()
        return self._asks.get(p) if p is not None else None

    def mid(self) -> Optional[float]:
        bb, ba = self.best_bid(), self.best_ask()
        if bb is None or ba is None:
            return None
        return (bb + ba) / 2.0

    def spread(self) -> Optional[float]:
        bb, ba = self.best_bid(), self.best_ask()
        if bb is None or ba is None:
            return None
        return ba - bb

    def microprice(self) -> Optional[float]:
        bb, ba = self.best_bid(), self.best_ask()
        if bb is None or ba is None:
            return None
        bq = self._bids.get(bb, 0.0)
        aq = self._asks.get(ba, 0.0)
        total = bq + aq
        if total <= 0:
            return self.mid()
        # weighted toward the side with LESS resting quantity (standard microprice)
        return (bb * aq + ba * bq) / total

    def depth(self, levels: int = 5) -> dict[str, list[tuple[float, float]]]:
        bids = [(p, self._bids[p]) for p in reversed(self._bid_prices[-levels:])]
        asks = [(p, self._asks[p]) for p in self._ask_prices[:levels]]
        return {"bids": bids, "asks": asks}

    def imbalance(self, levels: int = 1) -> Optional[float]:
        d = self.depth(levels)
        bid_qty = sum(q for _, q in d["bids"])
        ask_qty = sum(q for _, q in d["asks"])
        total = bid_qty + ask_qty
        if total <= 0:
            return None
        return (bid_qty - ask_qty) / total

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #
    def _validate(self, price: float, quantity: float) -> None:
        if price is None or price <= 0:
            raise InvalidPriceError(f"invalid price: {price}")
        if quantity < 0:
            raise NegativeQuantityError(f"invalid negative quantity: {quantity}")

    def _set_level(
        self,
        book: dict[float, float],
        prices: list[float],
        price: float,
        quantity: float,
        ascending: bool,
    ) -> None:
        existed = price in book
        if quantity == 0:
            if existed:
                del book[price]
                idx = bisect.bisect_left(prices, price)
                if idx < len(prices) and prices[idx] == price:
                    prices.pop(idx)
            return
        book[price] = quantity
        if not existed:
            bisect.insort(prices, price)

    def _check_sequence(self, sequence_number: Optional[int]) -> None:
        if sequence_number is None:
            return
        if sequence_number in self._seen_sequences:
            if self.strict:
                raise DuplicateMessageError(f"duplicate sequence_number: {sequence_number}")
            return
        self._seen_sequences.add(sequence_number)
        if self._last_sequence is not None and sequence_number != self._last_sequence + 1:
            self.sequence_gap_count += 1
            if self.strict:
                raise SequenceGapError(
                    f"sequence gap: expected {self._last_sequence + 1}, got {sequence_number}"
                )
        self._last_sequence = sequence_number

    def _check_book_integrity(self) -> None:
        bb, ba = self.best_bid(), self.best_ask()
        if bb is None or ba is None:
            return
        if bb > ba:
            self.crossed_count += 1
            if self.strict:
                raise CrossedBookError(f"crossed book: best_bid={bb} > best_ask={ba}")
        elif bb == ba:
            self.locked_count += 1
            if self.strict:
                raise LockedBookError(f"locked book: best_bid == best_ask == {bb}")
