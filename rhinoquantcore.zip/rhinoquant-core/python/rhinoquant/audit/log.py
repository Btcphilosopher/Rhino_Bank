"""Audit engine (section 34): a hash-chained, append-only event history.

Every record's hash covers its own content *and* the previous record's
hash, exactly like a simple blockchain/git-commit chain — so
:meth:`AuditLog.verify_chain` can detect any record being edited, removed,
or reordered after the fact ("immutable-style", since this is an in-memory
Python log rather than a write-once storage medium: nothing stops a
caller with a reference to ``_records`` from mutating the list directly,
but any such tampering breaks the hash chain and is exactly what
``verify_chain`` is for).
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from typing import Any, Optional

from rhinoquant.core.ids import now_ns

GENESIS_HASH = "0" * 64


@dataclass
class AuditRecord:
    index: int
    timestamp_ns: int
    category: str
    payload: dict[str, Any]
    correlation_id: Optional[str]
    prev_hash: str
    record_hash: str


class AuditLog:
    """Categories mirror section 34's list: ``orders``, ``fills``,
    ``risk_decisions``, ``strategy_decisions``, ``configuration_changes``,
    ``kill_switches``, ``system_events``."""

    def __init__(self) -> None:
        self._records: list[AuditRecord] = []
        self._last_hash = GENESIS_HASH

    def record(
        self,
        category: str,
        payload: dict[str, Any],
        correlation_id: Optional[str] = None,
        timestamp_ns: Optional[int] = None,
    ) -> AuditRecord:
        ts = timestamp_ns if timestamp_ns is not None else now_ns()
        index = len(self._records)
        content = json.dumps(
            {
                "index": index,
                "timestamp_ns": ts,
                "category": category,
                "payload": payload,
                "correlation_id": correlation_id,
                "prev_hash": self._last_hash,
            },
            sort_keys=True,
            default=str,
        )
        record_hash = hashlib.sha256(content.encode()).hexdigest()
        record = AuditRecord(
            index=index,
            timestamp_ns=ts,
            category=category,
            payload=payload,
            correlation_id=correlation_id,
            prev_hash=self._last_hash,
            record_hash=record_hash,
        )
        self._records.append(record)
        self._last_hash = record_hash
        return record

    def records(self, category: Optional[str] = None) -> list[AuditRecord]:
        if category is None:
            return list(self._records)
        return [r for r in self._records if r.category == category]

    def verify_chain(self) -> bool:
        prev_hash = GENESIS_HASH
        for record in self._records:
            if record.prev_hash != prev_hash:
                return False
            content = json.dumps(
                {
                    "index": record.index,
                    "timestamp_ns": record.timestamp_ns,
                    "category": record.category,
                    "payload": record.payload,
                    "correlation_id": record.correlation_id,
                    "prev_hash": record.prev_hash,
                },
                sort_keys=True,
                default=str,
            )
            expected_hash = hashlib.sha256(content.encode()).hexdigest()
            if expected_hash != record.record_hash:
                return False
            prev_hash = record.record_hash
        return True

    def to_dicts(self) -> list[dict[str, Any]]:
        return [asdict(r) for r in self._records]
