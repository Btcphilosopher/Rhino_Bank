from __future__ import annotations

from enum import Enum
from typing import Optional

from rhinoquant.schemas.base import RhinoQuantSchema


class SignalDirection(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"
    FLAT = "FLAT"


class Signal(RhinoQuantSchema):
    signal_id: str
    strategy_id: str
    symbol: str
    timestamp_ns: int
    direction: SignalDirection
    confidence: float
    expected_return: float
    holding_period_ns: int
    risk: float
    source_model: str = "unknown"
    correlation_id: Optional[str] = None
