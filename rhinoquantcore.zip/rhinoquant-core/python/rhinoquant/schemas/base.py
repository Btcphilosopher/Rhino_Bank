"""Shared base for every frontend-contract schema (section 6 / 38 / 46).

All schemas are JSON-compatible pydantic models carrying an explicit
``schema_version`` field so internal refactoring can never silently break
the existing frontend (section 46): a breaking change bumps the version
rather than mutating a shipped schema's meaning in place.
"""
from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class RhinoQuantSchema(BaseModel):
    model_config = ConfigDict(use_enum_values=True, extra="forbid")

    schema_version: str = Field(default="v1", frozen=True)

    def to_json_dict(self) -> dict:
        return self.model_dump(mode="json")
