from __future__ import annotations

from enum import Enum
from typing import Optional

from rhinoquant.schemas.base import RhinoQuantSchema


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, Enum):
    LIMIT = "LIMIT"
    MARKET = "MARKET"


class TimeInForce(str, Enum):
    DAY = "DAY"
    IOC = "IOC"
    FOK = "FOK"
    GTC = "GTC"


class OrderStatus(str, Enum):
    NEW = "NEW"
    ACK = "ACK"
    PARTIAL_FILL = "PARTIAL_FILL"
    FILL = "FILL"
    CANCEL = "CANCEL"
    CANCEL_ACK = "CANCEL_ACK"
    REJECT = "REJECT"
    REPLACE = "REPLACE"
    EXPIRE = "EXPIRE"


class Order(RhinoQuantSchema):
    client_order_id: str
    exchange_order_id: Optional[str] = None
    strategy_id: str
    portfolio_id: str
    symbol: str
    venue: str = "SIM"
    side: Side
    order_type: OrderType = OrderType.LIMIT
    time_in_force: TimeInForce = TimeInForce.DAY
    price: Optional[float] = None
    quantity: float
    filled_quantity: float = 0.0
    remaining_quantity: float = 0.0
    status: OrderStatus = OrderStatus.NEW
    created_ns: int
    updated_ns: int
    correlation_id: Optional[str] = None
    reject_reason: Optional[str] = None
