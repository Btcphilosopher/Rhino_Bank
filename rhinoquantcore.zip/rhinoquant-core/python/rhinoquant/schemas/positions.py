from __future__ import annotations

from rhinoquant.schemas.base import RhinoQuantSchema


class Position(RhinoQuantSchema):
    strategy_id: str
    portfolio_id: str
    symbol: str
    venue: str = "SIM"
    quantity: float = 0.0
    average_price: float = 0.0
    realised_pnl: float = 0.0
    unrealised_pnl: float = 0.0
    timestamp_ns: int
