from __future__ import annotations

from rhinoquant.schemas.base import RhinoQuantSchema


class StageLatencyStats(RhinoQuantSchema):
    stage: str
    count: int
    p50_ns: float
    p90_ns: float
    p95_ns: float
    p99_ns: float
    p999_ns: float
    max_ns: float


class LatencyReport(RhinoQuantSchema):
    run_id: str
    timestamp_ns: int
    stages: list[StageLatencyStats] = []
    source: str = "software_benchmark_simulation"
    note: str = (
        "These figures are software/simulation timings measured on this host; "
        "they are NOT exchange or network latency and must not be presented as such."
    )
