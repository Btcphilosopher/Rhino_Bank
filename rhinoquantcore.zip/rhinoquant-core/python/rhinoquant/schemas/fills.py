from __future__ import annotations

from typing import Optional

from rhinoquant.schemas.base import RhinoQuantSchema
from rhinoquant.schemas.orders import Side


class Fill(RhinoQuantSchema):
    fill_id: str
    client_order_id: str
    exchange_order_id: Optional[str] = None
    strategy_id: str
    portfolio_id: str
    symbol: str
    venue: str = "SIM"
    side: Side
    price: float
    quantity: float
    fee: float = 0.0
    rebate: float = 0.0
    liquidity_flag: str = "TAKER"
    timestamp_ns: int
    correlation_id: Optional[str] = None
