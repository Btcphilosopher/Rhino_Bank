from __future__ import annotations

from typing import Optional

from rhinoquant.schemas.base import RhinoQuantSchema


class PriceLevel(RhinoQuantSchema):
    price: float
    quantity: float
    order_count: int = 1


class OrderBookSnapshot(RhinoQuantSchema):
    symbol: str
    venue: str = "SIM"
    timestamp_ns: int
    sequence_number: int
    bids: list[PriceLevel] = []
    asks: list[PriceLevel] = []
    best_bid: Optional[float] = None
    best_ask: Optional[float] = None
    mid: Optional[float] = None
    microprice: Optional[float] = None
    spread: Optional[float] = None
    imbalance: Optional[float] = None
