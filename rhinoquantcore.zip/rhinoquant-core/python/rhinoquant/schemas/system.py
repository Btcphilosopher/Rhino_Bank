from __future__ import annotations

from rhinoquant.schemas.base import RhinoQuantSchema


class SystemStatus(RhinoQuantSchema):
    status: str
    environment: str
    engine_version: str
    api_version: str = "v1"
    uptime_ns: int
    components: dict[str, str] = {}


class HealthCheck(RhinoQuantSchema):
    healthy: bool
    ready: bool
    live: bool
    dependencies: dict[str, str] = {}
    timestamp_ns: int
