from __future__ import annotations

from typing import Optional

from rhinoquant.schemas.base import RhinoQuantSchema


class BacktestResult(RhinoQuantSchema):
    backtest_id: str
    run_id: str
    strategy_id: str
    symbols: list[str]
    started_ns: int
    finished_ns: int
    events_processed: int
    orders_submitted: int
    orders_filled: int
    orders_rejected: int
    total_return: float
    gross_pnl: float
    net_pnl: float
    fees: float
    sharpe: Optional[float] = None
    sortino: Optional[float] = None
    max_drawdown: Optional[float] = None
    volatility: Optional[float] = None
    turnover: Optional[float] = None
    hit_rate: Optional[float] = None
    deterministic_hash: str
    is_synthetic_data: bool = True
