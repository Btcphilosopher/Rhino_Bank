from __future__ import annotations

from rhinoquant.schemas.base import RhinoQuantSchema


class PnlSnapshot(RhinoQuantSchema):
    portfolio_id: str
    symbol: str | None = None
    strategy_id: str | None = None
    timestamp_ns: int
    realised_pnl: float = 0.0
    unrealised_pnl: float = 0.0
    fees: float = 0.0
    rebates: float = 0.0
    financing: float = 0.0
    total_pnl: float = 0.0
