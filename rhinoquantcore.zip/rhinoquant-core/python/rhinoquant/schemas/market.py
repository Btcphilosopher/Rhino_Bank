from __future__ import annotations

from typing import Optional

from pydantic import Field

from rhinoquant.schemas.base import RhinoQuantSchema


class MarketSnapshot(RhinoQuantSchema):
    symbol: str
    venue: str = "SIM"
    timestamp_ns: int
    last_trade_price: Optional[float] = None
    last_trade_quantity: Optional[float] = None
    best_bid: Optional[float] = None
    best_ask: Optional[float] = None
    best_bid_quantity: Optional[float] = None
    best_ask_quantity: Optional[float] = None
    is_synthetic: bool = Field(default=True, description="Always true until a real feed is attached.")


class InstrumentDefinition(RhinoQuantSchema):
    symbol: str
    venue: str = "SIM"
    tick_size: float = 0.01
    lot_size: float = 1.0
    currency: str = "USD"
    multiplier: float = 1.0
    is_active: bool = True
