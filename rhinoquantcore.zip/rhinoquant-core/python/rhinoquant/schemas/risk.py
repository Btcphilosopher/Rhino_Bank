from __future__ import annotations

from enum import Enum
from typing import Optional

from rhinoquant.schemas.base import RhinoQuantSchema


class RiskStatusLevel(str, Enum):
    NORMAL = "NORMAL"
    WARNING = "WARNING"
    BREACH = "BREACH"
    KILLED = "KILLED"


class RiskRejectReason(str, Enum):
    RISK_REJECT_POSITION_LIMIT = "RISK_REJECT_POSITION_LIMIT"
    RISK_REJECT_ORDER_SIZE_LIMIT = "RISK_REJECT_ORDER_SIZE_LIMIT"
    RISK_REJECT_NOTIONAL_LIMIT = "RISK_REJECT_NOTIONAL_LIMIT"
    RISK_REJECT_LEVERAGE_LIMIT = "RISK_REJECT_LEVERAGE_LIMIT"
    RISK_REJECT_LOSS_LIMIT = "RISK_REJECT_LOSS_LIMIT"
    RISK_REJECT_DAILY_LOSS_LIMIT = "RISK_REJECT_DAILY_LOSS_LIMIT"
    RISK_REJECT_STRATEGY_LOSS_LIMIT = "RISK_REJECT_STRATEGY_LOSS_LIMIT"
    RISK_REJECT_VENUE_EXPOSURE_LIMIT = "RISK_REJECT_VENUE_EXPOSURE_LIMIT"
    RISK_REJECT_RATE_LIMIT = "RISK_REJECT_RATE_LIMIT"
    RISK_REJECT_CANCEL_RATE_LIMIT = "RISK_REJECT_CANCEL_RATE_LIMIT"
    RISK_REJECT_PRICE_COLLAR = "RISK_REJECT_PRICE_COLLAR"
    RISK_REJECT_FAT_FINGER = "RISK_REJECT_FAT_FINGER"
    RISK_REJECT_STALE_MARKET = "RISK_REJECT_STALE_MARKET"
    RISK_REJECT_DUPLICATE_ORDER = "RISK_REJECT_DUPLICATE_ORDER"
    RISK_REJECT_KILL_SWITCH = "RISK_REJECT_KILL_SWITCH"


class RiskDecision(RhinoQuantSchema):
    order_client_id: str
    accepted: bool
    reason: Optional[RiskRejectReason] = None
    detail: Optional[str] = None
    timestamp_ns: int
    correlation_id: Optional[str] = None


class RiskState(RhinoQuantSchema):
    status: RiskStatusLevel = RiskStatusLevel.NORMAL
    strategy_id: Optional[str] = None
    portfolio_id: Optional[str] = None
    current_position: float = 0.0
    current_notional: float = 0.0
    current_leverage: float = 0.0
    daily_pnl: float = 0.0
    breaches: list[str] = []
    kill_switches_active: list[str] = []
    timestamp_ns: int
