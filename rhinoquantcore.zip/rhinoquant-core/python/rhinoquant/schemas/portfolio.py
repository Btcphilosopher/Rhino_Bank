from __future__ import annotations

from rhinoquant.schemas.base import RhinoQuantSchema
from rhinoquant.schemas.positions import Position


class PortfolioState(RhinoQuantSchema):
    portfolio_id: str
    timestamp_ns: int
    positions: list[Position] = []
    cash: float = 0.0
    gross_exposure: float = 0.0
    net_exposure: float = 0.0
    leverage: float = 0.0
    currency_exposure: dict[str, float] = {}
    instrument_exposure: dict[str, float] = {}
    venue_exposure: dict[str, float] = {}
    strategy_exposure: dict[str, float] = {}
