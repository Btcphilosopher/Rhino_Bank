"""Machine-learning research interfaces (section 30).

``scikit-learn`` is an *optional* dependency (``pip install
rhinoquant[ml]``, section 3: "keep dependencies controlled") — it is only
imported inside the factory functions below, so importing
:mod:`rhinoquant.ml` never fails for a research/backtest/simulation
install that has no interest in the ML models.

Leakage prevention (section 30: "Prevent data leakage.") is structural,
not a parameter you can forget to pass: :meth:`MLModel.fit` only ever sees
the row indices in the ``train`` :class:`~rhinoquant.research.splits.Split`
range you give it, and :meth:`MLModel.evaluate` refuses to score a split
whose ``validation``/``test`` range overlaps the fitted ``train`` range —
overlap is exactly what a chronologically-ordered feature matrix must
never have between the fit set and the set it is scored on.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from rhinoquant.research.splits import Split


class DataLeakageError(Exception):
    pass


@dataclass
class MLModel:
    """Wraps any scikit-learn-compatible estimator (``fit``/``predict``)
    with the task it targets, so a :class:`FeatureSnapshot`-derived
    feature matrix can be plugged into any of section 30's model
    categories interchangeably."""

    task: str
    estimator: Any
    _fitted_train_range: Optional[range] = None

    def fit(self, X, y, train_split: range) -> "MLModel":
        self.estimator.fit(X[list(train_split)], [y[i] for i in train_split])
        self._fitted_train_range = train_split
        return self

    def predict(self, X, indices: range):
        if self._fitted_train_range is None:
            raise RuntimeError(f"{self.task} model has not been fit yet")
        if set(indices) & set(self._fitted_train_range):
            raise DataLeakageError(
                f"requested prediction indices overlap the fitted training range for task={self.task!r}; "
                "refusing to score a model on rows it was trained on"
            )
        return self.estimator.predict(X[list(indices)])

    def fit_predict_split(self, X, y, split: Split) -> dict[str, Any]:
        self.fit(X, y, split.train)
        return {
            "validation": self.predict(X, split.validation),
            "test": self.predict(X, split.test),
        }


def _require_sklearn():
    try:
        import sklearn  # noqa: F401
    except ImportError as exc:  # pragma: no cover - exercised only without the optional extra
        raise ImportError(
            "scikit-learn is required for this model; install it with `pip install rhinoquant[ml]`"
        ) from exc


def feature_prediction_model(**kwargs) -> MLModel:
    _require_sklearn()
    from sklearn.linear_model import Ridge

    return MLModel(task="feature_prediction", estimator=Ridge(**kwargs))


def return_prediction_model(**kwargs) -> MLModel:
    _require_sklearn()
    from sklearn.linear_model import Ridge

    return MLModel(task="return_prediction", estimator=Ridge(**kwargs))


def volatility_prediction_model(**kwargs) -> MLModel:
    _require_sklearn()
    from sklearn.ensemble import GradientBoostingRegressor

    return MLModel(task="volatility_prediction", estimator=GradientBoostingRegressor(**kwargs))


def regime_classification_model(**kwargs) -> MLModel:
    _require_sklearn()
    from sklearn.ensemble import RandomForestClassifier

    return MLModel(task="regime_classification", estimator=RandomForestClassifier(**kwargs))


def execution_prediction_model(**kwargs) -> MLModel:
    _require_sklearn()
    from sklearn.linear_model import LogisticRegression

    return MLModel(task="execution_prediction", estimator=LogisticRegression(**kwargs))


def fill_probability_model(**kwargs) -> MLModel:
    _require_sklearn()
    from sklearn.linear_model import LogisticRegression

    return MLModel(task="fill_probability", estimator=LogisticRegression(**kwargs))


def slippage_estimation_model(**kwargs) -> MLModel:
    _require_sklearn()
    from sklearn.linear_model import Ridge

    return MLModel(task="slippage_estimation", estimator=Ridge(**kwargs))
