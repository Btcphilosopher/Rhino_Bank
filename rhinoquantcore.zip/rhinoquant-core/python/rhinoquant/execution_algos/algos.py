"""Execution algorithms (section 15): TWAP, VWAP, POV, Implementation
Shortfall, Adaptive. Each is implemented as a :class:`Strategy` so a parent
order is sliced into child :class:`OrderIntent` objects that flow through
the *same* risk -> OMS -> execution pathway as any other strategy — an
execution algo has no special bypass.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from rhinoquant.features.engine import FeatureSnapshot
from rhinoquant.schemas.fills import Fill
from rhinoquant.schemas.orders import Side
from rhinoquant.strategies.base import OrderIntent, Strategy


@dataclass
class ParentOrder:
    symbol: str
    side: Side
    total_quantity: float
    duration_ns: int
    portfolio_id: str = "execution_algo"


class _SlicingExecutionAlgo(Strategy):
    """Shared bookkeeping: tracks remaining quantity and elapsed time, and
    lets subclasses decide only *how much* to slice off on each timer
    tick via :meth:`_slice_quantity`.
    """

    strategy_id = "execution_algo"

    def __init__(self, parent: ParentOrder, n_slices: int = 20) -> None:
        super().__init__()
        self.parent = parent
        self.portfolio_id = parent.portfolio_id
        self.n_slices = max(1, n_slices)
        self.slice_interval_ns = max(1, parent.duration_ns // self.n_slices)
        self.remaining = parent.total_quantity
        self.filled = 0.0
        self._start_ns: Optional[int] = None
        self._last_slice_ns: Optional[int] = None
        self._slices_done = 0
        self._market_volume_since_last_slice = 0.0

    def on_trade(self, event) -> None:
        qty = event.payload.get("quantity")
        if qty:
            self._market_volume_since_last_slice += qty

    def on_fill(self, fill: Fill) -> None:
        self.filled += fill.quantity
        self.remaining = max(0.0, self.remaining - fill.quantity)

    def on_timer(self, timestamp_ns: int) -> None:
        if self.remaining <= 0:
            return
        if self._start_ns is None:
            self._start_ns = timestamp_ns
            self._last_slice_ns = timestamp_ns

        elapsed = timestamp_ns - self._start_ns
        if elapsed > self.parent.duration_ns:
            # final catch-up slice for whatever remains
            self._emit_slice(self.remaining)
            return

        if timestamp_ns - self._last_slice_ns < self.slice_interval_ns:
            return

        qty = min(self.remaining, self._slice_quantity(elapsed))
        if qty > 0:
            self._emit_slice(qty)
        self._last_slice_ns = timestamp_ns
        self._slices_done += 1
        self._market_volume_since_last_slice = 0.0

    def _emit_slice(self, quantity: float) -> None:
        self._submit(
            OrderIntent(
                strategy_id=self.strategy_id,
                portfolio_id=self.portfolio_id,
                symbol=self.parent.symbol,
                side=self.parent.side,
                quantity=quantity,
                tag=f"{self.strategy_id}_slice_{self._slices_done}",
            )
        )

    def _slice_quantity(self, elapsed_ns: int) -> float:  # pragma: no cover - abstract
        raise NotImplementedError


class TWAPExecutionAlgo(_SlicingExecutionAlgo):
    """Equal-sized slices spread evenly over the parent order's duration."""

    strategy_id = "twap"

    def _slice_quantity(self, elapsed_ns: int) -> float:
        return self.parent.total_quantity / self.n_slices


class VWAPExecutionAlgo(_SlicingExecutionAlgo):
    """Slices sized by a supplied historical volume-profile curve (weights
    per bucket, summing to 1.0) instead of even time slices."""

    strategy_id = "vwap"

    def __init__(self, parent: ParentOrder, volume_profile: list[float], n_slices: Optional[int] = None) -> None:
        super().__init__(parent, n_slices=n_slices or len(volume_profile))
        total_weight = sum(volume_profile) or 1.0
        self.weights = [w / total_weight for w in volume_profile]

    def _slice_quantity(self, elapsed_ns: int) -> float:
        idx = min(self._slices_done, len(self.weights) - 1)
        return self.parent.total_quantity * self.weights[idx]


class POVExecutionAlgo(_SlicingExecutionAlgo):
    """Participation-of-volume: each slice targets ``participation_rate``
    of the market volume traded since the previous slice."""

    strategy_id = "pov"

    def __init__(self, parent: ParentOrder, participation_rate: float = 0.1, n_slices: int = 50) -> None:
        super().__init__(parent, n_slices=n_slices)
        self.participation_rate = participation_rate

    def _slice_quantity(self, elapsed_ns: int) -> float:
        target = self._market_volume_since_last_slice * self.participation_rate
        # fall back to a TWAP-like minimum so the order still completes in
        # thin/no-volume conditions
        minimum = self.parent.total_quantity / self.n_slices
        return max(target, minimum)


class ImplementationShortfallAlgo(_SlicingExecutionAlgo):
    """Front-loads execution (higher urgency early) to trade off market
    impact against timing risk: slice size decays geometrically so more
    quantity trades near arrival price, less as time runs out.
    """

    strategy_id = "implementation_shortfall"

    def __init__(self, parent: ParentOrder, urgency: float = 0.3, n_slices: int = 20) -> None:
        super().__init__(parent, n_slices=n_slices)
        self.urgency = min(max(urgency, 0.01), 0.99)
        decay = 1.0 - self.urgency
        weights = [decay**i for i in range(self.n_slices)]
        total = sum(weights) or 1.0
        self.weights = [w / total for w in weights]

    def _slice_quantity(self, elapsed_ns: int) -> float:
        idx = min(self._slices_done, len(self.weights) - 1)
        return self.parent.total_quantity * self.weights[idx]


class AdaptiveExecutionAlgo(_SlicingExecutionAlgo):
    """POV-style participation that speeds up in calm/tight markets and
    slows down when spreads widen or volatility rises, using the live
    :class:`FeatureSnapshot`."""

    strategy_id = "adaptive"

    def __init__(
        self,
        parent: ParentOrder,
        base_participation_rate: float = 0.1,
        n_slices: int = 50,
        vol_sensitivity: float = 2.0,
    ) -> None:
        super().__init__(parent, n_slices=n_slices)
        self.base_participation_rate = base_participation_rate
        self.vol_sensitivity = vol_sensitivity
        self._features: Optional[FeatureSnapshot] = None
        self._reference_vol: Optional[float] = None

    def on_features(self, features: FeatureSnapshot) -> None:
        self._features = features
        if self._reference_vol is None and features.realised_volatility:
            self._reference_vol = features.realised_volatility

    def _slice_quantity(self, elapsed_ns: int) -> float:
        rate = self.base_participation_rate
        if self._features and self._features.realised_volatility and self._reference_vol:
            vol_ratio = self._features.realised_volatility / self._reference_vol
            rate = self.base_participation_rate / (1.0 + self.vol_sensitivity * max(0.0, vol_ratio - 1.0))
        target = self._market_volume_since_last_slice * rate
        minimum = self.parent.total_quantity / self.n_slices * 0.25
        return max(target, minimum)
