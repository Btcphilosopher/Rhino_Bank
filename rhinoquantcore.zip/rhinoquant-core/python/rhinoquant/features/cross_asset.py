"""Cross-asset feature hooks (section 11 / 14: pairs / stat-arb research).

Provides pairwise beta, correlation, a rolling spread z-score ("relative
value"), and lead/lag cross-correlation between two price streams. A full
cointegration test (Engle-Granger / Johansen) needs a statistics dependency
this project does not take on by default (section 3: "keep dependencies
controlled"); :meth:`CrossAssetFeatureEngine.cointegration_hook` computes
the OLS hedge ratio and residual series so a proper stationarity test
(ADF, etc.) can be plugged in later — it deliberately does not claim to
*be* one.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from rhinoquant.features.rolling import OnlineCovariance, RollingWindow


@dataclass
class CrossAssetSnapshot:
    symbol_a: str
    symbol_b: str
    beta: Optional[float]
    correlation: Optional[float]
    spread: Optional[float]
    spread_zscore: Optional[float]


class CrossAssetFeatureEngine:
    """Tracks a pair of price streams and derives relative-value features."""

    def __init__(self, symbol_a: str, symbol_b: str, spread_window: int = 500) -> None:
        self.symbol_a = symbol_a
        self.symbol_b = symbol_b
        self._cov = OnlineCovariance()
        self._spread_window = RollingWindow(spread_window)
        self._last_a: Optional[float] = None
        self._last_b: Optional[float] = None

    def push(self, price_a: Optional[float], price_b: Optional[float]) -> CrossAssetSnapshot:
        if price_a is not None:
            self._last_a = price_a
        if price_b is not None:
            self._last_b = price_b

        if self._last_a is not None and self._last_b is not None:
            self._cov.push(self._last_a, self._last_b)

        beta = self._cov.beta()
        correlation = self._cov.correlation()

        spread = None
        spread_z = None
        if self._last_a is not None and self._last_b is not None and beta is not None:
            spread = self._last_b - beta * self._last_a
            self._spread_window.push(spread)
            spread_z = self._spread_window.zscore(spread)

        return CrossAssetSnapshot(
            symbol_a=self.symbol_a,
            symbol_b=self.symbol_b,
            beta=beta,
            correlation=correlation,
            spread=spread,
            spread_zscore=spread_z,
        )

    def lead_lag_correlation(self, series_a: list[float], series_b: list[float], max_lag: int = 10) -> dict[int, float]:
        """Cross-correlation of ``series_b`` against lagged ``series_a`` for
        lags in ``[-max_lag, max_lag]``. Positive lag k means series_a leads
        series_b by k observations. Uses plain Pearson correlation per lag
        (O(max_lag * n)), fine at research data volumes.
        """
        import numpy as np

        a = np.asarray(series_a, dtype=float)
        b = np.asarray(series_b, dtype=float)
        n = min(len(a), len(b))
        a, b = a[:n], b[:n]
        result: dict[int, float] = {}
        for lag in range(-max_lag, max_lag + 1):
            if lag >= 0:
                x, y = a[: n - lag], b[lag:]
            else:
                x, y = a[-lag:], b[: n + lag]
            if len(x) < 3 or x.std() == 0 or y.std() == 0:
                continue
            result[lag] = float(np.corrcoef(x, y)[0, 1])
        return result

    def cointegration_hook(self) -> dict[str, Optional[float]]:
        """Returns the OLS hedge ratio (beta) and current residual (spread)
        used as inputs to an external stationarity test. This is a research
        *hook*, not a cointegration test result: it does not itself compute
        an ADF/Johansen statistic or a p-value.
        """
        return {
            "hedge_ratio": self._cov.beta(),
            "residual": self._spread_window.last(),
            "residual_std": self._spread_window.std(),
        }
