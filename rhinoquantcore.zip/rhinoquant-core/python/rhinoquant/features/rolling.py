"""Incremental statistical primitives used throughout the feature engine
(section 11: "Features should be incrementally updated wherever
practical.").

Each primitive updates in O(1) per observation rather than recomputing over
a stored window from scratch, with the exception of :class:`RollingWindow`
which keeps a bounded deque so exact windowed quantiles/mean/variance stay
available (its mean/variance updates are still O(1) amortised via a
running sum, only the eviction is a deque popleft).
"""
from __future__ import annotations

import math
from collections import deque
from typing import Optional


class RollingWindow:
    """Fixed-size rolling window with O(1) amortised mean/variance."""

    def __init__(self, size: int) -> None:
        if size <= 0:
            raise ValueError("size must be positive")
        self.size = size
        self._values: deque[float] = deque(maxlen=size)
        self._sum = 0.0
        self._sumsq = 0.0

    def push(self, x: float) -> None:
        if len(self._values) == self.size:
            oldest = self._values[0]
            self._sum -= oldest
            self._sumsq -= oldest * oldest
        self._values.append(x)
        self._sum += x
        self._sumsq += x * x

    def __len__(self) -> int:
        return len(self._values)

    def mean(self) -> Optional[float]:
        n = len(self._values)
        return self._sum / n if n else None

    def variance(self) -> Optional[float]:
        n = len(self._values)
        if n < 2:
            return None
        mean = self._sum / n
        var = self._sumsq / n - mean * mean
        return max(var, 0.0)

    def std(self) -> Optional[float]:
        var = self.variance()
        return math.sqrt(var) if var is not None else None

    def zscore(self, x: Optional[float] = None) -> Optional[float]:
        std = self.std()
        mean = self.mean()
        if std is None or mean is None or std == 0:
            return None
        target = self._values[-1] if x is None else x
        return (target - mean) / std

    def last(self) -> Optional[float]:
        return self._values[-1] if self._values else None

    def values(self) -> list[float]:
        return list(self._values)


class EWMA:
    """Exponentially weighted moving average / variance."""

    def __init__(self, alpha: float) -> None:
        if not (0 < alpha <= 1):
            raise ValueError("alpha must be in (0, 1]")
        self.alpha = alpha
        self._mean: Optional[float] = None
        self._var: float = 0.0
        self.n = 0

    def push(self, x: float) -> None:
        self.n += 1
        if self._mean is None:
            self._mean = x
            self._var = 0.0
            return
        diff = x - self._mean
        incr = self.alpha * diff
        self._mean += incr
        self._var = (1 - self.alpha) * (self._var + diff * incr)

    def mean(self) -> Optional[float]:
        return self._mean

    def std(self) -> Optional[float]:
        return math.sqrt(self._var) if self._var >= 0 else None


class RealizedVolatility:
    """Rolling realised volatility: sqrt of the sum of squared log returns
    over a fixed-size window, annualisation left to the caller (research
    context dependent)."""

    def __init__(self, size: int) -> None:
        self._returns = RollingWindow(size)
        self._last_price: Optional[float] = None

    def push_price(self, price: float) -> None:
        if self._last_price is not None and self._last_price > 0 and price > 0:
            ret = math.log(price / self._last_price)
            self._returns.push(ret)
        self._last_price = price

    def realised_vol(self) -> Optional[float]:
        if len(self._returns) < 2:
            return None
        std = self._returns.std()
        return std

    def returns(self) -> list[float]:
        return self._returns.values()


class OnlineCovariance:
    """Welford-style online covariance/correlation/beta between two
    streams, used for cross-asset features (section 11 / 14)."""

    def __init__(self) -> None:
        self.n = 0
        self._mean_x = 0.0
        self._mean_y = 0.0
        self._cxx = 0.0
        self._cyy = 0.0
        self._cxy = 0.0

    def push(self, x: float, y: float) -> None:
        self.n += 1
        dx = x - self._mean_x
        self._mean_x += dx / self.n
        dy = y - self._mean_y
        self._mean_y += dy / self.n
        self._cxx += dx * (x - self._mean_x)
        self._cyy += dy * (y - self._mean_y)
        self._cxy += dx * (y - self._mean_y)

    def covariance(self) -> Optional[float]:
        return self._cxy / (self.n - 1) if self.n > 1 else None

    def correlation(self) -> Optional[float]:
        if self.n < 2:
            return None
        denom = math.sqrt(self._cxx * self._cyy)
        return self._cxy / denom if denom > 0 else None

    def beta(self) -> Optional[float]:
        """Regression coefficient of y on x (y = beta * x + eps)."""
        if self.n < 2 or self._cxx == 0:
            return None
        return self._cxy / self._cxx
