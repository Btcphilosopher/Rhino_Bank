"""Streaming per-symbol feature engine (section 11).

Consumes order-book snapshots and trade prints incrementally and exposes a
single :class:`FeatureSnapshot` per update — the microstructure and
statistical features an :class:`~rhinoquant.alpha.base.AlphaModel` reads.

Caveats documented up front rather than glossed over (section 53 spirit —
no unsupported claims): this engine only ever sees market-by-price (L1/L2)
book state, not individual order IDs, so cancellation/replenishment rates
below are *proxies* (quantity change at the best level not explained by
observed trade volume), not ground-truth order-level cancel counts.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from rhinoquant.features.rolling import EWMA, OnlineCovariance, RealizedVolatility, RollingWindow
from rhinoquant.orderbook.book import LimitOrderBook


@dataclass
class FeatureSnapshot:
    symbol: str
    timestamp_ns: int

    # microstructure
    best_bid: Optional[float] = None
    best_ask: Optional[float] = None
    mid: Optional[float] = None
    microprice: Optional[float] = None
    spread: Optional[float] = None
    spread_ticks: Optional[float] = None
    imbalance_l1: Optional[float] = None
    imbalance_l5: Optional[float] = None
    order_flow_imbalance: Optional[float] = None
    trade_intensity: Optional[float] = None
    cancellation_intensity: Optional[float] = None
    replenishment_rate: Optional[float] = None
    price_impact: Optional[float] = None  # Kyle's-lambda-style: d(price) / signed volume
    short_term_momentum: Optional[float] = None
    mean_reversion_zscore: Optional[float] = None
    vwap: Optional[float] = None
    twap: Optional[float] = None
    volume_imbalance: Optional[float] = None

    # statistical
    rolling_mean: Optional[float] = None
    rolling_variance: Optional[float] = None
    ewma_mean: Optional[float] = None
    ewma_std: Optional[float] = None
    realised_volatility: Optional[float] = None
    volatility_of_volatility: Optional[float] = None
    zscore: Optional[float] = None


class FeatureEngine:
    """Single-symbol streaming feature computation.

    Call :meth:`on_book` after every order-book update and :meth:`on_trade`
    after every trade print, then :meth:`snapshot` to read the current
    feature vector. All internal state updates are O(1) per event.
    """

    def __init__(
        self,
        symbol: str,
        tick_size: float = 0.01,
        momentum_window: int = 50,
        mean_reversion_window: int = 200,
        vol_window: int = 200,
        vol_of_vol_window: int = 50,
        trade_rate_window: int = 100,
        ewma_alpha: float = 0.05,
    ) -> None:
        self.symbol = symbol
        self.tick_size = tick_size

        self._mid_window = RollingWindow(momentum_window)
        self._mean_reversion_window = RollingWindow(mean_reversion_window)
        self._realised_vol = RealizedVolatility(vol_window)
        self._vol_of_vol = RollingWindow(vol_of_vol_window)
        self._ewma = EWMA(ewma_alpha)

        self._trade_timestamps: RollingWindow = RollingWindow(trade_rate_window)
        self._trade_price_qty_signed: list[tuple[float, float]] = []  # (price, signed_qty)

        self._vwap_num = 0.0
        self._vwap_den = 0.0
        self._twap_num = 0.0
        self._twap_den = 0.0
        self._last_trade_ts: Optional[int] = None

        self._buy_volume = 0.0
        self._sell_volume = 0.0

        self._prev_best_bid: Optional[float] = None
        self._prev_best_bid_qty: Optional[float] = None
        self._prev_best_ask: Optional[float] = None
        self._prev_best_ask_qty: Optional[float] = None
        self._cum_ofi = 0.0

        self._pending_trade_consumption_bid = 0.0
        self._pending_trade_consumption_ask = 0.0
        self._cancel_intensity_ewma = EWMA(0.1)
        self._replenish_intensity_ewma = EWMA(0.1)

        self._last_snapshot: Optional[FeatureSnapshot] = None
        self._realised_vol_history_last: Optional[float] = None

    # ------------------------------------------------------------------ #
    def on_trade(self, price: float, quantity: float, aggressor_side: str, timestamp_ns: int) -> None:
        signed_qty = quantity if aggressor_side == "BUY" else -quantity
        if aggressor_side == "BUY":
            self._buy_volume += quantity
            self._pending_trade_consumption_ask += quantity
        else:
            self._sell_volume += quantity
            self._pending_trade_consumption_bid += quantity

        self._vwap_num += price * quantity
        self._vwap_den += quantity

        if self._last_trade_ts is not None:
            dt = max(timestamp_ns - self._last_trade_ts, 1)
            self._twap_num += price * dt
            self._twap_den += dt
        self._last_trade_ts = timestamp_ns

        self._trade_timestamps.push(float(timestamp_ns))
        self._trade_price_qty_signed.append((price, signed_qty))
        if len(self._trade_price_qty_signed) > 500:
            self._trade_price_qty_signed.pop(0)

    def on_book(self, book: LimitOrderBook, timestamp_ns: int) -> FeatureSnapshot:
        bb, ba = book.best_bid(), book.best_ask()
        mid = book.mid()
        micro = book.microprice()
        spread = book.spread()

        if mid is not None:
            self._mid_window.push(mid)
            self._mean_reversion_window.push(mid)
            self._realised_vol.push_price(mid)
            self._ewma.push(mid)
            rv = self._realised_vol.realised_vol()
            if rv is not None:
                self._vol_of_vol.push(rv)

        bbq = book.best_bid_quantity()
        baq = book.best_ask_quantity()
        self._update_ofi(bb, bbq, ba, baq)

        momentum = None
        if len(self._mid_window) >= 2 and mid is not None:
            first = self._mid_window.values()[0]
            if first:
                momentum = (mid - first) / first

        mean_rev_z = self._mean_reversion_window.zscore(mid) if mid is not None else None

        n_trades = len(self._trade_timestamps)
        trade_intensity = None
        if n_trades >= 2:
            span_ns = self._trade_timestamps.values()[-1] - self._trade_timestamps.values()[0]
            if span_ns > 0:
                trade_intensity = (n_trades - 1) / (span_ns / 1e9)  # trades / second

        price_impact = self._estimate_price_impact()

        total_vol = self._buy_volume + self._sell_volume
        vol_imbalance = (self._buy_volume - self._sell_volume) / total_vol if total_vol > 0 else None

        snap = FeatureSnapshot(
            symbol=self.symbol,
            timestamp_ns=timestamp_ns,
            best_bid=bb,
            best_ask=ba,
            mid=mid,
            microprice=micro,
            spread=spread,
            spread_ticks=(spread / self.tick_size) if spread is not None else None,
            imbalance_l1=book.imbalance(1),
            imbalance_l5=book.imbalance(5),
            order_flow_imbalance=self._cum_ofi,
            trade_intensity=trade_intensity,
            cancellation_intensity=self._cancel_intensity_ewma.mean(),
            replenishment_rate=self._replenish_intensity_ewma.mean(),
            price_impact=price_impact,
            short_term_momentum=momentum,
            mean_reversion_zscore=mean_rev_z,
            vwap=(self._vwap_num / self._vwap_den) if self._vwap_den > 0 else None,
            twap=(self._twap_num / self._twap_den) if self._twap_den > 0 else None,
            volume_imbalance=vol_imbalance,
            rolling_mean=self._mid_window.mean(),
            rolling_variance=self._mid_window.variance(),
            ewma_mean=self._ewma.mean(),
            ewma_std=self._ewma.std(),
            realised_volatility=self._realised_vol.realised_vol(),
            volatility_of_volatility=self._vol_of_vol.std(),
            zscore=self._mid_window.zscore(mid) if mid is not None else None,
        )
        self._last_snapshot = snap
        return snap

    def snapshot(self) -> Optional[FeatureSnapshot]:
        return self._last_snapshot

    # ------------------------------------------------------------------ #
    def _update_ofi(
        self,
        bb: Optional[float],
        bbq: Optional[float],
        ba: Optional[float],
        baq: Optional[float],
    ) -> None:
        """Cont-Kukanov-Stoikov style order-flow imbalance at the best
        level, netted against trade-implied consumption so a level that
        shrank purely because it traded is not double-counted as a
        cancellation.
        """
        e_bid = 0.0
        if bb is not None and bbq is not None:
            if self._prev_best_bid is None:
                e_bid = 0.0
            elif bb > self._prev_best_bid:
                e_bid = bbq
            elif bb == self._prev_best_bid:
                e_bid = bbq - (self._prev_best_bid_qty or 0.0)
            else:
                e_bid = -(self._prev_best_bid_qty or 0.0)

            non_trade_delta = e_bid + self._pending_trade_consumption_bid
            if non_trade_delta < 0:
                self._cancel_intensity_ewma.push(-non_trade_delta)
            elif non_trade_delta > 0:
                self._replenish_intensity_ewma.push(non_trade_delta)
            self._pending_trade_consumption_bid = 0.0

        e_ask = 0.0
        if ba is not None and baq is not None:
            if self._prev_best_ask is None:
                e_ask = 0.0
            elif ba < self._prev_best_ask:
                e_ask = baq
            elif ba == self._prev_best_ask:
                e_ask = baq - (self._prev_best_ask_qty or 0.0)
            else:
                e_ask = -(self._prev_best_ask_qty or 0.0)

            non_trade_delta = e_ask + self._pending_trade_consumption_ask
            if non_trade_delta < 0:
                self._cancel_intensity_ewma.push(-non_trade_delta)
            elif non_trade_delta > 0:
                self._replenish_intensity_ewma.push(non_trade_delta)
            self._pending_trade_consumption_ask = 0.0

        self._cum_ofi += e_bid - e_ask
        self._prev_best_bid, self._prev_best_bid_qty = bb, bbq
        self._prev_best_ask, self._prev_best_ask_qty = ba, baq

    def _estimate_price_impact(self) -> Optional[float]:
        """OLS slope of mid-price change on signed trade volume over the
        recent trade tape (a simple Kyle's-lambda-style estimate)."""
        if len(self._trade_price_qty_signed) < 5:
            return None
        cov = OnlineCovariance()
        prices = [p for p, _ in self._trade_price_qty_signed]
        signed_qtys = [q for _, q in self._trade_price_qty_signed]
        for i in range(1, len(prices)):
            dp = prices[i] - prices[i - 1]
            cov.push(signed_qtys[i], dp)
        return cov.beta()
