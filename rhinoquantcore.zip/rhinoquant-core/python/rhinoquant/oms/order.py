"""Order state machine (section 19).

    NEW -> ACK -> PARTIAL_FILL -> FILL
              \\-> REJECT
    ACK -> CANCEL -> CANCEL_ACK
    ACK/PARTIAL_FILL -> REPLACE
    NEW/ACK -> EXPIRE

:data:`ALLOWED_TRANSITIONS` is the single source of truth for legal status
changes; :func:`transition` is the only way an :class:`Order`'s status
should ever change, so a transition can never be silently skipped or lost
(section 19: "Never lose state transitions.").
"""
from __future__ import annotations

from rhinoquant.core.errors import OrderStateError
from rhinoquant.core.ids import now_ns
from rhinoquant.core.utils import enum_value
from rhinoquant.schemas.orders import Order, OrderStatus

ALLOWED_TRANSITIONS: dict[OrderStatus, set[OrderStatus]] = {
    OrderStatus.NEW: {OrderStatus.ACK, OrderStatus.REJECT},
    OrderStatus.ACK: {
        OrderStatus.PARTIAL_FILL,
        OrderStatus.FILL,
        OrderStatus.CANCEL,
        OrderStatus.REPLACE,
        OrderStatus.EXPIRE,
    },
    OrderStatus.PARTIAL_FILL: {
        OrderStatus.PARTIAL_FILL,
        OrderStatus.FILL,
        OrderStatus.CANCEL,
        OrderStatus.REPLACE,
        OrderStatus.EXPIRE,
    },
    OrderStatus.REPLACE: {
        OrderStatus.ACK,
        OrderStatus.PARTIAL_FILL,
        OrderStatus.FILL,
        OrderStatus.CANCEL,
        OrderStatus.EXPIRE,
    },
    OrderStatus.CANCEL: {OrderStatus.CANCEL_ACK},
    OrderStatus.CANCEL_ACK: set(),
    OrderStatus.FILL: set(),
    OrderStatus.REJECT: set(),
    OrderStatus.EXPIRE: set(),
}


def transition(order: Order, new_status: OrderStatus, timestamp_ns: int | None = None, **updates) -> Order:
    """Return a *new* :class:`Order` with ``new_status`` applied, after
    validating the transition is legal from ``order.status``. Orders are
    immutable pydantic models; callers persist the returned copy.
    """
    allowed = ALLOWED_TRANSITIONS.get(order.status, set())
    if new_status not in allowed:
        raise OrderStateError(
            f"illegal order transition {enum_value(order.status)} -> {enum_value(new_status)} "
            f"for client_order_id={order.client_order_id}"
        )
    ts = timestamp_ns if timestamp_ns is not None else now_ns()
    return order.model_copy(update={"status": new_status, "updated_ns": ts, **updates})
