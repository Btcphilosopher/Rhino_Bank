"""Order Management System (section 19).

Owns the authoritative :class:`Order` record for every ``client_order_id``
and an append-only transition log so no state change is ever lost —
:meth:`OrderManager.history` replays exactly what happened to an order,
which is what the audit engine (section 34) and correlation-ID tracing
(section 41) build on.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from rhinoquant.core.ids import new_client_order_id, now_ns
from rhinoquant.oms.order import transition
from rhinoquant.schemas.orders import Order, OrderStatus
from rhinoquant.strategies.base import OrderIntent


@dataclass
class OrderTransitionRecord:
    client_order_id: str
    status: OrderStatus
    timestamp_ns: int
    detail: Optional[str] = None


class OrderManager:
    def __init__(self) -> None:
        self._orders: dict[str, Order] = {}
        self._history: dict[str, list[OrderTransitionRecord]] = {}

    def create_order(self, intent: OrderIntent, timestamp_ns: Optional[int] = None) -> Order:
        ts = timestamp_ns if timestamp_ns is not None else now_ns()
        client_order_id = new_client_order_id()
        order = Order(
            client_order_id=client_order_id,
            strategy_id=intent.strategy_id,
            portfolio_id=intent.portfolio_id,
            symbol=intent.symbol,
            side=intent.side,
            order_type=intent.order_type,
            time_in_force=intent.time_in_force,
            price=intent.price,
            quantity=intent.quantity,
            remaining_quantity=intent.quantity,
            status=OrderStatus.NEW,
            created_ns=ts,
            updated_ns=ts,
            correlation_id=intent.correlation_id,
        )
        self._orders[client_order_id] = order
        self._record(client_order_id, OrderStatus.NEW, ts)
        return order

    def reject(self, client_order_id: str, reason: str, timestamp_ns: Optional[int] = None) -> Order:
        return self._apply(client_order_id, OrderStatus.REJECT, timestamp_ns, reject_reason=reason)

    def ack(self, client_order_id: str, exchange_order_id: str, timestamp_ns: Optional[int] = None) -> Order:
        return self._apply(client_order_id, OrderStatus.ACK, timestamp_ns, exchange_order_id=exchange_order_id)

    def apply_fill(self, client_order_id: str, fill_quantity: float, timestamp_ns: Optional[int] = None) -> Order:
        order = self._require(client_order_id)
        new_filled = order.filled_quantity + fill_quantity
        remaining = max(0.0, order.quantity - new_filled)
        status = OrderStatus.FILL if remaining <= 1e-9 else OrderStatus.PARTIAL_FILL
        return self._apply(
            client_order_id,
            status,
            timestamp_ns,
            filled_quantity=new_filled,
            remaining_quantity=remaining,
        )

    def cancel_request(self, client_order_id: str, timestamp_ns: Optional[int] = None) -> Order:
        return self._apply(client_order_id, OrderStatus.CANCEL, timestamp_ns)

    def cancel_ack(self, client_order_id: str, timestamp_ns: Optional[int] = None) -> Order:
        return self._apply(client_order_id, OrderStatus.CANCEL_ACK, timestamp_ns)

    def expire(self, client_order_id: str, timestamp_ns: Optional[int] = None) -> Order:
        return self._apply(client_order_id, OrderStatus.EXPIRE, timestamp_ns)

    def replace(self, client_order_id: str, timestamp_ns: Optional[int] = None, **updates) -> Order:
        return self._apply(client_order_id, OrderStatus.REPLACE, timestamp_ns, **updates)

    # ------------------------------------------------------------------ #
    def get(self, client_order_id: str) -> Optional[Order]:
        return self._orders.get(client_order_id)

    def all_orders(self) -> list[Order]:
        return list(self._orders.values())

    def open_orders(self) -> list[Order]:
        open_statuses = {OrderStatus.NEW, OrderStatus.ACK, OrderStatus.PARTIAL_FILL}
        return [o for o in self._orders.values() if o.status in open_statuses]

    def history(self, client_order_id: str) -> list[OrderTransitionRecord]:
        return list(self._history.get(client_order_id, []))

    # ------------------------------------------------------------------ #
    def _require(self, client_order_id: str) -> Order:
        order = self._orders.get(client_order_id)
        if order is None:
            raise KeyError(f"unknown client_order_id: {client_order_id}")
        return order

    def _apply(self, client_order_id: str, status: OrderStatus, timestamp_ns: Optional[int], **updates) -> Order:
        order = self._require(client_order_id)
        ts = timestamp_ns if timestamp_ns is not None else now_ns()
        new_order = transition(order, status, ts, **updates)
        self._orders[client_order_id] = new_order
        self._record(client_order_id, status, ts, updates.get("reject_reason"))
        return new_order

    def _record(self, client_order_id: str, status: OrderStatus, ts: int, detail: Optional[str] = None) -> None:
        self._history.setdefault(client_order_id, []).append(
            OrderTransitionRecord(client_order_id=client_order_id, status=status, timestamp_ns=ts, detail=detail)
        )
