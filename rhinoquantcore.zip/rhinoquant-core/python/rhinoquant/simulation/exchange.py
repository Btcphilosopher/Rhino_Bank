"""Simulated exchange (section 21).

Models limit and market orders, partial fills, queue position (via
:meth:`LimitOrderBook.register_own_order`/``queue_position``), configurable
per-stage latency, taker fees / maker rebates, and cancellation. Slippage
and market impact are emergent from matching against the live synthetic
book depth rather than a separate hard-coded model: a marketable order
that outsizes the top level walks the book and pays the worse price on the
remainder, exactly as a real venue would.

What this does **not** claim to model: real exchange queue-jump rules
beyond simple price/time priority, or adverse selection as a first-class
mechanism (that is a *measurement* — a markout of fill price vs. subsequent
mid — computed in :mod:`rhinoquant.analytics.performance`, not something
the matching engine itself injects).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from rhinoquant.config import LatencyConfig
from rhinoquant.core.ids import new_client_order_id
from rhinoquant.core.utils import enum_value
from rhinoquant.execution.base import ExecutionReport
from rhinoquant.orderbook.book import LimitOrderBook
from rhinoquant.schemas.fills import Fill
from rhinoquant.schemas.orders import Order, OrderType, Side, TimeInForce


@dataclass
class RestingOrder:
    order: Order
    remaining: float


@dataclass
class ExchangeFeeConfig:
    taker_fee_bps: float = 1.0
    maker_rebate_bps: float = 0.2  # paid TO the maker (reduces net cost)


class SimulatedExchange:
    """A single-symbol matching engine sitting on top of a
    :class:`LimitOrderBook`. One instance per symbol; the engine
    orchestrator owns one per traded instrument.
    """

    def __init__(
        self,
        symbol: str,
        book: LimitOrderBook,
        latency: Optional[LatencyConfig] = None,
        fees: Optional[ExchangeFeeConfig] = None,
    ) -> None:
        self.symbol = symbol
        self.book = book
        self.latency = latency or LatencyConfig()
        self.fees = fees or ExchangeFeeConfig()
        self._resting: dict[str, RestingOrder] = {}
        self._fill_seq = 0

    # ------------------------------------------------------------------ #
    def submit(self, order: Order, timestamp_ns: int) -> ExecutionReport:
        ack_ts = timestamp_ns + int(self.latency.exchange_ack_us * 1_000)
        exchange_order_id = new_client_order_id()
        fills: list[Fill] = []
        remaining = order.quantity

        if order.order_type == OrderType.MARKET or self._is_marketable(order):
            remaining, taker_fills = self._match_aggressively(order, remaining, ack_ts)
            fills.extend(taker_fills)

        if remaining > 1e-9:
            if order.order_type == OrderType.MARKET or order.time_in_force in (TimeInForce.IOC, TimeInForce.FOK):
                # unfilled remainder is cancelled, not rested
                remaining = 0.0 if order.time_in_force == TimeInForce.FOK and fills else remaining
            else:
                rest_price = order.price if order.price is not None else self._reference_price(order.side)
                if rest_price is not None:
                    ahead = self.book.register_own_order(exchange_order_id, enum_value(order.side), rest_price, remaining)
                    self._resting[exchange_order_id] = RestingOrder(
                        order=order.model_copy(update={"price": rest_price, "exchange_order_id": exchange_order_id}),
                        remaining=remaining,
                    )
                    _ = ahead  # available via book.queue_position(exchange_order_id) for callers

        return ExecutionReport(accepted=True, exchange_order_id=exchange_order_id, ack_timestamp_ns=ack_ts, fills=fills)

    def cancel(self, exchange_order_id: str, timestamp_ns: int) -> ExecutionReport:
        resting = self._resting.pop(exchange_order_id, None)
        if resting is None:
            return ExecutionReport(accepted=False, reject_reason="unknown or already-filled order")
        self.book.remove_own_order(exchange_order_id)
        return ExecutionReport(accepted=True, exchange_order_id=exchange_order_id)

    def replace(self, exchange_order_id: str, timestamp_ns: int, new_price: Optional[float] = None, new_quantity: Optional[float] = None) -> ExecutionReport:
        resting = self._resting.get(exchange_order_id)
        if resting is None:
            return ExecutionReport(accepted=False, reject_reason="unknown or already-filled order")
        cancel_report = self.cancel(exchange_order_id, timestamp_ns)
        if not cancel_report.accepted:
            return cancel_report
        updated = resting.order.model_copy(
            update={
                "price": new_price if new_price is not None else resting.order.price,
                "quantity": new_quantity if new_quantity is not None else resting.remaining,
            }
        )
        return self.submit(updated, timestamp_ns)

    def on_market_trade(self, price: float, quantity: float, aggressor_side: str, timestamp_ns: int) -> list[Fill]:
        """Deplete queue position for resting own orders on the passive
        side of an observed market trade, generating maker fills for
        whatever quantity clears our queue position at that exact price.
        """
        self.book.on_trade(price, quantity, aggressor_side)
        fills: list[Fill] = []
        passive_side = Side.SELL.value if aggressor_side == "BUY" else Side.BUY.value

        for exch_id, resting in list(self._resting.items()):
            if resting.order.price != price or enum_value(resting.order.side) != passive_side:
                continue
            try:
                ahead = self.book.queue_position(exch_id)
            except KeyError:
                continue
            if ahead <= 0:
                fill_qty = min(resting.remaining, quantity)
                if fill_qty > 0:
                    fills.append(self._make_fill(resting.order, exch_id, price, fill_qty, timestamp_ns, maker=True))
                    resting.remaining -= fill_qty
                    if resting.remaining <= 1e-9:
                        self._resting.pop(exch_id, None)
                        self.book.remove_own_order(exch_id)
        return fills

    # ------------------------------------------------------------------ #
    def _is_marketable(self, order: Order) -> bool:
        if order.price is None:
            return False
        if order.side == Side.BUY:
            best_ask = self.book.best_ask()
            return best_ask is not None and order.price >= best_ask
        best_bid = self.book.best_bid()
        return best_bid is not None and order.price <= best_bid

    def _reference_price(self, side: Side) -> Optional[float]:
        return self.book.best_bid() if side == Side.SELL else self.book.best_ask()

    def _match_aggressively(self, order: Order, remaining: float, timestamp_ns: int) -> tuple[float, list[Fill]]:
        fills: list[Fill] = []
        levels = self.book.depth(levels=50)
        opposite = levels["asks"] if order.side == Side.BUY else levels["bids"]
        limit_price = order.price

        for level_price, level_qty in opposite:
            if remaining <= 1e-9:
                break
            if order.order_type != OrderType.MARKET and limit_price is not None:
                if order.side == Side.BUY and level_price > limit_price:
                    break
                if order.side == Side.SELL and level_price < limit_price:
                    break
            trade_qty = min(remaining, level_qty)
            if trade_qty <= 0:
                continue
            fills.append(self._make_fill(order, None, level_price, trade_qty, timestamp_ns, maker=False))
            remaining -= trade_qty
            # reflect the consumption in the book itself
            if order.side == Side.BUY:
                self.book.update_ask(level_price, level_qty - trade_qty)
            else:
                self.book.update_bid(level_price, level_qty - trade_qty)

        return remaining, fills

    def _make_fill(self, order: Order, exchange_order_id: Optional[str], price: float, quantity: float, timestamp_ns: int, maker: bool) -> Fill:
        self._fill_seq += 1
        notional = price * quantity
        if maker:
            fee = -notional * self.fees.maker_rebate_bps / 10_000  # negative fee = rebate paid to us
            flag = "MAKER"
        else:
            fee = notional * self.fees.taker_fee_bps / 10_000
            flag = "TAKER"
        return Fill(
            fill_id=f"fill_{self.symbol}_{self._fill_seq}",
            client_order_id=order.client_order_id,
            exchange_order_id=exchange_order_id or order.exchange_order_id,
            strategy_id=order.strategy_id,
            portfolio_id=order.portfolio_id,
            symbol=order.symbol,
            side=order.side,
            price=price,
            quantity=quantity,
            fee=max(fee, 0.0),
            rebate=max(-fee, 0.0),
            liquidity_flag=flag,
            timestamp_ns=timestamp_ns,
            correlation_id=order.correlation_id,
        )
