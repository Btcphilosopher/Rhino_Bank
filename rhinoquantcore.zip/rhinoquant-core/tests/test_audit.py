from rhinoquant.audit.log import AuditLog


def test_hash_chain_verifies_clean():
    log = AuditLog()
    log.record("orders", {"event": "created"})
    log.record("fills", {"event": "filled"})
    log.record("system_events", {"event": "shutdown"})
    assert log.verify_chain() is True


def test_tampering_breaks_the_chain():
    log = AuditLog()
    log.record("orders", {"event": "created"})
    log.record("fills", {"event": "filled"})
    log._records[0].payload["event"] = "tampered"  # simulate direct mutation
    assert log.verify_chain() is False


def test_records_filterable_by_category():
    log = AuditLog()
    log.record("orders", {"n": 1})
    log.record("fills", {"n": 2})
    log.record("orders", {"n": 3})
    assert len(log.records("orders")) == 2
    assert len(log.records("fills")) == 1
