from rhinoquant.features.engine import FeatureEngine
from rhinoquant.features.rolling import EWMA, OnlineCovariance, RealizedVolatility, RollingWindow
from rhinoquant.orderbook.book import LimitOrderBook


def test_rolling_window_mean_and_variance():
    w = RollingWindow(3)
    for x in (1, 2, 3):
        w.push(x)
    assert w.mean() == 2.0
    assert w.variance() > 0
    w.push(4)  # evicts the 1
    assert w.mean() == 3.0


def test_ewma_converges_toward_a_constant_input():
    ewma = EWMA(alpha=0.5)
    for _ in range(50):
        ewma.push(10.0)
    assert abs(ewma.mean() - 10.0) < 1e-6


def test_realized_volatility_zero_for_constant_price():
    rv = RealizedVolatility(size=20)
    for _ in range(10):
        rv.push_price(100.0)
    assert rv.realised_vol() == 0.0


def test_online_covariance_perfect_correlation():
    cov = OnlineCovariance()
    for x in range(1, 20):
        cov.push(x, 2 * x)
    assert abs(cov.correlation() - 1.0) < 1e-9
    assert abs(cov.beta() - 2.0) < 1e-9


def test_feature_engine_produces_microstructure_snapshot():
    fe = FeatureEngine(symbol="RHINO", tick_size=0.01)
    book = LimitOrderBook("RHINO")
    book.update_bid(100.00, 500)
    book.update_ask(100.02, 300)
    snap = fe.on_book(book, timestamp_ns=0)
    assert snap.best_bid == 100.00
    assert snap.best_ask == 100.02
    assert snap.spread is not None and snap.spread > 0
    assert snap.imbalance_l1 == (500 - 300) / 800

    fe.on_trade(price=100.02, quantity=50, aggressor_side="BUY", timestamp_ns=1)
    snap2 = fe.on_book(book, timestamp_ns=2)
    assert snap2.vwap == 100.02
