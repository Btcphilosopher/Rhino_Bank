import json

from rhinoquant.schemas import MarketSnapshot, Order, OrderStatus, Side, SystemStatus


def test_market_snapshot_round_trips_through_json():
    snap = MarketSnapshot(symbol="RHINO", timestamp_ns=123, best_bid=100.0, best_ask=100.02)
    data = snap.to_json_dict()
    # must be plain-JSON-serialisable with no custom encoder (section 6)
    reencoded = json.loads(json.dumps(data))
    restored = MarketSnapshot.model_validate(reencoded)
    assert restored == snap
    assert data["is_synthetic"] is True


def test_schema_version_present_and_stable():
    snap = MarketSnapshot(symbol="RHINO", timestamp_ns=0)
    assert snap.to_json_dict()["schema_version"] == "v1"


def test_order_schema_defaults_and_status_enum_value():
    order = Order(
        client_order_id="c1",
        strategy_id="s1",
        portfolio_id="p1",
        symbol="RHINO",
        side=Side.BUY,
        quantity=10,
        created_ns=0,
        updated_ns=0,
    )
    assert order.status == OrderStatus.NEW
    assert order.to_json_dict()["status"] == "NEW"


def test_system_status_carries_api_version():
    status = SystemStatus(status="READY", environment="simulation", engine_version="0.1.0", uptime_ns=0)
    assert status.api_version == "v1"
