from rhinoquant.risk.kill_switch import KillSwitchEngine, KillSwitchKind


def test_inactive_switch_reports_none():
    engine = KillSwitchEngine()
    assert engine.any_active_for("s1", "p1", "SIM") is None


def test_strategy_kill_only_blocks_that_strategy():
    engine = KillSwitchEngine()
    engine.activate(KillSwitchKind.STRATEGY, "s1", "bad behaviour")
    assert engine.any_active_for("s1", "p1", "SIM") is not None
    assert engine.any_active_for("s2", "p1", "SIM") is None


def test_global_kill_blocks_everything():
    engine = KillSwitchEngine()
    engine.activate(KillSwitchKind.GLOBAL, "GLOBAL", "emergency stop")
    assert engine.any_active_for("s1", "p1", "SIM") is not None
    assert engine.any_active_for("s2", "p2", "OTHER_VENUE") is not None


def test_deactivate_restores_new_order_flow():
    engine = KillSwitchEngine()
    engine.activate(KillSwitchKind.STRATEGY, "s1", "test")
    assert engine.any_active_for("s1", "p1", "SIM") is not None
    engine.deactivate(KillSwitchKind.STRATEGY, "s1")
    assert engine.any_active_for("s1", "p1", "SIM") is None


def test_active_switches_lists_labels():
    engine = KillSwitchEngine()
    engine.activate(KillSwitchKind.VENUE, "SIM", "venue issue")
    labels = engine.active_switches()
    assert labels == ["VENUE:SIM"]
