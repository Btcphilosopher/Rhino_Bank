from rhinoquant.config import EngineConfig, Environment
from rhinoquant.engine import RhinoQuantEngine, SimulationOptions


def _run(seed: int, n_events: int = 800):
    cfg = EngineConfig.default(environment=Environment.SIMULATION)
    cfg.seed = seed
    engine = RhinoQuantEngine(cfg)
    _, report = engine.run_simulation(SimulationOptions(symbol="RHINO", n_events=n_events))
    return report.result


def test_same_seed_produces_identical_deterministic_hash():
    result_a = _run(seed=7)
    result_b = _run(seed=7)
    assert result_a.deterministic_hash == result_b.deterministic_hash
    assert result_a.events_processed == result_b.events_processed
    assert result_a.orders_submitted == result_b.orders_submitted
    assert result_a.net_pnl == result_b.net_pnl


def test_different_seed_produces_a_different_deterministic_hash():
    result_a = _run(seed=7)
    result_b = _run(seed=8)
    assert result_a.deterministic_hash != result_b.deterministic_hash


def test_result_is_explicitly_labelled_synthetic():
    result = _run(seed=1)
    assert result.is_synthetic_data is True
