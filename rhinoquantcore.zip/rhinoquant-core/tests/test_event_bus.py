from rhinoquant.core.events import Event, EventBus, EventType


def test_events_dispatch_in_timestamp_order_regardless_of_publish_order():
    bus = EventBus()
    order_seen = []
    bus.subscribe_all(lambda e: order_seen.append(e.payload["tag"]))

    bus.publish(Event(event_type=EventType.MARKET, timestamp_ns=30, payload={"tag": "c"}))
    bus.publish(Event(event_type=EventType.MARKET, timestamp_ns=10, payload={"tag": "a"}))
    bus.publish(Event(event_type=EventType.MARKET, timestamp_ns=20, payload={"tag": "b"}))
    bus.drain()

    assert order_seen == ["a", "b", "c"]


def test_same_timestamp_events_preserve_publish_order():
    bus = EventBus()
    seen = []
    bus.subscribe_all(lambda e: seen.append(e.payload["tag"]))
    for tag in ("first", "second", "third"):
        bus.publish(Event(event_type=EventType.MARKET, timestamp_ns=100, payload={"tag": tag}))
    bus.drain()
    assert seen == ["first", "second", "third"]


def test_type_specific_subscribers_only_see_their_event_type():
    bus = EventBus()
    trades = []
    quotes = []
    bus.subscribe(EventType.TRADE, lambda e: trades.append(e))
    bus.subscribe(EventType.QUOTE, lambda e: quotes.append(e))
    bus.publish(Event(event_type=EventType.TRADE, timestamp_ns=1))
    bus.publish(Event(event_type=EventType.QUOTE, timestamp_ns=2))
    bus.drain()
    assert len(trades) == 1
    assert len(quotes) == 1


def test_drain_returns_dispatched_count_and_empties_queue():
    bus = EventBus()
    for i in range(5):
        bus.publish(Event(event_type=EventType.SYSTEM, timestamp_ns=i))
    dispatched = bus.drain()
    assert dispatched == 5
    assert bus.pending() == 0
    assert bus.dispatched_count == 5
