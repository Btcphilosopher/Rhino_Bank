import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from rhinoquant.analytics.pnl import DuplicateFillError, PnLAccount
from rhinoquant.schemas.fills import Fill
from rhinoquant.schemas.orders import Side


def make_fill(fill_id: str, side: Side, price: float, quantity: float) -> Fill:
    return Fill(
        fill_id=fill_id,
        client_order_id="c1",
        strategy_id="s1",
        portfolio_id="p1",
        symbol="RHINO",
        side=side,
        price=price,
        quantity=quantity,
        timestamp_ns=0,
    )


def test_opening_a_long_position_sets_average_price():
    account = PnLAccount(strategy_id="s1", symbol="RHINO")
    account.apply_fill(make_fill("f1", Side.BUY, 100.0, 10))
    assert account.quantity == 10
    assert account.average_price == 100.0
    assert account.realised_pnl == 0.0


def test_adding_to_a_long_position_blends_average_price():
    account = PnLAccount(strategy_id="s1", symbol="RHINO")
    account.apply_fill(make_fill("f1", Side.BUY, 100.0, 10))
    account.apply_fill(make_fill("f2", Side.BUY, 110.0, 10))
    assert account.quantity == 20
    assert account.average_price == pytest.approx(105.0)


def test_partial_close_realises_pnl_and_keeps_average_price():
    account = PnLAccount(strategy_id="s1", symbol="RHINO")
    account.apply_fill(make_fill("f1", Side.BUY, 100.0, 10))
    account.apply_fill(make_fill("f2", Side.SELL, 110.0, 4))
    assert account.quantity == 6
    assert account.average_price == pytest.approx(100.0)  # unchanged for the remaining long
    assert account.realised_pnl == pytest.approx(4 * (110.0 - 100.0))


def test_flip_through_zero_opens_fresh_position_at_fill_price():
    account = PnLAccount(strategy_id="s1", symbol="RHINO")
    account.apply_fill(make_fill("f1", Side.BUY, 100.0, 10))
    account.apply_fill(make_fill("f2", Side.SELL, 90.0, 15))  # closes 10 long, opens 5 short
    assert account.quantity == -5
    assert account.average_price == pytest.approx(90.0)
    assert account.realised_pnl == pytest.approx(10 * (90.0 - 100.0))


def test_short_position_realises_pnl_on_cover():
    account = PnLAccount(strategy_id="s1", symbol="RHINO")
    account.apply_fill(make_fill("f1", Side.SELL, 100.0, 10))
    assert account.quantity == -10
    account.apply_fill(make_fill("f2", Side.BUY, 90.0, 10))  # cover at a lower price = profit for the short
    assert account.quantity == 0
    assert account.realised_pnl == pytest.approx(10 * (100.0 - 90.0))


def test_fees_and_rebates_flow_into_cash_and_total_pnl():
    account = PnLAccount(strategy_id="s1", symbol="RHINO")
    fill = make_fill("f1", Side.BUY, 100.0, 10)
    fill = fill.model_copy(update={"fee": 1.0, "rebate": 0.0})
    account.apply_fill(fill)
    assert account.fees == 1.0
    assert account.cash_flow == pytest.approx(-1000.0 - 1.0)


def test_fill_processed_exactly_once():
    account = PnLAccount(strategy_id="s1", symbol="RHINO")
    fill = make_fill("f1", Side.BUY, 100.0, 10)
    account.apply_fill(fill)
    with pytest.raises(DuplicateFillError):
        account.apply_fill(fill)


# -- property-based: cash_flow always matches the fills applied so far ---- #
fill_strategy = st.tuples(
    st.sampled_from([Side.BUY, Side.SELL]),
    st.floats(min_value=1.0, max_value=500.0, allow_nan=False),
    st.floats(min_value=1.0, max_value=100.0, allow_nan=False),
)


@given(fills=st.lists(fill_strategy, min_size=1, max_size=30))
@settings(max_examples=50)
def test_cash_flow_matches_sum_of_signed_fill_notionals(fills):
    account = PnLAccount(strategy_id="s1", symbol="RHINO")
    expected_cash_flow = 0.0
    for i, (side, price, qty) in enumerate(fills):
        f = make_fill(f"f{i}", side, round(price, 4), round(qty, 4))
        account.apply_fill(f)
        signed = f.quantity if side == Side.BUY else -f.quantity
        expected_cash_flow += -signed * f.price
    assert account.cash_flow == pytest.approx(expected_cash_flow, rel=1e-9)
