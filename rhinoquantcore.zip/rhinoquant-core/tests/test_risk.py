import pytest

from rhinoquant.config import RiskConfig
from rhinoquant.risk.engine import RiskContext, RiskEngine
from rhinoquant.risk.kill_switch import KillSwitchKind
from rhinoquant.schemas.risk import RiskRejectReason
from rhinoquant.schemas.orders import Side
from rhinoquant.strategies.base import OrderIntent


def make_intent(**overrides) -> OrderIntent:
    defaults = dict(strategy_id="s1", portfolio_id="p1", symbol="RHINO", side=Side.BUY, quantity=10, price=100.0)
    defaults.update(overrides)
    return OrderIntent(**defaults)


def test_accepts_a_reasonable_order():
    engine = RiskEngine(RiskConfig())
    decision = engine.evaluate(make_intent(), RiskContext(reference_price=100.0))
    assert decision.accepted
    assert decision.reason is None


def test_rejects_oversized_order():
    cfg = RiskConfig(max_order_quantity=50)
    engine = RiskEngine(cfg)
    decision = engine.evaluate(make_intent(quantity=100), RiskContext(reference_price=100.0))
    assert not decision.accepted
    assert decision.reason == RiskRejectReason.RISK_REJECT_ORDER_SIZE_LIMIT


def test_rejects_notional_limit():
    cfg = RiskConfig(max_notional=500)
    engine = RiskEngine(cfg)
    decision = engine.evaluate(make_intent(quantity=10, price=100.0), RiskContext(reference_price=100.0))
    assert not decision.accepted
    assert decision.reason == RiskRejectReason.RISK_REJECT_NOTIONAL_LIMIT


def test_price_collar_rejects_far_off_limit_price():
    cfg = RiskConfig(price_collar_bps=50)
    engine = RiskEngine(cfg)
    # 100 -> 101 is ~100bps away, collar is 50bps
    decision = engine.evaluate(make_intent(price=101.0), RiskContext(reference_price=100.0))
    assert not decision.accepted
    assert decision.reason == RiskRejectReason.RISK_REJECT_PRICE_COLLAR


def test_fat_finger_rejects_extreme_price():
    cfg = RiskConfig(price_collar_bps=50)
    engine = RiskEngine(cfg)
    decision = engine.evaluate(make_intent(price=150.0), RiskContext(reference_price=100.0))
    assert not decision.accepted
    assert decision.reason == RiskRejectReason.RISK_REJECT_FAT_FINGER


def test_daily_loss_limit_rejects():
    cfg = RiskConfig(max_daily_loss=1000)
    engine = RiskEngine(cfg)
    decision = engine.evaluate(make_intent(), RiskContext(reference_price=100.0, daily_pnl=-1500))
    assert not decision.accepted
    assert decision.reason == RiskRejectReason.RISK_REJECT_DAILY_LOSS_LIMIT


def test_order_rate_limit_rejects_after_threshold():
    cfg = RiskConfig(max_order_rate_per_sec=2)
    engine = RiskEngine(cfg)
    ts = 0
    accepted = []
    for i in range(5):
        # vary price per iteration so the duplicate-order dedupe (a
        # separate check, exercised in its own test) never fires here —
        # this test isolates the order-rate limiter specifically.
        decision = engine.evaluate(
            make_intent(price=100.0 + i * 0.01), RiskContext(reference_price=100.0), timestamp_ns=ts
        )
        accepted.append(decision.accepted)
        ts += 1_000_000  # 1ms apart, well within the 1s rate window
    assert accepted[:2] == [True, True]
    assert not any(accepted[2:])


def test_duplicate_order_rejected_within_dedupe_window():
    engine = RiskEngine(RiskConfig())
    intent = make_intent()
    d1 = engine.evaluate(intent, RiskContext(reference_price=100.0), timestamp_ns=0)
    d2 = engine.evaluate(intent, RiskContext(reference_price=100.0), timestamp_ns=1_000_000)  # 1ms later
    assert d1.accepted
    assert not d2.accepted
    assert d2.reason == RiskRejectReason.RISK_REJECT_DUPLICATE_ORDER


def test_kill_switch_blocks_new_orders():
    engine = RiskEngine(RiskConfig())
    engine.kill_switches.activate(KillSwitchKind.STRATEGY, "s1", "manual test kill")
    decision = engine.evaluate(make_intent(), RiskContext(reference_price=100.0))
    assert not decision.accepted
    assert decision.reason == RiskRejectReason.RISK_REJECT_KILL_SWITCH


def test_stale_market_rejected():
    cfg = RiskConfig(stale_market_ms=10)
    engine = RiskEngine(cfg)
    decision = engine.evaluate(
        make_intent(), RiskContext(reference_price=100.0, market_data_age_ns=50_000_000)
    )
    assert not decision.accepted
    assert decision.reason == RiskRejectReason.RISK_REJECT_STALE_MARKET
