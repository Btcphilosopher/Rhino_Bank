import pytest

from rhinoquant.core.errors import OrderStateError
from rhinoquant.oms.manager import OrderManager
from rhinoquant.oms.order import transition
from rhinoquant.schemas.orders import OrderStatus, Side
from rhinoquant.strategies.base import OrderIntent


def make_intent(**overrides) -> OrderIntent:
    defaults = dict(strategy_id="s1", portfolio_id="p1", symbol="RHINO", side=Side.BUY, quantity=100, price=100.0)
    defaults.update(overrides)
    return OrderIntent(**defaults)


def test_new_order_starts_in_new_status():
    oms = OrderManager()
    order = oms.create_order(make_intent(), timestamp_ns=0)
    assert order.status == OrderStatus.NEW
    assert order.remaining_quantity == 100


def test_full_lifecycle_new_ack_partial_fill_fill():
    oms = OrderManager()
    order = oms.create_order(make_intent(quantity=100), timestamp_ns=0)
    order = oms.ack(order.client_order_id, "exch1", timestamp_ns=1)
    assert order.status == OrderStatus.ACK

    order = oms.apply_fill(order.client_order_id, fill_quantity=40, timestamp_ns=2)
    assert order.status == OrderStatus.PARTIAL_FILL
    assert order.filled_quantity == 40
    assert order.remaining_quantity == 60

    order = oms.apply_fill(order.client_order_id, fill_quantity=60, timestamp_ns=3)
    assert order.status == OrderStatus.FILL
    assert order.remaining_quantity == 0

    history = oms.history(order.client_order_id)
    assert [h.status for h in history] == [
        OrderStatus.NEW,
        OrderStatus.ACK,
        OrderStatus.PARTIAL_FILL,
        OrderStatus.FILL,
    ]


def test_reject_path():
    oms = OrderManager()
    order = oms.create_order(make_intent(), timestamp_ns=0)
    order = oms.reject(order.client_order_id, "RISK_REJECT_POSITION_LIMIT", timestamp_ns=1)
    assert order.status == OrderStatus.REJECT
    assert order.reject_reason == "RISK_REJECT_POSITION_LIMIT"


def test_cancel_path():
    oms = OrderManager()
    order = oms.create_order(make_intent(), timestamp_ns=0)
    order = oms.ack(order.client_order_id, "exch1", timestamp_ns=1)
    order = oms.cancel_request(order.client_order_id, timestamp_ns=2)
    assert order.status == OrderStatus.CANCEL
    order = oms.cancel_ack(order.client_order_id, timestamp_ns=3)
    assert order.status == OrderStatus.CANCEL_ACK


def test_illegal_transition_raises():
    oms = OrderManager()
    order = oms.create_order(make_intent(), timestamp_ns=0)
    # NEW -> FILL is not a legal direct transition
    with pytest.raises(OrderStateError):
        transition(order, OrderStatus.FILL)


def test_terminal_states_have_no_outgoing_transitions():
    oms = OrderManager()
    order = oms.create_order(make_intent(), timestamp_ns=0)
    order = oms.reject(order.client_order_id, "reason", timestamp_ns=1)
    with pytest.raises(OrderStateError):
        transition(order, OrderStatus.ACK)


def test_open_orders_excludes_terminal_orders():
    oms = OrderManager()
    a = oms.create_order(make_intent(), timestamp_ns=0)
    b = oms.create_order(make_intent(), timestamp_ns=0)
    oms.ack(a.client_order_id, "e1", timestamp_ns=1)
    oms.reject(b.client_order_id, "reason", timestamp_ns=1)
    open_ids = {o.client_order_id for o in oms.open_orders()}
    assert a.client_order_id in open_ids
    assert b.client_order_id not in open_ids
