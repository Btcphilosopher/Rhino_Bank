from rhinoquant.config import LatencyConfig
from rhinoquant.orderbook.book import LimitOrderBook
from rhinoquant.simulation.exchange import ExchangeFeeConfig, SimulatedExchange
from rhinoquant.schemas.orders import Order, OrderType, Side, TimeInForce


def make_order(**overrides) -> Order:
    defaults = dict(
        client_order_id="c1",
        strategy_id="s1",
        portfolio_id="p1",
        symbol="RHINO",
        side=Side.BUY,
        order_type=OrderType.LIMIT,
        time_in_force=TimeInForce.DAY,
        quantity=10,
        price=None,
        created_ns=0,
        updated_ns=0,
    )
    defaults.update(overrides)
    return Order(**defaults)


def test_marketable_order_fills_immediately_against_the_book():
    book = LimitOrderBook("RHINO")
    book.update_bid(99.99, 100)
    book.update_ask(100.00, 50)
    exch = SimulatedExchange("RHINO", book, latency=LatencyConfig(exchange_ack_us=0))

    order = make_order(side=Side.BUY, quantity=20, price=100.00)  # crosses the ask
    report = exch.submit(order, timestamp_ns=0)

    assert report.accepted
    assert len(report.fills) == 1
    assert report.fills[0].price == 100.00
    assert report.fills[0].quantity == 20
    assert report.fills[0].liquidity_flag == "TAKER"


def test_non_marketable_order_rests_and_fills_on_subsequent_market_trade():
    book = LimitOrderBook("RHINO")
    book.update_bid(99.98, 50)
    book.update_ask(100.02, 50)
    exch = SimulatedExchange("RHINO", book, latency=LatencyConfig(exchange_ack_us=0))

    order = make_order(side=Side.BUY, quantity=10, price=99.99)  # inside the spread, does not cross
    report = exch.submit(order, timestamp_ns=0)
    assert report.accepted
    assert report.fills == []

    # nothing trades at our price yet
    fills = exch.on_market_trade(price=100.02, quantity=5, aggressor_side="BUY", timestamp_ns=1)
    assert fills == []

    # a sell trade at our exact resting price should now fill us (maker)
    fills = exch.on_market_trade(price=99.99, quantity=10, aggressor_side="SELL", timestamp_ns=2)
    assert len(fills) == 1
    assert fills[0].liquidity_flag == "MAKER"
    assert fills[0].quantity == 10


def test_cancel_removes_resting_order():
    book = LimitOrderBook("RHINO")
    book.update_bid(99.98, 50)
    book.update_ask(100.02, 50)
    exch = SimulatedExchange("RHINO", book, latency=LatencyConfig(exchange_ack_us=0))

    order = make_order(side=Side.BUY, quantity=10, price=99.99)
    report = exch.submit(order, timestamp_ns=0)
    cancel_report = exch.cancel(report.exchange_order_id, timestamp_ns=1)
    assert cancel_report.accepted

    fills = exch.on_market_trade(price=99.99, quantity=100, aggressor_side="SELL", timestamp_ns=2)
    assert fills == []  # nothing resting anymore, so nothing fills


def test_fees_charged_on_taker_fill():
    book = LimitOrderBook("RHINO")
    book.update_ask(100.00, 50)
    exch = SimulatedExchange("RHINO", book, latency=LatencyConfig(exchange_ack_us=0), fees=ExchangeFeeConfig(taker_fee_bps=10))

    order = make_order(side=Side.BUY, quantity=10, price=100.00)
    report = exch.submit(order, timestamp_ns=0)
    fill = report.fills[0]
    expected_fee = 100.00 * 10 * 10 / 10_000
    assert abs(fill.fee - expected_fee) < 1e-9
