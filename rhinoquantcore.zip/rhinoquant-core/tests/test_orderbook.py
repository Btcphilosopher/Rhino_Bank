import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from rhinoquant.orderbook import get_order_book, rust_backend_available
from rhinoquant.orderbook.book import LimitOrderBook
from rhinoquant.orderbook.errors import (
    CrossedBookError,
    DuplicateMessageError,
    InvalidPriceError,
    LockedBookError,
    NegativeQuantityError,
    SequenceGapError,
)


def test_best_bid_ask_mid_spread_microprice_imbalance():
    book = LimitOrderBook("RHINO")
    book.update_bid(100.25, 500)
    book.update_ask(100.27, 400)

    assert book.best_bid() == 100.25
    assert book.best_ask() == 100.27
    assert book.mid() == pytest.approx(100.26)
    assert book.spread() == pytest.approx(0.02)
    # microprice should sit between best bid and ask, weighted toward the thinner side
    mp = book.microprice()
    assert 100.25 < mp < 100.27
    imb = book.imbalance(1)
    assert imb == pytest.approx((500 - 400) / 900)


def test_zero_quantity_removes_level():
    book = LimitOrderBook("RHINO")
    book.update_bid(100.0, 10)
    assert book.best_bid() == 100.0
    book.update_bid(100.0, 0)
    assert book.best_bid() is None


def test_depth_multi_level_ordering():
    book = LimitOrderBook("RHINO")
    book.update_bid(100.00, 100)
    book.update_bid(99.99, 200)
    book.update_bid(99.98, 50)
    book.update_ask(100.01, 80)
    book.update_ask(100.02, 60)

    depth = book.depth(2)
    assert depth["bids"] == [(100.00, 100), (99.99, 200)]
    assert depth["asks"] == [(100.01, 80), (100.02, 60)]


def test_crossed_book_raises_in_strict_mode():
    book = LimitOrderBook("RHINO", strict=True)
    book.update_bid(100.0, 10)
    book.update_ask(100.05, 10)
    with pytest.raises(CrossedBookError):
        book.update_bid(100.10, 10)


def test_crossed_book_counted_not_raised_when_lenient():
    book = LimitOrderBook("RHINO", strict=False)
    book.update_bid(100.0, 10)
    book.update_ask(100.05, 10)
    book.update_bid(100.10, 10)  # does not raise
    assert book.crossed_count == 1


def test_locked_book_detected():
    book = LimitOrderBook("RHINO", strict=False)
    book.update_bid(100.0, 10)
    book.update_ask(100.0, 10)
    assert book.locked_count == 1


def test_negative_quantity_rejected():
    book = LimitOrderBook("RHINO")
    with pytest.raises(NegativeQuantityError):
        book.update_bid(100.0, -5)


def test_invalid_price_rejected():
    book = LimitOrderBook("RHINO")
    with pytest.raises(InvalidPriceError):
        book.update_bid(0.0, 5)
    with pytest.raises(InvalidPriceError):
        book.update_bid(-1.0, 5)


def test_sequence_gap_detected():
    book = LimitOrderBook("RHINO")
    book.update_bid(100.0, 10, sequence_number=1)
    with pytest.raises(SequenceGapError):
        book.update_bid(100.0, 20, sequence_number=3)


def test_duplicate_sequence_rejected():
    book = LimitOrderBook("RHINO")
    book.update_bid(100.0, 10, sequence_number=1)
    book.update_bid(100.0, 20, sequence_number=2)
    with pytest.raises(DuplicateMessageError):
        book.update_bid(100.0, 30, sequence_number=2)


def test_own_order_queue_position_and_depletion():
    book = LimitOrderBook("RHINO")
    book.update_bid(100.0, 300)  # public resting depth ahead of us
    ahead = book.register_own_order("own1", "BUY", 100.0, 50)
    assert ahead == 300
    assert book.queue_position("own1") == 300

    book.on_trade(price=100.0, quantity=100, aggressor_side="SELL")  # sells hit the bid
    assert book.queue_position("own1") == 200

    book.on_trade(price=100.0, quantity=250, aggressor_side="SELL")
    assert book.queue_position("own1") == 0  # floored at zero, not negative


def test_apply_snapshot_replaces_book_state():
    book = LimitOrderBook("RHINO")
    book.update_bid(100.0, 10)
    book.update_ask(100.5, 10)
    book.apply_snapshot(bids=[(99.0, 5)], asks=[(99.5, 5)])
    assert book.best_bid() == 99.0
    assert book.best_ask() == 99.5


@pytest.mark.skipif(not rust_backend_available(), reason="rhinoquant_core Rust extension not built")
def test_rust_backend_matches_python_reference():
    py_book = get_order_book("RHINO", prefer_rust=False)
    rust_book = get_order_book("RHINO", prefer_rust=True)
    for book in (py_book, rust_book):
        book.update_bid(100.25, 500)
        book.update_ask(100.27, 400)
    assert py_book.best_bid() == rust_book.best_bid()
    assert py_book.best_ask() == rust_book.best_ask()
    assert py_book.mid() == pytest.approx(rust_book.mid())
    assert py_book.microprice() == pytest.approx(rust_book.microprice())


# -- property-based tests (section 43) ------------------------------------ #

price_qty = st.tuples(
    st.floats(min_value=1.0, max_value=1000.0, allow_nan=False, allow_infinity=False),
    st.floats(min_value=0.0, max_value=1000.0, allow_nan=False, allow_infinity=False),
)


@given(updates=st.lists(price_qty, min_size=0, max_size=200))
@settings(max_examples=100)
def test_orderbook_never_reports_negative_depth(updates):
    """Whatever sequence of (price, quantity) bid updates a caller applies
    (in non-strict mode, so a crossed/locked book from random data doesn't
    abort the test), no resulting quantity is ever negative."""
    book = LimitOrderBook("PROP", strict=False)
    for price, qty in updates:
        book.update_bid(round(price, 2), round(qty, 2))
    for _, qty in book.depth(1000)["bids"]:
        assert qty >= 0
