from rhinoquant.schemas.market import MarketSnapshot
from rhinoquant.storage.backends import CSVStorageBackend, JSONLStorageBackend, ParquetStorageBackend
from rhinoquant.storage.stores import MarketDataStore


def _snapshots():
    return [
        MarketSnapshot(symbol="RHINO", timestamp_ns=1, best_bid=100.0, best_ask=100.02),
        MarketSnapshot(symbol="RHINO", timestamp_ns=2, best_bid=100.01, best_ask=100.03),
    ]


def test_parquet_round_trip(tmp_path):
    store = MarketDataStore(root_path=str(tmp_path), backend=ParquetStorageBackend())
    path = store.save_snapshots("RHINO", _snapshots())
    records = store.load("market/RHINO")
    assert len(records) == 2
    assert records[0]["symbol"] == "RHINO"
    assert path.endswith(".parquet")


def test_csv_round_trip(tmp_path):
    store = MarketDataStore(root_path=str(tmp_path), backend=CSVStorageBackend())
    store.save_snapshots("RHINO", _snapshots())
    records = store.load("market/RHINO")
    assert len(records) == 2
    assert records[0]["symbol"] == "RHINO"


def test_jsonl_round_trip(tmp_path):
    store = MarketDataStore(root_path=str(tmp_path), backend=JSONLStorageBackend())
    store.save_snapshots("RHINO", _snapshots())
    records = store.load("market/RHINO")
    assert len(records) == 2
    assert records[1]["timestamp_ns"] == 2
