"""Generates JSON Schema files for every frontend-contract schema
(section 6/45/46) into ``schemas/`` at the repository root, so the
existing frontend (or any other consumer) has a language-agnostic
specification of the engine contract without needing to import Python.

    python scripts/generate_schemas.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))

from rhinoquant import schemas as rq_schemas  # noqa: E402
from rhinoquant.schemas.base import RhinoQuantSchema  # noqa: E402


def main() -> None:
    out_dir = ROOT / "schemas"
    out_dir.mkdir(exist_ok=True)

    written = []
    for name in dir(rq_schemas):
        obj = getattr(rq_schemas, name)
        if isinstance(obj, type) and issubclass(obj, RhinoQuantSchema) and obj is not RhinoQuantSchema:
            schema = obj.model_json_schema()
            path = out_dir / f"{name}.schema.json"
            path.write_text(json.dumps(schema, indent=2) + "\n")
            written.append(path.name)

    index = {"api_version": "v1", "schemas": sorted(written)}
    (out_dir / "index.json").write_text(json.dumps(index, indent=2) + "\n")
    print(f"wrote {len(written)} schema files + index.json to {out_dir}")


if __name__ == "__main__":
    main()
