# Benchmarks

```bash
python benchmarks/bench_orderbook.py
python benchmarks/bench_features.py
python benchmarks/bench_event_bus.py
# or, for the order book comparison specifically:
python -m rhinoquant benchmark --iterations 50000
```

Every script prints throughput measured **on the host it runs on, for
that run only**. None of these numbers are portable HFT performance
claims (section 44/53) — they exist to catch regressions and to honestly
compare the pure-Python reference implementations against the Rust
(`rhinoquant_core`) backend where one is built.

There is no C++ benchmark: `cpp/execution-interface/` is a declaration-only
header with nothing compiled or runnable (see its `README.md`).
