"""Event dispatch benchmark (section 44): throughput of
:class:`EventBus` publish+drain on this host, this run only.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))

from rhinoquant.core.events import Event, EventBus, EventType  # noqa: E402


def main() -> None:
    n = 200_000
    bus = EventBus()
    counter = {"n": 0}
    bus.subscribe_all(lambda e: counter.__setitem__("n", counter["n"] + 1))

    start = time.perf_counter()
    for i in range(n):
        bus.publish(Event(event_type=EventType.MARKET, timestamp_ns=i))
    bus.drain()
    elapsed = time.perf_counter() - start

    assert counter["n"] == n
    print(f"n={n} events, this host only")
    print(f"[python] events dispatched/sec: {n / elapsed:,.0f}")


if __name__ == "__main__":
    main()
