"""Order book update / best-bid-ask / microprice benchmark (section 44).

Runs the same workload against the pure-Python reference book and
(if built) the Rust-accelerated backend, on THIS host, right now — the
numbers printed are a measurement, not a portable performance claim.
Also exercised by ``python -m rhinoquant benchmark``.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))

from rhinoquant.orderbook import get_order_book, rust_backend_available  # noqa: E402


def bench_updates(book, n: int) -> float:
    start = time.perf_counter()
    price = 100.0
    for i in range(n):
        price += 0.01 if i % 2 == 0 else -0.01
        book.update_bid(round(price - 0.01, 2), 100 + (i % 50))
        book.update_ask(round(price + 0.01, 2), 100 + (i % 50))
        book.update_bid(round(price - 0.02, 2), 0)
        book.update_ask(round(price + 0.02, 2), 0)
    return n / (time.perf_counter() - start)


def bench_reads(book, n: int) -> float:
    start = time.perf_counter()
    for _ in range(n):
        book.best_bid()
        book.best_ask()
        book.mid()
        book.microprice()
    return n / (time.perf_counter() - start)


def main() -> None:
    n = 50_000
    print(f"n={n} iterations, this host only\n")

    py_book = get_order_book("BENCH", prefer_rust=False)
    print(f"[python]  updates/sec: {bench_updates(py_book, n):,.0f}")
    print(f"[python]  reads/sec:   {bench_reads(py_book, n):,.0f}")

    if rust_backend_available():
        rust_book = get_order_book("BENCH", prefer_rust=True)
        print(f"[rust]    updates/sec: {bench_updates(rust_book, n):,.0f}")
        print(f"[rust]    reads/sec:   {bench_reads(rust_book, n):,.0f}")
    else:
        print("[rust]    extension not built — run `maturin develop --release` in rust/rhinoquant-core/")

    print("\n[future c++] not implemented; see cpp/execution-interface/README.md")


if __name__ == "__main__":
    main()
