"""Feature-calculation benchmark (section 44): throughput of
:meth:`FeatureEngine.on_book` on this host, this run only.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))

from rhinoquant.features.engine import FeatureEngine  # noqa: E402
from rhinoquant.orderbook.book import LimitOrderBook  # noqa: E402


def main() -> None:
    n = 50_000
    fe = FeatureEngine(symbol="BENCH")
    book = LimitOrderBook("BENCH")
    price = 100.0

    start = time.perf_counter()
    for i in range(n):
        price += 0.01 if i % 2 == 0 else -0.01
        book.apply_snapshot(bids=[(round(price - 0.01, 2), 100.0)], asks=[(round(price + 0.01, 2), 100.0)])
        fe.on_book(book, timestamp_ns=i)
        if i % 3 == 0:
            fe.on_trade(price=round(price, 2), quantity=10.0, aggressor_side="BUY", timestamp_ns=i)
    elapsed = time.perf_counter() - start

    print(f"n={n} iterations, this host only")
    print(f"[python] feature_calculations/sec: {n / elapsed:,.0f}")


if __name__ == "__main__":
    main()
