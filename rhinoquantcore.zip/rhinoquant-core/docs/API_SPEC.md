# API specification (section 7 / 46)

`rhinoquant.api.RhinoQuantAPI` (`python/rhinoquant/api/service.py`) is the
engine's service boundary. Every method takes plain arguments and returns
a plain, JSON-serialisable `dict`:

```json
{ "api_version": "v1", "data": { ... } }
```

`data` is one schema (or a list of them) from `python/rhinoquant/schemas/`
— see `schemas/*.schema.json` at the repository root for the full,
generated JSON Schema of each one (`python scripts/generate_schemas.py`
regenerates them from the pydantic models, which remain the single source
of truth).

| Endpoint | Method | Returns |
|---|---|---|
| `/system/status` | `system_status()` | `SystemStatus` |
| `/system/health` | `system_health()` | `HealthCheck` |
| `/market`, `/market/{symbol}` | `market(symbol=None)` | `MarketSnapshot` or `list[MarketSnapshot]` |
| `/orderbook/{symbol}` | `orderbook(symbol, levels=10)` | `OrderBookSnapshot` |
| `/features/{symbol}` | `features(symbol)` | `FeatureSnapshot` (plain dataclass, not a pydantic schema — see note below) |
| `/strategies`, `/strategies/{id}` | `strategies(strategy_id=None)` | list of `{strategy_id, portfolio_id, type}` or one |
| `/signals` | `signals()` | `list[Signal]` (empty for rule-based reference strategies; see method docstring) |
| `/orders`, `/orders/{id}` | `orders(client_order_id=None)` | `list[Order]` or one `Order` |
| `/fills` | `fills()` | `list[Fill]` |
| `/positions` | `positions()` | `list[Position]` |
| `/portfolio` | `portfolio()` | `PortfolioState` |
| `/pnl` | `pnl()` | `PnlSnapshot` |
| `/risk` | `risk()` | `RiskState` |
| `/backtests` | `backtests()` | `BacktestResult` |
| `/simulations` | `simulations()` | `BacktestResult` (same mechanism as `/backtests` — see method docstring) |
| `/analytics` | `analytics()` | `PerformanceReport` (dataclass; Sharpe/Sortino/drawdown/turnover/hit-rate/HFT metrics) |
| `/latency` | `latency()` | `LatencyReport` |
| `/metrics` | `metrics()` | machine-readable counters/gauges/histograms |

## Errors

Any method above can raise a structured error
(`rhinoquant.core.errors.RhinoQuantError` subclass — most commonly
`ValidationError` for an unknown symbol/strategy/order id, or if no
run has happened yet in this engine instance). Every error carries
`error_code`, `message`, `component`, `timestamp_ns`, and an optional
`correlation_id` (section 40/41) — see `errors.to_dict()`.

## Versioning (section 46)

`API_VERSION` (`python/rhinoquant/api/versioning.py`) is stamped on every
response envelope. A breaking change to what a version means bumps this
constant rather than silently changing behaviour under an existing
version — internal refactoring must never break a frontend that only
knows `v1`.

## Note on `/features`

`FeatureSnapshot` is a plain Python `dataclass`, not a pydantic
`RhinoQuantSchema` — the streaming feature engine runs on every market
data tick, so it is written with zero validation overhead on that hot
path. `RhinoQuantAPI.features()` converts it to a plain dict
(`dataclasses.asdict`) at the API boundary, so callers still only ever see
JSON-compatible data; only the internal representation differs from the
rest of the schema layer.

## No bundled HTTP server

This repository does not bundle FastAPI/gRPC/etc. — `RhinoQuantAPI` is
the stable *contract*; wrapping each method above as a real HTTP or IPC
endpoint for the existing frontend to call is a small, separate
integration step (see the module docstring in `api/service.py`), and is
exactly the kind of dependency section 3 asks to add only once it's
actually needed.
