# Verification log (section 55)

This is an honest record of what was actually run before delivery, on
this build machine, and its actual output — not a claim that these steps
were run somewhere else or that results are guaranteed to reproduce
identically on a different machine (compiler version, CPU, OS all affect
the benchmark numbers specifically; the pytest/CLI results are
deterministic given the same code and seeds).

Environment: Python 3.11.15, Rust 1.94.1 (`cargo`/`rustc`), `maturin`
1.15.0, Linux x86_64.

## 1-2. Install dependencies + build the Python package

```bash
pip install -e ".[dev]"          # clean venv, from pyproject.toml only
python -c "import rhinoquant; print(rhinoquant.__version__)"   # -> 0.1.0

python -m build --wheel          # produces rhinoquant-0.1.0-py3-none-any.whl
```

Then, in a **separate, fresh venv with no source tree present**, installed
just that wheel plus its runtime dependencies and confirmed both entry
points work:

```text
$ python -m rhinoquant health   # -> status: READY, healthy: True
$ rhinoquant health             # (console-script entry point) -> identical output
```

## 3. Build the Rust component

```bash
cd rust/rhinoquant-core
cargo test --release   # 7 passed; 0 failed
maturin develop --release
python -c "import rhinoquant_core; b = rhinoquant_core.OrderBook(); \
  b.update_bid(100.25, 500); b.update_ask(100.27, 400); \
  print(b.best_bid(), b.best_ask(), b.microprice())"
# -> 100.25 100.27 100.2611111111111
```

Repeated in the same fresh (wheel-only) venv used for step 1-2, to confirm
the extension builds and installs independently of any editable install.

## 4-6. Unit / integration / API-schema tests

```bash
python -m pytest tests/ -v
```

Result: **70 passed** (69 unit/property tests + `test_rust_backend_matches_python_reference`,
which is skipped when the Rust extension isn't built and passes when it
is — verified both ways). Covers: order book correctness (price/time
priority, crossed/locked/duplicate/sequence-gap/negative-qty detection,
a Hypothesis property test), risk engine (every reject reason code),
kill switches, OMS state machine (full lifecycle + illegal-transition
rejection), P&L accounting (average-cost long/short/flip, exactly-once
fill enforcement, a Hypothesis cash-conservation property test), the
event bus's deterministic ordering, the simulated exchange (taker fills,
resting/maker fills via queue depletion, cancellation, fees), backtest
determinism (same seed -> identical hash; different seed -> different
hash), the audit log's hash chain, feature engine primitives, and
schema JSON round-tripping.

## 7. Benchmark suite

```bash
python benchmarks/bench_orderbook.py
python benchmarks/bench_features.py
python benchmarks/bench_event_bus.py
```

Actual measured output on this host, this run (n=50,000 order book
updates, n=50,000 feature calculations, n=200,000 event-bus dispatches):

```text
[python]  updates/sec: 229,548        [rust] updates/sec: 521,672
[python]  reads/sec:   1,581,470      [rust] reads/sec:   8,599,927
[python] feature_calculations/sec: 5,128
[python] events dispatched/sec: 163,236
```

These are single-run numbers on one host and are not claimed to be
portable or representative of any other machine (section 44/53).

## 8. Synthetic market simulation

```bash
python -m rhinoquant simulate    # default: 100,000 synthetic ticks, RHINO
```

Actual output (fresh wheel-only venv):

```text
Orders:      Submitted: 1147   Accepted: 899   Rejected: 248   Filled: 34
Risk:        Status: NORMAL
Portfolio:   Inventory: -10
Performance: Gross P&L: -4533.30   Fees: 0.00   Net P&L: -4524.86   Turnover: 0.4223
deterministic_hash: c581bde15f3a194c28f0c9ed8ac8dd68b09ea1da5514327409721737765031d7
```

The net P&L is negative for this seed/strategy/config combination — this
is reported as-is. A symmetric-ish market maker losing money against a
synthetic trend regime is an expected outcome (adverse selection), not a
result that was tuned away; see the honesty notes in the top-level
README.

## 9-12. P&L / risk rejection / kill switch / deterministic backtesting

All four are exercised by `python -m rhinoquant validate`, in addition to
the dedicated pytest modules (`test_pnl.py`, `test_risk.py`,
`test_kill_switch.py`, `test_backtest_determinism.py`). Actual output:

```text
[PASS] config_loads
[PASS] risk_rejects_oversized_order — RISK_REJECT_ORDER_SIZE_LIMIT
[PASS] kill_switch_blocks_new_orders — RISK_REJECT_KILL_SWITCH
[PASS] deterministic_replay_same_seed — 26555ce96efc094f28bd5ad522120499f319a15d03cda881ba56a07a7f57480d
[PASS] api_schemas_serialise

5/5 checks passed
```

## 13. Frontend API schemas

`python scripts/generate_schemas.py` generated 17 JSON Schema files (plus
an index) from the live pydantic models into `schemas/` with no errors;
`tests/test_schemas.py` round-trips several schemas through
`json.dumps`/`json.loads`/`model_validate` and checks the
`schema_version`/`api_version` fields are present. `RhinoQuantAPI`'s
methods are also exercised directly by `validate`'s `api_schemas_serialise`
check.

## 14-15. Errors found and fixed, then the full suite re-run

Two real defects were found during this verification pass and fixed
(not merely noted):

1. **Risk engine (`risk/engine.py`)**: the price-collar check was ordered
   before the fat-finger check, so a deviation extreme enough to qualify
   as a fat-finger was still classified (and returned) as a plain
   `RISK_REJECT_PRICE_COLLAR` — the fat-finger branch was unreachable
   dead code. Fixed by checking the more severe condition first.
2. **Market-making strategy**: it originally re-submitted a fresh
   `OrderIntent` on every qualifying book update without tracking or
   cancelling its own previous resting order, which both left stale
   orders resting indefinitely and flooded the risk engine's
   duplicate-order protection (~99% reject rate in an early test run).
   Fixed by adding proper per-side resting-order lifecycle management
   (`on_order_ack`, cancel-before-requote) to `MarketMakingStrategy`, and
   a `Strategy.generate_cancels()` hook plumbed through the backtest
   engine so a strategy can cancel its own resting orders through the
   same risk-gated pathway as a new order.

After both fixes, the full pytest suite (step 4-6) was re-run and passed
70/70, and `python -m rhinoquant validate` was re-run and passed 5/5 (both
results shown above are from *after* the fixes, not before).
