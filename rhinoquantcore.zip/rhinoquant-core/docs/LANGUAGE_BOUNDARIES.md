# Language boundaries

```text
Existing Frontend
       |
       v
RhinoQuant API          (Python, rhinoquant.api.RhinoQuantAPI)
       |
       v
Python Engine           (research, strategy, risk, portfolio, backtest,
       |                  analytics, optimisation, ML, storage, API)
       v
Rust Infrastructure      (order book hot path today; the natural home for
       |                  a future binary-protocol parser, concurrent
       |                  event queue, persistence layer)
       v
Future C++ Execution Engine   (declared, NOT implemented — see
       |                        cpp/execution-interface/)
       v
Kernel / NIC / FPGA
```

This engine is **fully functional today using only the first two layers**
(Python, with Rust as an optional accelerated order-book backend). The
last two layers are documented interfaces, not running code — see below
for exactly what each layer owns and why nothing "leaks" past its
boundary.

## Python — `python/rhinoquant/`

The primary engineering layer for everything that benefits from a fast
edit-test loop and a rich numerical/ML ecosystem:

- quantitative research, backtesting, statistical modelling
- portfolio analytics, optimisation, machine-learning research
- configuration, orchestration, the engine API service
- strategy/alpha/risk/OMS/execution/backtest/simulation logic

It owns every business rule in this repository: what counts as a risk
breach, how P&L is accounted, how an order state machine transitions, what
a synthetic market regime looks like. None of that logic is duplicated in
Rust or C++ — the lower layers only ever accelerate primitives whose
interface Python already defines (the order book today).

## Rust — `rust/rhinoquant-core/`

Latency-sensitive infrastructure, exposed to Python through PyO3 /
maturin as the `rhinoquant_core` extension module:

- **today:** the order book hot path (`OrderBook` — best bid/ask, mid,
  spread, microprice, N-level depth/imbalance, crossed/locked-book
  detection). See `rust/rhinoquant-core/README.md` for what is and isn't
  ported here versus the pure-Python reference book.
- **natural next candidates**, not yet built: binary market-data protocol
  parsing, a concurrent/lock-free event queue, a high-throughput
  persistence/logging layer, networking abstractions for a future real
  feed handler.

`rhinoquant.orderbook.get_order_book()` prefers this backend automatically
when the extension is importable and falls back transparently to the pure
Python implementation otherwise — every other part of the Python engine
is written against the *interface*, never against "the Rust backend" as a
hard dependency, so the whole engine keeps working even in an environment
with no Rust toolchain at all.

## C++ — `cpp/execution-interface/` (declared, not implemented)

A single header (`include/rhinoquant/execution_interface.hpp`) declaring
`IExecutionEngine`: what a future nanosecond-class execution engine would
implement, sitting *below* Rust and talking directly to kernel-bypass
networking or an FPGA/SmartNIC. Every method is pure-virtual; there is no
`.cpp`, no build, no linkage anywhere in this repository, and no code path
in `python -m rhinoquant` can reach it. It exists purely so the interface
is designed now rather than retrofitted later — see that directory's
`README.md` for what building a real one would actually require.

Risk validation is drawn as a hard, non-negotiable line **above** this
layer, not something a future C++ engine would ever take on itself: every
order this repository can submit — via the simulator, paper execution, or
(should it ever exist) a live adapter — passes through
`rhinoquant.risk.RiskEngine` first (section 17). A hot-path execution
engine only ever executes what risk has already approved.

## FPGA / SmartNIC (conceptual only)

Named in the architecture diagram as the eventual hardware layer a real
C++ execution engine would offload onto for the very last microseconds of
latency (order entry, market-data parsing in hardware). Nothing in this
repository targets, simulates, or makes claims about FPGA/SmartNIC
performance — it is listed here only to complete the picture of where a
production HFT stack eventually goes, consistent with section 44's rule
against unsupported hardware-adjacent performance claims.

## What this means for the frontend

The existing frontend never needs to know which of these layers actually
executed a given call. It talks to `rhinoquant.api.RhinoQuantAPI` (or a
thin HTTP/IPC wrapper around it), which returns the same
JSON-serialisable schemas regardless of whether the order book underneath
it was the Rust extension or the pure-Python fallback, and regardless of
whether execution ran through the simulator or (in a future release) a
real venue.
