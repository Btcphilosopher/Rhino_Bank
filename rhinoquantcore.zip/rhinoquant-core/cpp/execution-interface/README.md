# execution-interface (C++ — future hot path, not implemented)

This directory contains exactly one header:
`include/rhinoquant/execution_interface.hpp`.

It declares `rhinoquant::execution::IExecutionEngine` — a pure-virtual C++
interface sketching what a future nanosecond-class execution engine would
look like. **Nothing here is built, linked, or called anywhere in this
repository.** There is no `CMakeLists.txt`, no `.cpp`, no compiled
artifact, and `python -m rhinoquant` has no code path that touches C++ at
all. The engine is complete and fully functional without this directory
existing (spec section 5: "The current implementation should remain fully
functional without C++.").

## Why it exists anyway

Spec section 5 asks for an explicit interface a future C++ hot path could
implement, so that:

1. The rest of the system (Rust order book, Python OMS/risk/portfolio) is
   already written against a stable execution-engine boundary
   (`submit`/`cancel`/`replace`, section 20) that a C++ implementation
   would also satisfy — swapping in a real one later is an additive
   change, not a redesign.
2. It is documented, not just implied, which responsibilities would live
   in C++ (raw execution against a venue) versus which never would (risk
   validation always happens upstream, in Python, before an order reaches
   *any* execution backend — see the class docstring in the header).

## What building a real one would take

1. Implement `IExecutionEngine` in a `.cpp` against real kernel-bypass
   networking (DPDK/io_uring) or an FPGA/SmartNIC offload.
2. Expose it to Rust through a small `extern "C"` shim (bindgen, or a
   hand-written struct-of-function-pointers) — not to Python directly.
3. Have `rust/rhinoquant-core` call through that shim instead of (or
   alongside) the in-process `SimulatedExchange`.
4. The Python layer needs **no changes**: it already only talks to
   whatever backend is wired in through
   `rhinoquant.execution.ExecutionEngine.submit/cancel/replace`.

See `docs/LANGUAGE_BOUNDARIES.md` at the repository root for the full
Python / Rust / C++ / FPGA-SmartNIC split this interface is the seam for.
