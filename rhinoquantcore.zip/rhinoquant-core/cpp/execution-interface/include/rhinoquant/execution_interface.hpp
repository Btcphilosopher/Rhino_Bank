// RhinoQuant Core — future C++ hot-path execution interface (spec section 5).
//
// This header defines the SHAPE of a future nanosecond-class execution
// engine so the rest of the system (Rust order book, Python OMS/risk)
// already has a stable boundary to call across, without implying that
// such a component exists yet. THIS IS A DECLARATION-ONLY STUB:
//
//   * every method is pure virtual (`= 0`) — there is no .cpp translation
//     unit, no compiled library, and nothing links against this header
//     anywhere in this repository;
//   * `python -m rhinoquant` never constructs an `IExecutionEngine` and
//     has no code path that could reach one;
//   * the engine is fully functional today without this file existing at
//     all (see rhinoquant.execution.SimulatorExecution / PaperExecution).
//
// Building a real implementation later means: write a .cpp that
// implements this interface against real kernel bypass / NIC / FPGA
// primitives, expose it to Rust via a small `extern "C"` shim (bindgen or
// a hand-written FFI struct-of-function-pointers), and have
// rust/rhinoquant-core call through that shim instead of the in-process
// SimulatedExchange. Nothing in the Python layer needs to change: it
// already talks to Rust/Python only through
// `rhinoquant.execution.ExecutionEngine.submit/cancel/replace`.
//
// See docs/LANGUAGE_BOUNDARIES.md for the full Python / Rust / C++ /
// FPGA-SmartNIC split this interface is the seam for.

#pragma once

#include <cstdint>
#include <functional>
#include <optional>
#include <string>

namespace rhinoquant::execution {

enum class Side : uint8_t { Buy = 0, Sell = 1 };
enum class OrderType : uint8_t { Limit = 0, Market = 1 };
enum class TimeInForce : uint8_t { Day = 0, IOC = 1, FOK = 2, GTC = 3 };

// Mirrors the wire-shape of rhinoquant.schemas.orders.Order closely enough
// that a future Rust/C++ FFI shim can translate 1:1 without inventing a
// second order representation.
struct OrderRequest {
    std::string client_order_id;
    std::string symbol;
    std::string venue;
    Side side{};
    OrderType order_type{};
    TimeInForce time_in_force{};
    std::optional<double> price;
    double quantity{0.0};
    uint64_t correlation_id_hash{0};  // FNV-hash of the correlation_id string, for cheap propagation across the FFI boundary
};

struct FillEvent {
    std::string client_order_id;
    std::string exchange_order_id;
    double price{0.0};
    double quantity{0.0};
    uint64_t exchange_timestamp_ns{0};
};

struct ExecutionAck {
    bool accepted{false};
    std::string exchange_order_id;
    std::string reject_reason;
    uint64_t ack_timestamp_ns{0};
};

using FillCallback = std::function<void(const FillEvent&)>;

// The future nanosecond-class execution engine boundary. A real
// implementation would sit behind kernel-bypass networking (e.g.
// DPDK/io_uring) or an FPGA/SmartNIC offload, and would be driven from
// Rust — never directly from Python — with risk checks having already
// been applied upstream (this interface performs NO risk validation of
// its own; that boundary is never allowed to move down to this layer,
// per spec section 17: risk sits between strategy and every execution
// backend, always in the same place).
class IExecutionEngine {
public:
    virtual ~IExecutionEngine() = default;

    virtual ExecutionAck submit(const OrderRequest& order) = 0;
    virtual ExecutionAck cancel(const std::string& exchange_order_id) = 0;
    virtual ExecutionAck replace(
        const std::string& exchange_order_id,
        std::optional<double> new_price,
        std::optional<double> new_quantity
    ) = 0;

    // Registers the callback invoked (from whatever thread/interrupt
    // context the real implementation uses) when a fill occurs.
    virtual void on_fill(FillCallback callback) = 0;
};

}  // namespace rhinoquant::execution
