/**
 * RhinoQuant Auto Finance
 * Collateral & Vehicle Residual Value Depreciation Engine
 */

import { FuelType, VehicleSegment } from '../types/finance';

export interface DepreciationPoint {
  month: number;
  residualPct: number;
  retailValue: number;
  wholesaleValue: number;
  auctionValue: number;
  confidenceLowerPct: number;
  confidenceUpperPct: number;
}

// Base depreciation curves (% retained of original invoice value at 12k miles/yr)
const SEGMENT_DEPRECIATION_36M: Record<VehicleSegment, number> = {
  'City/Compact': 0.48,
  'Executive Saloon': 0.51,
  'SUV/Crossover': 0.56,
  'Sports/Performance': 0.59,
  'Commercial Van': 0.45,
};

const FUEL_DEPRECIATION_MODIFIERS_36M: Record<FuelType, number> = {
  ICE: 0.00,       // Baseline
  Hybrid: 0.03,    // Strong market demand (+3% residual)
  PHEV: -0.02,     // High complexity (-2% residual)
  BEV: -0.08,      // Rapid tech cycle & battery perception (-8% baseline residual)
};

/**
 * Calculates deterministic residual value curve from 0 to 60 months
 */
export function calculateDepreciationCurve(params: {
  originalListPrice: number;
  segment: VehicleSegment;
  fuelType: FuelType;
  annualMileage: number;
  usedCarMarketIndex: number; // baseline 100
  bevResidualShockPct?: number; // e.g. -0.20 for -20% stress
}): DepreciationPoint[] {
  const {
    originalListPrice,
    segment,
    fuelType,
    annualMileage,
    usedCarMarketIndex = 100,
    bevResidualShockPct = 0.0,
  } = params;

  // 36-month baseline anchor
  const base36m = SEGMENT_DEPRECIATION_36M[segment] || 0.52;
  let fuelMod = FUEL_DEPRECIATION_MODIFIERS_36M[fuelType] || 0.0;
  if (fuelType === 'BEV' && bevResidualShockPct !== 0) {
    fuelMod += bevResidualShockPct;
  }

  // Mileage penalty: +/- 1.2% per 2,000 miles deviation from 10k baseline
  const mileageDeltaRatio = (annualMileage - 10000) / 10000;
  const mileageMod = -0.04 * mileageDeltaRatio;

  // Market index adjustment
  const marketMod = (usedCarMarketIndex - 100) / 100 * 0.25;

  const target36m = Math.max(0.20, Math.min(0.85, base36m + fuelMod + mileageMod + marketMod));

  // Exponential decay model: R(t) = exp(-k * t)
  // target36m = exp(-k * 36) => k = -ln(target36m) / 36
  const k = -Math.log(target36m) / 36;

  const points: DepreciationPoint[] = [];

  for (let month = 0; month <= 60; month += 6) {
    let residualPct = month === 0 ? 1.0 : Math.exp(-k * month);

    // Initial first-year VAT & drive-off drop (months 1..12)
    if (month > 0 && month <= 12) {
      residualPct = residualPct * 0.95;
    }

    // BEV battery aging adjustment beyond month 48
    if (fuelType === 'BEV' && month > 36) {
      const bevAging = (month - 36) * 0.0025;
      residualPct = Math.max(0.15, residualPct - bevAging);
    }

    const retailValue = Math.round(originalListPrice * residualPct);
    const wholesaleValue = Math.round(retailValue * 0.88); // 12% retail margin
    const auctionValue = Math.round(retailValue * 0.81);   // 19% auction liquidation haircut

    // 90% confidence bands (historical volatility)
    const bandWidth = 0.02 + (month / 60) * 0.05;
    const confidenceLowerPct = Math.max(0.10, residualPct - bandWidth);
    const confidenceUpperPct = Math.min(1.0, residualPct + bandWidth);

    points.push({
      month,
      residualPct: Number(residualPct.toFixed(4)),
      retailValue,
      wholesaleValue,
      auctionValue,
      confidenceLowerPct: Number(confidenceLowerPct.toFixed(4)),
      confidenceUpperPct: Number(confidenceUpperPct.toFixed(4)),
    });
  }

  return points;
}
