/**
 * RhinoQuant Auto Finance
 * High-Precision Cash-Flow & Amortisation Engine (HP, PCP, Balloon, Lease)
 */

import { FinanceProduct, LoanCashFlowPeriod } from '../types/finance';

export interface AmortisationScheduleOutput {
  monthlyPayment: number;
  totalInterestPayable: number;
  totalAmountPayable: number;
  guaranteedFutureValue: number;
  voluntaryTerminationMonth: number; // Month when 50% of total amount payable is reached
  periods: LoanCashFlowPeriod[];
}

/**
 * Calculates monthly interest rate from APR
 * Actuarial monthly compounding: (1 + APR)^(1/12) - 1
 */
export function aprToMonthlyRate(apr: number): number {
  return Math.pow(1 + apr, 1 / 12) - 1;
}

/**
 * Generates deterministic loan-level cash-flow schedule
 */
export function generateLoanCashFlowSchedule(params: {
  productType: FinanceProduct;
  vehiclePrice: number;
  deposit: number;
  customerAPR: number; // e.g. 0.084 (8.4%)
  termMonths: number;
  guaranteedFutureValue?: number; // for PCP
  balloonAmount?: number; // for Balloon loans
  cprAnnualised?: number; // Constant Prepayment Rate, e.g. 0.08 (8%)
  monthlyDepreciationVector: number[]; // Vehicle value at month t
}): AmortisationScheduleOutput {
  const {
    productType,
    vehiclePrice,
    deposit,
    customerAPR,
    termMonths,
    guaranteedFutureValue = 0,
    balloonAmount = 0,
    cprAnnualised = 0.06,
    monthlyDepreciationVector,
  } = params;

  const principal = Math.max(0, vehiclePrice - deposit);
  const r = aprToMonthlyRate(customerAPR);

  // Single Monthly Mortality (SMM) from CPR: SMM = 1 - (1 - CPR)^(1/12)
  const smm = 1 - Math.pow(1 - Math.max(0, Math.min(0.5, cprAnnualised)), 1 / 12);

  let finalBalloon = 0;
  if (productType === 'PCP') {
    finalBalloon = guaranteedFutureValue;
  } else if (productType === 'Balloon Loan') {
    finalBalloon = balloonAmount;
  }

  // Monthly payment calculation:
  // PV = M * [1 - (1+r)^(-n)] / r + Balloon * (1+r)^(-n)
  // M = [Principal - Balloon * (1+r)^(-n)] * [r / (1 - (1+r)^(-n))]
  let monthlyPayment = 0;
  if (r > 0) {
    const discountFactorN = Math.pow(1 + r, -termMonths);
    const annuityFactor = (1 - discountFactorN) / r;
    monthlyPayment = (principal - finalBalloon * discountFactorN) / annuityFactor;
  } else {
    monthlyPayment = (principal - finalBalloon) / termMonths;
  }

  monthlyPayment = Math.round(monthlyPayment * 100) / 100;

  const totalAmountPayable = deposit + (monthlyPayment * termMonths) + finalBalloon;
  const fiftyPercentThreshold = totalAmountPayable / 2;

  let cumulativePaid = deposit;
  let voluntaryTerminationMonth = termMonths;
  let runningBalance = principal;
  let totalInterestPayable = 0;

  const periods: LoanCashFlowPeriod[] = [];

  for (let m = 1; m <= termMonths; m++) {
    const openingBalance = runningBalance;
    const scheduledInterest = Math.round(openingBalance * r * 100) / 100;
    
    let scheduledPrincipal = 0;
    if (m === termMonths) {
      // Final month: clears the remaining amortised part plus balloon
      scheduledPrincipal = Math.round(openingBalance * 100) / 100;
    } else {
      scheduledPrincipal = Math.round((monthlyPayment - scheduledInterest) * 100) / 100;
    }

    // Apply SMM prepayment (unscheduled voluntary early principal reduction)
    const prepayableBalance = Math.max(0, openingBalance - scheduledPrincipal);
    const prepaymentPrincipal = m === termMonths ? 0 : Math.round(prepayableBalance * smm * 100) / 100;

    const closingBalance = Math.max(0, Math.round((openingBalance - scheduledPrincipal - prepaymentPrincipal) * 100) / 100);
    runningBalance = closingBalance;

    totalInterestPayable += scheduledInterest;
    cumulativePaid += (scheduledPrincipal + scheduledInterest);

    if (cumulativePaid >= fiftyPercentThreshold && voluntaryTerminationMonth === termMonths) {
      voluntaryTerminationMonth = m;
    }

    // Vehicle value at month m
    const vehicleVal = monthlyDepreciationVector[m] ?? (vehiclePrice * Math.pow(0.97, m));
    const customerEquity = Math.round((vehicleVal - closingBalance) * 100) / 100;

    const totalCashFlow = Math.round((scheduledPrincipal + scheduledInterest + prepaymentPrincipal) * 100) / 100;

    periods.push({
      periodMonth: m,
      openingBalance,
      scheduledPrincipal,
      scheduledInterest,
      prepaymentPrincipal,
      defaultLoss: 0,
      recoveryProceeds: 0,
      closingBalance,
      customerEquity,
      totalCashFlow,
    });
  }

  return {
    monthlyPayment,
    totalInterestPayable: Math.round(totalInterestPayable * 100) / 100,
    totalAmountPayable: Math.round(totalAmountPayable * 100) / 100,
    guaranteedFutureValue: finalBalloon,
    voluntaryTerminationMonth,
    periods,
  };
}
