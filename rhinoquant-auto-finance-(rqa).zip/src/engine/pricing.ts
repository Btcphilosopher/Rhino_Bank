/**
 * RhinoQuant Auto Finance
 * Institutional RAROC Pricing Engine & Dynamic Rate Sheet Matrix
 */

import { RiskGrade } from '../types/finance';

export interface PricingDecomposition {
  fundingCostPct: number;
  expectedCreditLossPct: number;
  operatingServicingPct: number;
  economicCapitalChargePct: number;
  liquidityPremiumPct: number;
  targetProfitMarginPct: number;
  totalRequiredCustomerRatePct: number;
  rarocContributionPct: number; // Return on Economic Capital
}

export interface RateSheetCell {
  riskGrade: RiskGrade;
  termMonths: number;
  customerAPR: number;
  rarocPct: number;
  marginSpreadBp: number;
}

const GRADE_PD_BASELINE: Record<RiskGrade, number> = {
  A: 0.008, // 0.8%
  B: 0.019, // 1.9%
  C: 0.038, // 3.8%
  D: 0.075, // 7.5%
  E: 0.142, // 14.2%
};

const GRADE_LGD_BASELINE: Record<RiskGrade, number> = {
  A: 0.38, // 38%
  B: 0.42, // 42%
  C: 0.46, // 46%
  D: 0.52, // 52%
  E: 0.58, // 58%
};

/**
 * Calculates risk-adjusted loan pricing decomposition
 */
export function calculatePricingBreakdown(params: {
  riskGrade: RiskGrade;
  termMonths: number;
  baseFundingCostPct?: number; // e.g. 4.31% (SONIA + warehouse margin)
  targetRarocHurdlePct?: number; // e.g. 18.0%
}): PricingDecomposition {
  const {
    riskGrade,
    termMonths,
    baseFundingCostPct = 4.31,
    targetRarocHurdlePct = 18.0,
  } = params;

  // 1. Funding cost with term liquidity adjustment (+5bp per 12m beyond 24m)
  const termSpread = ((termMonths - 24) / 12) * 0.12;
  const fundingCostPct = baseFundingCostPct + Math.max(0, termSpread);

  // 2. Expected Credit Loss (ECL = PD * LGD annualised)
  const pd = GRADE_PD_BASELINE[riskGrade];
  const lgd = GRADE_LGD_BASELINE[riskGrade];
  const expectedCreditLossPct = pd * lgd * 100;

  // 3. Operating & Servicing Cost
  const operatingServicingPct = 0.35;

  // 4. Economic Capital Charge
  // Economic Capital is unexpected loss buffer: higher for weaker grades
  const capitalMultiplier = riskGrade === 'A' ? 0.045 : riskGrade === 'B' ? 0.065 : riskGrade === 'C' ? 0.085 : riskGrade === 'D' ? 0.120 : 0.165;
  const economicCapitalChargePct = capitalMultiplier * (targetRarocHurdlePct / 100) * 100;

  // 5. Liquidity Premium
  const liquidityPremiumPct = 0.25;

  // 6. Target Profit Margin
  const targetProfitMarginPct = 1.45;

  const totalRequiredCustomerRatePct = 
    fundingCostPct +
    expectedCreditLossPct +
    operatingServicingPct +
    economicCapitalChargePct +
    liquidityPremiumPct +
    targetProfitMarginPct;

  // Calculate actual RAROC contribution = (Net Margin / Economic Capital)
  const grossYield = totalRequiredCustomerRatePct;
  const netEarnings = grossYield - fundingCostPct - expectedCreditLossPct - operatingServicingPct;
  const rarocContributionPct = (netEarnings / (capitalMultiplier * 100)) * 100;

  return {
    fundingCostPct: Number(fundingCostPct.toFixed(2)),
    expectedCreditLossPct: Number(expectedCreditLossPct.toFixed(2)),
    operatingServicingPct: Number(operatingServicingPct.toFixed(2)),
    economicCapitalChargePct: Number(economicCapitalChargePct.toFixed(2)),
    liquidityPremiumPct: Number(liquidityPremiumPct.toFixed(2)),
    targetProfitMarginPct: Number(targetProfitMarginPct.toFixed(2)),
    totalRequiredCustomerRatePct: Number(totalRequiredCustomerRatePct.toFixed(2)),
    rarocContributionPct: Number(rarocContributionPct.toFixed(2)),
  };
}

/**
 * Generates the institutional auto finance rate sheet matrix
 */
export function generateRateSheetMatrix(baseFundingCostPct: number = 4.31): RateSheetCell[] {
  const grades: RiskGrade[] = ['A', 'B', 'C', 'D', 'E'];
  const terms = [24, 36, 48, 60];
  const matrix: RateSheetCell[] = [];

  for (const grade of grades) {
    for (const term of terms) {
      const breakdown = calculatePricingBreakdown({
        riskGrade: grade,
        termMonths: term,
        baseFundingCostPct,
      });

      matrix.push({
        riskGrade: grade,
        termMonths: term,
        customerAPR: breakdown.totalRequiredCustomerRatePct,
        rarocPct: breakdown.rarocContributionPct,
        marginSpreadBp: Math.round((breakdown.totalRequiredCustomerRatePct - baseFundingCostPct) * 100),
      });
    }
  }

  return matrix;
}
