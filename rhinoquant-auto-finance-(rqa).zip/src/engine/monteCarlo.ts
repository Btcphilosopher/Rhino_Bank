/**
 * RhinoQuant Auto Finance
 * Vectorised Portfolio Monte Carlo Simulation & Value-at-Risk (VaR) Engine
 * Deterministic pseudo-random sequence for reproducibility (Seed: 0xRQA_2026)
 */

export interface MonteCarloDistribution {
  simulationCount: number;
  seed: string;
  expectedLossMean: number;
  p50Loss: number;
  p75Loss: number;
  p90Loss: number;
  p95VaR: number; // 95% Credit VaR
  p99VaR: number; // 99% Credit VaR
  histogramBins: { binLossM: number; count: number; cumulativePct: number }[];
  executionTimeMs: number;
}

// Linear Congruential PRNG with deterministic seed for full reproducibility
class DeterministicRNG {
  private state: number;

  constructor(seedHex: string = '0xRQA_2026') {
    let hash = 0;
    for (let i = 0; i < seedHex.length; i++) {
      hash = (hash << 5) - hash + seedHex.charCodeAt(i);
      hash |= 0;
    }
    this.state = Math.abs(hash) || 123456789;
  }

  // Uniform [0, 1)
  next(): number {
    this.state = (this.state * 1664525 + 1013904223) % 4294967296;
    return this.state / 4294967296;
  }

  // Box-Muller Standard Normal
  nextGaussian(): number {
    const u1 = Math.max(1e-7, this.next());
    const u2 = this.next();
    return Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  }
}

/**
 * Executes portfolio Monte Carlo simulation over 10,000 trials
 */
export function runPortfolioMonteCarlo(
  iterations: number = 10000,
  portfolioBalance: number = 2420000000,
  baselineEL: number = 24800000,
  seedHex: string = '0xRQA_2026'
): MonteCarloDistribution {
  const startTime = performance.now();
  const rng = new DeterministicRNG(seedHex);
  const losses: number[] = new Array(iterations);

  // Systematic macroeconomic factor loading (Vasicek single-factor model)
  const systematicWeight = 0.45; // correlation rho = 0.20 => sqrt(rho) = 0.45
  const idiosyncraticWeight = Math.sqrt(1 - systematicWeight * systematicWeight);

  for (let i = 0; i < iterations; i++) {
    // Systematic macro shock Z ~ N(0, 1)
    const zMacro = rng.nextGaussian();

    // Secondary collateral price shock Y ~ N(0, 1)
    const yCollateral = rng.nextGaussian();

    // Idiosyncratic credit shock
    const eps = rng.nextGaussian();

    const compositeFactor = systematicWeight * zMacro + idiosyncraticWeight * eps;

    // Loss calculation: Baseline EL scaled by log-normal credit environment
    const macroMultiplier = Math.exp(0.42 * compositeFactor - 0.5 * 0.42 * 0.42);
    
    // Collateral recovery shock: lower collateral value when macro is negative
    const recoveryMultiplier = 1.0 - Math.min(0.35, Math.max(-0.20, 0.08 * yCollateral - 0.12 * Math.min(0, zMacro)));

    const trialLoss = baselineEL * macroMultiplier * (1 / Math.max(0.65, recoveryMultiplier));
    losses[i] = trialLoss;
  }

  // Sort losses for empirical percentile evaluation
  losses.sort((a, b) => a - b);

  const p50Loss = Math.round(losses[Math.floor(iterations * 0.50)]);
  const p75Loss = Math.round(losses[Math.floor(iterations * 0.75)]);
  const p90Loss = Math.round(losses[Math.floor(iterations * 0.90)]);
  const p95VaR = Math.round(losses[Math.floor(iterations * 0.95)]); // 95% VaR
  const p99VaR = Math.round(losses[Math.floor(iterations * 0.99)]); // 99% VaR

  const totalSum = losses.reduce((acc, val) => acc + val, 0);
  const expectedLossMean = Math.round(totalSum / iterations);

  // Generate 16 histogram bins (in Millions GBP)
  const minM = Math.floor(losses[0] / 1000000);
  const maxM = Math.ceil(losses[losses.length - 1] / 1000000);
  const binStep = Math.max(1, (maxM - minM) / 16);

  const bins: { binLossM: number; count: number; cumulativePct: number }[] = [];
  for (let b = 0; b < 16; b++) {
    const lower = minM + b * binStep;
    const upper = lower + binStep;
    const count = losses.filter((l) => l / 1000000 >= lower && l / 1000000 < upper).length;
    bins.push({
      binLossM: Number(lower.toFixed(1)),
      count,
      cumulativePct: 0,
    });
  }

  let runningCount = 0;
  for (const bin of bins) {
    runningCount += bin.count;
    bin.cumulativePct = Number(((runningCount / iterations) * 100).toFixed(1));
  }

  const executionTimeMs = Math.round(performance.now() - startTime);

  return {
    simulationCount: iterations,
    seed: seedHex,
    expectedLossMean,
    p50Loss,
    p75Loss,
    p90Loss,
    p95VaR,
    p99VaR,
    histogramBins: bins,
    executionTimeMs,
  };
}
