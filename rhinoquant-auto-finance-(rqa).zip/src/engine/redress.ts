/**
 * RhinoQuant Auto Finance
 * Regulatory & Motor Finance Redress Engine (FCA 2026 DCA Framework)
 * Version-Controlled Rules for Discretionary Commission Arrangements (2007-2024)
 */

import { RedressCase } from '../types/finance';

export interface SchemeRuleConfiguration {
  version: string;
  schemeTitle: string;
  effectiveDate: string;
  isCourtChallengedOrSuspended: boolean;
  benchmarkLenderRateSpreadPct: number; // e.g. baseline benchmark rate
  compensatoryInterestRatePct: number; // e.g. 8.0% statutory simple interest
  interestCalculationMethod: 'SIMPLE_8PCT' | 'COMPOUND_COMMERCIAL' | 'STATUTORY_REBATE';
  includeExcessInterestPaid: boolean;
  timeLimitCutoffDate: string;
}

export const SCHEME_VERSIONS: Record<string, SchemeRuleConfiguration> = {
  'FCA-DCA-2026.2': {
    version: 'FCA-DCA-2026.2',
    schemeTitle: 'FCA Formal Redress Framework (Post-Consultation Consultation Rule 2026)',
    effectiveDate: '2026-05-01',
    isCourtChallengedOrSuspended: true, // Note court challenges as specified by prompt
    benchmarkLenderRateSpreadPct: 4.5,
    compensatoryInterestRatePct: 8.0,
    interestCalculationMethod: 'SIMPLE_8PCT',
    includeExcessInterestPaid: true,
    timeLimitCutoffDate: '2025-12-04',
  },
  'FCA-DCA-2025.1-CONSULTATION': {
    version: 'FCA-DCA-2025.1-CONSULTATION',
    schemeTitle: 'FCA Historical Consultation Draft (Pre-Suspension Proposal)',
    effectiveDate: '2025-01-11',
    isCourtChallengedOrSuspended: false,
    benchmarkLenderRateSpreadPct: 4.8,
    compensatoryInterestRatePct: 8.0,
    interestCalculationMethod: 'SIMPLE_8PCT',
    includeExcessInterestPaid: true,
    timeLimitCutoffDate: '2024-09-25',
  },
  'FINANCE-INDUSTRY-CHALLENGE-2026': {
    version: 'FINANCE-INDUSTRY-CHALLENGE-2026',
    schemeTitle: 'FLA / Lender Joint Defense Model (Direct Commission Difference Only)',
    effectiveDate: '2026-03-01',
    isCourtChallengedOrSuspended: false,
    benchmarkLenderRateSpreadPct: 5.2,
    compensatoryInterestRatePct: 4.25, // Bank of England base rate reference
    interestCalculationMethod: 'STATUTORY_REBATE',
    includeExcessInterestPaid: false,
    timeLimitCutoffDate: '2024-01-11',
  },
};

/**
 * Calculates redress liability for a historical motor-finance agreement
 */
export function calculateAgreementRedress(params: {
  financedAmount: number;
  contractAPR: number;
  agreementStartDate: string; // YYYY-MM-DD
  settlementDate?: string;
  schemeRule: SchemeRuleConfiguration;
}): {
  discretionaryCommissionPct: number;
  discretionaryCommissionAmount: number;
  statutoryInterestAmount: number;
  totalRedressPayable: number;
  yearsElapsed: number;
} {
  const {
    financedAmount,
    contractAPR,
    agreementStartDate,
    schemeRule,
  } = params;

  // Benchmark rate configured in scheme rule
  const benchmarkRate = schemeRule.benchmarkLenderRateSpreadPct;
  const discretionaryCommissionPct = Math.max(0, contractAPR - benchmarkRate);

  // Approximate commission received by broker/dealer on financed principal
  const discretionaryCommissionAmount = Math.round(financedAmount * (discretionaryCommissionPct / 100) * 0.72);

  // Calculate elapsed time from agreement origination to 2026 for statutory 8% interest
  const startYear = parseInt(agreementStartDate.substring(0, 4), 10) || 2018;
  const currentYear = 2026;
  const yearsElapsed = Math.max(1, currentYear - startYear);

  let statutoryInterestAmount = 0;
  if (schemeRule.interestCalculationMethod === 'SIMPLE_8PCT') {
    // FCA 8% simple statutory interest per annum
    statutoryInterestAmount = Math.round(discretionaryCommissionAmount * (schemeRule.compensatoryInterestRatePct / 100) * yearsElapsed);
  } else if (schemeRule.interestCalculationMethod === 'COMPOUND_COMMERCIAL') {
    statutoryInterestAmount = Math.round(discretionaryCommissionAmount * (Math.pow(1 + schemeRule.compensatoryInterestRatePct / 100, yearsElapsed) - 1));
  } else {
    statutoryInterestAmount = Math.round(discretionaryCommissionAmount * (0.0425 * yearsElapsed));
  }

  const totalRedressPayable = discretionaryCommissionAmount + statutoryInterestAmount;

  return {
    discretionaryCommissionPct: Number(discretionaryCommissionPct.toFixed(2)),
    discretionaryCommissionAmount,
    statutoryInterestAmount,
    totalRedressPayable,
    yearsElapsed,
  };
}

/**
 * Consumer Credit Promotion Checker (FCA CONC 3 Compliance)
 */
export interface PromotionComplianceCheckResult {
  isCompliant: boolean;
  representativeAprStated: boolean;
  riskWarningIncluded: boolean;
  representativeExampleValid: boolean;
  concerns: string[];
}

export function validateFinancialPromotionText(text: string): PromotionComplianceCheckResult {
  const textLower = text.toLowerCase();
  const concerns: string[] = [];

  const representativeAprStated = textLower.includes('representative') && (textLower.includes('apr') || textLower.includes('%'));
  if (!representativeAprStated) {
    concerns.push('CONC 3.5.3R: Missing mandatory "Representative APR" designation.');
  }

  const riskWarningIncluded = 
    textLower.includes('missed payment') || 
    textLower.includes('financial status') || 
    textLower.includes('repossession') || 
    textLower.includes('borrowing more') ||
    textLower.includes('vehicle may be repossessed');
  if (!riskWarningIncluded) {
    concerns.push('CONC 3.5.5R: Missing required prominent risk warning regarding non-payment / vehicle repossession.');
  }

  const hasVehiclePrice = textLower.includes('cash price') || textLower.includes('£') || textLower.includes('price');
  const hasDeposit = textLower.includes('deposit');
  const hasTerm = textLower.includes('month') || textLower.includes('payments');
  const representativeExampleValid = hasVehiclePrice && hasDeposit && hasTerm;
  if (!representativeExampleValid) {
    concerns.push('CONC 3.5.7R: Incomplete representative example table (must contain cash price, deposit, term, APR, and total amount payable).');
  }

  return {
    isCompliant: concerns.length === 0,
    representativeAprStated,
    riskWarningIncluded,
    representativeExampleValid,
    concerns,
  };
}
