/**
 * RhinoQuant Auto Finance
 * Institutional Credit Risk Engine (PD, LGD, EAD, Scorecard & Transition Matrices)
 */

import { Customer, RiskGrade, Vehicle } from '../types/finance';

export interface ScorecardResult {
  totalScore: number;
  riskGrade: RiskGrade;
  pd12m: number;
  pd24m: number;
  pdLifetime: number;
  positiveReasons: string[];
  negativeReasons: string[];
}

export interface TransitionMatrixRow {
  fromBucket: string;
  toCurrent: number;
  to1_30: number;
  to31_60: number;
  to61_90: number;
  to90Plus: number;
  toDefault: number;
}

/**
 * Institutional automotive credit scorecard
 * Transparent reason codes with zero unlawful/discriminatory proxies
 */
export function evaluateCreditScorecard(params: {
  customer: Customer;
  vehicle: Vehicle;
  loanAmount: number;
  depositAmount: number;
  termMonths: number;
  monthlyPayment: number;
}): ScorecardResult {
  const { customer, vehicle, loanAmount, depositAmount, monthlyPayment } = params;
  
  let score = 500; // Base score
  const positiveReasons: string[] = [];
  const negativeReasons: string[] = [];

  // 1. Bureau Score contribution (max 250 pts)
  const bureauContrib = Math.round((customer.bureauScore - 400) / 600 * 250);
  score += Math.max(-50, Math.min(250, bureauContrib));
  if (customer.bureauScore >= 750) {
    positiveReasons.push(`Prime bureau rating (${customer.bureauScore}/999)`);
  } else if (customer.bureauScore < 600) {
    negativeReasons.push(`Adverse bureau history (${customer.bureauScore}/999)`);
  }

  // 2. Deposit & Loan-to-Value (LTV)
  const totalValue = loanAmount + depositAmount;
  const ltv = totalValue > 0 ? loanAmount / totalValue : 1.0;
  if (ltv <= 0.80) {
    score += 80;
    positiveReasons.push(`Substantial cash deposit equity (LTV ${(ltv * 100).toFixed(1)}% <= 80%)`);
  } else if (ltv > 0.95) {
    score -= 60;
    negativeReasons.push(`High loan-to-value exposure (LTV ${(ltv * 100).toFixed(1)}% > 95%)`);
  }

  // 3. Payment-to-Income (Affordability)
  const pti = customer.affordability.monthlyNetIncome > 0 
    ? monthlyPayment / customer.affordability.monthlyNetIncome 
    : 0.35;
  if (pti <= 0.12) {
    score += 70;
    positiveReasons.push(`Robust affordability cushion (Payment-to-Income ${(pti * 100).toFixed(1)}%)`);
  } else if (pti > 0.22) {
    score -= 85;
    negativeReasons.push(`Elevated debt servicing burden (Payment-to-Income ${(pti * 100).toFixed(1)}% > 22%)`);
  }

  // 4. Employment Stability
  if (customer.employmentStatus === 'PERMANENT' && customer.tenureYears >= 3) {
    score += 50;
    positiveReasons.push(`Established employment tenure (${customer.tenureYears} yrs)`);
  } else if (customer.tenureYears < 1) {
    score -= 30;
    negativeReasons.push(`Short employment tenure (< 1 yr)`);
  }

  // 5. Residual Disposable Income check
  if (customer.affordability.residualDisposableIncome < 400) {
    score -= 75;
    negativeReasons.push(`Tight post-expenditure disposable income buffer (< £400/mo)`);
  } else if (customer.affordability.residualDisposableIncome >= 1500) {
    score += 45;
    positiveReasons.push(`Strong residual cash buffer (£${customer.affordability.residualDisposableIncome.toLocaleString()}/mo)`);
  }

  // 6. Vehicle collateral liquidity
  if (vehicle.segment === 'SUV/Crossover' || vehicle.segment === 'Executive Saloon') {
    score += 20;
    positiveReasons.push(`High secondary market auction liquidity for segment (${vehicle.segment})`);
  }

  // Clamp score
  score = Math.max(300, Math.min(950, score));

  // Determine Risk Grade
  let riskGrade: RiskGrade = 'C';
  let pd12m = 0.029; // default baseline

  if (score >= 780) {
    riskGrade = 'A';
    pd12m = 0.008; // 0.8%
  } else if (score >= 690) {
    riskGrade = 'B';
    pd12m = 0.019; // 1.9%
  } else if (score >= 600) {
    riskGrade = 'C';
    pd12m = 0.038; // 3.8%
  } else if (score >= 510) {
    riskGrade = 'D';
    pd12m = 0.075; // 7.5%
  } else {
    riskGrade = 'E';
    pd12m = 0.142; // 14.2%
  }

  const pd24m = Number((1 - Math.pow(1 - pd12m, 2) * 0.95).toFixed(4));
  const pdLifetime = Number((1 - Math.pow(1 - pd12m, 3.5)).toFixed(4));

  return {
    totalScore: score,
    riskGrade,
    pd12m,
    pd24m,
    pdLifetime,
    positiveReasons,
    negativeReasons,
  };
}

/**
 * Calculates Collateral-Adjusted Loss Given Default (LGD)
 * Incorporates auction recovery haircuts, repossession costs, and vehicle depreciation
 */
export function calculateLGD(params: {
  outstandingBalance: number;
  vehicleAuctionValue: number;
  recoveryCostFixed?: number; // average UK repossession & bailiff fee ~£950
  auctionSalesFeePct?: number; // 5%
  isBEV?: boolean;
  bevResidualShockPct?: number;
}): { lgd: number; netRecovery: number; grossLoss: number } {
  const {
    outstandingBalance,
    vehicleAuctionValue,
    recoveryCostFixed = 950,
    auctionSalesFeePct = 0.05,
    isBEV = false,
    bevResidualShockPct = 0,
  } = params;

  if (outstandingBalance <= 0) {
    return { lgd: 0, netRecovery: 0, grossLoss: 0 };
  }

  let effectiveAuctionValue = vehicleAuctionValue;
  if (isBEV && bevResidualShockPct !== 0) {
    effectiveAuctionValue *= (1 + bevResidualShockPct);
  }

  const liquidationCost = recoveryCostFixed + (effectiveAuctionValue * auctionSalesFeePct);
  const netRecovery = Math.max(0, effectiveAuctionValue - liquidationCost);
  const grossLoss = Math.max(0, outstandingBalance - netRecovery);

  const lgd = Math.max(0.05, Math.min(0.95, grossLoss / outstandingBalance));

  return {
    lgd: Number(lgd.toFixed(4)),
    netRecovery: Math.round(netRecovery),
    grossLoss: Math.round(grossLoss),
  };
}

/**
 * Delinquency Roll-Rate Transition Matrix (Monthly transition probabilities)
 */
export const BASELINE_TRANSITION_MATRIX: TransitionMatrixRow[] = [
  {
    fromBucket: 'CURRENT',
    toCurrent: 0.962,
    to1_30: 0.035,
    to31_60: 0.002,
    to61_90: 0.0007,
    to90Plus: 0.0002,
    toDefault: 0.0001,
  },
  {
    fromBucket: '1-30 DPD',
    toCurrent: 0.720, // 72% cure rate
    to1_30: 0.080,
    to31_60: 0.175,
    to61_90: 0.018,
    to90Plus: 0.005,
    toDefault: 0.002,
  },
  {
    fromBucket: '31-60 DPD',
    toCurrent: 0.310, // 31% cure
    to1_30: 0.140,
    to31_60: 0.120,
    to61_90: 0.370,
    to90Plus: 0.045,
    toDefault: 0.015,
  },
  {
    fromBucket: '61-90 DPD',
    toCurrent: 0.110,
    to1_30: 0.070,
    to31_60: 0.150,
    to61_90: 0.120,
    to90Plus: 0.460,
    toDefault: 0.090,
  },
  {
    fromBucket: '90+ DPD',
    toCurrent: 0.035,
    to1_30: 0.025,
    to31_60: 0.060,
    to61_90: 0.110,
    to90Plus: 0.220,
    toDefault: 0.550, // 55% roll to formal default/repo
  },
];
