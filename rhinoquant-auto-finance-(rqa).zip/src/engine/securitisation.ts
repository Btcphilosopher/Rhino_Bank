/**
 * RhinoQuant Auto Finance
 * Institutional ABS Securitisation & Priority-of-Payments Waterfall Engine
 */

import { Loan, SecuritisationDeal, Tranche } from '../types/finance';

export interface WaterfallRunOutput {
  period: number;
  availableCollections: number;
  seniorFeesPaid: number;
  trancheInterestPaid: Record<string, number>;
  tranchePrincipalPaid: Record<string, number>;
  reserveAccountEndingBalance: number;
  excessSpreadReleased: number;
  trancheBalancesEnding: Record<string, number>;
  trancheCumulativeLosses: Record<string, number>;
}

/**
 * Filter portfolio for ABS securitisation eligibility
 */
export function filterEligibleAbsPool(loans: Loan[], criteria: {
  minBureauScore?: number;
  maxLTV?: number;
  minSeasoningMonths?: number;
  maxDPD?: number;
  excludeChargedOff?: boolean;
}): { eligibleLoans: Loan[]; rejectedCount: number; poolBalance: number } {
  const {
    minBureauScore = 580,
    maxLTV = 0.95,
    minSeasoningMonths = 2,
    maxDPD = 0,
    excludeChargedOff = true,
  } = criteria;

  const eligibleLoans = loans.filter((loan) => {
    if (loan.vehicle.mileage > 100000) return false;
    if (loan.daysPastDue > maxDPD) return false;
    if (loan.seasoningMonths < minSeasoningMonths) return false;
    if (loan.ltvCurrent > maxLTV) return false;
    if (excludeChargedOff && (loan.status === 'DEFAULT' || loan.status === 'CHARGED_OFF' || loan.status === 'RECOVERY')) {
      return false;
    }
    return true;
  });

  const poolBalance = eligibleLoans.reduce((sum, l) => sum + l.currentOutstandingBalance, 0);

  return {
    eligibleLoans,
    rejectedCount: loans.length - eligibleLoans.length,
    poolBalance: Math.round(poolBalance),
  };
}

/**
 * Creates standard RhinoQuant Auto ABS Deal Structure (e.g. £500M notional reference)
 */
export function buildDefaultAbsStructure(poolBalance: number = 500000000, soniaRatePct: number = 4.25): SecuritisationDeal {
  const classAPrincipal = Math.round(poolBalance * 0.845);
  const classBPrincipal = Math.round(poolBalance * 0.060);
  const classCPrincipal = Math.round(poolBalance * 0.045);
  const classDPrincipal = Math.round(poolBalance * 0.025);
  const residualPrincipal = poolBalance - (classAPrincipal + classBPrincipal + classCPrincipal + classDPrincipal);

  const tranches: Tranche[] = [
    {
      id: 'TR-A',
      name: 'Class A Notes',
      ratingAgency: 'AAA (sf)',
      initialPrincipal: classAPrincipal,
      currentPrincipal: classAPrincipal,
      originalNotePct: 84.5,
      couponSpreadBp: 75,
      couponRatePct: Number((soniaRatePct + 0.75).toFixed(2)),
      attachmentPointPct: 15.5,
      detachmentPointPct: 100.0,
      weightedAverageLifeYears: 2.35,
      durationYears: 2.18,
      yieldToMaturityPct: Number((soniaRatePct + 0.75).toFixed(2)),
      cumulativeLossAllocation: 0,
      lossBufferRemainingPct: 15.5,
    },
    {
      id: 'TR-B',
      name: 'Class B Notes',
      ratingAgency: 'AA (sf)',
      initialPrincipal: classBPrincipal,
      currentPrincipal: classBPrincipal,
      originalNotePct: 6.0,
      couponSpreadBp: 130,
      couponRatePct: Number((soniaRatePct + 1.30).toFixed(2)),
      attachmentPointPct: 9.5,
      detachmentPointPct: 15.5,
      weightedAverageLifeYears: 3.42,
      durationYears: 3.12,
      yieldToMaturityPct: Number((soniaRatePct + 1.35).toFixed(2)),
      cumulativeLossAllocation: 0,
      lossBufferRemainingPct: 9.5,
    },
    {
      id: 'TR-C',
      name: 'Class C Notes',
      ratingAgency: 'BBB (sf)',
      initialPrincipal: classCPrincipal,
      currentPrincipal: classCPrincipal,
      originalNotePct: 4.5,
      couponSpreadBp: 220,
      couponRatePct: Number((soniaRatePct + 2.20).toFixed(2)),
      attachmentPointPct: 5.0,
      detachmentPointPct: 9.5,
      weightedAverageLifeYears: 3.90,
      durationYears: 3.51,
      yieldToMaturityPct: Number((soniaRatePct + 2.30).toFixed(2)),
      cumulativeLossAllocation: 0,
      lossBufferRemainingPct: 5.0,
    },
    {
      id: 'TR-D',
      name: 'Class D Notes',
      ratingAgency: 'BB (sf)',
      initialPrincipal: classDPrincipal,
      currentPrincipal: classDPrincipal,
      originalNotePct: 2.5,
      couponSpreadBp: 410,
      couponRatePct: Number((soniaRatePct + 4.10).toFixed(2)),
      attachmentPointPct: 2.5,
      detachmentPointPct: 5.0,
      weightedAverageLifeYears: 4.20,
      durationYears: 3.75,
      yieldToMaturityPct: Number((soniaRatePct + 4.25).toFixed(2)),
      cumulativeLossAllocation: 0,
      lossBufferRemainingPct: 2.5,
    },
    {
      id: 'TR-EQUITY',
      name: 'Residual Certificates (First Loss)',
      ratingAgency: 'Unrated (Equity)',
      initialPrincipal: residualPrincipal,
      currentPrincipal: residualPrincipal,
      originalNotePct: 2.5,
      couponSpreadBp: 0,
      couponRatePct: 0,
      attachmentPointPct: 0.0,
      detachmentPointPct: 2.5,
      weightedAverageLifeYears: 4.50,
      durationYears: 3.95,
      yieldToMaturityPct: 16.80, // Target Equity IRR
      cumulativeLossAllocation: 0,
      lossBufferRemainingPct: 0.0,
    },
  ];

  const reserveTarget = Math.round(poolBalance * 0.015); // 1.5% liquidity reserve

  return {
    id: 'RQA-ABS-2026-1',
    dealName: 'RHINO AUTO ABS 2026-1',
    closingDate: '2026-03-15',
    originalPoolBalance: poolBalance,
    currentPoolBalance: poolBalance,
    weightedAverageCouponPct: 8.42,
    weightedAverageRemainingTermMonths: 38,
    weightedAverageLTVPct: 81.4,
    weightedAverageBureauScore: 718,
    overcollateralisationAmount: Math.round(poolBalance * 0.010),
    reserveAccountTargetAmount: reserveTarget,
    reserveAccountCurrentBalance: reserveTarget,
    excessSpreadAnnualisedPct: 2.85,
    tranches,
    collections: [],
  };
}

/**
 * Executes multi-period deterministic waterfall cash flows with sequential priority
 */
export function simulateWaterfallSchedule(deal: SecuritisationDeal, periodsCount: number = 36, stressMultiplier: number = 1.0): WaterfallRunOutput[] {
  let poolBal = deal.currentPoolBalance;
  let reserveBal = deal.reserveAccountCurrentBalance;
  const servicerFeeAnnualPct = 0.0035; // 35bp servicer fee

  const trancheBalances: Record<string, number> = {};
  const trancheCumulativeLosses: Record<string, number> = {};
  deal.tranches.forEach((t) => {
    trancheBalances[t.id] = t.initialPrincipal;
    trancheCumulativeLosses[t.id] = 0;
  });

  const results: WaterfallRunOutput[] = [];

  for (let m = 1; m <= periodsCount; m++) {
    // Expected monthly collections (8.4% annual coupon amortising with 6% CPR)
    const monthlyCoupon = deal.weightedAverageCouponPct / 100 / 12;
    const monthlyPrincipalAmortPct = (1 / Math.max(1, deal.weightedAverageRemainingTermMonths - m + 1)) * 0.9;
    
    // Baseline monthly default rate
    const baseDefaultPct = (0.029 / 12) * stressMultiplier;
    const recoveryPct = Math.max(0.20, 0.58 / Math.sqrt(stressMultiplier)); // recoveries drop under stress
    
    const defaultedPrincipal = poolBal * baseDefaultPct;
    const grossLoss = defaultedPrincipal * (1 - recoveryPct);
    const recoveredCash = defaultedPrincipal * recoveryPct;

    const scheduledPrincipal = (poolBal - defaultedPrincipal) * monthlyPrincipalAmortPct;
    const prepayPrincipal = (poolBal - defaultedPrincipal - scheduledPrincipal) * (0.06 / 12);
    const interestCollections = (poolBal * monthlyCoupon);
    const totalPrincipalCollected = scheduledPrincipal + prepayPrincipal + recoveredCash;

    const availableCash = interestCollections + totalPrincipalCollected;

    // 1. Senior Fees (Servicer, Trustee, Corporate)
    const seniorFeesPaid = (poolBal * (servicerFeeAnnualPct / 12));
    let remainingCash = Math.max(0, availableCash - seniorFeesPaid);

    // 2. Note Interest sequentially (A -> B -> C -> D)
    const interestPaid: Record<string, number> = {};
    for (const t of deal.tranches) {
      if (t.id === 'TR-EQUITY') continue;
      const rateMonthly = (t.couponRatePct / 100) / 12;
      const due = trancheBalances[t.id] * rateMonthly;
      const pay = Math.min(remainingCash, due);
      interestPaid[t.id] = Math.round(pay);
      remainingCash -= pay;
    }

    // 3. Principal Allocation (Strict Sequential Paydown: A first, then B, C, D)
    const principalPaid: Record<string, number> = {};
    for (const t of deal.tranches) {
      principalPaid[t.id] = 0;
    }

    let principalAvailable = totalPrincipalCollected;
    for (const t of deal.tranches) {
      if (t.id === 'TR-EQUITY') continue;
      if (trancheBalances[t.id] > 0) {
        const payPrincipal = Math.min(principalAvailable, trancheBalances[t.id]);
        principalPaid[t.id] = Math.round(payPrincipal);
        trancheBalances[t.id] -= payPrincipal;
        principalAvailable -= payPrincipal;
        if (principalAvailable <= 0) break;
      }
    }

    // 4. Loss allocation from bottom up (Equity -> D -> C -> B -> A)
    let lossToAllocate = grossLoss;
    const tranchesReverse = [...deal.tranches].reverse();
    for (const t of tranchesReverse) {
      if (lossToAllocate <= 0) break;
      if (trancheBalances[t.id] > 0) {
        const lossAbsorbed = Math.min(lossToAllocate, trancheBalances[t.id]);
        trancheBalances[t.id] -= lossAbsorbed;
        trancheCumulativeLosses[t.id] += Math.round(lossAbsorbed);
        lossToAllocate -= lossAbsorbed;
      }
    }

    // 5. Reserve account replenishment
    if (reserveBal < deal.reserveAccountTargetAmount && remainingCash > 0) {
      const topUp = Math.min(deal.reserveAccountTargetAmount - reserveBal, remainingCash);
      reserveBal += topUp;
      remainingCash -= topUp;
    }

    // 6. Excess spread release to Equity
    const excessSpreadReleased = Math.max(0, Math.round(remainingCash));

    poolBal = Math.max(0, poolBal - scheduledPrincipal - prepayPrincipal - grossLoss);

    results.push({
      period: m,
      availableCollections: Math.round(availableCash),
      seniorFeesPaid: Math.round(seniorFeesPaid),
      trancheInterestPaid: interestPaid,
      tranchePrincipalPaid: principalPaid,
      reserveAccountEndingBalance: Math.round(reserveBal),
      excessSpreadReleased,
      trancheBalancesEnding: { ...trancheBalances },
      trancheCumulativeLosses: { ...trancheCumulativeLosses },
    });
  }

  return results;
}
