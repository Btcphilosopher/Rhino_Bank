/**
 * RhinoQuant Auto Finance
 * Institutional Stress Testing & Macroeconomic Scenario Engine
 */

import { StressScenarioConfig } from '../types/finance';

export interface StressTestExecutionResult {
  scenarioId: string;
  scenarioName: string;
  baselineExpectedLoss: number;
  stressedExpectedLoss: number;
  deltaLossAmount: number;
  deltaLossPct: number;
  baselineRarocPct: number;
  stressedRarocPct: number;
  collateralShortfallAmount: number;
  economicCapitalRequiredDelta: number;
  trancheLosses: {
    classA: number;
    classB: number;
    classC: number;
    classD: number;
    equity: number;
  };
}

export const PRESET_STRESS_SCENARIOS: StressScenarioConfig[] = [
  {
    id: 'BASE',
    name: 'Base Contractual Expectations',
    description: 'Current macroeconomic baseline (Bank of England Bank Rate 4.75%, SONIA 4.70%, stable used car index).',
    pdMultiplier: 1.0,
    lgdMultiplier: 1.0,
    bevResidualShockPct: 0.0,
    fundingRateShiftBp: 0,
    prepaymentMultiplier: 1.0,
    unemploymentShockPct: 0.0,
  },
  {
    id: 'BEV_SHOCK_10',
    name: 'BEV Residual Value Shock (-10%)',
    description: 'Electric vehicle secondary wholesale auction prices drop by 10% due to rapid battery cycle upgrades.',
    pdMultiplier: 1.05,
    lgdMultiplier: 1.14,
    bevResidualShockPct: -0.10,
    fundingRateShiftBp: 15,
    prepaymentMultiplier: 0.95,
    unemploymentShockPct: 0.0,
  },
  {
    id: 'BEV_SHOCK_20',
    name: 'BEV Residual Value Shock (-20%)',
    description: 'Severe secondary EV auction price slump of 20%, collateral recovery haircuts escalate across PCP lease ends.',
    pdMultiplier: 1.12,
    lgdMultiplier: 1.28,
    bevResidualShockPct: -0.20,
    fundingRateShiftBp: 35,
    prepaymentMultiplier: 0.90,
    unemploymentShockPct: 0.5,
  },
  {
    id: 'BEV_SHOCK_30',
    name: 'BEV Residual Value Shock (-30%)',
    description: 'Crisis-level depreciation shock in battery electric fleet values (-30%), severe voluntary surrender s.99 spike.',
    pdMultiplier: 1.25,
    lgdMultiplier: 1.48,
    bevResidualShockPct: -0.30,
    fundingRateShiftBp: 75,
    prepaymentMultiplier: 0.80,
    unemploymentShockPct: 1.0,
  },
  {
    id: 'MILD_RECESSION',
    name: 'Mild Stagflation / Recession',
    description: 'GDP contraction of 0.8%, unemployment increases +1.8%, used car values decline 8%.',
    pdMultiplier: 1.28,
    lgdMultiplier: 1.18,
    bevResidualShockPct: -0.12,
    fundingRateShiftBp: 65,
    prepaymentMultiplier: 0.85,
    unemploymentShockPct: 1.8,
  },
  {
    id: 'SEVERE_RECESSION',
    name: 'Severe PRA/EBA Macro Stress Scenario',
    description: 'Severe macroeconomic downturn: unemployment +4.2%, commercial bank funding spread widens +150bp, 22% used vehicle crash.',
    pdMultiplier: 1.68,
    lgdMultiplier: 1.42,
    bevResidualShockPct: -0.28,
    fundingRateShiftBp: 150,
    prepaymentMultiplier: 0.70,
    unemploymentShockPct: 4.2,
  },
  {
    id: 'INTEREST_RATE_SHOCK',
    name: 'Interest Rate Spike (+200bp)',
    description: 'Inflation reacceleration pushes benchmark SONIA up by 200bp, compressing warehouse facility net interest margin.',
    pdMultiplier: 1.18,
    lgdMultiplier: 1.08,
    bevResidualShockPct: -0.05,
    fundingRateShiftBp: 200,
    prepaymentMultiplier: 0.65,
    unemploymentShockPct: 0.8,
  },
  {
    id: 'SUBPRIME_DEFAULT_SHOCK',
    name: 'Subprime / Grade D-E Credit Collapse',
    description: 'Delinquency and default contagion isolated to Risk Grades D and E with 120% surge in default probabilities.',
    pdMultiplier: 1.85,
    lgdMultiplier: 1.35,
    bevResidualShockPct: -0.15,
    fundingRateShiftBp: 90,
    prepaymentMultiplier: 0.75,
    unemploymentShockPct: 2.5,
  },
];

/**
 * Evaluates stress scenario on portfolio (£2.42bn baseline)
 */
export function executeStressScenario(
  scenario: StressScenarioConfig,
  portfolioBalance: number = 2420000000,
  baselineEL: number = 24800000,
  baselineRaroc: number = 18.7,
  bevPortfolioSharePct: number = 0.214 // 21.4%
): StressTestExecutionResult {
  // Stressed EL = Baseline EL * pdMultiplier * lgdMultiplier
  // plus specific collateral shortfall from BEV residual shock
  const bevSubportfolioBalance = portfolioBalance * bevPortfolioSharePct;
  const collateralShortfallAmount = Math.abs(scenario.bevResidualShockPct) * bevSubportfolioBalance * 0.32; // ~32% end-of-term balloon exposure

  const lossMultiplier = scenario.pdMultiplier * scenario.lgdMultiplier;
  const stressedExpectedLoss = Math.round((baselineEL * lossMultiplier) + (collateralShortfallAmount * 0.18));
  const deltaLossAmount = stressedExpectedLoss - baselineEL;
  const deltaLossPct = Number(((deltaLossAmount / baselineEL) * 100).toFixed(1));

  // RAROC compression: yield remains contractual while cost of funding and ECL rise
  const fundingCostIncrease = (scenario.fundingRateShiftBp / 10000) * portfolioBalance;
  const totalEarningsDeterioration = deltaLossAmount + fundingCostIncrease;
  const economicCapitalBase = 91000000; // £91m base economic capital
  const economicCapitalRequiredDelta = Math.round(deltaLossAmount * 2.8);

  const stressedNetIncome = 47000000 - (totalEarningsDeterioration * 0.25);
  const stressedTotalCapital = economicCapitalBase + economicCapitalRequiredDelta;
  const stressedRarocPct = Math.max(0.5, Number(((stressedNetIncome / stressedTotalCapital) * 100).toFixed(1)));

  // ABS Tranche loss distribution (assume £500m issuance pool slice)
  // Equity: £12.5m, Class D: £12.5m, Class C: £22.5m, Class B: £30m, Class A: £422.5m
  const simulatedAbsLoss = deltaLossAmount * 0.20; // 20% ABS pool share
  let unallocated = simulatedAbsLoss;

  const equityLoss = Math.min(12500000, unallocated);
  unallocated -= equityLoss;

  const classDLoss = Math.min(12500000, unallocated);
  unallocated -= classDLoss;

  const classCLoss = Math.min(22500000, unallocated);
  unallocated -= classCLoss;

  const classBLoss = Math.min(30000000, unallocated);
  unallocated -= classBLoss;

  const classALoss = Math.min(422500000, unallocated);

  return {
    scenarioId: scenario.id,
    scenarioName: scenario.name,
    baselineExpectedLoss: baselineEL,
    stressedExpectedLoss,
    deltaLossAmount,
    deltaLossPct,
    baselineRarocPct: baselineRaroc,
    stressedRarocPct,
    collateralShortfallAmount: Math.round(collateralShortfallAmount),
    economicCapitalRequiredDelta,
    trancheLosses: {
      classA: Math.round(classALoss),
      classB: Math.round(classBLoss),
      classC: Math.round(classCLoss),
      classD: Math.round(classDLoss),
      equity: Math.round(equityLoss),
    },
  };
}
