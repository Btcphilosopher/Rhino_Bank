/**
 * RhinoQuant Auto Finance (RQA)
 * Institutional Automotive Finance Analytics, Valuation & Securitisation Terminal
 */

import React, { useState, useEffect } from 'react';
import { TerminalHeader } from './components/TerminalHeader';
import { CommandPaletteModal } from './components/CommandPaletteModal';
import { DataLineageModal } from './components/views/DataLineageModal';
import { ReportExportModal } from './components/views/ReportExportModal';
import { CommandCentreView } from './components/views/CommandCentreView';
import { OriginationPricingView } from './components/views/OriginationPricingView';
import { PortfolioAnalyticsView } from './components/views/PortfolioAnalyticsView';
import { ServicingDelinquencyView } from './components/views/ServicingDelinquencyView';
import { SecuritisationView } from './components/views/SecuritisationView';
import { FundingWarehouseView } from './components/views/FundingWarehouseView';
import { StressMonteCarloView } from './components/views/StressMonteCarloView';
import { DealerAnalyticsView } from './components/views/DealerAnalyticsView';
import { ModelRiskView } from './components/views/ModelRiskView';
import { RedressComplianceView } from './components/views/RedressComplianceView';
import { AuditTrailView } from './components/views/AuditTrailView';

export default function App() {
  const [activeCommand, setActiveCommand] = useState<string>('AUTO');
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState<boolean>(false);
  const [isDataLineageOpen, setIsDataLineageOpen] = useState<boolean>(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [lineageInitialMetric, setLineageInitialMetric] = useState<string>('EXPECTED_LOSS');

  // Global Keyboard Shortcuts (Ctrl+K or Cmd+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleExecuteCommand = (cmd: string) => {
    const normalized = cmd.toUpperCase().trim();
    if (normalized === 'DATA') {
      setIsDataLineageOpen(true);
      return;
    }
    if (normalized === 'REPORT') {
      setIsReportModalOpen(true);
      return;
    }
    setActiveCommand(normalized);
  };

  const handleOpenLineageForMetric = (metricKey?: string) => {
    if (metricKey) {
      setLineageInitialMetric(metricKey);
    }
    setIsDataLineageOpen(true);
  };

  // Render view based on active command
  const renderView = () => {
    switch (activeCommand) {
      case 'AUTO':
        return (
          <CommandCentreView
            onNavigate={handleExecuteCommand}
            onOpenDataLineage={handleOpenLineageForMetric}
          />
        );
      case 'PRICING':
      case 'CREDIT':
        return <OriginationPricingView />;
      case 'PORT':
      case 'LOAN':
        return <PortfolioAnalyticsView />;
      case 'RISK':
      case 'PD':
      case 'LGD':
        return <ServicingDelinquencyView />;
      case 'ABS':
      case 'WATERFALL':
        return <SecuritisationView />;
      case 'FUND':
        return <FundingWarehouseView />;
      case 'STRESS':
      case 'SCENARIO':
      case 'MONTE':
        return <StressMonteCarloView />;
      case 'DEALER':
        return <DealerAnalyticsView />;
      case 'MODEL':
        return <ModelRiskView />;
      case 'REDRESS':
      case 'COMPLIANCE':
        return <RedressComplianceView />;
      case 'AUDIT':
        return <AuditTrailView />;
      default:
        return (
          <CommandCentreView
            onNavigate={handleExecuteCommand}
            onOpenDataLineage={handleOpenLineageForMetric}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0e14] text-[#c9d1d9] flex flex-col font-sans selection:bg-[#238636]/30 selection:text-white">
      {/* Institutional Top Command Header */}
      <TerminalHeader
        currentCommand={activeCommand}
        onExecuteCommand={handleExecuteCommand}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        onOpenDataLineage={() => setIsDataLineageOpen(true)}
        onOpenReportModal={() => setIsReportModalOpen(true)}
      />

      {/* Main Terminal View Container */}
      <main className="flex-1 overflow-y-auto">
        {renderView()}
      </main>

      {/* Terminal Footer Status Strip */}
      <footer className="bg-[#0b0e14] border-t border-[#21262d] px-3 py-1 flex items-center justify-between text-[11px] font-mono text-[#8b949e] select-none">
        <div className="flex items-center space-x-3">
          <span className="flex items-center">
            <span className="w-1.5 h-1.5 rounded-full bg-[#3fb950] inline-block mr-1.5" />
            <span>DESK READY</span>
          </span>
          <span className="hidden sm:inline text-[#6e7681]">|</span>
          <span className="hidden sm:inline">
            SYSTEM: <strong>RHINOQUANT AUTO v3.8</strong>
          </span>
          <span className="hidden md:inline text-[#6e7681]">|</span>
          <span className="hidden md:inline">
            CORE: <strong>PYTHON 3.12 / RUST CASHFLOW ENGINE</strong>
          </span>
        </div>

        <div className="flex items-center space-x-3">
          <span className="hidden lg:inline text-[#6e7681]">
            SHORTCUTS: [Ctrl+K] Palette · [AUTO &lt;GO&gt;] Home · [REPORT] Dossier
          </span>
          <span className="text-[#d29922] font-semibold">
            RHINOBANK QUANTITATIVE FINANCE GROUP
          </span>
        </div>
      </footer>

      {/* Modals */}
      <CommandPaletteModal
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onSelectCommand={handleExecuteCommand}
      />

      <DataLineageModal
        isOpen={isDataLineageOpen}
        onClose={() => setIsDataLineageOpen(false)}
        initialMetric={lineageInitialMetric}
      />

      <ReportExportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
      />
    </div>
  );
}
