/**
 * RhinoQuant Auto Finance
 * Synthetic Institutional Portfolio Data Generator
 * STATUS: SYNTHETIC / SIMULATED | SEED: 0xRQA_2026
 * Modelled Scale: 250,000 Loans | £3.20bn Originated | £2.42bn Current Balance
 */

import {
  AuditRecord,
  Customer,
  DealerPerformance,
  FinanceProduct,
  FuelType,
  Loan,
  ModelRiskRecord,
  RedressCase,
  RiskGrade,
  Vehicle,
  VehicleSegment,
  WarehouseFacility,
} from '../types/finance';
import { generateLoanCashFlowSchedule } from '../engine/amortisation';
import { calculateDepreciationCurve } from '../engine/depreciation';

export interface PortfolioAggregateMetrics {
  totalLoanCount: number;
  totalCurrentBalanceGBP: number;
  totalOriginalPrincipalGBP: number;
  weightedAverageCustomerAPR: number;
  weightedAverageOriginalLTV: number;
  weightedAverageCurrentLTV: number;
  weightedAverageSeasoningMonths: number;
  weightedAverageRemainingTermMonths: number;
  expectedLossGBP: number;
  defaultRate12mPct: number;
  portfolioRarocPct: number;
  bevPortfolioSharePct: number;
  baseFundingCostPct: number;
  soniaBenchmarkPct: number;
  cprAnnualisedPct: number;
  economicCapitalGBP: number;
  netInterestIncomeGBP: number;
}

export const SYNTHETIC_PORTFOLIO_METRICS: PortfolioAggregateMetrics = {
  totalLoanCount: 184291,
  totalCurrentBalanceGBP: 2420000000, // £2.42bn
  totalOriginalPrincipalGBP: 3205000000, // £3.20bn
  weightedAverageCustomerAPR: 8.40,
  weightedAverageOriginalLTV: 86.2,
  weightedAverageCurrentLTV: 74.8,
  weightedAverageSeasoningMonths: 14.5,
  weightedAverageRemainingTermMonths: 33.5,
  expectedLossGBP: 24800000, // £24.8m
  defaultRate12mPct: 2.9,
  portfolioRarocPct: 18.7,
  bevPortfolioSharePct: 21.4,
  baseFundingCostPct: 4.31,
  soniaBenchmarkPct: 4.75,
  cprAnnualisedPct: 6.4,
  economicCapitalGBP: 91000000, // £91m
  netInterestIncomeGBP: 47000000, // £47m
};

// Vintages data breakdown (2023 Q1 to 2026 Q3)
export interface VintageSummary {
  vintageCohort: string;
  originationVolumeGBP: number;
  currentBalanceGBP: number;
  loanCount: number;
  avgAPR: number;
  cumulativeDefaultPct: number;
  cumulativeLossPct: number;
  thirtyPlusDpdPct: number;
  prepaymentCprPct: number;
  bevSharePct: number;
}

export const SYNTHETIC_VINTAGES: VintageSummary[] = [
  {
    vintageCohort: '2023-Q1',
    originationVolumeGBP: 310000000,
    currentBalanceGBP: 135000000,
    loanCount: 18900,
    avgAPR: 7.9,
    cumulativeDefaultPct: 4.8,
    cumulativeLossPct: 2.4,
    thirtyPlusDpdPct: 1.8,
    prepaymentCprPct: 8.2,
    bevSharePct: 14.2,
  },
  {
    vintageCohort: '2023-Q2',
    originationVolumeGBP: 335000000,
    currentBalanceGBP: 168000000,
    loanCount: 20200,
    avgAPR: 8.1,
    cumulativeDefaultPct: 4.2,
    cumulativeLossPct: 2.1,
    thirtyPlusDpdPct: 1.9,
    prepaymentCprPct: 7.8,
    bevSharePct: 16.5,
  },
  {
    vintageCohort: '2023-Q3',
    originationVolumeGBP: 360000000,
    currentBalanceGBP: 210000000,
    loanCount: 22100,
    avgAPR: 8.3,
    cumulativeDefaultPct: 3.6,
    cumulativeLossPct: 1.8,
    thirtyPlusDpdPct: 2.1,
    prepaymentCprPct: 7.4,
    bevSharePct: 18.1,
  },
  {
    vintageCohort: '2023-Q4',
    originationVolumeGBP: 385000000,
    currentBalanceGBP: 255000000,
    loanCount: 23400,
    avgAPR: 8.4,
    cumulativeDefaultPct: 3.1,
    cumulativeLossPct: 1.5,
    thirtyPlusDpdPct: 2.4,
    prepaymentCprPct: 6.9,
    bevSharePct: 19.8,
  },
  {
    vintageCohort: '2024-Q1',
    originationVolumeGBP: 410000000,
    currentBalanceGBP: 308000000,
    loanCount: 24800,
    avgAPR: 8.5,
    cumulativeDefaultPct: 2.5,
    cumulativeLossPct: 1.2,
    thirtyPlusDpdPct: 2.2,
    prepaymentCprPct: 6.5,
    bevSharePct: 21.0,
  },
  {
    vintageCohort: '2024-Q2',
    originationVolumeGBP: 430000000,
    currentBalanceGBP: 355000000,
    loanCount: 25600,
    avgAPR: 8.6,
    cumulativeDefaultPct: 1.9,
    cumulativeLossPct: 0.9,
    thirtyPlusDpdPct: 2.3,
    prepaymentCprPct: 6.2,
    bevSharePct: 22.4,
  },
  {
    vintageCohort: '2024-Q3',
    originationVolumeGBP: 445000000,
    currentBalanceGBP: 395000000,
    loanCount: 26100,
    avgAPR: 8.5,
    cumulativeDefaultPct: 1.3,
    cumulativeLossPct: 0.6,
    thirtyPlusDpdPct: 2.6,
    prepaymentCprPct: 5.8,
    bevSharePct: 23.8,
  },
  {
    vintageCohort: '2024-Q4',
    originationVolumeGBP: 420000000,
    currentBalanceGBP: 394000000,
    loanCount: 24100,
    avgAPR: 8.4,
    cumulativeDefaultPct: 0.7,
    cumulativeLossPct: 0.3,
    thirtyPlusDpdPct: 2.9, // Note: elevated 30+ DPD as per risk alerts
    prepaymentCprPct: 5.5,
    bevSharePct: 24.6,
  },
  {
    vintageCohort: '2025-Q1',
    originationVolumeGBP: 310000000,
    currentBalanceGBP: 300000000,
    loanCount: 17200,
    avgAPR: 8.3,
    cumulativeDefaultPct: 0.2,
    cumulativeLossPct: 0.1,
    thirtyPlusDpdPct: 1.8,
    prepaymentCprPct: 5.1,
    bevSharePct: 25.2,
  },
];

// Seed sample vehicles
export const VEHICLE_CATALOGUE: {
  make: string;
  model: string;
  derivative: string;
  segment: VehicleSegment;
  fuelType: FuelType;
  invoicePrice: number;
}[] = [
  { make: 'Tesla', model: 'Model Y', derivative: 'Long Range AWD', segment: 'SUV/Crossover', fuelType: 'BEV', invoicePrice: 52990 },
  { make: 'BMW', model: 'i4', derivative: 'eDrive40 M Sport', segment: 'Executive Saloon', fuelType: 'BEV', invoicePrice: 58800 },
  { make: 'Porsche', model: 'Taycan', derivative: '4S Performance Plus', segment: 'Sports/Performance', fuelType: 'BEV', invoicePrice: 94500 },
  { make: 'Hyundai', model: 'Ioniq 5', derivative: '77.4kWh Ultimate', segment: 'SUV/Crossover', fuelType: 'BEV', invoicePrice: 48900 },
  { make: 'Volkswagen', model: 'Golf', derivative: '2.0 TDI R-Line DSG', segment: 'City/Compact', fuelType: 'ICE', invoicePrice: 32400 },
  { make: 'Ford', model: 'Puma', derivative: '1.0 EcoBoost mHEV ST-Line', segment: 'City/Compact', fuelType: 'Hybrid', invoicePrice: 28500 },
  { make: 'Land Rover', model: 'Range Rover Sport', derivative: 'P460e Dynamic SE PHEV', segment: 'SUV/Crossover', fuelType: 'PHEV', invoicePrice: 89400 },
  { make: 'Mercedes-Benz', model: 'C-Class', derivative: 'C300e AMG Line Premium Plus', segment: 'Executive Saloon', fuelType: 'PHEV', invoicePrice: 54200 },
  { make: 'Ford', model: 'Transit Custom', derivative: '2.0 EcoBlue 130ps Leader', segment: 'Commercial Van', fuelType: 'ICE', invoicePrice: 33800 },
  { make: 'Audi', model: 'A4 Avant', derivative: '35 TDI S line S Tronic', segment: 'Executive Saloon', fuelType: 'ICE', invoicePrice: 42100 },
];

export const SYNTHETIC_DEALERS: DealerPerformance[] = [
  {
    id: 'DLR-482',
    name: 'Apex Motor Group (North West)',
    region: 'North West',
    dealerType: 'CAR_SUPERMARKET',
    totalOriginationsVolume: 42800000,
    activeLoanCount: 2680,
    approvalRatePct: 61.2,
    averageLTVPct: 87.4,
    averageCustomerAPR: 8.95,
    defaultRate12mPct: 4.8, // ELEVATED as per risk alert
    voluntaryTerminationPct: 8.4,
    earlySettlementPct: 7.2,
    rarocMarginPct: 2.4,
    fraudAnomalyAlerts: 4,
    riskRating: 'TIER_3_WATCHLIST',
  },
  {
    id: 'DLR-105',
    name: 'Stratstone Prestige Franchised',
    region: 'Greater London',
    dealerType: 'FRANCHISED',
    totalOriginationsVolume: 124500000,
    activeLoanCount: 3120,
    approvalRatePct: 78.4,
    averageLTVPct: 79.2,
    averageCustomerAPR: 7.85,
    defaultRate12mPct: 1.4,
    voluntaryTerminationPct: 3.1,
    earlySettlementPct: 9.8,
    rarocMarginPct: 2.1,
    fraudAnomalyAlerts: 0,
    riskRating: 'TIER_1_PREFERRED',
  },
  {
    id: 'DLR-219',
    name: 'Lookers Automotive Midlands',
    region: 'Midlands',
    dealerType: 'FRANCHISED',
    totalOriginationsVolume: 89200000,
    activeLoanCount: 4250,
    approvalRatePct: 73.1,
    averageLTVPct: 82.5,
    averageCustomerAPR: 8.20,
    defaultRate12mPct: 2.1,
    voluntaryTerminationPct: 4.5,
    earlySettlementPct: 8.4,
    rarocMarginPct: 2.3,
    fraudAnomalyAlerts: 1,
    riskRating: 'TIER_1_PREFERRED',
  },
  {
    id: 'DLR-331',
    name: 'Cazoo Retail Direct Online',
    region: 'National',
    dealerType: 'DIRECT_OEM',
    totalOriginationsVolume: 64100000,
    activeLoanCount: 3890,
    approvalRatePct: 69.8,
    averageLTVPct: 85.0,
    averageCustomerAPR: 8.45,
    defaultRate12mPct: 2.7,
    voluntaryTerminationPct: 5.9,
    earlySettlementPct: 7.1,
    rarocMarginPct: 2.2,
    fraudAnomalyAlerts: 2,
    riskRating: 'TIER_2_STANDARD',
  },
  {
    id: 'DLR-590',
    name: 'Vanguard Commercial Fleets',
    region: 'South East',
    dealerType: 'INDEPENDENT',
    totalOriginationsVolume: 51300000,
    activeLoanCount: 1840,
    approvalRatePct: 81.0,
    averageLTVPct: 80.1,
    averageCustomerAPR: 7.60,
    defaultRate12mPct: 1.8,
    voluntaryTerminationPct: 2.4,
    earlySettlementPct: 6.5,
    rarocMarginPct: 2.5,
    fraudAnomalyAlerts: 0,
    riskRating: 'TIER_1_PREFERRED',
  },
];

// Warehouse funding facilities
export const SYNTHETIC_WAREHOUSES: WarehouseFacility[] = [
  {
    id: 'WH-BARCLAYS-500',
    name: 'Rhino Auto Warehouse Facility A',
    lenderBank: 'Barclays Investment Bank / NatWest Markets',
    facilityLimit: 500000000, // £500m
    drawnAmount: 342000000,   // £342m drawn
    availableAmount: 158000000,// £158m available
    advanceRatePct: 85.0,
    haircutPct: 15.0,
    marginSpreadBp: 135,
    allInCostOfFundsPct: 4.31,
    maturityDate: '2027-09-30',
    covenants: [
      { metric: 'Max Portfolio Delinquency 60+ DPD', threshold: '< 3.0%', actual: '1.24%', status: 'COMPLIANT' },
      { metric: 'Min Weighted Average Bureau Score', threshold: '> 680', actual: '718', status: 'COMPLIANT' },
      { metric: 'Max BEV Collateral Concentration', threshold: '< 25.0%', actual: '21.4%', status: 'COMPLIANT' },
      { metric: 'Min Interest Coverage Ratio (ICR)', threshold: '> 1.75x', actual: '2.42x', status: 'COMPLIANT' },
    ],
  },
  {
    id: 'WH-HSBC-350',
    name: 'Rhino Green Fleet & BEV Facility B',
    lenderBank: 'HSBC Corporate / BNP Paribas',
    facilityLimit: 350000000,
    drawnAmount: 215000000,
    availableAmount: 135000000,
    advanceRatePct: 82.5,
    haircutPct: 17.5,
    marginSpreadBp: 150,
    allInCostOfFundsPct: 4.45,
    maturityDate: '2028-03-31',
    covenants: [
      { metric: 'Max BEV LTV at Origination', threshold: '< 90.0%', actual: '82.6%', status: 'COMPLIANT' },
      { metric: 'Cumulative Default Rate (12m)', threshold: '< 3.5%', actual: '2.90%', status: 'COMPLIANT' },
    ],
  },
];

// Model Risk Inventory
export const SYNTHETIC_MODEL_INVENTORY: ModelRiskRecord[] = [
  {
    id: 'MDL-PD-AUTO-3.2',
    modelName: 'Rhino Auto Application PD Scorecard',
    version: 'v3.2.1',
    owner: 'Dr. Sarah Henderson (Head of Credit Quantitative Research)',
    purpose: 'Predicts 12-month Probability of Default for retail automotive credit applications.',
    lifecycleStatus: 'APPROVED',
    lastValidationDate: '2026-02-14',
    auc: 0.842,
    gini: 0.684,
    ksStatistic: 0.472,
    brierScore: 0.024,
    populationStabilityIndex: 0.041,
    keyAssumptions: [
      'Bureau credit score correlation holds during macroeconomic shifts',
      'Affordability expenditure benchmarks refreshed quarterly from ONS data',
      'Zero discriminatory characteristics or prohibited demographic variables',
    ],
    limitations: [
      'Self-employed tenure under 18 months has wider predictive confidence bounds',
      'Rapid EV residual price swings may induce non-linear voluntary termination behavior',
    ],
  },
  {
    id: 'MDL-LGD-COLLAT-2.4',
    modelName: 'Collateral-Adjusted Auto LGD Model',
    version: 'v2.4.0',
    owner: 'Marcus Vance (Senior Collateral Quant)',
    purpose: 'Models Loss Given Default dynamically incorporating wholesale vehicle auction recovery proceeds and liquidation costs.',
    lifecycleStatus: 'MONITORED',
    lastValidationDate: '2026-01-28',
    auc: 0.812,
    gini: 0.624,
    ksStatistic: 0.418,
    brierScore: 0.038,
    populationStabilityIndex: 0.062,
    keyAssumptions: [
      'Wholesale auction liquidation haircut 19% under normal market depth',
      'Average repossession legal and recovery fee capped at £950',
    ],
    limitations: [
      'BEV secondary battery degradation uncertainty in 4th and 5th year cohorts',
    ],
  },
  {
    id: 'MDL-ABS-WATERFALL-1.8',
    modelName: 'Rhino Quant ABS Cash Flow & Waterfall Engine',
    version: 'v1.8.4',
    owner: 'Elena Rostova (Head of Structured Credit & ABS)',
    purpose: 'Deterministic priority-of-payments simulation, WAL, duration and tranche stress loss allocation.',
    lifecycleStatus: 'APPROVED',
    lastValidationDate: '2026-03-01',
    auc: 0.998,
    gini: 0.996,
    ksStatistic: 0.985,
    brierScore: 0.001,
    populationStabilityIndex: 0.012,
    keyAssumptions: [
      'Sequential note paydown applies upon breach of cumulative loss trigger (4.5%)',
      'Liquidity reserve replenishable from senior excess spread',
    ],
    limitations: [
      'Assumes uniform monthly payment frequency across all underlying notes',
    ],
  },
];

// Audit trail records
export const SYNTHETIC_AUDIT_TRAIL: AuditRecord[] = [
  {
    id: 'AUD-9941',
    timestamp: '2026-10-12 09:42:18 UTC',
    analyst: 'J. Smith (VP Treasury)',
    role: 'Treasury Desk',
    action: 'UPDATE_MARKET_CURVE',
    object: 'Base Funding Curve (SONIA Spread)',
    oldValue: '4.18%',
    newValue: '4.31%',
    reason: 'Updated SONIA 3M forward benchmark curve following Bank of England MPC minutes.',
    modelVersion: 'v3.2.1',
  },
  {
    id: 'AUD-9938',
    timestamp: '2026-10-11 16:15:02 UTC',
    analyst: 'M. Vance (Collateral Risk)',
    role: 'Risk Engine',
    action: 'STRESS_PARAMETER_OVERRIDE',
    object: 'BEV Residual Depreciation Curve (36M)',
    oldValue: '-6.5% discount',
    newValue: '-8.0% discount',
    reason: 'Increased technology obsolescence discount for battery electric vehicle cohort.',
    modelVersion: 'v2.4.0',
  },
  {
    id: 'AUD-9925',
    timestamp: '2026-10-10 11:20:44 UTC',
    analyst: 'K. Patel (Head of Compliance)',
    role: 'Compliance',
    action: 'REDRESS_SCHEME_VERSION_UPDATE',
    object: 'FCA DCA Redress Scheme Configuration',
    oldValue: 'FCA-DCA-2025.1-CONSULTATION',
    newValue: 'FCA-DCA-2026.2',
    reason: 'Incorporated updated Court of Appeal judgment considerations regarding broker disclosures.',
    modelVersion: 'SCHEME-2026.2',
  },
];

// Redress historical sample cases (2007-2024 DCA)
export const SYNTHETIC_REDRESS_CASES: RedressCase[] = [
  {
    id: 'RDR-2018-0412',
    agreementReference: 'AGR-2018-BMW-0982',
    originationDate: '2018-05-14',
    customerName: 'Robert Davies',
    dealerName: 'Apex Motor Group (North West)',
    originalVehicle: 'BMW 320d M Sport Saloon',
    financedAmount: 24500,
    contractAPR: 9.9,
    benchmarkLenderRate: 4.5,
    discretionaryCommissionPct: 5.4,
    discretionaryCommissionAmount: 952,
    compensatoryInterestBasis: 'SIMPLE_8PCT',
    statutoryInterestAmount: 609,
    totalRedressPayable: 1561,
    status: 'CALCULATED_PROVISIONAL',
    schemeRuleVersion: 'FCA-DCA-2026.2',
  },
  {
    id: 'RDR-2020-1108',
    agreementReference: 'AGR-2020-MERC-4411',
    originationDate: '2020-09-22',
    customerName: 'Claire Jenkins',
    dealerName: 'Lookers Automotive Midlands',
    originalVehicle: 'Mercedes-Benz A200 AMG Line',
    financedAmount: 21800,
    contractAPR: 10.4,
    benchmarkLenderRate: 4.5,
    discretionaryCommissionPct: 5.9,
    discretionaryCommissionAmount: 926,
    compensatoryInterestBasis: 'SIMPLE_8PCT',
    statutoryInterestAmount: 444,
    totalRedressPayable: 1370,
    status: 'APPEAL_SUSPENDED',
    schemeRuleVersion: 'FCA-DCA-2026.2',
  },
  {
    id: 'RDR-2022-0319',
    agreementReference: 'AGR-2022-AUDI-7712',
    originationDate: '2022-03-10',
    customerName: 'Marcus Thorne',
    dealerName: 'Stratstone Prestige Franchised',
    originalVehicle: 'Audi Q5 S line TDI',
    financedAmount: 34200,
    contractAPR: 8.8,
    benchmarkLenderRate: 4.5,
    discretionaryCommissionPct: 4.3,
    discretionaryCommissionAmount: 1058,
    compensatoryInterestBasis: 'SIMPLE_8PCT',
    statutoryInterestAmount: 338,
    totalRedressPayable: 1396,
    status: 'AUDIT_FLAGGED',
    schemeRuleVersion: 'FCA-DCA-2026.2',
  },
];

/**
 * Generates 120 detailed representative loan records for interactive drill-down
 */
export function generateSampleLoanPopulation(): Loan[] {
  const products: FinanceProduct[] = ['PCP', 'PCP', 'HP', 'HP', 'Balloon Loan', 'Lease'];
  const grades: RiskGrade[] = ['A', 'A', 'B', 'B', 'B', 'C', 'C', 'D', 'E'];
  const vintages = ['2023-Q3', '2023-Q4', '2024-Q1', '2024-Q2', '2024-Q3', '2024-Q4', '2025-Q1'];

  const loans: Loan[] = [];

  for (let i = 1; i <= 120; i++) {
    const vehSpec = VEHICLE_CATALOGUE[i % VEHICLE_CATALOGUE.length];
    const dealer = SYNTHETIC_DEALERS[i % SYNTHETIC_DEALERS.length];
    const riskGrade = grades[i % grades.length];
    const product = products[i % products.length];
    const vintage = vintages[i % vintages.length];

    const depositPct = riskGrade === 'A' ? 0.20 : riskGrade === 'B' ? 0.15 : riskGrade === 'C' ? 0.10 : 0.05;
    const vehiclePrice = vehSpec.invoicePrice;
    const depositAmount = Math.round(vehiclePrice * depositPct);
    const originalPrincipal = vehiclePrice - depositAmount;

    const termMonths = 48;
    const seasoning = ((i * 7) % 30) + 6;
    const remaining = Math.max(1, termMonths - seasoning);

    // Guaranteed Future Value for PCP
    const gfv = product === 'PCP' ? Math.round(vehiclePrice * 0.48) : 0;
    const balloon = product === 'Balloon Loan' ? Math.round(vehiclePrice * 0.35) : 0;

    const aprMap: Record<RiskGrade, number> = { A: 0.064, B: 0.074, C: 0.094, D: 0.125, E: 0.150 };
    const customerAPR = aprMap[riskGrade];

    // Depreciation curve
    const depCurve = calculateDepreciationCurve({
      originalListPrice: vehiclePrice,
      segment: vehSpec.segment,
      fuelType: vehSpec.fuelType,
      annualMileage: 10000,
      usedCarMarketIndex: 100,
    });
    const monthlyDepVector = new Array(61).fill(0).map((_, m) => {
      const idx = Math.min(depCurve.length - 1, Math.floor(m / 6));
      return depCurve[idx].retailValue;
    });

    const cashFlowOutput = generateLoanCashFlowSchedule({
      productType: product,
      vehiclePrice,
      deposit: depositAmount,
      customerAPR,
      termMonths,
      guaranteedFutureValue: gfv,
      balloonAmount: balloon,
      monthlyDepreciationVector: monthlyDepVector,
    });

    const periodIdx = Math.min(seasoning, cashFlowOutput.periods.length - 1);
    const currentOutstandingBalance = cashFlowOutput.periods[periodIdx]?.closingBalance ?? Math.round(originalPrincipal * 0.7);

    // Delinquency distribution
    let dpd = 0;
    let status: Loan['status'] = 'ACTIVE';
    let delinqBucket: Loan['delinquencyBucket'] = 'CURRENT';

    if (riskGrade === 'E' && (i % 5 === 0)) {
      dpd = 45;
      status = 'DELINQUENT';
      delinqBucket = '31-60 DPD';
    } else if (riskGrade === 'D' && (i % 7 === 0)) {
      dpd = 18;
      status = 'PAST_DUE';
      delinqBucket = '1-30 DPD';
    } else if (i === 42) {
      dpd = 95;
      status = 'DEFAULT';
      delinqBucket = '90+ DPD';
    }

    const pd12m = riskGrade === 'A' ? 0.008 : riskGrade === 'B' ? 0.019 : riskGrade === 'C' ? 0.038 : riskGrade === 'D' ? 0.075 : 0.142;
    const lgd = vehSpec.fuelType === 'BEV' ? 0.48 : 0.42;
    const ead = currentOutstandingBalance;
    const expectedLoss = Math.round(pd12m * lgd * ead);

    const vehicle: Vehicle = {
      vin: `SJNFAAZE1U0${(100000 + i * 389).toString(16).toUpperCase()}`,
      make: vehSpec.make,
      model: vehSpec.model,
      derivative: vehSpec.derivative,
      year: 2024 - Math.floor(seasoning / 12),
      originalListPrice: vehiclePrice,
      currentRetailValue: monthlyDepVector[seasoning] || Math.round(vehiclePrice * 0.72),
      currentWholesaleValue: Math.round((monthlyDepVector[seasoning] || vehiclePrice * 0.72) * 0.88),
      currentAuctionValue: Math.round((monthlyDepVector[seasoning] || vehiclePrice * 0.72) * 0.81),
      fuelType: vehSpec.fuelType,
      powertrainDetails: vehSpec.fuelType === 'BEV' ? 'Dual Motor AWD 400V Architecture' : 'Turbocharged Direct Injection Euro 6d',
      segment: vehSpec.segment,
      mileage: Math.round(seasoning * 850),
      annualMileageContract: 10000,
      batteryHealthPct: vehSpec.fuelType === 'BEV' ? Math.max(91, 100 - (seasoning * 0.22)) : undefined,
      expectedDepreciationCurve: depCurve.map((d) => d.residualPct),
    };

    loans.push({
      id: `LN-2026-${(10000 + i).toString()}`,
      agreementNumber: `RQA-AGR-${vintage.replace('-', '')}-${(4000 + i).toString()}`,
      vintageCohort: vintage,
      customerId: `CUST-${(8000 + i).toString()}`,
      customerName: ['Alexander Wright', 'Sophia Chen', 'David Patel', 'Emma Harrison', 'Liam O\'Connor', 'Oliver Scott', 'Charlotte Miller', 'Lucas Davies'][i % 8],
      customerRiskGrade: riskGrade,
      dealerId: dealer.id,
      dealerName: dealer.name,
      productType: product,
      vehicle,
      vehicleCashPrice: vehiclePrice,
      depositAmount,
      depositPct: Number((depositPct * 100).toFixed(1)),
      originalPrincipal,
      currentOutstandingBalance,
      customerAPR: Number((customerAPR * 100).toFixed(2)),
      contractInterestRate: Number(((customerAPR * 0.96) * 100).toFixed(2)),
      termMonths,
      remainingMonths: remaining,
      seasoningMonths: seasoning,
      guaranteedFutureValue: gfv,
      balloonAmount: balloon,
      ltvOrigination: Number(((originalPrincipal / vehiclePrice) * 100).toFixed(1)),
      ltvCurrent: Number(((currentOutstandingBalance / vehicle.currentRetailValue) * 100).toFixed(1)),
      pd12m,
      pdLifetime: Number((pd12m * 2.8).toFixed(4)),
      lgd,
      ead,
      expectedLoss,
      status,
      delinquencyBucket: delinqBucket,
      daysPastDue: dpd,
      arrearsBalance: dpd > 0 ? Math.round(cashFlowOutput.monthlyPayment * (dpd / 30)) : 0,
      cprAnnualised: 0.064,
      cashFlowSchedule: cashFlowOutput.periods,
    });
  }

  return loans;
}
