/**
 * RhinoQuant Auto Finance (RQA)
 * Institutional Automotive Finance Data Structures & Financial Types
 */

export type FuelType = 'ICE' | 'Hybrid' | 'PHEV' | 'BEV';
export type VehicleSegment = 'City/Compact' | 'Executive Saloon' | 'SUV/Crossover' | 'Sports/Performance' | 'Commercial Van';
export type FinanceProduct = 'HP' | 'PCP' | 'Lease' | 'Balloon Loan' | 'Fleet Finance';

export type RiskGrade = 'A' | 'B' | 'C' | 'D' | 'E';

export type LoanStatus = 
  | 'APPLICATION'
  | 'APPROVED'
  | 'CONTRACTED'
  | 'ACTIVE'
  | 'PAST_DUE'
  | 'DELINQUENT'
  | 'DEFAULT'
  | 'RECOVERY'
  | 'SETTLED'
  | 'MATURED'
  | 'CHARGED_OFF';

export type DelinquencyBucket = 'CURRENT' | '1-30 DPD' | '31-60 DPD' | '61-90 DPD' | '90+ DPD' | 'DEFAULT';

export interface CustomerAffordability {
  monthlyGrossIncome: number;
  monthlyNetIncome: number;
  essentialExpenditure: number;
  existingDebtObligations: number;
  proposedLoanPayment: number;
  residualDisposableIncome: number;
  paymentToIncomeRatio: number; // e.g. 0.14 = 14%
  debtToIncomeRatio: number;
  verifiedStatus: 'VERIFIED_OPEN_BANKING' | 'SELF_DECLARED_PAYSLIP' | 'MODEL_ESTIMATE';
}

export interface CreditScorecardFactor {
  name: string;
  category: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
  scoreImpact: number;
  description: string;
}

export interface Customer {
  id: string;
  name: string;
  employmentStatus: 'PERMANENT' | 'SELF_EMPLOYED' | 'DIRECTOR' | 'RETIRED';
  tenureYears: number;
  homeownerStatus: 'OWNER_MORTGAGE' | 'OWNER_OUTRIGHT' | 'TENANT';
  bureauScore: number; // e.g. 720 / 999
  riskGrade: RiskGrade;
  affordability: CustomerAffordability;
  scorecardFactors: CreditScorecardFactor[];
  unlawfulCharacteristicsExcluded: boolean; // strict compliance guarantee
}

export interface Vehicle {
  vin: string;
  make: string;
  model: string;
  derivative: string;
  year: number;
  originalListPrice: number;
  currentRetailValue: number;
  currentWholesaleValue: number;
  currentAuctionValue: number;
  fuelType: FuelType;
  powertrainDetails: string;
  segment: VehicleSegment;
  mileage: number;
  annualMileageContract: number;
  batteryCapacityKWh?: number;
  batteryHealthPct?: number; // SOH for BEVs
  expectedDepreciationCurve: number[]; // 1..60 month residual %
}

export interface LoanCashFlowPeriod {
  periodMonth: number;
  openingBalance: number;
  scheduledPrincipal: number;
  scheduledInterest: number;
  prepaymentPrincipal: number;
  defaultLoss: number;
  recoveryProceeds: number;
  closingBalance: number;
  customerEquity: number;
  totalCashFlow: number;
}

export interface Loan {
  id: string;
  agreementNumber: string;
  vintageCohort: string; // e.g. "2024-Q2"
  customerId: string;
  customerName: string;
  customerRiskGrade: RiskGrade;
  dealerId: string;
  dealerName: string;
  productType: FinanceProduct;
  vehicle: Vehicle;
  
  // Financial terms (in GBP)
  vehicleCashPrice: number;
  depositAmount: number;
  depositPct: number;
  originalPrincipal: number;
  currentOutstandingBalance: number;
  customerAPR: number; // e.g. 0.079 = 7.9%
  contractInterestRate: number; // nominal monthly rate * 12
  termMonths: number;
  remainingMonths: number;
  seasoningMonths: number;
  
  // PCP specific
  guaranteedFutureValue: number; // GFV / Balloon
  balloonAmount: number;
  
  // Risk metrics
  ltvOrigination: number; // e.g. 0.85
  ltvCurrent: number;
  pd12m: number; // 12-month PD
  pdLifetime: number;
  lgd: number; // collateral-adjusted
  ead: number; // exposure at default
  expectedLoss: number; // EL = PD * LGD * EAD
  
  // Status & Servicing
  status: LoanStatus;
  delinquencyBucket: DelinquencyBucket;
  daysPastDue: number;
  arrearsBalance: number;
  cprAnnualised: number; // Constant Prepayment Rate
  
  // Cash flows
  cashFlowSchedule: LoanCashFlowPeriod[];
}

export interface Tranche {
  id: string;
  name: string; // e.g. Class A, Class B, Class C, Class D, Residual
  ratingAgency: string; // AAA, AA, BBB, BB, NR
  initialPrincipal: number;
  currentPrincipal: number;
  originalNotePct: number; // attachment / pool share
  couponSpreadBp: number; // e.g. SONIA + 75bp
  couponRatePct: number;
  attachmentPointPct: number;
  detachmentPointPct: number;
  weightedAverageLifeYears: number;
  durationYears: number;
  yieldToMaturityPct: number;
  cumulativeLossAllocation: number;
  lossBufferRemainingPct: number;
}

export interface SecuritisationDeal {
  id: string;
  dealName: string; // e.g. "RHINO AUTO ABS 2026-1"
  closingDate: string;
  originalPoolBalance: number;
  currentPoolBalance: number;
  weightedAverageCouponPct: number;
  weightedAverageRemainingTermMonths: number;
  weightedAverageLTVPct: number;
  weightedAverageBureauScore: number;
  
  // Credit Enhancement
  overcollateralisationAmount: number;
  reserveAccountTargetAmount: number;
  reserveAccountCurrentBalance: number;
  excessSpreadAnnualisedPct: number;
  
  tranches: Tranche[];
  
  // Priority waterfall cash flows
  collections: {
    period: number;
    interestCollections: number;
    principalCollections: number;
    seniorServicerFees: number;
    noteInterestPaid: number;
    notePrincipalPaid: number;
    reserveReplenishment: number;
    juniorExcessSpreadReleased: number;
  }[];
}

export interface WarehouseFacility {
  id: string;
  name: string;
  lenderBank: string;
  facilityLimit: number;
  drawnAmount: number;
  availableAmount: number;
  advanceRatePct: number;
  haircutPct: number;
  marginSpreadBp: number; // e.g. SONIA + 135bp
  allInCostOfFundsPct: number;
  maturityDate: string;
  covenants: {
    metric: string;
    threshold: string;
    actual: string;
    status: 'COMPLIANT' | 'WARNING' | 'BREACH';
  }[];
}

export interface DealerPerformance {
  id: string;
  name: string;
  region: string;
  dealerType: 'FRANCHISED' | 'INDEPENDENT' | 'CAR_SUPERMARKET' | 'DIRECT_OEM';
  totalOriginationsVolume: number; // GBP
  activeLoanCount: number;
  approvalRatePct: number;
  averageLTVPct: number;
  averageCustomerAPR: number;
  defaultRate12mPct: number;
  voluntaryTerminationPct: number;
  earlySettlementPct: number;
  rarocMarginPct: number;
  fraudAnomalyAlerts: number;
  riskRating: 'TIER_1_PREFERRED' | 'TIER_2_STANDARD' | 'TIER_3_WATCHLIST' | 'TIER_4_SUSPENDED';
}

export interface StressScenarioConfig {
  id: string;
  name: string;
  description: string;
  pdMultiplier: number; // e.g. 1.25 (+25%)
  lgdMultiplier: number; // e.g. 1.15
  bevResidualShockPct: number; // e.g. -0.20 (-20%)
  fundingRateShiftBp: number; // e.g. +100bp
  prepaymentMultiplier: number; // e.g. 0.80 (-20%)
  unemploymentShockPct: number; // e.g. +3.5%
}

export interface ModelRiskRecord {
  id: string;
  modelName: string;
  version: string;
  owner: string;
  purpose: string;
  lifecycleStatus: 'DEVELOPMENT' | 'VALIDATION' | 'APPROVED' | 'MONITORED' | 'RETIRED';
  lastValidationDate: string;
  auc: number;
  gini: number;
  ksStatistic: number;
  brierScore: number;
  populationStabilityIndex: number;
  keyAssumptions: string[];
  limitations: string[];
}

export interface AuditRecord {
  id: string;
  timestamp: string;
  analyst: string;
  role: string;
  action: string;
  object: string;
  oldValue: string;
  newValue: string;
  reason: string;
  modelVersion: string;
}

export interface RedressCase {
  id: string;
  agreementReference: string;
  originationDate: string;
  customerName: string;
  dealerName: string;
  originalVehicle: string;
  financedAmount: number;
  contractAPR: number;
  benchmarkLenderRate: number;
  discretionaryCommissionPct: number;
  discretionaryCommissionAmount: number;
  compensatoryInterestBasis: 'SIMPLE_8PCT' | 'COMPOUND_COMMERCIAL' | 'NONE';
  statutoryInterestAmount: number;
  totalRedressPayable: number;
  status: 'AUDIT_FLAGGED' | 'CALCULATED_PROVISIONAL' | 'APPEAL_SUSPENDED' | 'SETTLED';
  schemeRuleVersion: string;
}

export interface DataLineageNode {
  label: string;
  value: string;
  sourceType: 'CALCULATION' | 'MODEL_OUTPUT' | 'INPUT_AGGREGATE' | 'MARKET_DATA' | 'CORE_SYSTEM';
  description: string;
  versionOrTimestamp: string;
  children?: DataLineageNode[];
}
