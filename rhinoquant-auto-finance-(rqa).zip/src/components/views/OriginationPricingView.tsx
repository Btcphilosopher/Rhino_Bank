/**
 * RhinoQuant Auto Finance
 * Institutional Origination, Scorecard & RAROC Pricing Engine (PRICING <GO> / CREDIT <GO>)
 */

import React, { useState, useMemo } from 'react';
import {
  Calculator,
  ShieldCheck,
  TrendingDown,
  Layers,
  ArrowRight,
  CheckCircle,
  AlertCircle,
  HelpCircle,
  Plus,
  Minus,
} from 'lucide-react';
import { FinanceProduct, FuelType, RiskGrade, VehicleSegment } from '../../types/finance';
import { calculateDepreciationCurve } from '../../engine/depreciation';
import { generateLoanCashFlowSchedule } from '../../engine/amortisation';
import { calculatePricingBreakdown, generateRateSheetMatrix } from '../../engine/pricing';
import { evaluateCreditScorecard, calculateLGD } from '../../engine/creditRisk';

export const OriginationPricingView: React.FC = () => {
  // Application Inputs
  const [productType, setProductType] = useState<FinanceProduct>('PCP');
  const [vehiclePrice, setVehiclePrice] = useState<number>(38500);
  const [depositAmount, setDepositAmount] = useState<number>(5000);
  const [termMonths, setTermMonths] = useState<number>(48);
  const [annualMileage, setAnnualMileage] = useState<number>(10000);
  const [fuelType, setFuelType] = useState<FuelType>('BEV');
  const [segment, setSegment] = useState<VehicleSegment>('SUV/Crossover');

  // Customer Underwriting Inputs
  const [bureauScore, setBureauScore] = useState<number>(735);
  const [monthlyGrossIncome, setMonthlyGrossIncome] = useState<number>(4200);
  const [monthlyNetIncome, setMonthlyNetIncome] = useState<number>(3250);
  const [essentialExpenditure, setEssentialExpenditure] = useState<number>(1350);
  const [existingDebt, setExistingDebt] = useState<number>(450);
  const [employmentTenureYears, setEmploymentTenureYears] = useState<number>(4);

  // Market & Funding configuration
  const [baseFundingCost, setBaseFundingCost] = useState<number>(4.31); // 4.31% wholesale cost
  const [usedCarMarketIndex, setUsedCarMarketIndex] = useState<number>(100);

  // 1. Calculate Depreciation & Residual Values
  const depreciationCurve = useMemo(() => {
    return calculateDepreciationCurve({
      originalListPrice: vehiclePrice,
      segment,
      fuelType,
      annualMileage,
      usedCarMarketIndex,
    });
  }, [vehiclePrice, segment, fuelType, annualMileage, usedCarMarketIndex]);

  // Guaranteed Future Value at Month 36 or 48 for PCP
  const expectedResidualAtTerm = useMemo(() => {
    const point = depreciationCurve.find((p) => p.month === termMonths) || depreciationCurve[depreciationCurve.length - 1];
    return point ? point.retailValue : Math.round(vehiclePrice * 0.45);
  }, [depreciationCurve, termMonths, vehiclePrice]);

  const guaranteedFutureValue = productType === 'PCP' ? Math.round(expectedResidualAtTerm * 0.95) : 0; // 5% underwriting safety haircut
  const balloonAmount = productType === 'Balloon Loan' ? Math.round(vehiclePrice * 0.35) : 0;

  // 2. Scorecard Evaluation
  const mockCustomer = useMemo(() => {
    const proposedLoan = Math.max(0, vehiclePrice - depositAmount);
    const approxMonthly = proposedLoan / termMonths * 1.2;
    const residualDisposable = monthlyNetIncome - essentialExpenditure - existingDebt - approxMonthly;

    return {
      id: 'APP-PROSPECT-01',
      name: 'Retail Applicant',
      employmentStatus: 'PERMANENT' as const,
      tenureYears: employmentTenureYears,
      homeownerStatus: 'OWNER_MORTGAGE' as const,
      bureauScore,
      riskGrade: 'B' as RiskGrade,
      affordability: {
        monthlyGrossIncome,
        monthlyNetIncome,
        essentialExpenditure,
        existingDebtObligations: existingDebt,
        proposedLoanPayment: Math.round(approxMonthly),
        residualDisposableIncome: Math.round(residualDisposable),
        paymentToIncomeRatio: Number((approxMonthly / monthlyNetIncome).toFixed(3)),
        debtToIncomeRatio: Number((existingDebt / monthlyNetIncome).toFixed(3)),
        verifiedStatus: 'VERIFIED_OPEN_BANKING' as const,
      },
      scorecardFactors: [],
      unlawfulCharacteristicsExcluded: true,
    };
  }, [bureauScore, monthlyGrossIncome, monthlyNetIncome, essentialExpenditure, existingDebt, employmentTenureYears, vehiclePrice, depositAmount, termMonths]);

  const mockVehicle = useMemo(() => {
    return {
      vin: 'SJNFAAZE1U0EXAMPLE',
      make: 'Underwritten Vehicle',
      model: segment,
      derivative: `${fuelType} Specification`,
      year: 2026,
      originalListPrice: vehiclePrice,
      currentRetailValue: vehiclePrice,
      currentWholesaleValue: Math.round(vehiclePrice * 0.88),
      currentAuctionValue: Math.round(vehiclePrice * 0.81),
      fuelType,
      powertrainDetails: `${fuelType} Standard`,
      segment,
      mileage: 0,
      annualMileageContract: annualMileage,
      expectedDepreciationCurve: depreciationCurve.map((p) => p.residualPct),
    };
  }, [vehiclePrice, fuelType, segment, annualMileage, depreciationCurve]);

  const scorecard = useMemo(() => {
    return evaluateCreditScorecard({
      customer: mockCustomer,
      vehicle: mockVehicle,
      loanAmount: Math.max(0, vehiclePrice - depositAmount),
      depositAmount,
      termMonths,
      monthlyPayment: 540,
    });
  }, [mockCustomer, mockVehicle, vehiclePrice, depositAmount, termMonths]);

  // 3. RAROC Pricing Breakdown
  const pricing = useMemo(() => {
    return calculatePricingBreakdown({
      riskGrade: scorecard.riskGrade,
      termMonths,
      baseFundingCostPct: baseFundingCost,
    });
  }, [scorecard.riskGrade, termMonths, baseFundingCost]);

  // 4. Deterministic Amortisation Schedule & Customer Equity
  const amortisation = useMemo(() => {
    const monthlyDepVector = new Array(61).fill(0).map((_, m) => {
      const idx = Math.min(depreciationCurve.length - 1, Math.floor(m / 6));
      return depreciationCurve[idx].retailValue;
    });

    return generateLoanCashFlowSchedule({
      productType,
      vehiclePrice,
      deposit: depositAmount,
      customerAPR: pricing.totalRequiredCustomerRatePct / 100,
      termMonths,
      guaranteedFutureValue,
      balloonAmount,
      monthlyDepreciationVector: monthlyDepVector,
    });
  }, [productType, vehiclePrice, depositAmount, pricing.totalRequiredCustomerRatePct, termMonths, guaranteedFutureValue, balloonAmount, depreciationCurve]);

  // Dynamic Rate Sheet Matrix
  const rateSheet = useMemo(() => {
    return generateRateSheetMatrix(baseFundingCost);
  }, [baseFundingCost]);

  // Customer Equity at 36M / Term End
  const equityAt36 = amortisation.periods[Math.min(36, amortisation.periods.length - 1)]?.customerEquity || 0;

  return (
    <div className="p-4 space-y-4 max-w-[1600px] mx-auto text-xs font-sans">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#21262d]">
        <div>
          <h1 className="font-mono text-sm font-bold text-white flex items-center space-x-2">
            <span>ORIGINATION, UNDERWRITING & RAROC PRICING DESK</span>
            <span className="text-[10px] bg-[#161b22] border border-[#30363d] px-1.5 py-0.5 text-[#d29922]">
              PRICING &lt;GO&gt;
            </span>
          </h1>
          <p className="text-[#8b949e] text-[11px]">
            Quantitative loan structuring, transparent scorecard evaluation, and risk-adjusted hurdle pricing.
          </p>
        </div>

        <div className="flex items-center space-x-2 font-mono text-[11px]">
          <span className="text-[#8b949e]">Base Funding Curve:</span>
          <div className="flex items-center bg-[#11151c] border border-[#30363d] px-2 py-0.5">
            <span className="text-white font-bold">{baseFundingCost.toFixed(2)}%</span>
            <span className="text-[#8b949e] ml-1">(SONIA+135bp)</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column (4 cols): Product Parameters & Underwriting Inputs */}
        <div className="lg:col-span-4 space-y-4">
          {/* Box 1: Product & Vehicle Parameters */}
          <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-3">
            <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
              <span>FINANCE PRODUCT SPECIFICATION</span>
              <span className="text-[10px] text-[#388bfd]">{productType}</span>
            </div>

            {/* Product Switcher */}
            <div>
              <label className="text-[10px] text-[#8b949e] uppercase font-mono block mb-1">Product Type</label>
              <div className="grid grid-cols-3 gap-1">
                {(['PCP', 'HP', 'Balloon Loan', 'Lease'] as FinanceProduct[]).map((p) => (
                  <button
                    key={p}
                    onClick={() => setProductType(p)}
                    className={`py-1 text-[11px] font-mono border transition-colors ${
                      productType === p
                        ? 'bg-[#1f2937] text-[#d29922] border-[#d29922] font-bold'
                        : 'bg-[#0b0e14] text-[#8b949e] hover:text-white border-[#21262d]'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            {/* Price & Deposit */}
            <div className="grid grid-cols-2 gap-2 font-mono text-[11px]">
              <div>
                <label className="text-[10px] text-[#8b949e] block mb-0.5">Vehicle Cash Price (£)</label>
                <input
                  type="number"
                  value={vehiclePrice}
                  onChange={(e) => setVehiclePrice(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#30363d] text-white px-2 py-1 focus:outline-none focus:border-[#d29922]"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#8b949e] block mb-0.5">Deposit (£)</label>
                <input
                  type="number"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#30363d] text-white px-2 py-1 focus:outline-none focus:border-[#d29922]"
                />
              </div>
            </div>

            {/* Term & Mileage */}
            <div className="grid grid-cols-2 gap-2 font-mono text-[11px]">
              <div>
                <label className="text-[10px] text-[#8b949e] block mb-0.5">Term (Months)</label>
                <select
                  value={termMonths}
                  onChange={(e) => setTermMonths(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#30363d] text-white px-2 py-1 focus:outline-none"
                >
                  <option value={24}>24 Months</option>
                  <option value={36}>36 Months</option>
                  <option value={48}>48 Months</option>
                  <option value={60}>60 Months</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] text-[#8b949e] block mb-0.5">Annual Mileage</label>
                <select
                  value={annualMileage}
                  onChange={(e) => setAnnualMileage(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#30363d] text-white px-2 py-1 focus:outline-none"
                >
                  <option value={8000}>8,000 miles</option>
                  <option value={10000}>10,000 miles</option>
                  <option value={15000}>15,000 miles</option>
                  <option value={20000}>20,000 miles</option>
                </select>
              </div>
            </div>

            {/* Vehicle Segment & Fuel */}
            <div className="grid grid-cols-2 gap-2 font-mono text-[11px]">
              <div>
                <label className="text-[10px] text-[#8b949e] block mb-0.5">Powertrain</label>
                <select
                  value={fuelType}
                  onChange={(e) => setFuelType(e.target.value as FuelType)}
                  className="w-full bg-[#0b0e14] border border-[#30363d] text-white px-2 py-1 focus:outline-none"
                >
                  <option value="BEV">Battery Electric (BEV)</option>
                  <option value="Hybrid">Full Hybrid (HEV)</option>
                  <option value="PHEV">Plug-in Hybrid (PHEV)</option>
                  <option value="ICE">Internal Combustion (ICE)</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] text-[#8b949e] block mb-0.5">Segment</label>
                <select
                  value={segment}
                  onChange={(e) => setSegment(e.target.value as VehicleSegment)}
                  className="w-full bg-[#0b0e14] border border-[#30363d] text-white px-2 py-1 focus:outline-none"
                >
                  <option value="SUV/Crossover">SUV / Crossover</option>
                  <option value="Executive Saloon">Executive Saloon</option>
                  <option value="City/Compact">City / Compact</option>
                  <option value="Sports/Performance">Sports / Performance</option>
                  <option value="Commercial Van">Commercial Van</option>
                </select>
              </div>
            </div>
          </div>

          {/* Box 2: Customer Affordability & Credit Inputs */}
          <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-3">
            <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
              <span>CUSTOMER UNDERWRITING & AFFORDABILITY</span>
              <span className="text-[10px] text-[#3fb950] flex items-center">
                <ShieldCheck className="w-3 h-3 mr-1" />
                CONC COMPLIANT
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 font-mono text-[11px]">
              <div>
                <label className="text-[10px] text-[#8b949e] block mb-0.5">Bureau Score (400-999)</label>
                <input
                  type="number"
                  value={bureauScore}
                  onChange={(e) => setBureauScore(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#30363d] text-white px-2 py-1 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#8b949e] block mb-0.5">Monthly Net Income (£)</label>
                <input
                  type="number"
                  value={monthlyNetIncome}
                  onChange={(e) => setMonthlyNetIncome(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#30363d] text-white px-2 py-1 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 font-mono text-[11px]">
              <div>
                <label className="text-[10px] text-[#8b949e] block mb-0.5">Essential Expenditure (£)</label>
                <input
                  type="number"
                  value={essentialExpenditure}
                  onChange={(e) => setEssentialExpenditure(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#30363d] text-white px-2 py-1 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#8b949e] block mb-0.5">Existing Debt (£)</label>
                <input
                  type="number"
                  value={existingDebt}
                  onChange={(e) => setExistingDebt(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#30363d] text-white px-2 py-1 focus:outline-none"
                />
              </div>
            </div>

            {/* Affordability Waterfall Breakdown */}
            <div className="bg-[#0b0e14] border border-[#21262d] p-2.5 font-mono text-[11px] space-y-1">
              <div className="flex justify-between text-[#8b949e]">
                <span>Verified Net Monthly Income:</span>
                <span className="text-white">£{monthlyNetIncome.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[#8b949e]">
                <span>- Essential Expenditure (ONS benchmark):</span>
                <span className="text-[#f85149]">-£{essentialExpenditure.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[#8b949e]">
                <span>- Existing Debt Commitments:</span>
                <span className="text-[#f85149]">-£{existingDebt.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[#8b949e]">
                <span>- Proposed Loan Installment:</span>
                <span className="text-[#d29922]">-£{amortisation.monthlyPayment.toFixed(0)}</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-[#21262d] font-bold">
                <span className="text-white">Residual Disposable Income:</span>
                <span className={mockCustomer.affordability.residualDisposableIncome >= 500 ? 'text-[#3fb950]' : 'text-[#f85149]'}>
                  £{(monthlyNetIncome - essentialExpenditure - existingDebt - amortisation.monthlyPayment).toFixed(0)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Middle Column (4 cols): Scorecard Evaluation & Contract Financials */}
        <div className="lg:col-span-4 space-y-4">
          {/* Scorecard Output Box */}
          <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-3">
            <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
              <span>SCORECARD DECISION & TRAIL</span>
              <span className={`px-2 py-0.5 font-mono text-xs font-bold border ${
                scorecard.riskGrade === 'A' ? 'bg-[#3fb950]/20 text-[#3fb950] border-[#3fb950]' :
                scorecard.riskGrade === 'B' ? 'bg-[#388bfd]/20 text-[#388bfd] border-[#388bfd]' :
                scorecard.riskGrade === 'C' ? 'bg-[#d29922]/20 text-[#d29922] border-[#d29922]' :
                'bg-[#f85149]/20 text-[#f85149] border-[#f85149]'
              }`}>
                RISK GRADE: {scorecard.riskGrade}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center font-mono text-[11px]">
              <div className="bg-[#0b0e14] border border-[#21262d] p-2">
                <div className="text-[10px] text-[#8b949e]">TOTAL SCORE</div>
                <div className="text-base font-bold text-white mt-0.5">{scorecard.totalScore}</div>
              </div>
              <div className="bg-[#0b0e14] border border-[#21262d] p-2">
                <div className="text-[10px] text-[#8b949e]">12M PD</div>
                <div className="text-base font-bold text-[#d29922] mt-0.5">{(scorecard.pd12m * 100).toFixed(2)}%</div>
              </div>
              <div className="bg-[#0b0e14] border border-[#21262d] p-2">
                <div className="text-[10px] text-[#8b949e]">LIFETIME PD</div>
                <div className="text-base font-bold text-[#f85149] mt-0.5">{(scorecard.pdLifetime * 100).toFixed(1)}%</div>
              </div>
            </div>

            {/* Transparent Reason Code Trail */}
            <div className="space-y-1.5 font-mono text-[11px]">
              <div className="text-[10px] text-[#8b949e] uppercase font-bold">TRANSPARENT REASON CODES</div>
              {scorecard.positiveReasons.map((reason, idx) => (
                <div key={idx} className="flex items-center space-x-1.5 text-[#3fb950] bg-[#0b0e14] px-2 py-1 border border-[#21262d]">
                  <Plus className="w-3 h-3 shrink-0" />
                  <span>{reason}</span>
                </div>
              ))}
              {scorecard.negativeReasons.map((reason, idx) => (
                <div key={idx} className="flex items-center space-x-1.5 text-[#f85149] bg-[#0b0e14] px-2 py-1 border border-[#21262d]">
                  <Minus className="w-3 h-3 shrink-0" />
                  <span>{reason}</span>
                </div>
              ))}
            </div>

            <div className="text-[10px] text-[#8b949e] border-t border-[#21262d] pt-2">
              Statutory Guarantee: Prohibited characteristics strictly quarantined from underwriting logic.
            </div>
          </div>

          {/* Loan Contract Financials Output */}
          <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-2.5 font-mono text-[11px]">
            <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
              <span>CONTRACT CASH FLOW TERMS</span>
              <span className="text-[#d29922] font-bold">APR {pricing.totalRequiredCustomerRatePct.toFixed(2)}%</span>
            </div>

            <div className="space-y-1.5 divide-y divide-[#161b22]">
              <div className="flex justify-between py-1">
                <span className="text-[#8b949e]">Original Financed Principal:</span>
                <span className="text-white font-bold">£{(vehiclePrice - depositAmount).toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#8b949e]">Monthly Installment ({termMonths}x):</span>
                <span className="text-[#3fb950] font-bold text-sm">£{amortisation.monthlyPayment.toFixed(2)} / mo</span>
              </div>
              {productType === 'PCP' && (
                <div className="flex justify-between py-1">
                  <span className="text-[#8b949e]">Guaranteed Future Value (GFV):</span>
                  <span className="text-[#388bfd] font-bold">£{guaranteedFutureValue.toLocaleString()} ({(guaranteedFutureValue / vehiclePrice * 100).toFixed(1)}%)</span>
                </div>
              )}
              <div className="flex justify-between py-1">
                <span className="text-[#8b949e]">Total Interest Payable:</span>
                <span className="text-[#d29922]">£{amortisation.totalInterestPayable.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#8b949e]">Total Amount Payable:</span>
                <span className="text-white font-bold">£{amortisation.totalAmountPayable.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#8b949e]">Voluntary Termination Month (s.99):</span>
                <span className="text-[#8b949e]">Month {amortisation.voluntaryTerminationMonth} of {termMonths}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (4 cols): RAROC Margin Waterfall & Dynamic Rate Sheet */}
        <div className="lg:col-span-4 space-y-4">
          {/* RAROC Margin Waterfall */}
          <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-2.5 font-mono text-[11px]">
            <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
              <span>RHINOQUANT RAROC MARGIN WATERFALL</span>
              <span className="text-[#3fb950] font-bold">RAROC {pricing.rarocContributionPct.toFixed(1)}%</span>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-white font-bold bg-[#0b0e14] p-1.5 border border-[#21262d]">
                <span>Required Customer APR:</span>
                <span className="text-sm text-[#3fb950]">{pricing.totalRequiredCustomerRatePct.toFixed(2)}%</span>
              </div>

              <div className="p-2 bg-[#0b0e14] border border-[#21262d] space-y-1 text-[11px]">
                <div className="flex justify-between text-[#8b949e]">
                  <span>- Wholesale Cost of Funds:</span>
                  <span className="text-white">-{pricing.fundingCostPct.toFixed(2)}%</span>
                </div>
                <div className="flex justify-between text-[#8b949e]">
                  <span>- Expected Credit Loss (ECL):</span>
                  <span className="text-[#d29922]">-{pricing.expectedCreditLossPct.toFixed(2)}%</span>
                </div>
                <div className="flex justify-between text-[#8b949e]">
                  <span>- Operating & Servicing Cost:</span>
                  <span className="text-white">-{pricing.operatingServicingPct.toFixed(2)}%</span>
                </div>
                <div className="flex justify-between text-[#8b949e]">
                  <span>- Economic Capital Charge:</span>
                  <span className="text-white">-{pricing.economicCapitalChargePct.toFixed(2)}%</span>
                </div>
                <div className="flex justify-between text-[#8b949e]">
                  <span>- Liquidity Term Premium:</span>
                  <span className="text-white">-{pricing.liquidityPremiumPct.toFixed(2)}%</span>
                </div>
                <div className="flex justify-between text-white font-bold pt-1 border-t border-[#21262d]">
                  <span>= Net Risk-Adjusted Margin:</span>
                  <span className="text-[#3fb950]">+{pricing.targetProfitMarginPct.toFixed(2)}%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Dynamic Rate Sheet Matrix */}
          <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-2">
            <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
              <span>AUTO FINANCE RATE SHEET MATRIX</span>
              <span className="text-[10px] text-[#8b949e] font-mono">LIVE ENGINE</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-center font-mono text-[10px] table-dense divide-y divide-[#21262d]">
                <thead>
                  <tr className="text-[#8b949e] bg-[#0b0e14]">
                    <th className="text-left py-1.5">GRADE</th>
                    <th>24M</th>
                    <th>36M</th>
                    <th>48M</th>
                    <th>60M</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#161b22]">
                  {(['A', 'B', 'C', 'D', 'E'] as RiskGrade[]).map((grade) => {
                    const isSelectedGrade = grade === scorecard.riskGrade;
                    return (
                      <tr key={grade} className={isSelectedGrade ? 'bg-[#1f2937] text-white font-bold' : 'text-[#c9d1d9]'}>
                        <td className="text-left py-1.5 font-bold text-[#d29922]">{grade}</td>
                        {[24, 36, 48, 60].map((t) => {
                          const cell = rateSheet.find((c) => c.riskGrade === grade && c.termMonths === t);
                          const isCurrent = isSelectedGrade && t === termMonths;
                          return (
                            <td key={t} className={`py-1 ${isCurrent ? 'bg-[#d29922]/20 text-[#d29922] font-bold border border-[#d29922]' : ''}`}>
                              {cell ? `${cell.customerAPR.toFixed(1)}%` : '-'}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Customer Equity Indicator */}
            <div className="p-2.5 bg-[#0b0e14] border border-[#21262d] font-mono text-[11px] space-y-1">
              <div className="text-[10px] text-[#8b949e] uppercase font-bold">MONTH 36 CUSTOMER EQUITY POSITION</div>
              <div className="flex justify-between text-[#8b949e]">
                <span>Vehicle Market Value (36M):</span>
                <span className="text-white">£{depreciationCurve.find(p => p.month === 36)?.retailValue.toLocaleString() || '21,700'}</span>
              </div>
              <div className="flex justify-between text-[#8b949e]">
                <span>Settlement / Loan Balance (36M):</span>
                <span className="text-white">£{(amortisation.periods[35]?.closingBalance || 19200).toLocaleString()}</span>
              </div>
              <div className="flex justify-between font-bold pt-1 border-t border-[#21262d]">
                <span className="text-white">Customer Equity Buffer:</span>
                <span className={equityAt36 >= 0 ? 'text-[#3fb950]' : 'text-[#f85149]'}>
                  {equityAt36 >= 0 ? `+£${equityAt36.toLocaleString()}` : `-£${Math.abs(equityAt36).toLocaleString()} (Negative Equity)`}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
