/**
 * RhinoQuant Auto Finance
 * Institutional Model Risk Management & Validation Inventory (MODEL <GO>)
 */

import React, { useState } from 'react';
import {
  ShieldCheck,
  Activity,
  Layers,
  Database,
  CheckCircle,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import { SYNTHETIC_MODEL_INVENTORY } from '../../data/syntheticPortfolio';

export const ModelRiskView: React.FC = () => {
  const [selectedModelId, setSelectedModelId] = useState<string>(SYNTHETIC_MODEL_INVENTORY[0].id);

  const activeModel = SYNTHETIC_MODEL_INVENTORY.find((m) => m.id === selectedModelId) || SYNTHETIC_MODEL_INVENTORY[0];

  return (
    <div className="p-4 space-y-4 max-w-[1600px] mx-auto text-xs font-sans">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#21262d]">
        <div>
          <h1 className="font-mono text-sm font-bold text-white flex items-center space-x-2">
            <span>MODEL RISK MANAGEMENT & QUANTITATIVE GOVERNANCE</span>
            <span className="text-[10px] bg-[#161b22] border border-[#30363d] px-1.5 py-0.5 text-[#d29922]">
              MODEL &lt;GO&gt;
            </span>
          </h1>
          <p className="text-[#8b949e] text-[11px]">
            SR 11-7 / SS1/23 Model Risk Framework inventory, statistical discrimination metrics, and out-of-sample backtests.
          </p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-[11px]">
          <div>Models in Inventory: <strong className="text-white">14</strong></div>
          <div>Active Approved: <strong className="text-[#3fb950]">11</strong></div>
          <div>Under Validation: <strong className="text-[#d29922]">3</strong></div>
        </div>
      </div>

      {/* Model Inventory Table */}
      <div className="bg-[#11151c] border border-[#21262d] overflow-x-auto">
        <table className="w-full text-left font-mono text-[11px] table-dense divide-y divide-[#21262d]">
          <thead>
            <tr className="text-[#8b949e] bg-[#0b0e14]">
              <th className="py-2">MODEL ID</th>
              <th>MODEL NAME</th>
              <th>VERSION</th>
              <th>OWNER</th>
              <th className="text-right">AUC / C-STAT</th>
              <th className="text-right">GINI COEFF</th>
              <th className="text-right">KS STAT</th>
              <th className="text-right">BRIER SCORE</th>
              <th className="text-right">PSI DRIFT</th>
              <th className="text-right">STATUS</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#161b22]">
            {SYNTHETIC_MODEL_INVENTORY.map((m) => {
              const isSelected = m.id === selectedModelId;
              return (
                <tr
                  key={m.id}
                  onClick={() => setSelectedModelId(m.id)}
                  className={`cursor-pointer transition-colors ${
                    isSelected ? 'bg-[#1c2128] text-white font-medium' : 'hover:bg-[#161b22] text-[#c9d1d9]'
                  }`}
                >
                  <td className="py-2 font-bold text-[#d29922]">{m.id}</td>
                  <td className="font-bold text-white">{m.modelName}</td>
                  <td>{m.version}</td>
                  <td className="text-[#8b949e]">{m.owner.split('(')[0]}</td>
                  <td className="text-right font-mono-numbers text-[#3fb950] font-bold">{m.auc.toFixed(3)}</td>
                  <td className="text-right font-mono-numbers">{m.gini.toFixed(3)}</td>
                  <td className="text-right font-mono-numbers">{m.ksStatistic.toFixed(3)}</td>
                  <td className="text-right font-mono-numbers">{m.brierScore.toFixed(3)}</td>
                  <td className="text-right font-mono-numbers text-[#3fb950]">{m.populationStabilityIndex.toFixed(3)} (Stable)</td>
                  <td className="text-right">
                    <span className={`px-1.5 py-0.2 text-[10px] font-bold border ${
                      m.lifecycleStatus === 'APPROVED' ? 'bg-[#3fb950]/20 text-[#3fb950] border-[#3fb950]' :
                      m.lifecycleStatus === 'MONITORED' ? 'bg-[#388bfd]/20 text-[#388bfd] border-[#388bfd]' :
                      'bg-[#d29922]/20 text-[#d29922] border-[#d29922]'
                    }`}>
                      {m.lifecycleStatus}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Model Technical Dossier */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left (6 cols): Governance & Assumptions */}
        <div className="lg:col-span-6 bg-[#11151c] border border-[#21262d] p-3 space-y-2.5 font-mono text-[11px]">
          <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
            <span>MODEL DOSSIER: {activeModel.modelName}</span>
            <span className="text-[10px] text-[#8b949e]">VALIDATED {activeModel.lastValidationDate}</span>
          </div>

          <div>
            <div className="text-[10px] text-[#8b949e] uppercase font-bold">PURPOSE & SCOPE</div>
            <p className="text-white mt-0.5 font-sans text-xs">{activeModel.purpose}</p>
          </div>

          <div>
            <div className="text-[10px] text-[#8b949e] uppercase font-bold">KEY QUANTITATIVE ASSUMPTIONS</div>
            <ul className="list-disc list-inside space-y-1 text-[#c9d1d9] mt-1 font-sans text-xs">
              {activeModel.keyAssumptions.map((ass, i) => (
                <li key={i}>{ass}</li>
              ))}
            </ul>
          </div>

          <div>
            <div className="text-[10px] text-[#8b949e] uppercase font-bold">DOCUMENTED LIMITATIONS & UNCERTAINTIES</div>
            <ul className="list-disc list-inside space-y-1 text-[#d29922] mt-1 font-sans text-xs">
              {activeModel.limitations.map((lim, i) => (
                <li key={i}>{lim}</li>
              ))}
            </ul>
          </div>
        </div>

        {/* Right (6 cols): Model Performance Validation Stats */}
        <div className="lg:col-span-6 bg-[#11151c] border border-[#21262d] p-3 space-y-3 font-mono text-[11px]">
          <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
            <span>VALIDATION METRICS & DISCRIMINATION POWER</span>
            <span className="text-[#3fb950] font-bold">OUT-OF-SAMPLE TESTED</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-center">
            <div className="bg-[#0b0e14] border border-[#21262d] p-2.5">
              <div className="text-[10px] text-[#8b949e]">AUC / ROC CONCORDANCE</div>
              <div className="text-lg font-bold text-[#3fb950] mt-1">{activeModel.auc.toFixed(3)}</div>
              <div className="text-[10px] text-[#8b949e]">Benchmark threshold &gt; 0.750</div>
            </div>

            <div className="bg-[#0b0e14] border border-[#21262d] p-2.5">
              <div className="text-[10px] text-[#8b949e]">GINI COEFFICIENT</div>
              <div className="text-lg font-bold text-white mt-1">{activeModel.gini.toFixed(3)}</div>
              <div className="text-[10px] text-[#8b949e]">Rank order discrimination</div>
            </div>

            <div className="bg-[#0b0e14] border border-[#21262d] p-2.5">
              <div className="text-[10px] text-[#8b949e]">KOLMOGOROV-SMIRNOV (KS)</div>
              <div className="text-lg font-bold text-[#d29922] mt-1">{activeModel.ksStatistic.toFixed(3)}</div>
              <div className="text-[10px] text-[#8b949e]">Max divergence point</div>
            </div>

            <div className="bg-[#0b0e14] border border-[#21262d] p-2.5">
              <div className="text-[10px] text-[#8b949e]">POPULATION STABILITY (PSI)</div>
              <div className="text-lg font-bold text-[#3fb950] mt-1">{activeModel.populationStabilityIndex.toFixed(3)}</div>
              <div className="text-[10px] text-[#3fb950]">Zero significant drift (&lt; 0.10)</div>
            </div>
          </div>

          <div className="bg-[#0b0e14] border border-[#21262d] p-2 text-[#8b949e] text-[10px]">
            Governance Note: Re-calibration mandatory every 12 months or when PSI breaches 0.150. Model risk tier: Tier 1 Material Decisioning.
          </div>
        </div>
      </div>
    </div>
  );
};
