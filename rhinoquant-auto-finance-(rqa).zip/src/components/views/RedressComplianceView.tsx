/**
 * RhinoQuant Auto Finance
 * Regulatory Compliance & Motor Finance Redress Engine (REDRESS <GO> / COMPLIANCE <GO>)
 * FCA 2026 DCA Framework & Financial Promotion Verifier
 */

import React, { useState } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  FileText,
  CheckCircle,
  HelpCircle,
  RotateCcw,
  Scale,
  Search,
} from 'lucide-react';
import {
  SCHEME_VERSIONS,
  calculateAgreementRedress,
  validateFinancialPromotionText,
} from '../../engine/redress';
import { SYNTHETIC_REDRESS_CASES } from '../../data/syntheticPortfolio';

export const RedressComplianceView: React.FC = () => {
  const [selectedSchemeKey, setSelectedSchemeKey] = useState<string>('FCA-DCA-2026.2');
  const [activeTab, setActiveTab] = useState<'REDRESS' | 'PROMOTION_CHECKER'>('REDRESS');

  // Promotion Checker State
  const [promoText, setPromoText] = useState<string>(
    'Drive away in a brand new BMW i4 from just £499 per month. Cash price £58,800, customer deposit £5,000, 48 monthly payments. Representative 8.4% APR. Missed payments may result in vehicle repossession.'
  );

  const activeScheme = SCHEME_VERSIONS[selectedSchemeKey] || SCHEME_VERSIONS['FCA-DCA-2026.2'];

  const promoValidation = validateFinancialPromotionText(promoText);

  // Redress portfolio total summary
  const totalCases = SYNTHETIC_REDRESS_CASES.length;
  const totalEstimatedLiability = SYNTHETIC_REDRESS_CASES.reduce((sum, c) => sum + c.totalRedressPayable, 0);

  return (
    <div className="p-4 space-y-4 max-w-[1600px] mx-auto text-xs font-sans">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#21262d]">
        <div>
          <h1 className="font-mono text-sm font-bold text-white flex items-center space-x-2">
            <span>REGULATORY COMPLIANCE & MOTOR FINANCE REDRESS DESK</span>
            <span className="text-[10px] bg-[#161b22] border border-[#30363d] px-1.5 py-0.5 text-[#388bfd]">
              REDRESS &lt;GO&gt; / COMPLIANCE &lt;GO&gt;
            </span>
          </h1>
          <p className="text-[#8b949e] text-[11px]">
            Historical Discretionary Commission Arrangements (DCA 2007-2024) liability modelling and FCA CONC 3 financial promotion controls.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center space-x-1 bg-[#11151c] border border-[#21262d] p-0.5 font-mono text-[11px]">
          <button
            onClick={() => setActiveTab('REDRESS')}
            className={`px-3 py-1 transition-colors ${
              activeTab === 'REDRESS' ? 'bg-[#1f2937] text-white font-bold' : 'text-[#8b949e] hover:text-white'
            }`}
          >
            DCA REDRESS ENGINE
          </button>
          <button
            onClick={() => setActiveTab('PROMOTION_CHECKER')}
            className={`px-3 py-1 transition-colors ${
              activeTab === 'PROMOTION_CHECKER' ? 'bg-[#1f2937] text-white font-bold' : 'text-[#8b949e] hover:text-white'
            }`}
          >
            CONC 3 PROMOTION CHECKER
          </button>
        </div>
      </div>

      {activeTab === 'REDRESS' ? (
        <div className="space-y-4">
          {/* Version-Controlled Regulatory Rule Selector Strip */}
          <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-2 font-mono text-[11px]">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#21262d] pb-1.5">
              <span className="font-bold text-white flex items-center">
                <Scale className="w-3.5 h-3.5 mr-1 text-[#d29922]" />
                ACTIVE REDRESS RULE VERSION SPECIFICATION
              </span>
              <span className="text-[10px] text-[#f85149] font-bold">
                {activeScheme.isCourtChallengedOrSuspended ? 'NOTICE: SCHEME CURRENTLY SUBJECT TO COURT APPEAL / SUSPENSION' : 'ACTIVE RULE'}
              </span>
            </div>

            <div className="flex flex-wrap gap-2 pt-1">
              {Object.keys(SCHEME_VERSIONS).map((key) => {
                const s = SCHEME_VERSIONS[key];
                const isSelected = selectedSchemeKey === key;
                return (
                  <button
                    key={key}
                    onClick={() => setSelectedSchemeKey(key)}
                    className={`px-3 py-1.5 border text-left transition-colors ${
                      isSelected
                        ? 'bg-[#1f2937] text-[#d29922] border-[#d29922] font-bold'
                        : 'bg-[#0b0e14] text-[#8b949e] hover:text-white border-[#21262d]'
                    }`}
                  >
                    <div>{s.version}</div>
                    <div className="text-[9px] text-[#8b949e] line-clamp-1">{s.schemeTitle}</div>
                  </button>
                );
              })}
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 pt-2 text-[#8b949e] text-[10px]">
              <div>Benchmark Lender Rate: <strong className="text-white">{activeScheme.benchmarkLenderRateSpreadPct}%</strong></div>
              <div>Compensatory Interest Basis: <strong className="text-white">{activeScheme.interestCalculationMethod}</strong></div>
              <div>Statutory Rate: <strong className="text-white">{activeScheme.compensatoryInterestRatePct}% p.a.</strong></div>
              <div>Cut-Off Date: <strong className="text-white">{activeScheme.timeLimitCutoffDate}</strong></div>
            </div>
          </div>

          {/* Historical Agreement Sample Ledger */}
          <div className="bg-[#11151c] border border-[#21262d]">
            <div className="flex items-center justify-between px-3 py-2 border-b border-[#21262d] bg-[#0b0e14]">
              <span className="font-mono text-xs font-bold text-white tracking-wide">
                HISTORICAL MOTOR FINANCE AGREEMENT COHORT (2007-2024 DCA)
              </span>
              <span className="text-[10px] text-[#8b949e] font-mono">
                Total Redress Liability: <strong className="text-[#f85149]">£{totalEstimatedLiability.toLocaleString()}</strong> across sample
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-[11px] table-dense divide-y divide-[#21262d]">
                <thead>
                  <tr className="text-[#8b949e] bg-[#0b0e14]">
                    <th className="py-2">AGREEMENT REF</th>
                    <th>START DATE</th>
                    <th>CUSTOMER</th>
                    <th>ORIGINATING DEALER</th>
                    <th>VEHICLE</th>
                    <th className="text-right">FINANCED AMT</th>
                    <th className="text-right">APR</th>
                    <th className="text-right">DISCRETION %</th>
                    <th className="text-right">COMMISSION</th>
                    <th className="text-right">8% STATUTORY INT</th>
                    <th className="text-right">TOTAL REDRESS</th>
                    <th className="text-right">LEGAL STATUS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#161b22]">
                  {SYNTHETIC_REDRESS_CASES.map((c) => {
                    return (
                      <tr key={c.id} className="hover:bg-[#161b22] text-[#c9d1d9]">
                        <td className="py-2 font-bold text-[#d29922]">{c.agreementReference}</td>
                        <td>{c.originationDate}</td>
                        <td className="text-white font-medium">{c.customerName}</td>
                        <td>{c.dealerName}</td>
                        <td>{c.originalVehicle}</td>
                        <td className="text-right font-mono-numbers">£{c.financedAmount.toLocaleString()}</td>
                        <td className="text-right font-mono-numbers text-white">{c.contractAPR.toFixed(1)}%</td>
                        <td className="text-right font-mono-numbers text-[#f85149]">+{c.discretionaryCommissionPct.toFixed(1)}%</td>
                        <td className="text-right font-mono-numbers text-white">£{c.discretionaryCommissionAmount.toLocaleString()}</td>
                        <td className="text-right font-mono-numbers text-[#d29922]">£{c.statutoryInterestAmount.toLocaleString()}</td>
                        <td className="text-right font-mono-numbers text-[#f85149] font-bold">
                          £{c.totalRedressPayable.toLocaleString()}
                        </td>
                        <td className="text-right">
                          <span className={`px-1.5 py-0.2 text-[10px] font-bold border ${
                            c.status === 'CALCULATED_PROVISIONAL' ? 'bg-[#388bfd]/20 text-[#388bfd] border-[#388bfd]' :
                            c.status === 'APPEAL_SUSPENDED' ? 'bg-[#d29922]/20 text-[#d29922] border-[#d29922]' :
                            'bg-[#161b22] text-[#8b949e] border-[#30363d]'
                          }`}>
                            {c.status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-[#0b0e14] border-t border-[#21262d] text-[10px] text-[#8b949e] font-mono">
              Disclaimer: Software calculation engine provided for quantitative reserving and actuarial scenarios. Does not constitute formal legal determination under statutory compensation schemes.
            </div>
          </div>
        </div>
      ) : (
        /* FCA CONC 3 Promotion Checker View */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-7 bg-[#11151c] border border-[#21262d] p-3 space-y-3 font-mono text-[11px]">
            <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
              <span>FINANCIAL PROMOTION COPY EDITOR</span>
              <span className="text-[10px] text-[#8b949e]">FCA CONC 3.5 RULES</span>
            </div>

            <div>
              <label className="text-[10px] text-[#8b949e] block mb-1">Proposed Marketing Advertisement Copy:</label>
              <textarea
                rows={6}
                value={promoText}
                onChange={(e) => setPromoText(e.target.value)}
                className="w-full bg-[#0b0e14] border border-[#30363d] text-white p-2.5 font-sans text-xs focus:outline-none focus:border-[#d29922] leading-relaxed"
              />
            </div>

            <div className="flex justify-between items-center text-[10px] text-[#8b949e]">
              <span>Real-time syntax validation against regulatory required warnings</span>
              <button
                onClick={() => setPromoText('Drive away in a new car today for only £299! Zero deposit required. Instant approval guaranteed!')}
                className="text-[#f85149] hover:underline"
              >
                [Load Non-Compliant Example]
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 bg-[#11151c] border border-[#21262d] p-3 space-y-3 font-mono text-[11px]">
            <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
              <span>COMPLIANCE AUDIT VERDICT</span>
              <span className={`px-2 py-0.5 text-xs font-bold border ${
                promoValidation.isCompliant
                  ? 'bg-[#3fb950]/20 text-[#3fb950] border-[#3fb950]'
                  : 'bg-[#f85149]/20 text-[#f85149] border-[#f85149]'
              }`}>
                {promoValidation.isCompliant ? 'CONC 3 PASSED' : 'CONC 3 BREACHES'}
              </span>
            </div>

            <div className="space-y-2 pt-1">
              <div className="flex items-center justify-between p-2 bg-[#0b0e14] border border-[#21262d]">
                <span>Representative APR Stated Prominently:</span>
                <span className={promoValidation.representativeAprStated ? 'text-[#3fb950] font-bold' : 'text-[#f85149] font-bold'}>
                  {promoValidation.representativeAprStated ? 'YES (PASS)' : 'MISSING (FAIL)'}
                </span>
              </div>

              <div className="flex items-center justify-between p-2 bg-[#0b0e14] border border-[#21262d]">
                <span>Mandatory Repossession / Default Warning:</span>
                <span className={promoValidation.riskWarningIncluded ? 'text-[#3fb950] font-bold' : 'text-[#f85149] font-bold'}>
                  {promoValidation.riskWarningIncluded ? 'YES (PASS)' : 'MISSING (FAIL)'}
                </span>
              </div>

              <div className="flex items-center justify-between p-2 bg-[#0b0e14] border border-[#21262d]">
                <span>Full Representative Example Elements:</span>
                <span className={promoValidation.representativeExampleValid ? 'text-[#3fb950] font-bold' : 'text-[#f85149] font-bold'}>
                  {promoValidation.representativeExampleValid ? 'YES (PASS)' : 'MISSING (FAIL)'}
                </span>
              </div>
            </div>

            {promoValidation.concerns.length > 0 && (
              <div className="p-2.5 bg-[#0b0e14] border-l-2 border-[#f85149] border-t border-r border-b border-[#21262d] space-y-1">
                <div className="text-[#f85149] font-bold text-[10px] uppercase">REGULATORY CONCERNS DETECTED</div>
                {promoValidation.concerns.map((c, i) => (
                  <div key={i} className="text-[#c9d1d9] text-[10px]">{c}</div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
