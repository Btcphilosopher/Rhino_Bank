/**
 * RhinoQuant Auto Finance
 * Institutional Treasury & Warehouse Funding Desk (FUND <GO>)
 */

import React, { useState } from 'react';
import {
  Briefcase,
  Layers,
  ShieldCheck,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  ArrowRight,
} from 'lucide-react';
import { SYNTHETIC_WAREHOUSES } from '../../data/syntheticPortfolio';

export const FundingWarehouseView: React.FC = () => {
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>(SYNTHETIC_WAREHOUSES[0].id);

  const activeFacility = SYNTHETIC_WAREHOUSES.find((w) => w.id === selectedWarehouseId) || SYNTHETIC_WAREHOUSES[0];

  const totalCommitted = SYNTHETIC_WAREHOUSES.reduce((sum, w) => sum + w.facilityLimit, 0);
  const totalDrawn = SYNTHETIC_WAREHOUSES.reduce((sum, w) => sum + w.drawnAmount, 0);
  const totalAvailable = totalCommitted - totalDrawn;
  const overallUtilisation = Number(((totalDrawn / totalCommitted) * 100).toFixed(1));

  return (
    <div className="p-4 space-y-4 max-w-[1600px] mx-auto text-xs font-sans">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#21262d]">
        <div>
          <h1 className="font-mono text-sm font-bold text-white flex items-center space-x-2">
            <span>TREASURY & WAREHOUSE LIQUIDITY DESK</span>
            <span className="text-[10px] bg-[#161b22] border border-[#30363d] px-1.5 py-0.5 text-[#d29922]">
              FUND &lt;GO&gt;
            </span>
          </h1>
          <p className="text-[#8b949e] text-[11px]">
            Institutional revolving warehouse facilities, advance rates, bank funding covenants, and cost of funds curves.
          </p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-[11px]">
          <div>Total Capacity: <strong className="text-white">£{(totalCommitted / 1000000).toFixed(0)}m</strong></div>
          <div>Drawn: <strong className="text-[#3fb950]">£{(totalDrawn / 1000000).toFixed(0)}m ({overallUtilisation}%)</strong></div>
          <div>Available: <strong className="text-[#d29922]">£{(totalAvailable / 1000000).toFixed(0)}m</strong></div>
        </div>
      </div>

      {/* Facility Strip Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {SYNTHETIC_WAREHOUSES.map((wh) => {
          const isSelected = wh.id === selectedWarehouseId;
          const utilPct = Number(((wh.drawnAmount / wh.facilityLimit) * 100).toFixed(1));
          return (
            <div
              key={wh.id}
              onClick={() => setSelectedWarehouseId(wh.id)}
              className={`p-3 border cursor-pointer transition-colors ${
                isSelected
                  ? 'bg-[#161b22] border-[#d29922]'
                  : 'bg-[#11151c] border-[#21262d] hover:border-[#30363d]'
              }`}
            >
              <div className="flex justify-between items-start font-mono text-xs">
                <div>
                  <div className="font-bold text-white">{wh.name}</div>
                  <div className="text-[10px] text-[#8b949e]">{wh.lenderBank}</div>
                </div>
                <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold bg-[#0b0e14] border border-[#30363d] text-[#3fb950]">
                  ACTIVE REVOLVING
                </span>
              </div>

              <div className="mt-3 grid grid-cols-4 gap-2 font-mono text-[11px]">
                <div>
                  <div className="text-[10px] text-[#8b949e]">LIMIT</div>
                  <div className="text-white font-bold">£{(wh.facilityLimit / 1000000).toFixed(0)}m</div>
                </div>
                <div>
                  <div className="text-[10px] text-[#8b949e]">DRAWN</div>
                  <div className="text-[#3fb950] font-bold">£{(wh.drawnAmount / 1000000).toFixed(0)}m</div>
                </div>
                <div>
                  <div className="text-[10px] text-[#8b949e]">UTILISATION</div>
                  <div className="text-white font-bold">{utilPct}%</div>
                </div>
                <div>
                  <div className="text-[10px] text-[#8b949e]">ALL-IN COST</div>
                  <div className="text-[#d29922] font-bold">{wh.allInCostOfFundsPct.toFixed(2)}%</div>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-[#0b0e14] h-1.5 mt-2.5">
                <div className="bg-[#3fb950] h-1.5" style={{ width: `${utilPct}%` }} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Active Facility Deep Dive: Terms & Covenants */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column (5 cols): Terms & Advance Rates */}
        <div className="lg:col-span-5 bg-[#11151c] border border-[#21262d] p-3 space-y-3 font-mono text-[11px]">
          <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
            <span>FACILITY TERMS: {activeFacility.name}</span>
            <span className="text-[10px] text-[#8b949e]">MATURITY {activeFacility.maturityDate}</span>
          </div>

          <div className="space-y-1.5 divide-y divide-[#161b22]">
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">Syndicate Agent:</span>
              <span className="text-white font-bold">{activeFacility.lenderBank}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">Advance Rate:</span>
              <span className="text-[#3fb950] font-bold">{activeFacility.advanceRatePct.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">Haircut / Equity Buffer:</span>
              <span className="text-white font-bold">{activeFacility.haircutPct.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">Margin Spread over SONIA:</span>
              <span className="text-[#d29922] font-bold">+{activeFacility.marginSpreadBp} bp</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">All-in Borrowing Cost:</span>
              <span className="text-white font-bold">{activeFacility.allInCostOfFundsPct.toFixed(2)}%</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">Available Headroom:</span>
              <span className="text-[#388bfd] font-bold">£{(activeFacility.availableAmount / 1000000).toFixed(1)}m</span>
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Covenant Tracking Ledger */}
        <div className="lg:col-span-7 bg-[#11151c] border border-[#21262d] p-3 space-y-2 font-mono text-[11px]">
          <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
            <span>FINANCIAL & COLLATERAL COVENANT TRACKER</span>
            <span className="text-[#3fb950] flex items-center text-[10px]">
              <ShieldCheck className="w-3.5 h-3.5 mr-1" />
              100% COMPLIANT
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-[11px] table-dense divide-y divide-[#21262d]">
              <thead>
                <tr className="text-[#8b949e] bg-[#0b0e14]">
                  <th className="py-2">COVENANT METRIC</th>
                  <th>THRESHOLD</th>
                  <th>ACTUAL</th>
                  <th className="text-right">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#161b22]">
                {activeFacility.covenants.map((cov, idx) => (
                  <tr key={idx} className="hover:bg-[#161b22] text-[#c9d1d9]">
                    <td className="py-2 font-medium text-white">{cov.metric}</td>
                    <td className="text-[#8b949e]">{cov.threshold}</td>
                    <td className="font-bold text-white">{cov.actual}</td>
                    <td className="text-right">
                      <span className="px-1.5 py-0.2 text-[10px] font-bold bg-[#3fb950]/20 text-[#3fb950] border border-[#3fb950]">
                        {cov.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
