/**
 * RhinoQuant Auto Finance
 * Institutional Command Centre Desk (AUTO <GO>)
 */

import React, { useState } from 'react';
import {
  TrendingUp,
  AlertTriangle,
  ShieldAlert,
  ArrowUpRight,
  Database,
  BarChart3,
  Layers,
  ArrowRight,
  ChevronRight,
  Zap,
} from 'lucide-react';
import { SYNTHETIC_PORTFOLIO_METRICS, SYNTHETIC_VINTAGES } from '../../data/syntheticPortfolio';

interface CommandCentreViewProps {
  onNavigate: (command: string) => void;
  onOpenDataLineage: (metricKey?: string) => void;
}

export const CommandCentreView: React.FC<CommandCentreViewProps> = ({
  onNavigate,
  onOpenDataLineage,
}) => {
  const [selectedVintageCohort, setSelectedVintageCohort] = useState<string>('2024-Q2');
  const [activeTab, setActiveTab] = useState<'VINTAGES' | 'DELINQUENCY' | 'LOSSES' | 'RESIDUALS'>('VINTAGES');

  const selectedVintage = SYNTHETIC_VINTAGES.find((v) => v.vintageCohort === selectedVintageCohort) || SYNTHETIC_VINTAGES[0];

  return (
    <div className="p-4 space-y-4 max-w-[1600px] mx-auto text-xs font-sans">
      {/* Topmost Institutional Desk Header Metrics Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
        {/* Metric 1: Portfolio Balance */}
        <div 
          onClick={() => onOpenDataLineage('PORTFOLIO_BALANCE')}
          className="bg-[#11151c] border border-[#21262d] hover:border-[#30363d] p-2.5 cursor-pointer transition-colors relative group"
        >
          <div className="flex items-center justify-between text-[#8b949e] text-[10px] uppercase font-mono">
            <span>Portfolio Balance</span>
            <Database className="w-3 h-3 text-[#388bfd] opacity-50 group-hover:opacity-100" />
          </div>
          <div className="mt-1 font-mono text-lg font-bold text-white tracking-tight">
            £2.42bn
          </div>
          <div className="mt-0.5 text-[10px] text-[#8b949e] font-mono flex items-center justify-between">
            <span>Active: 184,291</span>
            <span className="text-[#3fb950] font-medium">+4.2% YoY</span>
          </div>
        </div>

        {/* Metric 2: Expected Credit Loss (ECL) */}
        <div 
          onClick={() => onOpenDataLineage('EXPECTED_LOSS')}
          className="bg-[#11151c] border border-[#21262d] hover:border-[#d29922] p-2.5 cursor-pointer transition-colors relative group"
        >
          <div className="flex items-center justify-between text-[#8b949e] text-[10px] uppercase font-mono">
            <span>Expected Loss (12M)</span>
            <Database className="w-3 h-3 text-[#d29922] opacity-50 group-hover:opacity-100" />
          </div>
          <div className="mt-1 font-mono text-lg font-bold text-[#d29922] tracking-tight">
            £24.8m
          </div>
          <div className="mt-0.5 text-[10px] text-[#8b949e] font-mono flex items-center justify-between">
            <span>ECL Rate: 1.02%</span>
            <span className="text-[#8b949e]">PD × LGD × EAD</span>
          </div>
        </div>

        {/* Metric 3: 12M Default Rate */}
        <div 
          onClick={() => onNavigate('RISK')}
          className="bg-[#11151c] border border-[#21262d] hover:border-[#30363d] p-2.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-[#8b949e] text-[10px] uppercase font-mono">
            <span>12M Default Rate</span>
            <span className="text-[10px] text-[#8b949e]">RISK</span>
          </div>
          <div className="mt-1 font-mono text-lg font-bold text-white tracking-tight">
            2.90%
          </div>
          <div className="mt-0.5 text-[10px] text-[#8b949e] font-mono flex items-center justify-between">
            <span>Baseline: 2.85%</span>
            <span className="text-[#d29922]">+5bp buffer</span>
          </div>
        </div>

        {/* Metric 4: RAROC */}
        <div 
          onClick={() => onOpenDataLineage('RAROC')}
          className="bg-[#11151c] border border-[#21262d] hover:border-[#3fb950] p-2.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-[#8b949e] text-[10px] uppercase font-mono">
            <span>Portfolio RAROC</span>
            <Database className="w-3 h-3 text-[#3fb950] opacity-50" />
          </div>
          <div className="mt-1 font-mono text-lg font-bold text-[#3fb950] tracking-tight">
            18.70%
          </div>
          <div className="mt-0.5 text-[10px] text-[#8b949e] font-mono flex items-center justify-between">
            <span>Hurdle: 15.0%</span>
            <span className="text-[#3fb950]">+370bp spread</span>
          </div>
        </div>

        {/* Metric 5: BEV Exposure */}
        <div 
          onClick={() => onNavigate('STRESS')}
          className="bg-[#11151c] border border-[#21262d] hover:border-[#f85149] p-2.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-[#8b949e] text-[10px] uppercase font-mono">
            <span>BEV Exposure</span>
            <span className="text-[10px] text-[#d29922]">STRESS</span>
          </div>
          <div className="mt-1 font-mono text-lg font-bold text-[#e6edf3] tracking-tight">
            21.40%
          </div>
          <div className="mt-0.5 text-[10px] text-[#8b949e] font-mono flex items-center justify-between">
            <span>Limit: 25.0% max</span>
            <span className="text-[#3fb950]">OK (Headroom 3.6%)</span>
          </div>
        </div>

        {/* Metric 6: Base Funding Cost */}
        <div 
          onClick={() => onNavigate('FUND')}
          className="bg-[#11151c] border border-[#21262d] hover:border-[#30363d] p-2.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-[#8b949e] text-[10px] uppercase font-mono">
            <span>Funding Cost</span>
            <span className="text-[10px] text-[#8b949e]">TREASURY</span>
          </div>
          <div className="mt-1 font-mono text-lg font-bold text-white tracking-tight">
            4.31%
          </div>
          <div className="mt-0.5 text-[10px] text-[#8b949e] font-mono flex items-center justify-between">
            <span>SONIA + 135bp</span>
            <span className="text-[#8b949e]">Wholesale A</span>
          </div>
        </div>

        {/* Metric 7: Customer Yield */}
        <div 
          onClick={() => onNavigate('PRICING')}
          className="bg-[#11151c] border border-[#21262d] hover:border-[#30363d] p-2.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-[#8b949e] text-[10px] uppercase font-mono">
            <span>Avg Customer Yield</span>
            <span className="text-[10px] text-[#8b949e]">PRICING</span>
          </div>
          <div className="mt-1 font-mono text-lg font-bold text-white tracking-tight">
            8.40%
          </div>
          <div className="mt-0.5 text-[10px] text-[#8b949e] font-mono flex items-center justify-between">
            <span>Gross Spread</span>
            <span className="text-[#3fb950]">+409bp NIM</span>
          </div>
        </div>
      </div>

      {/* Main Grid: 70% Analytical Desk + 30% Right-hand Risk Alerts Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column (8 of 12 cols): Analytical Workbench & Vintage Performance */}
        <div className="lg:col-span-8 space-y-4">
          {/* Performance Module Tabs */}
          <div className="bg-[#11151c] border border-[#21262d]">
            <div className="flex items-center justify-between px-3 py-2 border-b border-[#21262d] bg-[#0b0e14]">
              <div className="flex items-center space-x-2">
                <span className="font-mono text-xs font-bold text-white tracking-wide">
                  PORTFOLIO PERFORMANCE COHORTS
                </span>
                <span className="text-[10px] text-[#8b949e] font-mono">· 2023 Q1 to 2025 Q1</span>
              </div>

              {/* Segmented control tabs */}
              <div className="flex items-center space-x-1">
                {(['VINTAGES', 'DELINQUENCY', 'LOSSES', 'RESIDUALS'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-2.5 py-1 text-[11px] font-mono transition-colors border ${
                      activeTab === tab
                        ? 'bg-[#1f2937] text-[#d29922] border-[#d29922]'
                        : 'bg-[#161b22] text-[#8b949e] hover:text-white border-[#21262d]'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            {/* Vintage Curves Table & Quantitative Visualisation */}
            <div className="p-3">
              {activeTab === 'VINTAGES' && (
                <div className="space-y-3">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left font-mono text-[11px] table-dense divide-y divide-[#21262d]">
                      <thead>
                        <tr className="text-[#8b949e] bg-[#0b0e14]">
                          <th className="py-2">VINTAGE</th>
                          <th className="text-right">ORIGINATION</th>
                          <th className="text-right">CURRENT BAL</th>
                          <th className="text-right">AVG APR</th>
                          <th className="text-right">CUMUL. DEFAULT</th>
                          <th className="text-right">CUMUL. LOSS</th>
                          <th className="text-right">30+ DPD</th>
                          <th className="text-right">CPR (PREPAY)</th>
                          <th className="text-right">BEV SHARE</th>
                          <th className="text-center">ACTION</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#161b22]">
                        {SYNTHETIC_VINTAGES.map((v) => {
                          const isSel = v.vintageCohort === selectedVintageCohort;
                          return (
                            <tr
                              key={v.vintageCohort}
                              onClick={() => setSelectedVintageCohort(v.vintageCohort)}
                              className={`cursor-pointer transition-colors ${
                                isSel ? 'bg-[#1c2128] text-white font-medium' : 'hover:bg-[#161b22] text-[#c9d1d9]'
                              }`}
                            >
                              <td className="py-2 font-bold text-[#d29922]">{v.vintageCohort}</td>
                              <td className="text-right font-mono-numbers">£{(v.originationVolumeGBP / 1000000).toFixed(0)}m</td>
                              <td className="text-right font-mono-numbers text-white">£{(v.currentBalanceGBP / 1000000).toFixed(0)}m</td>
                              <td className="text-right font-mono-numbers">{v.avgAPR.toFixed(1)}%</td>
                              <td className="text-right font-mono-numbers text-[#f85149]">{v.cumulativeDefaultPct.toFixed(1)}%</td>
                              <td className="text-right font-mono-numbers text-[#d29922]">{v.cumulativeLossPct.toFixed(1)}%</td>
                              <td className={`text-right font-mono-numbers ${v.thirtyPlusDpdPct >= 2.5 ? 'text-[#f85149] font-bold' : 'text-[#8b949e]'}`}>
                                {v.thirtyPlusDpdPct.toFixed(1)}%
                              </td>
                              <td className="text-right font-mono-numbers text-[#3fb950]">{v.prepaymentCprPct.toFixed(1)}%</td>
                              <td className="text-right font-mono-numbers">{v.bevSharePct.toFixed(1)}%</td>
                              <td className="text-center">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onNavigate('PORT');
                                  }}
                                  className="text-[10px] text-[#388bfd] hover:underline"
                                >
                                  DRILL &rarr;
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* Quantitative Vintage Visualisation Bar */}
                  <div className="bg-[#0b0e14] border border-[#21262d] p-3 space-y-2">
                    <div className="flex items-center justify-between text-[11px] font-mono">
                      <span className="text-[#8b949e]">
                        COHORT DRILLDOWN: <strong className="text-white">{selectedVintage.vintageCohort}</strong>
                      </span>
                      <span className="text-[#8b949e]">
                        Current Principal: <strong className="text-[#3fb950]">£{(selectedVintage.currentBalanceGBP / 1000000).toFixed(1)}m</strong>
                      </span>
                    </div>

                    <div className="space-y-1.5 font-mono text-[11px]">
                      <div>
                        <div className="flex justify-between text-[10px] text-[#8b949e] mb-0.5">
                          <span>Cumulative Loss Curve</span>
                          <span className="text-[#d29922]">{selectedVintage.cumulativeLossPct}% of Origination</span>
                        </div>
                        <div className="w-full bg-[#161b22] h-2">
                          <div 
                            className="bg-[#d29922] h-2" 
                            style={{ width: `${Math.min(100, selectedVintage.cumulativeLossPct * 15)}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[10px] text-[#8b949e] mb-0.5">
                          <span>Prepayment Rate (Annualised CPR)</span>
                          <span className="text-[#3fb950]">{selectedVintage.prepaymentCprPct}%</span>
                        </div>
                        <div className="w-full bg-[#161b22] h-2">
                          <div 
                            className="bg-[#3fb950] h-2" 
                            style={{ width: `${Math.min(100, selectedVintage.prepaymentCprPct * 8)}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'DELINQUENCY' && (
                <div className="space-y-3 font-mono text-xs">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <div className="bg-[#0b0e14] border border-[#21262d] p-2.5">
                      <div className="text-[10px] text-[#8b949e]">CURRENT (0 DPD)</div>
                      <div className="text-base font-bold text-[#3fb950] mt-1">96.82%</div>
                      <div className="text-[10px] text-[#8b949e] mt-0.5">£2,343m performing</div>
                    </div>
                    <div className="bg-[#0b0e14] border border-[#21262d] p-2.5">
                      <div className="text-[10px] text-[#8b949e]">1-30 DPD (EARLY)</div>
                      <div className="text-base font-bold text-[#d29922] mt-1">1.94%</div>
                      <div className="text-[10px] text-[#8b949e] mt-0.5">£46.9m balance</div>
                    </div>
                    <div className="bg-[#0b0e14] border border-[#21262d] p-2.5">
                      <div className="text-[10px] text-[#8b949e]">31-60 DPD (MID)</div>
                      <div className="text-base font-bold text-[#f85149] mt-1">0.78%</div>
                      <div className="text-[10px] text-[#8b949e] mt-0.5">£18.9m balance</div>
                    </div>
                    <div className="bg-[#0b0e14] border border-[#21262d] p-2.5">
                      <div className="text-[10px] text-[#8b949e]">60+ DPD & DEFAULT</div>
                      <div className="text-base font-bold text-[#f85149] mt-1">0.46%</div>
                      <div className="text-[10px] text-[#8b949e] mt-0.5">£11.1m in legal/repo</div>
                    </div>
                  </div>
                  <div className="p-3 bg-[#0b0e14] border border-[#21262d] flex justify-between items-center">
                    <div>
                      <div className="text-white font-medium">Delinquency Transition Matrices & Cure Rates</div>
                      <div className="text-[#8b949e] text-[11px]">Track roll rates from 1-30 to default or cure back to performing.</div>
                    </div>
                    <button
                      onClick={() => onNavigate('RISK')}
                      className="px-3 py-1.5 bg-[#21262d] hover:bg-[#30363d] text-white border border-[#30363d] font-mono text-xs"
                    >
                      VIEW TRANSITION MATRIX &rarr;
                    </button>
                  </div>
                </div>
              )}

              {activeTab === 'LOSSES' && (
                <div className="space-y-3 font-mono text-xs">
                  <div className="grid grid-cols-3 gap-2">
                    <div className="bg-[#0b0e14] border border-[#21262d] p-3">
                      <div className="text-[10px] text-[#8b949e]">CUMULATIVE GROSS DEFAULTS</div>
                      <div className="text-lg font-bold text-[#f85149] mt-1">£68.4m</div>
                      <div className="text-[10px] text-[#8b949e]">2.13% of original book</div>
                    </div>
                    <div className="bg-[#0b0e14] border border-[#21262d] p-3">
                      <div className="text-[10px] text-[#8b949e]">COLLATERAL RECOVERIES</div>
                      <div className="text-lg font-bold text-[#3fb950] mt-1">£43.6m</div>
                      <div className="text-[10px] text-[#8b949e]">63.7% net recovery rate</div>
                    </div>
                    <div className="bg-[#0b0e14] border border-[#21262d] p-3">
                      <div className="text-[10px] text-[#8b949e]">NET CUMULATIVE LOSS</div>
                      <div className="text-lg font-bold text-[#d29922] mt-1">£24.8m</div>
                      <div className="text-[10px] text-[#8b949e]">0.77% net loss rate</div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'RESIDUALS' && (
                <div className="space-y-2 font-mono text-xs">
                  <div className="bg-[#0b0e14] border border-[#21262d] p-3 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-white font-medium">Powertrain Residual Retention @ 36 Months</span>
                      <span className="text-[10px] text-[#8b949e]">Benchmark: 10k miles/yr</span>
                    </div>
                    <div className="space-y-1.5 text-[11px]">
                      <div className="flex justify-between">
                        <span className="text-[#8b949e]">Hybrid (HEV)</span>
                        <span className="text-[#3fb950]">59.2% retained (+3.2% vs baseline)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#8b949e]">Internal Combustion (ICE Euro 6d)</span>
                        <span className="text-white">56.4% retained (baseline)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#8b949e]">Plug-in Hybrid (PHEV)</span>
                        <span className="text-white">54.1% retained (-2.3% vs baseline)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#8b949e]">Battery Electric (BEV)</span>
                        <span className="text-[#f85149] font-bold">48.2% retained (-8.2% vs baseline)</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Quick Terminal Flow Drill Links */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <button
              onClick={() => onNavigate('ABS')}
              className="bg-[#11151c] hover:bg-[#161b22] border border-[#21262d] p-3 text-left transition-colors flex items-center justify-between"
            >
              <div>
                <div className="font-mono text-xs font-bold text-[#d29922]">ABS SECURITISATION</div>
                <div className="text-[11px] text-[#8b949e]">Model tranches & waterfall cash flows</div>
              </div>
              <ArrowRight className="w-4 h-4 text-[#8b949e]" />
            </button>

            <button
              onClick={() => onNavigate('STRESS')}
              className="bg-[#11151c] hover:bg-[#161b22] border border-[#21262d] p-3 text-left transition-colors flex items-center justify-between"
            >
              <div>
                <div className="font-mono text-xs font-bold text-[#f85149]">STRESS WORKBENCH</div>
                <div className="text-[11px] text-[#8b949e]">Test BEV residual shocks & recessions</div>
              </div>
              <ArrowRight className="w-4 h-4 text-[#8b949e]" />
            </button>

            <button
              onClick={() => onNavigate('REDRESS')}
              className="bg-[#11151c] hover:bg-[#161b22] border border-[#21262d] p-3 text-left transition-colors flex items-center justify-between"
            >
              <div>
                <div className="font-mono text-xs font-bold text-[#388bfd]">FCA MOTOR REDRESS</div>
                <div className="text-[11px] text-[#8b949e]">Historical DCA 2007-2024 calculation</div>
              </div>
              <ArrowRight className="w-4 h-4 text-[#8b949e]" />
            </button>
          </div>
        </div>

        {/* Right Column (4 of 12 cols): Institutional Risk Alerts & System Status */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-[#11151c] border border-[#21262d]">
            <div className="flex items-center justify-between px-3 py-2 border-b border-[#21262d] bg-[#0b0e14]">
              <div className="flex items-center space-x-2">
                <ShieldAlert className="w-4 h-4 text-[#d29922]" />
                <span className="font-mono text-xs font-bold text-white tracking-wide">
                  ACTIVE RISK ALERTS
                </span>
              </div>
              <span className="text-[10px] bg-[#161b22] border border-[#30363d] px-1.5 py-0.2 text-[#d29922] font-mono">
                3 UNRESOLVED
              </span>
            </div>

            <div className="p-3 space-y-3 font-mono text-xs">
              {/* Alert 1: BEV Residual Deterioration */}
              <div 
                onClick={() => onNavigate('STRESS')}
                className="bg-[#0b0e14] border-l-2 border-[#f85149] border-t border-r border-b border-[#21262d] p-2.5 space-y-1 cursor-pointer hover:bg-[#161b22] transition-colors"
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-[#f85149] flex items-center">
                    <AlertTriangle className="w-3 h-3 mr-1" />
                    BEV RESIDUAL DETERIORATION
                  </span>
                  <span className="text-[10px] text-[#8b949e]">CRITICAL</span>
                </div>
                <p className="text-[11px] text-[#c9d1d9] font-sans">
                  Secondary wholesale auction realizations for Battery Electric Vehicles (BEVs) are trailing contract GFV by <strong>8.2%</strong>. LGD buffer eroding on 2023-Q4/2024-Q1 PCP cohorts.
                </p>
                <div className="flex justify-between items-center text-[10px] text-[#8b949e] pt-1">
                  <span>Exposure: £518m (21.4%)</span>
                  <span className="text-[#388bfd] hover:underline">STRESS MODEL &rarr;</span>
                </div>
              </div>

              {/* Alert 2: Dealer 482 elevated default rate */}
              <div 
                onClick={() => onNavigate('DEALER')}
                className="bg-[#0b0e14] border-l-2 border-[#d29922] border-t border-r border-b border-[#21262d] p-2.5 space-y-1 cursor-pointer hover:bg-[#161b22] transition-colors"
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-[#d29922]">
                    DEALER 482: DEFAULT ELEVATED
                  </span>
                  <span className="text-[10px] text-[#8b949e]">WATCHLIST</span>
                </div>
                <p className="text-[11px] text-[#c9d1d9] font-sans">
                  Apex Motor Group (North West) 12M rolling default rate escalated to <strong>4.8%</strong> vs network benchmark of 2.9%. Four anomaly fraud flags triggered in broker documentation.
                </p>
                <div className="flex justify-between items-center text-[10px] text-[#8b949e] pt-1">
                  <span>Originations: £42.8m</span>
                  <span className="text-[#388bfd] hover:underline">DEALER AUDIT &rarr;</span>
                </div>
              </div>

              {/* Alert 3: 2024 Q4 30+ DPD above baseline */}
              <div 
                onClick={() => onNavigate('PORT')}
                className="bg-[#0b0e14] border-l-2 border-[#388bfd] border-t border-r border-b border-[#21262d] p-2.5 space-y-1 cursor-pointer hover:bg-[#161b22] transition-colors"
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-[#388bfd]">
                    2024 Q4: 30+ DPD ABOVE BASELINE
                  </span>
                  <span className="text-[10px] text-[#8b949e]">MONITOR</span>
                </div>
                <p className="text-[11px] text-[#c9d1d9] font-sans">
                  30+ Days Past Due for the 2024-Q4 vintage reached <strong>2.9%</strong>, +45bp above expected seasoning curve at month 10.
                </p>
                <div className="flex justify-between items-center text-[10px] text-[#8b949e] pt-1">
                  <span>Balance: £394m</span>
                  <span className="text-[#388bfd] hover:underline">VINTAGE DRILL &rarr;</span>
                </div>
              </div>
            </div>
          </div>

          {/* System & Architecture Ledger Status */}
          <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-2 font-mono text-[11px]">
            <div className="text-[#8b949e] text-[10px] uppercase font-bold tracking-wider">
              SYSTEM ENGINE STATUS
            </div>
            <div className="space-y-1 divide-y divide-[#161b22]">
              <div className="flex justify-between py-1">
                <span className="text-[#8b949e]">Quantitative Engine:</span>
                <span className="text-[#3fb950]">ONLINE (Python 3.12 / Polars)</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#8b949e]">Cash Flow Vector Engine:</span>
                <span className="text-[#3fb950]">ONLINE (Deterministic Rust Core)</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#8b949e]">Statistical Validation:</span>
                <span className="text-[#3fb950]">ONLINE (R rugarch / survival)</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#8b949e]">Abs Waterfall Protocol:</span>
                <span className="text-white">v1.8.4 (Active)</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#8b949e]">Regulatory Framework:</span>
                <span className="text-[#d29922]">FCA-DCA-2026.2 (Configurable)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
