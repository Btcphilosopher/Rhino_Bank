/**
 * RhinoQuant Auto Finance
 * Institutional Multi-Dimensional Portfolio Engine (PORT <GO>)
 */

import React, { useState, useMemo } from 'react';
import {
  Filter,
  Download,
  ArrowUpDown,
  Search,
  ExternalLink,
  ChevronRight,
  Database,
  Layers,
  PieChart,
} from 'lucide-react';
import { FinanceProduct, FuelType, Loan, RiskGrade } from '../../types/finance';
import { generateSampleLoanPopulation, SYNTHETIC_PORTFOLIO_METRICS } from '../../data/syntheticPortfolio';
import { LoanDetailModal } from './LoanDetailModal';

export const PortfolioAnalyticsView: React.FC = () => {
  const allLoans = useMemo(() => generateSampleLoanPopulation(), []);

  // Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<string>('ALL');
  const [selectedFuel, setSelectedFuel] = useState<string>('ALL');
  const [selectedGrade, setSelectedGrade] = useState<string>('ALL');
  const [selectedVintage, setSelectedVintage] = useState<string>('ALL');
  const [sortField, setSortField] = useState<keyof Loan>('currentOutstandingBalance');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  // Selected Loan for Modal Drilldown
  const [activeDrillLoan, setActiveDrillLoan] = useState<Loan | null>(null);

  // Aggregation View Mode
  const [viewMode, setViewMode] = useState<'LOAN_BOOK' | 'CONCENTRATIONS'>('LOAN_BOOK');

  // Filtering Logic
  const filteredLoans = useMemo(() => {
    return allLoans.filter((loan) => {
      if (selectedProduct !== 'ALL' && loan.productType !== selectedProduct) return false;
      if (selectedFuel !== 'ALL' && loan.vehicle.fuelType !== selectedFuel) return false;
      if (selectedGrade !== 'ALL' && loan.customerRiskGrade !== selectedGrade) return false;
      if (selectedVintage !== 'ALL' && loan.vintageCohort !== selectedVintage) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match =
          loan.id.toLowerCase().includes(q) ||
          loan.agreementNumber.toLowerCase().includes(q) ||
          loan.customerName.toLowerCase().includes(q) ||
          loan.dealerName.toLowerCase().includes(q) ||
          loan.vehicle.make.toLowerCase().includes(q) ||
          loan.vehicle.model.toLowerCase().includes(q);
        if (!match) return false;
      }

      return true;
    });
  }, [allLoans, selectedProduct, selectedFuel, selectedGrade, selectedVintage, searchQuery]);

  // Sorting
  const sortedLoans = useMemo(() => {
    return [...filteredLoans].sort((a, b) => {
      let aVal = a[sortField];
      let bVal = b[sortField];

      if (typeof aVal === 'string') {
        return sortDirection === 'asc'
          ? (aVal as string).localeCompare(bVal as string)
          : (bVal as string).localeCompare(aVal as string);
      }

      const numA = Number(aVal) || 0;
      const numB = Number(bVal) || 0;
      return sortDirection === 'asc' ? numA - numB : numB - numA;
    });
  }, [filteredLoans, sortField, sortDirection]);

  const handleSort = (field: keyof Loan) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const exportCSV = () => {
    const headers = ['Loan_ID', 'Agreement', 'Grade', 'Customer', 'Product', 'Vehicle', 'Fuel', 'Balance', 'APR', 'LTV', 'DPD', 'PD_12M', 'LGD', 'EL'];
    const rows = sortedLoans.map((l) => [
      l.id,
      l.agreementNumber,
      l.customerRiskGrade,
      `"${l.customerName}"`,
      l.productType,
      `"${l.vehicle.make} ${l.vehicle.model}"`,
      l.vehicle.fuelType,
      l.currentOutstandingBalance,
      l.customerAPR,
      l.ltvCurrent,
      l.daysPastDue,
      l.pd12m,
      l.lgd,
      l.expectedLoss,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `RQA_PORTFOLIO_EXTRACT_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-4 space-y-4 max-w-[1600px] mx-auto text-xs font-sans">
      {/* Header Banner & Portfolio Dimensions Strip */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#21262d]">
        <div>
          <h1 className="font-mono text-sm font-bold text-white flex items-center space-x-2">
            <span>PORTFOLIO ANALYTICS & LOAN BOOK ENGINE</span>
            <span className="text-[10px] bg-[#161b22] border border-[#30363d] px-1.5 py-0.5 text-[#d29922]">
              PORT &lt;GO&gt;
            </span>
          </h1>
          <p className="text-[#8b949e] text-[11px]">
            Active portfolio aggregation across £2.42bn receivables, 184,291 contracts, and multi-dimensional risk vectors.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <div className="flex items-center space-x-1 bg-[#11151c] border border-[#21262d] p-0.5">
            <button
              onClick={() => setViewMode('LOAN_BOOK')}
              className={`px-2.5 py-1 text-[11px] font-mono transition-colors ${
                viewMode === 'LOAN_BOOK' ? 'bg-[#1f2937] text-white font-bold' : 'text-[#8b949e] hover:text-white'
              }`}
            >
              LOAN BOOK (TABLE)
            </button>
            <button
              onClick={() => setViewMode('CONCENTRATIONS')}
              className={`px-2.5 py-1 text-[11px] font-mono transition-colors ${
                viewMode === 'CONCENTRATIONS' ? 'bg-[#1f2937] text-white font-bold' : 'text-[#8b949e] hover:text-white'
              }`}
            >
              CONCENTRATION LIMITS
            </button>
          </div>

          <button
            onClick={exportCSV}
            className="flex items-center space-x-1.5 bg-[#161b22] hover:bg-[#21262d] text-white border border-[#30363d] px-2.5 py-1 font-mono text-[11px] transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-[#d29922]" />
            <span>EXPORT CSV</span>
          </button>
        </div>
      </div>

      {viewMode === 'CONCENTRATIONS' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Concentration 1: Powertrain / Fuel */}
          <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-2 font-mono text-[11px]">
            <div className="text-white font-bold border-b border-[#21262d] pb-1 flex justify-between">
              <span>POWERTRAIN CONCENTRATION</span>
              <span className="text-[#3fb950]">LIMITS OK</span>
            </div>
            <div className="space-y-1.5 pt-1">
              <div>
                <div className="flex justify-between text-[#8b949e]">
                  <span>BEV (Battery Electric):</span>
                  <span className="text-[#d29922] font-bold">21.4% (Max 25.0%)</span>
                </div>
                <div className="w-full bg-[#161b22] h-1.5 mt-0.5">
                  <div className="bg-[#d29922] h-1.5" style={{ width: '85.6%' }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-[#8b949e]">
                  <span>ICE (Euro 6d Petrol/Diesel):</span>
                  <span className="text-white">48.2%</span>
                </div>
                <div className="w-full bg-[#161b22] h-1.5 mt-0.5">
                  <div className="bg-[#388bfd] h-1.5" style={{ width: '48.2%' }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-[#8b949e]">
                  <span>Hybrid & PHEV:</span>
                  <span className="text-white">30.4%</span>
                </div>
                <div className="w-full bg-[#161b22] h-1.5 mt-0.5">
                  <div className="bg-[#3fb950] h-1.5" style={{ width: '30.4%' }} />
                </div>
              </div>
            </div>
          </div>

          {/* Concentration 2: Risk Grade Distribution */}
          <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-2 font-mono text-[11px]">
            <div className="text-white font-bold border-b border-[#21262d] pb-1 flex justify-between">
              <span>CREDIT GRADE ALLOCATION</span>
              <span className="text-[#8b949e]">PRIME 82%</span>
            </div>
            <div className="space-y-1.5 pt-1">
              <div className="flex justify-between">
                <span className="text-[#3fb950]">Grade A (Super Prime):</span>
                <span className="text-white">34.5% (£835m)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#388bfd]">Grade B (Prime):</span>
                <span className="text-white">36.2% (£876m)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#d29922]">Grade C (Near Prime):</span>
                <span className="text-white">18.5% (£448m)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#f85149]">Grade D (Non-Standard):</span>
                <span className="text-[#f85149]">7.4% (£179m)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#f85149]">Grade E (Subprime / Limit 5%):</span>
                <span className="text-[#f85149] font-bold">3.4% (£82m)</span>
              </div>
            </div>
          </div>

          {/* Concentration 3: Product Mix */}
          <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-2 font-mono text-[11px]">
            <div className="text-white font-bold border-b border-[#21262d] pb-1 flex justify-between">
              <span>FINANCE PRODUCT MIX</span>
              <span className="text-[#8b949e]">PCP HEAVY</span>
            </div>
            <div className="space-y-1.5 pt-1">
              <div className="flex justify-between">
                <span className="text-white">Personal Contract Purchase (PCP):</span>
                <span className="text-[#d29922] font-bold">68.4% (£1,655m)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white">Hire Purchase (HP):</span>
                <span className="text-white">21.8% (£527m)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white">Commercial Fleet Lease:</span>
                <span className="text-white">5.8% (£140m)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white">Balloon Loan:</span>
                <span className="text-white">4.0% (£98m)</span>
              </div>
            </div>
          </div>

          {/* Concentration 4: Geographical Distribution */}
          <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-2 font-mono text-[11px]">
            <div className="text-white font-bold border-b border-[#21262d] pb-1 flex justify-between">
              <span>REGIONAL EXPOSURE (UK)</span>
              <span className="text-[#8b949e]">BALANCED</span>
            </div>
            <div className="space-y-1.5 pt-1">
              <div className="flex justify-between">
                <span className="text-white">Greater London & South East:</span>
                <span className="text-white">28.5%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white">Midlands:</span>
                <span className="text-white">21.2%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white">North West:</span>
                <span className="text-white">18.6%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white">Yorkshire & North East:</span>
                <span className="text-white">14.1%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white">Scotland, Wales & NI:</span>
                <span className="text-white">17.6%</span>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {/* Filter Control Bar */}
      <div className="bg-[#11151c] border border-[#21262d] p-2.5 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-2 font-mono text-[11px]">
          {/* Search Box */}
          <div className="relative flex items-center bg-[#0b0e14] border border-[#30363d] px-2 py-1">
            <Search className="w-3.5 h-3.5 text-[#8b949e] mr-1.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter by ID, Customer, VIN, Make..."
              className="bg-transparent text-white focus:outline-none w-48 text-[11px] placeholder:text-[#484f58]"
            />
          </div>

          {/* Product Filter */}
          <div className="flex items-center space-x-1">
            <span className="text-[#8b949e]">Product:</span>
            <select
              value={selectedProduct}
              onChange={(e) => setSelectedProduct(e.target.value)}
              className="bg-[#0b0e14] border border-[#30363d] text-white px-1.5 py-1 focus:outline-none"
            >
              <option value="ALL">ALL PRODUCTS</option>
              <option value="PCP">PCP</option>
              <option value="HP">HP</option>
              <option value="Balloon Loan">Balloon Loan</option>
              <option value="Lease">Lease</option>
            </select>
          </div>

          {/* Fuel Filter */}
          <div className="flex items-center space-x-1">
            <span className="text-[#8b949e]">Powertrain:</span>
            <select
              value={selectedFuel}
              onChange={(e) => setSelectedFuel(e.target.value)}
              className="bg-[#0b0e14] border border-[#30363d] text-white px-1.5 py-1 focus:outline-none"
            >
              <option value="ALL">ALL FUELS</option>
              <option value="BEV">BEV (Electric)</option>
              <option value="Hybrid">Hybrid (HEV)</option>
              <option value="PHEV">PHEV</option>
              <option value="ICE">ICE (Petrol/Diesel)</option>
            </select>
          </div>

          {/* Grade Filter */}
          <div className="flex items-center space-x-1">
            <span className="text-[#8b949e]">Grade:</span>
            <select
              value={selectedGrade}
              onChange={(e) => setSelectedGrade(e.target.value)}
              className="bg-[#0b0e14] border border-[#30363d] text-white px-1.5 py-1 focus:outline-none"
            >
              <option value="ALL">ALL GRADES</option>
              <option value="A">Grade A</option>
              <option value="B">Grade B</option>
              <option value="C">Grade C</option>
              <option value="D">Grade D</option>
              <option value="E">Grade E</option>
            </select>
          </div>

          {/* Vintage Filter */}
          <div className="flex items-center space-x-1">
            <span className="text-[#8b949e]">Cohort:</span>
            <select
              value={selectedVintage}
              onChange={(e) => setSelectedVintage(e.target.value)}
              className="bg-[#0b0e14] border border-[#30363d] text-white px-1.5 py-1 focus:outline-none"
            >
              <option value="ALL">ALL VINTAGES</option>
              <option value="2024-Q4">2024-Q4</option>
              <option value="2024-Q3">2024-Q3</option>
              <option value="2024-Q2">2024-Q2</option>
              <option value="2024-Q1">2024-Q1</option>
              <option value="2023-Q4">2023-Q4</option>
            </select>
          </div>
        </div>

        <div className="text-[11px] font-mono text-[#8b949e]">
          Showing <strong className="text-white">{sortedLoans.length}</strong> of {allLoans.length} sampled loans
        </div>
      </div>

      {/* High Density Institutional Loan Table */}
      <div className="bg-[#11151c] border border-[#21262d] overflow-x-auto">
        <table className="w-full text-left font-mono text-[11px] table-dense divide-y divide-[#21262d]">
          <thead>
            <tr className="text-[#8b949e] bg-[#0b0e14] whitespace-nowrap">
              <th className="py-2 cursor-pointer hover:text-white" onClick={() => handleSort('id')}>
                LOAN ID / AGR #
              </th>
              <th className="cursor-pointer hover:text-white" onClick={() => handleSort('customerRiskGrade')}>
                GRADE
              </th>
              <th>CUSTOMER</th>
              <th className="cursor-pointer hover:text-white" onClick={() => handleSort('productType')}>
                PRODUCT
              </th>
              <th>VEHICLE COLLATERAL</th>
              <th>FUEL</th>
              <th className="text-right cursor-pointer hover:text-white" onClick={() => handleSort('currentOutstandingBalance')}>
                OUTSTANDING BAL
              </th>
              <th className="text-right cursor-pointer hover:text-white" onClick={() => handleSort('customerAPR')}>
                APR
              </th>
              <th className="text-right cursor-pointer hover:text-white" onClick={() => handleSort('ltvCurrent')}>
                CURR LTV
              </th>
              <th className="text-right cursor-pointer hover:text-white" onClick={() => handleSort('daysPastDue')}>
                DPD
              </th>
              <th className="text-right cursor-pointer hover:text-white" onClick={() => handleSort('pd12m')}>
                12M PD
              </th>
              <th className="text-right cursor-pointer hover:text-white" onClick={() => handleSort('lgd')}>
                LGD
              </th>
              <th className="text-right cursor-pointer hover:text-white" onClick={() => handleSort('expectedLoss')}>
                EXPECTED LOSS
              </th>
              <th className="text-center">ACTION</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#161b22]">
            {sortedLoans.map((l) => {
              return (
                <tr
                  key={l.id}
                  onClick={() => setActiveDrillLoan(l)}
                  className="hover:bg-[#1c2128] cursor-pointer transition-colors text-[#c9d1d9] whitespace-nowrap"
                >
                  <td className="py-2 font-bold text-[#d29922]">
                    <div>{l.id}</div>
                    <div className="text-[10px] text-[#8b949e]">{l.agreementNumber}</div>
                  </td>
                  <td>
                    <span className={`px-1.5 py-0.2 text-[10px] font-bold border ${
                      l.customerRiskGrade === 'A' ? 'bg-[#3fb950]/20 text-[#3fb950] border-[#3fb950]' :
                      l.customerRiskGrade === 'B' ? 'bg-[#388bfd]/20 text-[#388bfd] border-[#388bfd]' :
                      l.customerRiskGrade === 'C' ? 'bg-[#d29922]/20 text-[#d29922] border-[#d29922]' :
                      'bg-[#f85149]/20 text-[#f85149] border-[#f85149]'
                    }`}>
                      {l.customerRiskGrade}
                    </span>
                  </td>
                  <td>
                    <div className="text-white font-medium">{l.customerName}</div>
                    <div className="text-[10px] text-[#8b949e]">{l.customerId}</div>
                  </td>
                  <td className="font-bold text-white">{l.productType}</td>
                  <td>
                    <div className="text-white">{l.vehicle.make} {l.vehicle.model}</div>
                    <div className="text-[10px] text-[#8b949e]">{l.vehicle.year} · {l.vehicle.mileage.toLocaleString()} mi</div>
                  </td>
                  <td>
                    <span className={l.vehicle.fuelType === 'BEV' ? 'text-[#388bfd]' : 'text-[#8b949e]'}>
                      {l.vehicle.fuelType}
                    </span>
                  </td>
                  <td className="text-right font-mono-numbers text-white font-bold">
                    £{l.currentOutstandingBalance.toLocaleString()}
                  </td>
                  <td className="text-right font-mono-numbers">{l.customerAPR.toFixed(1)}%</td>
                  <td className={`text-right font-mono-numbers ${l.ltvCurrent > 90 ? 'text-[#f85149] font-bold' : ''}`}>
                    {l.ltvCurrent.toFixed(1)}%
                  </td>
                  <td className={`text-right font-mono-numbers ${l.daysPastDue > 0 ? 'text-[#f85149] font-bold' : 'text-[#3fb950]'}`}>
                    {l.daysPastDue === 0 ? '0 (OK)' : `${l.daysPastDue}d`}
                  </td>
                  <td className="text-right font-mono-numbers">{(l.pd12m * 100).toFixed(1)}%</td>
                  <td className="text-right font-mono-numbers">{(l.lgd * 100).toFixed(1)}%</td>
                  <td className="text-right font-mono-numbers text-[#d29922] font-bold">
                    £{l.expectedLoss.toLocaleString()}
                  </td>
                  <td className="text-center">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveDrillLoan(l);
                      }}
                      className="text-[#388bfd] hover:underline text-[10px]"
                    >
                      CASH FLOWS &rarr;
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Drilldown Modal */}
      <LoanDetailModal loan={activeDrillLoan} onClose={() => setActiveDrillLoan(null)} />
    </div>
  );
};
