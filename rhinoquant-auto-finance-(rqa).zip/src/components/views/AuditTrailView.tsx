/**
 * RhinoQuant Auto Finance
 * Institutional Immutable Audit Trail & Parameter Log (AUDIT <GO>)
 */

import React, { useState } from 'react';
import {
  FileText,
  Clock,
  Search,
  Filter,
  CheckCircle,
  Database,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { SYNTHETIC_AUDIT_TRAIL } from '../../data/syntheticPortfolio';
import { AuditRecord } from '../../types/finance';

export const AuditTrailView: React.FC = () => {
  const [auditLogs, setAuditLogs] = useState<AuditRecord[]>(SYNTHETIC_AUDIT_TRAIL);
  const [filterQuery, setFilterQuery] = useState('');

  const filteredLogs = auditLogs.filter((log) => {
    if (!filterQuery) return true;
    const q = filterQuery.toLowerCase();
    return (
      log.analyst.toLowerCase().includes(q) ||
      log.action.toLowerCase().includes(q) ||
      log.object.toLowerCase().includes(q) ||
      log.reason.toLowerCase().includes(q)
    );
  });

  return (
    <div className="p-4 space-y-4 max-w-[1600px] mx-auto text-xs font-sans">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#21262d]">
        <div>
          <h1 className="font-mono text-sm font-bold text-white flex items-center space-x-2">
            <span>IMMUTABLE QUANTITATIVE AUDIT TRAIL & PARAMETER LOG</span>
            <span className="text-[10px] bg-[#161b22] border border-[#30363d] px-1.5 py-0.5 text-[#d29922]">
              AUDIT &lt;GO&gt;
            </span>
          </h1>
          <p className="text-[#8b949e] text-[11px]">
            Append-only tamper-evident ledger recording all parameter adjustments, model promotions, and market curve shifts.
          </p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-[11px]">
          <div>Ledger Hash: <strong className="text-white">SHA256:8f41...2e91</strong></div>
          <div>Audit Status: <strong className="text-[#3fb950]">UNCOMPROMISED</strong></div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-[#11151c] border border-[#21262d] p-2.5 flex items-center justify-between">
        <div className="flex items-center space-x-2 font-mono text-[11px]">
          <Search className="w-3.5 h-3.5 text-[#8b949e]" />
          <input
            type="text"
            value={filterQuery}
            onChange={(e) => setFilterQuery(e.target.value)}
            placeholder="Search audit trail by analyst, object, action, reason..."
            className="bg-[#0b0e14] border border-[#30363d] text-white px-2 py-1 w-72 focus:outline-none"
          />
        </div>

        <div className="text-[11px] font-mono text-[#8b949e]">
          Showing {filteredLogs.length} audit records
        </div>
      </div>

      {/* Audit Ledger Table */}
      <div className="bg-[#11151c] border border-[#21262d] overflow-x-auto">
        <table className="w-full text-left font-mono text-[11px] table-dense divide-y divide-[#21262d]">
          <thead>
            <tr className="text-[#8b949e] bg-[#0b0e14]">
              <th className="py-2">AUDIT ID & TIME</th>
              <th>ANALYST & ROLE</th>
              <th>ACTION TYPE</th>
              <th>TARGET OBJECT</th>
              <th>PREVIOUS VALUE</th>
              <th>NEW VALUE</th>
              <th>BUSINESS RATIONALE</th>
              <th className="text-right">MODEL VER</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#161b22]">
            {filteredLogs.map((log) => {
              return (
                <tr key={log.id} className="hover:bg-[#161b22] text-[#c9d1d9]">
                  <td className="py-2 font-bold text-white">
                    <div>{log.id}</div>
                    <div className="text-[10px] text-[#8b949e]">{log.timestamp}</div>
                  </td>
                  <td>
                    <div className="text-white font-medium">{log.analyst}</div>
                    <div className="text-[10px] text-[#8b949e]">{log.role}</div>
                  </td>
                  <td>
                    <span className="bg-[#0b0e14] px-1.5 py-0.2 border border-[#30363d] text-[10px] text-[#d29922] font-bold">
                      {log.action}
                    </span>
                  </td>
                  <td className="font-bold text-white">{log.object}</td>
                  <td className="text-[#f85149]">{log.oldValue}</td>
                  <td className="text-[#3fb950] font-bold">{log.newValue}</td>
                  <td className="text-[#c9d1d9] font-sans text-xs max-w-xs">{log.reason}</td>
                  <td className="text-right font-bold text-[#8b949e]">{log.modelVersion}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
