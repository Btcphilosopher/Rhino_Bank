/**
 * RhinoQuant Auto Finance
 * Loan-Level Contract Drilldown & Cash Flow Schedule Modal (LOAN <GO>)
 */

import React from 'react';
import { X, ShieldAlert, ArrowDown, FileText, CheckCircle, Car } from 'lucide-react';
import { Loan } from '../../types/finance';

interface LoanDetailModalProps {
  loan: Loan | null;
  onClose: () => void;
}

export const LoanDetailModal: React.FC<LoanDetailModalProps> = ({ loan, onClose }) => {
  if (!loan) return null;

  const v = loan.vehicle;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
      <div className="w-full max-w-5xl bg-[#11151c] border border-[#30363d] shadow-2xl flex flex-col max-h-[90vh] text-xs font-sans">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-[#21262d] bg-[#0b0e14]">
          <div className="flex items-center space-x-3">
            <span className="font-mono text-xs font-bold text-[#d29922] bg-[#161b22] px-2 py-0.5 border border-[#30363d]">
              {loan.id}
            </span>
            <span className="font-mono text-sm text-white font-semibold">
              AGREEMENT {loan.agreementNumber}
            </span>
            <span className="text-[10px] text-[#8b949e] font-mono">
              COHORT: {loan.vintageCohort}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <span className={`px-2 py-0.5 font-mono text-[10px] font-bold border ${
              loan.status === 'ACTIVE' ? 'bg-[#3fb950]/20 text-[#3fb950] border-[#3fb950]' :
              loan.status === 'PAST_DUE' ? 'bg-[#d29922]/20 text-[#d29922] border-[#d29922]' :
              loan.status === 'DELINQUENT' ? 'bg-[#f85149]/20 text-[#f85149] border-[#f85149]' :
              'bg-[#161b22] text-[#8b949e] border-[#30363d]'
            }`}>
              {loan.status} ({loan.delinquencyBucket})
            </span>
            <button onClick={onClose} className="text-[#8b949e] hover:text-white p-1">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Top Details Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-4 bg-[#0b0e14] border-b border-[#21262d] font-mono text-[11px]">
          <div>
            <div className="text-[10px] text-[#8b949e]">CUSTOMER</div>
            <div className="text-white font-bold text-xs mt-0.5">{loan.customerName}</div>
            <div className="text-[#8b949e] text-[10px]">Grade {loan.customerRiskGrade} · {loan.customerId}</div>
          </div>

          <div>
            <div className="text-[10px] text-[#8b949e]">VEHICLE COLLATERAL</div>
            <div className="text-white font-bold text-xs mt-0.5">{v.make} {v.model} ({v.year})</div>
            <div className="text-[#8b949e] text-[10px]">{v.fuelType} · {v.mileage.toLocaleString()} mi · VIN {v.vin.substring(0, 10)}...</div>
          </div>

          <div>
            <div className="text-[10px] text-[#8b949e]">FINANCIAL TERMS</div>
            <div className="text-white font-bold text-xs mt-0.5">£{loan.currentOutstandingBalance.toLocaleString()} / £{loan.originalPrincipal.toLocaleString()}</div>
            <div className="text-[#8b949e] text-[10px]">{loan.productType} · APR {loan.customerAPR}% · Seasoning {loan.seasoningMonths}m</div>
          </div>

          <div>
            <div className="text-[10px] text-[#8b949e]">CREDIT RISK (12M)</div>
            <div className="text-[#d29922] font-bold text-xs mt-0.5">EL: £{loan.expectedLoss.toLocaleString()}</div>
            <div className="text-[#8b949e] text-[10px]">PD: {(loan.pd12m * 100).toFixed(1)}% · LGD: {(loan.lgd * 100).toFixed(1)}%</div>
          </div>
        </div>

        {/* Cash Flow Schedule Table */}
        <div className="p-4 overflow-y-auto space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs font-bold text-white tracking-wide">
              CONTRACTUAL & BEHAVIOURAL CASH FLOW SCHEDULE
            </span>
            <span className="text-[10px] text-[#8b949e] font-mono">
              Voluntary Termination (s.99 CCA): Month {Math.round(loan.termMonths * 0.65)} threshold
            </span>
          </div>

          <div className="overflow-x-auto border border-[#21262d]">
            <table className="w-full text-left font-mono text-[11px] table-dense divide-y divide-[#21262d]">
              <thead>
                <tr className="text-[#8b949e] bg-[#0b0e14]">
                  <th className="py-2">PERIOD</th>
                  <th className="text-right">OPENING BAL</th>
                  <th className="text-right">PRINCIPAL</th>
                  <th className="text-right">INTEREST</th>
                  <th className="text-right">PREPAYMENT</th>
                  <th className="text-right">TOTAL CASH</th>
                  <th className="text-right">CLOSING BAL</th>
                  <th className="text-right">EQUITY (MKT-BAL)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#161b22] bg-[#11151c]">
                {loan.cashFlowSchedule.map((p) => {
                  const isCurrentMonth = p.periodMonth === loan.seasoningMonths;
                  return (
                    <tr
                      key={p.periodMonth}
                      className={isCurrentMonth ? 'bg-[#1f2937] text-white font-bold' : 'hover:bg-[#161b22] text-[#c9d1d9]'}
                    >
                      <td className="py-1.5 font-bold">
                        {p.periodMonth} {isCurrentMonth && <span className="text-[#3fb950] text-[9px] ml-1">[CURRENT]</span>}
                      </td>
                      <td className="text-right font-mono-numbers">£{p.openingBalance.toLocaleString()}</td>
                      <td className="text-right font-mono-numbers text-white">£{p.scheduledPrincipal.toLocaleString()}</td>
                      <td className="text-right font-mono-numbers text-[#d29922]">£{p.scheduledInterest.toLocaleString()}</td>
                      <td className="text-right font-mono-numbers text-[#3fb950]">£{p.prepaymentPrincipal.toLocaleString()}</td>
                      <td className="text-right font-mono-numbers font-bold text-white">£{p.totalCashFlow.toLocaleString()}</td>
                      <td className="text-right font-mono-numbers">£{p.closingBalance.toLocaleString()}</td>
                      <td className={`text-right font-mono-numbers ${p.customerEquity >= 0 ? 'text-[#3fb950]' : 'text-[#f85149]'}`}>
                        {p.customerEquity >= 0 ? `+£${p.customerEquity.toLocaleString()}` : `-£${Math.abs(p.customerEquity).toLocaleString()}`}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-[#0b0e14] border-t border-[#21262d] font-mono text-[11px] text-[#8b949e]">
          <div>
            DEALER ORIGINATION: <strong className="text-white">{loan.dealerName} ({loan.dealerId})</strong>
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1 bg-[#21262d] hover:bg-[#30363d] text-white font-mono text-xs border border-[#30363d]"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
