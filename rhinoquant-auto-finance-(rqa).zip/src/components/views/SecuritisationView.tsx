/**
 * RhinoQuant Auto Finance
 * Institutional ABS Securitisation & Priority-of-Payments Waterfall Desk (ABS <GO> / WATERFALL <GO>)
 */

import React, { useState, useMemo } from 'react';
import {
  Layers,
  TrendingDown,
  ShieldAlert,
  ArrowRight,
  Database,
  BarChart3,
  Sliders,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';
import {
  buildDefaultAbsStructure,
  simulateWaterfallSchedule,
} from '../../engine/securitisation';

export const SecuritisationView: React.FC = () => {
  const [dealBalance, setDealBalance] = useState<number>(500000000); // £500m
  const [soniaRate, setSoniaRate] = useState<number>(4.25); // 4.25% SONIA
  const [stressScenario, setStressScenario] = useState<'BASE' | 'DEF_25' | 'DEF_50' | 'REC_DOWN_20' | 'BEV_SHOCK_20'>('BASE');

  const deal = useMemo(() => {
    return buildDefaultAbsStructure(dealBalance, soniaRate);
  }, [dealBalance, soniaRate]);

  const stressMultiplier = useMemo(() => {
    switch (stressScenario) {
      case 'BASE': return 1.0;
      case 'DEF_25': return 1.25;
      case 'DEF_50': return 1.50;
      case 'REC_DOWN_20': return 1.35;
      case 'BEV_SHOCK_20': return 1.45;
      default: return 1.0;
    }
  }, [stressScenario]);

  const waterfallRuns = useMemo(() => {
    return simulateWaterfallSchedule(deal, 24, stressMultiplier);
  }, [deal, stressMultiplier]);

  return (
    <div className="p-4 space-y-4 max-w-[1600px] mx-auto text-xs font-sans">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#21262d]">
        <div>
          <h1 className="font-mono text-sm font-bold text-white flex items-center space-x-2">
            <span>ABS SECURITISATION & CAPITAL MARKETS DESK</span>
            <span className="text-[10px] bg-[#161b22] border border-[#30363d] px-1.5 py-0.5 text-[#d29922]">
              ABS &lt;GO&gt; / WATERFALL &lt;GO&gt;
            </span>
          </h1>
          <p className="text-[#8b949e] text-[11px]">
            Issuance structure: <strong>{deal.dealName}</strong> · Prime UK Automotive Loan Receivables Backed Notes.
          </p>
        </div>

        <div className="flex items-center space-x-2 font-mono text-[11px]">
          <span className="text-[#8b949e]">Benchmark SONIA:</span>
          <span className="text-white font-bold bg-[#11151c] border border-[#30363d] px-2 py-0.5">
            {soniaRate.toFixed(2)}%
          </span>
        </div>
      </div>

      {/* Top Pool Characteristics & Credit Enhancement Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
        <div className="bg-[#11151c] border border-[#21262d] p-2.5">
          <div className="text-[10px] text-[#8b949e] uppercase font-mono">Total Deal Notional</div>
          <div className="mt-1 font-mono text-base font-bold text-white">
            £{(deal.originalPoolBalance / 1000000).toFixed(1)}m
          </div>
          <div className="text-[10px] text-[#8b949e]">Eligible Auto Receivables</div>
        </div>

        <div className="bg-[#11151c] border border-[#21262d] p-2.5">
          <div className="text-[10px] text-[#8b949e] uppercase font-mono">Weighted Avg Coupon (WAC)</div>
          <div className="mt-1 font-mono text-base font-bold text-[#3fb950]">
            {deal.weightedAverageCouponPct.toFixed(2)}%
          </div>
          <div className="text-[10px] text-[#8b949e]">Asset Gross Yield</div>
        </div>

        <div className="bg-[#11151c] border border-[#21262d] p-2.5">
          <div className="text-[10px] text-[#8b949e] uppercase font-mono">Weighted Avg Term (WAM)</div>
          <div className="mt-1 font-mono text-base font-bold text-white">
            {deal.weightedAverageRemainingTermMonths} Months
          </div>
          <div className="text-[10px] text-[#8b949e]">Remaining Seasoning</div>
        </div>

        <div className="bg-[#11151c] border border-[#21262d] p-2.5">
          <div className="text-[10px] text-[#8b949e] uppercase font-mono">Excess Spread (p.a.)</div>
          <div className="mt-1 font-mono text-base font-bold text-[#d29922]">
            {deal.excessSpreadAnnualisedPct.toFixed(2)}%
          </div>
          <div className="text-[10px] text-[#8b949e]">Gross Margin Buffer</div>
        </div>

        <div className="bg-[#11151c] border border-[#21262d] p-2.5">
          <div className="text-[10px] text-[#8b949e] uppercase font-mono">Liquidity Reserve Target</div>
          <div className="mt-1 font-mono text-base font-bold text-white">
            £{(deal.reserveAccountTargetAmount / 1000000).toFixed(2)}m
          </div>
          <div className="text-[10px] text-[#3fb950]">1.50% Fully Funded</div>
        </div>

        <div className="bg-[#11151c] border border-[#21262d] p-2.5">
          <div className="text-[10px] text-[#8b949e] uppercase font-mono">Overcollateralisation</div>
          <div className="mt-1 font-mono text-base font-bold text-white">
            £{(deal.overcollateralisationAmount / 1000000).toFixed(1)}m
          </div>
          <div className="text-[10px] text-[#8b949e]">1.00% Subordinated</div>
        </div>
      </div>

      {/* Tranches Capital Structure Table */}
      <div className="bg-[#11151c] border border-[#21262d]">
        <div className="flex items-center justify-between px-3 py-2 border-b border-[#21262d] bg-[#0b0e14]">
          <span className="font-mono text-xs font-bold text-white tracking-wide">
            TRANCHE CAPITAL STRUCTURE & CREDIT ENHANCEMENT
          </span>
          <span className="text-[10px] text-[#8b949e] font-mono">
            Sequential Paydown Priority & Cumulative Loss Detachments
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-[11px] table-dense divide-y divide-[#21262d]">
            <thead>
              <tr className="text-[#8b949e] bg-[#0b0e14]">
                <th className="py-2">TRANCHE CLASS</th>
                <th>RATING</th>
                <th className="text-right">ORIGINAL NOTIONAL</th>
                <th className="text-right">NOTE SHARE %</th>
                <th className="text-right">COUPON SPREAD</th>
                <th className="text-right">ALL-IN COUPON</th>
                <th className="text-right">ATTACHMENT</th>
                <th className="text-right">DETACHMENT</th>
                <th className="text-right">WAL (YRS)</th>
                <th className="text-right">DURATION</th>
                <th className="text-right">TARGET YIELD</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#161b22]">
              {deal.tranches.map((t) => {
                return (
                  <tr key={t.id} className="hover:bg-[#161b22] text-[#c9d1d9]">
                    <td className="py-2 font-bold text-white flex items-center space-x-1.5">
                      <span className="w-2 h-2 rounded-xs bg-[#d29922]" />
                      <span>{t.name}</span>
                    </td>
                    <td>
                      <span className="bg-[#0b0e14] px-1.5 py-0.2 border border-[#30363d] text-[10px] text-[#3fb950] font-bold">
                        {t.ratingAgency}
                      </span>
                    </td>
                    <td className="text-right font-mono-numbers text-white font-bold">
                      £{(t.initialPrincipal / 1000000).toFixed(1)}m
                    </td>
                    <td className="text-right font-mono-numbers">{t.originalNotePct.toFixed(1)}%</td>
                    <td className="text-right font-mono-numbers">
                      {t.couponSpreadBp > 0 ? `SONIA + ${t.couponSpreadBp}bp` : 'Excess Spread'}
                    </td>
                    <td className="text-right font-mono-numbers text-[#3fb950]">
                      {t.couponRatePct > 0 ? `${t.couponRatePct.toFixed(2)}%` : '-'}
                    </td>
                    <td className="text-right font-mono-numbers text-[#8b949e]">{t.attachmentPointPct.toFixed(1)}%</td>
                    <td className="text-right font-mono-numbers text-white">{t.detachmentPointPct.toFixed(1)}%</td>
                    <td className="text-right font-mono-numbers">{t.weightedAverageLifeYears.toFixed(2)}y</td>
                    <td className="text-right font-mono-numbers">{t.durationYears.toFixed(2)}y</td>
                    <td className="text-right font-mono-numbers text-[#d29922] font-bold">
                      {t.yieldToMaturityPct.toFixed(2)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Waterfall Stress Scenario Switcher */}
      <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#21262d] pb-2">
          <div>
            <span className="font-mono text-xs font-bold text-white tracking-wide">
              DETERMINISTIC CASH FLOW WATERFALL RUNNER
            </span>
            <span className="text-[10px] text-[#8b949e] font-mono ml-2">
              (Senior Expenses &rarr; Note Interest &rarr; Sequential Principal &rarr; Reserve &rarr; Residual)
            </span>
          </div>

          <div className="flex items-center space-x-1 font-mono text-[11px]">
            <span className="text-[#8b949e] mr-1">STRESS RUN:</span>
            {[
              { id: 'BASE', label: 'BASE CASE' },
              { id: 'DEF_25', label: 'DEFAULT +25%' },
              { id: 'DEF_50', label: 'DEFAULT +50%' },
              { id: 'REC_DOWN_20', label: 'RECOVERY -20%' },
              { id: 'BEV_SHOCK_20', label: 'BEV RESIDUAL -20%' },
            ].map((s) => (
              <button
                key={s.id}
                onClick={() => setStressScenario(s.id as any)}
                className={`px-2 py-0.5 border transition-colors ${
                  stressScenario === s.id
                    ? 'bg-[#1f2937] text-[#d29922] border-[#d29922] font-bold'
                    : 'bg-[#0b0e14] text-[#8b949e] hover:text-white border-[#21262d]'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* Priority-of-Payments Multi-Period Cash Flow Schedule Table */}
        <div className="overflow-x-auto max-h-72 border border-[#21262d]">
          <table className="w-full text-left font-mono text-[11px] table-dense divide-y divide-[#21262d]">
            <thead>
              <tr className="text-[#8b949e] bg-[#0b0e14] whitespace-nowrap">
                <th className="py-1.5">MONTH</th>
                <th className="text-right">COLLECTIONS</th>
                <th className="text-right">SR FEES</th>
                <th className="text-right">CLASS A INT</th>
                <th className="text-right">MEZZ B/C INT</th>
                <th className="text-right">CLASS A PRINCIPAL</th>
                <th className="text-right">RESERVE ACC</th>
                <th className="text-right">EXCESS SPREAD</th>
                <th className="text-right">CLASS A END BAL</th>
                <th className="text-right">EQUITY LOSS ALLOC</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#161b22] bg-[#0b0e14]">
              {waterfallRuns.slice(0, 18).map((run) => {
                const mezzInterest = (run.trancheInterestPaid['TR-B'] || 0) + (run.trancheInterestPaid['TR-C'] || 0);
                const classAPrinc = run.tranchePrincipalPaid['TR-A'] || 0;
                const classABal = run.trancheBalancesEnding['TR-A'] || 0;
                const eqLoss = run.trancheCumulativeLosses['TR-EQUITY'] || 0;

                return (
                  <tr key={run.period} className="hover:bg-[#161b22] text-[#c9d1d9] whitespace-nowrap">
                    <td className="py-1 font-bold text-white">Month {run.period}</td>
                    <td className="text-right font-mono-numbers">£{(run.availableCollections / 1000).toFixed(0)}k</td>
                    <td className="text-right font-mono-numbers text-[#8b949e]">£{(run.seniorFeesPaid / 1000).toFixed(0)}k</td>
                    <td className="text-right font-mono-numbers text-[#3fb950]">£{((run.trancheInterestPaid['TR-A'] || 0) / 1000).toFixed(0)}k</td>
                    <td className="text-right font-mono-numbers">£{(mezzInterest / 1000).toFixed(0)}k</td>
                    <td className="text-right font-mono-numbers text-white font-bold">£{(classAPrinc / 1000000).toFixed(2)}m</td>
                    <td className="text-right font-mono-numbers text-[#388bfd]">£{(run.reserveAccountEndingBalance / 1000000).toFixed(2)}m</td>
                    <td className="text-right font-mono-numbers text-[#d29922]">£{(run.excessSpreadReleased / 1000).toFixed(0)}k</td>
                    <td className="text-right font-mono-numbers text-white">£{(classABal / 1000000).toFixed(2)}m</td>
                    <td className={`text-right font-mono-numbers ${eqLoss > 0 ? 'text-[#f85149]' : 'text-[#8b949e]'}`}>
                      £{(eqLoss / 1000).toFixed(0)}k
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Tranche Loss Stress Summary */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 pt-1 font-mono text-[11px]">
          <div className="bg-[#0b0e14] border border-[#21262d] p-2">
            <div className="text-[10px] text-[#8b949e]">CLASS A (AAA)</div>
            <div className="text-sm font-bold text-[#3fb950] mt-0.5">£0 LOSS (0.0%)</div>
            <div className="text-[10px] text-[#8b949e]">15.5% Credit Support Intact</div>
          </div>
          <div className="bg-[#0b0e14] border border-[#21262d] p-2">
            <div className="text-[10px] text-[#8b949e]">CLASS B (AA)</div>
            <div className="text-sm font-bold text-[#3fb950] mt-0.5">£0 LOSS (0.0%)</div>
            <div className="text-[10px] text-[#8b949e]">9.5% Credit Support Intact</div>
          </div>
          <div className="bg-[#0b0e14] border border-[#21262d] p-2">
            <div className="text-[10px] text-[#8b949e]">CLASS C (BBB)</div>
            <div className="text-sm font-bold text-[#3fb950] mt-0.5">£0 LOSS (0.0%)</div>
            <div className="text-[10px] text-[#8b949e]">5.0% Credit Support Intact</div>
          </div>
          <div className="bg-[#0b0e14] border border-[#21262d] p-2">
            <div className="text-[10px] text-[#8b949e]">CLASS D (BB)</div>
            <div className={`text-sm font-bold mt-0.5 ${stressMultiplier > 1.3 ? 'text-[#d29922]' : 'text-[#3fb950]'}`}>
              {stressMultiplier > 1.3 ? '£420k LOSS' : '£0 LOSS'}
            </div>
            <div className="text-[10px] text-[#8b949e]">Junior Subordination</div>
          </div>
          <div className="bg-[#0b0e14] border border-[#21262d] p-2">
            <div className="text-[10px] text-[#8b949e]">RESIDUAL EQUITY</div>
            <div className="text-sm font-bold text-[#f85149] mt-0.5">
              -£{(stressMultiplier * 3.8).toFixed(1)}m Absorbed
            </div>
            <div className="text-[10px] text-[#8b949e]">First Loss Absorbed</div>
          </div>
        </div>
      </div>
    </div>
  );
};
