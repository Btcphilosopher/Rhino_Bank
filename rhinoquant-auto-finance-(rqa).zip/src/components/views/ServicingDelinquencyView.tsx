/**
 * RhinoQuant Auto Finance
 * Institutional Servicing, Collections & Transition Matrix Engine (RISK <GO> / SERVICING)
 */

import React, { useState } from 'react';
import {
  Activity,
  Layers,
  TrendingDown,
  RotateCcw,
  CheckCircle,
  AlertTriangle,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { BASELINE_TRANSITION_MATRIX } from '../../engine/creditRisk';

export const ServicingDelinquencyView: React.FC = () => {
  const [selectedBucket, setSelectedBucket] = useState<string>('CURRENT');

  const servicingBuckets = [
    { name: 'CURRENT', count: 178420, balanceGBP: 2343000000, sharePct: 96.82, status: 'PERFORMING' },
    { name: '1-30 DPD', count: 3580, balanceGBP: 46900000, sharePct: 1.94, status: 'EARLY_ARREARS' },
    { name: '31-60 DPD', count: 1440, balanceGBP: 18900000, sharePct: 0.78, status: 'MID_ARREARS' },
    { name: '61-90 DPD', count: 520, balanceGBP: 6800000, sharePct: 0.28, status: 'LATE_ARREARS' },
    { name: '90+ DPD', count: 210, balanceGBP: 2750000, sharePct: 0.11, status: 'PRE_DEFAULT' },
    { name: 'DEFAULT', count: 121, balanceGBP: 1650000, sharePct: 0.07, status: 'RECOVERY_REPO' },
  ];

  return (
    <div className="p-4 space-y-4 max-w-[1600px] mx-auto text-xs font-sans">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#21262d]">
        <div>
          <h1 className="font-mono text-sm font-bold text-white flex items-center space-x-2">
            <span>SERVICING, COLLECTIONS & DELINQUENCY ROLL RATES</span>
            <span className="text-[10px] bg-[#161b22] border border-[#30363d] px-1.5 py-0.5 text-[#d29922]">
              RISK &lt;GO&gt;
            </span>
          </h1>
          <p className="text-[#8b949e] text-[11px]">
            Delinquency migration, cure rates, promise-to-pay adherence, and repossession liquidation pipelines.
          </p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-[11px]">
          <div>Total Arrears: <strong className="text-[#f85149]">£77.0m (3.18%)</strong></div>
          <div>Cure Rate (1-30): <strong className="text-[#3fb950]">72.0%</strong></div>
        </div>
      </div>

      {/* Delinquency Bucket Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {servicingBuckets.map((b) => {
          const isSelected = selectedBucket === b.name;
          return (
            <div
              key={b.name}
              onClick={() => setSelectedBucket(b.name)}
              className={`p-2.5 border cursor-pointer transition-colors ${
                isSelected
                  ? 'bg-[#161b22] border-[#d29922]'
                  : 'bg-[#11151c] border-[#21262d] hover:border-[#30363d]'
              }`}
            >
              <div className="flex justify-between text-[10px] font-mono text-[#8b949e]">
                <span>{b.name}</span>
                <span className={b.name === 'CURRENT' ? 'text-[#3fb950]' : 'text-[#f85149]'}>
                  {b.sharePct}%
                </span>
              </div>
              <div className="font-mono text-base font-bold text-white mt-1">
                £{(b.balanceGBP / 1000000).toFixed(1)}m
              </div>
              <div className="text-[10px] text-[#8b949e] font-mono mt-0.5">
                {b.count.toLocaleString()} contracts
              </div>
            </div>
          );
        })}
      </div>

      {/* Transition Matrix & Collections Deep Dive */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column (8 cols): Delinquency Roll-Rate Transition Matrix */}
        <div className="lg:col-span-8 bg-[#11151c] border border-[#21262d]">
          <div className="flex items-center justify-between px-3 py-2 border-b border-[#21262d] bg-[#0b0e14]">
            <span className="font-mono text-xs font-bold text-white tracking-wide">
              MONTHLY DELINQUENCY TRANSITION MATRIX (P_ij)
            </span>
            <span className="text-[10px] text-[#8b949e] font-mono">
              Calibrated Markovian Roll Rates & Cure Vectors
            </span>
          </div>

          <div className="p-3 overflow-x-auto">
            <table className="w-full text-center font-mono text-[11px] table-dense divide-y divide-[#21262d]">
              <thead>
                <tr className="text-[#8b949e] bg-[#0b0e14]">
                  <th className="text-left py-2">FROM BUCKET</th>
                  <th>CURRENT</th>
                  <th>1-30 DPD</th>
                  <th>31-60 DPD</th>
                  <th>61-90 DPD</th>
                  <th>90+ DPD</th>
                  <th className="text-right">DEFAULT (REPO)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#161b22]">
                {BASELINE_TRANSITION_MATRIX.map((row) => (
                  <tr key={row.fromBucket} className="hover:bg-[#161b22] text-[#c9d1d9]">
                    <td className="text-left py-2 font-bold text-white">{row.fromBucket}</td>
                    <td className="text-[#3fb950] font-bold">{(row.toCurrent * 100).toFixed(1)}%</td>
                    <td className={row.to1_30 > 0.1 ? 'text-[#d29922]' : 'text-[#8b949e]'}>
                      {(row.to1_30 * 100).toFixed(1)}%
                    </td>
                    <td className={row.to31_60 > 0.1 ? 'text-[#d29922]' : 'text-[#8b949e]'}>
                      {(row.to31_60 * 100).toFixed(1)}%
                    </td>
                    <td className={row.to61_90 > 0.1 ? 'text-[#f85149]' : 'text-[#8b949e]'}>
                      {(row.to61_90 * 100).toFixed(1)}%
                    </td>
                    <td className={row.to90Plus > 0.1 ? 'text-[#f85149]' : 'text-[#8b949e]'}>
                      {(row.to90Plus * 100).toFixed(1)}%
                    </td>
                    <td className="text-right text-[#f85149] font-bold">
                      {(row.toDefault * 100).toFixed(1)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="mt-3 text-[10px] text-[#8b949e] font-mono border-t border-[#21262d] pt-2 flex justify-between">
              <span>* High cure rate of 72.0% in 1-30 DPD driven by automated SMS reminder and direct debit retries.</span>
              <span>Default absorbing state</span>
            </div>
          </div>
        </div>

        {/* Right Column (4 cols): Collections & Repossession Operations */}
        <div className="lg:col-span-4 bg-[#11151c] border border-[#21262d] p-3 space-y-3 font-mono text-[11px]">
          <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
            <span>RECOVERY & REPOSSESSION PIPELINE</span>
            <span className="text-[10px] text-[#d29922]">ACTIVE LEGAL</span>
          </div>

          <div className="space-y-1.5 divide-y divide-[#161b22]">
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">Active Promise-to-Pay (PTP):</span>
              <span className="text-white font-bold">842 cases (£11.2m)</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">PTP Adherence Rate:</span>
              <span className="text-[#3fb950] font-bold">68.4% kept</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">Pre-Action Default Notices:</span>
              <span className="text-[#d29922] font-bold">185 pending</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">Physical Repossessions (Active):</span>
              <span className="text-white font-bold">48 in transit</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">Auction Liquidation Recovery:</span>
              <span className="text-[#3fb950] font-bold">63.7% net proceeds</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">Avg Days to Auction Settlement:</span>
              <span className="text-white font-bold">42 days</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
