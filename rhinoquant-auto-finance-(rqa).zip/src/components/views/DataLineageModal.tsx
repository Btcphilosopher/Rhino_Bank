/**
 * RhinoQuant Auto Finance
 * Institutional Data Lineage & Provenance Inspector (DATA <GO>)
 * "Where did this number come from?" - Zero Black Box Architecture
 */

import React, { useState } from 'react';
import {
  X,
  Database,
  ArrowDown,
  Layers,
  ChevronRight,
  ShieldCheck,
  CheckCircle,
  FileText,
} from 'lucide-react';
import { DataLineageNode } from '../../types/finance';

interface DataLineageModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMetric?: string;
}

export const DataLineageModal: React.FC<DataLineageModalProps> = ({
  isOpen,
  onClose,
  initialMetric = 'EXPECTED_LOSS',
}) => {
  const [selectedMetric, setSelectedMetric] = useState<string>(initialMetric);

  if (!isOpen) return null;

  // Provenance trees
  const expectedLossTree: DataLineageNode = {
    label: 'Portfolio 12M Expected Credit Loss (ECL)',
    value: '£24,800,000 (1.02% of Book)',
    sourceType: 'CALCULATION',
    description: 'Deterministic sum of loan-level Expected Loss across 184,291 active contracts: EL = sum(PD_i * LGD_i * EAD_i)',
    versionOrTimestamp: '2026-10-12 10:13:30 UTC · Calibrated',
    children: [
      {
        label: 'Active Loan Population & Cohorts',
        value: '184,291 contracts · £2,420,000,000 outstanding balance',
        sourceType: 'INPUT_AGGREGATE',
        description: 'Receivables originating between 2023-Q1 and 2025-Q1 across 482 partner dealerships.',
        versionOrTimestamp: 'Core System DB v3.8.4',
        children: [
          {
            label: 'Contractual Amortisation Schedules',
            value: 'Monthly principal & interest cash-flow vectors',
            sourceType: 'CORE_SYSTEM',
            description: 'Actuarial cash flows for PCP (with GFV), HP, Balloon and Lease structures.',
            versionOrTimestamp: 'Rust Cashflow Engine v2.1',
          },
        ],
      },
      {
        label: 'PD Model (Probability of Default)',
        value: 'Weighted Average 12M PD: 2.90%',
        sourceType: 'MODEL_OUTPUT',
        description: 'Logistic credit scorecard calibrated on 12-month bureau history, payment-to-income, and tenure.',
        versionOrTimestamp: 'MDL-PD-AUTO-3.2 (Approved 2026-02-14)',
        children: [
          {
            label: 'Bureau Scorecard Weights',
            value: 'Experian / Equifax prime weighting (400-999 scale)',
            sourceType: 'MODEL_OUTPUT',
            description: 'AUC 0.842, Gini 0.684, PSI 0.041. Zero unlawful demographic characteristics.',
            versionOrTimestamp: 'Model Registry Commit #884a',
          },
        ],
      },
      {
        label: 'Collateral-Adjusted LGD Model',
        value: 'Weighted Average LGD: 42.4%',
        sourceType: 'MODEL_OUTPUT',
        description: 'LGD = (Balance - Net Auction Recovery + £950 Repossession Costs) / Balance.',
        versionOrTimestamp: 'MDL-LGD-COLLAT-2.4 (Monitored 2026-01-28)',
        children: [
          {
            label: 'Vehicle Residual Depreciation Curves',
            value: 'BCA / Manheim wholesale liquidation data & battery degradation curves',
            sourceType: 'MARKET_DATA',
            description: 'Used Car Index 98.4; BEV 36M retention 48.2% (-8.2% discount vs ICE).',
            versionOrTimestamp: 'Market Data Feed: 2026-10-12 08:00 UTC',
          },
        ],
      },
      {
        label: 'Exposure at Default (EAD)',
        value: 'Contractual Principal Outstanding + Accrued Interest (£2.42bn)',
        sourceType: 'CALCULATION',
        description: 'EAD incorporates scheduled amortisation and expected prepayment via 6.4% CPR.',
        versionOrTimestamp: 'Basel III Standardised Approach Calibrated',
      },
    ],
  };

  const rarocTree: DataLineageNode = {
    label: 'Portfolio Return on Economic Capital (RAROC)',
    value: '18.70% (Hurdle: 15.0%)',
    sourceType: 'CALCULATION',
    description: 'RAROC = (Net Interest Income - ECL - Servicing Cost) / Economic Capital',
    versionOrTimestamp: '2026-10-12 10:13:30 UTC',
    children: [
      {
        label: 'Net Interest Margin (NIM)',
        value: '£47,000,000 (Average Customer Yield 8.40% - Funding 4.31%)',
        sourceType: 'CALCULATION',
        description: 'Wholesale warehouse cost of funds SONIA 4.70% + 135bp margin vs retail customer APR.',
        versionOrTimestamp: 'Treasury Desk Ledger 2026-10-12',
      },
      {
        label: 'Economic Capital Allocation (ECap)',
        value: '£91,000,000 (Pillar 2 Unexpected Loss Buffer)',
        sourceType: 'MODEL_OUTPUT',
        description: 'Calibrated at 99.9% confidence interval using 10,000 Monte Carlo vectorised iterations.',
        versionOrTimestamp: 'MDL-ECAP-AUTO-1.1',
      },
    ],
  };

  const activeTree = selectedMetric === 'RAROC' ? rarocTree : expectedLossTree;

  const renderNode = (node: DataLineageNode, depth: number = 0) => {
    return (
      <div key={node.label} className={`border-l-2 border-[#21262d] pl-3 py-1 space-y-1 ${depth > 0 ? 'ml-4' : ''}`}>
        <div className="flex items-center space-x-2">
          <span className="font-mono text-[10px] font-bold px-1.5 py-0.2 bg-[#0b0e14] border border-[#30363d] text-[#d29922]">
            {node.sourceType}
          </span>
          <span className="font-mono text-xs font-bold text-white">{node.label}</span>
          <span className="font-mono text-xs text-[#3fb950] font-bold">{node.value}</span>
        </div>
        <p className="text-[#8b949e] font-sans text-xs">{node.description}</p>
        <div className="text-[10px] text-[#6e7681] font-mono">
          PROVENANCE: {node.versionOrTimestamp}
        </div>

        {node.children && node.children.length > 0 && (
          <div className="mt-2 space-y-2">
            {node.children.map((child) => renderNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs">
      <div className="w-full max-w-4xl bg-[#11151c] border border-[#30363d] shadow-2xl flex flex-col max-h-[85vh] text-xs font-sans">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-[#21262d] bg-[#0b0e14]">
          <div className="flex items-center space-x-2">
            <Database className="w-4 h-4 text-[#388bfd]" />
            <span className="font-mono text-xs font-bold text-white tracking-wide">
              DATA LINEAGE & CALCULATION PROVENANCE INSPECTOR
            </span>
            <span className="text-[10px] bg-[#161b22] border border-[#30363d] px-1.5 py-0.5 text-[#388bfd] font-mono">
              ZERO BLACK-BOX GUARANTEE
            </span>
          </div>

          <button onClick={onClose} className="text-[#8b949e] hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Metric Selector Tabs */}
        <div className="flex items-center space-x-2 px-4 py-2 bg-[#0b0e14] border-b border-[#21262d] font-mono text-[11px]">
          <span className="text-[#8b949e]">Select Output Metric:</span>
          <button
            onClick={() => setSelectedMetric('EXPECTED_LOSS')}
            className={`px-2.5 py-1 border transition-colors ${
              selectedMetric === 'EXPECTED_LOSS'
                ? 'bg-[#1f2937] text-[#d29922] border-[#d29922] font-bold'
                : 'bg-[#161b22] text-[#8b949e] border-[#21262d]'
            }`}
          >
            EXPECTED LOSS (£24.8M)
          </button>
          <button
            onClick={() => setSelectedMetric('RAROC')}
            className={`px-2.5 py-1 border transition-colors ${
              selectedMetric === 'RAROC'
                ? 'bg-[#1f2937] text-[#d29922] border-[#d29922] font-bold'
                : 'bg-[#161b22] text-[#8b949e] border-[#21262d]'
            }`}
          >
            PORTFOLIO RAROC (18.70%)
          </button>
        </div>

        {/* Tree Content */}
        <div className="p-4 overflow-y-auto space-y-4">
          <div className="bg-[#0b0e14] border border-[#21262d] p-3 text-[11px] text-[#c9d1d9] font-sans">
            Every metric published on the RhinoQuant terminal is mathematically reproducible. Below is the complete directed acyclic graph (DAG) connecting underlying contract cash flows, validated statistical models, and live wholesale market curves.
          </div>

          <div className="space-y-3">
            {renderNode(activeTree, 0)}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-[#0b0e14] border-t border-[#21262d] font-mono text-[11px] text-[#8b949e]">
          <div>REPRODUCIBILITY CODE: <strong>RQA-PROV-SHA256:77a1...941d</strong></div>
          <button
            onClick={onClose}
            className="px-3 py-1 bg-[#21262d] hover:bg-[#30363d] text-white border border-[#30363d] font-mono text-xs"
          >
            DISMISS
          </button>
        </div>
      </div>
    </div>
  );
};
