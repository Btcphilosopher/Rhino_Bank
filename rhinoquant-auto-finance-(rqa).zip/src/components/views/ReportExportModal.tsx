/**
 * RhinoQuant Auto Finance
 * Institutional Reporting & Data Export Modal (REPORT <GO>)
 */

import React, { useState } from 'react';
import {
  X,
  FileText,
  Download,
  CheckCircle,
  Copy,
  Database,
  Layers,
} from 'lucide-react';
import { SYNTHETIC_PORTFOLIO_METRICS, SYNTHETIC_VINTAGES } from '../../data/syntheticPortfolio';

interface ReportExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReportExportModal: React.FC<ReportExportModalProps> = ({ isOpen, onClose }) => {
  const [selectedReportType, setSelectedReportType] = useState<string>('PORTFOLIO_EXECUTIVE');
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const reportData = {
    system: 'RHINOQUANT AUTO FINANCE (RQA)',
    reportId: `RQA-REP-${Date.now()}`,
    generatedTimestamp: new Date().toISOString(),
    dataset: 'SYNTHETIC / SIMULATED (Seed: 0xRQA_2026)',
    metrics: SYNTHETIC_PORTFOLIO_METRICS,
    vintages: SYNTHETIC_VINTAGES,
  };

  const handleCopyJSON = () => {
    navigator.clipboard.writeText(JSON.stringify(reportData, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(reportData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `RQA_${selectedReportType}_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs">
      <div className="w-full max-w-3xl bg-[#11151c] border border-[#30363d] shadow-2xl flex flex-col max-h-[85vh] text-xs font-sans">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-[#21262d] bg-[#0b0e14]">
          <div className="flex items-center space-x-2">
            <FileText className="w-4 h-4 text-[#d29922]" />
            <span className="font-mono text-xs font-bold text-white tracking-wide">
              INSTITUTIONAL QUANTITATIVE REPORT PACK GENERATOR
            </span>
            <span className="text-[10px] bg-[#161b22] border border-[#30363d] px-1.5 py-0.5 text-[#d29922] font-mono">
              REPORT &lt;GO&gt;
            </span>
          </div>

          <button onClick={onClose} className="text-[#8b949e] hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Report Type Selector */}
        <div className="p-4 space-y-3 overflow-y-auto">
          <div>
            <label className="text-[10px] text-[#8b949e] uppercase font-mono block mb-1">Select Report Dossier:</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 font-mono text-[11px]">
              {[
                { id: 'PORTFOLIO_EXECUTIVE', label: 'Portfolio Report' },
                { id: 'CREDIT_RISK', label: 'Credit Risk Report' },
                { id: 'ABS_INVESTOR', label: 'ABS Investor Report' },
                { id: 'STRESS_TEST', label: 'Stress Test Report' },
                { id: 'MODEL_VALIDATION', label: 'Model Validation Report' },
                { id: 'DEALER_AUDIT', label: 'Dealer Report' },
                { id: 'FUNDING_LIQUIDITY', label: 'Funding Report' },
                { id: 'FCA_COMPLIANCE', label: 'Compliance Report' },
              ].map((r) => (
                <button
                  key={r.id}
                  onClick={() => setSelectedReportType(r.id)}
                  className={`p-2 border text-left transition-colors ${
                    selectedReportType === r.id
                      ? 'bg-[#1f2937] text-[#d29922] border-[#d29922] font-bold'
                      : 'bg-[#0b0e14] text-[#8b949e] hover:text-white border-[#21262d]'
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>

          {/* Formatted Terminal Briefing Preview */}
          <div className="bg-[#0b0e14] border border-[#21262d] p-3 font-mono text-[11px] space-y-2 text-[#c9d1d9]">
            <div className="text-white font-bold border-b border-[#21262d] pb-1 flex justify-between">
              <span>RHINOQUANT AUTO FINANCE — EXECUTIVE DESK SUMMARY</span>
              <span className="text-[#3fb950]">CONFIDENTIAL / INSTITUTIONAL</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[10px]">
              <div>Portfolio Balance: <strong className="text-white">£2.42bn</strong></div>
              <div>Active Loan Population: <strong className="text-white">184,291 contracts</strong></div>
              <div>12-Month Expected Loss: <strong className="text-[#d29922]">£24.8m (1.02%)</strong></div>
              <div>12-Month Rolling Default: <strong className="text-white">2.90%</strong></div>
              <div>Portfolio RAROC: <strong className="text-[#3fb950]">18.70%</strong></div>
              <div>BEV Portfolio Concentration: <strong className="text-[#388bfd]">21.40%</strong></div>
              <div>Wholesale Cost of Funds: <strong className="text-white">4.31% (SONIA + 135bp)</strong></div>
              <div>Average Customer Yield: <strong className="text-white">8.40% (Gross NIM +409bp)</strong></div>
            </div>

            <div className="text-[10px] text-[#8b949e] pt-1 border-t border-[#21262d]">
              Reproducibility Stamp: Seed 0xRQA_2026 | Engine v3.8.4 | Models: PD-3.2, LGD-2.4, ABS-1.8 | FCA DCA Rule v2026.2
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#0b0e14] border-t border-[#21262d] font-mono text-[11px]">
          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopyJSON}
              className="flex items-center space-x-1.5 bg-[#161b22] hover:bg-[#21262d] text-white border border-[#30363d] px-3 py-1.5 transition-colors"
            >
              <Copy className="w-3.5 h-3.5 text-[#388bfd]" />
              <span>{copied ? 'COPIED TO CLIPBOARD' : 'COPY JSON DATA'}</span>
            </button>

            <button
              onClick={handleDownloadJSON}
              className="flex items-center space-x-1.5 bg-[#d29922] hover:bg-[#b07d19] text-black font-bold px-3 py-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>DOWNLOAD DOSSIER (.JSON)</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-3 py-1.5 bg-[#21262d] hover:bg-[#30363d] text-white border border-[#30363d]"
          >
            DISMISS
          </button>
        </div>
      </div>
    </div>
  );
};
