/**
 * RhinoQuant Auto Finance
 * Institutional Stress Testing Workbench & Monte Carlo Engine (STRESS <GO> / MONTE <GO>)
 */

import React, { useState, useMemo, useEffect } from 'react';
import {
  Sliders,
  Play,
  RotateCcw,
  AlertTriangle,
  Zap,
  BarChart3,
  TrendingDown,
  Layers,
  ShieldAlert,
  Database,
  CheckCircle,
} from 'lucide-react';
import {
  PRESET_STRESS_SCENARIOS,
  executeStressScenario,
} from '../../engine/stressTesting';
import {
  runPortfolioMonteCarlo,
  MonteCarloDistribution,
} from '../../engine/monteCarlo';

export const StressMonteCarloView: React.FC = () => {
  // Scenario Config State
  const [selectedPresetId, setSelectedPresetId] = useState<string>('BEV_SHOCK_20');
  const [pdMultiplier, setPdMultiplier] = useState<number>(1.25);
  const [lgdMultiplier, setLgdMultiplier] = useState<number>(1.15);
  const [bevResidualShockPct, setBevResidualShockPct] = useState<number>(-0.20); // -20%
  const [fundingShiftBp, setFundingShiftBp] = useState<number>(50); // +50bp
  const [prepaymentMultiplier, setPrepaymentMultiplier] = useState<number>(0.85);

  // Monte Carlo execution states
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simulationProgress, setSimulationProgress] = useState<number>(100);
  const [mcResult, setMcResult] = useState<MonteCarloDistribution | null>(null);

  // Load initial Monte Carlo baseline
  useEffect(() => {
    const res = runPortfolioMonteCarlo(10000, 2420000000, 24800000, '0xRQA_2026');
    setMcResult(res);
  }, []);

  const handleApplyPreset = (presetId: string) => {
    setSelectedPresetId(presetId);
    const p = PRESET_STRESS_SCENARIOS.find((item) => item.id === presetId);
    if (p) {
      setPdMultiplier(p.pdMultiplier);
      setLgdMultiplier(p.lgdMultiplier);
      setBevResidualShockPct(p.bevResidualShockPct);
      setFundingShiftBp(p.fundingRateShiftBp);
      setPrepaymentMultiplier(p.prepaymentMultiplier);
    }
  };

  // Execute analytical stress test
  const stressResult = useMemo(() => {
    return executeStressScenario({
      id: selectedPresetId,
      name: 'Custom Active Scenario',
      description: 'Active parameter workbench scenario',
      pdMultiplier,
      lgdMultiplier,
      bevResidualShockPct,
      fundingRateShiftBp: fundingShiftBp,
      prepaymentMultiplier,
      unemploymentShockPct: 1.5,
    });
  }, [selectedPresetId, pdMultiplier, lgdMultiplier, bevResidualShockPct, fundingShiftBp, prepaymentMultiplier]);

  // Trigger interactive Monte Carlo run with progress counter
  const runSimulationAsync = () => {
    setIsSimulating(true);
    setSimulationProgress(0);

    let current = 0;
    const interval = setInterval(() => {
      current += 15;
      if (current >= 100) {
        clearInterval(interval);
        setSimulationProgress(100);
        setIsSimulating(false);
        const res = runPortfolioMonteCarlo(10000, 2420000000, stressResult.stressedExpectedLoss, '0xRQA_2026');
        setMcResult(res);
      } else {
        setSimulationProgress(current);
      }
    }, 120);
  };

  return (
    <div className="p-4 space-y-4 max-w-[1600px] mx-auto text-xs font-sans">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#21262d]">
        <div>
          <h1 className="font-mono text-sm font-bold text-white flex items-center space-x-2">
            <span>PORTFOLIO STRESS TESTING & VALUE-AT-RISK (VaR) WORKBENCH</span>
            <span className="text-[10px] bg-[#161b22] border border-[#30363d] px-1.5 py-0.5 text-[#d29922]">
              STRESS &lt;GO&gt; / MONTE &lt;GO&gt;
            </span>
          </h1>
          <p className="text-[#8b949e] text-[11px]">
            Macroeconomic factor shocks, non-linear EV residual value stress, and 10,000 vectorised Monte Carlo iterations.
          </p>
        </div>

        <div className="flex items-center space-x-2 font-mono text-[11px]">
          <span className="text-[#8b949e]">PRNG SEED:</span>
          <span className="text-[#d29922] font-bold bg-[#11151c] border border-[#30363d] px-2 py-0.5">
            0xRQA_2026 (Reproducible)
          </span>
        </div>
      </div>

      {/* Preset Scenarios Strip */}
      <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-2">
        <div className="text-[10px] text-[#8b949e] uppercase font-mono font-bold tracking-wider">
          MACRO & COLLATERAL PRESET SCENARIOS
        </div>
        <div className="flex flex-wrap gap-1.5">
          {PRESET_STRESS_SCENARIOS.map((p) => {
            const isSelected = selectedPresetId === p.id;
            return (
              <button
                key={p.id}
                onClick={() => handleApplyPreset(p.id)}
                className={`px-2.5 py-1 text-[11px] font-mono border transition-colors ${
                  isSelected
                    ? 'bg-[#1f2937] text-[#d29922] border-[#d29922] font-bold'
                    : 'bg-[#0b0e14] text-[#8b949e] hover:text-white border-[#21262d]'
                }`}
              >
                {p.name}
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column (5 cols): Parameter Controls Workbench */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-3">
            <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
              <span>SCENARIO FACTOR SENSITIVITIES</span>
              <button
                onClick={() => handleApplyPreset('BASE')}
                className="text-[10px] text-[#8b949e] hover:text-white flex items-center"
              >
                <RotateCcw className="w-3 h-3 mr-1" />
                RESET BASE
              </button>
            </div>

            {/* Slider 1: PD Multiplier */}
            <div className="space-y-1 font-mono text-[11px]">
              <div className="flex justify-between">
                <span className="text-[#8b949e]">Probability of Default (PD):</span>
                <span className="text-white font-bold">{pdMultiplier > 1 ? `+${((pdMultiplier - 1) * 100).toFixed(0)}%` : 'Base'}</span>
              </div>
              <input
                type="range"
                min="0.8"
                max="2.0"
                step="0.05"
                value={pdMultiplier}
                onChange={(e) => setPdMultiplier(parseFloat(e.target.value))}
                className="w-full accent-[#d29922]"
              />
            </div>

            {/* Slider 2: LGD Multiplier */}
            <div className="space-y-1 font-mono text-[11px]">
              <div className="flex justify-between">
                <span className="text-[#8b949e]">Loss Given Default (LGD):</span>
                <span className="text-white font-bold">{lgdMultiplier > 1 ? `+${((lgdMultiplier - 1) * 100).toFixed(0)}%` : 'Base'}</span>
              </div>
              <input
                type="range"
                min="0.8"
                max="1.8"
                step="0.05"
                value={lgdMultiplier}
                onChange={(e) => setLgdMultiplier(parseFloat(e.target.value))}
                className="w-full accent-[#d29922]"
              />
            </div>

            {/* Slider 3: BEV Residual Value Shock */}
            <div className="space-y-1 font-mono text-[11px]">
              <div className="flex justify-between">
                <span className="text-[#8b949e]">BEV Residual Value Shock:</span>
                <span className={bevResidualShockPct < 0 ? 'text-[#f85149] font-bold' : 'text-white'}>
                  {(bevResidualShockPct * 100).toFixed(0)}%
                </span>
              </div>
              <input
                type="range"
                min="-0.40"
                max="0.0"
                step="0.05"
                value={bevResidualShockPct}
                onChange={(e) => setBevResidualShockPct(parseFloat(e.target.value))}
                className="w-full accent-[#f85149]"
              />
            </div>

            {/* Slider 4: Funding Spread Shift */}
            <div className="space-y-1 font-mono text-[11px]">
              <div className="flex justify-between">
                <span className="text-[#8b949e]">Wholesale Funding Spread Shift:</span>
                <span className="text-white font-bold">+{fundingShiftBp} bp</span>
              </div>
              <input
                type="range"
                min="0"
                max="250"
                step="10"
                value={fundingShiftBp}
                onChange={(e) => setFundingShiftBp(parseInt(e.target.value, 10))}
                className="w-full accent-[#388bfd]"
              />
            </div>

            {/* Slider 5: Prepayment CPR Multiplier */}
            <div className="space-y-1 font-mono text-[11px]">
              <div className="flex justify-between">
                <span className="text-[#8b949e]">Prepayment Rate (CPR) Multiplier:</span>
                <span className="text-white font-bold">{prepaymentMultiplier.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="1.5"
                step="0.05"
                value={prepaymentMultiplier}
                onChange={(e) => setPrepaymentMultiplier(parseFloat(e.target.value))}
                className="w-full accent-[#3fb950]"
              />
            </div>

            {/* Run Monte Carlo Action Button */}
            <div className="pt-2">
              <button
                onClick={runSimulationAsync}
                disabled={isSimulating}
                className="w-full py-2 bg-[#d29922] hover:bg-[#b07d19] text-black font-mono font-bold text-xs flex items-center justify-center space-x-2 transition-colors disabled:opacity-50"
              >
                <Play className="w-3.5 h-3.5" />
                <span>RUN 10,000 MONTE CARLO SIMULATIONS</span>
              </button>
            </div>

            {isSimulating && (
              <div className="bg-[#0b0e14] border border-[#21262d] p-2 space-y-1 font-mono text-[11px]">
                <div className="flex justify-between text-[#d29922]">
                  <span>SCENARIO RUNNING:</span>
                  <span>{simulationProgress}%</span>
                </div>
                <div className="text-[10px] text-[#8b949e]">
                  Simulation {Math.round(simulationProgress * 100)} / 10,000 vectorised trials...
                </div>
                <div className="w-full bg-[#161b22] h-1.5">
                  <div className="bg-[#d29922] h-1.5 transition-all" style={{ width: `${simulationProgress}%` }} />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column (7 cols): Stressed Impact & Tranche Waterfall Write-Down */}
        <div className="lg:col-span-7 space-y-4">
          {/* Stressed KPI Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="bg-[#11151c] border border-[#21262d] p-2.5 font-mono">
              <div className="text-[10px] text-[#8b949e]">STRESSED EXPECTED LOSS</div>
              <div className="text-base font-bold text-[#f85149] mt-0.5">
                £{(stressResult.stressedExpectedLoss / 1000000).toFixed(1)}m
              </div>
              <div className="text-[10px] text-[#f85149] mt-0.5">
                +£{(stressResult.deltaLossAmount / 1000000).toFixed(1)}m (+{stressResult.deltaLossPct}%)
              </div>
            </div>

            <div className="bg-[#11151c] border border-[#21262d] p-2.5 font-mono">
              <div className="text-[10px] text-[#8b949e]">PORTFOLIO RAROC</div>
              <div className="text-base font-bold text-[#d29922] mt-0.5">
                {stressResult.stressedRarocPct.toFixed(1)}%
              </div>
              <div className="text-[10px] text-[#8b949e] mt-0.5">
                Base 18.7% &rarr; {stressResult.stressedRarocPct.toFixed(1)}%
              </div>
            </div>

            <div className="bg-[#11151c] border border-[#21262d] p-2.5 font-mono">
              <div className="text-[10px] text-[#8b949e]">COLLATERAL SHORTFALL</div>
              <div className="text-base font-bold text-white mt-0.5">
                £{(stressResult.collateralShortfallAmount / 1000000).toFixed(1)}m
              </div>
              <div className="text-[10px] text-[#8b949e] mt-0.5">
                BEV Balloon Deficit
              </div>
            </div>

            <div className="bg-[#11151c] border border-[#21262d] p-2.5 font-mono">
              <div className="text-[10px] text-[#8b949e]">ECONOMIC CAPITAL REQ.</div>
              <div className="text-base font-bold text-white mt-0.5">
                +£{(stressResult.economicCapitalRequiredDelta / 1000000).toFixed(1)}m
              </div>
              <div className="text-[10px] text-[#8b949e] mt-0.5">
                Pillar 2 Capital Buffer
              </div>
            </div>
          </div>

          {/* Stressed ABS Tranche Loss Allocation (prompt Section 62 requirement) */}
          <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-2 font-mono text-[11px]">
            <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
              <span>ABS TRANCHE LOSS DISTRIBUTION IMPACT</span>
              <span className="text-[10px] text-[#8b949e]">£500M ISSUANCE REFERENCE</span>
            </div>

            <div className="grid grid-cols-5 gap-2 text-center pt-1">
              <div className="bg-[#0b0e14] border border-[#21262d] p-2">
                <div className="text-[10px] text-[#8b949e]">CLASS A (AAA)</div>
                <div className="text-xs font-bold text-[#3fb950] mt-1">UNAFFECTED</div>
                <div className="text-[9px] text-[#8b949e]">£0 loss</div>
              </div>

              <div className="bg-[#0b0e14] border border-[#21262d] p-2">
                <div className="text-[10px] text-[#8b949e]">CLASS B (AA)</div>
                <div className="text-xs font-bold text-[#3fb950] mt-1">UNAFFECTED</div>
                <div className="text-[9px] text-[#8b949e]">£0 loss</div>
              </div>

              <div className="bg-[#0b0e14] border border-[#21262d] p-2">
                <div className="text-[10px] text-[#8b949e]">CLASS C (BBB)</div>
                <div className="text-xs font-bold text-[#3fb950] mt-1">UNAFFECTED</div>
                <div className="text-[9px] text-[#8b949e]">£0 loss</div>
              </div>

              <div className="bg-[#0b0e14] border border-[#21262d] p-2">
                <div className="text-[10px] text-[#8b949e]">CLASS D (BB)</div>
                <div className={`text-xs font-bold mt-1 ${stressResult.trancheLosses.classD > 0 ? 'text-[#d29922]' : 'text-[#3fb950]'}`}>
                  {stressResult.trancheLosses.classD > 0 ? `-£${(stressResult.trancheLosses.classD / 1000000).toFixed(1)}m` : '£0 LOSS'}
                </div>
                <div className="text-[9px] text-[#8b949e]">Subordinated</div>
              </div>

              <div className="bg-[#0b0e14] border border-[#21262d] p-2">
                <div className="text-[10px] text-[#8b949e]">RESIDUAL EQUITY</div>
                <div className="text-xs font-bold text-[#f85149] mt-1">
                  -£{(stressResult.trancheLosses.equity / 1000000).toFixed(1)}m
                </div>
                <div className="text-[9px] text-[#8b949e]">First Loss Absorbed</div>
              </div>
            </div>
          </div>

          {/* Monte Carlo VaR Percentile Distribution */}
          {mcResult && (
            <div className="bg-[#11151c] border border-[#21262d] p-3 space-y-2 font-mono text-[11px]">
              <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
                <span>MONTE CARLO CREDIT VALUE-AT-RISK (VaR) DISTRIBUTION</span>
                <span className="text-[#3fb950] text-[10px]">
                  10,000 RUNS IN {mcResult.executionTimeMs}MS
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center pt-1">
                <div className="bg-[#0b0e14] border border-[#21262d] p-2">
                  <div className="text-[10px] text-[#8b949e]">P50 (MEDIAN)</div>
                  <div className="text-sm font-bold text-white mt-0.5">£{(mcResult.p50Loss / 1000000).toFixed(1)}m</div>
                </div>

                <div className="bg-[#0b0e14] border border-[#21262d] p-2">
                  <div className="text-[10px] text-[#8b949e]">P75 LOSS</div>
                  <div className="text-sm font-bold text-[#d29922] mt-0.5">£{(mcResult.p75Loss / 1000000).toFixed(1)}m</div>
                </div>

                <div className="bg-[#0b0e14] border border-[#21262d] p-2">
                  <div className="text-[10px] text-[#8b949e]">P90 LOSS</div>
                  <div className="text-sm font-bold text-[#d29922] mt-0.5">£{(mcResult.p90Loss / 1000000).toFixed(1)}m</div>
                </div>

                <div className="bg-[#0b0e14] border border-[#21262d] p-2">
                  <div className="text-[10px] text-[#8b949e]">95% CREDIT VaR</div>
                  <div className="text-sm font-bold text-[#f85149] mt-0.5">£{(mcResult.p95VaR / 1000000).toFixed(1)}m</div>
                </div>

                <div className="bg-[#0b0e14] border border-[#21262d] p-2">
                  <div className="text-[10px] text-[#8b949e]">99% EXTREME VaR</div>
                  <div className="text-sm font-bold text-[#f85149] mt-0.5">£{(mcResult.p99VaR / 1000000).toFixed(1)}m</div>
                </div>
              </div>

              {/* Loss Histogram Bar Chart */}
              <div className="pt-2">
                <div className="text-[10px] text-[#8b949e] mb-1">
                  EMPIRICAL LOSS DENSITY HISTOGRAM (£M)
                </div>
                <div className="grid grid-cols-16 gap-0.5 h-16 items-end bg-[#0b0e14] p-1 border border-[#21262d]">
                  {mcResult.histogramBins.map((bin, idx) => {
                    const maxCount = Math.max(...mcResult.histogramBins.map((b) => b.count));
                    const heightPct = Math.max(8, (bin.count / maxCount) * 100);
                    return (
                      <div
                        key={idx}
                        className="bg-[#388bfd] hover:bg-[#d29922] transition-colors relative group"
                        style={{ height: `${heightPct}%` }}
                        title={`£${bin.binLossM}m: ${bin.count} iterations (${bin.cumulativePct}%)`}
                      />
                    );
                  })}
                </div>
                <div className="flex justify-between text-[9px] text-[#8b949e] font-mono mt-0.5">
                  <span>£{mcResult.histogramBins[0]?.binLossM}m (Min)</span>
                  <span>95% VaR: £{(mcResult.p95VaR / 1000000).toFixed(1)}m</span>
                  <span>£{mcResult.histogramBins[mcResult.histogramBins.length - 1]?.binLossM}m (Extreme Tail)</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
