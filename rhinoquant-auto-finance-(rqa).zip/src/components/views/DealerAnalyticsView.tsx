/**
 * RhinoQuant Auto Finance
 * Institutional Dealer Analytics & Fraud Anomaly Engine (DEALER <GO>)
 */

import React, { useState } from 'react';
import {
  Users,
  AlertTriangle,
  ShieldAlert,
  ArrowUpDown,
  Search,
  CheckCircle,
  ExternalLink,
} from 'lucide-react';
import { SYNTHETIC_DEALERS } from '../../data/syntheticPortfolio';
import { DealerPerformance } from '../../types/finance';

export const DealerAnalyticsView: React.FC = () => {
  const [dealers, setDealers] = useState<DealerPerformance[]>(SYNTHETIC_DEALERS);
  const [selectedDealerId, setSelectedDealerId] = useState<string>('DLR-482');

  const activeDealer = dealers.find((d) => d.id === selectedDealerId) || dealers[0];

  return (
    <div className="p-4 space-y-4 max-w-[1600px] mx-auto text-xs font-sans">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#21262d]">
        <div>
          <h1 className="font-mono text-sm font-bold text-white flex items-center space-x-2">
            <span>DEALER NETWORK ANALYTICS & FRAUD ANOMALY ENGINE</span>
            <span className="text-[10px] bg-[#161b22] border border-[#30363d] px-1.5 py-0.5 text-[#d29922]">
              DEALER &lt;GO&gt;
            </span>
          </h1>
          <p className="text-[#8b949e] text-[11px]">
            Origination quality scoring, early surrender rates, broker commission patterns, and analytical fraud anomaly monitors.
          </p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-[11px]">
          <div>Active Partner Dealers: <strong className="text-white">482</strong></div>
          <div>Network 12M Default: <strong className="text-white">2.90%</strong></div>
          <div>Watchlist Dealers: <strong className="text-[#d29922]">12</strong></div>
        </div>
      </div>

      {/* Dealer Performance Table */}
      <div className="bg-[#11151c] border border-[#21262d] overflow-x-auto">
        <table className="w-full text-left font-mono text-[11px] table-dense divide-y divide-[#21262d]">
          <thead>
            <tr className="text-[#8b949e] bg-[#0b0e14]">
              <th className="py-2">DEALER NAME & ID</th>
              <th>REGION</th>
              <th>CHANNEL TYPE</th>
              <th className="text-right">ORIGINATIONS</th>
              <th className="text-right">APPROVAL %</th>
              <th className="text-right">AVG LTV</th>
              <th className="text-right">AVG APR</th>
              <th className="text-right">12M DEFAULT</th>
              <th className="text-right">VOL SURRENDER</th>
              <th className="text-right">RAROC MARGIN</th>
              <th className="text-center">ANOMALIES</th>
              <th className="text-right">RISK TIER</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#161b22]">
            {dealers.map((d) => {
              const isSelected = d.id === selectedDealerId;
              return (
                <tr
                  key={d.id}
                  onClick={() => setSelectedDealerId(d.id)}
                  className={`cursor-pointer transition-colors ${
                    isSelected ? 'bg-[#1c2128] text-white font-medium' : 'hover:bg-[#161b22] text-[#c9d1d9]'
                  }`}
                >
                  <td className="py-2 font-bold text-white">
                    <div>{d.name}</div>
                    <div className="text-[10px] text-[#8b949e]">{d.id}</div>
                  </td>
                  <td>{d.region}</td>
                  <td>
                    <span className="text-[10px] bg-[#0b0e14] px-1.5 py-0.2 border border-[#30363d] text-[#8b949e]">
                      {d.dealerType}
                    </span>
                  </td>
                  <td className="text-right font-mono-numbers text-white font-bold">
                    £{(d.totalOriginationsVolume / 1000000).toFixed(1)}m
                  </td>
                  <td className="text-right font-mono-numbers">{d.approvalRatePct.toFixed(1)}%</td>
                  <td className="text-right font-mono-numbers">{d.averageLTVPct.toFixed(1)}%</td>
                  <td className="text-right font-mono-numbers">{d.averageCustomerAPR.toFixed(2)}%</td>
                  <td className={`text-right font-mono-numbers ${d.defaultRate12mPct > 3.0 ? 'text-[#f85149] font-bold' : 'text-[#3fb950]'}`}>
                    {d.defaultRate12mPct.toFixed(1)}%
                  </td>
                  <td className="text-right font-mono-numbers">{d.voluntaryTerminationPct.toFixed(1)}%</td>
                  <td className="text-right font-mono-numbers text-[#3fb950] font-bold">
                    {d.rarocMarginPct.toFixed(1)}%
                  </td>
                  <td className="text-center">
                    {d.fraudAnomalyAlerts > 0 ? (
                      <span className="px-1.5 py-0.2 bg-[#f85149]/20 text-[#f85149] border border-[#f85149] text-[10px] font-bold">
                        {d.fraudAnomalyAlerts} ALERTS
                      </span>
                    ) : (
                      <span className="text-[#3fb950] text-[10px]">0</span>
                    )}
                  </td>
                  <td className="text-right">
                    <span className={`px-1.5 py-0.2 text-[10px] font-bold border ${
                      d.riskRating === 'TIER_1_PREFERRED' ? 'bg-[#3fb950]/20 text-[#3fb950] border-[#3fb950]' :
                      d.riskRating === 'TIER_2_STANDARD' ? 'bg-[#388bfd]/20 text-[#388bfd] border-[#388bfd]' :
                      'bg-[#f85149]/20 text-[#f85149] border-[#f85149]'
                    }`}>
                      {d.riskRating.replace('TIER_', 'T-')}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Selected Dealer Anomaly Investigation Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-6 bg-[#11151c] border border-[#21262d] p-3 space-y-2 font-mono text-[11px]">
          <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
            <span>DEALER PROFILE: {activeDealer.name}</span>
            <span className="text-[10px] text-[#8b949e]">{activeDealer.id}</span>
          </div>
          <div className="space-y-1.5 divide-y divide-[#161b22]">
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">Active Financed Contracts:</span>
              <span className="text-white font-bold">{activeDealer.activeLoanCount.toLocaleString()} loans</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">Early Settlement Velocity:</span>
              <span className="text-white">{activeDealer.earlySettlementPct.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">Early Voluntary Termination (s.99):</span>
              <span className={activeDealer.voluntaryTerminationPct > 6.0 ? 'text-[#f85149] font-bold' : 'text-white'}>
                {activeDealer.voluntaryTerminationPct.toFixed(1)}%
              </span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#8b949e]">Risk-Adjusted Margin (RAROC):</span>
              <span className="text-[#3fb950] font-bold">+{activeDealer.rarocMarginPct.toFixed(2)}%</span>
            </div>
          </div>
        </div>

        <div className="lg:col-span-6 bg-[#11151c] border border-[#21262d] p-3 space-y-2 font-mono text-[11px]">
          <div className="font-mono text-xs font-bold text-white flex items-center justify-between border-b border-[#21262d] pb-1.5">
            <span className="flex items-center text-[#d29922]">
              <ShieldAlert className="w-3.5 h-3.5 mr-1" />
              FRAUD / ANOMALY AUDIT TRAIL
            </span>
            <span className="text-[10px] text-[#8b949e]">HUMAN-IN-THE-LOOP VERIFICATION</span>
          </div>

          {activeDealer.fraudAnomalyAlerts > 0 ? (
            <div className="space-y-2 pt-1">
              <div className="p-2 bg-[#0b0e14] border-l-2 border-[#f85149] border-t border-r border-b border-[#21262d]">
                <div className="text-white font-bold text-[11px]">RAPID APPLICATION CLUSTER DETECTED</div>
                <div className="text-[#8b949e] text-[10px] mt-0.5">
                  12 applications submitted within a 90-minute window featuring identical employer phone numbers. Flagged for fraud underwriting review.
                </div>
              </div>
              <div className="p-2 bg-[#0b0e14] border-l-2 border-[#d29922] border-t border-r border-b border-[#21262d]">
                <div className="text-white font-bold text-[11px]">VEHICLE MILEAGE INCONSISTENCY</div>
                <div className="text-[#8b949e] text-[10px] mt-0.5">
                  Invoice declared 12,000 miles on 2023 derivative vs MOT / HPI database recording 38,500 miles. Dealer audit notice served.
                </div>
              </div>
            </div>
          ) : (
            <div className="py-6 text-center text-[#3fb950]">
              <CheckCircle className="w-6 h-6 mx-auto mb-1 opacity-75" />
              <div>Zero fraud anomaly alerts detected for this dealer franchise.</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
