/**
 * RhinoQuant Auto Finance
 * Institutional Terminal Navigation & Command Bar
 */

import React, { useState, useEffect } from 'react';
import {
  Terminal,
  Activity,
  Search,
  Sliders,
  ShieldAlert,
  HelpCircle,
  FileText,
  Clock,
  Layers,
  Database,
  Briefcase,
  AlertTriangle,
} from 'lucide-react';

interface TerminalHeaderProps {
  currentCommand: string;
  onExecuteCommand: (command: string) => void;
  onOpenCommandPalette: () => void;
  onOpenDataLineage: () => void;
  onOpenReportModal: () => void;
}

export const TerminalHeader: React.FC<TerminalHeaderProps> = ({
  currentCommand,
  onExecuteCommand,
  onOpenCommandPalette,
  onOpenDataLineage,
  onOpenReportModal,
}) => {
  const [commandInput, setCommandInput] = useState(currentCommand);
  const [currentTime, setCurrentTime] = useState<string>('');

  useEffect(() => {
    setCommandInput(currentCommand);
  }, [currentCommand]);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toISOString().replace('T', ' ').substring(0, 19) + ' UTC'
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCmd = commandInput.trim().toUpperCase().replace(/<GO>/g, '').trim();
    if (cleanCmd) {
      onExecuteCommand(cleanCmd);
    }
  };

  const navShortcuts = [
    { label: 'AUTO', cmd: 'AUTO' },
    { label: 'PORT', cmd: 'PORT' },
    { label: 'PRICING', cmd: 'PRICING' },
    { label: 'RISK', cmd: 'RISK' },
    { label: 'ABS', cmd: 'ABS' },
    { label: 'WATERFALL', cmd: 'WATERFALL' },
    { label: 'FUND', cmd: 'FUND' },
    { label: 'STRESS', cmd: 'STRESS' },
    { label: 'MONTE', cmd: 'MONTE' },
    { label: 'DEALER', cmd: 'DEALER' },
    { label: 'MODEL', cmd: 'MODEL' },
    { label: 'REDRESS', cmd: 'REDRESS' },
    { label: 'AUDIT', cmd: 'AUDIT' },
  ];

  return (
    <header className="bg-[#0b0e14] border-b border-[#21262d] select-none text-xs">
      {/* Topmost Institutional Brand & Ticker Ribbon */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-[#161b22] text-[#8b949e]">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5 font-bold tracking-wider text-[#e6edf3]">
            <span className="inline-block w-2 h-2 bg-[#d29922]" />
            <span className="font-mono text-sm tracking-tight text-white font-semibold">
              RHINOQUANT AUTO
            </span>
            <span className="text-[10px] bg-[#161b22] border border-[#30363d] px-1 py-0.2 text-[#d29922] font-mono">
              RQA-PRO v3.8
            </span>
          </div>

          <div className="hidden lg:flex items-center space-x-3 text-[11px] font-mono border-l border-[#21262d] pl-3">
            <span>SONIA 3M: <strong className="text-[#3fb950]">4.70%</strong></span>
            <span>BOE BASE: <strong className="text-white">4.75%</strong></span>
            <span>USED CAR IDX: <strong className="text-[#d29922]">98.4 (-1.6%)</strong></span>
            <span>BEV 36M RESIDUAL: <strong className="text-[#f85149]">48.2% (-6.8%)</strong></span>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="text-[10px] font-mono bg-[#161b22] border border-[#21262d] px-2 py-0.5 text-[#8b949e]">
            DATASET: <span className="text-[#d29922] font-medium">SYNTHETIC / SIMULATED</span> · SEED: 0xRQA_2026
          </div>
          <div className="hidden sm:flex items-center space-x-1 text-[#8b949e] font-mono text-[11px]">
            <Clock className="w-3.5 h-3.5 text-[#6e7681]" />
            <span>{currentTime || '2026-10-12 10:13:30 UTC'}</span>
          </div>
          <button
            onClick={onOpenReportModal}
            className="flex items-center space-x-1 bg-[#161b22] hover:bg-[#21262d] text-[#c9d1d9] border border-[#30363d] px-2 py-0.5 transition-colors"
            title="Institutional Reporting & Export"
          >
            <FileText className="w-3 h-3 text-[#d29922]" />
            <span>REPORT</span>
          </button>
        </div>
      </div>

      {/* Primary Terminal Command Bar & Quick Ribbon */}
      <div className="flex flex-wrap items-center justify-between px-3 py-1.5 gap-2 bg-[#11151c]">
        {/* Command Input Box */}
        <form onSubmit={handleSubmit} className="flex items-center space-x-1">
          <div className="relative flex items-center bg-[#0b0e14] border border-[#30363d] focus-within:border-[#d29922] px-2 py-1">
            <span className="text-[#d29922] font-mono font-bold mr-1.5 text-xs">&gt;</span>
            <input
              type="text"
              value={commandInput}
              onChange={(e) => setCommandInput(e.target.value.toUpperCase())}
              placeholder="ENTER COMMAND (E.G. AUTO, PORT, ABS, STRESS)"
              className="bg-transparent text-white font-mono text-xs focus:outline-none w-56 sm:w-72 uppercase tracking-wide placeholder:text-[#484f58]"
            />
            <button
              type="submit"
              className="bg-[#21262d] hover:bg-[#d29922] hover:text-black text-[#d29922] px-1.5 py-0.5 font-mono text-[10px] font-bold border border-[#30363d] ml-1 transition-colors"
            >
              &lt;GO&gt;
            </button>
          </div>

          <button
            type="button"
            onClick={onOpenCommandPalette}
            className="flex items-center space-x-1 text-[#8b949e] hover:text-white bg-[#161b22] hover:bg-[#21262d] border border-[#21262d] px-2 py-1 transition-colors font-mono text-[11px]"
            title="Open Command Launcher (Ctrl+K)"
          >
            <Search className="w-3 h-3" />
            <span className="hidden sm:inline">PALETTE</span>
            <span className="text-[10px] text-[#6e7681] border border-[#30363d] px-1 ml-0.5">^K</span>
          </button>

          <button
            type="button"
            onClick={onOpenDataLineage}
            className="flex items-center space-x-1 text-[#8b949e] hover:text-white bg-[#161b22] hover:bg-[#21262d] border border-[#21262d] px-2 py-1 transition-colors font-mono text-[11px]"
            title="Inspect Data Lineage & Provenance"
          >
            <Database className="w-3 h-3 text-[#388bfd]" />
            <span className="hidden md:inline">LINEAGE</span>
          </button>
        </form>

        {/* Quick Command Ribbon */}
        <div className="flex items-center space-x-1 overflow-x-auto py-0.5">
          {navShortcuts.map((item) => {
            const isActive = currentCommand.toUpperCase() === item.cmd;
            return (
              <button
                key={item.cmd}
                onClick={() => onExecuteCommand(item.cmd)}
                className={`px-2 py-1 font-mono text-[11px] font-medium transition-colors border ${
                  isActive
                    ? 'bg-[#1f2937] text-[#d29922] border-[#d29922]'
                    : 'bg-[#161b22] text-[#8b949e] hover:text-white hover:bg-[#21262d] border-[#21262d]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
