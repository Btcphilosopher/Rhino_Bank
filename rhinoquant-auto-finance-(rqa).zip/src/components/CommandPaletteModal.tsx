/**
 * RhinoQuant Auto Finance
 * Institutional Command Palette (Ctrl+K Launcher)
 */

import React, { useState, useEffect, useRef } from 'react';
import { Search, Terminal, ArrowRight, X } from 'lucide-react';

interface CommandPaletteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCommand: (command: string) => void;
}

interface CommandItem {
  code: string;
  category: string;
  title: string;
  description: string;
}

const COMMAND_REGISTRY: CommandItem[] = [
  { code: 'AUTO', category: 'COMMAND CENTRE', title: 'Portfolio Command Centre', description: 'Executive summary desk, headline risk, alerts & vintage curves' },
  { code: 'PORT', category: 'PORTFOLIO', title: 'Portfolio Analytics Engine', description: '250k loans, multidimensional vintage/dealer/segment drill-down' },
  { code: 'LOAN', category: 'PORTFOLIO', title: 'Loan Book Explorer', description: 'Inspect loan-level cash flows, voluntary termination & customer equity' },
  { code: 'PRICING', category: 'ORIGINATION', title: 'RAROC Pricing & Rate Sheet', description: 'Capital charge, ECL, funding spread, dynamic rate matrix' },
  { code: 'CREDIT', category: 'ORIGINATION', title: 'Scorecard & Underwriting', description: 'FCA affordability test, positive/negative reason code trails' },
  { code: 'RISK', category: 'RISK ENGINE', title: 'Credit Risk & Roll Rates', description: 'PD models, collateral-adjusted LGD, EAD, transition matrices' },
  { code: 'PD', category: 'RISK ENGINE', title: 'Probability of Default Models', description: '12m, 24m & lifetime logistic hazard functions' },
  { code: 'LGD', category: 'RISK ENGINE', title: 'Collateral & LGD Engine', description: 'Auction proceeds, liquidation costs, battery depreciation haircuts' },
  { code: 'ABS', category: 'CAPITAL MARKETS', title: 'Securitisation Structuring', description: 'Pool eligibility, note tranches (AAA to Residual), credit enhancement' },
  { code: 'WATERFALL', category: 'CAPITAL MARKETS', title: 'Priority of Payments Waterfall', description: 'Deterministic cash flow engine, sequential principal, excess spread' },
  { code: 'FUND', category: 'TREASURY', title: 'Funding & Warehouse Desk', description: 'Barclays £500m facility, advance rates, liquidity covenants' },
  { code: 'STRESS', category: 'RISK ENGINE', title: 'Macro Scenario & Stress Test', description: 'BEV residual shock (-10%/-20%/-30%), recession, unemployment' },
  { code: 'MONTE', category: 'RISK ENGINE', title: 'Portfolio Monte Carlo (VaR)', description: '10,000 vectorised simulations, P50-P99 loss distribution' },
  { code: 'DEALER', category: 'NETWORK', title: 'Dealer Analytics & Anomaly', description: 'Originations volume, 12m default rate, early surrender, fraud alerts' },
  { code: 'MODEL', category: 'GOVERNANCE', title: 'Model Risk Management', description: 'Inventory, validation metrics (AUC, Gini, KS), lifecycle approval' },
  { code: 'REDRESS', category: 'COMPLIANCE', title: 'FCA Motor Finance Redress', description: 'Historical 2007-2024 DCA simulation, 8% statutory interest, rules v2026.2' },
  { code: 'COMPLIANCE', category: 'COMPLIANCE', title: 'Promotion Compliance Checker', description: 'FCA CONC 3 financial promotions validation, representative APR' },
  { code: 'DATA', category: 'TRANSPARENCY', title: 'Data Lineage Inspector', description: 'Trace every quantitative output back to source inputs & models' },
  { code: 'AUDIT', category: 'GOVERNANCE', title: 'Audit Trail & Change Log', description: 'Immutable records of parameter, model, and curve adjustments' },
  { code: 'REPORT', category: 'REPORTING', title: 'Institutional Report Generator', description: 'Export quantitative credit desk summary in JSON/CSV format' },
];

export const CommandPaletteModal: React.FC<CommandPaletteModalProps> = ({
  isOpen,
  onClose,
  onSelectCommand,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setSearchQuery('');
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  const filteredCommands = COMMAND_REGISTRY.filter((cmd) => {
    const q = searchQuery.toLowerCase().trim();
    return (
      cmd.code.toLowerCase().includes(q) ||
      cmd.title.toLowerCase().includes(q) ||
      cmd.category.toLowerCase().includes(q) ||
      cmd.description.toLowerCase().includes(q)
    );
  });

  useEffect(() => {
    setSelectedIndex(0);
  }, [searchQuery]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % Math.max(1, filteredCommands.length));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + filteredCommands.length) % Math.max(1, filteredCommands.length));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredCommands[selectedIndex]) {
        onSelectCommand(filteredCommands[selectedIndex].code);
        onClose();
      }
    } else if (e.key === 'Escape') {
      e.preventDefault();
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 bg-black/75 backdrop-blur-xs p-4">
      <div className="w-full max-w-2xl bg-[#11151c] border border-[#30363d] shadow-2xl flex flex-col max-h-[75vh]">
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3 border-b border-[#21262d] bg-[#0b0e14]">
          <Search className="w-4 h-4 text-[#d29922] mr-2 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type a command or module name (e.g. ABS, STRESS, PRICING, REDRESS)..."
            className="w-full bg-transparent text-white font-mono text-sm focus:outline-none placeholder:text-[#484f58]"
          />
          <button onClick={onClose} className="text-[#8b949e] hover:text-white ml-2">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Command List */}
        <div className="overflow-y-auto divide-y divide-[#161b22] p-1">
          {filteredCommands.length === 0 ? (
            <div className="py-8 text-center text-[#8b949e] font-mono text-xs">
              No terminal command matched &quot;{searchQuery}&quot;
            </div>
          ) : (
            filteredCommands.map((cmd, idx) => {
              const isSelected = idx === selectedIndex;
              return (
                <div
                  key={cmd.code}
                  onClick={() => {
                    onSelectCommand(cmd.code);
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`flex items-center justify-between px-3 py-2 cursor-pointer transition-colors ${
                    isSelected ? 'bg-[#1c2128] border-l-2 border-[#d29922]' : 'hover:bg-[#161b22]'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className="font-mono text-xs font-bold text-[#d29922] bg-[#0b0e14] px-1.5 py-0.5 border border-[#30363d] min-w-[70px] text-center">
                      {cmd.code} &lt;GO&gt;
                    </span>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-white font-medium text-xs">{cmd.title}</span>
                        <span className="text-[10px] text-[#8b949e] uppercase font-mono">{cmd.category}</span>
                      </div>
                      <p className="text-[11px] text-[#8b949e] line-clamp-1">{cmd.description}</p>
                    </div>
                  </div>
                  <ArrowRight className={`w-3.5 h-3.5 ${isSelected ? 'text-[#d29922]' : 'text-transparent'}`} />
                </div>
              );
            })
          )}
        </div>

        {/* Terminal Footer Navigation Hints */}
        <div className="flex items-center justify-between px-3 py-2 bg-[#0b0e14] border-t border-[#21262d] text-[10px] text-[#6e7681] font-mono">
          <div className="flex space-x-3">
            <span>[UP/DOWN] Navigate</span>
            <span>[ENTER] Execute</span>
            <span>[ESC] Dismiss</span>
          </div>
          <span className="text-[#8b949e]">RHINOQUANT TERMINAL LAUNCHER</span>
        </div>
      </div>
    </div>
  );
};
