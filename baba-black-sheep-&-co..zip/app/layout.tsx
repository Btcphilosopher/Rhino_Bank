import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Baba Black Sheep & Co. — The British Wool Emporium',
  description: 'British wool emporium selling exceptional wool, yarn, fleece, cloth, blankets, knitting materials, weaving materials, garments and wool objects. From fleece to object.',
  openGraph: {
    title: 'Baba Black Sheep & Co. — The British Wool Emporium',
    description: 'British wool emporium selling exceptional wool, yarn, fleece, cloth, blankets, knitting materials, weaving materials, garments and wool objects. From fleece to object.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Baba Black Sheep & Co. — The British Wool Emporium',
    description: 'British wool emporium selling exceptional wool, yarn, fleece, cloth, blankets, knitting materials, weaving materials, garments and wool objects. From fleece to object.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600;700;800&family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600&family=JetBrains+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="bg-[#F3F0E8] text-[#191918] antialiased selection:bg-[#30302D] selection:text-[#F3F0E8] min-h-screen font-sans" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
