'use client';

import React from 'react';
import { EmporiumProvider, useEmporium } from '@/lib/store';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import TodayStrip from '@/components/TodayStrip';
import CategoryTiles from '@/components/CategoryTiles';
import WoolExplorer from '@/components/WoolExplorer';
import BreedIndex from '@/components/BreedIndex';
import FeelTheFibre from '@/components/FeelTheFibre';
import ProductGrid from '@/components/ProductGrid';
import TheClothRoom from '@/components/TheClothRoom';
import ColourLibrary from '@/components/ColourLibrary';
import SheepToObject from '@/components/SheepToObject';
import WoolBoard from '@/components/WoolBoard';
import WoolLibrary from '@/components/WoolLibrary';
import InteractiveStudio from '@/components/InteractiveStudio';
import TradeSection from '@/components/TradeSection';
import DigitalWorkbench from '@/components/DigitalWorkbench';
import Footer from '@/components/Footer';

// Modals
import ProductModal from '@/components/modals/ProductModal';
import BreedModal from '@/components/modals/BreedModal';
import TraceabilityModal from '@/components/modals/TraceabilityModal';
import BasketDrawer from '@/components/modals/BasketDrawer';
import SearchModal from '@/components/modals/SearchModal';
import AdminModal from '@/components/modals/AdminModal';
import WorkbenchModal from '@/components/modals/WorkbenchModal';
import TradeModal from '@/components/modals/TradeModal';

function MainApp() {
  const { activeModal } = useEmporium();

  return (
    <div className="min-h-screen bg-[#F3F0E8] text-[#191918] flex flex-col font-sans selection:bg-[#30302D] selection:text-[#F3F0E8]">
      
      {/* Top Bar */}
      <Navbar />

      {/* Main Content Sections */}
      <main className="flex-grow">
        {/* Hero: "THE FIBRE" Macro Experience */}
        <Hero />

        {/* Today at the Emporium Live Lot Strip */}
        <TodayStrip />

        {/* Section 01: Shop the Emporium (Category Tiles) */}
        <CategoryTiles />

        {/* Interactive Material Explorer */}
        <WoolExplorer />

        {/* Section 02: Meet the Flock (14 Breeds) */}
        <BreedIndex />

        {/* Tactile Sensory Mechanics: Feel the Fibre */}
        <FeelTheFibre />

        {/* Section 03: The Catalogue (Products Grid) */}
        <ProductGrid />

        {/* Section 04: The Cloth Room (Bolts & Metres) */}
        <TheClothRoom />

        {/* Section 05: Colour Library (Undyed vs Dyed) */}
        <ColourLibrary />

        {/* Section 06: From Sheep to Object (10-Stage continuum) */}
        <SheepToObject />

        {/* Section 07: The Wool Board (Simulated Auction Board) */}
        <WoolBoard />

        {/* Section 08: The Wool Library (Editorial Articles) */}
        <WoolLibrary />

        {/* Section 09: Yarn Finder & Project Calculator */}
        <InteractiveStudio />

        {/* Section 10: Trade & B2B Specification Engine */}
        <TradeSection />

        {/* Section 11: My Projects Digital Workbench */}
        <DigitalWorkbench />
      </main>

      {/* Editorial Footer */}
      <Footer />

      {/* Active Modals / Drawers */}
      {activeModal === 'product' && <ProductModal />}
      {activeModal === 'breed' && <BreedModal />}
      {activeModal === 'traceability' && <TraceabilityModal />}
      {activeModal === 'cart' && <BasketDrawer />}
      {activeModal === 'search' && <SearchModal />}
      {activeModal === 'admin' && <AdminModal />}
      {activeModal === 'workbench' && <WorkbenchModal />}
      {activeModal === 'trade' && <TradeModal />}
    </div>
  );
}

export default function Home() {
  return (
    <EmporiumProvider>
      <MainApp />
    </EmporiumProvider>
  );
}
