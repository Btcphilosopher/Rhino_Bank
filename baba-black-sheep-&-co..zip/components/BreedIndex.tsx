'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { BREEDS } from '@/lib/data';
import { useEmporium } from '@/lib/store';
import { ArrowRight, Compass } from 'lucide-react';

export default function BreedIndex() {
  const { openModal } = useEmporium();
  const [filterType, setFilterType] = useState<string>('all');

  const filteredBreeds = BREEDS.filter((breed) => {
    if (filterType === 'all') return true;
    if (filterType === 'mountain') {
      return (
        breed.id === 'swaledale' ||
        breed.id === 'herdwick' ||
        breed.id === 'cheviot' ||
        breed.id === 'dalesbred' ||
        breed.id === 'welsh-mountain'
      );
    }
    if (filterType === 'lustre') {
      return (
        breed.id === 'bluefaced-leicester' ||
        breed.id === 'wensleydale' ||
        breed.id === 'teeswater' ||
        breed.id === 'lincoln-longwool' ||
        breed.id === 'masham'
      );
    }
    if (filterType === 'primitive') {
      return (
        breed.id === 'shetland' ||
        breed.id === 'hebridean' ||
        breed.id === 'jacob' ||
        breed.id === 'romney'
      );
    }
    return true;
  });

  return (
    <section id="meet-the-flock" className="bg-[#F3F0E8] py-24 px-4 sm:px-6 lg:px-8 border-b border-[#CDBFA8]/60">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6 pb-6 border-b border-[#CDBFA8]">
          <div>
            <span className="text-xs font-mono tracking-widest text-[#77746F] uppercase block mb-1">
              Section 02 · Provenance & Zoology
            </span>
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-serif text-[#191918] tracking-tight">
              Meet the Flock
            </h2>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <span className="text-xs font-mono text-[#77766F] uppercase">Filter Terrain:</span>
            <div className="flex items-center gap-1 bg-[#E8E0D2] p-1 rounded text-xs font-mono">
              <button
                onClick={() => setFilterType('all')}
                className={`px-3 py-1.5 rounded transition-colors ${
                  filterType === 'all' ? 'bg-[#191918] text-white' : 'text-[#30302D] hover:text-black'
                }`}
              >
                All 14 Breeds
              </button>
              <button
                onClick={() => setFilterType('mountain')}
                className={`px-3 py-1.5 rounded transition-colors ${
                  filterType === 'mountain' ? 'bg-[#191918] text-white' : 'text-[#30302D] hover:text-black'
                }`}
              >
                Mountain & Fell
              </button>
              <button
                onClick={() => setFilterType('lustre')}
                className={`px-3 py-1.5 rounded transition-colors ${
                  filterType === 'lustre' ? 'bg-[#191918] text-white' : 'text-[#30302D] hover:text-black'
                }`}
              >
                Lustre Longwool
              </button>
              <button
                onClick={() => setFilterType('primitive')}
                className={`px-3 py-1.5 rounded transition-colors ${
                  filterType === 'primitive' ? 'bg-[#191918] text-white' : 'text-[#30302D] hover:text-black'
                }`}
              >
                Primitive & Island
              </button>
            </div>
          </div>
        </div>

        {/* Breeds Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredBreeds.map((breed) => (
            <div
              key={breed.id}
              className="group bg-[#E8E0D2]/35 border border-[#CDBFA8] rounded overflow-hidden hover:border-[#191918] transition-all hover:shadow-lg flex flex-col justify-between"
            >
              <div>
                {/* Visual Lockup: Sheep Portrait + Fleece Close-up */}
                <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#30302D]">
                  <Image
                    src={breed.portraitImage}
                    alt={breed.name}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" />
                  
                  {/* Top Breed Tag */}
                  <div className="absolute top-3 left-3 bg-[#191918]/85 text-[#E8E0D2] px-2.5 py-1 rounded font-mono text-[10px] tracking-wider uppercase">
                    {breed.region}
                  </div>

                  {/* Bottom Fibre Specs Overlay */}
                  <div className="absolute bottom-3 left-3 right-3 text-white flex items-end justify-between">
                    <div>
                      <span className="text-[10px] font-mono text-[#CDBFA8] uppercase tracking-wider block">
                        FIBRE MICRON
                      </span>
                      <span className="font-mono text-sm font-bold text-white tabular-nums">
                        {breed.micron}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] font-mono text-[#CDBFA8] uppercase tracking-wider block">
                        STAPLE
                      </span>
                      <span className="font-mono text-sm font-bold text-white tabular-nums">
                        {breed.stapleLength}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Content Details */}
                <div className="p-6">
                  <div className="flex items-baseline justify-between mb-2">
                    <h3 className="font-serif text-2xl font-semibold text-[#191918] group-hover:text-[#A33E32] transition-colors">
                      {breed.name}
                    </h3>
                    <span className="text-xs font-mono text-[#77766F] uppercase">
                      {breed.crimp} Crimp
                    </span>
                  </div>

                  <p className="text-xs text-[#77746F] font-sans leading-relaxed line-clamp-2 mb-4">
                    {breed.story}
                  </p>

                  {/* Attributes metadata chips (unboxed / clean) */}
                  <div className="space-y-1.5 text-xs font-mono text-[#30302D] pt-3 border-t border-[#CDBFA8]/60">
                    <div className="flex justify-between">
                      <span className="text-[#77766F]">Natural Colours:</span>
                      <span className="font-medium text-right truncate max-w-[200px]">
                        {breed.naturalColours.join(', ')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#77766F]">Handle:</span>
                      <span className="font-medium">{breed.handle}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#77766F]">Recommended:</span>
                      <span className="font-medium text-right truncate max-w-[200px]">
                        {breed.recommendedApplications.slice(0, 2).join(' · ')}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Card Footer Action */}
              <div className="p-6 pt-0">
                <button
                  onClick={() => openModal('breed', breed.id)}
                  className="w-full py-2.5 px-4 bg-[#191918] hover:bg-[#A33E32] text-[#F3F0E8] rounded transition-colors text-xs font-mono uppercase tracking-wider flex items-center justify-center gap-2 group/btn font-semibold"
                >
                  <span>Explore Fibre</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
