'use client';

import React, { useState } from 'react';
import { useEmporium } from '@/lib/store';
import { PRODUCTS, Product } from '@/lib/data';
import { Calculator, Sparkles, Compass, Check, ArrowRight, ShoppingBag, FolderPlus } from 'lucide-react';

export default function InteractiveStudio() {
  const { openModal, addToBasket, addProject } = useEmporium();
  const [activeTab, setActiveTab] = useState<'finder' | 'calculator'>('finder');

  // Yarn Finder State
  const [making, setMaking] = useState<string>('JUMPER');
  const [handlePref, setHandlePref] = useState<string>('STRUCTURED');
  const [colourPref, setColourPref] = useState<string>('NATURAL');

  // Calculator State
  const [calcProject, setCalcProject] = useState<'jumper' | 'scarf' | 'blanket' | 'socks'>('jumper');
  const [calcSize, setCalcSize] = useState<'S' | 'M' | 'L' | 'XL'>('M');
  const [calcYarnWeight, setCalcYarnWeight] = useState<'4-ply' | 'DK' | 'Aran' | 'Chunky'>('DK');
  const [customGauge, setCustomGauge] = useState<number>(22); // stitches per 10cm

  // Calculate yarn requirement
  const getRequirement = () => {
    let baseGrams = 600;
    if (calcProject === 'jumper') {
      if (calcSize === 'S') baseGrams = 550;
      if (calcSize === 'M') baseGrams = 650;
      if (calcSize === 'L') baseGrams = 750;
      if (calcSize === 'XL') baseGrams = 850;
    } else if (calcProject === 'scarf') {
      baseGrams = 250;
    } else if (calcProject === 'blanket') {
      baseGrams = 1200;
    } else if (calcProject === 'socks') {
      baseGrams = 100;
    }

    if (calcYarnWeight === 'Chunky') baseGrams *= 1.25;
    if (calcYarnWeight === '4-ply') baseGrams *= 0.85;

    const netBalls = Math.ceil(baseGrams / 100);
    const withAllowance = Math.ceil(netBalls * 1.12); // 12% safety margin
    return {
      netBalls,
      recommendedBalls: withAllowance,
      totalGrams: withAllowance * 100,
      allowancePercent: 12
    };
  };

  const req = getRequirement();

  // Matched yarns for Yarn Finder
  const recommendedYarns = PRODUCTS.filter(p => p.category === 'YARN').slice(0, 3);

  const handleSaveToWorkbench = () => {
    addProject({
      title: `${calcSize} ${calcProject.toUpperCase()} Project`,
      category: `Handknit / ${calcProject}`,
      yarnId: 'prod-y01',
      yarnName: `Baba Swaledale ${calcYarnWeight}`,
      breed: 'Swaledale',
      colour: 'Natural Fell Grey',
      quantityBalls: req.recommendedBalls,
      weightGrams: req.totalGrams,
      status: 'Planning',
      notes: `Calculated with 12% safety allowance. Target gauge: ${customGauge} sts per 10cm.`
    });
    openModal('workbench');
  };

  return (
    <section id="yarn-studio" className="bg-[#E8E0D2] py-24 px-4 sm:px-6 lg:px-8 border-b border-[#CDBFA8]">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6 pb-6 border-b border-[#CDBFA8]/80">
          <div>
            <span className="text-xs font-mono tracking-widest text-[#77746F] uppercase block mb-1">
              Section 09 · Digital Wool Workbench & Calculations
            </span>
            <h2 className="text-4xl sm:text-5xl font-serif text-[#191918] tracking-tight">
              Yarn Finder & Project Calculator
            </h2>
          </div>

          <div className="flex items-center gap-1 bg-[#F3F0E8] p-1 rounded text-xs font-mono border border-[#CDBFA8]">
            <button
              onClick={() => setActiveTab('finder')}
              className={`px-4 py-2 rounded transition-colors uppercase ${
                activeTab === 'finder' ? 'bg-[#191918] text-[#F3F0E8]' : 'text-[#30302D] hover:text-black'
              }`}
            >
              Yarn Discovery Engine
            </button>
            <button
              onClick={() => setActiveTab('calculator')}
              className={`px-4 py-2 rounded transition-colors uppercase ${
                activeTab === 'calculator' ? 'bg-[#191918] text-[#F3F0E8]' : 'text-[#30302D] hover:text-black'
              }`}
            >
              How Much Wool Do I Need?
            </button>
          </div>
        </div>

        {/* Tab 1: Yarn Finder */}
        {activeTab === 'finder' && (
          <div className="bg-[#F3F0E8] border border-[#CDBFA8] rounded p-6 sm:p-10 shadow-sm grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left 3 Questions (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Question 1: What are you making? */}
              <div>
                <label className="text-xs font-mono text-[#77766F] uppercase tracking-wider block mb-2">
                  01. WHAT ARE YOU MAKING?
                </label>
                <div className="flex flex-wrap gap-2 text-xs font-mono">
                  {['JUMPER', 'SCARF', 'BLANKET', 'SOCKS', 'CARDIGAN', 'HOMEWARE'].map((item) => (
                    <button
                      key={item}
                      onClick={() => setMaking(item)}
                      className={`px-3 py-1.5 rounded border transition-colors ${
                        making === item
                          ? 'bg-[#191918] text-white border-[#191918]'
                          : 'bg-[#E8E0D2]/50 text-[#30302D] border-[#CDBFA8] hover:border-[#191918]'
                      }`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>

              {/* Question 2: What handle? */}
              <div>
                <label className="text-xs font-mono text-[#77766F] uppercase tracking-wider block mb-2">
                  02. WHAT HANDLE & TACTILITY DO YOU DESIRE?
                </label>
                <div className="flex flex-wrap gap-2 text-xs font-mono">
                  {['SOFT & DRAPEY', 'STRUCTURED', 'RUSTIC & CRISP', 'LUXURIOUS LUSTRE', 'HEAVY WORKWEAR'].map((h) => (
                    <button
                      key={h}
                      onClick={() => setHandlePref(h)}
                      className={`px-3 py-1.5 rounded border transition-colors ${
                        handlePref === h
                          ? 'bg-[#191918] text-white border-[#191918]'
                          : 'bg-[#E8E0D2]/50 text-[#30302D] border-[#CDBFA8] hover:border-[#191918]'
                      }`}
                    >
                      {h}
                    </button>
                  ))}
                </div>
              </div>

              {/* Question 3: Colour preference */}
              <div>
                <label className="text-xs font-mono text-[#77766F] uppercase tracking-wider block mb-2">
                  03. WHAT COLOUR PHILOSOPHY?
                </label>
                <div className="flex flex-wrap gap-2 text-xs font-mono">
                  {['NATURAL FLEECE', 'EARTH & PEAT', 'VAT DYED INDIGO', 'MOORLAND HEATHER'].map((c) => (
                    <button
                      key={c}
                      onClick={() => setColourPref(c)}
                      className={`px-3 py-1.5 rounded border transition-colors ${
                        colourPref === c
                          ? 'bg-[#191918] text-white border-[#191918]'
                          : 'bg-[#E8E0D2]/50 text-[#30302D] border-[#CDBFA8] hover:border-[#191918]'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-4 text-xs font-mono text-[#77766F] italic">
                Engine query: {making} · {handlePref} · {colourPref}
              </div>

            </div>

            {/* Right Recommended Results (5 cols) */}
            <div className="lg:col-span-5 bg-[#E8E0D2]/40 border border-[#CDBFA8] rounded p-6 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-[#CDBFA8] mb-4">
                  <span className="text-xs font-mono uppercase tracking-wider text-[#191918] font-bold">
                    RECOMMENDED YARNS
                  </span>
                  <span className="text-[11px] font-mono text-[#A33E32] font-semibold">
                    100% MATCH
                  </span>
                </div>

                <div className="space-y-3">
                  {recommendedYarns.map((yarn) => (
                    <div
                      key={yarn.id}
                      onClick={() => openModal('product', yarn.id)}
                      className="group cursor-pointer bg-[#F3F0E8] border border-[#CDBFA8] hover:border-[#191918] p-3 rounded transition-colors"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="text-[10px] font-mono text-[#77766F] uppercase block">
                            {yarn.breed} · {yarn.subCategory}
                          </span>
                          <h4 className="font-serif text-base font-semibold text-[#191918] group-hover:text-[#A33E32] transition-colors">
                            {yarn.name}
                          </h4>
                          <span className="text-xs font-mono text-[#30302D]">
                            {yarn.handle} · {yarn.colourName}
                          </span>
                        </div>
                        <span className="font-mono text-sm font-bold text-[#191918]">
                          £{yarn.price.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-6 mt-6 border-t border-[#CDBFA8]">
                <button
                  onClick={() => openModal('product', recommendedYarns[0].id)}
                  className="w-full py-2.5 bg-[#191918] hover:bg-[#30302D] text-[#F3F0E8] rounded text-xs font-mono uppercase tracking-wider font-semibold transition-colors flex items-center justify-center gap-2"
                >
                  <span>Inspect Optimal Yarn Choice</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

            </div>

          </div>
        )}

        {/* Tab 2: Project Calculator */}
        {activeTab === 'calculator' && (
          <div className="bg-[#F3F0E8] border border-[#CDBFA8] rounded p-6 sm:p-10 shadow-sm grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left Inputs (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Project Type */}
              <div>
                <label className="text-xs font-mono text-[#77766F] uppercase tracking-wider block mb-2">
                  PROJECT PATTERN TYPE:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                  {(['jumper', 'scarf', 'blanket', 'socks'] as const).map((type) => (
                    <button
                      key={type}
                      onClick={() => setCalcProject(type)}
                      className={`py-2 px-3 rounded border capitalize font-semibold transition-colors ${
                        calcProject === type
                          ? 'bg-[#191918] text-white border-[#191918]'
                          : 'bg-[#E8E0D2]/50 text-[#30302D] border-[#CDBFA8] hover:border-[#191918]'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sizing (if applicable) */}
              {calcProject === 'jumper' && (
                <div>
                  <label className="text-xs font-mono text-[#77766F] uppercase tracking-wider block mb-2">
                    GARMENT SIZING (CHEST / FIT):
                  </label>
                  <div className="flex gap-2 text-xs font-mono">
                    {(['S', 'M', 'L', 'XL'] as const).map((sz) => (
                      <button
                        key={sz}
                        onClick={() => setCalcSize(sz)}
                        className={`w-12 py-2 rounded border font-bold transition-colors ${
                          calcSize === sz
                            ? 'bg-[#191918] text-white border-[#191918]'
                            : 'bg-[#E8E0D2]/50 text-[#30302D] border-[#CDBFA8] hover:border-[#191918]'
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Yarn Gauge / Weight */}
              <div>
                <label className="text-xs font-mono text-[#77766F] uppercase tracking-wider block mb-2">
                  YARN WEIGHT SPECIFICATION:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                  {(['4-ply', 'DK', 'Aran', 'Chunky'] as const).map((w) => (
                    <button
                      key={w}
                      onClick={() => setCalcYarnWeight(w)}
                      className={`py-2 px-3 rounded border font-semibold transition-colors ${
                        calcYarnWeight === w
                          ? 'bg-[#191918] text-white border-[#191918]'
                          : 'bg-[#E8E0D2]/50 text-[#30302D] border-[#CDBFA8] hover:border-[#191918]'
                      }`}
                    >
                      {w}
                    </button>
                  ))}
                </div>
              </div>

              {/* Gauge Slider */}
              <div>
                <div className="flex justify-between text-xs font-mono mb-2">
                  <span className="text-[#77766F] uppercase">KNITTING GAUGE TENSION:</span>
                  <span className="font-bold text-[#191918]">{customGauge} sts per 10cm</span>
                </div>
                <input
                  type="range"
                  min="12"
                  max="32"
                  value={customGauge}
                  onChange={(e) => setCustomGauge(Number(e.target.value))}
                  className="w-full accent-[#191918] cursor-pointer"
                />
              </div>

            </div>

            {/* Right Output Card (5 cols) */}
            <div className="lg:col-span-5 bg-[#191918] text-[#F3F0E8] rounded p-6 sm:p-8 flex flex-col justify-between shadow-xl">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-[#30302D] mb-6">
                  <span className="text-[10px] font-mono tracking-widest uppercase text-[#CDBFA8]">
                    ESTIMATED MATERIAL REQUIREMENT
                  </span>
                  <span className="text-xs font-mono text-[#A33E32] font-semibold">
                    12% CONTINGENCY INCLUDED
                  </span>
                </div>

                <div className="mb-6">
                  <span className="text-xs font-mono text-[#77766F] block mb-1">
                    RECOMMENDED PURCHASE:
                  </span>
                  <h3 className="font-serif text-4xl sm:text-5xl font-bold text-white tracking-tight">
                    {req.recommendedBalls} × 100g <span className="text-xl font-normal font-sans text-[#E8E0D2]">Skeins</span>
                  </h3>
                  <span className="text-xs font-mono text-[#CDBFA8] mt-1 block">
                    Total: {req.totalGrams}g ({req.netBalls * 100}g net requirement + {req.allowancePercent}% allowance)
                  </span>
                </div>

                <div className="bg-[#30302D]/60 border border-[#30302D] p-4 rounded text-xs font-mono space-y-2 mb-6 text-[#E8E0D2]">
                  <div className="flex justify-between">
                    <span className="text-[#CDBFA8]">SAMPLE YARN:</span>
                    <span>Baba Swaledale DK (£12.50)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#CDBFA8]">ESTIMATED TOTAL:</span>
                    <span className="font-bold text-white">£{(req.recommendedBalls * 12.50).toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3 pt-6 border-t border-[#30302D]">
                <button
                  onClick={() => addToBasket(PRODUCTS[0], req.recommendedBalls)}
                  className="w-full py-2.5 bg-[#F3F0E8] hover:bg-[#E8E0D2] text-[#191918] font-bold rounded text-xs font-mono uppercase tracking-wider transition-colors flex items-center justify-center gap-2"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>Add {req.recommendedBalls} Skeins to Order</span>
                </button>

                <button
                  onClick={handleSaveToWorkbench}
                  className="w-full py-2.5 border border-[#CDBFA8]/40 hover:bg-[#30302D] text-[#E8E0D2] rounded text-xs font-mono uppercase tracking-wider transition-colors flex items-center justify-center gap-2"
                >
                  <FolderPlus className="w-3.5 h-3.5" />
                  <span>Save to My Projects Workbench</span>
                </button>
              </div>

            </div>

          </div>
        )}

      </div>
    </section>
  );
}
