'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowDown, Play, Pause, Compass, Sparkles } from 'lucide-react';
import { useEmporium } from '@/lib/store';

const STAGES = [
  {
    id: 'fibre',
    name: '01 / FIBRE',
    title: 'The Microscopic Strand',
    spec: '33 μm · High Crimp · Lanolin Shell',
    image: '/images/hero_macro.jpg',
    subtext: 'Individual keratin fibres with natural crimp, lanolin wax, and cellular scales that trap air.',
  },
  {
    id: 'fleece',
    name: '02 / FLEECE',
    title: 'The Sheared Blanket',
    spec: '4.8 kg · Skirted · Yorkshire Dales',
    image: '/images/fleece.jpg',
    subtext: 'Intact mountain fleece harvested in high summer; natural colour variation and grease protection.',
  },
  {
    id: 'yarn',
    name: '03 / YARN',
    title: 'Twist & Tensile Strength',
    spec: 'Worsted Spun · 225m / 100g · Z-Twist',
    image: '/images/yarn.jpg',
    subtext: 'Parallel drafted fibres locked by mechanical twist on Calder Valley spinning frames.',
  },
  {
    id: 'cloth',
    name: '04 / CLOTH',
    title: 'The Woven Membrane',
    spec: '560 GSM · Rapier Looms · Fulling Water',
    image: '/images/cloth.jpg',
    subtext: 'Interlocking warp and weft milled with natural Pennine spring water into windproof tweed.',
  },
  {
    id: 'object',
    name: '05 / OBJECT',
    title: 'The Living Artefact',
    spec: 'Heirloom Grade · 100% Biodegradable',
    image: '/images/sheep.jpg',
    subtext: 'Tailored outerwear, blankets, and architectural upholstery engineered to endure generations.',
  }
];

export default function Hero() {
  const { openModal } = useEmporium();
  const [currentStageIdx, setCurrentStageIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  // Auto cycle every 3.5 seconds
  useEffect(() => {
    if (!isPlaying) return;
    const timer = setInterval(() => {
      setCurrentStageIdx((prev) => (prev + 1) % STAGES.length);
    }, 3800);
    return () => clearInterval(timer);
  }, [isPlaying]);

  const currentStage = STAGES[currentStageIdx];

  return (
    <section id="the-fibre" className="relative w-full min-h-[92vh] bg-[#191918] text-[#F3F0E8] overflow-hidden flex flex-col justify-between">
      
      {/* Background Visual Transition Container */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStage.id}
            initial={{ opacity: 0, scale: 1.08 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
            className="absolute inset-0"
          >
            <Image
              src={currentStage.image}
              alt={currentStage.title}
              fill
              priority
              className="object-cover object-center filter brightness-[0.75] contrast-[1.08]"
              referrerPolicy="no-referrer"
            />
            {/* Architectural subtle grain & gradient scrim */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#191918] via-[#191918]/40 to-black/30 pointer-events-none" />
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Top Technical Metadata Header */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 flex items-center justify-between text-xs font-mono tracking-widest text-[#E8E0D2]/80">
        <div className="flex items-center gap-3">
          <span className="w-2 h-2 rounded-full bg-[#E8E0D2] animate-ping" />
          <span>BABA BLACK SHEEP & CO. / MATERIAL ARCHIVE 01</span>
        </div>
        <div className="hidden sm:flex items-center gap-6">
          <span className="text-[#CDBFA8]">CYCLE: {currentStage.name}</span>
          <span className="border-l border-[#CDBFA8]/40 pl-6 text-[#E8E0D2]">
            {currentStage.spec}
          </span>
        </div>
      </div>

      {/* Main Hero Headline & Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 my-auto w-full">
        <div className="max-w-3xl">
          
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-xs sm:text-sm font-mono tracking-[0.25em] text-[#CDBFA8] uppercase mb-4"
          >
            Fleece to Object · Yorkshire, England
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="text-5xl sm:text-7xl lg:text-8xl font-serif font-light tracking-tight leading-[0.92] text-[#F3F0E8] mb-6"
            style={{ textWrap: 'balance' }}
          >
            WOOL.<br />
            <span className="italic font-serif font-normal text-[#E8E0D2]">IN ALL ITS FORMS.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.4 }}
            className="text-base sm:text-lg text-[#E8E0D2]/90 leading-relaxed font-sans max-w-2xl mb-8"
          >
            British wool, exceptional yarns, textiles and objects — selected with obsessive attention to fibre, breed, and provenance.
          </motion.p>

          {/* Action CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.6 }}
            className="flex flex-wrap items-center gap-4 text-xs font-mono tracking-wider uppercase"
          >
            <a
              href="#shop-emporium"
              className="px-6 py-3.5 bg-[#F3F0E8] text-[#191918] font-bold hover:bg-[#E8E0D2] transition-colors rounded shadow-lg flex items-center gap-2"
            >
              <span>Shop the Emporium</span>
            </a>

            <a
              href="#feel-the-fibre"
              className="px-6 py-3.5 border border-[#F3F0E8]/40 text-[#F3F0E8] hover:bg-[#F3F0E8]/10 transition-colors rounded flex items-center gap-2"
            >
              <Compass className="w-4 h-4" />
              <span>Explore the Fibre</span>
            </a>

            <button
              onClick={() => openModal('calculator')}
              className="px-4 py-3.5 text-[#CDBFA8] hover:text-[#F3F0E8] transition-colors flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Project Calculator</span>
            </button>
          </motion.div>

        </div>
      </div>

      {/* Bottom Architectural Sequence Bar & Stage Scrubber */}
      <div className="relative z-10 w-full border-t border-[#30302D] bg-[#191918]/85 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Stage Buttons */}
          <div className="flex items-center gap-2 sm:gap-4 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
            {STAGES.map((stage, idx) => {
              const isActive = idx === currentStageIdx;
              return (
                <button
                  key={stage.id}
                  onClick={() => {
                    setCurrentStageIdx(idx);
                    setIsPlaying(false);
                  }}
                  className={`text-left px-3 py-1.5 rounded transition-all whitespace-nowrap font-mono text-[11px] uppercase ${
                    isActive
                      ? 'bg-[#30302D] text-[#F3F0E8] border-l-2 border-[#E8E0D2]'
                      : 'text-[#77766F] hover:text-[#CDBFA8]'
                  }`}
                >
                  <span className="block font-semibold">{stage.name}</span>
                  <span className="hidden sm:block text-[9px] text-[#CDBFA8]/60 truncate max-w-[120px]">
                    {stage.title}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Player Controls & Stage Description */}
          <div className="flex items-center gap-4 text-xs font-mono text-[#CDBFA8] shrink-0">
            <span className="hidden lg:inline text-[11px] max-w-sm text-[#E8E0D2]/70 text-right truncate">
              {currentStage.subtext}
            </span>

            <button
              onClick={() => setIsPlaying(!isPlaying)}
              aria-label={isPlaying ? 'Pause material sequence' : 'Play material sequence'}
              className="p-2 border border-[#30302D] hover:border-[#77766F] rounded text-[#E8E0D2] transition-colors"
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            </button>

            <a
              href="#today-strip"
              aria-label="Scroll downward"
              className="p-2 border border-[#30302D] hover:border-[#77766F] rounded text-[#E8E0D2] transition-colors"
            >
              <ArrowDown className="w-3.5 h-3.5 animate-bounce" />
            </a>
          </div>

        </div>
      </div>

    </section>
  );
}
