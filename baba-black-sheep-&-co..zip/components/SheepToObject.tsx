'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { PROCESS_STAGES, ProcessStage } from '@/lib/data';
import { ArrowRight, ChevronRight, MapPin, Wrench } from 'lucide-react';

export default function SheepToObject() {
  const [activeStepIdx, setActiveStepIdx] = useState(0);
  const activeStage = PROCESS_STAGES[activeStepIdx];

  return (
    <section id="sheep-to-object" className="bg-[#191918] text-[#F3F0E8] py-24 px-4 sm:px-6 lg:px-8 border-b border-[#30302D]">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6 pb-6 border-b border-[#30302D]">
          <div>
            <span className="text-xs font-mono tracking-widest text-[#CDBFA8] uppercase block mb-1">
              Section 06 · The Manufacturing Continuum
            </span>
            <h2 className="text-4xl sm:text-5xl font-serif text-[#F3F0E8] tracking-tight">
              From Sheep to Object
            </h2>
          </div>
          <p className="text-sm font-sans text-[#E8E0D2]/80 max-w-md">
            Follow the 10-stage physical metamorphosis: from rugged mountain grazing to sheared blanket, scouring vats, spinning frames, and living architectural object.
          </p>
        </div>

        {/* 10-Stage Horizontal Stepper */}
        <div className="mb-10 overflow-x-auto pb-4 scrollbar-thin">
          <div className="flex items-center min-w-max gap-2">
            {PROCESS_STAGES.map((stage, idx) => {
              const isActive = idx === activeStepIdx;
              return (
                <button
                  key={stage.step}
                  onClick={() => setActiveStepIdx(idx)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded text-xs font-mono tracking-wider uppercase transition-all border ${
                    isActive
                      ? 'bg-[#A33E32] text-white border-[#A33E32] shadow-lg'
                      : 'bg-[#30302D]/60 text-[#CDBFA8] border-[#30302D] hover:bg-[#30302D] hover:text-white'
                  }`}
                >
                  <span className="opacity-70">{stage.step}</span>
                  <span className="font-semibold">{stage.title}</span>
                  {idx < PROCESS_STAGES.length - 1 && (
                    <ChevronRight className="w-3 h-3 opacity-40 ml-1" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Expanded Stage Stage Showcase */}
        <div className="bg-[#30302D]/40 border border-[#30302D] rounded p-6 sm:p-10 shadow-2xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Column: Visual Asset Frame (7 cols) */}
          <div className="lg:col-span-7">
            <div className="relative aspect-[16/10] w-full rounded overflow-hidden bg-black border border-[#30302D]">
              <Image
                src={activeStage.image}
                alt={activeStage.title}
                fill
                className="object-cover transition-transform duration-700 filter brightness-[0.88]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              
              <div className="absolute top-4 left-4 bg-[#191918]/90 text-[#E8E0D2] px-3 py-1 rounded text-xs font-mono tracking-widest uppercase">
                STAGE {activeStage.step} OF 10 · {activeStage.title.toUpperCase()}
              </div>

              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs font-mono text-[#CDBFA8]">
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#A33E32]" />
                  <span>{activeStage.location}</span>
                </div>
                <span>MATERIAL ASSAY PASSED</span>
              </div>
            </div>
          </div>

          {/* Right Column: Technical & Narrative Explanation (5 cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between h-full">
            <div>
              <span className="text-[11px] font-mono text-[#A33E32] font-semibold tracking-widest uppercase block mb-1">
                PROCESS SPECIFICATION
              </span>

              <h3 className="font-serif text-3xl sm:text-4xl font-bold text-white mb-2">
                {activeStage.title}
              </h3>

              <p className="text-sm font-mono text-[#CDBFA8] mb-6">
                {activeStage.subtitle}
              </p>

              <div className="space-y-4 text-sm font-sans text-[#E8E0D2] leading-relaxed mb-6">
                <p>{activeStage.description}</p>
              </div>

              {/* Technical Note Callout Box */}
              <div className="bg-[#191918] border border-[#30302D] p-4 rounded text-xs font-mono text-[#CDBFA8]">
                <div className="flex items-center gap-2 text-white font-bold mb-1">
                  <Wrench className="w-3.5 h-3.5 text-[#A33E32]" />
                  <span>TECHNICAL TOLERANCE & CONTROL:</span>
                </div>
                <p className="text-[#E8E0D2]/90 mt-1 leading-normal">
                  {activeStage.technicalNote}
                </p>
              </div>
            </div>

            {/* Stepper Navigation Buttons */}
            <div className="flex items-center justify-between pt-6 mt-6 border-t border-[#30302D]">
              <button
                disabled={activeStepIdx === 0}
                onClick={() => setActiveStepIdx(prev => Math.max(0, prev - 1))}
                className="px-4 py-2 border border-[#30302D] hover:border-[#77766F] disabled:opacity-30 disabled:pointer-events-none rounded text-xs font-mono uppercase tracking-wider text-[#E8E0D2] transition-colors"
              >
                &larr; Previous Stage
              </button>

              <span className="text-xs font-mono text-[#77746F]">
                {activeStepIdx + 1} / 10
              </span>

              <button
                disabled={activeStepIdx === PROCESS_STAGES.length - 1}
                onClick={() => setActiveStepIdx(prev => Math.min(PROCESS_STAGES.length - 1, prev + 1))}
                className="px-4 py-2 bg-[#F3F0E8] hover:bg-[#E8E0D2] disabled:opacity-30 disabled:pointer-events-none text-[#191918] rounded text-xs font-mono uppercase tracking-wider font-semibold transition-colors"
              >
                Next Stage &rarr;
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
