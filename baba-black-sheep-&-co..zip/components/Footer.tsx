'use client';

import React from 'react';
import { useEmporium } from '@/lib/store';
import { ShieldCheck, MapPin, Feather, Compass, Sparkles } from 'lucide-react';

export default function Footer() {
  const { openModal } = useEmporium();

  return (
    <footer className="bg-[#191918] text-[#F3F0E8] border-t border-[#30302D] pt-20 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Top Wordmark & Manifesto Block */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pb-16 border-b border-[#30302D]">
          
          <div className="lg:col-span-5 space-y-4">
            <span className="font-display text-2xl sm:text-3xl font-bold tracking-[0.15em] text-white uppercase block">
              BABA BLACK SHEEP
              <span className="block text-xl text-[#CDBFA8] tracking-[0.2em]">& CO.</span>
            </span>

            <p className="text-sm font-sans text-[#E8E0D2]/80 leading-relaxed max-w-sm">
              The British Wool Emporium. An extraordinary material archive and contemporary digital merchant dedicated to wool in all its physical forms — from fleece to finished object.
            </p>

            <div className="pt-2 text-xs font-mono text-[#77766F] space-y-1">
              <div>BRADFORD TEXTILE EXCHANGE ARCHIVE</div>
              <div>CALDER VALLEY · WEST YORKSHIRE · ENGLAND</div>
            </div>
          </div>

          {/* Nav columns */}
          <div className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-3 gap-8 text-xs font-mono">
            
            {/* Col 1 */}
            <div>
              <span className="text-[#CDBFA8] font-bold uppercase tracking-wider block mb-4">
                THE EMPORIUM
              </span>
              <ul className="space-y-2.5 text-[#E8E0D2]/80">
                <li><a href="#the-fibre" className="hover:text-white transition-colors">The Fibre Hero</a></li>
                <li><a href="#meet-the-flock" className="hover:text-white transition-colors">Meet the Flock</a></li>
                <li><a href="#shop-emporium" className="hover:text-white transition-colors">Yarns & Fleeces</a></li>
                <li><a href="#the-cloth-room" className="hover:text-white transition-colors">The Cloth Room</a></li>
                <li><a href="#colour-library" className="hover:text-white transition-colors">Colour Library</a></li>
                <li><a href="#sheep-to-object" className="hover:text-white transition-colors">Sheep to Object</a></li>
              </ul>
            </div>

            {/* Col 2 */}
            <div>
              <span className="text-[#CDBFA8] font-bold uppercase tracking-wider block mb-4">
                INTERACTIVE TOOLS
              </span>
              <ul className="space-y-2.5 text-[#E8E0D2]/80">
                <li><a href="#feel-the-fibre" className="hover:text-white transition-colors">Feel the Fibre</a></li>
                <li><a href="#yarn-studio" className="hover:text-white transition-colors">Yarn Finder Engine</a></li>
                <li><a href="#yarn-studio" className="hover:text-white transition-colors">Project Calculator</a></li>
                <li><a href="#the-wool-board" className="hover:text-white transition-colors">The Wool Board</a></li>
                <li>
                  <button onClick={() => openModal('workbench')} className="hover:text-white transition-colors text-left">
                    My Projects Workbench
                  </button>
                </li>
                <li>
                  <button onClick={() => openModal('trade')} className="hover:text-white transition-colors text-left">
                    Order Sample Library
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 3 */}
            <div>
              <span className="text-[#CDBFA8] font-bold uppercase tracking-wider block mb-4">
                COMMERCE & ADMIN
              </span>
              <ul className="space-y-2.5 text-[#E8E0D2]/80">
                <li>
                  <button onClick={() => openModal('cart')} className="hover:text-white transition-colors text-left">
                    Merchant Order Sheet
                  </button>
                </li>
                <li>
                  <button onClick={() => openModal('trade')} className="hover:text-white transition-colors text-left">
                    B2B Trade Portal
                  </button>
                </li>
                <li>
                  <button onClick={() => openModal('admin')} className="hover:text-white transition-colors text-left text-[#A33E32]">
                    Merchant Console
                  </button>
                </li>
                <li><a href="#wool-library" className="hover:text-white transition-colors">The Wool Library</a></li>
              </ul>
            </div>

          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between text-xs font-mono text-[#77766F] gap-4">
          <div>
            &copy; {new Date().getFullYear()} Baba Black Sheep & Co. All rights reserved.
          </div>
          
          <div className="text-center md:text-right text-[11px] text-[#CDBFA8]/60">
            SIMULATED DEMONSTRATION PLATFORM · BRITISH WOOL EMPORIUM PROTOTYPE
          </div>
        </div>

      </div>
    </footer>
  );
}
