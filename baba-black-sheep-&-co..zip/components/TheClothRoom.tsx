'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useEmporium } from '@/lib/store';
import { Product, PRODUCTS } from '@/lib/data';
import { Scissors, ShoppingBag, ArrowUpRight, Check, Ruler } from 'lucide-react';

export default function TheClothRoom() {
  const { addToBasket, openModal } = useEmporium();
  const clothProducts = PRODUCTS.filter(p => p.category === 'CLOTH');

  const [selectedMetres, setSelectedMetres] = useState<Record<string, number>>({
    'prod-c01': 2.5,
    'prod-c02': 1.8,
    'prod-c03': 3.0,
    'prod-c04': 2.0,
  });

  const [addedNotice, setAddedNotice] = useState<string | null>(null);

  const handleMetreChange = (id: string, delta: number) => {
    setSelectedMetres(prev => {
      const current = prev[id] || 1.0;
      const next = Math.max(0.5, Math.round((current + delta) * 10) / 10);
      return { ...prev, [id]: next };
    });
  };

  const handleCutAndAdd = (product: Product) => {
    const metres = selectedMetres[product.id] || 1.0;
    addToBasket(product, Math.round(metres), undefined, metres);
    setAddedNotice(product.id);
    setTimeout(() => setAddedNotice(null), 1800);
  };

  return (
    <section id="the-cloth-room" className="bg-[#F3F0E8] py-24 px-4 sm:px-6 lg:px-8 border-b border-[#CDBFA8]/60">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6 pb-6 border-b border-[#CDBFA8]">
          <div>
            <span className="text-xs font-mono tracking-widest text-[#77746F] uppercase block mb-1">
              Section 05 · Architectural Textiles & Loom Archive
            </span>
            <h2 className="text-4xl sm:text-5xl font-serif text-[#191918] tracking-tight">
              The Cloth Room
            </h2>
          </div>
          <p className="text-sm font-sans text-[#77766F] max-w-md">
            Heavyweight tweeds, 680 GSM upholstery cloths, and teasel-brushed blankets cut straight from Yorkshire and Cumbrian bolts.
          </p>
        </div>

        {/* Cloth Bolts Horizontal Shelf Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {clothProducts.map((cloth) => {
            const metres = selectedMetres[cloth.id] || 1.0;
            const totalPrice = cloth.price * metres;
            const isAdded = addedNotice === cloth.id;

            return (
              <div
                key={cloth.id}
                className="group bg-[#E8E0D2]/35 border border-[#CDBFA8] rounded overflow-hidden hover:border-[#191918] transition-all hover:shadow-md flex flex-col justify-between"
              >
                <div>
                  {/* Big Architectural Cloth Image */}
                  <div
                    onClick={() => openModal('product', cloth.id)}
                    className="relative aspect-[16/9] w-full bg-[#30302D] cursor-pointer overflow-hidden"
                  >
                    <Image
                      src={cloth.images[0]}
                      alt={cloth.name}
                      fill
                      className="object-cover group-hover:scale-103 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                    
                    <div className="absolute top-3 left-3 bg-[#191918]/85 text-[#E8E0D2] px-2.5 py-1 rounded text-[10px] font-mono tracking-wider uppercase">
                      LOT {cloth.lotNumber}
                    </div>

                    <div className="absolute bottom-3 left-3 right-3 text-white flex justify-between items-end">
                      <div>
                        <span className="text-[10px] font-mono text-[#CDBFA8] uppercase tracking-wider block">
                          WEAVE / FABRIC
                        </span>
                        <span className="font-serif text-lg font-bold text-white">
                          {cloth.subCategory}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] font-mono text-[#CDBFA8] uppercase tracking-wider block">
                          WEIGHT (GSM)
                        </span>
                        <span className="font-mono text-sm font-bold text-white tabular-nums">
                          {cloth.technical.gsm || 560} GSM
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Cloth Specifications Sheet */}
                  <div className="p-6">
                    <div className="flex items-baseline justify-between mb-2">
                      <h3
                        onClick={() => openModal('product', cloth.id)}
                        className="font-serif text-2xl font-semibold text-[#191918] group-hover:text-[#A33E32] transition-colors cursor-pointer"
                      >
                        {cloth.name}
                      </h3>
                      <span className="font-mono text-base font-bold text-[#191918] tabular-nums">
                        £{cloth.price.toFixed(2)} <span className="text-xs text-[#77766F] font-normal">/ metre</span>
                      </span>
                    </div>

                    <p className="text-xs text-[#77746F] font-sans leading-relaxed mb-4">
                      {cloth.description}
                    </p>

                    {/* Unboxed Technical Parameters */}
                    <div className="grid grid-cols-2 gap-y-2 py-3 border-y border-[#CDBFA8]/60 text-xs font-mono text-[#30302D]">
                      <div>
                        <span className="text-[#77766F]">BOLT WIDTH:</span>{' '}
                        <span className="font-medium">{cloth.technical.widthMm || 1500} mm</span>
                      </div>
                      <div>
                        <span className="text-[#77766F]">COMPOSITION:</span>{' '}
                        <span className="font-medium">100% British Wool</span>
                      </div>
                      <div>
                        <span className="text-[#77766F]">BREED:</span>{' '}
                        <span className="font-medium">{cloth.breed}</span>
                      </div>
                      <div>
                        <span className="text-[#77766F]">ORIGIN:</span>{' '}
                        <span className="font-medium">{cloth.origin}</span>
                      </div>
                      <div className="col-span-2">
                        <span className="text-[#77766F]">END USE:</span>{' '}
                        <span className="font-medium">{cloth.applications.join(' · ')}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Metre Selector & Add Cut Length */}
                <div className="p-6 pt-0 bg-[#E8E0D2]/20">
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4">
                    
                    {/* Stepper */}
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-mono text-[#77766F] uppercase">Length:</span>
                      <div className="flex items-center border border-[#CDBFA8] bg-[#F3F0E8] rounded overflow-hidden text-xs font-mono">
                        <button
                          onClick={() => handleMetreChange(cloth.id, -0.5)}
                          className="px-2.5 py-1.5 hover:bg-[#E8E0D2] transition-colors font-bold"
                          aria-label="Decrease metre length"
                        >
                          -
                        </button>
                        <span className="px-3 py-1.5 font-bold tabular-nums">
                          {metres.toFixed(1)} M
                        </span>
                        <button
                          onClick={() => handleMetreChange(cloth.id, 0.5)}
                          className="px-2.5 py-1.5 hover:bg-[#E8E0D2] transition-colors font-bold"
                          aria-label="Increase metre length"
                        >
                          +
                        </button>
                      </div>
                      <span className="text-xs font-mono font-bold text-[#191918] tabular-nums">
                        = £{totalPrice.toFixed(2)}
                      </span>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      <button
                        onClick={() => openModal('trade')}
                        className="px-3 py-2 border border-[#CDBFA8] hover:border-[#191918] text-[#30302D] rounded text-xs font-mono uppercase tracking-wider transition-colors"
                        title="Request trade swatch"
                      >
                        Sample
                      </button>

                      <button
                        onClick={() => handleCutAndAdd(cloth)}
                        className={`flex-1 sm:flex-none px-4 py-2 rounded text-xs font-mono uppercase tracking-wider font-semibold transition-colors flex items-center justify-center gap-1.5 ${
                          isAdded ? 'bg-[#4D5847] text-white' : 'bg-[#191918] hover:bg-[#30302D] text-[#F3F0E8]'
                        }`}
                      >
                        {isAdded ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Cut Reserved</span>
                          </>
                        ) : (
                          <>
                            <Scissors className="w-3.5 h-3.5" />
                            <span>Order Cut Metres</span>
                          </>
                        )}
                      </button>
                    </div>

                  </div>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
