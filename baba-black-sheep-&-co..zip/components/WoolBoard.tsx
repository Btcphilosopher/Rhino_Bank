'use client';

import React from 'react';
import { WOOL_BOARD_DATA } from '@/lib/data';
import { TrendingUp, TrendingDown, Minus, AlertCircle, BarChart3 } from 'lucide-react';

export default function WoolBoard() {
  return (
    <section id="the-wool-board" className="bg-[#191918] text-[#F3F0E8] py-20 px-4 sm:px-6 lg:px-8 border-b border-[#30302D]">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4 pb-6 border-b border-[#30302D]">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2 h-2 rounded-full bg-[#A33E32] animate-ping" />
              <span className="text-xs font-mono tracking-widest text-[#CDBFA8] uppercase">
                Section 07 · Internal Commodity Assay
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-[#F3F0E8] tracking-tight">
              The Wool Board
            </h2>
          </div>

          <div className="flex items-center gap-2 bg-[#30302D]/60 border border-[#30302D] px-3 py-1.5 rounded text-xs font-mono text-[#CDBFA8]">
            <AlertCircle className="w-3.5 h-3.5 text-[#B28A35]" />
            <span>SIMULATED MARKET DATA · HISTORIC BRADFORD AUCTION INDEX</span>
          </div>
        </div>

        {/* Board Table */}
        <div className="bg-[#30302D]/30 border border-[#30302D] rounded overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="bg-[#191918] border-b border-[#30302D] text-[#77766F] uppercase tracking-wider text-[11px]">
                  <th className="py-4 px-6">Grade / Category</th>
                  <th className="py-4 px-6">Fibre Range & Breeds</th>
                  <th className="py-4 px-6 text-right">Price / KG</th>
                  <th className="py-4 px-6 text-center">24h Shift</th>
                  <th className="py-4 px-6 text-right">Bale Volume</th>
                  <th className="py-4 px-6">Index Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#30302D]/60 text-sm">
                {WOOL_BOARD_DATA.map((row) => {
                  const isUp = row.trend === 'up';
                  const isDown = row.trend === 'down';

                  return (
                    <tr key={row.id} className="hover:bg-[#30302D]/50 transition-colors">
                      <td className="py-4 px-6">
                        <span className="font-serif text-lg font-semibold text-white block">
                          {row.grade}
                        </span>
                        <span className="text-[11px] font-mono text-[#CDBFA8]">
                          LOT GROUP {row.id.toUpperCase()}
                        </span>
                      </td>

                      <td className="py-4 px-6 text-xs text-[#E8E0D2]">
                        <span className="block font-sans">{row.description}</span>
                        <span className="text-[#77766F] text-[11px] font-mono">
                          Dominant: {row.dominantBreeds.join(', ')}
                        </span>
                      </td>

                      <td className="py-4 px-6 text-right font-mono font-bold text-white text-base tabular-nums">
                        £{row.pricePerKg.toFixed(2)}
                      </td>

                      <td className="py-4 px-6 text-center font-mono font-semibold tabular-nums">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs ${
                            isUp
                              ? 'text-[#68D391] bg-[#22543D]/40'
                              : isDown
                              ? 'text-[#FC8181] bg-[#742A2A]/40'
                              : 'text-[#E8E0D2] bg-[#30302D]'
                          }`}
                        >
                          {isUp && <TrendingUp className="w-3.5 h-3.5" />}
                          {isDown && <TrendingDown className="w-3.5 h-3.5" />}
                          {!isUp && !isDown && <Minus className="w-3.5 h-3.5" />}
                          <span>{row.change > 0 ? `+${row.change}%` : `${row.change}%`}</span>
                        </span>
                      </td>

                      <td className="py-4 px-6 text-right font-mono text-[#CDBFA8] tabular-nums">
                        {row.volumeBales.toLocaleString()} Bales
                      </td>

                      <td className="py-4 px-6 text-xs text-[#77766F] font-mono">
                        {row.updatedAt}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Footer note */}
          <div className="p-4 bg-[#191918] border-t border-[#30302D] flex flex-col sm:flex-row items-center justify-between text-[11px] font-mono text-[#77766F] gap-2">
            <span>
              All auctions conducted in accordance with historical British Wool Marketing Board grading standards.
            </span>
            <span className="text-[#CDBFA8]">
              SIMULATED MARKET DATA — FOR ARCHIVAL & EDUCATIONAL DEMO ONLY
            </span>
          </div>
        </div>

      </div>
    </section>
  );
}
