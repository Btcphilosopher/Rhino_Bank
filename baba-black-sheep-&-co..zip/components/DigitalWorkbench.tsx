'use client';

import React, { useState } from 'react';
import { useEmporium } from '@/lib/store';
import { FolderKanban, Plus, Trash2, CheckCircle, Clock, BookOpen, ExternalLink } from 'lucide-react';

export default function DigitalWorkbench() {
  const { projects, addProject, updateProjectStatus, deleteProject, openModal } = useEmporium();
  const [showAddForm, setShowAddForm] = useState(false);

  // Form states
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Garment / Cardigan');
  const [yarnName, setYarnName] = useState('Baba Swaledale DK');
  const [breed, setBreed] = useState('Swaledale');
  const [colour, setColour] = useState('Natural Fell Grey');
  const [quantityBalls, setQuantityBalls] = useState(7);
  const [notes, setNotes] = useState('');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;
    addProject({
      title,
      category,
      yarnId: 'prod-y01',
      yarnName,
      breed,
      colour,
      quantityBalls,
      weightGrams: quantityBalls * 100,
      status: 'Planning',
      notes: notes || 'Calculated project tension and requirements.',
    });
    setTitle('');
    setNotes('');
    setShowAddForm(false);
  };

  return (
    <section id="digital-workbench" className="bg-[#E8E0D2] py-24 px-4 sm:px-6 lg:px-8 border-b border-[#CDBFA8]">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6 pb-6 border-b border-[#CDBFA8]/80">
          <div>
            <span className="text-xs font-mono tracking-widest text-[#77746F] uppercase block mb-1">
              Section 11 · Maker Atelier & Digital Tool
            </span>
            <h2 className="text-4xl sm:text-5xl font-serif text-[#191918] tracking-tight">
              My Projects Workbench
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-4 py-2.5 bg-[#191918] hover:bg-[#30302D] text-[#F3F0E8] rounded text-xs font-mono uppercase tracking-wider font-semibold transition-colors flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>{showAddForm ? 'Close Project Creator' : 'New Wool Project'}</span>
            </button>
          </div>
        </div>

        {/* Add Project Form (Collapse) */}
        {showAddForm && (
          <div className="mb-10 bg-[#F3F0E8] border border-[#CDBFA8] p-6 sm:p-8 rounded shadow-sm">
            <h3 className="font-serif text-2xl font-bold text-[#191918] mb-4">
              Initialize New Wool Project
            </h3>
            <form onSubmit={handleCreate} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs font-mono">
              <div>
                <label className="text-[#77766F] uppercase block mb-1">PROJECT TITLE:</label>
                <input
                  type="text"
                  placeholder="e.g. Cabled Aran Sweater"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2.5 text-[#191918] outline-none focus:border-[#191918]"
                  required
                />
              </div>

              <div>
                <label className="text-[#77766F] uppercase block mb-1">CATEGORY:</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2.5 text-[#191918] outline-none focus:border-[#191918]"
                >
                  <option value="Garment / Jumper">Garment / Jumper</option>
                  <option value="Garment / Cardigan">Garment / Cardigan</option>
                  <option value="Accessory / Scarf">Accessory / Scarf</option>
                  <option value="Home / Blanket">Home / Blanket</option>
                  <option value="Home / Cushion">Home / Cushion</option>
                  <option value="Textile Art / Weaving">Textile Art / Weaving</option>
                </select>
              </div>

              <div>
                <label className="text-[#77766F] uppercase block mb-1">YARN / FIBRE:</label>
                <select
                  value={yarnName}
                  onChange={(e) => setYarnName(e.target.value)}
                  className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2.5 text-[#191918] outline-none focus:border-[#191918]"
                >
                  <option value="Baba Swaledale DK">Baba Swaledale DK</option>
                  <option value="Bluefaced Leicester 4-Ply">Bluefaced Leicester 4-Ply</option>
                  <option value="Herdwick Heavy Aran">Herdwick Heavy Aran</option>
                  <option value="Hebridean Raw Single-Origin Aran">Hebridean Raw Aran</option>
                  <option value="Cheviot Spring Tweed DK">Cheviot Spring Tweed DK</option>
                  <option value="Wensleydale Worsted Ringlet Lace">Wensleydale Ringlet Lace</option>
                </select>
              </div>

              <div>
                <label className="text-[#77766F] uppercase block mb-1">QUANTITY SKEINS (100G):</label>
                <input
                  type="number"
                  min="1"
                  max="50"
                  value={quantityBalls}
                  onChange={(e) => setQuantityBalls(Number(e.target.value))}
                  className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2.5 text-[#191918] outline-none focus:border-[#191918]"
                />
              </div>

              <div className="sm:col-span-2 lg:col-span-4">
                <label className="text-[#77766F] uppercase block mb-1">PATTERN NOTES & GAUGE:</label>
                <input
                  type="text"
                  placeholder="Needle size, gauge notes, pattern link..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2.5 text-[#191918] outline-none focus:border-[#191918]"
                />
              </div>

              <div className="sm:col-span-2 lg:col-span-4 flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 border border-[#CDBFA8] rounded text-xs font-mono uppercase"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-[#A33E32] text-white rounded text-xs font-mono uppercase font-bold"
                >
                  Save Project to Workbench
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Existing Projects Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((proj) => (
            <div
              key={proj.id}
              className="bg-[#F3F0E8] border border-[#CDBFA8] rounded p-6 shadow-sm flex flex-col justify-between hover:border-[#191918] transition-colors"
            >
              <div>
                <div className="flex items-center justify-between text-[11px] font-mono pb-3 border-b border-[#CDBFA8]/60 mb-3">
                  <span className="text-[#77766F] uppercase">{proj.category}</span>
                  <span className="text-[10px] text-[#A33E32] font-semibold">{proj.createdAt}</span>
                </div>

                <h3 className="font-serif text-2xl font-bold text-[#191918] mb-2 leading-tight">
                  {proj.title}
                </h3>

                <div className="space-y-1.5 text-xs font-mono text-[#30302D] mb-4">
                  <div className="flex justify-between">
                    <span className="text-[#77766F]">YARN SPEC:</span>
                    <span className="font-medium text-right">{proj.yarnName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#77766F]">BREED:</span>
                    <span className="font-medium">{proj.breed}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#77766F]">COLOUR:</span>
                    <span className="font-medium">{proj.colour}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#77766F]">REQUIREMENT:</span>
                    <span className="font-bold text-[#191918]">{proj.quantityBalls} × 100g ({proj.weightGrams}g)</span>
                  </div>
                </div>

                {proj.notes && (
                  <p className="text-xs font-sans text-[#77746F] italic bg-[#E8E0D2]/50 p-2.5 rounded mb-4">
                    &ldquo;{proj.notes}&rdquo;
                  </p>
                )}
              </div>

              {/* Status and Actions */}
              <div className="pt-4 border-t border-[#CDBFA8]/60 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-mono text-[#77766F]">STATUS:</span>
                  <select
                    value={proj.status}
                    onChange={(e) => updateProjectStatus(proj.id, e.target.value as any)}
                    className="bg-[#E8E0D2] border border-[#CDBFA8] text-[11px] font-mono rounded px-2 py-1 text-[#191918] focus:outline-none"
                  >
                    <option value="Planning">Planning</option>
                    <option value="Yarn Acquired">Yarn Acquired</option>
                    <option value="On Needles">On Needles</option>
                    <option value="Finishing">Finishing</option>
                    <option value="Archived">Archived</option>
                  </select>
                </div>

                <button
                  onClick={() => deleteProject(proj.id)}
                  className="p-1.5 text-[#77766F] hover:text-[#A33E32] transition-colors"
                  title="Delete project"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
