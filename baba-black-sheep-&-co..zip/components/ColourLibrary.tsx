'use client';

import React, { useState } from 'react';
import { useEmporium } from '@/lib/store';
import { NATURAL_COLOURS, DYED_COLOURS, PRODUCTS } from '@/lib/data';
import { ArrowUpRight, Palette, Sparkles, Check } from 'lucide-react';

export default function ColourLibrary() {
  const { accentTone, setAccentTone, openModal } = useEmporium();
  const [activeTab, setActiveTab] = useState<'natural' | 'dyed'>('natural');
  const [selectedColourName, setSelectedColourName] = useState<string>('Moorland Grey');

  const activePalette = activeTab === 'natural' ? NATURAL_COLOURS : DYED_COLOURS;
  const currentSelection = activePalette.find(c => c.name === selectedColourName) || activePalette[0];

  // Find related yarns for the selected colour
  const relatedProducts = PRODUCTS.filter(p => 
    p.category === 'YARN' && (
      p.colourName.toLowerCase().includes(currentSelection.name.toLowerCase().split(' ')[0]) ||
      p.colourFamily.toLowerCase().includes(currentSelection.name.toLowerCase().split(' ')[0]) ||
      p.isNaturalColour === (activeTab === 'natural')
    )
  ).slice(0, 3);

  const handleSelectColour = (colour: typeof activePalette[0]) => {
    setSelectedColourName(colour.name);
    if ('hex' in colour) {
      setAccentTone(colour.hex);
    }
  };

  return (
    <section id="colour-library" className="bg-[#E8E0D2] py-24 px-4 sm:px-6 lg:px-8 border-b border-[#CDBFA8]">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6 pb-6 border-b border-[#CDBFA8]/80">
          <div>
            <span className="text-xs font-mono tracking-widest text-[#77746F] uppercase block mb-1">
              Section 04 · Chromatic Materiality
            </span>
            <h2 className="text-4xl sm:text-5xl font-serif text-[#191918] tracking-tight">
              {activeTab === 'natural' ? 'Colour from the Sheep' : 'Colour from the Dyehouse'}
            </h2>
          </div>

          {/* Collection Tab Selector */}
          <div className="flex items-center gap-1 bg-[#F3F0E8] p-1 rounded text-xs font-mono border border-[#CDBFA8]">
            <button
              onClick={() => {
                setActiveTab('natural');
                setSelectedColourName(NATURAL_COLOURS[0].name);
              }}
              className={`px-4 py-2 rounded transition-colors uppercase ${
                activeTab === 'natural'
                  ? 'bg-[#191918] text-[#F3F0E8]'
                  : 'text-[#30302D] hover:text-black'
              }`}
            >
              Undyed Natural (Fleece Palette)
            </button>
            <button
              onClick={() => {
                setActiveTab('dyed');
                setSelectedColourName(DYED_COLOURS[0].name);
              }}
              className={`px-4 py-2 rounded transition-colors uppercase ${
                activeTab === 'dyed'
                  ? 'bg-[#191918] text-[#F3F0E8]'
                  : 'text-[#30302D] hover:text-black'
              }`}
            >
              The Dyehouse (Low-Impact)
            </button>
          </div>
        </div>

        {/* Architectural Colour Swatch Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 mb-10">
          {activePalette.map((col) => {
            const isSelected = selectedColourName === col.name;
            return (
              <div
                key={col.name}
                onClick={() => handleSelectColour(col)}
                className={`group cursor-pointer bg-[#F3F0E8] border rounded p-3 transition-all flex flex-col justify-between ${
                  isSelected ? 'border-[#191918] ring-2 ring-[#191918]/20 shadow-md' : 'border-[#CDBFA8] hover:border-[#191918]'
                }`}
              >
                {/* Large Colour Surface */}
                <div
                  className="aspect-[4/3] w-full rounded mb-3 shadow-inner relative flex items-center justify-center transition-transform group-hover:scale-102"
                  style={{ backgroundColor: col.hex }}
                >
                  {isSelected && (
                    <div className="w-5 h-5 rounded-full bg-white/90 text-black flex items-center justify-center shadow">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  )}
                </div>

                <div>
                  <h4 className="font-serif text-sm font-semibold text-[#191918] leading-tight truncate">
                    {col.name}
                  </h4>
                  <p className="text-[10px] font-mono text-[#77766F] uppercase truncate mt-0.5">
                    {'origin' in col ? String((col as any).origin) : 'Dyehouse Master'}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Colour Focus Pane */}
        <div className="bg-[#F3F0E8] border border-[#CDBFA8] rounded p-6 sm:p-10 shadow-sm grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left: Big Colour Field */}
          <div className="lg:col-span-6 flex flex-col justify-between">
            <div className="flex items-center gap-3 text-xs font-mono text-[#77766F] mb-3">
              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: currentSelection.hex }} />
              <span>COLOUR ARCHIVE SPECIFICATION · {currentSelection.name.toUpperCase()}</span>
            </div>

            <div
              className="w-full aspect-[16/9] rounded shadow-inner border border-black/10 relative overflow-hidden p-6 flex flex-col justify-end text-white"
              style={{ backgroundColor: currentSelection.hex }}
            >
              <div className="bg-[#191918]/80 backdrop-blur-sm p-4 rounded max-w-sm">
                <span className="text-[10px] font-mono text-[#CDBFA8] uppercase tracking-wider block">
                  HEX CODE: {currentSelection.hex}
                </span>
                <h3 className="font-serif text-2xl font-bold text-white mt-1">
                  {currentSelection.name}
                </h3>
                <p className="text-xs font-sans text-[#E8E0D2] mt-1 leading-relaxed">
                  {currentSelection.desc}
                </p>
              </div>
            </div>

            <p className="text-xs font-mono text-[#77766F] mt-4">
              Clicking dyed colours synchronises the emporium accent tint.
            </p>
          </div>

          {/* Right: Available Materials in This Shade */}
          <div className="lg:col-span-6 border-t lg:border-t-0 lg:border-l border-[#CDBFA8] lg:pl-8">
            <div className="flex items-center justify-between pb-3 border-b border-[#CDBFA8] mb-4">
              <span className="text-xs font-mono uppercase tracking-wider text-[#191918] font-bold">
                COMPATIBLE YARNS & CLOTHS
              </span>
              <span className="text-[11px] font-mono text-[#77766F]">
                IN THIS COLOUR REGISTER
              </span>
            </div>

            <div className="space-y-4">
              {relatedProducts.map((p) => (
                <div
                  key={p.id}
                  onClick={() => openModal('product', p.id)}
                  className="group cursor-pointer bg-[#E8E0D2]/40 hover:bg-[#E8E0D2] border border-[#CDBFA8] p-3 rounded flex items-center justify-between transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded shrink-0 border border-black/10"
                      style={{ backgroundColor: p.colourHex }}
                    />
                    <div>
                      <h4 className="font-serif text-base font-semibold text-[#191918] group-hover:text-[#A33E32] transition-colors leading-tight">
                        {p.name}
                      </h4>
                      <p className="text-[11px] font-mono text-[#77766F]">
                        {p.breed} · {p.weightGrams ? `${p.weightGrams}g` : p.unit}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="font-mono text-sm font-bold text-[#191918]">
                      £{p.price.toFixed(2)}
                    </span>
                    <span className="block text-[10px] font-mono text-[#A33E32] group-hover:underline">
                      Inspect &rarr;
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 pt-4 border-t border-[#CDBFA8]">
              <button
                onClick={() => {
                  const el = document.querySelector('#shop-emporium');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full py-2.5 bg-[#191918] text-[#F3F0E8] hover:bg-[#30302D] transition-colors rounded text-xs font-mono uppercase tracking-wider font-semibold"
              >
                Browse All Materials in Colour Palette
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
