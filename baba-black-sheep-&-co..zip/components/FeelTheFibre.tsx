'use client';

import React, { useState, useRef, MouseEvent } from 'react';
import Image from 'next/image';
import { Eye, Hand, Sparkles, Sliders } from 'lucide-react';

interface TactileZone {
  x: number; // percentage
  y: number;
  label: 'SOFT' | 'ROUGH' | 'LUSTROUS' | 'DENSE' | 'CRIMPED' | 'FINE';
  description: string;
  breedExample: string;
  metric: string;
}

const ZONES: TactileZone[] = [
  {
    x: 25,
    y: 35,
    label: 'CRIMPED',
    description: 'High-frequency helical wave locks microscopic pockets of dead air, granting 300% elasticity.',
    breedExample: 'Cheviot & Down Breeds',
    metric: '9 crimps per 25mm',
  },
  {
    x: 50,
    y: 20,
    label: 'FINE',
    description: 'Ultra-thin single fibres deflect with under 0.02 dynes of skin contact pressure.',
    breedExample: 'Bluefaced Leicester',
    metric: '24.5 μm Average',
  },
  {
    x: 75,
    y: 40,
    label: 'LUSTROUS',
    description: 'Flat, broad cortical cell scales reflect directional incident light like cut crystal.',
    breedExample: 'Wensleydale & Teeswater',
    metric: 'High Refractive Index',
  },
  {
    x: 35,
    y: 65,
    label: 'DENSE',
    description: 'Interlocking cuticular scales create high friction resistance against water and shear force.',
    breedExample: 'Herdwick Guard Hair',
    metric: '680 GSM Compressed Batt',
  },
  {
    x: 60,
    y: 70,
    label: 'SOFT',
    description: 'Naturally washed in soft Yorkshire water, retaining 1.5% soothing natural lanolin esters.',
    breedExample: 'Shetland Moorit Underwool',
    metric: 'Zero Carbonisation',
  },
  {
    x: 80,
    y: 80,
    label: 'ROUGH',
    description: 'Rustic mountain guard hair with thick medulla core built to withstand Pennine blizzards.',
    breedExample: 'Swaledale & Dalesbred',
    metric: '38–42 μm Tough Handle',
  }
];

export default function FeelTheFibre() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [coords, setCoords] = useState<{ x: number; y: number }>({ x: 50, y: 50 });
  const [activeZone, setActiveZone] = useState<TactileZone>(ZONES[0]);
  const [isHovering, setIsHovering] = useState<boolean>(false);

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100));
    const y = Math.max(0, Math.min(100, ((e.clientY - rect.top) / rect.height) * 100));
    setCoords({ x, y });

    // Find nearest tactile zone
    let closest = ZONES[0];
    let minDist = 999999;
    ZONES.forEach((zone) => {
      const dist = Math.hypot(zone.x - x, zone.y - y);
      if (dist < minDist) {
        minDist = dist;
        closest = zone;
      }
    });
    setActiveZone(closest);
  };

  return (
    <section id="feel-the-fibre" className="bg-[#191918] text-[#F3F0E8] py-24 px-4 sm:px-6 lg:px-8 border-b border-[#30302D]">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6 pb-6 border-b border-[#30302D]">
          <div>
            <span className="text-xs font-mono tracking-widest text-[#CDBFA8] uppercase block mb-1">
              Sensory Mechanics · Macro Tactility Interface
            </span>
            <h2 className="text-4xl sm:text-5xl font-serif text-[#F3F0E8] tracking-tight">
              Feel the Fibre
            </h2>
          </div>
          <p className="text-sm font-sans text-[#E8E0D2]/80 max-w-md">
            Move your cursor across the high-magnification Yorkshire wool field. The tactile sensor reveals physical handle, crimp tension, and cellular reflectance.
          </p>
        </div>

        {/* Interactive Tactile Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Main Macro Inspection Canvas (8 cols) */}
          <div className="lg:col-span-8">
            <div
              ref={containerRef}
              onMouseMove={handleMouseMove}
              onMouseEnter={() => setIsHovering(true)}
              onMouseLeave={() => setIsHovering(false)}
              className="relative aspect-[16/10] w-full rounded overflow-hidden cursor-crosshair border border-[#30302D] shadow-2xl bg-black"
            >
              <Image
                src="/images/hero_macro.jpg"
                alt="Macro Wool Fibre Surface"
                fill
                className="object-cover transition-transform duration-300"
                style={{
                  transform: isHovering
                    ? `scale(1.08) translate(${(coords.x - 50) * -0.06}%, ${(coords.y - 50) * -0.06}%)`
                    : 'scale(1)',
                }}
                referrerPolicy="no-referrer"
              />

              {/* Highlighting tactile anchor points */}
              {ZONES.map((zone, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveZone(zone)}
                  style={{ left: `${zone.x}%`, top: `${zone.y}%` }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 p-1.5 rounded-full border transition-all ${
                    activeZone.label === zone.label
                      ? 'bg-[#A33E32] text-white border-white scale-125 z-20 shadow-lg ring-4 ring-[#A33E32]/40'
                      : 'bg-[#191918]/80 text-[#E8E0D2] border-[#CDBFA8]/60 hover:bg-[#30302D]'
                  }`}
                  title={zone.label}
                >
                  <span className="block w-2 h-2 rounded-full bg-current" />
                </button>
              ))}

              {/* Magnifier Lens HUD */}
              {isHovering && (
                <div
                  style={{ left: `${coords.x}%`, top: `${coords.y}%` }}
                  className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 w-28 h-28 rounded-full border-2 border-[#E8E0D2] shadow-2xl overflow-hidden backdrop-brightness-125 backdrop-contrast-125 backdrop-saturate-150 flex items-center justify-center bg-black/10"
                >
                  <div className="w-1.5 h-1.5 rounded-full bg-[#A33E32]" />
                  <div className="absolute top-2 text-[9px] font-mono text-[#E8E0D2] bg-[#191918]/90 px-1 rounded">
                    {coords.x.toFixed(0)}μm
                  </div>
                </div>
              )}

              {/* Corner Live Scan Badge */}
              <div className="absolute bottom-4 left-4 bg-[#191918]/90 border border-[#30302D] px-3 py-1.5 rounded text-xs font-mono flex items-center gap-2">
                <Hand className="w-3.5 h-3.5 text-[#CDBFA8] animate-pulse" />
                <span>ACTIVE CONTACT SENSOR · {activeZone.label} DETECTED</span>
              </div>
            </div>
          </div>

          {/* Right Sensory Readout Panel (4 cols) */}
          <div className="lg:col-span-4 bg-[#30302D]/50 border border-[#30302D] rounded p-6 sm:p-8 flex flex-col justify-between h-full">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-[#77746F]/40 mb-6">
                <span className="text-[10px] font-mono tracking-widest uppercase text-[#CDBFA8]">
                  TACTILE RECEPTOR OUTPUT
                </span>
                <span className="text-xs font-mono font-bold text-[#A33E32]">
                  {activeZone.metric}
                </span>
              </div>

              {/* Giant Active Attribute Word */}
              <div className="mb-6">
                <span className="text-xs font-mono text-[#77766F] block mb-1">
                  TACTILE PERCEPTION:
                </span>
                <h3 className="font-serif text-4xl sm:text-5xl font-light tracking-wide text-[#F3F0E8]">
                  {activeZone.label}
                </h3>
              </div>

              <p className="text-sm text-[#E8E0D2] font-sans leading-relaxed mb-6">
                {activeZone.description}
              </p>

              <div className="bg-[#191918] border border-[#30302D] p-4 rounded text-xs font-mono space-y-2 mb-6">
                <div className="flex justify-between text-[#CDBFA8]">
                  <span>REPRESENTATIVE FLOCK:</span>
                  <span className="text-white font-semibold">{activeZone.breedExample}</span>
                </div>
                <div className="flex justify-between text-[#CDBFA8]">
                  <span>RESISTANCE TO DEFLECTION:</span>
                  <span className="text-[#A33E32] font-bold">OPTIMAL</span>
                </div>
                <div className="flex justify-between text-[#CDBFA8]">
                  <span>LANOLIN SATURATION:</span>
                  <span className="text-white font-semibold">1.4% NATURAL</span>
                </div>
              </div>

              {/* Fast selector buttons */}
              <div>
                <span className="text-[10px] font-mono tracking-wider text-[#77766F] uppercase block mb-2">
                  DIRECT SENSORY JUMP:
                </span>
                <div className="grid grid-cols-3 gap-1.5 font-mono text-[11px]">
                  {ZONES.map((z) => (
                    <button
                      key={z.label}
                      onClick={() => setActiveZone(z)}
                      className={`py-1.5 px-2 rounded border transition-colors ${
                        activeZone.label === z.label
                          ? 'bg-[#A33E32] text-white border-[#A33E32]'
                          : 'bg-[#191918] text-[#CDBFA8] border-[#30302D] hover:border-[#77766F]'
                      }`}
                    >
                      {z.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-6 mt-6 border-t border-[#77746F]/30 text-[11px] font-mono text-[#77766F] flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-[#CDBFA8]" />
              <span>Simulated tactile feedback based on British Wool Board physical assays.</span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
