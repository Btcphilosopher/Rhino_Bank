'use client';

import React from 'react';
import Image from 'next/image';
import { useEmporium } from '@/lib/store';
import { ArrowRight } from 'lucide-react';

const CATEGORIES = [
  {
    id: 'WOOL',
    title: 'Wool',
    subtitle: 'Raw & Prepared Fleeces, Tops, Roving & Locks',
    spec: '100% Untreated British Fleece',
    image: '/images/fleece.jpg',
    targetCategory: 'WOOL',
  },
  {
    id: 'YARN',
    title: 'Yarn',
    subtitle: '4-Ply, DK, Aran, Chunky & Heritage Single-Origin',
    spec: 'Worsted & Woollen Spun',
    image: '/images/yarn.jpg',
    targetCategory: 'YARN',
  },
  {
    id: 'CLOTH',
    title: 'Cloth',
    subtitle: 'Tweed, Suiting, Coating, Blanket & Heavy Melton',
    spec: 'Woven on Yorkshire Looms',
    image: '/images/cloth.jpg',
    targetCategory: 'CLOTH',
  },
  {
    id: 'HOME',
    title: 'Home',
    subtitle: 'Blankets, Hearth Rugs, Wool Bedding & Cushions',
    spec: 'Architectural Interiors',
    image: '/images/cloth.jpg',
    targetCategory: 'HOME',
  },
  {
    id: 'CLOTHING',
    title: 'Clothing',
    subtitle: 'Guernsey Jumpers, Fair Isle Vests & Fell Socks',
    spec: 'Generational British Workwear',
    image: '/images/sheep.jpg',
    targetCategory: 'CLOTHING',
  },
  {
    id: 'CRAFT',
    title: 'Craft & Tools',
    subtitle: 'English Oak Spindles, Looms, Kits & Pattern Books',
    spec: 'Specialist Tools & Fibres',
    image: '/images/hero_macro.jpg',
    targetCategory: 'CRAFT',
  },
  {
    id: 'SHEEP',
    title: 'The Breeds',
    subtitle: '14 British Native Breeds & Material Profiles',
    spec: 'Fibre Science & Heritage',
    image: '/images/sheep.jpg',
    targetAnchor: '#meet-the-flock',
  },
  {
    id: 'BOARD',
    title: 'The Wool Board',
    subtitle: 'Synthetic Market Auctions & Grade Indexing',
    spec: 'Market Intelligence',
    image: '/images/yarn.jpg',
    targetAnchor: '#the-wool-board',
  }
];

export default function CategoryTiles() {
  const { setActiveCategory } = useEmporium();

  const handleTileClick = (cat: typeof CATEGORIES[0]) => {
    if (cat.targetAnchor) {
      const el = document.querySelector(cat.targetAnchor);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (cat.targetCategory) {
      setActiveCategory(cat.targetCategory);
      const el = document.querySelector('#shop-emporium');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="bg-[#F3F0E8] py-20 px-4 sm:px-6 lg:px-8 border-b border-[#CDBFA8]/60">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4 pb-6 border-b border-[#CDBFA8]">
          <div>
            <span className="text-xs font-mono tracking-widest text-[#77746F] uppercase block mb-1">
              Section 01 · Archive Categories
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-[#191918] tracking-tight">
              Shop the Emporium
            </h2>
          </div>
          <p className="text-sm font-sans text-[#77766F] max-w-md">
            Every material is documented by fibre diameter, staple crimp, and processing mill. Select a discipline to explore the catalogue.
          </p>
        </div>

        {/* 8 Category Tiles Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {CATEGORIES.map((cat) => (
            <div
              key={cat.id}
              onClick={() => handleTileClick(cat)}
              className="group cursor-pointer bg-[#E8E0D2]/40 rounded overflow-hidden border border-[#CDBFA8] hover:border-[#191918] transition-all hover:shadow-lg flex flex-col justify-between"
            >
              {/* Image Frame */}
              <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#30302D]">
                <Image
                  src={cat.image}
                  alt={cat.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-700 filter brightness-[0.9]"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-80" />
                
                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <span className="text-[10px] font-mono tracking-widest uppercase bg-[#191918]/80 px-2 py-0.5 rounded text-[#E8E0D2]">
                    {cat.spec}
                  </span>
                </div>
              </div>

              {/* Text Meta */}
              <div className="p-5 flex flex-col justify-between flex-grow">
                <div>
                  <h3 className="font-serif text-2xl font-semibold text-[#191918] group-hover:text-[#A33E32] transition-colors mb-1">
                    {cat.title}
                  </h3>
                  <p className="text-xs text-[#77746F] font-sans leading-relaxed">
                    {cat.subtitle}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-[#CDBFA8]/60 flex items-center justify-between text-xs font-mono text-[#191918]">
                  <span>Explore Sector</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform text-[#A33E32]" />
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
