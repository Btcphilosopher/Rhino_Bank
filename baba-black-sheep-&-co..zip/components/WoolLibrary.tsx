'use client';

import React, { useState } from 'react';
import { WOOL_ARTICLES, WoolLibraryArticle } from '@/lib/data';
import { BookOpen, ArrowRight, ChevronDown, ChevronUp, Layers, Compass } from 'lucide-react';
import { useEmporium } from '@/lib/store';

export default function WoolLibrary() {
  const { openModal } = useEmporium();
  const [expandedId, setExpandedId] = useState<string>(WOOL_ARTICLES[0].id);

  return (
    <section id="wool-library" className="bg-[#F3F0E8] py-24 px-4 sm:px-6 lg:px-8 border-b border-[#CDBFA8]/60">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6 pb-6 border-b border-[#CDBFA8]">
          <div>
            <span className="text-xs font-mono tracking-widest text-[#77746F] uppercase block mb-1">
              Section 08 · Material Intelligence & Mill Science
            </span>
            <h2 className="text-4xl sm:text-5xl font-serif text-[#191918] tracking-tight">
              The Wool Library
            </h2>
          </div>
          <p className="text-sm font-sans text-[#77766F] max-w-md">
            Essential treatises on micron physics, mechanical carding, worsted drafting, and the thermal biology of British fleece.
          </p>
        </div>

        {/* Article Grid & Accordion */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Article List (5 cols) */}
          <div className="lg:col-span-5 space-y-3">
            {WOOL_ARTICLES.map((article) => {
              const isSelected = article.id === expandedId;
              return (
                <div
                  key={article.id}
                  onClick={() => setExpandedId(article.id)}
                  className={`cursor-pointer p-5 rounded border transition-all ${
                    isSelected
                      ? 'bg-[#191918] text-[#F3F0E8] border-[#191918] shadow-md'
                      : 'bg-[#E8E0D2]/40 hover:bg-[#E8E0D2] text-[#191918] border-[#CDBFA8]'
                  }`}
                >
                  <div className="flex items-center justify-between text-[11px] font-mono tracking-wider uppercase mb-1">
                    <span className={isSelected ? 'text-[#CDBFA8]' : 'text-[#A33E32]'}>
                      {article.category}
                    </span>
                    <span className={isSelected ? 'text-[#77766F]' : 'text-[#77746F]'}>
                      {article.readTime}
                    </span>
                  </div>

                  <h3 className="font-serif text-xl font-semibold leading-snug">
                    {article.title}
                  </h3>

                  <p className={`text-xs font-sans mt-2 line-clamp-2 ${isSelected ? 'text-[#E8E0D2]/80' : 'text-[#77766F]'}`}>
                    {article.summary}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Reading & Diagram Pane (7 cols) */}
          <div className="lg:col-span-7 bg-[#E8E0D2]/35 border border-[#CDBFA8] rounded p-6 sm:p-10 flex flex-col justify-between">
            {(() => {
              const current = WOOL_ARTICLES.find(a => a.id === expandedId) || WOOL_ARTICLES[0];
              return (
                <div>
                  <div className="flex items-center gap-3 text-xs font-mono text-[#77766F] uppercase pb-4 border-b border-[#CDBFA8]/60 mb-6">
                    <BookOpen className="w-4 h-4 text-[#A33E32]" />
                    <span>ARTICLE DISPATCH · {current.category}</span>
                  </div>

                  <h3 className="font-serif text-3xl sm:text-4xl font-bold text-[#191918] mb-4 leading-tight">
                    {current.title}
                  </h3>

                  <div className="space-y-4 text-sm font-sans text-[#30302D] leading-relaxed mb-8">
                    {current.content.map((p, idx) => (
                      <p key={idx}>{p}</p>
                    ))}
                  </div>

                  {/* Diagrammatic Callout Box */}
                  {current.diagramType === 'MICRON_SCALE' && (
                    <div className="bg-[#F3F0E8] border border-[#CDBFA8] p-5 rounded font-mono text-xs">
                      <span className="text-[10px] text-[#77766F] uppercase tracking-wider block mb-2">
                        COMPARATIVE FIBRE DIAMETER (MICRONS):
                      </span>
                      <div className="space-y-2">
                        <div>
                          <div className="flex justify-between text-[11px] mb-1">
                            <span>Spider Dragline Silk</span>
                            <span className="font-bold">4 μm</span>
                          </div>
                          <div className="w-full bg-[#E8E0D2] h-2 rounded overflow-hidden">
                            <div className="bg-[#263B49] h-full w-[10%]" />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between text-[11px] mb-1">
                            <span>Bluefaced Leicester (Soft Handle)</span>
                            <span className="font-bold">25 μm</span>
                          </div>
                          <div className="w-full bg-[#E8E0D2] h-2 rounded overflow-hidden">
                            <div className="bg-[#A33E32] h-full w-[45%]" />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between text-[11px] mb-1">
                            <span>Swaledale Mountain Wool (Textured)</span>
                            <span className="font-bold">35 μm</span>
                          </div>
                          <div className="w-full bg-[#E8E0D2] h-2 rounded overflow-hidden">
                            <div className="bg-[#4D5847] h-full w-[65%]" />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between text-[11px] mb-1">
                            <span>Herdwick Fell Guard Hair (Extreme Wear)</span>
                            <span className="font-bold">42 μm</span>
                          </div>
                          <div className="w-full bg-[#E8E0D2] h-2 rounded overflow-hidden">
                            <div className="bg-[#191918] h-full w-[85%]" />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {current.diagramType === 'FIBRE_ALIGNMENT' && (
                    <div className="bg-[#F3F0E8] border border-[#CDBFA8] p-5 rounded font-mono text-xs grid grid-cols-2 gap-4">
                      <div className="border-r border-[#CDBFA8] pr-4">
                        <span className="font-bold text-[#191918] block mb-1">WORSTED ALIGNMENT:</span>
                        <p className="text-[11px] text-[#77746F]">Parallel combed fibres with all short slubs removed. Creates dense, shiny suiting and lustre yarn.</p>
                      </div>
                      <div>
                        <span className="font-bold text-[#191918] block mb-1">WOOLLEN ALIGNMENT:</span>
                        <p className="text-[11px] text-[#77746F]">Criss-cross carded fibres locking microscopic air volumes. Creates airy, warm tweed and Fair Isle yarn.</p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })()}

            <div className="pt-6 mt-8 border-t border-[#CDBFA8]/60 flex items-center justify-between text-xs font-mono">
              <span className="text-[#77766F]">
                Curated by Baba Black Sheep Archival Fellows
              </span>
              <button
                onClick={() => {
                  const el = document.querySelector('#shop-emporium');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="text-[#A33E32] hover:text-[#191918] font-bold flex items-center gap-1"
              >
                <span>Browse Library Specimens</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
