'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useEmporium } from '@/lib/store';
import { BREEDS } from '@/lib/data';
import { ArrowUpRight, Check, SlidersHorizontal, Info } from 'lucide-react';

export default function WoolExplorer() {
  const { openModal } = useEmporium();
  const [selectedBreedId, setSelectedBreedId] = useState<string>('swaledale');
  const [activeFibreView, setActiveFibreView] = useState<'macro' | 'fleece' | 'yarn'>('macro');

  const breed = BREEDS.find(b => b.id === selectedBreedId) || BREEDS[0];

  const getImageSrc = () => {
    if (activeFibreView === 'macro') return '/images/hero_macro.jpg';
    if (activeFibreView === 'fleece') return breed.fleeceImage;
    return '/images/yarn.jpg';
  };

  return (
    <section id="wool-explorer" className="bg-[#E8E0D2] py-20 px-4 sm:px-6 lg:px-8 border-b border-[#CDBFA8]">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4 pb-6 border-b border-[#CDBFA8]/80">
          <div>
            <span className="text-xs font-mono tracking-widest text-[#77746F] uppercase block mb-1">
              Interactive Tool 01 · Material Specification Library
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-[#191918] tracking-tight">
              The Wool Explorer
            </h2>
          </div>
          <p className="text-sm font-sans text-[#77766F] max-w-md">
            Query the physical characteristics of British native sheep fleeces. Explore micron count, staple geometry, and recommended architectural and textile applications.
          </p>
        </div>

        {/* Breed Selector Horizontal Track */}
        <div className="mb-8">
          <label className="text-[11px] font-mono uppercase tracking-wider text-[#77746F] block mb-2">
            Select British Sheep Breed:
          </label>
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-thin">
            {BREEDS.map((b) => (
              <button
                key={b.id}
                onClick={() => setSelectedBreedId(b.id)}
                className={`px-3 py-1.5 rounded text-xs font-mono whitespace-nowrap transition-colors border ${
                  selectedBreedId === b.id
                    ? 'bg-[#191918] text-[#F3F0E8] border-[#191918]'
                    : 'bg-[#F3F0E8] text-[#30302D] border-[#CDBFA8] hover:border-[#191918]'
                }`}
              >
                {b.name}
              </button>
            ))}
          </div>
        </div>

        {/* Main Explorer Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 bg-[#F3F0E8] border border-[#CDBFA8] rounded p-6 sm:p-8 shadow-sm">
          
          {/* Left Column: Visual Material Sample (7 cols) */}
          <div className="lg:col-span-7 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-mono text-[#77766F] uppercase tracking-wider">
                  MATERIAL SPECIMEN: {breed.name.toUpperCase()} / {breed.region.toUpperCase()}
                </span>
                
                {/* View Toggles */}
                <div className="flex items-center gap-1 bg-[#E8E0D2] p-1 rounded text-[11px] font-mono">
                  <button
                    onClick={() => setActiveFibreView('macro')}
                    className={`px-2.5 py-1 rounded transition-colors ${
                      activeFibreView === 'macro' ? 'bg-[#191918] text-white' : 'text-[#30302D] hover:text-black'
                    }`}
                  >
                    Macro Fibre
                  </button>
                  <button
                    onClick={() => setActiveFibreView('fleece')}
                    className={`px-2.5 py-1 rounded transition-colors ${
                      activeFibreView === 'fleece' ? 'bg-[#191918] text-white' : 'text-[#30302D] hover:text-black'
                    }`}
                  >
                    Raw Fleece
                  </button>
                  <button
                    onClick={() => setActiveFibreView('yarn')}
                    className={`px-2.5 py-1 rounded transition-colors ${
                      activeFibreView === 'yarn' ? 'bg-[#191918] text-white' : 'text-[#30302D] hover:text-black'
                    }`}
                  >
                    Spun Yarn
                  </button>
                </div>
              </div>

              {/* Material Image Frame */}
              <div className="relative aspect-[16/10] w-full rounded overflow-hidden bg-[#30302D] border border-[#CDBFA8]">
                <Image
                  src={getImageSrc()}
                  alt={`${breed.name} ${activeFibreView}`}
                  fill
                  className="object-cover transition-all duration-500"
                  referrerPolicy="no-referrer"
                />
                
                <div className="absolute bottom-3 left-3 bg-[#191918]/85 text-[#E8E0D2] px-3 py-1 rounded font-mono text-[10px] tracking-widest uppercase">
                  FIBRE SCAN · {breed.micron} · {breed.crimp.toUpperCase()} CRIMP
                </div>
              </div>

              <p className="text-xs text-[#77766F] font-sans mt-4 italic leading-relaxed">
                &ldquo;{breed.story}&rdquo;
              </p>
            </div>

            <div className="pt-6 mt-6 border-t border-[#CDBFA8]/60 flex items-center justify-between">
              <button
                onClick={() => openModal('breed', breed.id)}
                className="text-xs font-mono text-[#A33E32] hover:text-[#191918] font-bold flex items-center gap-1.5"
              >
                <span>Open Full Breed Dossier</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>

              <span className="text-[11px] font-mono text-[#77766F]">
                SYNTHETIC LOT DATA
              </span>
            </div>
          </div>

          {/* Right Column: Physical Spec Sheet (5 cols) */}
          <div className="lg:col-span-5 bg-[#E8E0D2]/50 border border-[#CDBFA8] rounded p-6 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-[#CDBFA8]">
                <span className="font-mono text-xs uppercase tracking-wider text-[#191918] font-semibold">
                  PHYSICAL PROFILE
                </span>
                <span className="text-[10px] font-mono text-[#77766F] uppercase">
                  SPEC: {breed.id.toUpperCase()}-26
                </span>
              </div>

              <div className="space-y-3.5 py-4 text-xs font-mono">
                <div className="flex justify-between items-center py-1 border-b border-[#CDBFA8]/40">
                  <span className="text-[#77766F]">BREED:</span>
                  <span className="font-bold text-[#191918]">{breed.name}</span>
                </div>

                <div className="flex justify-between items-center py-1 border-b border-[#CDBFA8]/40">
                  <span className="text-[#77766F]">REGION:</span>
                  <span className="text-[#191918]">{breed.region}</span>
                </div>

                <div className="flex justify-between items-center py-1 border-b border-[#CDBFA8]/40">
                  <span className="text-[#77766F]">FIBRE DIAMETER:</span>
                  <span className="font-bold text-[#A33E32] tabular-nums">{breed.micron}</span>
                </div>

                <div className="flex justify-between items-center py-1 border-b border-[#CDBFA8]/40">
                  <span className="text-[#77766F]">STAPLE LENGTH:</span>
                  <span className="text-[#191918] tabular-nums">{breed.stapleLength}</span>
                </div>

                <div className="flex justify-between items-center py-1 border-b border-[#CDBFA8]/40">
                  <span className="text-[#77766F]">HANDLE:</span>
                  <span className="text-[#191918]">{breed.handle}</span>
                </div>

                <div className="flex justify-between items-center py-1 border-b border-[#CDBFA8]/40">
                  <span className="text-[#77766F]">LUSTRE:</span>
                  <span className="text-[#191918]">{breed.lustre}</span>
                </div>

                <div className="flex justify-between items-center py-1 border-b border-[#CDBFA8]/40">
                  <span className="text-[#77766F]">CRIMP ARCHITECTURE:</span>
                  <span className="text-[#191918]">{breed.crimp}</span>
                </div>

                <div className="flex justify-between items-center py-1 border-b border-[#CDBFA8]/40">
                  <span className="text-[#77766F]">THERMAL WARMTH:</span>
                  <span className="text-[#191918]">{breed.warmth}</span>
                </div>

                <div className="flex justify-between items-center py-1 border-b border-[#CDBFA8]/40">
                  <span className="text-[#77766F]">TENSILE STRENGTH:</span>
                  <span className="text-[#191918]">{breed.strength}</span>
                </div>
              </div>

              {/* Recommended Applications */}
              <div className="pt-3">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#77766F] block mb-2">
                  OPTIMAL INDUSTRIAL & TEXTILE APPLICATIONS:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {breed.recommendedApplications.map((app, idx) => (
                    <span
                      key={idx}
                      className="text-[11px] font-mono bg-[#F3F0E8] border border-[#CDBFA8] px-2 py-0.5 rounded text-[#30302D]"
                    >
                      {app}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Quick Action Button */}
            <div className="pt-6 mt-6 border-t border-[#CDBFA8]">
              <button
                onClick={() => {
                  const el = document.querySelector('#shop-emporium');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full py-2.5 bg-[#191918] text-[#F3F0E8] hover:bg-[#30302D] transition-colors rounded text-xs font-mono uppercase tracking-wider font-semibold"
              >
                View Available {breed.name} Products
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
