'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useEmporium } from '@/lib/store';
import { Product, PRODUCTS, BREEDS } from '@/lib/data';
import { ShoppingBag, Eye, ArrowUpRight, Check, SlidersHorizontal } from 'lucide-react';

export default function ProductGrid() {
  const { addToBasket, openModal, activeCategory, setActiveCategory, activeBreedFilter, setActiveBreedFilter } = useEmporium();
  const [hoveredCardId, setHoveredCardId] = useState<string | null>(null);
  const [addedNoticeId, setAddedNoticeId] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc'>('featured');

  const filteredProducts = PRODUCTS.filter((item) => {
    if (activeCategory !== 'ALL' && item.category !== activeCategory) return false;
    if (activeBreedFilter !== 'ALL' && !item.breed.toLowerCase().includes(activeBreedFilter.toLowerCase())) return false;
    return true;
  }).sort((a, b) => {
    if (sortBy === 'price-asc') return a.price - b.price;
    if (sortBy === 'price-desc') return b.price - a.price;
    return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
  });

  const handleQuickAdd = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    addToBasket(product, 1, product.variants?.[0]?.id);
    setAddedNoticeId(product.id);
    setTimeout(() => setAddedNoticeId(null), 1800);
  };

  return (
    <section id="shop-emporium" className="bg-[#F3F0E8] py-24 px-4 sm:px-6 lg:px-8 border-b border-[#CDBFA8]">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4 pb-6 border-b border-[#CDBFA8]">
          <div>
            <span className="text-xs font-mono tracking-widest text-[#77746F] uppercase block mb-1">
              Section 03 · The Full Catalogue
            </span>
            <h2 className="text-4xl sm:text-5xl font-serif text-[#191918] tracking-tight">
              Materials & Objects
            </h2>
          </div>
          <p className="text-sm font-sans text-[#77766F] max-w-md">
            Woven cloth by the metre, worsted and woollen skeins, graded raw fleeces, and British architectural interiors.
          </p>
        </div>

        {/* Filter & Category Controls Bar */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-10 pb-4 border-b border-[#CDBFA8]/60 text-xs font-mono">
          
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-1.5">
            {['ALL', 'YARN', 'CLOTH', 'WOOL', 'HOME', 'CLOTHING', 'CRAFT'].map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3.5 py-1.5 rounded transition-colors uppercase font-medium ${
                  activeCategory === cat
                    ? 'bg-[#191918] text-[#F3F0E8]'
                    : 'bg-[#E8E0D2] text-[#30302D] hover:bg-[#CDBFA8]'
                }`}
              >
                {cat === 'ALL' ? 'All Archive' : cat}
              </button>
            ))}
          </div>

          {/* Breed & Sort Pickers */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <span className="text-[#77766F] uppercase">Breed:</span>
              <select
                value={activeBreedFilter}
                onChange={(e) => setActiveBreedFilter(e.target.value)}
                className="bg-[#E8E0D2] border border-[#CDBFA8] rounded px-2.5 py-1.5 text-xs font-mono text-[#191918] focus:outline-none focus:border-[#191918]"
              >
                <option value="ALL">All Breeds</option>
                {BREEDS.map((b) => (
                  <option key={b.id} value={b.name}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[#77766F] uppercase">Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-[#E8E0D2] border border-[#CDBFA8] rounded px-2.5 py-1.5 text-xs font-mono text-[#191918] focus:outline-none focus:border-[#191918]"
              >
                <option value="featured">Featured First</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
              </select>
            </div>
          </div>

        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredProducts.map((product) => {
            const isHovered = hoveredCardId === product.id;
            const displayImage = isHovered && product.images[1] ? product.images[1] : product.images[0];
            const isAdded = addedNoticeId === product.id;

            return (
              <div
                key={product.id}
                onMouseEnter={() => setHoveredCardId(product.id)}
                onMouseLeave={() => setHoveredCardId(null)}
                onClick={() => openModal('product', product.id)}
                className="group cursor-pointer bg-[#F3F0E8] border border-[#CDBFA8] hover:border-[#191918] rounded overflow-hidden transition-all hover:shadow-md flex flex-col justify-between"
              >
                {/* Image Showcase */}
                <div className="relative aspect-[4/3] w-full bg-[#30302D] overflow-hidden">
                  <Image
                    src={displayImage}
                    alt={product.name}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />

                  {/* Lot tag */}
                  <div className="absolute top-2.5 left-2.5 bg-[#191918]/85 text-[#E8E0D2] px-2 py-0.5 rounded text-[10px] font-mono tracking-widest uppercase">
                    LOT {product.lotNumber}
                  </div>

                  {/* Natural colour vs dyed tag */}
                  <div className="absolute top-2.5 right-2.5">
                    {product.isNaturalColour ? (
                      <span className="bg-[#E8E0D2]/90 text-[#30302D] border border-[#CDBFA8] px-2 py-0.5 rounded text-[9px] font-mono uppercase tracking-wider">
                        Natural Undyed
                      </span>
                    ) : (
                      <span className="bg-[#263B49]/90 text-white px-2 py-0.5 rounded text-[9px] font-mono uppercase tracking-wider">
                        Vat Dyed
                      </span>
                    )}
                  </div>

                  {/* Hover "VIEW FIBRE" pill overlay */}
                  <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <span className="px-4 py-2 bg-[#F3F0E8] text-[#191918] font-mono text-xs uppercase tracking-widest font-bold shadow-md">
                      View Fibre & Specs
                    </span>
                  </div>
                </div>

                {/* Content Block */}
                <div className="p-5 flex flex-col justify-between flex-grow">
                  <div>
                    {/* Secondary meta */}
                    <div className="flex items-center justify-between text-[11px] font-mono text-[#77766F] uppercase mb-1">
                      <span>{product.breed}</span>
                      <span>{product.origin}</span>
                    </div>

                    {/* Title */}
                    <h3 className="font-serif text-xl font-semibold text-[#191918] group-hover:text-[#A33E32] transition-colors leading-tight mb-2">
                      {product.name}
                    </h3>

                    {/* Colour & Handle */}
                    <div className="flex items-center gap-2 text-xs font-mono text-[#30302D] mb-3">
                      <span
                        className="w-2.5 h-2.5 rounded-full border border-black/20 shrink-0"
                        style={{ backgroundColor: product.colourHex }}
                      />
                      <span className="truncate">{product.colourName}</span>
                      <span className="text-[#77766F]">·</span>
                      <span className="text-[#77766F] truncate">{product.handle}</span>
                    </div>
                  </div>

                  {/* Price & Action Row */}
                  <div className="pt-3 border-t border-[#CDBFA8]/60 flex items-center justify-between mt-auto">
                    <div>
                      <span className="font-mono text-base font-bold text-[#191918] tabular-nums">
                        £{product.price.toFixed(2)}
                      </span>
                      <span className="block text-[10px] font-mono text-[#77766F]">
                        {product.unit}
                      </span>
                    </div>

                    <button
                      onClick={(e) => handleQuickAdd(product, e)}
                      className={`px-3 py-1.5 rounded text-xs font-mono uppercase tracking-wider transition-colors flex items-center gap-1.5 font-medium ${
                        isAdded
                          ? 'bg-[#4D5847] text-white'
                          : 'bg-[#191918] hover:bg-[#30302D] text-[#F3F0E8]'
                      }`}
                    >
                      {isAdded ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Added</span>
                        </>
                      ) : (
                        <>
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Add</span>
                        </>
                      )}
                    </button>
                  </div>

                </div>

              </div>
            );
          })}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-16 bg-[#E8E0D2]/40 rounded border border-[#CDBFA8]">
            <p className="font-serif text-2xl text-[#191918] mb-2">No matching materials found.</p>
            <p className="text-xs font-mono text-[#77766F] mb-4">Try clearing your category or breed filter.</p>
            <button
              onClick={() => {
                setActiveCategory('ALL');
                setActiveBreedFilter('ALL');
              }}
              className="px-4 py-2 bg-[#191918] text-[#F3F0E8] text-xs font-mono uppercase rounded"
            >
              Reset Filters
            </button>
          </div>
        )}

      </div>
    </section>
  );
}
