'use client';

import React from 'react';
import { useEmporium } from '@/lib/store';
import { ArrowUpRight, Sparkles, Tag, ShieldCheck } from 'lucide-react';

const TODAY_ITEMS = [
  {
    tag: 'JUST LANDED',
    title: 'SWALEDALE NATURAL DK',
    lot: 'BBS-26-041',
    origin: '100% BRITISH WOOL · YORKSHIRE',
    price: '£12.50 / 100G',
    productId: 'prod-y01',
    accent: '#4D5847',
  },
  {
    tag: 'NEW CLOTH',
    title: 'NORTH COUNTRY TWEED',
    lot: 'BBS-26-TW01',
    origin: '560 GSM · YORKSHIRE MILL',
    price: '£84.00 / METRE',
    productId: 'prod-c01',
    accent: '#874536',
  },
  {
    tag: 'RARE HARVEST',
    title: 'HERDWICK HEAVY ARAN',
    lot: 'BBS-26-018',
    origin: '100% FELL FLEECE · CUMBRIA',
    price: '£13.00 / 100G',
    productId: 'prod-y03',
    accent: '#30302D',
  },
  {
    tag: 'LIMITED BATCH',
    title: 'BFL 4-PLY SEA INDIGO',
    lot: 'BBS-26-088',
    origin: 'VAT DYED · 25μm LUSTRE',
    price: '£16.50 / 100G',
    productId: 'prod-y02',
    accent: '#263B49',
  }
];

export default function TodayStrip() {
  const { openModal } = useEmporium();

  return (
    <section id="today-strip" className="bg-[#E8E0D2] border-b border-[#CDBFA8] py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Header line */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-5 border-b border-[#CDBFA8]/80 text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#A33E32]" />
            <span className="font-bold tracking-widest text-[#191918] uppercase">
              TODAY AT THE EMPORIUM
            </span>
            <span className="text-[#77766F]">· DISPATCH & MATERIAL ARRIVALS</span>
          </div>
          <span className="text-[11px] text-[#77746F]">
            SIMULATED DEMONSTRATION LOTS · VERIFIED WEIGHT & GRADES
          </span>
        </div>

        {/* Editorial Item Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 pt-6">
          {TODAY_ITEMS.map((item, idx) => (
            <div
              key={idx}
              className="group relative bg-[#F3F0E8] border border-[#CDBFA8] p-5 rounded hover:border-[#191918] transition-all hover:shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-[10px] font-mono tracking-wider mb-2">
                  <span className="text-[#A33E32] font-semibold">{item.tag}</span>
                  <button
                    onClick={() => openModal('traceability', item.lot)}
                    className="text-[#77766F] hover:text-[#191918] underline underline-offset-2 flex items-center gap-1 cursor-pointer"
                    title="View traceability cert"
                  >
                    <ShieldCheck className="w-3 h-3" />
                    <span>LOT {item.lot}</span>
                  </button>
                </div>

                <h3 className="font-serif text-lg font-semibold text-[#191918] group-hover:text-[#A33E32] transition-colors leading-snug">
                  {item.title}
                </h3>

                <p className="text-xs font-mono text-[#77746F] mt-1 mb-4">
                  {item.origin}
                </p>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-[#CDBFA8]/50 mt-auto">
                <span className="font-mono text-sm font-semibold text-[#191918] tabular-nums">
                  {item.price}
                </span>

                <button
                  onClick={() => openModal('product', item.productId)}
                  className="inline-flex items-center gap-1 text-xs font-mono text-[#191918] hover:text-[#A33E32] font-medium group-hover:translate-x-0.5 transition-transform"
                >
                  <span>View Fibre</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
