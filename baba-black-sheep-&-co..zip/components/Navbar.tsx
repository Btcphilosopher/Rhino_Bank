'use client';

import React from 'react';
import Link from 'next/link';
import { useEmporium } from '@/lib/store';
import { Search, ShoppingBag, FolderKanban, Building2, SlidersHorizontal, BookOpen } from 'lucide-react';

export default function Navbar() {
  const { basketCount, openModal, accentTone } = useEmporium();

  return (
    <>
      {/* Top Quiet Technical Registry Strip */}
      <div className="bg-[#191918] text-[#E8E0D2] border-b border-[#30302D] text-[11px] font-mono tracking-widest uppercase px-4 sm:px-8 py-1.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#E8E0D2] animate-pulse" />
          <span>BABA BLACK SHEEP & CO. / BRITISH WOOL ARCHIVE / LOT SPECIFICATIONS LIVE</span>
        </div>
        <div className="hidden md:flex items-center gap-6 text-[#CDBFA8]">
          <span>YORKSHIRE MILLS · CUMBRIAN FELLS · SHETLAND ISLES</span>
          <button
            onClick={() => openModal('admin')}
            className="hover:text-white transition-colors cursor-pointer text-[#CDBFA8]"
          >
            MERCHANT CONSOLE
          </button>
        </div>
      </div>

      {/* Main Top Bar Contract: 3 zones */}
      <header className="sticky top-0 z-40 bg-[#F3F0E8]/95 backdrop-blur-md border-b border-[#CDBFA8]/60 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
          
          {/* Zone 1: Single Text Element Wordmark */}
          <Link
            href="/"
            className="group flex flex-col items-start leading-none shrink-0"
          >
            <span className="font-display text-lg sm:text-xl font-bold tracking-[0.15em] text-[#191918] uppercase">
              Baba Black Sheep
            </span>
            <span className="text-[10px] font-mono tracking-[0.25em] text-[#77766F] uppercase">
              & Co. · British Wool Emporium
            </span>
          </Link>

          {/* Zone 2: 4-6 Clean Text Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7 text-xs font-mono uppercase tracking-wider text-[#30302D]">
            <a
              href="#the-fibre"
              className="hover:text-[#191918] hover:border-b hover:border-[#191918] pb-0.5 transition-all"
            >
              The Fibre
            </a>
            <a
              href="#meet-the-flock"
              className="hover:text-[#191918] hover:border-b hover:border-[#191918] pb-0.5 transition-all"
            >
              Meet the Flock
            </a>
            <a
              href="#shop-emporium"
              className="hover:text-[#191918] hover:border-b hover:border-[#191918] pb-0.5 transition-all"
            >
              The Catalogue
            </a>
            <a
              href="#the-cloth-room"
              className="hover:text-[#191918] hover:border-b hover:border-[#191918] pb-0.5 transition-all"
            >
              The Cloth Room
            </a>
            <a
              href="#sheep-to-object"
              className="hover:text-[#191918] hover:border-b hover:border-[#191918] pb-0.5 transition-all"
            >
              Sheep to Object
            </a>
            <a
              href="#the-wool-board"
              className="hover:text-[#191918] hover:border-b hover:border-[#191918] pb-0.5 transition-all"
            >
              Wool Board
            </a>
          </nav>

          {/* Zone 3: Primary Actions */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Search Trigger */}
            <button
              onClick={() => openModal('search')}
              aria-label="Search archive"
              className="p-2 sm:px-3 sm:py-2 text-xs font-mono flex items-center gap-1.5 text-[#30302D] hover:bg-[#E8E0D2] rounded transition-colors"
            >
              <Search className="w-4 h-4" />
              <span className="hidden sm:inline">Search</span>
            </button>

            {/* My Projects Workbench Button */}
            <button
              onClick={() => openModal('workbench')}
              aria-label="My Projects"
              className="p-2 sm:px-3 sm:py-2 text-xs font-mono flex items-center gap-1.5 text-[#30302D] hover:bg-[#E8E0D2] rounded transition-colors"
              title="Digital Wool Workbench"
            >
              <FolderKanban className="w-4 h-4" />
              <span className="hidden md:inline">Workbench</span>
            </button>

            {/* Trade / B2B */}
            <button
              onClick={() => openModal('trade')}
              aria-label="Trade & B2B"
              className="hidden sm:flex items-center gap-1.5 p-2 px-3 text-xs font-mono text-[#30302D] hover:bg-[#E8E0D2] rounded transition-colors"
            >
              <Building2 className="w-4 h-4" />
              <span>Trade</span>
            </button>

            {/* Merchant's Order Bag */}
            <button
              onClick={() => openModal('cart')}
              className="flex items-center gap-2 px-3 sm:px-4 py-2 text-xs font-mono tracking-wider uppercase text-white rounded transition-transform active:scale-95 shadow-sm"
              style={{ backgroundColor: '#191918' }}
              aria-label={`Shopping bag containing ${basketCount} items`}
            >
              <ShoppingBag className="w-4 h-4 text-[#F3F0E8]" />
              <span className="hidden sm:inline">Order Sheet</span>
              <span className="ml-1 px-1.5 py-0.2 bg-[#F3F0E8] text-[#191918] font-bold text-[10px] rounded-full">
                {basketCount}
              </span>
            </button>
          </div>

        </div>
      </header>
    </>
  );
}
