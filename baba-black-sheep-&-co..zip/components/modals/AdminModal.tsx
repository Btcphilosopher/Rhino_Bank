'use client';

import React, { useState } from 'react';
import { useEmporium } from '@/lib/store';
import { PRODUCTS, BREEDS, WOOL_BOARD_DATA, TRACEABILITY_LOTS } from '@/lib/data';
import { X, Database, Shield, FileText, CheckCircle, BarChart3, Package, Users } from 'lucide-react';

export default function AdminModal() {
  const { closeModal, tradeQuotes, sampleRequests, projects } = useEmporium();
  const [activeAdminTab, setActiveAdminTab] = useState<'inventory' | 'trade' | 'market' | 'traceability'>('inventory');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div
        className="relative w-full max-w-4xl bg-[#F3F0E8] border-2 border-[#191918] rounded shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col font-mono text-xs"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Admin Header */}
        <div className="p-4 sm:p-6 bg-[#191918] text-[#F3F0E8] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <Database className="w-5 h-5 text-[#CDBFA8]" />
            <div>
              <span className="font-bold text-sm tracking-wider uppercase block">
                BABA BLACK SHEEP & CO. · ARCHIVE CONSOLE
              </span>
              <span className="text-[10px] text-[#77766F] uppercase">
                EMPORIUM INVENTORY · TRADE QUOTATIONS · MARKET SPECIFICATIONS
              </span>
            </div>
          </div>

          <button
            onClick={closeModal}
            aria-label="Close admin console"
            className="p-1 rounded hover:bg-[#30302D] text-[#E8E0D2] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Admin Tabs */}
        <div className="bg-[#E8E0D2] border-b border-[#CDBFA8] px-6 py-2 flex items-center gap-2 overflow-x-auto text-[11px] uppercase">
          <button
            onClick={() => setActiveAdminTab('inventory')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeAdminTab === 'inventory' ? 'bg-[#191918] text-white font-bold' : 'text-[#30302D] hover:bg-[#CDBFA8]'
            }`}
          >
            Inventory ({PRODUCTS.length})
          </button>
          <button
            onClick={() => setActiveAdminTab('trade')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeAdminTab === 'trade' ? 'bg-[#191918] text-white font-bold' : 'text-[#30302D] hover:bg-[#CDBFA8]'
            }`}
          >
            Trade & Samples ({tradeQuotes.length + sampleRequests.length})
          </button>
          <button
            onClick={() => setActiveAdminTab('market')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeAdminTab === 'market' ? 'bg-[#191918] text-white font-bold' : 'text-[#30302D] hover:bg-[#CDBFA8]'
            }`}
          >
            Wool Board Market
          </button>
          <button
            onClick={() => setActiveAdminTab('traceability')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeAdminTab === 'traceability' ? 'bg-[#191918] text-white font-bold' : 'text-[#30302D] hover:bg-[#CDBFA8]'
            }`}
          >
            Traceability Lots
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6">
          
          {/* Inventory Tab */}
          {activeAdminTab === 'inventory' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center pb-2 border-b border-[#CDBFA8]">
                <span className="font-bold text-[#191918]">CATALOGUE SPECIMENS ({PRODUCTS.length} RECORDED)</span>
                <span className="text-[#77766F] text-[10px]">ALL LOT DATA SYNCHRONISED</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-[#CDBFA8] text-[#77766F] text-[10px] uppercase">
                      <th className="py-2">LOT ID</th>
                      <th className="py-2">PRODUCT NAME</th>
                      <th className="py-2">BREED</th>
                      <th className="py-2">SECTOR</th>
                      <th className="py-2 text-right">UNIT PRICE</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#CDBFA8]/60">
                    {PRODUCTS.map(p => (
                      <tr key={p.id} className="hover:bg-[#E8E0D2]/50">
                        <td className="py-2.5 font-bold text-[#A33E32]">{p.lotNumber}</td>
                        <td className="py-2.5 font-serif text-sm font-semibold text-[#191918]">{p.name}</td>
                        <td className="py-2.5 text-[#30302D]">{p.breed}</td>
                        <td className="py-2.5 text-[#77766F] uppercase text-[10px]">{p.category}</td>
                        <td className="py-2.5 text-right font-bold text-[#191918]">£{p.price.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Trade & Sample Requests Tab */}
          {activeAdminTab === 'trade' && (
            <div className="space-y-6">
              <div>
                <h4 className="font-bold text-[#191918] uppercase mb-2">B2B QUOTATION SPECIFICATIONS</h4>
                <div className="space-y-2">
                  {tradeQuotes.map(q => (
                    <div key={q.id} className="p-3 bg-[#E8E0D2]/50 border border-[#CDBFA8] rounded flex justify-between items-center">
                      <div>
                        <span className="font-bold text-[#191918]">{q.id}: {q.projectName}</span>
                        <span className="block text-[10px] text-[#77766F]">{q.companyName} · {q.materialName} ({q.quantityMetres} Metres)</span>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-[#A33E32]">£{q.totalEstimate.toLocaleString()}.00</span>
                        <span className="block text-[10px] text-[#4D5847] font-semibold">{q.status}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-bold text-[#191918] uppercase mb-2">SAMPLE LIBRARY REQUESTS</h4>
                <div className="space-y-2">
                  {sampleRequests.map(s => (
                    <div key={s.id} className="p-3 bg-[#E8E0D2]/50 border border-[#CDBFA8] rounded flex justify-between items-center">
                      <div>
                        <span className="font-bold text-[#191918]">{s.id}: {s.company}</span>
                        <span className="block text-[10px] text-[#77766F]">{s.sampleTypes.join(' · ')}</span>
                      </div>
                      <span className="text-[10px] text-[#4D5847] font-bold">QUEUED FOR SHIPMENT</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Market Tab */}
          {activeAdminTab === 'market' && (
            <div className="space-y-4">
              <p className="text-xs text-[#30302D]">
                Adjust synthetic wool auction reference parameters below for simulation demonstrations:
              </p>
              <div className="space-y-3">
                {WOOL_BOARD_DATA.map(m => (
                  <div key={m.id} className="p-3 bg-[#E8E0D2]/50 border border-[#CDBFA8] rounded flex justify-between items-center">
                    <div>
                      <span className="font-bold text-[#191918]">{m.grade}</span>
                      <span className="block text-[10px] text-[#77766F]">{m.description}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-sm">£{m.pricePerKg.toFixed(2)} / kg</span>
                      <span className="block text-[10px] text-[#4D5847]">Indexed 08:30 GMT</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Traceability Lots Tab */}
          {activeAdminTab === 'traceability' && (
            <div className="space-y-3">
              {Object.values(TRACEABILITY_LOTS).map(lot => (
                <div key={lot.lotNumber} className="p-3.5 bg-[#E8E0D2]/50 border border-[#CDBFA8] rounded">
                  <div className="flex justify-between items-center pb-1 border-b border-[#CDBFA8]/60 mb-2">
                    <span className="font-bold text-[#A33E32]">{lot.lotNumber}</span>
                    <span className="text-[10px] text-[#77766F]">{lot.shearSeason}</span>
                  </div>
                  <div className="text-[#30302D] space-y-1">
                    <div>PRODUCT: {lot.productName}</div>
                    <div>PROVENANCE: {lot.breed} ({lot.region})</div>
                    <div>SCOURER: {lot.scouringFacility}</div>
                    <div>SPINNER: {lot.spinningMill}</div>
                  </div>
                </div>
              ))}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-[#E8E0D2] border-t border-[#CDBFA8] text-[10px] text-[#77766F] flex justify-between items-center">
          <span>Baba Black Sheep & Co. Internal Commerce Console · Synthetic Demonstration Mode</span>
          <button
            onClick={closeModal}
            className="px-3 py-1 bg-[#191918] text-white rounded uppercase"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
}
