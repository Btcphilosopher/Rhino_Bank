'use client';

import React, { useState } from 'react';
import { useEmporium } from '@/lib/store';
import { X, FolderKanban, Plus, Trash2, ArrowRight } from 'lucide-react';

export default function WorkbenchModal() {
  const { projects, addProject, updateProjectStatus, deleteProject, closeModal } = useEmporium();
  const [showAdd, setShowAdd] = useState(false);
  const [title, setTitle] = useState('');
  const [yarnName, setYarnName] = useState('Baba Swaledale DK');
  const [quantity, setQuantity] = useState(8);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;
    addProject({
      title,
      category: 'Garment / Handknit',
      yarnId: 'prod-y01',
      yarnName,
      breed: 'Swaledale',
      colour: 'Natural Fell Grey',
      quantityBalls: quantity,
      weightGrams: quantity * 100,
      status: 'Planning',
      notes: 'Custom project saved from digital wool workbench.'
    });
    setTitle('');
    setShowAdd(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div
        className="relative w-full max-w-3xl bg-[#F3F0E8] border border-[#CDBFA8] rounded shadow-2xl overflow-hidden my-auto max-h-[90vh] flex flex-col font-mono text-xs"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-6 bg-[#E8E0D2] border-b border-[#CDBFA8] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <FolderKanban className="w-5 h-5 text-[#A33E32]" />
            <div>
              <span className="font-bold text-sm tracking-wider uppercase text-[#191918] block">
                MY PROJECTS · DIGITAL WOOL WORKBENCH
              </span>
              <span className="text-[10px] text-[#77766F] uppercase">
                ACTIVE WORKBENCH PROJECTS & GAUGE NOTES
              </span>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="p-1 rounded hover:bg-[#CDBFA8] text-[#191918]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action bar */}
        <div className="p-4 bg-[#F3F0E8] border-b border-[#CDBFA8]/60 flex justify-between items-center">
          <span className="text-[11px] text-[#77766F] uppercase">
            {projects.length} Saved Projects
          </span>
          <button
            onClick={() => setShowAdd(!showAdd)}
            className="px-3 py-1.5 bg-[#191918] text-white rounded text-xs uppercase flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{showAdd ? 'Cancel' : 'Add Project'}</span>
          </button>
        </div>

        {showAdd && (
          <form onSubmit={handleSubmit} className="p-4 bg-[#E8E0D2]/60 border-b border-[#CDBFA8] space-y-3">
            <div>
              <label className="text-[10px] uppercase text-[#77766F] block mb-1">PROJECT TITLE:</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Fair Isle Slipover Vest"
                className="w-full bg-[#F3F0E8] border border-[#CDBFA8] rounded p-2 text-[#191918] outline-none"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] uppercase text-[#77766F] block mb-1">YARN SPEC:</label>
                <input
                  type="text"
                  value={yarnName}
                  onChange={(e) => setYarnName(e.target.value)}
                  className="w-full bg-[#F3F0E8] border border-[#CDBFA8] rounded p-2 text-[#191918] outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase text-[#77766F] block mb-1">SKEINS (100G):</label>
                <input
                  type="number"
                  min="1"
                  max="40"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full bg-[#F3F0E8] border border-[#CDBFA8] rounded p-2 text-[#191918] outline-none"
                />
              </div>
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-[#A33E32] text-white font-bold rounded uppercase"
            >
              Save to Workbench
            </button>
          </form>
        )}

        {/* Projects List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
          {projects.map((p) => (
            <div
              key={p.id}
              className="p-4 bg-[#E8E0D2]/40 border border-[#CDBFA8] rounded flex justify-between items-center"
            >
              <div>
                <span className="text-[10px] text-[#A33E32] font-semibold uppercase block">
                  {p.category} · {p.createdAt}
                </span>
                <h4 className="font-serif text-lg font-bold text-[#191918]">
                  {p.title}
                </h4>
                <span className="text-[11px] text-[#30302D]">
                  {p.yarnName} ({p.quantityBalls} × 100g) · {p.colour}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <select
                  value={p.status}
                  onChange={(e) => updateProjectStatus(p.id, e.target.value as any)}
                  className="bg-[#F3F0E8] border border-[#CDBFA8] rounded p-1 text-[11px] text-[#191918]"
                >
                  <option value="Planning">Planning</option>
                  <option value="Yarn Acquired">Yarn Acquired</option>
                  <option value="On Needles">On Needles</option>
                  <option value="Finishing">Finishing</option>
                  <option value="Archived">Archived</option>
                </select>

                <button
                  onClick={() => deleteProject(p.id)}
                  className="p-1.5 text-[#77766F] hover:text-[#A33E32]"
                  title="Delete"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
