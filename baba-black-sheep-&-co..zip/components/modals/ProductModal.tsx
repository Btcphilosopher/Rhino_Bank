'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useEmporium } from '@/lib/store';
import { X, ShoppingBag, ShieldCheck, ChevronDown, ChevronUp, Check, Ruler, ArrowRight } from 'lucide-react';

export default function ProductModal() {
  const { selectedProduct, closeModal, addToBasket, openModal } = useEmporium();
  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [selectedVariantId, setSelectedVariantId] = useState<string | undefined>(
    selectedProduct?.variants?.[0]?.id
  );
  const [quantity, setQuantity] = useState(1);
  const [isAdded, setIsAdded] = useState(false);
  const [showTechnical, setShowTechnical] = useState(true);

  if (!selectedProduct) return null;

  const handleAdd = () => {
    addToBasket(selectedProduct, quantity, selectedVariantId);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div
        className="relative w-full max-w-5xl bg-[#F3F0E8] border border-[#CDBFA8] rounded shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#CDBFA8] bg-[#E8E0D2] shrink-0 text-xs font-mono">
          <div className="flex items-center gap-3">
            <span className="font-bold text-[#191918]">
              ARCHIVE SPECIMEN · {selectedProduct.category}
            </span>
            <button
              onClick={() => openModal('traceability', selectedProduct.lotNumber)}
              className="hidden sm:inline-flex items-center gap-1 text-[#A33E32] hover:underline"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>LOT {selectedProduct.lotNumber} CERTIFIED</span>
            </button>
          </div>

          <button
            onClick={closeModal}
            aria-label="Close product view"
            className="p-1 rounded hover:bg-[#CDBFA8] text-[#30302D] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="overflow-y-auto p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left: Gallery (6 cols) */}
          <div className="lg:col-span-6 flex flex-col gap-4">
            {/* Big Main Image */}
            <div className="relative aspect-[4/3] w-full rounded bg-[#30302D] overflow-hidden border border-[#CDBFA8]">
              <Image
                src={selectedProduct.images[selectedImageIdx] || selectedProduct.images[0]}
                alt={selectedProduct.name}
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-3 left-3 bg-[#191918]/85 text-[#E8E0D2] px-2.5 py-1 rounded text-[10px] font-mono tracking-wider uppercase">
                {selectedImageIdx === 0 && 'ANGLE 01 · PRODUCT MASTER'}
                {selectedImageIdx === 1 && 'ANGLE 02 · MACRO FIBRE SCAN'}
                {selectedImageIdx === 2 && 'ANGLE 03 · TEXTILE CONTEXT'}
                {selectedImageIdx === 3 && 'ANGLE 04 · FLEECE PROVENANCE'}
              </div>
            </div>

            {/* Thumbnail Selectors */}
            <div className="grid grid-cols-4 gap-2">
              {selectedProduct.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImageIdx(idx)}
                  className={`relative aspect-[4/3] rounded overflow-hidden border transition-all ${
                    selectedImageIdx === idx ? 'border-[#191918] ring-2 ring-[#191918]' : 'border-[#CDBFA8] opacity-70 hover:opacity-100'
                  }`}
                >
                  <Image
                    src={img}
                    alt={`Thumbnail ${idx}`}
                    fill
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </button>
              ))}
            </div>

            {/* Traceability Callout */}
            <div className="p-4 bg-[#E8E0D2]/50 border border-[#CDBFA8] rounded text-xs font-mono flex items-center justify-between">
              <div>
                <span className="text-[#77766F] block text-[10px] uppercase">CHAIN OF CUSTODY</span>
                <span className="text-[#191918] font-bold">Provenance: {selectedProduct.origin}</span>
              </div>
              <button
                onClick={() => openModal('traceability', selectedProduct.lotNumber)}
                className="text-[#A33E32] hover:underline font-semibold flex items-center gap-1"
              >
                <span>Audit Lot</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Right: Technical Spec & Purchase (6 cols) */}
          <div className="lg:col-span-6 flex flex-col justify-between">
            <div>
              {/* Category & Breed */}
              <div className="flex items-center justify-between text-xs font-mono text-[#77766F] uppercase mb-1">
                <span>{selectedProduct.breed} BREED</span>
                <span>{selectedProduct.subCategory}</span>
              </div>

              {/* Title */}
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#191918] mb-3 leading-tight">
                {selectedProduct.name}
              </h2>

              {/* Price & Unit */}
              <div className="flex items-baseline gap-2 mb-6">
                <span className="font-mono text-2xl sm:text-3xl font-bold text-[#191918] tabular-nums">
                  £{selectedProduct.price.toFixed(2)}
                </span>
                <span className="text-xs font-mono text-[#77766F]">
                  / {selectedProduct.unit}
                </span>
              </div>

              <p className="text-sm font-sans text-[#30302D] leading-relaxed mb-6">
                {selectedProduct.description}
              </p>

              {/* Variant Picker (if any) */}
              {selectedProduct.variants && selectedProduct.variants.length > 0 && (
                <div className="mb-6">
                  <label className="text-xs font-mono text-[#77766F] uppercase tracking-wider block mb-2">
                    AVAILABLE SHADE VARIANTS:
                  </label>
                  <div className="flex flex-wrap gap-2 text-xs font-mono">
                    {selectedProduct.variants.map((v) => (
                      <button
                        key={v.id}
                        onClick={() => setSelectedVariantId(v.id)}
                        className={`flex items-center gap-2 px-3 py-2 rounded border transition-colors ${
                          selectedVariantId === v.id
                            ? 'bg-[#191918] text-white border-[#191918]'
                            : 'bg-[#E8E0D2] text-[#30302D] border-[#CDBFA8] hover:border-[#191918]'
                        }`}
                      >
                        <span
                          className="w-2.5 h-2.5 rounded-full border border-black/20"
                          style={{ backgroundColor: v.hex }}
                        />
                        <span>{v.name}</span>
                        <span className="text-[10px] opacity-60">({v.stock} in stock)</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Expandable Technical Data Sheet */}
              <div className="border border-[#CDBFA8] rounded overflow-hidden mb-6 bg-[#E8E0D2]/30">
                <button
                  onClick={() => setShowTechnical(!showTechnical)}
                  className="w-full p-3.5 bg-[#E8E0D2] flex items-center justify-between text-xs font-mono uppercase tracking-wider font-bold text-[#191918]"
                >
                  <span>Material Assay & Fibre Specifications</span>
                  {showTechnical ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                {showTechnical && (
                  <div className="p-4 space-y-2 text-xs font-mono text-[#30302D] divide-y divide-[#CDBFA8]/40">
                    <div className="flex justify-between py-1">
                      <span className="text-[#77766F]">FIBRE DIAMETER:</span>
                      <span className="font-bold text-[#A33E32]">{selectedProduct.technical.fibreDiameter}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-[#77766F]">STAPLE LENGTH:</span>
                      <span>{selectedProduct.technical.stapleLength}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-[#77766F]">CRIMP FREQUENCY:</span>
                      <span>{selectedProduct.technical.crimp}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-[#77766F]">HANDLE & TACTILITY:</span>
                      <span>{selectedProduct.technical.handle}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-[#77766F]">THERMAL WARMTH:</span>
                      <span>{selectedProduct.technical.warmth}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-[#77766F]">DURABILITY RATING:</span>
                      <span>{selectedProduct.technical.durability}</span>
                    </div>
                  </div>
                )}
              </div>

              <div className="text-[10px] font-mono text-[#77766F] italic mb-6">
                Demonstration material data — verify against final supplier lot certificate.
              </div>

            </div>

            {/* Quantity Stepper & Add to Basket */}
            <div className="pt-4 border-t border-[#CDBFA8] flex items-center gap-4">
              <div className="flex items-center border border-[#CDBFA8] bg-[#E8E0D2] rounded text-xs font-mono">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-2.5 font-bold hover:bg-[#CDBFA8] transition-colors"
                >
                  -
                </button>
                <span className="px-4 py-2.5 font-bold tabular-nums">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-2.5 font-bold hover:bg-[#CDBFA8] transition-colors"
                >
                  +
                </button>
              </div>

              <button
                onClick={handleAdd}
                className={`flex-1 py-3 px-6 rounded text-xs font-mono uppercase tracking-wider font-semibold transition-colors flex items-center justify-center gap-2 ${
                  isAdded
                    ? 'bg-[#4D5847] text-white'
                    : 'bg-[#191918] hover:bg-[#30302D] text-[#F3F0E8]'
                }`}
              >
                {isAdded ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Added to Order Sheet</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>Add to Order Sheet (£{(selectedProduct.price * quantity).toFixed(2)})</span>
                  </>
                )}
              </button>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
