'use client';

import React from 'react';
import { useEmporium } from '@/lib/store';
import { TRACEABILITY_LOTS } from '@/lib/data';
import { X, ShieldCheck, CheckCircle2, FileText, AlertCircle, MapPin, Stamp } from 'lucide-react';

export default function TraceabilityModal() {
  const { selectedLot, closeModal } = useEmporium();

  if (!selectedLot) return null;

  const lotData = TRACEABILITY_LOTS[selectedLot] || {
    lotNumber: selectedLot,
    productName: 'Baba British Wool Specimen',
    breed: 'Native British Breed',
    region: 'Yorkshire Pennines & Fells',
    shearSeason: 'Summer Harvest 2025',
    processor: 'Synthetic Northern Wool Scourers',
    scouringFacility: 'Pennine Wash Works',
    spinningMill: 'Calder Valley Worsted Mills',
    micronCertified: '32.0 μm Average',
    naturalLot: true,
    notes: 'Pure untreated British wool. Clean scoured in soft water.'
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div
        className="relative w-full max-w-2xl bg-[#F3F0E8] border-2 border-[#191918] rounded shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col font-mono"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Certificate Header Banner */}
        <div className="p-6 bg-[#E8E0D2] border-b-2 border-[#191918] flex items-center justify-between text-xs">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#A33E32]" />
              <span className="font-bold text-sm tracking-wider uppercase text-[#191918]">
                BABA BLACK SHEEP & CO. / LOT PASSPORT
              </span>
            </div>
            <span className="text-[10px] text-[#77766F] block mt-0.5">
              OFFICIAL SPECIFICATION & PROVENANCE ASSAY
            </span>
          </div>

          <button
            onClick={closeModal}
            aria-label="Close traceability certificate"
            className="p-1 rounded hover:bg-[#CDBFA8] text-[#191918] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Certificate Body (Parchment aesthetic) */}
        <div className="p-6 sm:p-8 space-y-6 text-xs bg-[#F3F0E8]">
          
          <div className="flex justify-between items-start border-b border-[#CDBFA8] pb-4">
            <div>
              <span className="text-[#77766F] uppercase text-[10px]">VERIFIED LOT NUMBER:</span>
              <h2 className="text-xl font-bold text-[#191918] tracking-widest">
                {lotData.lotNumber}
              </h2>
              <span className="text-xs text-[#A33E32] font-semibold">{lotData.productName}</span>
            </div>

            <div className="text-right">
              <span className="text-[#77766F] uppercase text-[10px]">HARVEST SEASON:</span>
              <span className="block font-bold text-[#191918]">{lotData.shearSeason}</span>
              <span className="inline-block px-2 py-0.5 mt-1 bg-[#4D5847] text-white text-[10px] rounded">
                {lotData.naturalLot ? '100% UNDYED' : 'VAT DYED'}
              </span>
            </div>
          </div>

          {/* Custody Chain Table */}
          <div className="space-y-3 divide-y divide-[#CDBFA8]/60 text-xs">
            <div className="flex justify-between pt-2">
              <span className="text-[#77766F]">BREED ORIGIN:</span>
              <span className="font-bold text-[#191918] text-right">{lotData.breed}</span>
            </div>

            <div className="flex justify-between pt-2">
              <span className="text-[#77766F]">GRAZING REGION:</span>
              <span className="font-bold text-[#191918] text-right">{lotData.region}</span>
            </div>

            <div className="flex justify-between pt-2">
              <span className="text-[#77766F]">SCOURING FACILITY:</span>
              <span className="text-[#191918] text-right">{lotData.scouringFacility}</span>
            </div>

            <div className="flex justify-between pt-2">
              <span className="text-[#77766F]">SPINNING MILL:</span>
              <span className="text-[#191918] text-right">{lotData.spinningMill}</span>
            </div>

            {lotData.weavingMill && (
              <div className="flex justify-between pt-2">
                <span className="text-[#77766F]">WEAVING MILL:</span>
                <span className="text-[#191918] text-right">{lotData.weavingMill}</span>
              </div>
            )}

            <div className="flex justify-between pt-2">
              <span className="text-[#77766F]">CERTIFIED MICRON (LASERSCAN):</span>
              <span className="font-bold text-[#A33E32] text-right">{lotData.micronCertified}</span>
            </div>
          </div>

          {/* Notes Callout */}
          <div className="p-3.5 bg-[#E8E0D2] rounded border border-[#CDBFA8] text-[11px] leading-relaxed">
            <span className="font-bold text-[#191918] block mb-0.5">MILL MASTER NOTES:</span>
            <p className="text-[#30302D]">{lotData.notes}</p>
          </div>

          {/* Stamp & Verification */}
          <div className="pt-4 border-t-2 border-[#191918] flex items-center justify-between text-[10px] text-[#77766F]">
            <div className="flex items-center gap-1.5 text-[#30302D]">
              <CheckCircle2 className="w-4 h-4 text-[#4D5847]" />
              <span>CHAIN OF CUSTODY VERIFIED (SYNTHETIC RECORD)</span>
            </div>
            <span>ISSUED AT BRADFORD ARCHIVE</span>
          </div>

        </div>

        {/* Bottom Disclaimer Strip */}
        <div className="p-3 bg-[#191918] text-[#CDBFA8] text-[10px] flex items-center gap-2">
          <AlertCircle className="w-3.5 h-3.5 text-[#B28A35] shrink-0" />
          <span>Demonstration lot data — synthetic supply chain simulation. Does not claim real farm certification.</span>
        </div>

      </div>
    </div>
  );
}
