'use client';

import React, { useState } from 'react';
import { useEmporium } from '@/lib/store';
import { PRODUCTS, BREEDS } from '@/lib/data';
import { Search, X, ArrowRight, Tag, SlidersHorizontal } from 'lucide-react';

export default function SearchModal() {
  const { closeModal, openModal } = useEmporium();
  const [query, setQuery] = useState('');
  const [filterBreed, setFilterBreed] = useState('ALL');
  const [filterCategory, setFilterCategory] = useState('ALL');
  const [filterColourType, setFilterColourType] = useState<'ALL' | 'NATURAL' | 'DYED'>('ALL');

  const results = PRODUCTS.filter((item) => {
    // Text search matching name, breed, origin, colour, subcategory, lot, description
    const textTarget = `${item.name} ${item.breed} ${item.origin} ${item.colourName} ${item.subCategory} ${item.lotNumber} ${item.description} ${item.applications.join(' ')}`.toLowerCase();
    const queryMatch = !query.trim() || textTarget.includes(query.toLowerCase());

    if (!queryMatch) return false;
    if (filterBreed !== 'ALL' && !item.breed.toLowerCase().includes(filterBreed.toLowerCase())) return false;
    if (filterCategory !== 'ALL' && item.category !== filterCategory) return false;
    if (filterColourType === 'NATURAL' && !item.isNaturalColour) return false;
    if (filterColourType === 'DYED' && item.isNaturalColour) return false;

    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-3 sm:p-6 pt-16 sm:pt-20 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div
        className="relative w-full max-w-3xl bg-[#F3F0E8] border border-[#CDBFA8] rounded shadow-2xl overflow-hidden font-mono text-xs flex flex-col max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="p-4 sm:p-6 bg-[#E8E0D2] border-b border-[#CDBFA8] flex items-center gap-3">
          <Search className="w-5 h-5 text-[#77766F] shrink-0" />
          <input
            type="text"
            placeholder="Search archive: Swaledale, Grey DK, Tweed, Upholstery, Lot BBS..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            className="flex-1 bg-transparent text-[#191918] placeholder-[#77766F] text-sm outline-none font-mono"
          />
          <button
            onClick={closeModal}
            className="p-1 rounded hover:bg-[#CDBFA8] text-[#191918]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Filter Tags Strip */}
        <div className="p-4 bg-[#F3F0E8] border-b border-[#CDBFA8]/60 flex flex-wrap items-center gap-2 text-[11px]">
          <span className="text-[#77766F] uppercase">Quick Filters:</span>
          
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="bg-[#E8E0D2] border border-[#CDBFA8] rounded px-2 py-1 text-[#191918]"
          >
            <option value="ALL">All Sectors</option>
            <option value="YARN">Yarn</option>
            <option value="CLOTH">Cloth</option>
            <option value="WOOL">Fleece/Wool</option>
            <option value="HOME">Home</option>
            <option value="CLOTHING">Clothing</option>
          </select>

          <select
            value={filterBreed}
            onChange={(e) => setFilterBreed(e.target.value)}
            className="bg-[#E8E0D2] border border-[#CDBFA8] rounded px-2 py-1 text-[#191918]"
          >
            <option value="ALL">All Breeds</option>
            {BREEDS.map(b => (
              <option key={b.id} value={b.name}>{b.name}</option>
            ))}
          </select>

          <div className="flex items-center gap-1 bg-[#E8E0D2] p-0.5 rounded">
            <button
              onClick={() => setFilterColourType('ALL')}
              className={`px-2 py-0.5 rounded ${filterColourType === 'ALL' ? 'bg-[#191918] text-white' : ''}`}
            >
              All Shades
            </button>
            <button
              onClick={() => setFilterColourType('NATURAL')}
              className={`px-2 py-0.5 rounded ${filterColourType === 'NATURAL' ? 'bg-[#191918] text-white' : ''}`}
            >
              Undyed
            </button>
            <button
              onClick={() => setFilterColourType('DYED')}
              className={`px-2 py-0.5 rounded ${filterColourType === 'DYED' ? 'bg-[#191918] text-white' : ''}`}
            >
              Dyed
            </button>
          </div>
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 divide-y divide-[#CDBFA8]/60">
          <div className="pb-2 text-[11px] text-[#77766F] uppercase flex justify-between">
            <span>QUERY MATCHES ({results.length} MATERIALS FOUND)</span>
            <span>PRESS ESCAPE OR CLICK TO INSPECT</span>
          </div>

          {results.length === 0 ? (
            <div className="py-12 text-center text-[#77766F]">
              <p className="font-serif text-xl text-[#191918] mb-1">No matching archive lots found</p>
              <p className="text-xs">Try searching for &ldquo;Swaledale&rdquo;, &ldquo;Tweed&rdquo;, &ldquo;Indigo&rdquo;, or &ldquo;Herdwick&rdquo;</p>
            </div>
          ) : (
            results.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  closeModal();
                  openModal('product', item.id);
                }}
                className="group cursor-pointer py-3 hover:bg-[#E8E0D2]/50 px-2 rounded flex items-center justify-between transition-colors"
              >
                <div>
                  <div className="flex items-center gap-2 text-[10px] text-[#77766F] uppercase">
                    <span>LOT {item.lotNumber}</span>
                    <span>·</span>
                    <span>{item.breed}</span>
                    <span>·</span>
                    <span>{item.subCategory}</span>
                  </div>

                  <h4 className="font-serif text-base font-bold text-[#191918] group-hover:text-[#A33E32] transition-colors">
                    {item.name}
                  </h4>

                  <span className="text-xs text-[#30302D]">
                    {item.colourName} · {item.handle} · {item.origin}
                  </span>
                </div>

                <div className="text-right">
                  <span className="font-mono text-sm font-bold text-[#191918] block tabular-nums">
                    £{item.price.toFixed(2)}
                  </span>
                  <span className="text-[11px] text-[#A33E32] flex items-center gap-1 group-hover:underline">
                    <span>Inspect</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
}
