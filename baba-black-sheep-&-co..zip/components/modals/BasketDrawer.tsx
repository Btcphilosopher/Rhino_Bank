'use client';

import React, { useState } from 'react';
import { useEmporium } from '@/lib/store';
import { X, Trash2, ArrowRight, CheckCircle2, Shield, ShoppingBag, Receipt, Printer } from 'lucide-react';

export default function BasketDrawer() {
  const { basket, removeFromBasket, updateQuantity, clearBasket, basketTotal, closeModal } = useEmporium();
  
  // Checkout flow states: 'bag' | 'details' | 'delivery' | 'payment' | 'confirm'
  const [step, setStep] = useState<'bag' | 'details' | 'delivery' | 'payment' | 'confirm'>('bag');

  // Customer form state
  const [customerName, setCustomerName] = useState('Eleanor Vance');
  const [email, setEmail] = useState('eleanor.vance@yorkshirewool.co.uk');
  const [address, setAddress] = useState('42 Calder Mill Lane, Hebden Bridge, West Yorkshire');
  const [postcode, setPostcode] = useState('HX7 6AB');
  const [deliveryMethod, setDeliveryMethod] = useState<'standard' | 'express'>('standard');
  const [orderNumber, setOrderNumber] = useState('004182');

  const deliveryCost = deliveryMethod === 'standard' ? (basketTotal > 80 ? 0 : 4.50) : 9.00;
  const grandTotal = basketTotal + deliveryCost;

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const newOrderNum = `BBS-${Math.floor(100000 + Math.random() * 900000)}`;
    setOrderNumber(newOrderNum);
    setStep('confirm');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-sm">
      <div
        className="w-full max-w-xl h-full bg-[#F3F0E8] border-l border-[#CDBFA8] shadow-2xl flex flex-col font-mono text-xs overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Merchant Order Sheet Header */}
        <div className="p-6 bg-[#E8E0D2] border-b border-[#CDBFA8] flex items-center justify-between shrink-0">
          <div>
            <span className="font-bold text-sm tracking-wider uppercase text-[#191918] block">
              BABA BLACK SHEEP & CO.
            </span>
            <span className="text-[11px] text-[#77766F] uppercase">
              MERCHANT&apos;S DISPATCH ORDER SHEET #{orderNumber}
            </span>
          </div>

          <button
            onClick={closeModal}
            aria-label="Close basket"
            className="p-1.5 rounded hover:bg-[#CDBFA8] text-[#191918] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Bar (when checking out) */}
        {step !== 'confirm' && (
          <div className="bg-[#191918] text-[#CDBFA8] px-6 py-2.5 flex items-center justify-between text-[10px] uppercase tracking-wider shrink-0">
            <span className={step === 'bag' ? 'text-white font-bold' : ''}>01. BAG</span>
            <span>&rarr;</span>
            <span className={step === 'details' ? 'text-white font-bold' : ''}>02. DETAILS</span>
            <span>&rarr;</span>
            <span className={step === 'delivery' ? 'text-white font-bold' : ''}>03. DELIVERY</span>
            <span>&rarr;</span>
            <span className={step === 'payment' ? 'text-white font-bold' : ''}>04. PAYMENT</span>
          </div>
        )}

        {/* Step 1: Traditional Order Sheet Bag */}
        {step === 'bag' && (
          <>
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {basket.length === 0 ? (
                <div className="text-center py-20 text-[#77766F]">
                  <ShoppingBag className="w-10 h-10 mx-auto mb-3 opacity-40" />
                  <p className="font-serif text-2xl text-[#191918] mb-1">Your Order Sheet is Empty</p>
                  <p className="text-xs">Explore the catalogue to select British yarns, cloths, and fleeces.</p>
                </div>
              ) : (
                <div className="space-y-4 divide-y divide-[#CDBFA8]/60">
                  {basket.map((item) => (
                    <div key={item.id} className="pt-4 first:pt-0 flex items-start justify-between gap-4">
                      <div>
                        <span className="text-[10px] text-[#77766F] uppercase block">
                          LOT {item.product.lotNumber} · {item.product.breed}
                        </span>
                        <h4 className="font-serif text-base font-bold text-[#191918] leading-tight">
                          {item.product.name}
                        </h4>
                        
                        {item.variantName && (
                          <span className="text-[11px] text-[#30302D] block">
                            Shade: {item.variantName}
                          </span>
                        )}

                        {item.customMetres && (
                          <span className="text-[11px] text-[#30302D] block">
                            Custom Cut: {item.customMetres} Metres
                          </span>
                        )}

                        <div className="flex items-center gap-2 mt-2">
                          <button
                            onClick={() => updateQuantity(item.id, -1)}
                            className="px-2 py-0.5 bg-[#E8E0D2] border border-[#CDBFA8] rounded hover:bg-[#CDBFA8]"
                          >
                            -
                          </button>
                          <span className="font-bold tabular-nums px-1">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.id, 1)}
                            className="px-2 py-0.5 bg-[#E8E0D2] border border-[#CDBFA8] rounded hover:bg-[#CDBFA8]"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="font-mono text-sm font-bold text-[#191918] block tabular-nums">
                          £{(item.product.price * item.quantity).toFixed(2)}
                        </span>
                        <span className="text-[10px] text-[#77766F] block">
                          (£{item.product.price.toFixed(2)} each)
                        </span>

                        <button
                          onClick={() => removeFromBasket(item.id)}
                          className="mt-2 text-[#A33E32] hover:text-[#874536] p-1"
                          title="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5 ml-auto" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Subtotal & Checkout Footer */}
            {basket.length > 0 && (
              <div className="p-6 bg-[#E8E0D2] border-t border-[#CDBFA8] space-y-3 shrink-0">
                <div className="flex justify-between text-xs text-[#30302D]">
                  <span>SUBTOTAL:</span>
                  <span className="font-bold tabular-nums">£{basketTotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-xs text-[#30302D]">
                  <span>DELIVERY (UK DISPATCH):</span>
                  <span className="tabular-nums">
                    {basketTotal > 80 ? 'FREE (OVER £80)' : '£4.50'}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-bold text-[#191918] pt-2 border-t border-[#CDBFA8]">
                  <span>TOTAL ESTIMATE:</span>
                  <span className="tabular-nums">
                    £{(basketTotal + (basketTotal > 80 ? 0 : 4.50)).toFixed(2)}
                  </span>
                </div>

                <button
                  onClick={() => setStep('details')}
                  className="w-full py-3 bg-[#191918] hover:bg-[#30302D] text-[#F3F0E8] font-bold rounded text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 mt-2"
                >
                  <span>Proceed to Dispatch Details</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </>
        )}

        {/* Step 2: Customer Details */}
        {step === 'details' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            <h3 className="font-serif text-2xl font-bold text-[#191918]">
              Customer & Delivery Address
            </h3>
            
            <div className="space-y-3">
              <div>
                <label className="text-[#77766F] block mb-1">FULL NAME / CONTACT:</label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2.5 text-[#191918] outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-[#77766F] block mb-1">EMAIL FOR DISPATCH DISCLOSURE:</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2.5 text-[#191918] outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-[#77766F] block mb-1">STREET ADDRESS:</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2.5 text-[#191918] outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-[#77766F] block mb-1">POSTCODE:</label>
                <input
                  type="text"
                  value={postcode}
                  onChange={(e) => setPostcode(e.target.value)}
                  className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2.5 text-[#191918] outline-none"
                  required
                />
              </div>
            </div>

            <div className="pt-6 flex justify-between gap-3">
              <button
                onClick={() => setStep('bag')}
                className="px-4 py-2.5 border border-[#CDBFA8] rounded uppercase"
              >
                &larr; Back to Order
              </button>
              <button
                onClick={() => setStep('delivery')}
                className="px-6 py-2.5 bg-[#191918] text-white rounded uppercase font-bold"
              >
                Delivery Options &rarr;
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Delivery Selection */}
        {step === 'delivery' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            <h3 className="font-serif text-2xl font-bold text-[#191918]">
              Select Shipping Carrier
            </h3>

            <div className="space-y-3">
              <label
                onClick={() => setDeliveryMethod('standard')}
                className={`p-4 rounded border cursor-pointer flex justify-between items-center transition-colors ${
                  deliveryMethod === 'standard' ? 'bg-[#E8E0D2] border-[#191918]' : 'bg-[#F3F0E8] border-[#CDBFA8]'
                }`}
              >
                <div>
                  <span className="font-bold text-[#191918] block">Royal Mail Tracked 48</span>
                  <span className="text-[#77766F] text-[11px]">2–3 working days from Yorkshire Mill</span>
                </div>
                <span className="font-bold tabular-nums">
                  {basketTotal > 80 ? 'FREE' : '£4.50'}
                </span>
              </label>

              <label
                onClick={() => setDeliveryMethod('express')}
                className={`p-4 rounded border cursor-pointer flex justify-between items-center transition-colors ${
                  deliveryMethod === 'express' ? 'bg-[#E8E0D2] border-[#191918]' : 'bg-[#F3F0E8] border-[#CDBFA8]'
                }`}
              >
                <div>
                  <span className="font-bold text-[#191918] block">Direct Courier Priority Tracked</span>
                  <span className="text-[#77766F] text-[11px]">Next-day delivery with wool lot seals</span>
                </div>
                <span className="font-bold tabular-nums">£9.00</span>
              </label>
            </div>

            <div className="pt-6 flex justify-between gap-3">
              <button
                onClick={() => setStep('details')}
                className="px-4 py-2.5 border border-[#CDBFA8] rounded uppercase"
              >
                &larr; Back
              </button>
              <button
                onClick={() => setStep('payment')}
                className="px-6 py-2.5 bg-[#191918] text-white rounded uppercase font-bold"
              >
                Payment Verification &rarr;
              </button>
            </div>
          </div>
        )}

        {/* Step 4: Simulated Payment */}
        {step === 'payment' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            <h3 className="font-serif text-2xl font-bold text-[#191918]">
              Simulated Payment Settlement
            </h3>

            <div className="bg-[#E8E0D2] p-4 rounded border border-[#CDBFA8] space-y-2">
              <div className="flex justify-between">
                <span>DESTINATION:</span>
                <span className="font-bold">{customerName}</span>
              </div>
              <div className="flex justify-between">
                <span>ADDRESS:</span>
                <span className="truncate max-w-[260px]">{address}, {postcode}</span>
              </div>
              <div className="flex justify-between font-bold text-sm text-[#191918] pt-2 border-t border-[#CDBFA8]">
                <span>TOTAL SETTLEMENT:</span>
                <span>£{grandTotal.toFixed(2)}</span>
              </div>
            </div>

            <div className="p-4 bg-[#F3F0E8] border border-[#CDBFA8] rounded text-[11px] text-[#77766F] flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#4D5847] shrink-0" />
              <span>Simulated Payment Gateway. No credit card or actual monetary transaction is processed.</span>
            </div>

            <div className="pt-6 flex justify-between gap-3">
              <button
                onClick={() => setStep('delivery')}
                className="px-4 py-2.5 border border-[#CDBFA8] rounded uppercase"
              >
                &larr; Back
              </button>
              <button
                onClick={handlePlaceOrder}
                className="px-6 py-3 bg-[#A33E32] hover:bg-[#874536] text-white rounded uppercase font-bold transition-colors"
              >
                Authorise Order (£{grandTotal.toFixed(2)})
              </button>
            </div>
          </div>
        )}

        {/* Step 5: Confirmation Receipt */}
        {step === 'confirm' && (
          <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6 text-center">
            <div className="w-12 h-12 rounded-full bg-[#4D5847] text-white flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>

            <div>
              <span className="text-xs font-mono text-[#A33E32] font-semibold uppercase tracking-wider block">
                ORDER DISPATCH CONFIRMED
              </span>
              <h3 className="font-serif text-3xl font-bold text-[#191918] mt-1">
                Receipt #{orderNumber}
              </h3>
              <p className="text-xs text-[#77766F] mt-2 max-w-sm mx-auto">
                Thank you, {customerName}. Your order sheet has been recorded at the Bradford dispatch depot.
              </p>
            </div>

            <div className="bg-[#E8E0D2] p-5 rounded border border-[#CDBFA8] text-left text-xs space-y-2">
              <div className="flex justify-between pb-2 border-b border-[#CDBFA8]">
                <span className="text-[#77766F]">DATE:</span>
                <span>{new Date().toLocaleDateString('en-GB')}</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-[#CDBFA8]">
                <span className="text-[#77766F]">DISPATCH TARGET:</span>
                <span>{address}, {postcode}</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-[#CDBFA8]">
                <span className="text-[#77766F]">TOTAL PAID (SIMULATED):</span>
                <span className="font-bold text-[#191918]">£{grandTotal.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex justify-center gap-3 pt-4">
              <button
                onClick={() => {
                  clearBasket();
                  closeModal();
                }}
                className="px-6 py-2.5 bg-[#191918] text-[#F3F0E8] rounded uppercase font-semibold text-xs tracking-wider"
              >
                Return to Emporium
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
