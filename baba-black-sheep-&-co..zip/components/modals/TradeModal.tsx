'use client';

import React, { useState } from 'react';
import { useEmporium } from '@/lib/store';
import { X, Building2, Package, FileText, CheckCircle2 } from 'lucide-react';

export default function TradeModal() {
  const { closeModal, addTradeQuote, addSampleRequest } = useEmporium();
  const [subTab, setSubTab] = useState<'quote' | 'samples'>('quote');

  const [projectName, setProjectName] = useState('Clifton Hotel Project');
  const [companyName, setCompanyName] = useState('Bespoke Interiors Ltd');
  const [email, setEmail] = useState('spec@bespokeinteriors.co.uk');
  const [metres, setMetres] = useState(120);
  const [quoteSuccess, setQuoteSuccess] = useState<any>(null);

  const [sampleCompany, setSampleCompany] = useState('');
  const [sampleAddress, setSampleAddress] = useState('');
  const [sampleSuccess, setSampleSuccess] = useState(false);

  const handleQuoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const rate = 95.00;
    const q = addTradeQuote({
      projectName,
      companyName,
      email,
      materialName: 'North Country Tweed Herringbone',
      gsm: 560,
      widthMm: 1500,
      colourName: 'Natural Charcoal',
      quantityMetres: metres,
      totalEstimate: metres * rate,
    });
    setQuoteSuccess(q);
  };

  const handleSampleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addSampleRequest({
      name: 'Trade Specifier',
      company: sampleCompany || 'Architectural Practice',
      address: sampleAddress || '10 Hanover Square, London',
      sampleTypes: ['Cloth Swatches (Tweed)', 'Contract Upholstery', 'Yarn Shade Cards'],
      notes: 'B2B Trade sample library request from portal.'
    });
    setSampleSuccess(true);
    setTimeout(() => {
      setSampleSuccess(false);
      closeModal();
    }, 2200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div
        className="relative w-full max-w-3xl bg-[#F3F0E8] border border-[#CDBFA8] rounded shadow-2xl overflow-hidden my-auto max-h-[90vh] flex flex-col font-mono text-xs"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-6 bg-[#E8E0D2] border-b border-[#CDBFA8] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-[#A33E32]" />
            <div>
              <span className="font-bold text-sm tracking-wider uppercase text-[#191918] block">
                TRADE & ARCHITECTURAL SPECIFICATION SERVICE
              </span>
              <span className="text-[10px] text-[#77766F] uppercase">
                COMMERCIAL CLOTH SUPPLY · SAMPLE ARCHIVE
              </span>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="p-1 rounded hover:bg-[#CDBFA8] text-[#191918]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="bg-[#191918] text-[#E8E0D2] px-6 py-2 flex items-center gap-4 text-xs font-mono">
          <button
            onClick={() => setSubTab('quote')}
            className={`py-1 uppercase ${subTab === 'quote' ? 'text-white border-b-2 border-[#A33E32] font-bold' : 'text-[#CDBFA8]'}`}
          >
            B2B Specification Generator
          </button>
          <button
            onClick={() => setSubTab('samples')}
            className={`py-1 uppercase ${subTab === 'samples' ? 'text-white border-b-2 border-[#A33E32] font-bold' : 'text-[#CDBFA8]'}`}
          >
            Order Material Sample Box
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {subTab === 'quote' && (
            <div className="space-y-4">
              <form onSubmit={handleQuoteSubmit} className="space-y-3">
                <div>
                  <label className="text-[10px] uppercase text-[#77766F] block mb-1">PROJECT NAME:</label>
                  <input
                    type="text"
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2 text-[#191918] outline-none"
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] uppercase text-[#77766F] block mb-1">COMPANY NAME:</label>
                    <input
                      type="text"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2 text-[#191918] outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase text-[#77766F] block mb-1">CONTACT EMAIL:</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2 text-[#191918] outline-none"
                      required
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] uppercase text-[#77766F] block mb-1">METRES REQUIRED (MIN 50M):</label>
                  <input
                    type="number"
                    min="50"
                    max="10000"
                    value={metres}
                    onChange={(e) => setMetres(Number(e.target.value))}
                    className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2 text-[#191918] outline-none"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-[#A33E32] text-white font-bold rounded uppercase tracking-wider mt-2"
                >
                  Generate Official Specification Doc
                </button>
              </form>

              {quoteSuccess && (
                <div className="p-4 bg-[#E8E0D2] rounded border border-[#CDBFA8] space-y-1">
                  <div className="font-bold text-[#191918] text-sm">
                    DOCUMENT CREATED: {quoteSuccess.id}
                  </div>
                  <div className="text-[#30302D]">
                    Project: {quoteSuccess.projectName} ({quoteSuccess.quantityMetres} Metres)
                  </div>
                  <div className="font-bold text-[#A33E32]">
                    Contract Total: £{quoteSuccess.totalEstimate.toLocaleString()}.00
                  </div>
                  <div className="text-[10px] text-[#77766F] pt-2">
                    Official quote logged to merchant console.
                  </div>
                </div>
              )}
            </div>
          )}

          {subTab === 'samples' && (
            <form onSubmit={handleSampleSubmit} className="space-y-4">
              <p className="text-xs text-[#30302D]">
                Trade sample boxes are dispatched with complimentary standard postage to verified architectural and interior design studios.
              </p>

              <div>
                <label className="text-[10px] uppercase text-[#77766F] block mb-1">STUDIO / PRACTICE NAME:</label>
                <input
                  type="text"
                  placeholder="e.g. Forster Studio Architects"
                  value={sampleCompany}
                  onChange={(e) => setSampleCompany(e.target.value)}
                  className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2 text-[#191918] outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-[10px] uppercase text-[#77766F] block mb-1">DISPATCH ADDRESS:</label>
                <textarea
                  rows={3}
                  placeholder="Studio address..."
                  value={sampleAddress}
                  onChange={(e) => setSampleAddress(e.target.value)}
                  className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2 text-[#191918] outline-none"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#191918] hover:bg-[#30302D] text-white font-bold rounded uppercase tracking-wider flex items-center justify-center gap-2"
              >
                {sampleSuccess ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-[#68D391]" />
                    <span>Sample Order Received (Demo)</span>
                  </>
                ) : (
                  <>
                    <Package className="w-4 h-4" />
                    <span>Order Physical Swatch Library Box</span>
                  </>
                )}
              </button>
            </form>
          )}
        </div>

      </div>
    </div>
  );
}
