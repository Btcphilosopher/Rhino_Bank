'use client';

import React from 'react';
import Image from 'next/image';
import { useEmporium } from '@/lib/store';
import { PRODUCTS, BREEDS } from '@/lib/data';
import { X, ArrowRight, ShieldCheck, MapPin, Feather } from 'lucide-react';

export default function BreedModal() {
  const { selectedBreed, closeModal, openModal } = useEmporium();

  if (!selectedBreed) return null;

  // Find products made from this breed
  const relatedYarns = PRODUCTS.filter(p => p.breed.toLowerCase().includes(selectedBreed.name.toLowerCase()));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div
        className="relative w-full max-w-4xl bg-[#F3F0E8] border border-[#CDBFA8] rounded shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#CDBFA8] bg-[#E8E0D2] shrink-0 text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#A33E32]" />
            <span className="font-bold text-[#191918]">
              BREED DOSSIER · {selectedBreed.name.toUpperCase()}
            </span>
            <span className="text-[#77766F] hidden sm:inline">
              · {selectedBreed.region.toUpperCase()}
            </span>
          </div>

          <button
            onClick={closeModal}
            aria-label="Close breed dossier"
            className="p-1 rounded hover:bg-[#CDBFA8] text-[#30302D] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scroll Content */}
        <div className="overflow-y-auto p-6 sm:p-10 space-y-10">
          
          {/* Header Banner: Animal to Fleece */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="relative aspect-[4/3] rounded overflow-hidden bg-[#30302D] border border-[#CDBFA8]">
              <Image
                src={selectedBreed.portraitImage}
                alt={selectedBreed.name}
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-3 left-3 bg-[#191918]/85 text-[#E8E0D2] px-2.5 py-1 rounded text-[10px] font-mono tracking-wider uppercase">
                THE SHEEP · {selectedBreed.name}
              </div>
            </div>

            <div className="relative aspect-[4/3] rounded overflow-hidden bg-[#30302D] border border-[#CDBFA8]">
              <Image
                src={selectedBreed.fleeceImage}
                alt={`${selectedBreed.name} fleece`}
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-3 left-3 bg-[#191918]/85 text-[#E8E0D2] px-2.5 py-1 rounded text-[10px] font-mono tracking-wider uppercase">
                THE FLEECE · {selectedBreed.micron}
              </div>
            </div>
          </div>

          {/* SECTION 1: THE SHEEP & REGIONAL STORY */}
          <div>
            <span className="text-xs font-mono text-[#A33E32] font-semibold uppercase tracking-wider block mb-1">
              01 / THE SHEEP
            </span>
            <h3 className="font-serif text-3xl font-bold text-[#191918] mb-3">
              {selectedBreed.name} of the {selectedBreed.region}
            </h3>
            <p className="text-sm font-sans text-[#30302D] leading-relaxed mb-4">
              {selectedBreed.story}
            </p>
            <div className="bg-[#E8E0D2]/50 border-l-2 border-[#191918] p-3 text-xs font-mono text-[#77766F]">
              Historical Archive Note: {selectedBreed.historicalNote}
            </div>
          </div>

          {/* SECTION 2: THE FIBRE SPECIFICATIONS */}
          <div>
            <span className="text-xs font-mono text-[#A33E32] font-semibold uppercase tracking-wider block mb-1">
              02 / THE FIBRE
            </span>
            <h3 className="font-serif text-2xl font-bold text-[#191918] mb-4">
              Physical & Cellular Specifications
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
              <div className="bg-[#E8E0D2]/50 p-3 rounded border border-[#CDBFA8]">
                <span className="text-[#77766F] block text-[10px]">MICRON RANGE</span>
                <span className="font-bold text-[#A33E32] text-sm tabular-nums">{selectedBreed.micron}</span>
              </div>
              <div className="bg-[#E8E0D2]/50 p-3 rounded border border-[#CDBFA8]">
                <span className="text-[#77766F] block text-[10px]">STAPLE LENGTH</span>
                <span className="font-bold text-[#191918] text-sm tabular-nums">{selectedBreed.stapleLength}</span>
              </div>
              <div className="bg-[#E8E0D2]/50 p-3 rounded border border-[#CDBFA8]">
                <span className="text-[#77766F] block text-[10px]">CRIMP ARCHITECTURE</span>
                <span className="font-bold text-[#191918] text-sm">{selectedBreed.crimp}</span>
              </div>
              <div className="bg-[#E8E0D2]/50 p-3 rounded border border-[#CDBFA8]">
                <span className="text-[#77766F] block text-[10px]">SURFACE LUSTRE</span>
                <span className="font-bold text-[#191918] text-sm">{selectedBreed.lustre}</span>
              </div>
            </div>

            <div className="mt-4 p-4 bg-[#F3F0E8] border border-[#CDBFA8] rounded text-xs font-mono space-y-2">
              <div className="flex justify-between">
                <span className="text-[#77766F]">NATURAL COLOUR VARIETIES:</span>
                <span className="font-semibold">{selectedBreed.naturalColours.join(', ')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#77766F]">TACTILE HANDLE:</span>
                <span className="font-semibold">{selectedBreed.handle}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#77766F]">TENSILE STRENGTH & WARMTH:</span>
                <span className="font-semibold">{selectedBreed.strength} Strength · {selectedBreed.warmth} Warmth</span>
              </div>
            </div>
          </div>

          {/* SECTION 3: PRODUCTS & YARNS MADE FROM THIS BREED */}
          <div>
            <span className="text-xs font-mono text-[#A33E32] font-semibold uppercase tracking-wider block mb-1">
              03 / THE ARTEFACTS & YARNS
            </span>
            <h3 className="font-serif text-2xl font-bold text-[#191918] mb-4">
              Available Materials Produced from {selectedBreed.name}
            </h3>

            {relatedYarns.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {relatedYarns.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => openModal('product', p.id)}
                    className="group cursor-pointer bg-[#E8E0D2]/40 hover:bg-[#E8E0D2] border border-[#CDBFA8] p-4 rounded transition-colors flex items-center justify-between"
                  >
                    <div>
                      <span className="text-[10px] font-mono text-[#77766F] uppercase block">
                        LOT {p.lotNumber} · {p.category}
                      </span>
                      <h4 className="font-serif text-lg font-semibold text-[#191918] group-hover:text-[#A33E32] transition-colors">
                        {p.name}
                      </h4>
                      <span className="text-xs font-mono text-[#30302D]">
                        {p.colourName} · {p.handle}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="font-mono text-sm font-bold text-[#191918] block tabular-nums">
                        £{p.price.toFixed(2)}
                      </span>
                      <span className="text-xs font-mono text-[#A33E32] group-hover:underline">
                        Inspect &rarr;
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs font-mono text-[#77766F] italic">
                Raw fleeces for {selectedBreed.name} currently undergoing seasonal carding and worsted combing at the mill.
              </p>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}
