'use client';

import React, { useState } from 'react';
import { useEmporium } from '@/lib/store';
import { Building2, Package, FileText, CheckCircle2, ArrowRight, ShieldCheck, Download } from 'lucide-react';

export default function TradeSection() {
  const { addTradeQuote, addSampleRequest, tradeQuotes } = useEmporium();

  // Quote generator form
  const [projectName, setProjectName] = useState('Clifton Heritage Hotel');
  const [companyName, setCompanyName] = useState('Studio Craven Interior Architecture');
  const [email, setEmail] = useState('spec@studiocraven.co.uk');
  const [materialName, setMaterialName] = useState('Herdwick Architectural Upholstery Cloth');
  const [colourName, setColourName] = useState('Fellside Slate');
  const [quantityMetres, setQuantityMetres] = useState(184);
  const [quoteGenerated, setQuoteGenerated] = useState<any>(null);

  // Sample Box state
  const [selectedSamples, setSelectedSamples] = useState<string[]>([
    'Cloth Swatches (Tweed & Coating)',
    'Yarn Shade Cards',
    'Fibre & Breed Sample Specimens'
  ]);
  const [sampleSuccess, setSampleSuccess] = useState(false);

  const toggleSample = (item: string) => {
    setSelectedSamples(prev =>
      prev.includes(item) ? prev.filter(i => i !== item) : [...prev, item]
    );
  };

  const handleGenerateQuote = (e: React.FormEvent) => {
    e.preventDefault();
    const ratePerMetre = 110.0;
    const total = quantityMetres * ratePerMetre;
    const newQ = addTradeQuote({
      projectName,
      companyName,
      email,
      materialName,
      gsm: 680,
      widthMm: 1400,
      colourName,
      quantityMetres,
      totalEstimate: total,
    });
    setQuoteGenerated(newQ);
  };

  const handleOrderSampleLibrary = (e: React.FormEvent) => {
    e.preventDefault();
    addSampleRequest({
      name: 'Trade Specifier',
      company: companyName,
      address: 'Architectural Studio, London & Leeds',
      sampleTypes: selectedSamples,
      notes: 'Requesting 2026 British Wool Emporium Material Library Box.'
    });
    setSampleSuccess(true);
    setTimeout(() => setSampleSuccess(false), 3000);
  };

  return (
    <section id="trade-portal" className="bg-[#F3F0E8] py-24 px-4 sm:px-6 lg:px-8 border-b border-[#CDBFA8]/60">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6 pb-6 border-b border-[#CDBFA8]">
          <div>
            <span className="text-xs font-mono tracking-widest text-[#77746F] uppercase block mb-1">
              Section 10 · B2B Specifications & Architectural Supply
            </span>
            <h2 className="text-4xl sm:text-5xl font-serif text-[#191918] tracking-tight">
              Trade & Material Library
            </h2>
          </div>
          <p className="text-sm font-sans text-[#77766F] max-w-md">
            Wholesale cloth rolls, bespoke commercial spinning batches, flame-retardant contract upholstery, and architectural swatch services for designers, hotels, and tailors.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Sample Box Request (6 cols) */}
          <div className="lg:col-span-6 bg-[#E8E0D2]/40 border border-[#CDBFA8] rounded p-6 sm:p-10 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-[#A33E32] font-semibold tracking-wider uppercase mb-2">
                <Package className="w-4 h-4" />
                <span>ORDER THE MATERIAL LIBRARY</span>
              </div>

              <h3 className="font-serif text-3xl font-bold text-[#191918] mb-3">
                Architectural Sample Box
              </h3>

              <p className="text-sm text-[#77746F] font-sans leading-relaxed mb-6">
                Receive the physical archival box containing carded British fleeces, 24 cloth swatches, yarn weight coils, and certified technical specification sheets.
              </p>

              {/* Sample Checkboxes */}
              <div className="space-y-2.5 mb-6 text-xs font-mono">
                {[
                  'Cloth Swatches (Tweed & Coating)',
                  'Contract Upholstery Swatches (680 GSM)',
                  'Yarn Shade Cards (Natural & Dyed)',
                  'Fibre & Breed Sample Specimens (Raw to Tops)',
                  'Physical Breed Map of the British Isles'
                ].map((item) => {
                  const isChecked = selectedSamples.includes(item);
                  return (
                    <label
                      key={item}
                      onClick={() => toggleSample(item)}
                      className={`flex items-center gap-3 p-3 rounded border cursor-pointer transition-colors ${
                        isChecked
                          ? 'bg-[#F3F0E8] border-[#191918] text-[#191918]'
                          : 'bg-[#E8E0D2]/50 border-[#CDBFA8] text-[#77766F]'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => {}}
                        className="accent-[#191918] rounded"
                      />
                      <span>{item}</span>
                    </label>
                  );
                })}
              </div>
            </div>

            <div>
              <button
                onClick={handleOrderSampleLibrary}
                className="w-full py-3 bg-[#191918] hover:bg-[#30302D] text-[#F3F0E8] rounded text-xs font-mono uppercase tracking-wider font-semibold transition-colors flex items-center justify-center gap-2"
              >
                {sampleSuccess ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-[#68D391]" />
                    <span>Sample Library Dispatched (Demo)</span>
                  </>
                ) : (
                  <>
                    <Package className="w-4 h-4" />
                    <span>Request Curated Sample Box (Complimentary Trade)</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right Column: Instant Material Specification Generator (6 cols) */}
          <div className="lg:col-span-6 bg-[#F3F0E8] border border-[#CDBFA8] rounded p-6 sm:p-10 flex flex-col justify-between shadow-sm">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-[#CDBFA8] mb-6">
                <span className="text-xs font-mono uppercase tracking-wider text-[#191918] font-bold flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#A33E32]" />
                  <span>B2B SPECIFICATION & QUOTE ENGINE</span>
                </span>
                <span className="text-[10px] font-mono text-[#77766F] uppercase">
                  INSTANT GENERATION
                </span>
              </div>

              <form onSubmit={handleGenerateQuote} className="space-y-4 text-xs font-mono">
                <div>
                  <label className="text-[#77766F] uppercase block mb-1">PROJECT NAME:</label>
                  <input
                    type="text"
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2.5 text-[#191918] focus:border-[#191918] outline-none"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[#77766F] uppercase block mb-1">COMPANY / PRACTICE:</label>
                    <input
                      type="text"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2.5 text-[#191918] focus:border-[#191918] outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[#77766F] uppercase block mb-1">SPECIFIER EMAIL:</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2.5 text-[#191918] focus:border-[#191918] outline-none"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[#77766F] uppercase block mb-1">MATERIAL SELECTION:</label>
                    <select
                      value={materialName}
                      onChange={(e) => setMaterialName(e.target.value)}
                      className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2.5 text-[#191918] focus:border-[#191918] outline-none"
                    >
                      <option value="Herdwick Architectural Upholstery Cloth">Herdwick Upholstery (680 GSM)</option>
                      <option value="North Country Tweed Herringbone">North Country Tweed (560 GSM)</option>
                      <option value="Romney Heavy Double-Cloth Coating">Romney Coating (620 GSM)</option>
                      <option value="Wensleydale & Romney Blanket Cloth">Wensleydale Blanket (480 GSM)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[#77766F] uppercase block mb-1">METRES REQUIRED:</label>
                    <input
                      type="number"
                      min="10"
                      max="10000"
                      value={quantityMetres}
                      onChange={(e) => setQuantityMetres(Number(e.target.value))}
                      className="w-full bg-[#E8E0D2] border border-[#CDBFA8] rounded p-2.5 text-[#191918] focus:border-[#191918] outline-none"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#A33E32] hover:bg-[#874536] text-white rounded text-xs font-mono uppercase tracking-wider font-semibold transition-colors flex items-center justify-center gap-2 mt-4"
                >
                  <FileText className="w-4 h-4" />
                  <span>Generate Specification & Quotation</span>
                </button>
              </form>
            </div>

            {/* Generated Quote Display */}
            {quoteGenerated && (
              <div className="mt-6 pt-6 border-t border-[#CDBFA8] bg-[#E8E0D2]/50 p-4 rounded text-xs font-mono">
                <div className="flex justify-between items-center pb-2 border-b border-[#CDBFA8]">
                  <span className="font-bold text-[#191918]">
                    DOC ID: {quoteGenerated.id}
                  </span>
                  <span className="text-[#A33E32] font-bold">
                    STATUS: {quoteGenerated.status}
                  </span>
                </div>
                <div className="py-2 space-y-1 text-[#30302D]">
                  <div>PROJECT: {quoteGenerated.projectName} ({quoteGenerated.companyName})</div>
                  <div>MATERIAL: {quoteGenerated.materialName} ({quoteGenerated.gsm} GSM · {quoteGenerated.widthMm}mm)</div>
                  <div>VOLUME: {quoteGenerated.quantityMetres} Metres</div>
                  <div className="font-bold text-[#191918] text-sm pt-1">
                    ESTIMATED CONTRACT TOTAL: £{quoteGenerated.totalEstimate.toLocaleString()}.00
                  </div>
                </div>
                <div className="text-[10px] text-[#77766F] pt-2 border-t border-[#CDBFA8]/60">
                  Simulated commercial quotation generated in compliance with British contract standards.
                </div>
              </div>
            )}

          </div>

        </div>

      </div>
    </section>
  );
}
