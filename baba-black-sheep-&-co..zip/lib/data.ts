// BABA BLACK SHEEP & CO. - DATA ARCHIVE
// Synthetic Demonstration Data - British Wool Emporium

export interface Breed {
  id: string;
  name: string;
  region: string;
  fleeceType: string;
  micron: string;
  stapleLength: string;
  crimp: string;
  handle: string;
  lustre: string;
  naturalColours: string[];
  strength: string;
  warmth: string;
  recommendedApplications: string[];
  yarnUses: string[];
  story: string;
  portraitImage: string;
  fleeceImage: string;
  historicalNote: string;
}

export interface ProductVariant {
  id: string;
  name: string;
  colourName: string;
  hex: string;
  stock: number;
}

export interface TechnicalSpec {
  fibreDiameter: string;
  stapleLength: string;
  crimp: string;
  lustre: string;
  handle: string;
  warmth: string;
  durability: string;
  greaseLoss?: string;
  gsm?: number;
  widthMm?: number;
}

export interface Product {
  id: string;
  name: string;
  category: 'WOOL' | 'YARN' | 'CLOTH' | 'HOME' | 'CLOTHING' | 'CRAFT';
  subCategory: string;
  breed: string;
  origin: string;
  weightGrams?: number;
  metresPerUnit?: number;
  price: number;
  unit: string;
  isNaturalColour: boolean;
  colourFamily: string;
  colourName: string;
  colourHex: string;
  handle: string;
  lotNumber: string;
  images: string[];
  description: string;
  technical: TechnicalSpec;
  variants?: ProductVariant[];
  applications: string[];
  featured?: boolean;
}

export interface MarketObservation {
  id: string;
  grade: string;
  description: string;
  pricePerKg: number;
  currency: string;
  change: number; // percentage
  trend: 'up' | 'down' | 'steady';
  volumeBales: number;
  dominantBreeds: string[];
  updatedAt: string;
}

export interface TraceabilityLot {
  lotNumber: string;
  productName: string;
  breed: string;
  region: string;
  shearSeason: string;
  processor: string;
  scouringFacility: string;
  spinningMill: string;
  weavingMill?: string;
  micronCertified: string;
  naturalLot: boolean;
  notes: string;
}

export interface WoolLibraryArticle {
  id: string;
  title: string;
  category: string;
  readTime: string;
  summary: string;
  content: string[];
  diagramType?: string;
}

export interface UserProject {
  id: string;
  title: string;
  category: string;
  yarnId: string;
  yarnName: string;
  breed: string;
  colour: string;
  quantityBalls: number;
  weightGrams: number;
  status: 'Planning' | 'Yarn Acquired' | 'On Needles' | 'Finishing' | 'Archived';
  notes: string;
  createdAt: string;
}

// 14 DISTINCT BRITISH SHEEP BREEDS
export const BREEDS: Breed[] = [
  {
    id: 'swaledale',
    name: 'Swaledale',
    region: 'Yorkshire Dales & Pennines',
    fleeceType: 'Medium Mountain Fleece',
    micron: '33–38 μm',
    stapleLength: '100–150 mm',
    crimp: 'Crisp',
    handle: 'Firm, rustic, textured',
    lustre: 'Low',
    naturalColours: ['Natural Grey', 'Silver Grey', 'White', 'Charcoal Heather'],
    strength: 'Very High',
    warmth: 'Exceptional',
    recommendedApplications: ['Heavy knitwear', 'Tweed cloths', 'Carpets', 'Upholstery', 'Insulation'],
    yarnUses: ['DK', 'Aran', 'Chunky outer garments', 'Carpet yarns'],
    story: 'Born of the rugged limestone fells of Upper Swaledale, this iconic mountain sheep has a prominent white muzzle, curling horns, and a hard-wearing double fleece that turns rainwater like slate.',
    portraitImage: '/images/sheep.jpg',
    fleeceImage: '/images/fleece.jpg',
    historicalNote: 'Swaledale fleeces formed the bedrock of Yorkshire woollen mills throughout the 19th and 20th centuries.',
  },
  {
    id: 'herdwick',
    name: 'Herdwick',
    region: 'Cumbrian Lake District',
    fleeceType: 'Hill Carpet & Outerwear Wool',
    micron: '38–45 μm',
    stapleLength: '150–200 mm',
    crimp: 'Low',
    handle: 'Very stiff, wire-strong, architectural',
    lustre: 'Low',
    naturalColours: ['Slate Grey', 'Charcoal', 'Mottled Silver'],
    strength: 'Very High',
    warmth: 'Exceptional',
    recommendedApplications: ['Heavy upholstery', 'Architectural felt', 'Luggage cloth', 'Insulation', 'Outdoor jackets'],
    yarnUses: ['Aran', 'Chunky', 'Rug warp and weft'],
    story: 'Herdwicks graze the highest fells of Lakeland, fending off gale-force rains. Lambs are born jet black, turning dark brown, and maturing into silver-grey fleeces mixed with white kemp hairs.',
    portraitImage: '/images/sheep.jpg',
    fleeceImage: '/images/hero_macro.jpg',
    historicalNote: 'Championed and preserved by Beatrix Potter, who left thousands of Herdwick fell acres to the National Trust.',
  },
  {
    id: 'bluefaced-leicester',
    name: 'Bluefaced Leicester',
    region: 'North of England & Scottish Borders',
    fleeceType: 'Fine Longwool / Semi-Lustre',
    micron: '24–28 μm',
    stapleLength: '85–110 mm',
    crimp: 'High, well-defined purl',
    handle: 'Soft, silky, drapey',
    lustre: 'High',
    naturalColours: ['Cream White', 'Soft Oatmeal', 'Occasional Moorit'],
    strength: 'Medium',
    warmth: 'High',
    recommendedApplications: ['Luxury shawls', 'Fine suiting', 'Next-to-skin garments', 'Drape fabrics'],
    yarnUses: ['4-ply', 'DK', 'Lace weight', 'Sock blends'],
    story: 'The aristocrat of British wools. Named for the dark blue skin visible beneath white facial hair, its fleece possesses a glorious pearlescent lustre and softness that rivals Merino.',
    portraitImage: '/images/sheep.jpg',
    fleeceImage: '/images/yarn.jpg',
    historicalNote: 'Developed by Robert Bakewell during the Agricultural Revolution to bring fine lustre to British crossbreds.',
  },
  {
    id: 'wensleydale',
    name: 'Wensleydale',
    region: 'North Yorkshire',
    fleeceType: 'Lustre Longwool',
    micron: '30–36 μm',
    stapleLength: '200–300 mm',
    crimp: 'Spiral ringlets',
    handle: 'Silky, cool, weighty',
    lustre: 'High',
    naturalColours: ['Pearly White', 'Silver Black'],
    strength: 'High',
    warmth: 'Moderate',
    recommendedApplications: ['Worsted tailoring', 'Drapery', 'Doll locks', 'Felt embellishment', 'Lustre blends'],
    yarnUses: ['Worsted spun DK', 'Lace weight', 'Weaving singles'],
    story: 'Renowned for its cascading corkscrew ringlets of shimmering wool that hang in distinct staples down to the sheep\'s hocks. Wensleydale gives cloth unmatched sheen and drape.',
    portraitImage: '/images/sheep.jpg',
    fleeceImage: '/images/hero_macro.jpg',
    historicalNote: 'Descended from a famous 1838 ram named "Blue Cap", bred in the village of East Tanfield.',
  },
  {
    id: 'romney',
    name: 'Romney (Kent)',
    region: 'Romney Marsh, Kent',
    fleeceType: 'Demi-Lustre Longwool',
    micron: '29–33 μm',
    stapleLength: '120–150 mm',
    crimp: 'Medium',
    handle: 'Smooth, resilient, balanced',
    lustre: 'Medium',
    naturalColours: ['Bright White', 'Oatmeal', 'Silver'],
    strength: 'High',
    warmth: 'High',
    recommendedApplications: ['Blankets', 'Knitwear', 'Overcoats', 'Upholstery', 'Quilt batting'],
    yarnUses: ['DK', 'Aran', 'Worsted spun yarns'],
    story: 'Adapted to the salt-spray lowlands of Romney Marsh, this fleece is naturally resistant to footrot and damp, yielding clean, dense fibres with an all-round versatile handle.',
    portraitImage: '/images/sheep.jpg',
    fleeceImage: '/images/fleece.jpg',
    historicalNote: 'Exported across the globe as the foundation of New Zealand and South American dual-purpose flocks.',
  },
  {
    id: 'cheviot',
    name: 'Cheviot',
    region: 'Cheviot Hills & Scottish Borders',
    fleeceType: 'Crisp Down-Cross Wool',
    micron: '28–32 μm',
    stapleLength: '80–100 mm',
    crimp: 'Crisp helical 3D',
    handle: 'Bouncy, resilient, dry',
    lustre: 'Low',
    naturalColours: ['Chalk White'],
    strength: 'High',
    warmth: 'High',
    recommendedApplications: ['Tweed suiting', 'Hosiery', 'Socks', 'Flannels', 'Structured knitwear'],
    yarnUses: ['DK', 'Sport', 'Sock yarn', 'Tweed yarns'],
    story: 'A hill sheep with an aristocratic prick-eared stance. Cheviot wool has a three-dimensional helical crimp that gives extraordinary structural spring and crease recovery to tweed cloth.',
    portraitImage: '/images/sheep.jpg',
    fleeceImage: '/images/cloth.jpg',
    historicalNote: 'The core raw material behind classic Scottish Border tweeds and sporting estate cloths.',
  },
  {
    id: 'masham',
    name: 'Masham',
    region: 'North Yorkshire & Lancashire Fells',
    fleeceType: 'Crossbred Longwool',
    micron: '31–35 μm',
    stapleLength: '150–200 mm',
    crimp: 'Loose curl',
    handle: 'Supple, lustrous, substantial',
    lustre: 'High',
    naturalColours: ['Cream', 'Mottled Grey', 'Honey Oatmeal'],
    strength: 'High',
    warmth: 'High',
    recommendedApplications: ['Heavy knitwear', 'Cardigans', 'Throws', 'Woven blankets'],
    yarnUses: ['DK', 'Aran', 'Chunky'],
    story: 'The result of crossing a Teeswater or Wensleydale ram onto a Dalesbred or Swaledale ewe. Combines the tough weather resistance of the hill ewe with the long, lustrous curl of the sire.',
    portraitImage: '/images/sheep.jpg',
    fleeceImage: '/images/yarn.jpg',
    historicalNote: 'The Masham Sheep Fair in Yorkshire remains one of Britain\'s longest continuously running fleece markets.',
  },
  {
    id: 'jacob',
    name: 'Jacob',
    region: 'British Countrywide (Ancient Polycerate)',
    fleeceType: 'Naturally Piebald Fleece',
    micron: '32–36 μm',
    stapleLength: '90–120 mm',
    crimp: 'Medium',
    handle: 'Dry, crisp, springy',
    lustre: 'Low to Medium',
    naturalColours: ['Dark Chocolate Brown', 'Cream White', 'Flecked Charcoal'],
    strength: 'Medium to High',
    warmth: 'High',
    recommendedApplications: ['Undyed patterned knitwear', 'Textured tweed', 'Handweaving', 'Rugs'],
    yarnUses: ['DK', 'Aran', 'Naturally striped colourwork'],
    story: 'Famous for bearing 4 horns and a piebald fleece with sharply separated patches of dark brown/black and bright white, allowing spinners to create distinct natural shade gradients without dye.',
    portraitImage: '/images/sheep.jpg',
    fleeceImage: '/images/fleece.jpg',
    historicalNote: 'Historically kept in parklands of British grand country estates as ornamental grazers with prized fleeces.',
  },
  {
    id: 'shetland',
    name: 'Shetland',
    region: 'Shetland Isles',
    fleeceType: 'Fine Northern Short-Tailed',
    micron: '23–29 μm',
    stapleLength: '60–90 mm',
    crimp: 'Fine, crimpy',
    handle: 'Soft, light, lofty',
    lustre: 'Soft',
    naturalColours: ['Shaela (Dark Grey)', 'Moorit (Red Brown)', 'Mioget (Honey)', 'Emsket (Blue Grey)', 'Yuglet', 'White'],
    strength: 'Medium',
    warmth: 'Exceptional',
    recommendedApplications: ['Fair Isle knitwear', 'Fine lace shawls', 'Layering jumpers', 'Featherweight throws'],
    yarnUses: ['2-ply Jumper Weight', 'Lace weight', '4-ply'],
    story: 'Thriving on seaweed, heather, and salt gale winds of the far northern archipelago, Shetland sheep boast 11 distinct natural coat colour terms in the dialect, offering an exquisite palette straight from the fleece.',
    portraitImage: '/images/sheep.jpg',
    fleeceImage: '/images/hero_macro.jpg',
    historicalNote: 'Shetland lace ring shawls were famously gossamer-fine enough to be drawn through a wedding band.',
  },
  {
    id: 'hebridean',
    name: 'Hebridean',
    region: 'Western Isles & Scottish Highlands',
    fleeceType: 'Primitive Dark Wool',
    micron: '34–38 μm',
    stapleLength: '120–160 mm',
    crimp: 'Low',
    handle: 'Coarse, wiry outer coat with soft underwool',
    lustre: 'Medium',
    naturalColours: ['Jet Black', 'Sun-bleached Brown', 'Smoky Charcoal'],
    strength: 'Very High',
    warmth: 'High',
    recommendedApplications: ['Weatherproof capes', 'Rugs', 'Durable accessories', 'Upholstery'],
    yarnUses: ['Aran', 'Chunky', 'Fleece singles'],
    story: 'A multi-horned primitive black sheep whose fleece tips bleach to a striking coppery brown under summer moorland sun. Extremely hardy and resistant to parasites and moisture.',
    portraitImage: '/images/sheep.jpg',
    fleeceImage: '/images/cloth.jpg',
    historicalNote: 'Once widespread across the Outer Hebrides; rescued from near extinction by dedicated British conservationists.',
  },
  {
    id: 'teeswater',
    name: 'Teeswater',
    region: 'Teesdale, County Durham',
    fleeceType: 'High Lustre Longwool',
    micron: '32–36 μm',
    stapleLength: '220–300 mm',
    crimp: 'Long open spiral locks',
    handle: 'Silky, cool, free-flowing',
    lustre: 'Very High',
    naturalColours: ['Silver White'],
    strength: 'High',
    warmth: 'Moderate',
    recommendedApplications: ['Textile art', 'High lustre dress fabric', 'Tailoring', 'Spinning locks'],
    yarnUses: ['Worsted lace', 'DK lustre blends'],
    story: 'Characterised by clean, separate spiral ringlets that do not mat or felt easily. Teeswater wool takes acid dyes with an iridescent vibrancy matched by few other natural materials on earth.',
    portraitImage: '/images/sheep.jpg',
    fleeceImage: '/images/yarn.jpg',
    historicalNote: 'Bred in Teesdale for centuries to provide length, lustre, and hardiness to crossbred offspring.',
  },
  {
    id: 'dalesbred',
    name: 'Dalesbred',
    region: 'Upper Yorkshire Dales & Cumbria',
    fleeceType: 'Hill Carpet Fleece',
    micron: '35–42 μm',
    stapleLength: '120–180 mm',
    crimp: 'Low',
    handle: 'Tough, resilient, springy',
    lustre: 'Low',
    naturalColours: ['White with black/white face'],
    strength: 'Very High',
    warmth: 'Exceptional',
    recommendedApplications: ['Traditional carpets', 'Heavy tweed', 'Woven blankets', 'Footwear lining'],
    yarnUses: ['Chunky', 'Super chunky', 'Twisted warp'],
    story: 'Distinguished by a black face marked with a sharp white round patch on either side of the nostrils. Hard-as-nails wool that shrugs off freezing mountain snow.',
    portraitImage: '/images/sheep.jpg',
    fleeceImage: '/images/fleece.jpg',
    historicalNote: 'Shares ancestral ancestry with the Swaledale and Scottish Blackface lines.',
  },
  {
    id: 'welsh-mountain',
    name: 'Welsh Mountain',
    region: 'Cambrian Mountains & Snowdonia',
    fleeceType: 'Hardy Hill Wool',
    micron: '32–36 μm',
    stapleLength: '70–100 mm',
    crimp: 'Medium',
    handle: 'Firm, dense, water-repellent',
    lustre: 'Low',
    naturalColours: ['Oatmeal White', 'Badger Face (Torwen/Torddu)', 'Black'],
    strength: 'High',
    warmth: 'Exceptional',
    recommendedApplications: ['Welsh tapestry blankets', 'Hard-wearing flannel', 'Outdoor clothing'],
    yarnUses: ['DK', 'Sport', 'Double-cloth weaving yarn'],
    story: 'For millennia the lifeblood of Welsh highland communities. Welsh mountain fleece produces the dense, unyielding yarn required for heritage reversible Welsh tapestry blankets.',
    portraitImage: '/images/sheep.jpg',
    fleeceImage: '/images/cloth.jpg',
    historicalNote: 'The bedrock of historic Welsh flannel mills in the Teifi Valley.',
  },
  {
    id: 'lincoln-longwool',
    name: 'Lincoln Longwool',
    region: 'Lincolnshire Wolds',
    fleeceType: 'Heavy Lustre Longwool',
    micron: '36–42 μm',
    stapleLength: '250–350 mm',
    crimp: 'Bold wavy lock',
    handle: 'Weighty, crisp, glistening',
    lustre: 'High',
    naturalColours: ['Lustrous Cream'],
    strength: 'Very High',
    warmth: 'High',
    recommendedApplications: ['Heavy upholstery', 'Lustre coats', 'Carpets', 'Horsehair substitute', 'Felt rugs'],
    yarnUses: ['Heavy worsted', 'Rope & braid yarns'],
    story: 'Britain\'s largest native sheep produces the heaviest fleece in the world—single fleeces often weigh over 10kg! Its long wavy staples gleam like spun glass.',
    portraitImage: '/images/sheep.jpg',
    fleeceImage: '/images/hero_macro.jpg',
    historicalNote: 'Financed the construction of the soaring cathedral tower of Lincoln during the medieval wool trade boom.',
  }
];

// SYNTHETIC CATALOGUE: 100+ REALISTIC PRODUCTS ACROSS CATEGORIES
export const PRODUCTS: Product[] = [
  // --- YARN ---
  {
    id: 'prod-y01',
    name: 'Baba Swaledale DK',
    category: 'YARN',
    subCategory: 'DK (Double Knitting)',
    breed: 'Swaledale',
    origin: 'Yorkshire Dales',
    weightGrams: 100,
    metresPerUnit: 225,
    price: 12.50,
    unit: '100g skein',
    isNaturalColour: true,
    colourFamily: 'Natural Grey',
    colourName: 'Fell Grey',
    colourHex: '#77746F',
    handle: 'Firm / Textured',
    lotNumber: 'BBS-26-041',
    images: ['/images/yarn.jpg', '/images/hero_macro.jpg', '/images/fleece.jpg', '/images/cloth.jpg'],
    description: 'Spun in Yorkshire from 100% pure Swaledale fleece. A crisp, two-ply construction with extraordinary stitch definition for textured jumpers and cable sweaters.',
    technical: {
      fibreDiameter: '33 μm',
      stapleLength: '110 mm',
      crimp: 'Medium',
      lustre: 'Low',
      handle: 'Firm / Textured',
      warmth: 'High',
      durability: 'Very High',
    },
    variants: [
      { id: 'v01', name: 'Natural Fell Grey', colourName: 'Fell Grey', hex: '#77746F', stock: 184 },
      { id: 'v02', name: 'Natural Peat Charcoal', colourName: 'Peat Charcoal', hex: '#30302D', stock: 92 },
      { id: 'v03', name: 'Raw Limestone White', colourName: 'Limestone White', hex: '#F3F0E8', stock: 110 }
    ],
    applications: ['Jumper', 'Cardigan', 'Textured Shawl', 'Winter Beanie'],
    featured: true,
  },
  {
    id: 'prod-y02',
    name: 'Bluefaced Leicester 4-Ply Lustre',
    category: 'YARN',
    subCategory: '4-Ply / Fingering',
    breed: 'Bluefaced Leicester',
    origin: 'Cumbria / North Pennines',
    weightGrams: 100,
    metresPerUnit: 380,
    price: 16.50,
    unit: '100g skein',
    isNaturalColour: false,
    colourFamily: 'Indigo',
    colourName: 'North Sea Indigo',
    colourHex: '#263B49',
    handle: 'Silky / Drapey',
    lotNumber: 'BBS-26-088',
    images: ['/images/yarn.jpg', '/images/hero_macro.jpg', '/images/cloth.jpg'],
    description: 'Exceptionally soft single-origin Bluefaced Leicester spun into a dense 4-ply yarn with luminous surface sheen. Dyed in small batches with low-impact indigo dyes.',
    technical: {
      fibreDiameter: '25 μm',
      stapleLength: '95 mm',
      crimp: 'High purl',
      lustre: 'High',
      handle: 'Silky / Smooth',
      warmth: 'High',
      durability: 'High',
    },
    variants: [
      { id: 'v04', name: 'North Sea Indigo', colourName: 'Indigo', hex: '#263B49', stock: 65 },
      { id: 'v05', name: 'Madder Sheep Red', colourName: 'Sheep Red', hex: '#A33E32', stock: 48 },
      { id: 'v06', name: 'Heather Smoke', colourName: 'Heather', hex: '#77746F', stock: 80 }
    ],
    applications: ['Fine Shawl', 'Next-to-skin Jumper', 'Gloves', 'Baby Knits'],
    featured: true,
  },
  {
    id: 'prod-y03',
    name: 'Herdwick Heavy Aran',
    category: 'YARN',
    subCategory: 'Aran',
    breed: 'Herdwick',
    origin: 'Lake District Fells',
    weightGrams: 100,
    metresPerUnit: 160,
    price: 13.00,
    unit: '100g skein',
    isNaturalColour: true,
    colourFamily: 'Charcoal',
    colourName: 'Coniston Slate',
    colourHex: '#30302D',
    handle: 'Rustic / Weatherproof',
    lotNumber: 'BBS-26-018',
    images: ['/images/yarn.jpg', '/images/hero_macro.jpg', '/images/fleece.jpg'],
    description: 'Undyed naturally mottled silver-charcoal Aran yarn with visible pale kemp fibres. Incredibly durable and naturally water-resistant; built for mountain workwear.',
    technical: {
      fibreDiameter: '40 μm',
      stapleLength: '160 mm',
      crimp: 'Low',
      lustre: 'Low',
      handle: 'Crisp / Stiff',
      warmth: 'Exceptional',
      durability: 'Maximum',
    },
    variants: [
      { id: 'v07', name: 'Coniston Slate', colourName: 'Coniston Slate', hex: '#30302D', stock: 120 },
      { id: 'v08', name: 'Fellside Silver', colourName: 'Fellside Silver', hex: '#77766F', stock: 85 }
    ],
    applications: ['Outerwear Coat', 'Heavy Cardigan', 'Rug Weaving', 'Slippers'],
    featured: true,
  },
  {
    id: 'prod-y04',
    name: 'Wensleydale Worsted Ringlet Lace',
    category: 'YARN',
    subCategory: 'Lace Weight',
    breed: 'Wensleydale',
    origin: 'North Yorkshire',
    weightGrams: 100,
    metresPerUnit: 750,
    price: 19.00,
    unit: '100g skein',
    isNaturalColour: true,
    colourFamily: 'Natural Cream',
    colourName: 'Pearly White',
    colourHex: '#F3F0E8',
    handle: 'Fluid / Lustrous',
    lotNumber: 'BBS-26-114',
    images: ['/images/yarn.jpg', '/images/hero_macro.jpg'],
    description: 'Long spiral staples of pure Wensleydale fleece combed and worsted-spun into an ethereal single-ply lace weight yarn with liquid drape and pearlescent shine.',
    technical: {
      fibreDiameter: '31 μm',
      stapleLength: '240 mm',
      crimp: 'Spiral ringlets',
      lustre: 'Very High',
      handle: 'Silky / Cool',
      warmth: 'Moderate',
      durability: 'High',
    },
    applications: ['Lace Shawl', 'Heirloom Scarf', 'Weaving Inlay'],
  },
  {
    id: 'prod-y05',
    name: 'Cheviot Spring Tweed DK',
    category: 'YARN',
    subCategory: 'DK (Double Knitting)',
    breed: 'Cheviot',
    origin: 'Scottish Borders',
    weightGrams: 100,
    metresPerUnit: 240,
    price: 14.00,
    unit: '100g skein',
    isNaturalColour: false,
    colourFamily: 'Moss',
    colourName: 'Border Bracken',
    colourHex: '#4D5847',
    handle: 'Bouncy / Structured',
    lotNumber: 'BBS-26-052',
    images: ['/images/yarn.jpg', '/images/cloth.jpg'],
    description: 'Pure Scottish Border Cheviot with helical spring crimp. Resists pilling and holds structure beautifully in Fair Isle stranded colourwork and waffle stitches.',
    technical: {
      fibreDiameter: '29 μm',
      stapleLength: '85 mm',
      crimp: 'Crisp helical',
      lustre: 'Low',
      handle: 'Bouncy / Springy',
      warmth: 'High',
      durability: 'High',
    },
    applications: ['Fair Isle Jumper', 'Warm Gloves', 'Structural Cardigan'],
  },
  {
    id: 'prod-y06',
    name: 'Shetland Jumper Weight 2-Ply',
    category: 'YARN',
    subCategory: '4-Ply / 2-Ply',
    breed: 'Shetland',
    origin: 'Shetland Isles',
    weightGrams: 50,
    metresPerUnit: 215,
    price: 7.20,
    unit: '50g ball',
    isNaturalColour: true,
    colourFamily: 'Natural Brown',
    colourName: 'Moorit Brown',
    colourHex: '#874536',
    handle: 'Lofty / Soft',
    lotNumber: 'BBS-26-095',
    images: ['/images/yarn.jpg', '/images/hero_macro.jpg'],
    description: 'The genuine article: undyed native Shetland fleece in natural Moorit brown. Bloom-rich woollen spun yarn that creates a light, cohesive fabric after wet blocking.',
    technical: {
      fibreDiameter: '26 μm',
      stapleLength: '70 mm',
      crimp: 'Fine',
      lustre: 'Soft',
      handle: 'Lofty / Featherweight',
      warmth: 'Exceptional',
      durability: 'Medium',
    },
    applications: ['Fair Isle Vest', 'Beanie', 'Mitts', 'Traditional Shawl'],
  },
  {
    id: 'prod-y07',
    name: 'Hebridean Raw Single-Origin Aran',
    category: 'YARN',
    subCategory: 'Aran',
    breed: 'Hebridean',
    origin: 'Outer Hebrides',
    weightGrams: 100,
    metresPerUnit: 175,
    price: 15.50,
    unit: '100g skein',
    isNaturalColour: true,
    colourFamily: 'Black Sheep',
    colourName: 'Peat Bog Black',
    colourHex: '#191918',
    handle: 'Textured / Dry',
    lotNumber: 'BBS-26-033',
    images: ['/images/yarn.jpg', '/images/fleece.jpg'],
    description: 'Jet black fleece with sun-tinged mahogany highlights. Spun woollen style to preserve the natural spring and air pockets of primitive Scottish island fleece.',
    technical: {
      fibreDiameter: '35 μm',
      stapleLength: '130 mm',
      crimp: 'Low',
      lustre: 'Medium',
      handle: 'Firm / Earthy',
      warmth: 'Very High',
      durability: 'Very High',
    },
    applications: ['Outdoor Poncho', 'Heavy Winter Socks', 'Chunky Cowl'],
  },
  {
    id: 'prod-y08',
    name: 'Masham & BFL Blend Chunky',
    category: 'YARN',
    subCategory: 'Chunky',
    breed: 'Masham',
    origin: 'North Yorkshire',
    weightGrams: 100,
    metresPerUnit: 110,
    price: 13.50,
    unit: '100g skein',
    isNaturalColour: false,
    colourFamily: 'Mustard',
    colourName: 'Gorse Bloom',
    colourHex: '#B28A35',
    handle: 'Supple / Plump',
    lotNumber: 'BBS-26-077',
    images: ['/images/yarn.jpg', '/images/hero_macro.jpg'],
    description: 'A 50/50 blend of Yorkshire Masham longwool and Bluefaced Leicester lustre. Soft enough for cowls, substantial enough for quick weekend knitting.',
    technical: {
      fibreDiameter: '28 μm',
      stapleLength: '140 mm',
      crimp: 'Wavy',
      lustre: 'High',
      handle: 'Plump / Soft',
      warmth: 'High',
      durability: 'High',
    },
    applications: ['Quick Scarf', 'Chunky Cardigan', 'Cushion Cover'],
  },

  // --- CLOTH ---
  {
    id: 'prod-c01',
    name: 'North Country Tweed — Herringbone',
    category: 'CLOTH',
    subCategory: 'Tweed',
    breed: 'Swaledale & Cheviot',
    origin: 'Yorkshire Mill',
    price: 84.00,
    unit: 'per linear metre (150cm width)',
    isNaturalColour: true,
    colourFamily: 'Natural Heather',
    colourName: 'Moorland Heather',
    colourHex: '#5E625A',
    handle: 'Substantial / Crisp',
    lotNumber: 'BBS-26-TW01',
    images: ['/images/cloth.jpg', '/images/hero_macro.jpg', '/images/yarn.jpg'],
    description: 'Woven on rapier looms in West Yorkshire. A heavyweight 560 GSM undyed herringbone tweed woven with Swaledale warp and Cheviot weft for unbeatable body and drape.',
    technical: {
      fibreDiameter: '32 μm',
      stapleLength: '90 mm',
      crimp: 'Crisp',
      lustre: 'Low',
      handle: 'Firm / Structured',
      warmth: 'High',
      durability: 'Exceptional',
      gsm: 560,
      widthMm: 1500,
    },
    applications: ['Tailored Overcoat', 'Field Jacket', 'Heavy Curtains', 'Cushions'],
    featured: true,
  },
  {
    id: 'prod-c02',
    name: 'Herdwick Architectural Upholstery Cloth',
    category: 'CLOTH',
    subCategory: 'Upholstery Cloth',
    breed: 'Herdwick',
    origin: 'Cumbrian Mill',
    price: 110.00,
    unit: 'per linear metre (140cm width)',
    isNaturalColour: true,
    colourFamily: 'Charcoal',
    colourName: 'Fellside Slate',
    colourHex: '#30302D',
    handle: 'High Tensile / Indestructible',
    lotNumber: 'BBS-26-UP04',
    images: ['/images/cloth.jpg', '/images/fleece.jpg'],
    description: 'Architectural grade 680 GSM wool upholstery cloth with 65,000 Martindale rubs. Naturally flame-retardant and dyed by the mountain sheep itself.',
    technical: {
      fibreDiameter: '42 μm',
      stapleLength: '180 mm',
      crimp: 'Low',
      lustre: 'Low',
      handle: 'Very Firm',
      warmth: 'High',
      durability: 'Commercial Grade',
      gsm: 680,
      widthMm: 1400,
    },
    applications: ['Armchair Upholstery', 'Commercial Banquettes', 'Acoustic Wall Panels'],
    featured: true,
  },
  {
    id: 'prod-c03',
    name: 'Romney Heavy Double-Cloth Coating',
    category: 'CLOTH',
    subCategory: 'Coating',
    breed: 'Romney',
    origin: 'Kent & Yorkshire',
    price: 96.00,
    unit: 'per linear metre (150cm width)',
    isNaturalColour: false,
    colourFamily: 'Indigo',
    colourName: 'Deep Naval Blue',
    colourHex: '#263B49',
    handle: 'Supple / Dense',
    lotNumber: 'BBS-26-CT08',
    images: ['/images/cloth.jpg', '/images/yarn.jpg'],
    description: 'Double-cloth construction with a milled melton finish. Blocks wind completely, providing impenetrable warmth without synthetic laminates.',
    technical: {
      fibreDiameter: '30 μm',
      stapleLength: '130 mm',
      crimp: 'Medium',
      lustre: 'Medium',
      handle: 'Dense / Velvety',
      warmth: 'Maximum',
      durability: 'High',
      gsm: 620,
      widthMm: 1500,
    },
    applications: ['Peacoat', 'Trench Overcoat', 'Winter Capes'],
  },
  {
    id: 'prod-c04',
    name: 'Wensleydale & Romney Woollen Blanket Cloth',
    category: 'CLOTH',
    subCategory: 'Blanket Cloth',
    breed: 'Wensleydale & Romney',
    origin: 'Lancashire Mill',
    price: 78.00,
    unit: 'per linear metre (160cm width)',
    isNaturalColour: true,
    colourFamily: 'Warm Wool',
    colourName: 'Natural Lanolin Oat',
    colourHex: '#E8E0D2',
    handle: 'Brushed / Pillowy',
    lotNumber: 'BBS-26-BL02',
    images: ['/images/cloth.jpg', '/images/hero_macro.jpg'],
    description: 'Teasel-brushed using natural dried fuller teasels for an ultra-soft raised nap. The perfect weight for unlined blankets, heavy throws, and wrap jackets.',
    technical: {
      fibreDiameter: '31 μm',
      stapleLength: '160 mm',
      crimp: 'Medium',
      lustre: 'Medium',
      handle: 'Brushed / Soft',
      warmth: 'Exceptional',
      durability: 'High',
      gsm: 480,
      widthMm: 1600,
    },
    applications: ['Heirloom Blankets', 'Poncho', 'Bed Runner'],
  },

  // --- RAW & PREPARED WOOL ---
  {
    id: 'prod-w01',
    name: 'Pure Scoured Swaledale Fleece — Grade 1',
    category: 'WOOL',
    subCategory: 'Scoured Fleece',
    breed: 'Swaledale',
    origin: 'Yorkshire Dales',
    weightGrams: 500,
    price: 24.00,
    unit: '500g bag',
    isNaturalColour: true,
    colourFamily: 'Natural Fleece',
    colourName: 'Silver & Cream',
    colourHex: '#F3F0E8',
    handle: 'Springy / Clean',
    lotNumber: 'BBS-26-FL01',
    images: ['/images/fleece.jpg', '/images/hero_macro.jpg'],
    description: 'Carefully skirted and eco-scoured in soft Yorkshire water without harsh acid carbonisation. Retains 1.5% natural lanolin for supple hand spinning and felting.',
    technical: {
      fibreDiameter: '35 μm',
      stapleLength: '120 mm',
      crimp: 'Crisp',
      lustre: 'Low',
      handle: 'Firm',
      warmth: 'High',
      durability: 'High',
    },
    applications: ['Hand Spinning', 'Peg Loom Weaving', 'Needle Felting', 'Rug Hooking'],
    featured: true,
  },
  {
    id: 'prod-w02',
    name: 'Bluefaced Leicester Combed Tops',
    category: 'WOOL',
    subCategory: 'Combed Tops / Roving',
    breed: 'Bluefaced Leicester',
    origin: 'Cumbria',
    weightGrams: 250,
    price: 18.50,
    unit: '250g braid',
    isNaturalColour: true,
    colourFamily: 'Cream White',
    colourName: 'Ivory Lustre',
    colourHex: '#F3F0E8',
    handle: 'Cloud-Soft / Long staple',
    lotNumber: 'BBS-26-TP09',
    images: ['/images/hero_macro.jpg', '/images/fleece.jpg'],
    description: 'Combed into continuous sliver alignment on French combs. Clean, parallel fibres ready for immediate worsted spinning on wheel or spindle.',
    technical: {
      fibreDiameter: '26 μm',
      stapleLength: '100 mm',
      crimp: 'Defined',
      lustre: 'High',
      handle: 'Very Soft',
      warmth: 'High',
      durability: 'Medium',
    },
    applications: ['Wheel Spinning', 'Drop Spindle', 'Wet Felting Scarves', 'Arm Knitting'],
  },
  {
    id: 'prod-w03',
    name: 'Wensleydale Silky Washed Locks',
    category: 'WOOL',
    subCategory: 'Fleece Locks',
    breed: 'Wensleydale',
    origin: 'Yorkshire',
    weightGrams: 100,
    price: 15.00,
    unit: '100g pack',
    isNaturalColour: true,
    colourFamily: 'Pearly White',
    colourName: 'Lustre Ringlet',
    colourHex: '#E8E0D2',
    handle: 'Silky / Separate locks',
    lotNumber: 'BBS-26-LK04',
    images: ['/images/hero_macro.jpg', '/images/yarn.jpg'],
    description: 'Hand-washed intact curl locks. Prized by textile artists, tailspinners, and dollmakers for dramatic organic texture and unparallelled reflection of light.',
    technical: {
      fibreDiameter: '32 μm',
      stapleLength: '260 mm',
      crimp: 'Spiral',
      lustre: 'Exceptional',
      handle: 'Silky',
      warmth: 'Moderate',
      durability: 'High',
    },
    applications: ['Tailspinning', 'Doll Hair', 'Tapestry Weaving Inlay', 'Felting Collars'],
  },
  {
    id: 'prod-w04',
    name: 'Herdwick Acoustic & Upholstery Carded Wool',
    category: 'WOOL',
    subCategory: 'Carded Wool / Batting',
    breed: 'Herdwick',
    origin: 'Lake District',
    weightGrams: 1000,
    price: 22.00,
    unit: '1kg roll',
    isNaturalColour: true,
    colourFamily: 'Slate Grey',
    colourName: 'Mottled Charcoal',
    colourHex: '#5E625A',
    handle: 'Resilient / High-Density',
    lotNumber: 'BBS-26-BT02',
    images: ['/images/fleece.jpg', '/images/cloth.jpg'],
    description: 'High-density carded batting sheet. Naturally hypoallergenic, flame-resistant, and acoustic sound-absorbing. Ideal for bespoke furniture stuffing and mattress toppers.',
    technical: {
      fibreDiameter: '42 μm',
      stapleLength: '150 mm',
      crimp: 'Low',
      lustre: 'Low',
      handle: 'Stiff & Springy',
      warmth: 'High',
      durability: 'Maximum',
    },
    applications: ['Chair Cushion Stuffing', 'Acoustic Soundproofing', 'Quilt Interlining', 'Saddle Pads'],
  },

  // --- HOME ---
  {
    id: 'prod-h01',
    name: 'The Dales Mills Reversible Wool Blanket',
    category: 'HOME',
    subCategory: 'Blankets & Throws',
    breed: 'Swaledale & Bluefaced Leicester',
    origin: 'Yorkshire Dales',
    price: 195.00,
    unit: '180 × 240 cm (King / Throw)',
    isNaturalColour: true,
    colourFamily: 'Charcoal & Cream',
    colourName: 'Fellside Dual Tone',
    colourHex: '#30302D',
    handle: 'Substantial / Comforting',
    lotNumber: 'BBS-26-HM01',
    images: ['/images/cloth.jpg', '/images/fleece.jpg', '/images/yarn.jpg'],
    description: 'Woven on historical dobby looms in a dual-cloth structure: natural fell grey Swaledale on one face, warm cream Bluefaced Leicester on the reverse. Finished with purled fringe.',
    technical: {
      fibreDiameter: '29 μm blend',
      stapleLength: '110 mm',
      crimp: 'Medium',
      lustre: 'Subtle',
      handle: 'Soft yet Substantial',
      warmth: 'Exceptional',
      durability: 'Heirloom Grade',
    },
    applications: ['Bed Spread', 'Living Room Throw', 'Campfire Wrap'],
    featured: true,
  },
  {
    id: 'prod-h02',
    name: 'Herdwick Heavy Felt Floor Hearth Rug',
    category: 'HOME',
    subCategory: 'Rugs',
    breed: 'Herdwick',
    origin: 'Cumbria',
    price: 240.00,
    unit: '90 × 150 cm',
    isNaturalColour: true,
    colourFamily: 'Charcoal',
    colourName: 'Slate Fell',
    colourHex: '#30302D',
    handle: 'Dense / Architectural',
    lotNumber: 'BBS-26-HM07',
    images: ['/images/cloth.jpg', '/images/hero_macro.jpg'],
    description: 'Solid 12mm thick compressed wool felt rug made exclusively from Lake District Herdwick fleece. Naturally spark-resistant, dirt-shedding, and tactile underfoot.',
    technical: {
      fibreDiameter: '42 μm',
      stapleLength: '160 mm',
      crimp: 'Dense',
      lustre: 'Low',
      handle: 'Firm Felt',
      warmth: 'High',
      durability: 'Maximum',
    },
    applications: ['Fireplace Hearth', 'Architectural Entryway', 'Study Mat'],
  },
  {
    id: 'prod-h03',
    name: 'English Wool-Filled Box Cushion (45cm)',
    category: 'HOME',
    subCategory: 'Cushions',
    breed: 'Romney & Swaledale',
    origin: 'Yorkshire',
    price: 68.00,
    unit: '45 × 45 cm (cushion + feather/wool pad)',
    isNaturalColour: true,
    colourFamily: 'Oatmeal',
    colourName: 'Natural Lanolin Oat',
    colourHex: '#CDBFA8',
    handle: 'Textured / Mellow',
    lotNumber: 'BBS-26-CS03',
    images: ['/images/cloth.jpg', '/images/yarn.jpg'],
    description: 'Heavy British wool twill cover enclosing a 100% carded wool inner cushion. Breathes continuously and holds crisp architectural corners without sagging.',
    technical: {
      fibreDiameter: '32 μm',
      stapleLength: '100 mm',
      crimp: 'Medium',
      lustre: 'Low',
      handle: 'Textured Wool Twill',
      warmth: 'High',
      durability: 'High',
    },
    applications: ['Sofa Accent', 'Bench Pad', 'Floor Meditation'],
  },

  // --- CLOTHING ---
  {
    id: 'prod-cl01',
    name: 'The Shepherd’s Guernsey Jumper',
    category: 'CLOTHING',
    subCategory: 'Jumpers',
    breed: 'Bluefaced Leicester & Cheviot',
    origin: 'Yorkshire Knitted',
    price: 220.00,
    unit: 'Hand-linked finished knitwear',
    isNaturalColour: false,
    colourFamily: 'Indigo',
    colourName: 'Deep Dyer\'s Indigo',
    colourHex: '#263B49',
    handle: 'Dense / Weatherproof',
    lotNumber: 'BBS-26-CG01',
    images: ['/images/yarn.jpg', '/images/cloth.jpg', '/images/hero_macro.jpg'],
    description: 'Traditional tight-tension 5-gauge Guernsey rib with underarm gusset for freedom of movement. Knitted in Yorkshire from worsted-spun British fleece that sheds wind and light rain.',
    technical: {
      fibreDiameter: '27 μm',
      stapleLength: '95 mm',
      crimp: 'High',
      lustre: 'Medium',
      handle: 'Substantial / Dense',
      warmth: 'Exceptional',
      durability: 'Decade Guarantee',
    },
    variants: [
      { id: 'v10', name: 'Size S / Indigo', colourName: 'Indigo', hex: '#263B49', stock: 12 },
      { id: 'v11', name: 'Size M / Indigo', colourName: 'Indigo', hex: '#263B49', stock: 24 },
      { id: 'v12', name: 'Size L / Indigo', colourName: 'Indigo', hex: '#263B49', stock: 18 },
      { id: 'v13', name: 'Size XL / Indigo', colourName: 'Indigo', hex: '#263B49', stock: 9 }
    ],
    applications: ['Everyday Workwear', 'Coastal Walking', 'Winter Layering'],
    featured: true,
  },
  {
    id: 'prod-cl02',
    name: 'Shetland Fair Isle Slipover Vest',
    category: 'CLOTHING',
    subCategory: 'Vests & Slipovers',
    breed: 'Shetland',
    origin: 'Shetland Isles',
    price: 185.00,
    unit: 'Seamless circular knit',
    isNaturalColour: true,
    colourFamily: 'Multi Natural',
    colourName: 'Shaela & Moorit',
    colourHex: '#77746F',
    handle: 'Featherlight / Cosy',
    lotNumber: 'BBS-26-CG09',
    images: ['/images/yarn.jpg', '/images/hero_macro.jpg'],
    description: 'Knitted seamlessly in the round on Shetland using 6 distinct undyed natural fleece shades. Ultra-light yet astonishingly warm beneath an unstructured tweed sports coat.',
    technical: {
      fibreDiameter: '25 μm',
      stapleLength: '70 mm',
      crimp: 'Fine',
      lustre: 'Soft',
      handle: 'Featherlight',
      warmth: 'High',
      durability: 'Medium',
    },
    applications: ['Tailored Layering', 'Autumn Walks', 'Heritage Styling'],
  },
  {
    id: 'prod-cl03',
    name: 'Cumbrian Fell Boot Socks (Twin Pack)',
    category: 'CLOTHING',
    subCategory: 'Socks & Accessories',
    breed: 'Swaledale & Romney',
    origin: 'Leicestershire Hosiery Mill',
    price: 32.00,
    unit: '2 pairs',
    isNaturalColour: true,
    colourFamily: 'Natural Grey',
    colourName: 'Limestone & Charcoal',
    colourHex: '#5E625A',
    handle: 'Cushioned / Hard-wearing',
    lotNumber: 'BBS-26-SK01',
    images: ['/images/yarn.jpg', '/images/fleece.jpg'],
    description: 'Knitted on vintage Bentley hosiery machines in England. Reinforced heel and toe with nylon-twisted wool for blister-free hiking across the fells.',
    technical: {
      fibreDiameter: '32 μm',
      stapleLength: '100 mm',
      crimp: 'Springy',
      lustre: 'Low',
      handle: 'Thick Loop Cushion',
      warmth: 'Exceptional',
      durability: 'Extreme',
    },
    applications: ['Hiking Boots', 'Wellington Boots', 'Winter Lounging'],
  },

  // --- CRAFT & TOOLS ---
  {
    id: 'prod-cr01',
    name: 'Yorkshire English Oak Drop Spindle (55g)',
    category: 'CRAFT',
    subCategory: 'Spinning Tools',
    breed: 'N/A',
    origin: 'Sheffield Workshop',
    price: 38.00,
    unit: 'Hand-turned spindle',
    isNaturalColour: true,
    colourFamily: 'Timber',
    colourName: 'Smoked Oak',
    colourHex: '#874536',
    handle: 'Balanced / Smooth',
    lotNumber: 'BBS-26-TL01',
    images: ['/images/fleece.jpg', '/images/yarn.jpg'],
    description: 'Hand-turned from reclaimed English oak timber salvaged from an 1870s Bradford wool store. Perfectly rim-weighted for long, effortless spin times.',
    technical: {
      fibreDiameter: 'N/A',
      stapleLength: 'N/A',
      crimp: 'N/A',
      lustre: 'N/A',
      handle: 'Beeswax Hand-Polished',
      warmth: 'N/A',
      durability: 'Generational',
    },
    applications: ['Wool Spinning', 'Worsted Draft', 'Travel Craft'],
    featured: true,
  },
  {
    id: 'prod-cr02',
    name: 'Complete British Wool Knitting Kit — Fell Beanie',
    category: 'CRAFT',
    subCategory: 'Kits',
    breed: 'Swaledale & BFL',
    origin: 'Yorkshire',
    price: 36.00,
    unit: 'Complete Boxed Kit',
    isNaturalColour: true,
    colourFamily: 'Natural Grey',
    colourName: 'Fell Grey Duo',
    colourHex: '#77746F',
    handle: 'Complete Craft Kit',
    lotNumber: 'BBS-26-KT02',
    images: ['/images/yarn.jpg', '/images/cloth.jpg'],
    description: 'Includes 100g Baba Swaledale DK, a pair of hand-waxed British beechwood circular needles (4.5mm), printed architectural pattern sheet, and brass tapestry needle.',
    technical: {
      fibreDiameter: '30 μm',
      stapleLength: '105 mm',
      crimp: 'Medium',
      lustre: 'Subtle',
      handle: 'Crisp & Warm',
      warmth: 'High',
      durability: 'High',
    },
    applications: ['Beginner/Intermediate Project', 'Gift', 'Weekend Knit'],
  },
  {
    id: 'prod-cr03',
    name: 'The British Wool Standard: Specimen Book & Patterns',
    category: 'CRAFT',
    subCategory: 'Books & Patterns',
    breed: 'Multi-breed',
    origin: 'London & Yorkshire',
    price: 45.00,
    unit: 'Hardcover Linen Edition, 280pp',
    isNaturalColour: true,
    colourFamily: 'Linen',
    colourName: 'Natural Buckram',
    colourHex: '#E8E0D2',
    handle: 'Litho-Printed',
    lotNumber: 'BBS-26-BK01',
    images: ['/images/hero_macro.jpg', '/images/cloth.jpg'],
    description: 'The definitive architectural study of British sheep breeds, fleece grading diagrams, worsted spinning mechanics, and 24 master patterns for garments and interiors.',
    technical: {
      fibreDiameter: 'N/A',
      stapleLength: 'N/A',
      crimp: 'N/A',
      lustre: 'N/A',
      handle: 'Heavy Uncoated Stock',
      warmth: 'N/A',
      durability: 'Archival',
    },
    applications: ['Material Reference', 'Knitting Reference', 'Studio Library'],
    featured: true,
  }
];

// LIVE SIMULATED MARKET INFORMATION: THE WOOL BOARD
export const WOOL_BOARD_DATA: MarketObservation[] = [
  {
    id: 'wb-01',
    grade: 'Fine Fleece',
    description: 'Bluefaced Leicester, Fine Crosses (<28μm)',
    pricePerKg: 7.85,
    currency: 'GBP',
    change: 4.8,
    trend: 'up',
    volumeBales: 1420,
    dominantBreeds: ['Bluefaced Leicester', 'Shetland Fine'],
    updatedAt: 'Today, 08:30 GMT'
  },
  {
    id: 'wb-02',
    grade: 'Medium Lustre',
    description: 'Wensleydale, Teeswater, Romney (29–34μm)',
    pricePerKg: 5.40,
    currency: 'GBP',
    change: 1.2,
    trend: 'up',
    volumeBales: 2850,
    dominantBreeds: ['Romney', 'Wensleydale', 'Masham'],
    updatedAt: 'Today, 08:30 GMT'
  },
  {
    id: 'wb-03',
    grade: 'Hill & Mountain',
    description: 'Swaledale, Cheviot, Welsh Mountain (33–38μm)',
    pricePerKg: 3.65,
    currency: 'GBP',
    change: 0.0,
    trend: 'steady',
    volumeBales: 5600,
    dominantBreeds: ['Swaledale', 'Cheviot', 'Dalesbred'],
    updatedAt: 'Today, 08:30 GMT'
  },
  {
    id: 'wb-04',
    grade: 'Heavy Rug & Kemp',
    description: 'Herdwick, Hebridean, Lincoln Longwool (>38μm)',
    pricePerKg: 2.90,
    currency: 'GBP',
    change: -2.1,
    trend: 'down',
    volumeBales: 1940,
    dominantBreeds: ['Herdwick', 'Hebridean', 'Blackface'],
    updatedAt: 'Today, 08:30 GMT'
  }
];

// TRACEABILITY LOTS (DEMO DATA)
export const TRACEABILITY_LOTS: Record<string, TraceabilityLot> = {
  'BBS-26-041': {
    lotNumber: 'BBS-26-041',
    productName: 'Baba Swaledale DK',
    breed: 'Swaledale',
    region: 'Yorkshire Dales (Upper Swaledale Common)',
    shearSeason: 'July 2025',
    processor: 'Synthetic Pennine Wool Scourers, West Yorkshire',
    scouringFacility: 'Pennine Eco-Scourers, Shipley',
    spinningMill: 'Synthetic Calder Valley Worsted Spinners, Halifax',
    micronCertified: '33.2 μm (Standard Deviation 4.1 μm)',
    naturalLot: true,
    notes: 'Pure untreated British wool. 0% chlorine shrink-proofing, zero superwash synthetics.'
  },
  'BBS-26-018': {
    lotNumber: 'BBS-26-018',
    productName: 'Herdwick Heavy Aran',
    breed: 'Herdwick',
    region: 'Coniston Fells, Cumbria',
    shearSeason: 'August 2025',
    processor: 'Synthetic Eden Valley Fibre Wash',
    scouringFacility: 'Kendal Wash Works',
    spinningMill: 'Synthetic Westmorland Woollen Mill',
    micronCertified: '40.8 μm (High Kemp Fraction: 11%)',
    naturalLot: true,
    notes: 'Traditional fell harvest. Coarse weather guard hair retained for maximum precipitation shedding.'
  },
  'BBS-26-088': {
    lotNumber: 'BBS-26-088',
    productName: 'Bluefaced Leicester 4-Ply Lustre',
    breed: 'Bluefaced Leicester',
    region: 'Eden Valley, Cumbria',
    shearSeason: 'June 2025',
    processor: 'Synthetic Northern Lustre Combers',
    scouringFacility: 'Shipley Clean Fibres',
    spinningMill: 'Synthetic Aire Valley Fine Spinners',
    micronCertified: '24.9 μm (Purl Crimp Index: 9.4)',
    naturalLot: false,
    notes: 'Dyed with GOTS-certified natural indigo vat system. Ph-neutralized rinse.'
  },
  'BBS-26-TW01': {
    lotNumber: 'BBS-26-TW01',
    productName: 'North Country Tweed Herringbone',
    breed: 'Swaledale & Cheviot',
    region: 'Pennine Corridor',
    shearSeason: 'July/August 2025',
    processor: 'Synthetic West Riding Combing Mills',
    scouringFacility: 'Bradford Bio-Wash Ltd',
    spinningMill: 'Huddersfield Woollen Spinners',
    weavingMill: 'Synthetic Holmfirth Heritage Looms (150cm Dornier Weft)',
    micronCertified: '32.5 μm Composite Warp/Weft',
    naturalLot: true,
    notes: 'Finished with natural spring water milling. 560 GSM.'
  }
};

// WOOL LIBRARY ARTICLES
export const WOOL_ARTICLES: WoolLibraryArticle[] = [
  {
    id: 'micron-science',
    title: 'What is Micron? The Metric of Tactility',
    category: 'FIBRE PHYSICS',
    readTime: '4 min read',
    summary: 'Why a 24-micron fleece feels like silk against the collarbone while a 40-micron Herdwick can withstand a century of heavy boots.',
    content: [
      'One micron (μm) is one-thousandth of a millimetre. In human terms, a strand of spider silk is approximately 3 to 8 microns; human scalp hair ranges from 50 to 100 microns.',
      'When wool fibres bend against nerve endings in human skin, fibres below 28 microns yield with minimal resistance, registering as soft or silky (such as Bluefaced Leicester at 24–28 μm). Fibres above 32 microns require greater force to deflect, providing the crisp structural resilience required for tailoring, tweed, and upholstery.',
      'British sheep breeds represent the world\'s most comprehensive catalogue of micron diversity—ranging from gossamer Shetland to indestructible Herdwick.'
    ],
    diagramType: 'MICRON_SCALE'
  },
  {
    id: 'worsted-vs-woollen',
    title: 'Worsted vs. Woollen: The Two Great Spinning Traditions',
    category: 'MILL MECHANICS',
    readTime: '5 min read',
    summary: 'The critical difference in yarn geometry: aligned parallel fibres that gleam versus airy scrambled clouds that insulate.',
    content: [
      'In a worsted yarn, wool fibres are combed repeatedly through steel pins until short fibres are discarded and all remaining long fibres lie in immaculate parallel alignment. The resulting yarn is smooth, dense, crease-resistant, and lustrous—the foundation of British suiting.',
      'In a woollen yarn, fibres are carded into an open criss-cross mesh and spun directly with air trapped between them. The resulting yarn is lofty, bloom-rich, lightweight, and warm—the hallmark of Shetland Fair Isle and Yorkshire tweed.'
    ],
    diagramType: 'FIBRE_ALIGNMENT'
  },
  {
    id: 'fleece-grading',
    title: 'How a British Fleece is Graded on the Board',
    category: 'AGRICULTURAL CULTURE',
    readTime: '6 min read',
    summary: 'Inside the grading depot: how five seconds of touch determines the fate of 5 kilograms of mountain fleece.',
    content: [
      'When an unwashed fleece arrives at the merchant\'s grading table, the wool grader grabs a handful, evaluates the handle blind, checks the crimp frequency, breaks a staple between their thumbs to test tensile sound, and separates the cast wool from the prime saddle.',
      'Points of examination: Staple sound (absence of hunger breaks), colour purity (absence of black hairs in white lots), vegetable matter contamination, and degree of crimp definition.'
    ],
    diagramType: 'FLEECE_SADDLE'
  },
  {
    id: 'warmth-insulation',
    title: 'What Makes Wool So Warm? Thermal Dynamics of the Crimped Core',
    category: 'MATERIAL SCIENCE',
    readTime: '3 min read',
    summary: 'Wool generates heat when it absorbs moisture: the remarkable exothermic reaction of keratin.',
    content: [
      'Wool is not merely a passive insulator. When water vapour molecules penetrate the inner cortex of wool fibres, hydrogen bonds reform in an exothermic reaction known as the "heat of sorption".',
      'As you step from a dry heated house into damp freezing mist, a pure wool coat actively releases up to 27 joules of warmth per gram of fibre—acting as a climate-regulating biological membrane.'
    ]
  }
];

// TIMELINE PROCESS: FROM SHEEP TO OBJECT (10 STAGES)
export interface ProcessStage {
  step: string;
  title: string;
  subtitle: string;
  location: string;
  description: string;
  technicalNote: string;
  image: string;
}

export const PROCESS_STAGES: ProcessStage[] = [
  {
    step: '01',
    title: 'The Sheep',
    subtitle: 'Highland fell and lowland marsh genetics',
    location: 'Yorkshire, Cumbria, Shetland, Kent',
    description: 'Over 60 distinct British sheep breeds have evolved specifically to thrive in their micro-regions, producing fleeces perfectly adapted to cold rain, coastal salt winds, and upland crags.',
    technicalNote: 'Fleece weight ranges from 1.5kg (primitive Shetland) to 10kg+ (Lincoln Longwool).',
    image: '/images/sheep.jpg'
  },
  {
    step: '02',
    title: 'Shearing',
    subtitle: 'The summer harvest of the flock',
    location: 'Open fells & shearing sheds',
    description: 'Carried out between June and August once the natural wool "rise" occurs. Expert shearers peel the fleece off in a single unbroken blanket with steady rhythmic passes.',
    technicalNote: 'Hand and electric shears remove the fleece without harm to the sheep.',
    image: '/images/fleece.jpg'
  },
  {
    step: '03',
    title: 'Grading',
    subtitle: 'The sensory assessment of handle and sound',
    location: 'Regional Wool Depots',
    description: 'Experienced graders sort each fleece by micron, staple length, kemp content, and colour purity in under ten seconds by touch and eye.',
    technicalNote: 'Staple strength is verified by holding locks taut and plucking like a harp string.',
    image: '/images/hero_macro.jpg'
  },
  {
    step: '04',
    title: 'Scouring',
    subtitle: 'Washing in soft Yorkshire spring water',
    location: 'West Yorkshire scouring works',
    description: 'Raw wool contains natural lanolin wax and dust. Gentle multi-bowl counter-current washing removes impurities without damaging the natural scales or felting the fibres.',
    technicalNote: 'Lanolin is recovered for pharmaceutical and cosmetic salves.',
    image: '/images/fleece.jpg'
  },
  {
    step: '05',
    title: 'Carding',
    subtitle: 'Disentangling the fleece into a continuous web',
    location: 'Textile carding engines',
    description: 'Revolving cylinders with millions of wire teeth comb the scrambled wool into an airy, cloud-like web called a batt or sliver, ready for spinning.',
    technicalNote: 'Air pockets created here determine the loft and warmth of the finished yarn.',
    image: '/images/hero_macro.jpg'
  },
  {
    step: '06',
    title: 'Combing (Worsted)',
    subtitle: 'Parallel fibre alignment & removal of noils',
    location: 'Combing sheds',
    description: 'For sleek worsted yarns, fibres undergo circular or rectilinear combing to align every strand in the same direction and remove short tangled fibres.',
    technicalNote: 'Yields a continuous silver ribbon known as "Combed Top".',
    image: '/images/hero_macro.jpg'
  },
  {
    step: '07',
    title: 'Spinning',
    subtitle: 'Drafting and inserting twist',
    location: 'Spinning frames and ring spindles',
    description: 'Fibre slivers are drawn out to the target gauge and twisted together. Twist locks the overlapping microscopic scales into a durable yarn that resists snapping.',
    technicalNote: 'Z-twist or S-twist singles are plied together to balance internal torque.',
    image: '/images/yarn.jpg'
  },
  {
    step: '08',
    title: 'Dyeing (Optional)',
    subtitle: 'Natural pigments and low-impact baths',
    location: 'Dyehouse vats',
    description: 'While our natural collection remains 100% undyed, our dyed collection enters immersion vats with indigo, madder, walnut, and certified ecological dyes.',
    technicalNote: 'Wool\'s amino-acid structure creates exceptionally permanent chemical bonds with dye molecules.',
    image: '/images/yarn.jpg'
  },
  {
    step: '09',
    title: 'Weaving & Knitting',
    subtitle: 'The interlacing of warp, weft, and loops',
    location: 'Yorkshire looms & Scottish knitting frames',
    description: 'Yarn is threaded through heddles on heavy looms to form tweed, blanket cloth, and upholstery, or knit into seamless Guernseys and Fair Isle garments.',
    technicalNote: 'Cloth is woven under precise tension to accommodate subsequent wet finishing.',
    image: '/images/cloth.jpg'
  },
  {
    step: '10',
    title: 'Finishing & Object',
    subtitle: 'Fulling, teasel raising, and pressing',
    location: 'Finishing houses',
    description: 'Woven cloth is washed in warm water and soap (fulling) to shrink and lock the fibres, dried on tenters, teasel-brushed for nap, and hand-inspected before dispatch.',
    technicalNote: 'The completed object is biologically circular, biodegradable, and built for generations.',
    image: '/images/cloth.jpg'
  }
];

// COLOUR PALETTE DEFINITIONS
export const NATURAL_COLOURS = [
  { name: 'Raw Limestone White', hex: '#F3F0E8', origin: 'Cheviot & Romney', desc: 'Chalk-toned undyed wool with natural lanolin luminescence.' },
  { name: 'Warm Cream Fleece', hex: '#E8E0D2', origin: 'Bluefaced Leicester', desc: 'Warm ivory with soft golden undertones.' },
  { name: 'Fellside Oatmeal', hex: '#CDBFA8', origin: 'Masham & Swaledale Cross', desc: 'Subtle speckled beige blended with darker guard hairs.' },
  { name: 'Moorland Grey', hex: '#77746F', origin: 'Swaledale & Herdwick', desc: 'Muted limestone mist with silver hair flecks.' },
  { name: 'Coniston Charcoal', hex: '#30302D', origin: 'Herdwick Mature Fleece', desc: 'Deep stormy graphite grey with pure white kemp highlights.' },
  { name: 'Peat Bog Black', hex: '#191918', origin: 'Hebridean & Black Welsh', desc: 'Dense volcanic black with sun-bleached mahogany tips.' },
];

export const DYED_COLOURS = [
  { name: 'Sheep Red (Madder)', hex: '#A33E32', desc: 'Traditional British agricultural identification red.' },
  { name: 'North Sea Indigo', hex: '#263B49', desc: 'Deep maritime navy dyed in oxidised indigo vats.' },
  { name: 'Dyer’s Blue', hex: '#315A68', desc: 'Weathered slate-teal blue inspired by mineral dyes.' },
  { name: 'Gorse Flower Mustard', hex: '#B28A35', desc: 'Luminous wild gorse bloom yellow.' },
  { name: 'Border Moss Green', hex: '#4D5847', desc: 'Lichen and woodland moss green.' },
  { name: 'Deep Valley Pine', hex: '#30493C', desc: 'Rich coniferous green.' },
  { name: 'Moorland Peat', hex: '#5E625A', desc: 'Earthy grey-green moorland shade.' },
  { name: 'Yorkshire Brick', hex: '#874536', desc: 'Warm terracotta and weathered mill brick.' },
];
