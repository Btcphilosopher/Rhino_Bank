'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, Breed, UserProject, PRODUCTS, BREEDS } from './data';

export interface BasketItem {
  id: string; // unique item id (product id + variant)
  product: Product;
  quantity: number;
  variantId?: string;
  variantName?: string;
  customMetres?: number;
}

export interface TradeQuote {
  id: string;
  projectName: string;
  companyName: string;
  email: string;
  materialName: string;
  gsm: number;
  widthMm: number;
  colourName: string;
  quantityMetres: number;
  totalEstimate: number;
  status: 'QUOTATION' | 'SPECIFICATION_APPROVED' | 'IN_PRODUCTION';
  createdAt: string;
}

export interface SampleRequest {
  id: string;
  name: string;
  company: string;
  address: string;
  sampleTypes: string[];
  notes: string;
  createdAt: string;
}

interface EmporiumContextType {
  basket: BasketItem[];
  addToBasket: (product: Product, quantity?: number, variantId?: string, customMetres?: number) => void;
  removeFromBasket: (id: string) => void;
  updateQuantity: (id: string, delta: number) => void;
  clearBasket: () => void;
  basketCount: number;
  basketTotal: number;

  // Projects Digital Workbench
  projects: UserProject[];
  addProject: (project: Omit<UserProject, 'id' | 'createdAt'>) => void;
  updateProjectStatus: (id: string, status: UserProject['status']) => void;
  deleteProject: (id: string) => void;

  // Modals & Navigation
  activeModal: string | null;
  openModal: (modalName: string, entityId?: string) => void;
  closeModal: () => void;
  selectedProduct: Product | null;
  selectedBreed: Breed | null;
  selectedLot: string | null;
  selectedArticleId: string | null;

  // Accent Color (Dyed Collection interactive tone)
  accentTone: string;
  setAccentTone: (colorHex: string) => void;

  // Trade Quotes & Samples
  tradeQuotes: TradeQuote[];
  addTradeQuote: (quote: Omit<TradeQuote, 'id' | 'createdAt' | 'status'>) => TradeQuote;
  sampleRequests: SampleRequest[];
  addSampleRequest: (req: Omit<SampleRequest, 'id' | 'createdAt'>) => void;

  // Search & Global Filter State
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  activeCategory: string;
  setActiveCategory: (cat: string) => void;
  activeBreedFilter: string;
  setActiveBreedFilter: (breedId: string) => void;
}

const EmporiumContext = createContext<EmporiumContextType | undefined>(undefined);

export function EmporiumProvider({ children }: { children: React.ReactNode }) {
  const [basket, setBasket] = useState<BasketItem[]>([
    {
      id: 'prod-y01-v01',
      product: PRODUCTS[0],
      quantity: 4,
      variantId: 'v01',
      variantName: 'Natural Fell Grey',
    },
    {
      id: 'prod-c01-cloth',
      product: PRODUCTS[8], // North Country Tweed
      quantity: 2,
      customMetres: 2.0,
    }
  ]);

  const [projects, setProjects] = useState<UserProject[]>([
    {
      id: 'proj-01',
      title: 'Winter Fellside Jumper',
      category: 'Garment / Jumper',
      yarnId: 'prod-y01',
      yarnName: 'Baba Swaledale DK',
      breed: 'Swaledale',
      colour: 'Natural Fell Grey',
      quantityBalls: 8,
      weightGrams: 800,
      status: 'On Needles',
      notes: 'Knitting 4.5mm circular needles with classic moss stitch panels and moss raglan yoke.',
      createdAt: '2026-09-15',
    },
    {
      id: 'proj-02',
      title: 'Hebridean Floor Cushion',
      category: 'Interiors / Cushion',
      yarnId: 'prod-y07',
      yarnName: 'Hebridean Raw Single-Origin Aran',
      breed: 'Hebridean',
      colour: 'Peat Bog Black',
      quantityBalls: 5,
      weightGrams: 500,
      status: 'Planning',
      notes: 'Heavy ribbed twill texture for reading bench in sunroom.',
      createdAt: '2026-09-22',
    }
  ]);

  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedBreedId, setSelectedBreedId] = useState<string | null>(null);
  const [selectedLot, setSelectedLot] = useState<string | null>(null);
  const [selectedArticleId, setSelectedArticleId] = useState<string | null>(null);

  const [accentTone, setAccentTone] = useState<string>('#A33E32'); // Sheep Red accent default

  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('ALL');
  const [activeBreedFilter, setActiveBreedFilter] = useState('ALL');

  const [tradeQuotes, setTradeQuotes] = useState<TradeQuote[]>([
    {
      id: 'QUOTE-0842',
      projectName: 'Clifton Heritage Hotel Upholstery',
      companyName: 'Studio Craven Interior Architecture',
      email: 'spec@studiocraven.co.uk',
      materialName: 'Herdwick Architectural Upholstery Cloth',
      gsm: 680,
      widthMm: 1400,
      colourName: 'Fellside Slate (Charcoal)',
      quantityMetres: 184,
      totalEstimate: 20240.00,
      status: 'QUOTATION',
      createdAt: '2026-09-24',
    }
  ]);

  const [sampleRequests, setSampleRequests] = useState<SampleRequest[]>([
    {
      id: 'SMP-1092',
      name: 'Oliver Vance',
      company: 'Vance & Co Tailors, Savile Row',
      address: '14 Savile Row, Mayfair, London W1S 3JN',
      sampleTypes: ['Cloth Swatches (Tweed)', 'Yarn Cards', 'Breed Sample Box'],
      notes: 'Requesting 5 heavy coating samples and natural grey Cheviot swatches.',
      createdAt: '2026-09-25'
    }
  ]);

  const selectedProduct = selectedProductId ? PRODUCTS.find(p => p.id === selectedProductId) || null : null;
  const selectedBreed = selectedBreedId ? BREEDS.find(b => b.id === selectedBreedId) || null : null;

  const openModal = (modalName: string, entityId?: string) => {
    setActiveModal(modalName);
    if (modalName === 'product' && entityId) setSelectedProductId(entityId);
    if (modalName === 'breed' && entityId) setSelectedBreedId(entityId);
    if (modalName === 'traceability' && entityId) setSelectedLot(entityId);
    if (modalName === 'article' && entityId) setSelectedArticleId(entityId);
  };

  const closeModal = () => {
    setActiveModal(null);
  };

  const addToBasket = (product: Product, quantity = 1, variantId?: string, customMetres?: number) => {
    const itemKey = variantId ? `${product.id}-${variantId}` : `${product.id}-default`;
    let variantName: string | undefined;
    if (variantId && product.variants) {
      const v = product.variants.find(v => v.id === variantId);
      if (v) variantName = v.name;
    }

    setBasket(prev => {
      const existing = prev.find(item => item.id === itemKey);
      if (existing) {
        return prev.map(item =>
          item.id === itemKey
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [
        ...prev,
        {
          id: itemKey,
          product,
          quantity,
          variantId,
          variantName,
          customMetres
        }
      ];
    });
  };

  const removeFromBasket = (id: string) => {
    setBasket(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setBasket(prev =>
      prev
        .map(item => {
          if (item.id === id) {
            const nextQty = item.quantity + delta;
            return nextQty > 0 ? { ...item, quantity: nextQty } : null;
          }
          return item;
        })
        .filter(Boolean) as BasketItem[]
    );
  };

  const clearBasket = () => {
    setBasket([]);
  };

  const basketCount = basket.reduce((acc, item) => acc + item.quantity, 0);
  const basketTotal = basket.reduce((acc, item) => {
    const itemPrice = item.product.price;
    return acc + itemPrice * item.quantity;
  }, 0);

  const addProject = (project: Omit<UserProject, 'id' | 'createdAt'>) => {
    const newProj: UserProject = {
      ...project,
      id: `proj-${Date.now().toString().slice(-4)}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setProjects(prev => [newProj, ...prev]);
  };

  const updateProjectStatus = (id: string, status: UserProject['status']) => {
    setProjects(prev =>
      prev.map(p => (p.id === id ? { ...p, status } : p))
    );
  };

  const deleteProject = (id: string) => {
    setProjects(prev => prev.filter(p => p.id !== id));
  };

  const addTradeQuote = (quote: Omit<TradeQuote, 'id' | 'createdAt' | 'status'>) => {
    const newQuote: TradeQuote = {
      ...quote,
      id: `QUOTE-${Math.floor(1000 + Math.random() * 9000)}`,
      status: 'QUOTATION',
      createdAt: new Date().toISOString().split('T')[0]
    };
    setTradeQuotes(prev => [newQuote, ...prev]);
    return newQuote;
  };

  const addSampleRequest = (req: Omit<SampleRequest, 'id' | 'createdAt'>) => {
    const newReq: SampleRequest = {
      ...req,
      id: `SMP-${Math.floor(1000 + Math.random() * 9000)}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setSampleRequests(prev => [newReq, ...prev]);
  };

  return (
    <EmporiumContext.Provider
      value={{
        basket,
        addToBasket,
        removeFromBasket,
        updateQuantity,
        clearBasket,
        basketCount,
        basketTotal,
        projects,
        addProject,
        updateProjectStatus,
        deleteProject,
        activeModal,
        openModal,
        closeModal,
        selectedProduct,
        selectedBreed,
        selectedLot,
        selectedArticleId,
        accentTone,
        setAccentTone,
        tradeQuotes,
        addTradeQuote,
        sampleRequests,
        addSampleRequest,
        searchQuery,
        setSearchQuery,
        activeCategory,
        setActiveCategory,
        activeBreedFilter,
        setActiveBreedFilter,
      }}
    >
      {children}
    </EmporiumContext.Provider>
  );
}

export function useEmporium() {
  const context = useContext(EmporiumContext);
  if (!context) {
    throw new Error('useEmporium must be used within an EmporiumProvider');
  }
  return context;
}
