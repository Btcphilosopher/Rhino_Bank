import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {GoogleGenAI} from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Safe Gemini AI instance initialization
const apiKey = process.env['GEMINI_API_KEY'] || '';
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

// Initial synthetic vessel state for FV North Star
const vesselSpecs = {
  name: 'FV NORTH STAR',
  callsign: 'MNST4',
  mmsi: '232094820',
  flag: 'United Kingdom (UK)',
  portOfRegistry: 'Peterhead',
  registrationNumber: 'PD 412',
  loa: 64.8,
  beam: 14.2,
  draft: 6.8,
  grossTonnage: 1840,
  mainEngine: 'Bergen B33:45L8P Hybrid Diesel-Electric (3,200 kW)',
  auxGenerators: '2x Scania DI16 (640 kWe each) + 850 kWh Peak-Shaving ESS',
  trawlGear: 'Twin-rig demersal high-lift trawl with Morgère steerable clump',
  refrigeration: 'Dual-circuit CO2 / NH3 cascade (-28°C blast / -22°C hold)',
  autonomySystem: 'BTO-SYSTEM Autonomous Trawl Engine v4.8 (Industry 4.0 Marine Edition)',
  classification: "Lloyd's Register ✠ 100A1 Fishing Vessel, UMS, ICE-1B"
};

// API Endpoints
app.get('/api/vessel', (req, res) => {
  res.json({
    specs: vesselSpecs,
    timestamp: new Date().toISOString(),
    status: 'OPERATIONAL_SIMULATION',
    safetyNotice: 'SIMULATION / DECISION SUPPORT ONLY — HUMAN AUTHORISATION REQUIRED'
  });
});

app.get('/api/vessel/state', (req, res) => {
  res.json({
    vessel: 'FV NORTH STAR',
    tripId: 'TRIP-2026-026',
    mode: 'AT_SEA',
    latitude: 56.8421,
    longitude: 1.4820,
    heading: 287.4,
    speedKnots: 9.4,
    fuelPercent: 71.8,
    coldStorePercent: 64.2,
    seaState: 3,
    windKnots: 18.5,
    windDirection: 310,
    tripDay: 4,
    activeZone: 'ZONE N-04 (Fladen Ground)',
    engineRpm: 680,
    engineLoad: 62.4,
    totalCatchKg: 10118,
    autonomyMode: 'SUPERVISED_AUTONOMY',
    systemHealth: 'OPTIMAL'
  });
});

app.get('/api/vessel/telemetry', (req, res) => {
  res.json({
    propulsion: {
      rpm: 680,
      loadPercent: 62.4,
      fuelFlowLph: 342.0,
      coolantTempC: 84.2,
      oilPressureBar: 4.8,
      exhaustTempC: 382
    },
    generators: [
      { id: 'GEN-01', load: 58, outputKw: 371, freqHz: 50.1, status: 'ONLINE' },
      { id: 'GEN-02', load: 0, outputKw: 0, freqHz: 0, status: 'STANDBY' },
      { id: 'ESS-BATTERY', socPercent: 88.5, powerKw: -42.0, status: 'PEAK_SHAVING' }
    ],
    winches: [
      { id: 'WINCH-PORT', lineLengthM: 480, lineSpeedMps: 0.0, tensionKn: 84.5, motorLoad: 68, brakeState: 'ENGAGED', tempC: 48.2 },
      { id: 'WINCH-STBD', lineLengthM: 480, lineSpeedMps: 0.0, tensionKn: 85.2, motorLoad: 69, brakeState: 'ENGAGED', tempC: 49.1 }
    ],
    robotics: {
      armId: 'DR-04',
      status: 'SORTING',
      jointAngles: [14.2, -45.1, 88.4, 0.5, 32.1, 180.0],
      cycleTimeSec: 1.42,
      throughputKgH: 1850,
      lastDetectedSpecies: 'Haddock (Melanogrammus aeglefinus)',
      confidence: 0.94
    }
  });
});

app.get('/api/catch', (req, res) => {
  res.json({
    tripId: 'TRIP-2026-026',
    totalWeightKg: 10118,
    breakdown: [
      { species: 'Haddock', latin: 'Melanogrammus aeglefinus', weightKg: 4218, gradeA: 3650, gradeB: 568, avgLengthCm: 54, avgPricePerKg: 3.85 },
      { species: 'Cod', latin: 'Gadus morhua', weightKg: 2841, gradeA: 2420, gradeB: 421, avgLengthCm: 68, avgPricePerKg: 5.40 },
      { species: 'Plaice', latin: 'Pleuronectes platessa', weightKg: 1124, gradeA: 980, gradeB: 144, avgLengthCm: 38, avgPricePerKg: 2.95 },
      { species: 'Monkfish', latin: 'Lophius piscatorius', weightKg: 842, gradeA: 810, gradeB: 32, avgLengthCm: 72, avgPricePerKg: 7.60 },
      { species: 'Whiting', latin: 'Merlangius merlangus', weightKg: 580, gradeA: 490, gradeB: 90, avgLengthCm: 34, avgPricePerKg: 2.10 },
      { species: 'Other/Mixed', latin: 'Varius demersal', weightKg: 513, gradeA: 380, gradeB: 133, avgLengthCm: 30, avgPricePerKg: 1.80 }
    ]
  });
});

app.get('/api/elog', (req, res) => {
  res.json({
    system: 'UK Electronic Reporting System (ERS v3.4 Compliant)',
    mmoVesselRef: 'UK-ERS-MNST4-2026',
    queue: [
      { type: 'DEP', desc: 'Departure from Peterhead', timestamp: '2026-09-22T08:00:00Z', status: 'ACK', ackId: 'UK-ERS-ACK-99412' },
      { type: 'COE', desc: 'Prior notification entering North Sea Zone IVa', timestamp: '2026-09-22T14:20:00Z', status: 'ACK', ackId: 'UK-ERS-ACK-99450' },
      { type: 'FAR', desc: 'Fishing Activity Report - Hauls H01 to H04', timestamp: '2026-09-24T16:30:00Z', status: 'ACK', ackId: 'UK-ERS-ACK-99602' },
      { type: 'DIS', desc: 'Discard Notification (Undersize Whiting 12kg)', timestamp: '2026-09-24T16:35:00Z', status: 'ACK', ackId: 'UK-ERS-ACK-99605' },
      { type: 'PNO', desc: 'Prior Notification of Port Return', timestamp: '2026-09-26T04:15:00Z', status: 'PENDING', ackId: null }
    ]
  });
});

app.get('/api/vms', (req, res) => {
  res.json({
    status: 'CONNECTED',
    cadenceMinutes: 15,
    satelliteTransceiver: 'Iridium Certus Marine 100',
    signalStrengthDbm: -72,
    reportedLatitude: 56.8421,
    reportedLongitude: 1.4820,
    reportedSpeedKnots: 9.4,
    reportedCourseDeg: 287.4,
    mmoStatus: 'VERIFIED'
  });
});

app.post('/api/ai/query', async (req, res): Promise<void> => {
  const { query, vesselContext } = req.body;
  if (!query) {
    res.status(400).json({ error: 'Query is required' });
    return;
  }

  const systemPrompt = `You are BTO-SYSTEM Vessel Intelligence, an expert British maritime digital twin and autonomous operations advisory engine on FV NORTH STAR (Flag: UK, MMSI: 232094820, Port of Registry: Peterhead).
You represent high-end British naval architecture, North Sea fishing engineering, Rolls-Royce marine discipline, Industry 4.0 automation, and UK MMO / MCA compliance standards.
Always respond in crisp, authoritative, engineering-grade British English with clear technical breakdowns, data citations, and safety declarations.
Always include the standard mandatory disclaimer header: "[BTO-SYSTEM DECISION SUPPORT // SIMULATION ONLY // HUMAN AUTHORISATION REQUIRED]".
Current Vessel Telemetry Context: ${JSON.stringify(vesselContext || {})}`;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `${systemPrompt}\n\nOperator Query: ${query}`,
      });
      res.json({
        answer: response.text,
        source: 'GEMINI_2.5_MARITIME_ENGINE',
        timestamp: new Date().toISOString()
      });
      return;
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      console.warn('Gemini API call failed, providing rule-based synthetic response:', message);
    }
  }

  let syntheticResponse = `[BTO-SYSTEM DECISION SUPPORT // SIMULATION ONLY // HUMAN AUTHORISATION REQUIRED]\n\n`;
  const lower = query.toLowerCase();

  if (lower.includes('status') || lower.includes('state')) {
    syntheticResponse += `VESSEL TELEMETRY ASSESSMENT (FV NORTH STAR / TRIP 026):\n` +
      `• Position: 56°50.5'N 001°28.9'E (Fladen Ground, Zone N-04)\n` +
      `• Operational Mode: SUPERVISED AUTONOMOUS TOWING (Course 287°, Speed 9.4 kt)\n` +
      `• Propulsion & Power: Bergen Hybrid 62.4% Load, Fuel Flow 342 L/h, ESS SOC 88.5%\n` +
      `• Cold Store Hold: 64.2% Capacity (10.118 Tonnes demersal catch preserved at -24.8°C)\n` +
      `• Weather & Sea: Beaufort Force 5 (Wind 310°/18.5kt, Sig Wave Ht 2.4m, Sea State 3)\n` +
      `• Recommendation: Maintain current trawl tow for 95 minutes, then execute automated haul sequence prior to forecast wind shear at 14:00 UTC.`;
  } else if (lower.includes('robot') || lower.includes('processing') || lower.includes('bottleneck')) {
    syntheticResponse += `FISH PROCESSING LINE & ROBOTIC CELL DR-04 ANALYSIS:\n` +
      `• Optical Vision System: VISION-07 operational at 94.2% species classification confidence.\n` +
      `• Robotic Sorter DR-04: Cycle rate 1.42s/fish, handling 1.85 t/h demersal mix.\n` +
      `• Current Bottleneck: Line 02 Gutting Machine feed sync (differential buffer currently at 78% capacity).\n` +
      `• Quality Grade Yield: Grade A (88.4%), Grade B (11.6%), Zero reject threshold breached.\n` +
      `• Recommendation: Modulate conveyor speed from 0.85 m/s to 0.72 m/s to equalize grading hopper intake and prevent joint torque warnings on Axis 3.`;
  } else if (lower.includes('weather') || lower.includes('wind') || lower.includes('sea')) {
    syntheticResponse += `METEOROLOGICAL & HYDRODYNAMIC TWIN EVALUATION:\n` +
      `• Current: Wind 310° at 18.5 kt, Swell 2.4m period 7.2s. Dynamic vessel pitch 2.8° RMS.\n` +
      `• 6-Hour Forecast: Approaching North Sea low-pressure trough (996 hPa). Wind veering NW 28-34 kt (Gale Force 7), swell building to 4.1m.\n` +
      `• Digital Twin Risk Model: Deck machinery safety window expires at 12:45 UTC. Fuel consumption penalty increases by +22% in head seas.\n` +
      `• Autonomous Course Proposal: Route Option Beta (274° heading via Buchan Deep sheltered corridor to Peterhead). Estimated transit: 14.2 hours.`;
  } else if (lower.includes('quota') || lower.includes('elog') || lower.includes('compliance')) {
    syntheticResponse += `UK MMO QUOTA & ELECTRONIC REPORTING (ERS) AUDIT:\n` +
      `• Trip ERS Log: 5 Activity Reports (FAR) transmitted & ACK confirmed by UK MMO.\n` +
      `• Quota Utilization (Area IVa): Haddock (68.4% of trip quota), Cod (81.2% - caution threshold), Plaice (41.0%), Monkfish (52.6%).\n` +
      `• Prior Notification (PNO): Dispatched for Peterhead quay arrival. ETA: 18:30 UTC.\n` +
      `• Landing Declaration (LAN): Pre-compiled with full batch RFID traceability passports ready for auction dispatch.`;
  } else {
    syntheticResponse += `DIGITAL TWIN TELEMETRY SYNTHESIS:\n` +
      `• System: BTO-SYSTEM v4.8 North Sea Core Engine.\n` +
      `• Real-time digital twin monitoring 340 telemetry channels across propulsion, winches, robotics, refrigeration, and acoustic sonar.\n` +
      `• All systems operating within approved marine engineering tolerances.\n` +
      `• Query Parameter Processed: "${query}". Digital twin state is consistent with Trip 026 operational protocol.`;
  }

  res.json({
    answer: syntheticResponse,
    source: 'BTO_MARITIME_RULE_ENGINE',
    timestamp: new Date().toISOString()
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
