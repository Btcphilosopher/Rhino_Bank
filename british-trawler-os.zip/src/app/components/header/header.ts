import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TrawlerStateService } from '../../services/trawler-state.service';
import { AutonomyLevel } from '../../models/trawler.models';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-[#171B1D] border-b border-white/10 text-[#E9ECE8] select-none">
      <!-- Safety Boundary Banner (MANDATORY REQUIREMENT) -->
      <div class="bg-[#C96532]/20 border-b border-[#C96532]/30 px-3 py-1 flex items-center justify-between text-[11px] font-mono text-[#E9ECE8]">
        <div class="flex items-center gap-2">
          <span class="inline-flex items-center justify-center bg-[#C96532] text-white px-1.5 py-0.5 rounded font-bold text-[10px] tracking-wider">
            SAFETY NOTICE
          </span>
          <span class="font-semibold text-white">SIMULATION / DECISION SUPPORT / HUMAN AUTHORISATION REQUIRED</span>
          <span class="hidden md:inline text-[#A8B0AF]">| BTO-SYSTEM DOES NOT ENGAGE DIRECT PHYSICAL CONTROL OF PROPULSION OR ACTUATORS</span>
        </div>
        <div class="flex items-center gap-3 text-xs">
          <span class="text-[#BFD2D5]">LLOYD'S REG ✠ 100A1</span>
          <span class="text-[#46725F] flex items-center gap-1">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> DIGITAL TWIN SYNCED
          </span>
        </div>
      </div>

      <!-- Main Header Bar -->
      <div class="px-3 py-2 flex flex-wrap items-center justify-between gap-3">
        <!-- Brand & Vessel Identity -->
        <div class="flex items-center gap-3">
          <!-- British Maritime Ensign Symbol -->
          <div class="w-8 h-8 rounded bg-[#193D4C] border border-white/20 flex flex-col items-center justify-center font-mono font-black text-xs text-[#BFD2D5] shadow-inner">
            <span>BTO</span>
          </div>

          <div>
            <div class="flex items-center gap-2">
              <h1 class="font-mono text-base font-extrabold tracking-wider text-white">BRITISH TRAWLER OS</h1>
              <span class="text-[10px] font-mono bg-[#35677A]/40 text-[#BFD2D5] px-1.5 py-0.5 rounded border border-[#35677A]/50">
                BTO-SYSTEM v4.8
              </span>
            </div>
            <div class="text-[11px] font-mono text-[#A8B0AF] flex items-center gap-2">
              <span class="text-white font-bold">FV NORTH STAR</span>
              <span>•</span>
              <span>REG: PD 412 (PETERHEAD)</span>
              <span>•</span>
              <span class="text-[#BFD2D5]">MMSI: 232094820</span>
              <span>•</span>
              <span class="text-[#C0923D]">TRIP 026 (DAY {{ tripDay() }})</span>
            </div>
          </div>
        </div>

        <!-- Autonomy Level Mode Selector -->
        <div class="flex items-center gap-1.5 bg-[#2B3032]/80 border border-white/10 p-1 rounded-lg">
          <span class="text-[10px] font-mono text-[#697276] px-1.5 uppercase font-bold">AUTONOMY:</span>
          @for (lvl of autonomyLevels; track lvl) {
            <button
              (click)="setAutonomy(lvl)"
              [class]="
                autonomyLevel() === lvl
                  ? 'bg-[#C96532] text-white font-bold shadow-sm'
                  : 'bg-transparent text-[#A8B0AF] hover:text-white hover:bg-white/5'
              "
              class="px-2 py-0.5 text-xs rounded font-mono transition-all cursor-pointer"
            >
              {{ formatAutonomyLabel(lvl) }}
            </button>
          }
        </div>

        <!-- Simulation Speed & Clock Controls -->
        <div class="flex items-center gap-3">
          <div class="flex items-center gap-1 bg-[#2B3032]/80 border border-white/10 p-1 rounded-lg font-mono text-xs">
            <button
              (click)="toggleSim()"
              [title]="isRunning() ? 'Pause Simulation' : 'Resume Simulation'"
              class="p-1 rounded hover:bg-white/10 text-[#E9ECE8] transition-colors cursor-pointer flex items-center justify-center"
            >
              <mat-icon class="text-sm! w-4! h-4!">{{ isRunning() ? 'pause' : 'play_arrow' }}</mat-icon>
            </button>
            <div class="h-3 w-px bg-white/20"></div>
            @for (m of [1, 2, 5, 10]; track m) {
              <button
                (click)="setTimeMult(m)"
                [class]="timeMultiplier() === m ? 'bg-[#35677A] text-white font-bold' : 'text-[#A8B0AF] hover:text-white'"
                class="px-1.5 py-0.5 rounded text-[11px] transition-colors cursor-pointer"
              >
                {{ m }}x
              </button>
            }
          </div>

          <!-- UTC Clock -->
          <div class="font-mono text-right bg-[#142A35] border border-white/10 px-2.5 py-1 rounded-lg">
            <div class="text-xs font-bold text-white tracking-widest">{{ currentUtcString() }}</div>
            <div class="text-[9px] text-[#A8B0AF] uppercase tracking-wider">NORTH SEA UTC TIME</div>
          </div>
        </div>
      </div>

      <!-- Navigation Tabs -->
      <nav class="px-2 flex items-center gap-1 overflow-x-auto border-t border-white/10 bg-[#142A35] py-1 text-xs font-mono scrollbar-none">
        @for (tab of tabs; track tab.id) {
          <button
            (click)="selectTab(tab.id)"
            [class]="
              activeTab() === tab.id
                ? 'bg-[#193D4C] text-[#E9ECE8] border-[#35677A] font-bold shadow-sm'
                : 'bg-transparent text-[#A8B0AF] border-transparent hover:text-white hover:bg-white/5'
            "
            class="px-3 py-1.5 rounded-t border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer"
          >
            <mat-icon class="text-sm! w-4! h-4! leading-none">{{ tab.icon }}</mat-icon>
            {{ tab.label }}
          </button>
        }
      </nav>
    </header>
  `,
  styles: [
    `
      :host {
        display: block;
      }
    `,
  ],
})
export class Header {
  private state = inject(TrawlerStateService);

  readonly isRunning = this.state.isRunning;
  readonly timeMultiplier = this.state.timeMultiplier;
  readonly activeTab = this.state.activeTab;
  readonly autonomyLevel = this.state.autonomyLevel;
  readonly tripDay = this.state.tripDay;
  readonly simulationUtc = this.state.simulationUtc;

  readonly autonomyLevels: AutonomyLevel[] = [
    'MANUAL',
    'ASSISTED',
    'SUPERVISED_AUTONOMY',
    'SIMULATION_AUTONOMY',
  ];

  readonly tabs = [
    { id: 'VESSEL', label: 'VESSEL TWIN', icon: 'directions_boat' },
    { id: 'NAVIGATION', label: 'NAVIGATION & ECDIS', icon: 'explore' },
    { id: 'FISHING', label: 'TRAWL OPERATIONS', icon: 'water' },
    { id: 'GEAR', label: 'WINCHES & GEAR', icon: 'settings_input_component' },
    { id: 'CATCH', label: 'CATCH MANAGEMENT', icon: 'scale' },
    { id: 'PROCESSING', label: 'ROBOTIC PROCESSING', icon: 'precision_manufacturing' },
    { id: 'COLD_STORE', label: 'COLD CHAIN HOLD', icon: 'ac_unit' },
    { id: 'ENERGY', label: 'PROPULSION & ENERGY', icon: 'bolt' },
    { id: 'MAINTENANCE', label: 'PMS MAINTENANCE', icon: 'build' },
    { id: 'COMPLIANCE', label: 'UK ERS & VMS', icon: 'verified' },
    { id: 'LOGISTICS', label: 'PORT & LANDING', icon: 'storefront' },
    { id: 'ANALYTICS', label: 'TRIP ECONOMICS', icon: 'analytics' },
    { id: 'SIMULATION', label: 'SCENARIO LAB', icon: 'science' },
    { id: 'ASSISTANT', label: 'VESSEL INTELLIGENCE', icon: 'psychology' },
    { id: 'KNOWLEDGE', label: 'SPECIES & MANUALS', icon: 'menu_book' },
  ];

  selectTab(tabId: string) {
    this.state.setActiveTab(tabId);
  }

  setAutonomy(lvl: AutonomyLevel) {
    this.state.setAutonomyLevel(lvl);
  }

  toggleSim() {
    this.state.toggleSimulation();
  }

  setTimeMult(m: number) {
    this.state.setTimeMultiplier(m);
  }

  formatAutonomyLabel(lvl: AutonomyLevel): string {
    switch (lvl) {
      case 'MANUAL':
        return 'MANUAL';
      case 'ASSISTED':
        return 'ASSISTED';
      case 'SUPERVISED_AUTONOMY':
        return 'SUPERVISED';
      case 'SIMULATION_AUTONOMY':
        return 'FULL AUTONOMOUS';
    }
  }

  currentUtcString(): string {
    const d = this.simulationUtc();
    return d.toISOString().replace('T', ' ').substring(11, 19) + ' UTC';
  }
}
