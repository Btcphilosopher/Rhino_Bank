import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TrawlerStateService } from '../../services/trawler-state.service';

@Component({
  selector: 'app-navigation-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col md:flex-row gap-3 p-3 overflow-y-auto font-mono select-none">
      <!-- Left Column: ECDIS Electronic Nautical Chart & Radar -->
      <div class="flex-1 flex flex-col bg-[#171B1D] border border-white/10 rounded-xl overflow-hidden min-h-[480px]">
        <!-- Chart Header Bar -->
        <div class="bg-[#142A35] border-b border-white/10 px-3 py-2 flex items-center justify-between text-xs">
          <div class="flex items-center gap-2">
            <mat-icon class="text-sm! w-4! h-4! text-[#35677A]">map</mat-icon>
            <span class="font-bold text-white tracking-wider">ECDIS VECTOR CHART // NORTH SEA SECTOR IVa</span>
            <span class="text-[10px] bg-[#35677A]/30 text-[#BFD2D5] px-1.5 py-0.5 rounded">UK-HO WGS-84</span>
          </div>
          <div class="flex items-center gap-3 text-[#A8B0AF] text-[11px]">
            <span>LAT: <strong class="text-white">{{ navigation().lat.toFixed(4) }}° N</strong></span>
            <span>LON: <strong class="text-white">{{ navigation().lon.toFixed(4) }}° E</strong></span>
            <span>SCALE: <strong class="text-[#BFD2D5]">1:50,000</strong></span>
          </div>
        </div>

        <!-- Interactive SVG Chart Area -->
        <div class="relative flex-1 bg-[#0F1E26] overflow-hidden flex items-center justify-center">
          <svg class="w-full h-full" viewBox="0 0 800 500" preserveAspectRatio="xMidYMid slice">
            <!-- Grid Lines -->
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#193D4C" stroke-width="0.75" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />

            <!-- Depth Bathymetric Contour Shading -->
            <path d="M 0,200 Q 200,160 400,220 T 800,180 L 800,500 L 0,500 Z" fill="#142A35" opacity="0.6" />
            <path d="M 0,320 Q 300,280 500,340 T 800,300 L 800,500 L 0,500 Z" fill="#0D1F28" opacity="0.7" />

            <!-- Scottish Coastline Representation (West Edge) -->
            <path
              d="M 20,0 Q 60,80 45,150 T 80,260 T 30,380 T 60,500 L 0,500 L 0,0 Z"
              fill="#2B3032"
              stroke="#697276"
              stroke-width="1.5"
            />
            <text x="35" y="140" fill="#E9ECE8" font-size="11" font-weight="bold">PETERHEAD</text>
            <circle cx="50" cy="145" r="4" fill="#C96532" />

            <text x="30" y="240" fill="#E9ECE8" font-size="11" font-weight="bold">ABERDEEN</text>
            <circle cx="55" cy="245" r="4" fill="#C0923D" />

            <!-- Marine Protected Area (MPA) Hatching - Red Restricted Zone -->
            <rect x="240" y="80" width="160" height="110" fill="#A6453D" opacity="0.15" stroke="#A6453D" stroke-dasharray="4,4" stroke-width="1.2" />
            <text x="250" y="100" fill="#A6453D" font-size="10" font-weight="bold">MPA EXCLUSION ZONE (NO TRAWL)</text>

            <!-- Traffic Separation Scheme (TSS) Corridor -->
            <path d="M 120,400 L 450,420" stroke="#35677A" stroke-width="20" opacity="0.2" />
            <path d="M 120,400 L 450,420" stroke="#BFD2D5" stroke-width="1" stroke-dasharray="6,4" fill="none" />
            <text x="220" y="415" fill="#BFD2D5" font-size="9">TSS NORTH CORRIDOR</text>

            <!-- Fishing Grounds / Zones -->
            <!-- Zone N-04 (Fladen Ground - Active Zone) -->
            <polygon points="380,120 620,130 600,280 360,260" fill="#46725F" opacity="0.2" stroke="#46725F" stroke-width="1.5" />
            <text x="420" y="150" fill="#46725F" font-size="12" font-weight="bold">ZONE N-04 (FLADEN GROUND)</text>
            <text x="420" y="168" fill="#A8B0AF" font-size="9">DEMERSAL TARGET: HADDOCK / COD / PLAICE</text>

            <!-- Zone N-02 (Forties Bank) -->
            <polygon points="460,300 700,310 680,440 440,420" fill="#35677A" opacity="0.15" stroke="#35677A" stroke-dasharray="3,3" stroke-width="1" />
            <text x="500" y="340" fill="#35677A" font-size="10" font-weight="bold">ZONE N-02 (FORTIES)</text>

            <!-- Planned Autonomous Route Polyline -->
            <polyline
              points="50,145 180,160 320,180 480,210 540,230"
              fill="none"
              stroke="#C0923D"
              stroke-width="2"
              stroke-dasharray="8,4"
            />

            <!-- Waypoint Markers -->
            <circle cx="180" cy="160" r="3" fill="#C0923D" />
            <text x="185" y="155" fill="#C0923D" font-size="9">WP-01</text>
            <circle cx="320" cy="180" r="3" fill="#C0923D" />
            <text x="325" y="175" fill="#C0923D" font-size="9">WP-02</text>

            <!-- FV NORTH STAR Current Position (480, 210) -->
            <!-- Range Rings around vessel -->
            <circle cx="480" cy="210" r="45" fill="none" stroke="#BFD2D5" stroke-width="0.5" stroke-dasharray="2,2" opacity="0.4" />
            <circle cx="480" cy="210" r="90" fill="none" stroke="#BFD2D5" stroke-width="0.5" stroke-dasharray="2,2" opacity="0.2" />

            <!-- Vessel Heading Vector Line -->
            <line x1="480" y1="210" x2="430" y2="195" stroke="#C96532" stroke-width="2" />

            <!-- Vessel Marker Icon -->
            <g transform="translate(480, 210) rotate(-72)">
              <polygon points="0,-12 6,8 0,5 -6,8" fill="#C96532" stroke="#FFFFFF" stroke-width="1" />
            </g>
            <text x="495" y="205" fill="#FFFFFF" font-size="11" font-weight="bold">FV NORTH STAR (9.4 KT)</text>

            <!-- AIS Targets -->
            <!-- Target 1: Cargo MV North Sea Trader -->
            <g transform="translate(560, 160)">
              <polygon points="0,-6 4,4 0,2 -4,4" fill="#35677A" stroke="#BFD2D5" stroke-width="0.8" />
              <text x="8" y="4" fill="#BFD2D5" font-size="9">MV NORTH SEA TRADER (12.1 KT)</text>
              <line x1="0" y1="0" x2="-20" y2="15" stroke="#35677A" stroke-width="1" stroke-dasharray="2,2" />
            </g>

            <!-- Target 2: Trawler Altair -->
            <g transform="translate(390, 250)">
              <polygon points="0,-6 4,4 0,2 -4,4" fill="#46725F" stroke="#FFFFFF" stroke-width="0.8" />
              <text x="8" y="4" fill="#E9ECE8" font-size="9">FV ALTAIR (FR 12)</text>
            </g>
          </svg>

          <!-- Floating Radar Distance Legend -->
          <div class="absolute bottom-2 left-2 bg-[#171B1D]/85 border border-white/10 px-2 py-1 rounded text-[10px] text-[#A8B0AF]">
            RINGS: 2.0 NM / 4.0 NM • HDG: {{ navigation().heading }}° • COG: {{ navigation().cog }}°
          </div>
        </div>
      </div>

      <!-- Right Column: Autonomous Route Optimization & AIS Collision Table -->
      <div class="w-full md:w-88 flex flex-col gap-3">
        <!-- Autonomous Route Planner Card -->
        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2.5">
          <div class="flex items-center justify-between border-b border-white/10 pb-2">
            <div class="flex items-center gap-1.5 text-xs font-bold text-white">
              <mat-icon class="text-sm! w-4! h-4! text-[#C0923D]">alt_route</mat-icon>
              AUTONOMOUS ROUTE ENGINE
            </div>
            <span class="text-[10px] bg-[#46725F]/20 text-[#46725F] px-1.5 py-0.5 rounded font-bold">OPTIMAL</span>
          </div>

          <div class="space-y-1.5 text-xs text-[#A8B0AF]">
            <div class="flex justify-between">
              <span>DESTINATION:</span>
              <strong class="text-white">{{ navigation().destination }}</strong>
            </div>
            <div class="flex justify-between">
              <span>ROUTE DISTANCE:</span>
              <strong class="text-[#BFD2D5]">184.2 NM</strong>
            </div>
            <div class="flex justify-between">
              <span>ESTIMATED TRANSIT:</span>
              <strong class="text-white">19H 42M</strong>
            </div>
            <div class="flex justify-between">
              <span>ESTIMATED FUEL BURN:</span>
              <strong class="text-[#C0923D]">12.8% (6,840 L)</strong>
            </div>
            <div class="flex justify-between">
              <span>WEATHER PENALTY:</span>
              <span class="text-emerald-400 font-bold">MODERATE (+4.2%)</span>
            </div>
            <div class="flex justify-between">
              <span>TSS COMPLIANCE:</span>
              <span class="text-emerald-400 font-bold">VERIFIED (100%)</span>
            </div>
          </div>

          <div class="bg-[#142A35] p-2 rounded border border-white/10 text-[11px] text-[#A8B0AF]">
            <span class="text-[#C96532] font-bold">DECISION ENGINE PROPOSAL:</span>
            Maintain 287° course via Buchan sheltered channel to minimize wave pitching on cold hold inventory.
          </div>

          <button
            class="w-full py-1.5 bg-[#35677A] hover:bg-[#35677A]/80 text-white font-bold text-xs rounded transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <mat-icon class="text-sm! w-4! h-4!">navigation</mat-icon>
            AUTHORISE PROPOSED ROUTE (SIMULATED)
          </button>
        </div>

        <!-- AIS Target & Collision Risk Radar Table -->
        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex-1 flex flex-col gap-2">
          <div class="flex items-center justify-between border-b border-white/10 pb-1.5 text-xs font-bold text-white">
            <span class="flex items-center gap-1">
              <mat-icon class="text-sm! w-4! h-4! text-[#35677A]">radar</mat-icon>
              AIS CONTACTS & CPA RISK
            </span>
            <span class="text-[10px] text-[#A8B0AF]">{{ aisTargets().length }} TARGETS</span>
          </div>

          <div class="flex-1 overflow-y-auto space-y-1.5 text-xs">
            @for (target of aisTargets(); track target.mmsi) {
              <div class="p-2 bg-[#142A35] border border-white/5 rounded flex flex-col gap-1">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-white text-[11px]">{{ target.name }}</span>
                  <span
                    [class]="
                      target.riskLevel === 'CAUTION'
                        ? 'bg-[#C96532]/20 text-[#C96532] border-[#C96532]/40'
                        : 'bg-[#46725F]/20 text-[#46725F] border-[#46725F]/40'
                    "
                    class="text-[9px] px-1 py-0.5 rounded border font-bold"
                  >
                    {{ target.riskLevel }}
                  </span>
                </div>
                <div class="grid grid-cols-2 text-[10px] text-[#A8B0AF] gap-x-2">
                  <div>RNG: <strong class="text-white">{{ target.rangeNm }} NM</strong></div>
                  <div>BRG: <strong class="text-white">{{ target.bearingDeg }}°</strong></div>
                  <div>SOG: <strong class="text-white">{{ target.sog }} KT</strong></div>
                  <div>CPA: <strong class="text-[#BFD2D5]">{{ target.cpaNm }} NM ({{ target.tcpaMinutes }}m)</strong></div>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }
    `,
  ],
})
export class NavigationView {
  private state = inject(TrawlerStateService);

  readonly navigation = this.state.navigation;
  readonly weather = this.state.weather;
  readonly aisTargets = this.state.aisTargets;
}
