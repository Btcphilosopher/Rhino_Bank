import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TrawlerStateService } from '../../services/trawler-state.service';

@Component({
  selector: 'app-analytics-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-3 overflow-y-auto font-mono select-none">
      <!-- Top Financial Ribbon -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[#A8B0AF] text-[10px]">GROSS CATCH VALUE</span>
          <div class="text-xl font-bold text-emerald-400 mt-1">£{{ econ().grossCatchValueGbp.toLocaleString() }}</div>
          <span class="text-[10px] text-white">+£{{ econ().gradeAPremiumGbp.toLocaleString() }} GRADE A PREMIUM</span>
        </div>

        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[#A8B0AF] text-[10px]">TOTAL OPERATING COSTS</span>
          <div class="text-xl font-bold text-[#A6453D] mt-1">£{{ (econ().fuelCostGbp + econ().iceAndSuppliesGbp + econ().portLandingDuesGbp + econ().maintenanceReserveGbp).toLocaleString() }}</div>
          <span class="text-[10px] text-[#A8B0AF]">FUEL: £{{ econ().fuelCostGbp.toLocaleString() }}</span>
        </div>

        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[#A8B0AF] text-[10px]">CREW SHARE ALLOCATION</span>
          <div class="text-xl font-bold text-[#BFD2D5] mt-1">£{{ econ().crewShareAllocationGbp.toLocaleString() }}</div>
          <span class="text-[10px] text-[#A8B0AF]">12 CREW MEMBERS</span>
        </div>

        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[#A8B0AF] text-[10px]">NET TRIP PROFIT</span>
          <div class="text-xl font-bold text-[#C0923D] mt-1">£{{ econ().netTripProfitGbp.toLocaleString() }}</div>
          <span class="text-[10px] text-emerald-400">PROJECTED ROI: {{ econ().projectedRoiPercent }}%</span>
        </div>
      </div>

      <!-- Economic Breakdown & CPUE Analytics -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 min-h-[420px]">
        <!-- Financial Waterfall Table (7 cols) -->
        <div class="lg:col-span-7 bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2.5">
          <div class="flex items-center justify-between border-b border-white/10 pb-2 text-xs font-bold text-white">
            <span class="flex items-center gap-1.5">
              <mat-icon class="text-sm! w-4! h-4! text-[#C0923D]">analytics</mat-icon>
              TRIP 026 FINANCIAL STATEMENT (SIMULATION)
            </span>
            <span class="text-[10px] text-[#A8B0AF]">CURRENCY: GBP (£)</span>
          </div>

          <div class="space-y-2 text-xs">
            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span class="text-white">Gross Catch Auction Value:</span>
              <strong class="text-emerald-400 font-bold">+£{{ econ().grossCatchValueGbp.toLocaleString() }}</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span class="text-[#A8B0AF]">Marine Gas Oil Fuel Expense (MGO):</span>
              <strong class="text-[#A6453D]">-£{{ econ().fuelCostGbp.toLocaleString() }}</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span class="text-[#A8B0AF]">Fluid Ice, Salt & Vessel Supplies:</span>
              <strong class="text-[#A6453D]">-£{{ econ().iceAndSuppliesGbp.toLocaleString() }}</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span class="text-[#A8B0AF]">Peterhead Quay Landing Dues & Auction Levy:</span>
              <strong class="text-[#A6453D]">-£{{ econ().portLandingDuesGbp.toLocaleString() }}</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span class="text-[#A8B0AF]">Planned Maintenance & Overhaul Reserve:</span>
              <strong class="text-[#A6453D]">-£{{ econ().maintenanceReserveGbp.toLocaleString() }}</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span class="text-[#A8B0AF]">Contractual Crew Share (40% of Net Yield):</span>
              <strong class="text-[#BFD2D5]">-£{{ econ().crewShareAllocationGbp.toLocaleString() }}</strong>
            </div>

            <div class="flex justify-between items-center bg-[#35677A]/30 p-2.5 rounded border border-[#35677A]/40 mt-2">
              <span class="text-white font-bold">NET TRIP PROFIT TO VESSEL OWNER:</span>
              <strong class="text-emerald-400 font-extrabold text-sm">+£{{ econ().netTripProfitGbp.toLocaleString() }}</strong>
            </div>
          </div>
        </div>

        <!-- Right: CPUE Performance Indicators (5 cols) -->
        <div class="lg:col-span-5 bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2.5">
          <div class="flex items-center justify-between border-b border-white/10 pb-2 text-xs font-bold text-white">
            <span class="flex items-center gap-1.5 text-[#35677A]">
              <mat-icon class="text-sm! w-4! h-4!">speed</mat-icon>
              CATCH PER UNIT EFFORT (CPUE)
            </span>
            <span class="text-[10px] text-emerald-400 bg-emerald-400/20 px-1.5 py-0.5 rounded">HIGH EFFICIENCY</span>
          </div>

          <div class="space-y-2 text-xs text-[#A8B0AF]">
            <div class="bg-[#142A35] p-2 rounded flex justify-between">
              <span>CATCH PER TOW HOUR:</span>
              <strong class="text-white">540 KG / HOUR</strong>
            </div>
            <div class="bg-[#142A35] p-2 rounded flex justify-between">
              <span>GROSS REVENUE PER TOW HOUR:</span>
              <strong class="text-emerald-400">£2,289 / HOUR</strong>
            </div>
            <div class="bg-[#142A35] p-2 rounded flex justify-between">
              <span>REVENUE PER LITRE FUEL:</span>
              <strong class="text-[#C0923D]">£3.75 / LITRE</strong>
            </div>
            <div class="bg-[#142A35] p-2 rounded flex justify-between">
              <span>ROBOTIC SORTING SAVINGS:</span>
              <strong class="text-[#BFD2D5]">£1,420 (GRADE A PRESERVATION)</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }
    `,
  ],
})
export class AnalyticsView {
  private state = inject(TrawlerStateService);

  readonly econ = this.state.economics;
}
