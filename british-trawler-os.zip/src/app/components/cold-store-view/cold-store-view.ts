import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TrawlerStateService } from '../../services/trawler-state.service';

@Component({
  selector: 'app-cold-store-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-3 overflow-y-auto font-mono select-none">
      <!-- Top Cold Chain Overview -->
      <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div class="flex items-center gap-2">
          <mat-icon class="text-sm! w-4! h-4! text-[#BFD2D5]">ac_unit</mat-icon>
          <span class="font-bold text-white tracking-wider">NATURAL REFRIGERANT CASCADE (NH3 / CO2 DUAL-CIRCUIT)</span>
        </div>
        <div class="flex items-center gap-4 text-[11px] text-[#A8B0AF]">
          <div>TOTAL HOLD OCCUPANCY: <strong class="text-white">{{ totalFillPercent() }}%</strong></div>
          <div>THERMAL COP: <strong class="text-emerald-400 font-bold">4.12</strong></div>
          <div>HEAT RECOVERY: <strong class="text-[#C0923D]">142 kW (DECK DE-ICING)</strong></div>
        </div>
      </div>

      <!-- Cold Store Zones Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        @for (zone of zones(); track zone.id) {
          <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2.5">
            <div class="flex items-center justify-between border-b border-white/10 pb-2">
              <span class="font-bold text-white text-xs">{{ zone.name }}</span>
              <span
                [class]="
                  zone.alarmStatus === 'NORMAL'
                    ? 'bg-[#46725F]/20 text-[#46725F] border-[#46725F]/30'
                    : 'bg-[#C96532]/20 text-[#C96532] border-[#C96532]/30'
                "
                class="text-[9px] px-1.5 py-0.5 rounded border font-bold"
              >
                {{ zone.alarmStatus }}
              </span>
            </div>

            <!-- Temperature Meter Card -->
            <div class="bg-[#142A35] p-3 rounded flex items-center justify-between border border-white/5">
              <div>
                <span class="text-[10px] text-[#A8B0AF]">CURRENT CORE TEMP</span>
                <div class="text-2xl font-black text-[#BFD2D5] mt-0.5">{{ zone.currentTempC }}°C</div>
              </div>
              <div class="text-right">
                <span class="text-[10px] text-[#A8B0AF]">TARGET SETPOINT</span>
                <div class="text-sm font-bold text-white mt-0.5">{{ zone.targetTempC }}°C</div>
              </div>
            </div>

            <!-- Capacity & Fill -->
            <div class="space-y-1.5 text-xs text-[#A8B0AF]">
              <div class="flex justify-between">
                <span>INVENTORY WEIGHT:</span>
                <strong class="text-white">{{ (zone.currentWeightKg / 1000).toFixed(1) }} T / {{ (zone.capacityKg / 1000).toFixed(0) }} T</strong>
              </div>

              <div class="w-full bg-white/10 rounded-full h-2 overflow-hidden">
                <div
                  class="h-full bg-[#35677A] transition-all"
                  [style.width.%]="zone.utilizationPercent"
                ></div>
              </div>

              <div class="flex justify-between text-[11px] pt-1">
                <span>DOOR STATUS: <strong class="text-white">{{ zone.doorState }}</strong></span>
                <span>CIRCUIT: <strong class="text-[#BFD2D5]">{{ zone.refrigerantCircuit }}</strong></span>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }
    `,
  ],
})
export class ColdStoreView {
  private state = inject(TrawlerStateService);

  readonly zones = this.state.coldStoreZones;
  readonly totalFillPercent = this.state.coldStoreFillPercent;
}
