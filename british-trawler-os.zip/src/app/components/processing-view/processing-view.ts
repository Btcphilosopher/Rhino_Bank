import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TrawlerStateService } from '../../services/trawler-state.service';

@Component({
  selector: 'app-processing-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-3 overflow-y-auto font-mono select-none">
      <!-- Top Overview Banner -->
      <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div class="flex items-center gap-2">
          <mat-icon class="text-sm! w-4! h-4! text-[#C96532]">precision_manufacturing</mat-icon>
          <span class="font-bold text-white tracking-wider">ROBOTIC FISH PROCESSING & COMPUTER VISION CELL</span>
          <span class="text-[10px] bg-[#35677A]/30 text-[#BFD2D5] px-2 py-0.5 rounded border border-[#35677A]/40">
            CELL DR-04 (6-AXIS)
          </span>
        </div>

        <div class="flex items-center gap-4 text-[11px] text-[#A8B0AF]">
          <div>THROUGHPUT: <strong class="text-white">{{ robot().throughputKgH }} KG/H</strong></div>
          <div>CYCLE TIME: <strong class="text-emerald-400 font-bold">{{ robot().cycleTimeSec }}S / PICK</strong></div>
          <div>ARM STATUS: <strong [class.text-emerald-400]="robot().status === 'SORTING'" [class.text-red-400]="robot().status === 'FAULT'">{{ robot().status }}</strong></div>
          <div>COLLISION CHECK: <strong class="text-[#BFD2D5]">{{ robot().collisionStatus }}</strong></div>
        </div>
      </div>

      <!-- Main Layout: Left Camera Vision Feed + Right 6-Axis Kinematics & Review Queue -->
      <div class="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-3 min-h-[460px]">
        <!-- Left: VISION-07 Live Optical Camera Simulation (7 cols) -->
        <div class="lg:col-span-7 bg-[#171B1D] border border-white/10 rounded-xl flex flex-col overflow-hidden">
          <div class="bg-[#142A35] px-3 py-2 border-b border-white/10 flex items-center justify-between text-xs">
            <div class="flex items-center gap-2">
              <span class="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
              <span class="font-bold text-white">VISION-07 MULTISPECTRAL CAMERA (CONVEYOR #1)</span>
            </div>
            <div class="text-[11px] text-[#A8B0AF]">
              45 FPS • 1080p • YOLOv10-MARINE
            </div>
          </div>

          <!-- Camera Screen Simulated View with Conveyor & Bounding Boxes -->
          <div class="relative flex-1 bg-[#0D171C] p-3 overflow-hidden flex flex-col justify-between">
            <!-- Simulated Stainless Steel Conveyor Belt Graphic -->
            <div class="w-full h-full relative border border-white/15 rounded-lg bg-[#192226] p-4 flex flex-col justify-center overflow-hidden">
              <!-- Conveyor Movement Lines -->
              <div class="absolute inset-0 opacity-10 bg-[radial-gradient(#E9ECE8_1px,transparent_1px)] [background-size:16px_16px]"></div>

              <!-- Optical Fish Detection Bounding Boxes Overlay -->
              <div class="relative w-full h-64 border border-dashed border-[#697276]/50 rounded p-2 flex items-center justify-around gap-2">
                @for (det of detections(); track det.detectionId) {
                  <div
                    [class]="
                      det.requiresHumanReview
                        ? 'border-[#C96532] bg-[#C96532]/15 shadow-lg shadow-[#C96532]/20'
                        : 'border-[#46725F] bg-[#46725F]/15'
                    "
                    class="relative border-2 rounded p-2 flex flex-col justify-between h-48 w-36 transition-all"
                  >
                    <!-- Bounding Box Header Label -->
                    <div class="text-[10px] font-bold flex justify-between items-center text-white pb-1 border-b border-white/20">
                      <span class="truncate">{{ det.species }}</span>
                      <span [class.text-[#C96532]]="det.requiresHumanReview" class="text-emerald-400">
                        {{ (det.confidence * 100).toFixed(0) }}%
                      </span>
                    </div>

                    <!-- Fish Body Silhouette Simulation -->
                    <div class="flex-1 flex items-center justify-center text-center my-1">
                      <div class="text-[11px] text-[#BFD2D5] bg-[#171B1D]/80 px-2 py-1 rounded">
                        <div>{{ det.estimatedLengthCm }} cm</div>
                        <div class="text-[10px] text-[#A8B0AF]">{{ det.estimatedMassKg }} kg</div>
                      </div>
                    </div>

                    <!-- Quality Grade Tag -->
                    <div class="flex items-center justify-between text-[9px] pt-1 border-t border-white/10">
                      <span class="text-[#A8B0AF]">GRADE: <strong class="text-white">{{ det.grade }}</strong></span>
                      <span class="text-[8px] bg-white/10 px-1 py-0.5 rounded text-white">{{ det.detectionId }}</span>
                    </div>

                    <!-- Review Flag -->
                    @if (det.requiresHumanReview) {
                      <div class="absolute -top-2.5 -right-2 bg-[#C96532] text-white text-[8px] font-bold px-1.5 py-0.5 rounded-full uppercase shadow">
                        REVIEW
                      </div>
                    }
                  </div>
                }
              </div>

              <!-- Conveyor Speed Marker -->
              <div class="mt-2 flex justify-between text-[11px] text-[#A8B0AF] border-t border-white/10 pt-1.5">
                <span>CONVEYOR SPEED: <strong class="text-white">0.85 M/S</strong></span>
                <span>DESTINATION: <strong class="text-[#BFD2D5]">AUTOMATED CHUTE HOPPER 1-4</strong></span>
              </div>
            </div>
          </div>
        </div>

        <!-- Right: 6-Axis Kinematics & Ambiguous Sample Review Queue (5 cols) -->
        <div class="lg:col-span-5 flex flex-col gap-3">
          <!-- Robot Kinematics Card -->
          <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2">
            <div class="flex items-center justify-between border-b border-white/10 pb-2 text-xs font-bold text-white">
              <span class="flex items-center gap-1.5">
                <mat-icon class="text-sm! w-4! h-4! text-[#35677A]">smart_toy</mat-icon>
                6-AXIS KINEMATICS // DR-04
              </span>
              <span class="text-[10px] text-emerald-400 bg-emerald-400/20 px-1.5 py-0.5 rounded">CALIBRATED</span>
            </div>

            <!-- 6 Joint Angles Telemetry -->
            <div class="grid grid-cols-3 gap-2 text-xs">
              @for (angle of robot().jointAngles; track $index) {
                <div class="bg-[#142A35] p-2 rounded border border-white/5 flex flex-col">
                  <span class="text-[10px] text-[#A8B0AF]">AXIS {{ $index + 1 }}:</span>
                  <span class="text-white font-bold text-sm">{{ angle }}°</span>
                </div>
              }
            </div>

            <div class="text-[11px] text-[#A8B0AF] bg-[#142A35] p-2 rounded border border-white/5">
              CURRENT TASK: <span class="text-[#BFD2D5] font-semibold">{{ robot().currentTask }}</span>
            </div>

            @if (robot().errorDescription) {
              <div class="bg-[#A6453D]/20 border border-[#A6453D]/40 p-2 rounded text-[11px] text-red-300">
                <strong>FAULT NOTICE:</strong> {{ robot().errorDescription }}
              </div>
            }
          </div>

          <!-- Human Review Queue for Ambiguous Detections (MANDATORY REQUIREMENT) -->
          <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex-1 flex flex-col gap-2">
            <div class="flex items-center justify-between border-b border-white/10 pb-1.5 text-xs font-bold text-white">
              <span class="flex items-center gap-1 text-[#C0923D]">
                <mat-icon class="text-sm! w-4! h-4!">gavel</mat-icon>
                HUMAN REVIEW QUEUE (AMBIGUOUS DETECTIONS)
              </span>
              <span class="text-[10px] bg-[#C0923D]/20 text-[#C0923D] px-1.5 py-0.5 rounded">1 PENDING</span>
            </div>

            <div class="p-2.5 bg-[#142A35] border border-white/10 rounded flex flex-col gap-2 text-xs">
              <div class="flex justify-between items-center">
                <strong class="text-white">DET-9809 (Confidence: 61%)</strong>
                <span class="text-[10px] text-[#C96532] font-bold">MLS BOUNDARY</span>
              </div>
              <p class="text-[11px] text-[#A8B0AF]">
                Optical estimate 28cm juvenile Whiting / Haddock. Confirm retention vs discard under UK landing obligation rules.
              </p>

              <div class="flex items-center gap-2 pt-1">
                <button
                  class="flex-1 py-1.5 bg-[#46725F] hover:bg-[#46725F]/80 text-white font-bold text-xs rounded transition-colors cursor-pointer text-center"
                >
                  CONFIRM RETENTION (GRADE B)
                </button>
                <button
                  class="flex-1 py-1.5 bg-[#A6453D] hover:bg-[#A6453D]/80 text-white font-bold text-xs rounded transition-colors cursor-pointer text-center"
                >
                  ROUTE TO DISCARD HOPPER
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }
    `,
  ],
})
export class ProcessingView {
  private state = inject(TrawlerStateService);

  readonly robot = this.state.robotArm;
  readonly detections = this.state.visionDetections;
}
