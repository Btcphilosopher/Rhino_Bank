import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TrawlerStateService } from '../../services/trawler-state.service';

@Component({
  selector: 'app-scenarios-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-3 overflow-y-auto font-mono select-none">
      <!-- Top Scenario Lab Header -->
      <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div class="flex items-center gap-2">
          <mat-icon class="text-sm! w-4! h-4! text-[#C96532]">science</mat-icon>
          <span class="font-bold text-white tracking-wider">AUTONOMOUS FISHING SCENARIO LAB & FORENSIC EVENT REPLAY</span>
        </div>
        <div class="flex items-center gap-3">
          <button
            (click)="runSignatureDemo()"
            [disabled]="signatureActive()"
            class="px-3 py-1.5 bg-[#C96532] hover:bg-[#C96532]/80 text-white font-bold rounded text-xs transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <mat-icon class="text-sm! w-4! h-4!">play_circle</mat-icon>
            RUN SIGNATURE NORTH SEA MISSION
          </button>
        </div>
      </div>

      <!-- Active Signature Demo Progression Banner if running -->
      @if (signatureActive()) {
        <div class="bg-[#C96532]/20 border border-[#C96532]/40 rounded-xl p-3 flex items-center justify-between text-xs animate-pulse">
          <div class="flex items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-full bg-[#C96532]"></span>
            <span class="font-bold text-white">ACTIVE MISSION STAGE {{ signatureStep() }}/6:</span>
            <span class="text-[#BFD2D5] font-semibold uppercase">{{ signatureTitle() }}</span>
          </div>
          <span class="text-[10px] text-[#A8B0AF]">SIMULATING AUTOMATED TRAWLING CYCLE...</span>
        </div>
      }

      <!-- Scenarios Grid + Forensic Event Replay -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 min-h-[420px]">
        <!-- Left: Pre-configured Simulation Scenarios (6 cols) -->
        <div class="lg:col-span-6 bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2.5">
          <div class="flex items-center justify-between border-b border-white/10 pb-2 text-xs font-bold text-white">
            <span class="flex items-center gap-1.5">
              <mat-icon class="text-sm! w-4! h-4! text-[#35677A]">tune</mat-icon>
              SCENARIO EXPERIMENTS
            </span>
            <span class="text-[10px] text-[#A8B0AF]">INDUSTRY 4.0 LAB</span>
          </div>

          <div class="space-y-2 text-xs">
            <div class="bg-[#142A35] p-3 rounded border border-white/5 flex justify-between items-center">
              <div>
                <strong class="text-white">SCENARIO A: ROUGH WEATHER & GALE FORCE 7</strong>
                <p class="text-[11px] text-[#A8B0AF] mt-0.5">Tests autonomous course evasion, warp tension surge damping, and deck safety lockout.</p>
              </div>
              <button
                (click)="simulateRoughWeather()"
                class="px-2.5 py-1 bg-[#35677A] hover:bg-[#35677A]/80 text-white rounded font-bold text-[11px] transition-colors cursor-pointer"
              >
                APPLY
              </button>
            </div>

            <div class="bg-[#142A35] p-3 rounded border border-white/5 flex justify-between items-center">
              <div>
                <strong class="text-white">SCENARIO B: ROBOT DR-04 JOINT OVERLOAD</strong>
                <p class="text-[11px] text-[#A8B0AF] mt-0.5">Demonstrates bottleneck detection, conveyor modulation, and manual bypass fallback.</p>
              </div>
              <button
                (click)="simulateRobotFault()"
                class="px-2.5 py-1 bg-[#A6453D] hover:bg-[#A6453D]/80 text-white rounded font-bold text-[11px] transition-colors cursor-pointer"
              >
                APPLY
              </button>
            </div>

            <div class="bg-[#142A35] p-3 rounded border border-white/5 flex justify-between items-center">
              <div>
                <strong class="text-white">SCENARIO C: HIGH BIOMASS / ACCELERATED HAUL</strong>
                <p class="text-[11px] text-[#A8B0AF] mt-0.5">Triggers Simrad S3 acoustic alarm and generates automated decision proposal for haul.</p>
              </div>
              <button
                (click)="simulateHighBiomass()"
                class="px-2.5 py-1 bg-[#46725F] hover:bg-[#46725F]/80 text-white rounded font-bold text-[11px] transition-colors cursor-pointer"
              >
                APPLY
              </button>
            </div>

            <div class="bg-[#142A35] p-3 rounded border border-white/5 flex justify-between items-center">
              <div>
                <strong class="text-white">SCENARIO D: FUEL PRICE SHOCK (+35%)</strong>
                <p class="text-[11px] text-[#A8B0AF] mt-0.5">Recalculates economical tow speed (reduced to 3.1 kt) and battery ESS peak-shaving envelope.</p>
              </div>
              <button
                (click)="simulateFuelShock()"
                class="px-2.5 py-1 bg-[#C0923D] hover:bg-[#C0923D]/80 text-white rounded font-bold text-[11px] transition-colors cursor-pointer"
              >
                APPLY
              </button>
            </div>
          </div>
        </div>

        <!-- Right: Forensic Event Stream Log & Replay (6 cols) -->
        <div class="lg:col-span-6 bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2">
          <div class="flex items-center justify-between border-b border-white/10 pb-1.5 text-xs font-bold text-white">
            <span class="flex items-center gap-1.5 text-[#BFD2D5]">
              <mat-icon class="text-sm! w-4! h-4!">history</mat-icon>
              FORENSIC TRIP EVENT STREAM
            </span>
            <span class="text-[10px] text-[#A8B0AF]">{{ events().length }} EVENTS</span>
          </div>

          <div class="flex-1 overflow-y-auto space-y-2 text-xs">
            @for (event of events(); track event.id) {
              <div class="p-2.5 bg-[#142A35] border border-white/5 rounded flex flex-col gap-1">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-1.5">
                    <span
                      [class]="
                        event.severity === 'CRITICAL'
                          ? 'bg-[#A6453D] text-white'
                          : event.severity === 'SUCCESS'
                          ? 'bg-[#46725F] text-white'
                          : 'bg-[#35677A] text-white'
                      "
                      class="text-[9px] px-1.5 py-0.5 rounded font-bold"
                    >
                      {{ event.category }}
                    </span>
                    <strong class="text-white text-[11px]">{{ event.summary }}</strong>
                  </div>
                  <span class="text-[10px] text-[#A8B0AF]">{{ event.timestamp }}</span>
                </div>
                <p class="text-[11px] text-[#A8B0AF]">{{ event.details }}</p>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }
    `,
  ],
})
export class ScenariosView {
  private state = inject(TrawlerStateService);

  readonly events = this.state.eventStream;
  readonly signatureActive = this.state.signatureDemoActive;
  readonly signatureStep = this.state.signatureDemoStep;
  readonly signatureTitle = this.state.signatureDemoTitle;

  runSignatureDemo() {
    this.state.runSignatureDemo();
  }

  simulateRoughWeather() {
    this.state.weather.update((w) => ({
      ...w,
      windKnots: 34.0,
      waveHeightM: 4.5,
      seaState: 6,
      forecastTrend: 'GALE_WARNING',
    }));
    this.state.addEvent({
      category: 'NAVIGATION',
      summary: 'Scenario Injected: Rough Weather (Gale Force 7)',
      details: 'Wind increased to 34 kt, wave height 4.5m. Autonomy engine proposes course alteration.',
      severity: 'WARNING',
    });
  }

  simulateRobotFault() {
    this.state.triggerRobotFailureScenario();
  }

  simulateHighBiomass() {
    this.state.trawlPhysics.update((t) => ({
      ...t,
      codendFillPercent: 92,
      sensorCodendS4: true,
      acousticBiomassEstimateKg: 3600,
    }));
    this.state.addEvent({
      category: 'FISHING',
      summary: 'Acoustic Hit: Codend Sensors S1-S4 Active',
      details: 'Acoustic volume indicates 3.6 tonnes demersal catch. Recommendation: Commence Haul.',
      severity: 'SUCCESS',
    });
  }

  simulateFuelShock() {
    this.state.economics.update((e) => ({
      ...e,
      fuelCostGbp: Math.round(e.fuelCostGbp * 1.35),
      netTripProfitGbp: Math.round(e.netTripProfitGbp - e.fuelCostGbp * 0.35),
    }));
    this.state.addEvent({
      category: 'DECISION',
      summary: 'Scenario Injected: Fuel Price Shock (+35%)',
      details: 'MGO bunker rates updated to £1.12/L. Autonomous power manager derates transit speed to 8.8 kt.',
      severity: 'WARNING',
    });
  }
}
