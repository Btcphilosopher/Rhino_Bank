import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  effect,
  inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { TrawlerStateService } from '../../services/trawler-state.service';
import { CameraViewMode } from '../../models/trawler.models';

@Component({
  selector: 'app-vessel-twin-3d',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full bg-[#142A35] overflow-hidden flex flex-col select-none border border-white/10 rounded-xl">
      <!-- 3D Canvas Container -->
      <div #canvasContainer class="w-full h-full relative cursor-grab active:cursor-grabbing"></div>

      <!-- Top Overlay: Camera Mode Selector & Telemetry Ribbon -->
      <div class="absolute top-3 left-3 right-3 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        <!-- View Mode Buttons -->
        <div class="flex items-center gap-1 bg-[#171B1D]/90 backdrop-blur-md border border-white/15 p-1 rounded-lg pointer-events-auto shadow-lg">
          <span class="text-[10px] font-mono font-bold text-[#697276] uppercase px-2 tracking-wider">TWIN VIEW:</span>
          @for (mode of viewModes; track mode.id) {
            <button
              (click)="selectViewMode(mode.id)"
              [class]="
                cameraMode() === mode.id
                  ? 'bg-[#35677A] text-[#E9ECE8] font-bold border-[#BFD2D5]/40 shadow-sm'
                  : 'bg-transparent text-[#A8B0AF] hover:bg-white/5 hover:text-[#E9ECE8] border-transparent'
              "
              class="px-2.5 py-1 text-xs rounded border transition-all flex items-center gap-1 font-mono cursor-pointer"
            >
              <mat-icon class="text-sm! w-4! h-4! leading-none">{{ mode.icon }}</mat-icon>
              {{ mode.label }}
            </button>
          }
        </div>

        <!-- Live Vessel Telemetry Badge -->
        <div class="flex items-center gap-3 bg-[#171B1D]/90 backdrop-blur-md border border-white/15 px-3 py-1.5 rounded-lg pointer-events-auto font-mono text-xs shadow-lg">
          <div class="flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span class="text-[#A8B0AF]">SOG:</span>
            <span class="text-white font-bold">{{ navigation().sog }} KT</span>
          </div>
          <div class="h-3 w-px bg-white/20"></div>
          <div class="flex items-center gap-1">
            <span class="text-[#A8B0AF]">HDG:</span>
            <span class="text-[#BFD2D5] font-bold">{{ navigation().heading }}°</span>
          </div>
          <div class="h-3 w-px bg-white/20"></div>
          <div class="flex items-center gap-1">
            <span class="text-[#A8B0AF]">DEPTH:</span>
            <span class="text-[#C0923D] font-bold">{{ navigation().depthM }} M</span>
          </div>
          <div class="h-3 w-px bg-white/20"></div>
          <div class="flex items-center gap-1">
            <span class="text-[#A8B0AF]">TRAWL:</span>
            <span class="text-[#C96532] font-bold">{{ trawl().stage }} ({{ trawl().codendFillPercent }}%)</span>
          </div>
        </div>
      </div>

      <!-- Bottom Overlay: Controls & Cross-section Info -->
      <div class="absolute bottom-3 left-3 right-3 flex items-end justify-between pointer-events-none">
        <!-- Technical Spec Overlay Card -->
        <div class="bg-[#171B1D]/90 backdrop-blur-md border border-white/15 p-2.5 rounded-lg pointer-events-auto font-mono text-[11px] shadow-lg max-w-sm">
          <div class="flex items-center justify-between pb-1 border-b border-white/10 mb-1.5">
            <span class="text-white font-bold uppercase tracking-wider flex items-center gap-1">
              <mat-icon class="text-xs! w-3.5! h-3.5! text-[#35677A]">directions_boat</mat-icon>
              FV NORTH STAR (PD 412)
            </span>
            <span class="text-[#46725F] bg-[#46725F]/20 px-1.5 py-0.5 rounded text-[10px]">DIGITAL TWIN 3D</span>
          </div>
          <div class="grid grid-cols-2 gap-x-3 gap-y-1 text-[#A8B0AF]">
            <div>LOA / BEAM: <span class="text-white">64.8m / 14.2m</span></div>
            <div>DRAUGHT: <span class="text-white">6.8m</span></div>
            <div>PROPULSION: <span class="text-white">Bergen 3,200 kW</span></div>
            <div>HOLD TEMP: <span class="text-[#BFD2D5]">-24.8°C</span></div>
            <div>AUTONOMY: <span class="text-[#C96532]">{{ autonomyLevel() }}</span></div>
            <div>SEABED: <span class="text-[#C0923D]">{{ navigation().seabedType }}</span></div>
          </div>
        </div>

        <!-- Camera Helper Buttons -->
        <div class="flex items-center gap-1.5 bg-[#171B1D]/90 backdrop-blur-md border border-white/15 p-1 rounded-lg pointer-events-auto">
          <button
            (click)="resetCamera()"
            title="Reset Camera Orientation"
            class="px-2 py-1 text-xs text-[#A8B0AF] hover:text-white hover:bg-white/10 rounded font-mono flex items-center gap-1 transition-colors cursor-pointer"
          >
            <mat-icon class="text-sm! w-4! h-4!">videocam</mat-icon>
            RESET ORBIT
          </button>
          <div class="h-3 w-px bg-white/20"></div>
          <button
            (click)="toggleWireframe()"
            [class.text-[#BFD2D5]]="wireframeMode"
            title="Toggle Structural Wireframe CAD View"
            class="px-2 py-1 text-xs text-[#A8B0AF] hover:text-white hover:bg-white/10 rounded font-mono flex items-center gap-1 transition-colors cursor-pointer"
          >
            <mat-icon class="text-sm! w-4! h-4!">grid_view</mat-icon>
            CAD FRAME
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        width: 100%;
        height: 100%;
      }
    `,
  ],
})
export class VesselTwin3d implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainer!: ElementRef<HTMLDivElement>;

  private state = inject(TrawlerStateService);

  readonly cameraMode = this.state.cameraViewMode;
  readonly navigation = this.state.navigation;
  readonly weather = this.state.weather;
  readonly trawl = this.state.trawlPhysics;
  readonly autonomyLevel = this.state.autonomyLevel;

  wireframeMode = false;

  readonly viewModes: { id: CameraViewMode; label: string; icon: string }[] = [
    { id: 'EXTERIOR', label: 'EXTERIOR', icon: 'directions_boat' },
    { id: 'DECK', label: 'TRAWL DECK', icon: 'anchor' },
    { id: 'BRIDGE', label: 'WHEELHOUSE', icon: 'desktop_windows' },
    { id: 'ENGINE_ROOM', label: 'ENGINE ROOM', icon: 'bolt' },
    { id: 'FISH_PROCESSING', label: 'PROCESSING & ROBOT', icon: 'precision_manufacturing' },
    { id: 'COLD_STORE', label: 'COLD STORE HOLD', icon: 'ac_unit' },
    { id: 'SUBSEA_TRAWL', label: 'SUBSEA TRAWL NET', icon: 'water' },
  ];

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId = 0;

  // 3D Objects
  private vesselGroup!: THREE.Group;
  private hullMesh!: THREE.Mesh;
  private oceanMesh!: THREE.Mesh;
  private subseaNetGroup!: THREE.Group;
  private trawlLinesGroup!: THREE.Group;
  private seabedMesh!: THREE.Mesh;
  private robotArmGroup!: THREE.Group;
  private fishSchoolGroup!: THREE.Group;
  private internalCutawayGroup!: THREE.Group;

  // Orbit controls state
  private isMouseDown = false;
  private previousMousePosition = { x: 0, y: 0 };
  private targetRotation = { x: 0.3, y: -0.7 };
  private targetZoom = 45;
  private currentZoom = 45;
  private targetPan = new THREE.Vector3(0, 0, 0);

  constructor() {
    // Effect to adjust camera preset when view mode changes
    effect(() => {
      const mode = this.cameraMode();
      this.applyCameraPreset(mode);
    });
  }

  ngOnInit() {
    this.initThree();
    this.createSceneObjects();
    this.applyCameraPreset(this.cameraMode());
    this.animate();
    this.setupEventListeners();
  }

  ngOnDestroy() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  selectViewMode(mode: CameraViewMode) {
    this.state.setCameraView(mode);
  }

  resetCamera() {
    this.applyCameraPreset(this.cameraMode());
  }

  toggleWireframe() {
    this.wireframeMode = !this.wireframeMode;
    this.scene.traverse((obj) => {
      if (obj instanceof THREE.Mesh && obj.material) {
        if (Array.isArray(obj.material)) {
          obj.material.forEach((m) => (m.wireframe = this.wireframeMode));
        } else {
          obj.material.wireframe = this.wireframeMode;
        }
      }
    });
  }

  private initThree() {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    // Scene with dark North Sea maritime fog
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x142a35);
    this.scene.fog = new THREE.FogExp2(0x142a35, 0.008);

    // Camera
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.set(30, 20, 40);

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x8fa8b3, 1.2);
    this.scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xe9ece8, 2.0);
    sunLight.position.set(40, 60, 30);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    this.scene.add(sunLight);

    const subseaLight = new THREE.DirectionalLight(0x35677a, 1.0);
    subseaLight.position.set(-20, -30, -20);
    this.scene.add(subseaLight);
  }

  private createSceneObjects() {
    // 1. Ocean Surface
    const oceanGeo = new THREE.PlaneGeometry(300, 300, 48, 48);
    const oceanMat = new THREE.MeshStandardMaterial({
      color: 0x193d4c,
      roughness: 0.2,
      metalness: 0.8,
      transparent: true,
      opacity: 0.85,
    });
    this.oceanMesh = new THREE.Mesh(oceanGeo, oceanMat);
    this.oceanMesh.rotation.x = -Math.PI / 2;
    this.oceanMesh.position.y = 0;
    this.scene.add(this.oceanMesh);

    // 2. Seabed Bathymetry (Depth -35m representation)
    const seabedGeo = new THREE.PlaneGeometry(300, 300, 32, 32);
    // Add subtle seabed sand ripples
    const pos = seabedGeo.attributes['position'];
    for (let i = 0; i < pos.count; i++) {
      const z = pos.getZ(i);
      pos.setZ(i, z + Math.sin(i * 0.4) * 0.8);
    }
    seabedGeo.computeVertexNormals();

    const seabedMat = new THREE.MeshStandardMaterial({
      color: 0x2b3032,
      roughness: 0.9,
      metalness: 0.1,
    });
    this.seabedMesh = new THREE.Mesh(seabedGeo, seabedMat);
    this.seabedMesh.rotation.x = -Math.PI / 2;
    this.seabedMesh.position.y = -35;
    this.scene.add(this.seabedMesh);

    // 3. FV NORTH STAR 3D Model Group
    this.vesselGroup = new THREE.Group();
    this.buildVesselModel();
    this.scene.add(this.vesselGroup);

    // 4. Subsea Trawl Gear (Warps, Morgère Doors, Net, Codend)
    this.subseaNetGroup = new THREE.Group();
    this.buildSubseaTrawlNet();
    this.scene.add(this.subseaNetGroup);

    // 5. Internal Cutaway Machinery & Robotic Cell
    this.internalCutawayGroup = new THREE.Group();
    this.buildInternalCutaways();
    this.scene.add(this.internalCutawayGroup);

    // 6. Subsea Fish School Echo markers
    this.fishSchoolGroup = new THREE.Group();
    this.buildFishSchool();
    this.scene.add(this.fishSchoolGroup);
  }

  private buildVesselModel() {
    // Steel Hull
    const hullShape = new THREE.Shape();
    hullShape.moveTo(-16, -1.8);
    hullShape.lineTo(14, -1.8);
    hullShape.quadraticCurveTo(20, -1.0, 22, 1.8);
    hullShape.lineTo(22, 3.2);
    hullShape.lineTo(-16, 3.2);
    hullShape.lineTo(-16, -1.8);

    const extrudeSettings = {
      steps: 2,
      depth: 6.4,
      bevelEnabled: true,
      bevelThickness: 0.8,
      bevelSize: 0.6,
      bevelSegments: 4,
    };

    const hullGeo = new THREE.ExtrudeGeometry(hullShape, extrudeSettings);
    hullGeo.center();

    const hullMat = new THREE.MeshStandardMaterial({
      color: 0x171b1d, // Steel black
      roughness: 0.4,
      metalness: 0.6,
    });
    this.hullMesh = new THREE.Mesh(hullGeo, hullMat);
    this.hullMesh.position.set(0, 1.2, 0);
    this.hullMesh.castShadow = true;
    this.hullMesh.receiveShadow = true;
    this.vesselGroup.add(this.hullMesh);

    // Signal Orange Stripe
    const stripeGeo = new THREE.BoxGeometry(36, 0.4, 6.7);
    const stripeMat = new THREE.MeshStandardMaterial({
      color: 0xc96532, // Signal Orange
      roughness: 0.3,
    });
    const stripe = new THREE.Mesh(stripeGeo, stripeMat);
    stripe.position.set(1.5, 0.5, 0);
    this.vesselGroup.add(stripe);

    // Superstructure & Bridge (Forward-midship modern raked design)
    const bridgeGeo = new THREE.BoxGeometry(10, 4.5, 5.8);
    const bridgeMat = new THREE.MeshStandardMaterial({
      color: 0x2b3032, // Graphite
      roughness: 0.3,
    });
    const bridge = new THREE.Mesh(bridgeGeo, bridgeMat);
    bridge.position.set(6, 4.8, 0);
    this.vesselGroup.add(bridge);

    // Wheelhouse Glass (Wrap-around tinted maritime glass)
    const glassGeo = new THREE.BoxGeometry(6.5, 1.4, 6.0);
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x35677a, // Navigation Blue
      metalness: 0.9,
      roughness: 0.1,
      transparent: true,
      opacity: 0.8,
    });
    const glass = new THREE.Mesh(glassGeo, glassMat);
    glass.position.set(7.5, 5.8, 0);
    this.vesselGroup.add(glass);

    // Stern Trawl Gantry & A-Frame (High structural steel gantry)
    const gantryLegMat = new THREE.MeshStandardMaterial({ color: 0x697276, metalness: 0.8 });
    const leg1 = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 7), gantryLegMat);
    leg1.position.set(-14, 5.5, 2.8);
    leg1.rotation.z = 0.15;
    this.vesselGroup.add(leg1);

    const leg2 = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 7), gantryLegMat);
    leg2.position.set(-14, 5.5, -2.8);
    leg2.rotation.z = 0.15;
    this.vesselGroup.add(leg2);

    const crossBeam = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.6, 6.0), gantryLegMat);
    crossBeam.position.set(-14.5, 8.8, 0);
    this.vesselGroup.add(crossBeam);

    // Trawl Warp Winches on Deck (Port & Starboard drums)
    const winchMat = new THREE.MeshStandardMaterial({ color: 0xc0923d, metalness: 0.7 });
    const winchPort = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 1.4, 16), winchMat);
    winchPort.rotation.x = Math.PI / 2;
    winchPort.position.set(-4, 3.2, 2.2);
    this.vesselGroup.add(winchPort);

    const winchStbd = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 1.4, 16), winchMat);
    winchStbd.rotation.x = Math.PI / 2;
    winchStbd.position.set(-4, 3.2, -2.2);
    this.vesselGroup.add(winchStbd);

    // Net Drum at Stern
    const netDrumMat = new THREE.MeshStandardMaterial({ color: 0x193d4c, metalness: 0.5 });
    const netDrum = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.4, 4.8, 16), netDrumMat);
    netDrum.rotation.x = Math.PI / 2;
    netDrum.position.set(-11, 3.4, 0);
    this.vesselGroup.add(netDrum);

    // Radar Mast & Communication Domes
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.2, 4), gantryLegMat);
    mast.position.set(6, 8.5, 0);
    this.vesselGroup.add(mast);

    const domeMat = new THREE.MeshStandardMaterial({ color: 0xe9ece8 });
    const radome = new THREE.Mesh(new THREE.SphereGeometry(0.6, 16, 16), domeMat);
    radome.position.set(6, 10.5, 0);
    this.vesselGroup.add(radome);
  }

  private buildSubseaTrawlNet() {
    // Warp Cable Lines from Stern to Trawl Doors
    const warpMat = new THREE.LineBasicMaterial({ color: 0xc0923d, linewidth: 2 });

    const portPoints = [
      new THREE.Vector3(-15, 2.5, 2.5),
      new THREE.Vector3(-35, -15, 8.0),
      new THREE.Vector3(-60, -28, 12.0),
    ];
    const portGeo = new THREE.BufferGeometry().setFromPoints(portPoints);
    const portLine = new THREE.Line(portGeo, warpMat);
    this.subseaNetGroup.add(portLine);

    const stbdPoints = [
      new THREE.Vector3(-15, 2.5, -2.5),
      new THREE.Vector3(-35, -15, -8.0),
      new THREE.Vector3(-60, -28, -12.0),
    ];
    const stbdGeo = new THREE.BufferGeometry().setFromPoints(stbdPoints);
    const stbdLine = new THREE.Line(stbdGeo, warpMat);
    this.subseaNetGroup.add(stbdLine);

    // Morgère Trawl Doors (Hydrodynamic hydrofoil plates)
    const doorMat = new THREE.MeshStandardMaterial({ color: 0xc96532, metalness: 0.8 });
    const doorPort = new THREE.Mesh(new THREE.BoxGeometry(0.3, 3.2, 1.8), doorMat);
    doorPort.position.set(-60, -28, 12.0);
    doorPort.rotation.y = 0.2;
    this.subseaNetGroup.add(doorPort);

    const doorStbd = new THREE.Mesh(new THREE.BoxGeometry(0.3, 3.2, 1.8), doorMat);
    doorStbd.position.set(-60, -28, -12.0);
    doorStbd.rotation.y = -0.2;
    this.subseaNetGroup.add(doorStbd);

    // Center Steerable Clump Weight (for Twin Rig)
    const clumpMat = new THREE.MeshStandardMaterial({ color: 0x697276, metalness: 0.9 });
    const clump = new THREE.Mesh(new THREE.SphereGeometry(1.2, 12, 12), clumpMat);
    clump.position.set(-62, -30, 0);
    this.subseaNetGroup.add(clump);

    // Demersal Trawl Net Mouth & Funnel
    const netMat = new THREE.MeshStandardMaterial({
      color: 0x46725f,
      wireframe: true,
      transparent: true,
      opacity: 0.75,
    });
    const netConeGeo = new THREE.ConeGeometry(8, 24, 16, 8, true);
    const netCone = new THREE.Mesh(netConeGeo, netMat);
    netCone.position.set(-78, -29, 0);
    netCone.rotation.z = Math.PI / 2;
    this.subseaNetGroup.add(netCone);

    // Codend with acoustic catch sensor rings (S1, S2, S3, S4)
    const codendMat = new THREE.MeshStandardMaterial({ color: 0xc0923d, wireframe: true });
    const codend = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 1.8, 8, 12), codendMat);
    codend.position.set(-94, -29, 0);
    codend.rotation.z = Math.PI / 2;
    this.subseaNetGroup.add(codend);
  }

  private buildInternalCutaways() {
    // Robotic Arm DR-04 (6-Axis industrial manipulator)
    this.robotArmGroup = new THREE.Group();
    this.robotArmGroup.position.set(0, 3.5, 0);

    const baseMat = new THREE.MeshStandardMaterial({ color: 0x171b1d });
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.6, 0.4), baseMat);
    this.robotArmGroup.add(base);

    const linkMat = new THREE.MeshStandardMaterial({ color: 0xc96532, metalness: 0.5 }); // Industrial Orange
    const link1 = new THREE.Mesh(new THREE.BoxGeometry(0.4, 1.2, 0.4), linkMat);
    link1.position.set(0, 0.8, 0);
    this.robotArmGroup.add(link1);

    const link2 = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1.0, 0.3), linkMat);
    link2.position.set(0.3, 1.6, 0);
    link2.rotation.z = -0.4;
    this.robotArmGroup.add(link2);

    this.vesselGroup.add(this.robotArmGroup);
  }

  private buildFishSchool() {
    // Acoustic biomass echo markers near the seabed
    const fishGeo = new THREE.BufferGeometry();
    const count = 120;
    const positions = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      positions[i * 3] = -65 + (Math.random() - 0.5) * 20;
      positions[i * 3 + 1] = -28 + (Math.random() - 0.5) * 6;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 16;
    }

    fishGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const fishMat = new THREE.PointsMaterial({
      color: 0xbfd2d5,
      size: 0.6,
      transparent: true,
      opacity: 0.8,
    });
    const fishPoints = new THREE.Points(fishGeo, fishMat);
    this.fishSchoolGroup.add(fishPoints);
  }

  private applyCameraPreset(mode: CameraViewMode) {
    if (!this.camera) return;

    switch (mode) {
      case 'EXTERIOR':
        this.targetRotation = { x: 0.25, y: -0.65 };
        this.targetZoom = 48;
        this.targetPan.set(0, 0, 0);
        break;
      case 'DECK':
        this.targetRotation = { x: 0.55, y: -0.2 };
        this.targetZoom = 24;
        this.targetPan.set(-8, 3, 0);
        break;
      case 'BRIDGE':
        this.targetRotation = { x: 0.15, y: -0.4 };
        this.targetZoom = 14;
        this.targetPan.set(7, 5.5, 0);
        break;
      case 'ENGINE_ROOM':
        this.targetRotation = { x: 0.4, y: -0.8 };
        this.targetZoom = 18;
        this.targetPan.set(0, 1.5, 0);
        break;
      case 'FISH_PROCESSING':
        this.targetRotation = { x: 0.5, y: -0.1 };
        this.targetZoom = 12;
        this.targetPan.set(0, 3.5, 0);
        break;
      case 'COLD_STORE':
        this.targetRotation = { x: 0.3, y: -0.5 };
        this.targetZoom = 20;
        this.targetPan.set(-4, 1.0, 0);
        break;
      case 'SUBSEA_TRAWL':
        this.targetRotation = { x: 0.2, y: -0.9 };
        this.targetZoom = 80;
        this.targetPan.set(-50, -25, 0);
        break;
      default:
        this.targetRotation = { x: 0.3, y: -0.7 };
        this.targetZoom = 45;
        this.targetPan.set(0, 0, 0);
    }
  }

  private animate() {
    this.animationFrameId = requestAnimationFrame(() => this.animate());

    const time = Date.now() * 0.001;
    const waveAmp = (this.weather().waveHeightM || 2.0) * 0.2;

    // Pitch & Roll vessel with North Sea waves
    if (this.vesselGroup) {
      this.vesselGroup.position.y = Math.sin(time * 1.5) * waveAmp;
      this.vesselGroup.rotation.z = Math.sin(time * 1.2) * 0.035; // roll
      this.vesselGroup.rotation.x = Math.cos(time * 0.9) * 0.02; // pitch
    }

    // Dynamic wave motion on ocean plane
    if (this.oceanMesh) {
      const pos = this.oceanMesh.geometry.attributes['position'];
      for (let i = 0; i < pos.count; i++) {
        const u = pos.getX(i);
        const v = pos.getY(i);
        pos.setZ(i, Math.sin(u * 0.08 + time * 2) * waveAmp + Math.cos(v * 0.08 + time * 1.5) * (waveAmp * 0.6));
      }
      this.oceanMesh.geometry.computeVertexNormals();
      this.oceanMesh.geometry.attributes['position'].needsUpdate = true;
    }

    // Animate robotic arm in digital twin
    if (this.robotArmGroup) {
      this.robotArmGroup.rotation.y = Math.sin(time * 2.5) * 0.4;
    }

    // Camera smooth interpolation
    this.currentZoom += (this.targetZoom - this.currentZoom) * 0.08;

    const r = this.currentZoom;
    const phi = this.targetRotation.x;
    const theta = this.targetRotation.y;

    const cx = this.targetPan.x + r * Math.cos(phi) * Math.sin(theta);
    const cy = this.targetPan.y + r * Math.sin(phi);
    const cz = this.targetPan.z + r * Math.cos(phi) * Math.cos(theta);

    this.camera.position.set(cx, cy, cz);
    this.camera.lookAt(this.targetPan);

    this.renderer.render(this.scene, this.camera);
  }

  private setupEventListeners() {
    const container = this.canvasContainer.nativeElement;

    container.addEventListener('mousedown', (e) => {
      this.isMouseDown = true;
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isMouseDown = false;
    });

    container.addEventListener('mousemove', (e) => {
      if (!this.isMouseDown) return;

      const deltaX = e.clientX - this.previousMousePosition.x;
      const deltaY = e.clientY - this.previousMousePosition.y;

      this.targetRotation.y += deltaX * 0.006;
      this.targetRotation.x = Math.max(-Math.PI / 3, Math.min(Math.PI / 2.2, this.targetRotation.x + deltaY * 0.006));

      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    container.addEventListener(
      'wheel',
      (e) => {
        e.preventDefault();
        this.targetZoom = Math.max(8, Math.min(150, this.targetZoom + e.deltaY * 0.05));
      },
      { passive: false },
    );

    window.addEventListener('resize', () => {
      if (!container || !this.renderer || !this.camera) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    });
  }
}
