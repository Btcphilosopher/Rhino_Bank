import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HttpClient } from '@angular/common/http';
import { TrawlerStateService } from '../../services/trawler-state.service';

interface ChatMessage {
  id: string;
  sender: 'OPERATOR' | 'VESSEL_INTELLIGENCE';
  text: string;
  timestamp: string;
  source?: string;
}

@Component({
  selector: 'app-assistant-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-3 overflow-y-auto font-mono select-none">
      <!-- Top Assistant Header -->
      <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div class="flex items-center gap-2">
          <mat-icon class="text-sm! w-4! h-4! text-[#35677A]">psychology</mat-icon>
          <span class="font-bold text-white tracking-wider">BTO-SYSTEM VESSEL INTELLIGENCE // MARITIME DECISION SUPPORT</span>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-[10px] bg-[#46725F]/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30">
            DIGITAL TWIN TELEMETRY LINKED
          </span>
        </div>
      </div>

      <!-- Quick Technical Query Chips -->
      <div class="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        <span class="text-[#697276] text-[10px] uppercase font-bold shrink-0">QUICK QUERIES:</span>
        @for (q of sampleQueries; track q) {
          <button
            (click)="submitQuery(q)"
            class="px-2.5 py-1 bg-[#142A35] hover:bg-[#193D4C] text-[#BFD2D5] hover:text-white border border-white/10 rounded text-[11px] whitespace-nowrap transition-colors cursor-pointer"
          >
            {{ q }}
          </button>
        }
      </div>

      <!-- Chat History Stream -->
      <div class="flex-1 bg-[#171B1D] border border-white/10 rounded-xl p-3 overflow-y-auto flex flex-col gap-3 min-h-[350px]">
        @for (msg of messages(); track msg.id) {
          <div
            [class]="
              msg.sender === 'OPERATOR'
                ? 'self-end bg-[#35677A] text-white border-white/20 max-w-xl'
                : 'self-start bg-[#142A35] text-[#E9ECE8] border-white/10 max-w-2xl'
            "
            class="p-3 rounded-lg border text-xs flex flex-col gap-1 shadow-md"
          >
            <div class="flex items-center justify-between gap-4 text-[10px] pb-1 border-b border-white/15 opacity-80">
              <span class="font-bold uppercase">{{ msg.sender === 'OPERATOR' ? 'BRIDGE OPERATOR' : 'VESSEL INTELLIGENCE ENGINE' }}</span>
              <span>{{ msg.timestamp }}</span>
            </div>
            <p class="whitespace-pre-line text-[11px] leading-relaxed mt-1">{{ msg.text }}</p>
            @if (msg.source) {
              <div class="text-[9px] text-[#A8B0AF] text-right mt-0.5 font-bold">SOURCE: {{ msg.source }}</div>
            }
          </div>
        }

        @if (isLoading()) {
          <div class="self-start bg-[#142A35] p-3 rounded-lg border border-white/10 text-xs text-[#BFD2D5] flex items-center gap-2">
            <span class="w-2 h-2 rounded-full bg-[#35677A] animate-ping"></span>
            Synthesizing digital twin telemetry channels & UK MMO compliance models...
          </div>
        }
      </div>

      <!-- Input Bar -->
      <div class="bg-[#171B1D] border border-white/10 rounded-xl p-2 flex items-center gap-2">
        <input
          #queryInput
          type="text"
          placeholder="Ask Vessel Intelligence about telemetry, bottlenecks, quotas, weather, or maintenance..."
          (keydown.enter)="submitQuery(queryInput.value); queryInput.value = ''"
          class="flex-1 bg-[#142A35] text-white text-xs px-3 py-2 rounded border border-white/10 focus:outline-none focus:border-[#35677A]"
        />
        <button
          (click)="submitQuery(queryInput.value); queryInput.value = ''"
          [disabled]="isLoading()"
          class="px-4 py-2 bg-[#35677A] hover:bg-[#35677A]/80 text-white font-bold text-xs rounded transition-colors flex items-center gap-1 cursor-pointer disabled:opacity-50"
        >
          <mat-icon class="text-sm! w-4! h-4!">send</mat-icon>
          TRANSMIT
        </button>
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }
    `,
  ],
})
export class AssistantView {
  private http = inject(HttpClient);
  private state = inject(TrawlerStateService);

  readonly isLoading = signal<boolean>(false);

  readonly sampleQueries = [
    'What is the current vessel state?',
    'Why did catch processing slow down?',
    'Which machine is currently limiting throughput?',
    'What is the cold-store capacity?',
    'Which catch batches are ready for landing?',
    'What changed during the last haul?',
    'Evaluate weather risk for transit to Peterhead',
  ];

  readonly messages = signal<ChatMessage[]>([
    {
      id: 'MSG-INIT',
      sender: 'VESSEL_INTELLIGENCE',
      text: `[BTO-SYSTEM DECISION SUPPORT // SIMULATION ONLY // HUMAN AUTHORISATION REQUIRED]

FV NORTH STAR digital twin initialized.
Connected subsystems:
• 340 Telemetry channels active (Bergen Propulsion, Scania GenSets, Morgère Doors, Simrad Acoustic Sonar).
• Robotic Sorting Cell DR-04 linked with VISION-07 species classifier.
• UK Electronic Reporting System (ERS v3.4) synchronized with UK MMO shore hub.

How may I assist your North Sea operational decisions?`,
      timestamp: '04:00 UTC',
      source: 'BTO_CORE_TWIN',
    },
  ]);

  submitQuery(queryText: string) {
    if (!queryText || !queryText.trim() || this.isLoading()) return;

    const trimmed = queryText.trim();
    const userMsg: ChatMessage = {
      id: `USER-${Date.now()}`,
      sender: 'OPERATOR',
      text: trimmed,
      timestamp: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) + ' UTC',
    };

    this.messages.update((msgs) => [...msgs, userMsg]);
    this.isLoading.set(true);

    const context = {
      vessel: 'FV NORTH STAR',
      position: `${this.state.navigation().lat}°N ${this.state.navigation().lon}°E`,
      sog: this.state.navigation().sog,
      hdg: this.state.navigation().heading,
      trawlStage: this.state.trawlPhysics().stage,
      totalCatchKg: this.state.totalCatchWeightKg(),
      coldStoreFill: this.state.coldStoreFillPercent(),
      weather: this.state.weather(),
      robotStatus: this.state.robotArm().status,
    };

    this.http
      .post<{ answer: string; source: string; timestamp: string }>('/api/ai/query', {
        query: trimmed,
        vesselContext: context,
      })
      .subscribe({
        next: (res) => {
          const aiMsg: ChatMessage = {
            id: `AI-${Date.now()}`,
            sender: 'VESSEL_INTELLIGENCE',
            text: res.answer,
            timestamp: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) + ' UTC',
            source: res.source,
          };
          this.messages.update((msgs) => [...msgs, aiMsg]);
          this.isLoading.set(false);
        },
        error: () => {
          const fallbackMsg: ChatMessage = {
            id: `AI-${Date.now()}`,
            sender: 'VESSEL_INTELLIGENCE',
            text: `[BTO-SYSTEM DECISION SUPPORT // SIMULATION ONLY // HUMAN AUTHORISATION REQUIRED]

Digital Twin State Summary:
• Vessel: FV NORTH STAR (Speed: ${this.state.navigation().sog} kt, Heading: ${this.state.navigation().heading}°)
• Catch Onboard: ${this.state.totalCatchWeightKg()} kg demersal mix in Cold Hold 01/02.
• Systems operating within approved Lloyd's Register marine tolerances.`,
            timestamp: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) + ' UTC',
            source: 'BTO_FALLBACK_RULE_ENGINE',
          };
          this.messages.update((msgs) => [...msgs, fallbackMsg]);
          this.isLoading.set(false);
        },
      });
  }
}
