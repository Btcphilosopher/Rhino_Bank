import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TrawlerStateService } from '../../services/trawler-state.service';

@Component({
  selector: 'app-maintenance-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-3 overflow-y-auto font-mono select-none">
      <!-- Top Maintenance Overview -->
      <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div class="flex items-center gap-2">
          <mat-icon class="text-sm! w-4! h-4! text-[#C96532]">build</mat-icon>
          <span class="font-bold text-white tracking-wider">PLANNED MAINTENANCE SYSTEM (PMS) // LLOYD'S UMS COMPLIANT</span>
        </div>
        <div class="flex items-center gap-3">
          <button
            (click)="triggerFault()"
            class="px-2.5 py-1 bg-[#A6453D]/30 hover:bg-[#A6453D]/50 text-red-300 border border-[#A6453D]/50 rounded text-xs transition-colors flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-xs! w-3.5! h-3.5!">warning</mat-icon>
            SIMULATE ROBOT DR-04 FAULT
          </button>
          <button
            (click)="resetFault()"
            class="px-2.5 py-1 bg-[#46725F]/30 hover:bg-[#46725F]/50 text-emerald-300 border border-[#46725F]/50 rounded text-xs transition-colors flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-xs! w-3.5! h-3.5!">restart_alt</mat-icon>
            RESET ALL ASSET FAULTS
          </button>
        </div>
      </div>

      <!-- Assets Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        @for (asset of assets(); track asset.id) {
          <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col justify-between gap-2.5">
            <div>
              <div class="flex items-center justify-between border-b border-white/10 pb-2">
                <span class="font-bold text-white text-xs">{{ asset.name }}</span>
                <span
                  [class]="
                    asset.status === 'HEALTHY'
                      ? 'bg-[#46725F]/20 text-emerald-400 border-emerald-500/30'
                      : asset.status === 'ADVISORY'
                      ? 'bg-[#C0923D]/20 text-[#C0923D] border-[#C0923D]/30'
                      : 'bg-[#A6453D]/20 text-red-400 border-[#A6453D]/30'
                  "
                  class="text-[9px] px-1.5 py-0.5 rounded border font-bold"
                >
                  {{ asset.status }} ({{ asset.healthScore }}%)
                </span>
              </div>

              <div class="space-y-1.5 text-xs text-[#A8B0AF] mt-2">
                <div class="flex justify-between">
                  <span>RUN HOURS:</span>
                  <strong class="text-white">{{ asset.runHours }} H / {{ asset.serviceIntervalHours }} H</strong>
                </div>
                <div class="flex justify-between">
                  <span>HOURS TO NEXT SERVICE:</span>
                  <strong class="text-[#BFD2D5]">{{ asset.hoursUntilService }} H</strong>
                </div>
                <div class="flex justify-between">
                  <span>VIBRATION FFT:</span>
                  <strong class="text-white">{{ asset.vibrationMmS }} mm/s RMS</strong>
                </div>
                <div class="flex justify-between">
                  <span>OPERATING TEMP:</span>
                  <strong class="text-[#C0923D]">{{ asset.tempC }}°C</strong>
                </div>
              </div>

              @if (asset.faultDescription) {
                <div class="mt-2 p-2 bg-[#A6453D]/15 border border-[#A6453D]/30 rounded text-[10px] text-red-300">
                  <strong>FAULT:</strong> {{ asset.faultDescription }}
                </div>
              }

              @if (asset.mitigationRecommendation) {
                <div class="mt-2 p-2 bg-[#142A35] border border-white/5 rounded text-[10px] text-[#A8B0AF]">
                  <strong class="text-[#C0923D]">ACTION:</strong> {{ asset.mitigationRecommendation }}
                </div>
              }
            </div>

            <div class="text-[9px] text-[#697276] border-t border-white/5 pt-1">
              LAST OVERHAUL: {{ asset.lastServiceDate }}
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }
    `,
  ],
})
export class MaintenanceView {
  private state = inject(TrawlerStateService);

  readonly assets = this.state.maintenanceAssets;

  triggerFault() {
    this.state.triggerRobotFailureScenario();
  }

  resetFault() {
    this.state.resetRobotFault();
  }
}
