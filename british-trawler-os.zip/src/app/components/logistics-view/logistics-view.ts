import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TrawlerStateService } from '../../services/trawler-state.service';

@Component({
  selector: 'app-logistics-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-3 overflow-y-auto font-mono select-none">
      <!-- Top Port Banner -->
      <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div class="flex items-center gap-2">
          <mat-icon class="text-sm! w-4! h-4! text-[#35677A]">storefront</mat-icon>
          <span class="font-bold text-white tracking-wider">PORT DIGITAL TWIN // PORT OF PETERHEAD (QUAY 3 DEMERSAL TERMINAL)</span>
        </div>
        <div class="flex items-center gap-4 text-[11px] text-[#A8B0AF]">
          <div>BERTH ASSIGNMENT: <strong class="text-white">BERTH 3B (RESERVED)</strong></div>
          <div>ETA PETERHEAD: <strong class="text-[#C0923D] font-bold">18:30 UTC</strong></div>
          <div>AUCTION TIMING: <strong class="text-emerald-400">06:00 UTC (TOMORROW)</strong></div>
        </div>
      </div>

      <!-- Landing Order Manifest & Fish Market Auction Simulation -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 min-h-[420px]">
        <!-- Left: Landing Order Manifest (7 cols) -->
        <div class="lg:col-span-7 bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2.5">
          <div class="flex items-center justify-between border-b border-white/10 pb-2 text-xs font-bold text-white">
            <span class="flex items-center gap-1.5">
              <mat-icon class="text-sm! w-4! h-4! text-[#C96532]">assignment</mat-icon>
              LANDING ORDER & DISPATCH MANIFEST
            </span>
            <span class="text-[10px] text-emerald-400 bg-emerald-400/20 px-1.5 py-0.5 rounded">READY</span>
          </div>

          <div class="space-y-2 text-xs">
            <div class="bg-[#142A35] p-2.5 rounded border border-white/5 flex justify-between items-center">
              <div>
                <strong class="text-white">HADDOCK (GRADE A - 50-60CM)</strong>
                <div class="text-[10px] text-[#A8B0AF]">Freezer Hold 01 • Batch NS-260926-0041 • 842 KG</div>
              </div>
              <div class="text-right">
                <span class="text-emerald-400 font-bold">£3,241.70</span>
                <div class="text-[9px] text-[#A8B0AF]">Direct UK Retail Pre-Bid</div>
              </div>
            </div>

            <div class="bg-[#142A35] p-2.5 rounded border border-white/5 flex justify-between items-center">
              <div>
                <strong class="text-white">COD (GRADE A LARGE - >65CM)</strong>
                <div class="text-[10px] text-[#A8B0AF]">Freezer Hold 01 • Batch NS-260926-0040 • 1,240 KG</div>
              </div>
              <div class="text-right">
                <span class="text-emerald-400 font-bold">£6,696.00</span>
                <div class="text-[9px] text-[#A8B0AF]">High-End Gastronomy Pool</div>
              </div>
            </div>

            <div class="bg-[#142A35] p-2.5 rounded border border-white/5 flex justify-between items-center">
              <div>
                <strong class="text-white">MONKFISH (TAILS & WHOLE)</strong>
                <div class="text-[10px] text-[#A8B0AF]">Chilled Hold • Batch NS-260926-0039 • 460 KG</div>
              </div>
              <div class="text-right">
                <span class="text-emerald-400 font-bold">£3,496.00</span>
                <div class="text-[9px] text-[#A8B0AF]">Export Air-Freight Hub</div>
              </div>
            </div>

            <div class="bg-[#142A35] p-2.5 rounded border border-white/5 flex justify-between items-center">
              <div>
                <strong class="text-white">PLAICE (GRADE A - 35-42CM)</strong>
                <div class="text-[10px] text-[#A8B0AF]">Freezer Hold 02 • Batch NS-260926-0038 • 620 KG</div>
              </div>
              <div class="text-right">
                <span class="text-emerald-400 font-bold">£1,829.00</span>
                <div class="text-[9px] text-[#A8B0AF]">Peterhead Open Floor Auction</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Right: Shore Services & Cold Chain Dispatch (5 cols) -->
        <div class="lg:col-span-5 bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2.5">
          <div class="flex items-center justify-between border-b border-white/10 pb-2 text-xs font-bold text-white">
            <span class="flex items-center gap-1.5 text-[#C0923D]">
              <mat-icon class="text-sm! w-4! h-4!">local_shipping</mat-icon>
              SHORE INTEGRATION & BUNKERING
            </span>
            <span class="text-[10px] text-[#A8B0AF]">PETERHEAD HARBOUR</span>
          </div>

          <div class="space-y-2 text-xs text-[#A8B0AF]">
            <div class="bg-[#142A35] p-2 rounded flex justify-between">
              <span>BUNKER FUEL BOOKING:</span>
              <strong class="text-white">45,000 L MGO (0.1% Sulphur)</strong>
            </div>
            <div class="bg-[#142A35] p-2 rounded flex justify-between">
              <span>FLUID ICE SILO TOP-UP:</span>
              <strong class="text-white">30 TONNES FLUID ICE</strong>
            </div>
            <div class="bg-[#142A35] p-2 rounded flex justify-between">
              <span>REFRIGERATED ARTIC TRANSPORT:</span>
              <strong class="text-[#BFD2D5]">2x THERMO-KING TRAILERS</strong>
            </div>
            <div class="bg-[#142A35] p-2 rounded flex justify-between">
              <span>QUAY CRANE DISCHARGE RATE:</span>
              <strong class="text-white">18 TONNES / HOUR</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }
    `,
  ],
})
export class LogisticsView {
  private state = inject(TrawlerStateService);
}
