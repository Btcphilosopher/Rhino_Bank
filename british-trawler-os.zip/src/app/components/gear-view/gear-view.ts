import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TrawlerStateService } from '../../services/trawler-state.service';

@Component({
  selector: 'app-gear-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-3 overflow-y-auto font-mono select-none">
      <!-- Top Winch Summary -->
      <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div class="flex items-center gap-2">
          <mat-icon class="text-sm! w-4! h-4! text-[#C0923D]">settings_input_component</mat-icon>
          <span class="font-bold text-white tracking-wider">DECK MACHINERY & WINCH DIGITAL TWIN (HYDRAULIC + ELECTRIC)</span>
        </div>
        <div class="flex items-center gap-4 text-[11px] text-[#A8B0AF]">
          <div>HPU PRESSURE: <strong class="text-white">280 BAR</strong></div>
          <div>OIL TEMP: <strong class="text-[#BFD2D5]">54.0°C</strong></div>
          <div>AUTO-SPOOLING: <strong class="text-emerald-400 font-bold">SYNCHRONISED</strong></div>
        </div>
      </div>

      <!-- Winch Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        @for (w of winches(); track w.id) {
          <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2.5">
            <div class="flex items-center justify-between border-b border-white/10 pb-2">
              <span class="font-bold text-white text-xs">{{ w.name }}</span>
              <span class="text-[10px] bg-[#46725F]/20 text-[#46725F] px-1.5 py-0.5 rounded font-bold">
                HEALTH {{ w.healthScore }}%
              </span>
            </div>

            <!-- Telemetry Gauges -->
            <div class="space-y-1.5 text-xs text-[#A8B0AF]">
              <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
                <span>WARP LENGTH PAYOUT:</span>
                <strong class="text-white text-sm">{{ w.lineLengthM }} M</strong>
              </div>

              <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
                <span>LINE TENSION:</span>
                <strong class="text-[#C0923D] text-sm">{{ w.tensionKn }} kN / {{ w.maxTensionKn }} kN</strong>
              </div>

              <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
                <span>HAUL / SHOOT SPEED:</span>
                <strong class="text-white">{{ w.lineSpeedMps }} M/S</strong>
              </div>

              <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
                <span>MOTOR LOAD:</span>
                <strong class="text-emerald-400">{{ w.motorLoadPercent }}%</strong>
              </div>

              <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
                <span>HYDRAULIC BRAKE:</span>
                <strong class="text-[#BFD2D5]">{{ w.brakeState }}</strong>
              </div>

              <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
                <span>DIAMOND SPOOLER:</span>
                <strong class="text-white">{{ w.spoolingStatus }}</strong>
              </div>
            </div>

            <!-- Tension Bar Gauge -->
            <div class="w-full bg-white/5 rounded-full h-2 overflow-hidden">
              <div
                class="h-full bg-[#C0923D] transition-all"
                [style.width.%]="(w.tensionKn / w.maxTensionKn) * 100"
              ></div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }
    `,
  ],
})
export class GearView {
  private state = inject(TrawlerStateService);

  readonly winches = this.state.winches;
}
