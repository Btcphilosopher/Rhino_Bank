import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FISH_SPECIES_LIBRARY, MARITIME_MANUALS } from '../../services/knowledge-base.data';
import { FishSpeciesInfo, MaritimeManualArticle } from '../../models/trawler.models';

@Component({
  selector: 'app-knowledge-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-3 overflow-y-auto font-mono select-none">
      <!-- Section Toggle (Species vs Engineering Manuals) -->
      <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div class="flex items-center gap-2">
          <mat-icon class="text-sm! w-4! h-4! text-[#C96532]">menu_book</mat-icon>
          <span class="font-bold text-white tracking-wider">BRITISH MARITIME ENCYCLOPEDIA & NORTH SEA SPECIES LIBRARY</span>
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="selectedCategory.set('SPECIES')"
            [class]="selectedCategory() === 'SPECIES' ? 'bg-[#35677A] text-white font-bold' : 'bg-[#142A35] text-[#A8B0AF] hover:text-white'"
            class="px-3 py-1 rounded text-xs transition-colors cursor-pointer border border-white/10"
          >
            FISH SPECIES DATABASE ({{ speciesList.length }})
          </button>
          <button
            (click)="selectedCategory.set('MANUALS')"
            [class]="selectedCategory() === 'MANUALS' ? 'bg-[#35677A] text-white font-bold' : 'bg-[#142A35] text-[#A8B0AF] hover:text-white'"
            class="px-3 py-1 rounded text-xs transition-colors cursor-pointer border border-white/10"
          >
            NAVAL ENGINEERING MANUALS ({{ manualsList.length }})
          </button>
        </div>
      </div>

      <!-- SPECIES VIEW -->
      @if (selectedCategory() === 'SPECIES') {
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          @for (sp of speciesList; track sp.id) {
            <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3.5 flex flex-col justify-between gap-2.5 shadow-md">
              <div>
                <div class="flex items-center justify-between border-b border-white/10 pb-2">
                  <div>
                    <h3 class="font-bold text-white text-sm">{{ sp.name }}</h3>
                    <div class="text-[11px] text-[#A8B0AF] italic">{{ sp.latin }}</div>
                  </div>
                  <span class="text-[10px] bg-[#35677A]/30 text-[#BFD2D5] px-2 py-0.5 rounded font-bold border border-[#35677A]/40">
                    {{ sp.marketCode }}
                  </span>
                </div>

                <div class="space-y-1.5 text-xs text-[#A8B0AF] mt-2.5">
                  <div>
                    <span class="text-white font-semibold">TYPICAL SIZE:</span> {{ sp.typicalSizeCm }} (MLS: <strong class="text-emerald-400">{{ sp.minLandingSizeCm }} cm</strong>)
                  </div>
                  <div>
                    <span class="text-white font-semibold">MARKET VALUE:</span> <strong class="text-[#C0923D]">{{ sp.marketPriceRangeGbpKg }}</strong>
                  </div>
                  <div class="text-[11px] bg-[#142A35] p-2 rounded border border-white/5">
                    <span class="text-[#BFD2D5] font-semibold">HABITAT:</span> {{ sp.habitat }}
                  </div>
                  <div class="text-[11px] bg-[#142A35] p-2 rounded border border-white/5">
                    <span class="text-[#46725F] font-semibold">HANDLING & CHILLING:</span> {{ sp.handlingProtocol }}
                  </div>
                </div>
              </div>

              <div class="text-[10px] text-[#697276] border-t border-white/5 pt-1.5">
                QUOTA POOL: {{ sp.ukMmoQuotaCategory }}
              </div>
            </div>
          }
        </div>
      }

      <!-- MANUALS VIEW -->
      @if (selectedCategory() === 'MANUALS') {
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          @for (man of manualsList; track man.id) {
            <div class="bg-[#171B1D] border border-white/10 rounded-xl p-4 flex flex-col justify-between gap-3 shadow-md">
              <div>
                <div class="flex items-center justify-between border-b border-white/10 pb-2">
                  <span class="text-xs bg-[#C96532]/20 text-[#C96532] px-2 py-0.5 rounded font-bold border border-[#C96532]/30">
                    {{ man.category }}
                  </span>
                  <span class="text-[10px] text-[#A8B0AF]">{{ man.id }}</span>
                </div>

                <h3 class="font-bold text-white text-sm mt-2 leading-snug">{{ man.title }}</h3>
                <div class="text-[11px] text-[#BFD2D5] mt-0.5">AUTHOR: {{ man.author }}</div>

                <p class="text-xs text-[#A8B0AF] mt-2 italic bg-[#142A35] p-2.5 rounded border border-white/5">
                  {{ man.summary }}
                </p>

                <div class="text-xs text-[#E9ECE8] mt-2 whitespace-pre-line leading-relaxed bg-[#0D171C] p-3 rounded border border-white/10">
                  {{ man.content }}
                </div>
              </div>

              <div class="text-[10px] text-emerald-400 font-bold border-t border-white/5 pt-1.5 flex items-center gap-1">
                <mat-icon class="text-xs! w-3.5! h-3.5!">check_circle</mat-icon>
                APPROVED BRITISH NAVAL ARCHITECTURE & MMO SPECIFICATION
              </div>
            </div>
          }
        </div>
      }
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }
    `,
  ],
})
export class KnowledgeView {
  readonly speciesList: FishSpeciesInfo[] = FISH_SPECIES_LIBRARY;
  readonly manualsList: MaritimeManualArticle[] = MARITIME_MANUALS;

  readonly selectedCategory = signal<'SPECIES' | 'MANUALS'>('SPECIES');
}
