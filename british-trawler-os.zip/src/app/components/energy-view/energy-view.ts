import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TrawlerStateService } from '../../services/trawler-state.service';

@Component({
  selector: 'app-energy-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-3 overflow-y-auto font-mono select-none">
      <!-- Top Specific Metrics Banner -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[#A8B0AF] text-[10px]">ENERGY PER KG CATCH</span>
          <div class="text-xl font-bold text-emerald-400 mt-1">{{ energy().kwhPerKgCatch }} kWh / kg</div>
          <span class="text-[10px] text-[#A8B0AF]">BENCHMARK: &lt;0.55 kWh</span>
        </div>

        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[#A8B0AF] text-[10px]">FUEL PER TONNE LANDED</span>
          <div class="text-xl font-bold text-white mt-1">{{ energy().fuelLitersPerTonneLanded }} L / T</div>
          <span class="text-[10px] text-emerald-400">EEDI RATING: A+</span>
        </div>

        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[#A8B0AF] text-[10px]">BATTERY ESS STATE OF CHARGE</span>
          <div class="text-xl font-bold text-[#35677A] mt-1">{{ energy().batterySocPercent }}%</div>
          <span class="text-[10px] text-[#BFD2D5]">PEAK SHAVING (850 kWh)</span>
        </div>

        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[#A8B0AF] text-[10px]">TOTAL POWER DEMAND</span>
          <div class="text-xl font-bold text-[#C0923D] mt-1">{{ energy().totalPowerDemandKw }} kW</div>
          <span class="text-[10px] text-[#A8B0AF]">HYBRID BUS 690V / 50Hz</span>
        </div>
      </div>

      <!-- Main Energy Grid: Propulsion Engine + Electrical Distribution -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 min-h-[420px]">
        <!-- Left: Bergen Main Engine Telemetry (6 cols) -->
        <div class="lg:col-span-6 bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2.5">
          <div class="flex items-center justify-between border-b border-white/10 pb-2 text-xs font-bold text-white">
            <span class="flex items-center gap-1.5">
              <mat-icon class="text-sm! w-4! h-4! text-[#C96532]">bolt</mat-icon>
              BERGEN B33:45L8P MAIN DIESEL (3,200 kW)
            </span>
            <span class="text-[10px] text-emerald-400 bg-emerald-400/20 px-1.5 py-0.5 rounded">ONLINE</span>
          </div>

          <div class="space-y-2 text-xs text-[#A8B0AF]">
            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span>ENGINE SPEED:</span>
              <strong class="text-white text-sm">{{ engine().rpm }} RPM</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span>MCR LOAD:</span>
              <strong class="text-emerald-400 text-sm">{{ engine().loadPercent }}%</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span>INSTANTANEOUS FUEL FLOW:</span>
              <strong class="text-[#C0923D] text-sm">{{ engine().fuelFlowLitersPerHour }} L/H</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span>COOLANT TEMPERATURE:</span>
              <strong class="text-white">{{ engine().coolantTempC }}°C</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span>LUBRICATING OIL PRESSURE:</span>
              <strong class="text-white">{{ engine().oilPressureBar }} BAR</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span>EXHAUST GAS TEMP (CYL AVG):</span>
              <strong class="text-white">{{ engine().exhaustTempC }}°C</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span>SPECIFIC FUEL CONSUMPTION:</span>
              <strong class="text-[#BFD2D5]">{{ engine().specificFuelConsumptionGkwh }} g/kWh</strong>
            </div>
          </div>
        </div>

        <!-- Right: Power Consumer Sankey Breakdown & GenSets (6 cols) -->
        <div class="lg:col-span-6 bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2.5">
          <div class="flex items-center justify-between border-b border-white/10 pb-2 text-xs font-bold text-white">
            <span class="flex items-center gap-1.5">
              <mat-icon class="text-sm! w-4! h-4! text-[#35677A]">electric_meter</mat-icon>
              POWER CONSUMER DISTRIBUTION (690V / 440V)
            </span>
            <span class="text-[10px] text-[#A8B0AF]">BUS FREQ: 50.0 Hz</span>
          </div>

          <div class="space-y-2 text-xs">
            <div class="bg-[#142A35] p-2 rounded flex flex-col gap-1">
              <div class="flex justify-between">
                <span class="text-[#A8B0AF]">MAIN PROPULSION SHAFT:</span>
                <strong class="text-white">{{ energy().propulsionKw }} kW (68.0%)</strong>
              </div>
              <div class="w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                <div class="h-full bg-[#C96532] w-[68%]"></div>
              </div>
            </div>

            <div class="bg-[#142A35] p-2 rounded flex flex-col gap-1">
              <div class="flex justify-between">
                <span class="text-[#A8B0AF]">REFRIGERATION & BLAST FREEZERS:</span>
                <strong class="text-white">{{ energy().refrigerationKw }} kW (17.0%)</strong>
              </div>
              <div class="w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                <div class="h-full bg-[#35677A] w-[17%]"></div>
              </div>
            </div>

            <div class="bg-[#142A35] p-2 rounded flex flex-col gap-1">
              <div class="flex justify-between">
                <span class="text-[#A8B0AF]">HYDRAULIC POWER PACK (WINCHES):</span>
                <strong class="text-white">{{ energy().hydraulicsKw }} kW (8.0%)</strong>
              </div>
              <div class="w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                <div class="h-full bg-[#C0923D] w-[8%]"></div>
              </div>
            </div>

            <div class="bg-[#142A35] p-2 rounded flex flex-col gap-1">
              <div class="flex justify-between">
                <span class="text-[#A8B0AF]">ROBOTIC FISH PROCESSING CELL:</span>
                <strong class="text-white">{{ energy().roboticsKw }} kW (2.5%)</strong>
              </div>
              <div class="w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                <div class="h-full bg-[#46725F] w-[2.5%]"></div>
              </div>
            </div>

            <div class="bg-[#142A35] p-2 rounded flex flex-col gap-1">
              <div class="flex justify-between">
                <span class="text-[#A8B0AF]">HOTEL & NAVIGATION ELECTRONICS:</span>
                <strong class="text-white">{{ energy().hotelLoadKw }} kW (4.5%)</strong>
              </div>
              <div class="w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                <div class="h-full bg-[#BFD2D5] w-[4.5%]"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }
    `,
  ],
})
export class EnergyView {
  private state = inject(TrawlerStateService);

  readonly engine = this.state.propulsion;
  readonly energy = this.state.energyMetrics;
  readonly generators = this.state.generators;
}
