import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TrawlerStateService } from '../../services/trawler-state.service';

@Component({
  selector: 'app-compliance-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-3 overflow-y-auto font-mono select-none">
      <!-- VMS Satellite Telemetry Banner -->
      <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div class="flex items-center gap-2">
          <mat-icon class="text-sm! w-4! h-4! text-[#35677A]">satellite_alt</mat-icon>
          <span class="font-bold text-white tracking-wider">UK VESSEL MONITORING SYSTEM (VMS) // IRIDIUM CERTUS 100</span>
          <span class="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30">
            TRANSMITTING (15 MIN CADENCE)
          </span>
        </div>

        <div class="flex items-center gap-4 text-[11px] text-[#A8B0AF]">
          <div>SIGNAL: <strong class="text-white">{{ vms().signalStrengthDbm }} dBm</strong></div>
          <div>LAST REPORT: <strong class="text-[#BFD2D5]">{{ vms().lastTransmissionUtc }}</strong></div>
          <div>MMO STATUS: <strong class="text-emerald-400 font-bold">VERIFIED</strong></div>
        </div>
      </div>

      <!-- Electronic Reporting System (UK ERS) Message Queue -->
      <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex-1 flex flex-col gap-2.5">
        <div class="flex items-center justify-between border-b border-white/10 pb-2 text-xs font-bold text-white">
          <span class="flex items-center gap-1.5">
            <mat-icon class="text-sm! w-4! h-4! text-[#46725F]">verified</mat-icon>
            UK ELECTRONIC LOGBOOK (ERS v3.4 COMPLIANT) // MESSAGE QUEUE
          </span>
          <span class="text-[10px] text-[#A8B0AF]">MMO VESSEL REF: UK-ERS-MNST4-2026</span>
        </div>

        <div class="flex-1 overflow-y-auto space-y-2 text-xs">
          @for (report of elogQueue(); track report.id) {
            <div class="bg-[#142A35] p-3 rounded border border-white/5 flex flex-col gap-1.5">
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="px-2 py-0.5 rounded font-bold text-xs bg-[#35677A] text-white">
                    {{ report.type }}
                  </span>
                  <span class="font-bold text-white text-xs">{{ report.description }}</span>
                </div>
                <div class="flex items-center gap-2">
                  <span
                    [class]="
                      report.status === 'ACK'
                        ? 'bg-[#46725F]/20 text-emerald-400 border-emerald-500/30'
                        : report.status === 'PENDING'
                        ? 'bg-[#C0923D]/20 text-[#C0923D] border-[#C0923D]/30'
                        : 'bg-white/10 text-[#A8B0AF]'
                    "
                    class="text-[10px] px-2 py-0.5 rounded border font-bold"
                  >
                    {{ report.status }}
                  </span>
                  @if (report.ackRef) {
                    <span class="text-[10px] text-[#A8B0AF]">({{ report.ackRef }})</span>
                  }
                </div>
              </div>

              <p class="text-[11px] text-[#A8B0AF]">{{ report.payloadSummary }}</p>

              <div class="text-[10px] text-[#697276] flex justify-between border-t border-white/5 pt-1">
                <span>TRANSMITTED: {{ report.timestamp || 'STAGING' }}</span>
                <span>SCHEMA: UK-MMO-ERS-XML-v3.4</span>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }
    `,
  ],
})
export class ComplianceView {
  private state = inject(TrawlerStateService);

  readonly elogQueue = this.state.eLogQueue;
  readonly vms = this.state.vms;
}
