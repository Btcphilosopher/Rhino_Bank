import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TrawlerStateService } from '../../services/trawler-state.service';
import { TrawlStage } from '../../models/trawler.models';

@Component({
  selector: 'app-fishing-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-3 overflow-y-auto font-mono select-none">
      <!-- Trawl Cycle Progress Stepper Bar -->
      <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2">
        <div class="flex items-center justify-between text-xs font-bold text-white">
          <div class="flex items-center gap-2">
            <mat-icon class="text-sm! w-4! h-4! text-[#C96532]">water</mat-icon>
            <span>TRAWL OPERATING CYCLE // TWIN-RIG DEMERSAL HIGH-LIFT</span>
          </div>
          <div class="flex items-center gap-2">
            <span class="text-[#A8B0AF]">CURRENT STAGE:</span>
            <span class="text-[#C96532] bg-[#C96532]/20 px-2 py-0.5 rounded border border-[#C96532]/30">
              {{ trawl().stage }} ({{ trawl().stageProgress }}%)
            </span>
          </div>
        </div>

        <!-- Horizontal Stage Steps -->
        <div class="grid grid-cols-5 md:grid-cols-11 gap-1 pt-1">
          @for (s of allStages; track s) {
            <div
              [class]="
                trawl().stage === s
                  ? 'bg-[#C96532] text-white border-white/40 shadow-md font-bold'
                  : isPassedStage(s)
                  ? 'bg-[#46725F]/30 text-[#BFD2D5] border-white/10'
                  : 'bg-[#142A35] text-[#697276] border-white/5'
              "
              class="px-1.5 py-1 text-[10px] rounded border text-center transition-all truncate"
            >
              {{ s }}
            </div>
          }
        </div>
      </div>

      <!-- Main Fishing Grid: Sonar Echogram + Trawl Physics Gauges -->
      <div class="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-3 min-h-[420px]">
        <!-- Left 2 Cols: Subsea Echogram & Acoustic Net Sounder -->
        <div class="lg:col-span-2 bg-[#171B1D] border border-white/10 rounded-xl flex flex-col overflow-hidden">
          <div class="bg-[#142A35] px-3 py-2 border-b border-white/10 flex items-center justify-between text-xs">
            <div class="flex items-center gap-2">
              <mat-icon class="text-sm! w-4! h-4! text-[#35677A]">graphic_eq</mat-icon>
              <span class="font-bold text-white">SIMRAD SN90 MULTIBEAM ACOUSTIC ECHOGRAM</span>
            </div>
            <div class="flex items-center gap-3 text-[11px] text-[#A8B0AF]">
              <span>FREQ: <strong class="text-white">90 kHz</strong></span>
              <span>BIOMASS EST: <strong class="text-emerald-400 font-bold">{{ trawl().acousticBiomassEstimateKg }} KG</strong></span>
              <span>FILL: <strong class="text-[#C0923D]">{{ trawl().codendFillPercent }}%</strong></span>
            </div>
          </div>

          <!-- Echogram Canvas / SVG Visualization -->
          <div class="relative flex-1 bg-[#09151C] p-3 flex flex-col justify-between overflow-hidden">
            <!-- Simulated Acoustic Fish Marks -->
            <svg class="w-full h-full" viewBox="0 0 600 300" preserveAspectRatio="none">
              <!-- Water Column Gradient -->
              <defs>
                <linearGradient id="waterCol" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stop-color="#142A35" stop-opacity="0.3" />
                  <stop offset="100%" stop-color="#09151C" stop-opacity="0.9" />
                </linearGradient>
              </defs>
              <rect width="100%" height="100%" fill="url(#waterCol)" />

              <!-- Surface Line -->
              <line x1="0" y1="20" x2="600" y2="20" stroke="#35677A" stroke-width="1.5" stroke-dasharray="4,2" />
              <text x="10" y="16" fill="#BFD2D5" font-size="9">SURFACE (0.0M)</text>

              <!-- Seabed Contour Line (at ~86m depth = y: 250) -->
              <path
                d="M 0,250 Q 150,245 300,252 T 600,248 L 600,300 L 0,300 Z"
                fill="#2B3032"
                stroke="#C0923D"
                stroke-width="2"
              />
              <text x="10" y="270" fill="#E9ECE8" font-size="10" font-weight="bold">SEABED: 86.4M (SAND & GRAVEL)</text>

              <!-- Net Headrope Line (Depth 79.8m = y: 220) -->
              <line x1="200" y1="220" x2="520" y2="220" stroke="#46725F" stroke-width="2" />
              <text x="210" y="215" fill="#46725F" font-size="9" font-weight="bold">HEADROPE DEPTH: 79.8M</text>

              <!-- Net Footrope / Groundgear Line (Clearance 0.6m = y: 246) -->
              <line x1="200" y1="246" x2="520" y2="246" stroke="#C96532" stroke-width="1.5" />
              <text x="210" y="243" fill="#C96532" font-size="9">GROUNDGEAR CLEARANCE: 0.6M</text>

              <!-- Net Funnel Geometry in Echogram -->
              <polygon points="200,220 200,246 520,240 520,226" fill="#46725F" opacity="0.25" stroke="#46725F" stroke-width="1" />

              <!-- Acoustic High-Density Fish School Cloud (Haddock / Cod Biomass) -->
              <ellipse cx="140" cy="235" rx="45" ry="12" fill="#C0923D" opacity="0.6" />
              <ellipse cx="150" cy="232" rx="25" ry="6" fill="#A6453D" opacity="0.8" />
              <text x="110" y="215" fill="#C0923D" font-size="10" font-weight="bold">HIGH DENSITY BIOMASS</text>

              <!-- Fish entering codend -->
              <ellipse cx="360" cy="233" rx="30" ry="5" fill="#C0923D" opacity="0.5" />
              <ellipse cx="480" cy="233" rx="20" ry="4" fill="#A6453D" opacity="0.7" />
            </svg>

            <!-- Real-time Codend Catch Sensor Rings (S1 to S4) -->
            <div class="absolute top-4 right-4 bg-[#171B1D]/90 border border-white/10 p-2.5 rounded-lg flex flex-col gap-1.5 shadow-lg">
              <span class="text-[10px] text-[#A8B0AF] uppercase font-bold tracking-wider">CODEND FILL SENSORS</span>
              <div class="grid grid-cols-4 gap-2 text-center text-xs">
                <div class="p-1.5 rounded border border-emerald-500/40 bg-emerald-500/20 text-emerald-400 font-bold">
                  S1: ON
                </div>
                <div class="p-1.5 rounded border border-emerald-500/40 bg-emerald-500/20 text-emerald-400 font-bold">
                  S2: ON
                </div>
                <div class="p-1.5 rounded border border-emerald-500/40 bg-emerald-500/20 text-emerald-400 font-bold">
                  S3: ON
                </div>
                <div class="p-1.5 rounded border border-white/10 bg-[#142A35] text-[#697276]">
                  S4: OFF
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Right Col: Subsea Trawl Geometry & Controls -->
        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-3">
          <div class="flex items-center justify-between border-b border-white/10 pb-2 text-xs font-bold text-white">
            <span class="flex items-center gap-1.5">
              <mat-icon class="text-sm! w-4! h-4! text-[#C0923D]">tune</mat-icon>
              TRAWL GEOMETRY TWIN
            </span>
            <span class="text-[10px] text-emerald-400 bg-emerald-400/20 px-1.5 py-0.5 rounded">SYMMETRIC</span>
          </div>

          <div class="space-y-2 text-xs text-[#A8B0AF]">
            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span>MORGÈRE DOOR SPREAD:</span>
              <strong class="text-white text-sm">{{ trawl().doorSpreadM }} M</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span>NET OPENING HEIGHT:</span>
              <strong class="text-emerald-400 text-sm">{{ trawl().netOpeningHeightM }} M</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span>WARP LENGTH (PORT / STBD):</span>
              <strong class="text-white">{{ trawl().warpLengthPortM }}M / {{ trawl().warpLengthStbdM }}M</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span>PORT WARP TENSION:</span>
              <strong class="text-[#C0923D]">{{ trawl().warpTensionPortKn }} kN</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span>STARBOARD WARP TENSION:</span>
              <strong class="text-[#C0923D]">{{ trawl().warpTensionStbdKn }} kN</strong>
            </div>

            <div class="flex justify-between items-center bg-[#142A35] p-2 rounded">
              <span>STEERABLE CLUMP LOAD:</span>
              <strong class="text-[#BFD2D5]">{{ trawl().clumpWeightTensionKn }} kN</strong>
            </div>
          </div>

          <!-- Operator Action Controls -->
          <div class="mt-auto space-y-2 pt-2 border-t border-white/10">
            <button
              (click)="triggerHaul()"
              [disabled]="trawl().stage === 'HAUL'"
              class="w-full py-2 bg-[#C96532] hover:bg-[#C96532]/80 text-white font-bold text-xs rounded transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <mat-icon class="text-sm! w-4! h-4!">move_to_inbox</mat-icon>
              COMMENCE AUTOMATED HAUL (SIMULATED)
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }
    `,
  ],
})
export class FishingView {
  private state = inject(TrawlerStateService);

  readonly trawl = this.state.trawlPhysics;

  readonly allStages: TrawlStage[] = [
    'PREPARE',
    'LOWER_GEAR',
    'DEPLOY',
    'SET_DEPTH',
    'TOW',
    'MONITOR',
    'HAUL',
    'RECOVER',
    'SORT',
    'PROCESS',
    'STORE',
  ];

  isPassedStage(stage: TrawlStage): boolean {
    const currentIdx = this.allStages.indexOf(this.trawl().stage);
    const targetIdx = this.allStages.indexOf(stage);
    return targetIdx < currentIdx;
  }

  triggerHaul() {
    this.state.initiateHaulSequence();
  }
}
