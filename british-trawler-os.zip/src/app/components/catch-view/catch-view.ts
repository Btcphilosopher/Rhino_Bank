import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TrawlerStateService } from '../../services/trawler-state.service';

@Component({
  selector: 'app-catch-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-3 overflow-y-auto font-mono select-none">
      <!-- Top Metrics Ribbon -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[#A8B0AF] text-[10px]">TOTAL TRIP CATCH</span>
          <div class="text-xl font-bold text-white mt-1">{{ totalCatchKg() }} KG</div>
          <span class="text-[10px] text-[#46725F]">10.118 TONNES LANDED</span>
        </div>

        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[#A8B0AF] text-[10px]">EST. GROSS VALUE</span>
          <div class="text-xl font-bold text-[#C0923D] mt-1">£{{ grossValue().toLocaleString() }}</div>
          <span class="text-[10px] text-[#A8B0AF]">AVG £4.24 / KG</span>
        </div>

        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[#A8B0AF] text-[10px]">GRADE A YIELD</span>
          <div class="text-xl font-bold text-emerald-400 mt-1">88.4%</div>
          <span class="text-[10px] text-emerald-400">+£4,820 QUALITY PREMIUM</span>
        </div>

        <div class="bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[#A8B0AF] text-[10px]">ACTIVE HAULS LOGGED</span>
          <div class="text-xl font-bold text-[#BFD2D5] mt-1">5 HAULS</div>
          <span class="text-[10px] text-[#A8B0AF]">FLADEN GROUND IVa</span>
        </div>
      </div>

      <!-- Main Catch Grid: Species Breakdown & Traceable Batch Passports -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 min-h-[420px]">
        <!-- Left: Species Catch Breakdown & Quotas (7 cols) -->
        <div class="lg:col-span-7 bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2.5">
          <div class="flex items-center justify-between border-b border-white/10 pb-2 text-xs font-bold text-white">
            <span class="flex items-center gap-1.5">
              <mat-icon class="text-sm! w-4! h-4! text-[#35677A]">scale</mat-icon>
              SPECIES CATCH BREAKDOWN & UK QUOTA USAGE
            </span>
            <span class="text-[10px] text-[#A8B0AF]">AREA IVa POOL</span>
          </div>

          <div class="space-y-2 text-xs">
            @for (item of catchTotals(); track item.species) {
              <div class="bg-[#142A35] p-2.5 rounded border border-white/5 flex flex-col gap-1.5">
                <div class="flex justify-between items-center">
                  <div>
                    <span class="font-bold text-white">{{ item.species }}</span>
                    <span class="text-[10px] text-[#A8B0AF] italic ml-1">({{ item.latin }})</span>
                  </div>
                  <div class="text-right font-bold text-[#BFD2D5]">
                    {{ item.weightKg }} KG
                    <span class="text-[10px] text-[#C0923D] font-normal ml-1">(£{{ item.avgPricePerKg }}/kg)</span>
                  </div>
                </div>

                <!-- Quota Bar -->
                <div class="flex items-center gap-2 text-[10px] text-[#A8B0AF]">
                  <div class="flex-1 bg-white/10 rounded-full h-1.5 overflow-hidden">
                    <div
                      class="h-full rounded-full transition-all"
                      [style.background-color]="item.colorHex"
                      [style.width.%]="(item.weightKg / item.quotaAllocatedKg) * 100"
                    ></div>
                  </div>
                  <span>{{ ((item.weightKg / item.quotaAllocatedKg) * 100).toFixed(0) }}% QUOTA ({{ item.quotaAllocatedKg }} KG)</span>
                </div>

                <!-- Grade Breakdown -->
                <div class="flex gap-4 text-[10px] text-[#A8B0AF] pt-0.5">
                  <span>GRADE A: <strong class="text-emerald-400">{{ item.gradeA_Kg }} kg</strong></span>
                  <span>GRADE B: <strong class="text-white">{{ item.gradeB_Kg }} kg</strong></span>
                  <span>AVG LENGTH: <strong class="text-white">{{ item.avgLengthCm }} cm</strong></span>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Right: Traceable Batch Passports (5 cols) -->
        <div class="lg:col-span-5 bg-[#171B1D] border border-white/10 rounded-xl p-3 flex flex-col gap-2">
          <div class="flex items-center justify-between border-b border-white/10 pb-1.5 text-xs font-bold text-white">
            <span class="flex items-center gap-1.5 text-[#C96532]">
              <mat-icon class="text-sm! w-4! h-4!">qr_code</mat-icon>
              DIGITAL BATCH PASSPORTS (TRACEABILITY)
            </span>
            <span class="text-[10px] text-emerald-400 bg-emerald-400/20 px-1.5 py-0.5 rounded">RFID SYNC</span>
          </div>

          <div class="flex-1 overflow-y-auto space-y-2 text-xs">
            @for (batch of batches(); track batch.batchId) {
              <div class="p-2.5 bg-[#142A35] border border-white/10 rounded flex flex-col gap-1.5">
                <div class="flex justify-between items-center">
                  <strong class="text-white text-xs">{{ batch.batchId }}</strong>
                  <span class="text-[9px] bg-[#46725F]/30 text-[#46725F] px-1.5 py-0.5 rounded font-bold">
                    {{ batch.status }}
                  </span>
                </div>
                <div class="text-[11px] text-[#BFD2D5] font-semibold">{{ batch.species }} — {{ batch.weightKg }} KG</div>
                <div class="grid grid-cols-2 text-[10px] text-[#A8B0AF] gap-y-0.5">
                  <div>HAUL: <span class="text-white">{{ batch.haulId }}</span></div>
                  <div>HOLD: <span class="text-white">{{ batch.coldStoreLocation }}</span></div>
                  <div>TEMP: <span class="text-[#BFD2D5]">{{ batch.temperatureC }}°C</span></div>
                  <div>POS: <span class="text-white">{{ batch.gpsPosition }}</span></div>
                </div>
                <div class="text-[9px] text-[#697276] truncate border-t border-white/5 pt-1">
                  MMO CERT: {{ batch.mmoCatchCertificateRef }} | RFID: {{ batch.rfidUid }}
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }
    `,
  ],
})
export class CatchView {
  private state = inject(TrawlerStateService);

  readonly catchTotals = this.state.catchTotals;
  readonly batches = this.state.catchBatches;
  readonly totalCatchKg = this.state.totalCatchWeightKg;
  readonly grossValue = this.state.computedGrossValueGbp;
}
