import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TrawlerStateService } from './services/trawler-state.service';
import { Header } from './components/header/header';
import { VesselTwin3d } from './components/vessel-twin-3d/vessel-twin-3d';
import { NavigationView } from './components/navigation-view/navigation-view';
import { FishingView } from './components/fishing-view/fishing-view';
import { GearView } from './components/gear-view/gear-view';
import { CatchView } from './components/catch-view/catch-view';
import { ProcessingView } from './components/processing-view/processing-view';
import { ColdStoreView } from './components/cold-store-view/cold-store-view';
import { EnergyView } from './components/energy-view/energy-view';
import { MaintenanceView } from './components/maintenance-view/maintenance-view';
import { ComplianceView } from './components/compliance-view/compliance-view';
import { LogisticsView } from './components/logistics-view/logistics-view';
import { AnalyticsView } from './components/analytics-view/analytics-view';
import { ScenariosView } from './components/scenarios-view/scenarios-view';
import { AssistantView } from './components/assistant-view/assistant-view';
import { KnowledgeView } from './components/knowledge-view/knowledge-view';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    Header,
    VesselTwin3d,
    NavigationView,
    FishingView,
    GearView,
    CatchView,
    ProcessingView,
    ColdStoreView,
    EnergyView,
    MaintenanceView,
    ComplianceView,
    LogisticsView,
    AnalyticsView,
    ScenariosView,
    AssistantView,
    KnowledgeView,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  private state = inject(TrawlerStateService);

  readonly activeTab = this.state.activeTab;
  readonly decisionProposals = this.state.decisionProposals;

  get pendingProposal() {
    return this.decisionProposals().find(
      (p) => p.status === 'AWAITING_AUTHORISATION',
    );
  }

  approve(id: string) {
    this.state.approveProposal(id);
  }

  reject(id: string) {
    this.state.rejectProposal(id);
  }
}
