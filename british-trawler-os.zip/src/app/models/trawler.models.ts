export type AutonomyLevel = 'MANUAL' | 'ASSISTED' | 'SUPERVISED_AUTONOMY' | 'SIMULATION_AUTONOMY';

export type TrawlStage =
  | 'PREPARE'
  | 'LOWER_GEAR'
  | 'DEPLOY'
  | 'SET_DEPTH'
  | 'TOW'
  | 'MONITOR'
  | 'HAUL'
  | 'RECOVER'
  | 'SORT'
  | 'PROCESS'
  | 'STORE';

export type CameraViewMode =
  | 'EXTERIOR'
  | 'DECK'
  | 'BRIDGE'
  | 'ENGINE_ROOM'
  | 'FISH_PROCESSING'
  | 'COLD_STORE'
  | 'MACHINERY'
  | 'SUBSEA_TRAWL';

export interface VesselSpecs {
  name: string;
  hullNo: string;
  callsign: string;
  mmsi: string;
  flag: string;
  portOfRegistry: string;
  registrationNumber: string;
  loa: number; // meters (64.8)
  beam: number; // meters (14.2)
  draft: number; // meters (6.8)
  grossTonnage: number; // 1840 GT
  mainEngine: string;
  totalPowerKw: number;
  auxGenerators: string;
  batteryCapacityKwh: number;
  trawlGear: string;
  holdCapacityM3: number;
  holdCapacityTonnes: number;
  classSociety: string;
}

export interface NavigationState {
  lat: number;
  lon: number;
  heading: number; // degrees
  cog: number; // course over ground
  sog: number; // speed over ground in knots
  targetSpeed: number;
  destination: string;
  distanceToPortNm: number;
  etaHours: number;
  activeZoneId: string;
  activeZoneName: string;
  depthM: number;
  seabedType: 'Sand' | 'Mud' | 'Gravel' | 'Mixed Demersal' | 'Rock';
  underwaterCurrentKt: number;
  underwaterCurrentDir: number;
}

export interface WeatherState {
  windKnots: number;
  windGusts: number;
  windDirectionDeg: number;
  waveHeightM: number;
  wavePeriodSec: number;
  swellHeightM: number;
  swellDirectionDeg: number;
  seaState: number; // 1 to 7 Beaufort scale
  visibilityNm: number;
  airTempC: number;
  seaTempC: number;
  barometerHpa: number;
  forecastTrend: 'IMPROVING' | 'STABLE' | 'DETERIORATING' | 'GALE_WARNING';
}

export interface TrawlPhysics {
  stage: TrawlStage;
  stageProgress: number; // 0-100%
  doorSpreadM: number; // nominal 120m
  netOpeningHeightM: number; // nominal 6.5m
  headropeDepthM: number; // e.g. 84m
  seabedClearanceM: number; // e.g. 0.8m
  warpLengthPortM: number; // e.g. 480m
  warpLengthStbdM: number; // e.g. 480m
  warpTensionPortKn: number; // e.g. 84.5 kN
  warpTensionStbdKn: number; // e.g. 85.2 kN
  clumpWeightTensionKn: number;
  towSpeedKnots: number;
  codendFillPercent: number; // 0-100%
  sensorCodendS1: boolean;
  sensorCodendS2: boolean;
  sensorCodendS3: boolean;
  sensorCodendS4: boolean;
  acousticBiomassEstimateKg: number;
  haulStartTime: string | null;
  towDurationMinutes: number;
}

export interface WinchUnit {
  id: string;
  name: string;
  lineLengthM: number;
  lineSpeedMps: number;
  tensionKn: number;
  maxTensionKn: number;
  motorLoadPercent: number;
  tempC: number;
  brakeState: 'ENGAGED' | 'DISENGAGED' | 'SLIPPING_TENSION_HOLD';
  drumPositionDeg: number;
  spoolingStatus: 'ALIGNED' | 'CYCLE_LEFT' | 'CYCLE_RIGHT';
  healthScore: number;
}

export interface RoboticDeckArm {
  id: string;
  model: string;
  status: 'IDLE' | 'SORTING' | 'PACKING' | 'FAULT' | 'MAINTENANCE_HOLD';
  jointAngles: [number, number, number, number, number, number];
  cycleTimeSec: number;
  throughputKgH: number;
  payloadKg: number;
  maxPayloadKg: number;
  collisionStatus: 'CLEAR' | 'PROXIMITY_SLOW' | 'E_STOP';
  currentTask: string;
  errorDescription?: string;
}

export interface VisionDetection {
  detectionId: string;
  timestamp: string;
  species: string;
  latinName: string;
  confidence: number;
  estimatedLengthCm: number;
  estimatedMassKg: number;
  grade: 'A' | 'B' | 'C' | 'UNDERSIZE';
  destinationBin: string;
  boundingBox: { x: number; y: number; width: number; height: number };
  requiresHumanReview: boolean;
  reviewReason?: string;
}

export interface CatchSpeciesTotal {
  species: string;
  latin: string;
  weightKg: number;
  gradeA_Kg: number;
  gradeB_Kg: number;
  undersizeKg: number;
  avgLengthCm: number;
  avgPricePerKg: number;
  quotaAllocatedKg: number;
  colorHex: string;
}

export interface CatchBatchPassport {
  batchId: string; // e.g. NS-260926-0041
  haulId: string;
  vessel: string;
  species: string;
  weightKg: number;
  grade: string;
  catchTimestamp: string;
  processingLine: string;
  coldStoreLocation: string;
  temperatureC: number;
  rfidUid: string;
  mmoCatchCertificateRef: string;
  status: 'PROCESSING' | 'BLAST_FREEZING' | 'STORED' | 'READY_FOR_LANDING' | 'AUCTIONED';
  gpsPosition: string;
}

export interface ColdStoreZone {
  id: string;
  name: string;
  targetTempC: number;
  currentTempC: number;
  capacityKg: number;
  currentWeightKg: number;
  utilizationPercent: number;
  energyKw: number;
  doorState: 'CLOSED' | 'SEALED' | 'OPEN';
  refrigerantCircuit: 'CO2_CIRCUIT_1' | 'NH3_PRIMARY' | 'GLYCOL_SECONDARY';
  alarmStatus: 'NORMAL' | 'WARNING_HIGH_TEMP' | 'DEFROST_CYCLE';
}

export interface PropulsionEngine {
  model: string;
  rpm: number;
  targetRpm: number;
  loadPercent: number;
  fuelFlowLitersPerHour: number;
  coolantTempC: number;
  oilPressureBar: number;
  exhaustTempC: number;
  totalRunHours: number;
  specificFuelConsumptionGkwh: number;
}

export interface GeneratorUnit {
  id: string;
  name: string;
  outputKw: number;
  maxKw: number;
  loadPercent: number;
  voltageV: number;
  frequencyHz: number;
  status: 'ONLINE' | 'STANDBY' | 'TRIPPED';
  fuelFlowLph: number;
}

export interface EnergyMetrics {
  totalPowerDemandKw: number;
  propulsionKw: number;
  refrigerationKw: number;
  hydraulicsKw: number;
  roboticsKw: number;
  hotelLoadKw: number;
  batterySocPercent: number;
  batteryPowerKw: number; // + charging, - discharging
  kwhPerKgCatch: number;
  fuelLitersPerTonneLanded: number;
  co2KgPerTonneCatch: number;
}

export interface MaintenanceAsset {
  id: string;
  name: string;
  category: 'PROPULSION' | 'DECK_MACHINERY' | 'REFRIGERATION' | 'ROBOTICS' | 'NAVIGATION' | 'HYDRAULICS';
  healthScore: number; // 0-100
  runHours: number;
  serviceIntervalHours: number;
  hoursUntilService: number;
  tempC: number;
  vibrationMmS: number;
  status: 'HEALTHY' | 'ADVISORY' | 'WARNING' | 'FAULT';
  lastServiceDate: string;
  faultDescription?: string;
  mitigationRecommendation?: string;
}

export interface ELogReport {
  id: string;
  type: 'DEP' | 'FAR' | 'DIS' | 'COE' | 'COX' | 'PNO' | 'EOF' | 'RTP' | 'RLC' | 'TRA' | 'LAN';
  description: string;
  timestamp: string;
  status: 'QUEUED' | 'TRANSMITTING' | 'ACK' | 'NAK' | 'PENDING';
  ackRef: string | null;
  payloadSummary: string;
  rejectionReason?: string;
}

export interface VMSTelemetry {
  status: 'CONNECTED' | 'RECONNECTING' | 'SIMULATED_OUTAGE';
  cadenceMinutes: number;
  satelliteTransceiver: string;
  signalStrengthDbm: number;
  lastTransmissionUtc: string;
  nextScheduledUtc: string;
  lat: number;
  lon: number;
  sog: number;
  cog: number;
  mmoVerified: boolean;
}

export interface AISTarget {
  mmsi: string;
  name: string;
  type: 'Trawler' | 'Cargo' | 'Tanker' | 'Guard Vessel' | 'Windfarm Crew Vessel';
  lat: number;
  lon: number;
  rangeNm: number;
  bearingDeg: number;
  cog: number;
  sog: number;
  cpaNm: number; // closest point of approach
  tcpaMinutes: number; // time to CPA
  riskLevel: 'LOW' | 'CAUTION' | 'CRITICAL_COLLISION_RISK';
}

export interface AutonomousDecisionProposal {
  id: string;
  timestamp: string;
  proposalType: 'ROUTE_CHANGE' | 'HAUL_DECISION' | 'WEATHER_DIVERSION' | 'ROBOTIC_REALLOCATION' | 'SPEED_OPTIMISATION';
  headline: string;
  rationaleWhy: string;
  dataInputsUsed: string[];
  projectedOutcome: string;
  riskFactor: 'LOW' | 'MODERATE' | 'HIGH';
  status: 'AWAITING_AUTHORISATION' | 'APPROVED_BY_OPERATOR' | 'REJECTED_BY_OPERATOR' | 'EXECUTED';
}

export interface TripEconomics {
  tripId: string;
  grossCatchValueGbp: number;
  gradeAPremiumGbp: number;
  fuelCostGbp: number;
  iceAndSuppliesGbp: number;
  portLandingDuesGbp: number;
  maintenanceReserveGbp: number;
  crewShareAllocationGbp: number;
  netTripProfitGbp: number;
  projectedRoiPercent: number;
}

export interface TripEvent {
  id: string;
  timestamp: string;
  category: 'NAVIGATION' | 'FISHING' | 'ROBOTICS' | 'COLD_CHAIN' | 'COMPLIANCE' | 'ALERT' | 'DECISION';
  summary: string;
  details: string;
  severity: 'INFO' | 'SUCCESS' | 'WARNING' | 'CRITICAL';
}

export interface FishSpeciesInfo {
  id: string;
  name: string;
  latin: string;
  marketCode: string;
  typicalSizeCm: string;
  minLandingSizeCm: number;
  habitat: string;
  northSeaZonePreference: string;
  qualityFactors: string;
  handlingProtocol: string;
  marketPriceRangeGbpKg: string;
  ukMmoQuotaCategory: string;
}

export interface MaritimeManualArticle {
  id: string;
  title: string;
  category: 'NAVAL_ARCHITECTURE' | 'AUTONOMOUS_TRAWLING' | 'ROBOTIC_PROCESSING' | 'COLD_CHAIN_CO2' | 'UK_MMO_ERS' | 'SAFETY_ISM';
  author: string;
  summary: string;
  content: string;
}
