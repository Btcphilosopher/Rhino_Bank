import { Injectable, computed, signal } from '@angular/core';
import {
  AISTarget,
  AutonomyLevel,
  AutonomousDecisionProposal,
  CameraViewMode,
  CatchBatchPassport,
  CatchSpeciesTotal,
  ColdStoreZone,
  ELogReport,
  EnergyMetrics,
  GeneratorUnit,
  MaintenanceAsset,
  NavigationState,
  PropulsionEngine,
  RoboticDeckArm,
  TrawlPhysics,
  TripEconomics,
  TripEvent,
  VesselSpecs,
  VisionDetection,
  VMSTelemetry,
  WeatherState,
  WinchUnit,
} from '../models/trawler.models';

@Injectable({
  providedIn: 'root',
})
export class TrawlerStateService {
  // Core Simulation Control
  readonly isRunning = signal<boolean>(true);
  readonly timeMultiplier = signal<number>(1); // 1x, 2x, 5x, 10x
  readonly activeTab = signal<string>('VESSEL');
  readonly cameraViewMode = signal<CameraViewMode>('EXTERIOR');
  readonly autonomyLevel = signal<AutonomyLevel>('SUPERVISED_AUTONOMY');
  readonly simulationUtc = signal<Date>(new Date());
  readonly tripDay = signal<number>(4);
  readonly tripId = signal<string>('TRIP-2026-026');

  // Vessel Specs
  readonly specs = signal<VesselSpecs>({
    name: 'FV NORTH STAR',
    hullNo: 'UK-BTO-2026-N04',
    callsign: 'MNST4',
    mmsi: '232094820',
    flag: 'United Kingdom (UK)',
    portOfRegistry: 'Peterhead',
    registrationNumber: 'PD 412',
    loa: 64.8,
    beam: 14.2,
    draft: 6.8,
    grossTonnage: 1840,
    mainEngine: 'Bergen B33:45L8P Hybrid Diesel-Electric (3,200 kW)',
    totalPowerKw: 3200,
    auxGenerators: '2x Scania DI16 (640 kWe each) + 850 kWh Peak-Shaving ESS',
    batteryCapacityKwh: 850,
    trawlGear: 'Twin-rig demersal high-lift trawl with Morgère steerable clump',
    holdCapacityM3: 980,
    holdCapacityTonnes: 450,
    classSociety: "Lloyd's Register ✠ 100A1 Fishing Vessel, UMS, ICE-1B",
  });

  // Navigation & Location
  readonly navigation = signal<NavigationState>({
    lat: 56.8421,
    lon: 1.4820,
    heading: 287.4,
    cog: 286.9,
    sog: 9.4,
    targetSpeed: 9.5,
    destination: 'Port of Peterhead (Quay 3)',
    distanceToPortNm: 114.2,
    etaHours: 12.1,
    activeZoneId: 'ZONE-N04',
    activeZoneName: 'Zone N-04 (Fladen Ground / Demersal)',
    depthM: 86.4,
    seabedType: 'Sand',
    underwaterCurrentKt: 1.4,
    underwaterCurrentDir: 160,
  });

  // Weather & Hydrodynamics
  readonly weather = signal<WeatherState>({
    windKnots: 18.5,
    windGusts: 24.2,
    windDirectionDeg: 310,
    waveHeightM: 2.3,
    wavePeriodSec: 7.4,
    swellHeightM: 2.1,
    swellDirectionDeg: 320,
    seaState: 3,
    visibilityNm: 8.5,
    airTempC: 9.2,
    seaTempC: 8.4,
    barometerHpa: 1008.2,
    forecastTrend: 'STABLE',
  });

  // Trawl Subsea Physics & Geometry
  readonly trawlPhysics = signal<TrawlPhysics>({
    stage: 'TOW',
    stageProgress: 68,
    doorSpreadM: 118.4,
    netOpeningHeightM: 6.2,
    headropeDepthM: 79.8,
    seabedClearanceM: 0.6,
    warpLengthPortM: 480,
    warpLengthStbdM: 480,
    warpTensionPortKn: 84.5,
    warpTensionStbdKn: 85.2,
    clumpWeightTensionKn: 42.1,
    towSpeedKnots: 3.4,
    codendFillPercent: 74,
    sensorCodendS1: true,
    sensorCodendS2: true,
    sensorCodendS3: true,
    sensorCodendS4: false,
    acousticBiomassEstimateKg: 2850,
    haulStartTime: '2026-09-26T02:30:00Z',
    towDurationMinutes: 135,
  });

  // Deck Winches
  readonly winches = signal<WinchUnit[]>([
    {
      id: 'WINCH-01-PORT',
      name: 'Port Main Trawl Warp Winch (45t)',
      lineLengthM: 480,
      lineSpeedMps: 0.0,
      tensionKn: 84.5,
      maxTensionKn: 240,
      motorLoadPercent: 68,
      tempC: 48.2,
      brakeState: 'ENGAGED',
      drumPositionDeg: 142,
      spoolingStatus: 'ALIGNED',
      healthScore: 98,
    },
    {
      id: 'WINCH-02-STBD',
      name: 'Starboard Main Trawl Warp Winch (45t)',
      lineLengthM: 480,
      lineSpeedMps: 0.0,
      tensionKn: 85.2,
      maxTensionKn: 240,
      motorLoadPercent: 69,
      tempC: 49.1,
      brakeState: 'ENGAGED',
      drumPositionDeg: 146,
      spoolingStatus: 'ALIGNED',
      healthScore: 97,
    },
    {
      id: 'WINCH-03-NETDRUM-PORT',
      name: 'Port Net Drum (30 m³)',
      lineLengthM: 0,
      lineSpeedMps: 0.0,
      tensionKn: 12.0,
      maxTensionKn: 180,
      motorLoadPercent: 14,
      tempC: 32.4,
      brakeState: 'ENGAGED',
      drumPositionDeg: 0,
      spoolingStatus: 'ALIGNED',
      healthScore: 99,
    },
    {
      id: 'WINCH-04-NETDRUM-STBD',
      name: 'Starboard Net Drum (30 m³)',
      lineLengthM: 0,
      lineSpeedMps: 0.0,
      tensionKn: 11.5,
      maxTensionKn: 180,
      motorLoadPercent: 12,
      tempC: 31.8,
      brakeState: 'ENGAGED',
      drumPositionDeg: 0,
      spoolingStatus: 'ALIGNED',
      healthScore: 99,
    },
    {
      id: 'WINCH-05-GILSON',
      name: 'Gilson Auxiliary Hoist (25t)',
      lineLengthM: 18,
      lineSpeedMps: 0.0,
      tensionKn: 8.4,
      maxTensionKn: 120,
      motorLoadPercent: 8,
      tempC: 28.5,
      brakeState: 'ENGAGED',
      drumPositionDeg: 78,
      spoolingStatus: 'ALIGNED',
      healthScore: 99,
    },
  ]);

  // Robotics & Deck Automation
  readonly robotArm = signal<RoboticDeckArm>({
    id: 'DR-04',
    model: 'KUKA/MacGregor Marine 6-Axis KR-Quantec Heavy-Sea Edition',
    status: 'SORTING',
    jointAngles: [14.2, -45.1, 88.4, 0.5, 32.1, 180.0],
    cycleTimeSec: 1.42,
    throughputKgH: 1850,
    payloadKg: 4.8,
    maxPayloadKg: 60.0,
    collisionStatus: 'CLEAR',
    currentTask: 'High-speed demersal sorting to Chute #1 (Haddock Grade A)',
  });

  // Vision System (Vision-07 Camera Feed)
  readonly visionDetections = signal<VisionDetection[]>([
    {
      detectionId: 'DET-9812',
      timestamp: '04:42:18 UTC',
      species: 'Haddock',
      latinName: 'Melanogrammus aeglefinus',
      confidence: 0.94,
      estimatedLengthCm: 54,
      estimatedMassKg: 1.84,
      grade: 'A',
      destinationBin: 'CHUTE-01 (Grade A Haddock)',
      boundingBox: { x: 28, y: 32, width: 44, height: 38 },
      requiresHumanReview: false,
    },
    {
      detectionId: 'DET-9811',
      timestamp: '04:42:16 UTC',
      species: 'Cod',
      latinName: 'Gadus morhua',
      confidence: 0.96,
      estimatedLengthCm: 68,
      estimatedMassKg: 3.42,
      grade: 'A',
      destinationBin: 'CHUTE-02 (Grade A Cod)',
      boundingBox: { x: 18, y: 22, width: 58, height: 46 },
      requiresHumanReview: false,
    },
    {
      detectionId: 'DET-9810',
      timestamp: '04:42:14 UTC',
      species: 'Plaice',
      latinName: 'Pleuronectes platessa',
      confidence: 0.91,
      estimatedLengthCm: 38,
      estimatedMassKg: 0.78,
      grade: 'A',
      destinationBin: 'CHUTE-03 (Flatfish)',
      boundingBox: { x: 35, y: 40, width: 32, height: 28 },
      requiresHumanReview: false,
    },
    {
      detectionId: 'DET-9809',
      timestamp: '04:42:11 UTC',
      species: 'Whiting / Haddock juvenile',
      latinName: 'Merlangius / Melanogrammus',
      confidence: 0.61,
      estimatedLengthCm: 28,
      estimatedMassKg: 0.32,
      grade: 'UNDERSIZE',
      destinationBin: 'DISCARD_HOPPER_EXEMPT',
      boundingBox: { x: 42, y: 48, width: 26, height: 22 },
      requiresHumanReview: true,
      reviewReason: 'Confidence 61% below 80% automated threshold — verify minimum landing size (27cm)',
    },
  ]);

  // Catch Totals
  readonly catchTotals = signal<CatchSpeciesTotal[]>([
    {
      species: 'Haddock',
      latin: 'Melanogrammus aeglefinus',
      weightKg: 4218,
      gradeA_Kg: 3650,
      gradeB_Kg: 568,
      undersizeKg: 0,
      avgLengthCm: 54,
      avgPricePerKg: 3.85,
      quotaAllocatedKg: 6500,
      colorHex: '#35677A',
    },
    {
      species: 'Cod',
      latin: 'Gadus morhua',
      weightKg: 2841,
      gradeA_Kg: 2420,
      gradeB_Kg: 421,
      undersizeKg: 0,
      avgLengthCm: 68,
      avgPricePerKg: 5.40,
      quotaAllocatedKg: 3500,
      colorHex: '#46725F',
    },
    {
      species: 'Plaice',
      latin: 'Pleuronectes platessa',
      weightKg: 1124,
      gradeA_Kg: 980,
      gradeB_Kg: 144,
      undersizeKg: 0,
      avgLengthCm: 38,
      avgPricePerKg: 2.95,
      quotaAllocatedKg: 2800,
      colorHex: '#C0923D',
    },
    {
      species: 'Monkfish (Anglerfish)',
      latin: 'Lophius piscatorius',
      weightKg: 842,
      gradeA_Kg: 810,
      gradeB_Kg: 32,
      undersizeKg: 0,
      avgLengthCm: 72,
      avgPricePerKg: 7.60,
      quotaAllocatedKg: 1600,
      colorHex: '#C96532',
    },
    {
      species: 'Whiting',
      latin: 'Merlangius merlangus',
      weightKg: 580,
      gradeA_Kg: 490,
      gradeB_Kg: 90,
      undersizeKg: 12,
      avgLengthCm: 34,
      avgPricePerKg: 2.10,
      quotaAllocatedKg: 1500,
      colorHex: '#A8B0AF',
    },
    {
      species: 'Hake / Saithe / Mixed',
      latin: 'Merluccius / Pollachius',
      weightKg: 513,
      gradeA_Kg: 380,
      gradeB_Kg: 133,
      undersizeKg: 0,
      avgLengthCm: 48,
      avgPricePerKg: 2.40,
      quotaAllocatedKg: 2000,
      colorHex: '#697276',
    },
  ]);

  // Traceable Batch Passports
  readonly catchBatches = signal<CatchBatchPassport[]>([
    {
      batchId: 'NS-260926-0041',
      haulId: 'H-05',
      vessel: 'FV NORTH STAR',
      species: 'Haddock (Grade A)',
      weightKg: 842,
      grade: 'Grade A (50-60cm)',
      catchTimestamp: '2026-09-25T09:15:00Z',
      processingLine: 'Robotic Line 02 / Slurry Ice Pack',
      coldStoreLocation: 'FREEZER HOLD 01 (Bay 3, Rack A)',
      temperatureC: -24.8,
      rfidUid: 'E2806894000040182A9C',
      mmoCatchCertificateRef: 'UK-CC-2026-008914',
      status: 'READY_FOR_LANDING',
      gpsPosition: '56°50.5N 001°28.9E',
    },
    {
      batchId: 'NS-260926-0040',
      haulId: 'H-04',
      vessel: 'FV NORTH STAR',
      species: 'Cod (Grade A Large)',
      weightKg: 1240,
      grade: 'Grade A (>65cm)',
      catchTimestamp: '2026-09-24T12:30:00Z',
      processingLine: 'Robotic Line 01 / Blast Freeze',
      coldStoreLocation: 'FREEZER HOLD 01 (Bay 1, Rack B)',
      temperatureC: -25.2,
      rfidUid: 'E2806894000040182A8F',
      mmoCatchCertificateRef: 'UK-CC-2026-008910',
      status: 'READY_FOR_LANDING',
      gpsPosition: '56°48.2N 001°22.1E',
    },
    {
      batchId: 'NS-260926-0039',
      haulId: 'H-04',
      vessel: 'FV NORTH STAR',
      species: 'Monkfish (Tails & Whole)',
      weightKg: 460,
      grade: 'Grade A Premium',
      catchTimestamp: '2026-09-24T14:10:00Z',
      processingLine: 'Manual Trimming + Robotic Packing',
      coldStoreLocation: 'CHILLED HOLD (Bin 04)',
      temperatureC: -1.2,
      rfidUid: 'E2806894000040182A7D',
      mmoCatchCertificateRef: 'UK-CC-2026-008906',
      status: 'READY_FOR_LANDING',
      gpsPosition: '56°48.2N 001°22.1E',
    },
    {
      batchId: 'NS-260926-0038',
      haulId: 'H-03',
      vessel: 'FV NORTH STAR',
      species: 'Plaice (Grade A)',
      weightKg: 620,
      grade: 'Grade A (35-42cm)',
      catchTimestamp: '2026-09-24T03:45:00Z',
      processingLine: 'Robotic Line 01 / Ice Slurry',
      coldStoreLocation: 'FREEZER HOLD 02 (Bay 2, Rack A)',
      temperatureC: -24.4,
      rfidUid: 'E2806894000040182A6C',
      mmoCatchCertificateRef: 'UK-CC-2026-008899',
      status: 'READY_FOR_LANDING',
      gpsPosition: '56°44.0N 001°15.8E',
    },
  ]);

  // Cold Chain Refrigeration Hold
  readonly coldStoreZones = signal<ColdStoreZone[]>([
    {
      id: 'FREEZER-01',
      name: 'Main Low-Temp Freezer Hold 01',
      targetTempC: -25.0,
      currentTempC: -24.8,
      capacityKg: 200000,
      currentWeightKg: 132400,
      utilizationPercent: 66.2,
      energyKw: 48.5,
      doorState: 'CLOSED',
      refrigerantCircuit: 'CO2_CIRCUIT_1',
      alarmStatus: 'NORMAL',
    },
    {
      id: 'FREEZER-02',
      name: 'Secondary Low-Temp Freezer Hold 02',
      targetTempC: -25.0,
      currentTempC: -24.6,
      capacityKg: 180000,
      currentWeightKg: 112000,
      utilizationPercent: 62.2,
      energyKw: 44.0,
      doorState: 'CLOSED',
      refrigerantCircuit: 'CO2_CIRCUIT_1',
      alarmStatus: 'NORMAL',
    },
    {
      id: 'CHILLED-HOLD',
      name: 'Fresh Chilled Hold (Ice Slurry Boxes)',
      targetTempC: -0.5,
      currentTempC: -0.8,
      capacityKg: 50000,
      currentWeightKg: 34200,
      utilizationPercent: 68.4,
      energyKw: 18.2,
      doorState: 'CLOSED',
      refrigerantCircuit: 'GLYCOL_SECONDARY',
      alarmStatus: 'NORMAL',
    },
    {
      id: 'BLAST-FREEZER',
      name: 'Plate & Tunnel Blast Freezer Unit',
      targetTempC: -38.0,
      currentTempC: -36.9,
      capacityKg: 15000,
      currentWeightKg: 4800,
      utilizationPercent: 32.0,
      energyKw: 62.0,
      doorState: 'SEALED',
      refrigerantCircuit: 'NH3_PRIMARY',
      alarmStatus: 'NORMAL',
    },
    {
      id: 'ICE-SILO',
      name: 'Automated Fluid Ice Maker & Silo (50t)',
      targetTempC: -2.0,
      currentTempC: -2.4,
      capacityKg: 50000,
      currentWeightKg: 38500,
      utilizationPercent: 77.0,
      energyKw: 22.5,
      doorState: 'CLOSED',
      refrigerantCircuit: 'GLYCOL_SECONDARY',
      alarmStatus: 'NORMAL',
    },
  ]);

  // Propulsion & Engine Room
  readonly propulsion = signal<PropulsionEngine>({
    model: 'Bergen B33:45L8P Hybrid Common-Rail Marine Diesel',
    rpm: 680,
    targetRpm: 680,
    loadPercent: 62.4,
    fuelFlowLitersPerHour: 342.0,
    coolantTempC: 84.2,
    oilPressureBar: 4.8,
    exhaustTempC: 382,
    totalRunHours: 4218,
    specificFuelConsumptionGkwh: 172.5,
  });

  readonly generators = signal<GeneratorUnit[]>([
    {
      id: 'GEN-01',
      name: 'Auxiliary GenSet 01 (Scania DI16)',
      outputKw: 371,
      maxKw: 640,
      loadPercent: 58.0,
      voltageV: 440,
      frequencyHz: 50.0,
      status: 'ONLINE',
      fuelFlowLph: 74.2,
    },
    {
      id: 'GEN-02',
      name: 'Auxiliary GenSet 02 (Scania DI16)',
      outputKw: 0,
      maxKw: 640,
      loadPercent: 0.0,
      voltageV: 0,
      frequencyHz: 0.0,
      status: 'STANDBY',
      fuelFlowLph: 0.0,
    },
    {
      id: 'SHAFT-GEN',
      name: 'Permanent Magnet Shaft Generator / PTO',
      outputKw: 580,
      maxKw: 1200,
      loadPercent: 48.3,
      voltageV: 690,
      frequencyHz: 50.0,
      status: 'ONLINE',
      fuelFlowLph: 0.0,
    },
  ]);

  readonly energyMetrics = signal<EnergyMetrics>({
    totalPowerDemandKw: 1146,
    propulsionKw: 780,
    refrigerationKw: 195,
    hydraulicsKw: 92,
    roboticsKw: 28,
    hotelLoadKw: 51,
    batterySocPercent: 88.5,
    batteryPowerKw: -34.0, // peak shaving discharging
    kwhPerKgCatch: 0.465,
    fuelLitersPerTonneLanded: 142.8,
    co2KgPerTonneCatch: 382.4,
  });

  // Planned Maintenance System (PMS)
  readonly maintenanceAssets = signal<MaintenanceAsset[]>([
    {
      id: 'PMS-ENG-01',
      name: 'Bergen Main Propulsion Diesel Engine',
      category: 'PROPULSION',
      healthScore: 94,
      runHours: 4218,
      serviceIntervalHours: 5000,
      hoursUntilService: 782,
      tempC: 84.2,
      vibrationMmS: 2.1,
      status: 'HEALTHY',
      lastServiceDate: '12 Aug 2026 (Peterhead Dock)',
    },
    {
      id: 'PMS-WINCH-01',
      name: 'Port Warp Winch Hydraulic Drive & Drum',
      category: 'DECK_MACHINERY',
      healthScore: 96,
      runHours: 1280,
      serviceIntervalHours: 2000,
      hoursUntilService: 720,
      tempC: 48.2,
      vibrationMmS: 1.8,
      status: 'HEALTHY',
      lastServiceDate: '28 Aug 2026',
    },
    {
      id: 'PMS-ROBOT-04',
      name: 'Robotic Sorter Arm DR-04 (6-Axis)',
      category: 'ROBOTICS',
      healthScore: 92,
      runHours: 840,
      serviceIntervalHours: 1500,
      hoursUntilService: 660,
      tempC: 38.4,
      vibrationMmS: 0.9,
      status: 'HEALTHY',
      lastServiceDate: '04 Sep 2026',
    },
    {
      id: 'PMS-REF-01',
      name: 'CO2 Hold Refrigeration Compressor Unit #1',
      category: 'REFRIGERATION',
      healthScore: 89,
      runHours: 3410,
      serviceIntervalHours: 4000,
      hoursUntilService: 590,
      tempC: 62.1,
      vibrationMmS: 3.2,
      status: 'ADVISORY',
      lastServiceDate: '15 Jul 2026',
      mitigationRecommendation: 'Suction pressure variance ±0.4 bar; scheduled filter inspection on port return',
    },
    {
      id: 'PMS-HYD-01',
      name: 'High-Pressure Hydraulic Power Pack (HPU)',
      category: 'HYDRAULICS',
      healthScore: 97,
      runHours: 2150,
      serviceIntervalHours: 3000,
      hoursUntilService: 850,
      tempC: 54.0,
      vibrationMmS: 1.4,
      status: 'HEALTHY',
      lastServiceDate: '18 Aug 2026',
    },
    {
      id: 'PMS-SONAR-01',
      name: 'Simrad SN90 Multibeam Catch Sonar Transducer',
      category: 'NAVIGATION',
      healthScore: 99,
      runHours: 1980,
      serviceIntervalHours: 5000,
      hoursUntilService: 3020,
      tempC: 18.2,
      vibrationMmS: 0.2,
      status: 'HEALTHY',
      lastServiceDate: '01 Jun 2026',
    },
  ]);

  // Electronic Logbook (UK ERS)
  readonly eLogQueue = signal<ELogReport[]>([
    {
      id: 'ELOG-01',
      type: 'DEP',
      description: 'Departure Declaration — Port of Peterhead',
      timestamp: '2026-09-22T08:00:00Z',
      status: 'ACK',
      ackRef: 'UK-ERS-ACK-99412',
      payloadSummary: 'Master: Cpt. Alistair MacLeod | 12 Crew | 145m³ Fuel | Fishing Target: Demersal IVa',
    },
    {
      id: 'ELOG-02',
      type: 'COE',
      description: 'Prior Notification Entering North Sea Zone IVa (UK Waters)',
      timestamp: '2026-09-22T14:20:00Z',
      status: 'ACK',
      ackRef: 'UK-ERS-ACK-99450',
      payloadSummary: 'Entry Point: 57°28.0N 000°45.0E | Target Species: Haddock, Cod, Plaice',
    },
    {
      id: 'ELOG-03',
      type: 'FAR',
      description: 'Fishing Activity Report — Hauls H-01 & H-02',
      timestamp: '2026-09-23T19:00:00Z',
      status: 'ACK',
      ackRef: 'UK-ERS-ACK-99518',
      payloadSummary: '3,990 kg Landed equivalent (Haddock 1,820kg, Cod 1,210kg, Plaice 540kg)',
    },
    {
      id: 'ELOG-04',
      type: 'FAR',
      description: 'Fishing Activity Report — Hauls H-03 & H-04',
      timestamp: '2026-09-24T16:30:00Z',
      status: 'ACK',
      ackRef: 'UK-ERS-ACK-99602',
      payloadSummary: '4,400 kg Landed equivalent (Haddock 2,120kg, Cod 1,320kg, Monkfish 480kg)',
    },
    {
      id: 'ELOG-05',
      type: 'DIS',
      description: 'Discard Notification (Undersize Whiting 12kg - survivability exemption)',
      timestamp: '2026-09-24T16:35:00Z',
      status: 'ACK',
      ackRef: 'UK-ERS-ACK-99605',
      payloadSummary: 'Under-MLS demersal whiting returned under UK Landing Obligation Art. 15 survivability clause',
    },
    {
      id: 'ELOG-06',
      type: 'FAR',
      description: 'Fishing Activity Report — Haul H-05',
      timestamp: '2026-09-25T12:00:00Z',
      status: 'ACK',
      ackRef: 'UK-ERS-ACK-99688',
      payloadSummary: '1,728 kg Landed equivalent (Haddock 842kg, Cod 411kg, Plaice 290kg)',
    },
    {
      id: 'ELOG-07',
      type: 'PNO',
      description: 'Prior Notification of Landing (PNO) — Port of Peterhead',
      timestamp: '2026-09-26T04:15:00Z',
      status: 'ACK',
      ackRef: 'UK-ERS-ACK-99742',
      payloadSummary: 'Estimated Arrival: 26-Sep-2026 18:30 UTC | Quay 3 Demersal Auction Hall | Est. Catch: 10,118 kg',
    },
    {
      id: 'ELOG-08',
      type: 'LAN',
      description: 'Landing Declaration Manifest (Pre-Arrival Staging)',
      timestamp: '2026-09-26T04:30:00Z',
      status: 'QUEUED',
      ackRef: null,
      payloadSummary: 'Detailed batch weights ready for shore auction terminal automated handshake upon mooring',
    },
  ]);

  // Vessel Monitoring System (VMS)
  readonly vms = signal<VMSTelemetry>({
    status: 'CONNECTED',
    cadenceMinutes: 15,
    satelliteTransceiver: 'Iridium Certus Marine 100 Class-A VMS',
    signalStrengthDbm: -71.4,
    lastTransmissionUtc: '04:30:00 UTC',
    nextScheduledUtc: '04:45:00 UTC',
    lat: 56.8421,
    lon: 1.4820,
    sog: 9.4,
    cog: 287.4,
    mmoVerified: true,
  });

  // AIS Radar & Traffic
  readonly aisTargets = signal<AISTarget[]>([
    {
      mmsi: '235084920',
      name: 'MV NORTH SEA TRADER',
      type: 'Cargo',
      lat: 56.8812,
      lon: 1.5910,
      rangeNm: 4.8,
      bearingDeg: 31,
      cog: 214,
      sog: 12.1,
      cpaNm: 2.1,
      tcpaMinutes: 18.4,
      riskLevel: 'LOW',
    },
    {
      mmsi: '232049102',
      name: 'FV ALTAIR (FR 12)',
      type: 'Trawler',
      lat: 56.8120,
      lon: 1.3940,
      rangeNm: 3.6,
      bearingDeg: 242,
      cog: 95,
      sog: 3.2,
      cpaNm: 1.8,
      tcpaMinutes: 24.0,
      riskLevel: 'LOW',
    },
    {
      mmsi: '235198421',
      name: 'PACIFIC ENVOY',
      type: 'Tanker',
      lat: 56.9140,
      lon: 1.4200,
      rangeNm: 5.2,
      bearingDeg: 348,
      cog: 180,
      sog: 14.2,
      cpaNm: 1.4,
      tcpaMinutes: 14.8,
      riskLevel: 'CAUTION',
    },
    {
      mmsi: '232110940',
      name: 'SEAWAY GUARDIAN',
      type: 'Guard Vessel',
      lat: 56.7890,
      lon: 1.6200,
      rangeNm: 6.1,
      bearingDeg: 128,
      cog: 45,
      sog: 8.0,
      cpaNm: 4.5,
      tcpaMinutes: 38.0,
      riskLevel: 'LOW',
    },
  ]);

  // Autonomous Decision Proposals
  readonly decisionProposals = signal<AutonomousDecisionProposal[]>([
    {
      id: 'DEC-2026-089',
      timestamp: '04:35:10 UTC',
      proposalType: 'HAUL_DECISION',
      headline: 'Execute Haul Sequence within 45 minutes to optimize codend quality and yield',
      rationaleWhy: 'Simrad Acoustic Sensor S3 triggered (85% fill estimate = ~2.8 tonnes). Towing beyond 180 minutes increases skin scuffing on Grade A Haddock by an estimated 14.2% while fuel consumption increases non-linearly with net drag.',
      dataInputsUsed: [
        'Acoustic Codend Sensors S1/S2/S3 (Nominal Tension: 85.2 kN)',
        'Tow Speed: 3.4 kt vs Optimal Net Opening (6.2m)',
        'Cold Hold Temperature: -24.8°C (Optimal)',
        'Quota Reserve: 2,282 kg remaining in Area IVa',
      ],
      projectedOutcome: 'Yield: +2.8 tonnes demersal catch at 92% Grade A standard. Fuel savings: ~84 Litres vs 4-hour tow.',
      riskFactor: 'LOW',
      status: 'AWAITING_AUTHORISATION',
    },
    {
      id: 'DEC-2026-088',
      timestamp: '04:10:00 UTC',
      proposalType: 'ROUTE_CHANGE',
      headline: 'Adjust Transit Waypoint WP-03 by 2.4 NM North to avoid Forties Pipeline Zone',
      rationaleWhy: 'UK Hydrographic Office notice & subsea acoustic bottom clearance within 400m of gas trunkline corridor.',
      dataInputsUsed: ['ECDIS Vector Chart', 'Bathymetric Sonar Grid', 'UK MCA Safety Buffer Rule #14'],
      projectedOutcome: 'Zero pipeline crossing conflict; ETA delay < 8 minutes.',
      riskFactor: 'LOW',
      status: 'APPROVED_BY_OPERATOR',
    },
  ]);

  // Trip Economics
  readonly economics = signal<TripEconomics>({
    tripId: 'TRIP-2026-026',
    grossCatchValueGbp: 42860,
    gradeAPremiumGbp: 4820,
    fuelCostGbp: 11420,
    iceAndSuppliesGbp: 1850,
    portLandingDuesGbp: 1240,
    maintenanceReserveGbp: 2100,
    crewShareAllocationGbp: 14800,
    netTripProfitGbp: 16270,
    projectedRoiPercent: 38.0,
  });

  // Forensic Event Stream
  readonly eventStream = signal<TripEvent[]>([
    {
      id: 'EVT-101',
      timestamp: '22-Sep 08:00',
      category: 'NAVIGATION',
      summary: 'Vessel Departed Peterhead Quay 3',
      details: 'VMS activated, UK ERS DEP report transmitted and acknowledged (ACK-99412). All autonomous safety checks passed.',
      severity: 'SUCCESS',
    },
    {
      id: 'EVT-102',
      timestamp: '22-Sep 14:20',
      category: 'COMPLIANCE',
      summary: 'Entered Demersal Zone N-02 (Area IVa)',
      details: 'COE report dispatched. Autonomous route following active at 10.2 knots.',
      severity: 'INFO',
    },
    {
      id: 'EVT-103',
      timestamp: '23-Sep 06:30',
      category: 'FISHING',
      summary: 'Haul H-01 Deployed & Hauled',
      details: 'Twin-rig demersal net deployed at 78m depth. Yield: 1,840 kg mixed demersal catch.',
      severity: 'SUCCESS',
    },
    {
      id: 'EVT-104',
      timestamp: '24-Sep 10:45',
      category: 'FISHING',
      summary: 'Haul H-04 Acoustic Target Hit',
      details: 'Simrad multibeam sonar detected dense school. Yield: 2,420 kg high-grade Haddock & Cod.',
      severity: 'SUCCESS',
    },
    {
      id: 'EVT-105',
      timestamp: '25-Sep 08:00',
      category: 'ROBOTICS',
      summary: 'Robotic Sorter DR-04 Completed 12,000 Picks',
      details: 'Throughput averaged 1,850 kg/h with 94.2% optical classification confidence.',
      severity: 'SUCCESS',
    },
    {
      id: 'EVT-106',
      timestamp: '26-Sep 04:15',
      category: 'COMPLIANCE',
      summary: 'PNO Return Notification Transmitted',
      details: 'Dispatched to UK MMO shore hub for Peterhead landing slot 18:30 UTC.',
      severity: 'INFO',
    },
  ]);

  // Total catch weight derived
  readonly totalCatchWeightKg = computed(() => {
    return this.catchTotals().reduce((sum, item) => sum + item.weightKg, 0);
  });

  // Gross catch value derived
  readonly computedGrossValueGbp = computed(() => {
    return this.catchTotals().reduce(
      (sum, item) => sum + item.weightKg * item.avgPricePerKg,
      0,
    );
  });

  // Cold store total fill percentage
  readonly coldStoreFillPercent = computed(() => {
    const totalCap = this.coldStoreZones().reduce((s, z) => s + z.capacityKg, 0);
    const totalCurrent = this.coldStoreZones().reduce((s, z) => s + z.currentWeightKg, 0);
    return Math.round((totalCurrent / totalCap) * 100);
  });

  // Signature Demo State
  readonly signatureDemoActive = signal<boolean>(false);
  readonly signatureDemoStep = signal<number>(0);
  readonly signatureDemoTitle = signal<string>('');

  private timerInterval: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.startSimulationClock();
  }

  startSimulationClock() {
    if (this.timerInterval) clearInterval(this.timerInterval);
    this.timerInterval = setInterval(() => {
      if (this.isRunning()) {
        this.tickSimulation();
      }
    }, 1000);
  }

  toggleSimulation() {
    this.isRunning.update((v) => !v);
  }

  setTimeMultiplier(mult: number) {
    this.timeMultiplier.set(mult);
  }

  setAutonomyLevel(level: AutonomyLevel) {
    this.autonomyLevel.set(level);
    this.addEvent({
      category: 'DECISION',
      summary: `Autonomy Level Switched to ${level.replace(/_/g, ' ')}`,
      details: `Operator changed system operational envelope to ${level}. All automated recommendations require human sign-off where designated.`,
      severity: 'INFO',
    });
  }

  setCameraView(mode: CameraViewMode) {
    this.cameraViewMode.set(mode);
  }

  setActiveTab(tab: string) {
    this.activeTab.set(tab);
  }

  approveProposal(proposalId: string) {
    this.decisionProposals.update((list) =>
      list.map((p) => {
        if (p.id === proposalId) {
          return { ...p, status: 'APPROVED_BY_OPERATOR' as const };
        }
        return p;
      }),
    );

    const proposal = this.decisionProposals().find((p) => p.id === proposalId);
    if (proposal) {
      this.addEvent({
        category: 'DECISION',
        summary: `Operator Approved: ${proposal.headline}`,
        details: `Simulated action initiated: ${proposal.projectedOutcome}`,
        severity: 'SUCCESS',
      });

      if (proposal.proposalType === 'HAUL_DECISION') {
        this.initiateHaulSequence();
      }
    }
  }

  rejectProposal(proposalId: string) {
    this.decisionProposals.update((list) =>
      list.map((p) => {
        if (p.id === proposalId) {
          return { ...p, status: 'REJECTED_BY_OPERATOR' as const };
        }
        return p;
      }),
    );

    this.addEvent({
      category: 'DECISION',
      summary: `Operator Rejected Decision Proposal ${proposalId}`,
      details: 'Vessel will maintain baseline scheduled parameters.',
      severity: 'WARNING',
    });
  }

  initiateHaulSequence() {
    this.trawlPhysics.update((tp) => ({
      ...tp,
      stage: 'HAUL',
      stageProgress: 10,
    }));

    // Update winches to active haul
    this.winches.update((ws) =>
      ws.map((w) => {
        if (w.id.includes('PORT') || w.id.includes('STBD')) {
          return {
            ...w,
            lineSpeedMps: 1.2,
            tensionKn: 112.5,
            motorLoadPercent: 88,
            brakeState: 'DISENGAGED' as const,
          };
        }
        return w;
      }),
    );

    this.addEvent({
      category: 'FISHING',
      summary: 'Automated Haul Sequence Commenced',
      details: 'Warp winches recovering at 1.2 m/s. Clump and Morgère doors rising.',
      severity: 'INFO',
    });
  }

  // Trigger signature demo
  runSignatureDemo() {
    this.signatureDemoActive.set(true);
    this.signatureDemoStep.set(1);
    this.signatureDemoTitle.set('DEPARTURE & TRANSIT TO ZONE N-04');

    this.addEvent({
      category: 'NAVIGATION',
      summary: 'Signature Demo: North Sea Mission Initialised',
      details: 'FV NORTH STAR engaging simulated end-to-end autonomous cycle.',
      severity: 'INFO',
    });

    setTimeout(() => {
      this.signatureDemoStep.set(2);
      this.signatureDemoTitle.set('GEAR DEPLOYMENT & WINCH TOW');
      this.trawlPhysics.update((t) => ({ ...t, stage: 'DEPLOY', stageProgress: 45 }));
    }, 4000);

    setTimeout(() => {
      this.signatureDemoStep.set(3);
      this.signatureDemoTitle.set('ACOUSTIC SONAR HIT & CATCH ENTRY');
      this.trawlPhysics.update((t) => ({ ...t, stage: 'TOW', codendFillPercent: 85, acousticBiomassEstimateKg: 3200 }));
    }, 8000);

    setTimeout(() => {
      this.signatureDemoStep.set(4);
      this.signatureDemoTitle.set('HAUL & ROBOTIC DR-04 SORTING');
      this.trawlPhysics.update((t) => ({ ...t, stage: 'HAUL', stageProgress: 95 }));
      this.robotArm.update((r) => ({ ...r, status: 'SORTING', throughputKgH: 2100 }));
    }, 12000);

    setTimeout(() => {
      this.signatureDemoStep.set(5);
      this.signatureDemoTitle.set('WEATHER SHIFT & RETURN TO PETERHEAD');
      this.weather.update((w) => ({ ...w, windKnots: 28.5, waveHeightM: 3.8, seaState: 5, forecastTrend: 'GALE_WARNING' }));
      this.navigation.update((n) => ({ ...n, heading: 274.0, sog: 10.4, destination: 'Peterhead Quay 3' }));
    }, 16000);

    setTimeout(() => {
      this.signatureDemoStep.set(6);
      this.signatureDemoTitle.set('MISSION COMPLETE — 10.1T LANDED & CERTIFIED');
      this.signatureDemoActive.set(false);
      this.addEvent({
        category: 'COMPLIANCE',
        summary: 'Trip Complete: 10.118 Tonnes Certified',
        details: 'All batches assigned RFID passports. Gross value: £42,860. Fuel EEDI rating: A+.',
        severity: 'SUCCESS',
      });
    }, 20000);
  }

  // Trigger Robot DR-04 failure scenario
  triggerRobotFailureScenario() {
    this.robotArm.update((r) => ({
      ...r,
      status: 'FAULT',
      collisionStatus: 'E_STOP',
      currentTask: 'EMERGENCY HOLD — Joint 3 Resolver Feedback Loss',
      errorDescription: 'Resolver excitation error on Axis 3 (Elbow pitch). Automated safety interlock triggered.',
    }));

    this.maintenanceAssets.update((assets) =>
      assets.map((a) =>
        a.id === 'PMS-ROBOT-04'
          ? {
              ...a,
              status: 'FAULT' as const,
              healthScore: 42,
              faultDescription: 'Joint 3 encoder deviation > 2.4° RMS under high sea pitch',
              mitigationRecommendation: 'Switch to Manual Sorting Chute or assign Secondary Delta Arm DR-05',
            }
          : a,
      ),
    );

    this.addEvent({
      category: 'ALERT',
      summary: 'CRITICAL: Robot Arm DR-04 Fault Detected',
      details: 'Digital twin identifies processing bottleneck. Processing speed drops from 1.85 t/h to manual rate (0.6 t/h). Digital twin recommends activating Chute 02 bypass.',
      severity: 'CRITICAL',
    });
  }

  // Reset robot fault
  resetRobotFault() {
    this.robotArm.update((r) => ({
      ...r,
      status: 'SORTING',
      collisionStatus: 'CLEAR',
      currentTask: 'High-speed demersal sorting to Chute #1 (Haddock Grade A)',
      errorDescription: undefined,
    }));

    this.maintenanceAssets.update((assets) =>
      assets.map((a) =>
        a.id === 'PMS-ROBOT-04'
          ? {
              ...a,
              status: 'HEALTHY' as const,
              healthScore: 94,
              faultDescription: undefined,
              mitigationRecommendation: undefined,
            }
          : a,
      ),
    );

    this.addEvent({
      category: 'ROBOTICS',
      summary: 'Robot Arm DR-04 Calibration Restored',
      details: 'Digital twin recalibrated Axis 3 resolver; conveyor sync normalized.',
      severity: 'SUCCESS',
    });
  }

  addEvent(event: Omit<TripEvent, 'id' | 'timestamp'>) {
    const newEvent: TripEvent = {
      id: `EVT-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
      ...event,
    };
    this.eventStream.update((list) => [newEvent, ...list.slice(0, 49)]);
  }

  // Periodic physics / telemetry updates
  private tickSimulation() {
    const mult = this.timeMultiplier();

    // Advance simulated clock
    const current = this.simulationUtc();
    this.simulationUtc.set(new Date(current.getTime() + 1000 * mult));

    // Dynamic wave oscillation and heading slight yaw
    this.navigation.update((n) => {
      const yaw = Math.sin(Date.now() / 4000) * 0.4;
      const speedJitter = Math.cos(Date.now() / 3000) * 0.05;
      return {
        ...n,
        heading: +(287.4 + yaw).toFixed(1),
        sog: +(9.4 + speedJitter).toFixed(1),
      };
    });

    // Dynamic winch tension variation with simulated wave heave
    const heave = Math.sin(Date.now() / 2500) * 3.5;
    this.winches.update((ws) =>
      ws.map((w) => {
        if (w.id.includes('PORT')) {
          return { ...w, tensionKn: +(84.5 + heave).toFixed(1) };
        }
        if (w.id.includes('STBD')) {
          return { ...w, tensionKn: +(85.2 + heave * 0.95).toFixed(1) };
        }
        return w;
      }),
    );

    // Dynamic robot arm micro-kinematics for live feel
    if (this.robotArm().status === 'SORTING') {
      const t = Date.now() / 800;
      this.robotArm.update((r) => ({
        ...r,
        jointAngles: [
          +(14.2 + Math.sin(t) * 12).toFixed(1),
          +(-45.1 + Math.cos(t * 1.2) * 8).toFixed(1),
          +(88.4 + Math.sin(t * 0.8) * 10).toFixed(1),
          +(Math.sin(t * 1.5) * 5).toFixed(1),
          +(32.1 + Math.cos(t * 1.1) * 6).toFixed(1),
          +((180.0 + Math.sin(t * 2) * 15) % 360).toFixed(1),
        ],
      }));
    }
  }
}
