import { FishSpeciesInfo, MaritimeManualArticle } from '../models/trawler.models';

export const FISH_SPECIES_LIBRARY: FishSpeciesInfo[] = [
  {
    id: 'haddock',
    name: 'Haddock',
    latin: 'Melanogrammus aeglefinus',
    marketCode: 'HAD',
    typicalSizeCm: '35 - 65 cm (Max 100 cm)',
    minLandingSizeCm: 30,
    habitat: 'Demersal, clean sand, gravel and shell bottoms at depths between 40m and 300m.',
    northSeaZonePreference: 'Northern North Sea (Area IVa), Fladen Ground, Shetland Shelf, Viking Bank.',
    qualityFactors: 'High firmness index when chilled in fluid ice slurry within 20 min of landing. Low tolerance for net friction in codend beyond 3.5 hours.',
    handlingProtocol: 'Immediate evisceration, automated bloodline washing, rapid slurry chill to -0.5°C before transfer to blast tunnel or chilled bins.',
    marketPriceRangeGbpKg: '£3.60 - £4.20 / kg (Grade A)',
    ukMmoQuotaCategory: 'UK Demersal Pool IVa / IVb',
  },
  {
    id: 'cod',
    name: 'Atlantic Cod',
    latin: 'Gadus morhua',
    marketCode: 'COD',
    typicalSizeCm: '50 - 90 cm (Max 140 cm)',
    minLandingSizeCm: 35,
    habitat: 'Cold North Sea waters over rocky, pebbly, or sandy bottoms (20m to 400m).',
    northSeaZonePreference: 'Forties, Dogger Bank margins, Viking Deep, Buchan corridors.',
    qualityFactors: 'Flake translucency, high muscle glycogen if harvested without exhaustive stress in trawl.',
    handlingProtocol: 'Optical vision grading for parasite inspection, double wash, bleed tank 12 min, cold hold at -24°C or iced fresh.',
    marketPriceRangeGbpKg: '£5.10 - £6.00 / kg (Grade A Prime)',
    ukMmoQuotaCategory: 'North Sea Cod TAC Allocation',
  },
  {
    id: 'plaice',
    name: 'European Plaice',
    latin: 'Pleuronectes platessa',
    marketCode: 'PLE',
    typicalSizeCm: '28 - 45 cm',
    minLandingSizeCm: 27,
    habitat: 'Sandy and muddy seabeds, burrowing shallow during daylight, active feeding at night.',
    northSeaZonePreference: 'Southern & Central North Sea (Dogger Bank, Silver Pit, German Bight perimeter).',
    qualityFactors: 'Bright red-orange spots, slime layer integrity, absence of belly bruising.',
    handlingProtocol: 'Flat orientation in robotic pick suction array; avoid excessive stacked crate pressure.',
    marketPriceRangeGbpKg: '£2.80 - £3.40 / kg',
    ukMmoQuotaCategory: 'UK Demersal Flatfish Quota',
  },
  {
    id: 'monkfish',
    name: 'Monkfish (Anglerfish)',
    latin: 'Lophius piscatorius',
    marketCode: 'ANF',
    typicalSizeCm: '40 - 100 cm',
    minLandingSizeCm: 50,
    habitat: 'Benthic ambush predator on muddy/sandy bottom contours from 20m to 1000m.',
    northSeaZonePreference: 'North Sea shelf edge, Shetland Basin, Fladen margins.',
    qualityFactors: 'High collagen muscle structure; tail firmness and liver pristine condition.',
    handlingProtocol: 'Robotic tail excision, skinning line 03, chilled storage with direct ice contact.',
    marketPriceRangeGbpKg: '£7.20 - £8.50 / kg (Tails)',
    ukMmoQuotaCategory: 'Deepwater & Demersal UK Quota',
  },
  {
    id: 'whiting',
    name: 'Whiting',
    latin: 'Merlangius merlangus',
    marketCode: 'WHG',
    typicalSizeCm: '25 - 40 cm',
    minLandingSizeCm: 27,
    habitat: 'Muddy and gravel seabeds at depths of 30m to 100m.',
    northSeaZonePreference: 'Widespread across North Sea (Areas IVa, IVb, IVc).',
    qualityFactors: 'Soft delicate flesh; requires rapid processing to prevent enzymatic autolysis.',
    handlingProtocol: 'Automated high-speed fillet or immediate whole icing in 25kg bins.',
    marketPriceRangeGbpKg: '£1.90 - £2.40 / kg',
    ukMmoQuotaCategory: 'UK Landing Obligation Species',
  },
  {
    id: 'hake',
    name: 'European Hake',
    latin: 'Merluccius merluccius',
    marketCode: 'HKE',
    typicalSizeCm: '45 - 80 cm',
    minLandingSizeCm: 30,
    habitat: 'Continental shelf edges, deep shelf troughs (70m - 400m).',
    northSeaZonePreference: 'Northern North Sea and West of Scotland corridors.',
    qualityFactors: 'Pure white flesh; rapid degradation if temperature exceeds 2°C.',
    handlingProtocol: 'Gentle handling on pneumatic conveyor; slurry immersion immediately.',
    marketPriceRangeGbpKg: '£4.20 - £4.80 / kg',
    ukMmoQuotaCategory: 'Northern Hake Stock Quota',
  },
  {
    id: 'sole',
    name: 'Dover Sole',
    latin: 'Solea solea',
    marketCode: 'SOL',
    typicalSizeCm: '25 - 40 cm',
    minLandingSizeCm: 24,
    habitat: 'Fine sandy and muddy bottoms, warm summer shallows and deep winter troughs.',
    northSeaZonePreference: 'Southern North Sea & English Channel (Area IVc, VIId).',
    qualityFactors: 'Superior firmness, rigor mortis delay, premium gastronomic value.',
    handlingProtocol: 'Single-layer tray stacking in refrigerated hold at -0.5°C.',
    marketPriceRangeGbpKg: '£11.50 - £14.00 / kg',
    ukMmoQuotaCategory: 'UK High-Value Flatfish Quota',
  },
  {
    id: 'mackerel',
    name: 'Atlantic Mackerel',
    latin: 'Scomber scombrus',
    marketCode: 'MAC',
    typicalSizeCm: '30 - 45 cm',
    minLandingSizeCm: 20,
    habitat: 'Pelagic schools migrating through open North Sea waters.',
    northSeaZonePreference: 'Northern North Sea pelagic corridors (autumn migration).',
    qualityFactors: 'High Omega-3 fat content; rapid lipid oxidation risk if exposed to air.',
    handlingProtocol: 'Refrigerated Sea Water (RSW) pumping directly from pelagic bag.',
    marketPriceRangeGbpKg: '£1.40 - £1.90 / kg',
    ukMmoQuotaCategory: 'UK Pelagic TAC Pool',
  },
];

export const MARITIME_MANUALS: MaritimeManualArticle[] = [
  {
    id: 'MAN-01',
    title: 'Twin-Rig Demersal Trawl Hydrodynamics & Steerable Clump Control',
    category: 'AUTONOMOUS_TRAWLING',
    author: 'British Maritime Hydrodynamics Group & Rolls-Royce Marine Division',
    summary: 'Engineering principles of warp tension equilibrium, Morgère door geometry, and hydrodynamic drag minimization in North Sea sea states 3 to 6.',
    content: `The twin-rig demersal configuration on FV NORTH STAR utilizes a center steerable clump weight (3,200 kg) combined with Morgère high-aspect trawl doors. 
Warp tension balance between port and starboard winches is maintained by continuous closed-loop hydraulic PID controllers. 
Target door spread is mathematically modeled as:
Spread = f(Warp Length, Tow Speed, Seabed Friction, Hydrodynamic Lift).
When operating in 80-120m depths on Fladen Ground, maintaining a warp-to-depth ratio of 3.8:1 ensures optimal bottom contact of the groundgear without causing excessive sediment pluming or benthic disruption.`,
  },
  {
    id: 'MAN-02',
    title: 'Automated Fish Processing: 6-Axis Kinematics & Deep Learning Species Vision',
    category: 'ROBOTIC_PROCESSING',
    author: 'Aberdeen Robotics Lab & BTO Automation Systems',
    summary: 'Architecture of the VISION-07 camera pipeline, YOLOv10-Marine species detection model, and KUKA marine-hardened delta sorting arms.',
    content: `The deck robotic cell comprises two 6-axis marine-hardened arms (DR-04 and DR-05) synchronized with high-resolution stereo multispectral cameras.
The vision pipeline performs 3 inference tasks at 45 FPS:
1. Species segmentation (identifying Haddock, Cod, Plaice, Whiting, Monkfish).
2. 3D Pose and Length estimation using calibrated laser triangulation.
3. Quality Grading (Grade A: skin intact, clear cornea, firm structure; Grade B: minor net abrasion; Reject: undersize).
Fish categorized with <80% classification confidence are diverted to the human review bypass hopper under MCA guidelines.`,
  },
  {
    id: 'MAN-03',
    title: 'Dual-Circuit CO2 / Ammonia Cascade Cold Chain Engineering',
    category: 'COLD_CHAIN_CO2',
    author: 'Grimsby Refrigeration Engineers & Lloyd’s Register Survey',
    summary: 'Thermodynamic efficiency of natural refrigerant cascades in marine holds operating at -28°C and -38°C blast freezing.',
    content: `FV NORTH STAR uses an eco-friendly natural refrigerant cascade:
- High Stage: Ammonia (NH3) primary circuit located in sealed gas-tight machinery space.
- Low Stage: Subcritical Carbon Dioxide (CO2 / R744) pumped through the hold evaporators and plate freezers.
This eliminates synthetic HFCs, providing zero ODP and GWP=1. Heat recovered from the NH3 condenser is repurposed for accommodation heating, deck de-icing, and freshwater evaporator pre-heating, achieving a thermal COP of 4.12.`,
  },
  {
    id: 'MAN-04',
    title: 'UK Electronic Reporting System (ERS v3.4) & VMS Regulatory Compliance',
    category: 'UK_MMO_ERS',
    author: 'UK Marine Management Organisation (MMO) Compliance Framework',
    summary: 'Mandatory report schemas, transmission lifecycle (DEP, FAR, DIS, PNO, LAN), and automated ACK/NAK handling.',
    content: `Under UK fisheries statutory regulations (SI 2020 No. 1300 as amended 2026), all UK-flagged vessels over 12 meters must transmit XML-compliant ERS reports:
- DEP (Departure Declaration): within 2 hours of sailing.
- FAR (Fishing Activity Report): for every haul or at least every 24 hours.
- DIS (Discard Report): for all non-quota or exempt survivability species.
- PNO (Prior Notification of Arrival): minimum 4 hours prior to entering port limits.
- LAN (Landing Declaration): submitted within 24 hours of landing completion.
BTO-SYSTEM maintains a persistent offline message queue with automatic retry across Iridium and 4G/5G coastal mesh.`,
  },
];
