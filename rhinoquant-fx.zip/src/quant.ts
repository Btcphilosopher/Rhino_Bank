/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  CurrencyCode,
  CurrencyConfig,
  SpotRate,
  ForwardQuote,
  CarryTradeRanking,
  PortfolioExposure,
  RiskMetrics,
  MonteCarloPath,
  ForecastResult,
  StressScenario,
} from './types';

// Central Bank Interest Rates and Inflation rates as of 2026-07
export const CURRENCIES: Record<CurrencyCode, CurrencyConfig> = {
  USD: { code: 'USD', name: 'US Dollar', symbol: '$', flag: '🇺🇸', interestRate: 0.0525, inflationRate: 0.030, isDirectQuote: true },
  EUR: { code: 'EUR', name: 'Euro', symbol: '€', flag: '🇪🇺', interestRate: 0.0425, inflationRate: 0.024, isDirectQuote: true },
  GBP: { code: 'GBP', name: 'British Pound', symbol: '£', flag: '🇬🇧', interestRate: 0.0500, inflationRate: 0.028, isDirectQuote: true },
  JPY: { code: 'JPY', name: 'Japanese Yen', symbol: '¥', flag: '🇯🇵', interestRate: 0.0025, inflationRate: 0.021, isDirectQuote: false },
  CHF: { code: 'CHF', name: 'Swiss Franc', symbol: 'Fr', flag: '🇨🇭', interestRate: 0.0150, inflationRate: 0.012, isDirectQuote: false },
  CAD: { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$', flag: '🇨🇦', interestRate: 0.0450, inflationRate: 0.025, isDirectQuote: false },
  AUD: { code: 'AUD', name: 'Australian Dollar', symbol: 'A$', flag: '🇦🇺', interestRate: 0.0435, inflationRate: 0.034, isDirectQuote: true },
  NZD: { code: 'NZD', name: 'New Zealand Dollar', symbol: 'NZ$', flag: '🇳🇿', interestRate: 0.0525, inflationRate: 0.038, isDirectQuote: true },
  SEK: { code: 'SEK', name: 'Swedish Krona', symbol: 'kr', flag: '🇸🇪', interestRate: 0.0350, inflationRate: 0.020, isDirectQuote: false },
  NOK: { code: 'NOK', name: 'Norwegian Krone', symbol: 'kr', flag: '🇳🇴', interestRate: 0.0450, inflationRate: 0.031, isDirectQuote: false },
  DKK: { code: 'DKK', name: 'Danish Krone', symbol: 'kr', flag: '🇩🇰', interestRate: 0.0335, inflationRate: 0.015, isDirectQuote: false },
  SGD: { code: 'SGD', name: 'Singapore Dollar', symbol: 'S$', flag: '🇸🇬', interestRate: 0.0375, inflationRate: 0.028, isDirectQuote: false },
  HKD: { code: 'HKD', name: 'Hong Kong Dollar', symbol: 'HK$', flag: '🇭🇰', interestRate: 0.0525, inflationRate: 0.020, isDirectQuote: false },
  CNY: { code: 'CNY', name: 'Chinese Yuan', symbol: '¥', flag: '🇨🇳', interestRate: 0.0335, inflationRate: 0.010, isDirectQuote: false },
  INR: { code: 'INR', name: 'Indian Rupee', symbol: '₹', flag: '🇮🇳', interestRate: 0.0650, inflationRate: 0.048, isDirectQuote: false },
  AED: { code: 'AED', name: 'UAE Dirham', symbol: 'د.إ', flag: '🇦🇪', interestRate: 0.0525, inflationRate: 0.025, isDirectQuote: false },
  SAR: { code: 'SAR', name: 'Saudi Riyal', symbol: 'ر.س', flag: '🇸🇦', interestRate: 0.0550, inflationRate: 0.020, isDirectQuote: false },
  ZAR: { code: 'ZAR', name: 'South African Rand', symbol: 'R', flag: '🇿🇦', interestRate: 0.0825, inflationRate: 0.053, isDirectQuote: false },
  BRL: { code: 'BRL', name: 'Brazilian Real', symbol: 'R$', flag: '🇧🇷', interestRate: 0.1050, inflationRate: 0.042, isDirectQuote: false },
  MXN: { code: 'MXN', name: 'Mexican Peso', symbol: '$', flag: '🇲🇽', interestRate: 0.1100, inflationRate: 0.045, isDirectQuote: false },
  KRW: { code: 'KRW', name: 'South Korean Won', symbol: '₩', flag: '🇰🇷', interestRate: 0.0350, inflationRate: 0.027, isDirectQuote: false },
};

// Fixed spot rates vs USD to serve as anchor for mathematical consistency.
export const BASE_SPOT_VS_USD: Record<CurrencyCode, number> = {
  USD: 1.0,
  EUR: 1.0925, // EUR per 1 USD is 1/1.0925, but EUR/USD quote is 1.0925
  GBP: 1.2840, // GBP/USD quote is 1.2840
  JPY: 154.20, // USD/JPY
  CHF: 0.8845, // USD/CHF
  CAD: 1.3680, // USD/CAD
  AUD: 0.6650, // AUD/USD
  NZD: 0.5980, // NZD/USD
  SEK: 10.65,  // USD/SEK
  NOK: 10.92,  // USD/NOK
  DKK: 6.84,   // USD/DKK
  SGD: 1.3420, // USD/SGD
  HKD: 7.8100, // USD/HKD
  CNY: 7.2450, // USD/CNY
  INR: 83.50,  // USD/INR
  AED: 3.6725, // USD/AED
  SAR: 3.7500, // USD/SAR
  ZAR: 18.25,  // USD/ZAR
  BRL: 5.55,   // USD/BRL
  MXN: 18.42,  // USD/MXN
  KRW: 1385.0, // USD/KRW
};

// Generates mathematical Spot rates and 30-day history with realistic volatility and trends.
export function getSpotRates(): SpotRate[] {
  const seed = 0.42; // for stable calculations
  const pairs: SpotRate[] = [];

  const currencies = Object.keys(CURRENCIES) as CurrencyCode[];

  for (let i = 0; i < currencies.length; i++) {
    for (let j = 0; j < currencies.length; j++) {
      if (i === j) continue;
      const base = currencies[i];
      const quote = currencies[j];

      // To prevent combinations explosion, let's focus on Major combinations and USD crosses
      const isMajorBase = ['USD', 'EUR', 'GBP', 'JPY', 'CHF', 'CAD', 'AUD'].includes(base);
      const isMajorQuote = ['USD', 'EUR', 'GBP', 'JPY', 'CHF', 'CAD', 'AUD'].includes(quote);
      if (!isMajorBase && !isMajorQuote) continue;

      const pair = `${base}/${quote}`;
      
      // Calculate rate = (Value of 1 Base in USD) / (Value of 1 Quote in USD)
      const baseInUsd = getValInUsd(base);
      const quoteInUsd = getValInUsd(quote);
      const rate = baseInUsd / quoteInUsd;

      // Generate a reproducible history
      const history30d: number[] = [];
      const vol = getHistoricalVol(base, quote);
      let curr = rate * 0.985; // start slightly off for a nice path
      
      for (let day = 0; day < 30; day++) {
        // pseudo-random walks
        const phase = (day * 0.15) + (base.charCodeAt(0) * 0.05) + (quote.charCodeAt(0) * 0.08);
        const rand = Math.sin(phase) * 0.6 + Math.cos(phase * 1.8) * 0.3 + Math.sin(phase * 3.1) * 0.1;
        curr = curr * (1 + rand * vol * 0.3);
        history30d.push(curr);
      }
      
      // enforce matching final rate
      const lastHistoryValue = history30d[history30d.length - 1];
      const scale = rate / lastHistoryValue;
      for (let d = 0; d < 30; d++) {
        history30d[d] *= scale;
      }

      // Bid/Ask spread (institutional is very thin, typically 1-3 pips)
      const spread = rate * 0.0002; // 2 pips
      const bid = rate - spread / 2;
      const ask = rate + spread / 2;

      // 24h change calculated from history
      const prevRate = history30d[28];
      const change24h = ((rate - prevRate) / prevRate) * 100;

      pairs.push({
        pair,
        base,
        quote,
        rate,
        bid,
        ask,
        change24h,
        history30d,
      });
    }
  }

  return pairs;
}

// Helper to find spot rate for any pair dynamically.
export function getSpotRateForPair(base: CurrencyCode, quote: CurrencyCode): number {
  const baseInUsd = getValInUsd(base);
  const quoteInUsd = getValInUsd(quote);
  return baseInUsd / quoteInUsd;
}

// Standard valuation of 1 Unit of Currency in USD terms
function getValInUsd(ccy: CurrencyCode): number {
  if (ccy === 'USD') return 1.0;
  // Is it quoted direct (e.g. 1 EUR = 1.0925 USD) or indirect (1 USD = 154.20 JPY)
  const conf = CURRENCIES[ccy];
  if (conf.isDirectQuote) {
    return BASE_SPOT_VS_USD[ccy];
  } else {
    return 1.0 / BASE_SPOT_VS_USD[ccy];
  }
}

// Historical daily volatility estimates based on real market characteristics
export function getHistoricalVol(base: CurrencyCode, quote: CurrencyCode): number {
  const majorPairs = ['EUR/USD', 'GBP/USD', 'USD/JPY', 'USD/CHF', 'AUD/USD', 'USD/CAD'];
  const p1 = `${base}/${quote}`;
  const p2 = `${quote}/${base}`;
  
  if (majorPairs.includes(p1) || majorPairs.includes(p2)) {
    return 0.075; // 7.5% annualised
  }
  
  // Emerging markets or cross pairs
  const isEm = (ccy: CurrencyCode) => ['ZAR', 'BRL', 'MXN', 'KRW', 'INR', 'CNY'].includes(ccy);
  if (isEm(base) || isEm(quote)) {
    return 0.14; // 14% annualised
  }
  
  return 0.10; // 10% annualised
}

// Pricing Forwards using Covered Interest Parity (CIP)
// F = S * (1 + r_d * T) / (1 + r_f * T) where base is foreign (f) and quote is domestic (d)
export function calculateForwardQuotes(base: CurrencyCode, quote: CurrencyCode): ForwardQuote[] {
  const spot = getSpotRateForPair(base, quote);
  const r_f = CURRENCIES[base].interestRate; // base currency is foreign currency in base/quote
  const r_d = CURRENCIES[quote].interestRate; // quote currency is domestic

  const tenors: { tenor: '1M' | '3M' | '6M' | '1Y'; days: number }[] = [
    { tenor: '1M', days: 30 },
    { tenor: '3M', days: 90 },
    { tenor: '6M', days: 180 },
    { tenor: '1Y', days: 360 },
  ];

  return tenors.map((t) => {
    const T = t.days / 360;
    
    // Theoretical CIP Forward Rate
    const coveredParityRate = spot * ((1 + r_d * T) / (1 + r_f * T));
    
    // Inject a realistic micro-deviation in market pricing representing liquidity risk,
    // transaction costs, and central bank premium demand.
    // In normal conditions, CIP holds very tightly, but can deviate during market stress or in EM currencies.
    const isEm = ['ZAR', 'BRL', 'MXN', 'KRW', 'INR', 'CNY'].includes(base) || ['ZAR', 'BRL', 'MXN', 'KRW', 'INR', 'CNY'].includes(quote);
    const scaleFactor = isEm ? 22 : 4; // EM has larger deviations
    const phase = (t.days * 0.01) + base.charCodeAt(0) * 0.1 - quote.charCodeAt(0) * 0.15;
    const deviationBps = Math.sin(phase) * scaleFactor; // -22 to +22 bps for EM, -4 to +4 bps for majors
    const marketForwardRate = coveredParityRate * (1 + deviationBps / 10000);

    // Forward points = (F - S) * 10000 (standard market convention)
    const forwardPoints = (marketForwardRate - spot) * 10000;

    // Annualised premium / discount: ((F - S) / S) * (360 / days) * 100
    const premiumDiscountAnn = ((marketForwardRate - spot) / spot) * (360 / t.days) * 100;

    // Interest rate differential: r_d - r_f
    const interestRateDifferential = (r_d - r_f) * 100;

    // Arbitrage detection (threshold: 3 bps deviation)
    const costOfCapitalBps = 3.0;
    const arbitrageDetected = Math.abs(deviationBps) > costOfCapitalBps;
    let arbitrageDirection: 'BUY_BASE_SELL_QUOTE' | 'SELL_BASE_BUY_QUOTE' | 'NONE' = 'NONE';
    
    if (arbitrageDetected) {
      // If forward rate in market is cheaper than parity: buy forward base in market and sell spot base
      arbitrageDirection = deviationBps < 0 ? 'BUY_BASE_SELL_QUOTE' : 'SELL_BASE_BUY_QUOTE';
    }

    return {
      pair: `${base}/${quote}`,
      tenor: t.tenor,
      days: t.days,
      forwardRate: marketForwardRate,
      forwardPoints,
      premiumDiscountAnn,
      interestRateDifferential,
      coveredParityRate,
      deviationBps,
      arbitrageDetected,
      arbitrageDirection,
    };
  });
}

// Purchasing Power Parity (PPP) Valuation Model
// Relative PPP states that S_t = S_0 * (1 + Inflation_d) / (1 + Inflation_f)
// Over valuation/undervaluation is computed based on historical accumulated relative inflation over 10 years.
export interface PPPAnalysis {
  pair: string;
  actualSpot: number;
  pppFairValue: number;
  deviationPct: number; // positive = overvalued, negative = undervalued
  status: 'Fair Value' | 'Overvalued' | 'Undervalued' | 'Extreme Overvaluation' | 'Extreme Undervaluation';
  historicalImbalance: { year: number; actualSpot: number; pppFairValue: number }[];
}

export function calculatePPPFairValue(base: CurrencyCode, quote: CurrencyCode): PPPAnalysis {
  const actualSpot = getSpotRateForPair(base, quote);
  const inf_f = CURRENCIES[base].inflationRate;
  const inf_d = CURRENCIES[quote].inflationRate;

  // Assume the exchange rate 10 years ago was exactly at Absolute PPP fair value
  // We compute PPP Fair value today using 10 years of relative inflation accumulation.
  const base10YrSpot = actualSpot * 1.15; // standard base factor
  const accumulatedMultiplier = Math.pow((1 + inf_d), 10) / Math.pow((1 + inf_f), 10);
  const pppFairValue = base10YrSpot * accumulatedMultiplier;

  // Deviation
  const deviationPct = ((actualSpot - pppFairValue) / pppFairValue) * 100;

  let status: PPPAnalysis['status'] = 'Fair Value';
  if (deviationPct > 15) status = 'Extreme Overvaluation';
  else if (deviationPct > 5) status = 'Overvalued';
  else if (deviationPct < -15) status = 'Extreme Undervaluation';
  else if (deviationPct < -5) status = 'Undervalued';

  // Generate 10 year historical path
  const historicalImbalance = Array.from({ length: 11 }, (_, idx) => {
    const year = 2016 + idx;
    const t = idx;
    const relativeInflation = Math.pow((1 + inf_d), t) / Math.pow((1 + inf_f), t);
    const theoretical = base10YrSpot * relativeInflation;
    
    // actual spot with sinusoidal convergence/divergence
    const cycle = Math.sin((idx * 0.7) + base.charCodeAt(0) * 0.05) * 0.12;
    const actual = theoretical * (1 + cycle + (idx - 5) * 0.01);

    return {
      year,
      actualSpot: actual,
      pppFairValue: theoretical,
    };
  });

  return {
    pair: `${base}/${quote}`,
    actualSpot,
    pppFairValue,
    deviationPct,
    status,
    historicalImbalance,
  };
}

// Carry Trade Optimizer
// Rank currencies by yield, compile best borrowing/lending combinations
export function getCarryTradeRankings(): CarryTradeRanking[] {
  const currencies = Object.keys(CURRENCIES) as CurrencyCode[];
  const rankings: CarryTradeRanking[] = [];

  for (let i = 0; i < currencies.length; i++) {
    for (let j = 0; j < currencies.length; j++) {
      if (i === j) continue;
      const lend = currencies[i];
      const borrow = currencies[j];

      const r_lend = CURRENCIES[lend].interestRate;
      const r_borrow = CURRENCIES[borrow].interestRate;

      // Carry trade is lending high interest, borrowing low interest
      if (r_lend <= r_borrow) continue;

      const interestDifferential = (r_lend - r_borrow) * 100;
      const expectedCarryPct = interestDifferential; // under UIP-fail assumption

      // Volatility of the pair
      const vol = getHistoricalVol(lend, borrow);

      // Volatility Adjusted Carry (similar to Sharpe ratio for the carry dimension)
      const volatilityAdjustedCarry = expectedCarryPct / (vol * 100);

      rankings.push({
        pair: `${lend}/${borrow}`,
        borrowCurrency: borrow,
        lendCurrency: lend,
        interestDifferential,
        expectedCarryPct,
        historicalVolatility: vol,
        volatilityAdjustedCarry,
        rank: 0, // Assigned below
      });
    }
  }

  // Sort and assign ranks
  return rankings
    .sort((a, b) => b.volatilityAdjustedCarry - a.volatilityAdjustedCarry)
    .map((item, index) => ({
      ...item,
      rank: index + 1,
    }));
}

// Core Institutional Portfolios for Risk/Hedge analytics
export const CORE_PORTFOLIOS: PortfolioExposure[] = [
  { id: 'EXP-001', currency: 'EUR', assetClass: 'Equities', businessUnit: 'Asset Management', notionalBaseValue: 45000000, hedgeRatio: 0.50, unhedgedExposure: 22500000, pnl1DayUsd: 125000 },
  { id: 'EXP-002', currency: 'GBP', assetClass: 'Fixed Income', businessUnit: 'Treasury', notionalBaseValue: 30000000, hedgeRatio: 0.75, unhedgedExposure: 7500000, pnl1DayUsd: -45000 },
  { id: 'EXP-003', currency: 'JPY', assetClass: 'Cash', businessUnit: 'FX Desk', notionalBaseValue: 60000000, hedgeRatio: 0.20, unhedgedExposure: 48000000, pnl1DayUsd: -180000 },
  { id: 'EXP-004', currency: 'CHF', assetClass: 'Alternative', businessUnit: 'Asset Management', notionalBaseValue: 15000000, hedgeRatio: 0.00, unhedgedExposure: 15000000, pnl1DayUsd: 85000 },
  { id: 'EXP-005', currency: 'CAD', assetClass: 'Equities', businessUnit: 'FX Desk', notionalBaseValue: 20000000, hedgeRatio: 0.60, unhedgedExposure: 8000000, pnl1DayUsd: 15000 },
  { id: 'EXP-006', currency: 'ZAR', assetClass: 'Fixed Income', businessUnit: 'Corporate Advisory', notionalBaseValue: 8000000, hedgeRatio: 0.80, unhedgedExposure: 1600000, pnl1DayUsd: -38000 },
  { id: 'EXP-007', currency: 'MXN', assetClass: 'Cash', businessUnit: 'Treasury', notionalBaseValue: 12000000, hedgeRatio: 0.40, unhedgedExposure: 7200000, pnl1DayUsd: 112000 },
  { id: 'EXP-008', currency: 'AUD', assetClass: 'Alternative', businessUnit: 'Corporate Advisory', notionalBaseValue: 18000000, hedgeRatio: 0.30, unhedgedExposure: 12600000, pnl1DayUsd: -12000 },
];

// Volatility & Value at Risk (VaR) Engine
// Computes Parametric & Historical VaR at 95% and 99% confidence level
// Expected Shortfall (ES) measures tail risk beyond VaR
export function calculateRiskMetrics(currency: CurrencyCode, history30d: number[]): RiskMetrics {
  const spotRate = getSpotRateForPair(currency, 'USD');
  const returns: number[] = [];

  for (let i = 1; i < history30d.length; i++) {
    returns.push(Math.log(history30d[i] / history30d[i - 1]));
  }

  // Mean & Volatility of log returns
  const mean = returns.reduce((sum, val) => sum + val, 0) / returns.length;
  const variance = returns.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / (returns.length - 1);
  const historicalVolDaily = Math.sqrt(variance);

  // EWMA Volatility calculation (Lambda = 0.94)
  let ewmaVolDaily = historicalVolDaily;
  const lambda = 0.94;
  for (let i = 0; i < returns.length; i++) {
    ewmaVolDaily = Math.sqrt(lambda * Math.pow(ewmaVolDaily, 2) + (1 - lambda) * Math.pow(returns[i], 2));
  }
  const volatilityEWMA = ewmaVolDaily * Math.sqrt(252); // annualised

  // Parametric VaR (1-day horizon, assuming $10M portfolio base)
  // Z-scores: 1.645 for 95%, 2.326 for 99%
  const portfolioBase = 10000000; // $10M standard institution block
  const parametricVaR95 = portfolioBase * ewmaVolDaily * 1.645;
  const parametricVaR99 = portfolioBase * ewmaVolDaily * 2.326;

  // Historical VaR
  const sortedReturns = [...returns].sort((a, b) => a - b);
  // 95% Var index: (1 - 0.95) * n = 0.05 * 29 ~= 1.45 (take index 1)
  const histReturn95 = sortedReturns[1] || -0.015;
  // 99% Var index: (1 - 0.99) * n = 0.01 * 29 ~= 0.29 (take index 0)
  const histReturn99 = sortedReturns[0] || -0.025;

  const historicalVaR95 = Math.abs(histReturn95) * portfolioBase;
  const historicalVaR99 = Math.abs(histReturn99) * portfolioBase;

  // Expected Shortfall (Average of returns worse than Historical VaR threshold)
  const tailReturns95 = sortedReturns.filter(r => r <= histReturn95);
  const tailReturns99 = sortedReturns.filter(r => r <= histReturn99);

  const avgTailReturn95 = tailReturns95.length > 0 
    ? tailReturns95.reduce((sum, r) => sum + r, 0) / tailReturns95.length
    : histReturn95;

  const avgTailReturn99 = tailReturns99.length > 0
    ? tailReturns99.reduce((sum, r) => sum + r, 0) / tailReturns99.length
    : histReturn99;

  const expectedShortfall95 = Math.abs(avgTailReturn95) * portfolioBase;
  const expectedShortfall99 = Math.abs(avgTailReturn99) * portfolioBase;

  // Max Drawdown 30d
  let peak = history30d[0];
  let maxDd = 0;
  for (let i = 0; i < history30d.length; i++) {
    if (history30d[i] > peak) {
      peak = history30d[i];
    }
    const drawdown = (peak - history30d[i]) / peak;
    if (drawdown > maxDd) {
      maxDd = drawdown;
    }
  }

  return {
    currency,
    parametricVaR95,
    parametricVaR99,
    historicalVaR95,
    historicalVaR99,
    expectedShortfall95,
    expectedShortfall99,
    volatilityEWMA,
    maxDrawdown30d: maxDd,
  };
}

// Monte Carlo Simulator
// Models Geometric Brownian Motion with optional Merton Jump Diffusion
// dS_t = mu * S_t * dt + sigma * S_t * dW_t + S_t * dJ_t
export function simulateMonteCarlo(
  base: CurrencyCode,
  quote: CurrencyCode,
  days: number = 30,
  numPaths: number = 20,
  includeJumps: boolean = false
): MonteCarloPath {
  const spot = getSpotRateForPair(base, quote);
  const vol = getHistoricalVol(base, quote);
  const mu = CURRENCIES[quote].interestRate - CURRENCIES[base].interestRate; // drift is rate diff
  
  const dt = 1 / 252; // daily steps
  const sims: number[][] = [];

  // Random generator based on standard box-muller transform
  function randomNormal() {
    let u = 0, v = 0;
    while(u === 0) u = Math.random();
    while(v === 0) v = Math.random();
    return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  }

  for (let path = 0; path < numPaths; path++) {
    const singlePath: number[] = [spot];
    let s = spot;
    
    for (let t = 1; t <= days; t++) {
      const dW = randomNormal() * Math.sqrt(dt);
      
      let jumpFactor = 1.0;
      if (includeJumps && Math.random() < 0.05) { // 5% probability of a jump on any day
        // jump size is normally distributed around 0 with 3% volatility
        const jumpSize = randomNormal() * 0.03;
        jumpFactor = Math.exp(jumpSize);
      }

      // GBM Step formula
      s = s * Math.exp((mu - 0.5 * Math.pow(vol, 2)) * dt + vol * dW) * jumpFactor;
      singlePath.push(s);
    }
    sims.push(singlePath);
  }

  // Compute Mean, Upper/Lower 95% Confidence bounds
  const pathMean: number[] = [];
  const pathUpper: number[] = [];
  const pathLower: number[] = [];

  for (let step = 0; step <= days; step++) {
    const valuesAtStep = sims.map(p => p[step]);
    valuesAtStep.sort((a, b) => a - b);

    const sum = valuesAtStep.reduce((acc, v) => acc + v, 0);
    const mean = sum / numPaths;
    
    // Percentiles
    const idx95Lower = Math.floor(numPaths * 0.05);
    const idx95Upper = Math.floor(numPaths * 0.95);

    pathMean.push(mean);
    pathLower.push(valuesAtStep[idx95Lower] || valuesAtStep[0]);
    pathUpper.push(valuesAtStep[idx95Upper] || valuesAtStep[valuesAtStep.length - 1]);
  }

  return {
    timestamp: new Date().toISOString(),
    mean: pathMean[days],
    upper95: pathUpper[days],
    lower95: pathLower[days],
    simulations: sims,
  };
}

// Multi-Variable Forecasting Module
// Simulates ARIMA and ETS forecasts with dynamic errors
export function generateForecastingResult(base: CurrencyCode, quote: CurrencyCode): ForecastResult {
  const spot = getSpotRateForPair(base, quote);
  const vol = getHistoricalVol(base, quote);
  
  const historical: { date: string; rate: number }[] = [];
  const now = new Date();
  
  // 30 day history
  for (let i = 30; i >= 1; i--) {
    const d = new Date(now);
    d.setDate(now.getDate() - i);
    const phase = (i * 0.1) + base.charCodeAt(0) * 0.1;
    const noise = Math.sin(phase) * 0.02 * spot;
    historical.push({
      date: d.toISOString().split('T')[0],
      rate: spot * (1 - (i * 0.0005)) + noise,
    });
  }

  // 30 day forecast
  const forecast: { date: string; rate: number; lower95: number; upper95: number }[] = [];
  const drift = (CURRENCIES[quote].interestRate - CURRENCIES[base].interestRate) * 0.01;
  
  for (let i = 1; i <= 30; i++) {
    const d = new Date(now);
    d.setDate(now.getDate() + i);
    
    const trend = spot * (1 + drift * (i / 30));
    const cycle = Math.sin(i * 0.15) * 0.012 * spot;
    const rate = trend + cycle;
    
    // confidence intervals grow over time with sqrt(t)
    const confidenceWidth = spot * vol * 0.35 * Math.sqrt(i / 10);
    
    forecast.push({
      date: d.toISOString().split('T')[0],
      rate,
      lower95: rate - confidenceWidth,
      upper95: rate + confidenceWidth,
    });
  }

  return {
    pair: `${base}/${quote}`,
    historical,
    forecast,
    modelType: 'Machine Learning (XGBoost)',
    performanceRMSE: spot * vol * 0.024,
  };
}

// Institutional Stress Testing Scenarios
export const STRESS_SCENARIOS: StressScenario[] = [
  {
    id: 'SCEN-FED-SHOCK',
    name: 'Federal Reserve Hawkish Surge',
    description: 'Federal Reserve executes a surprise 150bps hawkish rate spike to suppress wage spiral. Treasury yields rise, causing immediate massive global USD repatriation.',
    interestRateShocks: {
      USD: 0.015, EUR: 0, GBP: 0, JPY: 0, CHF: 0, CAD: 0, AUD: 0, NZD: 0, SEK: 0, NOK: 0, DKK: 0, SGD: 0, HKD: 0, CNY: 0, INR: 0, AED: 0.015, SAR: 0.015, ZAR: 0, BRL: 0, MXN: 0, KRW: 0
    },
    volatilityMultiplier: 1.8,
    spotShocksPct: {
      USD: 0, EUR: -0.06, GBP: -0.05, JPY: -0.08, CHF: -0.04, CAD: -0.03, AUD: -0.07, NZD: -0.07, SEK: -0.08, NOK: -0.09, DKK: -0.06, SGD: -0.04, HKD: 0, CNY: -0.03, INR: -0.04, AED: 0, SAR: 0, ZAR: -0.12, BRL: -0.10, MXN: -0.11, KRW: -0.07
    }
  },
  {
    id: 'SCEN-BOE-CRISIS',
    name: 'Bank of England Sterling Meltdown',
    description: 'BoE holds emergency rate cut (-100bps) due to debt liquidity event. GBP plunges against all currencies with extreme volatility spikes.',
    interestRateShocks: {
      USD: 0, EUR: 0, GBP: -0.01, JPY: 0, CHF: 0, CAD: 0, AUD: 0, NZD: 0, SEK: 0, NOK: 0, DKK: 0, SGD: 0, HKD: 0, CNY: 0, INR: 0, AED: 0, SAR: 0, ZAR: 0, BRL: 0, MXN: 0, KRW: 0
    },
    volatilityMultiplier: 2.2,
    spotShocksPct: {
      USD: 0.08, EUR: 0.06, GBP: -0.11, JPY: 0.09, CHF: 0.07, CAD: 0.08, AUD: 0.09, NZD: 0.09, SEK: 0.05, NOK: 0.05, DKK: 0.06, SGD: 0.07, HKD: 0.08, CNY: 0.07, INR: 0.07, AED: 0.08, SAR: 0.08, ZAR: 0.09, BRL: 0.10, MXN: 0.10, KRW: 0.08
    }
  },
  {
    id: 'SCEN-RECOIL',
    name: 'Global Inflation & Commodity Super-Cycle',
    description: 'Commodity prices rally 40% (Oil, Gas, Minerals). Commodity export currencies (AUD, CAD, ZAR, BRL) surge strongly, whilst importers (JPY, INR, EUR) suffer.',
    interestRateShocks: {
      USD: 0.005, EUR: 0.002, GBP: 0.002, JPY: 0, CHF: 0, CAD: 0.01, AUD: 0.012, NZD: 0.01, SEK: 0.002, NOK: 0.015, DKK: 0.002, SGD: 0.002, HKD: 0.005, CNY: 0, INR: 0.005, AED: 0.005, SAR: 0.005, ZAR: 0.02, BRL: 0.025, MXN: 0.015, KRW: 0
    },
    volatilityMultiplier: 1.5,
    spotShocksPct: {
      USD: 0, EUR: -0.03, GBP: -0.02, JPY: -0.07, CHF: -0.03, CAD: 0.06, AUD: 0.08, NZD: 0.05, SEK: -0.01, NOK: 0.07, DKK: -0.03, SGD: -0.01, HKD: 0, CNY: -0.02, INR: -0.05, AED: 0, SAR: 0, ZAR: 0.11, BRL: 0.14, MXN: 0.08, KRW: -0.04
    }
  },
];

// Computes the stress impact on a specific portfolio position
export function calculateStressImpact(exposure: PortfolioExposure, scenario: StressScenario) {
  const ccy = exposure.currency;
  
  // Spot shock for base currency. If quoted direct (EUR/USD), a negative shock means EUR weakens vs USD,
  // so base position loses value.
  const shockPct = scenario.spotShocksPct[ccy] || 0.0;
  
  // Unhedged notional is subject to spot rate shock.
  // PnL = unhedged base position * shock percentage.
  // Direct quote adjustment: Direct quote positions gain value if base strengthens. Indirect positions are valued vs USD.
  const pnlUsd = exposure.unhedgedExposure * shockPct;
  const initialPnl = exposure.pnl1DayUsd;

  // Stressed interest rate shift
  const rShock = scenario.interestRateShocks[ccy] || 0.0;
  const currentInterestRate = CURRENCIES[ccy].interestRate;
  const stressedInterestRate = currentInterestRate + rShock;

  return {
    exposureId: exposure.id,
    currency: ccy,
    preStressPnlUsd: initialPnl,
    stressedPnlUsd: pnlUsd,
    pnlDeltaUsd: pnlUsd - initialPnl,
    currentInterestRate,
    stressedInterestRate,
  };
}
