/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  BrainCircuit,
  ArrowRight,
  Info,
} from 'lucide-react';
import {
  ComposedChart,
  Line,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { ForecastResult, CurrencyCode } from '../types';

interface Props {
  selectedPair: string;
}

export default function ForecastingView({ selectedPair }: Props) {
  const [base, quote] = selectedPair.split('/');
  const [forecastResult, setForecastResult] = useState<ForecastResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [modelType, setModelType] = useState<'XGBoost' | 'ARIMA' | 'VAR'>('XGBoost');

  useEffect(() => {
    async function fetchForecast() {
      setIsLoading(true);
      try {
        const res = await fetch(`/api/forecasting?base=${base}&quote=${quote}`);
        const data = await res.json();
        setForecastResult(data);
      } catch (err) {
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    }
    if (base && quote) {
      fetchForecast();
    }
  }, [selectedPair]);

  // Restructure forecast result for Recharts
  // Combine historical and forecast arrays with appropriate padding
  const chartData = (() => {
    if (!forecastResult) return [];
    
    const data: any[] = [];
    
    // Push historical values
    forecastResult.historical.forEach((item) => {
      data.push({
        date: item.date,
        historicalRate: item.rate,
      });
    });

    // Anchor point: the last historical rate is the start of the forecast
    const lastHist = forecastResult.historical[forecastResult.historical.length - 1];

    // Push forecast values
    forecastResult.forecast.forEach((item, idx) => {
      data.push({
        date: item.date,
        forecastRate: item.rate,
        lower95: item.lower95,
        upper95: item.upper95,
      });
    });

    return data;
  })();

  return (
    <div className="space-y-6" id="forecasting-view">
      {/* Header Summary */}
      <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5" id="forecasting-header">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <BrainCircuit className="text-amber-500 w-5 h-5" />
              Machine Learning Exchange Rate Forecasting
            </h2>
            <p className="text-xs text-[#9CA3AF] mt-1">
              Time series predictions leveraging multi-variable autoregressive models for <span className="font-semibold text-slate-300">{selectedPair}</span>.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#9CA3AF] font-semibold whitespace-nowrap">Forecast Engine:</span>
            <select
              value={modelType}
              onChange={(e) => setModelType(e.target.value as any)}
              className="bg-[#0A0B0D] border border-[#1F2937] text-slate-200 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-amber-500 font-bold"
            >
              <option value="XGBoost">Gradient Boosting (XGBoost)</option>
              <option value="ARIMA">Autoregressive Integrated MA (ARIMA)</option>
              <option value="VAR">Vector Autoregression (VAR)</option>
            </select>
          </div>
        </div>
      </div>

      {isLoading || !forecastResult ? (
        <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-12 text-center text-[#9CA3AF] text-xs" id="forecasting-loading">
          Running auto-ARIMA, training gradient boosting estimators...
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="forecasting-grid">
          {/* Main Chart Card */}
          <div className="lg:col-span-2 bg-[#16191E] border border-[#1F2937] rounded-xl p-5" id="forecasting-chart-card">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">Historical & 30-Day Forward Projection</h3>
                <p className="text-xs text-[#9CA3AF] mt-0.5">Shaded bands represent standard 95% error distribution corridor</p>
              </div>
              <div className="flex gap-2 text-xs">
                <span className="flex items-center gap-1 text-[#9CA3AF]">
                  <span className="w-2.5 h-1 bg-slate-500 inline-block"></span> History
                </span>
                <span className="flex items-center gap-1 text-amber-500 font-bold">
                  <span className="w-2.5 h-1 bg-amber-500 inline-block"></span> Projection
                </span>
              </div>
            </div>

            <div className="h-[360px]" id="forecast-recharts-container">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={chartData}>
                  <XAxis dataKey="date" stroke="#4B5563" fontSize={9} tickLine={false} />
                  <YAxis
                    stroke="#4B5563"
                    fontSize={10}
                    tickLine={false}
                    domain={['dataMin - 0.01', 'dataMax + 0.01']}
                    tickFormatter={(v) => v.toFixed(3)}
                  />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#16191E', borderColor: '#1F2937', borderRadius: '8px' }}
                    labelStyle={{ color: '#9CA3AF', fontSize: '11px' }}
                    itemStyle={{ fontSize: '12px', color: '#E0E2E5' }}
                  />
                  {/* Shaded confidence interval band */}
                  <Area
                    type="monotone"
                    dataKey="upper95"
                    stroke="none"
                    fill="#f59e0b"
                    fillOpacity={0.07}
                    name="95% CI Boundary"
                  />
                  <Area
                    type="monotone"
                    dataKey="lower95"
                    stroke="none"
                    fill="#f59e0b"
                    fillOpacity={0.12}
                    name="95% CI Floor"
                  />
                  {/* Historical Rate line */}
                  <Line
                    type="monotone"
                    dataKey="historicalRate"
                    stroke="#64748b"
                    strokeWidth={2}
                    dot={false}
                    name="Historical Mid"
                  />
                  {/* Forecast Rate line */}
                  <Line
                    type="monotone"
                    dataKey="forecastRate"
                    stroke="#f59e0b"
                    strokeWidth={2.5}
                    dot={false}
                    name={`${modelType} Forecast`}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Model Performance & Evaluation */}
          <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5 flex flex-col justify-between" id="forecasting-performance-panel">
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-1.5">
                <Info className="w-4 h-4 text-amber-500" />
                Model Validation Diagnostics
              </h3>

              <div className="space-y-3" id="forecasting-validation-list">
                <div className="bg-[#0A0B0D] p-3 rounded-lg border border-[#1F2937] text-xs">
                  <div className="text-[#6B7280] font-semibold">Active Algorithmic Model</div>
                  <div className="text-md font-bold font-mono text-slate-200 mt-1">
                    {modelType === 'XGBoost' ? 'Gradient Boosted Estimator' : modelType}
                  </div>
                </div>

                <div className="bg-[#0A0B0D] p-3 rounded-lg border border-[#1F2937] text-xs">
                  <div className="text-[#6B7280] font-semibold">Root Mean Square Error (RMSE)</div>
                  <div className="text-xl font-bold font-mono text-emerald-400 mt-1">
                    {forecastResult.performanceRMSE.toFixed(5)}
                  </div>
                  <p className="text-[10px] text-[#6B7280] mt-1">
                    Calculated via backtesting over 30d out-of-sample test arrays
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#1F2937]/60 text-[10px] text-[#6B7280] leading-relaxed" id="forecasting-model-note">
              <span className="font-semibold text-[#9CA3AF]">Methodology Framework:</span>
              <p className="mt-1">
                Autoregressive parameters utilize macroeconomic lagged interest rate matrices, relative purchasing power disparities, and moving momentum indicators.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
