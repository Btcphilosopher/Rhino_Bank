/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Briefcase,
  PieChart as PieIcon,
  ShieldCheck,
  TrendingUp,
  Percent,
  Sliders,
  Sparkles,
} from 'lucide-react';
import { PortfolioExposure } from '../types';

interface Props {
  exposures: PortfolioExposure[];
  onHedgeChange: (id: string, ratio: number) => void;
}

export default function PortfolioExposureView({ exposures, onHedgeChange }: Props) {
  const [selectedAssetClass, setSelectedAssetClass] = useState<string>('ALL');

  const filteredExposures = selectedAssetClass === 'ALL'
    ? exposures
    : exposures.filter(e => e.assetClass === selectedAssetClass);

  // Aggregates
  const totalNotionalUsd = exposures.reduce((acc, e) => acc + e.notionalBaseValue, 0);
  const totalUnhedgedUsd = exposures.reduce((acc, e) => acc + e.unhedgedExposure, 0);
  const totalHedgedUsd = totalNotionalUsd - totalUnhedgedUsd;
  const portfolioHedgeRatio = (totalHedgedUsd / totalNotionalUsd) * 100;
  
  const totalPnL = exposures.reduce((acc, e) => acc + e.pnl1DayUsd, 0);

  // Asset class filters
  const assetClasses = ['ALL', 'Cash', 'Equities', 'Fixed Income', 'Alternative'];

  // Portfolio concentration helper
  const concentration = exposures.reduce((acc, e) => {
    acc[e.currency] = (acc[e.currency] || 0) + e.notionalBaseValue;
    return acc;
  }, {} as Record<string, number>);

  const sortedConcentration = Object.entries(concentration)
    .sort((a, b) => b[1] - a[1])
    .map(([ccy, val]) => ({
      currency: ccy,
      valueUsd: val,
      pct: (val / totalNotionalUsd) * 100,
    }));

  return (
    <div className="space-y-6" id="portfolio-exposure-view">
      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4" id="portfolio-kpis">
        <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-4">
          <div className="text-xs text-[#9CA3AF] flex items-center gap-1.5">
            <Briefcase className="w-3.5 h-3.5 text-amber-500" />
            Total Gross Exposure
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
            ${(totalNotionalUsd / 1000000).toFixed(1)}M
          </div>
          <div className="text-xs text-[#6B7280] mt-1">
            Aggregate notional book value
          </div>
        </div>

        <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-4">
          <div className="text-xs text-[#9CA3AF] flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            Aggregate Hedged Value
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
            ${(totalHedgedUsd / 1000000).toFixed(1)}M
          </div>
          <div className="text-xs text-emerald-400 mt-1 font-medium">
            Hedged: {portfolioHedgeRatio.toFixed(1)}% of book
          </div>
        </div>

        <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-4">
          <div className="text-xs text-[#9CA3AF] flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-amber-500" />
            Residual Net Exposure
          </div>
          <div className="text-2xl font-bold font-mono text-amber-500 mt-1">
            ${(totalUnhedgedUsd / 1000000).toFixed(1)}M
          </div>
          <div className="text-xs text-[#6B7280] mt-1">
            Active tail capital subject to market volatility
          </div>
        </div>

        <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-4">
          <div className="text-xs text-[#9CA3AF] flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-[#818CF8]" />
            Portfolio Daily P&L
          </div>
          <div className={`text-2xl font-bold font-mono mt-1 ${totalPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {totalPnL >= 0 ? '+' : '-'}${(Math.abs(totalPnL) / 1000).toFixed(1)}k
          </div>
          <div className="text-xs text-[#6B7280] mt-1">
            Daily attribution performance
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="portfolio-interactive-grid">
        {/* Exposure Management Table */}
        <div className="lg:col-span-2 bg-[#16191E] border border-[#1F2937] rounded-xl p-5 flex flex-col justify-between" id="portfolio-positions-panel">
          <div>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">Active Book Exposure & Hedging Desk</h3>
                <p className="text-xs text-[#9CA3AF] mt-0.5">Adjust hedge percentages dynamically to mitigate currency correlation risk.</p>
              </div>
              <div className="flex gap-1 overflow-x-auto pb-1 md:pb-0">
                {assetClasses.map(ac => (
                  <button
                    key={ac}
                    onClick={() => setSelectedAssetClass(ac)}
                    className={`text-[10px] px-2.5 py-1 rounded font-medium border whitespace-nowrap transition-colors ${
                      selectedAssetClass === ac
                        ? 'bg-amber-500 border-amber-500 text-[#0A0B0D]'
                        : 'bg-[#0A0B0D] border-[#1F2937] text-[#9CA3AF] hover:text-slate-200'
                    }`}
                  >
                    {ac}
                  </button>
                ))}
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-[#1F2937] text-[#9CA3AF] font-medium">
                    <th className="pb-3 pl-2">Asset ID</th>
                    <th className="pb-3">Ccy</th>
                    <th className="pb-3">Asset Class</th>
                    <th className="pb-3 text-right">Gross Notional</th>
                    <th className="pb-3 text-center">Hedge Ratio</th>
                    <th className="pb-3 text-right">Net Exposure</th>
                    <th className="pb-3 text-right">1D P&L</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1F2937]/40">
                  {filteredExposures.map((item) => (
                    <tr key={item.id} className="hover:bg-[#0A0B0D]/40 transition-colors">
                      <td className="py-3 pl-2 font-mono font-bold text-slate-400">{item.id}</td>
                      <td className="py-3 font-semibold text-slate-100">
                        <span className="bg-[#0A0B0D] text-slate-300 px-1.5 py-0.5 rounded font-mono">
                          {item.currency}
                        </span>
                      </td>
                      <td className="py-3 text-[#9CA3AF] text-[11px]">{item.assetClass}</td>
                      <td className="py-3 text-right font-mono font-bold text-slate-200">
                        ${(item.notionalBaseValue).toLocaleString()}
                      </td>
                      <td className="py-3 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <input
                            type="range"
                            min="0"
                            max="1"
                            step="0.05"
                            value={item.hedgeRatio}
                            onChange={(e) => onHedgeChange(item.id, parseFloat(e.target.value))}
                            className="w-16 accent-amber-500 h-1 bg-[#0A0B0D] rounded-lg cursor-pointer"
                          />
                          <span className="font-mono font-semibold text-[11px] text-amber-500 w-8 text-right">
                            {Math.round(item.hedgeRatio * 100)}%
                          </span>
                        </div>
                      </td>
                      <td className="py-3 text-right font-mono text-amber-500">
                        ${(item.unhedgedExposure).toLocaleString()}
                      </td>
                      <td className={`py-3 text-right font-mono ${item.pnl1DayUsd >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {item.pnl1DayUsd >= 0 ? '+' : ''}
                        ${(item.pnl1DayUsd).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Portfolio Concentration & Natural Hedging */}
        <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5 flex flex-col justify-between" id="portfolio-concentration-panel">
          <div>
            <h3 className="text-sm font-semibold text-slate-200 mb-4 flex items-center gap-1.5">
              <PieIcon className="w-4 h-4 text-amber-500" />
              Currency Concentration Risk
            </h3>

            <div className="space-y-4" id="portfolio-concentration-list">
              {sortedConcentration.map((item, idx) => (
                <div key={item.currency} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5 font-bold text-slate-300">
                      <span className="text-[#6B7280] font-mono">#{idx+1}</span>
                      {item.currency}
                    </div>
                    <div className="font-mono text-[#9CA3AF]">
                      ${(item.valueUsd / 1000000).toFixed(1)}M <span className="text-[10px] text-[#6B7280]">({item.pct.toFixed(1)}%)</span>
                    </div>
                  </div>
                  <div className="w-full bg-[#0A0B0D] rounded-full h-1.5">
                    <div
                      className="bg-amber-500 h-1.5 rounded-full"
                      style={{ width: `${item.pct}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-5 border-t border-[#1F2937]/80 bg-[#0A0B0D]/40 p-3 rounded-lg" id="natural-hedging-advisory">
            <h4 className="text-xs font-semibold text-slate-200 flex items-center gap-1.5 mb-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              Natural Hedging Advisory
            </h4>
            <p className="text-[11px] text-[#9CA3AF] leading-relaxed">
              We detect active offset potential of <span className="font-semibold text-slate-300">CHF</span> and <span className="font-semibold text-slate-300">EUR</span> positions. 
              The historical correlation of -0.25 suggests a natural cross-balance, which reduces active volatility exposure by <span className="font-semibold text-emerald-400">12.5%</span> without requiring synthetic derivatives!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
