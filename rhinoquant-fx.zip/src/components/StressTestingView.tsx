/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Flame,
  ArrowRight,
  TrendingDown,
  Info,
  CheckCircle,
} from 'lucide-react';
import { StressScenario } from '../types';

interface StressedPosition {
  id: string;
  currency: string;
  assetClass: string;
  businessUnit: string;
  notionalBaseValue: number;
  hedgeRatio: number;
  unhedgedExposure: number;
  pnl1DayUsd: number;
  preStressPnlUsd: number;
  stressedPnlUsd: number;
  pnlDeltaUsd: number;
  currentInterestRate: number;
  stressedInterestRate: number;
}

interface StressResponse {
  scenario: StressScenario;
  portfolioImpacts: StressedPosition[];
  summary: {
    totalPreStressPnlUsd: number;
    totalStressedPnlUsd: number;
    pnlDeltaUsd: number;
    severity: string;
  };
}

export default function StressTestingView() {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>('SCEN-FED-SHOCK');
  const [stressData, setStressData] = useState<StressResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const scenariosList = [
    { id: 'SCEN-FED-SHOCK', name: 'Federal Reserve Hawkish Surge' },
    { id: 'SCEN-BOE-CRISIS', name: 'Sterling Debt Crisis' },
    { id: 'SCEN-RECOIL', name: 'Commodity Super-Cycle Inflation' },
  ];

  async function runStressTest() {
    setIsLoading(true);
    try {
      const res = await fetch('/api/stress-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenarioId: selectedScenarioId }),
      });
      const data = await res.json();
      setStressData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    runStressTest();
  }, [selectedScenarioId]);

  return (
    <div className="space-y-6" id="stress-testing-view">
      {/* Selector and Scenario Header */}
      <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5" id="stress-header">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <ShieldAlert className="text-rose-500 w-5 h-5 animate-pulse" />
              Institutional Macroeconomic Stress Testing Console
            </h2>
            <p className="text-xs text-[#9CA3AF] mt-1">
              Evaluating global portfolio resilience against severe interest rate shocks and extreme foreign exchange volatility.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#9CA3AF] font-semibold whitespace-nowrap">Stress Scenario:</span>
            <select
              value={selectedScenarioId}
              onChange={(e) => setSelectedScenarioId(e.target.value)}
              className="bg-[#0A0B0D] border border-[#1F2937] text-slate-200 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-amber-500 font-bold cursor-pointer"
              id="stress-scenario-select"
            >
              {scenariosList.map((sc) => (
                <option key={sc.id} value={sc.id}>
                  {sc.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {stressData?.scenario && (
          <div className="mt-4 p-4 bg-[#0A0B0D]/60 rounded-lg border border-[#1F2937] text-xs space-y-2" id="scenario-narrative">
            <div className="font-bold text-slate-200 flex items-center gap-1">
              <Info className="w-4 h-4 text-amber-500" /> Scenario Narrative & Impact Vector
            </div>
            <p className="text-[#9CA3AF] leading-relaxed">{stressData.scenario.description}</p>
            <div className="flex items-center gap-4 text-[10px] text-[#6B7280] pt-1">
              <div>
                Volatility Shock Multiplier:{' '}
                <span className="text-amber-400 font-semibold">{stressData.scenario.volatilityMultiplier}x</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {isLoading || !stressData ? (
        <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-12 text-center text-[#9CA3AF] text-xs" id="stress-loading">
          Recalculating interest rate curves, executing portfolio shocks...
        </div>
      ) : (
        <div className="space-y-6" id="stress-results-panel">
          {/* Summary Dashboard */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4" id="stress-summary-grid">
            <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-4">
              <div className="text-xs text-[#9CA3AF]">Pre-Stress Portfolio P&L</div>
              <div className={`text-2xl font-bold font-mono mt-1 ${stressData.summary.totalPreStressPnlUsd >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                ${stressData.summary.totalPreStressPnlUsd.toLocaleString()}
              </div>
              <div className="text-xs text-[#6B7280] mt-1">Normal trading parameters</div>
            </div>

            <div className="bg-[#16191E] border border-rose-500/30 rounded-xl p-4">
              <div className="text-xs text-[#9CA3AF]">Post-Stress Portfolio P&L</div>
              <div className={`text-2xl font-bold font-mono mt-1 ${stressData.summary.totalStressedPnlUsd >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                ${stressData.summary.totalStressedPnlUsd.toLocaleString()}
              </div>
              <div className="text-xs text-[#6B7280] mt-1">Stressed parameter results</div>
            </div>

            <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-4">
              <div className="text-xs text-[#9CA3AF]">Stress Impairment Delta</div>
              <div className={`text-2xl font-bold font-mono mt-1 ${stressData.summary.pnlDeltaUsd >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {stressData.summary.pnlDeltaUsd >= 0 ? '+' : ''}
                ${stressData.summary.pnlDeltaUsd.toLocaleString()}
              </div>
              <div className="text-xs text-rose-400 mt-1 font-semibold flex items-center gap-1">
                <Flame className="w-3 h-3" /> Impairment Severity: {stressData.summary.severity}
              </div>
            </div>
          </div>

          {/* Stressed Positions Table */}
          <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5" id="stress-table-card">
            <h3 className="text-sm font-semibold text-slate-200 mb-4">Position-Level Shock Attribution Matrix</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-[#1F2937] text-[#9CA3AF] font-medium">
                    <th className="pb-3 pl-2">Asset ID</th>
                    <th className="pb-3">Ccy</th>
                    <th className="pb-3 text-right">Gross Exposure</th>
                    <th className="pb-3 text-right">Unhedged Net</th>
                    <th className="pb-3 text-right">Pre-Stress P&L</th>
                    <th className="pb-3 text-right">Post-Stress P&L</th>
                    <th className="pb-3 text-right">Shock Delta</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1F2937]/40">
                  {stressData.portfolioImpacts.map((pos) => {
                    const isPositive = pos.pnlDeltaUsd >= 0;
                    return (
                      <tr key={pos.id} className="hover:bg-[#0A0B0D]/40 transition-colors">
                        <td className="py-3 pl-2 font-mono text-slate-400">{pos.id}</td>
                        <td className="py-3 font-semibold text-slate-200">{pos.currency}</td>
                        <td className="py-3 text-right font-mono text-slate-300">
                          ${pos.notionalBaseValue.toLocaleString()}
                        </td>
                        <td className="py-3 text-right font-mono text-amber-500">
                          ${pos.unhedgedExposure.toLocaleString()}
                        </td>
                        <td className={`py-3 text-right font-mono ${pos.preStressPnlUsd >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          ${pos.preStressPnlUsd.toLocaleString()}
                        </td>
                        <td className={`py-3 text-right font-mono ${pos.stressedPnlUsd >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          ${pos.stressedPnlUsd.toLocaleString()}
                        </td>
                        <td className={`py-3 text-right font-mono font-bold ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {isPositive ? '+' : ''}
                          ${pos.pnlDeltaUsd.toLocaleString()}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
