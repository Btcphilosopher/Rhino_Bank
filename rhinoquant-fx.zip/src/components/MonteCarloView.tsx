/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  RefreshCw,
  LineChart as LineChartIcon,
  Play,
  Info,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from 'recharts';
import { CurrencyCode, MonteCarloPath } from '../types';

interface Props {
  selectedPair: string;
}

export default function MonteCarloView({ selectedPair }: Props) {
  const [base, quote] = selectedPair.split('/');
  const [days, setDays] = useState<number>(30);
  const [paths, setPaths] = useState<number>(15);
  const [includeJumps, setIncludeJumps] = useState<boolean>(true);
  const [simData, setSimData] = useState<MonteCarloPath | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  async function triggerSimulation() {
    setIsLoading(true);
    try {
      const res = await fetch(
        `/api/monte-carlo?base=${base}&quote=${quote}&days=${days}&paths=${paths}&includeJumps=${includeJumps}`
      );
      const data = await res.json();
      setSimData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    if (base && quote) {
      triggerSimulation();
    }
  }, [selectedPair, days, paths, includeJumps]);

  // Restructure simulation paths for charting
  // Recharts requires [{ step: 0, path0: 1.09, path1: 1.10, mean: 1.095, ... }]
  const formattedChartData = (() => {
    if (!simData) return [];
    const stepsCount = simData.simulations[0]?.length || 0;
    
    return Array.from({ length: stepsCount }, (_, stepIdx) => {
      const stepRow: any = {
        step: `D+${stepIdx}`,
        mean: Number(simData.mean || 0), // assigned later
      };

      // Extract each path's value at this step
      simData.simulations.forEach((p, pathIdx) => {
        stepRow[`path_${pathIdx}`] = Number(p[stepIdx]?.toFixed(4));
      });

      // Calculate aggregated statistics for this specific step across simulations
      const stepVals = simData.simulations.map(p => p[stepIdx]);
      stepVals.sort((a, b) => a - b);
      
      const stepMean = stepVals.reduce((acc, v) => acc + v, 0) / stepVals.length;
      stepRow.mean = Number(stepMean.toFixed(4));
      stepRow.lower95 = Number((stepVals[Math.floor(stepVals.length * 0.1)] || stepVals[0]).toFixed(4));
      stepRow.upper95 = Number((stepVals[Math.floor(stepVals.length * 0.9)] || stepVals[stepVals.length - 1]).toFixed(4));

      return stepRow;
    });
  })();

  return (
    <div className="space-y-6" id="monte-carlo-view">
      {/* Configuration Header */}
      <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-6" id="mc-header">
        <div className="space-y-1">
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <LineChartIcon className="text-amber-500 w-5 h-5" />
            Geometric Brownian Motion Path Simulator
          </h2>
          <p className="text-xs text-[#9CA3AF]">
            Simulating drift, diffusion, and jump parameters for <span className="font-semibold text-slate-300">{selectedPair}</span> over custom horizons.
          </p>
        </div>

        {/* Dynamic Parameter Sliders */}
        <div className="flex flex-wrap items-center gap-4 text-xs" id="mc-controls">
          <div className="space-y-1.5">
            <label className="text-[#9CA3AF] block font-semibold">Horizon (Days):</label>
            <select
              value={days}
              onChange={(e) => setDays(parseInt(e.target.value))}
              className="bg-[#0A0B0D] border border-[#1F2937] text-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-amber-500"
            >
              <option value="15">15 Days</option>
              <option value="30">30 Days</option>
              <option value="60">60 Days</option>
              <option value="90">90 Days</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-[#9CA3AF] block font-semibold">Path Dimensions:</label>
            <select
              value={paths}
              onChange={(e) => setPaths(parseInt(e.target.value))}
              className="bg-[#0A0B0D] border border-[#1F2937] text-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-amber-500"
            >
              <option value="10">10 Paths</option>
              <option value="15">15 Paths</option>
              <option value="25">25 Paths</option>
              <option value="50">50 Paths</option>
            </select>
          </div>

          <div className="space-y-1.5 flex items-center gap-2 pt-5">
            <input
              type="checkbox"
              id="jumps-chk"
              checked={includeJumps}
              onChange={(e) => setIncludeJumps(e.target.checked)}
              className="accent-amber-500 rounded border-[#1F2937] bg-[#0A0B0D] cursor-pointer"
            />
            <label htmlFor="jumps-chk" className="text-slate-300 cursor-pointer font-semibold">
              Merton Jump Diffusion
            </label>
          </div>

          <button
            onClick={triggerSimulation}
            disabled={isLoading}
            className="bg-amber-500 hover:bg-amber-400 text-[#0A0B0D] font-semibold rounded-lg px-4 py-2 flex items-center gap-1.5 transition-all self-end disabled:opacity-50 mt-4 md:mt-0"
            id="mc-run-btn"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            Simulate
          </button>
        </div>
      </div>

      {isLoading || !simData ? (
        <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-16 text-center text-[#9CA3AF] text-xs" id="mc-loading">
          Generating random Wiener paths, applying jump poison distributions...
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="mc-results-grid">
          {/* Main Chart */}
          <div className="lg:col-span-2 bg-[#16191E] border border-[#1F2937] rounded-xl p-5" id="mc-chart-card">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">Stochastic Model Realizations</h3>
                <p className="text-xs text-[#9CA3AF] mt-0.5">Simulated individual paths with 95% confidence corridor</p>
              </div>
              <div className="flex gap-3 text-xs">
                <span className="flex items-center gap-1 text-amber-500 font-semibold">
                  <span className="w-2.5 h-1 bg-amber-500 inline-block"></span> Model Mean
                </span>
                <span className="flex items-center gap-1 text-[#9CA3AF]">
                  <span className="w-2.5 h-1 border-t border-dashed border-emerald-500 inline-block"></span> 95% Confidence Bounds
                </span>
              </div>
            </div>

            <div className="h-[360px]" id="mc-recharts-container">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={formattedChartData}>
                  <XAxis dataKey="step" stroke="#4B5563" fontSize={10} tickLine={false} />
                  <YAxis
                    stroke="#4B5563"
                    fontSize={10}
                    tickLine={false}
                    domain={['dataMin - 0.01', 'dataMax + 0.01']}
                    tickFormatter={(v) => v.toFixed(3)}
                  />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#16191E', borderColor: '#1F2937', borderRadius: '8px' }}
                    labelStyle={{ color: '#9CA3AF', fontSize: '11px' }}
                    itemStyle={{ fontSize: '12px', color: '#E0E2E5' }}
                  />
                  {/* Confidence Interval lines */}
                  <Line type="monotone" dataKey="upper95" stroke="#10b981" strokeDasharray="3 3" strokeWidth={1} dot={false} name="Upper 95% CI" />
                  <Line type="monotone" dataKey="lower95" stroke="#10b981" strokeDasharray="3 3" strokeWidth={1} dot={false} name="Lower 95% CI" />

                  {/* Draw each simulated path line */}
                  {Array.from({ length: paths }).map((_, idx) => (
                    <Line
                      key={idx}
                      type="monotone"
                      dataKey={`path_${idx}`}
                      stroke="#4B5563"
                      strokeWidth={0.8}
                      opacity={0.3}
                      dot={false}
                      activeDot={false}
                    />
                  ))}

                  {/* Mean Line */}
                  <Line type="monotone" dataKey="mean" stroke="#f59e0b" strokeWidth={2.5} dot={false} name="Mean Expectation" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Model Derivations & Analytics */}
          <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5 flex flex-col justify-between" id="mc-math-panel">
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-1.5">
                <Info className="w-4 h-4 text-amber-500" />
                Mathematical Derivation & Audit
              </h3>

              <div className="space-y-3" id="mc-audit-list">
                <div className="bg-[#0A0B0D] p-3 rounded-lg border border-[#1F2937] text-xs">
                  <div className="text-[#6B7280] font-semibold">Terminal Simulated Mean</div>
                  <div className="text-xl font-bold font-mono text-amber-500 mt-1">
                    {simData.mean.toFixed(5)}
                  </div>
                </div>

                <div className="bg-[#0A0B0D] p-3 rounded-lg border border-[#1F2937] text-xs">
                  <div className="text-[#6B7280] font-semibold">95% Confidence Corridor</div>
                  <div className="text-md font-bold font-mono text-slate-300 mt-1">
                    [{simData.lower95.toFixed(4)} , {simData.upper95.toFixed(4)}]
                  </div>
                  <p className="text-[10px] text-[#6B7280] mt-1">
                    Spread width: {(((simData.upper95 - simData.lower95) / simData.lower95) * 100).toFixed(2)}%
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#1F2937]/60 text-[10px] text-[#6B7280] leading-relaxed" id="mc-stochastic-formula">
              <span className="font-bold text-[#9CA3AF]">Model Framework:</span>
              <p className="mt-1">
                Prices follow continuous stochastic process where drift represents interest yield curves and diffusion represents EWMA volatility. Jumps are modeled with Poisson arrival density:
              </p>
              <span className="block font-mono text-slate-400 mt-1 bg-[#0A0B0D] p-1.5 rounded border border-[#1F2937]">
                dS_t = mu*S*dt + sigma*S*dW_t + dJ_t
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
