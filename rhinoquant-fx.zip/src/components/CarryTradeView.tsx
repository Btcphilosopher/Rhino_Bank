/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Coins,
  TrendingUp,
  Flame,
  CheckCircle2,
  HelpCircle,
  TrendingDown,
} from 'lucide-react';
import { CarryTradeRanking, CurrencyConfig } from '../types';

interface Props {
  rankings: CarryTradeRanking[];
  currencies: CurrencyConfig[];
}

export default function CarryTradeView({ rankings, currencies }: Props) {
  // Top 6 positions
  const topRanked = rankings.slice(0, 6);

  // Generate correlation/heatmap grid coordinates
  // Let's create a matrix of Lend (High Yield) vs Borrow (Low Yield)
  const borrowCcyList = ['JPY', 'CHF', 'USD', 'EUR', 'GBP'];
  const lendCcyList = ['MXN', 'BRL', 'ZAR', 'INR', 'AUD'];

  return (
    <div className="space-y-6" id="carry-trade-view">
      {/* Overview Block */}
      <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5" id="carry-header">
        <div className="flex items-center gap-3">
          <div className="bg-amber-500/10 p-2.5 rounded-lg border border-amber-500/20">
            <Coins className="text-amber-500 w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">Macro Currency Carry Optimizer</h2>
            <p className="text-xs text-[#9CA3AF] mt-1">
              Maximising portfolio yield by borrowing low-yield currencies (funding legs) and investing in high-yield assets (investment legs), adjusted for volatility.
            </p>
          </div>
        </div>
      </div>

      {/* Top 3 Rankings Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4" id="carry-rank-cards">
        {topRanked.slice(0, 3).map((item, idx) => {
          const lendConf = currencies.find(c => c.code === item.lendCurrency);
          const borrowConf = currencies.find(c => c.code === item.borrowCurrency);
          return (
            <div
              key={item.pair}
              className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5 relative overflow-hidden"
              id={`carry-ranking-card-${idx}`}
            >
              {/* Rank Badge */}
              <div className="absolute top-4 right-4 bg-[#0A0B0D] text-[11px] border border-amber-500/30 text-amber-500 px-2 py-0.5 rounded-full font-mono font-bold">
                RANK #{item.rank}
              </div>

              <div className="flex items-center gap-1.5 text-xs text-[#9CA3AF] font-semibold uppercase tracking-wider">
                <Flame className="w-3.5 h-3.5 text-amber-500" />
                Yield Optimization
              </div>

              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-bold font-mono text-slate-100">{item.pair}</span>
              </div>

              <div className="mt-4 pt-4 border-t border-[#1F2937]/60 grid grid-cols-2 gap-4 text-xs">
                <div>
                  <div className="text-[#6B7280]">Lend Interest Rate</div>
                  <div className="text-slate-200 font-mono font-bold mt-0.5">
                    {lendConf ? `${(lendConf.interestRate * 100).toFixed(2)}%` : '-'}
                  </div>
                </div>
                <div>
                  <div className="text-[#6B7280]">Borrow Interest Rate</div>
                  <div className="text-slate-200 font-mono font-bold mt-0.5">
                    {borrowConf ? `${(borrowConf.interestRate * 100).toFixed(2)}%` : '-'}
                  </div>
                </div>
                <div>
                  <div className="text-[#6B7280]">Carry Differential</div>
                  <div className="text-emerald-400 font-mono font-bold mt-0.5">
                    +{item.interestDifferential.toFixed(2)}%
                  </div>
                </div>
                <div>
                  <div className="text-[#6B7280]">Vol-Adjusted Sharpe</div>
                  <div className="text-amber-500 font-mono font-bold mt-0.5">
                    {item.volatilityAdjustedCarry.toFixed(2)}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Rankings Table & Heatmap Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6" id="carry-details-grid">
        {/* Rankings Table */}
        <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5" id="carry-table-panel">
          <h3 className="text-sm font-semibold text-slate-200 mb-4 flex items-center gap-1.5">
            <TrendingUp className="w-4 h-4 text-indigo-400" />
            Top High-Carry Opportunity Matrix
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#1F2937] text-[#9CA3AF] font-medium">
                  <th className="pb-3 pl-2">Rank</th>
                  <th className="pb-3">Trade Pair</th>
                  <th className="pb-3 text-right">Lend leg</th>
                  <th className="pb-3 text-right">Funding leg</th>
                  <th className="pb-3 text-right">Expected Yield</th>
                  <th className="pb-3 text-right">Sharpe Ratio</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1F2937]/40">
                {topRanked.map((item) => (
                  <tr key={item.pair} className="hover:bg-[#0A0B0D]/40 transition-colors">
                    <td className="py-3 pl-2 font-mono font-semibold text-amber-500">
                      #{item.rank}
                    </td>
                    <td className="py-3 font-bold text-slate-200">{item.pair}</td>
                    <td className="py-3 text-right text-slate-300">
                      {(currencies.find(c => c.code === item.lendCurrency)?.interestRate ?? 0 * 100).toFixed(2)}%
                    </td>
                    <td className="py-3 text-right text-slate-300">
                      {(currencies.find(c => c.code === item.borrowCurrency)?.interestRate ?? 0 * 100).toFixed(2)}%
                    </td>
                    <td className="py-3 text-right font-semibold font-mono text-emerald-400">
                      +{item.interestDifferential.toFixed(2)}%
                    </td>
                    <td className="py-3 text-right font-mono text-amber-500 font-bold">
                      {item.volatilityAdjustedCarry.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Tactical Heatmap Matrix */}
        <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5" id="carry-heatmap-panel">
          <h3 className="text-sm font-semibold text-slate-200 mb-4 flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-amber-400" />
            Tactical Yield Differentials (Lend vs Funding Leg)
          </h3>
          <div className="space-y-4" id="carry-heatmap-grid-root">
            <div className="grid grid-cols-6 gap-1 text-center font-mono text-[10px]">
              <div className="text-[#6B7280] py-1 font-semibold">Lend \ Funding</div>
              {borrowCcyList.map(ccy => (
                <div key={ccy} className="text-[#9CA3AF] py-1 font-bold">{ccy}</div>
              ))}

              {lendCcyList.map(lendCcy => {
                const lendRate = currencies.find(c => c.code === lendCcy)?.interestRate ?? 0;
                return (
                  <React.Fragment key={lendCcy}>
                    <div className="text-[#9CA3AF] py-2 font-bold text-left self-center">{lendCcy}</div>
                    {borrowCcyList.map(borrowCcy => {
                      const borrowRate = currencies.find(c => c.code === borrowCcy)?.interestRate ?? 0;
                      const diff = (lendRate - borrowRate) * 100;
                      
                      // style based on yield differential
                      let bg = 'bg-[#0A0B0D]/40 text-[#6B7280]';
                      if (diff > 8) bg = 'bg-emerald-950 border border-emerald-500/20 text-emerald-400 font-bold';
                      else if (diff > 5) bg = 'bg-teal-950/70 border border-teal-500/20 text-teal-400';
                      else if (diff > 2) bg = 'bg-amber-950/40 border border-amber-500/10 text-amber-500';

                      return (
                        <div
                          key={borrowCcy}
                          className={`p-2 rounded text-xs flex flex-col justify-center items-center ${bg}`}
                        >
                          <span>{diff > 0 ? '+' : ''}{diff.toFixed(1)}%</span>
                        </div>
                      );
                    })}
                  </React.Fragment>
                );
              })}
            </div>

            <div className="text-[10px] text-[#6B7280] flex items-center gap-4 pt-2">
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 bg-emerald-950 border border-emerald-500/20 rounded"></span>
                Extremely High Carry (&gt;8%)
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 bg-teal-950/70 border border-teal-500/20 rounded"></span>
                Moderate/High Carry (5% to 8%)
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 bg-amber-950/40 border border-amber-500/10 rounded"></span>
                Low Yield Carry (0% to 5%)
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
