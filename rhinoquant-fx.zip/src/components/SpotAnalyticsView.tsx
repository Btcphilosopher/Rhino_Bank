/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  Activity,
  Percent,
  Search,
  ArrowUpDown,
  DollarSign,
  Briefcase,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  ReferenceLine,
} from 'recharts';
import { SpotRate, CurrencyConfig } from '../types';

interface Props {
  spotRates: SpotRate[];
  currencies: CurrencyConfig[];
  selectedPair: string;
  setSelectedPair: (pair: string) => void;
}

export default function SpotAnalyticsView({
  spotRates,
  currencies,
  selectedPair,
  setSelectedPair,
}: Props) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'ALL' | 'MAJORS' | 'EM'>('ALL');

  const currentPairData = spotRates.find((s) => s.pair === selectedPair) || spotRates[0];

  const filteredRates = spotRates.filter((item) => {
    const matchesSearch = item.pair.toLowerCase().includes(searchQuery.toLowerCase());
    const isMajor = ['USD', 'EUR', 'GBP', 'JPY', 'CHF', 'CAD', 'AUD'].includes(item.base) &&
                    ['USD', 'EUR', 'GBP', 'JPY', 'CHF', 'CAD', 'AUD'].includes(item.quote);
    if (filterType === 'MAJORS') return matchesSearch && isMajor;
    if (filterType === 'EM') return matchesSearch && !isMajor;
    return matchesSearch;
  });

  // Calculate stats based on 30d history of selected pair
  const history = currentPairData?.history30d || [];
  const returns = history.map((val, idx) => {
    if (idx === 0) return 0;
    return ((val - history[idx - 1]) / history[idx - 1]) * 100;
  });

  const avgReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
  const maxRate = Math.max(...history);
  const minRate = Math.min(...history);
  const maxDrawdown = (() => {
    let peak = history[0];
    let maxDd = 0;
    for (let i = 0; i < history.length; i++) {
      if (history[i] > peak) peak = history[i];
      const dd = ((peak - history[i]) / peak) * 100;
      if (dd > maxDd) maxDd = dd;
    }
    return maxDd;
  })();

  // Construct chart data
  const chartData = history.map((val, idx) => {
    // Simple Moving Average 5-day
    const startIdx = Math.max(0, idx - 4);
    const subset = history.slice(startIdx, idx + 1);
    const sma5 = subset.reduce((a, b) => a + b, 0) / subset.length;

    return {
      day: `D-${29 - idx}`,
      rate: Number(val.toFixed(4)),
      sma5: Number(sma5.toFixed(4)),
    };
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="spot-analytics-container">
      {/* Sidebar: Pairs List */}
      <div className="lg:col-span-1 bg-[#16191E] border border-[#1F2937] rounded-xl p-4 flex flex-col h-[650px]" id="spot-sidebar">
        <div className="flex items-center gap-2 mb-4">
          <Search className="text-slate-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search currency pairs..."
            className="bg-[#0A0B0D] border border-[#1F2937] text-slate-100 rounded-lg px-3 py-1.5 text-sm w-full focus:outline-none focus:border-amber-500 transition-colors"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            id="spot-search-input"
          />
        </div>

        <div className="flex gap-1 mb-4" id="spot-filter-buttons">
          {(['ALL', 'MAJORS', 'EM'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`text-xs px-3 py-1.5 rounded-md font-medium transition-colors w-full ${
                filterType === t
                  ? 'bg-amber-500 text-[#0A0B0D]'
                  : 'bg-[#0A0B0D] text-[#9CA3AF] hover:text-slate-200 border border-[#1F2937]'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto space-y-1.5 pr-1" id="spot-pairs-list">
          {filteredRates.map((item) => {
            const isSelected = item.pair === selectedPair;
            return (
              <button
                key={item.pair}
                onClick={() => setSelectedPair(item.pair)}
                className={`w-full text-left p-3 rounded-lg border transition-all flex items-center justify-between ${
                  isSelected
                    ? 'bg-[#16191E]/80 border-amber-500 shadow-[0_0_12px_rgba(245,158,11,0.15)]'
                    : 'bg-[#0A0B0D] hover:bg-[#16191E]/40 border-[#1F2937]'
                }`}
                id={`spot-pair-btn-${item.pair.replace('/', '-')}`}
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-semibold text-slate-100">{item.pair}</span>
                    <span className="text-[10px] bg-[#16191E] text-slate-400 px-1 py-0.5 rounded">
                      OTC
                    </span>
                  </div>
                  <div className="text-xs text-[#9CA3AF] mt-1">
                    Spread: <span className="font-mono text-slate-300">{(item.rate * 0.0002).toFixed(5)}</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold text-slate-200 text-sm">
                    {item.rate.toFixed(4)}
                  </div>
                  <div
                    className={`text-xs flex items-center justify-end font-medium mt-0.5 ${
                      item.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {item.change24h >= 0 ? '+' : ''}
                    {item.change24h.toFixed(2)}%
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content Pane */}
      <div className="lg:col-span-2 space-y-6" id="spot-main-content">
        {/* Header Summary Stats */}
        {currentPairData && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4" id="spot-stats-grid">
            <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-4">
              <div className="text-xs text-[#9CA3AF] flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-amber-500" />
                Spot Mid Rate
              </div>
              <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
                {currentPairData.rate.toFixed(5)}
              </div>
              <div className="text-xs text-[#9CA3AF] mt-1 flex items-center gap-1">
                Bid <span className="text-slate-300 font-mono">{currentPairData.bid.toFixed(5)}</span> | Ask{' '}
                <span className="text-slate-300 font-mono">{currentPairData.ask.toFixed(5)}</span>
              </div>
            </div>

            <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-4">
              <div className="text-xs text-[#9CA3AF] flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                30d High / Low
              </div>
              <div className="text-lg font-bold font-mono text-slate-100 mt-1">
                {maxRate.toFixed(4)} <span className="text-xs text-slate-500 font-normal">/</span> {minRate.toFixed(4)}
              </div>
              <div className="text-xs text-emerald-400 mt-1">
                Amplitude: {(((maxRate - minRate) / minRate) * 100).toFixed(2)}%
              </div>
            </div>

            <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-4">
              <div className="text-xs text-[#9CA3AF] flex items-center gap-1.5">
                <Percent className="w-3.5 h-3.5 text-[#818CF8]" />
                Avg Log Return (Daily)
              </div>
              <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
                {avgReturn.toFixed(4)}%
              </div>
              <div className="text-xs text-[#9CA3AF] mt-1">
                Annualised: {(avgReturn * Math.sqrt(252)).toFixed(2)}%
              </div>
            </div>

            <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-4">
              <div className="text-xs text-[#9CA3AF] flex items-center gap-1.5">
                <ArrowUpDown className="w-3.5 h-3.5 text-rose-400" />
                Max 30d Drawdown
              </div>
              <div className="text-2xl font-bold font-mono text-rose-400 mt-1">
                -{maxDrawdown.toFixed(2)}%
              </div>
              <div className="text-xs text-[#9CA3AF] mt-1">
                Peak valuation risk metrics
              </div>
            </div>
          </div>
        )}

        {/* Spot Rate Chart */}
        <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5" id="spot-chart-card">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-200">Historical Spot Curve & SMA-5</h3>
              <p className="text-xs text-[#9CA3AF] mt-0.5">30-day daily interval midpoint trend analysis</p>
            </div>
            <div className="flex gap-2">
              <span className="inline-flex items-center gap-1 text-xs text-[#9CA3AF]">
                <span className="w-2.5 h-2.5 bg-amber-500 rounded-full"></span> Midrate
              </span>
              <span className="inline-flex items-center gap-1 text-xs text-[#9CA3AF]">
                <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full"></span> Simple Moving Average
              </span>
            </div>
          </div>

          <div className="h-[360px]" id="spot-recharts-container">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="day"
                  stroke="#4B5563"
                  fontSize={10}
                  tickLine={false}
                />
                <YAxis
                  stroke="#4B5563"
                  fontSize={10}
                  tickLine={false}
                  domain={['dataMin - 0.005', 'dataMax + 0.005']}
                  tickFormatter={(v) => v.toFixed(3)}
                />
                <Tooltip
                  contentStyle={{ backgroundColor: '#16191E', borderColor: '#1F2937', borderRadius: '8px' }}
                  labelStyle={{ color: '#9CA3AF', fontSize: '11px' }}
                  itemStyle={{ fontSize: '12px', color: '#E0E2E5' }}
                />
                <Area
                  type="monotone"
                  dataKey="rate"
                  stroke="#f59e0b"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorRate)"
                  name="Spot Mid"
                />
                <Area
                  type="monotone"
                  dataKey="sma5"
                  stroke="#10b981"
                  strokeWidth={1.5}
                  strokeDasharray="4 4"
                  fill="none"
                  name="SMA 5-day"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
