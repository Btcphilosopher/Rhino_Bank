/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  ArrowRight,
  TrendingDown,
  TrendingUp,
  Percent,
  RefreshCw,
  Scale,
  Zap,
} from 'lucide-react';
import { ForwardQuote, CurrencyCode } from '../types';

interface Props {
  selectedPair: string;
  forwardQuotes: ForwardQuote[];
  isLoading: boolean;
  onRefresh: () => void;
}

export default function ForwardPricingView({
  selectedPair,
  forwardQuotes,
  isLoading,
  onRefresh,
}: Props) {
  const [base, quote] = selectedPair.split('/');

  return (
    <div className="space-y-6" id="forward-pricing-view">
      {/* Overview Block */}
      <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5" id="forward-header">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <Scale className="text-amber-500 w-5 h-5" />
              Forward Curve Construction & Covered Interest Parity
            </h2>
            <p className="text-xs text-[#9CA3AF] mt-1">
              Pricing OTC forwards for <span className="font-semibold text-slate-300">{selectedPair}</span> based on interest rate parity models.
            </p>
          </div>
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="self-start md:self-auto bg-[#0A0B0D] border border-[#1F2937] hover:border-slate-700 text-slate-300 px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all disabled:opacity-50"
            id="forward-refresh-btn"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            Re-Price Curves
          </button>
        </div>
      </div>

      {/* Pricing Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4" id="forward-tenors-grid">
        {forwardQuotes.map((q) => {
          const isDisc = q.premiumDiscountAnn < 0;
          return (
            <div
              key={q.tenor}
              className={`bg-[#16191E] border rounded-xl p-4 flex flex-col justify-between transition-all ${
                q.arbitrageDetected
                  ? 'border-amber-500 shadow-[0_0_12px_rgba(245,158,11,0.1)]'
                  : 'border-[#1F2937] hover:border-slate-700'
              }`}
              id={`forward-card-${q.tenor}`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs bg-[#0A0B0D] text-amber-500 px-2 py-0.5 rounded font-mono font-bold">
                    {q.tenor} ({q.days}D)
                  </span>
                  {q.arbitrageDetected && (
                    <span className="text-[10px] bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded font-semibold flex items-center gap-1">
                      <Zap className="w-2.5 h-2.5 fill-current" /> Arb
                    </span>
                  )}
                </div>

                <div className="mt-4">
                  <div className="text-xs text-[#6B7280]">Quoted Forward Rate</div>
                  <div className="text-2xl font-bold font-mono text-slate-100 mt-0.5">
                    {q.forwardRate.toFixed(5)}
                  </div>
                </div>

                <div className="space-y-2 mt-4 pt-4 border-t border-[#1F2937]/60 text-xs">
                  <div className="flex justify-between">
                    <span className="text-[#9CA3AF]">Forward Points</span>
                    <span className="font-mono text-slate-300">
                      {q.forwardPoints >= 0 ? '+' : ''}
                      {q.forwardPoints.toFixed(1)}
                    </span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-[#9CA3AF]">Prem / Disc (Ann.)</span>
                    <span className={`font-semibold ${isDisc ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {q.premiumDiscountAnn >= 0 ? '+' : ''}
                      {q.premiumDiscountAnn.toFixed(3)}%
                    </span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-[#9CA3AF]">Yield Differential</span>
                    <span className="font-mono text-slate-300">{q.interestRateDifferential.toFixed(2)}%</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-[#1F2937]/80 text-xs">
                <div className="text-[#6B7280] text-[10px]">CIP Theoretical Rate</div>
                <div className="font-mono text-slate-400 mt-0.5">
                  {q.coveredParityRate.toFixed(5)}
                </div>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-[#6B7280] text-[10px]">Basis Point Spread</span>
                  <span className={`font-mono font-bold ${Math.abs(q.deviationBps) > 3.0 ? 'text-amber-400' : 'text-slate-400'}`}>
                    {q.deviationBps >= 0 ? '+' : ''}
                    {q.deviationBps.toFixed(2)} bps
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Arbitrage Workbench */}
      <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5" id="forward-arbitrage-desk">
        <h3 className="text-sm font-semibold text-slate-200 mb-4 flex items-center gap-2">
          <ShieldAlert className="text-amber-500 w-4.5 h-4.5" />
          Covered Interest Arbitrage Execution Desk
        </h3>

        {forwardQuotes.some((q) => q.arbitrageDetected) ? (
          <div className="space-y-4" id="arbitrage-active-panel">
            <p className="text-xs text-[#9CA3AF]">
              Theoretical pricing model deviates from the quoted OTC Forward rate. Arbitrage desks can locked-in riskless yields by exploiting this market inefficiency.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {forwardQuotes
                .filter((q) => q.arbitrageDetected)
                .map((q) => {
                  const isBuyBase = q.arbitrageDirection === 'BUY_BASE_SELL_QUOTE';
                  return (
                    <div key={q.tenor} className="bg-[#0A0B0D] border border-amber-500/20 rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-amber-400 text-sm">{q.tenor} Opportunity</span>
                        <span className="text-xs bg-amber-500/10 text-amber-400 px-2.5 py-0.5 rounded font-semibold">
                          Expected Yield Boost: {Math.abs(q.deviationBps).toFixed(1)} bps
                        </span>
                      </div>

                      <div className="text-xs text-slate-300 leading-relaxed">
                        <span className="font-semibold text-slate-100">Trade Execution Protocol:</span>
                        <ol className="list-decimal list-inside space-y-2.5 mt-2 text-slate-400">
                          {isBuyBase ? (
                            <>
                              <li>Borrow <span className="text-slate-200 font-mono">{quote}</span> at market lending rate.</li>
                              <li>Convert <span className="text-slate-200 font-mono">{quote}</span> to <span className="text-slate-200 font-mono">{base}</span> in spot market.</li>
                              <li>Invest <span className="text-slate-200 font-mono">{base}</span> at yield curve maturity rate.</li>
                              <li>Sell <span className="text-slate-200 font-mono">{base}</span> forward vs <span className="text-slate-200 font-mono">{quote}</span> to repatriate proceeds at maturity, capturing risk-free basis points.</li>
                            </>
                          ) : (
                            <>
                              <li>Borrow <span className="text-slate-200 font-mono">{base}</span> at market lending rate.</li>
                              <li>Convert <span className="text-slate-200 font-mono">{base}</span> to <span className="text-slate-200 font-mono">{quote}</span> in spot market.</li>
                              <li>Invest <span className="text-slate-200 font-mono">{quote}</span> at yield curve maturity rate.</li>
                              <li>Buy <span className="text-slate-200 font-mono">{base}</span> forward vs <span className="text-slate-200 font-mono">{quote}</span> to repay loan, locking in a premium.</li>
                            </>
                          )}
                        </ol>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        ) : (
          <div className="bg-[#0A0B0D] border border-[#1F2937] rounded-lg p-4 text-center py-6 text-[#9CA3AF] text-xs" id="arbitrage-inactive-panel">
            All maturity tenors represent high CIP convergence. Spread deviations are currently within the standard ±3.0 bps transaction cost band. No spatial arbitrage execution recommended.
          </div>
        )}
      </div>
    </div>
  );
}
