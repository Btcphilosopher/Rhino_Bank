/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  Flame,
  Scale,
  Percent,
  TrendingDown,
} from 'lucide-react';
import { RiskMetrics, CurrencyCode } from '../types';

interface Props {
  selectedCurrency: CurrencyCode;
  onCurrencyChange: (ccy: CurrencyCode) => void;
  availableCurrencies: CurrencyCode[];
}

export default function RiskEngineView({
  selectedCurrency,
  onCurrencyChange,
  availableCurrencies,
}: Props) {
  const [metrics, setMetrics] = useState<RiskMetrics | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    async function fetchRisk() {
      setIsLoading(true);
      try {
        const res = await fetch(`/api/risk-analytics?currency=${selectedCurrency}`);
        const data = await res.json();
        setMetrics(data);
      } catch (err) {
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    }
    fetchRisk();
  }, [selectedCurrency]);

  return (
    <div className="space-y-6" id="risk-engine-view">
      {/* Top Controller */}
      <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4" id="risk-header">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <ShieldCheck className="text-amber-500 w-5 h-5" />
            Market Risk Engine (VaR & Expected Shortfall Desk)
          </h2>
          <p className="text-xs text-[#9CA3AF] mt-1">
            Calculating Value at Risk (VaR) and Expected Shortfall (ES) under normal and extreme distributions.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-[#9CA3AF]">Risk Target Leg:</span>
          <select
            value={selectedCurrency}
            onChange={(e) => onCurrencyChange(e.target.value as CurrencyCode)}
            className="bg-[#0A0B0D] border border-[#1F2937] text-slate-200 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-amber-500 font-semibold"
            id="risk-ccy-select"
          >
            {availableCurrencies.map((ccy) => (
              <option key={ccy} value={ccy}>
                {ccy} / USD Position
              </option>
            ))}
          </select>
        </div>
      </div>

      {isLoading || !metrics ? (
        <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-12 text-center text-[#9CA3AF] text-xs" id="risk-loading">
          Recalculating covariance matrix, calculating historical percentiles...
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="risk-main-grid">
          {/* Main VaR Metrics */}
          <div className="lg:col-span-2 bg-[#16191E] border border-[#1F2937] rounded-xl p-5 space-y-6" id="risk-var-panel">
            <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-1.5">
              <Scale className="w-4 h-4 text-amber-500" />
              1-Day Value at Risk (VaR) & ES Profile ($10M Portfolio Unit)
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="var-sub-metrics">
              {/* 95% Confidence Block */}
              <div className="bg-[#0A0B0D] border border-[#1F2937] rounded-xl p-4 space-y-4">
                <div className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wider">
                  95% Confidence Interval
                </div>
                <div>
                  <div className="text-[10px] text-[#6B7280] font-semibold">Parametric VaR (EWMA)</div>
                  <div className="text-xl font-bold font-mono text-slate-200 mt-0.5">
                    ${Math.round(metrics.parametricVaR95).toLocaleString()}
                  </div>
                </div>
                <div className="pt-3 border-t border-[#1F2937]/60">
                  <div className="text-[10px] text-[#6B7280] font-semibold">Historical VaR</div>
                  <div className="text-xl font-bold font-mono text-slate-200 mt-0.5">
                    ${Math.round(metrics.historicalVaR95).toLocaleString()}
                  </div>
                </div>
                <div className="pt-3 border-t border-[#1F2937]/60 bg-amber-950/20 p-2.5 rounded-lg border border-amber-500/10">
                  <div className="text-[10px] text-amber-500 font-semibold">Expected Shortfall (Tail Risk)</div>
                  <div className="text-xl font-bold font-mono text-amber-500 mt-0.5">
                    ${Math.round(metrics.expectedShortfall95).toLocaleString()}
                  </div>
                </div>
              </div>

              {/* 99% Confidence Block */}
              <div className="bg-[#0A0B0D] border border-[#1F2937] rounded-xl p-4 space-y-4">
                <div className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wider">
                  99% Confidence Interval
                </div>
                <div>
                  <div className="text-[10px] text-[#6B7280] font-semibold">Parametric VaR (EWMA)</div>
                  <div className="text-xl font-bold font-mono text-amber-500 mt-0.5">
                    ${Math.round(metrics.parametricVaR99).toLocaleString()}
                  </div>
                </div>
                <div className="pt-3 border-t border-[#1F2937]/60">
                  <div className="text-[10px] text-[#6B7280] font-semibold">Historical VaR</div>
                  <div className="text-xl font-bold font-mono text-slate-200 mt-0.5">
                    ${Math.round(metrics.historicalVaR99).toLocaleString()}
                  </div>
                </div>
                <div className="pt-3 border-t border-[#1F2937]/60 bg-rose-950/20 p-2.5 rounded-lg border border-rose-500/10">
                  <div className="text-[10px] text-rose-400 font-semibold">Expected Shortfall (Tail Risk)</div>
                  <div className="text-xl font-bold font-mono text-rose-400 mt-0.5">
                    ${Math.round(metrics.expectedShortfall99).toLocaleString()}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Volatility & Stress Stats */}
          <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5 flex flex-col justify-between" id="risk-vol-panel">
            <div>
              <h3 className="text-sm font-semibold text-slate-200 mb-4 flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-amber-400" />
                Volatility Term Diagnostics
              </h3>

              <div className="space-y-4" id="vol-diagnostics-list">
                <div className="bg-[#0A0B0D] p-3 rounded-lg border border-[#1F2937]">
                  <div className="text-xs text-[#9CA3AF]">EWMA Annualised Volatility</div>
                  <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
                    {(metrics.volatilityEWMA * 100).toFixed(2)}%
                  </div>
                  <p className="text-[10px] text-[#6B7280] mt-1">
                    Lambda ($\lambda$ = 0.94) covariance decay model
                  </p>
                </div>

                <div className="bg-[#0A0B0D] p-3 rounded-lg border border-[#1F2937]">
                  <div className="text-xs text-[#9CA3AF]">Peak 30d Historical Drawdown</div>
                  <div className="text-2xl font-bold font-mono text-rose-400 mt-1">
                    -{(metrics.maxDrawdown30d * 100).toFixed(2)}%
                  </div>
                  <p className="text-[10px] text-[#6B7280] mt-1">
                    Deepest peak-to-trough valuation drop
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#1F2937]/60 text-[11px] text-[#6B7280] leading-relaxed" id="risk-formula-audit">
              <div className="font-semibold text-[#9CA3AF] flex items-center gap-1 mb-1">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-500" /> Audit Formula Reference:
              </div>
              Parametric VaR is based on Gaussian distribution assumption mapped dynamically over decaying historical squares: 
              <span className="block font-mono text-slate-400 mt-1">VaR = V * z * sqrt(sigma_t_squared)</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
