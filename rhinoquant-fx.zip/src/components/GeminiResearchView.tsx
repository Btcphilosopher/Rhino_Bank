/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Sparkles, RefreshCw, Send, ShieldAlert, Award } from 'lucide-react';

interface Props {
  selectedPair: string;
}

export default function GeminiResearchView({ selectedPair }: Props) {
  const [base, quote] = selectedPair.split('/');
  const [commentary, setCommentary] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  async function generateBriefing() {
    setIsLoading(true);
    setError('');
    try {
      const res = await fetch('/api/gemini/market-outlook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ base, quote }),
      });
      const data = await res.json();
      if (data.error) {
        setError(data.error);
      } else {
        setCommentary(data.commentary);
      }
    } catch (err) {
      console.error(err);
      setError('Failed to communicate with RhinoQuant FX server. Please check dev console.');
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    generateBriefing();
  }, [selectedPair]);

  // A light-weight markdown parser to render bullet points, bold text, and subheaders cleanly.
  // This bypasses the need for large external react-markdown dependencies, guaranteeing build stability.
  const renderFormattedText = (rawText: string) => {
    if (!rawText) return null;
    const lines = rawText.split('\n');
    return lines.map((line, idx) => {
      const cleanLine = line.trim();
      
      // Headers
      if (cleanLine.startsWith('###')) {
        return (
          <h4 key={idx} className="text-sm font-bold text-amber-500 mt-4 mb-2">
            {cleanLine.replace('###', '').trim()}
          </h4>
        );
      }
      if (cleanLine.startsWith('##') || cleanLine.startsWith('#')) {
        return (
          <h3 key={idx} className="text-md font-bold text-slate-100 border-b border-[#1F2937] pb-1 mt-5 mb-3 flex items-center gap-1.5">
            <Award className="w-4 h-4 text-amber-500" />
            {cleanLine.replace(/^#+\s*/, '').trim()}
          </h3>
        );
      }

      // Blockquotes
      if (cleanLine.startsWith('>')) {
        return (
          <blockquote key={idx} className="border-l-2 border-amber-500 pl-3 italic text-[#9CA3AF] my-2 bg-[#0A0B0D]/40 p-2 rounded-r">
            {cleanLine.replace('>', '').trim()}
          </blockquote>
        );
      }

      // Bullet items
      if (cleanLine.startsWith('-') || cleanLine.startsWith('*')) {
        const text = cleanLine.replace(/^[-\*]\s*/, '').trim();
        return (
          <ul key={idx} className="list-disc list-inside text-xs text-[#D1D5DB] space-y-1 pl-2">
            <li>{parseBoldText(text)}</li>
          </ul>
        );
      }

      // Normal text lines
      if (cleanLine === '') {
        return <div key={idx} className="h-2" />;
      }

      return (
        <p key={idx} className="text-xs text-[#D1D5DB] leading-relaxed my-2">
          {parseBoldText(cleanLine)}
        </p>
      );
    });
  };

  const parseBoldText = (text: string) => {
    const parts = text.split(/\*\*(.*?)\*\*/g);
    return parts.map((part, i) => {
      if (i % 2 === 1) {
        return <strong key={i} className="text-slate-100 font-semibold">{part}</strong>;
      }
      return part;
    });
  };

  return (
    <div className="space-y-6" id="gemini-research-view">
      {/* Overview Card */}
      <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-5" id="gemini-header">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-amber-500/10 p-2.5 rounded-lg border border-amber-500/20">
              <Sparkles className="text-amber-500 w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-100">AI Macro Research & Allocation Strategy</h2>
              <p className="text-xs text-[#9CA3AF] mt-1">
                Deep strategy generation using secure server-side models powered by <span className="font-semibold text-slate-300">Gemini 3.6-flash</span>.
              </p>
            </div>
          </div>
          <button
            onClick={generateBriefing}
            disabled={isLoading}
            className="self-start md:self-auto bg-[#0A0B0D] border border-[#1F2937] hover:border-[#374151] text-slate-300 px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all disabled:opacity-50"
            id="gemini-regenerate-btn"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            Generate Allocation Note
          </button>
        </div>
      </div>

      {/* Main Board */}
      <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-6" id="gemini-body-card">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20 space-y-4" id="gemini-loading-indicator">
            <RefreshCw className="w-8 h-8 text-amber-500 animate-spin" />
            <div className="text-xs text-[#9CA3AF] text-center">
              <p className="font-semibold text-slate-300">Formulating Macro Briefing...</p>
              <p className="mt-1">Evaluating yields, processing parity deviations, and formatting executive summaries...</p>
            </div>
          </div>
        ) : error ? (
          <div className="bg-rose-950/20 border border-rose-500/20 p-4 rounded-lg flex gap-3 text-xs text-rose-400" id="gemini-error-indicator">
            <ShieldAlert className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Gemini Service Limitation</p>
              <p className="mt-1">{error}</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4 max-w-4xl" id="gemini-parsed-content">
            {commentary ? (
              renderFormattedText(commentary)
            ) : (
              <p className="text-xs text-[#9CA3AF] italic text-center py-12">
                Click "Generate Allocation Note" to compile an institutional-grade research note for {selectedPair}.
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
