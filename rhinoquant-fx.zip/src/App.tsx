/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  Activity,
  Percent,
  Sliders,
  ShieldCheck,
  Coins,
  BrainCircuit,
  LineChart as LineIcon,
  Sparkles,
  Info,
  Layers,
} from 'lucide-react';

import SpotAnalyticsView from './components/SpotAnalyticsView';
import ForwardPricingView from './components/ForwardPricingView';
import CarryTradeView from './components/CarryTradeView';
import PortfolioExposureView from './components/PortfolioExposureView';
import RiskEngineView from './components/RiskEngineView';
import MonteCarloView from './components/MonteCarloView';
import ForecastingView from './components/ForecastingView';
import StressTestingView from './components/StressTestingView';
import GeminiResearchView from './components/GeminiResearchView';

import { SpotRate, CurrencyConfig, ForwardQuote, CarryTradeRanking, PortfolioExposure } from './types';

type TabId =
  | 'SPOT'
  | 'FORWARD'
  | 'CARRY'
  | 'PORTFOLIO'
  | 'RISK'
  | 'MONTE_CARLO'
  | 'FORECAST'
  | 'STRESS'
  | 'GEMINI';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('SPOT');
  const [selectedPair, setSelectedPair] = useState<string>('EUR/USD');
  const [selectedRiskCcy, setSelectedRiskCcy] = useState<'EUR' | 'GBP' | 'JPY' | 'CHF' | 'CAD' | 'ZAR' | 'MXN' | 'AUD'>('EUR');

  const [currencies, setCurrencies] = useState<CurrencyConfig[]>([]);
  const [spotRates, setSpotRates] = useState<SpotRate[]>([]);
  const [carryRankings, setCarryRankings] = useState<CarryTradeRanking[]>([]);
  const [forwardQuotes, setForwardQuotes] = useState<ForwardQuote[]>([]);
  const [exposures, setExposures] = useState<PortfolioExposure[]>([]);

  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Load initial global market metrics
  async function loadInitialMetrics() {
    setIsLoading(true);
    try {
      // 1. Load spot & core configurations
      const mRes = await fetch('/api/market-data');
      const mData = await mRes.json();
      setCurrencies(mData.currencies || []);
      setSpotRates(mData.spotRates || []);
      setCarryRankings(mData.carryRankings || []);

      // 2. Load portfolio exposures
      const pRes = await fetch('/api/portfolio');
      const pData = await pRes.json();
      setExposures(pData.exposures || []);

      // 3. Trigger initial forward rates calculations
      const [base, quote] = selectedPair.split('/');
      const fRes = await fetch(`/api/forward-pricing?base=${base}&quote=${quote}`);
      const fData = await fRes.json();
      setForwardQuotes(fData.forwards || []);
    } catch (err) {
      console.error('Failed to boot market indices:', err);
    } finally {
      setIsLoading(false);
    }
  }

  // Refresh Forward Curves when selectedPair changes
  async function fetchForwardCurves() {
    if (!selectedPair) return;
    const [base, quote] = selectedPair.split('/');
    try {
      const fRes = await fetch(`/api/forward-pricing?base=${base}&quote=${quote}`);
      const fData = await fRes.json();
      setForwardQuotes(fData.forwards || []);
    } catch (err) {
      console.error(err);
    }
  }

  useEffect(() => {
    loadInitialMetrics();
  }, []);

  useEffect(() => {
    fetchForwardCurves();
  }, [selectedPair]);

  // Adjust individual exposure hedge ratio locally
  const handleHedgeChange = (id: string, ratio: number) => {
    setExposures((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const unhedged = item.notionalBaseValue * (1 - ratio);
          return {
            ...item,
            hedgeRatio: ratio,
            unhedgedExposure: unhedged,
          };
        }
        return item;
      })
    );
  };

  const navTabs: { id: TabId; label: string; icon: React.ComponentType<any> }[] = [
    { id: 'SPOT', label: 'Spot Analytics', icon: Activity },
    { id: 'FORWARD', label: 'Forward pricing', icon: Sliders },
    { id: 'CARRY', label: 'Carry trades', icon: Coins },
    { id: 'PORTFOLIO', label: 'Portfolio exposure', icon: Layers },
    { id: 'RISK', label: 'Risk analytics', icon: ShieldCheck },
    { id: 'MONTE_CARLO', label: 'Monte Carlo', icon: LineIcon },
    { id: 'FORECAST', label: 'Forecasting', icon: BrainCircuit },
    { id: 'STRESS', label: 'Stress testing', icon: Sliders },
    { id: 'GEMINI', label: 'AI Strategy Note', icon: Sparkles },
  ];

  return (
    <div className="min-h-screen bg-[#0F1115] text-[#E0E2E5] flex flex-col font-sans" id="rhinoquant-app-root">
      {/* Upper Navigation Terminal Header */}
      <header className="bg-[#0A0B0D] border-b border-[#1F2937] py-4 px-6 flex flex-col md:flex-row md:items-center justify-between gap-4 sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="bg-amber-500 text-[#0A0B0D] rounded-lg p-2 font-black tracking-wider text-sm border border-amber-400/20 shadow-[0_0_12px_rgba(245,158,11,0.2)]">
            RQ
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-md font-extrabold tracking-tight text-slate-100 uppercase">
                RhinoQuant FX Analytics Engine
              </h1>
              <span className="text-[10px] bg-amber-500/15 text-amber-500 font-bold px-1.5 py-0.5 rounded border border-amber-500/10 uppercase tracking-wide">
                Institutional v1.8 (R-Linked)
              </span>
            </div>
            <p className="text-xs text-[#9CA3AF] mt-0.5">
              Rhino Bank Trading Desk & Portfolio Risk Management Platform
            </p>
          </div>
        </div>

        {/* Global Controller (Currency Pair Selector) */}
        <div className="flex items-center gap-3">
          <span className="text-xs text-[#9CA3AF] font-medium">Focused Currency Leg:</span>
          <select
            value={selectedPair}
            onChange={(e) => setSelectedPair(e.target.value)}
            className="bg-[#0A0B0D] border border-[#1F2937] text-slate-200 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-amber-500 font-bold"
            id="global-focused-pair"
          >
            <option value="EUR/USD">EUR / USD (Euro)</option>
            <option value="GBP/USD">GBP / USD (Sterling)</option>
            <option value="USD/JPY">USD / JPY (Yen)</option>
            <option value="USD/CHF">USD / CHF (Swiss Franc)</option>
            <option value="USD/CAD">USD / CAD (Canadian Dollar)</option>
            <option value="AUD/USD">AUD / USD (Aussie Dollar)</option>
            <option value="NZD/USD">NZD / USD (Kiwi Dollar)</option>
            <option value="USD/ZAR">USD / ZAR (South African Rand)</option>
            <option value="USD/MXN">USD / MXN (Mexican Peso)</option>
          </select>
        </div>
      </header>

      {/* Main Terminal Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6 flex flex-col justify-start">
        {/* Horizontal Navigation Grid */}
        <div className="flex border-b border-[#1F2937] overflow-x-auto pb-1 gap-1" id="tab-navigation">
          {navTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-t-lg text-xs font-semibold whitespace-nowrap border-t border-x transition-all duration-150 ${
                  isActive
                    ? 'bg-[#16191E] border-[#1F2937] text-amber-500 shadow-[0_-2px_10px_rgba(245,158,11,0.06)]'
                    : 'bg-transparent border-transparent text-[#9CA3AF] hover:text-white hover:bg-[#16191E]/30'
                }`}
                id={`tab-btn-${tab.id.toLowerCase()}`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-500' : 'text-[#6B7280]'}`} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab content view containers */}
        {isLoading ? (
          <div className="bg-[#16191E] border border-[#1F2937] rounded-xl p-20 text-center text-[#9CA3AF] text-xs" id="app-global-loading">
            <Activity className="w-8 h-8 text-amber-500 animate-spin mx-auto mb-4" />
            Booting market telemetry, aligning risk-adjusted covariance matrices, initializing algorithms...
          </div>
        ) : (
          <div className="min-h-[500px]" id="tab-content-container">
            {activeTab === 'SPOT' && (
              <SpotAnalyticsView
                spotRates={spotRates}
                currencies={currencies}
                selectedPair={selectedPair}
                setSelectedPair={setSelectedPair}
              />
            )}

            {activeTab === 'FORWARD' && (
              <ForwardPricingView
                selectedPair={selectedPair}
                forwardQuotes={forwardQuotes}
                isLoading={isLoading}
                onRefresh={fetchForwardCurves}
              />
            )}

            {activeTab === 'CARRY' && (
              <CarryTradeView rankings={carryRankings} currencies={currencies} />
            )}

            {activeTab === 'PORTFOLIO' && (
              <PortfolioExposureView exposures={exposures} onHedgeChange={handleHedgeChange} />
            )}

            {activeTab === 'RISK' && (
              <RiskEngineView
                selectedCurrency={selectedRiskCcy}
                onCurrencyChange={(ccy) => setSelectedRiskCcy(ccy as any)}
                availableCurrencies={['EUR', 'GBP', 'JPY', 'CHF', 'CAD', 'ZAR', 'MXN', 'AUD']}
              />
            )}

            {activeTab === 'MONTE_CARLO' && <MonteCarloView selectedPair={selectedPair} />}

            {activeTab === 'FORECAST' && <ForecastingView selectedPair={selectedPair} />}

            {activeTab === 'STRESS' && <StressTestingView />}

            {activeTab === 'GEMINI' && <GeminiResearchView selectedPair={selectedPair} />}
          </div>
        )}
      </main>

      {/* Institutional Legal Footer */}
      <footer className="bg-[#0A0B0D] border-t border-[#1F2937] py-4 px-6 text-center text-[10px] text-[#6B7280] mt-auto flex flex-col md:flex-row md:justify-between items-center gap-2 font-mono">
        <div>
          © 2026 Rhino Bank Quantitative Finance Desk. All calculations conform with global Basel III risk frameworks.
        </div>
        <div className="flex gap-4">
          <a href="#rules" className="hover:text-[#9CA3AF] transition-colors">CIP/UIP Parity Disclaimers</a>
          <span className="text-[#1F2937]">|</span>
          <a href="#audit" className="hover:text-[#9CA3AF] transition-colors">Risk Model Auditing</a>
          <span className="text-[#1F2937]">|</span>
          <a href="#terms" className="hover:text-[#9CA3AF] transition-colors">SEC Form 10-K References</a>
        </div>
      </footer>
    </div>
  );
}
