/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type CurrencyCode =
  | 'USD' | 'EUR' | 'GBP' | 'JPY' | 'CHF' | 'CAD' | 'AUD' | 'NZD'
  | 'SEK' | 'NOK' | 'DKK' | 'SGD' | 'HKD' | 'CNY' | 'INR' | 'AED'
  | 'SAR' | 'ZAR' | 'BRL' | 'MXN' | 'KRW';

export interface CurrencyConfig {
  code: CurrencyCode;
  name: string;
  symbol: string;
  flag: string;
  interestRate: number; // Annual Central Bank Rate (e.g. 0.0525 for 5.25%)
  inflationRate: number; // Annual CPI (e.g. 0.031 for 3.1%)
  isDirectQuote: boolean; // True if quoted as USD per Unit (e.g. EUR/USD), false otherwise
}

export interface SpotRate {
  pair: string; // e.g., "EUR/USD"
  base: CurrencyCode;
  quote: CurrencyCode;
  rate: number;
  bid: number;
  ask: number;
  change24h: number; // percentage
  history30d: number[]; // Daily prices for past 30 days
}

export interface ForwardQuote {
  pair: string;
  tenor: '1M' | '3M' | '6M' | '1Y';
  days: number;
  forwardRate: number;
  forwardPoints: number;
  premiumDiscountAnn: number; // annualised % premium/discount
  interestRateDifferential: number;
  coveredParityRate: number;
  deviationBps: number;
  arbitrageDetected: boolean;
  arbitrageDirection: 'BUY_BASE_SELL_QUOTE' | 'SELL_BASE_BUY_QUOTE' | 'NONE';
}

export interface CarryTradeRanking {
  pair: string;
  borrowCurrency: CurrencyCode;
  lendCurrency: CurrencyCode;
  interestDifferential: number;
  expectedCarryPct: number;
  historicalVolatility: number;
  volatilityAdjustedCarry: number; // expectedCarry / historicalVol
  rank: number;
}

export interface PortfolioExposure {
  id: string;
  currency: CurrencyCode;
  assetClass: 'Cash' | 'Equities' | 'Fixed Income' | 'Real Estate' | 'Alternative';
  businessUnit: 'Treasury' | 'FX Desk' | 'Asset Management' | 'Corporate Advisory';
  notionalBaseValue: number; // in USD
  hedgeRatio: number; // e.g. 0.60 for 60% hedged
  unhedgedExposure: number; // notional * (1 - hedgeRatio)
  pnl1DayUsd: number;
}

export interface RiskMetrics {
  currency: CurrencyCode;
  parametricVaR95: number;
  parametricVaR99: number;
  historicalVaR95: number;
  historicalVaR99: number;
  expectedShortfall95: number;
  expectedShortfall99: number;
  volatilityEWMA: number;
  maxDrawdown30d: number;
}

export interface MonteCarloPath {
  timestamp: string;
  mean: number;
  upper95: number;
  lower95: number;
  simulations: number[][]; // [pathIndex][timeIndex]
}

export interface ForecastResult {
  pair: string;
  historical: { date: string; rate: number }[];
  forecast: { date: string; rate: number; lower95: number; upper95: number }[];
  modelType: 'ARIMA' | 'VAR' | 'ETS' | 'Machine Learning (XGBoost)';
  performanceRMSE: number;
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  interestRateShocks: Record<CurrencyCode, number>; // absolute rate change (e.g., +0.02)
  volatilityMultiplier: number; // multiplier (e.g. 1.5)
  spotShocksPct: Record<CurrencyCode, number>; // percentage shock to USD rates
}
