# @license
# SPDX-License-Identifier: Apache-2.0

#' @title Interest Rate and Purchasing Power Parity Analyzer
#' @description
#' Models pricing deviations, evaluating market efficiencies, and detecting arbitrage bounds.
#' @export
ParityAnalyzer <- R6::R6Class(
  "ParityAnalyzer",
  public = list(
    #' @description
    #' Validates Covered Interest Parity (CIP) deviations on a given market forward rate.
    #' @param base String, base currency.
    #' @param quote String, quote currency.
    #' @param market_forward Numeric, observed market rate.
    #' @param days Integer, maturity days.
    #' @return List containing theoretical forward rate and arbitrage details.
    validate_cip = function(base, quote, market_forward, days) {
      f_engine <- ForwardEngine$new()
      forwards <- f_engine$price_forwards(base, quote)
      row <- forwards[forwards$days == days, ]
      
      theoretical <- row$forward_rate
      deviation_bps <- ((market_forward - theoretical) / theoretical) * 10000
      
      arbitrage <- abs(deviation_bps) > 3.0 # transaction cost threshold
      
      return(list(
        base = base,
        quote = quote,
        market_forward = market_forward,
        theoretical_forward = theoretical,
        deviation_bps = deviation_bps,
        arbitrage_detected = arbitrage
      ))
    },

    #' @description
    #' Calculates Purchasing Power Parity (PPP) Fair Value under the relative inflation framework.
    #' @param base String, foreign currency.
    #' @param quote String, domestic currency.
    #' @return List of PPP fair value and overvaluation percentages.
    calculate_ppp_fair_value = function(base, quote) {
      spot_eng <- SpotEngine$new()
      utils_eng <- RhinoUtilities$new()
      
      spot <- spot_eng$get_spot_cross(base, quote)
      curves <- utils_eng$get_central_bank_curves()
      
      inf_f <- curves$inflation_rate[curves$currency == base]
      inf_d <- curves$inflation_rate[curves$currency == quote]
      
      # Assume base spot of 10 years ago was at fair value
      base_10y_spot <- spot * 1.15
      accumulated_inflation <- ((1 + inf_d)^10) / ((1 + inf_f)^10)
      ppp_value <- base_10y_spot * accumulated_inflation
      
      deviation <- ((spot - ppp_value) / ppp_value) * 100
      
      return(list(
        pair = paste0(base, "/", quote),
        actual_spot = spot,
        ppp_fair_value = ppp_value,
        deviation_pct = deviation
      ))
    }
  )
)
