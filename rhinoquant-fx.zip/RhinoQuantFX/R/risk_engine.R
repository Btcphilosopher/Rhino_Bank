# @license
# SPDX-License-Identifier: Apache-2.0

#' @title Market Risk Engine
#' @description
#' Measures tail-risk parameters (Value at Risk, Expected Shortfall) under normal & non-normal conditions.
#' @export
RiskEngine <- R6::R6Class(
  "RiskEngine",
  public = list(
    #' @description
    #' Computes VaR and ES on a standard base portfolio size ($10,000,000 unit).
    #' @param currency String, ISO target currency.
    #' @param portfolio_size Numeric, default 10M.
    #' @return List of risk indicators.
    calculate_var_es = function(currency, portfolio_size = 10000000) {
      # Simulate a vector of 100 historical returns for the currency
      set.seed(42) # reproducible statistics
      daily_returns <- rnorm(100, mean = 0.0001, sd = 0.0065) # daily return vector
      
      # Volatility calculations
      daily_sd <- sd(daily_returns)
      annual_sd <- daily_sd * sqrt(252)
      
      # Parametric VaR (Normal Z-scores: 1.645 for 95%, 2.326 for 99%)
      parametric_var_95 <- portfolio_size * daily_sd * 1.645
      parametric_var_99 <- portfolio_size * daily_sd * 2.326
      
      # Historical VaR (percentiles of returns)
      sorted_returns <- sort(daily_returns)
      hist_cutoff_95 <- quantile(daily_returns, 0.05)
      hist_cutoff_99 <- quantile(daily_returns, 0.01)
      
      historical_var_95 <- abs(hist_cutoff_95) * portfolio_size
      historical_var_99 <- abs(hist_cutoff_99) * portfolio_size
      
      # Expected Shortfall (average of returns beyond VaR threshold)
      es_tail_95 <- daily_returns[daily_returns <= hist_cutoff_95]
      es_tail_99 <- daily_returns[daily_returns <= hist_cutoff_99]
      
      expected_shortfall_95 <- abs(mean(es_tail_95)) * portfolio_size
      expected_shortfall_99 <- abs(mean(es_tail_99)) * portfolio_size
      
      return(list(
        currency = currency,
        annual_volatility = annual_sd,
        parametric_var_95 = parametric_var_95,
        parametric_var_99 = parametric_var_99,
        historical_var_95 = historical_var_95,
        historical_var_99 = historical_var_99,
        expected_shortfall_95 = expected_shortfall_95,
        expected_shortfall_99 = expected_shortfall_99
      ))
    }
  )
)
