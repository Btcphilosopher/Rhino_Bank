# @license
# SPDX-License-Identifier: Apache-2.0

#' @title Forward FX Engine
#' @description
#' Models forward rate curves, pricing OTC forwards and pricing adjustments.
#' @export
ForwardEngine <- R6::R6Class(
  "ForwardEngine",
  public = list(
    #' @description
    #' Prices forward contracts based on Interest Rate Parity theory.
    #' @param base String, foreign currency.
    #' @param quote String, domestic currency.
    #' @return Data frame containing tenor-based forward valuations.
    price_forwards = function(base, quote) {
      spot_eng <- SpotEngine$new()
      utils_eng <- RhinoUtilities$new()
      
      spot <- spot_eng$get_spot_cross(base, quote)
      curves <- utils_eng$get_central_bank_curves()
      
      r_f <- curves$interest_rate[curves$currency == base]
      r_d <- curves$interest_rate[curves$currency == quote]
      
      tenors <- data.frame(
        tenor = c("1M", "3M", "6M", "1Y"),
        days = c(30, 90, 180, 360),
        stringsAsFactors = FALSE
      )
      
      results <- data.frame(
        tenor = character(),
        days = integer(),
        spot = numeric(),
        forward_rate = numeric(),
        forward_points = numeric(),
        stringsAsFactors = FALSE
      )
      
      for (i in 1:nrow(tenors)) {
        t_days <- tenors$days[i]
        T_yrs <- t_days / 360
        
        # Covered Interest Parity formula
        f_rate <- spot * ((1 + r_d * T_yrs) / (1 + r_f * T_yrs))
        f_pts <- (f_rate - spot) * 10000
        
        results <- rbind(results, data.frame(
          tenor = tenors$tenor[i],
          days = t_days,
          spot = spot,
          forward_rate = f_rate,
          forward_points = f_pts,
          stringsAsFactors = FALSE
        ))
      }
      return(results)
    }
  )
)
