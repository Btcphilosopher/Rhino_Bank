# @license
# SPDX-License-Identifier: Apache-2.0

#' @title Spot Foreign Exchange Engine
#' @description
#' Calculates Spot rate relationships, cross-currency rate matrices,
#' and rolling return statistics for institutional portfolio tracking.
#' @export
SpotEngine <- R6::R6Class(
  "SpotEngine",
  public = list(
    #' @field spot_bases Named list of USD anchor rates.
    spot_bases = list(
      USD = 1.0,
      EUR = 1.0925,
      GBP = 1.2840,
      JPY = 154.20,
      CHF = 0.8845,
      CAD = 1.3680,
      AUD = 0.6650,
      ZAR = 18.25,
      MXN = 18.42
    ),

    #' @description
    #' Computes cross-rates dynamically, ensuring no triangular arbitrage leakages in pricing.
    #' @param base String, ISO currency code.
    #' @param quote String, ISO currency code.
    #' @return Numeric, exchange rate value.
    get_spot_cross = function(base, quote) {
      base_val <- if (base == "USD") 1.0 else {
        if (base %in% c("EUR", "GBP", "AUD")) self$spot_bases[[base]] else 1.0 / self$spot_bases[[base]]
      }
      quote_val <- if (quote == "USD") 1.0 else {
        if (quote %in% c("EUR", "GBP", "AUD")) self$spot_bases[[quote]] else 1.0 / self$spot_bases[[quote]]
      }
      return(base_val / quote_val)
    },

    #' @description
    #' Calculates full spot cross matrix for all configured currencies.
    #' @return Data frame of pairs and cross rates.
    calculate_spot_crosses = function() {
      ccys <- names(self$spot_bases)
      results <- data.frame(pair = character(), rate = numeric(), stringsAsFactors = FALSE)
      
      for (b in ccys) {
        for (q in ccys) {
          if (b == q) next
          pair_name <- paste0(b, "/", q)
          rate_val <- self$get_spot_cross(b, q)
          results <- rbind(results, data.frame(pair = pair_name, rate = rate_val, stringsAsFactors = FALSE))
        }
      }
      return(results)
    }
  )
)
