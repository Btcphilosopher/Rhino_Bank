# @license
# SPDX-License-Identifier: Apache-2.0

#' @title Monte Carlo Path Simulator
#' @description
#' Simulates asset price trajectories using Geometric Brownian Motion (GBM) with jump-diffusion loops.
#' @export
MCEngine <- R6::R6Class(
  "MCEngine",
  public = list(
    #' @description
    #' Generates simulation paths for base/quote pairs.
    #' @param base String, base currency code.
    #' @param quote String, quote currency code.
    #' @param days Integer, time horizon.
    #' @param paths Integer, path dimensions.
    #' @param include_jumps Logical, enable Poisson jumps.
    #' @return Matrix of simulated paths where rows represent paths and columns represent days.
    simulate_paths = function(base, quote, days = 30, paths = 100, include_jumps = TRUE) {
      spot_eng <- SpotEngine$new()
      utils_eng <- RhinoUtilities$new()
      
      spot <- spot_eng$get_spot_cross(base, quote)
      curves <- utils_eng$get_central_bank_curves()
      
      # Volatility of the pair
      vol <- 0.085 # default historical annualised volatility
      
      # Drift (r_d - r_f)
      r_f <- curves$interest_rate[curves$currency == base]
      r_d <- curves$interest_rate[curves$currency == quote]
      mu <- r_d - r_f
      
      dt <- 1 / 252 # daily steps
      
      # Initialise paths matrix
      sim_matrix <- matrix(nrow = paths, ncol = days + 1)
      sim_matrix[, 1] <- spot
      
      for (p in 1:paths) {
        s <- spot
        for (t in 1:days) {
          # Brownian motion random step
          dW <- utils_eng$box_muller(1) * sqrt(dt)
          
          # Optional Merton Poisson Jump
          jump <- 1.0
          if (include_jumps && runif(1) < 0.05) { # 5% probability of Poisson jump
            # Jump size normal distribution
            jump_size <- utils_eng$box_muller(1) * 0.03
            jump <- exp(jump_size)
          }
          
          # GBM formula
          s <- s * exp((mu - 0.5 * (vol^2)) * dt + vol * dW) * jump
          sim_matrix[p, t + 1] <- s
        }
      }
      return(sim_matrix)
    }
  )
)
