# @license
# SPDX-License-Identifier: Apache-2.0

#' @title Quantitative Math and Telemetry Utilities
#' @description Core mathematical utilities, configuration curves, and audit trails for RhinoQuant.
#' @export
RhinoUtilities <- R6::R6Class(
  "RhinoUtilities",
  public = list(
    #' @description
    #' Generates high-fidelity Central Bank yield and inflation structures for Basel validation.
    #' @return A data frame of ISO currency parameters.
    get_central_bank_curves = function() {
      data.frame(
        currency = c("USD", "EUR", "GBP", "JPY", "CHF", "CAD", "AUD", "ZAR", "MXN"),
        interest_rate = c(0.0525, 0.0425, 0.0500, 0.0025, 0.0150, 0.0450, 0.0435, 0.0825, 0.1100),
        inflation_rate = c(0.030, 0.024, 0.028, 0.021, 0.012, 0.025, 0.034, 0.053, 0.045),
        stringsAsFactors = FALSE
      )
    },

    #' @description
    #' Generates normally distributed random numbers via Box-Muller transform for Monte Carlo.
    #' @param n Integer, path count.
    #' @return Numeric vector of standard normals.
    box_muller = function(n) {
      u1 <- runif(n)
      u2 <- runif(n)
      z0 <- sqrt(-2.0 * log(u1)) * cos(2.0 * pi * u2)
      return(z0)
    }
  )
)
