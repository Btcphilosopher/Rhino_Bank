# @license
# SPDX-License-Identifier: Apache-2.0

#' @title Systemic Stress Testing Engine
#' @description
#' Measures absolute and relative portfolio impacts under severe historical macroeconomic shocks.
#' @export
StressEngine <- R6::R6Class(
  "StressEngine",
  public = list(
    #' @description
    #' Applies macroeconomic interest rate and spot rate shocks to institutional exposures.
    #' @param scenario String, name of target stress scenario.
    #' @return Data frame of stressed position adjustments.
    apply_rate_shocks = function(scenario = "Fed Hawkish Surge") {
      # Sample currency exposures book ($M base values)
      exposures <- data.frame(
        id = c("EXP-01", "EXP-02", "EXP-03"),
        currency = c("EUR", "GBP", "JPY"),
        notional_usd = c(45000000, 30000000, 60000000),
        hedge_ratio = c(0.50, 0.75, 0.20),
        stringsAsFactors = FALSE
      )
      
      # Set up shocks for "Fed Hawkish Surge" scenario (USD rate climbs, foreign currencies fall)
      shocks <- data.frame(
        currency = c("EUR", "GBP", "JPY"),
        spot_shock = c(-0.06, -0.05, -0.08), # percentage depreciations
        stringsAsFactors = FALSE
      )
      
      results <- data.frame(
        id = character(),
        currency = character(),
        pre_pnl_usd = numeric(),
        post_pnl_usd = numeric(),
        stringsAsFactors = FALSE
      )
      
      for (i in 1:nrow(exposures)) {
        exp <- exposures[i, ]
        shock_val <- shocks$spot_shock[shocks$currency == exp$currency]
        
        # Unhedged exposure is subject to the spot shock
        unhedged <- exp$notional_usd * (1 - exp$hedge_ratio)
        post_pnl <- unhedged * shock_val
        
        results <- rbind(results, data.frame(
          id = exp$id,
          currency = exp$currency,
          pre_pnl_usd = 0.0, # baseline
          post_pnl_usd = post_pnl,
          stringsAsFactors = FALSE
        ))
      }
      return(results)
    }
  )
)
