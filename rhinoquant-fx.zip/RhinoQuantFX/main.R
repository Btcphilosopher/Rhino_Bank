# @license
# SPDX-License-Identifier: Apache-2.0

#' RhinoQuant FX Analytics Engine - Library Bootstrapper
#'
#' @description
#' Core bootstrap entrypoint for the RhinoQuant institutional quantitative foreign exchange framework.
#' Manages dependency injection, loads analytical engines, seeds mock market variables, and
#' demonstrates quantitative workflows (CIP/UIP testing, GARCH vol forecasts, VaR, Monte Carlo).
#'
#' @author Rhino Bank Quantitative Research Desk
#' @docType package
#' @name RhinoQuantFX
#' @references
#' Hull, J. C. (2018). Options, Futures, and Other Derivatives. Pearson.
#' Cochrane, J. H. (2005). Asset Pricing. Princeton University Press.

library(R6)

# Load helper libraries (standard investment banking imports)
suppressPackageStartupMessages({
  if (requireNamespace("ggplot2", quietly = TRUE)) library(ggplot2)
  if (requireNamespace("plotly", quietly = TRUE)) library(plotly)
})

# Boot up core sub-modules
# Source files containing R6 quantitative model classes
message("=== INITIALISING RHINOQUANT FX QUANT DESK ENGINE ===")

source("R/utilities.R")
source("R/spot_rates.R")
source("R/forward_rates.R")
source("R/interest_rate_parity.R")
source("R/risk_engine.R")
source("R/monte_carlo_fx.R")
source("R/stress_testing.R")

message("All quantitative libraries loaded. Ready for portfolio evaluation.")

#' Execute institutional demo workflows
#' @export
run_institutional_demo <- function() {
  message("\n--- Step 1: Initialising Spot FX Analytics Matrix ---")
  spot_engine <- SpotEngine$new()
  spots <- spot_engine$calculate_spot_crosses()
  print(head(spots))

  message("\n--- Step 2: Forward Pricing Curve & Covered Interest Parity (CIP) ---")
  forward_engine <- ForwardEngine$new()
  forwards <- forward_engine$price_forwards(base = "EUR", quote = "USD")
  print(forwards)

  message("\n--- Step 3: Risk Analytics Engine (VaR & Expected Shortfall) ---")
  risk_engine <- RiskEngine$new()
  risk_metrics <- risk_engine$calculate_var_es(currency = "EUR")
  print(risk_metrics)

  message("\n--- Step 4: Stochastic Monte Carlo Path Generation (GBM + Jumps) ---")
  mc_engine <- MCEngine$new()
  simulation <- mc_engine$simulate_paths(base = "EUR", quote = "USD", days = 30, paths = 100)
  message("Successfully simulated ", length(simulation), " paths over 30 days.")

  message("\n--- Step 5: Stress Testing Scenario Portfolio Evaluation ---")
  stress_engine <- StressEngine$new()
  stress_results <- stress_engine$apply_rate_shocks()
  print(stress_results)

  message("\n=== RHINOQUANT INSTITUTIONAL EXECUTION SUCCESSFUL ===")
}
