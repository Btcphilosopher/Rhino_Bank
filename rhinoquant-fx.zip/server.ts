/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import {
  CURRENCIES,
  getSpotRates,
  getSpotRateForPair,
  calculateForwardQuotes,
  calculatePPPFairValue,
  getCarryTradeRankings,
  CORE_PORTFOLIOS,
  calculateRiskMetrics,
  simulateMonteCarlo,
  generateForecastingResult,
  STRESS_SCENARIOS,
  calculateStressImpact,
} from './src/quant';
import { CurrencyCode } from './src/types';

const app = express();
const PORT = 3000;

app.use(express.json());

// 1. Initialise Gemini API client securely on server side
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// --- API ENDPOINTS ---

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', serverTime: new Date().toISOString() });
});

// Market data & currencies configuration
app.get('/api/market-data', (req, res) => {
  try {
    const spotRates = getSpotRates();
    const carryRankings = getCarryTradeRankings();
    res.json({
      currencies: Object.values(CURRENCIES),
      spotRates,
      carryRankings,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Forward pricing
app.get('/api/forward-pricing', (req, res) => {
  try {
    const { base, quote } = req.query;
    if (!base || !quote) {
      return res.status(400).json({ error: 'Missing base or quote currency parameter' });
    }
    const forwards = calculateForwardQuotes(base as CurrencyCode, quote as CurrencyCode);
    res.json({ base, quote, forwards });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Purchasing Power Parity fair value valuation
app.get('/api/ppp-valuation', (req, res) => {
  try {
    const { base, quote } = req.query;
    if (!base || !quote) {
      return res.status(400).json({ error: 'Missing base or quote parameter' });
    }
    const analysis = calculatePPPFairValue(base as CurrencyCode, quote as CurrencyCode);
    res.json(analysis);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Volatility & Risk analytics (VaR, ES)
app.get('/api/risk-analytics', (req, res) => {
  try {
    const { currency } = req.query;
    if (!currency) {
      return res.status(400).json({ error: 'Missing currency parameter' });
    }
    const spotRates = getSpotRates();
    const match = spotRates.find(r => r.base === currency && r.quote === 'USD');
    const history = match ? match.history30d : Array.from({ length: 30 }, (_, idx) => getSpotRateForPair(currency as CurrencyCode, 'USD') * (1 + (idx - 15) * 0.001));

    const metrics = calculateRiskMetrics(currency as CurrencyCode, history);
    res.json(metrics);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Portfolio Exposure metrics & P&L
app.get('/api/portfolio', (req, res) => {
  try {
    res.json({
      exposures: CORE_PORTFOLIOS,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Monte Carlo simulations
app.get('/api/monte-carlo', (req, res) => {
  try {
    const { base, quote, days, paths, includeJumps } = req.query;
    const daysNum = days ? parseInt(days as string) : 30;
    const pathsNum = paths ? parseInt(paths as string) : 25;
    const jumpsBool = includeJumps === 'true';

    if (!base || !quote) {
      return res.status(400).json({ error: 'Missing base or quote parameter' });
    }

    const simulation = simulateMonteCarlo(
      base as CurrencyCode,
      quote as CurrencyCode,
      daysNum,
      pathsNum,
      jumpsBool
    );
    res.json(simulation);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Time series forecasting
app.get('/api/forecasting', (req, res) => {
  try {
    const { base, quote } = req.query;
    if (!base || !quote) {
      return res.status(400).json({ error: 'Missing base or quote parameter' });
    }
    const result = generateForecastingResult(base as CurrencyCode, quote as CurrencyCode);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Stress testing & Scenarios
app.post('/api/stress-test', (req, res) => {
  try {
    const { scenarioId } = req.body;
    const scenario = STRESS_SCENARIOS.find(s => s.id === scenarioId);
    if (!scenario) {
      return res.status(400).json({ error: 'Invalid or missing scenario ID' });
    }

    const impacts = CORE_PORTFOLIOS.map(exp => {
      const impact = calculateStressImpact(exp, scenario);
      return {
        ...exp,
        ...impact,
      };
    });

    const totalPreStressPnl = CORE_PORTFOLIOS.reduce((acc, exp) => acc + exp.pnl1DayUsd, 0);
    const totalPostStressPnl = impacts.reduce((acc, imp) => acc + imp.stressedPnlUsd, 0);

    res.json({
      scenario,
      portfolioImpacts: impacts,
      summary: {
        totalPreStressPnlUsd: totalPreStressPnl,
        totalStressedPnlUsd: totalPostStressPnl,
        pnlDeltaUsd: totalPostStressPnl - totalPreStressPnl,
        severity: totalPostStressPnl < 0 ? 'High Portfolio Impairment' : 'Moderate Impact',
      },
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Gemini-Powered Market Commentary & Research Note
// Secure server-side call. Never exposes API keys.
app.post('/api/gemini/market-outlook', async (req, res) => {
  try {
    const { base, quote } = req.body;
    
    // Construct real context from our quant models
    const spot = getSpotRateForPair(base || 'EUR', quote || 'USD');
    const forwards = calculateForwardQuotes(base || 'EUR', quote || 'USD');
    const ppp = calculatePPPFairValue(base || 'EUR', quote || 'USD');
    const rankings = getCarryTradeRankings().slice(0, 5);

    const baseConfig = CURRENCIES[base as CurrencyCode] || CURRENCIES.EUR;
    const quoteConfig = CURRENCIES[quote as CurrencyCode] || CURRENCIES.USD;

    const prompt = `
You are the Head of Global Foreign Exchange Strategy and Chief Quantitative Macro Economist at Rhino Bank.
Draft an executive-ready Institutional Quantitative Foreign Exchange Briefing and Portfolio Allocation Guideline.

Focus currency pair: ${base}/${quote} (Spot Rate: ${spot.toFixed(4)})
- Base Currency (${base}) Central Bank Interest Yield: ${(baseConfig.interestRate * 100).toFixed(2)}%, Annual CPI Inflation: ${(baseConfig.inflationRate * 100).toFixed(2)}%
- Quote Currency (${quote}) Central Bank Interest Yield: ${(quoteConfig.interestRate * 100).toFixed(2)}%, Annual CPI Inflation: ${(quoteConfig.inflationRate * 100).toFixed(2)}%

Quantitative Parity Matrix:
1. 3-Month Forward Rate: ${forwards[1].forwardRate.toFixed(4)} (Parity Target: ${forwards[1].coveredParityRate.toFixed(4)})
   - Market Deviation: ${forwards[1].deviationBps.toFixed(2)} bps. Arbitrage detected: ${forwards[1].arbitrageDetected ? 'YES' : 'NO'}.
2. Relative PPP Fair Value estimate (10-Year Relative inflation model): ${ppp.pppFairValue.toFixed(4)}
   - Spot deviation from PPP Fair Value: ${ppp.deviationPct.toFixed(2)}% (Valuation: ${ppp.status})

Top 3 Global Yield Curve Carry Trade Opportunities (ranked by Volatility-Adjusted Sharpe dimension):
${rankings.slice(0, 3).map((r, i) => `${i+1}. Lend ${r.lendCurrency} (${(CURRENCIES[r.lendCurrency].interestRate * 100).toFixed(2)}%) / Borrow ${r.borrowCurrency} (${(CURRENCIES[r.borrowCurrency].interestRate * 100).toFixed(2)}%), Interest Differential: ${r.interestDifferential.toFixed(2)}%, Volatility-Adjusted Carry Index: ${r.volatilityAdjustedCarry.toFixed(2)}`).join('\n')}

Structure your response into 3 highly structured, elegant sections using rich Markdown. Speak with absolute professional authority:
- **Macroeconomic & Central Bank Policy Outlook**: Critically evaluate the interest yield and inflation differentials. What does this mean for capital flows?
- **Parity Deviation & Arbitrage Analysis**: Detail whether Covered Interest Parity (CIP) or Purchasing Power Parity (PPP) shows overvaluation, and whether our institutional desks should execute spatial arbitrage.
- **Strategic Hedging & Allocation Recommendations**: Provide precise recommendation for corporate treasuries on hedging ratios, and for asset managers on carry trade risk-adjusted allocation.
`;

    // Make the secure Gemini API call
    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        temperature: 0.7,
      },
    });

    res.json({
      commentary: response.text,
      modelUsed: 'gemini-3.6-flash',
    });
  } catch (error: any) {
    console.error('Gemini API call failed:', error);
    res.status(500).json({ error: 'Failed to generate quantitative market commentary. Please ensure process.env.GEMINI_API_KEY is configured.' });
  }
});

// --- VITE DEV OR PROD MIDDWARE ---
async function bootstrapServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    // Serve index.html on wildcard (standard React router fallback)
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RhinoQuant FX server booting on http://localhost:${PORT}`);
  });
}

bootstrapServer().catch(err => {
  console.error('Failed to start full-stack server:', err);
});
