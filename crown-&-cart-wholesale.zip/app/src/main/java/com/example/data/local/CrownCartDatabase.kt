package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.model.BasketItem
import com.example.model.CustomerAccount
import com.example.model.Depot
import com.example.model.Order
import com.example.model.OrderLine
import com.example.model.Product
import com.example.model.ProductRecall
import com.example.model.SavedList
import com.example.model.SavedListItem

@Database(
    entities = [
        CustomerAccount::class,
        Product::class,
        Depot::class,
        BasketItem::class,
        SavedList::class,
        SavedListItem::class,
        Order::class,
        OrderLine::class,
        ProductRecall::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class CrownCartDatabase : RoomDatabase() {

    abstract fun dao(): CrownCartDao

    companion object {
        @Volatile
        private var INSTANCE: CrownCartDatabase? = null

        fun getDatabase(context: Context): CrownCartDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CrownCartDatabase::class.java,
                    "crown_cart_wholesale_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
