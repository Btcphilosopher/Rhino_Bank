package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.model.BasketItem
import com.example.model.CustomerAccount
import com.example.model.Depot
import com.example.model.Order
import com.example.model.OrderLine
import com.example.model.Product
import com.example.model.ProductRecall
import com.example.model.SavedList
import com.example.model.SavedListItem
import kotlinx.coroutines.flow.Flow

@Dao
interface CrownCartDao {

    // --- Accounts ---
    @Query("SELECT * FROM customer_accounts")
    fun getAllAccounts(): Flow<List<CustomerAccount>>

    @Query("SELECT * FROM customer_accounts WHERE id = :id LIMIT 1")
    fun getAccountByIdFlow(id: String): Flow<CustomerAccount?>

    @Query("SELECT * FROM customer_accounts WHERE id = :id LIMIT 1")
    suspend fun getAccountById(id: String): CustomerAccount?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccount(account: CustomerAccount)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccounts(accounts: List<CustomerAccount>)

    @Update
    suspend fun updateAccount(account: CustomerAccount)

    // --- Products ---
    @Query("SELECT * FROM products ORDER BY isPromotion DESC, name ASC")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE sku = :sku LIMIT 1")
    suspend fun getProductBySku(sku: String): Product?

    @Query("SELECT * FROM products WHERE ean = :ean LIMIT 1")
    suspend fun getProductByEan(ean: String): Product?

    @Query("SELECT * FROM products WHERE isPromotion = 1")
    fun getPromotions(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE category = :category ORDER BY name ASC")
    fun getProductsByCategory(category: String): Flow<List<Product>>

    @Query("""
        SELECT * FROM products 
        WHERE name LIKE '%' || :query || '%' 
           OR brand LIKE '%' || :query || '%' 
           OR sku LIKE '%' || :query || '%' 
           OR ean LIKE '%' || :query || '%'
           OR category LIKE '%' || :query || '%'
        ORDER BY isPromotion DESC, name ASC
    """)
    fun searchProducts(query: String): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<Product>)

    @Query("SELECT COUNT(*) FROM products")
    suspend fun getProductCount(): Int

    // --- Depots ---
    @Query("SELECT * FROM depots")
    fun getAllDepots(): Flow<List<Depot>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDepots(depots: List<Depot>)

    // --- Basket Items ---
    @Query("SELECT * FROM basket_items WHERE accountId = :accountId")
    fun getBasketForAccount(accountId: String): Flow<List<BasketItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBasketItem(item: BasketItem)

    @Query("DELETE FROM basket_items WHERE id = :itemId")
    suspend fun deleteBasketItem(itemId: Long)

    @Query("DELETE FROM basket_items WHERE accountId = :accountId")
    suspend fun clearBasket(accountId: String)

    @Query("UPDATE basket_items SET quantity = :quantity WHERE id = :itemId")
    suspend fun updateBasketQuantity(itemId: Long, quantity: Int)

    // --- Saved Lists ---
    @Query("SELECT * FROM saved_lists WHERE accountId = :accountId")
    fun getSavedListsForAccount(accountId: String): Flow<List<SavedList>>

    @Query("SELECT * FROM saved_list_items WHERE listId = :listId")
    fun getSavedListItems(listId: Long): Flow<List<SavedListItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedList(savedList: SavedList): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedListItems(items: List<SavedListItem>)

    // --- Orders ---
    @Query("SELECT * FROM orders WHERE accountId = :accountId ORDER BY createdAtTimestamp DESC")
    fun getOrdersForAccount(accountId: String): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE orderNumber = :orderNumber LIMIT 1")
    suspend fun getOrderByNumber(orderNumber: String): Order?

    @Query("SELECT * FROM order_lines WHERE orderNumber = :orderNumber")
    suspend fun getOrderLines(orderNumber: String): List<OrderLine>

    @Query("SELECT * FROM order_lines WHERE orderNumber = :orderNumber")
    fun getOrderLinesFlow(orderNumber: String): Flow<List<OrderLine>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderLines(lines: List<OrderLine>)

    @Query("UPDATE orders SET status = :status WHERE orderNumber = :orderNumber")
    suspend fun updateOrderStatus(orderNumber: String, status: String)

    // --- Product Recalls ---
    @Query("SELECT * FROM product_recalls ORDER BY recallId DESC")
    fun getAllRecalls(): Flow<List<ProductRecall>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecall(recall: ProductRecall)
}
