package com.example.data.local

import androidx.room.TypeConverter
import com.example.model.CustomerType
import com.example.model.DeliveryType
import com.example.model.OrderStatus
import com.example.model.UnitType

class Converters {
    @TypeConverter
    fun fromCustomerType(value: CustomerType): String = value.name

    @TypeConverter
    fun toCustomerType(value: String): CustomerType = try {
        CustomerType.valueOf(value)
    } catch (e: Exception) {
        CustomerType.INDEPENDENT_RETAILER
    }

    @TypeConverter
    fun fromUnitType(value: UnitType): String = value.name

    @TypeConverter
    fun toUnitType(value: String): UnitType = try {
        UnitType.valueOf(value)
    } catch (e: Exception) {
        UnitType.CASE
    }

    @TypeConverter
    fun fromOrderStatus(value: OrderStatus): String = value.name

    @TypeConverter
    fun toOrderStatus(value: String): OrderStatus = try {
        OrderStatus.valueOf(value)
    } catch (e: Exception) {
        OrderStatus.CONFIRMED
    }

    @TypeConverter
    fun fromDeliveryType(value: DeliveryType): String = value.name

    @TypeConverter
    fun toDeliveryType(value: String): DeliveryType = try {
        DeliveryType.valueOf(value)
    } catch (e: Exception) {
        DeliveryType.DELIVERY
    }
}
