package com.example.data.repository

import com.example.data.local.CrownCartDao
import com.example.model.BasketItem
import com.example.model.CustomerAccount
import com.example.model.CustomerType
import com.example.model.DeliveryType
import com.example.model.Depot
import com.example.model.Order
import com.example.model.OrderLine
import com.example.model.OrderStatus
import com.example.model.Product
import com.example.model.ProductRecall
import com.example.model.SavedList
import com.example.model.SavedListItem
import com.example.model.UnitType
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class WholesaleRepository(private val dao: CrownCartDao) {

    val allAccounts: Flow<List<CustomerAccount>> = dao.getAllAccounts()
    val allProducts: Flow<List<Product>> = dao.getAllProducts()
    val promotions: Flow<List<Product>> = dao.getPromotions()
    val allDepots: Flow<List<Depot>> = dao.getAllDepots()
    val allRecalls: Flow<List<ProductRecall>> = dao.getAllRecalls()

    fun getAccountFlow(accountId: String): Flow<CustomerAccount?> = dao.getAccountByIdFlow(accountId)
    fun getBasketFlow(accountId: String): Flow<List<BasketItem>> = dao.getBasketForAccount(accountId)
    fun getOrdersFlow(accountId: String): Flow<List<Order>> = dao.getOrdersForAccount(accountId)
    fun getSavedListsFlow(accountId: String): Flow<List<SavedList>> = dao.getSavedListsForAccount(accountId)
    fun getSavedListItemsFlow(listId: Long): Flow<List<SavedListItem>> = dao.getSavedListItems(listId)

    fun searchProducts(query: String): Flow<List<Product>> {
        return if (query.isBlank()) dao.getAllProducts() else dao.searchProducts(query.trim())
    }

    fun getProductsByCategory(category: String): Flow<List<Product>> {
        return if (category == "All") dao.getAllProducts() else dao.getProductsByCategory(category)
    }

    suspend fun getProductBySku(sku: String): Product? = dao.getProductBySku(sku)
    suspend fun getProductByEan(ean: String): Product? = dao.getProductByEan(ean)

    suspend fun addToBasket(accountId: String, sku: String, unitType: UnitType, qty: Int) {
        val existingBasket = dao.getBasketForAccount(accountId)
        // Insert new item
        dao.insertBasketItem(
            BasketItem(
                accountId = accountId,
                sku = sku,
                unitType = unitType,
                quantity = qty
            )
        )
    }

    suspend fun updateBasketQuantity(itemId: Long, qty: Int) {
        if (qty <= 0) {
            dao.deleteBasketItem(itemId)
        } else {
            dao.updateBasketQuantity(itemId, qty)
        }
    }

    suspend fun removeBasketItem(itemId: Long) {
        dao.deleteBasketItem(itemId)
    }

    suspend fun clearBasket(accountId: String) {
        dao.clearBasket(accountId)
    }

    suspend fun createOrderFromBasket(
        accountId: String,
        basketItems: List<BasketItem>,
        deliveryType: DeliveryType,
        poNumber: String,
        deliverySlot: String
    ): Order? {
        val account = dao.getAccountById(accountId) ?: return null
        if (basketItems.isEmpty()) return null

        var subtotalExVat = 0.0
        var vatTotal = 0.0
        var savingsTotal = 0.0

        val orderNumber = "CC-" + (100000..999999).random()
        val lines = mutableListOf<OrderLine>()

        for (item in basketItems) {
            val product = dao.getProductBySku(item.sku) ?: continue
            val baseCasePrice = if (product.isPromotion) product.promoCasePriceExVat else product.casePriceExVat
            if (product.isPromotion) {
                savingsTotal += (product.casePriceExVat - product.promoCasePriceExVat) * item.quantity
            }

            // Unit multiplier logic
            val unitMultiplier = when (item.unitType) {
                UnitType.EACH -> 1.0 / product.itemsPerCase
                UnitType.CASE -> 1.0
                UnitType.PALLET -> 40.0 // 40 cases per pallet layer
            }

            // Volume break discount: > 10 cases = 5% off, > 50 cases = 10% off
            var effectiveCasePrice = baseCasePrice
            if (item.quantity >= 50) {
                effectiveCasePrice *= 0.90
            } else if (item.quantity >= 10) {
                effectiveCasePrice *= 0.95
            }

            val linePriceExVat = effectiveCasePrice * unitMultiplier
            val lineSubtotalExVat = linePriceExVat * item.quantity
            val lineVat = lineSubtotalExVat * product.vatRate

            subtotalExVat += lineSubtotalExVat
            vatTotal += lineVat

            lines.add(
                OrderLine(
                    orderNumber = orderNumber,
                    sku = product.sku,
                    productName = product.name,
                    packSize = product.packSize,
                    unitType = item.unitType,
                    quantity = item.quantity,
                    unitPriceExVat = linePriceExVat,
                    lineTotalExVat = lineSubtotalExVat
                )
            )
        }

        val totalIncVat = subtotalExVat + vatTotal

        val order = Order(
            orderNumber = orderNumber,
            accountId = accountId,
            depotId = account.depotId,
            deliveryType = deliveryType,
            status = OrderStatus.CONFIRMED,
            subtotalExVat = subtotalExVat,
            vatTotal = vatTotal,
            totalIncVat = totalIncVat,
            savingsTotal = savingsTotal,
            poNumber = poNumber.ifBlank { "PO-${(1000..9999).random()}" },
            deliveryDateSlot = deliverySlot.ifBlank { "Next Working Day (08:00 - 12:00)" },
            deliveryAddress = "${account.tradingName}, ${account.address}, ${account.city}",
            createdAtTimestamp = System.currentTimeMillis()
        )

        dao.insertOrder(order)
        dao.insertOrderLines(lines)

        // Deduct from account balance
        val updatedBalance = account.currentBalance + totalIncVat
        dao.updateAccount(account.copy(currentBalance = updatedBalance))

        // Clear current basket
        dao.clearBasket(accountId)

        return order
    }

    suspend fun updateOrderStatus(orderNumber: String, status: OrderStatus) {
        dao.updateOrderStatus(orderNumber, status.name)
    }

    suspend fun registerNewAccount(
        businessName: String,
        tradingName: String,
        companyNo: String,
        vatNo: String,
        customerType: CustomerType,
        address: String,
        city: String,
        depotId: String
    ): CustomerAccount {
        val newId = "CC-" + (500000..999999).random()
        val account = CustomerAccount(
            id = newId,
            businessName = businessName,
            tradingName = tradingName,
            accountNo = newId,
            depotId = depotId,
            customerType = customerType,
            creditLimit = 15000.0,
            currentBalance = 0.0,
            paymentTermsDays = 30,
            vatNumber = vatNo.ifBlank { "GB${(100000000..999999999).random()}" },
            companyNumber = companyNo.ifBlank { "${(10000000..99999999).random()}" },
            priceListCode = "${customerType.name}-UK-01",
            deliveryRoute = "ROUTE-${city.take(3).uppercase()}-01",
            accountManagerName = "Sarah Mitchell",
            accountManagerPhone = "+44 0121 496 0192",
            address = address,
            city = city
        )
        dao.insertAccount(account)
        return account
    }

    suspend fun addSavedListToBasket(accountId: String, listId: Long) {
        // Collect items from saved list and insert into basket
    }

    suspend fun seedInitialDataIfNeeded() {
        if (dao.getProductCount() > 0) return

        // 1. Seed Accounts
        val accounts = listOf(
            CustomerAccount(
                id = "CC-104829",
                businessName = "Green Dragon Pubs Ltd",
                tradingName = "THE GREEN DRAGON",
                accountNo = "CC-104829",
                depotId = "DEP-BHM",
                customerType = CustomerType.PUB,
                creditLimit = 25000.0,
                currentBalance = 8420.0,
                paymentTermsDays = 30,
                vatNumber = "GB842910382",
                companyNumber = "04928102",
                priceListCode = "PUB-UK-04",
                deliveryRoute = "BHM-07",
                accountManagerName = "Sarah Mitchell",
                accountManagerPhone = "+44 0121 496 0882",
                address = "142 High Street, Digbeth",
                city = "Birmingham"
            ),
            CustomerAccount(
                id = "CC-209411",
                businessName = "Corner Express Retail Ltd",
                tradingName = "PREMIER EXPRESS CORNER SHOP",
                accountNo = "CC-209411",
                depotId = "DEP-LON-W",
                customerType = CustomerType.INDEPENDENT_RETAILER,
                creditLimit = 18000.0,
                currentBalance = 3210.0,
                paymentTermsDays = 14,
                vatNumber = "GB910283741",
                companyNumber = "08291028",
                priceListCode = "RET-UK-02",
                deliveryRoute = "LON-W-18",
                accountManagerName = "Mark Higgins",
                accountManagerPhone = "+44 020 7946 0912",
                address = "88 Uxbridge Road, Ealing",
                city = "London"
            ),
            CustomerAccount(
                id = "CC-304912",
                businessName = "Trattoria Bella Ltd",
                tradingName = "BELLA ITALIA TRATTORIA",
                accountNo = "CC-304912",
                depotId = "DEP-MAN",
                customerType = CustomerType.RESTAURANT,
                creditLimit = 20000.0,
                currentBalance = 4800.0,
                paymentTermsDays = 30,
                vatNumber = "GB729102834",
                companyNumber = "05829102",
                priceListCode = "REST-UK-01",
                deliveryRoute = "MAN-03",
                accountManagerName = "Emma Watson",
                accountManagerPhone = "+44 0161 496 0381",
                address = "24 Deansgate",
                city = "Manchester"
            ),
            CustomerAccount(
                id = "CC-401289",
                businessName = "Golden Dragon Fast Food",
                tradingName = "GOLDEN DRAGON TAKEAWAY",
                accountNo = "CC-401289",
                depotId = "DEP-LDS",
                customerType = CustomerType.TAKEAWAY,
                creditLimit = 10000.0,
                currentBalance = 1950.0,
                paymentTermsDays = 7,
                vatNumber = "GB619283740",
                companyNumber = "06928104",
                priceListCode = "TAK-UK-03",
                deliveryRoute = "LDS-12",
                accountManagerName = "Sarah Mitchell",
                accountManagerPhone = "+44 0121 496 0882",
                address = "52 Headingley Lane",
                city = "Leeds"
            )
        )
        dao.insertAccounts(accounts)

        // 2. Seed Depots
        val depots = listOf(
            Depot("DEP-LON-W", "London West Depot", "London", "Park Royal Industrial Estate, NW10 7QQ", "06:00 – 22:00", "+44 020 8961 1000", "C17", 24),
            Depot("DEP-LON-N", "London North Depot", "London", "Enfield Distribution Park, EN3 7XQ", "06:00 – 22:00", "+44 020 8364 2000", "A04", 20),
            Depot("DEP-BHM", "Birmingham Central Depot", "Birmingham", "Midland Logistics Park, B24 8DW", "05:30 – 22:00", "+44 0121 328 3000", "B08", 30),
            Depot("DEP-MAN", "Manchester Depot", "Manchester", "Trafford Park Wholesale Zone, M17 1EH", "06:00 – 21:30", "+44 0161 872 4000", "M02", 28),
            Depot("DEP-LDS", "Leeds Depot", "Leeds", "Cross Green Industrial Estate, LS9 0SG", "06:00 – 21:00", "+44 0113 240 5000", "L11", 20),
            Depot("DEP-BRS", "Bristol Depot", "Bristol", "Avonmouth Trade Park, BS11 9HS", "06:00 – 21:00", "+44 0117 982 6000", "R05", 18),
            Depot("DEP-GLA", "Glasgow Central Depot", "Glasgow", "Polmadie Industrial Estate, G5 0US", "06:00 – 21:00", "+44 0141 429 7000", "G01", 22)
        )
        dao.insertDepots(depots)

        // 3. Seed Products
        val products = listOf(
            Product(
                sku = "CC-330-24",
                ean = "0500011254820",
                name = "Coca-Cola Original Taste Cans",
                brand = "Coca-Cola",
                category = "Soft Drinks",
                subcategory = "Carbonates",
                packSize = "24 x 330ml",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 17.40,
                vatRate = 0.20,
                rrpEach = 1.10,
                isPromotion = true,
                promoText = "Buy 10 cases Save £1.50/case",
                promoCasePriceExVat = 15.90,
                availableCases = 184,
                warehouseAisle = "Aisle A14",
                warehouseBay = "Bay 07",
                warehouseShelf = "Shelf 03",
                supplierName = "CCHBC GB",
                itemsPerCase = 24
            ),
            Product(
                sku = "CC-DIET-24",
                ean = "0500011254837",
                name = "Diet Coke Cans",
                brand = "Coca-Cola",
                category = "Soft Drinks",
                subcategory = "Carbonates",
                packSize = "24 x 330ml",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 14.80,
                vatRate = 0.20,
                rrpEach = 1.00,
                isPromotion = false,
                availableCases = 120,
                warehouseAisle = "Aisle A14",
                warehouseBay = "Bay 08",
                warehouseShelf = "Shelf 02",
                supplierName = "CCHBC GB",
                itemsPerCase = 24
            ),
            Product(
                sku = "PEP-MAX-24",
                ean = "0500021300291",
                name = "Pepsi MAX No Sugar Cans",
                brand = "Pepsi",
                category = "Soft Drinks",
                subcategory = "Carbonates",
                packSize = "24 x 330ml",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 13.90,
                vatRate = 0.20,
                rrpEach = 0.95,
                isPromotion = true,
                promoText = "3 Cases for £36 Ex VAT",
                promoCasePriceExVat = 12.00,
                availableCases = 210,
                warehouseAisle = "Aisle A15",
                warehouseBay = "Bay 02",
                warehouseShelf = "Shelf 01",
                supplierName = "Britvic Soft Drinks",
                itemsPerCase = 24
            ),
            Product(
                sku = "WALK-RS-32",
                ean = "0500032801124",
                name = "Walkers Ready Salted Crisps",
                brand = "Walkers",
                category = "Crisps & Snacks",
                subcategory = "Crisps",
                packSize = "32 x 25g",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 18.20,
                vatRate = 0.20,
                rrpEach = 0.90,
                isPromotion = false,
                availableCases = 95,
                warehouseAisle = "Aisle C04",
                warehouseBay = "Bay 12",
                warehouseShelf = "Shelf 02",
                supplierName = "PepsiCo UK",
                itemsPerCase = 32
            ),
            Product(
                sku = "WALK-CO-32",
                ean = "0500032801131",
                name = "Walkers Cheese & Onion Crisps",
                brand = "Walkers",
                category = "Crisps & Snacks",
                subcategory = "Crisps",
                packSize = "32 x 25g",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 18.20,
                vatRate = 0.20,
                rrpEach = 0.90,
                isPromotion = true,
                promoText = "Pallet Buy: £16.50/case Ex VAT",
                promoCasePriceExVat = 16.50,
                availableCases = 140,
                warehouseAisle = "Aisle C04",
                warehouseBay = "Bay 13",
                warehouseShelf = "Shelf 02",
                supplierName = "PepsiCo UK",
                itemsPerCase = 32
            ),
            Product(
                sku = "CARL-CAN-24",
                ean = "0500010101021",
                name = "Carling Premium Lager Cans",
                brand = "Carling",
                category = "Alcohol",
                subcategory = "Lager",
                packSize = "24 x 440ml",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 21.50,
                vatRate = 0.20,
                rrpEach = 1.45,
                isPromotion = true,
                promoText = "Pub Bulk Deal: Buy 20 cases get 2 free",
                promoCasePriceExVat = 19.80,
                availableCases = 310,
                warehouseAisle = "Aisle AL02",
                warehouseBay = "Bay 01",
                warehouseShelf = "Floor Pallet",
                supplierName = "Molson Coors UK",
                itemsPerCase = 24
            ),
            Product(
                sku = "GUIN-DR-24",
                ean = "0500021301014",
                name = "Guinness Draught In Can",
                brand = "Guinness",
                category = "Alcohol",
                subcategory = "Stout & Ale",
                packSize = "24 x 440ml",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 26.80,
                vatRate = 0.20,
                rrpEach = 1.75,
                isPromotion = false,
                availableCases = 165,
                warehouseAisle = "Aisle AL03",
                warehouseBay = "Bay 05",
                warehouseShelf = "Floor Pallet",
                supplierName = "Diageo GB",
                itemsPerCase = 24
            ),
            Product(
                sku = "STELLA-BTL-24",
                ean = "0541022814012",
                name = "Stella Artois Belgian Lager Bottles",
                brand = "Stella Artois",
                category = "Alcohol",
                subcategory = "Lager",
                packSize = "24 x 330ml",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 22.90,
                vatRate = 0.20,
                rrpEach = 1.50,
                isPromotion = false,
                availableCases = 88,
                warehouseAisle = "Aisle AL01",
                warehouseBay = "Bay 09",
                warehouseShelf = "Shelf 01",
                supplierName = "AB InBev UK",
                itemsPerCase = 24
            ),
            Product(
                sku = "CAD-DM-24",
                ean = "0500015948392",
                name = "Cadbury Dairy Milk Single Bars",
                brand = "Cadbury",
                category = "Confectionery",
                subcategory = "Chocolate",
                packSize = "24 x 45g",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 15.60,
                vatRate = 0.20,
                rrpEach = 0.95,
                isPromotion = false,
                availableCases = 130,
                warehouseAisle = "Aisle CF01",
                warehouseBay = "Bay 04",
                warehouseShelf = "Shelf 03",
                supplierName = "Mondelez UK",
                itemsPerCase = 24
            ),
            Product(
                sku = "HAR-STAR-12",
                ean = "0400168630102",
                name = "Haribo Starmix Share Bags",
                brand = "Haribo",
                category = "Confectionery",
                subcategory = "Sweets",
                packSize = "12 x 175g",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 11.40,
                vatRate = 0.20,
                rrpEach = 1.25,
                isPromotion = true,
                promoText = "Special £0.85/unit Trade Price",
                promoCasePriceExVat = 10.20,
                availableCases = 220,
                warehouseAisle = "Aisle CF02",
                warehouseBay = "Bay 01",
                warehouseShelf = "Shelf 02",
                supplierName = "Haribo UK",
                itemsPerCase = 12
            ),
            Product(
                sku = "CAT-FLOUR-25KG",
                ean = "0501002938102",
                name = "Crown Catering All Purpose Wheat Flour",
                brand = "Crown Professional",
                category = "Fresh & Catering",
                subcategory = "Ingredients",
                packSize = "1 x 25kg Sack",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 16.50,
                vatRate = 0.0, // Food ingredient zero VAT
                rrpEach = 24.00,
                isPromotion = false,
                availableCases = 75,
                warehouseAisle = "Aisle G08",
                warehouseBay = "Bay 01",
                warehouseShelf = "Floor Pallet",
                supplierName = "ADM Milling UK",
                itemsPerCase = 1
            ),
            Product(
                sku = "CAT-OIL-15L",
                ean = "0501002938119",
                name = "Pure Vegetable Cooking Oil BIB",
                brand = "Crown Professional",
                category = "Fresh & Catering",
                subcategory = "Oils & Fats",
                packSize = "1 x 15L Bag in Box",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 22.80,
                vatRate = 0.0, // Food
                rrpEach = 32.00,
                isPromotion = true,
                promoText = "Buy 5 BIBs get £2.00 off per BIB",
                promoCasePriceExVat = 20.80,
                availableCases = 90,
                warehouseAisle = "Aisle G08",
                warehouseBay = "Bay 04",
                warehouseShelf = "Floor Pallet",
                supplierName = "KTC Edibles",
                itemsPerCase = 1
            ),
            Product(
                sku = "CHICK-BRST-10KG",
                ean = "0501002938126",
                name = "Frozen Grade-A Skinless Chicken Fillets",
                brand = "Crown Farm",
                category = "Fresh & Catering",
                subcategory = "Poultry & Meat",
                packSize = "1 x 10kg Box",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 48.50,
                vatRate = 0.0,
                rrpEach = 68.00,
                isPromotion = false,
                availableCases = 60,
                warehouseAisle = "Aisle FR02",
                warehouseBay = "Bay 03",
                warehouseShelf = "Freezer Bay 02",
                supplierName = "Moy Park Poultry",
                itemsPerCase = 1
            ),
            Product(
                sku = "FAIRY-PRO-5L",
                ean = "0501008827301",
                name = "Fairy Professional Washing Up Liquid Original",
                brand = "Fairy",
                category = "Cleaning & Paper",
                subcategory = "Chemicals",
                packSize = "2 x 5L Bottles",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 24.50,
                vatRate = 0.20,
                rrpEach = 18.00,
                isPromotion = true,
                promoText = "Commercial Kitchen Essential Deal",
                promoCasePriceExVat = 21.90,
                availableCases = 110,
                warehouseAisle = "Aisle H02",
                warehouseBay = "Bay 05",
                warehouseShelf = "Shelf 01",
                supplierName = "P&G Professional",
                itemsPerCase = 2
            ),
            Product(
                sku = "ANDREX-40R",
                ean = "0502905301290",
                name = "Andrex Classic Clean Toilet Tissue",
                brand = "Andrex",
                category = "Cleaning & Paper",
                subcategory = "Paper Products",
                packSize = "40 Rolls",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 19.80,
                vatRate = 0.20,
                rrpEach = 0.75,
                isPromotion = false,
                availableCases = 150,
                warehouseAisle = "Aisle H05",
                warehouseBay = "Bay 02",
                warehouseShelf = "High Rack 01",
                supplierName = "Kimberly-Clark UK",
                itemsPerCase = 40
            ),
            Product(
                sku = "RED-BULL-24",
                ean = "0900249010007",
                name = "Red Bull Energy Drink Cans",
                brand = "Red Bull",
                category = "Soft Drinks",
                subcategory = "Energy",
                packSize = "24 x 250ml",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 23.40,
                vatRate = 0.20,
                rrpEach = 1.65,
                isPromotion = false,
                availableCases = 190,
                warehouseAisle = "Aisle A16",
                warehouseBay = "Bay 01",
                warehouseShelf = "Shelf 03",
                supplierName = "Red Bull UK",
                itemsPerCase = 24
            ),
            Product(
                sku = "HARRO-WTR-24",
                ean = "0501839210291",
                name = "Harrogate Spring Water Still",
                brand = "Harrogate",
                category = "Soft Drinks",
                subcategory = "Water",
                packSize = "24 x 500ml PET",
                defaultUnit = UnitType.CASE,
                casePriceExVat = 7.80,
                vatRate = 0.20,
                rrpEach = 0.75,
                isPromotion = true,
                promoText = "High Margin Margin Driver - 57.8% GP",
                promoCasePriceExVat = 6.50,
                availableCases = 350,
                warehouseAisle = "Aisle A12",
                warehouseBay = "Bay 01",
                warehouseShelf = "Floor Pallet",
                supplierName = "Danone Waters UK",
                itemsPerCase = 24
            )
        )
        dao.insertProducts(products)

        // 4. Seed Saved Lists
        val listId = dao.insertSavedList(
            SavedList(
                accountId = "CC-104829",
                listName = "Weekend Pub Refill",
                categoryTag = "Pub Standard"
            )
        )
        dao.insertSavedListItems(
            listOf(
                SavedListItem(listId = listId, sku = "CARL-CAN-24", defaultQty = 10, defaultUnit = UnitType.CASE),
                SavedListItem(listId = listId, sku = "GUIN-DR-24", defaultQty = 6, defaultUnit = UnitType.CASE),
                SavedListItem(listId = listId, sku = "CC-330-24", defaultQty = 8, defaultUnit = UnitType.CASE),
                SavedListItem(listId = listId, sku = "WALK-RS-32", defaultQty = 4, defaultUnit = UnitType.CASE)
            )
        )

        // 5. Seed Recalls
        dao.insertRecall(
            ProductRecall(
                recallId = "REC-2026-089",
                sku = "HARRO-WTR-24",
                productName = "Harrogate Spring Water Still 24x500ml",
                batchNumber = "BATCH-HRG-88201",
                title = "Packaging Seal Precautionary Notice",
                reason = "Precautionary recall due to potential loose bottle caps in Batch HRG-88201",
                urgency = "HIGH",
                dateIssued = "24 Sep 2026",
                affectedDepots = "London West, Birmingham, Manchester",
                affectedOrdersCount = 14,
                status = "ACTIVE"
            )
        )
    }
}
