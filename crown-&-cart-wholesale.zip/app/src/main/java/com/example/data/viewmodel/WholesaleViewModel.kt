package com.example.data.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.CrownCartDatabase
import com.example.data.repository.WholesaleRepository
import com.example.model.BasketItem
import com.example.model.CustomerAccount
import com.example.model.CustomerType
import com.example.model.DeliveryType
import com.example.model.Depot
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.Product
import com.example.model.ProductRecall
import com.example.model.SavedList
import com.example.model.UnitType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MarginCalcState(
    val costPriceExVat: Double = 17.40,
    val itemsInPack: Int = 24,
    val targetSellingPrice: Double = 1.15
) {
    val unitCostExVat: Double get() = if (itemsInPack > 0) costPriceExVat / itemsInPack else 0.0
    val grossProfitPerUnit: Double get() = targetSellingPrice - unitCostExVat
    val gpMarginPercentage: Double get() = if (targetSellingPrice > 0) (grossProfitPerUnit / targetSellingPrice) * 100.0 else 0.0
    val markupPercentage: Double get() = if (unitCostExVat > 0) (grossProfitPerUnit / unitCostExVat) * 100.0 else 0.0
    val breakEvenPriceExVat: Double get() = unitCostExVat
}

class WholesaleViewModel(application: Application) : AndroidViewModel(application) {

    private val db = CrownCartDatabase.getDatabase(application)
    val repository = WholesaleRepository(db.dao())

    val allAccounts: StateFlow<List<CustomerAccount>> = repository.allAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allDepots: StateFlow<List<Depot>> = repository.allDepots
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val promotions: StateFlow<List<Product>> = repository.promotions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recalls: StateFlow<List<ProductRecall>> = repository.allRecalls
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Account ID State
    private val _selectedAccountId = MutableStateFlow("CC-104829") // Green Dragon
    val selectedAccountId: StateFlow<String> = _selectedAccountId.asStateFlow()

    val currentAccount: StateFlow<CustomerAccount?> = _selectedAccountId
        .flatMapLatest { id -> repository.getAccountFlow(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Ex VAT Toggle (Trade default = true)
    private val _showExVat = MutableStateFlow(true)
    val showExVat: StateFlow<Boolean> = _showExVat.asStateFlow()

    fun toggleExVat() {
        _showExVat.value = !_showExVat.value
    }

    fun selectAccount(accountId: String) {
        _selectedAccountId.value = accountId
    }

    // Navigation Tab (0: Home, 1: Shop, 2: Quick Order, 3: Saved Lists, 4: Orders & Credit, 5: Depots, 6: Staff/Warehouse)
    private val _activeTab = MutableStateFlow(0)
    val activeTab: StateFlow<Int> = _activeTab.asStateFlow()

    fun setTab(index: Int) {
        _activeTab.value = index
    }

    // Search and Category Filter State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(cat: String) {
        _selectedCategory.value = cat
    }

    // Product List Flow
    val filteredProducts: StateFlow<List<Product>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isNotBlank()) {
                repository.searchProducts(query)
            } else {
                _selectedCategory.flatMapLatest { cat ->
                    repository.getProductsByCategory(cat)
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Basket Flow for active account
    val basketItems: StateFlow<List<BasketItem>> = _selectedAccountId
        .flatMapLatest { accId -> repository.getBasketFlow(accId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Orders Flow for active account
    val ordersHistory: StateFlow<List<Order>> = _selectedAccountId
        .flatMapLatest { accId -> repository.getOrdersFlow(accId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Saved Lists Flow
    val savedLists: StateFlow<List<SavedList>> = _selectedAccountId
        .flatMapLatest { accId -> repository.getSavedListsFlow(accId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Product Detail Dialog State
    private val _selectedProductDetail = MutableStateFlow<Product?>(null)
    val selectedProductDetail: StateFlow<Product?> = _selectedProductDetail.asStateFlow()

    fun showProductDetail(product: Product?) {
        _selectedProductDetail.value = product
        if (product != null) {
            _marginCalcState.value = MarginCalcState(
                costPriceExVat = if (product.isPromotion) product.promoCasePriceExVat else product.casePriceExVat,
                itemsInPack = product.itemsPerCase,
                targetSellingPrice = product.rrpEach
            )
        }
    }

    // Margin Calculator State
    private val _marginCalcState = MutableStateFlow(MarginCalcState())
    val marginCalcState: StateFlow<MarginCalcState> = _marginCalcState.asStateFlow()

    fun updateMarginCalcSellingPrice(price: Double) {
        _marginCalcState.value = _marginCalcState.value.copy(targetSellingPrice = price)
    }

    fun updateMarginCalcCostPrice(price: Double) {
        _marginCalcState.value = _marginCalcState.value.copy(costPriceExVat = price)
    }

    // Barcode Scanner Dialog / Screen State
    private val _showScannerDialog = MutableStateFlow(false)
    val showScannerDialog: StateFlow<Boolean> = _showScannerDialog.asStateFlow()

    private val _scannedProductResult = MutableStateFlow<Product?>(null)
    val scannedProductResult: StateFlow<Product?> = _scannedProductResult.asStateFlow()

    fun openBarcodeScanner() {
        _showScannerDialog.value = true
        _scannedProductResult.value = null
    }

    fun closeBarcodeScanner() {
        _showScannerDialog.value = false
    }

    fun simulateBarcodeScan(eanOrSku: String) {
        viewModelScope.launch {
            var found = repository.getProductByEan(eanOrSku)
            if (found == null) {
                found = repository.getProductBySku(eanOrSku)
            }
            if (found == null && filteredProducts.value.isNotEmpty()) {
                found = filteredProducts.value.random()
            }
            _scannedProductResult.value = found
        }
    }

    // Add to Basket action
    fun addToBasket(product: Product, unitType: UnitType = UnitType.CASE, quantity: Int = 1) {
        viewModelScope.launch {
            repository.addToBasket(_selectedAccountId.value, product.sku, unitType, quantity)
        }
    }

    fun updateBasketQty(itemId: Long, newQty: Int) {
        viewModelScope.launch {
            repository.updateBasketQuantity(itemId, newQty)
        }
    }

    fun removeBasketItem(itemId: Long) {
        viewModelScope.launch {
            repository.removeBasketItem(itemId)
        }
    }

    fun clearBasket() {
        viewModelScope.launch {
            repository.clearBasket(_selectedAccountId.value)
        }
    }

    // Checkout / Order Placement State
    private val _poNumber = MutableStateFlow("")
    val poNumber: StateFlow<String> = _poNumber.asStateFlow()

    private val _selectedDeliveryType = MutableStateFlow(DeliveryType.DELIVERY)
    val selectedDeliveryType: StateFlow<DeliveryType> = _selectedDeliveryType.asStateFlow()

    private val _deliveryTimeSlot = MutableStateFlow("Tuesday 08:00 – 11:00")
    val deliveryTimeSlot: StateFlow<String> = _deliveryTimeSlot.asStateFlow()

    fun setPoNumber(po: String) {
        _poNumber.value = po
    }

    fun setDeliveryType(type: DeliveryType) {
        _selectedDeliveryType.value = type
    }

    fun setDeliveryTimeSlot(slot: String) {
        _deliveryTimeSlot.value = slot
    }

    private val _lastPlacedOrder = MutableStateFlow<Order?>(null)
    val lastPlacedOrder: StateFlow<Order?> = _lastPlacedOrder.asStateFlow()

    fun checkoutBasket() {
        viewModelScope.launch {
            val order = repository.createOrderFromBasket(
                accountId = _selectedAccountId.value,
                basketItems = basketItems.value,
                deliveryType = _selectedDeliveryType.value,
                poNumber = _poNumber.value,
                deliverySlot = _deliveryTimeSlot.value
            )
            if (order != null) {
                _lastPlacedOrder.value = order
                _poNumber.value = ""
                setTab(4) // Move to Orders / Delivery tracking tab
            }
        }
    }

    // Registration Dialog State
    private val _showRegisterDialog = MutableStateFlow(false)
    val showRegisterDialog: StateFlow<Boolean> = _showRegisterDialog.asStateFlow()

    fun openRegisterDialog() {
        _showRegisterDialog.value = true
    }

    fun closeRegisterDialog() {
        _showRegisterDialog.value = false
    }

    fun registerAccount(
        businessName: String,
        tradingName: String,
        companyNo: String,
        vatNo: String,
        type: CustomerType,
        address: String,
        city: String,
        depotId: String
    ) {
        viewModelScope.launch {
            val newAcc = repository.registerNewAccount(
                businessName, tradingName, companyNo, vatNo, type, address, city, depotId
            )
            _selectedAccountId.value = newAcc.id
            closeRegisterDialog()
        }
    }

    // Trade Card Dialog State
    private val _showTradeCard = MutableStateFlow(false)
    val showTradeCard: StateFlow<Boolean> = _showTradeCard.asStateFlow()

    fun openTradeCard() {
        _showTradeCard.value = true
    }

    fun closeTradeCard() {
        _showTradeCard.value = false
    }

    // Order Simulation advancement
    fun advanceOrderStatus(orderNumber: String, nextStatus: OrderStatus) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderNumber, nextStatus)
        }
    }

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfNeeded()
        }
    }
}
