package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Depot
import com.example.ui.components.WarehouseMapCanvas
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.CrownNavy
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.WarmCream

@Composable
fun DepotsAndWarehouseMapScreen(
    depots: List<Depot>,
    modifier: Modifier = Modifier
) {
    var selectedDepot by remember { mutableStateOf(depots.firstOrNull() ?: Depot("DEP-LON-W", "London West Depot", "London", "Park Royal Industrial Estate", "06:00 – 22:00", "+44 020 8961 1000", "C17", 24)) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        // Header
        Surface(
            color = CrownNavy,
            shadowElevation = 4.dp
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Map, contentDescription = null, tint = AmberGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "NATIONAL DEPOT NETWORK & WAREHOUSE MAP",
                        color = PaperWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
                Text(
                    text = "Self-service Cash & Carry warehouses across the UK",
                    color = WarmCream,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Interactive Warehouse Map
            item {
                WarehouseMapCanvas(
                    highlightAisle = "Aisle A14",
                    depotName = selectedDepot.name,
                    readyBay = selectedDepot.readyCollectionBay
                )
            }

            // Depots List Title
            item {
                Text(
                    text = "SELECT A CROWN & CART DEPOT",
                    color = CrownNavy,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.8.sp
                )
            }

            items(depots) { depot ->
                val isSelected = selectedDepot.id == depot.id
                Card(
                    colors = CardDefaults.cardColors(containerColor = if (isSelected) CrownNavy else PaperWhite),
                    shape = RoundedCornerShape(8.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedDepot = depot }
                        .testTag("depot_card_${depot.id}")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = depot.name,
                                color = if (isSelected) AmberGold else CrownNavy,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Box(
                                modifier = Modifier
                                    .background(BritishRacingGreen, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "OPEN • ${depot.openHours}",
                                    color = PaperWhite,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Place, contentDescription = null, tint = if (isSelected) PaperWhite else Color.Gray, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(depot.address, color = if (isSelected) WarmCream else Color.DarkGray, fontSize = 11.sp)
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Phone, contentDescription = null, tint = if (isSelected) AmberGold else CrownNavy, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(depot.phone, color = if (isSelected) PaperWhite else CrownNavy, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Text(
                                text = "Collection Bay ${depot.readyCollectionBay} Available",
                                color = if (isSelected) AmberGold else BritishRacingGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
