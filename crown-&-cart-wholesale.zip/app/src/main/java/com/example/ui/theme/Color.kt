package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CrownNavy = Color(0xFF0E1B2E)
val CrownNavyLight = Color(0xFF1E3250)
val BritishRacingGreen = Color(0xFF1B4332)
val BritishRacingGreenLight = Color(0xFF2D6A4F)
val WarmCream = Color(0xFFF7F5F0)
val PaperWhite = Color(0xFFFFFFFF)
val Graphite = Color(0xFF2B2D42)
val WarehouseGrey = Color(0xFFE5E7EB)
val MutedRed = Color(0xFF9E2A2B)
val AmberGold = Color(0xFFD4A373)
val AmberGoldDark = Color(0xFFB58348)
val TradeGreen = Color(0xFF10B981)
val DiscountBadgeRed = Color(0xFFDC2626)

