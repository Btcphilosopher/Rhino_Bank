package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.viewmodel.MarginCalcState
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.CrownNavy
import com.example.ui.theme.Graphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.WarmCream
import java.util.Locale

@Composable
fun MarginCalculatorCard(
    state: MarginCalcState,
    onSellingPriceChanged: (Double) -> Unit,
    onCostPriceChanged: (Double) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CrownNavy),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Title Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Calculate,
                    contentDescription = "Margin Calculator",
                    tint = AmberGold,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "RETAIL / TRADE MARGIN CALCULATOR",
                    color = PaperWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Inputs Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Cost Price Input
                OutlinedTextField(
                    value = String.format(Locale.UK, "%.2f", state.costPriceExVat),
                    onValueChange = { input ->
                        input.toDoubleOrNull()?.let { onCostPriceChanged(it) }
                    },
                    label = { Text("Case Cost Ex VAT", fontSize = 10.sp, color = WarmCream) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AmberGold,
                        unfocusedBorderColor = Color.Gray,
                        focusedTextColor = PaperWhite,
                        unfocusedTextColor = PaperWhite
                    ),
                    modifier = Modifier.weight(1f)
                )

                // Target Selling Price Input
                OutlinedTextField(
                    value = String.format(Locale.UK, "%.2f", state.targetSellingPrice),
                    onValueChange = { input ->
                        input.toDoubleOrNull()?.let { onSellingPriceChanged(it) }
                    },
                    label = { Text("Selling Price Each", fontSize = 10.sp, color = WarmCream) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AmberGold,
                        unfocusedBorderColor = Color.Gray,
                        focusedTextColor = PaperWhite,
                        unfocusedTextColor = PaperWhite
                    ),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Interactive Selling Price Slider
            Text(
                text = "Adjust Retail Price: £${String.format(Locale.UK, "%.2f", state.targetSellingPrice)}",
                color = WarmCream,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
            Slider(
                value = state.targetSellingPrice.toFloat(),
                onValueChange = { onSellingPriceChanged(it.toDouble()) },
                valueRange = 0.50f..10.00f,
                colors = SliderDefaults.colors(
                    thumbColor = AmberGold,
                    activeTrackColor = AmberGold,
                    inactiveTrackColor = Color.Gray
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Calculation Results Matrix
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1E3250))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Unit Cost Ex VAT
                Column(horizontalAlignment = Alignment.Start) {
                    Text("Unit Cost", color = WarmCream.copy(alpha = 0.7f), fontSize = 10.sp)
                    Text("£${String.format(Locale.UK, "%.2f", state.unitCostExVat)}", color = PaperWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                // Profit Per Unit
                Column(horizontalAlignment = Alignment.Start) {
                    Text("GP / Unit", color = WarmCream.copy(alpha = 0.7f), fontSize = 10.sp)
                    Text(
                        text = "£${String.format(Locale.UK, "%.2f", state.grossProfitPerUnit)}",
                        color = if (state.grossProfitPerUnit > 0) BritishRacingGreen else Color.Red,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // GP Margin %
                Column(horizontalAlignment = Alignment.Start) {
                    Text("GP Margin %", color = WarmCream.copy(alpha = 0.7f), fontSize = 10.sp)
                    Box(
                        modifier = Modifier
                            .background(BritishRacingGreen, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${String.format(Locale.UK, "%.1f", state.gpMarginPercentage)}%",
                            color = PaperWhite,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                // Markup %
                Column(horizontalAlignment = Alignment.End) {
                    Text("Markup %", color = WarmCream.copy(alpha = 0.7f), fontSize = 10.sp)
                    Text("${String.format(Locale.UK, "%.1f", state.markupPercentage)}%", color = AmberGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Profit Per Case Summary
            val profitPerCase = state.grossProfitPerUnit * state.itemsInPack
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Break-Even Price: £${String.format(Locale.UK, "%.2f", state.breakEvenPriceExVat)} ex VAT",
                    color = Color.LightGray,
                    fontSize = 10.sp
                )

                Text(
                    text = "Gross Profit Per Case: £${String.format(Locale.UK, "%.2f", profitPerCase)}",
                    color = AmberGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
