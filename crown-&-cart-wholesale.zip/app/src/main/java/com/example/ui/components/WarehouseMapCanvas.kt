package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.CrownNavy
import com.example.ui.theme.PaperWhite

@Composable
fun WarehouseMapCanvas(
    highlightAisle: String = "Aisle A14",
    depotName: String = "London West Depot",
    readyBay: String = "C17",
    modifier: Modifier = Modifier
) {
    var selectedZone by remember { mutableStateOf(highlightAisle) }

    Card(
        colors = CardDefaults.cardColors(containerColor = CrownNavy),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "DEPOT WAREHOUSE MAP",
                        color = AmberGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = depotName,
                        color = PaperWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .background(BritishRacingGreen, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "BAY $readyBay READY",
                        color = PaperWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Interactive 2D Canvas Schematic
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(Color(0xFF14243B), RoundedCornerShape(8.dp))
                    .clickable {
                        // Cycle through selected zones
                        selectedZone = when (selectedZone) {
                            "Aisle A14" -> "Aisle AL02"
                            "Aisle AL02" -> "Aisle C04"
                            "Aisle C04" -> "Aisle G08"
                            else -> "Aisle A14"
                        }
                    }
            ) {
                val w = size.width
                val h = size.height

                // Draw Outer Boundary
                drawRect(
                    color = Color(0xFF2B2D42),
                    topLeft = Offset(10f, 10f),
                    size = Size(w - 20f, h - 20f),
                    style = Stroke(width = 3f)
                )

                // Draw Zones Grid
                // 1. Soft Drinks (Aisles A10-A20)
                val softDrinksColor = if (selectedZone.contains("A14") || selectedZone.contains("Soft")) AmberGold else Color(0xFF254168)
                drawRect(
                    color = softDrinksColor,
                    topLeft = Offset(20f, 20f),
                    size = Size((w - 50f) * 0.45f, (h - 50f) * 0.45f)
                )

                // 2. Alcohol & Beers (Aisles AL01-AL10)
                val alcoholColor = if (selectedZone.contains("AL")) AmberGold else Color(0xFF1E3A5F)
                drawRect(
                    color = alcoholColor,
                    topLeft = Offset(20f + (w - 50f) * 0.5f, 20f),
                    size = Size((w - 50f) * 0.45f, (h - 50f) * 0.45f)
                )

                // 3. Crisps & Confectionery (Aisles C01-C10)
                val crispsColor = if (selectedZone.contains("C04") || selectedZone.contains("Crisps")) AmberGold else Color(0xFF1B385C)
                drawRect(
                    color = crispsColor,
                    topLeft = Offset(20f, 20f + (h - 50f) * 0.5f),
                    size = Size((w - 50f) * 0.45f, (h - 50f) * 0.45f)
                )

                // 4. Catering & Fresh (Aisles G01-G15)
                val cateringColor = if (selectedZone.contains("G08") || selectedZone.contains("Catering")) AmberGold else Color(0xFF2D507B)
                drawRect(
                    color = cateringColor,
                    topLeft = Offset(20f + (w - 50f) * 0.5f, 20f + (h - 50f) * 0.5f),
                    size = Size((w - 50f) * 0.45f, (h - 50f) * 0.45f)
                )

                // Draw Collection Bays & Loading Docks
                drawRect(
                    color = Color(0xFF10B981),
                    topLeft = Offset(w - 45f, (h - 50f) * 0.5f),
                    size = Size(25f, 40f)
                )

                // Draw Target Pin Marker
                val pinX = when {
                    selectedZone.contains("A14") -> 60f
                    selectedZone.contains("AL") -> w * 0.7f
                    selectedZone.contains("C04") -> 60f
                    else -> w * 0.7f
                }
                val pinY = when {
                    selectedZone.contains("A14") -> 60f
                    selectedZone.contains("AL") -> 60f
                    selectedZone.contains("C04") -> h * 0.7f
                    else -> h * 0.7f
                }

                drawCircle(
                    color = Color.Red,
                    radius = 12f,
                    center = Offset(pinX, pinY)
                )
                drawCircle(
                    color = Color.White,
                    radius = 5f,
                    center = Offset(pinX, pinY)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Map Legend & Selection Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Place,
                        contentDescription = null,
                        tint = AmberGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Active Location: $selectedZone",
                        color = PaperWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "Tap map to switch zone",
                    color = Color.LightGray,
                    fontSize = 10.sp
                )
            }
        }
    }
}
