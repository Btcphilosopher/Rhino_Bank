package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Product
import com.example.model.UnitType
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.CrownNavy
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.WarmCream
import java.util.Locale

data class QuickOrderRow(
    var skuOrSearch: String = "",
    var matchedProduct: Product? = null,
    var quantity: Int = 1,
    var unitType: UnitType = UnitType.CASE
)

@Composable
fun QuickOrderScreen(
    allProducts: List<Product>,
    onAddProductToBasket: (Product, UnitType, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val rows = remember {
        mutableStateListOf(
            QuickOrderRow(skuOrSearch = "CC-330-24", matchedProduct = allProducts.firstOrNull { it.sku == "CC-330-24" }, quantity = 10),
            QuickOrderRow(skuOrSearch = "WALK-RS-32", matchedProduct = allProducts.firstOrNull { it.sku == "WALK-RS-32" }, quantity = 8),
            QuickOrderRow(skuOrSearch = "CARL-CAN-24", matchedProduct = allProducts.firstOrNull { it.sku == "CARL-CAN-24" }, quantity = 5),
            QuickOrderRow(skuOrSearch = "FAIRY-PRO-5L", matchedProduct = allProducts.firstOrNull { it.sku == "FAIRY-PRO-5L" }, quantity = 2),
            QuickOrderRow()
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        // Header
        Surface(
            color = CrownNavy,
            shadowElevation = 4.dp
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FormatListNumbered, contentDescription = null, tint = AmberGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "RAPID B2B WHOLESALE ORDER ENTRY SHEET",
                        color = PaperWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
                Text(
                    text = "Type SKU, EAN or product name for fast multi-line entry",
                    color = WarmCream,
                    fontSize = 11.sp
                )
            }
        }

        // Action Buttons Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { rows.add(QuickOrderRow()) },
                colors = ButtonDefaults.buttonColors(containerColor = AmberGold, contentColor = CrownNavy),
                shape = RoundedCornerShape(6.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Row", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("ADD LINE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = {
                    rows.forEach { row ->
                        row.matchedProduct?.let { prod ->
                            onAddProductToBasket(prod, row.unitType, row.quantity)
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CrownNavy, contentColor = PaperWhite),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.testTag("bulk_import_quick_order_btn")
            ) {
                Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("BULK ADD ALL TO ORDER", fontSize = 11.sp, fontWeight = FontWeight.Black)
            }
        }

        // Table Rows
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(rows) { index, row ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = PaperWhite),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("#${index + 1}", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                            // Search Input
                            OutlinedTextField(
                                value = row.skuOrSearch,
                                onValueChange = { input ->
                                    rows[index] = row.copy(
                                        skuOrSearch = input,
                                        matchedProduct = allProducts.firstOrNull {
                                            it.sku.contains(input, ignoreCase = true) ||
                                                    it.name.contains(input, ignoreCase = true) ||
                                                    it.ean.contains(input, ignoreCase = true)
                                        }
                                    )
                                },
                                placeholder = { Text("SKU or Name", fontSize = 11.sp) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AmberGold,
                                    unfocusedBorderColor = Color.LightGray
                                ),
                                modifier = Modifier.weight(1.5f)
                            )

                            // Quantity
                            OutlinedTextField(
                                value = if (row.quantity > 0) row.quantity.toString() else "",
                                onValueChange = { input ->
                                    val q = input.toIntOrNull() ?: 1
                                    rows[index] = row.copy(quantity = q)
                                },
                                label = { Text("Qty", fontSize = 9.sp) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AmberGold,
                                    unfocusedBorderColor = Color.LightGray
                                ),
                                modifier = Modifier.weight(0.7f)
                            )

                            // Unit (CS / EA)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(CrownNavy)
                                    .padding(horizontal = 8.dp, vertical = 12.dp)
                            ) {
                                Text(row.unitType.code, color = PaperWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            // Delete Line
                            IconButton(
                                onClick = { if (rows.size > 1) rows.removeAt(index) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(18.dp))
                            }
                        }

                        // Matched Product info bar
                        row.matchedProduct?.let { prod ->
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(WarmCream, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${prod.name} (${prod.packSize})",
                                    color = CrownNavy,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                val price = if (prod.isPromotion) prod.promoCasePriceExVat else prod.casePriceExVat
                                val lineTotal = price * row.quantity
                                Text(
                                    text = "Line Est: £${String.format(Locale.UK, "%.2f", lineTotal)} Ex VAT",
                                    color = BritishRacingGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
