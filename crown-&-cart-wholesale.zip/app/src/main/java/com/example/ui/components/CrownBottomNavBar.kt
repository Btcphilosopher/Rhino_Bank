package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.CrownNavy
import com.example.ui.theme.PaperWhite

@Composable
fun CrownBottomNavBar(
    activeTab: Int,
    cartItemCount: Int,
    cartTotalExVat: Double,
    showExVat: Boolean,
    onTabSelected: (Int) -> Unit,
    onCartClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxWidth()) {
        NavigationBar(
            containerColor = CrownNavy,
            contentColor = PaperWhite,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            NavigationBarItem(
                selected = activeTab == 0,
                onClick = { onTabSelected(0) },
                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                label = { Text("Home", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = CrownNavy,
                    selectedTextColor = AmberGold,
                    indicatorColor = AmberGold,
                    unselectedIconColor = PaperWhite.copy(alpha = 0.7f),
                    unselectedTextColor = PaperWhite.copy(alpha = 0.7f)
                ),
                modifier = Modifier.testTag("nav_home_tab")
            )

            NavigationBarItem(
                selected = activeTab == 1,
                onClick = { onTabSelected(1) },
                icon = { Icon(Icons.Default.Storefront, contentDescription = "Shop Catalogue") },
                label = { Text("Shop", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = CrownNavy,
                    selectedTextColor = AmberGold,
                    indicatorColor = AmberGold,
                    unselectedIconColor = PaperWhite.copy(alpha = 0.7f),
                    unselectedTextColor = PaperWhite.copy(alpha = 0.7f)
                ),
                modifier = Modifier.testTag("nav_shop_tab")
            )

            NavigationBarItem(
                selected = activeTab == 2,
                onClick = { onTabSelected(2) },
                icon = { Icon(Icons.Default.FormatListNumbered, contentDescription = "Quick Order Sheet") },
                label = { Text("Quick Order", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = CrownNavy,
                    selectedTextColor = AmberGold,
                    indicatorColor = AmberGold,
                    unselectedIconColor = PaperWhite.copy(alpha = 0.7f),
                    unselectedTextColor = PaperWhite.copy(alpha = 0.7f)
                ),
                modifier = Modifier.testTag("nav_quick_order_tab")
            )

            NavigationBarItem(
                selected = activeTab == 3,
                onClick = { onTabSelected(3) },
                icon = { Icon(Icons.Default.ListAlt, contentDescription = "Saved Lists") },
                label = { Text("Lists", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = CrownNavy,
                    selectedTextColor = AmberGold,
                    indicatorColor = AmberGold,
                    unselectedIconColor = PaperWhite.copy(alpha = 0.7f),
                    unselectedTextColor = PaperWhite.copy(alpha = 0.7f)
                ),
                modifier = Modifier.testTag("nav_lists_tab")
            )

            NavigationBarItem(
                selected = activeTab == 4,
                onClick = { onTabSelected(4) },
                icon = { Icon(Icons.Default.ReceiptLong, contentDescription = "Orders & Credit") },
                label = { Text("Orders", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = CrownNavy,
                    selectedTextColor = AmberGold,
                    indicatorColor = AmberGold,
                    unselectedIconColor = PaperWhite.copy(alpha = 0.7f),
                    unselectedTextColor = PaperWhite.copy(alpha = 0.7f)
                ),
                modifier = Modifier.testTag("nav_orders_tab")
            )

            NavigationBarItem(
                selected = activeTab == 5,
                onClick = { onTabSelected(5) },
                icon = { Icon(Icons.Default.Map, contentDescription = "Depots & Map") },
                label = { Text("Depots", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = CrownNavy,
                    selectedTextColor = AmberGold,
                    indicatorColor = AmberGold,
                    unselectedIconColor = PaperWhite.copy(alpha = 0.7f),
                    unselectedTextColor = PaperWhite.copy(alpha = 0.7f)
                ),
                modifier = Modifier.testTag("nav_depots_tab")
            )

            NavigationBarItem(
                selected = activeTab == 6,
                onClick = { onTabSelected(6) },
                icon = { Icon(Icons.Default.Build, contentDescription = "Staff Mode") },
                label = { Text("Staff", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = CrownNavy,
                    selectedTextColor = AmberGold,
                    indicatorColor = AmberGold,
                    unselectedIconColor = PaperWhite.copy(alpha = 0.7f),
                    unselectedTextColor = PaperWhite.copy(alpha = 0.7f)
                ),
                modifier = Modifier.testTag("nav_staff_tab")
            )
        }
    }
}
