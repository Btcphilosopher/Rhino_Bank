package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = AmberGold,
    onPrimary = CrownNavy,
    primaryContainer = CrownNavyLight,
    onPrimaryContainer = PaperWhite,
    secondary = BritishRacingGreenLight,
    onSecondary = PaperWhite,
    tertiary = AmberGoldDark,
    background = CrownNavy,
    onBackground = PaperWhite,
    surface = CrownNavyLight,
    onSurface = PaperWhite,
    surfaceVariant = Graphite,
    onSurfaceVariant = WarmCream,
    error = DiscountBadgeRed
)

private val LightColorScheme = lightColorScheme(
    primary = CrownNavy,
    onPrimary = PaperWhite,
    primaryContainer = WarmCream,
    onPrimaryContainer = CrownNavy,
    secondary = BritishRacingGreen,
    onSecondary = PaperWhite,
    secondaryContainer = Color(0xFFD8F3DC),
    onSecondaryContainer = BritishRacingGreen,
    tertiary = AmberGoldDark,
    onTertiary = PaperWhite,
    background = WarmCream,
    onBackground = Graphite,
    surface = PaperWhite,
    onSurface = Graphite,
    surfaceVariant = Color(0xFFEFECE6),
    onSurfaceVariant = Graphite,
    error = MutedRed
)

@Composable
fun CrownAndCartTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

