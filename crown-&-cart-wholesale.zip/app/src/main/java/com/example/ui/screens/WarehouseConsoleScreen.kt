package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ProductRecall
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.CrownNavy
import com.example.ui.theme.DiscountBadgeRed
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.WarmCream

@Composable
fun WarehouseConsoleScreen(
    recalls: List<ProductRecall>,
    modifier: Modifier = Modifier
) {
    var substitutionAccepted by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        // Header
        Surface(
            color = CrownNavy,
            shadowElevation = 4.dp
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Build, contentDescription = null, tint = AmberGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "INTERNAL WAREHOUSE OPERATIONS CONSOLE",
                        color = PaperWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
                Text(
                    text = "Depot Pick Waves • Substitutions • Product Recall Traceability",
                    color = WarmCream,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Live Pick Wave Metrics
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CrownNavy),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("LIVE DEPOT PICK WAVE METRICS", color = AmberGold, fontSize = 10.sp, fontWeight = FontWeight.Black)

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Orders Pending", color = WarmCream, fontSize = 10.sp)
                                Text("142", color = PaperWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)
                            }
                            Column {
                                Text("Active Pickers", color = WarmCream, fontSize = 10.sp)
                                Text("58", color = PaperWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)
                            }
                            Column {
                                Text("Collection Bays", color = WarmCream, fontSize = 10.sp)
                                Text("36 Ready", color = BritishRacingGreen, fontSize = 18.sp, fontWeight = FontWeight.Black)
                            }
                            Column {
                                Text("Dispatched Today", color = WarmCream, fontSize = 10.sp)
                                Text("226", color = AmberGold, fontSize = 18.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }

            // Product Substitutions Manager Widget
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = PaperWhite),
                    shape = RoundedCornerShape(8.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("ITEM SHORTAGE & SUBSTITUTION APPROVAL", color = CrownNavy, fontSize = 12.sp, fontWeight = FontWeight.Black)
                            Box(
                                modifier = Modifier
                                    .background(DiscountBadgeRed, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("SHORTAGE DETECTED", color = PaperWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text("Unavailable Item: Coca-Cola Original Taste 24 x 330ml (CC-330-24)", color = CrownNavy, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Suggested Replacement: Coca-Cola Zero Sugar 24 x 330ml @ Same Trade Price", color = Color.DarkGray, fontSize = 11.sp)

                        Spacer(modifier = Modifier.height(10.dp))

                        if (substitutionAccepted) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(BritishRacingGreen, RoundedCornerShape(4.dp))
                                    .padding(8.dp)
                            ) {
                                Text("SUBSTITUTION ACCEPTED BY CLIENT", color = PaperWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { substitutionAccepted = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen, contentColor = PaperWhite),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("ACCEPT REPLACEMENT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { },
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("REMOVE FROM ORDER", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Product Safety Recall System Section
            item {
                Text(
                    text = "PRODUCT SAFETY RECALL SYSTEM",
                    color = CrownNavy,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.8.sp
                )
            }

            items(recalls) { recall ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = PaperWhite),
                    shape = RoundedCornerShape(8.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = DiscountBadgeRed)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("RECALL #${recall.recallId}", color = CrownNavy, fontSize = 14.sp, fontWeight = FontWeight.Black)
                            }

                            Box(
                                modifier = Modifier
                                    .background(DiscountBadgeRed, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(recall.urgency, color = PaperWhite, fontSize = 9.sp, fontWeight = FontWeight.Black)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(recall.title, color = CrownNavy, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Affected Product: ${recall.productName} • Batch: ${recall.batchNumber}", color = Color.DarkGray, fontSize = 11.sp)
                        Text("Reason: ${recall.reason}", color = Color.Gray, fontSize = 11.sp)

                        Spacer(modifier = Modifier.height(8.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(WarmCream, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "Traceability Status: ${recall.affectedOrdersCount} Orders Flagged across ${recall.affectedDepots}. Automated SMS & email alerts sent.",
                                color = CrownNavy,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
