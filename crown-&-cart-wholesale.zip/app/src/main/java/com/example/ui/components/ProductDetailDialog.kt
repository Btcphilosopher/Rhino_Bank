package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.viewmodel.MarginCalcState
import com.example.model.Product
import com.example.model.UnitType
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.CrownNavy
import com.example.ui.theme.DiscountBadgeRed
import com.example.ui.theme.Graphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.WarmCream
import java.util.Locale

@Composable
fun ProductDetailDialog(
    product: Product?,
    showExVat: Boolean,
    marginCalcState: MarginCalcState,
    onMarginSellingPriceChanged: (Double) -> Unit,
    onMarginCostPriceChanged: (Double) -> Unit,
    onAddProduct: (Product, UnitType, Int) -> Unit,
    onDismiss: () -> Unit
) {
    if (product == null) return

    var selectedUnit by remember { mutableStateOf(product.defaultUnit) }
    var qty by remember { mutableStateOf(1) }

    val basePriceExVat = if (product.isPromotion) product.promoCasePriceExVat else product.casePriceExVat

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = WarmCream),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(6.dp)
                .testTag("product_detail_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .background(CrownNavy, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = product.brand.uppercase(Locale.UK),
                            color = AmberGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = CrownNavy)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = product.name,
                    color = CrownNavy,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black
                )

                Text(
                    text = "SKU: ${product.sku} • EAN: ${product.ean} • Category: ${product.category}",
                    color = Color.DarkGray,
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Location & Stock Banner
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(CrownNavy)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Place, contentDescription = null, tint = AmberGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${product.warehouseAisle} • ${product.warehouseBay} • ${product.warehouseShelf}",
                            color = PaperWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(BritishRacingGreen, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${product.availableCases} Cases in Stock",
                            color = PaperWhite,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Volume Break Discount Table
                Text(
                    text = "B2B VOLUME BREAK TRADE PRICES",
                    color = CrownNavy,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.8.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(PaperWhite)
                        .border(1.dp, Color.LightGray, RoundedCornerShape(6.dp))
                ) {
                    // Row 1: Standard
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("1 - 9 Cases (Standard)", fontSize = 11.sp, color = CrownNavy, fontWeight = FontWeight.SemiBold)
                        Text("£${String.format(Locale.UK, "%.2f", basePriceExVat)} Ex VAT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CrownNavy)
                    }

                    // Row 2: 10+ Cases
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(WarmCream)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("10 - 49 Cases (5% Vol Discount)", fontSize = 11.sp, color = BritishRacingGreen, fontWeight = FontWeight.Bold)
                        Text("£${String.format(Locale.UK, "%.2f", basePriceExVat * 0.95)} Ex VAT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BritishRacingGreen)
                    }

                    // Row 3: 50+ Cases
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("50+ Cases / Pallet (10% Vol Discount)", fontSize = 11.sp, color = DiscountBadgeRed, fontWeight = FontWeight.Bold)
                        Text("£${String.format(Locale.UK, "%.2f", basePriceExVat * 0.90)} Ex VAT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DiscountBadgeRed)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Embedded Interactive ROI Margin Calculator
                MarginCalculatorCard(
                    state = marginCalcState,
                    onSellingPriceChanged = onMarginSellingPriceChanged,
                    onCostPriceChanged = onMarginCostPriceChanged
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Quantity & Add to Basket Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Qty Stepper
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .border(1.dp, Color.LightGray, RoundedCornerShape(6.dp))
                            .background(PaperWhite)
                    ) {
                        IconButton(
                            onClick = { if (qty > 1) qty-- },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Minus", tint = CrownNavy)
                        }

                        Text(
                            text = "$qty",
                            color = CrownNavy,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp)
                        )

                        IconButton(
                            onClick = { qty++ },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Plus", tint = CrownNavy)
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Button(
                        onClick = {
                            onAddProduct(product, selectedUnit, qty)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrownNavy, contentColor = PaperWhite),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ADD $qty CASES TO ORDER", fontSize = 12.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}
