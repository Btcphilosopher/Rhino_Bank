package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.CustomerType
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CrownNavy
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.WarmCream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeRegistrationDialog(
    onDismiss: () -> Unit,
    onSubmit: (businessName: String, tradingName: String, companyNo: String, vatNo: String, type: CustomerType, address: String, city: String, depotId: String) -> Unit
) {
    var businessName by remember { mutableStateOf("") }
    var tradingName by remember { mutableStateOf("") }
    var companyNo by remember { mutableStateOf("") }
    var vatNo by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(CustomerType.INDEPENDENT_RETAILER) }
    var address by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("London") }
    var typeDropdownExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = CrownNavy),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
                .testTag("trade_registration_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // Title Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Business, contentDescription = null, tint = AmberGold)
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(
                            text = "REGISTER BUSINESS ACCOUNT",
                            color = PaperWhite,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = PaperWhite)
                    }
                }

                Text(
                    text = "Application for Crown & Cart B2B Cash & Carry Access",
                    color = WarmCream,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Business Name Input
                OutlinedTextField(
                    value = businessName,
                    onValueChange = { businessName = it },
                    label = { Text("Registered Business Name", color = WarmCream, fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AmberGold, focusedTextColor = PaperWhite, unfocusedTextColor = PaperWhite),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reg_business_name")
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Trading Name Input
                OutlinedTextField(
                    value = tradingName,
                    onValueChange = { tradingName = it },
                    label = { Text("Trading Name (Venue / Shop Name)", color = WarmCream, fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AmberGold, focusedTextColor = PaperWhite, unfocusedTextColor = PaperWhite),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reg_trading_name")
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Business Type Dropdown
                ExposedDropdownMenuBox(
                    expanded = typeDropdownExpanded,
                    onExpandedChange = { typeDropdownExpanded = !typeDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedType.displayName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Business Type", color = WarmCream, fontSize = 11.sp) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeDropdownExpanded) },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AmberGold, focusedTextColor = PaperWhite, unfocusedTextColor = PaperWhite),
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )

                    ExposedDropdownMenu(
                        expanded = typeDropdownExpanded,
                        onDismissRequest = { typeDropdownExpanded = false },
                        modifier = Modifier.background(CrownNavy)
                    ) {
                        CustomerType.values().forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type.displayName, color = PaperWhite) },
                                onClick = {
                                    selectedType = type
                                    typeDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Company No & VAT No
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = companyNo,
                        onValueChange = { companyNo = it },
                        label = { Text("Company No", color = WarmCream, fontSize = 10.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AmberGold, focusedTextColor = PaperWhite, unfocusedTextColor = PaperWhite),
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = vatNo,
                        onValueChange = { vatNo = it },
                        label = { Text("VAT No", color = WarmCream, fontSize = 10.sp) },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AmberGold, focusedTextColor = PaperWhite, unfocusedTextColor = PaperWhite),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Address & City
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Business Address", color = WarmCream, fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AmberGold, focusedTextColor = PaperWhite, unfocusedTextColor = PaperWhite),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = city,
                    onValueChange = { city = it },
                    label = { Text("City / Town", color = WarmCream, fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AmberGold, focusedTextColor = PaperWhite, unfocusedTextColor = PaperWhite),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        val bName = businessName.ifBlank { "Apex Trading Ltd" }
                        val tName = tradingName.ifBlank { "APEX STORES" }
                        val cNo = companyNo.ifBlank { "09820192" }
                        val vNo = vatNo.ifBlank { "GB882910283" }
                        val addr = address.ifBlank { "10 Commercial Road" }
                        val depot = "DEP-LON-W"
                        onSubmit(bName, tName, cNo, vNo, selectedType, addr, city, depot)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberGold, contentColor = CrownNavy),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("submit_registration_btn")
                ) {
                    Text("SUBMIT BUSINESS APPLICATION", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}
