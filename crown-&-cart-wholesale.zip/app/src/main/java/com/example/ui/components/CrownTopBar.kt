package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CustomerAccount
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.CrownNavy
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.WarmCream
import java.util.Locale

@Composable
fun CrownTopBar(
    currentAccount: CustomerAccount?,
    accounts: List<CustomerAccount>,
    showExVat: Boolean,
    onToggleExVat: () -> Unit,
    onSelectAccount: (String) -> Unit,
    onOpenRegister: () -> Unit,
    onOpenTradeCard: () -> Unit,
    modifier: Modifier = Modifier
) {
    var dropdownExpanded by remember { mutableStateOf(false) }

    Surface(
        color = CrownNavy,
        contentColor = PaperWhite,
        shadowElevation = 6.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // Main Top Bar Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Brand Title & Account Switcher
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(AmberGold, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "CROWN & CART",
                                color = CrownNavy,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "WHOLESALE",
                            color = PaperWhite.copy(alpha = 0.8f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.2.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Account Selector Dropdown trigger
                    Box {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF1E3250))
                                .clickable { dropdownExpanded = true }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .testTag("account_switcher_dropdown")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Business,
                                contentDescription = "Business Account",
                                tint = AmberGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = currentAccount?.tradingName ?: "SELECT BUSINESS",
                                color = PaperWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Expand",
                                tint = PaperWhite
                            )
                        }

                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false },
                            modifier = Modifier.background(CrownNavy)
                        ) {
                            Text(
                                text = "SELECT BUSINESS ACCOUNT",
                                color = AmberGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                            )
                            accounts.forEach { acc ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(acc.tradingName, color = PaperWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text("${acc.customerType.displayName} • Acc ${acc.accountNo}", color = Color.LightGray, fontSize = 11.sp)
                                        }
                                    },
                                    onClick = {
                                        onSelectAccount(acc.id)
                                        dropdownExpanded = false
                                    }
                                )
                            }
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.PersonAdd, contentDescription = null, tint = AmberGold, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("+ Register New Business", color = AmberGold, fontWeight = FontWeight.Bold)
                                    }
                                },
                                onClick = {
                                    dropdownExpanded = false
                                    onOpenRegister()
                                }
                            )
                        }
                    }
                }

                // Ex/Inc VAT Switch & Digital Trade Card Icon
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Digital Trade Card Button
                    IconButton(
                        onClick = onOpenTradeCard,
                        modifier = Modifier.testTag("digital_trade_card_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode,
                            contentDescription = "Trade Card",
                            tint = AmberGold,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // VAT Toggle Pill
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF1E3250))
                            .clickable { onToggleExVat() }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("vat_toggle_switch")
                    ) {
                        Text(
                            text = if (showExVat) "EX VAT" else "INC VAT",
                            color = if (showExVat) AmberGold else Color.Green,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            // Account Financial Header Bar
            if (currentAccount != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF14243B))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Credit Limit: ",
                            color = PaperWhite.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                        Text(
                            text = "£${String.format(Locale.UK, "%,.0f", currentAccount.creditLimit)}",
                            color = PaperWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Balance: ",
                            color = PaperWhite.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                        Text(
                            text = "£${String.format(Locale.UK, "%,.2f", currentAccount.currentBalance)}",
                            color = AmberGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    val availCredit = currentAccount.creditLimit - currentAccount.currentBalance
                    Box(
                        modifier = Modifier
                            .background(
                                if (availCredit > 0) BritishRacingGreen else Color(0xFF9E2A2B),
                                RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Avail: £${String.format(Locale.UK, "%,.0f", availCredit)}",
                            color = PaperWhite,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
