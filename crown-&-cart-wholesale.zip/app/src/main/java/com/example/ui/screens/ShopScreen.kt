package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Product
import com.example.model.UnitType
import com.example.ui.components.ProductCard
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.CrownNavy
import com.example.ui.theme.Graphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.WarmCream

@Composable
fun ShopScreen(
    products: List<Product>,
    searchQuery: String,
    selectedCategory: String,
    showExVat: Boolean,
    onSearchChanged: (String) -> Unit,
    onCategorySelected: (String) -> Unit,
    onAddProduct: (Product, UnitType, Int) -> Unit,
    onOpenDetail: (Product) -> Unit,
    modifier: Modifier = Modifier
) {
    val categories = listOf("All", "Soft Drinks", "Alcohol", "Crisps & Snacks", "Confectionery", "Fresh & Catering", "Cleaning & Paper")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        // Search Bar Area
        Surface(
            color = CrownNavy,
            shadowElevation = 4.dp
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChanged,
                    placeholder = { Text("Search product name, SKU, EAN or brand...", color = Color.Gray, fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = AmberGold) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchChanged("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = PaperWhite)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = PaperWhite,
                        unfocusedContainerColor = PaperWhite,
                        focusedTextColor = CrownNavy,
                        unfocusedTextColor = CrownNavy
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("shop_search_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Horizontal Category Chips
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories) { category ->
                        val isSelected = selectedCategory == category
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) AmberGold else Color(0xFF1E3250))
                                .clickable { onCategorySelected(category) }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                .testTag("cat_chip_$category")
                        ) {
                            Text(
                                text = category,
                                color = if (isSelected) CrownNavy else PaperWhite,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Header Summary Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${products.size} WHOLESALE PRODUCTS FOUND",
                color = CrownNavy,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.8.sp
            )

            Text(
                text = if (showExVat) "PRICES EX VAT" else "PRICES INC VAT",
                color = BritishRacingGreen,
                fontSize = 10.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }

        // Products List
        if (products.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FilterList, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No wholesale products found", color = CrownNavy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Try searching for 'Coca-Cola', 'Walkers', 'Carling' or 'Flour'", color = Color.Gray, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(products, key = { it.sku }) { product ->
                    ProductCard(
                        product = product,
                        showExVat = showExVat,
                        onAddProduct = onAddProduct,
                        onOpenDetail = onOpenDetail
                    )
                }
            }
        }
    }
}
