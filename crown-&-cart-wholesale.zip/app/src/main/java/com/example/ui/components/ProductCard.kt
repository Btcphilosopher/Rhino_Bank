package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Product
import com.example.model.UnitType
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.CrownNavy
import com.example.ui.theme.DiscountBadgeRed
import com.example.ui.theme.Graphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.WarmCream
import java.util.Locale

@Composable
fun ProductCard(
    product: Product,
    showExVat: Boolean,
    onAddProduct: (Product, UnitType, Int) -> Unit,
    onOpenDetail: (Product) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedUnit by remember { mutableStateOf(product.defaultUnit) }
    var qty by remember { mutableStateOf(1) }

    val effectiveCasePriceExVat = if (product.isPromotion) product.promoCasePriceExVat else product.casePriceExVat
    val effectivePriceExVat = when (selectedUnit) {
        UnitType.EACH -> effectiveCasePriceExVat / product.itemsPerCase
        UnitType.CASE -> effectiveCasePriceExVat
        UnitType.PALLET -> effectiveCasePriceExVat * 40.0
    }

    val displayPrice = if (showExVat) effectivePriceExVat else effectivePriceExVat * (1.0 + product.vatRate)
    val unitCostPerItemExVat = effectiveCasePriceExVat / product.itemsPerCase
    val profitPerUnit = product.rrpEach - unitCostPerItemExVat
    val gpMargin = if (product.rrpEach > 0) (profitPerUnit / product.rrpEach) * 100.0 else 0.0

    Card(
        colors = CardDefaults.cardColors(containerColor = PaperWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onOpenDetail(product) }
            .testTag("product_card_${product.sku}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Header: Brand & Promotion Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = product.brand.uppercase(Locale.UK),
                    color = AmberGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )

                if (product.isPromotion) {
                    Box(
                        modifier = Modifier
                            .background(DiscountBadgeRed, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.LocalOffer,
                                contentDescription = null,
                                tint = PaperWhite,
                                modifier = Modifier.size(10.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "TRADE DEAL",
                                color = PaperWhite,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            // Product Name
            Text(
                text = product.name,
                color = CrownNavy,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            // Pack Size & SKU
            Row(
                modifier = Modifier.padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .background(WarmCream, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Pack: ${product.packSize}",
                        color = Graphite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "SKU: ${product.sku}",
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }

            // Warehouse Location & Stock Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Place,
                        contentDescription = "Aisle",
                        tint = BritishRacingGreen,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "${product.warehouseAisle} • ${product.warehouseBay}",
                        color = BritishRacingGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "${product.availableCases} cases available",
                    color = if (product.availableCases > 20) BritishRacingGreen else DiscountBadgeRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            if (product.isPromotion && product.promoText.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = product.promoText,
                    color = DiscountBadgeRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Price & Margin Overview Box
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(WarmCream, RoundedCornerShape(6.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "£${String.format(Locale.UK, "%.2f", displayPrice)}",
                            color = CrownNavy,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (showExVat) "Ex VAT" else "Inc VAT",
                            color = Color.Gray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (selectedUnit == UnitType.CASE) {
                        Text(
                            text = "Unit Cost: £${String.format(Locale.UK, "%.2f", unitCostPerItemExVat)} ex VAT",
                            color = Color.DarkGray,
                            fontSize = 10.sp
                        )
                    }
                }

                // Retail Margin ROI Badge
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "RRP: £${String.format(Locale.UK, "%.2f", product.rrpEach)}",
                        color = Graphite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .background(BritishRacingGreen, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${String.format(Locale.UK, "%.1f", gpMargin)}% GP Margin",
                            color = PaperWhite,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Unit Selector Pills (CS / EA / PL)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                UnitType.values().forEach { unit ->
                    val isSelected = selectedUnit == unit
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) CrownNavy else WarmCream)
                            .border(
                                width = 1.dp,
                                color = if (isSelected) CrownNavy else Color.LightGray,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .clickable { selectedUnit = unit }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = unit.code,
                            color = if (isSelected) PaperWhite else CrownNavy,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Quantity Control & Add To Basket Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quantity Stepper
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .border(1.dp, Color.LightGray, RoundedCornerShape(6.dp))
                        .background(WarmCream)
                ) {
                    IconButton(
                        onClick = { if (qty > 1) qty-- },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = CrownNavy, modifier = Modifier.size(16.dp))
                    }

                    Text(
                        text = "$qty",
                        color = CrownNavy,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    IconButton(
                        onClick = { qty++ },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Increase", tint = CrownNavy, modifier = Modifier.size(16.dp))
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Add To Basket Button
                Button(
                    onClick = { onAddProduct(product, selectedUnit, qty) },
                    colors = ButtonDefaults.buttonColors(containerColor = CrownNavy, contentColor = PaperWhite),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("add_to_cart_btn_${product.sku}")
                ) {
                    Icon(
                        Icons.Default.AddShoppingCart,
                        contentDescription = "Add",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ADD ${qty} ${selectedUnit.code}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
