package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CustomerAccount
import com.example.model.Order
import com.example.model.Product
import com.example.model.ProductRecall
import com.example.model.UnitType
import com.example.ui.components.ProductCard
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.CrownNavy
import com.example.ui.theme.DiscountBadgeRed
import com.example.ui.theme.Graphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.WarmCream
import java.util.Locale

@Composable
fun HomeScreen(
    account: CustomerAccount?,
    promotions: List<Product>,
    regulars: List<Product>,
    activeOrders: List<Order>,
    recalls: List<ProductRecall>,
    showExVat: Boolean,
    onSearchClicked: () -> Unit,
    onOpenScanner: () -> Unit,
    onOpenQuickOrder: () -> Unit,
    onOpenDepots: () -> Unit,
    onOpenOrders: () -> Unit,
    onAddProduct: (Product, UnitType, Int) -> Unit,
    onOpenDetail: (Product) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmCream)
            .verticalScroll(rememberScrollState())
            .padding(14.dp)
    ) {
        // Hero B2B Headline Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(CrownNavy)
                .padding(16.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(AmberGold, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = account?.customerType?.displayName?.uppercase(Locale.UK) ?: "TRADE CUSTOMER",
                            color = CrownNavy,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "BUY IN BULK • BUY AT TRADE PRICE",
                        color = WarmCream,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "WHAT DOES YOUR BUSINESS NEED TODAY?",
                    color = PaperWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    lineHeight = 22.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Search Bar Fake Input
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(PaperWhite)
                        .clickable { onSearchClicked() }
                        .padding(horizontal = 12.dp, vertical = 12.dp)
                ) {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = CrownNavy)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Search 10,000+ products, SKUs, brands or EAN...",
                        color = Color.Gray,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Quick Action Grid Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Scan Barcode
            Card(
                colors = CardDefaults.cardColors(containerColor = PaperWhite),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onOpenScanner() }
                    .testTag("quick_action_scan")
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan", tint = AmberGold, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Scan Barcode", color = CrownNavy, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Quick Order Sheet
            Card(
                colors = CardDefaults.cardColors(containerColor = PaperWhite),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onOpenQuickOrder() }
                    .testTag("quick_action_quick_order")
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.FormatListNumbered, contentDescription = "Quick Sheet", tint = BritishRacingGreen, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Quick Order", color = CrownNavy, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Reorder Previous
            Card(
                colors = CardDefaults.cardColors(containerColor = PaperWhite),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onOpenOrders() }
                    .testTag("quick_action_reorder")
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Repeat, contentDescription = "Reorder", tint = CrownNavy, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Reorder Last", color = CrownNavy, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Depots & Map
            Card(
                colors = CardDefaults.cardColors(containerColor = PaperWhite),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onOpenDepots() }
                    .testTag("quick_action_depots")
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Map, contentDescription = "Depots", tint = CrownNavy, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Depot Finder", color = CrownNavy, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Active Delivery Status Banner if order in progress
        val latestActiveOrder = activeOrders.firstOrNull()
        if (latestActiveOrder != null) {
            Spacer(modifier = Modifier.height(14.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = CrownNavy),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenOrders() }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.LocalShipping, contentDescription = "Delivery", tint = AmberGold, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "ORDER #${latestActiveOrder.orderNumber} • ${latestActiveOrder.status.label}",
                            color = PaperWhite,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Route: ${latestActiveOrder.driverRouteCode} • Driver: ${latestActiveOrder.driverName}",
                            color = WarmCream,
                            fontSize = 11.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .background(BritishRacingGreen, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("TRACK", color = PaperWhite, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        // Product Recall Safety Alert if any
        val activeRecall = recalls.firstOrNull()
        if (activeRecall != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFFFEF2F2))
                    .border(1.dp, DiscountBadgeRed, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = "Recall", tint = DiscountBadgeRed, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "SAFETY NOTICE: ${activeRecall.title}",
                            color = DiscountBadgeRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${activeRecall.productName} (${activeRecall.batchNumber})",
                            color = Graphite,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Your Regulars Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "YOUR REGULAR STOCK REFILLS",
                color = CrownNavy,
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.8.sp
            )

            Text(
                text = "View All",
                color = BritishRacingGreen,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onSearchClicked() }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            regulars.take(5).forEach { product ->
                ProductCard(
                    product = product,
                    showExVat = showExVat,
                    onAddProduct = onAddProduct,
                    onOpenDetail = onOpenDetail
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // This Week's Deals Carousel
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocalOffer, contentDescription = null, tint = DiscountBadgeRed, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "THIS WEEK'S HIGH-MARGIN PROMOTIONS",
                    color = CrownNavy,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.8.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(promotions) { promoProduct ->
                Box(modifier = Modifier.width(280.dp)) {
                    ProductCard(
                        product = promoProduct,
                        showExVat = showExVat,
                        onAddProduct = onAddProduct,
                        onOpenDetail = onOpenDetail
                    )
                }
            }
        }
    }
}
