package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditScore
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BasketItem
import com.example.model.CustomerAccount
import com.example.model.DeliveryType
import com.example.model.Product
import com.example.model.UnitType
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.CrownNavy
import com.example.ui.theme.DiscountBadgeRed
import com.example.ui.theme.Graphite
import com.example.ui.theme.PaperWhite
import com.example.ui.theme.WarmCream
import java.util.Locale

@Composable
fun BasketAndCheckoutScreen(
    account: CustomerAccount?,
    basketItems: List<BasketItem>,
    allProducts: List<Product>,
    poNumber: String,
    deliveryType: DeliveryType,
    deliverySlot: String,
    showExVat: Boolean,
    onPoNumberChanged: (String) -> Unit,
    onDeliveryTypeChanged: (DeliveryType) -> Unit,
    onDeliverySlotChanged: (String) -> Unit,
    onUpdateBasketQty: (Long, Int) -> Unit,
    onRemoveBasketItem: (Long) -> Unit,
    onClearBasket: () -> Unit,
    onCheckout: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Calculate Totals
    var subtotalExVat = 0.0
    var vatTotal = 0.0
    var totalSavings = 0.0

    basketItems.forEach { item ->
        val product = allProducts.firstOrNull { it.sku == item.sku }
        if (product != null) {
            val basePrice = if (product.isPromotion) product.promoCasePriceExVat else product.casePriceExVat
            if (product.isPromotion) {
                totalSavings += (product.casePriceExVat - product.promoCasePriceExVat) * item.quantity
            }

            var effectivePrice = basePrice
            if (item.quantity >= 50) effectivePrice *= 0.90
            else if (item.quantity >= 10) effectivePrice *= 0.95

            val unitMultiplier = when (item.unitType) {
                UnitType.EACH -> 1.0 / product.itemsPerCase
                UnitType.CASE -> 1.0
                UnitType.PALLET -> 40.0
            }

            val lineExVat = effectivePrice * unitMultiplier * item.quantity
            val lineVat = lineExVat * product.vatRate

            subtotalExVat += lineExVat
            vatTotal += lineVat
        }
    }

    val totalIncVat = subtotalExVat + vatTotal
    val remainingCredit = (account?.creditLimit ?: 25000.0) - (account?.currentBalance ?: 0.0)
    val isCreditSufficient = remainingCredit >= totalIncVat

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        // Header
        Surface(
            color = CrownNavy,
            shadowElevation = 4.dp
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = AmberGold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CURRENT WHOLESALE ORDER SHEET",
                            color = PaperWhite,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }

                    if (basketItems.isNotEmpty()) {
                        Text(
                            text = "Clear All",
                            color = DiscountBadgeRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { onClearBasket() }
                        )
                    }
                }
                Text(
                    text = "${basketItems.sumOf { it.quantity }} items in basket • ${account?.tradingName}",
                    color = WarmCream,
                    fontSize = 11.sp
                )
            }
        }

        if (basketItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(56.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Your wholesale order sheet is empty", color = CrownNavy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Browse the catalogue or use Quick Order to add bulk items", color = Color.Gray, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Items List
                items(basketItems, key = { it.id }) { item ->
                    val product = allProducts.firstOrNull { it.sku == item.sku }
                    if (product != null) {
                        val basePrice = if (product.isPromotion) product.promoCasePriceExVat else product.casePriceExVat
                        var effectivePrice = basePrice
                        if (item.quantity >= 50) effectivePrice *= 0.90
                        else if (item.quantity >= 10) effectivePrice *= 0.95

                        val unitMultiplier = when (item.unitType) {
                            UnitType.EACH -> 1.0 / product.itemsPerCase
                            UnitType.CASE -> 1.0
                            UnitType.PALLET -> 40.0
                        }

                        val lineTotalExVat = effectivePrice * unitMultiplier * item.quantity

                        Card(
                            colors = CardDefaults.cardColors(containerColor = PaperWhite),
                            shape = RoundedCornerShape(8.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = product.name,
                                            color = CrownNavy,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "SKU: ${product.sku} • Pack: ${product.packSize} • Unit: ${item.unitType.label}",
                                            color = Color.Gray,
                                            fontSize = 11.sp
                                        )
                                    }

                                    IconButton(
                                        onClick = { onRemoveBasketItem(item.id) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Remove", tint = Color.Red, modifier = Modifier.size(18.dp))
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Qty Stepper
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .border(1.dp, Color.LightGray, RoundedCornerShape(4.dp))
                                            .background(WarmCream)
                                    ) {
                                        IconButton(
                                            onClick = { onUpdateBasketQty(item.id, item.quantity - 1) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Remove, contentDescription = "Minus", tint = CrownNavy, modifier = Modifier.size(14.dp))
                                        }

                                        Text(
                                            text = "${item.quantity}",
                                            color = CrownNavy,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp)
                                        )

                                        IconButton(
                                            onClick = { onUpdateBasketQty(item.id, item.quantity + 1) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = "Plus", tint = CrownNavy, modifier = Modifier.size(14.dp))
                                        }
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "£${String.format(Locale.UK, "%.2f", lineTotalExVat)}",
                                            color = CrownNavy,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                        Text(
                                            text = "Ex VAT",
                                            color = Color.Gray,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Checkout Details Section
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CrownNavy),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "B2B ACCOUNT & DELIVERY DETAILS",
                                color = AmberGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.8.sp
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // PO Number Input
                            OutlinedTextField(
                                value = poNumber,
                                onValueChange = onPoNumberChanged,
                                label = { Text("Purchase Order (PO) Reference", color = WarmCream, fontSize = 11.sp) },
                                placeholder = { Text("e.g. PO-PUB-2026-089", color = Color.Gray, fontSize = 11.sp) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AmberGold,
                                    focusedTextColor = PaperWhite,
                                    unfocusedTextColor = PaperWhite
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("po_number_input")
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Delivery vs Collection Selector
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (deliveryType == DeliveryType.DELIVERY) AmberGold else Color(0xFF1E3250))
                                        .clickable { onDeliveryTypeChanged(DeliveryType.DELIVERY) }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "CROWN DIRECT DELIVERY",
                                        color = if (deliveryType == DeliveryType.DELIVERY) CrownNavy else PaperWhite,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (deliveryType == DeliveryType.COLLECTION) AmberGold else Color(0xFF1E3250))
                                        .clickable { onDeliveryTypeChanged(DeliveryType.COLLECTION) }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "DEPOT CLICK & COLLECT",
                                        color = if (deliveryType == DeliveryType.COLLECTION) CrownNavy else PaperWhite,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Commercial Invoice Totals Box
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF14243B))
                                    .padding(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Goods Subtotal Ex VAT:", color = WarmCream, fontSize = 12.sp)
                                    Text("£${String.format(Locale.UK, "%,.2f", subtotalExVat)}", color = PaperWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("VAT Total (Standard 20%):", color = WarmCream, fontSize = 12.sp)
                                    Text("£${String.format(Locale.UK, "%,.2f", vatTotal)}", color = PaperWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                if (totalSavings > 0) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Total Trade Savings:", color = AmberGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text("-£${String.format(Locale.UK, "%,.2f", totalSavings)}", color = AmberGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("COMMERCIAL TOTAL INC VAT:", color = PaperWhite, fontSize = 14.sp, fontWeight = FontWeight.Black)
                                    Text("£${String.format(Locale.UK, "%,.2f", totalIncVat)}", color = AmberGold, fontSize = 16.sp, fontWeight = FontWeight.Black)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Submit Order Button
                            Button(
                                onClick = onCheckout,
                                enabled = isCreditSufficient,
                                colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen, contentColor = PaperWhite),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("submit_trade_order_btn")
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("CONFIRM & SUBMIT TRADE ORDER", fontSize = 13.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }
    }
}
