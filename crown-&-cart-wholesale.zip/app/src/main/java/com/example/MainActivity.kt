package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.viewmodel.WholesaleViewModel
import com.example.ui.components.BarcodeScannerDialog
import com.example.ui.components.CrownBottomNavBar
import com.example.ui.components.CrownTopBar
import com.example.ui.components.ProductDetailDialog
import com.example.ui.components.TradeCardDialog
import com.example.ui.components.TradeRegistrationDialog
import com.example.ui.screens.BasketAndCheckoutScreen
import com.example.ui.screens.DeliveryTrackerScreen
import com.example.ui.screens.DepotsAndWarehouseMapScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.QuickOrderScreen
import com.example.ui.screens.SavedListsScreen
import com.example.ui.screens.ShopScreen
import com.example.ui.screens.WarehouseConsoleScreen
import com.example.ui.theme.CrownAndCartTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CrownAndCartTheme {
                CrownAndCartApp()
            }
        }
    }
}

@Composable
fun CrownAndCartApp(
    viewModel: WholesaleViewModel = viewModel()
) {
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val accounts by viewModel.allAccounts.collectAsStateWithLifecycle()
    val currentAccount by viewModel.currentAccount.collectAsStateWithLifecycle()
    val showExVat by viewModel.showExVat.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val filteredProducts by viewModel.filteredProducts.collectAsStateWithLifecycle()
    val promotions by viewModel.promotions.collectAsStateWithLifecycle()
    val basketItems by viewModel.basketItems.collectAsStateWithLifecycle()
    val ordersHistory by viewModel.ordersHistory.collectAsStateWithLifecycle()
    val depots by viewModel.allDepots.collectAsStateWithLifecycle()
    val savedLists by viewModel.savedLists.collectAsStateWithLifecycle()
    val recalls by viewModel.recalls.collectAsStateWithLifecycle()

    val selectedProductDetail by viewModel.selectedProductDetail.collectAsStateWithLifecycle()
    val marginCalcState by viewModel.marginCalcState.collectAsStateWithLifecycle()

    val showTradeCard by viewModel.showTradeCard.collectAsStateWithLifecycle()
    val showRegisterDialog by viewModel.showRegisterDialog.collectAsStateWithLifecycle()
    val showScannerDialog by viewModel.showScannerDialog.collectAsStateWithLifecycle()
    val scannedProductResult by viewModel.scannedProductResult.collectAsStateWithLifecycle()

    val poNumber by viewModel.poNumber.collectAsStateWithLifecycle()
    val deliveryType by viewModel.selectedDeliveryType.collectAsStateWithLifecycle()
    val deliverySlot by viewModel.deliveryTimeSlot.collectAsStateWithLifecycle()

    // Handle Back Press to return to Home Tab
    if (activeTab != 0) {
        BackHandler {
            viewModel.setTab(0)
        }
    }

    Scaffold(
        topBar = {
            CrownTopBar(
                currentAccount = currentAccount,
                accounts = accounts,
                showExVat = showExVat,
                onToggleExVat = { viewModel.toggleExVat() },
                onSelectAccount = { accId -> viewModel.selectAccount(accId) },
                onOpenRegister = { viewModel.openRegisterDialog() },
                onOpenTradeCard = { viewModel.openTradeCard() }
            )
        },
        bottomBar = {
            val totalCartItems = basketItems.sumOf { it.quantity }
            val cartTotalExVat = 0.0 // Handled in basket view
            CrownBottomNavBar(
                activeTab = activeTab,
                cartItemCount = totalCartItems,
                cartTotalExVat = cartTotalExVat,
                showExVat = showExVat,
                onTabSelected = { tab -> viewModel.setTab(tab) },
                onCartClicked = { viewModel.setTab(4) }
            )
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = activeTab, label = "ScreenTransition") { tab ->
                when (tab) {
                    0 -> HomeScreen(
                        account = currentAccount,
                        promotions = promotions,
                        regulars = filteredProducts,
                        activeOrders = ordersHistory,
                        recalls = recalls,
                        showExVat = showExVat,
                        onSearchClicked = { viewModel.setTab(1) },
                        onOpenScanner = { viewModel.openBarcodeScanner() },
                        onOpenQuickOrder = { viewModel.setTab(2) },
                        onOpenDepots = { viewModel.setTab(5) },
                        onOpenOrders = { viewModel.setTab(4) },
                        onAddProduct = { prod, unit, qty -> viewModel.addToBasket(prod, unit, qty) },
                        onOpenDetail = { prod -> viewModel.showProductDetail(prod) }
                    )

                    1 -> ShopScreen(
                        products = filteredProducts,
                        searchQuery = searchQuery,
                        selectedCategory = selectedCategory,
                        showExVat = showExVat,
                        onSearchChanged = { q -> viewModel.setSearchQuery(q) },
                        onCategorySelected = { cat -> viewModel.setSelectedCategory(cat) },
                        onAddProduct = { prod, unit, qty -> viewModel.addToBasket(prod, unit, qty) },
                        onOpenDetail = { prod -> viewModel.showProductDetail(prod) }
                    )

                    2 -> QuickOrderScreen(
                        allProducts = filteredProducts,
                        onAddProductToBasket = { prod, unit, qty -> viewModel.addToBasket(prod, unit, qty) }
                    )

                    3 -> SavedListsScreen(
                        savedLists = savedLists,
                        allProducts = filteredProducts,
                        onAddProductToBasket = { prod, unit, qty -> viewModel.addToBasket(prod, unit, qty) }
                    )

                    4 -> BasketAndCheckoutScreen(
                        account = currentAccount,
                        basketItems = basketItems,
                        allProducts = filteredProducts,
                        poNumber = poNumber,
                        deliveryType = deliveryType,
                        deliverySlot = deliverySlot,
                        showExVat = showExVat,
                        onPoNumberChanged = { po -> viewModel.setPoNumber(po) },
                        onDeliveryTypeChanged = { dt -> viewModel.setDeliveryType(dt) },
                        onDeliverySlotChanged = { slot -> viewModel.setDeliveryTimeSlot(slot) },
                        onUpdateBasketQty = { itemId, q -> viewModel.updateBasketQty(itemId, q) },
                        onRemoveBasketItem = { itemId -> viewModel.removeBasketItem(itemId) },
                        onClearBasket = { viewModel.clearBasket() },
                        onCheckout = { viewModel.checkoutBasket() }
                    )

                    5 -> DepotsAndWarehouseMapScreen(
                        depots = depots
                    )

                    6 -> WarehouseConsoleScreen(
                        recalls = recalls
                    )

                    else -> DeliveryTrackerScreen(
                        account = currentAccount,
                        orders = ordersHistory,
                        onAdvanceStatus = { orderNo, status -> viewModel.advanceOrderStatus(orderNo, status) }
                    )
                }
            }
        }

        // Modals & Dialogs
        if (selectedProductDetail != null) {
            ProductDetailDialog(
                product = selectedProductDetail,
                showExVat = showExVat,
                marginCalcState = marginCalcState,
                onMarginSellingPriceChanged = { price -> viewModel.updateMarginCalcSellingPrice(price) },
                onMarginCostPriceChanged = { price -> viewModel.updateMarginCalcCostPrice(price) },
                onAddProduct = { prod, unit, qty -> viewModel.addToBasket(prod, unit, qty) },
                onDismiss = { viewModel.showProductDetail(null) }
            )
        }

        if (showTradeCard) {
            TradeCardDialog(
                account = currentAccount,
                onDismiss = { viewModel.closeTradeCard() }
            )
        }

        if (showRegisterDialog) {
            TradeRegistrationDialog(
                onDismiss = { viewModel.closeRegisterDialog() },
                onSubmit = { bName, tName, cNo, vNo, type, addr, city, depot ->
                    viewModel.registerAccount(bName, tName, cNo, vNo, type, addr, city, depot)
                }
            )
        }

        if (showScannerDialog) {
            BarcodeScannerDialog(
                scannedProduct = scannedProductResult,
                onSimulateScan = { ean -> viewModel.simulateBarcodeScan(ean) },
                onAddProduct = { prod, unit, qty -> viewModel.addToBasket(prod, unit, qty) },
                onOpenDetail = { prod -> viewModel.showProductDetail(prod) },
                onDismiss = { viewModel.closeBarcodeScanner() }
            )
        }
    }
}
