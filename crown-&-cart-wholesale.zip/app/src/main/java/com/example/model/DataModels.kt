package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class CustomerType(val displayName: String) {
    PUB("Pub & Bar"),
    INDEPENDENT_RETAILER("Independent Retailer"),
    RESTAURANT("Restaurant & Foodservice"),
    TAKEAWAY("Takeaway & Fast Food"),
    CAFE("Café & Bakery"),
    HOTEL("Hotel & Hospitality"),
    CATERER("Catering Services"),
    OFFICE("Office & Corporate")
}

enum class UnitType(val code: String, val label: String) {
    EACH("EA", "Each / Bottle"),
    CASE("CS", "Case / Outer"),
    PALLET("PL", "Pallet Layer")
}

enum class OrderStatus(val label: String, val step: Int) {
    CONFIRMED("Order Confirmed", 1),
    PICKING("Warehouse Picking", 2),
    READY("Ready for Dispatch / Collect", 3),
    LOADED("Loaded on Vehicle", 4),
    ON_ROUTE("On Route / Delivering", 5),
    DELIVERED("Delivered", 6)
}

enum class DeliveryType {
    DELIVERY,
    COLLECTION
}

@Entity(tableName = "customer_accounts")
data class CustomerAccount(
    @PrimaryKey val id: String,
    val businessName: String,
    val tradingName: String,
    val accountNo: String,
    val depotId: String,
    val customerType: CustomerType,
    val creditLimit: Double,
    val currentBalance: Double,
    val paymentTermsDays: Int,
    val vatNumber: String,
    val companyNumber: String,
    val priceListCode: String,
    val deliveryRoute: String,
    val accountManagerName: String,
    val accountManagerPhone: String,
    val address: String,
    val city: String
)

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val sku: String,
    val ean: String,
    val name: String,
    val brand: String,
    val category: String,
    val subcategory: String,
    val packSize: String, // e.g. "24 x 330ml"
    val defaultUnit: UnitType,
    val casePriceExVat: Double,
    val vatRate: Double, // 0.20 for standard, 0.0 for zero-rated
    val rrpEach: Double,
    val isPromotion: Boolean = false,
    val promoText: String = "",
    val promoCasePriceExVat: Double = 0.0,
    val availableCases: Int,
    val warehouseAisle: String,
    val warehouseBay: String,
    val warehouseShelf: String,
    val supplierName: String,
    val isMarketplace: Boolean = false,
    val itemsPerCase: Int = 24
)

@Entity(tableName = "depots")
data class Depot(
    @PrimaryKey val id: String,
    val name: String,
    val city: String,
    val address: String,
    val openHours: String,
    val phone: String,
    val readyCollectionBay: String,
    val totalBays: Int,
    val isOperational: Boolean = true
)

@Entity(tableName = "basket_items")
data class BasketItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val accountId: String,
    val sku: String,
    val unitType: UnitType,
    val quantity: Int
)

@Entity(tableName = "saved_lists")
data class SavedList(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val accountId: String,
    val listName: String,
    val categoryTag: String
)

@Entity(tableName = "saved_list_items")
data class SavedListItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val listId: Long,
    val sku: String,
    val defaultQty: Int,
    val defaultUnit: UnitType
)

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey val orderNumber: String,
    val accountId: String,
    val depotId: String,
    val deliveryType: DeliveryType,
    val status: OrderStatus,
    val subtotalExVat: Double,
    val vatTotal: Double,
    val totalIncVat: Double,
    val savingsTotal: Double,
    val poNumber: String,
    val deliveryDateSlot: String,
    val deliveryAddress: String,
    val createdAtTimestamp: Long,
    val driverName: String = "Dave Roberts",
    val driverRouteCode: String = "BHM-07"
)

@Entity(tableName = "order_lines")
data class OrderLine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderNumber: String,
    val sku: String,
    val productName: String,
    val packSize: String,
    val unitType: UnitType,
    val quantity: Int,
    val unitPriceExVat: Double,
    val lineTotalExVat: Double
)

@Entity(tableName = "product_recalls")
data class ProductRecall(
    @PrimaryKey val recallId: String,
    val sku: String,
    val productName: String,
    val batchNumber: String,
    val title: String,
    val reason: String,
    val urgency: String, // URGENT, HIGH, MEDIUM
    val dateIssued: String,
    val affectedDepots: String,
    val affectedOrdersCount: Int,
    val status: String // ACTIVE, RESOLVED
)
