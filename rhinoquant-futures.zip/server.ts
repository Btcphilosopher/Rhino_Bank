/**
 * RHINOQUANT FUTURES - EXPRESS BACKEND SERVER
 * Serves institutional versioned REST API v1 endpoints & Vite frontend middleware.
 * Listens on port 3000 at 0.0.0.0.
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { quantStore } from './src/engine/stateStore';
import {
  calculateContractNotional,
  calculateGrossPnL,
  calculateMarginRequirements,
  calculateTickValue,
  calculateCarryAndBasis,
} from './src/engine/quantMath';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API v1 REST Routes
  app.get('/api/v1/health', (req, res) => {
    res.json({
      status: 'OPERATIONAL',
      service: 'RhinoQuant Futures Quantitative Engine',
      timestamp: new Date().toISOString(),
      model_version: 'v2026.1',
    });
  });

  // 1. Contracts
  app.get('/api/v1/contracts', (req, res) => {
    res.json({ data: quantStore.getContractSpecs() });
  });

  app.get('/api/v1/contracts/:symbol', (req, res) => {
    const spec = quantStore.getSpecBySymbol(req.params.symbol);
    if (!spec) {
      return res.status(404).json({ error: 'Contract specification not found' });
    }
    res.json({ data: spec });
  });

  app.get('/api/v1/contracts/:symbol/specification', (req, res) => {
    const spec = quantStore.getSpecBySymbol(req.params.symbol);
    if (!spec) {
      return res.status(404).json({ error: 'Contract specification not found' });
    }

    const { tickValue, lineage: tickLineage } = calculateTickValue(spec.tick_size, spec.contract_multiplier);
    const { notional, lineage: notionalLineage } = calculateContractNotional(5840.0, spec.contract_multiplier);

    res.json({
      data: {
        specification: spec,
        computed_metrics: {
          tick_value: tickValue,
          point_value: spec.point_value,
          sample_notional: notional,
        },
        lineage: [tickLineage, notionalLineage],
      },
    });
  });

  app.post('/api/v1/contracts', (req, res) => {
    const spec = req.body;
    if (!spec.root_symbol || !spec.contract_multiplier || !spec.tick_size) {
      return res.status(400).json({ error: 'Missing required contract specification parameters' });
    }
    quantStore.saveContractSpec(spec);
    res.status(201).json({ status: 'SUCCESS', data: spec });
  });

  // 2. Contract Chains & Term Structure Curves
  app.get('/api/v1/contract-chains/:root_symbol', (req, res) => {
    const chain = quantStore.generateContractChain(req.params.root_symbol);
    res.json({ root_symbol: req.params.root_symbol, count: chain.length, data: chain });
  });

  app.get('/api/v1/contract-chains/:root_symbol/curve', (req, res) => {
    const curve = quantStore.getFuturesCurve(req.params.root_symbol);
    res.json({ data: curve });
  });

  // 3. Market Data
  app.get('/api/v1/market-data', (req, res) => {
    const specs = quantStore.getContractSpecs();
    const marketObservations = specs.map((s) => {
      const chain = quantStore.generateContractChain(s.root_symbol);
      const front = chain[0];
      return {
        instrument_id: front.contract_code,
        root_symbol: s.root_symbol,
        contract_name: s.contract_name,
        price: front.last_price,
        bid: front.bid,
        ask: front.ask,
        settlement_price: front.settlement,
        volume: front.volume,
        open_interest: front.open_interest,
        source: 'RHINOQUANT_SYNTHETIC_DATA_ADAPTER',
        status: 'SYNTHETIC',
        quality_score: 0.99,
        currency: s.currency,
        unit: s.quote_unit,
        snapshot_id: `snap_${Date.now()}`,
      };
    });
    res.json({ count: marketObservations.length, data: marketObservations });
  });

  app.get('/api/v1/market-data/snapshots', (req, res) => {
    res.json({
      active_snapshot_id: `snap_rhino_live_${new Date().toISOString().slice(0, 10)}`,
      status: 'STABLE',
      quality_check: 'PASSED',
      source: 'SYNTHETIC_QUANT_FEED',
    });
  });

  // 4. Positions
  app.get('/api/v1/positions', (req, res) => {
    res.json({ data: quantStore.getPositions() });
  });

  app.post('/api/v1/positions', (req, res) => {
    const { root_symbol, side, quantity, price } = req.body;
    const spec = quantStore.getSpecBySymbol(root_symbol);
    if (!spec) {
      return res.status(404).json({ error: `Root symbol ${root_symbol} not found` });
    }
    quantStore.createTrade(spec, side, quantity, price);
    res.status(201).json({ status: 'TRADE_EXECUTED_SUCCESS' });
  });

  // 5. Valuation
  app.post('/api/v1/valuation/run', (req, res) => {
    quantStore.recalculateAllValuations();
    res.json({
      valuation_run_id: `val_${Date.now()}`,
      status: 'COMPLETED',
      timestamp: new Date().toISOString(),
      positions_valued: quantStore.getPositions().length,
      margin_account: quantStore.getMarginAccount(),
    });
  });

  // 6. Margin
  app.get('/api/v1/margin/accounts', (req, res) => {
    res.json({ data: quantStore.getMarginAccount() });
  });

  app.post('/api/v1/margin/calculate', (req, res) => {
    const { notional, margin_method, volatility } = req.body;
    const result = calculateMarginRequirements(notional || 1000000, margin_method || 'SPAN_STYLE_ABSTRACTION', volatility || 0.18);
    res.json({ data: result });
  });

  // 7. Risk
  app.post('/api/v1/risk/scenario', (req, res) => {
    const scenario = req.body;
    const result = quantStore.calculateRiskScenario(scenario);
    res.json({ data: result });
  });

  // 8. Reconciliation
  app.post('/api/v1/reconciliation/run', (req, res) => {
    const exceptions = quantStore.runReconciliation();
    res.json({ status: 'RECONCILIATION_RUN_COMPLETED', exceptions_count: exceptions.length, exceptions });
  });

  app.get('/api/v1/reconciliation/exceptions', (req, res) => {
    res.json({ data: quantStore.getReconciliationExceptions() });
  });

  // 9. Simulation Control
  app.post('/api/v1/simulation/control', (req, res) => {
    quantStore.updateSimulationConfig(req.body);
    res.json({ status: 'SIMULATION_CONFIG_UPDATED', config: quantStore.getSimulationConfig() });
  });

  // Vite Middleware integration for dev and production static serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RhinoQuant Futures Engine running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
