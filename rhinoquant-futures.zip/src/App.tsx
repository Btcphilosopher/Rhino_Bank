/**
 * RHINOQUANT FUTURES - MAIN APPLICATION ENTRY POINT
 * Institutional Futures Contract Analytics, Valuation and Risk Platform
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { Navigation, NavTab } from './components/Navigation';
import { CalculationLineageModal } from './components/CalculationLineageModal';

import { OverviewTerminal } from './components/views/OverviewTerminal';
import { ContractsWorkbench } from './components/views/ContractsWorkbench';
import { ContractChainScreen } from './components/views/ContractChainScreen';
import { MarketDataScreen } from './components/views/MarketDataScreen';
import { CurvesTerminal } from './components/views/CurvesTerminal';
import { PositionsScreen } from './components/views/PositionsScreen';
import { ValuationScreen } from './components/views/ValuationScreen';
import { MarginScreen } from './components/views/MarginScreen';
import { RiskLaboratoryScreen } from './components/views/RiskLaboratoryScreen';
import { RollAnalysisScreen } from './components/views/RollAnalysisScreen';
import { SettlementScreen } from './components/views/SettlementScreen';
import { ExpiryScreen } from './components/views/ExpiryScreen';
import { ReconciliationScreen } from './components/views/ReconciliationScreen';
import { ReportsScreen } from './components/views/ReportsScreen';
import { ModelGovernanceScreen } from './components/views/ModelGovernanceScreen';

import { CalculationLineage } from './types/futures';
import { calculateTickValue, calculateContractNotional } from './engine/quantMath';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NavTab>('OVERVIEW');
  const [selectedLineage, setSelectedLineage] = useState<CalculationLineage | null>(null);

  const openSampleLineage = () => {
    const { lineage } = calculateTickValue(0.25, 50);
    setSelectedLineage(lineage);
  };

  return (
    <div className="min-h-screen bg-[#090d14] text-slate-100 flex flex-col font-mono selection:bg-blue-600 selection:text-white">
      {/* Top Header */}
      <Header onOpenLineage={openSampleLineage} />

      {/* Main Tab Navigation */}
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />

      {/* View Container */}
      <main className="flex-1 overflow-y-auto">
        {activeTab === 'OVERVIEW' && <OverviewTerminal onNavigate={setActiveTab} />}
        {activeTab === 'CONTRACTS' && <ContractsWorkbench />}
        {activeTab === 'CONTRACT_CHAIN' && <ContractChainScreen />}
        {activeTab === 'MARKET_DATA' && <MarketDataScreen />}
        {activeTab === 'CURVES' && <CurvesTerminal />}
        {activeTab === 'POSITIONS' && <PositionsScreen />}
        {activeTab === 'VALUATION' && <ValuationScreen />}
        {activeTab === 'MARGIN' && <MarginScreen />}
        {activeTab === 'RISK' && <RiskLaboratoryScreen />}
        {activeTab === 'ROLL_ANALYSIS' && <RollAnalysisScreen />}
        {activeTab === 'SETTLEMENT' && <SettlementScreen />}
        {activeTab === 'EXPIRY' && <ExpiryScreen />}
        {activeTab === 'RECONCILIATION' && <ReconciliationScreen />}
        {activeTab === 'REPORTS' && <ReportsScreen />}
        {activeTab === 'MODEL_GOVERNANCE' && <ModelGovernanceScreen />}
      </main>

      {/* Calculation Lineage Modal */}
      <CalculationLineageModal
        lineage={selectedLineage}
        onClose={() => setSelectedLineage(null)}
      />
    </div>
  );
};

export default App;
