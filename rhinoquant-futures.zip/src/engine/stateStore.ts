/**
 * RHINOQUANT STATE STORE & SIMULATION ENGINE
 * Centralized, reactive state store with deterministic market simulator.
 * Handles Contracts, Chains, Positions, Margins, Valuation, Risk,
 * Settlement, Reconciliation, Audit Logs, and Lineage.
 */

import {
  FuturesContractSpecification,
  FuturesPosition,
  MarginAccount,
  ModelGovernanceCard,
  ReconciliationException,
  AuditEvent,
  ContractChainPoint,
  Trade,
  SimulationConfig,
  CalculationLineage,
  RiskResult,
  RiskScenario,
  RollAnalysis,
  FuturesCurve,
  FuturesCurvePoint,
} from '../types/futures';

import {
  INITIAL_CONTRACT_SPECS,
  INITIAL_POSITIONS,
  INITIAL_MARGIN_ACCOUNT,
  INITIAL_MODEL_CARDS,
  INITIAL_RECONCILIATION_EXCEPTIONS,
  INITIAL_AUDIT_LOGS,
} from './dataFixtures';

import {
  calculateContractNotional,
  calculateGrossPnL,
  calculateMarginRequirements,
  calculatePointValue,
  calculateTickBasedPnL,
  calculateTickValue,
  calculateCarryAndBasis,
  calculateLiquidityScore,
} from './quantMath';

export class QuantEngineStore {
  private specs: FuturesContractSpecification[] = [...INITIAL_CONTRACT_SPECS];
  private positions: FuturesPosition[] = [...INITIAL_POSITIONS];
  private marginAccount: MarginAccount = { ...INITIAL_MARGIN_ACCOUNT };
  private modelCards: ModelGovernanceCard[] = [...INITIAL_MODEL_CARDS];
  private reconciliationExceptions: ReconciliationException[] = [...INITIAL_RECONCILIATION_EXCEPTIONS];
  private auditLogs: AuditEvent[] = [...INITIAL_AUDIT_LOGS];
  private trades: Trade[] = [];

  private simulationConfig: SimulationConfig = {
    time_scale: '1X',
    market_regime: 'CALM',
    term_structure: 'CONTANGO',
    liquidity_regime: 'HIGH',
    margin_regime: 'NORMAL',
    expiry_mode: 'NORMAL',
  };

  private listeners: Set<() => void> = new Set();
  private selectedLineage: CalculationLineage | null = null;

  constructor() {
    this.recalculateAllValuations();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  // Lineage Modal Inspector
  public setLineage(lineage: CalculationLineage | null) {
    this.selectedLineage = lineage;
    this.notify();
  }

  public getLineage(): CalculationLineage | null {
    return this.selectedLineage;
  }

  // Getters
  public getContractSpecs(): FuturesContractSpecification[] {
    return this.specs;
  }

  public getSpecBySymbol(rootSymbol: string): FuturesContractSpecification | undefined {
    return this.specs.find((s) => s.root_symbol.toUpperCase() === rootSymbol.toUpperCase());
  }

  public getPositions(): FuturesPosition[] {
    return this.positions;
  }

  public getMarginAccount(): MarginAccount {
    return this.marginAccount;
  }

  public getModelCards(): ModelGovernanceCard[] {
    return this.modelCards;
  }

  public getModelGovernanceCards(): ModelGovernanceCard[] {
    return this.modelCards;
  }

  public getReconciliationExceptions(): ReconciliationException[] {
    return this.reconciliationExceptions;
  }

  public getAuditLogs(): AuditEvent[] {
    return this.auditLogs;
  }

  public getSimulationConfig(): SimulationConfig {
    return this.simulationConfig;
  }

  // Contract Specification Management
  public saveContractSpec(spec: FuturesContractSpecification) {
    // Calculate derived fields
    const { tickValue } = calculateTickValue(spec.tick_size, spec.contract_multiplier);
    const { pointValue } = calculatePointValue(spec.contract_multiplier);

    spec.tick_value = tickValue;
    spec.point_value = pointValue;

    const existingIdx = this.specs.findIndex((s) => s.contract_id === spec.contract_id || s.root_symbol === spec.root_symbol);
    if (existingIdx >= 0) {
      this.specs[existingIdx] = spec;
    } else {
      this.specs.push(spec);
    }

    this.addAuditLog('CONTRACT_SPECIFICATION_SAVED', `Updated specification for ${spec.root_symbol} (${spec.contract_name})`);
    this.notify();
  }

  // Contract Chain Generator
  public generateContractChain(rootSymbol: string): ContractChainPoint[] {
    const spec = this.getSpecBySymbol(rootSymbol) || this.specs[0];
    const spotPriceMap: Record<string, number> = {
      RQES: 5820.00,
      RQNQ: 20450.00,
      RQNK: 38200.00,
      RQST: 5020.00,
      RQCL: 71.00,
      RQNG: 2.85,
      RQGC: 2700.00,
      RQSI: 31.50,
      RQZW: 575.00,
      RQEU: 1.1080,
      RQSR: 95.25,
      RQTY: 112.50,
    };

    const spot = spotPriceMap[spec.root_symbol] || 100.00;
    const months = spec.listed_months.length > 0 ? spec.listed_months : ['H', 'M', 'U', 'Z'];

    const monthCodeToMonthNum: Record<string, number> = {
      F: 1, G: 2, H: 3, J: 4, K: 5, M: 6,
      N: 7, Q: 8, U: 9, V: 10, X: 11, Z: 12,
    };

    const currentYear = 2026;
    const chainPoints: ContractChainPoint[] = [];

    // Generate next 5 contract months
    let yearOffset = 0;
    let idx = 0;

    for (let i = 0; i < 5; i++) {
      const monthCode = months[i % months.length];
      if (i > 0 && months[i % months.length] === months[0]) {
        yearOffset += 1;
      }

      const year = currentYear + yearOffset;
      const monthNum = monthCodeToMonthNum[monthCode] || 3;
      const contractCode = `${spec.root_symbol}${monthCode}${year.toString().slice(-2)}`;

      // Days to expiry approximation
      const daysToExpiry = (year - 2026) * 365 + (monthNum - 9) * 30 + 20;
      const timeToExpiryYears = Math.max(daysToExpiry / 365, 0.01);

      // Term Structure slope factor
      let termSlope = 0.015; // Contango +1.5% annualized
      if (this.simulationConfig.term_structure === 'BACKWARDATION') termSlope = -0.025;
      if (this.simulationConfig.term_structure === 'FLAT') termSlope = 0.0001;

      const futuresPrice = spot * Math.exp(termSlope * timeToExpiryYears);
      const roundedPrice = Number(futuresPrice.toFixed(spec.tick_size < 0.001 ? 5 : 2));

      const spread = spec.tick_size * 2;
      const bid = Number((roundedPrice - spread / 2).toFixed(spec.tick_size < 0.001 ? 5 : 2));
      const ask = Number((roundedPrice + spread / 2).toFixed(spec.tick_size < 0.001 ? 5 : 2));

      const { basis, impliedCarryRate } = calculateCarryAndBasis(
        spec.asset_class,
        roundedPrice,
        spot,
        timeToExpiryYears
      );

      chainPoints.push({
        contract_id: `chain_${contractCode.toLowerCase()}`,
        root_symbol: spec.root_symbol,
        contract_code: contractCode,
        month_code: monthCode,
        year,
        expiry_date: `${year}-${monthNum.toString().padStart(2, '0')}-18`,
        days_to_expiry: Math.max(daysToExpiry, 1),
        last_price: roundedPrice,
        change: Number(((i === 0 ? 18.5 : i * 4.2) * (spec.tick_size < 0.01 ? 0.001 : 1)).toFixed(2)),
        change_percent: 0.32,
        bid,
        ask,
        settlement: Number((roundedPrice - spec.tick_size).toFixed(spec.tick_size < 0.001 ? 5 : 2)),
        volume: Math.round(150000 / (i + 1)),
        open_interest: Math.round(420000 / (i + 1)),
        basis,
        implied_carry: impliedCarryRate,
        status: 'SYNTHETIC',
      });
    }

    return chainPoints;
  }

  // Futures Term Structure Curve Engine
  public getFuturesCurve(rootSymbol: string): FuturesCurve {
    const chain = this.generateContractChain(rootSymbol);
    const frontPrice = chain[0]?.last_price || 100;

    const points: FuturesCurvePoint[] = chain.map((p, idx) => ({
      contract_code: p.contract_code,
      expiry_date: p.expiry_date,
      days_to_expiry: p.days_to_expiry,
      futures_price: p.last_price,
      spread_to_front: Number((p.last_price - frontPrice).toFixed(2)),
      open_interest: p.open_interest,
      volume: p.volume,
      implied_roll_yield: p.implied_carry,
      is_synthetic: true,
    }));

    return {
      curve_id: `crv_${rootSymbol.toLowerCase()}_${Date.now()}`,
      root_symbol: rootSymbol,
      valuation_time: new Date().toISOString(),
      construction_method: 'OUTRIGHT_OBSERVED_PRICE',
      interpolation_method: 'MONOTONE_CUBIC_SPLINE',
      source_snapshot_id: 'snap_synthetic_live_01',
      quality_status: 'SYNTHETIC',
      points,
    };
  }

  // Trade Execution & Position Ledger
  public createTrade(
    contractSpec: FuturesContractSpecification,
    side: 'LONG' | 'SHORT',
    quantity: number,
    price: number
  ) {
    const tradeId = `trd_${Date.now()}`;
    const contractCode = `${contractSpec.root_symbol}Z26`;

    const newTrade: Trade = {
      trade_id: tradeId,
      contract_id: contractSpec.contract_id,
      portfolio_id: 'PORT_ALPHA_INSTITUTIONAL',
      side,
      quantity,
      price,
      timestamp: new Date().toISOString(),
      execution_reference: `EXEC_${Math.floor(Math.random() * 899999 + 100000)}`,
      commission: quantity * 2.50,
      fees: quantity * 0.80,
      source: 'MANUAL_DECK_ORDER',
    };

    this.trades.push(newTrade);

    // Update or Create Position
    const existingPos = this.positions.find((p) => p.contract_id === contractSpec.contract_id && p.position_status === 'OPEN');

    if (existingPos) {
      if (existingPos.side === side) {
        // Average Price
        const totalQty = existingPos.quantity + quantity;
        const totalVal = existingPos.quantity * existingPos.average_entry_price + quantity * price;
        existingPos.average_entry_price = Number((totalVal / totalQty).toFixed(4));
        existingPos.quantity = totalQty;
        existingPos.lots.push({
          lot_id: `lot_${Date.now()}`,
          trade_id: tradeId,
          quantity,
          entry_price: price,
          entry_time: new Date().toISOString(),
          realized_pnl: 0,
        });
      } else {
        // Partial or complete position closure (FIFO)
        if (quantity >= existingPos.quantity) {
          // Closed position P&L
          const { pnl } = calculateGrossPnL(existingPos.side, existingPos.average_entry_price, price, contractSpec.contract_multiplier, existingPos.quantity);
          existingPos.realized_pnl += pnl;
          existingPos.position_status = 'CLOSED';
        } else {
          const closedQty = quantity;
          const { pnl } = calculateGrossPnL(existingPos.side, existingPos.average_entry_price, price, contractSpec.contract_multiplier, closedQty);
          existingPos.realized_pnl += pnl;
          existingPos.quantity -= closedQty;
        }
      }
    } else {
      // Create New Position
      const { notional } = calculateContractNotional(price, contractSpec.contract_multiplier);
      const posNotional = notional * quantity;
      const { initialMargin, maintenanceMargin } = calculateMarginRequirements(posNotional, contractSpec.margin_method);

      this.positions.push({
        position_id: `pos_${Date.now()}`,
        portfolio_id: 'PORT_ALPHA_INSTITUTIONAL',
        account_id: 'ACCT_CLEARING_MAIN_01',
        contract_id: contractSpec.contract_id,
        contract_code: contractCode,
        contract_name: contractSpec.contract_name,
        root_symbol: contractSpec.root_symbol,
        asset_class: contractSpec.asset_class,
        side,
        quantity,
        average_entry_price: price,
        current_price: price,
        settlement_price: price,
        contract_multiplier: contractSpec.contract_multiplier,
        tick_size: contractSpec.tick_size,
        tick_value: contractSpec.tick_value,
        notional_value: posNotional,
        unrealized_pnl: 0,
        realized_pnl: 0,
        initial_margin: initialMargin,
        maintenance_margin: maintenanceMargin,
        margin_utilization: 15.0,
        position_status: 'OPEN',
        currency: contractSpec.currency,
        expiry_date: contractSpec.final_settlement_date || '2026-12-18',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        lots: [
          {
            lot_id: `lot_${Date.now()}`,
            trade_id: tradeId,
            quantity,
            entry_price: price,
            entry_time: new Date().toISOString(),
            realized_pnl: 0,
          },
        ],
      });
    }

    this.recalculateAllValuations();
    this.addAuditLog('TRADE_EXECUTED', `Executed ${side} ${quantity} ${contractCode} @ ${price}`);
    this.notify();
  }

  // Recalculates Mark-to-Market P&L, Notional, Margin Accounts
  public recalculateAllValuations() {
    let totalUnrealizedPnL = 0;
    let totalRealizedPnL = 0;
    let totalNotional = 0;
    let totalInitialMargin = 0;
    let totalMaintenanceMargin = 0;

    this.positions.forEach((pos) => {
      if (pos.position_status !== 'OPEN') return;

      const spec = this.getSpecBySymbol(pos.root_symbol);
      const multiplier = spec?.contract_multiplier || pos.contract_multiplier;

      // P&L calculation
      const { pnl } = calculateGrossPnL(pos.side, pos.average_entry_price, pos.current_price, multiplier, pos.quantity);
      pos.unrealized_pnl = pnl;

      // Notional
      const { notional } = calculateContractNotional(pos.current_price, multiplier);
      pos.notional_value = notional * pos.quantity;

      // Margin
      const { initialMargin, maintenanceMargin } = calculateMarginRequirements(
        pos.notional_value,
        spec?.margin_method || 'SPAN_STYLE_ABSTRACTION'
      );
      pos.initial_margin = initialMargin;
      pos.maintenance_margin = maintenanceMargin;

      totalUnrealizedPnL += pos.unrealized_pnl;
      totalRealizedPnL += pos.realized_pnl;
      totalNotional += pos.notional_value;
      totalInitialMargin += pos.initial_margin;
      totalMaintenanceMargin += pos.maintenance_margin;
    });

    // Update Margin Account
    this.marginAccount.initial_margin_req = totalInitialMargin;
    this.marginAccount.maintenance_margin_req = totalMaintenanceMargin;
    this.marginAccount.current_equity =
      this.marginAccount.cash_balance + this.marginAccount.collateral_value + totalUnrealizedPnL + totalRealizedPnL;

    this.marginAccount.excess_liquidity = this.marginAccount.current_equity - totalInitialMargin;
    this.marginAccount.margin_utilization_pct = Number(
      ((totalInitialMargin / Math.max(this.marginAccount.current_equity, 1)) * 100).toFixed(1)
    );

    if (this.marginAccount.excess_liquidity < 0) {
      this.marginAccount.status = 'MARGIN_CALL';
    } else if (this.marginAccount.margin_utilization_pct > 80) {
      this.marginAccount.status = 'WARNING';
    } else {
      this.marginAccount.status = 'HEALTHY';
    }

    this.marginAccount.last_updated = new Date().toISOString();
  }

  // Contract Roll Analyzer
  public analyzeContractRoll(rootSymbol: string): RollAnalysis {
    const chain = this.generateContractChain(rootSymbol);
    const front = chain[0];
    const next = chain[1];

    const rollSpread = Number((next.last_price - front.last_price).toFixed(2));
    const daysDiff = next.days_to_expiry - front.days_to_expiry;
    const annualizedYield = (rollSpread / front.last_price) * (365 / Math.max(daysDiff, 1)) * 100;

    return {
      front_contract: front.contract_code,
      next_contract: next.contract_code,
      front_price: front.last_price,
      next_price: next.last_price,
      roll_spread: rollSpread,
      annualized_roll_yield: Number(annualizedYield.toFixed(2)),
      estimated_execution_cost: 25.00, // Bid/ask slippage estimate
      front_volume: front.volume,
      next_volume: next.volume,
      volume_migration_pct: Number(((next.volume / (front.volume + next.volume)) * 100).toFixed(1)),
      front_open_interest: front.open_interest,
      next_open_interest: next.open_interest,
      open_interest_migration_pct: Number(((next.open_interest / (front.open_interest + next.open_interest)) * 100).toFixed(1)),
      recommendation_note:
        rollSpread > 0
          ? 'Contango structure detected. Long positions incur negative roll yield upon rolling deferred contract.'
          : 'Backwardation structure detected. Long positions capture positive roll yield upon rolling deferred contract.',
    };
  }

  // Risk Laboratory Stress Scenarios
  public calculateRiskScenario(scenario: RiskScenario): RiskResult {
    let totalBasePnL = 0;
    let totalShockedPnL = 0;
    let totalBaseNotional = 0;
    let totalShockedNotional = 0;
    let totalBaseMargin = 0;
    let totalShockedMargin = 0;

    const decomposition: { asset_class: string; exposure: number; shocked_pnl: number }[] = [];

    this.positions.forEach((pos) => {
      if (pos.position_status !== 'OPEN') return;

      const spec = this.getSpecBySymbol(pos.root_symbol);
      const multiplier = spec?.contract_multiplier || pos.contract_multiplier;

      const shockedPrice = pos.current_price * (1 + scenario.price_shock_pct);
      const baseNotional = pos.quantity * pos.current_price * multiplier;
      const shockedNotional = pos.quantity * shockedPrice * multiplier;

      const { pnl: basePnL } = calculateGrossPnL(pos.side, pos.average_entry_price, pos.current_price, multiplier, pos.quantity);
      const { pnl: shockedPnL } = calculateGrossPnL(pos.side, pos.average_entry_price, shockedPrice, multiplier, pos.quantity);

      const baseMargin = pos.initial_margin;
      const shockedMargin = baseMargin * scenario.margin_rate_multiplier;

      totalBasePnL += basePnL;
      totalShockedPnL += shockedPnL;
      totalBaseNotional += baseNotional;
      totalShockedNotional += shockedNotional;
      totalBaseMargin += baseMargin;
      totalShockedMargin += shockedMargin;

      decomposition.push({
        asset_class: pos.asset_class,
        exposure: shockedNotional,
        shocked_pnl: shockedPnL,
      });
    });

    return {
      scenario_id: scenario.scenario_id,
      scenario_name: scenario.scenario_name || scenario.name || 'Custom Stress Scenario',
      timestamp: new Date().toISOString(),
      base_pnl: totalBasePnL,
      shocked_pnl: totalShockedPnL,
      pnl_difference: totalShockedPnL - totalBasePnL,
      base_notional: totalBaseNotional,
      shocked_notional: totalShockedNotional,
      notional_difference: totalShockedNotional - totalBaseNotional,
      base_margin: totalBaseMargin,
      shocked_margin: totalShockedMargin,
      margin_difference: totalShockedMargin - totalBaseMargin,
      liquidity_impact_score: Math.min(100, Math.round(Math.abs(scenario.price_shock_pct) * 400 + 10)),
      risk_decomposition: decomposition,
    };
  }

  // Simulation Controls
  public updateSimulationConfig(newConfig: Partial<SimulationConfig>) {
    this.simulationConfig = { ...this.simulationConfig, ...newConfig };

    // Apply regime price variations to positions
    if (this.simulationConfig.market_regime === 'VOLATILE' || this.simulationConfig.market_regime === 'STRESSED') {
      this.positions.forEach((p) => {
        const delta = (Math.random() - 0.5) * 0.02 * p.current_price;
        p.current_price = Number((p.current_price + delta).toFixed(2));
      });
    }

    this.recalculateAllValuations();
    this.addAuditLog('SIMULATION_REGIME_CHANGED', `Market regime updated to ${this.simulationConfig.market_regime}`);
    this.notify();
  }

  // Reconciliation Run
  public runReconciliation(): ReconciliationException[] {
    const runTimestamp = new Date().toISOString();
    this.reconciliationExceptions = [];

    // Check position vs margin equity
    if (this.marginAccount.status === 'MARGIN_CALL') {
      this.reconciliationExceptions.push({
        exception_id: `EXC_${Date.now()}_1`,
        severity: 'CRITICAL',
        source_system: 'MARGIN_ENGINE',
        target_system: 'PORTFOLIO_LEDGER',
        entity_type: 'MARGIN',
        entity_ref: this.marginAccount.account_id,
        expected_value: `Available Equity >= $${this.marginAccount.initial_margin_req.toLocaleString()}`,
        actual_value: `Current Equity $${this.marginAccount.current_equity.toLocaleString()} (Shortfall $${Math.abs(this.marginAccount.excess_liquidity).toLocaleString()})`,
        discrepancy_details: 'Account equity breached initial margin requirement. Margin call triggered.',
        assigned_user: 'Head of Risk & Clearing',
        resolution_status: 'EXCEPTION',
        created_at: runTimestamp,
        resolution_history: ['Automated reconciliation flagged margin shortfall.'],
      });
    }

    // Spec verification rule
    this.specs.forEach((s) => {
      const calcTv = s.tick_size * s.contract_multiplier;
      if (Math.abs(calcTv - s.tick_value) > 0.0001) {
        this.reconciliationExceptions.push({
          exception_id: `EXC_${Date.now()}_2`,
          severity: 'HIGH',
          source_system: 'CONTRACT_SPEC_ENGINE',
          target_system: 'MARKET_DATA',
          entity_type: 'SPECIFICATION',
          entity_ref: s.root_symbol,
          expected_value: `Tick Value: $${calcTv.toFixed(2)}`,
          actual_value: `Recorded Spec Tick Value: $${s.tick_value.toFixed(2)}`,
          discrepancy_details: 'Tick value spec mismatch against calculated multiplier product.',
          assigned_user: 'Contract Governance Desk',
          resolution_status: 'WARNING',
          created_at: runTimestamp,
        });
      }
    });

    if (this.reconciliationExceptions.length === 0) {
      this.addAuditLog('RECONCILIATION_RUN', 'Reconciliation run completed with 100% matched transactions.');
    } else {
      this.addAuditLog('RECONCILIATION_RUN', `Reconciliation run completed. Found ${this.reconciliationExceptions.length} exceptions.`);
    }

    this.notify();
    return this.reconciliationExceptions;
  }

  public resolveException(exceptionId: string) {
    const exc = this.reconciliationExceptions.find((e) => e.exception_id === exceptionId);
    if (exc) {
      exc.resolution_status = 'RESOLVED';
      exc.resolution_history = exc.resolution_history || [];
      exc.resolution_history.push(`Resolved by user at ${new Date().toISOString()}`);
      this.addAuditLog('EXCEPTION_RESOLVED', `Resolved reconciliation exception ${exceptionId}`);
      this.notify();
    }
  }

  private addAuditLog(action: string, details: string) {
    this.auditLogs.unshift({
      audit_id: `AUD_${Date.now()}`,
      timestamp: new Date().toISOString(),
      user_action: action,
      actor: 'RHINOQUANT_USER_OPERATOR',
      entity_type: 'SYSTEM',
      entity_id: 'SYSTEM_MAIN',
      specification_version: 'v2026.1',
      details,
    });
  }
}

export const quantStore = new QuantEngineStore();
