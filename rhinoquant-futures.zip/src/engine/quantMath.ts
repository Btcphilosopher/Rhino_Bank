/**
 * RHINOQUANT QUANTITATIVE MATHEMATICS ENGINE
 * Fully transparent, precision financial calculations for Futures Contracts.
 * Handles Notional, Tick Value, Point Value, Mark-to-Market, Carry Models,
 * Margins, Curve Interpolation, Stress Testing, and Lineage Tracking.
 */

import Decimal from 'decimal.js';
import { AssetClass, CalculationLineage, MarginMethod } from '../types/futures';

// Configure Decimal for financial precision
Decimal.set({ precision: 28, rounding: Decimal.ROUND_HALF_UP });

/**
 * Tick Value = Tick Size × Contract Multiplier
 */
export function calculateTickValue(
  tickSize: number,
  contractMultiplier: number
): { tickValue: number; lineage: CalculationLineage } {
  const ts = new Decimal(tickSize);
  const cm = new Decimal(contractMultiplier);
  const tv = ts.times(cm);

  return {
    tickValue: tv.toNumber(),
    lineage: {
      calculation_name: 'Tick Value Calculation',
      formula: 'Tick Value = Minimum Tick Size × Contract Multiplier',
      inputs: {
        tick_size: ts.toString(),
        contract_multiplier: cm.toString(),
      },
      units: 'Currency per tick',
      precision_applied: 'Decimal.ROUND_HALF_UP (28 digits)',
      model_version: 'v1.0.0-RhinoQuantMath',
      limitations: 'Assumes linear tick sizing across all price levels.',
      result_value: tv.toString(),
    },
  };
}

/**
 * Point Value = 1.0 Point × Contract Multiplier
 */
export function calculatePointValue(
  contractMultiplier: number
): { pointValue: number; lineage: CalculationLineage } {
  const cm = new Decimal(contractMultiplier);

  return {
    pointValue: cm.toNumber(),
    lineage: {
      calculation_name: 'Point Value Calculation',
      formula: 'Point Value = 1.0 Full Index/Price Point × Contract Multiplier',
      inputs: {
        point_step: '1.0',
        contract_multiplier: cm.toString(),
      },
      units: 'Currency per point',
      precision_applied: 'Exact Decimal',
      model_version: 'v1.0.0-RhinoQuantMath',
      limitations: 'Non-linear options or volatility futures may vary point scaling.',
      result_value: cm.toString(),
    },
  };
}

/**
 * Contract Notional Value = Price × Multiplier
 */
export function calculateContractNotional(
  price: number,
  contractMultiplier: number
): { notional: number; lineage: CalculationLineage } {
  const p = new Decimal(price);
  const cm = new Decimal(contractMultiplier);
  const notional = p.times(cm);

  return {
    notional: notional.toNumber(),
    lineage: {
      calculation_name: 'Contract Notional Value',
      formula: 'Notional Value = Futures Price × Contract Multiplier',
      inputs: {
        futures_price: p.toString(),
        contract_multiplier: cm.toString(),
      },
      units: 'Currency monetary exposure',
      precision_applied: 'Decimal 28-digit precision',
      model_version: 'v1.0.0-RhinoQuantMath',
      limitations: 'Does not include leverage/margin discounts; represents total gross asset exposure.',
      result_value: notional.toString(),
    },
  };
}

/**
 * Position Gross Exposure = Contract Notional × Quantity
 */
export function calculatePositionNotional(
  contractNotional: number,
  quantity: number
): { positionNotional: number; lineage: CalculationLineage } {
  const cn = new Decimal(contractNotional);
  const qty = new Decimal(quantity);
  const posNotional = cn.times(qty);

  return {
    positionNotional: posNotional.toNumber(),
    lineage: {
      calculation_name: 'Position Gross Exposure',
      formula: 'Position Notional = Contract Notional × Quantity',
      inputs: {
        contract_notional: cn.toString(),
        quantity: qty.toString(),
      },
      units: 'Monetary Exposure',
      precision_applied: 'Exact Decimal',
      model_version: 'v1.0.0-RhinoQuantMath',
      limitations: 'Calculates gross notional without netting cross-asset hedges.',
      result_value: posNotional.toString(),
    },
  };
}

/**
 * Gross P&L Calculation:
 * Long: (Exit Price - Entry Price) * Multiplier * Qty
 * Short: (Entry Price - Exit Price) * Multiplier * Qty
 */
export function calculateGrossPnL(
  side: 'LONG' | 'SHORT',
  entryPrice: number,
  exitPrice: number,
  contractMultiplier: number,
  quantity: number
): { pnl: number; lineage: CalculationLineage } {
  const entry = new Decimal(entryPrice);
  const exit = new Decimal(exitPrice);
  const cm = new Decimal(contractMultiplier);
  const qty = new Decimal(quantity);

  const priceDiff = side === 'LONG' ? exit.minus(entry) : entry.minus(exit);
  const pnl = priceDiff.times(cm).times(qty);

  return {
    pnl: pnl.toNumber(),
    lineage: {
      calculation_name: 'Mark-to-Market P&L',
      formula:
        side === 'LONG'
          ? 'P&L = (Exit Price - Entry Price) × Multiplier × Quantity'
          : 'P&L = (Entry Price - Exit Price) × Multiplier × Quantity',
      inputs: {
        side,
        entry_price: entry.toString(),
        exit_price: exit.toString(),
        contract_multiplier: cm.toString(),
        quantity: qty.toString(),
      },
      units: 'Currency monetary P&L',
      precision_applied: 'Decimal 28-digit precision',
      model_version: 'v1.0.0-RhinoQuantMath',
      limitations: 'Excludes transaction commissions, slippage, and overnight financing charges.',
      result_value: pnl.toString(),
    },
  };
}

/**
 * Tick-Based P&L:
 * Ticks Moved = (Exit - Entry) / Tick Size
 * P&L = Ticks Moved * Tick Value * Quantity
 */
export function calculateTickBasedPnL(
  side: 'LONG' | 'SHORT',
  entryPrice: number,
  exitPrice: number,
  tickSize: number,
  tickValue: number,
  quantity: number
): { pnl: number; ticksMoved: number; lineage: CalculationLineage } {
  const entry = new Decimal(entryPrice);
  const exit = new Decimal(exitPrice);
  const ts = new Decimal(tickSize);
  const tv = new Decimal(tickValue);
  const qty = new Decimal(quantity);

  const priceDiff = side === 'LONG' ? exit.minus(entry) : entry.minus(exit);
  const ticksMoved = priceDiff.dividedBy(ts);
  const pnl = ticksMoved.times(tv).times(qty);

  return {
    pnl: pnl.toNumber(),
    ticksMoved: ticksMoved.toNumber(),
    lineage: {
      calculation_name: 'Tick-Based P&L Calculation',
      formula: 'Ticks Moved = (Δ Price / Tick Size); P&L = Ticks Moved × Tick Value × Quantity',
      inputs: {
        side,
        entry_price: entry.toString(),
        exit_price: exit.toString(),
        tick_size: ts.toString(),
        tick_value: tv.toString(),
        quantity: qty.toString(),
      },
      units: 'Ticks & Currency P&L',
      precision_applied: 'Exact Decimal',
      model_version: 'v1.0.0-RhinoQuantMath',
      limitations: 'Rounding to integer ticks may differ if price is off-tick.',
      result_value: pnl.toString(),
    },
  };
}

/**
 * Asset-Class Specific Cost of Carry / Basis Analytics
 * Equity Index: F = S * exp((r - q) * T)
 * Commodity: F = S * exp((r + u - c) * T) (u = storage, c = convenience yield)
 * Currency: F = S * exp((r_dom - r_for) * T)
 * Interest Rate: F = 100 - IMM Rate
 */
export function calculateCarryAndBasis(
  assetClass: AssetClass,
  futuresPrice: number,
  spotPrice: number,
  timeToExpiryYears: number,
  riskFreeRate: number = 0.045, // 4.5% risk free
  dividendOrStorage: number = 0.015, // 1.5% dividend yield or storage
  convenienceYield: number = 0.005,
  foreignRate: number = 0.03
): {
  basis: number;
  theoreticalFutures: number;
  impliedCarryRate: number;
  lineage: CalculationLineage;
} {
  const F = new Decimal(futuresPrice);
  const S = new Decimal(spotPrice);
  const T = Math.max(timeToExpiryYears, 0.0001);

  const basis = F.minus(S).toNumber();
  let theoretical = spotPrice;
  let carryFormula = '';

  if (assetClass === 'EQUITY_INDEX') {
    // F = S * exp((r - q) * T)
    const netCarry = riskFreeRate - dividendOrStorage;
    theoretical = S.times(Math.exp(netCarry * T)).toNumber();
    carryFormula = 'Cost of Carry (Equity): F = Spot × exp((r - dividend_yield) × T)';
  } else if (assetClass === 'COMMODITY' || assetClass === 'ENERGY' || assetClass === 'METALS' || assetClass === 'AGRICULTURE') {
    // F = S * exp((r + storage - convenience) * T)
    const netCarry = riskFreeRate + dividendOrStorage - convenienceYield;
    theoretical = S.times(Math.exp(netCarry * T)).toNumber();
    carryFormula = 'Cost of Carry (Commodity): F = Spot × exp((r + storage_cost - convenience_yield) × T)';
  } else if (assetClass === 'CURRENCY') {
    // F = S * exp((r_domestic - r_foreign) * T)
    const netCarry = riskFreeRate - foreignRate;
    theoretical = S.times(Math.exp(netCarry * T)).toNumber();
    carryFormula = 'Covered Interest Parity (FX): F = Spot × exp((r_domestic - r_foreign) × T)';
  } else {
    // Interest Rates: Short rate carry
    const netCarry = riskFreeRate;
    theoretical = S.times(Math.exp(netCarry * T)).toNumber();
    carryFormula = 'Bond / Short Rate Carry: F = Spot × exp(r_repo × T)';
  }

  // Implied annual carry % = (F / S - 1) / T
  const impliedCarryRate = T > 0 ? ((futuresPrice / spotPrice - 1) / T) : 0;

  return {
    basis,
    theoreticalFutures: Number(theoretical.toFixed(4)),
    impliedCarryRate: Number((impliedCarryRate * 100).toFixed(4)),
    lineage: {
      calculation_name: `${assetClass} Basis & Carry Model`,
      formula: carryFormula,
      inputs: {
        futures_price: F.toString(),
        spot_price: S.toString(),
        time_to_expiry_years: T.toFixed(6),
        risk_free_rate: `${(riskFreeRate * 100).toFixed(2)}%`,
        dividend_or_storage: `${(dividendOrStorage * 100).toFixed(2)}%`,
        convenience_yield: `${(convenienceYield * 100).toFixed(2)}%`,
        foreign_rate: `${(foreignRate * 100).toFixed(2)}%`,
      },
      units: 'Points & Annualized Percent (%)',
      precision_applied: 'Analytical Exponential Model',
      model_version: 'v1.2.0-RhinoQuantCarry',
      limitations: 'Assumes continuous compounding and constant risk-free/storage rates.',
      result_value: `Basis: ${basis.toFixed(2)}, Theoretical: ${theoretical.toFixed(2)}, Implied Carry: ${(impliedCarryRate * 100).toFixed(2)}%`,
    },
  };
}

/**
 * Margin Engine Calculation:
 * Calculates Initial Margin, Maintenance Margin, and Stress Margin
 */
export function calculateMarginRequirements(
  notionalValue: number,
  marginMethod: MarginMethod,
  volatility: number = 0.18,
  fixedRatePct: number = 0.08
): {
  initialMargin: number;
  maintenanceMargin: number;
  lineage: CalculationLineage;
} {
  const notional = new Decimal(notionalValue);
  let initRate = fixedRatePct;

  if (marginMethod === 'SPAN_STYLE_ABSTRACTION') {
    // SPAN style 99% 1-day VaR ~ 2.33 * vol / sqrt(252) + liquidity buffer
    initRate = Math.max(0.04, (2.33 * volatility) / Math.sqrt(252) * 5 + 0.02);
  } else if (marginMethod === 'VOLATILITY_SCALED') {
    initRate = Math.max(0.03, volatility * 0.4);
  } else if (marginMethod === 'RISK_BASED') {
    initRate = Math.max(0.05, volatility * 0.5);
  } else {
    initRate = fixedRatePct; // e.g. 8%
  }

  const initialMargin = notional.times(initRate);
  // Maintenance Margin is typically 80% to 85% of Initial Margin
  const maintenanceMargin = initialMargin.times(0.80);

  return {
    initialMargin: Math.round(initialMargin.toNumber()),
    maintenanceMargin: Math.round(maintenanceMargin.toNumber()),
    lineage: {
      calculation_name: `Margin Model (${marginMethod})`,
      formula:
        marginMethod === 'SPAN_STYLE_ABSTRACTION'
          ? 'Initial Margin = Notional × [ (2.33 × Vol / √252) × 5 + 2% Buffer ]; Maintenance = 80% IM'
          : 'Initial Margin = Notional × Effective Margin Rate; Maintenance = 80% IM',
      inputs: {
        notional_value: notional.toString(),
        margin_method: marginMethod,
        volatility: `${(volatility * 100).toFixed(2)}%`,
        applied_rate: `${(initRate * 100).toFixed(2)}%`,
      },
      units: 'Currency monetary margin requirement',
      precision_applied: 'Rounded to nearest currency unit',
      model_version: 'v2.1.0-RhinoQuantMargin',
      limitations: 'Simulation model abstraction. Actual exchange SPAN arrays use full portfolio scenario vectors.',
      result_value: `IM: $${Math.round(initialMargin.toNumber()).toLocaleString()}, MM: $${Math.round(maintenanceMargin.toNumber()).toLocaleString()}`,
    },
  };
}

/**
 * Liquidity Score Calculation (0 to 100)
 */
export function calculateLiquidityScore(
  volume: number,
  openInterest: number,
  bidAskSpreadTicks: number,
  turnoverRatio: number = 0.1
): { score: number; lineage: CalculationLineage } {
  // Higher volume, higher OI, lower spread -> higher score
  const volFactor = Math.min(40, Math.log10(volume + 1) * 8);
  const oiFactor = Math.min(40, Math.log10(openInterest + 1) * 7);
  const spreadPenalty = Math.max(0, (bidAskSpreadTicks - 1) * 8);

  const rawScore = Math.max(5, Math.min(100, volFactor + oiFactor - spreadPenalty));
  const score = Number(rawScore.toFixed(1));

  return {
    score,
    lineage: {
      calculation_name: 'Transparent Liquidity Scoring Model',
      formula: 'Score = Min(100, 8×log10(Volume) + 7×log10(OpenInterest) - 8×(SpreadTicks - 1))',
      inputs: {
        volume,
        open_interest: openInterest,
        bid_ask_spread_ticks: bidAskSpreadTicks,
      },
      units: 'Score (0.0 - 100.0)',
      precision_applied: 'Single decimal place',
      model_version: 'v1.0.0-RhinoQuantLiquidity',
      limitations: 'Composite metric for quantitative relative liquidity comparison.',
      result_value: score.toString(),
    },
  };
}
