/**
 * RHINOQUANT FUTURES - DOMAIN MODEL DEFINITIONS
 * Institutional Quantitative Types & Specifications
 */

export type AssetClass =
  | 'EQUITY_INDEX'
  | 'COMMODITY'
  | 'INTEREST_RATE'
  | 'CURRENCY'
  | 'ENERGY'
  | 'METALS'
  | 'AGRICULTURE'
  | 'SYNTHETIC_CUSTOM';

export type SettlementType = 'CASH' | 'PHYSICAL';

export type DeliveryMethod =
  | 'CASH_FINAL'
  | 'PHYSICAL_PIPELINE'
  | 'PHYSICAL_WAREHOUSE_RECEIPT'
  | 'PHYSICAL_VAULT_DELIVERY';

export type MarginMethod =
  | 'FIXED_RATE'
  | 'SPAN_STYLE_ABSTRACTION'
  | 'RISK_BASED'
  | 'VOLATILITY_SCALED';

export type ExceptionSeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'WARNING' | 'INFO';
export type ReconciliationStatus = 'OPEN' | 'INVESTIGATING' | 'RESOLVED' | 'EXCEPTION' | 'WARNING' | 'MATCHED';
export type TradeSide = 'LONG' | 'SHORT';
export type PositionStatus = 'OPEN' | 'CLOSED' | 'EXPIRED' | 'SETTLED';

export interface FuturesContractSpecification {
  contract_id: string;
  root_symbol: string;
  contract_name: string;
  asset_class: AssetClass;
  underlying_asset: string;
  exchange_code: string;
  currency: string;
  quote_unit: string;
  contract_unit: string;
  contract_multiplier: number;
  contract_size: number;
  tick_size: number;
  tick_value: number;
  point_value: number;
  listed_months: string[]; // e.g. ['H', 'M', 'U', 'Z']
  first_trade_date: string;
  last_trade_date: string;
  final_settlement_date: string;
  settlement_type: SettlementType;
  delivery_method: DeliveryMethod;
  price_limit_rule: string;
  trading_hours: string;
  margin_method: MarginMethod;
  specification_version: string;
  is_custom_synthetic?: boolean;
}

export interface ContractChainPoint {
  contract_id?: string;
  contract_code: string; // e.g. RQESZ26
  root_symbol: string;
  expiry_date: string;
  days_to_expiry: number;
  month_code: string; // F, G, H, J, K, M, N, Q, U, V, X, Z
  year: number;
  last_price: number;
  bid: number;
  ask: number;
  settlement: number;
  volume: number;
  open_interest: number;
  basis: number;
  implied_carry: number;
  change: number;
  change_percent?: number;
  status?: string;
}

export interface MarketDataObservation {
  instrument_id: string;
  root_symbol: string;
  contract_name: string;
  price: number;
  bid: number;
  ask: number;
  settlement_price: number;
  volume: number;
  open_interest: number;
  source: string;
  status: 'LIVE' | 'SYNTHETIC' | 'STALE' | 'SUSPECT';
  quality_score: number; // 0.0 - 1.0
  currency: string;
  unit: string;
  snapshot_id: string;
}

export interface Trade {
  trade_id: string;
  contract_id: string;
  portfolio_id: string;
  side: TradeSide;
  quantity: number;
  price: number;
  timestamp: string;
  execution_reference: string;
  commission: number;
  fees: number;
  source: string;
}

export interface PositionLot {
  lot_id: string;
  trade_id: string;
  entry_time: string;
  quantity: number;
  entry_price: number;
  realized_pnl?: number;
}

export interface FuturesPosition {
  position_id: string;
  contract_id?: string;
  portfolio_id: string;
  account_id: string;
  root_symbol: string;
  contract_code: string;
  contract_name: string;
  asset_class: AssetClass;
  side: TradeSide;
  quantity: number;
  average_entry_price: number;
  current_price: number;
  settlement_price?: number;
  contract_multiplier: number;
  tick_size?: number;
  tick_value?: number;
  notional_value: number;
  unrealized_pnl: number;
  realized_pnl: number;
  initial_margin: number;
  maintenance_margin: number;
  margin_utilization: number;
  currency: string;
  position_status: PositionStatus;
  expiry_date: string;
  created_at?: string;
  updated_at?: string;
  lots: PositionLot[];
}

export interface ValuationRun {
  valuation_run_id: string;
  valuation_time: string;
  market_snapshot_id: string;
  model_version: string;
  position_version: string;
  valuation_status: string;
  entry_value: number;
  current_value: number;
  price_pnl: number;
  currency_pnl: number;
  fees: number;
  slippage: number;
  net_pnl: number;
}

export interface MarginAccount {
  account_id: string;
  portfolio_id: string;
  cash_balance: number;
  collateral_value: number;
  current_equity: number;
  initial_margin_req: number;
  maintenance_margin_req: number;
  variation_margin_due: number;
  margin_utilization_pct: number;
  excess_liquidity: number;
  status: 'HEALTHY' | 'WARNING' | 'MARGIN_CALL' | 'LIQUIDATION_RISK';
  margin_model: MarginMethod;
  last_updated: string;
}

export interface MarginEvent {
  event_id: string;
  account_id: string;
  timestamp: string;
  event_type: 'INITIAL_DEPOSIT' | 'VARIATION_MARGIN_SETTLEMENT' | 'MARGIN_CALL_ISSUED' | 'COLLATERAL_TRANSFER';
  amount: number;
  resulting_balance: number;
  description: string;
}

export interface SettlementEvent {
  event_id: string;
  contract_code: string;
  timestamp: string;
  settlement_type: SettlementType;
  settlement_date: string;
  settlement_price: number;
  final_settlement_price: number;
  gross_cash_flow: number;
  cash_amount: number;
  total_positions_settled?: number;
  delivery_notice_id?: string;
  delivery_notice_ref?: string;
  delivery_location?: string;
  status: 'PENDING' | 'EXECUTED' | 'DELIVERY_NOTICE_ISSUED' | 'FINAL_SETTLED' | 'RECONCILED';
}

export interface FuturesCurvePoint {
  contract_code: string;
  expiry_date: string;
  days_to_expiry: number;
  futures_price: number;
  spread_to_front: number;
  open_interest: number;
  volume: number;
  implied_roll_yield: number;
  is_synthetic: boolean;
}

export interface FuturesCurve {
  curve_id: string;
  root_symbol: string;
  valuation_time: string;
  construction_method: string;
  interpolation_method: string;
  source_snapshot_id: string;
  quality_status: string;
  points: FuturesCurvePoint[];
}

export interface RiskScenario {
  scenario_id: string;
  scenario_name?: string;
  name?: string;
  price_shock_pct: number;
  volatility_shift_pct: number;
  basis_shock_pct?: number;
  basis_shock_bps?: number;
  margin_rate_multiplier: number;
  fx_shock_pct?: number;
  fx_rate_shock_pct?: number;
}

export interface RiskResult {
  scenario_id: string;
  scenario_name: string;
  timestamp: string;
  base_pnl: number;
  shocked_pnl: number;
  pnl_difference: number;
  base_notional: number;
  shocked_notional: number;
  notional_difference: number;
  base_margin: number;
  shocked_margin: number;
  margin_difference: number;
  liquidity_impact_score: number;
  risk_decomposition: {
    asset_class: string;
    exposure: number;
    shocked_pnl: number;
  }[];
}

export interface RollAnalysis {
  front_contract: string;
  next_contract: string;
  front_price: number;
  next_price: number;
  roll_spread: number;
  annualized_roll_yield: number;
  estimated_execution_cost: number;
  front_volume: number;
  next_volume: number;
  volume_migration_pct: number;
  front_open_interest: number;
  next_open_interest: number;
  open_interest_migration_pct: number;
  recommendation_note: string;
}

export interface ReconciliationException {
  exception_id: string;
  severity: ExceptionSeverity;
  source_system: string;
  target_system: string;
  entity_type: string;
  entity_id?: string;
  entity_ref: string;
  expected_value: string;
  actual_value: string;
  discrepancy_details: string;
  assigned_user: string;
  status?: string;
  resolution_status: ReconciliationStatus;
  created_at: string;
  resolution_history?: string[];
}

export interface ModelGovernanceCard {
  model_id: string;
  model_name: string;
  model_category: 'VALUATION' | 'CARRY' | 'CURVE' | 'MARGIN' | 'RISK' | 'LIQUIDITY';
  version?: string;
  model_version: string;
  owner?: string;
  intended_use: string;
  prohibited_use: string;
  formula_definition?: string;
  formulas: string[];
  inputs?: string[];
  outputs?: string[];
  assumptions: string[];
  calibration_data: string;
  limitations: string[] | string;
  validation_status: 'APPROVED' | 'PROVISIONAL' | 'UNDER_REVIEW';
  change_history: { version: string; date: string; notes: string }[];
}

export interface AuditEvent {
  audit_id: string;
  timestamp: string;
  user_action: string;
  actor: string;
  entity_type: string;
  entity_id: string;
  specification_version?: string;
  details: string;
}

export interface CalculationLineage {
  calculation_name: string;
  formula: string;
  inputs: Record<string, any>;
  units: string;
  precision_applied: string;
  model_version: string;
  limitations: string;
  result_value: any;
}

export interface SimulationConfig {
  time_scale: '1X' | '10X' | '100X';
  market_regime: 'CALM' | 'TRENDING' | 'VOLATILE' | 'STRESSED';
  term_structure: 'CONTANGO' | 'BACKWARDATION' | 'FLAT';
  liquidity_regime: 'HIGH' | 'MEDIUM' | 'LOW';
  margin_regime: 'NORMAL' | 'ELEVATED' | 'STRESSED';
  expiry_mode: 'NORMAL' | 'APPROACHING' | 'DELIVERY_RISK';
}
