/**
 * RHINOQUANT FUTURES - TOP HEADER BAR
 * Institutional Header with Brand, Quick Ticker metrics, Simulation Controls,
 * and Data Provenance status badges.
 */

import React, { useState, useEffect } from 'react';
import { quantStore } from '../engine/stateStore';
import { SimulationConfig } from '../types/futures';
import { Activity, ShieldCheck, Zap, Sliders, Calculator, RefreshCw } from 'lucide-react';

interface Props {
  onOpenLineage: () => void;
}

export const Header: React.FC<Props> = ({ onOpenLineage }) => {
  const [config, setConfig] = useState<SimulationConfig>(quantStore.getSimulationConfig());
  const [marginAcct, setMarginAcct] = useState(quantStore.getMarginAccount());
  const [currentTime, setCurrentTime] = useState(new Date().toISOString().slice(11, 19));

  useEffect(() => {
    const unsubscribe = quantStore.subscribe(() => {
      setConfig(quantStore.getSimulationConfig());
      setMarginAcct(quantStore.getMarginAccount());
    });
    const interval = setInterval(() => {
      setCurrentTime(new Date().toISOString().slice(11, 19));
    }, 1000);
    return () => {
      unsubscribe();
      clearInterval(interval);
    };
  }, []);

  const handleRegimeChange = (market_regime: SimulationConfig['market_regime']) => {
    quantStore.updateSimulationConfig({ market_regime });
  };

  const handleTermStructureChange = (term_structure: SimulationConfig['term_structure']) => {
    quantStore.updateSimulationConfig({ term_structure });
  };

  const handleTimeScaleChange = (time_scale: SimulationConfig['time_scale']) => {
    quantStore.updateSimulationConfig({ time_scale });
  };

  return (
    <header className="bg-[#0b0e14] border-b border-slate-800 text-slate-200 select-none">
      {/* Top Banner */}
      <div className="px-6 py-2.5 flex flex-wrap items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded bg-gradient-to-br from-blue-600 to-slate-900 border border-blue-400/40 flex items-center justify-center font-bold text-white tracking-widest text-sm shadow-md">
            RQ
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-sm font-bold tracking-wider text-slate-100 uppercase">
                RHINOQUANT FUTURES
              </h1>
              <span className="px-1.5 py-0.5 text-[10px] font-mono bg-blue-950 text-blue-300 border border-blue-800 rounded">
                INSTITUTIONAL v2026.1
              </span>
              <span className="px-1.5 py-0.5 text-[10px] font-mono bg-amber-950/80 text-amber-300 border border-amber-800/80 rounded font-semibold">
                SYNTHETIC PROTOTYPE
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">
              Futures Contract Analytics, Valuation & Portfolio Risk Laboratory
            </p>
          </div>
        </div>

        {/* Global Key Status Indicators */}
        <div className="flex items-center space-x-6 text-xs font-mono">
          {/* Equity */}
          <div className="flex flex-col items-end">
            <span className="text-[10px] text-slate-400 uppercase">Portfolio Equity</span>
            <span className="font-bold text-slate-100">
              ${marginAcct.current_equity.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
          </div>

          {/* Initial Margin */}
          <div className="flex flex-col items-end">
            <span className="text-[10px] text-slate-400 uppercase">Initial Margin</span>
            <span className="font-medium text-slate-300">
              ${marginAcct.initial_margin_req.toLocaleString()}
            </span>
          </div>

          {/* Utilization % */}
          <div className="flex flex-col items-end">
            <span className="text-[10px] text-slate-400 uppercase">Margin Util %</span>
            <span
              className={`font-bold ${
                marginAcct.margin_utilization_pct > 80 ? 'text-amber-400' : 'text-emerald-400'
              }`}
            >
              {marginAcct.margin_utilization_pct}%
            </span>
          </div>

          {/* Time & Feed Status */}
          <div className="flex items-center space-x-2 border-l border-slate-800 pl-4">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-slate-300 font-bold">{currentTime} UTC</span>
          </div>
        </div>
      </div>

      {/* Control Strip & Simulation Parameters */}
      <div className="px-6 py-1.5 bg-[#121722] border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs font-mono">
        {/* Simulation Controls */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1.5 text-slate-400">
            <Sliders className="w-3.5 h-3.5 text-blue-400" />
            <span className="uppercase text-[11px] font-semibold text-slate-300">Market Regime:</span>
          </div>
          <div className="inline-flex rounded border border-slate-700 bg-slate-900 p-0.5">
            {(['CALM', 'TRENDING', 'VOLATILE', 'STRESSED'] as const).map((r) => (
              <button
                key={r}
                onClick={() => handleRegimeChange(r)}
                className={`px-2 py-0.5 text-[10px] font-bold rounded transition-colors ${
                  config.market_regime === r
                    ? r === 'STRESSED'
                      ? 'bg-rose-700 text-white'
                      : 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          <div className="flex items-center space-x-1.5 text-slate-400 pl-2">
            <span className="uppercase text-[11px] font-semibold text-slate-300">Term Structure:</span>
          </div>
          <div className="inline-flex rounded border border-slate-700 bg-slate-900 p-0.5">
            {(['CONTANGO', 'BACKWARDATION', 'FLAT'] as const).map((t) => (
              <button
                key={t}
                onClick={() => handleTermStructureChange(t)}
                className={`px-2 py-0.5 text-[10px] font-bold rounded transition-colors ${
                  config.term_structure === t
                    ? 'bg-slate-700 text-blue-300 border border-slate-600'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          <div className="flex items-center space-x-1 text-slate-400 pl-2">
            <span className="uppercase text-[11px] font-semibold text-slate-300">Speed:</span>
            {(['1X', '10X', '100X'] as const).map((s) => (
              <button
                key={s}
                onClick={() => handleTimeScaleChange(s)}
                className={`px-1.5 py-0.5 text-[10px] font-bold rounded ${
                  config.time_scale === s ? 'bg-emerald-700 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-3">
          <button
            onClick={() => quantStore.recalculateAllValuations()}
            className="flex items-center space-x-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded text-[11px] transition-colors"
          >
            <RefreshCw className="w-3 h-3 text-blue-400" />
            <span>Recalculate Mark-to-Market</span>
          </button>

          <button
            onClick={onOpenLineage}
            className="flex items-center space-x-1 px-2.5 py-1 bg-blue-950/80 hover:bg-blue-900 border border-blue-700 text-blue-200 rounded text-[11px] transition-colors font-semibold"
          >
            <Calculator className="w-3.5 h-3.5 text-blue-400" />
            <span>Calculation Lineage</span>
          </button>
        </div>
      </div>
    </header>
  );
};
