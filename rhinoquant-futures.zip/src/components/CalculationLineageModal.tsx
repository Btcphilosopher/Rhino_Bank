/**
 * RHINOQUANT - CALCULATION LINEAGE MODAL
 * Displays complete mathematical provenance, formula, inputs, units,
 * precision, and limitations for any calculated financial value.
 */

import React from 'react';
import { CalculationLineage } from '../types/futures';
import { X, Calculator, ShieldCheck, Cpu } from 'lucide-react';

interface Props {
  lineage: CalculationLineage | null;
  onClose: () => void;
}

export const CalculationLineageModal: React.FC<Props> = ({ lineage, onClose }) => {
  if (!lineage) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="w-full max-w-2xl bg-[#0f141d] border border-slate-700 rounded-lg shadow-2xl overflow-hidden text-slate-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-[#161c28]">
          <div className="flex items-center space-x-3">
            <Calculator className="w-5 h-5 text-blue-400" />
            <div>
              <h3 className="text-sm font-semibold tracking-wider text-slate-100 uppercase">
                {lineage.calculation_name}
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Model: {lineage.model_version}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 text-xs font-mono">
          {/* Result Highlight */}
          <div className="p-4 bg-slate-900/90 border border-slate-800 rounded flex items-center justify-between">
            <span className="text-slate-400 uppercase tracking-wider">Calculated Output Result</span>
            <span className="text-base font-bold text-emerald-400">{lineage.result_value}</span>
          </div>

          {/* Formula */}
          <div>
            <label className="text-slate-400 uppercase tracking-wider block mb-1.5 text-[11px]">
              Mathematical Formula
            </label>
            <div className="p-3 bg-[#090d14] border border-slate-800 rounded font-mono text-blue-300">
              {lineage.formula}
            </div>
          </div>

          {/* Inputs Grid */}
          <div>
            <label className="text-slate-400 uppercase tracking-wider block mb-1.5 text-[11px]">
              Exact Model Inputs
            </label>
            <div className="bg-[#090d14] border border-slate-800 rounded p-3 grid grid-cols-2 gap-2 text-slate-300">
              {Object.entries(lineage.inputs).map(([key, val]) => (
                <div key={key} className="flex justify-between border-b border-slate-800/60 pb-1">
                  <span className="text-slate-400">{key}:</span>
                  <span className="font-semibold text-slate-200">{String(val)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Metadata Grid */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-slate-400 uppercase tracking-wider block mb-1 text-[11px]">
                Units
              </label>
              <div className="text-slate-300">{lineage.units}</div>
            </div>
            <div>
              <label className="text-slate-400 uppercase tracking-wider block mb-1 text-[11px]">
                Precision Applied
              </label>
              <div className="text-slate-300">{lineage.precision_applied}</div>
            </div>
          </div>

          {/* Limitations */}
          <div>
            <label className="text-slate-400 uppercase tracking-wider block mb-1 text-[11px]">
              Model Assumptions & Limitations
            </label>
            <div className="p-2.5 bg-amber-950/20 border border-amber-900/40 rounded text-amber-300/90">
              {lineage.limitations}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 bg-[#161c28] border-t border-slate-800 flex justify-between items-center text-xs">
          <div className="flex items-center space-x-1.5 text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Audit Proof Verified by RhinoQuant Model Governance</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium rounded transition-colors"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
