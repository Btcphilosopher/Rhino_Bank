/**
 * RHINOQUANT - POSITION & TRANSACTION LEDGER
 * Immutable portfolio position ledger, trade execution form,
 * FIFO position lot drill-down, unrealized & realized P&L accounting.
 */

import React, { useState } from 'react';
import { quantStore } from '../../engine/stateStore';
import { FuturesPosition, TradeSide, PositionLot } from '../../types/futures';
import { Layers, Plus, DollarSign, ChevronRight, Info } from 'lucide-react';

export const PositionsScreen: React.FC = () => {
  const [positions, setPositions] = useState<FuturesPosition[]>(quantStore.getPositions());
  const specs = quantStore.getContractSpecs();

  // New Trade Execution Form State
  const [selectedSpecId, setSelectedSpecId] = useState(specs[0].contract_id);
  const [tradeSide, setTradeSide] = useState<TradeSide>('LONG');
  const [tradeQty, setTradeQty] = useState(5);
  const [tradePrice, setTradePrice] = useState(5840.00);
  const [selectedLotPos, setSelectedLotPos] = useState<FuturesPosition | null>(null);

  const handleExecuteTrade = (e: React.FormEvent) => {
    e.preventDefault();
    const spec = specs.find((s) => s.contract_id === selectedSpecId) || specs[0];
    quantStore.createTrade(spec, tradeSide, tradeQty, tradePrice);
    setPositions([...quantStore.getPositions()]);
  };

  return (
    <div className="p-6 space-y-6 font-mono text-slate-200">
      {/* Header & New Order Form */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-100">
            Portfolio Position & Transaction Ledger
          </h2>
          <p className="text-xs text-slate-400">
            Immutable trade ledger, lot-level accounting, mark-to-market P&L, and margin tracking.
          </p>
        </div>

        {/* Order Deck Form */}
        <form onSubmit={handleExecuteTrade} className="flex flex-wrap items-center gap-3 bg-[#111622] p-2 border border-slate-800 rounded text-xs">
          <div>
            <label className="text-[10px] text-slate-400 block uppercase">Contract</label>
            <select
              value={selectedSpecId}
              onChange={(e) => {
                setSelectedSpecId(e.target.value);
                const s = specs.find((x) => x.contract_id === e.target.value);
                if (s) setTradePrice(s.tick_size < 0.01 ? 1.1080 : 5840.00);
              }}
              className="bg-[#090d14] border border-slate-800 rounded px-2 py-1 text-blue-400 font-bold"
            >
              {specs.map((s) => (
                <option key={s.contract_id} value={s.contract_id}>
                  {s.root_symbol} ({s.contract_name})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] text-slate-400 block uppercase">Side</label>
            <select
              value={tradeSide}
              onChange={(e) => setTradeSide(e.target.value as TradeSide)}
              className="bg-[#090d14] border border-slate-800 rounded px-2 py-1 font-bold"
            >
              <option value="LONG">LONG (BUY)</option>
              <option value="SHORT">SHORT (SELL)</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] text-slate-400 block uppercase">Qty</label>
            <input
              type="number"
              value={tradeQty}
              onChange={(e) => setTradeQty(parseInt(e.target.value) || 1)}
              className="w-16 bg-[#090d14] border border-slate-800 rounded px-2 py-1 font-bold text-slate-100"
            />
          </div>

          <div>
            <label className="text-[10px] text-slate-400 block uppercase">Price</label>
            <input
              type="number"
              step="any"
              value={tradePrice}
              onChange={(e) => setTradePrice(parseFloat(e.target.value) || 100)}
              className="w-24 bg-[#090d14] border border-slate-800 rounded px-2 py-1 font-bold text-slate-100"
            />
          </div>

          <div className="pt-3">
            <button
              type="submit"
              className={`px-3 py-1 rounded text-xs font-bold text-white transition-colors ${
                tradeSide === 'LONG' ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-rose-600 hover:bg-rose-500'
              }`}
            >
              Execute {tradeSide} Order
            </button>
          </div>
        </form>
      </div>

      {/* Position Table */}
      <div className="bg-[#111622] border border-slate-800 rounded overflow-hidden">
        <div className="px-4 py-3 bg-[#161c28] border-b border-slate-800 flex justify-between items-center">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Open Portfolio Positions ({positions.filter((p) => p.position_status === 'OPEN').length} Active)
          </h3>
          <span className="text-[11px] text-slate-400">Account: PORT_ALPHA_INSTITUTIONAL</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#0b0e14] text-slate-400 border-b border-slate-800 uppercase text-[10px]">
                <th className="p-2.5">Contract Code</th>
                <th className="p-2.5">Side</th>
                <th className="p-2.5 text-right">Quantity</th>
                <th className="p-2.5 text-right">Avg Entry</th>
                <th className="p-2.5 text-right">Last Price</th>
                <th className="p-2.5 text-right">Notional Value</th>
                <th className="p-2.5 text-right">Unrealized P&L</th>
                <th className="p-2.5 text-right">Realized P&L</th>
                <th className="p-2.5 text-right">Initial Margin</th>
                <th className="p-2.5 text-right">Margin Util %</th>
                <th className="p-2.5">Lots</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {positions.map((pos) => {
                const isOpen = pos.position_status === 'OPEN';
                return (
                  <tr key={pos.position_id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="p-2.5 font-bold text-blue-400">{pos.contract_code}</td>
                    <td className="p-2.5">
                      <span
                        className={`px-1.5 py-0.5 text-[10px] rounded font-bold ${
                          pos.side === 'LONG' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'
                        }`}
                      >
                        {pos.side}
                      </span>
                    </td>
                    <td className="p-2.5 text-right font-bold text-slate-100">{pos.quantity}</td>
                    <td className="p-2.5 text-right text-slate-300">{pos.average_entry_price}</td>
                    <td className="p-2.5 text-right font-bold text-slate-100">{pos.current_price}</td>
                    <td className="p-2.5 text-right text-blue-300">${pos.notional_value.toLocaleString()}</td>
                    <td className={`p-2.5 text-right font-bold ${pos.unrealized_pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {pos.unrealized_pnl >= 0 ? '+' : ''}${pos.unrealized_pnl.toLocaleString()}
                    </td>
                    <td className="p-2.5 text-right text-slate-300">${pos.realized_pnl.toLocaleString()}</td>
                    <td className="p-2.5 text-right text-slate-300">${pos.initial_margin.toLocaleString()}</td>
                    <td className="p-2.5 text-right text-slate-400">{pos.margin_utilization}%</td>
                    <td className="p-2.5">
                      <button
                        onClick={() => setSelectedLotPos(pos)}
                        className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-blue-300 text-[10px] rounded border border-slate-700 font-bold"
                      >
                        Inspect {pos.lots.length} Lot(s)
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Lot Breakdown Modal */}
      {selectedLotPos && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-xl bg-[#0f141d] border border-slate-700 rounded-lg p-5 text-slate-200 font-mono space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <h3 className="text-xs font-bold uppercase text-slate-100">
                FIFO Position Lots ({selectedLotPos.contract_code})
              </h3>
              <button onClick={() => setSelectedLotPos(null)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <div className="space-y-2 text-xs">
              {selectedLotPos.lots.map((lot) => (
                <div key={lot.lot_id} className="p-3 bg-[#090d14] border border-slate-800 rounded flex justify-between items-center">
                  <div>
                    <div className="font-bold text-blue-400">Trade Ref: {lot.trade_id}</div>
                    <div className="text-slate-400 text-[10px]">{lot.entry_time}</div>
                  </div>
                  <div className="text-right">
                    <div>Quantity: <span className="font-bold text-slate-100">{lot.quantity}</span></div>
                    <div>Entry Price: <span className="font-bold text-emerald-400">${lot.entry_price}</span></div>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => setSelectedLotPos(null)}
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
