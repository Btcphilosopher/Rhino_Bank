/**
 * RHINOQUANT - MODEL GOVERNANCE & SYSTEM CONTROLS
 * Model cards, governance documentation, intended vs prohibited uses,
 * mathematical assumptions, simulation engine controls, and audit log ledger.
 */

import React, { useState } from 'react';
import { quantStore } from '../../engine/stateStore';
import { ModelGovernanceCard } from '../../types/futures';
import { ShieldCheck, Sliders, Cpu, Activity, Info, CheckCircle } from 'lucide-react';

export const ModelGovernanceScreen: React.FC = () => {
  const cards: ModelGovernanceCard[] = quantStore.getModelGovernanceCards();
  const [selectedCard, setSelectedCard] = useState<ModelGovernanceCard>(cards[0]);
  const [simConfig, setSimConfig] = useState(quantStore.getSimulationConfig());

  const handleUpdateSim = (updates: Partial<typeof simConfig>) => {
    quantStore.updateSimulationConfig(updates);
    setSimConfig(quantStore.getSimulationConfig());
  };

  return (
    <div className="p-6 space-y-6 font-mono text-slate-200">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-100">
            Quantitative Model Governance & System Engine
          </h2>
          <p className="text-xs text-slate-400">
            Formal model documentation cards, mathematical assumptions, limitations, and simulation controls.
          </p>
        </div>

        <span className="px-2.5 py-1 text-xs bg-emerald-950 text-emerald-300 border border-emerald-800 rounded font-bold flex items-center space-x-1">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>GOVERNANCE STATUS: COMPLIANT</span>
        </span>
      </div>

      {/* Simulation Engine Controls Bar */}
      <div className="bg-[#111622] border border-slate-800 p-4 rounded space-y-3 text-xs">
        <h3 className="font-bold uppercase tracking-wider text-slate-200 border-b border-slate-800 pb-2">
          Synthetic Engine Simulation & Regime Controls
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-slate-400 block mb-1">Market Regime</label>
            <div className="inline-flex rounded border border-slate-800 bg-slate-900 p-1 w-full">
              {(['CALM', 'TRENDING', 'VOLATILE', 'STRESSED'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => handleUpdateSim({ market_regime: r })}
                  className={`flex-1 py-1 text-[10px] font-bold rounded transition-colors ${
                    simConfig.market_regime === r
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Term Structure Regime</label>
            <div className="inline-flex rounded border border-slate-800 bg-slate-900 p-1 w-full">
              {(['CONTANGO', 'BACKWARDATION', 'FLAT'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => handleUpdateSim({ term_structure: t })}
                  className={`flex-1 py-1 text-[10px] font-bold rounded transition-colors ${
                    simConfig.term_structure === t
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Simulation Time Scale</label>
            <div className="inline-flex rounded border border-slate-800 bg-slate-900 p-1 w-full">
              {(['1X', '10X', '100X'] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => handleUpdateSim({ time_scale: s })}
                  className={`flex-1 py-1 text-[10px] font-bold rounded transition-colors ${
                    simConfig.time_scale === s
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Model Cards Deck */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Card Selector (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          <h3 className="text-xs font-bold uppercase text-slate-200">Registered Model Cards</h3>
          <div className="bg-[#111622] border border-slate-800 rounded divide-y divide-slate-800/80">
            {cards.map((c) => {
              const isSelected = selectedCard.model_id === c.model_id;
              return (
                <div
                  key={c.model_id}
                  onClick={() => setSelectedCard(c)}
                  className={`p-3 cursor-pointer transition-colors ${
                    isSelected ? 'bg-blue-950/80 border-l-4 border-blue-500' : 'hover:bg-slate-800/40'
                  }`}
                >
                  <div className="font-bold text-blue-400 text-xs">{c.model_name}</div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                    Ver: {c.version} | Owner: {c.owner}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Model Card Details (8 cols) */}
        <div className="lg:col-span-8 bg-[#111622] border border-slate-800 rounded p-5 space-y-4 text-xs font-mono">
          <div className="flex justify-between items-center border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-100 uppercase">{selectedCard.model_name}</h3>
              <p className="text-[11px] text-slate-400">ID: {selectedCard.model_id} | Version: {selectedCard.version}</p>
            </div>
            <span className="px-2 py-0.5 text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 rounded font-bold">
              {selectedCard.validation_status}
            </span>
          </div>

          <div>
            <label className="text-slate-400 uppercase text-[10px] font-bold block mb-1">Intended Purpose</label>
            <div className="p-3 bg-[#090d14] border border-slate-800 rounded text-slate-200">
              {selectedCard.intended_use}
            </div>
          </div>

          <div>
            <label className="text-slate-400 uppercase text-[10px] font-bold block mb-1">Strict Prohibited Uses</label>
            <div className="p-3 bg-rose-950/20 border border-rose-900/40 rounded text-rose-300">
              {selectedCard.prohibited_use}
            </div>
          </div>

          <div>
            <label className="text-slate-400 uppercase text-[10px] font-bold block mb-1">Mathematical Formula</label>
            <div className="p-3 bg-[#090d14] border border-slate-800 rounded text-blue-300 font-bold">
              {selectedCard.formula_definition}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-slate-400 uppercase text-[10px] font-bold block mb-1">Core Inputs</label>
              <div className="p-2.5 bg-[#090d14] border border-slate-800 rounded text-slate-300">
                {(selectedCard.inputs || []).join(', ')}
              </div>
            </div>
            <div>
              <label className="text-slate-400 uppercase text-[10px] font-bold block mb-1">Outputs</label>
              <div className="p-2.5 bg-[#090d14] border border-slate-800 rounded text-slate-300">
                {(selectedCard.outputs || []).join(', ')}
              </div>
            </div>
          </div>

          <div>
            <label className="text-slate-400 uppercase text-[10px] font-bold block mb-1">Assumptions & Limitations</label>
            <div className="p-3 bg-amber-950/20 border border-amber-900/40 rounded text-amber-300/90 space-y-1">
              <div>Assumptions: {selectedCard.assumptions.join('; ')}</div>
              <div>Limitations: {selectedCard.limitations}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
