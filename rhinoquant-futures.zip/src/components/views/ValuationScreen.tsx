/**
 * RHINOQUANT - MARK-TO-MARKET VALUATION ENGINE
 * Intraday and daily official settlement valuation runs, entry value,
 * current value, price P&L, currency P&L, fees, slippage, net P&L.
 */

import React, { useState } from 'react';
import { quantStore } from '../../engine/stateStore';
import { FuturesPosition, ValuationRun } from '../../types/futures';
import { DollarSign, RefreshCw, BarChart2, ShieldCheck } from 'lucide-react';

export const ValuationScreen: React.FC = () => {
  const [positions] = useState<FuturesPosition[]>(quantStore.getPositions());
  const [lastValuation, setLastValuation] = useState<ValuationRun | null>({
    valuation_run_id: `val_${Date.now()}`,
    valuation_time: new Date().toISOString(),
    market_snapshot_id: 'snap_20260921_01',
    model_version: 'v2.4.0-RhinoQuantValuation',
    position_version: 'v1.0',
    valuation_status: 'COMPLETED',
    entry_value: positions.reduce((acc, p) => acc + p.average_entry_price * p.contract_multiplier * p.quantity, 0),
    current_value: positions.reduce((acc, p) => acc + p.current_price * p.contract_multiplier * p.quantity, 0),
    price_pnl: positions.reduce((acc, p) => acc + p.unrealized_pnl, 0),
    currency_pnl: 0,
    fees: 18.50,
    slippage: 12.00,
    net_pnl: positions.reduce((acc, p) => acc + p.unrealized_pnl, 0) - 30.50,
  });

  const handleRunValuation = () => {
    quantStore.recalculateAllValuations();
    const updatedPos = quantStore.getPositions();
    const pnl = updatedPos.reduce((acc, p) => acc + p.unrealized_pnl, 0);

    setLastValuation({
      valuation_run_id: `val_${Date.now()}`,
      valuation_time: new Date().toISOString(),
      market_snapshot_id: `snap_${Date.now()}`,
      model_version: 'v2.4.0-RhinoQuantValuation',
      position_version: 'v1.0',
      valuation_status: 'COMPLETED',
      entry_value: updatedPos.reduce((acc, p) => acc + p.average_entry_price * p.contract_multiplier * p.quantity, 0),
      current_value: updatedPos.reduce((acc, p) => acc + p.current_price * p.contract_multiplier * p.quantity, 0),
      price_pnl: pnl,
      currency_pnl: 0,
      fees: 18.50,
      slippage: 12.00,
      net_pnl: pnl - 30.50,
    });
  };

  return (
    <div className="p-6 space-y-6 font-mono text-slate-200">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-100">
            Mark-to-Market Valuation Engine
          </h2>
          <p className="text-xs text-slate-400">
            Intraday valuation runs, full cost decomposition, FX translation, and audit-provenance logs.
          </p>
        </div>

        <button
          onClick={handleRunValuation}
          className="flex items-center space-x-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-bold transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Execute Official Valuation Run</span>
        </button>
      </div>

      {/* Valuation Breakdown Grid */}
      {lastValuation && (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
          <div className="p-3 bg-[#111622] border border-slate-800 rounded">
            <div className="text-[10px] text-slate-400 uppercase">Entry Value</div>
            <div className="text-sm font-bold text-slate-200 mt-1">
              ${(lastValuation.entry_value / 1e6).toFixed(2)}M
            </div>
          </div>

          <div className="p-3 bg-[#111622] border border-slate-800 rounded">
            <div className="text-[10px] text-slate-400 uppercase">Current Value</div>
            <div className="text-sm font-bold text-blue-400 mt-1">
              ${(lastValuation.current_value / 1e6).toFixed(2)}M
            </div>
          </div>

          <div className="p-3 bg-[#111622] border border-slate-800 rounded">
            <div className="text-[10px] text-slate-400 uppercase">Price P&L</div>
            <div className={`text-sm font-bold mt-1 ${lastValuation.price_pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {lastValuation.price_pnl >= 0 ? '+' : ''}${lastValuation.price_pnl.toLocaleString()}
            </div>
          </div>

          <div className="p-3 bg-[#111622] border border-slate-800 rounded">
            <div className="text-[10px] text-slate-400 uppercase">Currency P&L</div>
            <div className="text-sm font-bold text-slate-300 mt-1">$0.00</div>
          </div>

          <div className="p-3 bg-[#111622] border border-slate-800 rounded">
            <div className="text-[10px] text-slate-400 uppercase">Fees</div>
            <div className="text-sm font-bold text-rose-300 mt-1">-${lastValuation.fees.toFixed(2)}</div>
          </div>

          <div className="p-3 bg-[#111622] border border-slate-800 rounded">
            <div className="text-[10px] text-slate-400 uppercase">Slippage</div>
            <div className="text-sm font-bold text-rose-300 mt-1">-${lastValuation.slippage.toFixed(2)}</div>
          </div>

          <div className="p-3 bg-[#111622] border border-slate-800 rounded">
            <div className="text-[10px] text-slate-400 uppercase">Net P&L</div>
            <div className={`text-sm font-bold mt-1 ${lastValuation.net_pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {lastValuation.net_pnl >= 0 ? '+' : ''}${lastValuation.net_pnl.toLocaleString()}
            </div>
          </div>
        </div>
      )}

      {/* Position Level Valuation Table */}
      <div className="bg-[#111622] border border-slate-800 rounded overflow-hidden">
        <div className="px-4 py-3 bg-[#161c28] border-b border-slate-800 flex justify-between items-center">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Valued Positions Line Items
          </h3>
          <span className="text-[11px] text-slate-400">Model: {lastValuation?.model_version}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#0b0e14] text-slate-400 border-b border-slate-800 uppercase text-[10px]">
                <th className="p-2.5">Contract</th>
                <th className="p-2.5">Side</th>
                <th className="p-2.5 text-right">Quantity</th>
                <th className="p-2.5 text-right">Avg Price</th>
                <th className="p-2.5 text-right">Current Price</th>
                <th className="p-2.5 text-right">Contract Notional</th>
                <th className="p-2.5 text-right">Unrealized P&L</th>
                <th className="p-2.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {positions.map((pos) => (
                <tr key={pos.position_id} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-bold text-blue-400">{pos.contract_code}</td>
                  <td className="p-2.5 text-slate-300">{pos.side}</td>
                  <td className="p-2.5 text-right font-bold text-slate-100">{pos.quantity}</td>
                  <td className="p-2.5 text-right text-slate-300">{pos.average_entry_price}</td>
                  <td className="p-2.5 text-right font-bold text-slate-100">{pos.current_price}</td>
                  <td className="p-2.5 text-right text-blue-300">${pos.notional_value.toLocaleString()}</td>
                  <td className={`p-2.5 text-right font-bold ${pos.unrealized_pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {pos.unrealized_pnl >= 0 ? '+' : ''}${pos.unrealized_pnl.toLocaleString()}
                  </td>
                  <td className="p-2.5 text-emerald-400 font-bold">VALUED_OK</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
