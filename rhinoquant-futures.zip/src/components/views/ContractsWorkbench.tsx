/**
 * RHINOQUANT - CONTRACT SPECIFICATION ENGINE & WORKBENCH
 * Create, edit, inspect, compare, and validate synthetic futures contracts.
 * Includes dynamic tick value / point value / notional exposure recalculations
 * and ASCII Contract Specification Box as defined in Section 7.
 */

import React, { useState } from 'react';
import { quantStore } from '../../engine/stateStore';
import { FuturesContractSpecification, AssetClass, SettlementType, DeliveryMethod, MarginMethod } from '../../types/futures';
import { calculateTickValue, calculatePointValue, calculateContractNotional } from '../../engine/quantMath';
import { Plus, Search, Layers, Calculator, CheckCircle, ArrowLeftRight, Edit3 } from 'lucide-react';

export const ContractsWorkbench: React.FC = () => {
  const [specs, setSpecs] = useState<FuturesContractSpecification[]>(quantStore.getContractSpecs());
  const [selectedSpec, setSelectedSpec] = useState<FuturesContractSpecification>(specs[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAssetFilter, setSelectedAssetFilter] = useState<string>('ALL');
  const [compareSpec, setCompareSpec] = useState<FuturesContractSpecification | null>(specs[1] || null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);

  // Form State for Creation / Editing
  const [formData, setFormData] = useState<FuturesContractSpecification>({ ...specs[0] });

  // Update form data and auto-recalculate tick value, point value, sample notional
  const handleFormChange = (field: keyof FuturesContractSpecification, val: any) => {
    const updated = { ...formData, [field]: val };

    if (field === 'tick_size' || field === 'contract_multiplier' || field === 'contract_size') {
      const ts = Number(updated.tick_size) || 0.25;
      const cm = Number(updated.contract_multiplier) || 50;

      const { tickValue } = calculateTickValue(ts, cm);
      const { pointValue } = calculatePointValue(cm);

      updated.tick_value = tickValue;
      updated.point_value = pointValue;
    }

    setFormData(updated);
  };

  const handleSaveSpec = (e: React.FormEvent) => {
    e.preventDefault();
    quantStore.saveContractSpec(formData);
    setSpecs(quantStore.getContractSpecs());
    setSelectedSpec(formData);
    setIsCreatingNew(false);
  };

  const startNewCustomContract = () => {
    const newSpec: FuturesContractSpecification = {
      contract_id: `spec_custom_${Date.now()}`,
      root_symbol: 'CUSTOM',
      contract_name: 'Custom Synthetic Futures Contract',
      asset_class: 'SYNTHETIC_CUSTOM',
      underlying_asset: 'Synthetic Index / Asset',
      exchange_code: 'RQEX_LAB',
      currency: 'USD',
      quote_unit: 'Points',
      contract_unit: '100 × Index',
      contract_multiplier: 100,
      contract_size: 100,
      tick_size: 0.10,
      tick_value: 10.00,
      point_value: 100.00,
      listed_months: ['H', 'M', 'U', 'Z'],
      first_trade_date: '2026-01-01',
      last_trade_date: '2026-12-31',
      final_settlement_date: '2026-12-31',
      settlement_type: 'CASH',
      delivery_method: 'CASH_FINAL',
      price_limit_rule: 'Standard Circuit Breaker',
      trading_hours: '24/7 Synthetic Hours',
      margin_method: 'SPAN_STYLE_ABSTRACTION',
      specification_version: 'v2026.1-LAB',
      is_custom_synthetic: true,
    };
    setFormData(newSpec);
    setSelectedSpec(newSpec);
    setIsCreatingNew(true);
  };

  const filteredSpecs = specs.filter((s) => {
    const matchesSearch =
      s.root_symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.contract_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.underlying_asset.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesAsset = selectedAssetFilter === 'ALL' || s.asset_class === selectedAssetFilter;
    return matchesSearch && matchesAsset;
  });

  const { notional: sampleNotional } = calculateContractNotional(100, formData.contract_multiplier);

  return (
    <div className="p-6 space-y-6 font-mono text-slate-200">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-100">
            Futures Contract Specification Workbench
          </h2>
          <p className="text-xs text-slate-400">
            Define, inspect, validate, and compare formal futures contract specifications.
          </p>
        </div>

        <button
          onClick={startNewCustomContract}
          className="flex items-center space-x-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-bold transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Create Custom Synthetic Spec</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (4 cols): Search & Specs List */}
        <div className="lg:col-span-4 space-y-4">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search symbol, name, underlying..."
              className="w-full pl-9 pr-3 py-2 bg-[#111622] border border-slate-800 rounded text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap gap-1 text-[10px]">
            {['ALL', 'EQUITY_INDEX', 'COMMODITY', 'ENERGY', 'METALS', 'CURRENCY', 'INTEREST_RATE'].map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedAssetFilter(cat)}
                className={`px-2 py-1 rounded border transition-colors ${
                  selectedAssetFilter === cat
                    ? 'bg-blue-900/80 border-blue-600 text-blue-200 font-bold'
                    : 'bg-[#111622] border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat.replace('_', ' ')}
              </button>
            ))}
          </div>

          {/* Specs List */}
          <div className="bg-[#111622] border border-slate-800 rounded divide-y divide-slate-800/80 max-h-[550px] overflow-y-auto">
            {filteredSpecs.map((spec) => {
              const isSelected = selectedSpec.contract_id === spec.contract_id;
              return (
                <div
                  key={spec.contract_id}
                  onClick={() => {
                    setSelectedSpec(spec);
                    setFormData({ ...spec });
                    setIsCreatingNew(false);
                  }}
                  className={`p-3 cursor-pointer transition-colors ${
                    isSelected ? 'bg-blue-950/60 border-l-4 border-blue-500' : 'hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <span className="font-bold text-blue-400 text-xs">{spec.root_symbol}</span>
                    <span className="text-[10px] bg-slate-900 px-1.5 py-0.5 text-slate-400 border border-slate-800 rounded">
                      {spec.asset_class}
                    </span>
                  </div>
                  <div className="text-xs text-slate-200 font-semibold mt-1">{spec.contract_name}</div>
                  <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
                    <span>Multiplier: ×{spec.contract_multiplier}</span>
                    <span>Tick Val: ${spec.tick_value}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (8 cols): Editor, Specification Preview, Side-by-Side Comparison */}
        <div className="lg:col-span-8 space-y-6">
          {/* Section 7 ASCII Contract Specification Preview Box */}
          <div className="bg-[#090d14] border border-slate-800 rounded p-4 font-mono text-xs">
            <div className="text-slate-400 uppercase text-[10px] mb-2 font-bold tracking-wider">
              Exact Contract Specification Render (ASCII Model Lineage)
            </div>
            <pre className="text-emerald-400 leading-tight overflow-x-auto bg-[#05080e] p-3 rounded border border-emerald-900/40">
{`┌─────────────────────────────────────────────────────────────┐
│ CONTRACT SPECIFICATION PREVIEW                              │
├─────────────────────────────────────────────────────────────┤
│ ROOT SYMBOL       ${formData.root_symbol.padEnd(42)}│
│ CONTRACT          ${formData.contract_name.padEnd(42)}│
│ UNDERLYING        ${formData.underlying_asset.padEnd(42)}│
│ CONTRACT SIZE     ${`${formData.contract_multiplier} × ${formData.quote_unit}`.padEnd(42)}│
│ MINIMUM TICK      ${`${formData.tick_size} ${formData.quote_unit}`.padEnd(42)}│
│ TICK VALUE        ${`$${formData.tick_value.toFixed(2)} (${formData.currency})`.padEnd(42)}│
│ POINT VALUE       ${`$${formData.point_value.toFixed(2)} (${formData.currency})`.padEnd(42)}│
│ SETTLEMENT        ${formData.settlement_type.padEnd(42)}│
│ EXPIRY            ${formData.listed_months.join(', ').padEnd(42)}│
└─────────────────────────────────────────────────────────────┘`}
            </pre>
          </div>

          {/* Editor Form */}
          <form onSubmit={handleSaveSpec} className="bg-[#111622] border border-slate-800 rounded p-5 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                {isCreatingNew ? 'Create Custom Synthetic Contract' : `Editing Specification: ${formData.root_symbol}`}
              </h3>
              <button
                type="submit"
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold transition-colors"
              >
                Save Specification
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Root Symbol</label>
                <input
                  type="text"
                  value={formData.root_symbol}
                  onChange={(e) => handleFormChange('root_symbol', e.target.value.toUpperCase())}
                  className="w-full p-2 bg-[#090d14] border border-slate-800 rounded text-slate-100 font-bold focus:border-blue-500"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Contract Name</label>
                <input
                  type="text"
                  value={formData.contract_name}
                  onChange={(e) => handleFormChange('contract_name', e.target.value)}
                  className="w-full p-2 bg-[#090d14] border border-slate-800 rounded text-slate-100 focus:border-blue-500"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Asset Class</label>
                <select
                  value={formData.asset_class}
                  onChange={(e) => handleFormChange('asset_class', e.target.value as AssetClass)}
                  className="w-full p-2 bg-[#090d14] border border-slate-800 rounded text-slate-100 focus:border-blue-500"
                >
                  <option value="EQUITY_INDEX">EQUITY INDEX</option>
                  <option value="COMMODITY">COMMODITY</option>
                  <option value="ENERGY">ENERGY</option>
                  <option value="METALS">METALS</option>
                  <option value="AGRICULTURE">AGRICULTURE</option>
                  <option value="CURRENCY">CURRENCY</option>
                  <option value="INTEREST_RATE">INTEREST RATE</option>
                  <option value="SYNTHETIC_CUSTOM">SYNTHETIC CUSTOM</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Contract Multiplier</label>
                <input
                  type="number"
                  step="any"
                  value={formData.contract_multiplier}
                  onChange={(e) => handleFormChange('contract_multiplier', parseFloat(e.target.value) || 1)}
                  className="w-full p-2 bg-[#090d14] border border-slate-800 rounded text-blue-400 font-bold focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Minimum Tick Size</label>
                <input
                  type="number"
                  step="any"
                  value={formData.tick_size}
                  onChange={(e) => handleFormChange('tick_size', parseFloat(e.target.value) || 0.01)}
                  className="w-full p-2 bg-[#090d14] border border-slate-800 rounded text-blue-400 font-bold focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Derived Tick Value (Calculated)</label>
                <div className="p-2 bg-slate-900 border border-slate-800 rounded text-emerald-400 font-bold">
                  ${formData.tick_value.toFixed(2)}
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Derived Point Value (Calculated)</label>
                <div className="p-2 bg-slate-900 border border-slate-800 rounded text-emerald-400 font-bold">
                  ${formData.point_value.toFixed(2)}
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Settlement Type</label>
                <select
                  value={formData.settlement_type}
                  onChange={(e) => handleFormChange('settlement_type', e.target.value as SettlementType)}
                  className="w-full p-2 bg-[#090d14] border border-slate-800 rounded text-slate-100"
                >
                  <option value="CASH">CASH SETTLEMENT</option>
                  <option value="PHYSICAL">PHYSICAL DELIVERY</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Margin Method</label>
                <select
                  value={formData.margin_method}
                  onChange={(e) => handleFormChange('margin_method', e.target.value as MarginMethod)}
                  className="w-full p-2 bg-[#090d14] border border-slate-800 rounded text-slate-100"
                >
                  <option value="SPAN_STYLE_ABSTRACTION">SPAN STYLE ABSTRACTION</option>
                  <option value="FIXED_RATE">FIXED RATE</option>
                  <option value="RISK_BASED">RISK BASED</option>
                  <option value="VOLATILITY_SCALED">VOLATILITY SCALED</option>
                </select>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
