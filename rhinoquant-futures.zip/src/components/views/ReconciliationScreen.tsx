/**
 * RHINOQUANT - RECONCILIATION ENGINE
 * Trades ↔ Positions ↔ Market Data ↔ Valuation ↔ Margin ↔ Settlement multi-tier matrix.
 * Audit exception table, discrepancy details, and automated resolution actions.
 */

import React, { useState } from 'react';
import { quantStore } from '../../engine/stateStore';
import { ReconciliationException } from '../../types/futures';
import { CheckCircle, AlertOctagon, RefreshCw, ShieldCheck } from 'lucide-react';

export const ReconciliationScreen: React.FC = () => {
  const [exceptions, setExceptions] = useState<ReconciliationException[]>(
    quantStore.getReconciliationExceptions()
  );

  const handleRunRecon = () => {
    const res = quantStore.runReconciliation();
    setExceptions([...res]);
  };

  return (
    <div className="p-6 space-y-6 font-mono text-slate-200">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-100">
            Multi-Tier Reconciliation & Integrity Matrix
          </h2>
          <p className="text-xs text-slate-400">
            Cross-verify Trades ↔ Positions ↔ Market Data ↔ Valuation ↔ Margin ↔ Settlement.
          </p>
        </div>

        <button
          onClick={handleRunRecon}
          className="flex items-center space-x-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-bold transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Execute Full Reconciliation Scan</span>
        </button>
      </div>

      {/* Reconciliation Matrix Status Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-3 bg-[#111622] border border-slate-800 rounded">
          <span className="text-[10px] text-slate-400 uppercase block">Trade ↔ Position Match</span>
          <span className="text-sm font-bold text-emerald-400 flex items-center space-x-1 mt-1">
            <CheckCircle className="w-4 h-4" />
            <span>100% MATCHED</span>
          </span>
        </div>

        <div className="p-3 bg-[#111622] border border-slate-800 rounded">
          <span className="text-[10px] text-slate-400 uppercase block">Valuation ↔ Market Data</span>
          <span className="text-sm font-bold text-emerald-400 flex items-center space-x-1 mt-1">
            <CheckCircle className="w-4 h-4" />
            <span>100% MATCHED</span>
          </span>
        </div>

        <div className="p-3 bg-[#111622] border border-slate-800 rounded">
          <span className="text-[10px] text-slate-400 uppercase block">Margin ↔ Equity Balance</span>
          <span className="text-sm font-bold text-emerald-400 flex items-center space-x-1 mt-1">
            <CheckCircle className="w-4 h-4" />
            <span>100% MATCHED</span>
          </span>
        </div>

        <div className="p-3 bg-[#111622] border border-slate-800 rounded">
          <span className="text-[10px] text-slate-400 uppercase block">Active Exceptions</span>
          <span className="text-sm font-bold text-slate-100 mt-1 block">
            {exceptions.filter((e) => (e.status || e.resolution_status) !== 'RESOLVED').length} Open
          </span>
        </div>
      </div>

      {/* Exception Log */}
      <div className="bg-[#111622] border border-slate-800 rounded overflow-hidden">
        <div className="px-4 py-3 bg-[#161c28] border-b border-slate-800">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Reconciliation Exceptions & Audit Logs
          </h3>
        </div>

        {exceptions.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400 font-mono space-y-2">
            <CheckCircle className="w-8 h-8 text-emerald-400 mx-auto" />
            <div className="text-sm font-bold text-slate-200">Zero Reconciliation Exceptions Found</div>
            <div>All internal systems are perfectly balanced and reconciled.</div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="bg-[#0b0e14] text-slate-400 border-b border-slate-800 uppercase text-[10px]">
                  <th className="p-2.5">ID</th>
                  <th className="p-2.5">Severity</th>
                  <th className="p-2.5">Source ↔ Target</th>
                  <th className="p-2.5">Entity</th>
                  <th className="p-2.5">Discrepancy Details</th>
                  <th className="p-2.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {exceptions.map((ex) => (
                  <tr key={ex.exception_id} className="hover:bg-slate-800/40">
                    <td className="p-2.5 font-bold text-slate-300">{ex.exception_id}</td>
                    <td className="p-2.5 font-bold text-rose-400">{ex.severity}</td>
                    <td className="p-2.5 text-slate-300">{ex.source_system} ↔ {ex.target_system}</td>
                    <td className="p-2.5 text-blue-400 font-bold">{ex.entity_id || ex.entity_ref}</td>
                    <td className="p-2.5 text-slate-300">{ex.discrepancy_details}</td>
                    <td className="p-2.5">
                      <span className="px-2 py-0.5 text-[10px] bg-amber-950 text-amber-300 border border-amber-800 rounded font-bold">
                        {ex.status || ex.resolution_status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
