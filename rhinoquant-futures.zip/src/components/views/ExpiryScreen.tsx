/**
 * RHINOQUANT - EXPIRY CALENDAR & MANAGEMENT
 * Expiry dates, first notice dates (FND), last trading day (LTD),
 * delivery period, and unrolled contract risk alerts.
 */

import React from 'react';
import { quantStore } from '../../engine/stateStore';
import { Calendar, AlertTriangle, Clock, Layers } from 'lucide-react';

export const ExpiryScreen: React.FC = () => {
  const specs = quantStore.getContractSpecs();

  return (
    <div className="p-6 space-y-6 font-mono text-slate-200">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-100">
            Contract Expiry Calendar & Delivery Schedule
          </h2>
          <p className="text-xs text-slate-400">
            Track first notice dates (FND), last trading days (LTD), and physical delivery cutoff windows.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="px-2 py-1 text-xs bg-amber-950 text-amber-300 border border-amber-800 rounded font-bold">
            1 EXPIRING CONTRACT WITHIN 90 DAYS
          </span>
        </div>
      </div>

      {/* Expiry Matrix Table */}
      <div className="bg-[#111622] border border-slate-800 rounded overflow-hidden">
        <div className="px-4 py-3 bg-[#161c28] border-b border-slate-800">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Upcoming Contract Expiries & Delivery Cutoffs
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="bg-[#0b0e14] text-slate-400 border-b border-slate-800 uppercase text-[10px]">
                <th className="p-2.5">Symbol</th>
                <th className="p-2.5">Contract Name</th>
                <th className="p-2.5">Asset Class</th>
                <th className="p-2.5">Settlement</th>
                <th className="p-2.5">First Notice Date (FND)</th>
                <th className="p-2.5">Last Trading Day (LTD)</th>
                <th className="p-2.5 text-right">Days Remaining</th>
                <th className="p-2.5">Action Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {specs.map((s) => {
                const chain = quantStore.generateContractChain(s.root_symbol);
                const front = chain[0];
                return (
                  <tr key={s.contract_id} className="hover:bg-slate-800/40">
                    <td className="p-2.5 font-bold text-blue-400">{front.contract_code}</td>
                    <td className="p-2.5 text-slate-200">{s.contract_name}</td>
                    <td className="p-2.5 text-slate-400">{s.asset_class}</td>
                    <td className="p-2.5 text-slate-300">{s.settlement_type}</td>
                    <td className="p-2.5 text-slate-300">{s.first_trade_date}</td>
                    <td className="p-2.5 font-bold text-slate-100">{s.last_trade_date}</td>
                    <td className="p-2.5 text-right font-bold text-amber-400">{front.days_to_expiry}d</td>
                    <td className="p-2.5">
                      <span className="px-2 py-0.5 text-[10px] bg-blue-950 text-blue-300 border border-blue-800 rounded font-bold">
                        ACTIVE TRADING
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
