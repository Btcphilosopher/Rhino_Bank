/**
 * RHINOQUANT - MARGIN ENGINE & SIMULATOR
 * Initial, maintenance, variation margin, margin utilization %,
 * collateral equity, excess liquidity, margin call alerts,
 * and margin model switching.
 */

import React, { useState } from 'react';
import { quantStore } from '../../engine/stateStore';
import { MarginAccount, MarginMethod } from '../../types/futures';
import { ShieldAlert, CheckCircle, RefreshCw, Layers } from 'lucide-react';

export const MarginScreen: React.FC = () => {
  const [account, setAccount] = useState<MarginAccount>(quantStore.getMarginAccount());

  const handleModelChange = (model: MarginMethod) => {
    account.margin_model = model;
    quantStore.recalculateAllValuations();
    setAccount({ ...quantStore.getMarginAccount() });
  };

  return (
    <div className="p-6 space-y-6 font-mono text-slate-200">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-100">
            Margin Engine & Collateral Account Simulator
          </h2>
          <p className="text-xs text-slate-400">
            Initial & maintenance margin requirements, variation margin, utilization, and margin call alerts.
          </p>
        </div>

        {/* Model Switcher */}
        <div className="flex items-center space-x-2 bg-[#111622] p-1.5 border border-slate-800 rounded text-xs">
          <span className="text-slate-400 uppercase text-[10px] font-bold">Margin Model:</span>
          {(['SPAN_STYLE_ABSTRACTION', 'FIXED_RATE', 'RISK_BASED', 'VOLATILITY_SCALED'] as const).map((m) => (
            <button
              key={m}
              onClick={() => handleModelChange(m)}
              className={`px-2 py-1 rounded text-[10px] font-bold transition-colors ${
                account.margin_model === m
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200'
              }`}
            >
              {m.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Account Visual ASCII Box as shown in Section 14 */}
      <div className="bg-[#090d14] border border-slate-800 rounded p-5">
        <div className="text-slate-400 text-[10px] uppercase font-bold mb-2">
          MARGIN ACCOUNT SUMMARY (RhinoQuant Clearing Engine)
        </div>
        <pre className="text-blue-300 font-mono text-sm leading-relaxed bg-[#05080e] p-4 rounded border border-blue-900/40">
{`MARGIN ACCOUNT: ${account.account_id}

INITIAL MARGIN       $${account.initial_margin_req.toLocaleString()}
MAINTENANCE MARGIN   $${account.maintenance_margin_req.toLocaleString()}
CURRENT EQUITY       $${account.current_equity.toLocaleString()}
UTILISATION          ${account.margin_utilization_pct}%
EXCESS LIQUIDITY     $${account.excess_liquidity.toLocaleString()}
STATUS               ${account.status}`}
        </pre>
      </div>

      {/* Detail Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#111622] border border-slate-800 rounded p-4 space-y-3">
          <h3 className="text-xs font-bold uppercase text-slate-200 border-b border-slate-800 pb-2">
            Collateral Balances
          </h3>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Cash Balance:</span>
              <span className="font-bold text-slate-100">${account.cash_balance.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Treasury Collateral:</span>
              <span className="font-bold text-slate-100">${account.collateral_value.toLocaleString()}</span>
            </div>
            <div className="flex justify-between pt-2 border-t border-slate-800">
              <span className="text-slate-400 font-bold">Total Equity:</span>
              <span className="font-bold text-emerald-400">${account.current_equity.toLocaleString()}</span>
            </div>
          </div>
        </div>

        <div className="bg-[#111622] border border-slate-800 rounded p-4 space-y-3">
          <h3 className="text-xs font-bold uppercase text-slate-200 border-b border-slate-800 pb-2">
            Variation Margin Settlement
          </h3>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Daily Mark P&L:</span>
              <span className="font-bold text-emerald-400">+$45,875.00</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">VM Due to Clearing:</span>
              <span className="font-bold text-slate-100">$0.00</span>
            </div>
            <div className="flex justify-between pt-2 border-t border-slate-800">
              <span className="text-slate-400 font-bold">Settlement Status:</span>
              <span className="font-bold text-emerald-400">SETTLED</span>
            </div>
          </div>
        </div>

        <div className="bg-[#111622] border border-slate-800 rounded p-4 space-y-3">
          <h3 className="text-xs font-bold uppercase text-slate-200 border-b border-slate-800 pb-2">
            Margin Call Monitor
          </h3>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Account Health:</span>
              <span className="font-bold text-emerald-400">HEALTHY</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Buffer to MM Call:</span>
              <span className="font-bold text-blue-400">${(account.current_equity - account.maintenance_margin_req).toLocaleString()}</span>
            </div>
            <div className="flex justify-between pt-2 border-t border-slate-800">
              <span className="text-slate-400 font-bold">Liquidation Risk:</span>
              <span className="font-bold text-emerald-400">VERY LOW</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
