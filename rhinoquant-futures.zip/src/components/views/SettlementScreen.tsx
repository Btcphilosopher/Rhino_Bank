/**
 * RHINOQUANT - SETTLEMENT ENGINE
 * Final settlement processing, cash settlement vs physical delivery workflow,
 * warehouse receipts, delivery location notices, and settlement events.
 */

import React, { useState } from 'react';
import { quantStore } from '../../engine/stateStore';
import { SettlementEvent } from '../../types/futures';
import { CheckCircle, Truck, DollarSign, Layers } from 'lucide-react';

export const SettlementScreen: React.FC = () => {
  const [events] = useState<SettlementEvent[]>([
    {
      event_id: 'settle_ev_1',
      contract_code: 'RQESZ26',
      timestamp: '2026-12-18T16:00:00Z',
      settlement_type: 'CASH',
      settlement_date: '2026-12-18',
      settlement_price: 5840.00,
      final_settlement_price: 5840.00,
      gross_cash_flow: 3504000,
      cash_amount: 3504000,
      status: 'FINAL_SETTLED',
    },
    {
      event_id: 'settle_ev_2',
      contract_code: 'RQCLZ26',
      timestamp: '2026-11-20T16:00:00Z',
      settlement_type: 'PHYSICAL',
      settlement_date: '2026-11-20',
      settlement_price: 72.50,
      final_settlement_price: 72.50,
      gross_cash_flow: 362500,
      cash_amount: 362500,
      delivery_notice_id: 'DELIV_CUSHING_OK_882',
      status: 'DELIVERY_NOTICE_ISSUED',
    },
  ]);

  return (
    <div className="p-6 space-y-6 font-mono text-slate-200">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-100">
            Futures Settlement Engine & Delivery Clearing
          </h2>
          <p className="text-xs text-slate-400">
            Cash settlement final mark processing, physical delivery notices, and warehouse receipt matching.
          </p>
        </div>

        <button className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-bold transition-colors">
          Run End-of-Day Settlement Clearing
        </button>
      </div>

      {/* Settlement Events Log */}
      <div className="bg-[#111622] border border-slate-800 rounded overflow-hidden">
        <div className="px-4 py-3 bg-[#161c28] border-b border-slate-800">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Settlement Clearing Event Ledger
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="bg-[#0b0e14] text-slate-400 border-b border-slate-800 uppercase text-[10px]">
                <th className="p-2.5">Event ID</th>
                <th className="p-2.5">Contract</th>
                <th className="p-2.5">Settlement Type</th>
                <th className="p-2.5">Settlement Date</th>
                <th className="p-2.5 text-right">Final Price</th>
                <th className="p-2.5 text-right">Gross Cash Flow</th>
                <th className="p-2.5">Notice Ref</th>
                <th className="p-2.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {events.map((ev) => (
                <tr key={ev.event_id} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-bold text-slate-300">{ev.event_id}</td>
                  <td className="p-2.5 font-bold text-blue-400">{ev.contract_code}</td>
                  <td className="p-2.5 text-slate-300">{ev.settlement_type}</td>
                  <td className="p-2.5 text-slate-300">{ev.settlement_date}</td>
                  <td className="p-2.5 text-right font-bold text-emerald-400">${ev.final_settlement_price}</td>
                  <td className="p-2.5 text-right text-slate-100">${ev.gross_cash_flow.toLocaleString()}</td>
                  <td className="p-2.5 text-slate-400">{ev.delivery_notice_id || 'N/A (Cash)'}</td>
                  <td className="p-2.5">
                    <span className="px-2 py-0.5 text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 rounded font-bold">
                      {ev.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Physical Delivery Protocol Guide */}
      <div className="bg-[#090d14] border border-slate-800 rounded p-4 text-xs space-y-2">
        <div className="text-slate-400 font-bold uppercase text-[10px]">
          PHYSICAL DELIVERY PROTOCOL & LOCATION SPECS
        </div>
        <p className="text-slate-300">
          Energy & Metals delivery contracts (e.g., RQCL - Crude Oil) require delivery at approved Cushing, Oklahoma pipelines or designated warehouse facilities. Intent to deliver notices must be submitted prior to First Notice Date (FND).
        </p>
      </div>
    </div>
  );
};
