/**
 * RHINOQUANT - RISK LABORATORY & STRESS TESTING
 * Interactive stress testing laboratory with sliders for price shock,
 * volatility shift, basis shock, and margin multiplier. Computes base
 * vs shocked P&L, notional delta, margin delta, and liquidity impact scores.
 */

import React, { useState } from 'react';
import { quantStore } from '../../engine/stateStore';
import { RiskScenario } from '../../types/futures';
import { Sliders, AlertTriangle, ShieldCheck, Activity } from 'lucide-react';

export const RiskLaboratoryScreen: React.FC = () => {
  const [scenario, setScenario] = useState<RiskScenario>({
    scenario_id: 'scen_user_stress',
    scenario_name: 'Custom Interactive Shock Scenario',
    price_shock_pct: -5,
    volatility_shift_pct: 20,
    basis_shock_pct: 1,
    margin_rate_multiplier: 1.25,
    fx_shock_pct: 0,
  });

  const basePositions = quantStore.getPositions();
  const baseMargin = quantStore.getMarginAccount();

  const baseNotional = basePositions.reduce((a, p) => a + p.notional_value, 0);
  const basePnL = basePositions.reduce((a, p) => a + p.unrealized_pnl, 0);

  // Shocked Calculations
  const priceMultiplier = 1 + scenario.price_shock_pct / 100;
  const shockedPnLDelta = basePositions.reduce((acc, p) => {
    const shockPriceChange = p.current_price * (scenario.price_shock_pct / 100);
    const pnlShift = shockPriceChange * p.contract_multiplier * p.quantity * (p.side === 'LONG' ? 1 : -1);
    return acc + pnlShift;
  }, 0);

  const shockedMarginReq = baseMargin.initial_margin_req * scenario.margin_rate_multiplier;
  const shockedEquity = baseMargin.current_equity + shockedPnLDelta;
  const shockedLiquidity = shockedEquity - shockedMarginReq;
  const shockedUtilPct = Math.round((shockedMarginReq / (shockedEquity || 1)) * 100);

  return (
    <div className="p-6 space-y-6 font-mono text-slate-200">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-100">
            Institutional Risk & Stress Testing Laboratory
          </h2>
          <p className="text-xs text-slate-400">
            Simulate extreme market regimes, price shocks, volatility expansion, and margin rate surges.
          </p>
        </div>

        <span className="px-2 py-1 text-xs bg-rose-950 text-rose-300 border border-rose-800 rounded font-bold">
          RISK ENGINE ACTIVE
        </span>
      </div>

      {/* Interactive Controls & Sliders */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 bg-[#111622] border border-slate-800 p-5 rounded text-xs">
        <div>
          <div className="flex justify-between mb-1 font-bold">
            <span className="text-slate-400">Underlying Price Shock:</span>
            <span className={scenario.price_shock_pct < 0 ? 'text-rose-400' : 'text-emerald-400'}>
              {scenario.price_shock_pct > 0 ? '+' : ''}{scenario.price_shock_pct}%
            </span>
          </div>
          <input
            type="range"
            min="-20"
            max="20"
            step="1"
            value={scenario.price_shock_pct}
            onChange={(e) => setScenario({ ...scenario, price_shock_pct: parseFloat(e.target.value) })}
            className="w-full accent-blue-500 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex justify-between mb-1 font-bold">
            <span className="text-slate-400">Volatility Shift:</span>
            <span className="text-amber-400">+{scenario.volatility_shift_pct}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            step="5"
            value={scenario.volatility_shift_pct}
            onChange={(e) => setScenario({ ...scenario, volatility_shift_pct: parseFloat(e.target.value) })}
            className="w-full accent-amber-500 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex justify-between mb-1 font-bold">
            <span className="text-slate-400">Basis Shock:</span>
            <span className="text-blue-400">{(scenario.basis_shock_pct || 0) > 0 ? '+' : ''}{scenario.basis_shock_pct || 0}%</span>
          </div>
          <input
            type="range"
            min="-5"
            max="5"
            step="0.5"
            value={scenario.basis_shock_pct || 0}
            onChange={(e) => setScenario({ ...scenario, basis_shock_pct: parseFloat(e.target.value) })}
            className="w-full accent-blue-500 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex justify-between mb-1 font-bold">
            <span className="text-slate-400">Margin Multiplier:</span>
            <span className="text-purple-400">{scenario.margin_rate_multiplier}x</span>
          </div>
          <input
            type="range"
            min="1.0"
            max="3.0"
            step="0.25"
            value={scenario.margin_rate_multiplier}
            onChange={(e) => setScenario({ ...scenario, margin_rate_multiplier: parseFloat(e.target.value) })}
            className="w-full accent-purple-500 cursor-pointer"
          />
        </div>
      </div>

      {/* Comparison Table: Base Case vs Shocked Scenario */}
      <div className="bg-[#111622] border border-slate-800 rounded overflow-hidden">
        <div className="px-4 py-3 bg-[#161c28] border-b border-slate-800">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Stress Test Impact Comparison (Base vs Shocked)
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="bg-[#0b0e14] text-slate-400 border-b border-slate-800 uppercase text-[10px]">
                <th className="p-3">Risk Metric</th>
                <th className="p-3 text-right">Base Portfolio Case</th>
                <th className="p-3 text-right">Shocked Scenario</th>
                <th className="p-3 text-right">Net Impact / Delta</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              <tr className="hover:bg-slate-800/40">
                <td className="p-3 font-bold text-slate-200">Gross Notional Exposure</td>
                <td className="p-3 text-right text-slate-300">${baseNotional.toLocaleString()}</td>
                <td className="p-3 text-right text-blue-400 font-bold">${(baseNotional * priceMultiplier).toLocaleString()}</td>
                <td className="p-3 text-right text-slate-400">${(baseNotional * (priceMultiplier - 1)).toLocaleString()}</td>
              </tr>

              <tr className="hover:bg-slate-800/40">
                <td className="p-3 font-bold text-slate-200">Unrealized Portfolio P&L</td>
                <td className="p-3 text-right text-emerald-400 font-bold">${basePnL.toLocaleString()}</td>
                <td className={`p-3 text-right font-bold ${basePnL + shockedPnLDelta >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  ${(basePnL + shockedPnLDelta).toLocaleString()}
                </td>
                <td className={`p-3 text-right font-bold ${shockedPnLDelta >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {shockedPnLDelta >= 0 ? '+' : ''}${shockedPnLDelta.toLocaleString()}
                </td>
              </tr>

              <tr className="hover:bg-slate-800/40">
                <td className="p-3 font-bold text-slate-200">Initial Margin Requirement</td>
                <td className="p-3 text-right text-slate-300">${baseMargin.initial_margin_req.toLocaleString()}</td>
                <td className="p-3 text-right text-purple-400 font-bold">${shockedMarginReq.toLocaleString()}</td>
                <td className="p-3 text-right text-rose-300">+${(shockedMarginReq - baseMargin.initial_margin_req).toLocaleString()}</td>
              </tr>

              <tr className="hover:bg-slate-800/40">
                <td className="p-3 font-bold text-slate-200">Portfolio Equity</td>
                <td className="p-3 text-right text-emerald-400 font-bold">${baseMargin.current_equity.toLocaleString()}</td>
                <td className="p-3 text-right font-bold text-slate-100">${shockedEquity.toLocaleString()}</td>
                <td className={`p-3 text-right font-bold ${shockedPnLDelta >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {shockedPnLDelta >= 0 ? '+' : ''}${shockedPnLDelta.toLocaleString()}
                </td>
              </tr>

              <tr className="hover:bg-slate-800/40">
                <td className="p-3 font-bold text-slate-200">Margin Utilization %</td>
                <td className="p-3 text-right text-slate-300">{baseMargin.margin_utilization_pct}%</td>
                <td className={`p-3 text-right font-bold ${shockedUtilPct > 80 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {shockedUtilPct}%
                </td>
                <td className="p-3 text-right text-slate-400">+{shockedUtilPct - baseMargin.margin_utilization_pct}%</td>
              </tr>

              <tr className="hover:bg-slate-800/40">
                <td className="p-3 font-bold text-slate-200">Excess Liquidity Buffer</td>
                <td className="p-3 text-right text-blue-400 font-bold">${baseMargin.excess_liquidity.toLocaleString()}</td>
                <td className={`p-3 text-right font-bold ${shockedLiquidity >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  ${shockedLiquidity.toLocaleString()}
                </td>
                <td className="p-3 text-right text-rose-400">
                  -${(baseMargin.excess_liquidity - shockedLiquidity).toLocaleString()}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
