/**
 * RHINOQUANT - CONTRACT CHAIN SCREEN
 * Displays option/futures contract chains across listed contract months
 * (F, G, H, J, K, M, N, Q, U, V, X, Z) with bid/ask, last, change,
 * volume, open interest, basis, implied carry, and synthetic data badges.
 */

import React, { useState } from 'react';
import { quantStore } from '../../engine/stateStore';
import { ContractChainPoint, FuturesContractSpecification } from '../../types/futures';
import { Layers, Calendar, BarChart2, Info } from 'lucide-react';

export const ContractChainScreen: React.FC = () => {
  const specs = quantStore.getContractSpecs();
  const [selectedSymbol, setSelectedSymbol] = useState(specs[0].root_symbol);
  const spec = quantStore.getSpecBySymbol(selectedSymbol) || specs[0];

  const chain: ContractChainPoint[] = quantStore.generateContractChain(selectedSymbol);

  const MONTH_CODE_NAMES: Record<string, string> = {
    F: 'January', G: 'February', H: 'March', J: 'April',
    K: 'May', M: 'June', N: 'July', Q: 'August',
    U: 'September', V: 'October', X: 'November', Z: 'December',
  };

  return (
    <div className="p-6 space-y-6 font-mono text-slate-200">
      {/* Header & Symbol Selector */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-base font-bold uppercase tracking-wider text-slate-100">
              Contract Chain Matrix
            </h2>
            <span className="px-2 py-0.5 text-[10px] bg-blue-950 text-blue-300 border border-blue-800 rounded font-bold">
              ROOT: {spec.root_symbol}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            {spec.contract_name} — {spec.exchange_code} ({spec.currency})
          </p>
        </div>

        {/* Symbol Switcher */}
        <div className="flex items-center space-x-2">
          <label className="text-xs text-slate-400">Select Root Symbol:</label>
          <select
            value={selectedSymbol}
            onChange={(e) => setSelectedSymbol(e.target.value)}
            className="px-3 py-1.5 bg-[#111622] border border-slate-800 rounded text-xs font-bold text-blue-400 focus:outline-none focus:border-blue-500"
          >
            {specs.map((s) => (
              <option key={s.contract_id} value={s.root_symbol}>
                {s.root_symbol} - {s.contract_name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Contract Specification Highlights */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-3 bg-[#111622] border border-slate-800 p-3 rounded text-xs">
        <div>
          <span className="text-slate-500 uppercase text-[10px] block">Contract Multiplier</span>
          <span className="font-bold text-slate-200">×{spec.contract_multiplier}</span>
        </div>
        <div>
          <span className="text-slate-500 uppercase text-[10px] block">Tick Size</span>
          <span className="font-bold text-slate-200">{spec.tick_size}</span>
        </div>
        <div>
          <span className="text-slate-500 uppercase text-[10px] block">Tick Value</span>
          <span className="font-bold text-emerald-400">${spec.tick_value}</span>
        </div>
        <div>
          <span className="text-slate-500 uppercase text-[10px] block">Listed Months</span>
          <span className="font-bold text-blue-400">{spec.listed_months.join(', ')}</span>
        </div>
        <div>
          <span className="text-slate-500 uppercase text-[10px] block">Settlement Type</span>
          <span className="font-bold text-slate-200">{spec.settlement_type}</span>
        </div>
        <div>
          <span className="text-slate-500 uppercase text-[10px] block">Margin Method</span>
          <span className="font-bold text-slate-200">{spec.margin_method}</span>
        </div>
      </div>

      {/* Contract Chain Table */}
      <div className="bg-[#111622] border border-slate-800 rounded overflow-hidden">
        <div className="px-4 py-3 bg-[#161c28] border-b border-slate-800 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Layers className="w-4 h-4 text-blue-400" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Listed Contract Months ({chain.length} Active Points)
            </h3>
          </div>
          <span className="text-[11px] text-amber-400 font-bold bg-amber-950/60 px-2 py-0.5 border border-amber-800/80 rounded">
            SYNTHETIC MARKET DATA
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#0b0e14] text-slate-400 border-b border-slate-800 uppercase text-[10px]">
                <th className="p-2.5">Contract</th>
                <th className="p-2.5">Month (Code)</th>
                <th className="p-2.5">Expiry Date</th>
                <th className="p-2.5 text-right">Days to Expiry</th>
                <th className="p-2.5 text-right">Last Price</th>
                <th className="p-2.5 text-right">Bid</th>
                <th className="p-2.5 text-right">Ask</th>
                <th className="p-2.5 text-right">Settlement</th>
                <th className="p-2.5 text-right">Volume</th>
                <th className="p-2.5 text-right">Open Interest</th>
                <th className="p-2.5 text-right">Basis</th>
                <th className="p-2.5 text-right">Implied Carry %</th>
                <th className="p-2.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {chain.map((pt, idx) => (
                <tr key={pt.contract_code} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-2.5 font-bold text-blue-400">{pt.contract_code}</td>
                  <td className="p-2.5 text-slate-300">
                    {MONTH_CODE_NAMES[pt.month_code] || pt.month_code} ({pt.month_code})
                  </td>
                  <td className="p-2.5 text-slate-300">{pt.expiry_date}</td>
                  <td className="p-2.5 text-right text-slate-300">{pt.days_to_expiry}d</td>
                  <td className="p-2.5 text-right font-bold text-slate-100">
                    {pt.last_price.toLocaleString(undefined, { minimumFractionDigits: spec.tick_size < 0.01 ? 4 : 2 })}
                  </td>
                  <td className="p-2.5 text-right text-slate-400">{pt.bid}</td>
                  <td className="p-2.5 text-right text-slate-400">{pt.ask}</td>
                  <td className="p-2.5 text-right text-emerald-400">{pt.settlement}</td>
                  <td className="p-2.5 text-right text-slate-300">{pt.volume.toLocaleString()}</td>
                  <td className="p-2.5 text-right text-slate-300">{pt.open_interest.toLocaleString()}</td>
                  <td className={`p-2.5 text-right font-bold ${pt.basis >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {pt.basis >= 0 ? '+' : ''}{pt.basis.toFixed(2)}
                  </td>
                  <td className="p-2.5 text-right text-blue-300">{pt.implied_carry}%</td>
                  <td className="p-2.5">
                    <span className="px-1.5 py-0.5 text-[10px] bg-amber-950/70 border border-amber-800 text-amber-300 rounded font-bold">
                      SYNTHETIC
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
