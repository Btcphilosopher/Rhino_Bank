/**
 * RHINOQUANT - MARKET DATA ENGINE
 * Ingestion monitor, synthetic observations, order book depth,
 * quality scoring, and settlement snapshot isolation.
 */

import React, { useState } from 'react';
import { quantStore } from '../../engine/stateStore';
import { MarketDataObservation } from '../../types/futures';
import { Database, CheckCircle, AlertCircle, RefreshCw, BarChart2 } from 'lucide-react';

export const MarketDataScreen: React.FC = () => {
  const specs = quantStore.getContractSpecs();
  const [selectedSymbol, setSelectedSymbol] = useState(specs[0].root_symbol);

  const chain = quantStore.generateContractChain(selectedSymbol);
  const front = chain[0];

  return (
    <div className="p-6 space-y-6 font-mono text-slate-200">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-100">
            Market Data Engine & Ingestion Monitor
          </h2>
          <p className="text-xs text-slate-400">
            Real-time tick observations, order book depth, quality scores, and snapshot isolation.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <span className="px-2 py-1 text-xs bg-emerald-950 text-emerald-300 border border-emerald-800 rounded font-bold">
            FEED STATUS: SYNTHETIC OK
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Data Feed Table */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-[#111622] border border-slate-800 rounded overflow-hidden">
            <div className="px-4 py-3 bg-[#161c28] border-b border-slate-800 flex justify-between items-center">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Active Market Data Observations
              </h3>
              <span className="text-[11px] text-slate-400">Snapshot ID: snap_20260921_01</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-[#0b0e14] text-slate-400 border-b border-slate-800 uppercase text-[10px]">
                    <th className="p-2.5">Instrument</th>
                    <th className="p-2.5 text-right">Price</th>
                    <th className="p-2.5 text-right">Bid</th>
                    <th className="p-2.5 text-right">Ask</th>
                    <th className="p-2.5 text-right">Settlement</th>
                    <th className="p-2.5 text-right">Volume</th>
                    <th className="p-2.5 text-right">Quality</th>
                    <th className="p-2.5">Source</th>
                    <th className="p-2.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {specs.map((s) => {
                    const c = quantStore.generateContractChain(s.root_symbol)[0];
                    return (
                      <tr
                        key={s.contract_id}
                        onClick={() => setSelectedSymbol(s.root_symbol)}
                        className={`cursor-pointer transition-colors ${
                          selectedSymbol === s.root_symbol ? 'bg-blue-950/60 font-bold' : 'hover:bg-slate-800/40'
                        }`}
                      >
                        <td className="p-2.5 text-blue-400">{c.contract_code}</td>
                        <td className="p-2.5 text-right font-bold text-slate-100">{c.last_price}</td>
                        <td className="p-2.5 text-right text-slate-400">{c.bid}</td>
                        <td className="p-2.5 text-right text-slate-400">{c.ask}</td>
                        <td className="p-2.5 text-right text-emerald-400">{c.settlement}</td>
                        <td className="p-2.5 text-right text-slate-300">{c.volume.toLocaleString()}</td>
                        <td className="p-2.5 text-right text-emerald-400">99.8%</td>
                        <td className="p-2.5 text-slate-400">QUANT_ENGINE</td>
                        <td className="p-2.5">
                          <span className="px-1.5 py-0.5 text-[10px] bg-amber-950 text-amber-300 border border-amber-800 rounded">
                            SYNTHETIC
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Col: Synthetic Order Book Depth */}
        <div className="space-y-4">
          <div className="bg-[#111622] border border-slate-800 rounded p-4 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 border-b border-slate-800 pb-2">
              Order Book Depth ({front.contract_code})
            </h3>

            {/* Asks (Red) */}
            <div className="space-y-1 text-xs font-mono">
              <div className="text-[10px] text-slate-500 uppercase flex justify-between">
                <span>Ask Price</span>
                <span>Size</span>
              </div>
              {[3, 2, 1].map((step) => {
                const askPrice = (front.ask + step * 0.25).toFixed(2);
                const askQty = 50 + step * 40;
                return (
                  <div key={step} className="flex justify-between text-rose-400 bg-rose-950/20 px-2 py-1 rounded">
                    <span className="font-bold">{askPrice}</span>
                    <span>{askQty}</span>
                  </div>
                );
              })}
            </div>

            {/* Mid Price Spread */}
            <div className="p-2 bg-slate-900 border border-slate-800 text-center text-xs text-blue-400 font-bold">
              Spread: {(front.ask - front.bid).toFixed(2)} | Mid: {((front.ask + front.bid) / 2).toFixed(2)}
            </div>

            {/* Bids (Green) */}
            <div className="space-y-1 text-xs font-mono">
              {[1, 2, 3].map((step) => {
                const bidPrice = (front.bid - step * 0.25).toFixed(2);
                const bidQty = 60 + step * 35;
                return (
                  <div key={step} className="flex justify-between text-emerald-400 bg-emerald-950/20 px-2 py-1 rounded">
                    <span className="font-bold">{bidPrice}</span>
                    <span>{bidQty}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
