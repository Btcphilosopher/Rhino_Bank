/**
 * RHINOQUANT - FUTURES TERM STRUCTURE CURVES
 * Multi-view futures curve engine: Outright Price, Calendar Spread,
 * Open Interest, Volume, Roll Yield, Curve Interpolation & Curve Shocks.
 */

import React, { useState } from 'react';
import { quantStore } from '../../engine/stateStore';
import { FuturesCurve, FuturesCurvePoint } from '../../types/futures';
import { ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { TrendingUp, Sliders, Layers } from 'lucide-react';

export const CurvesTerminal: React.FC = () => {
  const specs = quantStore.getContractSpecs();
  const [selectedSymbol, setSelectedSymbol] = useState('RQES');
  const [curveView, setCurveView] = useState<'OUTRIGHT' | 'SPREAD' | 'OPEN_INTEREST' | 'VOLUME' | 'ROLL_YIELD'>('OUTRIGHT');
  const [shockMode, setShockMode] = useState<'NONE' | 'PARALLEL_UP' | 'STEEPEN' | 'FLATTEN'>('NONE');

  const rawCurve: FuturesCurve = quantStore.getFuturesCurve(selectedSymbol);

  // Apply shock scenarios if selected
  const curvePoints: FuturesCurvePoint[] = rawCurve.points.map((pt, idx) => {
    let shockPrice = pt.futures_price;
    if (shockMode === 'PARALLEL_UP') shockPrice *= 1.02; // +2%
    if (shockMode === 'STEEPEN') shockPrice *= 1 + idx * 0.008;
    if (shockMode === 'FLATTEN') shockPrice *= 1 - idx * 0.008;

    return {
      ...pt,
      futures_price: Number(shockPrice.toFixed(2)),
    };
  });

  return (
    <div className="p-6 space-y-6 font-mono text-slate-200">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-100">
            Futures Term Structure & Curve Analytics
          </h2>
          <p className="text-xs text-slate-400">
            Outright term structure, calendar spreads, open interest distribution & shock scenarios.
          </p>
        </div>

        {/* Symbol Switcher */}
        <div className="flex items-center space-x-2">
          <label className="text-xs text-slate-400">Curve Symbol:</label>
          <select
            value={selectedSymbol}
            onChange={(e) => setSelectedSymbol(e.target.value)}
            className="px-3 py-1.5 bg-[#111622] border border-slate-800 rounded text-xs font-bold text-blue-400 focus:outline-none"
          >
            {specs.map((s) => (
              <option key={s.contract_id} value={s.root_symbol}>
                {s.root_symbol} - {s.contract_name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Curve Views Selector & Shock Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#111622] border border-slate-800 p-3 rounded text-xs">
        {/* Views */}
        <div className="flex items-center space-x-1">
          <span className="text-slate-400 mr-2 uppercase text-[11px] font-bold">Curve View:</span>
          {(['OUTRIGHT', 'SPREAD', 'OPEN_INTEREST', 'VOLUME', 'ROLL_YIELD'] as const).map((view) => (
            <button
              key={view}
              onClick={() => setCurveView(view)}
              className={`px-2.5 py-1 rounded border transition-colors ${
                curveView === view
                  ? 'bg-blue-600 border-blue-500 text-white font-bold'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {view.replace('_', ' ')}
            </button>
          ))}
        </div>

        {/* Shock Scenario */}
        <div className="flex items-center space-x-1">
          <Sliders className="w-3.5 h-3.5 text-amber-400 mr-1" />
          <span className="text-slate-400 mr-1 uppercase text-[11px] font-bold">Curve Shock:</span>
          {(['NONE', 'PARALLEL_UP', 'STEEPEN', 'FLATTEN'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setShockMode(s)}
              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                shockMode === s ? 'bg-amber-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-slate-200'
              }`}
            >
              {s.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Main Curve Chart Panel */}
      <div className="bg-[#111622] border border-slate-800 rounded p-5 space-y-4">
        <div className="flex justify-between items-center border-b border-slate-800 pb-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            {curveView} CURVE — {selectedSymbol} ({rawCurve.interpolation_method})
          </h3>
          <span className="px-1.5 py-0.5 text-[10px] bg-amber-950 text-amber-300 border border-amber-800 rounded">
            SYNTHETIC DATA
          </span>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            {curveView === 'OPEN_INTEREST' || curveView === 'VOLUME' ? (
              <BarChart data={curvePoints}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f293d" />
                <XAxis dataKey="contract_code" stroke="#64748b" tick={{ fontSize: 10 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: '#090d14', borderColor: '#334155', fontSize: '11px' }} />
                <Bar
                  dataKey={curveView === 'OPEN_INTEREST' ? 'open_interest' : 'volume'}
                  fill="#3b82f6"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            ) : (
              <LineChart data={curvePoints}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f293d" />
                <XAxis dataKey="contract_code" stroke="#64748b" tick={{ fontSize: 10 }} />
                <YAxis domain={['auto', 'auto']} stroke="#64748b" tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: '#090d14', borderColor: '#334155', fontSize: '11px' }} />
                <Line
                  type="monotone"
                  dataKey={
                    curveView === 'OUTRIGHT'
                      ? 'futures_price'
                      : curveView === 'SPREAD'
                      ? 'spread_to_front'
                      : 'implied_roll_yield'
                  }
                  stroke={curveView === 'SPREAD' ? '#10b981' : '#3b82f6'}
                  strokeWidth={2.5}
                  dot={{ r: 5 }}
                />
              </LineChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* Curve Data Points Table */}
      <div className="bg-[#111622] border border-slate-800 rounded overflow-hidden">
        <div className="px-4 py-3 bg-[#161c28] border-b border-slate-800">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Term Structure Curve Data Matrix ({selectedSymbol})
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#0b0e14] text-slate-400 border-b border-slate-800 uppercase text-[10px]">
                <th className="p-2.5">Contract</th>
                <th className="p-2.5">Expiry Date</th>
                <th className="p-2.5 text-right">Days to Expiry</th>
                <th className="p-2.5 text-right">Futures Price</th>
                <th className="p-2.5 text-right">Spread to Front</th>
                <th className="p-2.5 text-right">Open Interest</th>
                <th className="p-2.5 text-right">Volume</th>
                <th className="p-2.5 text-right">Implied Roll Yield %</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {curvePoints.map((pt) => (
                <tr key={pt.contract_code} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-2.5 font-bold text-blue-400">{pt.contract_code}</td>
                  <td className="p-2.5 text-slate-300">{pt.expiry_date}</td>
                  <td className="p-2.5 text-right text-slate-400">{pt.days_to_expiry}d</td>
                  <td className="p-2.5 text-right font-bold text-slate-100">{pt.futures_price}</td>
                  <td
                    className={`p-2.5 text-right font-bold ${
                      pt.spread_to_front >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {pt.spread_to_front >= 0 ? '+' : ''}{pt.spread_to_front}
                  </td>
                  <td className="p-2.5 text-right text-slate-300">{pt.open_interest.toLocaleString()}</td>
                  <td className="p-2.5 text-right text-slate-300">{pt.volume.toLocaleString()}</td>
                  <td className="p-2.5 text-right text-blue-300">{pt.implied_roll_yield}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
