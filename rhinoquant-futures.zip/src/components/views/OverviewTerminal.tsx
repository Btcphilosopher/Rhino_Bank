/**
 * RHINOQUANT - OVERVIEW TERMINAL (Dashboard)
 * High-density institutional summary terminal displaying active contracts, open positions,
 * notional exposure, margin monitor, term structure curve preview, and system health.
 */

import React, { useState, useEffect } from 'react';
import { quantStore } from '../../engine/stateStore';
import { FuturesContractSpecification, FuturesPosition, MarginAccount, ContractChainPoint } from '../../types/futures';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Activity, AlertTriangle, CheckCircle, Clock, ShieldCheck, DollarSign, BarChart2, Layers } from 'lucide-react';

interface Props {
  onNavigate: (tab: any) => void;
}

export const OverviewTerminal: React.FC<Props> = ({ onNavigate }) => {
  const [specs, setSpecs] = useState<FuturesContractSpecification[]>(quantStore.getContractSpecs());
  const [positions, setPositions] = useState<FuturesPosition[]>(quantStore.getPositions());
  const [marginAcct, setMarginAcct] = useState<MarginAccount>(quantStore.getMarginAccount());
  const [chain, setChain] = useState<ContractChainPoint[]>(quantStore.generateContractChain('RQES'));

  useEffect(() => {
    const unsub = quantStore.subscribe(() => {
      setSpecs(quantStore.getContractSpecs());
      setPositions(quantStore.getPositions());
      setMarginAcct(quantStore.getMarginAccount());
      setChain(quantStore.generateContractChain('RQES'));
    });
    return unsub;
  }, []);

  const totalNotional = positions.reduce((acc, p) => acc + (p.position_status === 'OPEN' ? p.notional_value : 0), 0);
  const totalUnrealizedPnL = positions.reduce((acc, p) => acc + (p.position_status === 'OPEN' ? p.unrealized_pnl : 0), 0);

  return (
    <div className="p-6 space-y-6 font-mono text-slate-200">
      {/* Top Metric Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
        <div className="p-3 bg-[#111622] border border-slate-800 rounded">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">Active Contracts</div>
          <div className="text-base font-bold text-slate-100 mt-1">{specs.length}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">5 Asset Classes</div>
        </div>

        <div className="p-3 bg-[#111622] border border-slate-800 rounded">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">Open Positions</div>
          <div className="text-base font-bold text-slate-100 mt-1">
            {positions.filter((p) => p.position_status === 'OPEN').length}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Institutional Portfolio</div>
        </div>

        <div className="p-3 bg-[#111622] border border-slate-800 rounded">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">Total Notional</div>
          <div className="text-base font-bold text-blue-400 mt-1">
            ${(totalNotional / 1e6).toFixed(2)}M
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Gross Market Value</div>
        </div>

        <div className="p-3 bg-[#111622] border border-slate-800 rounded">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">Daily Unrealized P&L</div>
          <div className={`text-base font-bold mt-1 ${totalUnrealizedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {totalUnrealizedPnL >= 0 ? '+' : ''}${totalUnrealizedPnL.toLocaleString()}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Mark-to-Market</div>
        </div>

        <div className="p-3 bg-[#111622] border border-slate-800 rounded">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">Margin Utilisation</div>
          <div className={`text-base font-bold mt-1 ${marginAcct.margin_utilization_pct > 80 ? 'text-amber-400' : 'text-emerald-400'}`}>
            {marginAcct.margin_utilization_pct}%
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Initial / Equity</div>
        </div>

        <div className="p-3 bg-[#111622] border border-slate-800 rounded">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">Expiring Contracts</div>
          <div className="text-base font-bold text-amber-300 mt-1">1</div>
          <div className="text-[10px] text-amber-500/80 mt-0.5">RQESZ26 (&lt;90 days)</div>
        </div>

        <div className="p-3 bg-[#111622] border border-slate-800 rounded">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">Curve Exceptions</div>
          <div className="text-base font-bold text-emerald-400 mt-1">0</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Monotone Spline Valid</div>
        </div>

        <div className="p-3 bg-[#111622] border border-slate-800 rounded">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">Reconciliation</div>
          <div className="text-base font-bold text-emerald-400 mt-1 flex items-center space-x-1">
            <CheckCircle className="w-4 h-4" />
            <span>MATCHED</span>
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">0 Exceptions</div>
        </div>
      </div>

      {/* Main Grid Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Market Watchlist & Term Structure */}
        <div className="lg:col-span-2 space-y-6">
          {/* Market Watchlist */}
          <div className="bg-[#111622] border border-slate-800 rounded overflow-hidden">
            <div className="px-4 py-3 bg-[#161c28] border-b border-slate-800 flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <BarChart2 className="w-4 h-4 text-blue-400" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                  Institutional Market Watchlist
                </h3>
              </div>
              <button
                onClick={() => onNavigate('CONTRACT_CHAIN')}
                className="text-[11px] text-blue-400 hover:underline"
              >
                View Full Chain →
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-[#0b0e14] text-slate-400 border-b border-slate-800 uppercase text-[10px]">
                    <th className="p-2.5">Symbol</th>
                    <th className="p-2.5">Contract Name</th>
                    <th className="p-2.5 text-right">Last</th>
                    <th className="p-2.5 text-right">Change</th>
                    <th className="p-2.5 text-right">Volume</th>
                    <th className="p-2.5 text-right">Open Int</th>
                    <th className="p-2.5">Expiry</th>
                    <th className="p-2.5">Data Tag</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {specs.slice(0, 7).map((s) => {
                    const c = quantStore.generateContractChain(s.root_symbol)[0];
                    return (
                      <tr key={s.contract_id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="p-2.5 font-bold text-blue-400">{c.contract_code}</td>
                        <td className="p-2.5 text-slate-300">{s.contract_name}</td>
                        <td className="p-2.5 text-right font-bold text-slate-100">
                          {c.last_price.toLocaleString(undefined, { minimumFractionDigits: s.tick_size < 0.01 ? 4 : 2 })}
                        </td>
                        <td className="p-2.5 text-right text-emerald-400 font-semibold">
                          +{c.change}
                        </td>
                        <td className="p-2.5 text-right text-slate-400">{c.volume.toLocaleString()}</td>
                        <td className="p-2.5 text-right text-slate-400">{c.open_interest.toLocaleString()}</td>
                        <td className="p-2.5 text-slate-300">{c.expiry_date}</td>
                        <td className="p-2.5">
                          <span className="px-1.5 py-0.5 text-[10px] bg-amber-950/70 border border-amber-800 text-amber-300 rounded font-bold">
                            SYNTHETIC
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Interactive Term Structure Preview */}
          <div className="bg-[#111622] border border-slate-800 rounded p-4">
            <div className="flex justify-between items-center mb-3">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                  Futures Term Structure Curve (RQES RhinoQuant Index)
                </h3>
                <p className="text-[11px] text-slate-400">
                  Outright Futures Settlement Price vs Maturity Date
                </p>
              </div>
              <button
                onClick={() => onNavigate('CURVES')}
                className="text-[11px] text-blue-400 hover:underline"
              >
                Inspect All Curves →
              </button>
            </div>

            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chain}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1f293d" />
                  <XAxis dataKey="contract_code" stroke="#64748b" tick={{ fontSize: 10 }} />
                  <YAxis domain={['auto', 'auto']} stroke="#64748b" tick={{ fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#090d14', borderColor: '#334155', fontSize: '11px' }}
                    formatter={(val: any) => [`$${val}`, 'Futures Price']}
                  />
                  <Line type="monotone" dataKey="last_price" stroke="#3b82f6" strokeWidth={2} dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Right Col: Margin Monitor & System Health */}
        <div className="space-y-6">
          {/* Margin Account Monitor */}
          <div className="bg-[#111622] border border-slate-800 rounded p-4 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Margin Account Monitor
              </h3>
              <span className="px-1.5 py-0.5 text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 rounded">
                HEALTHY
              </span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">INITIAL MARGIN</span>
                <span className="font-bold text-slate-100">${marginAcct.initial_margin_req.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">MAINTENANCE MARGIN</span>
                <span className="font-medium text-slate-300">${marginAcct.maintenance_margin_req.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">CURRENT EQUITY</span>
                <span className="font-bold text-emerald-400">${marginAcct.current_equity.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">EXCESS LIQUIDITY</span>
                <span className="font-bold text-blue-400">${marginAcct.excess_liquidity.toLocaleString()}</span>
              </div>
            </div>

            <button
              onClick={() => onNavigate('MARGIN')}
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-blue-300 text-xs font-bold rounded transition-colors"
            >
              Open Margin Simulator →
            </button>
          </div>

          {/* System Engine Operational Health */}
          <div className="bg-[#111622] border border-slate-800 rounded p-4 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 border-b border-slate-800 pb-2">
              Engine System Status
            </h3>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Market Data Ingestion</span>
                <span className="text-emerald-400 font-bold flex items-center space-x-1">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>SYNTHETIC OK</span>
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Valuation Engine</span>
                <span className="text-emerald-400 font-bold">ONLINE</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">SPAN Margin Simulator</span>
                <span className="text-emerald-400 font-bold">ONLINE</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Settlement & Expiry</span>
                <span className="text-emerald-400 font-bold">ACTIVE</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Reconciliation Matrix</span>
                <span className="text-emerald-400 font-bold">MATCHED</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
