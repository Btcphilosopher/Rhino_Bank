/**
 * RHINOQUANT - CONTRACT ROLL MODULE
 * Front month to deferred month roll strategy, roll spread calculation,
 * annualized roll yield, execution cost estimation, volume & OI migration.
 */

import React, { useState } from 'react';
import { quantStore } from '../../engine/stateStore';
import { RefreshCw, ArrowRightLeft, Layers } from 'lucide-react';

export const RollAnalysisScreen: React.FC = () => {
  const specs = quantStore.getContractSpecs();
  const [selectedSymbol, setSelectedSymbol] = useState('RQES');

  const chain = quantStore.generateContractChain(selectedSymbol);
  const front = chain[0] || { contract_code: 'RQESZ26', last_price: 5840.0, days_to_expiry: 85, volume: 154200, open_interest: 480000 };
  const deferred = chain[1] || { contract_code: 'RQESH27', last_price: 5885.0, days_to_expiry: 175, volume: 42100, open_interest: 185000 };

  const rollSpread = deferred.last_price - front.last_price;
  const daysDiff = deferred.days_to_expiry - front.days_to_expiry;
  const annualizedYield = ((rollSpread / front.last_price) * (365 / (daysDiff || 90)) * 100).toFixed(2);
  const spec = specs.find((s) => s.root_symbol === selectedSymbol) || specs[0];
  const rollCost = spec.tick_value * 2; // Assume 2 ticks slippage

  return (
    <div className="p-6 space-y-6 font-mono text-slate-200">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-100">
            Futures Contract Roll & Calendar Spread Engine
          </h2>
          <p className="text-xs text-slate-400">
            Analyze contract roll timing, roll yields, calendar spread pricing, and execution slippage.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <label className="text-xs text-slate-400">Select Contract:</label>
          <select
            value={selectedSymbol}
            onChange={(e) => setSelectedSymbol(e.target.value)}
            className="px-3 py-1.5 bg-[#111622] border border-slate-800 rounded text-xs font-bold text-blue-400 focus:outline-none"
          >
            {specs.map((s) => (
              <option key={s.contract_id} value={s.root_symbol}>
                {s.root_symbol} - {s.contract_name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Roll Pair Visualizer */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-[#111622] border border-slate-800 p-5 rounded">
        {/* Front Month */}
        <div className="p-4 bg-[#090d14] border border-slate-800 rounded space-y-2">
          <span className="text-[10px] text-slate-400 uppercase font-bold block">Front Month Contract</span>
          <div className="text-lg font-bold text-blue-400">{front.contract_code}</div>
          <div className="text-xs text-slate-200">Last Price: ${front.last_price}</div>
          <div className="text-xs text-slate-400">Days to Expiry: {front.days_to_expiry}d</div>
          <div className="text-xs text-slate-400">Open Interest: {front.open_interest.toLocaleString()}</div>
        </div>

        {/* Roll Action Center */}
        <div className="flex flex-col items-center justify-center p-4 bg-slate-900 border border-slate-800 rounded space-y-3">
          <ArrowRightLeft className="w-6 h-6 text-emerald-400 animate-pulse" />
          <div className="text-center">
            <div className="text-[10px] text-slate-400 uppercase font-bold">Roll Spread (Calendar)</div>
            <div className={`text-base font-bold ${rollSpread >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {rollSpread >= 0 ? '+' : ''}{rollSpread.toFixed(2)} pts
            </div>
            <div className="text-xs text-blue-300 font-bold mt-1">
              Annualized Roll Yield: {annualizedYield}%
            </div>
          </div>
          <button className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded transition-colors">
            Simulate Contract Roll
          </button>
        </div>

        {/* Deferred Month */}
        <div className="p-4 bg-[#090d14] border border-slate-800 rounded space-y-2">
          <span className="text-[10px] text-slate-400 uppercase font-bold block">Next Deferred Contract</span>
          <div className="text-lg font-bold text-blue-400">{deferred.contract_code}</div>
          <div className="text-xs text-slate-200">Last Price: ${deferred.last_price}</div>
          <div className="text-xs text-slate-400">Days to Expiry: {deferred.days_to_expiry}d</div>
          <div className="text-xs text-slate-400">Open Interest: {deferred.open_interest.toLocaleString()}</div>
        </div>
      </div>

      {/* Roll Economics Breakdown */}
      <div className="bg-[#111622] border border-slate-800 rounded p-4 space-y-3 text-xs">
        <h3 className="font-bold uppercase tracking-wider text-slate-200 border-b border-slate-800 pb-2">
          Roll Execution Cost & Slippage Matrix
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <span className="text-slate-400 block text-[10px]">Estimated Roll Slippage</span>
            <span className="font-bold text-slate-100">${rollCost.toFixed(2)} / contract</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px]">Exchange Roll Fee Discount</span>
            <span className="font-bold text-emerald-400">-50% Applied</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px]">Liquidity Migration Ratio</span>
            <span className="font-bold text-blue-400">72% Front / 28% Next</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px]">Optimal Roll Window</span>
            <span className="font-bold text-amber-300">T-8 to T-3 Days Before FND</span>
          </div>
        </div>
      </div>
    </div>
  );
};
