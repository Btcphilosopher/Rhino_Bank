/**
 * RHINOQUANT FUTURES - NAVIGATION TAB BAR
 * Complete institutional navigation supporting all 15 required sections.
 */

import React from 'react';

export type NavTab =
  | 'OVERVIEW'
  | 'CONTRACTS'
  | 'CONTRACT_CHAIN'
  | 'MARKET_DATA'
  | 'CURVES'
  | 'POSITIONS'
  | 'VALUATION'
  | 'MARGIN'
  | 'RISK'
  | 'ROLL_ANALYSIS'
  | 'SETTLEMENT'
  | 'EXPIRY'
  | 'RECONCILIATION'
  | 'REPORTS'
  | 'MODEL_GOVERNANCE';

interface Props {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

const TABS: { id: NavTab; label: string }[] = [
  { id: 'OVERVIEW', label: 'OVERVIEW' },
  { id: 'CONTRACTS', label: 'CONTRACTS' },
  { id: 'CONTRACT_CHAIN', label: 'CONTRACT CHAIN' },
  { id: 'MARKET_DATA', label: 'MARKET DATA' },
  { id: 'CURVES', label: 'CURVES' },
  { id: 'POSITIONS', label: 'POSITIONS' },
  { id: 'VALUATION', label: 'VALUATION' },
  { id: 'MARGIN', label: 'MARGIN' },
  { id: 'RISK', label: 'RISK' },
  { id: 'ROLL_ANALYSIS', label: 'ROLL ANALYSIS' },
  { id: 'SETTLEMENT', label: 'SETTLEMENT' },
  { id: 'EXPIRY', label: 'EXPIRY' },
  { id: 'RECONCILIATION', label: 'RECONCILIATION' },
  { id: 'REPORTS', label: 'REPORTS' },
  { id: 'MODEL_GOVERNANCE', label: 'MODEL GOVERNANCE' },
];

export const Navigation: React.FC<Props> = ({ activeTab, onTabChange }) => {
  return (
    <nav className="bg-[#0e121a] border-b border-slate-800 px-4 overflow-x-auto scrollbar-thin scrollbar-thumb-slate-800 select-none">
      <div className="flex items-center space-x-1 min-w-max">
        {TABS.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`px-3 py-2.5 text-[11px] font-mono font-bold tracking-wider transition-all duration-150 border-b-2 ${
                isActive
                  ? 'border-blue-500 text-blue-400 bg-slate-900/80'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
