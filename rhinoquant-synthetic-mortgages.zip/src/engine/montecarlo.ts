/**
 * RHINOQUANT Monte Carlo Engine
 * Stochastic interest rate paths (Vasicek mean-reversion), path-dependent cash flow simulation,
 * percentiles (P10/P50/P90), VaR, and OAS convergence.
 */

import { DeterministicPRNG } from './prng';
import { MortgagePool, PrepaymentModelParams, DefaultModelParams, CashFlowPeriod, MonteCarloSummary } from '../types';
import { simulatePoolCashFlows, calculateWalFromCashFlows } from './pools';

export interface VasicekParams {
  r0: number; // Initial interest rate e.g. 4.5%
  a: number; // Mean reversion speed e.g. 0.15
  b: number; // Long-term mean rate e.g. 3.8%
  sigma: number; // Volatility e.g. 0.012 (1.2%)
}

export function generateVasicekRatePath(
  params: VasicekParams,
  months: number = 360,
  prng: DeterministicPRNG
): number[] {
  const rates: number[] = [params.r0];
  const dt = 1 / 12;

  let currentRate = params.r0;

  for (let m = 1; m < months; m++) {
    const dW = prng.nextGaussian(0, Math.sqrt(dt));
    // dr_t = a * (b - r_t) * dt + sigma * dW_t
    const dr = params.a * (params.b - currentRate) * dt + params.sigma * dW * 100;
    currentRate = Math.max(0.5, currentRate + dr); // Floor at 0.5%
    rates.push(currentRate);
  }

  return rates;
}

export function runMonteCarloSimulation(
  pool: MortgagePool,
  prepayParams: PrepaymentModelParams,
  defaultParams: DefaultModelParams,
  pathCount: number = 100,
  seed: number = 42
): MonteCarloSummary {
  const prng = new DeterministicPRNG(seed);
  const vasicek: VasicekParams = {
    r0: pool.wac,
    a: 0.20,
    b: 3.5,
    sigma: 0.015,
  };

  const wals: number[] = [];
  const losses: number[] = [];
  const monthlyBalancesByPath: number[][] = [];
  const ratePaths: number[][] = [];
  const oasConvergence: { path: number; oas: number }[] = [];

  // Limit full detailed timeline storage for super high path counts to avoid memory bloat
  const samplePathsCount = Math.min(pathCount, 500);

  for (let i = 0; i < pathCount; i++) {
    const ratePath = generateVasicekRatePath(vasicek, 360, prng);
    ratePaths.push(ratePath);

    const cfs = simulatePoolCashFlows(pool, ratePath, prepayParams, defaultParams, 360);
    const wal = calculateWalFromCashFlows(cfs);
    const totalLoss = cfs.reduce((sum, c) => sum + c.lossAmount, 0);

    wals.push(wal);
    losses.push(totalLoss);

    if (i < samplePathsCount) {
      const balances = cfs.map((c) => c.closingBalance);
      monthlyBalancesByPath.push(balances);
    }

    // Measure OAS convergence every 10%
    if ((i + 1) % Math.max(1, Math.floor(pathCount / 10)) === 0 || i === pathCount - 1) {
      const avgLossSoFar = losses.reduce((a, b) => a + b, 0) / (i + 1);
      const estOas = 120 + (avgLossSoFar / pool.originalBalance) * 1000;
      oasConvergence.push({ path: i + 1, oas: Math.round(estOas) });
    }
  }

  // Calculate Mean WAL & Std WAL
  const meanWal = wals.reduce((a, b) => a + b, 0) / pathCount;
  const varianceWal = wals.reduce((sum, w) => sum + Math.pow(w - meanWal, 2), 0) / pathCount;
  const stdWal = Math.sqrt(varianceWal);

  // Sorted losses for Value at Risk (VaR)
  const sortedLosses = [...losses].sort((a, b) => a - b);
  const var95Idx = Math.floor(pathCount * 0.95);
  const var99Idx = Math.floor(pathCount * 0.99);
  const var95 = sortedLosses[var95Idx] || sortedLosses[sortedLosses.length - 1];
  const var99 = sortedLosses[var99Idx] || sortedLosses[sortedLosses.length - 1];
  const meanLoss = losses.reduce((a, b) => a + b, 0) / pathCount;

  // Calculate P10, P50, P90 Balances over time (360 months)
  const p10Balance: number[] = [];
  const p50Balance: number[] = [];
  const p90Balance: number[] = [];

  const effectiveSampleCount = monthlyBalancesByPath.length;
  for (let m = 0; m < 360; m++) {
    const monthBalances: number[] = [];
    for (let k = 0; k < effectiveSampleCount; k++) {
      if (monthlyBalancesByPath[k] && monthlyBalancesByPath[k][m] !== undefined) {
        monthBalances.push(monthlyBalancesByPath[k][m]);
      }
    }

    if (monthBalances.length > 0) {
      monthBalances.sort((a, b) => a - b);
      const p10Idx = Math.floor(monthBalances.length * 0.1);
      const p50Idx = Math.floor(monthBalances.length * 0.5);
      const p90Idx = Math.floor(monthBalances.length * 0.9);

      p10Balance.push(monthBalances[p10Idx]);
      p50Balance.push(monthBalances[p50Idx]);
      p90Balance.push(monthBalances[p90Idx]);
    } else {
      p10Balance.push(0);
      p50Balance.push(0);
      p90Balance.push(0);
    }
  }

  return {
    pathCount,
    meanWal,
    stdWal,
    var95,
    var99,
    expectedLossMean: meanLoss,
    percentiles: {
      p10Balance,
      p50Balance,
      p90Balance,
    },
    oasConvergence,
  };
}
