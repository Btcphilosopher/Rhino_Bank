/**
 * RHINOQUANT Interest-Only (IO) & Principal-Only (PO) Engine
 * Cash-flow stripping, independent pricing, and prepayment rate sensitivity dynamics.
 */

import { CashFlowPeriod } from '../types';

export interface IoPoStripResult {
  month: number;
  ioCashFlow: number;
  poCashFlow: number;
  totalCashFlow: number;
  remainingBalance: number;
}

export interface IoPoValuation {
  ioPrice: number; // Clean price
  poPrice: number; // Clean price
  combinedPrice: number;
  ioYield: number;
  poYield: number;
  ioDuration: number;
  poDuration: number;
  strips: IoPoStripResult[];
}

export function generateIoPoStrips(poolCashFlows: CashFlowPeriod[]): IoPoStripResult[] {
  return poolCashFlows.map((cf) => ({
    month: cf.month,
    ioCashFlow: cf.interest,
    poCashFlow: cf.scheduledPrincipal + cf.unscheduledPrincipal + cf.recoveryAmount,
    totalCashFlow: cf.totalCashFlow,
    remainingBalance: cf.closingBalance,
  }));
}

export function priceIoPoStrips(
  strips: IoPoStripResult[],
  discountRatePct: number
): IoPoValuation {
  let ioPv = 0;
  let poPv = 0;
  let ioDurSum = 0;
  let poDurSum = 0;

  const monthlyRate = discountRatePct / 100 / 12;

  strips.forEach((s) => {
    const df = Math.pow(1 + monthlyRate, s.month);
    const ioCfPv = s.ioCashFlow / df;
    const poCfPv = s.poCashFlow / df;

    ioPv += ioCfPv;
    poPv += poCfPv;

    ioDurSum += (s.month / 12) * ioCfPv;
    poDurSum += (s.month / 12) * poCfPv;
  });

  const originalNotional = strips[0] ? strips[0].remainingBalance + strips[0].poCashFlow : 100;
  const ioPrice = originalNotional > 0 ? (ioPv / originalNotional) * 100 : 0;
  const poPrice = originalNotional > 0 ? (poPv / originalNotional) * 100 : 0;

  return {
    ioPrice,
    poPrice,
    combinedPrice: ioPrice + poPrice,
    ioYield: discountRatePct,
    poYield: discountRatePct,
    ioDuration: ioPv > 0 ? ioDurSum / ioPv : 0,
    poDuration: poPv > 0 ? poDurSum / poPv : 0,
    strips,
  };
}
