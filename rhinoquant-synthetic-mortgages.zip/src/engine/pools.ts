/**
 * RHINOQUANT Mortgage Pool Engine
 * Stratification tables, portfolio weighted averages, 360-month cash flow aggregation.
 */

import {
  SyntheticMortgage,
  MortgagePool,
  StratificationRow,
  CashFlowPeriod,
  PrepaymentModelParams,
  DefaultModelParams,
  Region,
  PropertyType,
} from '../types';

import { calculatePrepaymentSmm } from './prepayment';
import { calculateDefaultMetrics } from './default';

export function calculatePoolMetrics(loans: SyntheticMortgage[]): Omit<MortgagePool, 'id' | 'name'> {
  if (loans.length === 0) {
    return {
      loanCount: 0,
      originalBalance: 0,
      currentBalance: 0,
      wac: 0,
      wal: 0,
      wam: 0,
      weightedLtv: 0,
      weightedCreditScore: 0,
      averageBalance: 0,
      originationYear: 2026,
      geographicDistribution: {} as Record<Region, number>,
      creditDistribution: {},
      propertyDistribution: {} as Record<PropertyType, number>,
    };
  }

  let totalBalance = 0;
  let weightedCouponSum = 0;
  let weightedLtvSum = 0;
  let weightedCreditSum = 0;
  let weightedTermSum = 0;

  const geoCount: Record<string, number> = {};
  const propCount: Record<string, number> = {};
  const creditBuckets: Record<string, number> = {
    'Prime (750+)': 0,
    'Good (700-749)': 0,
    'Near Prime (650-699)': 0,
    'Subprime (<650)': 0,
  };

  loans.forEach((loan) => {
    const bal = loan.loanAmount;
    totalBalance += bal;
    weightedCouponSum += loan.interestRate * bal;
    weightedLtvSum += loan.ltv * bal;
    weightedCreditSum += loan.creditScore * bal;
    weightedTermSum += loan.termMonths * bal;

    geoCount[loan.region] = (geoCount[loan.region] || 0) + bal;
    propCount[loan.propertyType] = (propCount[loan.propertyType] || 0) + bal;

    if (loan.creditScore >= 750) creditBuckets['Prime (750+)'] += bal;
    else if (loan.creditScore >= 700) creditBuckets['Good (700-749)'] += bal;
    else if (loan.creditScore >= 650) creditBuckets['Near Prime (650-699)'] += bal;
    else creditBuckets['Subprime (<650)'] += bal;
  });

  const wac = totalBalance > 0 ? weightedCouponSum / totalBalance : 0;
  const weightedLtv = totalBalance > 0 ? weightedLtvSum / totalBalance : 0;
  const weightedCreditScore = totalBalance > 0 ? weightedCreditSum / totalBalance : 0;
  const wam = totalBalance > 0 ? weightedTermSum / totalBalance : 0;

  // Convert distribution absolute balances to percentages
  const geoDist: Record<Region, number> = {} as any;
  Object.keys(geoCount).forEach((k) => {
    geoDist[k as Region] = totalBalance > 0 ? (geoCount[k] / totalBalance) * 100 : 0;
  });

  const propDist: Record<PropertyType, number> = {} as any;
  Object.keys(propCount).forEach((k) => {
    propDist[k as PropertyType] = totalBalance > 0 ? (propCount[k] / totalBalance) * 100 : 0;
  });

  const creditDist: Record<string, number> = {};
  Object.keys(creditBuckets).forEach((k) => {
    creditDist[k] = totalBalance > 0 ? (creditBuckets[k] / totalBalance) * 100 : 0;
  });

  return {
    loanCount: loans.length,
    originalBalance: totalBalance,
    currentBalance: totalBalance,
    wac,
    wal: wam / 12 / 2, // Initial rough WAL approximation
    wam,
    weightedLtv,
    weightedCreditScore,
    averageBalance: loans.length > 0 ? totalBalance / loans.length : 0,
    originationYear: 2026,
    geographicDistribution: geoDist,
    creditDistribution: creditDist,
    propertyDistribution: propDist,
  };
}

export function generateStratification(
  loans: SyntheticMortgage[],
  type: 'LTV' | 'CREDIT' | 'REGION' | 'COUPON' | 'ORIGINATION' | 'LOAN_AGE'
): StratificationRow[] {
  const buckets: Record<string, SyntheticMortgage[]> = {};

  const totalPoolBalance = loans.reduce((sum, l) => sum + l.loanAmount, 0);

  loans.forEach((loan) => {
    let key = 'Other';
    if (type === 'LTV') {
      if (loan.ltv < 50) key = '<50%';
      else if (loan.ltv < 60) key = '50–60%';
      else if (loan.ltv < 70) key = '60–70%';
      else if (loan.ltv < 80) key = '70–80%';
      else if (loan.ltv < 90) key = '80–90%';
      else key = '90%+';
    } else if (type === 'CREDIT') {
      if (loan.creditScore >= 750) key = '750+ (Prime)';
      else if (loan.creditScore >= 700) key = '700–749 (Good)';
      else if (loan.creditScore >= 650) key = '650–699 (Near Prime)';
      else key = '<650 (Subprime)';
    } else if (type === 'REGION') {
      key = loan.region.replace('_', ' ');
    } else if (type === 'COUPON') {
      if (loan.interestRate < 3.5) key = '<3.5%';
      else if (loan.interestRate < 4.5) key = '3.5–4.5%';
      else if (loan.interestRate < 5.5) key = '4.5–5.5%';
      else if (loan.interestRate < 6.5) key = '5.5–6.5%';
      else key = '>6.5%';
    } else if (type === 'ORIGINATION') {
      key = loan.originationDate.slice(0, 4) || '2026';
    } else if (type === 'LOAN_AGE') {
      const ageMonths = 12; // Example baseline loan age
      if (ageMonths < 12) key = '<12 Months';
      else if (ageMonths <= 36) key = '12–36 Months';
      else if (ageMonths <= 60) key = '36–60 Months';
      else key = '>60 Months';
    }

    if (!buckets[key]) buckets[key] = [];
    buckets[key].push(loan);
  });

  return Object.entries(buckets).map(([category, group]) => {
    const bal = group.reduce((sum, l) => sum + l.loanAmount, 0);
    const wacSum = group.reduce((sum, l) => sum + l.interestRate * l.loanAmount, 0);
    const ltvSum = group.reduce((sum, l) => sum + l.ltv * l.loanAmount, 0);
    const creditSum = group.reduce((sum, l) => sum + l.creditScore * l.loanAmount, 0);

    return {
      category,
      loanCount: group.length,
      balance: bal,
      balancePercentage: totalPoolBalance > 0 ? (bal / totalPoolBalance) * 100 : 0,
      wac: bal > 0 ? wacSum / bal : 0,
      weightedLtv: bal > 0 ? ltvSum / bal : 0,
      weightedCreditScore: bal > 0 ? creditSum / bal : 0,
    };
  });
}

/**
 * Simulates aggregate monthly cash flows for a pool over 360 periods
 */
export function simulatePoolCashFlows(
  pool: MortgagePool,
  marketRatePath: number[],
  prepayParams: PrepaymentModelParams,
  defaultParams: DefaultModelParams,
  maxMonths: number = 360
): CashFlowPeriod[] {
  const periods: CashFlowPeriod[] = [];
  let balance = pool.originalBalance;
  let cumulativePrepaidRatio = 0;

  for (let m = 1; m <= maxMonths && balance > 1.0; m++) {
    const openingBalance = balance;
    const currentMarketRate = marketRatePath[m - 1] ?? marketRatePath[marketRatePath.length - 1] ?? 4.0;

    // Monthly interest coupon
    const monthlyCoupon = pool.wac / 100 / 12;
    const interest = openingBalance * monthlyCoupon;

    // Scheduled principal (25 year amortisation formula or WAM)
    const remainingMonths = Math.max(1, pool.wam - m + 1);
    const monthlyRate = pool.wac / 100 / 12;
    const pmt = (openingBalance * monthlyRate * Math.pow(1 + monthlyRate, remainingMonths)) / (Math.pow(1 + monthlyRate, remainingMonths) - 1);
    const scheduledPrincipal = Math.max(0, Math.min(openingBalance, pmt - interest));

    let balAfterScheduled = openingBalance - scheduledPrincipal;

    // Competing Prepayment SMM & Default MDR
    const prepayRes = calculatePrepaymentSmm(m, pool.wac, currentMarketRate, prepayParams, cumulativePrepaidRatio);
    const defaultRes = calculateDefaultMetrics({
      month: m,
      ltv: pool.weightedLtv,
      dti: 36,
      creditScore: pool.weightedCreditScore,
      loanRate: pool.wac,
      region: 'LONDON',
      propertyValue: pool.originalBalance / (pool.weightedLtv / 100),
      loanBalance: balAfterScheduled,
      params: defaultParams,
    });

    const smm = prepayRes.smm;
    const mdr = defaultRes.mdr;

    // Apply Default
    const defaultAmount = balAfterScheduled * mdr;
    const recoveryAmount = defaultAmount * (1 - defaultRes.lgdPct / 100);
    const lossAmount = defaultAmount - recoveryAmount;
    balAfterScheduled -= defaultAmount;

    // Apply Prepayment
    const unscheduledPrincipal = balAfterScheduled * smm;
    balAfterScheduled -= unscheduledPrincipal;

    cumulativePrepaidRatio += unscheduledPrincipal / pool.originalBalance;

    const closingBalance = Math.max(0, balAfterScheduled);
    const totalCashFlow = interest + scheduledPrincipal + unscheduledPrincipal + recoveryAmount;

    periods.push({
      month: m,
      openingBalance,
      scheduledPrincipal,
      unscheduledPrincipal,
      interest,
      defaultAmount,
      recoveryAmount,
      lossAmount,
      totalCashFlow,
      closingBalance,
      smm,
      mdr,
    });

    balance = closingBalance;
  }

  return periods;
}

export function calculateWalFromCashFlows(cashFlows: CashFlowPeriod[]): number {
  let weightedTimeSum = 0;
  let totalPrincipalReturned = 0;

  cashFlows.forEach((period) => {
    const principalReturned = period.scheduledPrincipal + period.unscheduledPrincipal;
    weightedTimeSum += (period.month / 12) * principalReturned;
    totalPrincipalReturned += principalReturned;
  });

  return totalPrincipalReturned > 0 ? weightedTimeSum / totalPrincipalReturned : 0;
}
