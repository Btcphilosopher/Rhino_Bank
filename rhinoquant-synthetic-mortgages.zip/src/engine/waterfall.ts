/**
 * RHINOQUANT Securitisation SPV Waterfall Engine
 * Explicit cash-flow allocation, loss absorption, and tranche state tracking.
 */

import { CashFlowPeriod, SecuritisationStructure, Tranche, TrancheCashFlow } from '../types';

export interface WaterfallExecutionResult {
  trancheCashFlows: Record<string, TrancheCashFlow[]>;
  finalTrancheBalances: Record<string, number>;
  totalLossesAbsorbed: Record<string, number>;
  totalInterestPaid: Record<string, number>;
  totalPrincipalPaid: Record<string, number>;
}

export function runSecuritisationWaterfall(
  structure: SecuritisationStructure,
  poolCashFlows: CashFlowPeriod[]
): WaterfallExecutionResult {
  // Sort tranches by rank (1 = Senior, 2 = Mezz, etc.)
  const tranches = [...structure.tranches].sort((a, b) => a.rank - b.rank);

  // Initialize tranche balances
  const currentBalances: Record<string, number> = {};
  const trancheFlows: Record<string, TrancheCashFlow[]> = {};
  const totalLosses: Record<string, number> = {};
  const totalInterest: Record<string, number> = {};
  const totalPrincipal: Record<string, number> = {};

  tranches.forEach((t) => {
    currentBalances[t.id] = t.notional;
    trancheFlows[t.id] = [];
    totalLosses[t.id] = 0;
    totalInterest[t.id] = 0;
    totalPrincipal[t.id] = 0;
  });

  poolCashFlows.forEach((period) => {
    let availableInterest = period.interest;
    let availablePrincipal = period.scheduledPrincipal + period.unscheduledPrincipal + period.recoveryAmount;
    let periodLoss = period.lossAmount;

    // 1. FIRST ABSORB LOSSES (Bottom-Up: Equity/Subordinated first, then higher tranches)
    const reverseTranches = [...tranches].sort((a, b) => b.rank - a.rank);
    for (const t of reverseTranches) {
      if (periodLoss <= 0) break;
      const bal = currentBalances[t.id];
      if (bal > 0) {
        const lossAbsorbed = Math.min(bal, periodLoss);
        currentBalances[t.id] -= lossAbsorbed;
        periodLoss -= lossAbsorbed;
        totalLosses[t.id] += lossAbsorbed;
      }
    }

    // 2. PAY INTEREST (Top-Down: Senior first, then Mezz, etc.)
    const periodTrancheInterest: Record<string, number> = {};
    const periodTrancheInterestShortfall: Record<string, number> = {};

    for (const t of tranches) {
      const bal = currentBalances[t.id];
      const monthlyCoupon = t.couponRate / 100 / 12;
      const dueInterest = bal * monthlyCoupon;

      const paidInterest = Math.min(availableInterest, dueInterest);
      availableInterest -= paidInterest;
      const shortfall = dueInterest - paidInterest;

      periodTrancheInterest[t.id] = paidInterest;
      periodTrancheInterestShortfall[t.id] = shortfall;
      totalInterest[t.id] += paidInterest;
    }

    // Any excess interest flows into principal waterfall or residual
    availablePrincipal += availableInterest;

    // 3. PAY PRINCIPAL (Sequential by Rank)
    const periodTranchePrincipal: Record<string, number> = {};

    for (const t of tranches) {
      const openingBal = currentBalances[t.id];
      periodTranchePrincipal[t.id] = 0;

      if (structure.waterfallType === 'SEQUENTIAL') {
        if (openingBal > 0 && availablePrincipal > 0) {
          const paidPrincipal = Math.min(openingBal, availablePrincipal);
          currentBalances[t.id] -= paidPrincipal;
          availablePrincipal -= paidPrincipal;
          periodTranchePrincipal[t.id] = paidPrincipal;
          totalPrincipal[t.id] += paidPrincipal;
        }
      } else {
        // Pro-Rata or Residual pass-through
        const totalOutstanding = Object.values(currentBalances).reduce((a, b) => a + b, 0);
        if (totalOutstanding > 0 && availablePrincipal > 0) {
          const share = openingBal / totalOutstanding;
          const paidPrincipal = Math.min(openingBal, availablePrincipal * share);
          currentBalances[t.id] -= paidPrincipal;
          periodTranchePrincipal[t.id] = paidPrincipal;
          totalPrincipal[t.id] += paidPrincipal;
        }
      }
    }

    // Record Period Output per Tranche
    tranches.forEach((t) => {
      trancheFlows[t.id].push({
        month: period.month,
        trancheId: t.id,
        openingBalance: currentBalances[t.id] + periodTranchePrincipal[t.id],
        interestPaid: periodTrancheInterest[t.id] || 0,
        interestShortfall: periodTrancheInterestShortfall[t.id] || 0,
        principalPaid: periodTranchePrincipal[t.id] || 0,
        lossAllocated: totalLosses[t.id],
        closingBalance: currentBalances[t.id],
      });
    });
  });

  return {
    trancheCashFlows: trancheFlows,
    finalTrancheBalances: currentBalances,
    totalLossesAbsorbed: totalLosses,
    totalInterestPaid: totalInterest,
    totalPrincipalPaid: totalPrincipal,
  };
}
