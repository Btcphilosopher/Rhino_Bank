/**
 * RHINOQUANT Synthetic Mortgage Generator
 * Synthesizes 10,000 to 1,000,000 loans with coherent borrower, property, and credit profiles.
 */

import { DeterministicPRNG } from './prng';
import { SyntheticMortgage, Region, PropertyType, AgeBand, EmploymentType, LoanType } from '../types';

const REGIONS: Region[] = [
  'LONDON',
  'SOUTH_EAST',
  'NORTH_WEST',
  'YORKSHIRE',
  'WEST_MIDLANDS',
  'EAST_ANGLIA',
  'SOUTH_WEST',
  'WALES',
  'SCOTLAND',
  'NORTHERN_IRELAND',
];

const PROPERTY_TYPES: PropertyType[] = [
  'DETACHED',
  'SEMI_DETACHED',
  'TERRACED',
  'FLAT_MAISONETTE',
  'BUNGALOW',
];

const AGE_BANDS: AgeBand[] = ['18-25', '26-35', '36-45', '46-55', '56-65', '65+'];
const EMPLOYMENT_TYPES: EmploymentType[] = [
  'PERMANENT_FULL_TIME',
  'SELF_EMPLOYED',
  'CONTRACTOR',
  'PART_TIME',
  'RETIRED',
];

const REGIONAL_BASE_VALUES: Record<Region, number> = {
  LONDON: 520000,
  SOUTH_EAST: 390000,
  SOUTH_WEST: 320000,
  EAST_ANGLIA: 310000,
  WEST_MIDLANDS: 250000,
  YORKSHIRE: 220000,
  NORTH_WEST: 215000,
  WALES: 210000,
  SCOTLAND: 200000,
  NORTHERN_IRELAND: 185000,
};

export function generateSyntheticLoans(
  count: number = 10000,
  seed: number = 42
): SyntheticMortgage[] {
  const prng = new DeterministicPRNG(seed);
  const loans: SyntheticMortgage[] = new Array(count);

  for (let i = 0; i < count; i++) {
    const regionIdx = prng.nextInt(0, REGIONS.length - 1);
    const region = REGIONS[regionIdx];

    const propTypeIdx = prng.nextInt(0, PROPERTY_TYPES.length - 1);
    const propertyType = PROPERTY_TYPES[propTypeIdx];

    const baseVal = REGIONAL_BASE_VALUES[region];
    const propertyValue = Math.round(Math.max(80000, prng.nextGaussian(baseVal, baseVal * 0.25)));

    // LTV normally distributed around 68%, bounded [20%, 95%]
    const ltv = Math.round(Math.min(95, Math.max(20, prng.nextGaussian(68, 12))));

    const loanAmount = Math.round((propertyValue * ltv) / 100);

    // Credit score around 735, bounded [550, 850]
    const creditScore = Math.round(Math.min(850, Math.max(550, prng.nextGaussian(735, 45))));

    // DTI around 34%, bounded [15%, 55%]
    const dti = Math.round(Math.min(55, Math.max(15, prng.nextGaussian(34, 7))));

    // Coupon around 4.65%, bounded [2.5%, 7.5%]
    const interestRate = Number((Math.min(7.5, Math.max(2.5, prng.nextGaussian(4.65, 0.6))).toFixed(2)));

    // Term: 25 or 30 years mostly
    const termYears = prng.next() > 0.3 ? 25 : 30;

    const loanType: LoanType = prng.next() > 0.85 ? 'INTEREST_ONLY' : 'AMORTISING';

    loans[i] = {
      id: `LN-UK-${2026 + (i % 5)}-${String(i + 1).padStart(7, '0')}`,
      borrowerId: `BW-${String(i + 1).padStart(7, '0')}`,
      propertyId: `PR-${String(i + 1).padStart(7, '0')}`,
      loanAmount,
      propertyValue,
      interestRate,
      termMonths: termYears * 12,
      loanType,
      paymentFrequency: 'MONTHLY',
      originationDate: '2026-01-01',
      maturityDate: `${2026 + termYears}-01-01`,
      ltv,
      dti,
      creditScore,
      region,
      propertyType,
      currentState: 'CURRENT',
    };
  }

  return loans;
}
