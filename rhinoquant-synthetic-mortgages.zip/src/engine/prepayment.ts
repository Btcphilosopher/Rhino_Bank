/**
 * RHINOQUANT Prepayment Engine
 * CPR/SMM conversions, PSA benchmark, Refinancing Incentive S-Curves, Burnout & Seasonality models.
 */

import { PrepaymentModelParams } from '../types';

export function cprToSmm(cprPct: number): number {
  const cpr = cprPct / 100;
  return 1 - Math.pow(1 - cpr, 1 / 12);
}

export function smmToCpr(smm: number): number {
  return (1 - Math.pow(1 - smm, 12)) * 100;
}

/**
 * Public Securities Association (PSA) standard prepayment benchmark CPR
 * @param month Current loan age in months (1-indexed)
 * @param psaMultiplier e.g. 100 for 100% PSA, 150 for 150% PSA
 */
export function getPsaCpr(month: number, psaMultiplier: number = 100): number {
  const baseCpr = month <= 30 ? (month / 30) * 6.0 : 6.0;
  return baseCpr * (psaMultiplier / 100);
}

/**
 * Calculates monthly SMM based on economic drivers (Refi incentive, burnout, seasonality, loan age)
 */
export function calculatePrepaymentSmm(
  month: number,
  loanRate: number,
  marketRate: number,
  params: PrepaymentModelParams,
  cumulativePrepaidRatio: number = 0,
  randomFactor: number = 1.0
): { cpr: number; smm: number } {
  const { type, baseCPR, refiIncentiveSensitivity, burnoutFactor, seasonalityStrength } = params;

  let cpr = baseCPR;

  if (type === 'BASELINE') {
    // Standard PSA-adjusted baseline
    cpr = getPsaCpr(month, baseCPR * (100 / 6.0));
  } else if (type === 'RATE_INCENTIVE' || type === 'BEHAVIOURAL' || type === 'STOCHASTIC') {
    // Incentive = Loan Rate - Market Current Rate (e.g. 5.5% - 3.5% = +2.0% incentive)
    const incentiveBps = (loanRate - marketRate) * 100;

    // Refi S-Curve (Logistic function)
    // When incentive is zero, refi is baseline. As incentive grows > 100bps, CPR accelerates up to 35%
    const refiBoost = 30 / (1 + Math.exp(-refiIncentiveSensitivity * (incentiveBps - 100) / 100));
    cpr = baseCPR + refiBoost;

    // Burnout Decay: as pool prepays, remaining borrowers are stickier
    if (type === 'BEHAVIOURAL' && burnoutFactor > 0) {
      const burnoutMultiplier = Math.exp(-burnoutFactor * cumulativePrepaidRatio * 5);
      cpr *= Math.max(0.2, burnoutMultiplier);
    }

    // Seasonality Factor (Peak in Month 5-8, lowest in Month 12-1)
    const monthInYear = ((month - 1) % 12) + 1;
    const seasonality = 1 + seasonalityStrength * Math.sin(((monthInYear - 3) * Math.PI) / 6);
    cpr *= Math.max(0.5, seasonality);

    if (type === 'STOCHASTIC') {
      cpr *= Math.max(0.1, randomFactor);
    }
  }

  // Cap CPR between 0% and 80%
  cpr = Math.min(80, Math.max(0, cpr));
  const smm = cprToSmm(cpr);

  return { cpr, smm };
}
