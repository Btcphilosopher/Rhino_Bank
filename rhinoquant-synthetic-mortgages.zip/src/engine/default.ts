/**
 * RHINOQUANT Default & Property Recovery Engine
 * Competing Risk Credit Model (PD, LGD, Loss Recovery, Competing SMM/MDR)
 */

import { DefaultModelParams, Region } from '../types';

export function cdrToMdr(cdrPct: number): number {
  const cdr = cdrPct / 100;
  return 1 - Math.pow(1 - cdr, 1 / 12);
}

export function mdrToCdr(mdr: number): number {
  return (1 - Math.pow(1 - mdr, 12)) * 100;
}

export interface DefaultStateInput {
  month: number;
  ltv: number; // e.g. 80
  dti: number; // e.g. 35
  creditScore: number; // e.g. 720
  loanRate: number; // %
  region: Region;
  propertyValue: number; // Original £
  loanBalance: number; // Current balance £
  params: DefaultModelParams;
}

export interface DefaultStateOutput {
  cdr: number;
  mdr: number;
  currentPropertyValue: number;
  recoveryValue: number;
  lgdPct: number; // Loss Given Default %
  expectedLoss: number; // £
}

export function calculateDefaultMetrics(input: DefaultStateInput): DefaultStateOutput {
  const {
    month,
    ltv,
    dti,
    creditScore,
    propertyValue,
    loanBalance,
    params,
  } = input;

  const {
    baseCDR,
    ltvSensitivity,
    dtiSensitivity,
    unemploymentShock,
    hpiChange,
    recoveryCostRate,
  } = params;

  // LTV Risk Multiplier (Non-linear acceleration above 75% LTV)
  const effectiveLtv = ltv * (1 - hpiChange / 100);
  const ltvMultiplier = effectiveLtv > 75 
    ? 1.0 + Math.pow((effectiveLtv - 75) / 10, 1.8) * ltvSensitivity 
    : Math.max(0.2, effectiveLtv / 75);

  // Credit Score Multiplier (FICO curve: 750+ = 0.3x, 620- = 3.5x)
  const creditMultiplier = Math.exp(-0.008 * (creditScore - 680));

  // DTI Multiplier
  const dtiMultiplier = dti > 40 ? 1.0 + ((dti - 40) / 10) * dtiSensitivity : 0.8;

  // Loan Seasoning Curve (Peak default risk between month 18 and 48)
  let seasoningFactor = 1.0;
  if (month <= 12) seasoningFactor = 0.3 + (month / 12) * 0.7;
  else if (month <= 48) seasoningFactor = 1.0 + 0.2 * Math.sin(((month - 12) / 36) * Math.PI);
  else seasoningFactor = Math.max(0.3, 1.2 - ((month - 48) / 300) * 0.9);

  // Unemployment Shock
  const macroFactor = 1.0 + (unemploymentShock / 5.0);

  // Calculated Annualised Conditional Default Rate (CDR)
  let cdr = baseCDR * ltvMultiplier * creditMultiplier * dtiMultiplier * seasoningFactor * macroFactor;
  cdr = Math.min(50, Math.max(0, cdr));

  const mdr = cdrToMdr(cdr);

  // Property Value updated for HPI shift
  const currentPropertyValue = Math.max(1000, propertyValue * (1 + hpiChange / 100));

  // Recovery Value = Current Property Value - Recovery/Foreclosure Costs
  const recoveryValue = Math.max(0, currentPropertyValue * (1 - recoveryCostRate));

  // Loss Given Default (LGD): portion of loan balance not recovered
  const loss = Math.max(0, loanBalance - recoveryValue);
  const lgdPct = loanBalance > 0 ? (loss / loanBalance) * 100 : 0;

  const expectedLoss = loanBalance * (mdr * 12) * (lgdPct / 100);

  return {
    cdr,
    mdr,
    currentPropertyValue,
    recoveryValue,
    lgdPct,
    expectedLoss,
  };
}
