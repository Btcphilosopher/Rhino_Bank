/**
 * RHINOQUANT Pricing, OAS & Risk Engine
 * Present Value, Yield to Maturity, OAS Solver, Duration, Convexity, DV01 & Sensitivities.
 */

import { CashFlowPeriod, RiskMetrics } from '../types';

export function calculatePresentValue(cashFlows: CashFlowPeriod[], annualDiscountRatePct: number): number {
  let pv = 0;
  const monthlyRate = annualDiscountRatePct / 100 / 12;

  cashFlows.forEach((cf) => {
    const df = Math.pow(1 + monthlyRate, cf.month);
    pv += cf.totalCashFlow / df;
  });

  return pv;
}

export function solveYieldToMaturity(cashFlows: CashFlowPeriod[], targetPrice: number): number {
  if (cashFlows.length === 0 || targetPrice <= 0) return 0;

  let low = 0.0;
  let high = 0.30; // 30% yield max
  let yieldEst = 0.05;

  for (let iter = 0; iter < 40; iter++) {
    yieldEst = (low + high) / 2;
    const pv = calculatePresentValue(cashFlows, yieldEst * 100);

    if (Math.abs(pv - targetPrice) < 0.01) {
      break;
    }

    if (pv > targetPrice) {
      low = yieldEst;
    } else {
      high = yieldEst;
    }
  }

  return yieldEst * 100;
}

/**
 * Solves Option-Adjusted Spread (OAS) in basis points across simulated interest rate paths
 */
export function solveOas(
  simulatedPathCashFlows: CashFlowPeriod[][],
  ratePaths: number[][],
  marketPrice: number
): { oasBps: number; expectedPv: number } {
  if (simulatedPathCashFlows.length === 0 || marketPrice <= 0) {
    return { oasBps: 0, expectedPv: marketPrice };
  }

  const pathCount = simulatedPathCashFlows.length;

  let lowSpread = -0.05; // -500 bps
  let highSpread = 0.15; // +1500 bps
  let midSpread = 0.02;

  for (let iter = 0; iter < 30; iter++) {
    midSpread = (lowSpread + highSpread) / 2;
    let sumPv = 0;

    for (let k = 0; k < pathCount; k++) {
      const cfs = simulatedPathCashFlows[k];
      const rates = ratePaths[k];
      let pathPv = 0;
      let cumDiscountFactor = 1.0;

      for (let t = 0; t < cfs.length; t++) {
        const periodRate = (rates[t] ?? 4.0) / 100 / 12 + midSpread / 12;
        cumDiscountFactor *= 1 + periodRate;
        pathPv += cfs[t].totalCashFlow / cumDiscountFactor;
      }

      sumPv += pathPv;
    }

    const avgPv = sumPv / pathCount;

    if (Math.abs(avgPv - marketPrice) < 1.0) {
      break;
    }

    if (avgPv > marketPrice) {
      lowSpread = midSpread;
    } else {
      highSpread = midSpread;
    }
  }

  return {
    oasBps: Math.round(midSpread * 10000),
    expectedPv: marketPrice,
  };
}

export function calculateRiskMetrics(
  cashFlows: CashFlowPeriod[],
  baseRatePct: number,
  parNotional: number = 100
): RiskMetrics {
  const pv0 = calculatePresentValue(cashFlows, baseRatePct);
  if (pv0 <= 0) {
    return {
      macaulayDuration: 0,
      modifiedDuration: 0,
      effectiveDuration: 0,
      convexity: 0,
      dv01: 0,
      vega: 0,
      oasDuration: 0,
      prepaymentSensitivity: 0,
      defaultSensitivity: 0,
      wal: 0,
      expectedLoss: 0,
    };
  }

  // Shift rates by +/- 50 bps (0.50%)
  const deltaR = 0.0050; // 50 bps
  const pvUp = calculatePresentValue(cashFlows, baseRatePct + 0.50);
  const pvDown = calculatePresentValue(cashFlows, Math.max(0.1, baseRatePct - 0.50));

  // Effective Duration = (PV_down - PV_up) / (2 * PV0 * deltaR)
  const effectiveDuration = (pvDown - pvUp) / (2 * pv0 * deltaR);

  // Convexity = (PV_down + PV_up - 2 * PV0) / (PV0 * deltaR^2)
  const convexity = (pvDown + pvUp - 2 * pv0) / (pv0 * Math.pow(deltaR, 2));

  // DV01 = PV0 * Effective Duration * 0.0001
  const dv01 = (pv0 * effectiveDuration * 0.0001);

  // Macaulay Duration
  let macDurSum = 0;
  const monthlyRate = baseRatePct / 100 / 12;
  cashFlows.forEach((cf) => {
    const pvCf = cf.totalCashFlow / Math.pow(1 + monthlyRate, cf.month);
    macDurSum += (cf.month / 12) * pvCf;
  });
  const macaulayDuration = macDurSum / pv0;
  const modifiedDuration = macaulayDuration / (1 + monthlyRate);

  // Weighted Average Life (WAL)
  let walSum = 0;
  let totalPrin = 0;
  cashFlows.forEach((cf) => {
    const prin = cf.scheduledPrincipal + cf.unscheduledPrincipal;
    walSum += (cf.month / 12) * prin;
    totalPrin += prin;
  });
  const wal = totalPrin > 0 ? walSum / totalPrin : 0;

  // Total Expected Loss
  const totalLoss = cashFlows.reduce((sum, cf) => sum + cf.lossAmount, 0);

  return {
    macaulayDuration,
    modifiedDuration,
    effectiveDuration,
    convexity,
    dv01,
    vega: effectiveDuration * 0.12, // Vega proxy
    oasDuration: effectiveDuration * 0.95,
    prepaymentSensitivity: (pvDown - pvUp) * 1.5,
    defaultSensitivity: totalLoss / pv0,
    wal,
    expectedLoss: totalLoss,
  };
}
