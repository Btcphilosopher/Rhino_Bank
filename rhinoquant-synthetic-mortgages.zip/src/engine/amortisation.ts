/**
 * RHINOQUANT Amortisation Engine
 * Precision cash-flow schedule generation for fixed, floating, tracker, and interest-only mortgages.
 */

import { AmortisationMonth, LoanType, LoanState } from '../types';

export interface AmortisationInput {
  loanAmount: number;
  annualRate: number; // e.g. 4.75 for 4.75%
  termMonths: number;
  loanType: LoanType;
  extraMonthlyPayment?: number;
  startDate?: string;
  monthlyPrepaymentSMM?: number; // Optional Single Monthly Mortality
  monthlyDefaultMDR?: number; // Optional Monthly Default Rate
  recoveryRate?: number; // e.g. 0.85
}

export interface AmortisationSummary {
  schedule: AmortisationMonth[];
  totalInterestPaid: number;
  totalPrincipalPaid: number;
  totalPrepaymentPaid: number;
  totalDefaultLoss: number;
  actualTermMonths: number;
}

export function calculateScheduledPayment(
  balance: number,
  annualRate: number,
  remainingMonths: number,
  loanType: LoanType
): number {
  if (remainingMonths <= 0 || balance <= 0) return 0;
  const monthlyRate = annualRate / 100 / 12;

  if (loanType === 'INTEREST_ONLY') {
    return balance * monthlyRate;
  }

  if (monthlyRate === 0) {
    return balance / remainingMonths;
  }

  const factor = Math.pow(1 + monthlyRate, remainingMonths);
  return (balance * monthlyRate * factor) / (factor - 1);
}

export function generateAmortisationSchedule(input: AmortisationInput): AmortisationSummary {
  const {
    loanAmount,
    annualRate,
    termMonths,
    loanType,
    extraMonthlyPayment = 0,
    startDate = '2026-01-01',
    monthlyPrepaymentSMM = 0,
    monthlyDefaultMDR = 0,
    recoveryRate = 0.85,
  } = input;

  const schedule: AmortisationMonth[] = [];
  let balance = loanAmount;
  let totalInterest = 0;
  let totalPrincipal = 0;
  let totalPrepayment = 0;
  let totalDefaultLoss = 0;

  const startYear = parseInt(startDate.slice(0, 4), 10) || 2026;
  const startMonthNum = parseInt(startDate.slice(5, 7), 10) || 1;

  for (let m = 1; m <= termMonths && balance > 0.01; m++) {
    const currentDate = new Date(startYear, startMonthNum - 1 + m - 1, 1);
    const dateStr = currentDate.toISOString().slice(0, 7);

    const monthlyRate = annualRate / 100 / 12;
    const openingBalance = balance;
    const interest = openingBalance * monthlyRate;

    // Scheduled payment for remaining duration
    const remainingMonths = termMonths - m + 1;
    let scheduledPayment = calculateScheduledPayment(openingBalance, annualRate, remainingMonths, loanType);

    let scheduledPrincipal = 0;
    if (loanType === 'INTEREST_ONLY') {
      scheduledPrincipal = m === termMonths ? openingBalance : 0;
    } else {
      scheduledPrincipal = Math.max(0, Math.min(openingBalance, scheduledPayment - interest));
    }

    let balAfterScheduled = openingBalance - scheduledPrincipal;

    // Apply Default MDR (Competing risk model)
    let defaultAmt = 0;
    let recoveryAmt = 0;
    if (monthlyDefaultMDR > 0 && balAfterScheduled > 0) {
      defaultAmt = balAfterScheduled * monthlyDefaultMDR;
      balAfterScheduled -= defaultAmt;
      recoveryAmt = defaultAmt * recoveryRate;
      totalDefaultLoss += defaultAmt * (1 - recoveryRate);
    }

    // Apply Prepayment SMM + Extra Payment
    let prepayAmt = 0;
    if (balAfterScheduled > 0) {
      const smmPrepay = balAfterScheduled * monthlyPrepaymentSMM;
      const extraPrepay = Math.min(balAfterScheduled - smmPrepay, extraMonthlyPayment);
      prepayAmt = Math.min(balAfterScheduled, smmPrepay + extraPrepay);
      balAfterScheduled -= prepayAmt;
    }

    const actualPrincipal = scheduledPrincipal + prepayAmt;
    const actualPayment = interest + actualPrincipal;
    const closingBalance = Math.max(0, balAfterScheduled);

    let state: LoanState = 'CURRENT';
    if (defaultAmt > 0 && closingBalance === 0) state = 'DEFAULT';
    else if (prepayAmt > 0 && closingBalance === 0) state = 'PREPAID';
    else if (m === termMonths || closingBalance === 0) state = 'MATURED';

    schedule.push({
      month: m,
      date: dateStr,
      openingBalance,
      interestPaid: interest,
      principalPaid: scheduledPrincipal,
      prepayment: prepayAmt,
      defaultAmount: defaultAmt,
      recoveryAmount: recoveryAmt,
      totalPayment: actualPayment,
      closingBalance,
      state,
    });

    totalInterest += interest;
    totalPrincipal += scheduledPrincipal;
    totalPrepayment += prepayAmt;
    balance = closingBalance;
  }

  return {
    schedule,
    totalInterestPaid: totalInterest,
    totalPrincipalPaid: totalPrincipal,
    totalPrepaymentPaid: totalPrepayment,
    totalDefaultLoss: totalDefaultLoss,
    actualTermMonths: schedule.length,
  };
}
