/**
 * RHINOQUANT Market Terminal & Hierarchy Overview
 * Core Architecture Hierarchy, Macro Yield Curve, Regional Property Index & Origination Pipeline.
 */

import React from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { ArrowRight, Layers, TrendingUp, Building, ArrowUpRight } from 'lucide-react';
import { NavTab } from './Header';

interface MarketOverviewProps {
  onNavigate: (tab: NavTab) => void;
}

export const MarketOverview: React.FC<MarketOverviewProps> = ({ onNavigate }) => {
  // Synthetic Gilt & Mortgage Yield Curve
  const yieldCurveData = [
    { tenor: '1Y', gilt: 3.85, mortgageFixed: 4.35, mortgageTracker: 4.10 },
    { tenor: '2Y', gilt: 3.70, mortgageFixed: 4.25, mortgageTracker: 4.05 },
    { tenor: '3Y', gilt: 3.60, mortgageFixed: 4.20, mortgageTracker: 4.00 },
    { tenor: '5Y', gilt: 3.50, mortgageFixed: 4.35, mortgageTracker: 4.10 },
    { tenor: '7Y', gilt: 3.55, mortgageFixed: 4.50, mortgageTracker: 4.25 },
    { tenor: '10Y', gilt: 3.65, mortgageFixed: 4.65, mortgageTracker: 4.45 },
    { tenor: '15Y', gilt: 3.80, mortgageFixed: 4.85, mortgageTracker: 4.65 },
    { tenor: '25Y', gilt: 3.95, mortgageFixed: 5.10, mortgageTracker: 4.90 },
    { tenor: '30Y', gilt: 4.05, mortgageFixed: 5.25, mortgageTracker: 5.05 },
  ];

  // Regional House Price Index Time Series
  const hpiData = [
    { year: '2021', London: 100, SouthEast: 100, NorthWest: 100, Scotland: 100 },
    { year: '2022', London: 104, SouthEast: 107, NorthWest: 109, Scotland: 106 },
    { year: '2023', London: 102, SouthEast: 105, NorthWest: 111, Scotland: 107 },
    { year: '2024', London: 105, SouthEast: 108, NorthWest: 115, Scotland: 110 },
    { year: '2025', London: 108, SouthEast: 112, NorthWest: 119, Scotland: 114 },
    { year: '2026', London: 111, SouthEast: 115, NorthWest: 123, Scotland: 117 },
  ];

  const coreHierarchy = [
    { step: '1. BORROWER', desc: 'Synthetic demographics, credit score, DTI, income', target: 'LOAN_CONSTRUCTOR' as NavTab },
    { step: '2. PROPERTY', desc: 'Synthetic property valuation, region, HPI, LTV', target: 'LOAN_CONSTRUCTOR' as NavTab },
    { step: '3. MORTGAGE', desc: 'Loan terms, coupon rate, amortisation type', target: 'LOAN_CONSTRUCTOR' as NavTab },
    { step: '4. CASH FLOWS', desc: '360-month principal, interest, extra payment schedule', target: 'LOAN_CONSTRUCTOR' as NavTab },
    { step: '5. PREPAYMENT / DEFAULT', desc: 'Competing risk CPR/SMM, CDR/MDR, property recovery', target: 'PREPAY_DEFAULT' as NavTab },
    { step: '6. MORTGAGE POOL', desc: 'Pool aggregation, WAC, WAL, WAM, stratifications', target: 'POOL_ENGINE' as NavTab },
    { step: '7. SECURITISATION', desc: 'SPV structure, sequential waterfall rules', target: 'CMO_LAB' as NavTab },
    { step: '8. TRANCHES', desc: 'Senior AAA to Equity rating labels, cash allocation', target: 'TRANCHE_IOPO' as NavTab },
    { step: '9. PRICING & OAS', desc: 'Option-Adjusted Spread, rate paths, discounting', target: 'RATE_PATHS' as NavTab },
    { step: '10. RISK & STRESS', desc: 'Effective Duration, Convexity, Extension/Contraction', target: 'RISK_EXTENSION' as NavTab },
  ];

  return (
    <div className="space-y-6">
      {/* Top Hero Banner */}
      <div className="bg-gradient-to-r from-[#0d131f] via-[#121927] to-[#0d131f] border border-slate-800 rounded-xl p-6 relative overflow-hidden">
        <div className="max-w-3xl space-y-3 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-950/80 border border-blue-700/50 text-blue-300 text-xs font-mono">
            <Layers className="w-3.5 h-3.5" />
            <span>INSTITUTIONAL QUANTITATIVE STRUCTURED CREDIT ENVIRONMENT</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Synthetic Mortgage Portfolio & Securitised Credit Engine
          </h2>
          <p className="text-slate-300 text-sm leading-relaxed">
            RHINOQUANT simulates the complete lifecycle of mortgage collateral: from synthetic borrower origination and competing-risk prepayment/default behaviour to SPV cash-flow waterfalls, Option-Adjusted Spread (OAS) pricing, and extension/contraction risk under macroeconomic stress.
          </p>
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => onNavigate('SIGNATURE_DEMOS')}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow transition-colors flex items-center gap-2"
            >
              <span>Launch Signature Demos (RQ-UK-MBS-2032-001)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('RISK_EXTENSION')}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors flex items-center gap-2"
            >
              <span>Explore Extension / Contraction Risk</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Core Architecture Hierarchy Flow */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-semibold text-white font-mono tracking-wide uppercase flex items-center gap-2">
            <Building className="w-4 h-4 text-blue-400" />
            1. Core Architecture Hierarchy
          </h3>
          <span className="text-xs text-slate-400 font-mono">10-STEP QUANTITATIVE PIPELINE</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
          {coreHierarchy.map((item, idx) => (
            <div
              key={idx}
              onClick={() => onNavigate(item.target)}
              className="bg-[#141b29] hover:bg-[#1a2336] border border-slate-800 hover:border-blue-500/50 rounded-lg p-3 cursor-pointer transition-all space-y-1.5 group"
            >
              <div className="text-xs font-mono font-bold text-blue-400 group-hover:text-blue-300 flex items-center justify-between">
                <span>{item.step}</span>
                <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-blue-400" />
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Market Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* UK Macro Yield Curve */}
        <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <h4 className="text-sm font-semibold text-white font-mono uppercase flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                UK Gilt vs Mortgage Yield Curves
              </h4>
              <p className="text-[11px] text-slate-400">Benchmark Gilt Yields vs Synthetic Fixed & Tracker Rates</p>
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 border border-emerald-800/60 rounded">
              Base Rate: 4.50%
            </span>
          </div>

          <div className="h-64 pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={yieldCurveData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="tenor" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" domain={[3.0, 6.0]} tick={{ fontSize: 11 }} tickFormatter={(v) => `${v}%`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                  formatter={(val: any) => [`${val}%`, '']}
                />
                <Line type="monotone" dataKey="gilt" name="UK Gilt Benchmark" stroke="#10b981" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="mortgageFixed" name="Synthetic Fixed Mortgage" stroke="#3b82f6" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="mortgageTracker" name="Synthetic Tracker Rate" stroke="#f59e0b" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Regional House Price Index */}
        <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <h4 className="text-sm font-semibold text-white font-mono uppercase flex items-center gap-2">
                <Building className="w-4 h-4 text-amber-400" />
                Regional House Price Index (HPI) Series
              </h4>
              <p className="text-[11px] text-slate-400">Reindexed baseline (2021 = 100) across key UK regions</p>
            </div>
            <span className="text-xs font-mono text-slate-300">
              10 Regions Simulated
            </span>
          </div>

          <div className="h-64 pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={hpiData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="year" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" domain={[95, 130]} tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                />
                <Line type="monotone" dataKey="London" stroke="#6366f1" strokeWidth={2} />
                <Line type="monotone" dataKey="SouthEast" stroke="#ec4899" strokeWidth={2} />
                <Line type="monotone" dataKey="NorthWest" stroke="#06b6d4" strokeWidth={2} />
                <Line type="monotone" dataKey="Scotland" stroke="#eab308" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
