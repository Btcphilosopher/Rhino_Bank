/**
 * RHINOQUANT 1M Synthetic Mortgage Generator Console
 * Generates 10,000, 100,000, or 1,000,000 synthetic loans fast using Mulberry32 PRNG.
 */

import React, { useState } from 'react';
import { generateSyntheticLoans } from '../engine/generator';
import { calculatePoolMetrics } from '../engine/pools';
import { Database, Play, Cpu, CheckCircle2 } from 'lucide-react';

export const GeneratorConsole: React.FC = () => {
  const [loanCount, setLoanCount] = useState<number>(10000);
  const [seed, setSeed] = useState<number>(42);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [genTimeMs, setGenTimeMs] = useState<number | null>(null);
  const [generatedPoolMetrics, setGeneratedPoolMetrics] = useState<any | null>(null);

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const t0 = performance.now();
      const loans = generateSyntheticLoans(loanCount, seed);
      const metrics = calculatePoolMetrics(loans);
      const t1 = performance.now();

      setGenTimeMs(Math.round(t1 - t0));
      setGeneratedPoolMetrics(metrics);
      setIsGenerating(false);
    }, 50);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Database className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-bold text-white font-mono uppercase">30. Synthetic Mortgage Generator</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Synthesize 10,000, 100,000, or 1,000,000 loans with coherent borrower, property, and credit profiles using deterministic seeds.
          </p>
        </div>
      </div>

      {/* Control Card */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
        <h3 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2">
          Synthesis Engine Controls
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div>
            <label className="text-slate-400 block mb-1">Target Loan Count</label>
            <select
              value={loanCount}
              onChange={(e) => setLoanCount(Number(e.target.value))}
              className="w-full bg-[#161c28] border border-slate-700 rounded px-3 py-2 text-white outline-none focus:border-blue-500"
            >
              <option value={10000}>10,000 LOANS (Standard)</option>
              <option value={100000}>100,000 LOANS (Large Portfolio)</option>
              <option value={1000000}>1,000,000 LOANS (Mega Market Scale)</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Mulberry32 PRNG Seed</label>
            <input
              type="number"
              value={seed}
              onChange={(e) => setSeed(Number(e.target.value))}
              className="w-full bg-[#161c28] border border-slate-700 rounded px-3 py-2 text-white outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>{isGenerating ? 'SYNTHESIZING...' : 'GENERATE PORTFOLIO'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Generated Metrics Output */}
      {generatedPoolMetrics && (
        <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold text-white uppercase flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              Synthesized Portfolio Summary
            </h3>
            <span className="text-emerald-400 font-bold">SYNTHESIS TIME: {genTimeMs} MS</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-[#141b28] p-3 rounded border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Total Loan Count</span>
              <span className="text-base font-bold text-white">{generatedPoolMetrics.loanCount.toLocaleString()}</span>
            </div>
            <div className="bg-[#141b28] p-3 rounded border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Total Balance</span>
              <span className="text-base font-bold text-white">£{(generatedPoolMetrics.originalBalance / 1e9).toFixed(2)}bn</span>
            </div>
            <div className="bg-[#141b28] p-3 rounded border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Weighted Avg Coupon (WAC)</span>
              <span className="text-base font-bold text-blue-400">{generatedPoolMetrics.wac.toFixed(2)}%</span>
            </div>
            <div className="bg-[#141b28] p-3 rounded border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Weighted Avg LTV</span>
              <span className="text-base font-bold text-emerald-400">{generatedPoolMetrics.weightedLtv.toFixed(1)}%</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
