/**
 * RHINOQUANT Header & Navigation Bar
 * Top Bar Contract: Brand, Tagline, Navigation Tabs & Demo Trigger
 */

import React from 'react';
import { Activity, ShieldCheck, Database, Sliders, Zap, Sparkles } from 'lucide-react';

export type NavTab =
  | 'MARKET'
  | 'LOAN_CONSTRUCTOR'
  | 'POOL_ENGINE'
  | 'PREPAY_DEFAULT'
  | 'CMO_LAB'
  | 'TRANCHE_IOPO'
  | 'RATE_PATHS'
  | 'MONTE_CARLO'
  | 'RISK_EXTENSION'
  | 'STRESS_LAB'
  | 'SIGNATURE_DEMOS'
  | 'RESEARCH'
  | 'VALIDATION'
  | 'GENERATOR';

interface HeaderProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  seed: number;
  activeScenarioName: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  seed,
  activeScenarioName,
}) => {
  const navItems: { id: NavTab; label: string }[] = [
    { id: 'MARKET', label: 'Market Terminal' },
    { id: 'SIGNATURE_DEMOS', label: 'Signature Demos' },
    { id: 'LOAN_CONSTRUCTOR', label: 'Loan Constructor' },
    { id: 'POOL_ENGINE', label: 'Pool & Stratification' },
    { id: 'PREPAY_DEFAULT', label: 'Prepay & Default' },
    { id: 'CMO_LAB', label: 'Securitisation SPV' },
    { id: 'TRANCHE_IOPO', label: 'Tranches & IO/PO' },
    { id: 'RATE_PATHS', label: 'Rate Paths & OAS' },
    { id: 'MONTE_CARLO', label: 'Monte Carlo' },
    { id: 'RISK_EXTENSION', label: 'Risk & Extension' },
    { id: 'STRESS_LAB', label: 'Stress Lab' },
    { id: 'RESEARCH', label: 'Research AI' },
    { id: 'VALIDATION', label: 'Model Validation' },
    { id: 'GENERATOR', label: '1M Loan Generator' },
  ];

  return (
    <header className="bg-[#0f141d] border-b border-slate-800 text-slate-200 sticky top-0 z-50 shadow-md">
      {/* Top Banner Row */}
      <div className="max-w-[1700px] mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="bg-blue-600/20 border border-blue-500/40 p-1.5 rounded-md text-blue-400">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold tracking-wider text-white font-mono uppercase">
                RHINOQUANT <span className="text-blue-400 font-sans font-normal text-xs px-1.5 py-0.5 bg-blue-950/80 border border-blue-800/60 rounded">SYNTHETIC MORTGAGES</span>
              </h1>
            </div>
            <p className="text-[11px] text-slate-400 font-mono tracking-wide">
              LOAN → POOL → CASH FLOW → PREPAYMENT → SECURITISATION → RISK
            </p>
          </div>
        </div>

        {/* Global Controls & Status */}
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-2 bg-[#161c28] border border-slate-700/60 px-2.5 py-1 rounded font-mono text-slate-300">
            <Sliders className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-slate-400">SCENARIO:</span>
            <span className="text-emerald-400 font-medium">{activeScenarioName}</span>
          </div>

          <div className="flex items-center gap-2 bg-[#161c28] border border-slate-700/60 px-2.5 py-1 rounded font-mono text-slate-300">
            <Database className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400">PRNG SEED:</span>
            <span className="text-amber-300 font-medium">{seed}</span>
          </div>

          <div className="flex items-center gap-1.5 bg-emerald-950/60 border border-emerald-800/50 text-emerald-300 px-2.5 py-1 rounded text-[11px] font-mono">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>AUDIT VERIFIED</span>
          </div>
        </div>
      </div>

      {/* Navigation Bar Row */}
      <div className="max-w-[1700px] mx-auto px-4 overflow-x-auto scrollbar-none py-1.5 flex items-center gap-1">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap rounded-md flex items-center gap-1.5 ${
                isActive
                  ? 'bg-blue-600 text-white shadow-sm font-semibold'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60'
              }`}
            >
              {item.id === 'SIGNATURE_DEMOS' && <Zap className="w-3.5 h-3.5 text-amber-300 fill-amber-300/20" />}
              {item.id === 'RESEARCH' && <Sparkles className="w-3.5 h-3.5 text-blue-300" />}
              {item.label}
            </button>
          );
        })}
      </div>
    </header>
  );
};
