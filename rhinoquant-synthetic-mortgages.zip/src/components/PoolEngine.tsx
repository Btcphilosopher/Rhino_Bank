/**
 * RHINOQUANT Mortgage Pool & Stratification Engine
 * Pool metrics, 6 professional stratification tables, 360-month cash flow ladder & chart.
 */

import React, { useState, useMemo } from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { SIGNATURE_POOL_1, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS } from '../data/signatureDemos';
import { generateStratification, simulatePoolCashFlows } from '../engine/pools';
import { Layers, BarChart3, ListFilter, TrendingDown } from 'lucide-react';

export const PoolEngine: React.FC = () => {
  const pool = SIGNATURE_POOL_1;
  const [stratType, setStratType] = useState<'LTV' | 'CREDIT' | 'REGION' | 'COUPON' | 'ORIGINATION' | 'LOAN_AGE'>('LTV');

  // Stratification Rows
  const stratRows = useMemo(() => {
    return generateStratification(pool.loans || [], stratType);
  }, [pool, stratType]);

  // 360-month Pool Cash Flows
  const marketRates = useMemo(() => new Array(360).fill(4.50), []);
  const poolCashFlows = useMemo(() => {
    return simulatePoolCashFlows(pool, marketRates, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS, 360);
  }, [pool, marketRates]);

  const [page, setPage] = useState<number>(1);
  const pageSize = 12; // 1 year per page
  const paginatedCashFlows = poolCashFlows.slice((page - 1) * pageSize, page * pageSize);
  const totalPages = Math.ceil(poolCashFlows.length / pageSize);

  return (
    <div className="space-y-6">
      {/* Pool Header Metrics */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono bg-blue-950 text-blue-300 border border-blue-800 px-2 py-0.5 rounded">
                POOL ID: {pool.id}
              </span>
              <h2 className="text-lg font-bold text-white font-mono">{pool.name}</h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              50,000 Synthetic Mortgages • £9.4bn Original Balance • UK Prime Mortgage Collateral
            </p>
          </div>
        </div>

        {/* Top Pool Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-xs">
          <div className="bg-[#141b28] border border-slate-800 p-3 rounded-lg">
            <span className="text-[10px] text-slate-400 block uppercase">Original Balance</span>
            <span className="text-sm font-bold text-white">£{(pool.originalBalance / 1e9).toFixed(2)}bn</span>
          </div>
          <div className="bg-[#141b28] border border-slate-800 p-3 rounded-lg">
            <span className="text-[10px] text-slate-400 block uppercase">WAC (Coupon)</span>
            <span className="text-sm font-bold text-blue-400">{pool.wac.toFixed(2)}%</span>
          </div>
          <div className="bg-[#141b28] border border-slate-800 p-3 rounded-lg">
            <span className="text-[10px] text-slate-400 block uppercase">Weighted Avg LTV</span>
            <span className="text-sm font-bold text-emerald-400">{pool.weightedLtv.toFixed(1)}%</span>
          </div>
          <div className="bg-[#141b28] border border-slate-800 p-3 rounded-lg">
            <span className="text-[10px] text-slate-400 block uppercase">Weighted Credit</span>
            <span className="text-sm font-bold text-amber-400">{Math.round(pool.weightedCreditScore)} FICO</span>
          </div>
          <div className="bg-[#141b28] border border-slate-800 p-3 rounded-lg">
            <span className="text-[10px] text-slate-400 block uppercase">Expected WAL</span>
            <span className="text-sm font-bold text-white">{pool.wal.toFixed(2)} YRS</span>
          </div>
          <div className="bg-[#141b28] border border-slate-800 p-3 rounded-lg">
            <span className="text-[10px] text-slate-400 block uppercase">Average Balance</span>
            <span className="text-sm font-bold text-white">£{Math.round(pool.averageBalance).toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Pool Stratification Tables */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <h3 className="text-xs font-bold text-white font-mono uppercase flex items-center gap-2">
            <ListFilter className="w-4 h-4 text-blue-400" />
            Professional Pool Stratification Tables
          </h3>

          <div className="flex flex-wrap items-center gap-1 bg-[#141b28] p-1 rounded-lg border border-slate-800">
            {(['LTV', 'CREDIT', 'REGION', 'COUPON', 'ORIGINATION', 'LOAN_AGE'] as const).map((type) => (
              <button
                key={type}
                onClick={() => setStratType(type)}
                className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
                  stratType === type ? 'bg-blue-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                BY {type}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-[#141b28]">
                <th className="py-2.5 px-3">Stratification Bucket</th>
                <th className="py-2.5 px-3">Loan Count</th>
                <th className="py-2.5 px-3">Current Balance (£)</th>
                <th className="py-2.5 px-3">% of Pool</th>
                <th className="py-2.5 px-3">WAC (%)</th>
                <th className="py-2.5 px-3">WA LTV (%)</th>
                <th className="py-2.5 px-3">WA FICO-Equivalent</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {stratRows.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 font-semibold text-white">{row.category}</td>
                  <td className="py-2.5 px-3 text-slate-300">{row.loanCount.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-slate-200">£{Math.round(row.balance).toLocaleString()}</td>
                  <td className="py-2.5 px-3 font-bold text-blue-400">{row.balancePercentage.toFixed(2)}%</td>
                  <td className="py-2.5 px-3 text-amber-400">{row.wac.toFixed(2)}%</td>
                  <td className="py-2.5 px-3 text-emerald-400">{row.weightedLtv.toFixed(1)}%</td>
                  <td className="py-2.5 px-3 text-slate-300">{Math.round(row.weightedCreditScore)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pool Balance Amortisation & Cash Flow Ladder */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Balance Decay Chart */}
        <div className="lg:col-span-7 bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 className="text-xs font-bold text-white font-mono uppercase flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-emerald-400" />
              Pool Balance Decay Curve Over Time (360 Months)
            </h4>
            <span className="text-xs font-mono text-slate-400">Scheduled + Prepayments</span>
          </div>

          <div className="h-64 pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={poolCashFlows.filter((_, i) => i % 6 === 0)}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="month" stroke="#64748b" tick={{ fontSize: 11 }} tickFormatter={(m) => `M${m}`} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} tickFormatter={(v) => `£${(v / 1e9).toFixed(1)}b`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                  formatter={(val: any) => [`£${(Number(val) / 1e6).toFixed(1)}m`, 'Balance']}
                />
                <Area type="monotone" dataKey="closingBalance" stroke="#3b82f6" fill="#1d4ed8" fillOpacity={0.2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 360-month Cash Flow Ladder Table */}
        <div className="lg:col-span-5 bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 className="text-xs font-bold text-white font-mono uppercase flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-amber-400" />
              Monthly Pool Cash Flow Ladder
            </h4>
            <div className="flex items-center gap-2 text-xs font-mono">
              <button
                disabled={page <= 1}
                onClick={() => setPage(page - 1)}
                className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 rounded"
              >
                Prev
              </button>
              <span className="text-slate-400">Yr {page}</span>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage(page + 1)}
                className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 rounded"
              >
                Next
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-[#141b28]">
                  <th className="py-2 px-2">Month</th>
                  <th className="py-2 px-2">Sched Prin</th>
                  <th className="py-2 px-2">Prepay</th>
                  <th className="py-2 px-2">Interest</th>
                  <th className="py-2 px-2">Total CF</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {paginatedCashFlows.map((row) => (
                  <tr key={row.month} className="hover:bg-slate-800/40">
                    <td className="py-1.5 px-2 text-slate-300">M{row.month}</td>
                    <td className="py-1.5 px-2 text-emerald-400">£{(row.scheduledPrincipal / 1e6).toFixed(2)}m</td>
                    <td className="py-1.5 px-2 text-blue-400">£{(row.unscheduledPrincipal / 1e6).toFixed(2)}m</td>
                    <td className="py-1.5 px-2 text-amber-400">£{(row.interest / 1e6).toFixed(2)}m</td>
                    <td className="py-1.5 px-2 font-bold text-white">£{(row.totalCashFlow / 1e6).toFixed(2)}m</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
