/**
 * RHINOQUANT Tranche & Interest-Only (IO) / Principal-Only (PO) Strip Engine
 * Strip cash-flow decomposition, pricing, and inverse prepayment/rate-sensitivity.
 */

import React, { useState, useMemo } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { SIGNATURE_POOL_1, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS } from '../data/signatureDemos';
import { simulatePoolCashFlows } from '../engine/pools';
import { generateIoPoStrips, priceIoPoStrips } from '../engine/io_po';
import { Layers, TrendingUp, DollarSign, Activity } from 'lucide-react';

export const TrancheIOPOView: React.FC = () => {
  const [discountRate, setDiscountRate] = useState<number>(4.50);

  // Generate pool cash flows
  const marketRates = useMemo(() => new Array(360).fill(4.50), []);
  const poolCashFlows = useMemo(() => {
    return simulatePoolCashFlows(SIGNATURE_POOL_1, marketRates, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS, 360);
  }, [marketRates]);

  // IO / PO Strips
  const ioPoStrips = useMemo(() => generateIoPoStrips(poolCashFlows), [poolCashFlows]);

  // Pricing
  const ioPoValuation = useMemo(() => {
    return priceIoPoStrips(ioPoStrips, discountRate);
  }, [ioPoStrips, discountRate]);

  // Rate Shift Curve (-200bps to +200bps) for IO vs PO Price
  const rateShiftData = useMemo(() => {
    const data = [];
    for (let shift = -200; shift <= 200; shift += 50) {
      const shiftRate = Math.max(0.5, 4.50 + shift / 100);
      const shiftMarket = new Array(360).fill(shiftRate);

      // Higher rate = lower prepay, lower rate = higher prepay
      const cfs = simulatePoolCashFlows(SIGNATURE_POOL_1, shiftMarket, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS, 360);
      const strips = generateIoPoStrips(cfs);
      const val = priceIoPoStrips(strips, shiftRate);

      data.push({
        shiftBps: shift,
        ratePct: shiftRate,
        ioPrice: Number(val.ioPrice.toFixed(2)),
        poPrice: Number(val.poPrice.toFixed(2)),
        combined: Number(val.combinedPrice.toFixed(2)),
      });
    }
    return data;
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white font-mono uppercase flex items-center gap-2">
            <Layers className="w-5 h-5 text-blue-400" />
            17. Interest-Only (IO) & Principal-Only (PO) Strip Engine
          </h2>
          <p className="text-xs text-slate-400">
            Federal Reserve noted mortgage cash-flow claims on interest vs principal with opposite sensitivity to prepayment.
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="bg-[#141b28] border border-slate-800 px-3 py-1.5 rounded">
            <span className="text-slate-400">DISCOUNT CURVE: </span>
            <span className="text-amber-400 font-bold">{discountRate.toFixed(2)}%</span>
          </div>
        </div>
      </div>

      {/* IO / PO Valuation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
        <div className="bg-[#0f141e] border border-amber-800/80 rounded-xl p-4 space-y-2">
          <div className="flex justify-between items-center text-amber-400">
            <span className="font-bold uppercase">INTEREST-ONLY (IO) STRIP</span>
            <span className="text-[10px] bg-amber-950 px-2 py-0.5 rounded border border-amber-800">INTEREST CLAIMS</span>
          </div>
          <div className="text-2xl font-bold text-white">£{ioPoValuation.ioPrice.toFixed(2)}</div>
          <p className="text-[11px] text-slate-400">
            Benefits when interest rates rise and prepayments slow, prolonging interest receipts.
          </p>
          <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-300">
            Expected Duration: <span className="font-bold text-amber-300">{ioPoValuation.ioDuration.toFixed(2)} YRS</span>
          </div>
        </div>

        <div className="bg-[#0f141e] border border-blue-800/80 rounded-xl p-4 space-y-2">
          <div className="flex justify-between items-center text-blue-400">
            <span className="font-bold uppercase">PRINCIPAL-ONLY (PO) STRIP</span>
            <span className="text-[10px] bg-blue-950 px-2 py-0.5 rounded border border-blue-800">PAR PRINCIPAL</span>
          </div>
          <div className="text-2xl font-bold text-white">£{ioPoValuation.poPrice.toFixed(2)}</div>
          <p className="text-[11px] text-slate-400">
            Benefits when interest rates fall and prepayments surge, returning par principal faster.
          </p>
          <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-300">
            Expected Duration: <span className="font-bold text-blue-300">{ioPoValuation.poDuration.toFixed(2)} YRS</span>
          </div>
        </div>

        <div className="bg-[#0f141e] border border-emerald-800/80 rounded-xl p-4 space-y-2">
          <div className="flex justify-between items-center text-emerald-400">
            <span className="font-bold uppercase">COMBINED PASS-THROUGH</span>
            <span className="text-[10px] bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">IO + PO</span>
          </div>
          <div className="text-2xl font-bold text-white">£{ioPoValuation.combinedPrice.toFixed(2)}</div>
          <p className="text-[11px] text-slate-400">
            Reconstructed full pass-through security combining interest and principal cash flow streams.
          </p>
          <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-300">
            Base Discount Rate: <span className="font-bold text-emerald-300">{discountRate}%</span>
          </div>
        </div>
      </div>

      {/* Rate Shift Sensitivity Chart */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-3">
        <div className="border-b border-slate-800 pb-2">
          <h4 className="text-xs font-bold text-white font-mono uppercase flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            Inverse Rate Sensitivity: IO vs PO Price Dynamics Under Interest Rate Shifts
          </h4>
          <p className="text-[11px] text-slate-400">
            Visually proves why IO prices increase when rates rise (slower prepayments) while PO prices drop.
          </p>
        </div>

        <div className="h-72 pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={rateShiftData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="shiftBps" stroke="#64748b" tick={{ fontSize: 11 }} tickFormatter={(v) => `${v}bps`} />
              <YAxis stroke="#64748b" domain={[0, 100]} tick={{ fontSize: 11 }} tickFormatter={(v) => `£${v}`} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                formatter={(val: any) => [`£${val}`, 'Clean Price']}
              />
              <Line type="monotone" dataKey="ioPrice" name="IO Strip Price" stroke="#f59e0b" strokeWidth={2.5} dot={{ r: 4 }} />
              <Line type="monotone" dataKey="poPrice" name="PO Strip Price" stroke="#3b82f6" strokeWidth={2.5} dot={{ r: 4 }} />
              <Line type="monotone" dataKey="combined" name="Combined Pass-Through" stroke="#10b981" strokeWidth={2} strokeDasharray="5 5" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
