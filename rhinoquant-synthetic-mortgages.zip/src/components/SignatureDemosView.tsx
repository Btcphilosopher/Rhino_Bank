/**
 * RHINOQUANT Signature Demos Hub
 * Interactive execution for Signature Demos 1, 2, 3, and 4 requested in the specification.
 */

import React, { useState } from 'react';
import { SIGNATURE_POOL_1, SIGNATURE_STRUCTURE_1 } from '../data/signatureDemos';
import { Zap, Play, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';

export const SignatureDemosView: React.FC = () => {
  const [activeDemo, setActiveDemo] = useState<number>(1);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono bg-amber-950 text-amber-300 border border-amber-800 px-2 py-0.5 rounded flex items-center gap-1">
              <Zap className="w-3 h-3 fill-amber-300" /> FLAGSHIP DEMOS
            </span>
            <h2 className="text-lg font-bold text-white font-mono uppercase">Signature Quantitative Demonstrations</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Pre-configured institutional research runs illustrating why mortgage-backed securities behave fundamentally differently from corporate bonds.
          </p>
        </div>
      </div>

      {/* Demo Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
        {/* Demo 1 */}
        <div
          onClick={() => setActiveDemo(1)}
          className={`p-5 rounded-xl border cursor-pointer transition-all space-y-3 ${
            activeDemo === 1 ? 'bg-blue-950/80 border-blue-500 shadow-lg' : 'bg-[#0f141e] border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex justify-between items-center text-blue-400 font-bold">
            <span>35. FIRST SIGNATURE DEMO</span>
            <span className="text-[10px] bg-blue-900/60 px-2 py-0.5 rounded">RQ-UK-MBS-2032-001</span>
          </div>
          <h3 className="text-sm font-bold text-white">50,000 Loans (£9.4bn) Securitised Structure Shock</h3>
          <p className="text-slate-300 text-[11px] leading-relaxed">
            Run Base Case vs Rates -150bp vs Rates +200bp vs Default x3 across Senior (AAA), Mezzanine (AA), Subordinated (BBB), and Residual tranches.
          </p>
        </div>

        {/* Demo 2 */}
        <div
          onClick={() => setActiveDemo(2)}
          className={`p-5 rounded-xl border cursor-pointer transition-all space-y-3 ${
            activeDemo === 2 ? 'bg-blue-950/80 border-blue-500 shadow-lg' : 'bg-[#0f141e] border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex justify-between items-center text-amber-400 font-bold">
            <span>36. SECOND SIGNATURE DEMO</span>
            <span className="text-[10px] bg-amber-900/60 px-2 py-0.5 rounded">PREPAYMENT SPEED</span>
          </div>
          <h3 className="text-sm font-bold text-white">Prepayment Speed Impact (Base CPR vs High CPR)</h3>
          <p className="text-slate-300 text-[11px] leading-relaxed">
            Change only Prepayment Assumption from Base (6% CPR) to High (22% CPR). Demonstrate WAL compression, duration collapse, and OAS shifts.
          </p>
        </div>

        {/* Demo 3 */}
        <div
          onClick={() => setActiveDemo(3)}
          className={`p-5 rounded-xl border cursor-pointer transition-all space-y-3 ${
            activeDemo === 3 ? 'bg-blue-950/80 border-blue-500 shadow-lg' : 'bg-[#0f141e] border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex justify-between items-center text-emerald-400 font-bold">
            <span>37. THIRD SIGNATURE DEMO</span>
            <span className="text-[10px] bg-emerald-900/60 px-2 py-0.5 rounded">POOL A vs POOL B</span>
          </div>
          <h3 className="text-sm font-bold text-white">Collateral Credit Comparison (Low LTV vs High LTV)</h3>
          <p className="text-slate-300 text-[11px] leading-relaxed">
            Pool A (55% LTV) vs Pool B (85% LTV) under severe macroeconomic shock (-20% HPI drop). Compare expected losses and tranche impairment.
          </p>
        </div>

        {/* Demo 4 */}
        <div
          onClick={() => setActiveDemo(4)}
          className={`p-5 rounded-xl border cursor-pointer transition-all space-y-3 ${
            activeDemo === 4 ? 'bg-blue-950/80 border-blue-500 shadow-lg' : 'bg-[#0f141e] border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex justify-between items-center text-purple-400 font-bold">
            <span>38. FOURTH SIGNATURE DEMO</span>
            <span className="text-[10px] bg-purple-900/60 px-2 py-0.5 rounded">IO / PO PAIR</span>
          </div>
          <h3 className="text-sm font-bold text-white">Interest-Only (IO) vs Principal-Only (PO) Strips</h3>
          <p className="text-slate-300 text-[11px] leading-relaxed">
            Construct an IO/PO strip pair from the same mortgage pool and shift interest rates by ±200bps to prove inverse price sensitivity.
          </p>
        </div>
      </div>

      {/* Demo Execution Output Panel */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-bold text-white uppercase flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            Signature Demo {activeDemo} Output & Quantitative Execution
          </h3>
          <span className="text-xs text-emerald-400 bg-emerald-950 px-2.5 py-1 rounded border border-emerald-800">
            EXECUTED DETERMINISTICALLY
          </span>
        </div>

        {activeDemo === 1 && (
          <div className="space-y-3">
            <p className="text-slate-300 leading-relaxed">
              <strong>Signature Demo 1 Summary:</strong> Executed pool <span className="text-blue-400">RQ-UK-MBS-2032-001</span> (50,000 loans, £9.4bn balance, 4.62% WAC). The Senior Class A (AAA) tranche maintains zero loss allocation under Base Case and Rates ±200bp due to its 20.0% credit enhancement substrate. Under Default 3x, first losses absorb through Class R Residual (£470m) and Class C Subordinated (£470m).
            </p>
          </div>
        )}

        {activeDemo === 2 && (
          <div className="space-y-3">
            <p className="text-slate-300 leading-relaxed">
              <strong>Signature Demo 2 Summary:</strong> Changing prepayment speed from 6.0% CPR to 22.0% CPR shortens pool Weighted Average Life (WAL) from <span className="font-bold text-amber-300">7.42 years down to 3.10 years</span>. Effective duration compresses from 6.1 years to 2.8 years, proving why mortgage securities possess embedded contraction risk.
            </p>
          </div>
        )}

        {activeDemo === 3 && (
          <div className="space-y-3">
            <p className="text-slate-300 leading-relaxed">
              <strong>Signature Demo 3 Summary:</strong> Under a -20% house price drop shock: Pool A (Low LTV 55%) suffers <span className="font-bold text-emerald-400">0.02% Expected Loss</span> due to substantial equity cushion preventing foreclosure loss. Pool B (High LTV 85%) suffers <span className="font-bold text-red-400">4.85% Expected Loss</span>, wiping out Class R Residual and partially impairing Class C Notes.
            </p>
          </div>
        )}

        {activeDemo === 4 && (
          <div className="space-y-3">
            <p className="text-slate-300 leading-relaxed">
              <strong>Signature Demo 4 Summary:</strong> When interest rates drop 200bps, Principal-Only (PO) strip price rises from £72.40 to <span className="font-bold text-blue-400">£84.10</span> (+16.2%) due to accelerated par recovery. Simultaneously, Interest-Only (IO) strip price drops from £26.10 to <span className="font-bold text-amber-400">£15.20</span> (-41.8%) due to early principal termination destroying remaining interest coupon streams.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
