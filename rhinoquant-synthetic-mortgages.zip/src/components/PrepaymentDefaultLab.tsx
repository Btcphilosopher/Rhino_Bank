/**
 * RHINOQUANT Prepayment & Default Competing Risk Engine Lab
 * Refinance incentive S-curves, competing prepayment SMM vs default MDR, property recovery & LGD.
 */

import React, { useState, useMemo } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { calculatePrepaymentSmm } from '../engine/prepayment';
import { calculateDefaultMetrics } from '../engine/default';
import { BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS } from '../data/signatureDemos';
import { Sliders, ShieldAlert, FastForward, Activity } from 'lucide-react';

export const PrepaymentDefaultLab: React.FC = () => {
  const [loanRate, setLoanRate] = useState<number>(4.75);
  const [marketRate, setMarketRate] = useState<number>(3.50);
  const [baseCpr, setBaseCpr] = useState<number>(6.0);
  const [refiSensitivity, setRefiSensitivity] = useState<number>(1.8);

  const [baseCdr, setBaseCdr] = useState<number>(1.2);
  const [hpiDropPct, setHpiDropPct] = useState<number>(0.0);
  const [unemployment, setUnemployment] = useState<number>(0.0);
  const [recoveryCostPct, setRecoveryCostPct] = useState<number>(15.0);

  // Refinance Incentive S-Curve Data (-300bps to +300bps incentive)
  const sCurveData = useMemo(() => {
    const data = [];
    for (let inc = -300; inc <= 300; inc += 25) {
      const mktRate = loanRate - inc / 100;
      const res = calculatePrepaymentSmm(
        12,
        loanRate,
        mktRate,
        { ...BASE_PREPAY_PARAMS, baseCPR: baseCpr, refiIncentiveSensitivity: refiSensitivity }
      );
      data.push({ incentiveBps: inc, cpr: Number(res.cpr.toFixed(2)), smmPct: Number((res.smm * 100).toFixed(2)) });
    }
    return data;
  }, [loanRate, baseCpr, refiSensitivity]);

  // Competing Risk 360-month SMM vs MDR curve
  const competingRiskTimeline = useMemo(() => {
    const timeline = [];
    let cumulativeSurvival = 1.0;

    for (let m = 1; m <= 120; m++) {
      const prepayRes = calculatePrepaymentSmm(
        m,
        loanRate,
        marketRate,
        { ...BASE_PREPAY_PARAMS, baseCPR: baseCpr, refiIncentiveSensitivity: refiSensitivity }
      );

      const defaultRes = calculateDefaultMetrics({
        month: m,
        ltv: 75,
        dti: 35,
        creditScore: 720,
        loanRate,
        region: 'LONDON',
        propertyValue: 350000,
        loanBalance: 250000 * cumulativeSurvival,
        params: {
          ...BASE_DEFAULT_PARAMS,
          baseCDR: baseCdr,
          hpiChange: -hpiDropPct,
          unemploymentShock: unemployment,
          recoveryCostRate: recoveryCostPct / 100,
        },
      });

      const smm = prepayRes.smm;
      const mdr = defaultRes.mdr;

      // Competing risk survival update
      cumulativeSurvival *= (1 - smm - mdr);

      timeline.push({
        month: m,
        cpr: Number(prepayRes.cpr.toFixed(2)),
        cdr: Number(defaultRes.cdr.toFixed(2)),
        smmPct: Number((smm * 100).toFixed(3)),
        mdrPct: Number((mdr * 100).toFixed(3)),
        survivalPct: Number((cumulativeSurvival * 100).toFixed(1)),
      });
    }

    return timeline;
  }, [loanRate, marketRate, baseCpr, refiSensitivity, baseCdr, hpiDropPct, unemployment, recoveryCostPct]);

  // Calculated Property Recovery Sample
  const sampleRecovery = useMemo(() => {
    return calculateDefaultMetrics({
      month: 24,
      ltv: 80,
      dti: 38,
      creditScore: 690,
      loanRate,
      region: 'LONDON',
      propertyValue: 350000,
      loanBalance: 280000,
      params: {
        ...BASE_DEFAULT_PARAMS,
        baseCDR: baseCdr,
        hpiChange: -hpiDropPct,
        unemploymentShock: unemployment,
        recoveryCostRate: recoveryCostPct / 100,
      },
    });
  }, [loanRate, baseCdr, hpiDropPct, unemployment, recoveryCostPct]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white font-mono uppercase flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-400" />
            Prepayment & Default Competing Risk Engine Lab
          </h2>
          <p className="text-xs text-slate-400">
            Federal Reserve compliant competing-risk framework treating prepayment and credit default as competing terminal states.
          </p>
        </div>
      </div>

      {/* Control Sliders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
        {/* Prepayment Model Sliders */}
        <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-xs font-bold text-amber-400 uppercase border-b border-slate-800 pb-2 flex items-center gap-2">
            <FastForward className="w-4 h-4" /> Prepayment Refinance Model Controls
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Contract Loan Rate:</span>
                <span className="font-bold text-white">{loanRate.toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min="2.5"
                max="8.0"
                step="0.1"
                value={loanRate}
                onChange={(e) => setLoanRate(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Current Market Refi Rate:</span>
                <span className="font-bold text-amber-300">{marketRate.toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min="2.0"
                max="8.0"
                step="0.1"
                value={marketRate}
                onChange={(e) => setMarketRate(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Baseline CPR (%):</span>
                <span className="font-bold text-white">{baseCpr.toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="15.0"
                step="0.5"
                value={baseCpr}
                onChange={(e) => setBaseCpr(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Refi Sensitivity (S-Curve Alpha):</span>
                <span className="font-bold text-white">{refiSensitivity.toFixed(1)}</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="4.0"
                step="0.1"
                value={refiSensitivity}
                onChange={(e) => setRefiSensitivity(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>
          </div>
        </div>

        {/* Default Model Sliders */}
        <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-xs font-bold text-red-400 uppercase border-b border-slate-800 pb-2 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4" /> Default & Recovery Model Controls
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Baseline CDR (%):</span>
                <span className="font-bold text-white">{baseCdr.toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0.2"
                max="10.0"
                step="0.2"
                value={baseCdr}
                onChange={(e) => setBaseCdr(Number(e.target.value))}
                className="w-full accent-red-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>House Price Drop (HPI Shift):</span>
                <span className="font-bold text-red-300">-{hpiDropPct.toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="30"
                step="1"
                value={hpiDropPct}
                onChange={(e) => setHpiDropPct(Number(e.target.value))}
                className="w-full accent-red-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Unemployment Shock (+%):</span>
                <span className="font-bold text-white">+{unemployment.toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="10"
                step="0.5"
                value={unemployment}
                onChange={(e) => setUnemployment(Number(e.target.value))}
                className="w-full accent-red-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Foreclosure Recovery Cost Rate:</span>
                <span className="font-bold text-white">{recoveryCostPct.toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="5"
                max="35"
                step="1"
                value={recoveryCostPct}
                onChange={(e) => setRecoveryCostPct(Number(e.target.value))}
                className="w-full accent-red-500"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Refinance Incentive S-Curve */}
        <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-3">
          <div className="border-b border-slate-800 pb-2">
            <h4 className="text-xs font-bold text-white font-mono uppercase">Refinance Incentive Logistic S-Curve</h4>
            <p className="text-[11px] text-slate-400">Prepayment CPR % as a function of Refinance Incentive (bps)</p>
          </div>

          <div className="h-64 pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sCurveData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="incentiveBps" stroke="#64748b" tick={{ fontSize: 11 }} tickFormatter={(v) => `${v}bps`} />
                <YAxis stroke="#64748b" domain={[0, 40]} tick={{ fontSize: 11 }} tickFormatter={(v) => `${v}%`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                  formatter={(val: any) => [`${val}% CPR`, 'Prepayment Speed']}
                />
                <Line type="monotone" dataKey="cpr" stroke="#f59e0b" strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Competing Risk CPR vs CDR Timeline */}
        <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-3">
          <div className="border-b border-slate-800 pb-2">
            <h4 className="text-xs font-bold text-white font-mono uppercase">Competing Risk CPR vs CDR Dynamics</h4>
            <p className="text-[11px] text-slate-400">Simultaneous Prepayment (CPR) vs Default (CDR) over 120 Months</p>
          </div>

          <div className="h-64 pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={competingRiskTimeline}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="month" stroke="#64748b" tick={{ fontSize: 11 }} tickFormatter={(m) => `M${m}`} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} tickFormatter={(v) => `${v}%`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                />
                <Line type="monotone" dataKey="cpr" name="Prepayment CPR (%)" stroke="#f59e0b" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="cdr" name="Default CDR (%)" stroke="#ef4444" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Property Recovery Engine Summary Card */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-3 font-mono text-xs">
        <h4 className="font-bold text-white uppercase border-b border-slate-800 pb-2">
          Property Recovery Engine Calculation Sample
        </h4>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <div className="bg-[#141b28] p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-400 block">Property Value</span>
            <span className="text-sm font-bold text-white">£{Math.round(sampleRecovery.currentPropertyValue).toLocaleString()}</span>
          </div>
          <div className="bg-[#141b28] p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-400 block">Foreclosure Recovery</span>
            <span className="text-sm font-bold text-emerald-400">£{Math.round(sampleRecovery.recoveryValue).toLocaleString()}</span>
          </div>
          <div className="bg-[#141b28] p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-400 block">Loss Given Default (LGD)</span>
            <span className="text-sm font-bold text-red-400">{sampleRecovery.lgdPct.toFixed(2)}%</span>
          </div>
          <div className="bg-[#141b28] p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-400 block">Annualised CDR</span>
            <span className="text-sm font-bold text-amber-400">{sampleRecovery.cdr.toFixed(2)}%</span>
          </div>
          <div className="bg-[#141b28] p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-400 block">Expected Loss</span>
            <span className="text-sm font-bold text-white">£{Math.round(sampleRecovery.expectedLoss).toLocaleString()}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
