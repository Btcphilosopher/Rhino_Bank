/**
 * RHINOQUANT Mortgage Risk & Extension/Contraction Risk Lab
 * Federal Reserve highlighted extension and contraction mechanics with interactive rate shift sliders.
 */

import React, { useState, useMemo } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { SIGNATURE_POOL_1, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS } from '../data/signatureDemos';
import { simulatePoolCashFlows } from '../engine/pools';
import { calculateRiskMetrics } from '../engine/pricing';
import { ArrowDown, ArrowUp, Zap, ShieldAlert, FastForward, Activity } from 'lucide-react';

export const RiskExtensionLab: React.FC = () => {
  const [rateShiftBps, setRateShiftBps] = useState<number>(0);

  // Base Risk Metrics
  const baseRates = useMemo(() => new Array(360).fill(4.62), []);
  const baseCashFlows = useMemo(() => {
    return simulatePoolCashFlows(SIGNATURE_POOL_1, baseRates, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS, 360);
  }, [baseRates]);

  const riskMetrics = useMemo(() => {
    return calculateRiskMetrics(baseCashFlows, 4.62);
  }, [baseCashFlows]);

  // Shifted Rate Cash Flows
  const shiftedRates = useMemo(() => new Array(360).fill(4.62 + rateShiftBps / 100), [rateShiftBps]);
  const shiftedCashFlows = useMemo(() => {
    return simulatePoolCashFlows(SIGNATURE_POOL_1, shiftedRates, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS, 360);
  }, [shiftedRates]);

  const shiftedRiskMetrics = useMemo(() => {
    return calculateRiskMetrics(shiftedCashFlows, 4.62 + rateShiftBps / 100);
  }, [shiftedCashFlows]);

  // Extension / Contraction Comparison Bar Data
  const extensionComparisonData = [
    { scenario: 'Rates -200bps (Cut)', cpr: 22.5, wal: 3.10, duration: 2.8 },
    { scenario: 'Rates -100bps', cpr: 14.0, wal: 4.80, duration: 4.1 },
    { scenario: 'Base Case (4.62%)', cpr: 6.0, wal: 7.42, duration: 6.1 },
    { scenario: 'Rates +100bps', cpr: 3.2, wal: 9.80, duration: 8.2 },
    { scenario: 'Rates +200bps (Hike)', cpr: 1.5, wal: 12.40, duration: 10.5 },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white font-mono uppercase flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-400" />
            21 & 22. Mortgage Risk & Extension / Contraction Risk Lab
          </h2>
          <p className="text-xs text-slate-400">
            Federal Reserve identifies shortening and extension behavior as a fundamental feature of mortgage securities.
          </p>
        </div>
      </div>

      {/* Mechanics Interactive Diagram */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
        <h3 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2">
          Extension vs Contraction Mechanics Interactive Simulation
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Contraction Box */}
          <div className="bg-emerald-950/40 border border-emerald-800/80 p-4 rounded-xl space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 font-bold uppercase">
              <ArrowDown className="w-4 h-4" />
              Contraction Risk (Rates Fall)
            </div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              RATES FALL ↓ → PREPAYMENT SURGES ↑ → POOL BALANCE DECAYS FASTER → WAL SHORTENS
            </p>
            <div className="pt-2 border-t border-emerald-800/60 text-emerald-300">
              At -200bps: Prepayments reach <span className="font-bold">22.5% CPR</span>, WAL shortens from <span className="font-bold">7.42 yrs to 3.10 yrs</span>.
            </div>
          </div>

          {/* Extension Box */}
          <div className="bg-amber-950/40 border border-amber-800/80 p-4 rounded-xl space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold uppercase">
              <ArrowUp className="w-4 h-4" />
              Extension Risk (Rates Rise)
            </div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              RATES RISE ↑ → PREPAYMENT DROPS ↓ → POOL BALANCE REMAINS LONGER → WAL EXTENDS
            </p>
            <div className="pt-2 border-t border-amber-800/60 text-amber-300">
              At +200bps: Prepayments drop to <span className="font-bold">1.5% CPR</span>, WAL extends from <span className="font-bold">7.42 yrs to 12.40 yrs</span>.
            </div>
          </div>
        </div>

        {/* Interactive Rate Shift Slider */}
        <div className="pt-3 border-t border-slate-800 space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-slate-300 font-bold">INTERACTIVE MARKET RATE SHIFT:</span>
            <span className={`text-sm font-bold ${rateShiftBps > 0 ? 'text-amber-400' : rateShiftBps < 0 ? 'text-emerald-400' : 'text-white'}`}>
              {rateShiftBps > 0 ? `+${rateShiftBps} bps` : `${rateShiftBps} bps`}
            </span>
          </div>
          <input
            type="range"
            min="-300"
            max="300"
            step="25"
            value={rateShiftBps}
            onChange={(e) => setRateShiftBps(Number(e.target.value))}
            className="w-full accent-blue-500"
          />
        </div>
      </div>

      {/* Shifted Risk KPI Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-[#0f141e] border border-slate-800 p-4 rounded-xl">
          <span className="text-[10px] text-slate-400 block uppercase">Shifted Weighted Avg Life (WAL)</span>
          <span className="text-2xl font-bold text-white">{shiftedRiskMetrics.wal.toFixed(2)} YRS</span>
          <span className="text-[10px] text-slate-500 block mt-1">Base: {riskMetrics.wal.toFixed(2)} YRS</span>
        </div>

        <div className="bg-[#0f141e] border border-slate-800 p-4 rounded-xl">
          <span className="text-[10px] text-slate-400 block uppercase">Effective Duration</span>
          <span className="text-2xl font-bold text-blue-400">{shiftedRiskMetrics.effectiveDuration.toFixed(2)} YRS</span>
          <span className="text-[10px] text-slate-500 block mt-1">Base: {riskMetrics.effectiveDuration.toFixed(2)} YRS</span>
        </div>

        <div className="bg-[#0f141e] border border-slate-800 p-4 rounded-xl">
          <span className="text-[10px] text-slate-400 block uppercase">Convexity</span>
          <span className="text-2xl font-bold text-emerald-400">{shiftedRiskMetrics.convexity.toFixed(3)}</span>
          <span className="text-[10px] text-slate-500 block mt-1">Negative convexity for prepayable MBS</span>
        </div>

        <div className="bg-[#0f141e] border border-slate-800 p-4 rounded-xl">
          <span className="text-[10px] text-slate-400 block uppercase">DV01 (Dollar Value of 1bp)</span>
          <span className="text-2xl font-bold text-amber-400">£{Math.round(shiftedRiskMetrics.dv01 * (SIGNATURE_POOL_1.originalBalance / 100)).toLocaleString()}</span>
          <span className="text-[10px] text-slate-500 block mt-1">Dollar risk per 1bp shift</span>
        </div>
      </div>

      {/* Extension Risk Bar Chart */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-3">
        <div className="border-b border-slate-800 pb-2">
          <h4 className="text-xs font-bold text-white font-mono uppercase">Weighted Average Life (WAL) Extension / Contraction Curve Across Rate Shifts</h4>
          <p className="text-[11px] text-slate-400">Comparing expected WAL across -200bps to +200bps rate shocks</p>
        </div>

        <div className="h-64 pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={extensionComparisonData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="scenario" stroke="#64748b" tick={{ fontSize: 11 }} />
              <YAxis stroke="#64748b" domain={[0, 15]} tick={{ fontSize: 11 }} tickFormatter={(v) => `${v}y`} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                formatter={(val: any) => [`${val} years`, 'WAL']}
              />
              <Bar dataKey="wal" name="Expected WAL (Years)" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
