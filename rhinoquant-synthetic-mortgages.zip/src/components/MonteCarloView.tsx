/**
 * RHINOQUANT Monte Carlo Engine Terminal
 * Runs 10, 100, 1,000, 10,000, or 100,000 stochastic simulation paths.
 * Generates P10/P50/P90 pool balance confidence bands, Value at Risk (VaR), and OAS convergence.
 */

import React, { useState, useMemo } from 'react';
import { ResponsiveContainer, AreaChart, Area, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { SIGNATURE_POOL_1, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS } from '../data/signatureDemos';
import { runMonteCarloSimulation } from '../engine/montecarlo';
import { Play, Cpu, ShieldAlert, BarChart, CheckCircle2 } from 'lucide-react';

export const MonteCarloView: React.FC = () => {
  const [pathCount, setPathCount] = useState<number>(100);
  const [seed, setSeed] = useState<number>(42);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [execTimeMs, setExecTimeMs] = useState<number>(0);

  const mcSummary = useMemo(() => {
    const t0 = performance.now();
    const result = runMonteCarloSimulation(SIGNATURE_POOL_1, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS, pathCount, seed);
    const t1 = performance.now();
    setExecTimeMs(Math.round(t1 - t0));
    return result;
  }, [pathCount, seed]);

  // Transform percentiles for Recharts
  const percentileChartData = useMemo(() => {
    const data = [];
    for (let m = 0; m < 360; m += 6) {
      data.push({
        month: m,
        P10: Number((mcSummary.percentiles.p10Balance[m] / 1e9 || 0).toFixed(2)),
        P50: Number((mcSummary.percentiles.p50Balance[m] / 1e9 || 0).toFixed(2)),
        P90: Number((mcSummary.percentiles.p90Balance[m] / 1e9 || 0).toFixed(2)),
      });
    }
    return data;
  }, [mcSummary]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white font-mono uppercase flex items-center gap-2">
            <Cpu className="w-5 h-5 text-blue-400" />
            20. Monte Carlo Simulation Engine
          </h2>
          <p className="text-xs text-slate-400">
            Stochastic Vasicek rate paths, path-dependent prepayment/default execution, and loss distributions.
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="bg-[#141b28] border border-slate-800 px-3 py-1.5 rounded">
            <span className="text-slate-400">EXEC TIME: </span>
            <span className="text-emerald-400 font-bold">{execTimeMs} ms</span>
          </div>
        </div>
      </div>

      {/* Path Count Selector */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="text-xs font-bold text-white font-mono uppercase border-b border-slate-800 pb-2">
          Simulation Configuration & Performance Mode
        </h3>

        <div className="flex flex-wrap items-center gap-3">
          <span className="text-xs font-mono text-slate-300">SELECT PATH COUNT:</span>
          {[10, 100, 1000, 10000].map((count) => (
            <button
              key={count}
              onClick={() => setPathCount(count)}
              className={`px-4 py-2 text-xs font-mono font-bold rounded-lg transition-colors border ${
                pathCount === count
                  ? 'bg-blue-600 border-blue-500 text-white shadow'
                  : 'bg-[#141b28] border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              {count.toLocaleString()} PATHS
            </button>
          ))}
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-[#0f141e] border border-slate-800 p-4 rounded-xl">
          <span className="text-[10px] text-slate-400 block uppercase">Mean Weighted Avg Life (WAL)</span>
          <span className="text-2xl font-bold text-white">{mcSummary.meanWal.toFixed(2)} YRS</span>
          <span className="text-[10px] text-slate-500 block mt-1">Std Dev: ±{mcSummary.stdWal.toFixed(2)} yrs</span>
        </div>

        <div className="bg-[#0f141e] border border-slate-800 p-4 rounded-xl">
          <span className="text-[10px] text-slate-400 block uppercase">Mean Expected Credit Loss</span>
          <span className="text-2xl font-bold text-amber-400">£{(mcSummary.expectedLossMean / 1e6).toFixed(2)}m</span>
          <span className="text-[10px] text-slate-500 block mt-1">{(mcSummary.expectedLossMean / SIGNATURE_POOL_1.originalBalance * 100).toFixed(2)}% of Pool</span>
        </div>

        <div className="bg-[#0f141e] border border-slate-800 p-4 rounded-xl">
          <span className="text-[10px] text-red-400 block uppercase">95% Value at Risk (VaR 95)</span>
          <span className="text-2xl font-bold text-red-400">£{(mcSummary.var95 / 1e6).toFixed(2)}m</span>
          <span className="text-[10px] text-slate-500 block mt-1">95th Percentile Tail Loss</span>
        </div>

        <div className="bg-[#0f141e] border border-slate-800 p-4 rounded-xl">
          <span className="text-[10px] text-red-400 block uppercase">99% Value at Risk (VaR 99)</span>
          <span className="text-2xl font-bold text-red-400">£{(mcSummary.var99 / 1e6).toFixed(2)}m</span>
          <span className="text-[10px] text-slate-500 block mt-1">Extreme Stress Tail Loss</span>
        </div>
      </div>

      {/* Confidence Bands Chart (P10 / P50 / P90) */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-3">
        <div className="border-b border-slate-800 pb-2">
          <h4 className="text-xs font-bold text-white font-mono uppercase flex items-center gap-2">
            <BarChart className="w-4 h-4 text-blue-400" />
            Pool Balance Confidence Bands (P10 / P50 / P90 Percentiles)
          </h4>
          <p className="text-[11px] text-slate-400">360-month stochastic pool amortization bands</p>
        </div>

        <div className="h-72 pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={percentileChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="month" stroke="#64748b" tick={{ fontSize: 11 }} tickFormatter={(m) => `M${m}`} />
              <YAxis stroke="#64748b" tick={{ fontSize: 11 }} tickFormatter={(v) => `£${v}b`} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                formatter={(val: any) => [`£${val}bn`, 'Pool Balance']}
              />
              <Area type="monotone" dataKey="P90" name="P90 (Slow Prepay / High Rates)" stroke="#ef4444" fill="#ef4444" fillOpacity={0.1} />
              <Area type="monotone" dataKey="P50" name="P50 (Median Path)" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.2} />
              <Area type="monotone" dataKey="P10" name="P10 (Fast Prepay / Low Rates)" stroke="#10b981" fill="#10b981" fillOpacity={0.1} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* OAS Convergence Plot */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-3">
        <div className="border-b border-slate-800 pb-2">
          <h4 className="text-xs font-bold text-white font-mono uppercase">OAS Numerical Convergence Curve</h4>
          <p className="text-[11px] text-slate-400">Convergence of Option-Adjusted Spread as sample path count increases</p>
        </div>

        <div className="h-48 pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={mcSummary.oasConvergence}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="path" stroke="#64748b" tick={{ fontSize: 11 }} />
              <YAxis stroke="#64748b" domain={[100, 200]} tick={{ fontSize: 11 }} tickFormatter={(v) => `${v}bps`} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                formatter={(val: any) => [`${val} bps`, 'OAS']}
              />
              <Line type="monotone" dataKey="oas" stroke="#f59e0b" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
