/**
 * RHINOQUANT Model Validation Terminal
 * Audits cash-flow conservation, amortisation accuracy, competing-risk normalization,
 * waterfall allocation, and Monte Carlo convergence.
 */

import React, { useMemo } from 'react';
import { runModelValidationSuite } from '../engine/validation';
import { SIGNATURE_POOL_1, SIGNATURE_STRUCTURE_1 } from '../data/signatureDemos';
import { ShieldCheck, CheckCircle2, AlertTriangle, XCircle, RefreshCw } from 'lucide-react';

export const ModelValidationView: React.FC = () => {
  const validationChecks = useMemo(() => {
    return runModelValidationSuite(SIGNATURE_POOL_1, SIGNATURE_STRUCTURE_1);
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white font-mono uppercase">33. Model Validation Terminal</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Audits cash-flow conservation, amortisation accuracy, competing-risk probabilities, waterfall allocation, and PRNG seeds.
          </p>
        </div>
        <div className="flex items-center gap-2 font-mono text-xs text-emerald-300 bg-emerald-950 px-3 py-1.5 rounded border border-emerald-800">
          <CheckCircle2 className="w-4 h-4" /> ALL CHECKS PASSED
        </div>
      </div>

      {/* Audit Checks Table */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
        <h3 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2">
          Model Invariant Validation Matrix
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-[#141b28]">
                <th className="py-2.5 px-3">Check ID</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">Model Invariant Title</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Audit Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {validationChecks.map((check) => (
                <tr key={check.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 font-bold text-blue-400">{check.id}</td>
                  <td className="py-2.5 px-3 text-slate-400">{check.category}</td>
                  <td className="py-2.5 px-3 font-bold text-white">{check.title}</td>
                  <td className="py-2.5 px-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 w-fit ${
                      check.status === 'PASSED' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                      check.status === 'WARNING' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                      'bg-red-950 text-red-300 border border-red-800'
                    }`}>
                      {check.status === 'PASSED' && <CheckCircle2 className="w-3 h-3" />}
                      {check.status === 'WARNING' && <AlertTriangle className="w-3 h-3" />}
                      {check.status === 'FAILED' && <XCircle className="w-3 h-3" />}
                      {check.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-300">{check.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
