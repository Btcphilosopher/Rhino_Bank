/**
 * RHINOQUANT Securitisation & CMO Lab
 * SPV Waterfall builder, explicit cash allocation, tranche editor, and loss absorption audit.
 */

import React, { useState, useMemo } from 'react';
import { SIGNATURE_STRUCTURE_1, SIGNATURE_POOL_1, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS } from '../data/signatureDemos';
import { runSecuritisationWaterfall } from '../engine/waterfall';
import { simulatePoolCashFlows } from '../engine/pools';
import { SecuritisationStructure, Tranche } from '../types';
import { Layers, ArrowDown, Plus, Trash2, CheckCircle2, DollarSign } from 'lucide-react';

export const CMOLab: React.FC = () => {
  const [structure, setStructure] = useState<SecuritisationStructure>(SIGNATURE_STRUCTURE_1);

  // Pool cash flows over 360 months
  const marketRates = useMemo(() => new Array(360).fill(4.50), []);
  const poolCashFlows = useMemo(() => {
    return simulatePoolCashFlows(SIGNATURE_POOL_1, marketRates, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS, 360);
  }, [marketRates]);

  // Run Waterfall Execution
  const waterfallResult = useMemo(() => {
    return runSecuritisationWaterfall(structure, poolCashFlows);
  }, [structure, poolCashFlows]);

  // Calculate totals
  const totalPoolCash = useMemo(() => {
    return poolCashFlows.reduce((sum, c) => sum + c.totalCashFlow, 0);
  }, [poolCashFlows]);

  // Handlers to edit tranches
  const handleCouponChange = (trancheId: string, newCoupon: number) => {
    setStructure((prev) => ({
      ...prev,
      tranches: prev.tranches.map((t) => (t.id === trancheId ? { ...t, couponRate: newCoupon } : t)),
    }));
  };

  const handleNotionalChange = (trancheId: string, newNotional: number) => {
    setStructure((prev) => ({
      ...prev,
      tranches: prev.tranches.map((t) => (t.id === trancheId ? { ...t, notional: newNotional } : t)),
    }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono bg-blue-950 text-blue-300 border border-blue-800 px-2 py-0.5 rounded">
              SPV: {structure.spvName}
            </span>
            <h2 className="text-lg font-bold text-white font-mono uppercase">CMO Structuring & Waterfall Lab</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Construct synthetic CMO tranche structures, define waterfall seniority, and audit priority of payments.
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="bg-[#141b28] border border-slate-800 px-3 py-1.5 rounded">
            <span className="text-slate-400">TOTAL NOTIONAL: </span>
            <span className="text-white font-bold">£{(structure.totalNotional / 1e9).toFixed(2)}bn</span>
          </div>
        </div>
      </div>

      {/* Explicit Waterfall Flowchart Diagram */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="text-xs font-bold text-white font-mono uppercase flex items-center gap-2 border-b border-slate-800 pb-2">
          <Layers className="w-4 h-4 text-blue-400" />
          15. Explicit Cash Flow Priority Waterfall Diagram
        </h3>

        <div className="flex flex-col items-center space-y-2 font-mono text-xs max-w-2xl mx-auto py-2">
          <div className="bg-blue-950/80 border border-blue-700 text-blue-200 px-4 py-2 rounded-lg font-bold text-center w-full shadow">
            POOL CASH FLOW (Scheduled Principal + Prepayment + Interest + Recovery) = £{(totalPoolCash / 1e9).toFixed(2)}bn
          </div>
          <ArrowDown className="w-4 h-4 text-slate-500 my-0.5" />

          <div className="bg-emerald-950/80 border border-emerald-700 text-emerald-200 px-4 py-1.5 rounded text-center w-full">
            SENIOR INTEREST (Class A AAA Notes @ {structure.tranches.find((t) => t.ratingLabel === 'AAA')?.couponRate}% Coupon)
          </div>
          <ArrowDown className="w-4 h-4 text-slate-500 my-0.5" />

          <div className="bg-emerald-950/80 border border-emerald-700 text-emerald-200 px-4 py-1.5 rounded text-center w-full">
            SENIOR PRINCIPAL (Sequential Paydown until Class A Par = £0)
          </div>
          <ArrowDown className="w-4 h-4 text-slate-500 my-0.5" />

          <div className="bg-blue-950/80 border border-blue-700 text-blue-200 px-4 py-1.5 rounded text-center w-full">
            MEZZANINE INTEREST & PRINCIPAL (Class B AA Notes @ {structure.tranches.find((t) => t.ratingLabel === 'AA')?.couponRate}% Coupon)
          </div>
          <ArrowDown className="w-4 h-4 text-slate-500 my-0.5" />

          <div className="bg-amber-950/80 border border-amber-700 text-amber-200 px-4 py-1.5 rounded text-center w-full">
            SUBORDINATED INTEREST & PRINCIPAL (Class C BBB Notes)
          </div>
          <ArrowDown className="w-4 h-4 text-slate-500 my-0.5" />

          <div className="bg-red-950/80 border border-red-700 text-red-200 px-4 py-1.5 rounded text-center w-full font-bold">
            RESIDUAL / EQUITY CERTIFICATES (First Loss Buffer & Excess Interest)
          </div>
        </div>
      </div>

      {/* Tranche Structure Table & Waterfall Results */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="text-xs font-bold text-white font-mono uppercase flex items-center gap-2 border-b border-slate-800 pb-2">
          <DollarSign className="w-4 h-4 text-emerald-400" />
          Tranche Capital Structure & Simulated Waterfall Disbursements
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-[#141b28]">
                <th className="py-2.5 px-3">Tranche Name</th>
                <th className="py-2.5 px-3">Rating</th>
                <th className="py-2.5 px-3">Rank</th>
                <th className="py-2.5 px-3">Notional (£)</th>
                <th className="py-2.5 px-3">Coupon (%)</th>
                <th className="py-2.5 px-3">Attach / Detach</th>
                <th className="py-2.5 px-3">Total Interest Recv</th>
                <th className="py-2.5 px-3">Total Prin Recv</th>
                <th className="py-2.5 px-3">Loss Absorbed</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {structure.tranches.map((t) => {
                const interestPaid = waterfallResult.totalInterestPaid[t.id] || 0;
                const principalPaid = waterfallResult.totalPrincipalPaid[t.id] || 0;
                const lossAbsorbed = waterfallResult.totalLossesAbsorbed[t.id] || 0;

                return (
                  <tr key={t.id} className="hover:bg-slate-800/40">
                    <td className="py-2.5 px-3 font-semibold text-white">{t.name}</td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        t.ratingLabel === 'AAA' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                        t.ratingLabel === 'AA' ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                        t.ratingLabel === 'BBB' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                        'bg-red-950 text-red-300 border border-red-800'
                      }`}>
                        {t.ratingLabel}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">Rank {t.rank}</td>
                    <td className="py-2.5 px-3">
                      <input
                        type="number"
                        step="10000000"
                        value={t.notional}
                        onChange={(e) => handleNotionalChange(t.id, Number(e.target.value))}
                        className="w-32 bg-[#161c28] border border-slate-700 rounded px-2 py-1 text-white font-mono focus:border-blue-500 outline-none"
                      />
                    </td>
                    <td className="py-2.5 px-3">
                      <input
                        type="number"
                        step="0.05"
                        value={t.couponRate}
                        onChange={(e) => handleCouponChange(t.id, Number(e.target.value))}
                        className="w-20 bg-[#161c28] border border-slate-700 rounded px-2 py-1 text-amber-400 font-mono focus:border-blue-500 outline-none"
                      />
                    </td>
                    <td className="py-2.5 px-3 text-slate-400">{t.attachmentPoint}% - {t.detachmentPoint}%</td>
                    <td className="py-2.5 px-3 text-amber-300 font-bold">£{(interestPaid / 1e6).toFixed(2)}m</td>
                    <td className="py-2.5 px-3 text-emerald-300 font-bold">£{(principalPaid / 1e6).toFixed(2)}m</td>
                    <td className="py-2.5 px-3 text-red-400 font-bold">£{Math.round(lossAbsorbed).toLocaleString()}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
