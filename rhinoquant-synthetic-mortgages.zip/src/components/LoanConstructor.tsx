/**
 * RHINOQUANT Borrower & Property Engine & Mortgage Constructor
 * Construct synthetic mortgage loans, generate monthly amortisation tables, and observe loan state transitions.
 */

import React, { useState, useMemo } from 'react';
import { Region, PropertyType, LoanType, SyntheticMortgage } from '../types';
import { generateAmortisationSchedule } from '../engine/amortisation';
import { Calculator, Download, Table, CheckCircle2, ShieldAlert, FastForward, Clock } from 'lucide-react';

export const LoanConstructor: React.FC = () => {
  // Inputs for constructing a loan
  const [loanAmount, setLoanAmount] = useState<number>(250000);
  const [propertyValue, setPropertyValue] = useState<number>(350000);
  const [interestRate, setInterestRate] = useState<number>(4.75);
  const [termYears, setTermYears] = useState<number>(25);
  const [loanType, setLoanType] = useState<LoanType>('AMORTISING');
  const [region, setRegion] = useState<Region>('LONDON');
  const [propertyType, setPropertyType] = useState<PropertyType>('SEMI_DETACHED');
  const [creditScore, setCreditScore] = useState<number>(740);
  const [dti, setDti] = useState<number>(32);
  const [extraMonthlyPayment, setExtraMonthlyPayment] = useState<number>(0);

  // Prepayment & Default simulation overlays
  const [cprOverlay, setCprOverlay] = useState<number>(6.0);
  const [cdrOverlay, setCdrOverlay] = useState<number>(1.0);

  const ltv = useMemo(() => {
    return propertyValue > 0 ? Number(((loanAmount / propertyValue) * 100).toFixed(1)) : 0;
  }, [loanAmount, propertyValue]);

  // Generate 360-month amortisation schedule
  const amortisationSummary = useMemo(() => {
    return generateAmortisationSchedule({
      loanAmount,
      annualRate: interestRate,
      termMonths: termYears * 12,
      loanType,
      extraMonthlyPayment,
      monthlyPrepaymentSMM: (1 - Math.pow(1 - cprOverlay / 100, 1 / 12)),
      monthlyDefaultMDR: (1 - Math.pow(1 - cdrOverlay / 100, 1 / 12)),
      recoveryRate: 0.85,
    });
  }, [loanAmount, interestRate, termYears, loanType, extraMonthlyPayment, cprOverlay, cdrOverlay]);

  const [page, setPage] = useState<number>(1);
  const pageSize = 24; // Show 2 years per table page

  const paginatedSchedule = useMemo(() => {
    const start = (page - 1) * pageSize;
    return amortisationSummary.schedule.slice(start, start + pageSize);
  }, [amortisationSummary.schedule, page]);

  const totalPages = Math.ceil(amortisationSummary.schedule.length / pageSize);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white font-mono uppercase flex items-center gap-2">
            <Calculator className="w-5 h-5 text-blue-400" />
            Synthetic Borrower, Property & Mortgage Constructor
          </h2>
          <p className="text-xs text-slate-400">
            Construct synthetic mortgage contracts, parameterize amortisation schedules, and test extra payments or stress overlays.
          </p>
        </div>
        <div className="flex items-center gap-2 font-mono text-xs">
          <div className="bg-slate-800/90 border border-slate-700/80 px-3 py-1.5 rounded">
            <span className="text-slate-400">CALCULATED LTV: </span>
            <span className={`font-bold ${ltv > 80 ? 'text-amber-400' : 'text-emerald-400'}`}>{ltv}%</span>
          </div>
          <div className="bg-slate-800/90 border border-slate-700/80 px-3 py-1.5 rounded">
            <span className="text-slate-400">TERM: </span>
            <span className="text-white font-bold">{termYears * 12} MOS</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Inputs Panel */}
        <div className="lg:col-span-4 bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider border-b border-slate-800 pb-2">
            Mortgage & Borrower Parameters
          </h3>

          <div className="space-y-3 text-xs">
            {/* Loan Amount & Property Value */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Loan Amount (£)</label>
                <input
                  type="number"
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(Number(e.target.value))}
                  className="w-full bg-[#161c28] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono focus:border-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Property Value (£)</label>
                <input
                  type="number"
                  value={propertyValue}
                  onChange={(e) => setPropertyValue(Number(e.target.value))}
                  className="w-full bg-[#161c28] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Rate & Term */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Interest Rate (%)</label>
                <input
                  type="number"
                  step="0.05"
                  value={interestRate}
                  onChange={(e) => setInterestRate(Number(e.target.value))}
                  className="w-full bg-[#161c28] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono focus:border-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Term (Years)</label>
                <input
                  type="number"
                  value={termYears}
                  onChange={(e) => setTermYears(Number(e.target.value))}
                  className="w-full bg-[#161c28] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Amortisation Type */}
            <div>
              <label className="text-slate-400 block mb-1">Amortisation Structure</label>
              <select
                value={loanType}
                onChange={(e) => setLoanType(e.target.value as LoanType)}
                className="w-full bg-[#161c28] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono focus:border-blue-500 outline-none"
              >
                <option value="AMORTISING">AMORTISING (Repayment)</option>
                <option value="INTEREST_ONLY">INTEREST ONLY</option>
                <option value="FIXED_RATE">FIXED RATE (2-Year/5-Year)</option>
                <option value="TRACKER">TRACKER-LIKE RATE</option>
              </select>
            </div>

            {/* Region & Property Type */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Region</label>
                <select
                  value={region}
                  onChange={(e) => setRegion(e.target.value as Region)}
                  className="w-full bg-[#161c28] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono focus:border-blue-500 outline-none"
                >
                  <option value="LONDON">LONDON</option>
                  <option value="SOUTH_EAST">SOUTH EAST</option>
                  <option value="NORTH_WEST">NORTH WEST</option>
                  <option value="YORKSHIRE">YORKSHIRE</option>
                  <option value="WEST_MIDLANDS">WEST MIDLANDS</option>
                  <option value="EAST_ANGLIA">EAST ANGLIA</option>
                  <option value="SOUTH_WEST">SOUTH WEST</option>
                  <option value="WALES">WALES</option>
                  <option value="SCOTLAND">SCOTLAND</option>
                  <option value="NORTHERN_IRELAND">NORTHERN IRELAND</option>
                </select>
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Property Type</label>
                <select
                  value={propertyType}
                  onChange={(e) => setPropertyType(e.target.value as PropertyType)}
                  className="w-full bg-[#161c28] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono focus:border-blue-500 outline-none"
                >
                  <option value="DETACHED">DETACHED</option>
                  <option value="SEMI_DETACHED">SEMI DETACHED</option>
                  <option value="TERRACED">TERRACED</option>
                  <option value="FLAT_MAISONETTE">FLAT / MAISONETTE</option>
                  <option value="BUNGALOW">BUNGALOW</option>
                </select>
              </div>
            </div>

            {/* Credit Score & DTI */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Credit Score (300-850)</label>
                <input
                  type="number"
                  value={creditScore}
                  onChange={(e) => setCreditScore(Number(e.target.value))}
                  className="w-full bg-[#161c28] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono focus:border-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">DTI Ratio (%)</label>
                <input
                  type="number"
                  value={dti}
                  onChange={(e) => setDti(Number(e.target.value))}
                  className="w-full bg-[#161c28] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Extra Monthly Payment */}
            <div className="pt-2 border-t border-slate-800">
              <label className="text-blue-400 font-semibold block mb-1">Extra Monthly Payment (£)</label>
              <input
                type="number"
                step="50"
                value={extraMonthlyPayment}
                onChange={(e) => setExtraMonthlyPayment(Number(e.target.value))}
                className="w-full bg-[#161c28] border border-blue-800/80 rounded px-2.5 py-1.5 text-white font-mono focus:border-blue-500 outline-none"
              />
              <p className="text-[10px] text-slate-500 mt-1">Accelerates principal repayment and shortens loan maturity.</p>
            </div>

            {/* CPR & CDR Overlays */}
            <div className="pt-2 border-t border-slate-800 grid grid-cols-2 gap-3">
              <div>
                <label className="text-amber-400 font-semibold block mb-1">Prepayment CPR (%)</label>
                <input
                  type="number"
                  step="0.5"
                  value={cprOverlay}
                  onChange={(e) => setCprOverlay(Number(e.target.value))}
                  className="w-full bg-[#161c28] border border-amber-800/80 rounded px-2.5 py-1.5 text-white font-mono focus:border-amber-500 outline-none"
                />
              </div>
              <div>
                <label className="text-red-400 font-semibold block mb-1">Default CDR (%)</label>
                <input
                  type="number"
                  step="0.1"
                  value={cdrOverlay}
                  onChange={(e) => setCdrOverlay(Number(e.target.value))}
                  className="w-full bg-[#161c28] border border-red-800/80 rounded px-2.5 py-1.5 text-white font-mono focus:border-red-500 outline-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Output Amortisation Schedule & State Machine */}
        <div className="lg:col-span-8 space-y-5">
          {/* Summary KPIs */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono">
            <div className="bg-[#0f141e] border border-slate-800 p-3 rounded-lg">
              <span className="text-[10px] text-slate-400 block uppercase">Total Interest</span>
              <span className="text-base font-bold text-white">£{Math.round(amortisationSummary.totalInterestPaid).toLocaleString()}</span>
            </div>
            <div className="bg-[#0f141e] border border-slate-800 p-3 rounded-lg">
              <span className="text-[10px] text-slate-400 block uppercase">Total Principal</span>
              <span className="text-base font-bold text-white">£{Math.round(amortisationSummary.totalPrincipalPaid).toLocaleString()}</span>
            </div>
            <div className="bg-[#0f141e] border border-slate-800 p-3 rounded-lg">
              <span className="text-[10px] text-amber-400 block uppercase">Total Prepayments</span>
              <span className="text-base font-bold text-amber-300">£{Math.round(amortisationSummary.totalPrepaymentPaid).toLocaleString()}</span>
            </div>
            <div className="bg-[#0f141e] border border-slate-800 p-3 rounded-lg">
              <span className="text-[10px] text-emerald-400 block uppercase">Actual Term</span>
              <span className="text-base font-bold text-emerald-300">{amortisationSummary.actualTermMonths} MOS</span>
            </div>
          </div>

          {/* Mortgage State Machine Visualizer */}
          <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-4 space-y-2">
            <span className="text-xs font-bold font-mono text-slate-300 uppercase block">6. Mortgage State Machine Transition Pipeline</span>
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
              <span className="px-2.5 py-1 rounded bg-emerald-950 border border-emerald-800 text-emerald-300 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> CURRENT
              </span>
              <span>→</span>
              <span className="px-2.5 py-1 rounded bg-amber-950 border border-amber-800 text-amber-300 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" /> DELINQUENT
              </span>
              <span>→</span>
              <span className="px-2.5 py-1 rounded bg-red-950 border border-red-800 text-red-300 flex items-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5" /> DEFAULT
              </span>
              <span>or</span>
              <span className="px-2.5 py-1 rounded bg-blue-950 border border-blue-800 text-blue-300 flex items-center gap-1">
                <FastForward className="w-3.5 h-3.5" /> PREPAID
              </span>
            </div>
          </div>

          {/* Amortisation Table */}
          <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h4 className="text-xs font-bold text-white font-mono uppercase flex items-center gap-2">
                <Table className="w-4 h-4 text-blue-400" />
                Amortisation Cash Flow Schedule
              </h4>
              <div className="flex items-center gap-2 text-xs font-mono">
                <button
                  disabled={page <= 1}
                  onClick={() => setPage(page - 1)}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 rounded"
                >
                  Prev
                </button>
                <span className="text-slate-400">Page {page} / {totalPages}</span>
                <button
                  disabled={page >= totalPages}
                  onClick={() => setPage(page + 1)}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 rounded"
                >
                  Next
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 bg-[#141b28]">
                    <th className="py-2 px-2">Month</th>
                    <th className="py-2 px-2">Date</th>
                    <th className="py-2 px-2">Opening (£)</th>
                    <th className="py-2 px-2">Interest (£)</th>
                    <th className="py-2 px-2">Principal (£)</th>
                    <th className="py-2 px-2">Prepay (£)</th>
                    <th className="py-2 px-2">Closing (£)</th>
                    <th className="py-2 px-2">State</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {paginatedSchedule.map((row) => (
                    <tr key={row.month} className="hover:bg-slate-800/40">
                      <td className="py-2 px-2 text-slate-300">{row.month}</td>
                      <td className="py-2 px-2 text-slate-400">{row.date}</td>
                      <td className="py-2 px-2 text-slate-200">£{Math.round(row.openingBalance).toLocaleString()}</td>
                      <td className="py-2 px-2 text-amber-400">£{Math.round(row.interestPaid).toLocaleString()}</td>
                      <td className="py-2 px-2 text-emerald-400">£{Math.round(row.principalPaid).toLocaleString()}</td>
                      <td className="py-2 px-2 text-blue-400">£{Math.round(row.prepayment).toLocaleString()}</td>
                      <td className="py-2 px-2 font-bold text-white">£{Math.round(row.closingBalance).toLocaleString()}</td>
                      <td className="py-2 px-2">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                          row.state === 'CURRENT' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                          row.state === 'PREPAID' ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                          'bg-amber-950 text-amber-300 border border-amber-800'
                        }`}>
                          {row.state}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
