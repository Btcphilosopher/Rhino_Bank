/**
 * RHINOQUANT Rate Path Engine & Option-Adjusted Spread (OAS) Solver
 * Synthetic rate paths (Flat, Rising, Falling, Mean Reverting, Volatile) and OAS Newton-Raphson Solver.
 */

import React, { useState, useMemo } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { SIGNATURE_POOL_1, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS } from '../data/signatureDemos';
import { generateVasicekRatePath } from '../engine/montecarlo';
import { DeterministicPRNG } from '../engine/prng';
import { solveOas } from '../engine/pricing';
import { simulatePoolCashFlows } from '../engine/pools';
import { Activity, Sliders, Zap, DollarSign } from 'lucide-react';

export const RatePathOASView: React.FC = () => {
  const [rateModel, setRateModel] = useState<'FLAT' | 'RISING' | 'FALLING' | 'MEAN_REVERTING' | 'VOLATILE'>('MEAN_REVERTING');
  const [marketPrice, setMarketPrice] = useState<number>(98.50);

  // Generate 5 rate paths for visualization
  const ratePathsData = useMemo(() => {
    const prng = new DeterministicPRNG(2032);
    const pathsCount = 5;
    const paths: number[][] = [];

    for (let p = 0; p < pathsCount; p++) {
      let r0 = 4.50;
      let a = 0.20;
      let b = 3.50;
      let sigma = 0.012;

      if (rateModel === 'FLAT') {
        paths.push(new Array(360).fill(4.50));
        continue;
      } else if (rateModel === 'RISING') {
        b = 6.50;
      } else if (rateModel === 'FALLING') {
        b = 2.00;
      } else if (rateModel === 'VOLATILE') {
        sigma = 0.035;
      }

      const path = generateVasicekRatePath({ r0, a, b, sigma }, 360, prng);
      paths.push(path);
    }

    // Chart points
    const points = [];
    for (let m = 0; m < 360; m += 6) {
      points.push({
        month: m,
        Path1: Number((paths[0][m] || 4.5).toFixed(2)),
        Path2: Number((paths[1][m] || 4.5).toFixed(2)),
        Path3: Number((paths[2][m] || 4.5).toFixed(2)),
        Path4: Number((paths[3][m] || 4.5).toFixed(2)),
        Path5: Number((paths[4][m] || 4.5).toFixed(2)),
      });
    }

    return { points, rawPaths: paths };
  }, [rateModel]);

  // Solve OAS for selected market price
  const oasResult = useMemo(() => {
    const simCfs = ratePathsData.rawPaths.map((path) => {
      return simulatePoolCashFlows(SIGNATURE_POOL_1, path, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS, 360);
    });

    const targetPriceAbs = (SIGNATURE_POOL_1.originalBalance * marketPrice) / 100;
    return solveOas(simCfs, ratePathsData.rawPaths, targetPriceAbs);
  }, [ratePathsData, marketPrice]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white font-mono uppercase flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-400" />
            18 & 19. Rate Path Engine & Option-Adjusted Spread (OAS) Solver
          </h2>
          <p className="text-xs text-slate-400">
            Calculates OAS by stripping out embedded borrower prepayment optionality across simulated interest rate paths.
          </p>
        </div>
      </div>

      {/* Controls & OAS KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 font-mono text-xs">
        {/* Model Selection */}
        <div className="md:col-span-5 bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-blue-400" /> Rate Path Generator Parameters
          </h3>

          <div className="space-y-3">
            <div>
              <label className="text-slate-400 block mb-1">Interest Rate Path Model</label>
              <select
                value={rateModel}
                onChange={(e) => setRateModel(e.target.value as any)}
                className="w-full bg-[#161c28] border border-slate-700 rounded px-2.5 py-1.5 text-white focus:border-blue-500 outline-none"
              >
                <option value="MEAN_REVERTING">MEAN REVERTING (Vasicek Model)</option>
                <option value="RISING">RISING RATE PATH (+200bps Target)</option>
                <option value="FALLING">FALLING RATE PATH (-250bps Target)</option>
                <option value="VOLATILE">HIGH VOLATILITY RATE SHIFT</option>
                <option value="FLAT">FLAT BASELINE CURVE</option>
              </select>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Synthetic Market Price (Par = 100):</span>
                <span className="font-bold text-emerald-400">{marketPrice.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="85.0"
                max="105.0"
                step="0.25"
                value={marketPrice}
                onChange={(e) => setMarketPrice(Number(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* OAS Result Summary */}
        <div className="md:col-span-7 bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-3">
          <h3 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2 flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" /> OAS Solver Output
          </h3>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#141b28] border border-slate-800 p-4 rounded-lg">
              <span className="text-[10px] text-slate-400 block uppercase">Option-Adjusted Spread (OAS)</span>
              <span className="text-2xl font-bold text-amber-400">{oasResult.oasBps} BPS</span>
              <p className="text-[10px] text-slate-500 mt-1">Spread above base curve after removing prepayment option cost.</p>
            </div>

            <div className="bg-[#141b28] border border-slate-800 p-4 rounded-lg">
              <span className="text-[10px] text-slate-400 block uppercase">Target Market Clean Price</span>
              <span className="text-2xl font-bold text-white">{marketPrice.toFixed(2)}</span>
              <p className="text-[10px] text-slate-500 mt-1">Consistent with expected present value across simulated paths.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Rate Paths Chart */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-3">
        <div className="border-b border-slate-800 pb-2">
          <h4 className="text-xs font-bold text-white font-mono uppercase">Simulated 360-Month Interest Rate Paths</h4>
          <p className="text-[11px] text-slate-400">Vasicek mean-reverting interest rate trajectories</p>
        </div>

        <div className="h-72 pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={ratePathsData.points}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="month" stroke="#64748b" tick={{ fontSize: 11 }} tickFormatter={(m) => `M${m}`} />
              <YAxis stroke="#64748b" domain={[0, 10]} tick={{ fontSize: 11 }} tickFormatter={(v) => `${v}%`} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                formatter={(val: any) => [`${val}%`, 'Rate']}
              />
              <Line type="monotone" dataKey="Path1" stroke="#3b82f6" strokeWidth={1.5} dot={false} />
              <Line type="monotone" dataKey="Path2" stroke="#10b981" strokeWidth={1.5} dot={false} />
              <Line type="monotone" dataKey="Path3" stroke="#f59e0b" strokeWidth={1.5} dot={false} />
              <Line type="monotone" dataKey="Path4" stroke="#ec4899" strokeWidth={1.5} dot={false} />
              <Line type="monotone" dataKey="Path5" stroke="#8b5cf6" strokeWidth={1.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
