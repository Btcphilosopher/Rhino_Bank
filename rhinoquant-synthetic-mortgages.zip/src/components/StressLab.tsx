/**
 * RHINOQUANT Stress Lab Terminal
 * Evaluates 10 macroeconomic scenarios across LOAN → POOL → MBS → TRANCHES.
 */

import React, { useState, useMemo } from 'react';
import { STRESS_SCENARIOS, SIGNATURE_POOL_1, SIGNATURE_STRUCTURE_1, BASE_PREPAY_PARAMS, BASE_DEFAULT_PARAMS } from '../data/signatureDemos';
import { simulatePoolCashFlows } from '../engine/pools';
import { runSecuritisationWaterfall } from '../engine/waterfall';
import { StressScenario } from '../types';
import { ShieldAlert, Play, ArrowRight, Zap, Layers } from 'lucide-react';

export const StressLab: React.FC = () => {
  const [selectedScenario, setSelectedScenario] = useState<StressScenario>(STRESS_SCENARIOS[0]);

  // Run Pool & Securitisation under selected stress scenario
  const stressResults = useMemo(() => {
    const marketRates = new Array(360).fill(4.62 + selectedScenario.rateShiftBps / 100);

    const prepayParams = {
      ...BASE_PREPAY_PARAMS,
      baseCPR: BASE_PREPAY_PARAMS.baseCPR * selectedScenario.prepaymentMultiplier,
    };

    const defaultParams = {
      ...BASE_DEFAULT_PARAMS,
      baseCDR: BASE_DEFAULT_PARAMS.baseCDR * selectedScenario.defaultMultiplier,
      hpiChange: selectedScenario.hpiShiftPct,
      unemploymentShock: selectedScenario.unemploymentShockPct,
    };

    const cfs = simulatePoolCashFlows(SIGNATURE_POOL_1, marketRates, prepayParams, defaultParams, 360);
    const waterfall = runSecuritisationWaterfall(SIGNATURE_STRUCTURE_1, cfs);

    const totalLosses = cfs.reduce((sum, c) => sum + c.lossAmount, 0);

    return { cfs, waterfall, totalLosses };
  }, [selectedScenario]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white font-mono uppercase flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-400" />
            25. Stress Testing Laboratory
          </h2>
          <p className="text-xs text-slate-400">
            Simulate macro shocks across LOAN → POOL → MBS → TRANCHES and evaluate loss absorption across the SPV structure.
          </p>
        </div>
      </div>

      {/* Scenario Selection Grid */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-3 font-mono text-xs">
        <h3 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2">
          Select Macroeconomic Stress Scenario
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {STRESS_SCENARIOS.map((sc) => {
            const isSelected = selectedScenario.id === sc.id;
            return (
              <div
                key={sc.id}
                onClick={() => setSelectedScenario(sc)}
                className={`p-3 rounded-lg border cursor-pointer transition-all space-y-1 ${
                  isSelected
                    ? 'bg-blue-950/80 border-blue-500 shadow-md'
                    : 'bg-[#141b28] border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between font-bold text-white">
                  <span>{sc.name}</span>
                  {isSelected && <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400/20" />}
                </div>
                <p className="text-[11px] text-slate-400 leading-snug">{sc.description}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Stress Impact Breakdown Across Hierarchy */}
      <div className="bg-[#0f141e] border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
        <h3 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2 flex items-center gap-2">
          <Layers className="w-4 h-4 text-blue-400" />
          LOAN → POOL → MBS → TRANCHES Impact Analysis for [{selectedScenario.name}]
        </h3>

        {/* Tranche Loss Absorption Matrix */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-[#141b28]">
                <th className="py-2.5 px-3">Tranche</th>
                <th className="py-2.5 px-3">Rating</th>
                <th className="py-2.5 px-3">Original Notional (£)</th>
                <th className="py-2.5 px-3">Loss Absorbed (£)</th>
                <th className="py-2.5 px-3">Loss %</th>
                <th className="py-2.5 px-3">Tranche Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {SIGNATURE_STRUCTURE_1.tranches.map((t) => {
                const loss = stressResults.waterfall.totalLossesAbsorbed[t.id] || 0;
                const lossPct = t.notional > 0 ? (loss / t.notional) * 100 : 0;

                return (
                  <tr key={t.id} className="hover:bg-slate-800/40">
                    <td className="py-2.5 px-3 font-bold text-white">{t.name}</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-200">
                        {t.ratingLabel}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">£{(t.notional / 1e6).toFixed(0)}m</td>
                    <td className="py-2.5 px-3 text-red-400 font-bold">£{Math.round(loss).toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-red-300 font-bold">{lossPct.toFixed(2)}%</td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        lossPct === 0 ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                        lossPct < 100 ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                        'bg-red-950 text-red-300 border border-red-800'
                      }`}>
                        {lossPct === 0 ? 'IMPAIRED = 0%' : lossPct < 100 ? 'PARTIAL IMPAIRMENT' : 'TOTAL IMPAIRMENT'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
