/**
 * RHINOQUANT Signature Demos Dataset & Pre-configured Scenarios
 * Institutional flagship portfolios for demonstration and research.
 */

import { MortgagePool, SecuritisationStructure, StressScenario, PrepaymentModelParams, DefaultModelParams } from '../types';
import { generateSyntheticLoans } from '../engine/generator';
import { calculatePoolMetrics } from '../engine/pools';

// Generate 500 representative sample loans for high-precision instant demo calculations
const DEMO_1_LOANS = generateSyntheticLoans(500, 2032);

const POOL_METRICS_50K = calculatePoolMetrics(DEMO_1_LOANS);

export const SIGNATURE_POOL_1: MortgagePool = {
  id: 'RQ-UK-MBS-2032-001',
  name: 'RhinoQuant UK Prime Mortgages 2032-1',
  loanCount: 50000,
  originalBalance: 9400000000, // £9.4bn
  currentBalance: 9400000000,
  wac: 4.62,
  wal: 7.42,
  wam: 300, // 25 years
  weightedLtv: 68.0,
  weightedCreditScore: 742,
  averageBalance: 188000,
  originationYear: 2026,
  geographicDistribution: POOL_METRICS_50K.geographicDistribution,
  creditDistribution: POOL_METRICS_50K.creditDistribution,
  propertyDistribution: POOL_METRICS_50K.propertyDistribution,
  loans: DEMO_1_LOANS,
};

export const SIGNATURE_STRUCTURE_1: SecuritisationStructure = {
  id: 'SPV-UK-2032-1',
  poolId: 'RQ-UK-MBS-2032-001',
  spvName: 'RhinoQuant Securitised Mortgage Issuer PLC 2032-1',
  totalNotional: 9400000000,
  waterfallType: 'SEQUENTIAL',
  tranches: [
    {
      id: 'TR-AAA',
      name: 'Class A Senior Notes',
      ratingLabel: 'AAA',
      rank: 1,
      notional: 7520000000, // 80%
      couponRate: 4.10,
      attachmentPoint: 20.0,
      detachmentPoint: 100.0,
      expectedWal: 5.2,
      expectedLoss: 0.02,
      duration: 4.3,
      convexity: 0.22,
      price: 99.85,
      yield: 4.15,
      oas: 65,
    },
    {
      id: 'TR-AA',
      name: 'Class B Mezzanine Notes',
      ratingLabel: 'AA',
      rank: 2,
      notional: 940000000, // 10%
      couponRate: 5.25,
      attachmentPoint: 10.0,
      detachmentPoint: 20.0,
      expectedWal: 7.8,
      expectedLoss: 0.35,
      duration: 6.1,
      convexity: 0.35,
      price: 98.40,
      yield: 5.52,
      oas: 180,
    },
    {
      id: 'TR-BBB',
      name: 'Class C Subordinated Notes',
      ratingLabel: 'BBB',
      rank: 3,
      notional: 470000000, // 5%
      couponRate: 6.80,
      attachmentPoint: 5.0,
      detachmentPoint: 10.0,
      expectedWal: 9.4,
      expectedLoss: 1.85,
      duration: 7.2,
      convexity: 0.48,
      price: 96.10,
      yield: 7.40,
      oas: 340,
    },
    {
      id: 'TR-EQUITY',
      name: 'Class R Residual Certificates',
      ratingLabel: 'EQUITY',
      rank: 4,
      notional: 470000000, // 5%
      couponRate: 9.50,
      attachmentPoint: 0.0,
      detachmentPoint: 5.0,
      expectedWal: 11.2,
      expectedLoss: 8.50,
      duration: 8.5,
      convexity: -0.85,
      price: 91.20,
      yield: 11.80,
      oas: 750,
    },
  ],
};

export const STRESS_SCENARIOS: StressScenario[] = [
  {
    id: 'SC-BASE',
    name: 'Base Case (Market Neutral)',
    description: 'Current macroeconomic baseline assumptions.',
    rateShiftBps: 0,
    hpiShiftPct: 0,
    unemploymentShockPct: 0,
    prepaymentMultiplier: 1.0,
    defaultMultiplier: 1.0,
    liquiditySpreadBps: 0,
  },
  {
    id: 'SC-RATES-DOWN',
    name: 'Rates Fall -150bp (Monetary Easing)',
    description: 'Bank Rate cuts spark refinancing surge and prepayment expansion.',
    rateShiftBps: -150,
    hpiShiftPct: 3.5,
    unemploymentShockPct: 0,
    prepaymentMultiplier: 2.2,
    defaultMultiplier: 0.8,
    liquiditySpreadBps: -15,
  },
  {
    id: 'SC-RATES-UP',
    name: 'Rates Rise +200bp (Inflationary Shock)',
    description: 'Central bank tightening halts refinancing and extends WAL significantly.',
    rateShiftBps: 200,
    hpiShiftPct: -5.0,
    unemploymentShockPct: 1.2,
    prepaymentMultiplier: 0.4,
    defaultMultiplier: 1.8,
    liquiditySpreadBps: 35,
  },
  {
    id: 'SC-DEFAULT-3X',
    name: 'Severe Credit Default (Default 3x)',
    description: 'Triple baseline default rates with -15% house price drop.',
    rateShiftBps: 50,
    hpiShiftPct: -15.0,
    unemploymentShockPct: 3.5,
    prepaymentMultiplier: 0.6,
    defaultMultiplier: 3.0,
    liquiditySpreadBps: 120,
  },
  {
    id: 'SC-HOUSING-CRASH',
    name: 'Housing Market Crash (-20% HPI)',
    description: 'Severe decline in property values pushing high LTV borrowers into negative equity.',
    rateShiftBps: -100,
    hpiShiftPct: -20.0,
    unemploymentShockPct: 4.0,
    prepaymentMultiplier: 0.3,
    defaultMultiplier: 4.5,
    liquiditySpreadBps: 250,
  },
];

export const BASE_PREPAY_PARAMS: PrepaymentModelParams = {
  type: 'RATE_INCENTIVE',
  baseCPR: 6.0,
  refiIncentiveSensitivity: 1.8,
  burnoutFactor: 0.04,
  seasonalityStrength: 0.25,
};

export const BASE_DEFAULT_PARAMS: DefaultModelParams = {
  baseCDR: 1.2,
  ltvSensitivity: 1.5,
  dtiSensitivity: 1.1,
  unemploymentShock: 0.0,
  hpiChange: 0.0,
  recoveryCostRate: 0.15,
};
