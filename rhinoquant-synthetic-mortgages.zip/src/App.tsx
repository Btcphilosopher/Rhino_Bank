/**
 * RHINOQUANT SYNTHETIC MORTGAGES — Main Application Entry Point
 * Institutional Mortgage Cash-Flow, Prepayment, Default, MBS & Structured-Credit Engine
 */

import React, { useState } from 'react';
import { Header, NavTab } from './components/Header';
import { MarketOverview } from './components/MarketOverview';
import { LoanConstructor } from './components/LoanConstructor';
import { PoolEngine } from './components/PoolEngine';
import { PrepaymentDefaultLab } from './components/PrepaymentDefaultLab';
import { CMOLab } from './components/CMOLab';
import { TrancheIOPOView } from './components/TrancheIOPOView';
import { RatePathOASView } from './components/RatePathOASView';
import { MonteCarloView } from './components/MonteCarloView';
import { RiskExtensionLab } from './components/RiskExtensionLab';
import { StressLab } from './components/StressLab';
import { SignatureDemosView } from './components/SignatureDemosView';
import { ResearchTerminal } from './components/ResearchTerminal';
import { ModelValidationView } from './components/ModelValidationView';
import { GeneratorConsole } from './components/GeneratorConsole';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('MARKET');
  const [seed] = useState<number>(2032);
  const [activeScenarioName] = useState<string>('BASE_CASE_2026');

  return (
    <div className="min-h-screen bg-[#0b0e14] text-slate-100 flex flex-col font-sans">
      {/* Header & Navigation Bar */}
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        seed={seed}
        activeScenarioName={activeScenarioName}
      />

      {/* Main Workspace Container */}
      <main className="flex-1 max-w-[1700px] w-full mx-auto p-4 md:p-6 space-y-6">
        {activeTab === 'MARKET' && <MarketOverview onNavigate={setActiveTab} />}
        {activeTab === 'SIGNATURE_DEMOS' && <SignatureDemosView />}
        {activeTab === 'LOAN_CONSTRUCTOR' && <LoanConstructor />}
        {activeTab === 'POOL_ENGINE' && <PoolEngine />}
        {activeTab === 'PREPAY_DEFAULT' && <PrepaymentDefaultLab />}
        {activeTab === 'CMO_LAB' && <CMOLab />}
        {activeTab === 'TRANCHE_IOPO' && <TrancheIOPOView />}
        {activeTab === 'RATE_PATHS' && <RatePathOASView />}
        {activeTab === 'MONTE_CARLO' && <MonteCarloView />}
        {activeTab === 'RISK_EXTENSION' && <RiskExtensionLab />}
        {activeTab === 'STRESS_LAB' && <StressLab />}
        {activeTab === 'RESEARCH' && <ResearchTerminal />}
        {activeTab === 'VALIDATION' && <ModelValidationView />}
        {activeTab === 'GENERATOR' && <GeneratorConsole />}
      </main>

      {/* Institutional Footer */}
      <footer className="border-t border-slate-800 bg-[#0d1118] text-slate-400 py-4 px-6 text-xs font-mono">
        <div className="max-w-[1700px] mx-auto flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className="font-bold text-white">RHINOQUANT SYNTHETIC MORTGAGES</span> — Quantitative Structured Credit Laboratory
          </div>
          <div className="text-[11px] text-slate-500">
            DETERMINISTIC SYNTHETIC DATA • NO REAL BORROWERS • NO PERSONAL DATA • FOR QUANTITATIVE RESEARCH & SIMULATION ONLY
          </div>
          <div className="flex items-center gap-3 text-slate-400">
            <span>ENGINE VERSION: 3.6.0</span>
            <span>·</span>
            <span>MODEL SEED: {seed}</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
