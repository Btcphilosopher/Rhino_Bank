/**
 * RHINOQUANT SYNTHETIC MORTGAGES — Core Data Types
 * Institutional Quantitative Mortgage, Pool, Securitisation & Risk Types
 */

export type Region =
  | 'LONDON'
  | 'SOUTH_EAST'
  | 'NORTH_WEST'
  | 'YORKSHIRE'
  | 'WEST_MIDLANDS'
  | 'EAST_ANGLIA'
  | 'SOUTH_WEST'
  | 'WALES'
  | 'SCOTLAND'
  | 'NORTHERN_IRELAND';

export type EmploymentType =
  | 'PERMANENT_FULL_TIME'
  | 'SELF_EMPLOYED'
  | 'CONTRACTOR'
  | 'PART_TIME'
  | 'RETIRED';

export type AgeBand =
  | '18-25'
  | '26-35'
  | '36-45'
  | '46-55'
  | '56-65'
  | '65+';

export type PropertyType =
  | 'DETACHED'
  | 'SEMI_DETACHED'
  | 'TERRACED'
  | 'FLAT_MAISONETTE'
  | 'BUNGALOW';

export type LoanType =
  | 'FIXED_RATE'
  | 'FLOATING_RATE'
  | 'INTEREST_ONLY'
  | 'AMORTISING'
  | 'TRACKER';

export type LoanState =
  | 'CURRENT'
  | 'DELINQUENT'
  | 'DEFAULT'
  | 'PREPAID'
  | 'REFINANCED'
  | 'MATURED';

export interface SyntheticBorrower {
  id: string;
  ageBand: AgeBand;
  income: number; // Annual income £
  employmentType: EmploymentType;
  creditScore: number; // 300 - 850 (FICO equivalent)
  totalExistingDebt: number;
  ltv: number; // % e.g. 75
  dti: number; // Debt-to-income ratio % e.g. 35
  region: Region;
  propertyType: PropertyType;
  loanSize: number;
  interestRate: number; // % e.g. 4.5
  termYears: number;
}

export interface SyntheticProperty {
  id: string;
  region: Region;
  propertyType: PropertyType;
  value: number; // £
  ltv: number; // %
  hpiSeries: number[]; // House price index factor over time (1.0 baseline)
  propertyAgeYears: number;
}

export interface SyntheticMortgage {
  id: string;
  borrowerId: string;
  propertyId: string;
  loanAmount: number;
  propertyValue: number;
  interestRate: number; // Annual rate e.g. 4.75%
  termMonths: number;
  loanType: LoanType;
  paymentFrequency: 'MONTHLY' | 'QUARTERLY';
  originationDate: string; // ISO format
  maturityDate: string;
  ltv: number;
  dti: number;
  creditScore: number;
  region: Region;
  propertyType: PropertyType;
  currentState: LoanState;
  extraMonthlyPayment?: number;
}

export interface AmortisationMonth {
  month: number;
  date: string;
  openingBalance: number;
  interestPaid: number;
  principalPaid: number;
  prepayment: number;
  defaultAmount: number;
  recoveryAmount: number;
  totalPayment: number;
  closingBalance: number;
  state: LoanState;
}

export interface PrepaymentModelParams {
  type: 'BASELINE' | 'RATE_INCENTIVE' | 'BEHAVIOURAL' | 'STOCHASTIC';
  baseCPR: number; // Baseline Annualised Prepayment Rate (e.g. 6.0%)
  refiIncentiveSensitivity: number; // Alpha multiplier for (Loan Rate - Market Rate)
  burnoutFactor: number; // Rate at which refi pool burns out over time
  seasonalityStrength: number; // Seasonality factor amplitude
}

export interface DefaultModelParams {
  baseCDR: number; // Baseline Conditional Default Rate (e.g. 1.2%)
  ltvSensitivity: number; // Weight on LTV > 80%
  dtiSensitivity: number; // Weight on DTI > 40%
  unemploymentShock: number; // % unemployment addition
  hpiChange: number; // % house price drop e.g. -10%
  recoveryCostRate: number; // % of property value lost in foreclosure costs e.g. 15%
}

export interface CashFlowPeriod {
  month: number;
  openingBalance: number;
  scheduledPrincipal: number;
  unscheduledPrincipal: number; // Prepayment
  interest: number;
  defaultAmount: number;
  recoveryAmount: number;
  lossAmount: number;
  totalCashFlow: number;
  closingBalance: number;
  smm: number; // Single Monthly Mortality rate
  mdr: number; // Monthly Default Rate
}

export interface MortgagePool {
  id: string;
  name: string;
  loanCount: number;
  originalBalance: number;
  currentBalance: number;
  wac: number; // Weighted Average Coupon %
  wal: number; // Weighted Average Life (years)
  wam: number; // Weighted Average Maturity (months)
  weightedLtv: number; // %
  weightedCreditScore: number;
  averageBalance: number;
  originationYear: number;
  geographicDistribution: Record<Region, number>; // % allocation
  creditDistribution: Record<string, number>; // Rating bucket %
  propertyDistribution: Record<PropertyType, number>; // % allocation
  loans?: SyntheticMortgage[];
}

export interface StratificationRow {
  category: string;
  loanCount: number;
  balance: number;
  balancePercentage: number;
  wac: number;
  weightedLtv: number;
  weightedCreditScore: number;
}

export interface Tranche {
  id: string;
  name: string;
  ratingLabel: 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'EQUITY';
  rank: number; // 1 = highest seniority
  notional: number; // £
  couponRate: number; // %
  attachmentPoint: number; // % e.g. 15%
  detachmentPoint: number; // % e.g. 100%
  expectedWal: number; // Years
  expectedLoss: number; // %
  duration: number; // Years
  convexity: number;
  price: number; // Clean price (e.g. 98.50 per 100 par)
  yield: number; // Yield to maturity %
  oas: number; // Option-Adjusted Spread in bps
}

export interface SecuritisationStructure {
  id: string;
  poolId: string;
  spvName: string;
  totalNotional: number;
  tranches: Tranche[];
  waterfallType: 'SEQUENTIAL' | 'PRO_RATA' | 'HYBRID';
}

export interface TrancheCashFlow {
  month: number;
  trancheId: string;
  openingBalance: number;
  interestPaid: number;
  interestShortfall: number;
  principalPaid: number;
  lossAllocated: number;
  closingBalance: number;
}

export interface RatePath {
  id: string;
  name: string;
  type: 'FLAT' | 'RISING' | 'FALLING' | 'MEAN_REVERTING' | 'VOLATILE';
  rates: number[]; // Annualised rates per month (360 periods)
}

export interface MonteCarloSummary {
  pathCount: number;
  meanWal: number;
  stdWal: number;
  var95: number; // 95% Value at Risk
  var99: number; // 99% Value at Risk
  expectedLossMean: number;
  percentiles: {
    p10Balance: number[];
    p50Balance: number[];
    p90Balance: number[];
  };
  oasConvergence: { path: number; oas: number }[];
}

export interface RiskMetrics {
  macaulayDuration: number;
  modifiedDuration: number;
  effectiveDuration: number;
  convexity: number;
  dv01: number; // Dollar Value of a 1 basis point shift
  vega: number; // Sensitivity to rate volatility
  oasDuration: number;
  prepaymentSensitivity: number; // dPV / dCPR
  defaultSensitivity: number; // dPV / dCDR
  wal: number;
  expectedLoss: number;
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  rateShiftBps: number;
  hpiShiftPct: number;
  unemploymentShockPct: number;
  prepaymentMultiplier: number;
  defaultMultiplier: number;
  liquiditySpreadBps: number;
}

export interface PriceDecomposition {
  baseCurveValue: number;
  creditAdjustment: number;
  prepaymentOptionCost: number;
  liquidityDiscount: number;
  expectedLossDeduction: number;
  modelAdjustment: number;
  finalPrice: number;
}

export interface ValidationCheck {
  id: string;
  category: 'CASH_FLOW' | 'AMORTISATION' | 'PREPAYMENT' | 'COMPETING_RISK' | 'WATERFALL' | 'CONVERGENCE';
  title: string;
  status: 'PASSED' | 'WARNING' | 'FAILED';
  details: string;
  numericalValue?: number;
  expectedValue?: number;
}
