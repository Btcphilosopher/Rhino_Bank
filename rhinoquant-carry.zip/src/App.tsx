import React, { useState } from 'react';
import { Header, NavTab } from './components/Header';
import { RiskGovernanceBanner } from './components/RiskGovernanceBanner';
import { DashboardView } from './components/DashboardView';
import { CurrencyHeatmapView } from './components/CurrencyHeatmapView';
import { FundingTargetEngineView } from './components/FundingTargetEngineView';
import { CipBasisView } from './components/CipBasisView';
import { CarryVolCrashView } from './components/CarryVolCrashView';
import { CentralBankRegimeView } from './components/CentralBankRegimeView';
import { MlResearchView } from './components/MlResearchView';
import { PortfolioOptimizerView } from './components/PortfolioOptimizerView';
import { LeverageLiquidityView } from './components/LeverageLiquidityView';
import { StressTestingView } from './components/StressTestingView';
import { MonteCarloView } from './components/MonteCarloView';
import { BacktestView } from './components/BacktestView';
import { TradeTicketView } from './components/TradeTicketView';
import { ResearchLabView } from './components/ResearchLabView';
import { AuditTrailView } from './components/AuditTrailView';

import { calculateCarryPair } from './engine/carryEngine';
import { calculateFundingScores } from './engine/fundingEngine';
import { generateResearchSignals } from './engine/signalEngine';
import { CORE_CARRY_PAIRS_SPEC } from './data/currencyData';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [ticketFunding, setTicketFunding] = useState<string>('JPY');
  const [ticketTarget, setTicketTarget] = useState<string>('MXN');

  // Compute live engine data
  const pairs = CORE_CARRY_PAIRS_SPEC.map((spec) => calculateCarryPair(spec.fundingCode, spec.targetCode));
  const fundingScores = calculateFundingScores();
  const signals = generateResearchSignals();

  const handleSelectPairForTicket = (funding: string, target: string) => {
    setTicketFunding(funding);
    setTicketTarget(target);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#D1D1D1] font-sans flex flex-col selection:bg-[#F27D26] selection:text-black">
      {/* Header & Risk Governance Banner */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} fundingStressIndex={24} crashRiskScore={32} />
      <RiskGovernanceBanner />

      {/* Main Terminal Viewport */}
      <main className="flex-1 p-4 md:p-6 max-w-[1600px] w-full mx-auto">
        {activeTab === 'dashboard' && (
          <DashboardView
            pairs={pairs}
            fundingScores={fundingScores}
            signals={signals}
            setActiveTab={setActiveTab}
            onSelectPairForTicket={handleSelectPairForTicket}
          />
        )}
        {activeTab === 'heatmap' && <CurrencyHeatmapView />}
        {activeTab === 'fundingTarget' && <FundingTargetEngineView />}
        {activeTab === 'cipBasis' && <CipBasisView />}
        {activeTab === 'carryVolCrash' && <CarryVolCrashView />}
        {activeTab === 'centralBank' && <CentralBankRegimeView />}
        {activeTab === 'mlResearch' && <MlResearchView />}
        {activeTab === 'portfolio' && <PortfolioOptimizerView />}
        {activeTab === 'leverageLiquidity' && <LeverageLiquidityView />}
        {activeTab === 'stressTesting' && <StressTestingView />}
        {activeTab === 'monteCarlo' && <MonteCarloView />}
        {activeTab === 'backtester' && <BacktestView />}
        {activeTab === 'tradeTicket' && (
          <TradeTicketView initialFunding={ticketFunding} initialTarget={ticketTarget} />
        )}
        {activeTab === 'researchLab' && <ResearchLabView />}
        {activeTab === 'auditTrail' && <AuditTrailView />}
      </main>

      {/* Terminal Footer */}
      <footer className="bg-[#0A0A0A] border-t border-[#222] py-2.5 px-6 text-[10px] text-[#666] font-mono flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center space-x-6">
          <span className="font-bold text-[#F27D26] uppercase tracking-wider">MD_VERSION: 14.0.2</span>
          <span>AUDIT_ID: RQ_772_XCARRY</span>
          <span>NODE: LON-QS-04</span>
          <span>NODE_STATUS: <strong className="text-emerald-400">ONLINE</strong></span>
        </div>

        <div className="flex items-center space-x-4 uppercase tracking-tighter">
          <span className="text-emerald-500/70">S&P 500: 5,420.22</span>
          <span className="text-red-500/70">VIX: 13.04</span>
          <span className="text-white/70">DXY: 104.12</span>
        </div>
      </footer>
    </div>
  );
}
