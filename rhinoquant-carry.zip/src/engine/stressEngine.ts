import { StressTestScenario } from '../types/carry';

export function getPredefinedStressScenarios(): StressTestScenario[] {
  return [
    {
      id: 'gfc-2008',
      name: '2008 Global Financial Crisis',
      description: 'Systemic liquidity collapse, severe EM currency depreciation vs USD & JPY funding surge.',
      fundingFxShockPct: 24.5, // Funding currency (JPY/USD) appreciates 24.5%
      targetFxShockPct: -32.0, // Target EM currency drops 32%
      volatilityMultiplier: 3.5,
      rateShiftBps: -250,
      liquidityHaircutPct: 35.0,
      portfolioDrawdownPct: 38.4,
      marginCallTriggered: true,
      estimatedRecoveryMonths: 22,
    },
    {
      id: 'eurozone-2011',
      name: '2011 Eurozone Sovereign Debt Crisis',
      description: 'EUR funding stress, cross-currency basis widening, European asset sell-off.',
      fundingFxShockPct: 14.0,
      targetFxShockPct: -18.5,
      volatilityMultiplier: 2.2,
      rateShiftBps: -100,
      liquidityHaircutPct: 20.0,
      portfolioDrawdownPct: 21.8,
      marginCallTriggered: false,
      estimatedRecoveryMonths: 11,
    },
    {
      id: 'covid-2020',
      name: '2020 COVID Market Shock',
      description: 'Rapid global dash for USD cash, violent FX vol expansion, short-lived carry unwind.',
      fundingFxShockPct: 12.0,
      targetFxShockPct: -22.0,
      volatilityMultiplier: 4.1,
      rateShiftBps: -150,
      liquidityHaircutPct: 25.0,
      portfolioDrawdownPct: 26.5,
      marginCallTriggered: true,
      estimatedRecoveryMonths: 7,
    },
    {
      id: 'rate-shock-2022',
      name: '2022 Aggressive Policy Rate Hikes',
      description: 'Global G10 central bank tightening, real yield repricing, EM debt pressure.',
      fundingFxShockPct: 18.0,
      targetFxShockPct: -15.0,
      volatilityMultiplier: 2.0,
      rateShiftBps: 425,
      liquidityHaircutPct: 15.0,
      portfolioDrawdownPct: 19.2,
      marginCallTriggered: false,
      estimatedRecoveryMonths: 14,
    },
    {
      id: 'jpy-unwind-2024',
      name: '2024 Global JPY Carry Trade Unwind',
      description: 'BOJ surprise rate hike combined with US recession fears triggering sudden massive JPY short cover.',
      fundingFxShockPct: 16.5,
      targetFxShockPct: -25.0,
      volatilityMultiplier: 3.8,
      rateShiftBps: 25,
      liquidityHaircutPct: 30.0,
      portfolioDrawdownPct: 31.0,
      marginCallTriggered: true,
      estimatedRecoveryMonths: 16,
    },
  ];
}

export function simulateCustomStressScenario(
  fundingFxShockPct: number,
  targetFxShockPct: number,
  volatilityMultiplier: number,
  rateShiftBps: number,
  liquidityHaircutPct: number,
  leverage: number = 3.0
): StressTestScenario {
  // Drawdown = Leverage * (Target_Drop + Funding_Appreciation)
  const grossLossPct = leverage * (Math.abs(targetFxShockPct) + Math.abs(fundingFxShockPct) * 0.7);
  const portfolioDrawdownPct = parseFloat(Math.min(99.9, grossLossPct).toFixed(1));

  const marginCallTriggered = portfolioDrawdownPct > (100 / leverage) * 0.7; // Equity depleted > 70%
  const estimatedRecoveryMonths = Math.round(portfolioDrawdownPct * 0.6);

  return {
    id: 'custom-scenario',
    name: 'Custom User Shock Scenario',
    description: 'User-defined parameters for FX, volatility, rate shifts, and liquidity haircuts.',
    fundingFxShockPct,
    targetFxShockPct,
    volatilityMultiplier,
    rateShiftBps,
    liquidityHaircutPct,
    portfolioDrawdownPct,
    marginCallTriggered,
    estimatedRecoveryMonths,
  };
}
