import { CarryPair } from '../types/carry';
import { generateAllCarryPairs } from './carryEngine';

export interface CarryVolItem {
  pairName: string;
  fundingCode: string;
  targetCode: string;
  expectedCarry: number; // Y axis
  volatility: number;    // X axis
  carryToVolRatio: number;
  liquidityScore: number; // Bubble size
  riskRegime: string;     // Color coding
  expectedDrawdown: number;
  expectedTailLoss: number; // CVaR 95%
}

export function getCarryVolMatrix(): CarryVolItem[] {
  const pairs = generateAllCarryPairs();

  return pairs.map((p) => {
    const carryToVolRatio = parseFloat((p.expectedCarryAnnual / Math.max(0.1, p.annualizedVol)).toFixed(2));
    const expectedTailLoss = parseFloat((p.annualizedVol * 1.645 + Math.abs(p.skewness) * 2).toFixed(2));

    return {
      pairName: p.pairName,
      fundingCode: p.fundingCode,
      targetCode: p.targetCode,
      expectedCarry: p.expectedCarryAnnual,
      volatility: p.annualizedVol,
      carryToVolRatio,
      liquidityScore: p.carryQualityScore,
      riskRegime: p.crashWarningState,
      expectedDrawdown: p.maxDrawdown,
      expectedTailLoss,
    };
  });
}
