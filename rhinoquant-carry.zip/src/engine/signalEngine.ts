import { generateAllCarryPairs } from './carryEngine';
import { calculateFundingScores } from './fundingEngine';

export interface ResearchSignal {
  id: string;
  pairName: string;
  signalType:
    | 'STRONG CARRY'
    | 'WEAK CARRY'
    | 'CARRY IMPROVING'
    | 'CARRY DETERIORATING'
    | 'FX RISK ELEVATED'
    | 'FUNDING RISK ELEVATED'
    | 'CENTRAL BANK REVERSAL'
    | 'CARRY CRASH WARNING'
    | 'LIQUIDITY WARNING'
    | 'REGIME CHANGE';
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  description: string;
  timestamp: string;
}

export function generateResearchSignals(): ResearchSignal[] {
  const pairs = generateAllCarryPairs();
  const fundingScores = calculateFundingScores();

  const signals: ResearchSignal[] = [];
  const now = new Date().toISOString().substring(0, 16).replace('T', ' ');

  // 1. High Carry signal
  const topPair = pairs[0];
  if (topPair) {
    signals.push({
      id: 'sig-1',
      pairName: topPair.pairName,
      signalType: 'STRONG CARRY',
      severity: 'INFO',
      description: `High net annualized carry of ${topPair.netReturn1Y}% with Carry Quality Score ${topPair.carryQualityScore}/100.`,
      timestamp: now,
    });
  }

  // 2. Crash Warnings
  const highCrashPairs = pairs.filter((p) => p.carryCrashScore >= 65);
  highCrashPairs.forEach((p, idx) => {
    signals.push({
      id: `sig-crash-${idx}`,
      pairName: p.pairName,
      signalType: 'CARRY CRASH WARNING',
      severity: p.carryCrashScore >= 80 ? 'CRITICAL' : 'WARNING',
      description: `Crash Risk Score elevated at ${p.carryCrashScore}/100 (${p.crashWarningState}). Kurtosis: ${p.kurtosis}, Skew: ${p.skewness}.`,
      timestamp: now,
    });
  });

  // 3. Central Bank Reversal
  pairs.slice(0, 5).forEach((p, idx) => {
    if (p.interestDiff > 5.0 && p.carryCrashScore > 40) {
      signals.push({
        id: `sig-cb-${idx}`,
        pairName: p.pairName,
        signalType: 'CENTRAL BANK REVERSAL',
        severity: 'WARNING',
        description: `Potential monetary policy divergence shift. Central Bank repricing risk elevated.`,
        timestamp: now,
      });
    }
  });

  // 4. Funding Risk Elevated
  const weakFunding = fundingScores.find((f) => f.fundingStressScore > 50);
  if (weakFunding) {
    signals.push({
      id: 'sig-funding-1',
      pairName: `* / ${weakFunding.code}`,
      signalType: 'FUNDING RISK ELEVATED',
      severity: 'WARNING',
      description: `${weakFunding.code} funding stress index rising (${weakFunding.fundingStressScore}/100). FX swap liquidity tightening.`,
      timestamp: now,
    });
  }

  return signals;
}
