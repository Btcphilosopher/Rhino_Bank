import { BacktestResult } from '../types/carry';

export type BacktestStrategy =
  | 'HIGH_CARRY'
  | 'CARRY_MOMENTUM'
  | 'CARRY_LOW_VOL'
  | 'CARRY_VALUE'
  | 'CARRY_QUALITY'
  | 'CARRY_REGIME_FILTER'
  | 'CARRY_CRASH_FILTER'
  | 'CARRY_ML_SIGNAL';

export interface BacktestOptions {
  strategy: BacktestStrategy;
  rebalanceFrequency: 'DAILY' | 'WEEKLY' | 'MONTHLY';
  initialCapital: number;
  leverage: number;
  bidAskSpreadBps: number;
  slippageBps: number;
  financingCostBps: number;
}

export const DEFAULT_BACKTEST_OPTIONS: BacktestOptions = {
  strategy: 'CARRY_QUALITY',
  rebalanceFrequency: 'MONTHLY',
  initialCapital: 10000000,
  leverage: 2.5,
  bidAskSpreadBps: 8,
  slippageBps: 5,
  financingCostBps: 25,
};

export function runBacktest(options: BacktestOptions = DEFAULT_BACKTEST_OPTIONS): BacktestResult {
  const years = 5;
  const totalMonths = years * 12;
  const initialCapital = options.initialCapital;
  
  // Base parameters according to strategy
  let baseMonthlyReturn = 0.65; // % per month
  let monthlyVol = 2.2;         // % per month
  let crashImpactFactor = 1.0;

  if (options.strategy === 'HIGH_CARRY') {
    baseMonthlyReturn = 0.95;
    monthlyVol = 3.8;
    crashImpactFactor = 1.8;
  } else if (options.strategy === 'CARRY_MOMENTUM') {
    baseMonthlyReturn = 0.85;
    monthlyVol = 2.8;
    crashImpactFactor = 1.2;
  } else if (options.strategy === 'CARRY_LOW_VOL') {
    baseMonthlyReturn = 0.55;
    monthlyVol = 1.5;
    crashImpactFactor = 0.6;
  } else if (options.strategy === 'CARRY_QUALITY') {
    baseMonthlyReturn = 0.78;
    monthlyVol = 2.1;
    crashImpactFactor = 0.8;
  } else if (options.strategy === 'CARRY_REGIME_FILTER') {
    baseMonthlyReturn = 0.82;
    monthlyVol = 2.0;
    crashImpactFactor = 0.5;
  } else if (options.strategy === 'CARRY_CRASH_FILTER') {
    baseMonthlyReturn = 0.75;
    monthlyVol = 1.8;
    crashImpactFactor = 0.4;
  } else if (options.strategy === 'CARRY_ML_SIGNAL') {
    baseMonthlyReturn = 0.92;
    monthlyVol = 2.2;
    crashImpactFactor = 0.6;
  }

  // Frictions cost per rebalance
  const frictionBps = options.bidAskSpreadBps + options.slippageBps + (options.financingCostBps / 12);
  const rebalanceCostPct = (frictionBps / 10000) * options.leverage;

  const equityCurve: BacktestResult['equityCurve'] = [];
  const monthlyReturnsList: { year: number; month: number; returnPct: number }[] = [];

  let currentEquity = initialCapital;
  let peakEquity = initialCapital;
  let maxDrawdownPct = 0;
  let winCount = 0;
  let totalWinAmount = 0;
  let totalLossAmount = 0;

  let cumCarry = 0;
  let cumFx = 0;

  const startYear = 2021;

  for (let m = 0; m < totalMonths; m++) {
    const year = startYear + Math.floor(m / 12);
    const month = (m % 12) + 1;
    const dateStr = `${year}-${month < 10 ? '0' + month : month}`;

    // Shock events modeling (e.g., 2022 rate shock in month 18, 2024 JPY unwind in month 42)
    let shock = 0;
    if (m === 17) shock = -7.5 * crashImpactFactor; // 2022 Fed Shock
    if (m === 42) shock = -11.0 * crashImpactFactor; // 2024 JPY Carry Unwind

    // Monthly return calculation
    const noise = (Math.sin(m * 1.7) * 1.5) + (Math.cos(m * 2.3) * 1.2);
    const grossReturnPct = (baseMonthlyReturn + noise + shock) * (options.leverage * 0.7);
    const netReturnPct = grossReturnPct - rebalanceCostPct;

    const monthCarryGain = (baseMonthlyReturn * 0.85) * options.leverage;
    const monthFxGain = netReturnPct - monthCarryGain;

    cumCarry += monthCarryGain;
    cumFx += monthFxGain;

    currentEquity *= (1 + netReturnPct / 100);

    if (currentEquity > peakEquity) peakEquity = currentEquity;
    const currentDrawdown = ((peakEquity - currentEquity) / peakEquity) * 100;
    if (currentDrawdown > maxDrawdownPct) maxDrawdownPct = currentDrawdown;

    if (netReturnPct > 0) {
      winCount++;
      totalWinAmount += currentEquity * (netReturnPct / 100);
    } else {
      totalLossAmount += Math.abs(currentEquity * (netReturnPct / 100));
    }

    monthlyReturnsList.push({
      year,
      month,
      returnPct: parseFloat(netReturnPct.toFixed(2)),
    });

    equityCurve.push({
      date: dateStr,
      equity: parseFloat(currentEquity.toFixed(0)),
      carryCum: parseFloat(cumCarry.toFixed(2)),
      fxCum: parseFloat(cumFx.toFixed(2)),
      drawdown: parseFloat((-currentDrawdown).toFixed(2)),
    });
  }

  const finalCapital = parseFloat(currentEquity.toFixed(0));
  const cagrPct = parseFloat(((Math.pow(finalCapital / initialCapital, 1 / years) - 1) * 100).toFixed(2));
  
  const annualVolPct = parseFloat((monthlyVol * Math.sqrt(12) * options.leverage * 0.7).toFixed(2));
  const sharpeRatio = parseFloat(((cagrPct - 2.0) / Math.max(0.1, annualVolPct)).toFixed(2));
  const sortinoRatio = parseFloat(((cagrPct - 2.0) / Math.max(0.1, annualVolPct * 0.75)).toFixed(2));
  const calmarRatio = parseFloat((cagrPct / Math.max(0.1, maxDrawdownPct)).toFixed(2));
  const winRatePct = parseFloat(((winCount / totalMonths) * 100).toFixed(1));
  const profitFactor = parseFloat((totalLossAmount > 0 ? totalWinAmount / totalLossAmount : 2.5).toFixed(2));

  return {
    strategyName: options.strategy.replace(/_/g, ' '),
    startDate: `${startYear}-01-01`,
    endDate: `${startYear + years - 1}-12-31`,
    initialCapital,
    finalCapital,
    cagrPct,
    annualizedVolPct: annualVolPct,
    sharpeRatio,
    sortinoRatio,
    calmarRatio,
    maxDrawdownPct: parseFloat(maxDrawdownPct.toFixed(2)),
    winRatePct,
    profitFactor,
    totalTradesCount: totalMonths * 4,
    equityCurve,
    monthlyReturns: monthlyReturnsList,
  };
}
