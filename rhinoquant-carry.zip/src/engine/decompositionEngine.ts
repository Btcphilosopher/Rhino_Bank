import { ReturnDecomposition } from '../types/carry';
import { calculateCarryPair } from './carryEngine';

export function getReturnDecomposition(fundingCode: string, targetCode: string): ReturnDecomposition {
  const pair = calculateCarryPair(fundingCode, targetCode);

  const interestComponent = pair.targetRate; // Target yield earned
  const fundingComponent = pair.fundingRate; // Funding interest paid
  const spotFxComponent = pair.fxReturn1Y;   // Spot exchange rate change
  const forwardComponent = parseFloat((pair.cipDeviationBps / 100).toFixed(2)); // Basis / forward point effect
  const transactionCostComponent = parseFloat(((100 - Math.min(85, pair.carryQualityScore)) * 0.025).toFixed(2));

  // Net strategy return = Interest - Funding + Spot FX + Forward - Tx Cost
  const netTotalReturn = parseFloat(
    (interestComponent - fundingComponent + spotFxComponent + forwardComponent - transactionCostComponent).toFixed(2)
  );

  return {
    pairName: pair.pairName,
    interestComponent: parseFloat(interestComponent.toFixed(2)),
    fundingComponent: parseFloat(fundingComponent.toFixed(2)),
    spotFxComponent: parseFloat(spotFxComponent.toFixed(2)),
    forwardComponent: parseFloat(forwardComponent.toFixed(2)),
    transactionCostComponent,
    netTotalReturn,
  };
}
