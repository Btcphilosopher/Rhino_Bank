import { CipBasisMetric } from '../types/carry';
import { calculateCarryPair } from './carryEngine';

export function calculateCipBasis(fundingCode: string, targetCode: string): CipBasisMetric {
  const pair = calculateCarryPair(fundingCode, targetCode);

  const theoreticalForward = pair.impliedForwardRate;
  const observedForward = pair.forward1Y;
  
  // CIP Deviation in Basis Points: (Observed - Theoretical) / Spot * 10,000
  const cipDeviationBps = parseFloat((((observedForward - theoreticalForward) / pair.spotRate) * 10000).toFixed(1));
  const crossCurrencyBasisBps = parseFloat((cipDeviationBps * 0.85 + (pair.interestDiff * 2)).toFixed(1));
  const basisVolatility = parseFloat((Math.abs(cipDeviationBps) * 0.18 + 4.2).toFixed(2));

  // CIP Deviation Score (0-100)
  const absDev = Math.abs(cipDeviationBps);
  const cipDeviationScore = Math.min(100, Math.max(0, Math.round((absDev / 120) * 100)));

  let arbitrageSignal: CipBasisMetric['arbitrageSignal'] = 'NO_ARBITRAGE';
  if (absDev > 100) {
    arbitrageSignal = 'STRUCTURAL_FUNDING_STRESS';
  } else if (absDev > 35) {
    arbitrageSignal = 'MODERATE_DISCREPANCY';
  }

  return {
    pairName: pair.pairName,
    observedForward,
    theoreticalForward,
    cipDeviationBps,
    crossCurrencyBasisBps,
    basisVolatility,
    cipDeviationScore,
    arbitrageSignal,
  };
}

export function getAllCipMetrics(): CipBasisMetric[] {
  const fundings = ['USD', 'EUR', 'JPY', 'GBP', 'CHF'];
  const targets = ['MXN', 'BRL', 'ZAR', 'INR', 'TRY', 'AUD', 'NZD', 'PLN'];

  const results: CipBasisMetric[] = [];
  for (const f of fundings) {
    for (const t of targets) {
      if (f !== t) {
        results.push(calculateCipBasis(f, t));
      }
    }
  }
  return results.sort((a, b) => b.cipDeviationScore - a.cipDeviationScore);
}
