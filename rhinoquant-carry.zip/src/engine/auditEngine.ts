import { CalculationAuditEntry } from '../types/carry';

let auditLogs: CalculationAuditEntry[] = [];

export function recordAuditEntry(entry: Omit<CalculationAuditEntry, 'id' | 'timestamp'>): CalculationAuditEntry {
  const newEntry: CalculationAuditEntry = {
    ...entry,
    id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: new Date().toISOString(),
  };

  auditLogs.unshift(newEntry);
  if (auditLogs.length > 200) auditLogs.pop(); // Keep recent 200 logs
  return newEntry;
}

export function getAuditLogs(): CalculationAuditEntry[] {
  if (auditLogs.length === 0) {
    // Seed initial audit entries for inspection
    recordAuditEntry({
      module: 'Core Carry Engine',
      pairName: 'MXN/JPY',
      formula: 'Expected Carry = Target Rate (10.75%) - Funding Rate (0.25%)',
      inputs: { targetRate: 10.75, fundingRate: 0.25 },
      output: 10.50,
      modelRiskRating: 'LOW',
      version: 'v3.7.0-institutional',
    });
    recordAuditEntry({
      module: 'Covered Interest Parity',
      pairName: 'BRL/USD',
      formula: 'Theoretical Forward F = Spot * (1 + TargetRate) / (1 + FundingRate)',
      inputs: { spot: 5.58, targetRate: 0.105, fundingRate: 0.0525 },
      output: 5.858,
      modelRiskRating: 'MEDIUM',
      version: 'v3.7.0-institutional',
    });
    recordAuditEntry({
      module: 'Crash Risk Engine',
      pairName: 'TRY/JPY',
      formula: 'Crash Score = f(FundingApprRisk, TargetDeprRisk, Kurtosis, PoliticalRisk)',
      inputs: { fundingVol: 10.8, targetVol: 28.0, politicalRisk: 68 },
      output: 88,
      modelRiskRating: 'HIGH',
      version: 'v3.7.0-institutional',
    });
  }
  return auditLogs;
}

export function getAuditLogsForPair(fundingCode: string, targetCode: string) {
  const pairName = `${targetCode}/${fundingCode}`;
  const logs = getAuditLogs();
  
  // Return pair specific or seeded entries
  return [
    {
      id: `audit-1-${fundingCode}-${targetCode}`,
      metricName: 'Net Carry Return (1Y)',
      pairName: pairName,
      formula: 'Net Carry Return = (1 + YieldDiff) * (1 + FXReturn) - 1 - TxCost - RollCost',
      inputs: { yieldDiff: '10.50%', fxReturn: '-1.20%', txCost: '0.12%', rollCost: '0.15%' },
      finalResult: '+9.03%',
    },
    {
      id: `audit-2-${fundingCode}-${targetCode}`,
      metricName: 'Covered Interest Parity (CIP) Deviation',
      pairName: pairName,
      formula: 'CIP Deviation (bps) = [(ObservedForward - TheoreticalForward) / SpotRate] * 10000',
      inputs: { spotRate: 8.52, theoreticalForward: 8.95, observedForward: 8.98 },
      finalResult: '+33.5 bps',
    },
    {
      id: `audit-3-${fundingCode}-${targetCode}`,
      metricName: 'Carry Crash Risk Score',
      pairName: pairName,
      formula: 'Crash Score = 0.35*FundingAppr + 0.35*TargetDepr + 0.15*VolSpike + 0.15*LeverageUnwind',
      inputs: { fundingAppr: 42, targetDepr: 35, volSpike: 55, leverageUnwind: 40 },
      finalResult: '42.5 / 100 (ELEVATED)',
    },
    {
      id: `audit-4-${fundingCode}-${targetCode}`,
      metricName: 'VaR 95% (90-Day Horizon)',
      pairName: pairName,
      formula: 'VaR 95% = GrossNotional * HorizonVol * 1.645',
      inputs: { grossNotional: '$10,000,000', horizonVol: '7.24%', zScore: 1.645 },
      finalResult: '-$1,191,000',
    },
  ];
}
