import { PortfolioPosition, PortfolioMetrics } from '../types/carry';
import { generateAllCarryPairs } from './carryEngine';

export type OptimizationObjective =
  | 'MAXIMUM_CARRY'
  | 'MAXIMUM_SHARPE'
  | 'MINIMUM_VOLATILITY'
  | 'MAXIMUM_CARRY_RISK'
  | 'RISK_PARITY'
  | 'USER_CONSTRAINED';

export interface OptimizerConstraints {
  maxPositionSizePct: number; // e.g. 30%
  maxLeverage: number;         // e.g. 5.0x
  maxCurrencyCapPct: number;   // e.g. 40%
  maxVolatilityPct: number;    // e.g. 15%
  maxDrawdownPct: number;      // e.g. 20%
  minLiquidityScore: number;   // e.g. 60
}

export const DEFAULT_OPTIMIZER_CONSTRAINTS: OptimizerConstraints = {
  maxPositionSizePct: 35,
  maxLeverage: 3.0,
  maxCurrencyCapPct: 40,
  maxVolatilityPct: 15,
  maxDrawdownPct: 20,
  minLiquidityScore: 50,
};

export function optimizePortfolio(
  positions: PortfolioPosition[],
  objective: OptimizationObjective = 'MAXIMUM_SHARPE',
  constraints: OptimizerConstraints = DEFAULT_OPTIMIZER_CONSTRAINTS,
  totalCapitalUSD: number = 10000000
): { positions: PortfolioPosition[]; metrics: PortfolioMetrics } {
  // Available top pairs
  const topPairs = generateAllCarryPairs().filter((p) => p.carryQualityScore >= constraints.minLiquidityScore);

  let updatedPositions = [...positions];

  // If no positions provided, generate initial basket
  if (updatedPositions.length === 0) {
    const selectedPairs = topPairs.slice(0, 4);
    const weightEach = Math.min(constraints.maxPositionSizePct, 100 / selectedPairs.length);
    updatedPositions = selectedPairs.map((p, idx) => ({
      id: `pos-${idx + 1}`,
      fundingCode: p.fundingCode,
      targetCode: p.targetCode,
      pairName: p.pairName,
      weight: weightEach,
      notionalUSD: totalCapitalUSD * (weightEach / 100) * constraints.maxLeverage,
      leverage: constraints.maxLeverage,
      expectedCarry: p.expectedCarryAnnual,
      annualizedVol: p.annualizedVol,
      var95: parseFloat(((totalCapitalUSD * (weightEach / 100) * constraints.maxLeverage) * (p.annualizedVol / 100) * 1.645).toFixed(0)),
      expectedShortfall95: parseFloat(((totalCapitalUSD * (weightEach / 100) * constraints.maxLeverage) * (p.annualizedVol / 100) * 2.06).toFixed(0)),
    }));
  }

  // Adjust weights according to optimization objective
  const count = updatedPositions.length;
  if (count > 0) {
    if (objective === 'MAXIMUM_CARRY') {
      // Weight proportional to expected carry
      const totalCarry = updatedPositions.reduce((acc, p) => acc + Math.max(0.1, p.expectedCarry), 0);
      updatedPositions.forEach((p) => {
        p.weight = Math.min(constraints.maxPositionSizePct, parseFloat(((p.expectedCarry / totalCarry) * 100).toFixed(1)));
      });
    } else if (objective === 'MINIMUM_VOLATILITY') {
      // Weight inversely proportional to volatility
      const invVolSum = updatedPositions.reduce((acc, p) => acc + (1 / Math.max(0.1, p.annualizedVol)), 0);
      updatedPositions.forEach((p) => {
        p.weight = Math.min(constraints.maxPositionSizePct, parseFloat((((1 / p.annualizedVol) / invVolSum) * 100).toFixed(1)));
      });
    } else if (objective === 'RISK_PARITY') {
      // Equal risk contribution
      const invVolSum = updatedPositions.reduce((acc, p) => acc + (1 / Math.max(0.1, p.annualizedVol)), 0);
      updatedPositions.forEach((p) => {
        p.weight = parseFloat((((1 / p.annualizedVol) / invVolSum) * 100).toFixed(1));
      });
    } else if (objective === 'MAXIMUM_SHARPE') {
      // Weight proportional to Sharpe ratio
      const sharpeSum = updatedPositions.reduce((acc, p) => acc + Math.max(0.1, (p.expectedCarry / Math.max(0.1, p.annualizedVol))), 0);
      updatedPositions.forEach((p) => {
        const s = Math.max(0.1, (p.expectedCarry / Math.max(0.1, p.annualizedVol)));
        p.weight = Math.min(constraints.maxPositionSizePct, parseFloat(((s / sharpeSum) * 100).toFixed(1)));
      });
    }

    // Normalize weights to sum to 100%
    const totalWeight = updatedPositions.reduce((acc, p) => acc + p.weight, 0);
    updatedPositions.forEach((p) => {
      p.weight = parseFloat(((p.weight / totalWeight) * 100).toFixed(1));
      p.notionalUSD = totalCapitalUSD * (p.weight / 100) * constraints.maxLeverage;
      p.var95 = parseFloat((p.notionalUSD * (p.annualizedVol / 100) * 1.645).toFixed(0));
      p.expectedShortfall95 = parseFloat((p.notionalUSD * (p.annualizedVol / 100) * 2.06).toFixed(0));
    });
  }

  // Calculate portfolio aggregate metrics
  const totalNotionalUSD = updatedPositions.reduce((acc, p) => acc + p.notionalUSD, 0);
  const effectiveLeverage = totalCapitalUSD > 0 ? parseFloat((totalNotionalUSD / totalCapitalUSD).toFixed(2)) : 1.0;

  const portfolioCarryAnnual = updatedPositions.reduce((acc, p) => acc + (p.expectedCarry * (p.weight / 100)), 0);
  
  // Diversified portfolio volatility (assuming 0.3 average pairwise correlation)
  const weightedVolSquare = updatedPositions.reduce((acc, p) => acc + Math.pow(p.annualizedVol * (p.weight / 100), 2), 0);
  const crossVolSum = updatedPositions.reduce((acc, p1, i) => {
    return acc + updatedPositions.reduce((innerAcc, p2, j) => {
      if (i >= j) return innerAcc;
      return innerAcc + 2 * (p1.weight / 100) * (p2.weight / 100) * p1.annualizedVol * p2.annualizedVol * 0.35;
    }, 0);
  }, 0);

  const portfolioVolAnnual = parseFloat(Math.sqrt(weightedVolSquare + crossVolSum).toFixed(2));

  const sharpeRatio = parseFloat(((portfolioCarryAnnual - 2.0) / Math.max(0.1, portfolioVolAnnual)).toFixed(2));
  const sortinoRatio = parseFloat(((portfolioCarryAnnual - 2.0) / Math.max(0.1, portfolioVolAnnual * 0.7)).toFixed(2));
  const maxDrawdown = parseFloat((portfolioVolAnnual * 1.6 * effectiveLeverage * 0.4).toFixed(2));

  const var95Annual = parseFloat((totalNotionalUSD * (portfolioVolAnnual / 100) * 1.645).toFixed(0));
  const var99Annual = parseFloat((totalNotionalUSD * (portfolioVolAnnual / 100) * 2.326).toFixed(0));
  const expectedShortfall95 = parseFloat((var95Annual * 1.25).toFixed(0));

  // Herfindahl-Hirschman Concentration Index
  const hhiConcentrationIndex = Math.round(updatedPositions.reduce((acc, p) => acc + Math.pow(p.weight, 2), 0));

  const stressLossGFC = parseFloat((totalNotionalUSD * 0.28).toFixed(0));
  const stressLoss2024Unwind = parseFloat((totalNotionalUSD * 0.18).toFixed(0));

  return {
    positions: updatedPositions,
    metrics: {
      totalNotionalUSD,
      leverage: effectiveLeverage,
      portfolioCarryAnnual: parseFloat(portfolioCarryAnnual.toFixed(2)),
      portfolioVolAnnual,
      sharpeRatio,
      sortinoRatio,
      maxDrawdown,
      var95Annual,
      var99Annual,
      expectedShortfall95,
      fxBetaVsUSD: 0.82,
      hhiConcentrationIndex,
      stressLossGFC,
      stressLoss2024Unwind,
    },
  };
}
