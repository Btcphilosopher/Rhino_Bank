import { GLOBAL_CURRENCIES } from '../data/currencyData';
import { TargetCurrencyScore } from '../types/carry';

export interface TargetEngineWeights {
  interestDiffWeight: number; // default 0.30
  momentumWeight: number; // default 0.15
  realRateWeight: number; // default 0.15
  liquidityWeight: number; // default 0.15
  stabilityWeight: number; // default 0.15
  volatilityPenaltyWeight: number; // default 0.10
}

export const DEFAULT_TARGET_WEIGHTS: TargetEngineWeights = {
  interestDiffWeight: 0.30,
  momentumWeight: 0.15,
  realRateWeight: 0.15,
  liquidityWeight: 0.15,
  stabilityWeight: 0.15,
  volatilityPenaltyWeight: 0.10,
};

export function calculateTargetScores(
  fundingCurrencyCode: string = 'JPY',
  weights: TargetEngineWeights = DEFAULT_TARGET_WEIGHTS,
  candidates?: string[]
): TargetCurrencyScore[] {
  const funding = GLOBAL_CURRENCIES.find((c) => c.code === fundingCurrencyCode) || GLOBAL_CURRENCIES[2]; // JPY
  const list = candidates
    ? GLOBAL_CURRENCIES.filter((c) => candidates.includes(c.code) && c.code !== funding.code)
    : GLOBAL_CURRENCIES.filter((c) => c.code !== funding.code);

  const scores: TargetCurrencyScore[] = list.map((c) => {
    const interestDiff = c.policyRate - funding.policyRate;
    const fxMomentum3M = (c.cbExpectation6M * 0.05) + (c.gdpGrowth * 0.8) - (c.inflation * 0.2);
    const realRate = c.realRate;
    const liquidityFactor = c.liquidityScore / 100;
    const stabilityFactor = Math.max(0.1, 1 - (c.politicalRiskIndex / 100));
    const fxTrendFactor = 1 + (c.cbExpectation6M / 200);

    // Score calculations (normalized 0-100 scales)
    const diffScore = Math.min(100, Math.max(0, interestDiff * 6));
    const momentumScore = Math.min(100, Math.max(0, (fxMomentum3M + 5) * 10));
    const realRateScore = Math.min(100, Math.max(0, (realRate + 3) * 10));
    const liqScore = c.liquidityScore;
    const stabScore = Math.round(stabilityFactor * 100);
    const volPenaltyScore = Math.max(0, 100 - (c.volatility1Y * 4));

    // Weighted composite
    const composite =
      (diffScore * weights.interestDiffWeight) +
      (momentumScore * weights.momentumWeight) +
      (realRateScore * weights.realRateWeight) +
      (liqScore * weights.liquidityWeight) +
      (stabScore * weights.stabilityWeight) +
      (volPenaltyScore * weights.volatilityPenaltyWeight);

    const carryQualityScore = Math.min(100, Math.max(0, Math.round(composite)));

    return {
      code: c.code,
      name: c.name,
      policyRate: c.policyRate,
      interestDiffVsUSD: interestDiff,
      fxMomentum3M: parseFloat(fxMomentum3M.toFixed(2)),
      volatility: c.volatility1Y,
      realRate: c.realRate,
      carryQualityScore,
      liquidityFactor: parseFloat(liquidityFactor.toFixed(2)),
      stabilityFactor: parseFloat(stabilityFactor.toFixed(2)),
      fxTrendFactor: parseFloat(fxTrendFactor.toFixed(2)),
      rank: 0,
    };
  });

  scores.sort((a, b) => b.carryQualityScore - a.carryQualityScore);
  scores.forEach((s, idx) => {
    s.rank = idx + 1;
  });

  return scores;
}
