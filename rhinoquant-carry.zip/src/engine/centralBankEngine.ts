import { CentralBankRegimeInfo } from '../types/carry';
import { GLOBAL_CURRENCIES } from '../data/currencyData';

export function getCentralBankRegimes(): CentralBankRegimeInfo[] {
  return GLOBAL_CURRENCIES.map((c) => {
    const expectedRate12M = parseFloat((c.policyRate + (c.cbExpectation6M / 50)).toFixed(2));

    let hikeProbability = 15;
    let cutProbability = 15;

    if (c.centralBankRegime === 'EASING') {
      cutProbability = 85;
      hikeProbability = 5;
    } else if (c.centralBankRegime === 'TIGHTENING') {
      hikeProbability = 80;
      cutProbability = 10;
    } else if (c.centralBankRegime === 'REPRICING') {
      hikeProbability = 45;
      cutProbability = 45;
    } else if (c.centralBankRegime === 'POLICY SHOCK') {
      hikeProbability = 60;
      cutProbability = 30;
    } else {
      hikeProbability = 20;
      cutProbability = 20;
    }

    // Regime transition matrix simulation
    const transitionProbabilities = {
      EASING: c.centralBankRegime === 'EASING' ? 0.65 : 0.15,
      NEUTRAL: c.centralBankRegime === 'NEUTRAL' ? 0.60 : 0.25,
      TIGHTENING: c.centralBankRegime === 'TIGHTENING' ? 0.60 : 0.15,
      REPRICING: c.centralBankRegime === 'REPRICING' ? 0.50 : 0.20,
      POLICY_SHOCK: c.centralBankRegime === 'POLICY SHOCK' ? 0.40 : 0.05,
    };

    let cbName = `${c.code} Central Bank`;
    if (c.code === 'USD') cbName = 'Federal Reserve (Fed)';
    if (c.code === 'EUR') cbName = 'European Central Bank (ECB)';
    if (c.code === 'JPY') cbName = 'Bank of Japan (BOJ)';
    if (c.code === 'GBP') cbName = 'Bank of England (BOE)';
    if (c.code === 'CHF') cbName = 'Swiss National Bank (SNB)';
    if (c.code === 'AUD') cbName = 'Reserve Bank of Australia (RBA)';
    if (c.code === 'MXN') cbName = 'Banco de México (Banxico)';
    if (c.code === 'BRL') cbName = 'Banco Central do Brasil (BCB)';

    return {
      currency: c.code,
      cbName,
      currentRate: c.policyRate,
      expectedRate12M,
      regime: c.centralBankRegime,
      hikeProbability,
      cutProbability,
      transitionProbabilities,
    };
  });
}
