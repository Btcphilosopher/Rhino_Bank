import { CrashRiskMetric } from '../types/carry';
import { GLOBAL_CURRENCIES } from '../data/currencyData';
import { calculateCarryPair } from './carryEngine';

export function getCrashRiskForPair(fundingCode: string, targetCode: string): CrashRiskMetric {
  const pair = calculateCarryPair(fundingCode, targetCode);
  const funding = GLOBAL_CURRENCIES.find((c) => c.code === fundingCode) || GLOBAL_CURRENCIES[2];
  const target = GLOBAL_CURRENCIES.find((c) => c.code === targetCode) || GLOBAL_CURRENCIES[10];

  const fundingAppreciationRisk = parseFloat((funding.volatility1Y * 1.3).toFixed(1));
  const targetDepreciationRisk = parseFloat((target.volatility1Y * 1.5).toFixed(1));
  const volatilitySpikeRisk = parseFloat((pair.annualizedVol * 1.4).toFixed(1));
  const correlationBreakdownRisk = parseFloat((target.politicalRiskIndex * 0.75).toFixed(1));
  const liquidityDeteriorationRisk = parseFloat((100 - target.liquidityScore).toFixed(1));
  const leverageUnwindRisk = parseFloat(((pair.kurtosis * 12) + (target.politicalRiskIndex * 0.4)).toFixed(1));

  const crashScore = pair.carryCrashScore;

  return {
    pairName: pair.pairName,
    crashScore,
    warningState: pair.crashWarningState,
    fundingAppreciationRisk,
    targetDepreciationRisk,
    volatilitySpikeRisk,
    correlationBreakdownRisk,
    liquidityDeteriorationRisk,
    leverageUnwindRisk,
  };
}
