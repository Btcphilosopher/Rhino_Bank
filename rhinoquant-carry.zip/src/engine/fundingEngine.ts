import { GLOBAL_CURRENCIES } from '../data/currencyData';
import { FundingCurrencyScore } from '../types/carry';

export function calculateFundingScores(customCandidates?: string[]): FundingCurrencyScore[] {
  const candidates = customCandidates || ['USD', 'EUR', 'GBP', 'JPY', 'CHF', 'CNH', 'SGD', 'CAD'];

  const scores: FundingCurrencyScore[] = candidates.map((code) => {
    const currency = GLOBAL_CURRENCIES.find((c) => c.code === code) || GLOBAL_CURRENCIES[2];

    // Low policy rate = highly attractive funding currency
    const rateScore = Math.max(0, 100 - (currency.policyRate * 12));

    // Low volatility = stable funding
    const volScore = Math.max(0, 100 - (currency.volatility1Y * 6));

    // High liquidity = cheap transaction execution & tight swap spreads
    const liqScore = currency.liquidityScore;

    // Easing or neutral CB regime increases funding stability
    let regimeScore = 70;
    if (currency.centralBankRegime === 'EASING') regimeScore = 95;
    if (currency.centralBankRegime === 'NEUTRAL') regimeScore = 80;
    if (currency.centralBankRegime === 'TIGHTENING') regimeScore = 40;
    if (currency.centralBankRegime === 'REPRICING') regimeScore = 30;
    if (currency.centralBankRegime === 'POLICY SHOCK') regimeScore = 10;

    // Funding stress (0-100, higher = worse)
    const fundingStressScore = Math.round(
      Math.max(0, Math.min(100, (currency.volatility30D * 3.5) + (currency.politicalRiskIndex * 0.8) - (currency.liquidityScore * 0.3)))
    );

    // Dynamic Composite Attractiveness Score (0-100)
    // Rate weight: 40%, Vol weight: 20%, Liquidity weight: 20%, CB Regime: 20%
    const attractivenessRaw = (rateScore * 0.40) + (volScore * 0.20) + (liqScore * 0.20) + (regimeScore * 0.20);
    const attractivenessScore = Math.min(100, Math.max(0, Math.round(attractivenessRaw)));

    return {
      code: currency.code,
      name: currency.name,
      policyRate: currency.policyRate,
      fundingRate: currency.shortTermRate,
      volatility: currency.volatility1Y,
      liquidityScore: currency.liquidityScore,
      cbRegime: currency.centralBankRegime,
      fundingStressScore,
      attractivenessScore,
      rank: 0,
    };
  });

  // Sort descending by attractiveness score
  scores.sort((a, b) => b.attractivenessScore - a.attractivenessScore);

  // Assign ranks
  scores.forEach((s, idx) => {
    s.rank = idx + 1;
  });

  return scores;
}
