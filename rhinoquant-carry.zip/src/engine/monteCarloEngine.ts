import { MonteCarloSummary } from '../types/carry';

export function runMonteCarloSimulation(
  portfolioCarryAnnualPct: number = 8.5,
  portfolioVolAnnualPct: number = 12.0,
  leverage: number = 3.0,
  horizonDays: number = 252,
  simulationsCount: number = 2000
): MonteCarloSummary {
  // Deterministic seed simulation for reproducibility
  const dailyDrift = (portfolioCarryAnnualPct / 100) / 252;
  const dailyVol = (portfolioVolAnnualPct / 100) / Math.sqrt(252);

  const finalReturns: number[] = [];
  const maxDrawdowns: number[] = [];
  let lossCount = 0;
  let marginCallCount = 0;

  const dayPoints = 50; // Points for visual sample curve
  const step = Math.max(1, Math.floor(horizonDays / dayPoints));
  const samplePaths: number[][] = Array.from({ length: dayPoints + 1 }, () => []);

  for (let s = 0; s < simulationsCount; s++) {
    let currentLevel = 100.0;
    let peakLevel = 100.0;
    let maxDd = 0.0;
    let marginCall = false;

    // Pseudo-random Gaussian using Box-Muller transform with s seed
    for (let d = 0; d < horizonDays; d++) {
      const u1 = (Math.sin(s * 1000 + d * 13) + 1) / 2 || 0.0001;
      const u2 = (Math.cos(s * 500 + d * 17) + 1) / 2 || 0.0001;
      const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);

      // Volatility jump process (fat tails / crash risk)
      const isCrashStep = (d % 40 === 0 && Math.abs(z) > 1.8);
      const stepVol = isCrashStep ? dailyVol * 2.8 : dailyVol;
      const stepReturn = (dailyDrift - 0.5 * stepVol * stepVol) + stepVol * z;

      // Leveraged return
      currentLevel *= (1 + stepReturn * leverage);

      if (currentLevel > peakLevel) peakLevel = currentLevel;
      const dd = (peakLevel - currentLevel) / peakLevel;
      if (dd > maxDd) maxDd = dd;

      if (currentLevel < 100 * (1 - (0.8 / leverage))) {
        marginCall = true;
      }

      if (d % step === 0) {
        const pointIdx = Math.floor(d / step);
        if (pointIdx <= dayPoints) {
          samplePaths[pointIdx].push(currentLevel);
        }
      }
    }

    const returnPct = ((currentLevel - 100) / 100) * 100;
    finalReturns.push(returnPct);
    maxDrawdowns.push(maxDd * 100);

    if (returnPct < 0) lossCount++;
    if (marginCall) marginCallCount++;
  }

  // Sort returns for percentile calculations
  finalReturns.sort((a, b) => a - b);
  maxDrawdowns.sort((a, b) => a - b);

  const getPercentile = (arr: number[], p: number) => {
    const idx = Math.floor((p / 100) * arr.length);
    return arr[Math.min(arr.length - 1, Math.max(0, idx))];
  };

  const meanReturnPct = parseFloat((finalReturns.reduce((a, b) => a + b, 0) / simulationsCount).toFixed(2));
  const medianReturnPct = parseFloat(getPercentile(finalReturns, 50).toFixed(2));
  const percentile5thPct = parseFloat(getPercentile(finalReturns, 5).toFixed(2));
  const percentile25thPct = parseFloat(getPercentile(finalReturns, 25).toFixed(2));
  const percentile75thPct = parseFloat(getPercentile(finalReturns, 75).toFixed(2));
  const percentile95thPct = parseFloat(getPercentile(finalReturns, 95).toFixed(2));

  const var95Pct = parseFloat((-percentile5thPct).toFixed(2));
  
  // Tail loss (average of bottom 5%)
  const bottom5Count = Math.floor(simulationsCount * 0.05);
  const bottom5Sum = finalReturns.slice(0, bottom5Count).reduce((a, b) => a + b, 0);
  const expectedShortfall95Pct = parseFloat((-bottom5Sum / Math.max(1, bottom5Count)).toFixed(2));

  const maxDrawdownMedianPct = parseFloat(getPercentile(maxDrawdowns, 50).toFixed(2));
  const probabilityOfLossPct = parseFloat(((lossCount / simulationsCount) * 100).toFixed(1));
  const probabilityOfMarginCallPct = parseFloat(((marginCallCount / simulationsCount) * 100).toFixed(1));

  // Build percentile sample path curves for chart rendering
  const pathSample = samplePaths.map((vals, idx) => {
    vals.sort((a, b) => a - b);
    return {
      day: idx * step,
      p5: parseFloat(getPercentile(vals, 5).toFixed(2)),
      p50: parseFloat(getPercentile(vals, 50).toFixed(2)),
      p95: parseFloat(getPercentile(vals, 95).toFixed(2)),
    };
  });

  return {
    simulationsCount,
    horizonDays,
    meanReturnPct,
    medianReturnPct,
    percentile5thPct,
    percentile25thPct,
    percentile75thPct,
    percentile95thPct,
    var95Pct,
    expectedShortfall95Pct,
    maxDrawdownMedianPct,
    probabilityOfLossPct,
    probabilityOfMarginCallPct,
    expectedRecoveryDays: Math.round(maxDrawdownMedianPct * 2.8),
    pathSample,
  };
}
