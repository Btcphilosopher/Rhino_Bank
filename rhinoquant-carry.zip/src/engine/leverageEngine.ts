import { LeverageMetrics } from '../types/carry';

export function calculateLeverageMetrics(
  capitalUSD: number = 10000000, // $10M
  grossExposureUSD: number = 30000000, // $30M (3x leverage)
  marginRequirementPct: number = 5.0, // 5% initial margin
  maintenanceMarginPct: number = 3.0, // 3% maintenance margin
  grossCarryAnnualPct: number = 7.5,
  fundingCostPct: number = 1.2
): LeverageMetrics {
  const netExposureUSD = grossExposureUSD;
  const effectiveLeverage = capitalUSD > 0 ? parseFloat((grossExposureUSD / capitalUSD).toFixed(2)) : 1.0;

  const initialMarginReqUSD = grossExposureUSD * (marginRequirementPct / 100);
  const maintenanceMarginReqUSD = grossExposureUSD * (maintenanceMarginPct / 100);

  const grossCarryAnnualUSD = grossExposureUSD * (grossCarryAnnualPct / 100);
  const fundingCostUSD = grossExposureUSD * (fundingCostPct / 100);
  const netCarryAnnualUSD = grossCarryAnnualUSD - fundingCostUSD;

  // Return on Equity %
  const roeAnnualPct = capitalUSD > 0 ? parseFloat(((netCarryAnnualUSD / capitalUSD) * 100).toFixed(2)) : 0;

  // Margin Usage %
  const marginUsagePct = capitalUSD > 0 ? parseFloat(((initialMarginReqUSD / capitalUSD) * 100).toFixed(1)) : 0;

  // Margin Call Distance: how far can target currency depreciate before equity falls below maintenance margin
  // Capital remaining = Capital - (GrossExposure * FX_Drop_Pct)
  // Condition: Capital - (GrossExposure * FX_Drop) = MaintenanceMarginReq
  // FX_Drop = (Capital - MaintenanceMarginReq) / GrossExposure
  const marginCallDistancePct = capitalUSD > 0
    ? parseFloat((((capitalUSD - maintenanceMarginReqUSD) / grossExposureUSD) * 100).toFixed(2))
    : 0;

  const forcedLiquidationRiskPct = Math.min(100, Math.max(0, Math.round(Math.pow(effectiveLeverage, 1.8) * 4.5)));

  return {
    capitalUSD,
    grossExposureUSD,
    netExposureUSD,
    effectiveLeverage,
    marginRequirementPct,
    maintenanceMarginPct,
    haircutPct: 10.0,
    grossCarryAnnualUSD: parseFloat(grossCarryAnnualUSD.toFixed(0)),
    netCarryAnnualUSD: parseFloat(netCarryAnnualUSD.toFixed(0)),
    roeAnnualPct,
    marginUsagePct,
    marginCallDistancePct,
    forcedLiquidationRiskPct,
  };
}
