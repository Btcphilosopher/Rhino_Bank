import { Currency, CarryPair } from '../types/carry';
import { GLOBAL_CURRENCIES, SPOT_RATES_VS_USD } from '../data/currencyData';

export function calculateCarryPair(fundingCode: string, targetCode: string): CarryPair {
  const funding = GLOBAL_CURRENCIES.find((c) => c.code === fundingCode) || GLOBAL_CURRENCIES[2]; // fallback JPY
  const target = GLOBAL_CURRENCIES.find((c) => c.code === targetCode) || GLOBAL_CURRENCIES[10]; // fallback MXN

  const pairName = `${target.code}/${funding.code}`;

  // Rates
  const fundingRate = funding.policyRate;
  const targetRate = target.policyRate;
  const interestDiff = targetRate - fundingRate; // % per annum

  // Spot & Forward rates calculation
  // Base rate conversion vs USD
  const targetSpotUSD = SPOT_RATES_VS_USD[target.code] || 1;
  const fundingSpotUSD = SPOT_RATES_VS_USD[funding.code] || 1;

  // Cross spot rate
  let spotRate = 1;
  if (target.code === 'USD') {
    spotRate = fundingSpotUSD;
  } else if (funding.code === 'USD') {
    spotRate = targetSpotUSD;
  } else {
    spotRate = targetSpotUSD / fundingSpotUSD;
  }

  // Covered Interest Parity theoretical forward 1Y
  // F = S * (1 + targetRate/100) / (1 + fundingRate/100)
  const theoreticalForward = spotRate * ((1 + targetRate / 100) / (1 + fundingRate / 100));
  
  // Market CIP basis perturbation
  const cipDeviationBps = (target.politicalRiskIndex * 0.8) - (funding.politicalRiskIndex * 0.4) + (target.forwardPoints1Y / 10);
  const forward1Y = theoreticalForward * (1 + cipDeviationBps / 10000);

  // Expected annual carry
  const expectedCarryAnnual = interestDiff;

  // Realized historical simulation metrics
  // Simulated FX drift based on PPP & Momentum
  const pppDrift = -0.4 * target.reerValuation; // High valuation -> slight depreciation expected
  const momentumDrift = target.cbExpectation6M * 0.02;
  const fxReturn1Y = parseFloat((pppDrift + momentumDrift + (Math.sin(target.code.charCodeAt(0)) * 2.5)).toFixed(2));

  const totalReturn1Y = expectedCarryAnnual + fxReturn1Y;
  
  // Frictions
  const fundingCost = funding.shortTermRate * 0.1;
  const txCost = (100 - Math.min(target.liquidityScore, funding.liquidityScore)) * 0.03;
  const netReturn1Y = parseFloat((totalReturn1Y - fundingCost - txCost).toFixed(2));

  // Volatility calculation (combined FX & rate diff vol)
  const pairVol = Math.sqrt(Math.pow(target.volatility1Y, 2) + Math.pow(funding.volatility1Y, 2) * 0.5);
  const annualizedVol = parseFloat(pairVol.toFixed(2));

  // Risk Ratios
  const riskFreeRate = 2.0; // Benchmark RF %
  const sharpeRatio = parseFloat(((netReturn1Y - riskFreeRate) / Math.max(0.1, annualizedVol)).toFixed(2));
  
  const downsideDev = parseFloat((annualizedVol * 0.72).toFixed(2));
  const sortinoRatio = parseFloat(((netReturn1Y - riskFreeRate) / Math.max(0.1, downsideDev)).toFixed(2));

  // Drawdown & Crash metrics
  const maxDrawdown = parseFloat((annualizedVol * (1.8 + (target.politicalRiskIndex / 50))).toFixed(2));
  const calmarRatio = parseFloat((netReturn1Y / Math.max(0.1, maxDrawdown)).toFixed(2));

  // Statistical distribution metrics
  const skewness = parseFloat((-0.6 - (target.politicalRiskIndex / 100)).toFixed(2)); // Carry trades have negative skew
  const kurtosis = parseFloat((4.2 + (annualizedVol / 5)).toFixed(2)); // Fat tails
  const crashFrequency1Y = parseFloat((1.2 + (target.politicalRiskIndex / 30)).toFixed(1));

  // Scores
  // Carry Quality = (Interest Diff * Liquidity * Stability * Trend) / Vol
  const liquidityFactor = target.liquidityScore / 100;
  const stabilityFactor = 1 - (target.politicalRiskIndex / 100);
  const fxTrendFactor = 1 + (target.cbExpectation6M / 200);
  const qualityScoreRaw = (Math.max(0, interestDiff) * liquidityFactor * stabilityFactor * fxTrendFactor) / Math.max(1, annualizedVol);
  const carryQualityScore = Math.min(100, Math.max(0, Math.round(qualityScoreRaw * 25)));

  // Crash Score
  const fundingApprRisk = funding.volatility1Y * 1.2;
  const targetDeprRisk = target.volatility1Y * 1.5;
  const crashScoreRaw = (fundingApprRisk + targetDeprRisk + target.politicalRiskIndex * 0.6 + (kurtosis * 5)) / 2.5;
  const carryCrashScore = Math.min(100, Math.max(0, Math.round(crashScoreRaw)));

  let crashWarningState: CarryPair['crashWarningState'] = 'NORMAL';
  if (carryCrashScore >= 80) crashWarningState = 'CRASH CONDITIONS';
  else if (carryCrashScore >= 65) crashWarningState = 'SEVERE';
  else if (carryCrashScore >= 50) crashWarningState = 'HIGH';
  else if (carryCrashScore >= 35) crashWarningState = 'ELEVATED';

  return {
    fundingCode: funding.code,
    targetCode: target.code,
    pairName,
    spotRate: parseFloat(spotRate.toFixed(4)),
    forward1Y: parseFloat(forward1Y.toFixed(4)),
    fundingRate,
    targetRate,
    interestDiff: parseFloat(interestDiff.toFixed(2)),
    expectedCarryAnnual: parseFloat(expectedCarryAnnual.toFixed(2)),
    realizedCarry1Y: parseFloat(expectedCarryAnnual.toFixed(2)),
    fxReturn1Y,
    totalReturn1Y: parseFloat(totalReturn1Y.toFixed(2)),
    netReturn1Y,
    annualizedVol,
    sharpeRatio,
    sortinoRatio,
    calmarRatio,
    maxDrawdown,
    skewness,
    kurtosis,
    downsideDeviation: downsideDev,
    crashFrequency1Y,
    cipDeviationBps: parseFloat(cipDeviationBps.toFixed(1)),
    impliedForwardRate: parseFloat(theoreticalForward.toFixed(4)),
    carryQualityScore,
    carryCrashScore,
    crashWarningState,
  };
}

export function generateAllCarryPairs(fundingFilter?: string[], targetFilter?: string[]): CarryPair[] {
  const fundings = fundingFilter || ['JPY', 'CHF', 'EUR', 'USD', 'CNH'];
  const targets = targetFilter || ['MXN', 'BRL', 'ZAR', 'INR', 'TRY', 'PLN', 'HUF', 'IDR', 'CLP', 'AUD', 'NZD', 'EGP', 'NGN', 'KES', 'KZT'];

  const pairs: CarryPair[] = [];
  for (const f of fundings) {
    for (const t of targets) {
      if (f !== t) {
        pairs.push(calculateCarryPair(f, t));
      }
    }
  }

  // Sort by netReturn1Y descending by default
  return pairs.sort((a, b) => b.netReturn1Y - a.netReturn1Y);
}
