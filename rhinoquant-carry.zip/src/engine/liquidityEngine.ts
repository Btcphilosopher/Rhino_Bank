import { GLOBAL_CURRENCIES } from '../data/currencyData';

export interface FundingLiquidityMetrics {
  fundingStressIndex: number; // 0-100
  crossCurrencyBasisAvgBps: number;
  fxSwapSpreadAvgBps: number;
  fundingSpreadAvgBps: number;
  bidAskSpreadAvgPips: number;
  marketDepthScore: number; // 0-100
  liquidityAdjustedVar95USD: number;
  stressLevel: 'LOW' | 'MODERATE' | 'ELEVATED' | 'HIGH' | 'SYSTEMIC_CRUNCH';
}

export function calculateFundingLiquidityModel(
  portfolioNotionalUSD: number = 30000000,
  selectedFundingCodes: string[] = ['JPY', 'USD', 'EUR']
): FundingLiquidityMetrics {
  const fundings = GLOBAL_CURRENCIES.filter((c) => selectedFundingCodes.includes(c.code));
  
  const avgVol = fundings.reduce((acc, c) => acc + c.volatility30D, 0) / Math.max(1, fundings.length);
  const avgRisk = fundings.reduce((acc, c) => acc + c.politicalRiskIndex, 0) / Math.max(1, fundings.length);
  const avgDepth = fundings.reduce((acc, c) => acc + c.marketDepthUSD, 0) / Math.max(1, fundings.length);

  const crossCurrencyBasisAvgBps = parseFloat((avgVol * 3.8 + avgRisk * 0.4).toFixed(1));
  const fxSwapSpreadAvgBps = parseFloat((avgVol * 2.2 + 8.5).toFixed(1));
  const fundingSpreadAvgBps = parseFloat((avgVol * 1.8 + 12.0).toFixed(1));
  const bidAskSpreadAvgPips = parseFloat((1.2 + (1000 / Math.max(10, avgDepth))).toFixed(1));

  // Funding Stress Index calculation (0-100)
  const stressRaw = (crossCurrencyBasisAvgBps * 0.35) + (fxSwapSpreadAvgBps * 0.25) + (avgVol * 2.5) + (avgRisk * 0.3);
  const fundingStressIndex = Math.min(100, Math.max(0, Math.round(stressRaw)));

  let stressLevel: FundingLiquidityMetrics['stressLevel'] = 'LOW';
  if (fundingStressIndex >= 80) stressLevel = 'SYSTEMIC_CRUNCH';
  else if (fundingStressIndex >= 65) stressLevel = 'HIGH';
  else if (fundingStressIndex >= 45) stressLevel = 'ELEVATED';
  else if (fundingStressIndex >= 25) stressLevel = 'MODERATE';

  // Liquidity-adjusted VaR = standard VaR + (0.5 * Liquidity Cost)
  const standardVar95USD = portfolioNotionalUSD * 0.08 * 1.645;
  const liquidityCost = portfolioNotionalUSD * (bidAskSpreadAvgPips / 10000) * 4;
  const liquidityAdjustedVar95USD = parseFloat((standardVar95USD + liquidityCost).toFixed(0));

  return {
    fundingStressIndex,
    crossCurrencyBasisAvgBps,
    fxSwapSpreadAvgBps,
    fundingSpreadAvgBps,
    bidAskSpreadAvgPips,
    marketDepthScore: Math.round(Math.min(100, avgDepth / 25)),
    liquidityAdjustedVar95USD,
    stressLevel,
  };
}
