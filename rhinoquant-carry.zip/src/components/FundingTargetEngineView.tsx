import React, { useState } from 'react';
import { calculateFundingScores } from '../engine/fundingEngine';
import { calculateTargetScores, DEFAULT_TARGET_WEIGHTS, TargetEngineWeights } from '../engine/targetEngine';
import { SlidersHorizontal, ArrowRight, Zap, Award } from 'lucide-react';

export const FundingTargetEngineView: React.FC = () => {
  const [fundingCode, setFundingCode] = useState<string>('JPY');
  const [targetWeights, setTargetWeights] = useState<TargetEngineWeights>(DEFAULT_TARGET_WEIGHTS);

  const fundingScores = calculateFundingScores();
  const targetScores = calculateTargetScores(fundingCode, targetWeights);

  const handleWeightChange = (key: keyof TargetEngineWeights, val: number) => {
    setTargetWeights((prev) => ({
      ...prev,
      [key]: val,
    }));
  };

  return (
    <div className="space-y-6 text-slate-100">
      {/* Title */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
        <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
          <SlidersHorizontal className="w-5 h-5 text-cyan-400" />
          <span>Funding & Target Currency Quantitative Engines</span>
        </h2>
        <p className="text-xs text-slate-400">
          Section 2 & 3: Dynamic Funding Attractiveness Ranking & Composite Target Carry Quality Scoring with user-weighted parameters.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Section 2: Funding Currency Engine */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center space-x-1.5">
                <Zap className="w-4 h-4" />
                <span>Funding Currency Ranking Engine</span>
              </h3>
              <p className="text-[11px] text-slate-400">Evaluates low yield, low volatility, high market depth & central bank stability.</p>
            </div>
            <span className="text-xs bg-cyan-950 text-cyan-300 border border-cyan-800 px-2 py-0.5 rounded font-mono">
              Dynamic Environment
            </span>
          </div>

          <div className="space-y-2.5">
            {fundingScores.map((f) => {
              const isSelected = f.code === fundingCode;
              return (
                <div
                  key={f.code}
                  onClick={() => setFundingCode(f.code)}
                  className={`p-3 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'bg-cyan-950/60 border-cyan-500 ring-1 ring-cyan-500'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className="font-mono font-bold text-slate-500 text-sm">#{f.rank}</span>
                    <div>
                      <span className="font-bold font-mono text-slate-100 text-sm">{f.code}</span>
                      <span className="text-slate-400 text-xs ml-2">({f.name})</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4 font-mono text-xs">
                    <div>
                      <span className="text-slate-500 block text-[10px]">Policy Rate</span>
                      <span className="text-cyan-400 font-bold">{f.policyRate}%</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Funding Stress</span>
                      <span className={f.fundingStressScore > 50 ? 'text-rose-400' : 'text-emerald-400'}>
                        {f.fundingStressScore}/100
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-slate-500 block text-[10px]">Attractiveness Score</span>
                      <span className="bg-cyan-950 text-cyan-300 border border-cyan-800 px-2 py-0.5 rounded font-bold text-xs">
                        {f.attractivenessScore}/100
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Section 3: Target Currency Composite Engine */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center space-x-1.5">
                <Award className="w-4 h-4" />
                <span>Target Currency Composite Model</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Carry Quality = (Interest Diff × Liquidity × Stability × Trend) / Volatility
              </p>
            </div>

            <div className="text-right text-xs font-mono">
              <span className="text-slate-400">Selected Funding:</span>{' '}
              <strong className="text-cyan-400 font-bold">{fundingCode}</strong>
            </div>
          </div>

          {/* Interactive Weight Sliders */}
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-3 text-xs">
            <span className="font-bold text-slate-300 block mb-1">Model Weight Parameter Calibration:</span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Interest Diff Weight:</span>
                  <span className="font-mono text-emerald-400">{(targetWeights.interestDiffWeight * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.60"
                  step="0.05"
                  value={targetWeights.interestDiffWeight}
                  onChange={(e) => handleWeightChange('interestDiffWeight', parseFloat(e.target.value))}
                  className="w-full accent-emerald-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>FX Momentum Weight:</span>
                  <span className="font-mono text-emerald-400">{(targetWeights.momentumWeight * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.40"
                  step="0.05"
                  value={targetWeights.momentumWeight}
                  onChange={(e) => handleWeightChange('momentumWeight', parseFloat(e.target.value))}
                  className="w-full accent-emerald-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Real Rate Weight:</span>
                  <span className="font-mono text-emerald-400">{(targetWeights.realRateWeight * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.40"
                  step="0.05"
                  value={targetWeights.realRateWeight}
                  onChange={(e) => handleWeightChange('realRateWeight', parseFloat(e.target.value))}
                  className="w-full accent-emerald-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Liquidity Weight:</span>
                  <span className="font-mono text-emerald-400">{(targetWeights.liquidityWeight * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.40"
                  step="0.05"
                  value={targetWeights.liquidityWeight}
                  onChange={(e) => handleWeightChange('liquidityWeight', parseFloat(e.target.value))}
                  className="w-full accent-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Target Score Rankings */}
          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {targetScores.map((t) => (
              <div
                key={t.code}
                className="p-2.5 rounded-lg border border-slate-800 bg-slate-950 flex items-center justify-between text-xs font-mono"
              >
                <div className="flex items-center space-x-2">
                  <span className="text-slate-500 font-bold">#{t.rank}</span>
                  <span className="font-bold text-emerald-400 text-sm">{t.code}</span>
                  <span className="text-slate-400 text-[11px]">({t.name})</span>
                </div>

                <div className="flex items-center space-x-4">
                  <div>
                    <span className="text-slate-500 block text-[10px]">Diff vs {fundingCode}</span>
                    <span className="text-emerald-400 font-semibold">+{t.interestDiffVsUSD.toFixed(2)}%</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Real Rate</span>
                    <span className="text-slate-300">{t.realRate}%</span>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-500 block text-[10px]">Carry Quality</span>
                    <span className="bg-emerald-950 text-emerald-300 border border-emerald-800 px-2.5 py-0.5 rounded font-bold">
                      {t.carryQualityScore}/100
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
