import React, { useState } from 'react';
import { GLOBAL_CURRENCIES } from '../data/currencyData';
import { Currency } from '../types/carry';
import { ArrowUpDown, Globe } from 'lucide-react';

type SortOption =
  | 'BEST_CARRY'
  | 'BEST_RISK_ADJUSTED'
  | 'LOWEST_VOL'
  | 'LOWEST_CRASH_RISK'
  | 'BEST_LIQUIDITY'
  | 'HIGHEST_FUNDING_QUALITY';

export const CurrencyHeatmapView: React.FC = () => {
  const [sortOption, setSortOption] = useState<SortOption>('BEST_CARRY');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  const filteredCurrencies = GLOBAL_CURRENCIES.filter((c) => {
    if (categoryFilter === 'ALL') return true;
    return c.category === categoryFilter;
  });

  const sortedCurrencies = [...filteredCurrencies].sort((a, b) => {
    if (sortOption === 'BEST_CARRY') return b.policyRate - a.policyRate;
    if (sortOption === 'BEST_RISK_ADJUSTED') return (b.policyRate / b.volatility1Y) - (a.policyRate / a.volatility1Y);
    if (sortOption === 'LOWEST_VOL') return a.volatility1Y - b.volatility1Y;
    if (sortOption === 'LOWEST_CRASH_RISK') return a.politicalRiskIndex - b.politicalRiskIndex;
    if (sortOption === 'BEST_LIQUIDITY') return b.liquidityScore - a.liquidityScore;
    if (sortOption === 'HIGHEST_FUNDING_QUALITY') return a.policyRate - b.policyRate; // Lower rate = better funding
    return 0;
  });

  return (
    <div className="space-y-6 text-slate-100">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <Globe className="w-5 h-5 text-emerald-400" />
            <span>Global Currency Heatmap & Quantitative Matrix</span>
          </h2>
          <p className="text-xs text-slate-400">
            Real-time evaluation of G10, Developed, Emerging, and Frontier currencies across monetary policy, volatility, and macro risks.
          </p>
        </div>

        {/* Filter & Sort Controls */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div>
            <label className="text-slate-400 mr-2">Category:</label>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-slate-200 px-3 py-1.5 rounded font-mono focus:outline-none focus:border-emerald-500"
            >
              <option value="ALL">All Categories</option>
              <option value="G10">G10 Currencies</option>
              <option value="Developed">Developed Markets</option>
              <option value="Emerging">Emerging Markets</option>
              <option value="Frontier">Frontier Markets</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 mr-2">Sort By:</label>
            <select
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value as SortOption)}
              className="bg-slate-950 border border-slate-800 text-slate-200 px-3 py-1.5 rounded font-mono focus:outline-none focus:border-emerald-500"
            >
              <option value="BEST_CARRY">Highest Policy Rate (Best Target)</option>
              <option value="HIGHEST_FUNDING_QUALITY">Lowest Policy Rate (Best Funding)</option>
              <option value="BEST_RISK_ADJUSTED">Best Risk-Adjusted Carry (Rate/Vol)</option>
              <option value="LOWEST_VOL">Lowest Volatility</option>
              <option value="LOWEST_CRASH_RISK">Lowest Political & Tail Risk</option>
              <option value="BEST_LIQUIDITY">Best Market Liquidity</option>
            </select>
          </div>
        </div>
      </div>

      {/* Grid Heatmap Visual Tiles */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {sortedCurrencies.map((c) => {
          const isHighYield = c.policyRate >= 6.0;
          const isLowYield = c.policyRate <= 2.0;

          return (
            <div
              key={c.code}
              className={`p-3 rounded-lg border transition-all space-y-2 ${
                isHighYield
                  ? 'bg-emerald-950/40 border-emerald-800/80 hover:border-emerald-500'
                  : isLowYield
                  ? 'bg-cyan-950/40 border-cyan-800/80 hover:border-cyan-500'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-1.5">
                  <span className="text-base">{c.flag}</span>
                  <span className="font-bold font-mono text-slate-100">{c.code}</span>
                </div>
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                    c.category === 'G10'
                      ? 'bg-blue-950 text-blue-300 border border-blue-800'
                      : c.category === 'Emerging'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : 'bg-amber-950 text-amber-300 border border-amber-800'
                  }`}
                >
                  {c.category}
                </span>
              </div>

              <div>
                <span className="text-slate-400 text-[10px] block">Policy Rate</span>
                <span className="text-lg font-black font-mono text-emerald-400">{c.policyRate}%</span>
              </div>

              <div className="grid grid-cols-2 gap-1 text-[11px] font-mono pt-1 border-t border-slate-800/80 text-slate-300">
                <div>
                  <span className="text-slate-500 block text-[9px]">Real Rate</span>
                  <span>{c.realRate > 0 ? `+${c.realRate}` : c.realRate}%</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[9px]">1Y Vol</span>
                  <span>{c.volatility1Y}%</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Comprehensive Quantitative Heatmap Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
          Complete Currency Quantitative Analytics Matrix
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/60">
                <th className="p-2.5">Currency</th>
                <th className="p-2.5">Category</th>
                <th className="p-2.5 text-right">Policy Rate</th>
                <th className="p-2.5 text-right">Real Rate</th>
                <th className="p-2.5 text-right">30D Vol</th>
                <th className="p-2.5 text-right">1Y Vol</th>
                <th className="p-2.5 text-center">CB Regime</th>
                <th className="p-2.5 text-right">Inflation</th>
                <th className="p-2.5 text-center">Liquidity</th>
                <th className="p-2.5 text-center">Political Risk</th>
                <th className="p-2.5 text-right">REER Val.</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {sortedCurrencies.map((c) => (
                <tr key={c.code} className="hover:bg-slate-800/50 transition-colors">
                  <td className="p-2.5 font-bold text-slate-200">
                    <span className="mr-1.5">{c.flag}</span> {c.code}
                  </td>
                  <td className="p-2.5 text-slate-400">{c.category}</td>
                  <td className="p-2.5 text-right text-emerald-400 font-bold">{c.policyRate}%</td>
                  <td className="p-2.5 text-right text-slate-200">{c.realRate}%</td>
                  <td className="p-2.5 text-right text-slate-300">{c.volatility30D}%</td>
                  <td className="p-2.5 text-right text-slate-300">{c.volatility1Y}%</td>
                  <td className="p-2.5 text-center">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded border ${
                        c.centralBankRegime === 'EASING'
                          ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                          : c.centralBankRegime === 'TIGHTENING'
                          ? 'bg-rose-950 text-rose-300 border-rose-800'
                          : 'bg-slate-950 text-slate-400 border-slate-800'
                      }`}
                    >
                      {c.centralBankRegime}
                    </span>
                  </td>
                  <td className="p-2.5 text-right text-slate-300">{c.inflation}%</td>
                  <td className="p-2.5 text-center text-cyan-300">{c.liquidityScore}/100</td>
                  <td className="p-2.5 text-center text-amber-300">{c.politicalRiskIndex}/100</td>
                  <td className="p-2.5 text-right text-slate-300">{c.reerValuation > 0 ? `+${c.reerValuation}` : c.reerValuation}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
