import React, { useState } from 'react';
import { FlaskConical, Plus, Save, Play, CheckCircle } from 'lucide-react';

interface CustomFactor {
  id: string;
  name: string;
  yieldWeight: number;
  momentumWeight: number;
  volWeight: number;
  valuationWeight: number;
  cipBasisWeight: number;
}

export const ResearchLabView: React.FC = () => {
  const [factors, setFactors] = useState<CustomFactor[]>([
    {
      id: 'f1',
      name: 'Institutional Carry Alpha v1.2',
      yieldWeight: 0.4,
      momentumWeight: 0.2,
      volWeight: 0.2,
      valuationWeight: 0.1,
      cipBasisWeight: 0.1,
    },
    {
      id: 'f2',
      name: 'Tail-Hedged Macro Carry v2.0',
      yieldWeight: 0.3,
      momentumWeight: 0.1,
      volWeight: 0.3,
      valuationWeight: 0.15,
      cipBasisWeight: 0.15,
    },
  ]);

  const [activeFactorId, setActiveFactorId] = useState<string>('f1');
  const activeFactor = factors.find((f) => f.id === activeFactorId) || factors[0];

  const handleWeightChange = (key: keyof CustomFactor, val: number) => {
    setFactors((prev) =>
      prev.map((f) => (f.id === activeFactorId ? { ...f, [key]: val } : f))
    );
  };

  const handleCreateFactor = () => {
    const newFactor: CustomFactor = {
      id: `f-${Date.now()}`,
      name: `Custom Quant Strategy #${factors.length + 1}`,
      yieldWeight: 0.35,
      momentumWeight: 0.25,
      volWeight: 0.2,
      valuationWeight: 0.1,
      cipBasisWeight: 0.1,
    };
    setFactors([...factors, newFactor]);
    setActiveFactorId(newFactor.id);
  };

  return (
    <div className="space-y-6 text-slate-100">
      {/* Title */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
        <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
          <FlaskConical className="w-5 h-5 text-indigo-400" />
          <span>Institutional Research Laboratory & Custom Factor Studio</span>
        </h2>
        <p className="text-xs text-slate-400">
          Section 17: Build custom quantitative factors, test proprietary multi-signal strategies, and maintain versioned experiment logs.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Factor Preset Selector List */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Saved Quantitative Experiments
            </h3>
            <button
              onClick={handleCreateFactor}
              className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs px-2.5 py-1 rounded font-semibold flex items-center space-x-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Factor</span>
            </button>
          </div>

          <div className="space-y-2">
            {factors.map((f) => (
              <div
                key={f.id}
                onClick={() => setActiveFactorId(f.id)}
                className={`p-3 rounded-lg border text-xs cursor-pointer transition-all ${
                  f.id === activeFactorId
                    ? 'bg-indigo-950/60 border-indigo-500 ring-1 ring-indigo-500 text-slate-100'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="font-bold font-mono">{f.name}</div>
                <div className="text-[10px] text-slate-400 mt-1 font-mono">
                  Yield: {(f.yieldWeight * 100).toFixed(0)}% | Vol: {(f.volWeight * 100).toFixed(0)}% | Mom: {(f.momentumWeight * 100).toFixed(0)}%
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Custom Factor Builder */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold uppercase tracking-wider text-indigo-400 font-mono">
              Factor Weight Calibration Studio ({activeFactor.name})
            </h3>
            <div className="flex items-center space-x-2">
              <span className="text-xs bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-mono">
                Validated OOS
              </span>
            </div>
          </div>

          <div className="space-y-4 text-xs font-mono">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Interest Differential Weight:</span>
                <span className="text-indigo-400 font-bold">{(activeFactor.yieldWeight * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="0.8"
                step="0.05"
                value={activeFactor.yieldWeight}
                onChange={(e) => handleWeightChange('yieldWeight', Number(e.target.value))}
                className="w-full accent-indigo-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>FX Trend / Momentum Weight:</span>
                <span className="text-indigo-400 font-bold">{(activeFactor.momentumWeight * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="0.5"
                step="0.05"
                value={activeFactor.momentumWeight}
                onChange={(e) => handleWeightChange('momentumWeight', Number(e.target.value))}
                className="w-full accent-indigo-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Volatility Penalty Weight:</span>
                <span className="text-indigo-400 font-bold">{(activeFactor.volWeight * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="0.5"
                step="0.05"
                value={activeFactor.volWeight}
                onChange={(e) => handleWeightChange('volWeight', Number(e.target.value))}
                className="w-full accent-indigo-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>REER Macro Valuation Weight:</span>
                <span className="text-indigo-400 font-bold">{(activeFactor.valuationWeight * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="0.4"
                step="0.05"
                value={activeFactor.valuationWeight}
                onChange={(e) => handleWeightChange('valuationWeight', Number(e.target.value))}
                className="w-full accent-indigo-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>CIP Cross-Currency Basis Weight:</span>
                <span className="text-indigo-400 font-bold">{(activeFactor.cipBasisWeight * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="0.4"
                step="0.05"
                value={activeFactor.cipBasisWeight}
                onChange={(e) => handleWeightChange('cipBasisWeight', Number(e.target.value))}
                className="w-full accent-indigo-500"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
