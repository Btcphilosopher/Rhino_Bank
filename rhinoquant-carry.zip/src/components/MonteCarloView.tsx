import React, { useState } from 'react';
import { runMonteCarloSimulation } from '../engine/monteCarloEngine';
import { Zap, Activity, AlertTriangle, ShieldCheck } from 'lucide-react';

export const MonteCarloView: React.FC = () => {
  const [carryAnnualPct, setCarryAnnualPct] = useState<number>(8.5);
  const [volAnnualPct, setVolAnnualPct] = useState<number>(12.0);
  const [leverage, setLeverage] = useState<number>(3.0);
  const [simulationsCount, setSimulationsCount] = useState<number>(2000);

  const mcResult = runMonteCarloSimulation(carryAnnualPct, volAnnualPct, leverage, 252, simulationsCount);

  return (
    <div className="space-y-6 text-slate-100">
      {/* Title */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
        <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
          <Zap className="w-5 h-5 text-amber-400" />
          <span>Monte Carlo Stochastic Path Engine</span>
        </h2>
        <p className="text-xs text-slate-400">
          Section 14: Stochastic FX path simulation (2,000+ paths), jump-diffusion volatility regimes, margin failure probability, and VaR/Expected Shortfall distribution.
        </p>
      </div>

      {/* Inputs & Controls Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs font-mono">
          <div>
            <label className="text-slate-400 block mb-1">Portfolio Carry (% p.a.):</label>
            <input
              type="number"
              value={carryAnnualPct}
              onChange={(e) => setCarryAnnualPct(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-emerald-400 font-bold p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Portfolio Volatility (% p.a.):</label>
            <input
              type="number"
              value={volAnnualPct}
              onChange={(e) => setVolAnnualPct(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Leverage Multiple:</label>
            <input
              type="number"
              value={leverage}
              onChange={(e) => setLeverage(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-amber-400 font-bold p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Simulations Count:</label>
            <select
              value={simulationsCount}
              onChange={(e) => setSimulationsCount(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-cyan-400 font-bold p-2 rounded w-full"
            >
              <option value="1000">1,000 Paths</option>
              <option value="2000">2,000 Paths</option>
              <option value="5000">5,000 Paths</option>
            </select>
          </div>
        </div>

        {/* Output Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-xs pt-2">
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Median 1Y Return</span>
            <span className="text-base font-bold text-emerald-400">+{mcResult.medianReturnPct}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">5th Percentile (VaR 95)</span>
            <span className="text-base font-bold text-rose-400">{mcResult.percentile5thPct}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Expected Shortfall 95</span>
            <span className="text-base font-bold text-rose-400">-{mcResult.expectedShortfall95Pct}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Prob. of Negative Return</span>
            <span className="text-base font-bold text-amber-400">{mcResult.probabilityOfLossPct}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Prob. of Margin Failure</span>
            <span className="text-base font-bold text-rose-400">{mcResult.probabilityOfMarginCallPct}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Expected Recovery Days</span>
            <span className="text-base font-bold text-slate-200">{mcResult.expectedRecoveryDays} Days</span>
          </div>
        </div>
      </div>

      {/* Stochastic Percentile Paths Visualizer */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
          Stochastic Equity Path Simulation Envelope (5th, 50th, 95th Percentile)
        </h3>

        <div className="h-64 w-full bg-slate-950 rounded-lg border border-slate-800 p-4 flex flex-col justify-between font-mono text-xs text-slate-500 relative overflow-hidden">
          {/* Visual sample path curves */}
          <svg className="absolute inset-0 w-full h-full p-4 overflow-visible" preserveAspectRatio="none">
            {/* 95th Percentile path (green) */}
            <path
              d={`M ${mcResult.pathSample.map((p, idx) => `${(idx / mcResult.pathSample.length) * 100}%, ${100 - (p.p95 - 80) * 1.5}%`).join(' L ')}`}
              fill="none"
              stroke="#10B981"
              strokeWidth="2"
            />
            {/* 50th Percentile path (cyan) */}
            <path
              d={`M ${mcResult.pathSample.map((p, idx) => `${(idx / mcResult.pathSample.length) * 100}%, ${100 - (p.p50 - 80) * 1.5}%`).join(' L ')}`}
              fill="none"
              stroke="#06B6D4"
              strokeWidth="2"
            />
            {/* 5th Percentile path (rose) */}
            <path
              d={`M ${mcResult.pathSample.map((p, idx) => `${(idx / mcResult.pathSample.length) * 100}%, ${100 - (p.p5 - 80) * 1.5}%`).join(' L ')}`}
              fill="none"
              stroke="#EF4444"
              strokeWidth="2"
              strokeDasharray="4,4"
            />
          </svg>

          <div className="flex justify-between z-10 text-[11px]">
            <span className="text-emerald-400 font-bold">95th Percentile (Best Case: +{mcResult.percentile95thPct}%)</span>
            <span className="text-cyan-400 font-bold">Median Path (+{mcResult.medianReturnPct}%)</span>
            <span className="text-rose-400 font-bold">5th Percentile (Worst Case: {mcResult.percentile5thPct}%)</span>
          </div>

          <div className="flex justify-between z-10 text-[10px] text-slate-500 border-t border-slate-800/80 pt-2">
            <span>Day 0 (Initial Equity 100.0)</span>
            <span>Day 126</span>
            <span>Day 252 (1 Year Horizon)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
