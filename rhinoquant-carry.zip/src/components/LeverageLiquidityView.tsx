import React, { useState } from 'react';
import { calculateLeverageMetrics } from '../engine/leverageEngine';
import { calculateFundingLiquidityModel } from '../engine/liquidityEngine';
import { Gauge, Layers, AlertOctagon, TrendingUp, AlertTriangle } from 'lucide-react';

export const LeverageLiquidityView: React.FC = () => {
  const [capitalUSD, setCapitalUSD] = useState<number>(10000000); // $10M
  const [grossExposureUSD, setGrossExposureUSD] = useState<number>(30000000); // $30M (3x)
  const [marginReqPct, setMarginReqPct] = useState<number>(5.0);
  const [maintMarginPct, setMaintMarginPct] = useState<number>(3.0);
  const [grossCarryPct, setGrossCarryPct] = useState<number>(9.5);
  const [fundingCostPct, setFundingCostPct] = useState<number>(1.5);

  const levMetrics = calculateLeverageMetrics(
    capitalUSD,
    grossExposureUSD,
    marginReqPct,
    maintMarginPct,
    grossCarryPct,
    fundingCostPct
  );

  const liqMetrics = calculateFundingLiquidityModel(grossExposureUSD, ['JPY', 'USD', 'EUR']);

  return (
    <div className="space-y-6 text-slate-100">
      {/* Title */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
        <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
          <Gauge className="w-5 h-5 text-amber-400" />
          <span>Leverage Stress & Funding-Liquidity Engine</span>
        </h2>
        <p className="text-xs text-slate-400">
          Section 11 & 12: Explicit leverage amplification modeling, margin-call distance calculation, forced-liquidation threshold, and Funding Stress Index.
        </p>
      </div>

      {/* Section 11: Interactive Leverage Stress Simulator */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-2 border-b border-slate-800 pb-2">
          <AlertOctagon className="w-4 h-4" />
          <span>Section 11: Explicit Leverage & Margin Call Distance Engine</span>
        </h3>

        {/* Inputs Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs font-mono">
          <div>
            <label className="text-slate-400 block mb-1">Capital ($USD):</label>
            <input
              type="number"
              value={capitalUSD}
              onChange={(e) => setCapitalUSD(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Gross Exposure ($USD):</label>
            <input
              type="number"
              value={grossExposureUSD}
              onChange={(e) => setGrossExposureUSD(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Init Margin Req %:</label>
            <input
              type="number"
              value={marginReqPct}
              onChange={(e) => setMarginReqPct(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Maintenance Margin %:</label>
            <input
              type="number"
              value={maintMarginPct}
              onChange={(e) => setMaintMarginPct(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Gross Target Yield %:</label>
            <input
              type="number"
              value={grossCarryPct}
              onChange={(e) => setGrossCarryPct(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-emerald-400 p-2 rounded w-full font-bold"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Funding Cost %:</label>
            <input
              type="number"
              value={fundingCostPct}
              onChange={(e) => setFundingCostPct(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-cyan-400 p-2 rounded w-full font-bold"
            />
          </div>
        </div>

        {/* Calculated Output Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-xs pt-2">
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Effective Leverage</span>
            <span className="text-base font-bold text-amber-400">{levMetrics.effectiveLeverage}x</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Net Annual Carry ($)</span>
            <span className="text-base font-bold text-emerald-400">${(levMetrics.netCarryAnnualUSD / 1000).toFixed(0)}k</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Leveraged ROE (%)</span>
            <span className="text-base font-bold text-emerald-400">+{levMetrics.roeAnnualPct}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Margin Usage (%)</span>
            <span className="text-base font-bold text-cyan-400">{levMetrics.marginUsagePct}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Margin-Call Distance</span>
            <span className="text-base font-bold text-rose-400">-{levMetrics.marginCallDistancePct}% FX Drop</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Forced Liquidation Risk</span>
            <span className="text-base font-bold text-rose-400">{levMetrics.forcedLiquidationRiskPct}%</span>
          </div>
        </div>
      </div>

      {/* Section 12: Funding Stress Index & Liquidity Analytics */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center space-x-2 border-b border-slate-800 pb-2">
          <Layers className="w-4 h-4" />
          <span>Section 12: Institutional Funding Stress Index & Liquidity-Adjusted VaR (L-VaR)</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs">
          <div className="bg-slate-950 p-4 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Funding Stress Index</span>
            <span className="text-2xl font-black text-amber-400">{liqMetrics.fundingStressIndex} / 100</span>
            <span className="text-[10px] text-slate-500 block mt-1">Level: {liqMetrics.stressLevel}</span>
          </div>

          <div className="bg-slate-950 p-4 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Cross-Currency Basis Avg</span>
            <span className="text-2xl font-black text-indigo-400">{liqMetrics.crossCurrencyBasisAvgBps} bps</span>
            <span className="text-[10px] text-slate-500 block mt-1">FX Swap Spread: {liqMetrics.fxSwapSpreadAvgBps} bps</span>
          </div>

          <div className="bg-slate-950 p-4 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Bid/Ask Spread Avg</span>
            <span className="text-2xl font-black text-slate-200">{liqMetrics.bidAskSpreadAvgPips} pips</span>
            <span className="text-[10px] text-slate-500 block mt-1">Depth Score: {liqMetrics.marketDepthScore}/100</span>
          </div>

          <div className="bg-slate-950 p-4 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Liquidity-Adjusted VaR 95%</span>
            <span className="text-2xl font-black text-rose-400">${(liqMetrics.liquidityAdjustedVar95USD / 1000).toFixed(0)}k</span>
            <span className="text-[10px] text-slate-500 block mt-1">Includes liquidation slippage cost</span>
          </div>
        </div>
      </div>
    </div>
  );
};
