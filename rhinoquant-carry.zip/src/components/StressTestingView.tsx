import React, { useState } from 'react';
import { getPredefinedStressScenarios, simulateCustomStressScenario } from '../engine/stressEngine';
import { Flame, AlertTriangle, ShieldAlert, Play, RefreshCw } from 'lucide-react';

export const StressTestingView: React.FC = () => {
  const predefined = getPredefinedStressScenarios();

  const [fundingShock, setFundingShock] = useState<number>(18.0);
  const [targetShock, setTargetShock] = useState<number>(-22.0);
  const [volMultiplier, setVolMultiplier] = useState<number>(3.0);
  const [rateShift, setRateShift] = useState<number>(-150);
  const [liquidityHaircut, setLiquidityHaircut] = useState<number>(25.0);
  const [leverage, setLeverage] = useState<number>(3.0);

  const customScenario = simulateCustomStressScenario(
    fundingShock,
    targetShock,
    volMultiplier,
    rateShift,
    liquidityHaircut,
    leverage
  );

  return (
    <div className="space-y-6 text-slate-100">
      {/* Title */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
        <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
          <Flame className="w-5 h-5 text-rose-400" />
          <span>Institutional Stress Testing & Scenario Simulator</span>
        </h2>
        <p className="text-xs text-slate-400">
          Section 13: Simulate historical financial crisis shocks (2008 GFC, 2011 Eurozone, 2020 COVID, 2022 Rate Hikes, 2024 JPY Carry Unwind) and model custom stress scenarios.
        </p>
      </div>

      {/* Predefined Scenarios Matrix */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
          Predefined Historical Crisis Scenarios
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {predefined.map((sc) => (
            <div
              key={sc.id}
              className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3 font-mono text-xs"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-slate-100 text-sm">{sc.name}</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                    sc.marginCallTriggered
                      ? 'bg-rose-950 text-rose-300 border-rose-800 animate-pulse'
                      : 'bg-amber-950 text-amber-300 border-amber-800'
                  }`}
                >
                  {sc.marginCallTriggered ? 'MARGIN CALL' : 'SURVIVED'}
                </span>
              </div>

              <p className="text-[11px] text-slate-400 font-sans leading-normal">{sc.description}</p>

              <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-slate-800/80">
                <div>
                  <span className="text-slate-500 block text-[9px]">Target FX Shock</span>
                  <span className="text-rose-400 font-bold">{sc.targetFxShockPct}%</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[9px]">Funding FX Shock</span>
                  <span className="text-amber-400 font-bold">+{sc.fundingFxShockPct}%</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[9px]">Portfolio Drawdown</span>
                  <span className="text-rose-400 font-bold text-sm">-{sc.portfolioDrawdownPct}%</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[9px]">Recovery Period</span>
                  <span className="text-slate-200 font-bold">{sc.estimatedRecoveryMonths} months</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Custom Scenario Interactive Builder */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-rose-400 flex items-center space-x-2 border-b border-slate-800 pb-2">
          <Play className="w-4 h-4 text-rose-400" />
          <span>Interactive Custom Shock Scenario Engine</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs font-mono">
          <div className="space-y-1">
            <div className="flex justify-between text-slate-300">
              <span>Target Currency Drop:</span>
              <span className="text-rose-400 font-bold">{targetShock}%</span>
            </div>
            <input
              type="range"
              min="-50"
              max="0"
              step="1"
              value={targetShock}
              onChange={(e) => setTargetShock(Number(e.target.value))}
              className="w-full accent-rose-500"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-slate-300">
              <span>Funding Currency Surge:</span>
              <span className="text-amber-400 font-bold">+{fundingShock}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="40"
              step="1"
              value={fundingShock}
              onChange={(e) => setFundingShock(Number(e.target.value))}
              className="w-full accent-amber-500"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-slate-300">
              <span>Volatility Multiplier:</span>
              <span className="text-purple-400 font-bold">{volMultiplier}x</span>
            </div>
            <input
              type="range"
              min="1.0"
              max="6.0"
              step="0.5"
              value={volMultiplier}
              onChange={(e) => setVolMultiplier(Number(e.target.value))}
              className="w-full accent-purple-500"
            />
          </div>
        </div>

        {/* Custom Scenario Outcome Card */}
        <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
          <div>
            <span className="text-slate-400 block text-[10px]">Simulated Portfolio Drawdown</span>
            <span className="text-2xl font-black text-rose-400">-{customScenario.portfolioDrawdownPct}%</span>
          </div>

          <div>
            <span className="text-slate-400 block text-[10px]">Margin Call Status</span>
            <span
              className={`text-sm font-bold px-2.5 py-0.5 rounded border ${
                customScenario.marginCallTriggered
                  ? 'bg-rose-950 text-rose-300 border-rose-800 animate-pulse'
                  : 'bg-emerald-950 text-emerald-300 border-emerald-800'
              }`}
            >
              {customScenario.marginCallTriggered ? 'FORCED LIQUIDATION TRIGGERED' : 'MARGIN OK'}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block text-[10px]">Estimated Recovery Time</span>
            <span className="text-lg font-bold text-slate-200">{customScenario.estimatedRecoveryMonths} Months</span>
          </div>
        </div>
      </div>
    </div>
  );
};
