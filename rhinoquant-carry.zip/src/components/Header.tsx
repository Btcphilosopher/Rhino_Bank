import React from 'react';
import { 
  BarChart3, 
  Globe2, 
  Layers, 
  Zap, 
  SlidersHorizontal, 
  ShieldAlert, 
  Bot, 
  PieChart, 
  Activity, 
  Flame, 
  TrendingUp, 
  Ticket, 
  FlaskConical, 
  FileSpreadsheet,
  Gauge
} from 'lucide-react';

export type NavTab = 
  | 'dashboard'
  | 'heatmap'
  | 'fundingTarget'
  | 'cipBasis'
  | 'carryVolCrash'
  | 'centralBank'
  | 'mlResearch'
  | 'portfolio'
  | 'leverageLiquidity'
  | 'stressTesting'
  | 'monteCarlo'
  | 'backtester'
  | 'tradeTicket'
  | 'researchLab'
  | 'auditTrail';

interface HeaderProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  fundingStressIndex: number;
  crashRiskScore: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  fundingStressIndex,
  crashRiskScore,
}) => {
  const tabs: { id: NavTab; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', label: 'Terminal Overview', icon: <BarChart3 className="w-3.5 h-3.5" /> },
    { id: 'heatmap', label: 'Global Heatmap', icon: <Globe2 className="w-3.5 h-3.5" /> },
    { id: 'fundingTarget', label: 'Funding & Target', icon: <SlidersHorizontal className="w-3.5 h-3.5" /> },
    { id: 'cipBasis', label: 'CIP / Basis', icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'carryVolCrash', label: 'Vol & Crash Matrix', icon: <ShieldAlert className="w-3.5 h-3.5" /> },
    { id: 'centralBank', label: 'Central Banks', icon: <Activity className="w-3.5 h-3.5" /> },
    { id: 'mlResearch', label: 'ML Models', icon: <Bot className="w-3.5 h-3.5" /> },
    { id: 'portfolio', label: 'Portfolio Optimizer', icon: <PieChart className="w-3.5 h-3.5" /> },
    { id: 'leverageLiquidity', label: 'Leverage & Liquidity', icon: <Gauge className="w-3.5 h-3.5" /> },
    { id: 'stressTesting', label: 'Stress Testing', icon: <Flame className="w-3.5 h-3.5" /> },
    { id: 'monteCarlo', label: 'Monte Carlo', icon: <Zap className="w-3.5 h-3.5" /> },
    { id: 'backtester', label: 'Backtester', icon: <TrendingUp className="w-3.5 h-3.5" /> },
    { id: 'tradeTicket', label: 'Trade Ticket & Breakeven', icon: <Ticket className="w-3.5 h-3.5" /> },
    { id: 'researchLab', label: 'Research Lab', icon: <FlaskConical className="w-3.5 h-3.5" /> },
    { id: 'auditTrail', label: 'Audit Trail', icon: <FileSpreadsheet className="w-3.5 h-3.5" /> },
  ];

  return (
    <header className="bg-[#0A0A0A] border-b border-[#222] text-[#D1D1D1] sticky top-0 z-50 shadow-2xl">
      {/* Top Ticker & Status Bar */}
      <div className="flex flex-wrap items-center justify-between px-6 py-3 border-b border-[#222] bg-[#0A0A0A] gap-3">
        <div className="flex items-center space-x-4">
          <div className="text-[#F27D26] font-black text-xl tracking-tighter flex items-center space-x-1.5 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <span>RHINOQUANT</span>
            <span className="font-light text-white opacity-80">CARRY</span>
          </div>

          <div className="h-4 w-[1px] bg-[#333]"></div>

          <div className="flex items-center space-x-2 text-[10px] uppercase tracking-widest text-[#888]">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>Global Market Feed Active</span>
          </div>

          <div className="hidden xl:flex items-center space-x-4 border-l border-[#222] pl-4 text-[11px] font-mono">
            <div>
              <span className="text-[#666]">USD/JPY:</span>{' '}
              <span className="text-emerald-400 font-medium">145.20</span>
            </div>
            <div>
              <span className="text-[#666]">USD/MXN:</span>{' '}
              <span className="text-[#F27D26] font-medium">19.65</span>
            </div>
            <div>
              <span className="text-[#666]">USD/BRL:</span>{' '}
              <span className="text-cyan-400 font-medium">5.58</span>
            </div>
            <div>
              <span className="text-[#666]">US10Y:</span>{' '}
              <span className="text-white">3.85%</span>
            </div>
            <div>
              <span className="text-[#666]">VIX:</span>{' '}
              <span className="text-rose-400">16.4</span>
            </div>
          </div>
        </div>

        {/* Global Risk Gauges & System Time */}
        <div className="flex items-center space-x-4 text-[11px] font-mono">
          <div className="flex items-center space-x-2 bg-[#0F0F0F] px-3 py-1 rounded border border-[#222]">
            <span className="text-[#888]">Funding Stress:</span>
            <span
              className={`font-bold ${
                fundingStressIndex > 65
                  ? 'text-rose-400'
                  : fundingStressIndex > 40
                  ? 'text-[#F27D26]'
                  : 'text-emerald-400'
              }`}
            >
              {fundingStressIndex}/100
            </span>
          </div>

          <div className="flex items-center space-x-2 bg-[#0F0F0F] px-3 py-1 rounded border border-[#222]">
            <span className="text-[#888]">Crash Risk:</span>
            <span
              className={`font-bold ${
                crashRiskScore > 65
                  ? 'text-rose-400 animate-pulse'
                  : crashRiskScore > 40
                  ? 'text-[#F27D26]'
                  : 'text-emerald-400'
              }`}
            >
              {crashRiskScore}/100
            </span>
          </div>

          <div className="flex flex-col items-end leading-none border-l border-[#333] pl-4">
            <span className="text-[#888] mb-1 text-[9px] uppercase tracking-wider">RISK REGIME</span>
            <span className="text-emerald-400 font-bold text-[10px]">NORMAL / LOW VOL</span>
          </div>
        </div>
      </div>

      {/* Navigation Sub-bar */}
      <div className="flex items-center overflow-x-auto no-scrollbar px-4 py-1.5 bg-[#050505] gap-1 text-[11px] border-b border-[#1A1A1A]">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-[#1A1A1A] text-[#F27D26] font-bold border border-[#F27D26]/40 shadow-sm'
                  : 'text-[#888] hover:text-white hover:bg-[#0F0F0F] border border-transparent'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
