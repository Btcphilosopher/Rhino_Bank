import React, { useState } from 'react';
import { runBacktest, BacktestStrategy, DEFAULT_BACKTEST_OPTIONS } from '../engine/backtestEngine';
import { TrendingUp, RefreshCw, BarChart2, Calendar } from 'lucide-react';

export const BacktestView: React.FC = () => {
  const [strategy, setStrategy] = useState<BacktestStrategy>('CARRY_QUALITY');
  const [rebalanceFrequency, setRebalanceFrequency] = useState<'DAILY' | 'WEEKLY' | 'MONTHLY'>('MONTHLY');
  const [leverage, setLeverage] = useState<number>(2.5);
  const [bidAskSpreadBps, setBidAskSpreadBps] = useState<number>(8);
  const [slippageBps, setSlippageBps] = useState<number>(5);

  const backtestResult = runBacktest({
    strategy,
    rebalanceFrequency,
    initialCapital: 10000000,
    leverage,
    bidAskSpreadBps,
    slippageBps,
    financingCostBps: 25,
  });

  return (
    <div className="space-y-6 text-slate-100">
      {/* Title */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
        <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
          <TrendingUp className="w-5 h-5 text-emerald-400" />
          <span>Institutional Quantitative Carry Backtesting Engine</span>
        </h2>
        <p className="text-xs text-slate-400">
          Section 15: Historical quantitative strategy simulation with transaction cost friction, slippage, roll financing, and rebalancing options. Zero lookahead bias.
        </p>
      </div>

      {/* Strategy Selector & Execution Controls */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 text-xs font-mono">
          <div>
            <label className="text-slate-400 block mb-1">Quantitative Strategy Rule:</label>
            <select
              value={strategy}
              onChange={(e) => setStrategy(e.target.value as BacktestStrategy)}
              className="bg-slate-950 border border-slate-800 text-emerald-400 font-bold p-2 rounded w-full"
            >
              <option value="HIGH_CARRY">High Carry Unconstrained</option>
              <option value="CARRY_MOMENTUM">Carry + FX Momentum Filter</option>
              <option value="CARRY_LOW_VOL">Carry + Low Volatility Filter</option>
              <option value="CARRY_QUALITY">Carry + Composite Quality Score</option>
              <option value="CARRY_REGIME_FILTER">Carry + CB Regime Filter</option>
              <option value="CARRY_CRASH_FILTER">Carry + Crash Risk Filter</option>
              <option value="CARRY_ML_SIGNAL">Carry + ML Signal Generator</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Rebalancing Frequency:</label>
            <select
              value={rebalanceFrequency}
              onChange={(e) => setRebalanceFrequency(e.target.value as any)}
              className="bg-slate-950 border border-slate-800 text-slate-200 font-bold p-2 rounded w-full"
            >
              <option value="DAILY">Daily Rebalance</option>
              <option value="WEEKLY">Weekly Rebalance</option>
              <option value="MONTHLY">Monthly Rebalance</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Leverage Multiple:</label>
            <input
              type="number"
              value={leverage}
              onChange={(e) => setLeverage(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-amber-400 font-bold p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Bid/Ask Spread (bps):</label>
            <input
              type="number"
              value={bidAskSpreadBps}
              onChange={(e) => setBidAskSpreadBps(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Execution Slippage (bps):</label>
            <input
              type="number"
              value={slippageBps}
              onChange={(e) => setSlippageBps(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded w-full"
            />
          </div>
        </div>

        {/* Strategy Tear Sheet Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 font-mono text-xs pt-2">
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">CAGR</span>
            <span className="text-sm font-bold text-emerald-400">+{backtestResult.cagrPct}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Annual Vol</span>
            <span className="text-sm font-bold text-slate-200">{backtestResult.annualizedVolPct}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Sharpe Ratio</span>
            <span className="text-sm font-bold text-emerald-400">{backtestResult.sharpeRatio}</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Sortino Ratio</span>
            <span className="text-sm font-bold text-emerald-400">{backtestResult.sortinoRatio}</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Max Drawdown</span>
            <span className="text-sm font-bold text-rose-400">-{backtestResult.maxDrawdownPct}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Calmar Ratio</span>
            <span className="text-sm font-bold text-cyan-400">{backtestResult.calmarRatio}</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Win Rate</span>
            <span className="text-sm font-bold text-emerald-400">{backtestResult.winRatePct}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Profit Factor</span>
            <span className="text-sm font-bold text-slate-100">{backtestResult.profitFactor}</span>
          </div>
        </div>
      </div>

      {/* Equity Curve Visualizer */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
          Strategy Historical Equity Growth vs Drawdown Underwater Chart
        </h3>

        <div className="h-64 w-full bg-slate-950 rounded-lg border border-slate-800 p-4 flex flex-col justify-between font-mono text-xs text-slate-500 relative overflow-hidden">
          <svg className="absolute inset-0 w-full h-full p-4 overflow-visible" preserveAspectRatio="none">
            {/* Equity Curve (emerald) */}
            <path
              d={`M ${backtestResult.equityCurve.map((eq, idx) => `${(idx / backtestResult.equityCurve.length) * 100}%, ${100 - ((eq.equity - 10000000) / 10000000) * 80}%`).join(' L ')}`}
              fill="none"
              stroke="#10B981"
              strokeWidth="2.5"
            />
          </svg>

          <div className="flex justify-between z-10 text-[11px]">
            <span className="text-slate-400">Initial Capital: $10.0M</span>
            <span className="text-emerald-400 font-bold">
              Final Capital: ${(backtestResult.finalCapital / 1000000).toFixed(2)}M
            </span>
          </div>

          <div className="flex justify-between z-10 text-[10px] text-slate-500 border-t border-slate-800/80 pt-2">
            <span>{backtestResult.startDate}</span>
            <span>5-Year Cumulative Equity Curve</span>
            <span>{backtestResult.endDate}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
