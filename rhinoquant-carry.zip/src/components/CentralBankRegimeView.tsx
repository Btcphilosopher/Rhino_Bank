import React from 'react';
import { getCentralBankRegimes } from '../engine/centralBankEngine';
import { Activity, ArrowRightLeft, TrendingUp, AlertCircle } from 'lucide-react';

export const CentralBankRegimeView: React.FC = () => {
  const cbRegimes = getCentralBankRegimes();

  return (
    <div className="space-y-6 text-slate-100">
      {/* Title */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
        <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
          <Activity className="w-5 h-5 text-emerald-400" />
          <span>Central-Bank Regime & Policy Expectation Detector</span>
        </h2>
        <p className="text-xs text-slate-400">
          Section 8: Track monetary policy expectations, rate hike/cut market probabilities, forward curves, and regime transition matrices.
        </p>
      </div>

      {/* Central Bank Regimes Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
          Global Central Bank Policy Regimes & Implied Probabilities
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {cbRegimes.slice(0, 9).map((cb) => (
            <div
              key={cb.currency}
              className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3 font-mono text-xs"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div>
                  <span className="font-bold text-slate-100 text-sm">{cb.currency}</span>
                  <span className="text-[10px] text-slate-400 block">{cb.cbName}</span>
                </div>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                    cb.regime === 'EASING'
                      ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                      : cb.regime === 'TIGHTENING'
                      ? 'bg-rose-950 text-rose-300 border-rose-800'
                      : cb.regime === 'REPRICING'
                      ? 'bg-amber-950 text-amber-300 border-amber-800'
                      : 'bg-slate-900 text-slate-300 border-slate-700'
                  }`}
                >
                  {cb.regime}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-500 block text-[9px]">Current Rate</span>
                  <span className="text-emerald-400 font-bold text-sm">{cb.currentRate}%</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[9px]">12M Expected</span>
                  <span className="text-slate-200 font-bold text-sm">{cb.expectedRate12M}%</span>
                </div>
              </div>

              {/* Hike vs Cut Probability Bar */}
              <div className="space-y-1 pt-2 border-t border-slate-800/80">
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>Cut: {cb.cutProbability}%</span>
                  <span>Hike: {cb.hikeProbability}%</span>
                </div>
                <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden flex">
                  <div style={{ width: `${cb.cutProbability}%` }} className="bg-emerald-500 h-full"></div>
                  <div style={{ width: `${100 - cb.cutProbability - cb.hikeProbability}%` }} className="bg-slate-700 h-full"></div>
                  <div style={{ width: `${cb.hikeProbability}%` }} className="bg-rose-500 h-full"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
