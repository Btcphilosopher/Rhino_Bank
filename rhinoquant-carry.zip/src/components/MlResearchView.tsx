import React, { useState } from 'react';
import { runMlCarryModel } from '../engine/mlEngine';
import { Bot, CheckCircle, ArrowUpRight, Cpu, BarChart } from 'lucide-react';
import { MlModelOutput } from '../types/carry';

export const MlResearchView: React.FC = () => {
  const [modelType, setModelType] = useState<MlModelOutput['modelType']>('Gradient Boosting');
  const [fundingCode, setFundingCode] = useState('JPY');
  const [targetCode, setTargetCode] = useState('MXN');

  const mlOutput = runMlCarryModel(fundingCode, targetCode, modelType);

  return (
    <div className="space-y-6 text-slate-100">
      {/* Title */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
        <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
          <Bot className="w-5 h-5 text-purple-400" />
          <span>Machine-Learning Quantitative Carry Model Layer</span>
        </h2>
        <p className="text-xs text-slate-400">
          Section 9: Walk-forward validation, feature importance ranking, and out-of-sample leakage prevention for non-linear return forecasting.
        </p>
      </div>

      {/* Model Selection & Inputs */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-3 text-xs">
            <div>
              <label className="text-slate-400 mr-2">ML Architecture:</label>
              <select
                value={modelType}
                onChange={(e) => setModelType(e.target.value as MlModelOutput['modelType'])}
                className="bg-slate-950 border border-slate-800 text-purple-300 font-bold px-3 py-1.5 rounded font-mono"
              >
                <option value="Gradient Boosting">Gradient Boosting Trees (XGBoost)</option>
                <option value="Random Forest">Random Forest Classifier/Regressor</option>
                <option value="ElasticNet">ElasticNet Regularized Regression</option>
                <option value="Regime Classifier">Regime Hidden Markov Classifier</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 mr-2">Funding:</label>
              <select
                value={fundingCode}
                onChange={(e) => setFundingCode(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-slate-200 px-2.5 py-1.5 rounded font-mono"
              >
                <option value="JPY">JPY</option>
                <option value="CHF">CHF</option>
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 mr-2">Target:</label>
              <select
                value={targetCode}
                onChange={(e) => setTargetCode(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-slate-200 px-2.5 py-1.5 rounded font-mono"
              >
                <option value="MXN">MXN</option>
                <option value="BRL">BRL</option>
                <option value="ZAR">ZAR</option>
                <option value="TRY">TRY</option>
                <option value="CLP">CLP</option>
              </select>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-400">ML Forecast Signal:</span>
            <span
              className={`font-mono text-xs font-bold px-3 py-1 rounded border ${
                mlOutput.signal === 'LONG'
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                  : mlOutput.signal === 'SHORT'
                  ? 'bg-rose-950 text-rose-300 border-rose-700'
                  : 'bg-slate-950 text-slate-300 border-slate-700'
              }`}
            >
              {mlOutput.signal} POSITION
            </span>
          </div>
        </div>

        {/* Prediction Outputs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs">
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Predicted Carry Return</span>
            <span className="text-base font-bold text-emerald-400">+{mlOutput.predictedCarryReturn}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Predicted Spot FX Return</span>
            <span className={`text-base font-bold ${mlOutput.predictedFxReturn >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {mlOutput.predictedFxReturn >= 0 ? `+${mlOutput.predictedFxReturn}` : mlOutput.predictedFxReturn}%
            </span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Predicted FX Volatility</span>
            <span className="text-base font-bold text-slate-200">{mlOutput.predictedVol}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Crash Probability</span>
            <span className="text-base font-bold text-rose-400">{mlOutput.predictedCrashProbability}%</span>
          </div>
        </div>
      </div>

      {/* Robustness & Validation Split: In-Sample vs Out-of-Sample */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Validation Tear Sheet */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 flex items-center space-x-2">
            <Cpu className="w-4 h-4 text-purple-400" />
            <span>Robustness Validation & Leakage Controls</span>
          </h3>

          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">In-Sample Sharpe (Training 2015-2022):</span>
              <strong className="text-emerald-400 font-bold">{mlOutput.inSampleSharpe}</strong>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">Out-of-Sample Sharpe (Testing 2023-2025):</span>
              <strong className="text-purple-400 font-bold">{mlOutput.outOfSampleSharpe}</strong>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">Walk-Forward Rolling Sharpe:</span>
              <strong className="text-cyan-400 font-bold">{mlOutput.walkForwardSharpe}</strong>
            </div>
          </div>
        </div>

        {/* Feature Importance Bar Chart */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 flex items-center space-x-2">
            <BarChart className="w-4 h-4 text-purple-400" />
            <span>Model Feature Importances</span>
          </h3>

          <div className="space-y-2.5">
            {mlOutput.featureImportances.map((item) => (
              <div key={item.feature} className="space-y-1 text-xs font-mono">
                <div className="flex justify-between text-slate-300">
                  <span>{item.feature}</span>
                  <span className="text-purple-400 font-bold">{(item.importance * 100).toFixed(0)}%</span>
                </div>
                <div className="w-full bg-slate-950 h-2 rounded overflow-hidden">
                  <div
                    style={{ width: `${item.importance * 100}%` }}
                    className="bg-purple-500 h-full rounded"
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
