import React, { useState } from 'react';
import { getAllCipMetrics, calculateCipBasis } from '../engine/cipEngine';
import { Layers, AlertCircle, CheckCircle2, TrendingUp } from 'lucide-react';

export const CipBasisView: React.FC = () => {
  const [fundingCode, setFundingCode] = useState<string>('USD');
  const [targetCode, setTargetCode] = useState<string>('MXN');

  const selectedCip = calculateCipBasis(fundingCode, targetCode);
  const allCipMetrics = getAllCipMetrics();

  return (
    <div className="space-y-6 text-slate-100">
      {/* Title */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
        <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
          <Layers className="w-5 h-5 text-indigo-400" />
          <span>Covered Interest Parity (CIP) & Cross-Currency Basis Engine</span>
        </h2>
        <p className="text-xs text-slate-400">
          Section 5: Institutional FX funding analytics. Monitors deviations between theoretical forward prices and observed market forwards to detect structural funding stress.
        </p>
      </div>

      {/* Selected Pair Detail Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-3">
            <h3 className="text-lg font-black font-mono text-indigo-400">{selectedCip.pairName} CIP Analysis</h3>
            <span
              className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded border ${
                selectedCip.arbitrageSignal === 'STRUCTURAL_FUNDING_STRESS'
                  ? 'bg-rose-950 text-rose-300 border-rose-800'
                  : selectedCip.arbitrageSignal === 'MODERATE_DISCREPANCY'
                  ? 'bg-amber-950 text-amber-300 border-amber-800'
                  : 'bg-emerald-950 text-emerald-300 border-emerald-800'
              }`}
            >
              {selectedCip.arbitrageSignal.replace(/_/g, ' ')}
            </span>
          </div>

          <div className="flex items-center space-x-3 text-xs">
            <div>
              <label className="text-slate-400 mr-2">Funding:</label>
              <select
                value={fundingCode}
                onChange={(e) => setFundingCode(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-slate-200 px-2.5 py-1 rounded font-mono"
              >
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
                <option value="JPY">JPY</option>
                <option value="GBP">GBP</option>
                <option value="CHF">CHF</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 mr-2">Target:</label>
              <select
                value={targetCode}
                onChange={(e) => setTargetCode(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-slate-200 px-2.5 py-1 rounded font-mono"
              >
                <option value="MXN">MXN</option>
                <option value="BRL">BRL</option>
                <option value="ZAR">ZAR</option>
                <option value="INR">INR</option>
                <option value="TRY">TRY</option>
                <option value="AUD">AUD</option>
                <option value="NZD">NZD</option>
                <option value="PLN">PLN</option>
              </select>
            </div>
          </div>
        </div>

        {/* Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-xs">
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Theoretical Forward</span>
            <span className="text-sm font-bold text-slate-100">{selectedCip.theoreticalForward}</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Observed Forward</span>
            <span className="text-sm font-bold text-indigo-400">{selectedCip.observedForward}</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">CIP Deviation (bps)</span>
            <span
              className={`text-sm font-bold ${
                Math.abs(selectedCip.cipDeviationBps) > 50 ? 'text-rose-400' : 'text-emerald-400'
              }`}
            >
              {selectedCip.cipDeviationBps > 0 ? `+${selectedCip.cipDeviationBps}` : selectedCip.cipDeviationBps} bps
            </span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Cross-Currency Basis</span>
            <span className="text-sm font-bold text-cyan-400">{selectedCip.crossCurrencyBasisBps} bps</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Basis Volatility</span>
            <span className="text-sm font-bold text-slate-200">{selectedCip.basisVolatility}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">CIP Deviation Score</span>
            <span className="text-sm font-bold text-amber-400">{selectedCip.cipDeviationScore} / 100</span>
          </div>
        </div>
      </div>

      {/* Cross-Currency Basis Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
          Global Cross-Currency CIP Deviation Ranking
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/60">
                <th className="p-2.5">Pair</th>
                <th className="p-2.5 text-right">Theoretical Forward</th>
                <th className="p-2.5 text-right">Observed Forward</th>
                <th className="p-2.5 text-right">CIP Deviation (bps)</th>
                <th className="p-2.5 text-right">Cross-Currency Basis</th>
                <th className="p-2.5 text-center">CIP Deviation Score</th>
                <th className="p-2.5 text-center">Market Signal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {allCipMetrics.map((item) => (
                <tr key={item.pairName} className="hover:bg-slate-800/50 transition-colors">
                  <td className="p-2.5 font-bold text-slate-100">{item.pairName}</td>
                  <td className="p-2.5 text-right text-slate-300">{item.theoreticalForward}</td>
                  <td className="p-2.5 text-right text-indigo-400 font-bold">{item.observedForward}</td>
                  <td className="p-2.5 text-right text-amber-400 font-bold">
                    {item.cipDeviationBps > 0 ? `+${item.cipDeviationBps}` : item.cipDeviationBps}
                  </td>
                  <td className="p-2.5 text-right text-cyan-400">{item.crossCurrencyBasisBps} bps</td>
                  <td className="p-2.5 text-center">
                    <span className="bg-slate-950 border border-slate-800 px-2 py-0.5 rounded text-amber-300 font-bold">
                      {item.cipDeviationScore}/100
                    </span>
                  </td>
                  <td className="p-2.5 text-center">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded border ${
                        item.arbitrageSignal === 'STRUCTURAL_FUNDING_STRESS'
                          ? 'bg-rose-950 text-rose-300 border-rose-800'
                          : item.arbitrageSignal === 'MODERATE_DISCREPANCY'
                          ? 'bg-amber-950 text-amber-300 border-amber-800'
                          : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                      }`}
                    >
                      {item.arbitrageSignal.replace(/_/g, ' ')}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
