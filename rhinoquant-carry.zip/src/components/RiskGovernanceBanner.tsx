import React, { useState } from 'react';
import { AlertTriangle, ChevronDown, ChevronUp, ShieldCheck } from 'lucide-react';

export const RiskGovernanceBanner: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="bg-[#0A0A0A] border-b border-[#222] text-xs px-6 py-2.5 text-[#D1D1D1]">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5 text-[#F27D26] font-bold uppercase tracking-wider text-[11px]">
            <AlertTriangle className="w-4 h-4 text-[#F27D26]" />
            <span>Institutional Risk Governance Notice</span>
          </div>
          <p className="hidden md:inline text-[#888] text-[11px]">
            Positive carry represents interest differential compensation for unhedged FX, liquidity, tail, and central-bank regime risks.
          </p>
        </div>

        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center space-x-1 text-[#F27D26] hover:text-[#ff8e42] font-medium underline underline-offset-2 cursor-pointer text-[11px]"
        >
          <span>{isOpen ? 'Hide Risk Governance Protocols' : 'View Risk Mandate & Classifications'}</span>
          {isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>
      </div>

      {isOpen && (
        <div className="mt-3 pt-3 border-t border-[#222] grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-[#D1D1D1] text-[11px] leading-relaxed">
          <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
            <span className="font-bold text-[#F27D26] block mb-1 uppercase tracking-wider text-[10px]">Model Data Classification</span>
            <ul className="space-y-0.5 text-[#888]">
              <li><strong className="text-white">Expected Return:</strong> Yield diff net of carry costs.</li>
              <li><strong className="text-white">Model Forecast:</strong> ML & trend expectations.</li>
              <li><strong className="text-white">Historical Return:</strong> Realized ex-post performance.</li>
              <li><strong className="text-white">Simulated / Stress:</strong> Hypothetical shock paths.</li>
            </ul>
          </div>

          <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
            <span className="font-bold text-rose-400 block mb-1 uppercase tracking-wider text-[10px]">Core Risk Vectors</span>
            <div className="flex flex-wrap gap-1 mt-1">
              <span className="bg-rose-950/60 border border-rose-800/60 text-rose-300 px-1.5 py-0.5 rounded text-[10px]">MODEL RISK</span>
              <span className="bg-rose-950/60 border border-rose-800/60 text-rose-300 px-1.5 py-0.5 rounded text-[10px]">FX TAIL RISK</span>
              <span className="bg-rose-950/60 border border-rose-800/60 text-rose-300 px-1.5 py-0.5 rounded text-[10px]">LIQUIDITY STRESS</span>
              <span className="bg-rose-950/60 border border-rose-800/60 text-rose-300 px-1.5 py-0.5 rounded text-[10px]">LEVERAGE UNWIND</span>
              <span className="bg-rose-950/60 border border-rose-800/60 text-rose-300 px-1.5 py-0.5 rounded text-[10px]">CB REPRICING</span>
            </div>
          </div>

          <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
            <span className="font-bold text-emerald-400 block mb-1 uppercase tracking-wider text-[10px]">Auditability & Reproducibility</span>
            <p className="text-[#888]">
              Every quantitative P&L, Sharpe, and Var calculation includes an immutable mathematical audit log with explicit formula inputs.
            </p>
          </div>

          <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A] flex items-start space-x-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-white block mb-1 uppercase tracking-wider text-[10px]">Institutional Standard</span>
              <p className="text-[#888]">
                Designed for institutional quantitative research and risk monitoring. No auto-execution without compliance verification.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
