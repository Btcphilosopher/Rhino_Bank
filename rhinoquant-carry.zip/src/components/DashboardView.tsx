import React from 'react';
import { CarryPair, FundingCurrencyScore, ResearchSignal } from '../types/carry';
import { TrendingUp, AlertTriangle, ArrowUpRight, Zap, Shield, ArrowDownRight, Layers } from 'lucide-react';
import { NavTab } from './Header';

interface DashboardViewProps {
  pairs: CarryPair[];
  fundingScores: FundingCurrencyScore[];
  signals: ResearchSignal[];
  setActiveTab: (tab: NavTab) => void;
  onSelectPairForTicket: (funding: string, target: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  pairs,
  fundingScores,
  signals,
  setActiveTab,
  onSelectPairForTicket,
}) => {
  const topCarryPair = pairs[0];

  return (
    <div className="space-y-6 text-[#D1D1D1]">
      {/* Overview Stat Banners */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0A0A0A] border border-[#222] p-4 rounded shadow-sm">
          <div className="flex items-center justify-between text-[#888] text-[10px] font-bold uppercase tracking-widest">
            <span>Highest Net Carry Pair</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-black font-mono text-emerald-400">{topCarryPair?.pairName || 'MXN/JPY'}</span>
            <span className="text-[10px] bg-emerald-950/60 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30 font-mono">
              +{topCarryPair?.netReturn1Y}% Net 1Y
            </span>
          </div>
          <p className="mt-2 text-[11px] text-[#666]">
            Yield Diff: <strong className="text-white">+{topCarryPair?.interestDiff}%</strong> | Vol: {topCarryPair?.annualizedVol}%
          </p>
        </div>

        <div className="bg-[#0A0A0A] border border-[#222] p-4 rounded shadow-sm">
          <div className="flex items-center justify-between text-[#888] text-[10px] font-bold uppercase tracking-widest">
            <span>Top Funding Currency</span>
            <Zap className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-black font-mono text-cyan-400">{fundingScores[0]?.code || 'JPY'}</span>
            <span className="text-[10px] bg-cyan-950/60 text-cyan-400 px-2 py-0.5 rounded border border-cyan-500/30 font-mono">
              Score: {fundingScores[0]?.attractivenessScore}/100
            </span>
          </div>
          <p className="mt-2 text-[11px] text-[#666]">
            Rate: <strong className="text-white">{fundingScores[0]?.policyRate}%</strong> | Vol: {fundingScores[0]?.volatility}%
          </p>
        </div>

        <div className="bg-[#0A0A0A] border border-[#222] p-4 rounded shadow-sm">
          <div className="flex items-center justify-between text-[#888] text-[10px] font-bold uppercase tracking-widest">
            <span>Global Funding Stress</span>
            <Layers className="w-4 h-4 text-[#F27D26]" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-black font-mono text-[#F27D26]">38.5 / 100</span>
            <span className="text-[10px] bg-[#F27D26]/20 text-[#F27D26] px-2 py-0.5 rounded border border-[#F27D26]/30 font-mono">
              MODERATE
            </span>
          </div>
          <p className="mt-2 text-[11px] text-[#666]">
            CIP Basis Avg: <strong className="text-white">28.4 bps</strong> | Swap Spread: Normal
          </p>
        </div>

        <div className="bg-[#0A0A0A] border border-[#222] p-4 rounded shadow-sm">
          <div className="flex items-center justify-between text-[#888] text-[10px] font-bold uppercase tracking-widest">
            <span>Active Research Signals</span>
            <Shield className="w-4 h-4 text-rose-400" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-black font-mono text-white">{signals.length} Active</span>
            <span className="text-[10px] bg-rose-950/60 text-rose-300 px-2 py-0.5 rounded border border-rose-500/30 font-mono">
              {signals.filter((s) => s.severity === 'CRITICAL').length} Critical
            </span>
          </div>
          <p className="mt-2 text-[11px] text-[#666]">
            Latest: <strong className="text-white">{signals[0]?.signalType || 'STRONG CARRY'}</strong>
          </p>
        </div>
      </div>

      {/* Main Grid: Top Carry Opportunities + Funding Ranks + Signals */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Opportunity Matrix Table */}
        <div className="lg:col-span-2 bg-[#0A0A0A] border border-[#222] rounded p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#222] pb-3">
            <div>
              <h2 className="text-xs font-bold uppercase tracking-widest text-white flex items-center space-x-2">
                <span>Core Carry Pairs Opportunity Matrix</span>
                <span className="bg-[#1A1A1A] text-[#888] text-[10px] px-2 py-0.5 rounded font-mono font-normal">
                  {pairs.length} Pairs Evaluated
                </span>
              </h2>
              <p className="text-[11px] text-[#666] mt-0.5">Realized 1Y Net Return = Carry Return + FX Return - Funding Cost - Tx Cost</p>
            </div>

            <button
              onClick={() => setActiveTab('heatmap')}
              className="text-xs text-[#F27D26] hover:text-[#ff8e42] font-medium flex items-center space-x-1 cursor-pointer"
            >
              <span>View Heatmap</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-[#222] text-[#888] bg-[#0F0F0F] font-mono text-[10px] uppercase tracking-wider">
                  <th className="p-3">Pair</th>
                  <th className="p-3 text-right">Target Rate</th>
                  <th className="p-3 text-right">Funding Rate</th>
                  <th className="p-3 text-right">Yield Diff</th>
                  <th className="p-3 text-right">Net 1Y Return</th>
                  <th className="p-3 text-right">Sharpe</th>
                  <th className="p-3 text-center">Quality Score</th>
                  <th className="p-3 text-center">Crash Risk</th>
                  <th className="p-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1A1A1A]">
                {pairs.slice(0, 8).map((pair) => (
                  <tr key={pair.pairName} className="hover:bg-[#151515] transition-colors">
                    <td className="p-3 font-bold font-mono text-white">{pair.pairName}</td>
                    <td className="p-3 text-right font-mono text-emerald-400">{pair.targetRate}%</td>
                    <td className="p-3 text-right font-mono text-cyan-400">{pair.fundingRate}%</td>
                    <td className="p-3 text-right font-mono text-white font-semibold">+{pair.interestDiff}%</td>
                    <td className="p-3 text-right font-mono font-bold text-emerald-400">+{pair.netReturn1Y}%</td>
                    <td className="p-3 text-right font-mono text-[#D1D1D1]">{pair.sharpeRatio}</td>
                    <td className="p-3 text-center">
                      <span className="bg-[#0F0F0F] border border-[#222] text-emerald-400 font-mono text-[10px] px-2 py-0.5 rounded">
                        {pair.carryQualityScore}/100
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      <span
                        className={`font-mono text-[10px] px-2 py-0.5 rounded border ${
                          pair.carryCrashScore >= 65
                            ? 'bg-rose-950/60 text-rose-300 border-rose-800'
                            : pair.carryCrashScore >= 45
                            ? 'bg-amber-950/60 text-amber-300 border-amber-800'
                            : 'bg-[#0F0F0F] text-[#888] border-[#222]'
                        }`}
                      >
                        {pair.carryCrashScore} ({pair.crashWarningState})
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <button
                        onClick={() => {
                          onSelectPairForTicket(pair.fundingCode, pair.targetCode);
                          setActiveTab('tradeTicket');
                        }}
                        className="bg-[#F27D26] text-black font-bold text-[10px] uppercase tracking-wider px-2.5 py-1 rounded hover:bg-[#ff8e42] cursor-pointer transition-colors"
                      >
                        Ticket
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Col: Funding Currency Rankings & Active Signals */}
        <div className="space-y-6">
          {/* Funding Currency Ranking Panel */}
          <div className="bg-[#0A0A0A] border border-[#222] rounded p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-[#222] pb-2">
              <h3 className="text-xs font-bold uppercase tracking-widest text-white">
                Funding Currency Rankings
              </h3>
              <button
                onClick={() => setActiveTab('fundingTarget')}
                className="text-xs text-[#F27D26] hover:text-[#ff8e42] font-medium"
              >
                Engine Details
              </button>
            </div>

            <div className="space-y-2">
              {fundingScores.slice(0, 5).map((f) => (
                <div
                  key={f.code}
                  className="flex items-center justify-between p-2.5 rounded bg-[#0F0F0F] border border-[#1A1A1A] text-xs"
                >
                  <div className="flex items-center space-x-2">
                    <span className="font-mono text-[#555] font-bold">#{f.rank}</span>
                    <span className="font-bold font-mono text-cyan-400">{f.code}</span>
                    <span className="text-[#666] text-[11px]">({f.name})</span>
                  </div>
                  <div className="flex items-center space-x-3 font-mono">
                    <span className="text-[#888]">{f.policyRate}% rate</span>
                    <span className="bg-[#1A1A1A] text-cyan-300 border border-cyan-800/50 px-2 py-0.5 rounded text-[10px] font-bold">
                      Score: {f.attractivenessScore}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Active Quantitative Research Signals */}
          <div className="bg-[#0A0A0A] border border-[#222] rounded p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-[#222] pb-2">
              <h3 className="text-xs font-bold uppercase tracking-widest text-white flex items-center space-x-1.5">
                <AlertTriangle className="w-4 h-4 text-[#F27D26]" />
                <span>Active Research Signals</span>
              </h3>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {signals.map((sig) => (
                <div
                  key={sig.id}
                  className={`p-2.5 rounded border text-xs space-y-1 ${
                    sig.severity === 'CRITICAL'
                      ? 'bg-rose-950/40 border-rose-800/70 text-rose-200'
                      : sig.severity === 'WARNING'
                      ? 'bg-amber-950/40 border-amber-800/70 text-amber-200'
                      : 'bg-[#0F0F0F] border-[#1A1A1A] text-[#D1D1D1]'
                  }`}
                >
                  <div className="flex items-center justify-between font-mono font-bold">
                    <span className="text-white">{sig.pairName}</span>
                    <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-[#0A0A0A] border border-[#333]">
                      {sig.signalType}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#888]">{sig.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
