import React, { useState } from 'react';
import { getAuditLogsForPair } from '../engine/auditEngine';
import { FileText, Search, Code, CheckCircle, ShieldCheck } from 'lucide-react';

export const AuditTrailView: React.FC = () => {
  const [selectedFunding, setSelectedFunding] = useState('JPY');
  const [selectedTarget, setSelectedTarget] = useState('MXN');

  const auditLogs = getAuditLogsForPair(selectedFunding, selectedTarget);

  return (
    <div className="space-y-6 text-slate-100">
      {/* Title */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
        <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
          <FileText className="w-5 h-5 text-emerald-400" />
          <span>Institutional Formula Inspection & Quantitative Audit Trail</span>
        </h2>
        <p className="text-xs text-slate-400">
          Section 16: Mandatory institutional transparency layer. Reconstructs exact mathematical steps, inputs, intermediate variables, and formulas for every output. Zero black-box metrics.
        </p>
      </div>

      {/* Filter Controls */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
        <div className="flex items-center space-x-3">
          <div>
            <label className="text-slate-400 mr-2">Funding:</label>
            <select
              value={selectedFunding}
              onChange={(e) => setSelectedFunding(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-cyan-400 font-bold px-3 py-1.5 rounded"
            >
              <option value="JPY">JPY</option>
              <option value="CHF">CHF</option>
              <option value="USD">USD</option>
              <option value="EUR">EUR</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 mr-2">Target:</label>
            <select
              value={selectedTarget}
              onChange={(e) => setSelectedTarget(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-emerald-400 font-bold px-3 py-1.5 rounded"
            >
              <option value="MXN">MXN</option>
              <option value="BRL">BRL</option>
              <option value="ZAR">ZAR</option>
              <option value="TRY">TRY</option>
              <option value="INR">INR</option>
            </select>
          </div>
        </div>

        <div className="flex items-center space-x-2 text-emerald-400">
          <ShieldCheck className="w-4 h-4" />
          <span>{auditLogs.length} Verified Mathematical Formula Traces</span>
        </div>
      </div>

      {/* Audit Log Cards */}
      <div className="space-y-4">
        {auditLogs.map((log) => (
          <div
            key={log.id}
            className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-3 font-mono text-xs"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center space-x-2">
                <span className="font-bold text-slate-100 text-sm">{log.metricName}</span>
                <span className="text-slate-500">({log.pairName})</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-slate-400 text-[10px]">Result:</span>
                <span className="bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-bold">
                  {log.finalResult}
                </span>
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
              <span className="text-slate-400 text-[10px] block">Mathematical Formula:</span>
              <code className="text-amber-300 text-xs block font-bold">{log.formula}</code>
            </div>

            <div>
              <span className="text-slate-400 text-[10px] block mb-1">Inputs Audit JSON:</span>
              <pre className="bg-slate-950 p-2.5 rounded border border-slate-800 text-[11px] text-slate-300 overflow-x-auto">
                {JSON.stringify(log.inputs, null, 2)}
              </pre>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
