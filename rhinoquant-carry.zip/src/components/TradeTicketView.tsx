import React, { useState } from 'react';
import { calculateCarryPair } from '../engine/carryEngine';
import { Ticket, AlertTriangle, ShieldAlert, ArrowRight, DollarSign, Clock } from 'lucide-react';

interface TradeTicketViewProps {
  initialFunding?: string;
  initialTarget?: string;
}

export const TradeTicketView: React.FC<TradeTicketViewProps> = ({
  initialFunding = 'JPY',
  initialTarget = 'MXN',
}) => {
  const [fundingCode, setFundingCode] = useState(initialFunding);
  const [targetCode, setTargetCode] = useState(initialTarget);
  const [notionalUSD, setNotionalUSD] = useState<number>(10000000); // $10M
  const [holdingPeriodDays, setHoldingPeriodDays] = useState<number>(90);
  const [leverage, setLeverage] = useState<number>(3.0);

  const pair = calculateCarryPair(fundingCode, targetCode);

  // Math Calculations for Trade Ticket & Risk Breakeven Engine
  const yearFraction = holdingPeriodDays / 365;
  const expectedCarryPct = parseFloat((pair.expectedCarryAnnual * yearFraction).toFixed(2));
  const expectedCarryUSD = parseFloat((notionalUSD * (expectedCarryPct / 100)).toFixed(0));

  // FX Breakeven Drop %: Target currency fall that erases expected carry
  const fxBreakevenDropPct = expectedCarryPct;
  const fxBreakevenRate = parseFloat((pair.spotRate * (1 - fxBreakevenDropPct / 100)).toFixed(4));

  // Volatility moves over holding period horizon
  const horizonVolPct = pair.annualizedVol * Math.sqrt(yearFraction);
  const move1SigmaPct = parseFloat(horizonVolPct.toFixed(2));
  const move2SigmaPct = parseFloat((horizonVolPct * 2.0).toFixed(2));
  const move3SigmaPct = parseFloat((horizonVolPct * 3.0).toFixed(2));
  const stressMovePct = parseFloat((horizonVolPct * 3.8).toFixed(2));

  // Dollar P&L impact for each sigma move
  const move1SigmaUSD = parseFloat((notionalUSD * (move1SigmaPct / 100)).toFixed(0));
  const move2SigmaUSD = parseFloat((notionalUSD * (move2SigmaPct / 100)).toFixed(0));
  const move3SigmaUSD = parseFloat((notionalUSD * (move3SigmaPct / 100)).toFixed(0));
  const stressMoveUSD = parseFloat((notionalUSD * (stressMovePct / 100)).toFixed(0));

  // Risk & Margin Thresholds
  const var95USD = parseFloat((notionalUSD * (horizonVolPct / 100) * 1.645).toFixed(0));
  const expectedShortfall95USD = parseFloat((var95USD * 1.28).toFixed(0));
  const liquidationThresholdRate = parseFloat((pair.spotRate * (1 - (0.75 / leverage))).toFixed(4));
  const transactionCostUSD = parseFloat((notionalUSD * 0.0012).toFixed(0));

  return (
    <div className="space-y-6 text-[#D1D1D1]">
      {/* Title */}
      <div className="bg-[#0A0A0A] border border-[#222] p-4 rounded">
        <h2 className="text-base font-bold text-white flex items-center space-x-2">
          <Ticket className="w-5 h-5 text-[#F27D26]" />
          <span>Interactive Institutional Carry Trade Ticket & Risk Breakeven Engine</span>
        </h2>
        <p className="text-xs text-[#888] mt-1">
          Pre-trade position analysis, FX breakeven move calculation, 1σ/2σ/3σ loss levels, and margin call thresholds.
        </p>
      </div>

      {/* Ticket Input Panel */}
      <div className="bg-[#0A0A0A] border border-[#222] rounded p-5 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-widest text-white border-b border-[#222] pb-2">
          Trade Execution Parameters
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 text-xs font-mono">
          <div>
            <label className="text-[#888] block mb-1">Funding Currency (Short):</label>
            <select
              value={fundingCode}
              onChange={(e) => setFundingCode(e.target.value)}
              className="bg-[#0F0F0F] border border-[#222] text-cyan-400 font-bold p-2.5 rounded w-full text-sm"
            >
              <option value="JPY">JPY (Japanese Yen)</option>
              <option value="CHF">CHF (Swiss Franc)</option>
              <option value="EUR">EUR (Euro)</option>
              <option value="USD">USD (US Dollar)</option>
              <option value="CNH">CNH (Offshore Yuan)</option>
            </select>
          </div>

          <div>
            <label className="text-[#888] block mb-1">Target Currency (Long):</label>
            <select
              value={targetCode}
              onChange={(e) => setTargetCode(e.target.value)}
              className="bg-[#0F0F0F] border border-[#222] text-emerald-400 font-bold p-2.5 rounded w-full text-sm"
            >
              <option value="MXN">MXN (Mexican Peso)</option>
              <option value="BRL">BRL (Brazilian Real)</option>
              <option value="ZAR">ZAR (South African Rand)</option>
              <option value="TRY">TRY (Turkish Lira)</option>
              <option value="INR">INR (Indian Rupee)</option>
              <option value="PLN">PLN (Polish Zloty)</option>
              <option value="CLP">CLP (Chilean Peso)</option>
            </select>
          </div>

          <div>
            <label className="text-[#888] block mb-1">Gross Notional ($USD):</label>
            <input
              type="number"
              value={notionalUSD}
              onChange={(e) => setNotionalUSD(Number(e.target.value))}
              className="bg-[#0F0F0F] border border-[#222] text-white font-bold p-2.5 rounded w-full text-sm"
            />
          </div>

          <div>
            <label className="text-[#888] block mb-1">Holding Period (Days):</label>
            <input
              type="number"
              value={holdingPeriodDays}
              onChange={(e) => setHoldingPeriodDays(Number(e.target.value))}
              className="bg-[#0F0F0F] border border-[#222] text-white font-bold p-2.5 rounded w-full text-sm"
            />
          </div>

          <div>
            <label className="text-[#888] block mb-1">Leverage Multiple:</label>
            <input
              type="number"
              value={leverage}
              onChange={(e) => setLeverage(Number(e.target.value))}
              className="bg-[#0F0F0F] border border-[#222] text-[#F27D26] font-bold p-2.5 rounded w-full text-sm"
            />
          </div>
        </div>
      </div>

      {/* Trade Summary & Expected P&L Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#0A0A0A] border border-[#222] rounded p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#222] pb-2">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#F27D26] font-mono">
              Position P&L & Yield Summary ({pair.pairName})
            </h3>
            <span className="text-xs bg-[#0F0F0F] text-emerald-400 border border-emerald-500/30 px-2.5 py-0.5 rounded font-mono font-bold">
              Expected Carry: +${expectedCarryUSD.toLocaleString()}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
            <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
              <span className="text-[#888] block text-[10px] uppercase">Spot Exchange Rate</span>
              <span className="text-base font-bold text-white">{pair.spotRate}</span>
            </div>

            <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
              <span className="text-[#888] block text-[10px] uppercase">Annual Interest Diff</span>
              <span className="text-base font-bold text-emerald-400">+{pair.interestDiff}%</span>
            </div>

            <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
              <span className="text-[#888] block text-[10px] uppercase">{holdingPeriodDays}D Period Carry</span>
              <span className="text-base font-bold text-emerald-400">+{expectedCarryPct}%</span>
            </div>

            <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
              <span className="text-[#888] block text-[10px] uppercase">Est. Transaction Cost</span>
              <span className="text-base font-bold text-rose-400">-${transactionCostUSD.toLocaleString()}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
            <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
              <span className="text-[#888] block text-[10px] uppercase">Holding Horizon Vol</span>
              <span className="text-base font-bold text-[#D1D1D1]">{horizonVolPct.toFixed(2)}%</span>
            </div>

            <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
              <span className="text-[#888] block text-[10px] uppercase">{holdingPeriodDays}D VaR 95%</span>
              <span className="text-base font-bold text-rose-400">-${var95USD.toLocaleString()}</span>
            </div>

            <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
              <span className="text-[#888] block text-[10px] uppercase">Expected Shortfall 95</span>
              <span className="text-base font-bold text-rose-400">-${expectedShortfall95USD.toLocaleString()}</span>
            </div>

            <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
              <span className="text-[#888] block text-[10px] uppercase">Liquidation Spot Rate</span>
              <span className="text-base font-bold text-rose-400">{liquidationThresholdRate}</span>
            </div>
          </div>
        </div>

        {/* Section 20: Risk Breakeven Engine Display */}
        <div className="bg-[#0A0A0A] border border-[#222] rounded p-5 space-y-4">
          <div className="border-b border-[#222] pb-2">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#F27D26] flex items-center space-x-1.5">
              <AlertTriangle className="w-4 h-4" />
              <span>Risk Breakeven Engine</span>
            </h3>
            <p className="text-[10px] text-[#888] mt-0.5">
              "How far can {targetCode} fall before the carry trade loses money?"
            </p>
          </div>

          <div className="bg-[#0F0F0F] p-3.5 rounded border border-[#F27D26]/40 text-center font-mono space-y-1">
            <span className="text-[#888] text-xs block uppercase">Breakeven FX Move</span>
            <span className="text-2xl font-black text-[#F27D26]">-{fxBreakevenDropPct}%</span>
            <span className="text-xs text-[#888] block">Spot Rate Breakeven: {fxBreakevenRate}</span>
          </div>

          <div className="space-y-2 font-mono text-xs">
            <div className="flex justify-between p-2.5 bg-[#0F0F0F] rounded border border-[#1A1A1A]">
              <span className="text-[#888]">1σ FX Drop (-{move1SigmaPct}%):</span>
              <span className="text-rose-400 font-bold">-${move1SigmaUSD.toLocaleString()}</span>
            </div>

            <div className="flex justify-between p-2.5 bg-[#0F0F0F] rounded border border-[#1A1A1A]">
              <span className="text-[#888]">2σ FX Drop (-{move2SigmaPct}%):</span>
              <span className="text-rose-400 font-bold">-${move2SigmaUSD.toLocaleString()}</span>
            </div>

            <div className="flex justify-between p-2.5 bg-[#0F0F0F] rounded border border-[#1A1A1A]">
              <span className="text-[#888]">3σ FX Crash (-{move3SigmaPct}%):</span>
              <span className="text-rose-400 font-bold">-${move3SigmaUSD.toLocaleString()}</span>
            </div>

            <div className="flex justify-between p-2.5 bg-[#0F0F0F] rounded border border-[#1A1A1A]">
              <span className="text-[#888]">Stress Shock (-{stressMovePct}%):</span>
              <span className="text-rose-500 font-bold">-${stressMoveUSD.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
