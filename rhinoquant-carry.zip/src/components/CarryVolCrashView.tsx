import React, { useState } from 'react';
import { getCarryVolMatrix } from '../engine/volatilityEngine';
import { getCrashRiskForPair } from '../engine/crashEngine';
import { ShieldAlert, BarChart2, AlertCircle } from 'lucide-react';

export const CarryVolCrashView: React.FC = () => {
  const [selectedFunding, setSelectedFunding] = useState('JPY');
  const [selectedTarget, setSelectedTarget] = useState('MXN');

  const carryVolData = getCarryVolMatrix();
  const selectedCrash = getCrashRiskForPair(selectedFunding, selectedTarget);

  return (
    <div className="space-y-6 text-[#D1D1D1]">
      {/* Title */}
      <div className="bg-[#0A0A0A] border border-[#222] p-4 rounded">
        <h2 className="text-base font-bold text-white flex items-center space-x-2">
          <ShieldAlert className="w-5 h-5 text-rose-400" />
          <span>Carry-Volatility Matrix & Crash Risk Engine</span>
        </h2>
        <p className="text-xs text-[#888] mt-1">
          Evaluate carry return vs volatility trade-offs and monitor structural carry crash unwinding risk.
        </p>
      </div>

      {/* Section 6: Scatter Plot Visual Representation */}
      <div className="bg-[#0A0A0A] border border-[#222] rounded p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#222] pb-2">
          <h3 className="text-xs font-bold uppercase tracking-widest text-white">
            Carry vs Volatility Scatter Matrix (X = Volatility, Y = Expected Carry)
          </h3>
          <span className="text-[11px] text-[#888] font-mono">
            Bubble size = Liquidity | Color = Risk State
          </span>
        </div>

        {/* Custom Scatter Plot Representation */}
        <div className="relative h-72 w-full bg-[#050505] rounded border border-[#1A1A1A] p-4 flex flex-col justify-between font-mono text-[10px] text-[#555] overflow-hidden">
          {/* Grid lines */}
          <div className="absolute inset-0 grid grid-cols-4 grid-rows-4 pointer-events-none border-[#1A1A1A]">
            <div className="border-b border-r border-[#151515]"></div>
            <div className="border-b border-r border-[#151515]"></div>
            <div className="border-b border-r border-[#151515]"></div>
            <div className="border-b border-[#151515]"></div>
            <div className="border-b border-r border-[#151515]"></div>
            <div className="border-b border-r border-[#151515]"></div>
            <div className="border-b border-r border-[#151515]"></div>
            <div className="border-b border-[#151515]"></div>
          </div>

          {/* Scatter Bubbles */}
          <div className="absolute inset-6">
            {carryVolData.slice(0, 16).map((item) => {
              const posX = Math.min(95, Math.max(5, ((item.volatility - 3) / 22) * 100));
              const posY = Math.min(95, Math.max(5, (item.expectedCarry / 15) * 100));
              
              const isHighRisk = item.riskRegime === 'SEVERE' || item.riskRegime === 'CRASH CONDITIONS';

              return (
                <div
                  key={item.pairName}
                  onClick={() => {
                    setSelectedFunding(item.fundingCode);
                    setSelectedTarget(item.targetCode);
                  }}
                  style={{ left: `${posX}%`, bottom: `${posY}%` }}
                  className={`absolute transform -translate-x-1/2 translate-y-1/2 cursor-pointer transition-transform hover:scale-125 z-10 group`}
                >
                  <div
                    className={`rounded-full flex items-center justify-center font-bold text-[9px] shadow-lg ${
                      isHighRisk
                        ? 'bg-rose-500/80 text-black border border-rose-400'
                        : item.carryToVolRatio > 0.8
                        ? 'bg-emerald-500/80 text-black border border-emerald-300'
                        : 'bg-[#F27D26]/80 text-black border border-[#F27D26]'
                    }`}
                    style={{
                      width: `${Math.max(26, Math.min(48, item.liquidityScore * 0.5))}px`,
                      height: `${Math.max(26, Math.min(48, item.liquidityScore * 0.5))}px`,
                    }}
                  >
                    {item.pairName}
                  </div>

                  {/* Tooltip */}
                  <div className="hidden group-hover:block absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-[#0A0A0A] text-white p-2.5 rounded border border-[#333] whitespace-nowrap z-30 shadow-2xl text-xs">
                    <p className="font-bold font-mono text-[#F27D26]">{item.pairName}</p>
                    <p className="text-[10px] text-[#D1D1D1]">Expected Carry: +{item.expectedCarry}%</p>
                    <p className="text-[10px] text-[#D1D1D1]">Volatility: {item.volatility}%</p>
                    <p className="text-[10px] text-[#D1D1D1]">Carry/Vol Ratio: {item.carryToVolRatio}</p>
                    <p className="text-[10px] text-rose-400">Expected Tail Loss: -{item.expectedTailLoss}%</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex justify-between z-0 text-[#666]">
            <span>Y: Expected Carry % (0% to 15%)</span>
            <span className="text-[#F27D26]">High Sharpe Zone ↗</span>
          </div>
          <div className="flex justify-between z-0 text-[#666]">
            <span>Low Risk Zone ↖</span>
            <span>X: Annualized Volatility % (3% to 25%)</span>
          </div>
        </div>
      </div>

      {/* Section 7: Carry Crash Risk Model */}
      <div className="bg-[#0A0A0A] border border-[#222] rounded p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between border-b border-[#222] pb-3 gap-2">
          <div className="flex items-center space-x-3">
            <h3 className="text-xs font-bold uppercase tracking-widest text-rose-400">
              Carry Crash Score & Warning State Analysis
            </h3>

            <div className="flex items-center space-x-2 text-xs">
              <select
                value={selectedFunding}
                onChange={(e) => setSelectedFunding(e.target.value)}
                className="bg-[#0F0F0F] border border-[#222] text-white px-2.5 py-1 rounded font-mono"
              >
                <option value="JPY">Funding: JPY</option>
                <option value="CHF">Funding: CHF</option>
                <option value="USD">Funding: USD</option>
                <option value="EUR">Funding: EUR</option>
              </select>

              <select
                value={selectedTarget}
                onChange={(e) => setSelectedTarget(e.target.value)}
                className="bg-[#0F0F0F] border border-[#222] text-white px-2.5 py-1 rounded font-mono"
              >
                <option value="MXN">Target: MXN</option>
                <option value="BRL">Target: BRL</option>
                <option value="ZAR">Target: ZAR</option>
                <option value="TRY">Target: TRY</option>
                <option value="CLP">Target: CLP</option>
                <option value="AUD">Target: AUD</option>
              </select>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-xs text-[#888]">Pair Warning State:</span>
            <span
              className={`font-mono text-xs font-bold px-3 py-1 rounded border ${
                selectedCrash.crashScore >= 80
                  ? 'bg-rose-950/80 text-rose-300 border-rose-700 animate-pulse'
                  : selectedCrash.crashScore >= 60
                  ? 'bg-rose-900/60 text-rose-300 border-rose-800'
                  : selectedCrash.crashScore >= 40
                  ? 'bg-amber-950/60 text-amber-300 border-amber-800'
                  : 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
              }`}
            >
              {selectedCrash.warningState} ({selectedCrash.crashScore}/100)
            </span>
          </div>
        </div>

        {/* Crash Factor Deconstruction */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-xs">
          <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
            <span className="text-[#888] block text-[10px] uppercase">Funding Appr. Risk</span>
            <span className="text-sm font-bold text-rose-400">+{selectedCrash.fundingAppreciationRisk}%</span>
          </div>

          <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
            <span className="text-[#888] block text-[10px] uppercase">Target Depr. Risk</span>
            <span className="text-sm font-bold text-rose-400">-{selectedCrash.targetDepreciationRisk}%</span>
          </div>

          <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
            <span className="text-[#888] block text-[10px] uppercase">Volatility Spike Risk</span>
            <span className="text-sm font-bold text-[#F27D26]">{selectedCrash.volatilitySpikeRisk}%</span>
          </div>

          <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
            <span className="text-[#888] block text-[10px] uppercase">Correlation Breakdown</span>
            <span className="text-sm font-bold text-white">{selectedCrash.correlationBreakdownRisk}/100</span>
          </div>

          <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
            <span className="text-[#888] block text-[10px] uppercase">Liquidity Deterioration</span>
            <span className="text-sm font-bold text-cyan-400">{selectedCrash.liquidityDeteriorationRisk}/100</span>
          </div>

          <div className="bg-[#0F0F0F] p-3 rounded border border-[#1A1A1A]">
            <span className="text-[#888] block text-[10px] uppercase">Leverage Unwind Risk</span>
            <span className="text-sm font-bold text-purple-400">{selectedCrash.leverageUnwindRisk}/100</span>
          </div>
        </div>
      </div>
    </div>
  );
};
