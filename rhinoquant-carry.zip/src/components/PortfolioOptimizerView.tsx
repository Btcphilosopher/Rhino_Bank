import React, { useState } from 'react';
import { optimizePortfolio, OptimizationObjective, DEFAULT_OPTIMIZER_CONSTRAINTS, OptimizerConstraints } from '../engine/portfolioOptimizer';
import { PortfolioPosition } from '../types/carry';
import { PieChart, Plus, Trash2, Sliders, ShieldCheck } from 'lucide-react';

export const PortfolioOptimizerView: React.FC = () => {
  const [capitalUSD, setCapitalUSD] = useState<number>(10000000); // $10M
  const [objective, setObjective] = useState<OptimizationObjective>('MAXIMUM_SHARPE');
  const [constraints, setConstraints] = useState<OptimizerConstraints>(DEFAULT_OPTIMIZER_CONSTRAINTS);
  
  const [positions, setPositions] = useState<PortfolioPosition[]>([]);

  const { positions: optimizedPositions, metrics } = optimizePortfolio(positions, objective, constraints, capitalUSD);

  const handleAddPosition = () => {
    const newPos: PortfolioPosition = {
      id: `pos-${Date.now()}`,
      fundingCode: 'JPY',
      targetCode: 'MXN',
      pairName: 'MXN/JPY',
      weight: 25,
      notionalUSD: capitalUSD * 0.25 * constraints.maxLeverage,
      leverage: constraints.maxLeverage,
      expectedCarry: 10.5,
      annualizedVol: 14.0,
      var95: 575000,
      expectedShortfall95: 720000,
    };
    setPositions([...optimizedPositions, newPos]);
  };

  const handleRemovePosition = (id: string) => {
    setPositions(optimizedPositions.filter((p) => p.id !== id));
  };

  return (
    <div className="space-y-6 text-slate-100">
      {/* Title */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
        <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
          <PieChart className="w-5 h-5 text-emerald-400" />
          <span>Multi-Currency Carry Portfolio Construction & Risk Optimizer</span>
        </h2>
        <p className="text-xs text-slate-400">
          Section 10: Multi-currency long/short position builder with Mean-Variance, Max Sharpe, Min Vol, and Risk Parity optimization algorithms.
        </p>
      </div>

      {/* Optimization Objectives & Capital Controls */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-3 text-xs">
            <div>
              <label className="text-slate-400 mr-2">Optimization Objective:</label>
              <select
                value={objective}
                onChange={(e) => setObjective(e.target.value as OptimizationObjective)}
                className="bg-slate-950 border border-slate-800 text-emerald-400 font-bold px-3 py-1.5 rounded font-mono"
              >
                <option value="MAXIMUM_SHARPE">Maximum Sharpe Ratio</option>
                <option value="MAXIMUM_CARRY">Maximum Carry Return</option>
                <option value="MINIMUM_VOLATILITY">Minimum Volatility</option>
                <option value="RISK_PARITY">Equal Risk Parity</option>
                <option value="USER_CONSTRAINED">User-Constrained Custom</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 mr-2">Portfolio Capital ($USD):</label>
              <input
                type="number"
                value={capitalUSD}
                onChange={(e) => setCapitalUSD(Number(e.target.value))}
                className="bg-slate-950 border border-slate-800 text-slate-200 px-3 py-1.5 rounded font-mono w-36"
              />
            </div>
          </div>

          <button
            onClick={handleAddPosition}
            className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs px-3 py-1.5 rounded font-semibold flex items-center space-x-1 cursor-pointer transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Position</span>
          </button>
        </div>

        {/* Portfolio Aggregate Risk Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-xs">
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Total Gross Notional</span>
            <span className="text-sm font-bold text-slate-100">${(metrics.totalNotionalUSD / 1000000).toFixed(1)}M</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Effective Leverage</span>
            <span className="text-sm font-bold text-cyan-400">{metrics.leverage}x</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Portfolio Carry (Annual)</span>
            <span className="text-sm font-bold text-emerald-400">+{metrics.portfolioCarryAnnual}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Portfolio Volatility</span>
            <span className="text-sm font-bold text-slate-200">{metrics.portfolioVolAnnual}%</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Sharpe Ratio</span>
            <span className="text-sm font-bold text-emerald-400">{metrics.sharpeRatio}</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">VaR 95% (1Y)</span>
            <span className="text-sm font-bold text-rose-400">${(metrics.var95Annual / 1000).toFixed(0)}k</span>
          </div>
        </div>
      </div>

      {/* Portfolio Holdings Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
          Optimal Portfolio Allocation Basket
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/60">
                <th className="p-2.5">Pair</th>
                <th className="p-2.5 text-right">Optimal Weight</th>
                <th className="p-2.5 text-right">Notional ($USD)</th>
                <th className="p-2.5 text-right">Expected Carry</th>
                <th className="p-2.5 text-right">Pair Vol</th>
                <th className="p-2.5 text-right">1Y VaR 95%</th>
                <th className="p-2.5 text-right">Expected Shortfall</th>
                <th className="p-2.5 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {optimizedPositions.map((p) => (
                <tr key={p.id} className="hover:bg-slate-800/50 transition-colors">
                  <td className="p-2.5 font-bold text-slate-100">{p.pairName}</td>
                  <td className="p-2.5 text-right text-emerald-400 font-bold">{p.weight}%</td>
                  <td className="p-2.5 text-right text-slate-200">${(p.notionalUSD / 1000000).toFixed(2)}M</td>
                  <td className="p-2.5 text-right text-emerald-400">+{p.expectedCarry}%</td>
                  <td className="p-2.5 text-right text-slate-300">{p.annualizedVol}%</td>
                  <td className="p-2.5 text-right text-rose-400">${(p.var95 / 1000).toFixed(0)}k</td>
                  <td className="p-2.5 text-right text-rose-300">${(p.expectedShortfall95 / 1000).toFixed(0)}k</td>
                  <td className="p-2.5 text-center">
                    <button
                      onClick={() => handleRemovePosition(p.id)}
                      className="text-slate-500 hover:text-rose-400 cursor-pointer p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
