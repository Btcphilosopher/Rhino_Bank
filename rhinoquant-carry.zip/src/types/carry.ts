/**
 * RHINOQUANT CARRY - Global Institutional Carry Trade Engine Types
 */

export type CurrencyCategory = 'G10' | 'Developed' | 'Emerging' | 'Frontier';

export interface Currency {
  code: string;
  name: string;
  flag: string;
  category: CurrencyCategory;
  policyRate: number; // in %
  shortTermRate: number; // in %
  depositYield: number; // in %
  swapRate1Y: number; // in %
  inflation: number; // in %
  realRate: number; // policyRate - inflation
  volatility30D: number; // annualized %
  volatility1Y: number; // annualized %
  liquidityScore: number; // 0-100
  marketDepthUSD: number; // in $Billions daily
  centralBankRegime: 'EASING' | 'NEUTRAL' | 'TIGHTENING' | 'REPRICING' | 'POLICY SHOCK';
  cbExpectation6M: number; // expected rate change in bps
  gdpGrowth: number; // %
  commodityExposure: 'EXPORTER' | 'IMPORTER' | 'NEUTRAL';
  currentAccountBalancePct: number; // % of GDP
  politicalRiskIndex: number; // 0-100 (higher = riskier)
  reerValuation: number; // % over/valued vs PPP
  forwardPoints1Y: number; // pips
}

export interface CarryPair {
  fundingCode: string;
  targetCode: string;
  pairName: string; // e.g. "MXN/JPY"
  spotRate: number;
  forward1Y: number;
  fundingRate: number;
  targetRate: number;
  interestDiff: number; // targetRate - fundingRate
  expectedCarryAnnual: number; // %
  realizedCarry1Y: number; // %
  fxReturn1Y: number; // %
  totalReturn1Y: number; // Carry + FX
  netReturn1Y: number; // Total - Funding - TxCosts
  annualizedVol: number; // %
  sharpeRatio: number;
  sortinoRatio: number;
  calmarRatio: number;
  maxDrawdown: number; // %
  skewness: number;
  kurtosis: number;
  downsideDeviation: number;
  crashFrequency1Y: number;
  cipDeviationBps: number;
  impliedForwardRate: number;
  carryQualityScore: number; // 0-100
  carryCrashScore: number; // 0-100
  crashWarningState: 'NORMAL' | 'ELEVATED' | 'HIGH' | 'SEVERE' | 'CRASH CONDITIONS';
}

export interface FundingCurrencyScore {
  code: string;
  name: string;
  policyRate: number;
  fundingRate: number;
  volatility: number;
  liquidityScore: number;
  cbRegime: string;
  fundingStressScore: number; // 0-100
  attractivenessScore: number; // 0-100
  rank: number;
}

export interface TargetCurrencyScore {
  code: string;
  name: string;
  policyRate: number;
  interestDiffVsUSD: number;
  fxMomentum3M: number;
  volatility: number;
  realRate: number;
  carryQualityScore: number; // 0-100
  liquidityFactor: number;
  stabilityFactor: number;
  fxTrendFactor: number;
  rank: number;
}

export interface ReturnDecomposition {
  pairName: string;
  interestComponent: number;
  spotFxComponent: number;
  forwardComponent: number;
  fundingComponent: number;
  transactionCostComponent: number;
  netTotalReturn: number;
}

export interface CipBasisMetric {
  pairName: string;
  observedForward: number;
  theoreticalForward: number;
  cipDeviationBps: number;
  crossCurrencyBasisBps: number;
  basisVolatility: number;
  cipDeviationScore: number; // 0-100
  arbitrageSignal: 'NO_ARBITRAGE' | 'MODERATE_DISCREPANCY' | 'STRUCTURAL_FUNDING_STRESS';
}

export interface CrashRiskMetric {
  pairName: string;
  crashScore: number; // 0-100
  warningState: 'NORMAL' | 'ELEVATED' | 'HIGH' | 'SEVERE' | 'CRASH CONDITIONS';
  fundingAppreciationRisk: number; // %
  targetDepreciationRisk: number; // %
  volatilitySpikeRisk: number;
  correlationBreakdownRisk: number;
  liquidityDeteriorationRisk: number;
  leverageUnwindRisk: number;
}

export interface CentralBankRegimeInfo {
  currency: string;
  cbName: string;
  currentRate: number;
  expectedRate12M: number;
  regime: 'EASING' | 'NEUTRAL' | 'TIGHTENING' | 'REPRICING' | 'POLICY SHOCK';
  hikeProbability: number; // %
  cutProbability: number; // %
  transitionProbabilities: {
    EASING: number;
    NEUTRAL: number;
    TIGHTENING: number;
    REPRICING: number;
    POLICY_SHOCK: number;
  };
}

export interface MlModelOutput {
  pairName: string;
  modelType: 'Gradient Boosting' | 'Random Forest' | 'ElasticNet' | 'Regime Classifier';
  predictedCarryReturn: number; // %
  predictedFxReturn: number; // %
  predictedVol: number; // %
  predictedCrashProbability: number; // %
  predictedRegime: string;
  inSampleSharpe: number;
  outOfSampleSharpe: number;
  walkForwardSharpe: number;
  featureImportances: { feature: string; importance: number }[];
  signal: 'LONG' | 'SHORT' | 'NEUTRAL';
}

export interface PortfolioPosition {
  id: string;
  fundingCode: string;
  targetCode: string;
  pairName: string;
  weight: number; // % of total portfolio
  notionalUSD: number;
  leverage: number;
  expectedCarry: number;
  annualizedVol: number;
  var95: number;
  expectedShortfall95: number;
}

export interface PortfolioMetrics {
  totalNotionalUSD: number;
  leverage: number;
  portfolioCarryAnnual: number; // %
  portfolioVolAnnual: number; // %
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdown: number;
  var95Annual: number; // $
  var99Annual: number; // $
  expectedShortfall95: number; // $
  fxBetaVsUSD: number;
  hhiConcentrationIndex: number; // 0-10,000
  stressLossGFC: number; // $
  stressLoss2024Unwind: number; // $
}

export interface LeverageMetrics {
  capitalUSD: number;
  grossExposureUSD: number;
  netExposureUSD: number;
  effectiveLeverage: number;
  marginRequirementPct: number;
  maintenanceMarginPct: number;
  haircutPct: number;
  grossCarryAnnualUSD: number;
  netCarryAnnualUSD: number;
  roeAnnualPct: number;
  marginUsagePct: number;
  marginCallDistancePct: number; // % FX drop to trigger margin call
  forcedLiquidationRiskPct: number; // %
}

export interface StressTestScenario {
  id: string;
  name: string;
  description: string;
  fundingFxShockPct: number;
  targetFxShockPct: number;
  volatilityMultiplier: number;
  rateShiftBps: number;
  liquidityHaircutPct: number;
  portfolioDrawdownPct: number;
  marginCallTriggered: boolean;
  estimatedRecoveryMonths: number;
}

export interface MonteCarloSummary {
  simulationsCount: number;
  horizonDays: number;
  meanReturnPct: number;
  medianReturnPct: number;
  percentile5thPct: number;
  percentile25thPct: number;
  percentile75thPct: number;
  percentile95thPct: number;
  var95Pct: number;
  expectedShortfall95Pct: number;
  maxDrawdownMedianPct: number;
  probabilityOfLossPct: number;
  probabilityOfMarginCallPct: number;
  expectedRecoveryDays: number;
  pathSample: { day: number; p5: number; p50: number; p95: number }[];
}

export interface BacktestResult {
  strategyName: string;
  startDate: string;
  endDate: string;
  initialCapital: number;
  finalCapital: number;
  cagrPct: number;
  annualizedVolPct: number;
  sharpeRatio: number;
  sortinoRatio: number;
  calmarRatio: number;
  maxDrawdownPct: number;
  winRatePct: number;
  profitFactor: number;
  totalTradesCount: number;
  equityCurve: { date: string; equity: number; carryCum: number; fxCum: number; drawdown: number }[];
  monthlyReturns: { year: number; month: number; returnPct: number }[];
}

export interface TradeTicketDetails {
  fundingCode: string;
  targetCode: string;
  notionalUSD: number;
  holdingPeriodDays: number;
  leverage: number;
  spotRate: number;
  fundingRate: number;
  targetYield: number;
  interestDiff: number;
  expectedCarryUSD: number;
  expectedCarryPct: number;
  fxBreakevenDropPct: number; // FX drop to wipe out carry
  fxBreakevenRate: number;
  move1SigmaUSD: number;
  move2SigmaUSD: number;
  move3SigmaUSD: number;
  stressMoveUSD: number;
  var95USD: number;
  expectedShortfall95USD: number;
  marginReqUSD: number;
  liquidationThresholdRate: number;
  transactionCostUSD: number;
}

export interface ResearchSignal {
  id: string;
  pairName: string;
  signalType: 'STRONG CARRY' | 'CRASH WARNING' | 'CIP BASIS ARBITRAGE' | 'CB REPRICING' | 'LIQUIDITY STRESS';
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  description: string;
  score: number;
}

export interface CalculationAuditEntry {
  id: string;
  timestamp: string;
  module: string;
  pairName?: string;
  formula: string;
  inputs: Record<string, number | string>;
  output: number | string;
  modelRiskRating: 'LOW' | 'MEDIUM' | 'HIGH';
  version: string;
}

export interface ResearchExperiment {
  id: string;
  title: string;
  timestamp: string;
  factors: string[];
  parameters: Record<string, number | string>;
  inSamplePeriod: string;
  outOfSamplePeriod: string;
  cagr: number;
  sharpe: number;
  maxDrawdown: number;
  status: 'COMPLETED' | 'RUNNING' | 'SAVED';
}
