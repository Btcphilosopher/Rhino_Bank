package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.RhinoMainViewModel
import java.text.DecimalFormat

@Composable
fun RhinoTickerTape(
    viewModel: RhinoMainViewModel,
    modifier: Modifier = Modifier
) {
    val securities by viewModel.securities.collectAsState()
    val macroInstruments by viewModel.macroInstruments.collectAsState()
    val tickerList = remember(securities) {
        listOf("AAPL", "MSFT", "NVDA", "AMZN", "META", "GOOGL", "TSLA", "JPM", "LLY", "AVGO", "GS", "XOM")
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(RhinoBackground)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp, horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            tickerList.forEach { ticker ->
                val sec = securities[ticker]
                if (sec != null) {
                    val isUp = sec.change >= 0
                    val flashColor by animateColorAsState(
                        targetValue = if (isUp) MarketGreen else MarketRed,
                        animationSpec = tween(durationMillis = 400),
                        label = "ticker_flash"
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .clickable {
                                viewModel.selectSecurity(ticker)
                                viewModel.selectTab(com.example.ui.viewmodel.MainNavigationTab.TERMINAL)
                            }
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = sec.ticker,
                            color = TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = DecimalFormat("#,##0.00").format(sec.price),
                            color = TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "${if (isUp) "+" else ""}${DecimalFormat("#0.00").format(sec.changePercent)}%",
                            color = flashColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = "│",
                        color = RhinoBorder,
                        fontSize = 10.sp
                    )
                }
            }

            // Macro items
            macroInstruments.take(4).forEach { macro ->
                val isUp = macro.change >= 0
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = macro.symbol,
                        color = RhinoGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = DecimalFormat("#,##0.00").format(macro.value),
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${if (isUp) "+" else ""}${DecimalFormat("#0.00").format(macro.changePercent)}%",
                        color = if (isUp) MarketGreen else MarketRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = "│",
                    color = RhinoBorder,
                    fontSize = 10.sp
                )
            }
        }
        Divider(color = RhinoBorder, thickness = 1.dp)
    }
}
