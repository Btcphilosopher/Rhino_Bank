package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Institutional Dark Palette
val RhinoBackground = Color(0xFF080C14)
val RhinoSurface = Color(0xFF0E1626)
val RhinoSurfaceElevated = Color(0xFF162136)
val RhinoSurfaceHighlight = Color(0xFF1E2D4A)
val RhinoBorder = Color(0xFF22324D)
val RhinoBorderLight = Color(0xFF2E4366)

// Accents & Signals
val RhinoCyan = Color(0xFF00E5FF)
val RhinoBlue = Color(0xFF2979FF)
val RhinoGold = Color(0xFFFFB300)
val RhinoPurple = Color(0xFFB388FF)

// Market Data Uptick / Downtick
val MarketGreen = Color(0xFF00E676)
val MarketGreenDim = Color(0x2200E676)
val MarketRed = Color(0xFFFF3D71)
val MarketRedDim = Color(0x22FF3D71)

// Level 2 Depth Colors
val BidDepthColor = Color(0xFF00B0FF)
val AskDepthColor = Color(0xFFFF5252)

// Typography Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val TextMuted = Color(0xFF475569)
