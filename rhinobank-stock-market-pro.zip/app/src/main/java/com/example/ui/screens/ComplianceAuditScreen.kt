package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuditEvent
import com.example.data.model.ComplianceRule
import com.example.data.model.UserRole
import com.example.ui.theme.*
import com.example.ui.viewmodel.RhinoMainViewModel
import java.text.DecimalFormat

@Composable
fun ComplianceAuditScreen(
    viewModel: RhinoMainViewModel,
    modifier: Modifier = Modifier
) {
    val complianceRules by viewModel.complianceRules.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()
    val systemStatus by viewModel.systemStatus.collectAsState()
    val activeRole by viewModel.activeRole.collectAsState()
    val isPaused by viewModel.isStreamingPaused.collectAsState()
    val tickCount by viewModel.tickCount.collectAsState()

    var activeSubView by remember { mutableStateOf("AUDIT_TRAIL") } // AUDIT_TRAIL, SURVEILLANCE_RULES, RBAC_MATRIX, DIAGNOSTICS

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Compliance Header & Tab Switcher
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = RhinoCyan)
                            Text(
                                text = "ENTERPRISE COMPLIANCE & SURVEILLANCE SUITE",
                                color = RhinoCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                        Text(
                            text = "SOX / FINRA / MiFID II",
                            color = RhinoGold,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Navigation Pills
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            "AUDIT_TRAIL" to "Audit Trail",
                            "SURVEILLANCE_RULES" to "Compliance Rules",
                            "RBAC_MATRIX" to "RBAC Matrix",
                            "DIAGNOSTICS" to "System Health"
                        ).forEach { pair ->
                            val isSelected = activeSubView == pair.first
                            Surface(
                                onClick = { activeSubView = pair.first },
                                shape = RoundedCornerShape(4.dp),
                                color = if (isSelected) RhinoCyan.copy(alpha = 0.2f) else RhinoSurfaceElevated,
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, RhinoCyan) else null
                            ) {
                                Text(
                                    text = pair.second,
                                    color = if (isSelected) RhinoCyan else TextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        when (activeSubView) {
            "AUDIT_TRAIL" -> {
                item {
                    Text(
                        text = "TAMPER-EVIDENT CRYPTOGRAPHIC AUDIT LOGS (${auditLogs.size} ENTRIES)",
                        color = RhinoCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                items(auditLogs) { log ->
                    AuditLogRowCard(log = log)
                }
            }

            "SURVEILLANCE_RULES" -> {
                items(complianceRules) { rule ->
                    ComplianceRuleCard(rule = rule)
                }
            }

            "RBAC_MATRIX" -> {
                item {
                    RbacRoleMatrixCard(activeRole = activeRole, onSelectRole = { viewModel.selectRole(it) })
                }
            }

            "DIAGNOSTICS" -> {
                item {
                    SystemDiagnosticsCard(
                        systemStatus = systemStatus,
                        tickCount = tickCount,
                        isPaused = isPaused,
                        onTogglePause = { viewModel.toggleStreamingPause() },
                        onInjectShock = { viewModel.injectPriceShock("NVDA", 10.0) }
                    )
                }
            }
        }
    }
}

@Composable
private fun AuditLogRowCard(log: AuditEvent) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(RhinoCyan.copy(alpha = 0.15f))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(log.action, color = RhinoCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    Text(log.user, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Text(log.timestamp, color = TextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }

            Text(log.reason, color = TextSecondary, fontSize = 10.sp)

            Text(
                text = "DELTA: '${log.oldValue}' ➔ '${log.newValue}'",
                color = RhinoGold,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )

            Divider(color = RhinoBorder.copy(alpha = 0.4f), thickness = 0.5.dp)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("IP: ${log.ipSession}", color = TextTertiary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("HASH: ${log.tamperProofHash}", color = TextTertiary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun ComplianceRuleCard(rule: ComplianceRule) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = MarketGreen, modifier = Modifier.size(16.dp))
                    Text(rule.name, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(RhinoGold.copy(alpha = 0.2f))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(rule.ruleType, color = RhinoGold, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            }

            Text(rule.thresholdDescription, color = TextSecondary, fontSize = 10.sp)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Rule ID: ${rule.id}", color = TextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("Status: ${rule.status} (Breaches: ${rule.currentBreaches})", color = RhinoCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun RbacRoleMatrixCard(activeRole: UserRole, onSelectRole: (UserRole) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("ROLE-BASED ACCESS CONTROL (RBAC) PRIVILEGE MATRIX", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

            UserRole.values().forEach { role ->
                val isSelected = activeRole == role
                Surface(
                    onClick = { onSelectRole(role) },
                    shape = RoundedCornerShape(6.dp),
                    color = if (isSelected) RhinoCyan.copy(alpha = 0.2f) else RhinoSurfaceElevated,
                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, RhinoCyan) else null,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(role.badge, color = RhinoCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(role.title, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                text = when (role) {
                                    UserRole.TRADER -> "Permissions: Level 2 Depth, Order Execution, Dark Pool Crossing"
                                    UserRole.PORTFOLIO_MANAGER -> "Permissions: Portfolio Rebalancing, OMS Review, Asset Allocation"
                                    UserRole.RESEARCH_ANALYST -> "Permissions: DCF Workbench, Factor Models, Algorithmic Backtesting"
                                    UserRole.RISK_MANAGER -> "Permissions: VaR Engines, Stress Testing, Correlation Matrix"
                                    UserRole.COMPLIANCE_OFFICER -> "Permissions: Pre-Trade Surveillance, Restricted List, Audit Verification"
                                    UserRole.ADMINISTRATOR -> "Permissions: Market Feed Controls, Infrastructure Health, Simulation Shocks"
                                    UserRole.EXECUTIVE -> "Permissions: Executive KPI Dashboards, Capital Memorandums, Read-All"
                                    UserRole.READ_ONLY -> "Permissions: Read Only Surveillance and Reporting"
                                },
                                color = TextSecondary,
                                fontSize = 9.sp
                            )
                        }

                        if (isSelected) {
                            Text("ACTIVE", color = RhinoCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SystemDiagnosticsCard(
    systemStatus: Map<String, String>,
    tickCount: Long,
    isPaused: Boolean,
    onTogglePause: () -> Unit,
    onInjectShock: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("CORE ENGINE SYSTEM DIAGNOSTICS & TELEMETRY", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("ENGINE HEARTBEAT", color = TextTertiary, fontSize = 9.sp)
                    Text("PULSE #${tickCount}", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                Column {
                    Text("LATENCY", color = TextTertiary, fontSize = 9.sp)
                    Text("< 1.2 ms", color = MarketGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                Column {
                    Text("STATUS", color = TextTertiary, fontSize = 9.sp)
                    Text(systemStatus["SIMULATION"] ?: "ACTIVE", color = RhinoGold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }

            Divider(color = RhinoBorder, thickness = 1.dp)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onTogglePause,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isPaused) MarketGreen else RhinoSurfaceElevated
                    )
                ) {
                    Text(if (isPaused) "RESUME FEED" else "PAUSE FEED", color = if (isPaused) RhinoBackground else TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onInjectShock,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = RhinoGold)
                ) {
                    Text("INJECT NVDA +10%", color = RhinoBackground, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
