package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GlobalIndex
import com.example.data.model.MacroInstrument
import com.example.data.model.Security
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.RhinoMainViewModel
import java.text.DecimalFormat

@Composable
fun MarketsDashboardScreen(
    viewModel: RhinoMainViewModel,
    modifier: Modifier = Modifier
) {
    val globalIndices by viewModel.globalIndices.collectAsState()
    val macroInstruments by viewModel.macroInstruments.collectAsState()
    val securities by viewModel.securities.collectAsState()
    val activeAccount by viewModel.activeAccount.collectAsState()
    val positions by viewModel.positions.collectAsState()

    val totalMarketValue = positions.filter { it.accountId == activeAccount?.id }.sumOf { it.marketValue }
    val totalCash = activeAccount?.cash ?: 0.0
    val totalAum = totalMarketValue + totalCash
    val todayPnl = positions.filter { it.accountId == activeAccount?.id }.sumOf { it.unrealizedPnL * 0.08 }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Executive KPI Snapshot Bar
        item {
            ExecutiveKpiBar(
                aum = totalAum,
                cash = totalCash,
                todayPnl = todayPnl,
                buyingPower = activeAccount?.buyingPower ?: 0.0,
                onGenerateReport = { viewModel.openReportModal("PORTFOLIO_REPORT") }
            )
        }

        // Global Markets Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "GLOBAL INDICES",
                    color = RhinoCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "REAL-TIME MULTI-VENUE COMPOSITES",
                    color = TextTertiary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Global Markets Horizontal Scroll Grid
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                globalIndices.forEach { index ->
                    GlobalIndexCard(index = index)
                }
            }
        }

        // Macro & Fixed Income / Yields
        item {
            Text(
                text = "FIXED INCOME, COMMODITIES, CURRENCIES & CRYPTO",
                color = RhinoCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                macroInstruments.forEach { macro ->
                    MacroInstrumentCard(macro = macro)
                }
            }
        }

        // Equity Universe Watchlist Table Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "INSTITUTIONAL EQUITY UNIVERSE",
                        color = RhinoCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "(${securities.size} SECURITIES)",
                        color = TextTertiary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Surface(
                    onClick = { viewModel.openSearch() },
                    shape = RoundedCornerShape(4.dp),
                    color = RhinoSurfaceElevated
                ) {
                    Text(
                        text = "FILTERS & SEARCH",
                        color = RhinoCyan,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }
        }

        // Equity Items
        items(securities.values.toList()) { sec ->
            SecurityMarketRow(
                security = sec,
                onSelectSecurity = {
                    viewModel.selectSecurity(sec.ticker)
                    viewModel.selectTab(MainNavigationTab.TERMINAL)
                },
                onQuickTrade = {
                    viewModel.selectSecurity(sec.ticker)
                    viewModel.selectTab(MainNavigationTab.TRADE_DESK)
                }
            )
        }
    }
}

@Composable
private fun ExecutiveKpiBar(
    aum: Double,
    cash: Double,
    todayPnl: Double,
    buyingPower: Double,
    onGenerateReport: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(RhinoCyan)
                    )
                    Text(
                        text = "EXECUTIVE WORKSTATION SUMMARY",
                        color = TextPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }

                Surface(
                    onClick = onGenerateReport,
                    shape = RoundedCornerShape(4.dp),
                    color = RhinoCyan.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(0.8.dp, RhinoCyan.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.FileDownload, contentDescription = null, tint = RhinoCyan, modifier = Modifier.size(12.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("GENERATE MEMO", color = RhinoCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("TOTAL AUM", color = TextTertiary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "$${DecimalFormat("#,##0").format(aum)}",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Column {
                    Text("TODAY'S P&L", color = TextTertiary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "${if (todayPnl >= 0) "+" else ""}$${DecimalFormat("#,##0").format(todayPnl)}",
                        color = if (todayPnl >= 0) MarketGreen else MarketRed,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Column {
                    Text("BUYING POWER", color = TextTertiary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "$${DecimalFormat("#,##0").format(buyingPower)}",
                        color = RhinoCyan,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Column {
                    Text("REGIME", color = TextTertiary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "BULL ACCEL",
                        color = RhinoGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
private fun GlobalIndexCard(index: GlobalIndex) {
    val isUp = index.change >= 0
    Card(
        modifier = Modifier.width(145.dp),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = index.symbol, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (index.status == "OPEN") MarketGreen.copy(alpha = 0.2f) else RhinoSurfaceElevated)
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(text = index.status, color = if (index.status == "OPEN") MarketGreen else TextTertiary, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            }
            Text(text = index.name, color = TextSecondary, fontSize = 9.sp, maxLines = 1)
            Spacer(Modifier.height(4.dp))
            Text(
                text = DecimalFormat("#,##0.00").format(index.value),
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${if (isUp) "+" else ""}${DecimalFormat("#0.00").format(index.change)}",
                    color = if (isUp) MarketGreen else MarketRed,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "${if (isUp) "+" else ""}${DecimalFormat("#0.00").format(index.changePercent)}%",
                    color = if (isUp) MarketGreen else MarketRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(Modifier.height(2.dp))
            Text(
                text = "Day: ${index.dayRange}",
                color = TextTertiary,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun MacroInstrumentCard(macro: MacroInstrument) {
    val isUp = macro.change >= 0
    Card(
        modifier = Modifier.width(140.dp),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(text = macro.symbol, color = RhinoGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(text = macro.name, color = TextSecondary, fontSize = 9.sp, maxLines = 1)
            Spacer(Modifier.height(4.dp))
            Text(
                text = "${DecimalFormat("#,##0.00").format(macro.value)} ${macro.unit}",
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${if (isUp) "+" else ""}${DecimalFormat("#0.00").format(macro.change)}",
                    color = if (isUp) MarketGreen else MarketRed,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "${if (isUp) "+" else ""}${DecimalFormat("#0.00").format(macro.changePercent)}%",
                    color = if (isUp) MarketGreen else MarketRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
private fun SecurityMarketRow(
    security: Security,
    onSelectSecurity: () -> Unit,
    onQuickTrade: () -> Unit
) {
    val isUp = security.change >= 0
    Surface(
        onClick = onSelectSecurity,
        shape = RoundedCornerShape(6.dp),
        color = RhinoSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder),
        modifier = Modifier.fillMaxWidth().testTag("market_security_row_${security.ticker}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1.2f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = security.ticker, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(RhinoCyan.copy(alpha = 0.15f))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(text = security.exchange, color = RhinoCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                    if (security.isRestricted) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(MarketRed.copy(alpha = 0.2f))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(text = "RESTRICTED", color = MarketRed, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text(text = security.name, color = TextSecondary, fontSize = 10.sp, maxLines = 1)
                Text(
                    text = "MCap: $${security.marketCap}B • P/E: ${security.pe} • EPS: $${security.eps}",
                    color = TextTertiary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(0.8f)) {
                Text(
                    text = "$${DecimalFormat("#,##0.00").format(security.price)}",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "${if (isUp) "+" else ""}${DecimalFormat("#0.00").format(security.changePercent)}%",
                    color = if (isUp) MarketGreen else MarketRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Vol: ${DecimalFormat("#,##0").format(security.volume / 1000)}k",
                    color = TextTertiary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            IconButton(
                onClick = onQuickTrade,
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(RhinoSurfaceElevated)
            ) {
                Icon(
                    imageVector = Icons.Default.SwapHoriz,
                    contentDescription = "Trade",
                    tint = RhinoCyan,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
