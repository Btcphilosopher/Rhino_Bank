package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.RhinoFinancialEngine
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class MainNavigationTab(val title: String, val iconLabel: String) {
    MARKETS("Markets", "MKT"),
    TERMINAL("Terminal", "TERM"),
    TRADE_DESK("Trade Desk", "TRD"),
    PORTFOLIO_OMS("Portfolio & OMS", "PORT"),
    RISK_ANALYTICS("Risk Engine", "RISK"),
    QUANT_MODELS("Models & DCF", "MOD"),
    SCREENER_NEWS("Screener & News", "SCR"),
    COMPLIANCE_AUDIT("Compliance & Audit", "COMP")
}

data class UiNotification(
    val id: String,
    val title: String,
    val message: String,
    val isPositive: Boolean = true
)

class RhinoMainViewModel : ViewModel() {

    private val engine = RhinoFinancialEngine.getInstance()

    // Navigation
    private val _currentTab = MutableStateFlow(MainNavigationTab.MARKETS)
    val currentTab: StateFlow<MainNavigationTab> = _currentTab.asStateFlow()

    // Search dialog
    private val _isSearchOpen = MutableStateFlow(false)
    val isSearchOpen: StateFlow<Boolean> = _isSearchOpen.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Alert dialog
    private val _isAlertModalOpen = MutableStateFlow(false)
    val isAlertModalOpen: StateFlow<Boolean> = _isAlertModalOpen.asStateFlow()

    // Report dialog
    private val _isReportModalOpen = MutableStateFlow(false)
    val isReportModalOpen: StateFlow<Boolean> = _isReportModalOpen.asStateFlow()

    private val _generatedReportText = MutableStateFlow("")
    val generatedReportText: StateFlow<String> = _generatedReportText.asStateFlow()

    // Notification toast
    private val _notification = MutableStateFlow<UiNotification?>(null)
    val notification: StateFlow<UiNotification?> = _notification.asStateFlow()

    // Chart Timeframe & Indicator Selection
    private val _selectedTimeframe = MutableStateFlow("1D")
    val selectedTimeframe: StateFlow<String> = _selectedTimeframe.asStateFlow()

    private val _activeChartType = MutableStateFlow("CANDLESTICK") // CANDLESTICK, LINE, AREA
    val activeChartType: StateFlow<String> = _activeChartType.asStateFlow()

    private val _enabledIndicators = MutableStateFlow(setOf("SMA_20", "VWAP", "RSI"))
    val enabledIndicators: StateFlow<Set<String>> = _enabledIndicators.asStateFlow()

    // DCF Assumptions State
    private val _dcfAssumptions = MutableStateFlow(DcfAssumptions())
    val dcfAssumptions: StateFlow<DcfAssumptions> = _dcfAssumptions.asStateFlow()

    // Screener Filters State
    private val _screenerCriteria = MutableStateFlow(ScreenerCriteria())
    val screenerCriteria: StateFlow<ScreenerCriteria> = _screenerCriteria.asStateFlow()

    // Correlation Timeframe
    private val _correlationTimeframe = MutableStateFlow("1Y")
    val correlationTimeframe: StateFlow<String> = _correlationTimeframe.asStateFlow()

    // Terminal Sub-Tab
    private val _terminalSubTab = MutableStateFlow("CHART")
    val terminalSubTab: StateFlow<String> = _terminalSubTab.asStateFlow()

    // Watchlist State
    private val _watchlist = MutableStateFlow(setOf("AAPL", "MSFT", "NVDA", "AMZN", "META", "TSLA"))
    val watchlist: StateFlow<Set<String>> = _watchlist.asStateFlow()

    // Engine Flow Delegations
    val dataMode = engine.dataMode
    val isStreamingPaused = engine.isStreamingPaused
    val tickCount = engine.tickCount
    val activeRole = engine.activeRole
    val activeAccountId = engine.activeAccountId
    val selectedSecurityTicker = engine.selectedSecurityTicker
    val securities = engine.securities
    val globalIndices = engine.globalIndices
    val macroInstruments = engine.macroInstruments
    val accounts = engine.accounts
    val positions = engine.positions
    val orders = engine.orders
    val orderBooks = engine.orderBooks
    val news = engine.news
    val earnings = engine.earnings
    val alerts = engine.alerts
    val auditLogs = engine.auditLogs
    val complianceRules = engine.complianceRules
    val systemStatus = engine.systemStatus

    // Derived Selected Security
    val selectedSecurity: StateFlow<Security?> = combine(securities, selectedSecurityTicker) { secMap, ticker ->
        secMap[ticker]
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    // Derived Active Account
    val activeAccount: StateFlow<Account?> = combine(accounts, activeAccountId) { accMap, accId ->
        accMap[accId]
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    // Derived Active OrderBook
    val activeOrderBook: StateFlow<OrderBook?> = combine(orderBooks, selectedSecurityTicker) { bookMap, ticker ->
        bookMap[ticker]
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    // Derived Open Orders
    val openOrders: StateFlow<List<Order>> = orders.map { list ->
        list.filter { it.status == OrderStatus.OPEN || it.status == OrderStatus.PARTIALLY_FILLED }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Derived Is Security Bookmarked
    val isSecurityBookmarked: StateFlow<Boolean> = combine(watchlist, selectedSecurityTicker) { list, ticker ->
        list.contains(ticker)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    // Filtered Securities for Search
    val searchResults: StateFlow<List<Security>> = combine(securities, _searchQuery) { secMap, query ->
        if (query.isBlank()) {
            secMap.values.take(8)
        } else {
            val q = query.trim().lowercase()
            secMap.values.filter { sec ->
                sec.ticker.lowercase().contains(q) ||
                sec.name.lowercase().contains(q) ||
                sec.isin.lowercase().contains(q) ||
                sec.cusip.lowercase().contains(q) ||
                sec.exchange.lowercase().contains(q) ||
                sec.sector.lowercase().contains(q) ||
                sec.industry.lowercase().contains(q) ||
                sec.country.lowercase().contains(q)
            }.take(15)
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Screened Securities
    val screenedSecurities: StateFlow<List<Security>> = combine(securities, _screenerCriteria) { secMap, crit ->
        secMap.values.filter { sec ->
            sec.marketCap >= crit.minMarketCap &&
            sec.pe <= crit.maxPe &&
            sec.roic >= crit.minRoic &&
            sec.debtToEquity <= crit.maxDebtEquity &&
            (crit.selectedSector == "ALL" || sec.sector.equals(crit.selectedSector, ignoreCase = true)) &&
            (crit.selectedExchange == "ALL" || sec.exchange.equals(crit.selectedExchange, ignoreCase = true))
        }.sortedByDescending { it.marketCap }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Actions

    fun selectTab(tab: MainNavigationTab) {
        _currentTab.value = tab
    }

    fun selectSecurity(ticker: String) {
        engine.setSecurity(ticker)
    }

    fun selectAccount(accountId: String) {
        engine.setActiveAccount(accountId)
        showNotification("Active Portfolio Changed", "Switched to account $accountId")
    }

    fun selectRole(role: UserRole) {
        engine.setUserRole(role)
        showNotification("Role Updated", "Active role switched to ${role.title}")
    }

    fun toggleWatchlist(ticker: String) {
        val current = _watchlist.value.toMutableSet()
        if (current.contains(ticker)) {
            current.remove(ticker)
            showNotification("Watchlist", "$ticker removed from institutional watchlist")
        } else {
            current.add(ticker)
            showNotification("Watchlist", "$ticker added to institutional watchlist")
        }
        _watchlist.value = current
    }

    fun setTimeframe(tf: String) {
        _selectedTimeframe.value = tf
    }

    fun setChartType(type: String) {
        _activeChartType.value = type
    }

    fun toggleIndicator(indicator: String) {
        val current = _enabledIndicators.value.toMutableSet()
        if (current.contains(indicator)) {
            current.remove(indicator)
        } else {
            current.add(indicator)
        }
        _enabledIndicators.value = current
    }

    fun setTerminalSubTab(tabName: String) {
        _terminalSubTab.value = tabName
    }

    fun setCorrelationTimeframe(tf: String) {
        _correlationTimeframe.value = tf
    }

    fun openSearch() {
        _isSearchOpen.value = true
        _searchQuery.value = ""
    }

    fun closeSearch() {
        _isSearchOpen.value = false
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun openAlertModal(ticker: String = "") {
        if (ticker.isNotBlank()) {
            engine.setSecurity(ticker)
        }
        _isAlertModalOpen.value = true
    }

    fun closeAlertModal() {
        _isAlertModalOpen.value = false
    }

    fun openReportModal(reportType: String) {
        _generatedReportText.value = generateReportContent(reportType)
        _isReportModalOpen.value = true
    }

    fun closeReportModal() {
        _isReportModalOpen.value = false
    }

    fun updateDcfAssumptions(newAssumptions: DcfAssumptions) {
        _dcfAssumptions.value = newAssumptions
    }

    fun updateScreenerCriteria(newCriteria: ScreenerCriteria) {
        _screenerCriteria.value = newCriteria
    }

    fun toggleStreamingPause() {
        engine.toggleStreamingPause()
        val paused = engine.isStreamingPaused.value
        showNotification("Market Feed", if (paused) "Data streaming paused" else "Live market feed resumed")
    }

    fun injectPriceShock(ticker: String, percentage: Double) {
        engine.injectPriceShock(ticker, percentage)
        showNotification("Stress Shock Injected", "$ticker shifted ${if (percentage >= 0) "+" else ""}$percentage%. Portfolio & Risk recalculated.")
    }

    fun validatePreTrade(symbol: String, side: OrderSide, type: OrderType, quantity: Int, price: Double?): PreTradeCheckResult {
        return engine.validatePreTrade(symbol, side, type, quantity, price)
    }

    fun submitOrder(
        symbol: String,
        side: OrderSide,
        type: OrderType,
        quantity: Int,
        price: Double?,
        stopPrice: Double? = null,
        timeInForce: TimeInForce = TimeInForce.DAY
    ) {
        val check = engine.validatePreTrade(symbol, side, type, quantity, price)
        if (!check.passed) {
            showNotification("Order Rejected by Compliance", check.checks.firstOrNull { !it.passed }?.details ?: "Risk ceiling exceeded", false)
            return
        }

        val order = engine.submitOrder(symbol, side, type, quantity, price, stopPrice, timeInForce)
        showNotification("Order Submitted", "${order.side} ${order.quantity} ${order.symbol} (${order.status.name})")
    }

    fun cancelOrder(orderId: String) {
        engine.cancelOrder(orderId)
        showNotification("Order Cancelled", "Order #$orderId has been revoked")
    }

    fun createPriceAlert(symbol: String, condition: String, targetPrice: Double, note: String) {
        engine.createPriceAlert(symbol, condition, targetPrice, note)
        showNotification("Alert Armed", "Surveillance tracking $symbol $condition $$targetPrice")
    }

    fun deleteAlert(id: String) {
        engine.deleteAlert(id)
        showNotification("Alert Deleted", "Alert rule #$id removed")
    }

    fun getCandles(ticker: String, timeframe: String): List<Candle> {
        return engine.getCandlesForTicker(ticker, timeframe)
    }

    fun getDcfResult(ticker: String): DcfResult {
        return engine.computeDcf(ticker, _dcfAssumptions.value)
    }

    fun getStressScenarios(): List<StressScenario> {
        val aum = activeAccount.value?.cash?.plus(
            positions.value.filter { it.accountId == activeAccountId.value }.sumOf { it.marketValue }
        ) ?: 450000000.0
        return engine.getStressScenarios(aum)
    }

    fun getBacktestStrategies(): List<BacktestStrategy> = engine.getBacktestStrategies()

    fun getFinancialStatements(ticker: String): List<FinancialStatementItem> = engine.getFinancialStatements(ticker)

    fun getEarnings(ticker: String): List<EarningsEvent> {
        return engine.earnings.value.filter { it.symbol == ticker }
    }

    private fun showNotification(title: String, message: String, isPositive: Boolean = true) {
        _notification.value = UiNotification(
            id = System.currentTimeMillis().toString(),
            title = title,
            message = message,
            isPositive = isPositive
        )
        viewModelScope.launch {
            kotlinx.coroutines.delay(4000L)
            if (_notification.value?.title == title) {
                _notification.value = null
            }
        }
    }

    private fun generateReportContent(reportType: String): String {
        val acc = activeAccount.value
        val sec = selectedSecurity.value
        val now = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", java.util.Locale.US).format(java.util.Date())

        return when (reportType) {
            "RISK_REPORT" -> """
========================================================================
RHINOBANK INSTITUTIONAL RISK & CAPITAL MANAGEMENT MEMORANDUM
========================================================================
Generated: $now
Account: ${acc?.name ?: "Institutional Alpha Fund"} (${acc?.id})
Classification: CONFIDENTIAL / PROPRIETARY / CRO LEVEL-1

EXECUTIVE SUMMARY
------------------------------------------------------------------------
Portfolio Volatility (Annualized): 16.42%
Portfolio Beta (vs SPX): 1.18
Sharpe Ratio (Rf=4.25%): 2.14
Sortino Ratio: 2.88
Max Historic Drawdown: -11.20%
1-Day 95% Parametric Value-at-Risk (VaR): $6,420,000 (1.42% AUM)
1-Day 95% Expected Shortfall (CVaR): $9,150,000 (2.03% AUM)
Concentration Index (Herfindahl-Hirschman): 0.142 (COMPLIANT)

SCENARIO STRESS TESTING
------------------------------------------------------------------------
* Global Market Shock (-10%): Estimated Impact -$35.1M (-7.8%)
* Severe Equity Crash (-20%): Estimated Impact -$72.9M (-16.2%)
* Tech Sector De-Rating (-25%): Estimated Impact -$64.8M (-14.4%)
* Rates Spike +100bps: Estimated Impact -$21.6M (-4.8%)

COMPLIANCE & SURVEILLANCE STATUS
------------------------------------------------------------------------
Pre-Trade Surveillance: 0 Breaches Logged
Restricted List Verification: 100% Passed
Auditor Signature Digest: 0x7F9940A39BF1104C
========================================================================
            """.trimIndent()

            "EQUITY_RESEARCH" -> """
========================================================================
RHINOBANK GLOBAL EQUITY RESEARCH INITIATION MEMO
========================================================================
Security: ${sec?.name ?: "Apple Inc."} (${sec?.ticker ?: "AAPL"})
Exchange: ${sec?.exchange} | Sector: ${sec?.sector} | Country: ${sec?.country}
ISIN: ${sec?.isin} | CUSIP: ${sec?.cusip}
Rating: OVERWEIGHT / CONVICTION BUY
Target Price: $265.00 (Current: $${sec?.price ?: 214.52}, Implied Upside: +23.5%)

INVESTMENT THESIS & QUANTITATIVE HIGHLIGHTS
------------------------------------------------------------------------
* Market Capitalization: $${sec?.marketCap}B
* P/E (Trailing): ${sec?.pe}x | Forward P/E: ${sec?.forwardPe}x | PEG: ${sec?.peg}x
* ROIC: ${sec?.roic}% | ROE: ${sec?.roe}% | Free Cash Flow: $${sec?.fcf}B
* Beta: ${sec?.beta} | ESG Rating: ${sec?.esgScore}/100 | Carbon Intensity: ${sec?.carbonIntensity} tCO2e/M$

DISCOUNTED CASH FLOW (DCF) OUTPUT
------------------------------------------------------------------------
* Assumed WACC: ${_dcfAssumptions.value.waccPct}%
* Terminal Growth Rate: ${_dcfAssumptions.value.terminalGrowthPct}%
* Implied Enterprise Value: $3,640.2B
* Fair Value Per Share: $248.50

ANALYST: T. Sterling, CFA (Managing Director, Equity Strategy)
SUPERVISORY APPROVAL: Verified by Rhino Compliance Engine
========================================================================
            """.trimIndent()

            else -> """
========================================================================
RHINOBANK INSTITUTIONAL PORTFOLIO PERFORMANCE & ACCOUNTING STATEMENT
========================================================================
Generated: $now
Account: ${acc?.name} (${acc?.id})
Base Currency: USD
Total Cash Balance: $${acc?.cash?.let { String.format("%,.2f", it) }}
Available Buying Power: $${acc?.buyingPower?.let { String.format("%,.2f", it) }}

ACTIVE POSITIONS & WEIGHT DISTRIBUTION
------------------------------------------------------------------------
${positions.value.filter { it.accountId == activeAccountId.value }.joinToString("\n") { 
    "${it.symbol.padEnd(6)} | Qty: ${it.quantity.toString().padStart(7)} | Avg: $${it.averageCost.toString().padStart(6)} | Value: $${String.format("%,.0f", it.marketValue).padStart(11)} | UnPnL: ${String.format("%+.2f", it.unrealizedPnLPercent).padStart(7)}% | Wgt: ${it.portfolioWeight}%"
}}

DISCLAIMER: For institutional client review only. Simulated models do not guarantee future returns.
========================================================================
            """.trimIndent()
        }
    }
}
