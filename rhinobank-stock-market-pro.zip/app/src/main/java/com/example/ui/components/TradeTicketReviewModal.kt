package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.*
import com.example.ui.theme.*
import java.text.DecimalFormat

@Composable
fun TradeTicketReviewModal(
    symbol: String,
    side: OrderSide,
    type: OrderType,
    quantity: Int,
    price: Double?,
    stopPrice: Double?,
    timeInForce: TimeInForce,
    account: Account?,
    preTradeCheck: PreTradeCheckResult,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    val estimatedValue = quantity * (price ?: 100.0)

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = RhinoSurface),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, if (preTradeCheck.passed) RhinoCyan else MarketRed)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "ORDER REVIEW & PRE-TRADE CHECK",
                            color = RhinoCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(Modifier.height(8.dp))

                // Order Summary Card
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = RhinoSurfaceElevated,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${side.name} ${DecimalFormat("#,##0").format(quantity)} $symbol",
                                color = if (side == OrderSide.BUY) MarketGreen else MarketRed,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(RhinoCyan.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(type.name, color = RhinoCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Divider(color = RhinoBorder, thickness = 1.dp)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Estimated Value:", color = TextSecondary, fontSize = 11.sp)
                            Text(
                                "$${DecimalFormat("#,##0.00").format(estimatedValue)}",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Limit Price:", color = TextSecondary, fontSize = 11.sp)
                            Text(
                                if (price != null) "$${DecimalFormat("#,##0.00").format(price)}" else "MARKET (BEST BID/OFFER)",
                                color = TextPrimary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Account Target:", color = TextSecondary, fontSize = 11.sp)
                            Text(account?.id ?: "N/A", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Execution Venue:", color = TextSecondary, fontSize = 11.sp)
                            Text("RHINO-DARK-POOL (CROSS)", color = RhinoGold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Risk Status Banner
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (preTradeCheck.passed) MarketGreen.copy(alpha = 0.15f) else MarketRed.copy(alpha = 0.15f))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (preTradeCheck.passed) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (preTradeCheck.passed) MarketGreen else MarketRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Column {
                        Text(
                            text = "RISK STATUS: ${preTradeCheck.riskStatus}",
                            color = if (preTradeCheck.passed) MarketGreen else MarketRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                // Surveillance Rules Breakdown
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    preTradeCheck.checks.forEach { check ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "• ${check.ruleName}",
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                            Text(
                                text = if (check.passed) "PASSED" else "BREACH",
                                color = if (check.passed) MarketGreen else MarketRed,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                    ) {
                        Text("CANCEL", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onConfirm,
                        enabled = preTradeCheck.passed,
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("confirm_order_submission_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (side == OrderSide.BUY) MarketGreen else MarketRed,
                            disabledContainerColor = RhinoSurfaceHighlight
                        )
                    ) {
                        Text(
                            text = "AUTHORIZE & EXECUTE",
                            color = if (preTradeCheck.passed) Color(0xFF001E2B) else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }
    }
}
