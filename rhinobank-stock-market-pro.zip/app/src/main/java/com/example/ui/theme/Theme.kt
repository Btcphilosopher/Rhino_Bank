package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val InstitutionalDarkColorScheme = darkColorScheme(
    primary = RhinoCyan,
    onPrimary = Color(0xFF001E2B),
    primaryContainer = RhinoSurfaceElevated,
    onPrimaryContainer = RhinoCyan,
    secondary = RhinoBlue,
    onSecondary = Color.White,
    secondaryContainer = RhinoSurfaceHighlight,
    onSecondaryContainer = Color(0xFF90CAF9),
    tertiary = RhinoGold,
    onTertiary = Color(0xFF261900),
    background = RhinoBackground,
    onBackground = TextPrimary,
    surface = RhinoSurface,
    onSurface = TextPrimary,
    surfaceVariant = RhinoSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = RhinoBorder,
    outlineVariant = RhinoBorderLight,
    error = MarketRed,
    onError = Color.White
)

@Composable
fun RhinoBankTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = InstitutionalDarkColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    RhinoBankTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}
