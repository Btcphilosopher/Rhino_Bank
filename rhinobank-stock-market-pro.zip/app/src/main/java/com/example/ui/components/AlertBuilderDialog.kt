package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.RhinoMainViewModel

@Composable
fun AlertBuilderDialog(
    viewModel: RhinoMainViewModel
) {
    val selectedSec by viewModel.selectedSecurity.collectAsState()
    var symbol by remember { mutableStateOf(selectedSec?.ticker ?: "NVDA") }
    var condition by remember { mutableStateOf(">") }
    var targetPriceStr by remember { mutableStateOf((selectedSec?.price?.times(1.05)?.toInt() ?: 200).toString()) }
    var note by remember { mutableStateOf("Breakout momentum surveillance alert") }

    Dialog(onDismissRequest = { viewModel.closeAlertModal() }) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = RhinoSurface),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, RhinoGold)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(imageVector = Icons.Default.NotificationsActive, contentDescription = null, tint = RhinoGold)
                        Text(
                            text = "ARM INSTITUTIONAL PRICE ALERT",
                            color = RhinoGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                    IconButton(onClick = { viewModel.closeAlertModal() }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(Modifier.height(10.dp))

                OutlinedTextField(
                    value = symbol,
                    onValueChange = { symbol = it.uppercase() },
                    label = { Text("Ticker Symbol", color = TextSecondary, fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = RhinoCyan,
                        unfocusedBorderColor = RhinoBorder
                    )
                )

                Spacer(Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Condition selector
                    Surface(
                        onClick = { condition = if (condition == ">") "<" else ">" },
                        shape = RoundedCornerShape(6.dp),
                        color = RhinoSurfaceElevated,
                        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Condition", color = TextTertiary, fontSize = 9.sp)
                            Text(
                                if (condition == ">") "GREATER (>=)" else "LESS (<=)",
                                color = RhinoCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Price input
                    OutlinedTextField(
                        value = targetPriceStr,
                        onValueChange = { targetPriceStr = it },
                        label = { Text("Target Price ($)", color = TextSecondary, fontSize = 11.sp) },
                        modifier = Modifier.weight(1.5f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = RhinoCyan,
                            unfocusedBorderColor = RhinoBorder
                        )
                    )
                }

                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Desk Note / Thesis", color = TextSecondary, fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = RhinoCyan,
                        unfocusedBorderColor = RhinoBorder
                    )
                )

                Spacer(Modifier.height(16.dp))

                Button(
                    onClick = {
                        val target = targetPriceStr.toDoubleOrNull() ?: 100.0
                        viewModel.createPriceAlert(symbol, condition, target, note)
                        viewModel.closeAlertModal()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("arm_price_alert_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = RhinoGold)
                ) {
                    Text("ARM SURVEILLANCE ALERT", color = RhinoBackground, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}
