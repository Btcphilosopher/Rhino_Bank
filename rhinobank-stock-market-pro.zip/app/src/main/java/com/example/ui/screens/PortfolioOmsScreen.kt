package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.model.Position
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.RhinoMainViewModel
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PortfolioOmsScreen(
    viewModel: RhinoMainViewModel,
    modifier: Modifier = Modifier
) {
    val activeAccount by viewModel.activeAccount.collectAsState()
    val positions by viewModel.positions.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val openOrders by viewModel.openOrders.collectAsState()

    var activeTab by remember { mutableStateOf("HOLDINGS") } // HOLDINGS, ORDERS_BLOTTER, ALLOCATION, ATTRIBUTION

    val totalMarketVal = positions.sumOf { it.marketValue }
    val totalCash = activeAccount?.cash ?: 0.0
    val totalPortfolioVal = totalMarketVal + totalCash
    val totalUnrealizedPnL = positions.sumOf { it.unrealizedPnL }
    val totalRealizedPnL = positions.sumOf { it.realizedPnL }

    val isUnrealizedPos = totalUnrealizedPnL >= 0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Account KPI Summary Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("portfolio_kpi_card"),
                colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("PORTFOLIO NET ASSET VALUE (NAV)", color = TextTertiary, fontSize = 9.sp, letterSpacing = 0.5.sp)
                            Text(
                                "$${DecimalFormat("#,##0").format(totalPortfolioVal)}",
                                color = TextPrimary,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        // Generate Report Button
                        Surface(
                            onClick = { viewModel.openReportModal("PORTFOLIO_MEMO") },
                            shape = RoundedCornerShape(4.dp),
                            color = RhinoCyan.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(0.8.dp, RhinoCyan.copy(alpha = 0.4f))
                        ) {
                            Row(modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Description, contentDescription = null, tint = RhinoCyan, modifier = Modifier.size(12.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("EXPORT MEMO", color = RhinoCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Divider(color = RhinoBorder, thickness = 1.dp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Unrealized P&L", color = TextTertiary, fontSize = 9.sp)
                            Text(
                                "${if (isUnrealizedPos) "+" else ""}$${DecimalFormat("#,##0").format(totalUnrealizedPnL)}",
                                color = if (isUnrealizedPos) MarketGreen else MarketRed,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column {
                            Text("Realized P&L", color = TextTertiary, fontSize = 9.sp)
                            Text(
                                "+$${DecimalFormat("#,##0").format(totalRealizedPnL)}",
                                color = MarketGreen,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column {
                            Text("Available Cash", color = TextTertiary, fontSize = 9.sp)
                            Text(
                                "$${DecimalFormat("#,##0").format(totalCash)}",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column {
                            Text("Buying Power", color = TextTertiary, fontSize = 9.sp)
                            Text(
                                "$${DecimalFormat("#,##0").format(activeAccount?.buyingPower ?: 0.0)}",
                                color = RhinoCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Sub-Tab Switcher (HOLDINGS, ORDERS_BLOTTER, ALLOCATION, ATTRIBUTION)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(
                        "HOLDINGS" to "Holdings (${positions.size})",
                        "ORDERS_BLOTTER" to "OMS Blotter (${orders.size})",
                        "ALLOCATION" to "Asset Allocation",
                        "ATTRIBUTION" to "Performance"
                    ).forEach { pair ->
                        val isSelected = activeTab == pair.first
                        Surface(
                            onClick = { activeTab = pair.first },
                            shape = RoundedCornerShape(4.dp),
                            color = if (isSelected) RhinoCyan.copy(alpha = 0.2f) else RhinoSurfaceElevated,
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, RhinoCyan) else null,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(modifier = Modifier.padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    text = pair.second,
                                    color = if (isSelected) RhinoCyan else TextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Tab Views
        when (activeTab) {
            "HOLDINGS" -> {
                item {
                    Text("ACTIVE INSTITUTIONAL POSITIONS", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                }

                items(positions) { pos ->
                    PositionRowCard(
                        position = pos,
                        onClick = {
                            viewModel.selectSecurity(pos.symbol)
                            viewModel.selectTab(MainNavigationTab.TERMINAL)
                        }
                    )
                }
            }

            "ORDERS_BLOTTER" -> {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("INSTITUTIONAL ORDER BLOTTER", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("${openOrders.size} OPEN ORDERS", color = RhinoGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }

                items(orders) { order ->
                    OmsOrderRowCard(
                        order = order,
                        onCancel = { viewModel.cancelOrder(order.id) }
                    )
                }
            }

            "ALLOCATION" -> {
                item {
                    AssetAllocationCard(account = activeAccount)
                }
            }

            "ATTRIBUTION" -> {
                item {
                    PerformanceAttributionCard()
                }
            }
        }
    }
}

@Composable
private fun PositionRowCard(position: Position, onClick: () -> Unit) {
    val isPos = position.unrealizedPnL >= 0
    val pnlColor = if (isPos) MarketGreen else MarketRed
    val sign = if (isPos) "+" else ""

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(6.dp),
        color = RhinoSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder),
        modifier = Modifier.fillMaxWidth().testTag("pos_card_${position.symbol}")
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = position.symbol,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${position.quantity} shs",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = "$${DecimalFormat("#,##0").format(position.marketValue)}",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Avg: $${position.averageCost} | Cur: $${position.currentPrice}",
                    color = TextTertiary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "$sign$${DecimalFormat("#,##0").format(position.unrealizedPnL)} ($sign${position.unrealizedPnLPercent}%)",
                    color = pnlColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Weight Bar
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Weight: ${position.portfolioWeight}%", color = TextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                LinearProgressIndicator(
                    progress = { (position.portfolioWeight / 30f).toFloat().coerceIn(0f, 1f) },
                    modifier = Modifier.weight(1f).height(3.dp).clip(RoundedCornerShape(2.dp)),
                    color = RhinoCyan,
                    trackColor = RhinoSurfaceElevated
                )
            }
        }
    }
}

@Composable
private fun OmsOrderRowCard(order: Order, onCancel: () -> Unit) {
    val isOpen = order.status == OrderStatus.OPEN
    val statusColor = when (order.status) {
        OrderStatus.FILLED -> MarketGreen
        OrderStatus.OPEN -> RhinoGold
        OrderStatus.CANCELLED, OrderStatus.REJECTED -> MarketRed
        else -> TextTertiary
    }
    val timeStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(order.timestamp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (order.side.name == "BUY") MarketGreen.copy(alpha = 0.2f) else MarketRed.copy(alpha = 0.2f))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = order.side.name,
                            color = if (order.side.name == "BUY") MarketGreen else MarketRed,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(order.symbol, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text("${order.quantity} shs @ ${if (order.price != null) "$${order.price}" else "MKT"}", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(statusColor.copy(alpha = 0.15f))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(order.status.name, color = statusColor, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${order.id} • ${order.venue} • $timeStr", color = TextTertiary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)

                if (isOpen) {
                    IconButton(onClick = onCancel, modifier = Modifier.size(20.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Cancel", tint = MarketRed, modifier = Modifier.size(14.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun AssetAllocationCard(account: com.example.data.model.Account?) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("TARGET VS ACTUAL ASSET ALLOCATION", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

            val allocs = listOf(
                "Global Equities" to ((account?.allocationEquities ?: 0.7) * 100).toInt(),
                "Fixed Income & Sovereign Bonds" to ((account?.allocationBonds ?: 0.18) * 100).toInt(),
                "Institutional Funds & ETFs" to ((account?.allocationFunds ?: 0.08) * 100).toInt(),
                "Alternative Assets / Private Credit" to ((account?.allocationAlternatives ?: 0.04) * 100).toInt(),
                "Digital Assets / Reserve" to ((account?.allocationCrypto ?: 0.0) * 100).toInt()
            )

            allocs.forEach { (name, pct) ->
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(name, color = TextSecondary, fontSize = 10.sp)
                        Text("$pct%", color = RhinoCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    LinearProgressIndicator(
                        progress = { pct / 100f },
                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                        color = RhinoCyan,
                        trackColor = RhinoSurfaceElevated
                    )
                }
            }
        }
    }
}

@Composable
private fun PerformanceAttributionCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("BRINSON-FACHLER PERFORMANCE ATTRIBUTION", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

            listOf(
                Triple("Allocation Effect", "+1.42%", "Overweight Technology and Semiconductor sub-sectors."),
                Triple("Selection Effect", "+3.85%", "Alpha generated from NVDA and AAPL stock selection."),
                Triple("Interaction Effect", "-0.18%", "Cross-product residual interaction across FX hedges.")
            ).forEach { item ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.first, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(item.third, color = TextTertiary, fontSize = 9.sp)
                    }
                    Text(item.second, color = if (item.second.startsWith("+")) MarketGreen else MarketRed, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                Divider(color = RhinoBorder.copy(alpha = 0.3f), thickness = 0.5.dp)
            }
        }
    }
}
