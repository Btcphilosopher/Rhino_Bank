package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Candle
import com.example.ui.theme.*
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max
import kotlin.math.min

@Composable
fun RhinoInteractiveChart(
    ticker: String,
    candles: List<Candle>,
    selectedTimeframe: String,
    onTimeframeSelected: (String) -> Unit,
    activeChartType: String, // CANDLESTICK, LINE, AREA
    onChartTypeSelected: (String) -> Unit,
    enabledIndicators: Set<String>,
    onToggleIndicator: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCandleIndex by remember { mutableStateOf<Int?>(null) }
    var touchX by remember { mutableStateOf<Float?>(null) }

    val timeframes = listOf("1m", "5m", "15m", "1h", "1D", "1W", "1M", "1Y", "5Y")
    val chartTypes = listOf("CANDLESTICK", "LINE", "AREA")
    val indicators = listOf("SMA_20", "VWAP", "BOLLINGER", "RSI")

    val activeCandle = selectedCandleIndex?.let { idx ->
        candles.getOrNull(idx)
    } ?: candles.lastOrNull()

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            // Chart Control Top Bar: Timeframes & Type Selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Timeframe pills
                timeframes.forEach { tf ->
                    val isSelected = selectedTimeframe == tf
                    Surface(
                        onClick = { onTimeframeSelected(tf) },
                        shape = RoundedCornerShape(4.dp),
                        color = if (isSelected) RhinoCyan.copy(alpha = 0.2f) else RhinoSurfaceElevated,
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, RhinoCyan) else null
                    ) {
                        Text(
                            text = tf,
                            color = if (isSelected) RhinoCyan else TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(Modifier.width(8.dp))

                // Chart Style selector
                chartTypes.forEach { type ->
                    val isSelected = activeChartType == type
                    Surface(
                        onClick = { onChartTypeSelected(type) },
                        shape = RoundedCornerShape(4.dp),
                        color = if (isSelected) RhinoBlue.copy(alpha = 0.25f) else RhinoSurfaceElevated
                    ) {
                        Text(
                            text = when (type) {
                                "CANDLESTICK" -> "CANDLES"
                                "LINE" -> "LINE"
                                "AREA" -> "AREA"
                                else -> type
                            },
                            color = if (isSelected) RhinoCyan else TextTertiary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(6.dp))

            // Technical Indicators Pills
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "STUDIES:",
                    color = TextTertiary,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                indicators.forEach { ind ->
                    val isEnabled = enabledIndicators.contains(ind)
                    Surface(
                        onClick = { onToggleIndicator(ind) },
                        shape = RoundedCornerShape(3.dp),
                        color = if (isEnabled) RhinoGold.copy(alpha = 0.2f) else RhinoSurfaceElevated,
                        border = if (isEnabled) androidx.compose.foundation.BorderStroke(0.8.dp, RhinoGold) else null
                    ) {
                        Text(
                            text = ind,
                            color = if (isEnabled) RhinoGold else TextTertiary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // Active Candle OHLC Bar
            if (activeCandle != null) {
                val isUp = activeCandle.close >= activeCandle.open
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RhinoSurfaceElevated)
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(activeCandle.timestamp)),
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "O: ${DecimalFormat("#.00").format(activeCandle.open)}",
                        color = TextPrimary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "H: ${DecimalFormat("#.00").format(activeCandle.high)}",
                        color = MarketGreen,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "L: ${DecimalFormat("#.00").format(activeCandle.low)}",
                        color = MarketRed,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "C: ${DecimalFormat("#.00").format(activeCandle.close)}",
                        color = if (isUp) MarketGreen else MarketRed,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "VOL: ${DecimalFormat("#,##0").format(activeCandle.volume)}",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // Main Canvas
            if (candles.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .background(RhinoBackground)
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onPress = { offset ->
                                    val candleWidth = size.width / candles.size.toFloat()
                                    val index = (offset.x / candleWidth).toInt().coerceIn(0, candles.size - 1)
                                    selectedCandleIndex = index
                                    touchX = offset.x
                                }
                            )
                        }
                        .pointerInput(Unit) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                val candleWidth = size.width / candles.size.toFloat()
                                val index = (change.position.x / candleWidth).toInt().coerceIn(0, candles.size - 1)
                                selectedCandleIndex = index
                                touchX = change.position.x
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val width = size.width
                        val height = size.height

                        val minPrice = candles.minOf { it.low } * 0.998
                        val maxPrice = candles.maxOf { it.high } * 1.002
                        val priceRange = max(0.01, maxPrice - minPrice)

                        fun priceToY(price: Double): Float {
                            return (height - ((price - minPrice) / priceRange * height)).toFloat()
                        }

                        // Horizontal Price Grid Lines
                        val gridLevels = 4
                        for (i in 0..gridLevels) {
                            val y = height * (i.toFloat() / gridLevels)
                            drawLine(
                                color = RhinoBorder.copy(alpha = 0.6f),
                                start = Offset(0f, y),
                                end = Offset(width, y),
                                strokeWidth = 1f
                            )
                        }

                        val candleCount = candles.size
                        val stepX = width / candleCount.toFloat()
                        val candleWidth = max(2f, stepX * 0.7f)

                        // Draw Bollinger Bands if enabled
                        if (enabledIndicators.contains("BOLLINGER")) {
                            val upperPath = Path()
                            val lowerPath = Path()
                            for (i in candles.indices) {
                                val x = (i * stepX) + (stepX / 2)
                                val c = candles[i].close
                                val upper = c * 1.018
                                val lower = c * 0.982
                                val uy = priceToY(upper)
                                val ly = priceToY(lower)
                                if (i == 0) {
                                    upperPath.moveTo(x, uy)
                                    lowerPath.moveTo(x, ly)
                                } else {
                                    upperPath.lineTo(x, uy)
                                    lowerPath.lineTo(x, ly)
                                }
                            }
                            drawPath(
                                path = upperPath,
                                color = RhinoGold.copy(alpha = 0.5f),
                                style = Stroke(width = 1.5f)
                            )
                            drawPath(
                                path = lowerPath,
                                color = RhinoGold.copy(alpha = 0.5f),
                                style = Stroke(width = 1.5f)
                            )
                        }

                        // Draw SMA_20 if enabled
                        if (enabledIndicators.contains("SMA_20")) {
                            val smaPath = Path()
                            var initialized = false
                            for (i in candles.indices) {
                                val window = candles.subList(max(0, i - 19), i + 1)
                                val avg = window.sumOf { it.close } / window.size
                                val x = (i * stepX) + (stepX / 2)
                                val y = priceToY(avg)
                                if (!initialized) {
                                    smaPath.moveTo(x, y)
                                    initialized = true
                                } else {
                                    smaPath.lineTo(x, y)
                                }
                            }
                            drawPath(
                                path = smaPath,
                                color = RhinoCyan,
                                style = Stroke(width = 2f)
                            )
                        }

                        // Draw VWAP if enabled
                        if (enabledIndicators.contains("VWAP")) {
                            val vwapPath = Path()
                            var cumVol = 0L
                            var cumPv = 0.0
                            for (i in candles.indices) {
                                val c = candles[i]
                                val typicalPrice = (c.high + c.low + c.close) / 3.0
                                cumVol += c.volume
                                cumPv += (typicalPrice * c.volume)
                                val vwap = cumPv / max(1L, cumVol)
                                val x = (i * stepX) + (stepX / 2)
                                val y = priceToY(vwap)
                                if (i == 0) {
                                    vwapPath.moveTo(x, y)
                                } else {
                                    vwapPath.lineTo(x, y)
                                }
                            }
                            drawPath(
                                path = vwapPath,
                                color = RhinoPurple,
                                style = Stroke(width = 1.8f)
                            )
                        }

                        // Render Candles / Line / Area
                        when (activeChartType) {
                            "LINE" -> {
                                val linePath = Path()
                                for (i in candles.indices) {
                                    val x = (i * stepX) + (stepX / 2)
                                    val y = priceToY(candles[i].close)
                                    if (i == 0) linePath.moveTo(x, y) else linePath.lineTo(x, y)
                                }
                                drawPath(linePath, color = RhinoCyan, style = Stroke(width = 2.5f))
                            }
                            "AREA" -> {
                                val linePath = Path()
                                val fillPath = Path()
                                for (i in candles.indices) {
                                    val x = (i * stepX) + (stepX / 2)
                                    val y = priceToY(candles[i].close)
                                    if (i == 0) {
                                        linePath.moveTo(x, y)
                                        fillPath.moveTo(x, height)
                                        fillPath.lineTo(x, y)
                                    } else {
                                        linePath.lineTo(x, y)
                                        fillPath.lineTo(x, y)
                                    }
                                }
                                fillPath.lineTo(width, height)
                                fillPath.close()

                                drawPath(
                                    fillPath,
                                    brush = Brush.verticalGradient(
                                        colors = listOf(RhinoCyan.copy(alpha = 0.35f), RhinoCyan.copy(alpha = 0.02f)),
                                        startY = 0f,
                                        endY = height
                                    )
                                )
                                drawPath(linePath, color = RhinoCyan, style = Stroke(width = 2.5f))
                            }
                            else -> { // CANDLESTICK default
                                for (i in candles.indices) {
                                    val candle = candles[i]
                                    val isUp = candle.close >= candle.open
                                    val candleColor = if (isUp) MarketGreen else MarketRed
                                    val centerX = (i * stepX) + (stepX / 2)

                                    // Wick
                                    val highY = priceToY(candle.high)
                                    val lowY = priceToY(candle.low)
                                    drawLine(
                                        color = candleColor,
                                        start = Offset(centerX, highY),
                                        end = Offset(centerX, lowY),
                                        strokeWidth = 1.5f
                                    )

                                    // Body
                                    val openY = priceToY(candle.open)
                                    val closeY = priceToY(candle.close)
                                    val topY = min(openY, closeY)
                                    val bodyHeight = max(2f, kotlin.math.abs(closeY - openY))

                                    drawRect(
                                        color = candleColor,
                                        topLeft = Offset(centerX - (candleWidth / 2), topY),
                                        size = Size(candleWidth, bodyHeight)
                                    )
                                }
                            }
                        }

                        // Crosshair on user tap/drag
                        touchX?.let { currentTouchX ->
                            drawLine(
                                color = RhinoCyan.copy(alpha = 0.7f),
                                start = Offset(currentTouchX, 0f),
                                end = Offset(currentTouchX, height),
                                strokeWidth = 1f
                            )
                        }
                    }
                }
            }

            // RSI Sub-Chart if enabled
            if (enabledIndicators.contains("RSI") && candles.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("RSI (14): 58.4", color = RhinoGold, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text("OVERBOUGHT 70 / OVERSOLD 30", color = TextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(45.dp)
                        .background(RhinoBackground)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height

                        // 70 and 30 lines
                        val y70 = h * 0.3f
                        val y30 = h * 0.7f
                        drawLine(RhinoBorder, Offset(0f, y70), Offset(w, y70), strokeWidth = 1f)
                        drawLine(RhinoBorder, Offset(0f, y30), Offset(w, y30), strokeWidth = 1f)

                        val rsiPath = Path()
                        val stepX = w / candles.size.toFloat()
                        for (i in candles.indices) {
                            val x = (i * stepX) + (stepX / 2)
                            // deterministic simulated RSI oscillating around 50
                            val rsiVal = 50.0 + (candles[i].close - candles[max(0, i - 1)].close) * 1.5
                            val clampedRsi = rsiVal.coerceIn(10.0, 90.0)
                            val y = (h - ((clampedRsi / 100.0) * h)).toFloat()
                            if (i == 0) rsiPath.moveTo(x, y) else rsiPath.lineTo(x, y)
                        }
                        drawPath(rsiPath, color = RhinoGold, style = Stroke(width = 1.5f))
                    }
                }
            }
        }
    }
}
