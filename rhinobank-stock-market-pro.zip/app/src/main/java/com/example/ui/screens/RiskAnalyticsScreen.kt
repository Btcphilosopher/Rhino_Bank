package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StressScenario
import com.example.ui.theme.*
import com.example.ui.viewmodel.RhinoMainViewModel
import java.text.DecimalFormat

@Composable
fun RiskAnalyticsScreen(
    viewModel: RhinoMainViewModel,
    modifier: Modifier = Modifier
) {
    val correlationTimeframe by viewModel.correlationTimeframe.collectAsState()
    val stressScenarios = remember { viewModel.getStressScenarios() }

    val corrMatrix = listOf(
        listOf("AAPL", "1.00", "0.74", "0.68", "0.62", "0.58", "0.32"),
        listOf("MSFT", "0.74", "1.00", "0.82", "0.71", "0.66", "0.28"),
        listOf("NVDA", "0.68", "0.82", "1.00", "0.65", "0.70", "0.21"),
        listOf("AMZN", "0.62", "0.71", "0.65", "1.00", "0.76", "0.35"),
        listOf("META", "0.58", "0.66", "0.70", "0.76", "1.00", "0.29"),
        listOf("JPM",  "0.32", "0.28", "0.21", "0.35", "0.29", "1.00")
    )
    val corrHeaders = listOf("SEC", "AAPL", "MSFT", "NVDA", "AMZN", "META", "JPM")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Risk Header & Report Button
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = RhinoCyan)
                        Text(
                            text = "INSTITUTIONAL RISK & CAPITAL MANAGEMENT",
                            color = RhinoCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Surface(
                        onClick = { viewModel.openReportModal("RISK_REPORT") },
                        shape = RoundedCornerShape(4.dp),
                        color = RhinoCyan.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(0.8.dp, RhinoCyan.copy(alpha = 0.4f))
                    ) {
                        Row(modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Description, contentDescription = null, tint = RhinoCyan, modifier = Modifier.size(12.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("RISK MEMO", color = RhinoCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Institutional Risk Metrics Grid
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("KEY RISK & SENSITIVITY METRICS (CONFIDENCE 95%)", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                    val kpis = listOf(
                        "Annualized Volatility" to "16.42%",
                        "Portfolio Beta" to "1.18",
                        "Sharpe Ratio (Rf=4.2%)" to "2.14",
                        "Sortino Ratio" to "2.88",
                        "1-Day 95% VaR" to "$6,420,000",
                        "1-Day 95% CVaR" to "$9,150,000",
                        "Max Historic Drawdown" to "-11.20%",
                        "Herfindahl Index" to "0.142 (OK)"
                    )

                    for (i in kpis.indices step 2) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(kpis[i].first, color = TextTertiary, fontSize = 9.sp)
                                Text(kpis[i].second, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                            if (i + 1 < kpis.size) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(kpis[i + 1].first, color = TextTertiary, fontSize = 9.sp)
                                    Text(kpis[i + 1].second, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                        if (i < kpis.size - 2) Divider(color = RhinoBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                    }
                }
            }
        }

        // Stress Testing Scenarios Section
        item {
            Text("STRESS TESTING & CAPITAL AT RISK SIMULATIONS", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }

        items(stressScenarios) { scn ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(scn.name, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = "${DecimalFormat("#0.00").format(scn.estimatedPortfolioImpactPercent)}%",
                            color = if (scn.estimatedPortfolioImpactPercent < 0) MarketRed else MarketGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(scn.shockDescription, color = TextSecondary, fontSize = 9.sp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Simulated Dollar Impact (${scn.affectedSectors}):", color = TextTertiary, fontSize = 9.sp)
                        Text(
                            text = "$${DecimalFormat("#,##0,000").format(scn.estimatedDollarLoss)}",
                            color = if (scn.estimatedDollarLoss < 0) MarketRed else MarketGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Cross-Asset Correlation Matrix
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("CROSS-ASSET CORRELATION MATRIX", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("30D", "90D", "1Y", "3Y", "5Y").forEach { tf ->
                                val isSelected = correlationTimeframe == tf
                                Surface(
                                    onClick = { viewModel.setCorrelationTimeframe(tf) },
                                    shape = RoundedCornerShape(3.dp),
                                    color = if (isSelected) RhinoCyan.copy(alpha = 0.2f) else RhinoSurfaceElevated
                                ) {
                                    Text(tf, color = if (isSelected) RhinoCyan else TextSecondary, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                }
                            }
                        }
                    }

                    // Table
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Headers
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            corrHeaders.forEach { h ->
                                Box(
                                    modifier = Modifier.width(42.dp).background(RhinoSurfaceElevated).padding(vertical = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(h, color = RhinoCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }

                        // Matrix Rows
                        corrMatrix.forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                row.forEachIndexed { idx, cell ->
                                    val cellVal = cell.toDoubleOrNull() ?: 0.0
                                    val cellBg = when {
                                        idx == 0 -> RhinoSurfaceElevated
                                        cellVal >= 0.8 -> RhinoCyan.copy(alpha = 0.35f)
                                        cellVal >= 0.6 -> RhinoCyan.copy(alpha = 0.20f)
                                        else -> RhinoSurfaceElevated
                                    }
                                    Box(
                                        modifier = Modifier.width(42.dp).background(cellBg).padding(vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = cell,
                                            color = if (idx == 0) TextPrimary else TextSecondary,
                                            fontSize = 9.sp,
                                            fontWeight = if (idx == 0) FontWeight.Bold else FontWeight.Normal,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
