package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.RhinoOrderBookLadder
import com.example.ui.components.TradeTicketReviewModal
import com.example.ui.theme.*
import com.example.ui.viewmodel.RhinoMainViewModel
import java.text.DecimalFormat

@Composable
fun TradeDeskScreen(
    viewModel: RhinoMainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedSec by viewModel.selectedSecurity.collectAsState()
    val orderBooks by viewModel.orderBooks.collectAsState()
    val activeAccount by viewModel.activeAccount.collectAsState()
    val orders by viewModel.orders.collectAsState()

    val sec = selectedSec
    val ticker = sec?.ticker ?: "NVDA"
    val orderBook = orderBooks[ticker]

    var side by remember { mutableStateOf(OrderSide.BUY) }
    var orderType by remember { mutableStateOf(OrderType.LIMIT) }
    var quantityStr by remember { mutableStateOf("500") }
    var priceStr by remember(sec?.price) { mutableStateOf(sec?.price?.let { DecimalFormat("#0.00").format(it) } ?: "120.00") }
    var stopPriceStr by remember { mutableStateOf("") }
    var timeInForce by remember { mutableStateOf(TimeInForce.DAY) }
    var showReviewModal by remember { mutableStateOf(false) }

    val quantity = quantityStr.toIntOrNull() ?: 100
    val price = if (orderType == OrderType.MARKET) sec?.price else priceStr.toDoubleOrNull()
    val stopPrice = stopPriceStr.toDoubleOrNull()
    val estimatedValue = quantity * (price ?: 0.0)

    val preTradeCheck = remember(ticker, side, orderType, quantity, price, activeAccount) {
        viewModel.validatePreTrade(ticker, side, orderType, quantity, price)
    }

    if (showReviewModal) {
        TradeTicketReviewModal(
            symbol = ticker,
            side = side,
            type = orderType,
            quantity = quantity,
            price = price,
            stopPrice = stopPrice,
            timeInForce = timeInForce,
            account = activeAccount,
            preTradeCheck = preTradeCheck,
            onDismiss = { showReviewModal = false },
            onConfirm = {
                viewModel.submitOrder(ticker, side, orderType, quantity, price, stopPrice, timeInForce)
                showReviewModal = false
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Trade Desk Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("INSTITUTIONAL TRADE DESK", color = RhinoCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                            Text("[DIRECT MARKET ACCESS]", color = RhinoGold, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Text(
                            text = "Target Account: ${activeAccount?.name} (${activeAccount?.id}) • Cash: $${DecimalFormat("#,##0").format(activeAccount?.cash ?: 0.0)}",
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = RhinoSurfaceElevated,
                        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
                    ) {
                        Text(
                            text = "VENUE: RHINO-CROSS",
                            color = TextTertiary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }

        // Level II Depth Ladder
        item {
            RhinoOrderBookLadder(
                orderBook = orderBook,
                onPriceSelected = { selectedPrice ->
                    priceStr = DecimalFormat("#0.00").format(selectedPrice)
                    orderType = OrderType.LIMIT
                }
            )
        }

        // Order Entry Ticket
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ORDER EXECUTION TICKET ($ticker)", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                    // Side Selector (BUY / SELL)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { side = OrderSide.BUY },
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("trade_side_buy_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (side == OrderSide.BUY) MarketGreen else RhinoSurfaceElevated
                            )
                        ) {
                            Text(
                                "BUY / LONG",
                                color = if (side == OrderSide.BUY) Color(0xFF001E2B) else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        Button(
                            onClick = { side = OrderSide.SELL },
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("trade_side_sell_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (side == OrderSide.SELL) MarketRed else RhinoSurfaceElevated
                            )
                        ) {
                            Text(
                                "SELL / SHORT",
                                color = if (side == OrderSide.SELL) Color(0xFF001E2B) else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }

                    // Order Type Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        OrderType.values().forEach { ot ->
                            val isSelected = orderType == ot
                            Surface(
                                onClick = { orderType = ot },
                                shape = RoundedCornerShape(4.dp),
                                color = if (isSelected) RhinoCyan.copy(alpha = 0.2f) else RhinoSurfaceElevated,
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, RhinoCyan) else null,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = ot.name,
                                    color = if (isSelected) RhinoCyan else TextSecondary,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(vertical = 6.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }

                    // Quantity and Quick Buttons
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedTextField(
                            value = quantityStr,
                            onValueChange = { quantityStr = it },
                            label = { Text("Share Quantity", color = TextSecondary, fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth().testTag("trade_quantity_input"),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = RhinoCyan,
                                unfocusedBorderColor = RhinoBorder
                            )
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(100, 500, 1000, 5000).forEach { qty ->
                                Surface(
                                    onClick = { quantityStr = qty.toString() },
                                    shape = RoundedCornerShape(4.dp),
                                    color = RhinoSurfaceElevated,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = "+$qty",
                                        color = TextSecondary,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.padding(vertical = 4.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        }
                    }

                    // Limit Price (if not market)
                    if (orderType != OrderType.MARKET) {
                        OutlinedTextField(
                            value = priceStr,
                            onValueChange = { priceStr = it },
                            label = { Text("Limit Price ($)", color = TextSecondary, fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth().testTag("trade_price_input"),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = RhinoCyan,
                                unfocusedBorderColor = RhinoBorder
                            )
                        )
                    }

                    // Time in Force
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        TimeInForce.values().forEach { tif ->
                            val isSelected = timeInForce == tif
                            Surface(
                                onClick = { timeInForce = tif },
                                shape = RoundedCornerShape(4.dp),
                                color = if (isSelected) RhinoGold.copy(alpha = 0.2f) else RhinoSurfaceElevated,
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, RhinoGold) else null,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = tif.name,
                                    color = if (isSelected) RhinoGold else TextTertiary,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(vertical = 4.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }

                    Divider(color = RhinoBorder, thickness = 1.dp)

                    // Order Consideration Summary
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("ESTIMATED CONSIDERATION:", color = TextTertiary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = "$${DecimalFormat("#,##0.00").format(estimatedValue)}",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Pre-Trade Surveillance Banner
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (preTradeCheck.passed) MarketGreen.copy(alpha = 0.15f) else MarketRed.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = if (preTradeCheck.passed) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (preTradeCheck.passed) MarketGreen else MarketRed,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "PRE-TRADE RISK: ${preTradeCheck.riskStatus}",
                            color = if (preTradeCheck.passed) MarketGreen else MarketRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Order Submission Action
                    Button(
                        onClick = { showReviewModal = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("preview_order_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (side == OrderSide.BUY) MarketGreen else MarketRed
                        )
                    ) {
                        Text(
                            text = "REVIEW & EXECUTE ${side.name} ORDER",
                            color = Color(0xFF001E2B),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }

        // Active Orders for this Account
        item {
            Text(
                text = "ACTIVE OPEN ORDERS (OMS)",
                color = RhinoCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        val openOrders = orders.filter { it.status == OrderStatus.OPEN || it.status == OrderStatus.PARTIALLY_FILLED }
        if (openOrders.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = RhinoSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No open working orders in OMS blotter.",
                        color = TextTertiary,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(14.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            items(openOrders) { ord ->
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = RhinoSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder),
                    modifier = Modifier.fillMaxWidth().testTag("open_order_${ord.id}")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(ord.side.name, color = if (ord.side == OrderSide.BUY) MarketGreen else MarketRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(ord.symbol, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text("${ord.quantity} shs", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            }
                            Text(
                                text = "#${ord.id} • ${ord.type.name} @ ${ord.price?.let { "$$it" } ?: "MKT"} • ${ord.status.name}",
                                color = TextTertiary,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        IconButton(
                            onClick = { viewModel.cancelOrder(ord.id) },
                            modifier = Modifier.size(28.dp).background(RhinoSurfaceElevated, RoundedCornerShape(4.dp))
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Cancel", tint = MarketRed, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}
