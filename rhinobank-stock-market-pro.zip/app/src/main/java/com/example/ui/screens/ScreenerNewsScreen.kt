package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NewsCategory
import com.example.data.model.NewsItem
import com.example.data.model.Security
import com.example.data.model.Sentiment
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.RhinoMainViewModel
import java.text.DecimalFormat

@Composable
fun ScreenerNewsScreen(
    viewModel: RhinoMainViewModel,
    modifier: Modifier = Modifier
) {
    val screenedSecurities by viewModel.screenedSecurities.collectAsState()
    val screenerCriteria by viewModel.screenerCriteria.collectAsState()
    val news by viewModel.news.collectAsState()

    var activeTopTab by remember { mutableStateOf("SCREENER") } // SCREENER, NEWS_WIRE
    var selectedNewsCategory by remember { mutableStateOf<NewsCategory?>(null) }
    var selectedSector by remember { mutableStateOf("ALL") }

    val sectors = listOf("ALL", "Technology", "Healthcare", "Financial Services", "Energy", "Consumer Cyclical")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Top Switcher
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { activeTopTab = "SCREENER" },
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f).height(36.dp).testTag("tab_screener_toggle"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (activeTopTab == "SCREENER") RhinoCyan else RhinoSurfaceElevated
                        )
                    ) {
                        Icon(imageVector = Icons.Default.FilterList, contentDescription = null, tint = if (activeTopTab == "SCREENER") RhinoBackground else TextSecondary, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("EQUITY SCREENER", color = if (activeTopTab == "SCREENER") RhinoBackground else TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { activeTopTab = "NEWS_WIRE" },
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f).height(36.dp).testTag("tab_news_toggle"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (activeTopTab == "NEWS_WIRE") RhinoCyan else RhinoSurfaceElevated
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Newspaper, contentDescription = null, tint = if (activeTopTab == "NEWS_WIRE") RhinoBackground else TextSecondary, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("INSTITUTIONAL NEWS", color = if (activeTopTab == "NEWS_WIRE") RhinoBackground else TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (activeTopTab == "SCREENER") {
            // Screener Filter Controls
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("MULTI-VARIABLE QUANT FILTER SETTINGS", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                        // Sector filter pills
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            sectors.forEach { sec ->
                                val isSelected = selectedSector == sec
                                Surface(
                                    onClick = {
                                        selectedSector = sec
                                        viewModel.updateScreenerCriteria(screenerCriteria.copy(selectedSector = sec))
                                    },
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (isSelected) RhinoCyan.copy(alpha = 0.2f) else RhinoSurfaceElevated,
                                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, RhinoCyan) else null
                                ) {
                                    Text(
                                        text = sec,
                                        color = if (isSelected) RhinoCyan else TextSecondary,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.height(4.dp))

                        // Sliders: Max P/E and Min ROIC
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Max Trailing P/E: ${DecimalFormat("#0").format(screenerCriteria.maxPe)}x", color = TextSecondary, fontSize = 10.sp)
                        }
                        Slider(
                            value = screenerCriteria.maxPe.toFloat(),
                            onValueChange = { viewModel.updateScreenerCriteria(screenerCriteria.copy(maxPe = it.toDouble())) },
                            valueRange = 10f..100f,
                            colors = SliderDefaults.colors(thumbColor = RhinoCyan, activeTrackColor = RhinoCyan)
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Min ROIC: ${DecimalFormat("#0").format(screenerCriteria.minRoic)}%", color = TextSecondary, fontSize = 10.sp)
                        }
                        Slider(
                            value = screenerCriteria.minRoic.toFloat(),
                            onValueChange = { viewModel.updateScreenerCriteria(screenerCriteria.copy(minRoic = it.toDouble())) },
                            valueRange = 0f..40f,
                            colors = SliderDefaults.colors(thumbColor = RhinoCyan, activeTrackColor = RhinoCyan)
                        )
                    }
                }
            }

            // Screened Results Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("QUALIFYING SECURITIES (${screenedSecurities.size})", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("SORT: MARKET CAP (DESC)", color = TextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }

            items(screenedSecurities) { sec ->
                Surface(
                    onClick = {
                        viewModel.selectSecurity(sec.ticker)
                        viewModel.selectTab(MainNavigationTab.TERMINAL)
                    },
                    shape = RoundedCornerShape(6.dp),
                    color = RhinoSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder),
                    modifier = Modifier.fillMaxWidth().testTag("screener_item_${sec.ticker}")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.2f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(sec.ticker, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(sec.exchange, color = RhinoCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(sec.name, color = TextSecondary, fontSize = 10.sp, maxLines = 1)
                            Text("ROIC: ${sec.roic}% • P/E: ${sec.pe}x • D/E: ${sec.debtToEquity}x", color = TextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("$${DecimalFormat("#,##0.00").format(sec.price)}", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text("MCap: $${sec.marketCap}B", color = TextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        } else {
            // News Wire Section
            item {
                // Category filter pills
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        onClick = { selectedNewsCategory = null },
                        shape = RoundedCornerShape(4.dp),
                        color = if (selectedNewsCategory == null) RhinoCyan.copy(alpha = 0.2f) else RhinoSurfaceElevated
                    ) {
                        Text("ALL NEWS", color = if (selectedNewsCategory == null) RhinoCyan else TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                    }
                    NewsCategory.values().forEach { cat ->
                        val isSelected = selectedNewsCategory == cat
                        Surface(
                            onClick = { selectedNewsCategory = cat },
                            shape = RoundedCornerShape(4.dp),
                            color = if (isSelected) RhinoCyan.copy(alpha = 0.2f) else RhinoSurfaceElevated
                        ) {
                            Text(cat.name, color = if (isSelected) RhinoCyan else TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                        }
                    }
                }
            }

            val filteredNews = if (selectedNewsCategory == null) news else news.filter { it.category == selectedNewsCategory }

            items(filteredNews) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(item.source, color = RhinoGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(
                                            when (item.sentiment) {
                                                Sentiment.BULLISH -> MarketGreen.copy(alpha = 0.2f)
                                                Sentiment.BEARISH -> MarketRed.copy(alpha = 0.2f)
                                                Sentiment.NEUTRAL -> RhinoSurfaceElevated
                                            }
                                        )
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = item.sentiment.name,
                                        color = when (item.sentiment) {
                                            Sentiment.BULLISH -> MarketGreen
                                            Sentiment.BEARISH -> MarketRed
                                            Sentiment.NEUTRAL -> TextTertiary
                                        },
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(item.timestamp, color = TextTertiary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }

                        Text(item.headline, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(item.summary, color = TextSecondary, fontSize = 10.sp, lineHeight = 14.sp)

                        if (item.relatedTickers.isNotEmpty()) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                item.relatedTickers.forEach { sym ->
                                    Surface(
                                        onClick = {
                                            viewModel.selectSecurity(sym)
                                            viewModel.selectTab(MainNavigationTab.TERMINAL)
                                        },
                                        shape = RoundedCornerShape(3.dp),
                                        color = RhinoCyan.copy(alpha = 0.15f)
                                    ) {
                                        Text(sym, color = RhinoCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
