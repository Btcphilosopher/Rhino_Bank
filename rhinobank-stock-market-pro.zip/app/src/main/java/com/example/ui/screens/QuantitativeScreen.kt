package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BacktestStrategy
import com.example.ui.theme.*
import com.example.ui.viewmodel.RhinoMainViewModel
import java.text.DecimalFormat

@Composable
fun QuantitativeScreen(
    viewModel: RhinoMainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedSec by viewModel.selectedSecurity.collectAsState()
    val assumptions by viewModel.dcfAssumptions.collectAsState()
    val strategies = remember { viewModel.getBacktestStrategies() }

    val ticker = selectedSec?.ticker ?: "NVDA"
    val dcfResult = viewModel.getDcfResult(ticker)
    var activeQuantTab by remember { mutableStateOf("DCF_WORKBENCH") } // DCF_WORKBENCH, SCENARIOS, MARKOWITZ, BACKTEST

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Quantitative Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "QUANTITATIVE VALUATION & ALGORITHMIC LAB",
                            color = RhinoCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "SECURITY: $ticker",
                            color = RhinoGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Selector
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(
                            "DCF_WORKBENCH" to "DCF Model",
                            "SCENARIOS" to "Scenarios",
                            "MARKOWITZ" to "Markowitz MPT",
                            "BACKTEST" to "Backtesting"
                        ).forEach { pair ->
                            val isSelected = activeQuantTab == pair.first
                            Surface(
                                onClick = { activeQuantTab = pair.first },
                                shape = RoundedCornerShape(4.dp),
                                color = if (isSelected) RhinoCyan.copy(alpha = 0.2f) else RhinoSurfaceElevated,
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, RhinoCyan) else null
                            ) {
                                Text(
                                    text = pair.second,
                                    color = if (isSelected) RhinoCyan else TextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        when (activeQuantTab) {
            "DCF_WORKBENCH" -> {
                item {
                    DcfWorkbenchCard(ticker = ticker, price = selectedSec?.price ?: 120.0, dcfResult = dcfResult, assumptions = assumptions, onUpdate = { viewModel.updateDcfAssumptions(it) })
                }
            }

            "SCENARIOS" -> {
                item {
                    ScenarioModellingCard(basePrice = selectedSec?.price ?: 120.0, dcfFairValue = dcfResult.fairValuePerShare)
                }
            }

            "MARKOWITZ" -> {
                item {
                    MarkowitzOptimizationCard()
                }
            }

            "BACKTEST" -> {
                items(strategies) { strat ->
                    BacktestStrategyCard(strat = strat)
                }
            }
        }
    }
}

@Composable
private fun DcfWorkbenchCard(
    ticker: String,
    price: Double,
    dcfResult: com.example.data.model.DcfResult,
    assumptions: com.example.data.model.DcfAssumptions,
    onUpdate: (com.example.data.model.DcfAssumptions) -> Unit
) {
    val isUndervalued = dcfResult.fairValuePerShare > price
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("DCF INTRINSIC VALUATION FOR $ticker", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

            Surface(
                shape = RoundedCornerShape(6.dp),
                color = if (isUndervalued) MarketGreen.copy(alpha = 0.15f) else MarketRed.copy(alpha = 0.15f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("IMPLIED FAIR VALUE PER SHARE", color = TextSecondary, fontSize = 9.sp)
                        Text(
                            "$${DecimalFormat("#,##0.00").format(dcfResult.fairValuePerShare)}",
                            color = if (isUndervalued) MarketGreen else MarketRed,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("IMPLIED ENTERPRISE VALUE", color = TextSecondary, fontSize = 9.sp)
                        Text(
                            "$${DecimalFormat("#,##0.0").format(dcfResult.enterpriseValueBln)}B",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Sliders
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Revenue Growth (5-Year CAGR)", color = TextSecondary, fontSize = 10.sp)
                    Text("${DecimalFormat("#0.0").format(assumptions.revenueGrowthPct)}%", color = RhinoCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
                Slider(
                    value = assumptions.revenueGrowthPct.toFloat(),
                    onValueChange = { onUpdate(assumptions.copy(revenueGrowthPct = it.toDouble())) },
                    valueRange = 0f..35f,
                    colors = SliderDefaults.colors(thumbColor = RhinoCyan, activeTrackColor = RhinoCyan)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("EBITDA Operating Margin", color = TextSecondary, fontSize = 10.sp)
                    Text("${DecimalFormat("#0.0").format(assumptions.ebitdaMarginPct)}%", color = RhinoCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
                Slider(
                    value = assumptions.ebitdaMarginPct.toFloat(),
                    onValueChange = { onUpdate(assumptions.copy(ebitdaMarginPct = it.toDouble())) },
                    valueRange = 10f..65f,
                    colors = SliderDefaults.colors(thumbColor = RhinoCyan, activeTrackColor = RhinoCyan)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("WACC (Weighted Avg Cost of Capital)", color = TextSecondary, fontSize = 10.sp)
                    Text("${DecimalFormat("#0.0").format(assumptions.waccPct)}%", color = RhinoCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
                Slider(
                    value = assumptions.waccPct.toFloat(),
                    onValueChange = { onUpdate(assumptions.copy(waccPct = it.toDouble())) },
                    valueRange = 5f..15f,
                    colors = SliderDefaults.colors(thumbColor = RhinoCyan, activeTrackColor = RhinoCyan)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Terminal Growth Rate (Perpetuity)", color = TextSecondary, fontSize = 10.sp)
                    Text("${DecimalFormat("#0.0").format(assumptions.terminalGrowthPct)}%", color = RhinoCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
                Slider(
                    value = assumptions.terminalGrowthPct.toFloat(),
                    onValueChange = { onUpdate(assumptions.copy(terminalGrowthPct = it.toDouble())) },
                    valueRange = 1f..5f,
                    colors = SliderDefaults.colors(thumbColor = RhinoCyan, activeTrackColor = RhinoCyan)
                )
            }
        }
    }
}

@Composable
private fun ScenarioModellingCard(basePrice: Double, dcfFairValue: Double) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("THREE-STAGE SCENARIO VALUATION MATRIX", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

            listOf(
                Triple("BULL CASE (30% Prob)", dcfFairValue * 1.35, "Accelerated AI Cloud monetization, operating leverage expands margin to 42%."),
                Triple("BASE CASE (50% Prob)", dcfFairValue, "Market-consensus revenue growth with stable gross margins and controlled capex."),
                Triple("BEAR CASE (20% Prob)", dcfFairValue * 0.72, "Regulatory scrutiny, macro deceleration, enterprise spend compression.")
            ).forEach { item ->
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = RhinoSurfaceElevated,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(item.first, color = if (item.first.startsWith("BULL")) MarketGreen else if (item.first.startsWith("BASE")) RhinoCyan else MarketRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("$${DecimalFormat("#,##0.00").format(item.second)}", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Text(item.third, color = TextSecondary, fontSize = 9.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun MarkowitzOptimizationCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("MARKOWITZ MEAN-VARIANCE EFFICIENT FRONTIER", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("OPTIMAL PORTFOLIO", color = TextTertiary, fontSize = 9.sp)
                    Text("MAX SHARPE (2.42)", color = RhinoGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Column {
                    Text("EXP RETURN", color = TextTertiary, fontSize = 9.sp)
                    Text("+24.8% p.a.", color = MarketGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                Column {
                    Text("TARGET VOL", color = TextTertiary, fontSize = 9.sp)
                    Text("12.6% p.a.", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }

            Divider(color = RhinoBorder, thickness = 1.dp)

            Text("RECOMMENDED WEIGHT REBALANCING:", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            listOf(
                "AAPL" to "22.5% (+2.5%)",
                "MSFT" to "25.0% (-1.0%)",
                "NVDA" to "28.0% (+6.0%)",
                "AMZN" to "14.5% (-4.5%)",
                "META" to "10.0% (-3.0%)"
            ).forEach { pair ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(pair.first, color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text(pair.second, color = RhinoCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
private fun BacktestStrategyCard(strat: BacktestStrategy) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(strat.name, color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Sharpe: ${strat.sharpe}", color = RhinoGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
            Text("Simulated Win Rate: ${strat.winRate}% • Profit Factor: ${strat.profitFactor}x", color = TextSecondary, fontSize = 9.sp)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("CAGR: +${strat.cagr}%", color = MarketGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                Text("Max DD: ${strat.maxDrawdown}%", color = MarketRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                Text("Win Rate: ${strat.winRate}%", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Text("Turnover: ${strat.turnoverPct}%", color = TextTertiary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
