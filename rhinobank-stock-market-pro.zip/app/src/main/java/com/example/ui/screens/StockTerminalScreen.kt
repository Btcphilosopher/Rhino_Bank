package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EarningsEvent
import com.example.data.model.Security
import com.example.ui.components.RhinoInteractiveChart
import com.example.ui.components.RhinoOrderBookLadder
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.RhinoMainViewModel
import java.text.DecimalFormat

@Composable
fun StockTerminalScreen(
    viewModel: RhinoMainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedSec by viewModel.selectedSecurity.collectAsState()
    val isBookmarked by viewModel.isSecurityBookmarked.collectAsState()
    val orderBook by viewModel.activeOrderBook.collectAsState()
    val terminalSubTab by viewModel.terminalSubTab.collectAsState()
    val selectedTimeframe by viewModel.selectedTimeframe.collectAsState()
    val activeChartType by viewModel.activeChartType.collectAsState()
    val enabledIndicators by viewModel.enabledIndicators.collectAsState()

    val security = selectedSec ?: return

    val isPositive = security.change >= 0
    val priceChangeColor = if (isPositive) MarketGreen else MarketRed
    val sign = if (isPositive) "+" else ""

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBackground)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Institutional Header
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("terminal_header_card"),
                colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Row 1: Ticker, Name, Exchange, Watchlist & Alert Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = security.ticker,
                                color = TextPrimary,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(RhinoCyan.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = security.exchange,
                                    color = RhinoCyan,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            if (security.isRestricted) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(MarketRed.copy(alpha = 0.2f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "RESTRICTED",
                                        color = MarketRed,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            // Quick Trade Button
                            Surface(
                                onClick = { viewModel.selectTab(MainNavigationTab.TRADE_DESK) },
                                shape = RoundedCornerShape(4.dp),
                                color = RhinoCyan,
                                modifier = Modifier.testTag("terminal_trade_btn")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ShoppingCart,
                                        contentDescription = "Trade",
                                        tint = RhinoBackground,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = "TRADE",
                                        color = RhinoBackground,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            // Watchlist Toggle
                            IconButton(
                                onClick = { viewModel.toggleWatchlist(security.ticker) },
                                modifier = Modifier.size(28.dp).testTag("terminal_watchlist_btn")
                            ) {
                                Icon(
                                    imageVector = if (isBookmarked) Icons.Default.Check else Icons.Default.Bookmark,
                                    contentDescription = "Watchlist",
                                    tint = if (isBookmarked) RhinoGold else TextTertiary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }

                            // Set Alert
                            IconButton(
                                onClick = { viewModel.openAlertModal(security.ticker) },
                                modifier = Modifier.size(28.dp).testTag("terminal_alert_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddAlert,
                                    contentDescription = "Set Alert",
                                    tint = RhinoCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Text(
                        text = "${security.name} • ${security.sector} • ${security.industry} • ${security.country}",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )

                    // Price & Real-Time Statistics
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = "$${DecimalFormat("#,##0.00").format(security.price)}",
                                color = TextPrimary,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "$sign$${DecimalFormat("#0.00").format(security.change)} ($sign${DecimalFormat("#0.00").format(security.changePercent)}%)",
                                    color = priceChangeColor,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "VOL: ${DecimalFormat("#,###").format(security.volume)}",
                                    color = TextTertiary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        // ISIN / CUSIP
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "ISIN: ${security.isin}",
                                color = TextTertiary,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "CUSIP: ${security.cusip}",
                                color = TextTertiary,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "ESG: ${security.esgScore}/100",
                                color = RhinoGold,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Sub-Navigation Tabs (CHART, DEPTH, FINANCIALS, DCF, EARNINGS, NEWS, PEERS)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(
                        "CHART" to "Technical Chart",
                        "DEPTH" to "Order Book L2",
                        "FINANCIALS" to "Financial Statements",
                        "DCF" to "DCF Valuation",
                        "EARNINGS" to "Earnings & Surprises",
                        "NEWS" to "News Wire",
                        "PEERS" to "Comps & Metrics"
                    ).forEach { pair ->
                        val isSelected = terminalSubTab == pair.first
                        Surface(
                            onClick = { viewModel.setTerminalSubTab(pair.first) },
                            shape = RoundedCornerShape(4.dp),
                            color = if (isSelected) RhinoCyan.copy(alpha = 0.2f) else RhinoSurfaceElevated,
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, RhinoCyan) else null,
                            modifier = Modifier.testTag("terminal_subtab_${pair.first}")
                        ) {
                            Text(
                                text = pair.second,
                                color = if (isSelected) RhinoCyan else TextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }
        }

        // Sub-Tab Content Views
        when (terminalSubTab) {
            "CHART" -> {
                item {
                    val candles = remember(security.ticker, selectedTimeframe) {
                        viewModel.getCandles(security.ticker, selectedTimeframe)
                    }
                    RhinoInteractiveChart(
                        ticker = security.ticker,
                        candles = candles,
                        selectedTimeframe = selectedTimeframe,
                        onTimeframeSelected = { viewModel.setTimeframe(it) },
                        activeChartType = activeChartType,
                        onChartTypeSelected = { viewModel.setChartType(it) },
                        enabledIndicators = enabledIndicators,
                        onToggleIndicator = { viewModel.toggleIndicator(it) }
                    )
                }
                item {
                    KeyStatisticsGrid(security = security)
                }
            }

            "DEPTH" -> {
                item {
                    if (orderBook != null) {
                        RhinoOrderBookLadder(orderBook = orderBook!!)
                    }
                }
            }

            "FINANCIALS" -> {
                item {
                    FinancialStatementsView(viewModel = viewModel, ticker = security.ticker)
                }
            }

            "DCF" -> {
                item {
                    TerminalDcfView(viewModel = viewModel, security = security)
                }
            }

            "EARNINGS" -> {
                item {
                    TerminalEarningsView(viewModel = viewModel, ticker = security.ticker)
                }
            }

            "NEWS" -> {
                item {
                    TerminalNewsView(viewModel = viewModel, ticker = security.ticker)
                }
            }

            "PEERS" -> {
                item {
                    TerminalPeersView(security = security)
                }
            }
        }
    }
}

@Composable
private fun KeyStatisticsGrid(security: Security) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "KEY VALUATION & QUANTITATIVE METRICS",
                color = RhinoCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )

            val stats = listOf(
                "Market Cap" to "$${DecimalFormat("#,##0.0").format(security.marketCap)}B",
                "Trailing P/E" to "${security.pe}x",
                "Forward P/E" to "${security.forwardPe}x",
                "PEG Ratio" to "${security.peg}x",
                "EPS (TTM)" to "$${security.eps}",
                "Div Yield" to "${security.dividendYield}%",
                "Beta (5Y)" to "${security.beta}",
                "ROIC" to "${security.roic}%",
                "ROE" to "${security.roe}%",
                "Debt / Equity" to "${security.debtToEquity}x",
                "EV / EBITDA" to "${security.evEbitda}x",
                "P / S" to "${security.priceToSales}x",
                "52-Wk Range" to "$${security.yearLow} - $${security.yearHigh}",
                "RSI (14D)" to "${DecimalFormat("#0.0").format(security.rsi)}"
            )

            for (i in stats.indices step 2) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(stats[i].first, color = TextTertiary, fontSize = 10.sp)
                        Text(stats[i].second, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    Spacer(Modifier.width(16.dp))
                    if (i + 1 < stats.size) {
                        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(stats[i + 1].first, color = TextTertiary, fontSize = 10.sp)
                            Text(stats[i + 1].second, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
                if (i < stats.size - 2) {
                    Divider(color = RhinoBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                }
            }
        }
    }
}

@Composable
private fun FinancialStatementsView(viewModel: RhinoMainViewModel, ticker: String) {
    val statements = remember(ticker) { viewModel.getFinancialStatements(ticker) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "INCOME STATEMENT & BALANCE SHEET SUMMARY ($ticker)",
                color = RhinoCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Header row
                Row(modifier = Modifier.background(RhinoSurfaceElevated).padding(vertical = 4.dp)) {
                    Text("LINE ITEM ($ BLN)", color = RhinoCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(130.dp))
                    statements.forEach { st ->
                        Text(st.period, color = RhinoCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(70.dp), fontFamily = FontFamily.Monospace)
                    }
                }

                // Data Rows
                val rows = listOf(
                    "Total Revenue" to statements.map { "$${DecimalFormat("#0.0").format(it.revenueBln)}" },
                    "Gross Profit" to statements.map { "$${DecimalFormat("#0.0").format(it.grossProfitBln)}" },
                    "EBITDA" to statements.map { "$${DecimalFormat("#0.0").format(it.ebitdaBln)}" },
                    "Operating Income (EBIT)" to statements.map { "$${DecimalFormat("#0.0").format(it.ebitBln)}" },
                    "Net Income" to statements.map { "$${DecimalFormat("#0.0").format(it.netIncomeBln)}" },
                    "Diluted EPS ($)" to statements.map { "$${DecimalFormat("#0.00").format(it.eps)}" },
                    "Free Cash Flow" to statements.map { "$${DecimalFormat("#0.0").format(it.freeCashFlowBln)}" },
                    "Cash & Equivalents" to statements.map { "$${DecimalFormat("#0.0").format(it.cashBln)}" },
                    "Total Debt" to statements.map { "$${DecimalFormat("#0.0").format(it.totalDebtBln)}" },
                    "Total Stockholders Equity" to statements.map { "$${DecimalFormat("#0.0").format(it.totalEquityBln)}" }
                )

                rows.forEach { (label, values) ->
                    Row(modifier = Modifier.padding(vertical = 3.dp)) {
                        Text(label, color = TextSecondary, fontSize = 9.sp, modifier = Modifier.width(130.dp))
                        values.forEach { v ->
                            Text(v, color = TextPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(70.dp), fontFamily = FontFamily.Monospace)
                        }
                    }
                    Divider(color = RhinoBorder.copy(alpha = 0.3f), thickness = 0.5.dp)
                }
            }
        }
    }
}

@Composable
private fun TerminalDcfView(viewModel: RhinoMainViewModel, security: Security) {
    val dcfResult = viewModel.getDcfResult(security.ticker)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("INTRINSIC DCF VALUATION BENCHMARK", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

            Surface(
                shape = RoundedCornerShape(6.dp),
                color = RhinoSurfaceElevated,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("FAIR VALUE PER SHARE", color = TextTertiary, fontSize = 9.sp)
                        Text(
                            "$${DecimalFormat("#,##0.00").format(dcfResult.fairValuePerShare)}",
                            color = if (dcfResult.fairValuePerShare >= security.price) MarketGreen else MarketRed,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("IMPLIED UPSIDE / DOWNSIDE", color = TextTertiary, fontSize = 9.sp)
                        Text(
                            "${if (dcfResult.upsideDownsidePct >= 0) "+" else ""}${DecimalFormat("#0.0").format(dcfResult.upsideDownsidePct)}%",
                            color = if (dcfResult.upsideDownsidePct >= 0) MarketGreen else MarketRed,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Button(
                onClick = { viewModel.selectTab(MainNavigationTab.QUANT_MODELS) },
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RhinoCyan.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("OPEN INTERACTIVE DCF WORKBENCH ➔", color = RhinoCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun TerminalEarningsView(viewModel: RhinoMainViewModel, ticker: String) {
    val earnings = remember(ticker) { viewModel.getEarnings(ticker) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("HISTORICAL EARNINGS & EPS SURPRISE HISTORY", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

            earnings.forEach { ev ->
                val surprise = ev.surprisePct ?: 0.0
                val isSurprisePositive = surprise >= 0
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = RhinoSurfaceElevated,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(ev.quarter, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Est: $${ev.epsEstimate}", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Act: $${ev.epsActual ?: "--"}", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text(
                                "Surprise: ${if (isSurprisePositive) "+" else ""}$surprise%",
                                color = if (isSurprisePositive) MarketGreen else MarketRed,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TerminalNewsView(viewModel: RhinoMainViewModel, ticker: String) {
    val news by viewModel.news.collectAsState()
    val tickerNews = news.filter { it.relatedTickers.contains(ticker) }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (tickerNews.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                shape = RoundedCornerShape(8.dp)
            ) {
                Box(modifier = Modifier.padding(16.dp), contentAlignment = Alignment.Center) {
                    Text("No direct breaking news for $ticker at this timestamp.", color = TextSecondary, fontSize = 11.sp)
                }
            }
        } else {
            tickerNews.forEach { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = RhinoSurface),
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
                ) {
                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(item.source, color = RhinoGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text(item.timestamp, color = TextTertiary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                        Text(item.headline, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(item.summary, color = TextSecondary, fontSize = 9.sp, lineHeight = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun TerminalPeersView(security: Security) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("SECTOR COMPARABLE MULTIPLES (${security.sector})", color = RhinoCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

            val peers = listOf(
                Triple("MSFT", "35.8x", "38.6%"),
                Triple("NVDA", "48.2x", "68.5%"),
                Triple("AAPL", "31.4x", "54.2%"),
                Triple("GOOGL", "22.1x", "30.1%"),
                Triple("AMZN", "39.1x", "18.2%")
            )

            peers.forEach { (peerTicker, pe, roic) ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(peerTicker, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text("P/E: $pe", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text("ROIC: $roic", color = RhinoCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                Divider(color = RhinoBorder.copy(alpha = 0.4f), thickness = 0.5.dp)
            }
        }
    }
}
