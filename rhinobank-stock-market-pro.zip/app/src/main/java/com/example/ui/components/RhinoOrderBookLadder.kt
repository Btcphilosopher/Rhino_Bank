package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderBook
import com.example.ui.theme.*
import java.text.DecimalFormat

@Composable
fun RhinoOrderBookLadder(
    orderBook: OrderBook?,
    onPriceSelected: ((Double) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoSurface),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "ORDER BOOK (LEVEL II)",
                        color = RhinoCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "[SIMULATED DEPTH]",
                        color = RhinoGold,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                if (orderBook != null) {
                    Text(
                        text = "SPREAD: $${DecimalFormat("#0.02").format(orderBook.spread)} (${orderBook.spreadBps} bps)",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // Column Titles
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceElevated)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("BID SIZE", color = TextTertiary, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("BID PRICE", color = TextTertiary, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("ASK PRICE", color = TextTertiary, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("ASK SIZE", color = TextTertiary, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            }

            Spacer(Modifier.height(4.dp))

            if (orderBook != null) {
                val maxRows = maxOf(orderBook.bids.size, orderBook.asks.size).coerceAtMost(6)
                for (i in 0 until maxRows) {
                    val bid = orderBook.bids.getOrNull(i)
                    val ask = orderBook.asks.getOrNull(i)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clickable {
                                if (ask != null) onPriceSelected?.invoke(ask.price)
                                else if (bid != null) onPriceSelected?.invoke(bid.price)
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Bid side
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(20.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (bid != null) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(bid.depthPercent.coerceIn(0.1f, 1f))
                                        .background(BidDepthColor.copy(alpha = 0.15f))
                                )
                                Text(
                                    text = DecimalFormat("#,##0").format(bid.size),
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(start = 6.dp)
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(20.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (bid != null) {
                                Text(
                                    text = DecimalFormat("#,##0.00").format(bid.price),
                                    color = MarketGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        // Ask side
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(20.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (ask != null) {
                                Text(
                                    text = DecimalFormat("#,##0.00").format(ask.price),
                                    color = MarketRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(20.dp),
                            contentAlignment = Alignment.CenterEnd
                        ) {
                            if (ask != null) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(ask.depthPercent.coerceIn(0.1f, 1f))
                                        .align(Alignment.CenterEnd)
                                        .background(AskDepthColor.copy(alpha = 0.15f))
                                )
                                Text(
                                    text = DecimalFormat("#,##0").format(ask.size),
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(end = 6.dp)
                                )
                            }
                        }
                    }
                }

                // Mid price line
                Divider(color = RhinoBorder, thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MID MARKET: $${DecimalFormat("#,##0.00").format(orderBook.midPrice)}",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                Text(
                    text = "Awaiting Level II market feed...",
                    color = TextTertiary,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        }
    }
}
