package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Account
import com.example.data.model.MarketDataMode
import com.example.data.model.UserRole
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.RhinoMainViewModel
import java.text.DecimalFormat

@Composable
fun RhinoTopBar(
    viewModel: RhinoMainViewModel,
    modifier: Modifier = Modifier
) {
    val activeRole by viewModel.activeRole.collectAsState()
    val activeAccount by viewModel.activeAccount.collectAsState()
    val accounts by viewModel.accounts.collectAsState()
    val dataMode by viewModel.dataMode.collectAsState()
    val isPaused by viewModel.isStreamingPaused.collectAsState()
    val tickCount by viewModel.tickCount.collectAsState()

    var showRoleMenu by remember { mutableStateOf(false) }
    var showAccountMenu by remember { mutableStateOf(false) }
    var showShockMenu by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(RhinoSurface)
    ) {
        // Status & Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand & System Identity
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(RhinoCyan.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🦏",
                        fontSize = 16.sp
                    )
                }

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "RHINOBANK",
                            color = RhinoCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "STOCK MARKET PRO",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (dataMode == MarketDataMode.SIMULATED) RhinoGold.copy(alpha = 0.2f) else MarketGreen.copy(alpha = 0.2f))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = dataMode.label,
                                color = if (dataMode == MarketDataMode.SIMULATED) RhinoGold else MarketGreen,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isPaused) RhinoGold else MarketGreen)
                        )
                        Text(
                            text = if (isPaused) "FEED PAUSED" else "LIVE PULSE #${tickCount}",
                            color = TextSecondary,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "• TLSv1.3 EAL6+",
                            color = TextTertiary,
                            fontSize = 9.sp
                        )
                    }
                }
            }

            // Quick Actions & Controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Search Trigger (Ctrl+K)
                IconButton(
                    onClick = { viewModel.openSearch() },
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(RhinoSurfaceElevated)
                        .testTag("global_search_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Universal Search",
                        tint = RhinoCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Shock Simulator
                Box {
                    IconButton(
                        onClick = { showShockMenu = true },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(RhinoSurfaceElevated)
                            .testTag("shock_menu_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ElectricBolt,
                            contentDescription = "Inject Market Shock",
                            tint = RhinoGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showShockMenu,
                        onDismissRequest = { showShockMenu = false },
                        modifier = Modifier.background(RhinoSurfaceElevated)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Shock: NVDA +5.0% (AI Surge)", color = MarketGreen, fontSize = 12.sp) },
                            onClick = {
                                viewModel.injectPriceShock("NVDA", 5.0)
                                showShockMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Shock: AAPL -8.0% (Supply Risk)", color = MarketRed, fontSize = 12.sp) },
                            onClick = {
                                viewModel.injectPriceShock("AAPL", -8.0)
                                showShockMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Shock: MSFT +4.2% (Cloud Beat)", color = MarketGreen, fontSize = 12.sp) },
                            onClick = {
                                viewModel.injectPriceShock("MSFT", 4.2)
                                showShockMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Shock: TSLA -12.0% (Volatility Flash)", color = MarketRed, fontSize = 12.sp) },
                            onClick = {
                                viewModel.injectPriceShock("TSLA", -12.0)
                                showShockMenu = false
                            }
                        )
                    }
                }

                // Stream Pause/Resume
                IconButton(
                    onClick = { viewModel.toggleStreamingPause() },
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(RhinoSurfaceElevated)
                        .testTag("stream_pause_toggle")
                ) {
                    Icon(
                        imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = "Pause Stream",
                        tint = if (isPaused) MarketGreen else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Account Selector Dropdown
                Box {
                    Surface(
                        onClick = { showAccountMenu = true },
                        shape = RoundedCornerShape(6.dp),
                        color = RhinoSurfaceElevated,
                        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoBorder),
                        modifier = Modifier.testTag("account_selector_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = activeAccount?.id ?: "ACC",
                                color = TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showAccountMenu,
                        onDismissRequest = { showAccountMenu = false },
                        modifier = Modifier.background(RhinoSurfaceElevated)
                    ) {
                        accounts.values.forEach { acc ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(text = acc.name, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = "${acc.id} • Cash: $${DecimalFormat("#,##0").format(acc.cash)}",
                                            color = TextSecondary,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                },
                                onClick = {
                                    viewModel.selectAccount(acc.id)
                                    showAccountMenu = false
                                }
                            )
                        }
                    }
                }

                // Role Switcher Dropdown
                Box {
                    Surface(
                        onClick = { showRoleMenu = true },
                        shape = RoundedCornerShape(6.dp),
                        color = RhinoCyan.copy(alpha = 0.12f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoCyan.copy(alpha = 0.3f)),
                        modifier = Modifier.testTag("role_selector_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = activeRole.badge,
                                color = RhinoCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = RhinoCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showRoleMenu,
                        onDismissRequest = { showRoleMenu = false },
                        modifier = Modifier.background(RhinoSurfaceElevated)
                    ) {
                        UserRole.values().forEach { role ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(3.dp))
                                                .background(RhinoCyan.copy(alpha = 0.2f))
                                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                        ) {
                                            Text(role.badge, color = RhinoCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Text(role.title, color = TextPrimary, fontSize = 11.sp)
                                    }
                                },
                                onClick = {
                                    viewModel.selectRole(role)
                                    showRoleMenu = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Persistent Workspace Navigation Bar (Horizontally scrollable dense tabs)
        val currentTab by viewModel.currentTab.collectAsState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(RhinoSurfaceElevated)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            MainNavigationTab.values().forEach { tab ->
                val isSelected = currentTab == tab
                Surface(
                    onClick = { viewModel.selectTab(tab) },
                    shape = RoundedCornerShape(5.dp),
                    color = if (isSelected) RhinoCyan.copy(alpha = 0.15f) else Color.Transparent,
                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, RhinoCyan) else null,
                    modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Text(
                            text = "[${tab.iconLabel}]",
                            color = if (isSelected) RhinoCyan else TextTertiary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = tab.title,
                            color = if (isSelected) TextPrimary else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }
        Divider(color = RhinoBorder, thickness = 1.dp)
    }
}
