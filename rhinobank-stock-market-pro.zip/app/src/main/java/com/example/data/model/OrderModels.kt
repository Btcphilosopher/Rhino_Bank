package com.example.data.model

enum class OrderSide { BUY, SELL }

enum class OrderType { MARKET, LIMIT, STOP, STOP_LIMIT, TRAILING_STOP }

enum class TimeInForce { DAY, GTC, IOC, FOK }

enum class OrderStatus { OPEN, FILLED, PARTIALLY_FILLED, CANCELLED, REJECTED, EXPIRED }

data class Order(
    val id: String,
    val timestamp: Long,
    val accountId: String,
    val symbol: String,
    val side: OrderSide,
    val type: OrderType,
    val quantity: Int,
    val price: Double?, // null for MARKET
    val stopPrice: Double? = null,
    val timeInForce: TimeInForce = TimeInForce.DAY,
    val filledQuantity: Int = 0,
    val avgFillPrice: Double? = null,
    val status: OrderStatus = OrderStatus.OPEN,
    val venue: String = "RHINO-DARK-POOL",
    val trader: String = "T. Sterling (ID: RS-8092)",
    val commission: Double = 15.00,
    val estimatedMarketImpactBps: Double = 1.8,
    val estimatedConsideration: Double = 0.0
)

data class RiskRuleCheck(
    val ruleName: String,
    val passed: Boolean,
    val details: String
)

data class PreTradeCheckResult(
    val passed: Boolean,
    val checks: List<RiskRuleCheck>,
    val riskStatus: String
)
