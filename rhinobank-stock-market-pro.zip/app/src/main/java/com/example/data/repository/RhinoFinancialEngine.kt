package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class RhinoFinancialEngine private constructor() {

    companion object {
        @Volatile
        private var instance: RhinoFinancialEngine? = null

        fun getInstance(): RhinoFinancialEngine {
            return instance ?: synchronized(this) {
                instance ?: RhinoFinancialEngine().also { instance = it }
            }
        }
    }

    private val engineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val dateTimeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    // Current State
    private val _dataMode = MutableStateFlow(MarketDataMode.SIMULATED)
    val dataMode: StateFlow<MarketDataMode> = _dataMode.asStateFlow()

    private val _isStreamingPaused = MutableStateFlow(false)
    val isStreamingPaused: StateFlow<Boolean> = _isStreamingPaused.asStateFlow()

    private val _tickCount = MutableStateFlow(0L)
    val tickCount: StateFlow<Long> = _tickCount.asStateFlow()

    private val _activeRole = MutableStateFlow(UserRole.PORTFOLIO_MANAGER)
    val activeRole: StateFlow<UserRole> = _activeRole.asStateFlow()

    private val _activeAccountId = MutableStateFlow("ACC-INST-001")
    val activeAccountId: StateFlow<String> = _activeAccountId.asStateFlow()

    private val _selectedSecurityTicker = MutableStateFlow("AAPL")
    val selectedSecurityTicker: StateFlow<String> = _selectedSecurityTicker.asStateFlow()

    // Data Collections
    private val _securities = MutableStateFlow<Map<String, Security>>(emptyMap())
    val securities: StateFlow<Map<String, Security>> = _securities.asStateFlow()

    private val _globalIndices = MutableStateFlow<List<GlobalIndex>>(emptyList())
    val globalIndices: StateFlow<List<GlobalIndex>> = _globalIndices.asStateFlow()

    private val _macroInstruments = MutableStateFlow<List<MacroInstrument>>(emptyList())
    val macroInstruments: StateFlow<List<MacroInstrument>> = _macroInstruments.asStateFlow()

    private val _accounts = MutableStateFlow<Map<String, Account>>(emptyMap())
    val accounts: StateFlow<Map<String, Account>> = _accounts.asStateFlow()

    private val _positions = MutableStateFlow<List<Position>>(emptyList())
    val positions: StateFlow<List<Position>> = _positions.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _orderBooks = MutableStateFlow<Map<String, OrderBook>>(emptyMap())
    val orderBooks: StateFlow<Map<String, OrderBook>> = _orderBooks.asStateFlow()

    private val _candleCache = mutableMapOf<String, List<Candle>>()

    private val _news = MutableStateFlow<List<NewsItem>>(emptyList())
    val news: StateFlow<List<NewsItem>> = _news.asStateFlow()

    private val _earnings = MutableStateFlow<List<EarningsEvent>>(emptyList())
    val earnings: StateFlow<List<EarningsEvent>> = _earnings.asStateFlow()

    private val _alerts = MutableStateFlow<List<PriceAlert>>(emptyList())
    val alerts: StateFlow<List<PriceAlert>> = _alerts.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AuditEvent>>(emptyList())
    val auditLogs: StateFlow<List<AuditEvent>> = _auditLogs.asStateFlow()

    private val _complianceRules = MutableStateFlow<List<ComplianceRule>>(emptyList())
    val complianceRules: StateFlow<List<ComplianceRule>> = _complianceRules.asStateFlow()

    private val _systemStatus = MutableStateFlow(
        mapOf(
            "MARKET DATA" to "ONLINE",
            "ORDER SYSTEM" to "ONLINE",
            "RISK ENGINE" to "ONLINE",
            "NEWS STREAM" to "ONLINE",
            "DATABASE" to "ONLINE",
            "SIMULATION" to "ACTIVE"
        )
    )
    val systemStatus: StateFlow<Map<String, String>> = _systemStatus.asStateFlow()

    init {
        initializeDatabase()
        startMarketSimulation()
    }

    private fun initializeDatabase() {
        // Initialize 100+ Enterprise Securities
        val initialSecurities = createInitialSecurities()
        _securities.value = initialSecurities.associateBy { it.ticker }

        // Initialize Global Indices
        _globalIndices.value = createInitialGlobalIndices()

        // Initialize Macro & Yields
        _macroInstruments.value = createInitialMacroInstruments()

        // Initialize Multi-Accounts
        _accounts.value = mapOf(
            "ACC-INST-001" to Account(
                id = "ACC-INST-001",
                name = "Institutional Alpha Fund (USD)",
                type = AccountType.INSTITUTIONAL,
                cash = 48500000.0,
                buyingPower = 194000000.0,
                marginUsed = 12000000.0,
                allocationEquities = 0.72,
                allocationBonds = 0.15,
                allocationFunds = 0.08,
                allocationAlternatives = 0.03,
                allocationCrypto = 0.02
            ),
            "ACC-HF-002" to Account(
                id = "ACC-HF-002",
                name = "Global Long/Short Equity Fund",
                type = AccountType.HEDGE_FUND,
                cash = 18200000.0,
                buyingPower = 72800000.0,
                marginUsed = 24000000.0,
                allocationEquities = 0.85,
                allocationBonds = 0.05,
                allocationFunds = 0.05,
                allocationAlternatives = 0.05,
                allocationCrypto = 0.00
            ),
            "ACC-PWM-003" to Account(
                id = "ACC-PWM-003",
                name = "Prime Wealth Segregated Mandate",
                type = AccountType.MANAGED_PORTFOLIO,
                cash = 6400000.0,
                buyingPower = 12800000.0,
                marginUsed = 0.0,
                allocationEquities = 0.55,
                allocationBonds = 0.30,
                allocationFunds = 0.10,
                allocationAlternatives = 0.05,
                allocationCrypto = 0.00
            ),
            "ACC-CORP-004" to Account(
                id = "ACC-CORP-004",
                name = "Rhino Corporate Treasury Reserves",
                type = AccountType.CORPORATE,
                cash = 32000000.0,
                buyingPower = 64000000.0,
                marginUsed = 0.0,
                allocationEquities = 0.20,
                allocationBonds = 0.70,
                allocationFunds = 0.05,
                allocationAlternatives = 0.05,
                allocationCrypto = 0.00
            ),
            "ACC-PART-005" to Account(
                id = "ACC-PART-005",
                name = "Principal Partner Account",
                type = AccountType.PERSONAL,
                cash = 2500000.0,
                buyingPower = 10000000.0,
                marginUsed = 1200000.0,
                allocationEquities = 0.80,
                allocationBonds = 0.10,
                allocationFunds = 0.05,
                allocationAlternatives = 0.03,
                allocationCrypto = 0.02
            )
        )

        // Initialize Positions for default account
        _positions.value = createInitialPositions("ACC-INST-001", initialSecurities)

        // Initialize Historical Orders
        _orders.value = createInitialOrders()

        // Generate Order Books
        initialSecurities.forEach { sec ->
            _orderBooks.value = _orderBooks.value + (sec.ticker to generateOrderBook(sec.ticker, sec.price))
        }

        // Initialize News Feed
        _news.value = createInitialNews()

        // Initialize Earnings
        _earnings.value = createInitialEarnings()

        // Initialize Compliance Rules
        _complianceRules.value = listOf(
            ComplianceRule("CR-001", "Max Single Position Weight Limit", "CONCENTRATION", "Position Weight <= 10.0%", 0),
            ComplianceRule("CR-002", "Restricted Instrument Trading Check", "SANCTION_LIST", "Symbol NOT IN RestrictedList", 0),
            ComplianceRule("CR-003", "Leverage & Margin Ceiling", "RISK_LIMIT", "Margin Utilization <= 50.0%", 0),
            ComplianceRule("CR-004", "Pre-Trade Minimum Liquidity", "LIQUIDITY", "Order Qty <= 5.0% ADV", 0),
            ComplianceRule("CR-005", "Restricted Jurisdiction Sanctions", "JURISDICTION", "Country NOT IN SanctionedZones", 0)
        )

        // Initialize Alerts
        _alerts.value = listOf(
            PriceAlert("AL-101", "NVDA", ">", 190.0, false, null, "Target high momentum breakout"),
            PriceAlert("AL-102", "AAPL", ">", 220.0, false, null, "Quarterly resistance check"),
            PriceAlert("AL-103", "MSFT", "<", 520.0, false, null, "Dip buying opportunity"),
            PriceAlert("AL-104", "TSLA", ">", 260.0, false, null, "Automated hedge rebalance")
        )

        // Initial Audit Logs
        addAuditEntry(
            user = "SYSTEM_KERNEL",
            account = "ALL",
            action = "PLATFORM_INITIALIZATION",
            instrument = "GLOBAL",
            oldVal = "OFFLINE",
            newVal = "ONLINE",
            reason = "Deterministic Market Engine Bootstrapped"
        )
    }

    private fun startMarketSimulation() {
        engineScope.launch {
            val random = Random()
            while (isActive) {
                if (!_isStreamingPaused.value) {
                    _tickCount.value += 1

                    // Update random subset of securities
                    val currentSecurities = _securities.value.toMutableMap()
                    val updatedKeys = currentSecurities.keys.shuffled().take(6)

                    for (ticker in updatedKeys) {
                        val sec = currentSecurities[ticker] ?: continue
                        val drift = (random.nextGaussian() * 0.002) // subtle realistic volatility
                        val newPrice = ((sec.price * (1.0 + drift)) * 100.0).roundToInt() / 100.0
                        val newChange = ((newPrice - (sec.price - sec.change)) * 100.0).roundToInt() / 100.0
                        val newPct = ((newChange / (newPrice - newChange)) * 10000.0).roundToInt() / 100.0

                        val updated = sec.copy(
                            price = max(0.5, newPrice),
                            change = newChange,
                            changePercent = newPct,
                            dayLow = min(sec.dayLow, newPrice),
                            dayHigh = max(sec.dayHigh, newPrice),
                            volume = sec.volume + (random.nextInt(500) + 50)
                        )
                        currentSecurities[ticker] = updated

                        // Update its order book
                        val currentBooks = _orderBooks.value.toMutableMap()
                        currentBooks[ticker] = generateOrderBook(ticker, updated.price)
                        _orderBooks.value = currentBooks

                        // Check price alerts for this ticker
                        checkAlertsForTicker(updated.ticker, updated.price)
                    }

                    _securities.value = currentSecurities

                    // Update Global Indices slightly
                    _globalIndices.value = _globalIndices.value.map { idx ->
                        val indexDrift = (random.nextGaussian() * 0.001)
                        val newVal = ((idx.value * (1.0 + indexDrift)) * 100.0).roundToInt() / 100.0
                        val newChg = ((idx.change + (random.nextGaussian() * 1.5)) * 100.0).roundToInt() / 100.0
                        idx.copy(value = newVal, change = newChg)
                    }

                    // Recalculate Positions & P&L
                    recalculatePositionsAndPnL()

                    // Check Open Limit Orders for Simulated Execution
                    checkAndExecuteLimitOrders()
                }

                delay(1600L) // Micro-pulse rate
            }
        }
    }

    private fun recalculatePositionsAndPnL() {
        val currentAccId = _activeAccountId.value
        val secMap = _securities.value
        val currentPositions = _positions.value.filter { it.accountId == currentAccId }

        val totalPortfolioMarketValue = currentPositions.sumOf { pos ->
            val curPrice = secMap[pos.symbol]?.price ?: pos.currentPrice
            pos.quantity * curPrice
        }

        val updatedPositions = currentPositions.map { pos ->
            val curPrice = secMap[pos.symbol]?.price ?: pos.currentPrice
            val marketVal = pos.quantity * curPrice
            val totalCost = pos.quantity * pos.averageCost
            val unrealized = marketVal - totalCost
            val unrealizedPct = if (totalCost > 0) (unrealized / totalCost) * 100.0 else 0.0
            val weight = if (totalPortfolioMarketValue > 0) (marketVal / totalPortfolioMarketValue) * 100.0 else 0.0
            val contribution = (weight * unrealizedPct) / 100.0

            pos.copy(
                currentPrice = curPrice,
                marketValue = marketVal,
                unrealizedPnL = unrealized,
                unrealizedPnLPercent = ((unrealizedPct * 100).roundToInt() / 100.0),
                portfolioWeight = ((weight * 100).roundToInt() / 100.0),
                contributionPercent = ((contribution * 100).roundToInt() / 100.0)
            )
        }

        _positions.value = updatedPositions
    }

    private fun checkAlertsForTicker(symbol: String, price: Double) {
        val currentAlerts = _alerts.value.toMutableList()
        var changed = false

        for (i in currentAlerts.indices) {
            val alert = currentAlerts[i]
            if (alert.symbol == symbol && !alert.isTriggered) {
                val shouldTrigger = when (alert.condition) {
                    ">" -> price >= alert.targetPrice
                    "<" -> price <= alert.targetPrice
                    else -> false
                }
                if (shouldTrigger) {
                    currentAlerts[i] = alert.copy(
                        isTriggered = true,
                        triggeredTime = timeFormat.format(Date())
                    )
                    changed = true

                    addAuditEntry(
                        user = "SURVEILLANCE_ENGINE",
                        account = _activeAccountId.value,
                        action = "PRICE_ALERT_TRIGGERED",
                        instrument = symbol,
                        oldVal = "ARMED",
                        newVal = "TRIGGERED ($$price)",
                        reason = "Threshold ${alert.condition} ${alert.targetPrice} breached"
                    )
                }
            }
        }

        if (changed) {
            _alerts.value = currentAlerts
        }
    }

    private fun checkAndExecuteLimitOrders() {
        val currentOrders = _orders.value.toMutableList()
        val secMap = _securities.value
        var updated = false

        for (i in currentOrders.indices) {
            val order = currentOrders[i]
            if (order.status == OrderStatus.OPEN) {
                val currentPrice = secMap[order.symbol]?.price ?: continue

                val isExecutable = when (order.type) {
                    OrderType.MARKET -> true
                    OrderType.LIMIT -> {
                        if (order.side == OrderSide.BUY) currentPrice <= (order.price ?: 0.0)
                        else currentPrice >= (order.price ?: Double.MAX_VALUE)
                    }
                    OrderType.STOP -> {
                        if (order.side == OrderSide.BUY) currentPrice >= (order.stopPrice ?: Double.MAX_VALUE)
                        else currentPrice <= (order.stopPrice ?: 0.0)
                    }
                    OrderType.STOP_LIMIT -> {
                        if (order.side == OrderSide.BUY) currentPrice <= (order.price ?: 0.0)
                        else currentPrice >= (order.price ?: 0.0)
                    }
                    OrderType.TRAILING_STOP -> true
                }

                if (isExecutable) {
                    val fillPrice = order.price ?: currentPrice
                    val updatedOrder = order.copy(
                        status = OrderStatus.FILLED,
                        filledQuantity = order.quantity,
                        avgFillPrice = fillPrice
                    )
                    currentOrders[i] = updatedOrder
                    updated = true

                    // Apply position change
                    executePositionUpdate(updatedOrder)

                    addAuditEntry(
                        user = order.trader,
                        account = order.accountId,
                        action = "ORDER_EXECUTED",
                        instrument = order.symbol,
                        oldVal = "OPEN (${order.quantity} @ ${order.price})",
                        newVal = "FILLED (${order.quantity} @ $$fillPrice)",
                        reason = "Limit price matched on ${order.venue}"
                    )
                }
            }
        }

        if (updated) {
            _orders.value = currentOrders
        }
    }

    private fun executePositionUpdate(order: Order) {
        val currentPositions = _positions.value.toMutableList()
        val existingIndex = currentPositions.indexOfFirst { it.accountId == order.accountId && it.symbol == order.symbol }
        val fillPrice = order.avgFillPrice ?: (order.price ?: 100.0)

        if (order.side == OrderSide.BUY) {
            if (existingIndex >= 0) {
                val existing = currentPositions[existingIndex]
                val newQty = existing.quantity + order.quantity
                val newAvgCost = ((existing.quantity * existing.averageCost) + (order.quantity * fillPrice)) / newQty
                currentPositions[existingIndex] = existing.copy(
                    quantity = newQty,
                    averageCost = ((newAvgCost * 100).roundToInt() / 100.0),
                    marketValue = newQty * fillPrice
                )
            } else {
                val sec = _securities.value[order.symbol]
                currentPositions.add(
                    Position(
                        id = "POS-${System.currentTimeMillis() % 10000}",
                        accountId = order.accountId,
                        symbol = order.symbol,
                        companyName = sec?.name ?: order.symbol,
                        quantity = order.quantity,
                        averageCost = fillPrice,
                        currentPrice = fillPrice,
                        marketValue = order.quantity * fillPrice,
                        unrealizedPnL = 0.0,
                        unrealizedPnLPercent = 0.0,
                        realizedPnL = 0.0,
                        portfolioWeight = 5.0,
                        sectorWeight = 5.0,
                        countryExposure = sec?.country ?: "United States",
                        contributionPercent = 0.0
                    )
                )
            }
        } else {
            if (existingIndex >= 0) {
                val existing = currentPositions[existingIndex]
                val remainingQty = max(0, existing.quantity - order.quantity)
                val realizedGain = (fillPrice - existing.averageCost) * min(existing.quantity, order.quantity)
                if (remainingQty == 0) {
                    currentPositions.removeAt(existingIndex)
                } else {
                    currentPositions[existingIndex] = existing.copy(
                        quantity = remainingQty,
                        realizedPnL = existing.realizedPnL + realizedGain,
                        marketValue = remainingQty * fillPrice
                    )
                }
            }
        }
        _positions.value = currentPositions
        recalculatePositionsAndPnL()
    }

    // Public Operations

    fun setSecurity(ticker: String) {
        _selectedSecurityTicker.value = ticker
    }

    fun setActiveAccount(accountId: String) {
        _activeAccountId.value = accountId
        recalculatePositionsAndPnL()
    }

    fun setUserRole(role: UserRole) {
        val oldRole = _activeRole.value
        _activeRole.value = role
        addAuditEntry(
            user = "RBAC_SECURITY",
            account = _activeAccountId.value,
            action = "ROLE_CHANGED",
            instrument = "SYSTEM",
            oldVal = oldRole.name,
            newVal = role.name,
            reason = "Role switched via Enterprise Access Control Panel"
        )
    }

    fun setMarketDataMode(mode: MarketDataMode) {
        _dataMode.value = mode
    }

    fun toggleStreamingPause() {
        _isStreamingPaused.value = !_isStreamingPaused.value
    }

    // Shock / Price Injection for Live Interactive Demos
    fun injectPriceShock(ticker: String, percentage: Double) {
        val currentSec = _securities.value[ticker] ?: return
        val newPrice = max(1.0, currentSec.price * (1.0 + (percentage / 100.0)))
        val roundedPrice = ((newPrice * 100).roundToInt() / 100.0)
        val newChange = ((roundedPrice - (currentSec.price - currentSec.change)) * 100.0).roundToInt() / 100.0
        val newPct = ((newChange / (roundedPrice - newChange)) * 10000.0).roundToInt() / 100.0

        val updated = currentSec.copy(
            price = roundedPrice,
            change = newChange,
            changePercent = newPct,
            dayHigh = max(currentSec.dayHigh, roundedPrice),
            dayLow = min(currentSec.dayLow, roundedPrice)
        )

        val map = _securities.value.toMutableMap()
        map[ticker] = updated
        _securities.value = map

        val currentBooks = _orderBooks.value.toMutableMap()
        currentBooks[ticker] = generateOrderBook(ticker, roundedPrice)
        _orderBooks.value = currentBooks

        recalculatePositionsAndPnL()
        checkAlertsForTicker(ticker, roundedPrice)
        checkAndExecuteLimitOrders()

        addAuditEntry(
            user = _activeRole.value.title,
            account = _activeAccountId.value,
            action = "SIMULATED_PRICE_SHOCK_INJECTED",
            instrument = ticker,
            oldVal = "$${currentSec.price}",
            newVal = "$$roundedPrice (${if (percentage >= 0) "+" else ""}$percentage%)",
            reason = "Manual Institutional Market Stress Test Injection"
        )
    }

    // Pre-Trade Risk Verification Check
    fun validatePreTrade(
        symbol: String,
        side: OrderSide,
        type: OrderType,
        quantity: Int,
        price: Double?
    ): PreTradeCheckResult {
        val sec = _securities.value[symbol]
        val account = _accounts.value[_activeAccountId.value]
        val currentPrice = price ?: (sec?.price ?: 100.0)
        val orderValue = quantity * currentPrice

        val checks = mutableListOf<RiskRuleCheck>()

        // 1. Restricted Security Check
        val isRestricted = sec?.isRestricted == true
        checks.add(
            RiskRuleCheck(
                ruleName = "Restricted List Compliance",
                passed = !isRestricted,
                details = if (isRestricted) "SECURITY IS ON INSTITUTIONAL RESTRICTED LIST" else "Clear to Trade"
            )
        )

        // 2. Buying Power Check
        val hasBuyingPower = if (side == OrderSide.BUY) {
            orderValue <= (account?.buyingPower ?: 0.0)
        } else true
        checks.add(
            RiskRuleCheck(
                ruleName = "Available Buying Power Check",
                passed = hasBuyingPower,
                details = "Order Value: $$${formatCurrency(orderValue)} | Avail: $$${formatCurrency(account?.buyingPower ?: 0.0)}"
            )
        )

        // 3. Concentration Limit Check (>10% portfolio)
        val totalPortfolio = _positions.value.filter { it.accountId == _activeAccountId.value }.sumOf { it.marketValue }
        val prospectiveWeight = if (totalPortfolio > 0) ((orderValue) / (totalPortfolio + orderValue)) * 100.0 else 0.0
        val isUnderConcentrationLimit = prospectiveWeight <= 15.0 // 15% ceiling
        checks.add(
            RiskRuleCheck(
                ruleName = "Portfolio Concentration Rule (<=15%)",
                passed = isUnderConcentrationLimit,
                details = "Estimated New Weight: ${DecimalFormat("#.##").format(prospectiveWeight)}%"
            )
        )

        // 4. Role Authorization Check
        val canTrade = _activeRole.value in listOf(UserRole.TRADER, UserRole.PORTFOLIO_MANAGER, UserRole.ADMINISTRATOR)
        checks.add(
            RiskRuleCheck(
                ruleName = "Role Execution Entitlement",
                passed = canTrade,
                details = if (canTrade) "Entitled: ${_activeRole.value.name}" else "Role '${_activeRole.value.name}' lacks execution privilege"
            )
        )

        val allPassed = checks.all { it.passed }
        return PreTradeCheckResult(
            passed = allPassed,
            checks = checks,
            riskStatus = if (allPassed) "PASSED" else "REJECTED_BY_COMPLIANCE"
        )
    }

    // Submit Order to OMS
    fun submitOrder(
        symbol: String,
        side: OrderSide,
        type: OrderType,
        quantity: Int,
        price: Double?,
        stopPrice: Double? = null,
        timeInForce: TimeInForce = TimeInForce.DAY
    ): Order {
        val sec = _securities.value[symbol]
        val currentPrice = price ?: (sec?.price ?: 100.0)
        val consideration = quantity * currentPrice
        val orderId = "ORD-${UUID.randomUUID().toString().take(8).uppercase()}"

        val newOrder = Order(
            id = orderId,
            timestamp = System.currentTimeMillis(),
            accountId = _activeAccountId.value,
            symbol = symbol,
            side = side,
            type = type,
            quantity = quantity,
            price = price,
            stopPrice = stopPrice,
            timeInForce = timeInForce,
            filledQuantity = if (type == OrderType.MARKET) quantity else 0,
            avgFillPrice = if (type == OrderType.MARKET) currentPrice else null,
            status = if (type == OrderType.MARKET) OrderStatus.FILLED else OrderStatus.OPEN,
            venue = "RHINO-DARK-POOL",
            trader = "Trader (${_activeRole.value.badge})",
            commission = 15.0,
            estimatedMarketImpactBps = ((quantity.toDouble() / (sec?.volume ?: 1000000L)) * 100.0).coerceIn(0.2, 8.5),
            estimatedConsideration = consideration
        )

        _orders.value = listOf(newOrder) + _orders.value

        if (newOrder.status == OrderStatus.FILLED) {
            executePositionUpdate(newOrder)
        }

        addAuditEntry(
            user = _activeRole.value.title,
            account = _activeAccountId.value,
            action = "ORDER_SUBMISSION",
            instrument = symbol,
            oldVal = "N/A",
            newVal = "${side.name} $quantity $symbol @ ${if (price != null) "$$price" else "MKT"} (${newOrder.status})",
            reason = "Pre-trade risk checks passed. Routed to ${newOrder.venue}"
        )

        return newOrder
    }

    fun cancelOrder(orderId: String) {
        val currentOrders = _orders.value.toMutableList()
        val index = currentOrders.indexOfFirst { it.id == orderId }
        if (index >= 0 && currentOrders[index].status == OrderStatus.OPEN) {
            val oldOrder = currentOrders[index]
            val cancelled = oldOrder.copy(status = OrderStatus.CANCELLED)
            currentOrders[index] = cancelled
            _orders.value = currentOrders

            addAuditEntry(
                user = _activeRole.value.title,
                account = oldOrder.accountId,
                action = "ORDER_CANCELLED",
                instrument = oldOrder.symbol,
                oldVal = "OPEN",
                newVal = "CANCELLED",
                reason = "User initiated cancellation via OMS interface"
            )
        }
    }

    fun createPriceAlert(symbol: String, condition: String, targetPrice: Double, note: String) {
        val alert = PriceAlert(
            id = "AL-${UUID.randomUUID().toString().take(6).uppercase()}",
            symbol = symbol,
            condition = condition,
            targetPrice = targetPrice,
            isTriggered = false,
            triggeredTime = null,
            note = note
        )
        _alerts.value = listOf(alert) + _alerts.value

        addAuditEntry(
            user = _activeRole.value.title,
            account = _activeAccountId.value,
            action = "ALERT_CREATED",
            instrument = symbol,
            oldVal = "NONE",
            newVal = "$condition $$targetPrice",
            reason = "Automated surveillance threshold arming"
        )
    }

    fun deleteAlert(id: String) {
        _alerts.value = _alerts.value.filterNot { it.id == id }
    }

    private fun addAuditEntry(
        user: String,
        account: String,
        action: String,
        instrument: String,
        oldVal: String,
        newVal: String,
        reason: String,
        approval: String = "APPROVED"
    ) {
        val timestamp = dateTimeFormat.format(Date())
        val hash = "0x" + UUID.randomUUID().toString().replace("-", "").take(16).uppercase()

        val event = AuditEvent(
            id = "AUD-${System.currentTimeMillis() % 100000}",
            timestamp = timestamp,
            user = user,
            account = account,
            action = action,
            instrument = instrument,
            oldValue = oldVal,
            newValue = newVal,
            ipSession = "10.244.18.91 (TLSv1.3/EAL6+)",
            reason = reason,
            approvalStatus = approval,
            tamperProofHash = hash
        )
        _auditLogs.value = listOf(event) + _auditLogs.value.take(200)
    }

    // DCF Calculation Engine
    fun computeDcf(ticker: String, assumptions: DcfAssumptions): DcfResult {
        val sec = _securities.value[ticker]
        val currentRevenue = (sec?.fcf ?: 10.0) * 4.0 // base approximation
        var projRev = currentRevenue
        val fcfList = mutableListOf<Double>()
        var pvFcf = 0.0

        for (i in 1..5) {
            projRev *= (1.0 + (assumptions.revenueGrowthPct / 100.0))
            val ebitda = projRev * (assumptions.ebitdaMarginPct / 100.0)
            val ebit = ebitda * 0.85
            val nopat = ebit * (1.0 - (assumptions.taxRatePct / 100.0))
            val capex = projRev * (assumptions.capexPctOfRev / 100.0)
            val nwc = projRev * (assumptions.workingCapitalPctOfRev / 100.0)
            val fcf = nopat - capex - nwc
            fcfList.add(fcf)

            val discountFactor = (1.0 + (assumptions.waccPct / 100.0)).pow(i)
            pvFcf += (fcf / discountFactor)
        }

        val terminalFcf = fcfList.last() * (1.0 + (assumptions.terminalGrowthPct / 100.0))
        val terminalValue = terminalFcf / max(0.005, ((assumptions.waccPct - assumptions.terminalGrowthPct) / 100.0))
        val pvTerminalValue = terminalValue / (1.0 + (assumptions.waccPct / 100.0)).pow(5)

        val enterpriseVal = pvFcf + pvTerminalValue
        val equityVal = enterpriseVal - assumptions.netDebtBln
        val fairValuePerShare = max(1.0, (equityVal * 1000.0) / (assumptions.sharesOutstandingBln * 1000.0))
        val currentPrice = sec?.price ?: 100.0
        val upside = ((fairValuePerShare - currentPrice) / currentPrice) * 100.0

        return DcfResult(
            enterpriseValueBln = ((enterpriseVal * 10).roundToInt() / 10.0),
            equityValueBln = ((equityVal * 10).roundToInt() / 10.0),
            fairValuePerShare = ((fairValuePerShare * 100).roundToInt() / 100.0),
            upsideDownsidePct = ((upside * 10).roundToInt() / 10.0),
            projectedFcfList = fcfList.map { ((it * 10).roundToInt() / 10.0) },
            terminalValueBln = ((terminalValue * 10).roundToInt() / 10.0),
            pvOfFcfBln = ((pvFcf * 10).roundToInt() / 10.0)
        )
    }

    // Historical Candle Generator (1m, 5m, 1h, 1D, 1Y)
    fun getCandlesForTicker(ticker: String, timeframe: String): List<Candle> {
        val key = "$ticker-$timeframe"
        if (_candleCache.containsKey(key)) {
            return _candleCache[key]!!
        }

        val sec = _securities.value[ticker]
        val basePrice = sec?.price ?: 200.0
        val count = when (timeframe) {
            "1m", "5m" -> 35
            "15m", "30m", "1h", "4h" -> 40
            "1D" -> 60
            "1W", "1M" -> 52
            "1Y", "5Y", "MAX" -> 70
            else -> 40
        }

        val candles = mutableListOf<Candle>()
        var current = basePrice * 0.85
        val random = Random(ticker.hashCode().toLong() + timeframe.hashCode().toLong())
        val now = System.currentTimeMillis()
        val intervalMs = when (timeframe) {
            "1m" -> 60_000L
            "5m" -> 300_000L
            "1h" -> 3600_000L
            "1D" -> 86400_000L
            else -> 604800_000L
        }

        for (i in count downTo 0) {
            val change = (random.nextGaussian() * (basePrice * 0.015))
            val open = current
            val close = max(1.0, open + change)
            val high = max(open, close) + (abs(random.nextGaussian()) * (basePrice * 0.008))
            val low = max(0.5, min(open, close) - (abs(random.nextGaussian()) * (basePrice * 0.008)))
            val volume = (random.nextInt(80000) + 12000).toLong()

            candles.add(
                Candle(
                    timestamp = now - (i * intervalMs),
                    open = ((open * 100).roundToInt() / 100.0),
                    high = ((high * 100).roundToInt() / 100.0),
                    low = ((low * 100).roundToInt() / 100.0),
                    close = ((close * 100).roundToInt() / 100.0),
                    volume = volume
                )
            )
            current = close
        }

        _candleCache[key] = candles
        return candles
    }

    private fun generateOrderBook(ticker: String, midPrice: Double): OrderBook {
        val random = Random(ticker.hashCode().toLong() + (_tickCount.value / 2))
        val bids = mutableListOf<OrderBookLevel>()
        val asks = mutableListOf<OrderBookLevel>()

        val spread = 0.02
        var bidRunningTotal = 0
        for (i in 0..7) {
            val levelPrice = ((midPrice - (spread / 2) - (i * 0.01)) * 100.0).roundToInt() / 100.0
            val size = (random.nextInt(60) + 12) * 100
            bidRunningTotal += size
            bids.add(OrderBookLevel(levelPrice, size, bidRunningTotal, (i + 1) * 0.12f))
        }

        var askRunningTotal = 0
        for (i in 0..7) {
            val levelPrice = ((midPrice + (spread / 2) + (i * 0.01)) * 100.0).roundToInt() / 100.0
            val size = (random.nextInt(60) + 12) * 100
            askRunningTotal += size
            asks.add(OrderBookLevel(levelPrice, size, askRunningTotal, (i + 1) * 0.12f))
        }

        return OrderBook(
            symbol = ticker,
            bids = bids,
            asks = asks,
            spread = spread,
            spreadBps = ((spread / midPrice) * 10000.0 * 10.0).roundToInt() / 10.0,
            midPrice = midPrice
        )
    }

    // Mock initial database seed generators
    private fun createInitialSecurities(): List<Security> {
        return listOf(
            Security("AAPL", "Apple Inc.", "US0378331005", "037833100", "NASDAQ", "Technology", "Consumer Electronics", "United States", 214.52, 3.01, 1.42, 211.80, 215.90, 168.49, 237.23, 54230000, 48000000, 3240.0, 31.4, 27.2, 2.1, 6.83, 0.48, 1.05, 54.2, 148.0, 108.5, 1.45, 23.4, 7.8, 8.2, 58.4, false, 86, 12.4),
            Security("MSFT", "Microsoft Corporation", "US5949181045", "594918104", "NASDAQ", "Technology", "Software Infrastructure", "United States", 531.20, -1.65, -0.31, 528.10, 534.50, 395.00, 555.00, 22100000, 21000000, 3940.0, 35.8, 30.1, 2.3, 14.80, 0.62, 0.92, 32.4, 38.6, 74.1, 0.42, 25.1, 12.2, 14.1, 52.1, false, 91, 8.1),
            Security("NVDA", "NVIDIA Corporation", "US67066G1040", "67066G104", "NASDAQ", "Technology", "Semiconductors", "United States", 182.74, 5.05, 2.84, 177.20, 184.10, 85.00, 195.00, 84300000, 72000000, 4480.0, 48.2, 34.5, 1.4, 3.79, 0.03, 1.68, 68.5, 115.0, 56.8, 0.18, 38.2, 18.4, 28.5, 66.8, false, 84, 16.8),
            Security("AMZN", "Amazon.com, Inc.", "US0231351067", "023135106", "NASDAQ", "Consumer Cyclical", "Internet Retail", "United States", 241.16, 1.77, 0.74, 238.50, 243.20, 165.00, 245.50, 38900000, 42000000, 2520.0, 39.1, 31.0, 1.8, 6.16, 0.00, 1.15, 18.2, 22.4, 48.3, 0.58, 17.5, 3.8, 4.1, 61.2, false, 79, 24.5),
            Security("META", "Meta Platforms, Inc.", "US30303M1027", "30303M102", "NASDAQ", "Communication Services", "Internet Content", "United States", 721.10, -1.30, -0.18, 715.00, 728.40, 450.00, 740.00, 14200000, 16500000, 1830.0, 26.4, 22.8, 1.2, 27.30, 0.28, 1.22, 28.4, 34.1, 44.5, 0.24, 16.2, 8.4, 11.2, 54.7, false, 74, 11.3),
            Security("GOOGL", "Alphabet Inc.", "US02079K3059", "02079K305", "NASDAQ", "Communication Services", "Internet Content", "United States", 192.40, 2.10, 1.10, 189.80, 193.50, 142.00, 201.00, 28500000, 26000000, 2380.0, 22.1, 19.5, 1.1, 8.70, 0.42, 1.08, 30.1, 31.2, 69.4, 0.11, 14.8, 6.2, 7.1, 57.3, false, 88, 9.5),
            Security("TSLA", "Tesla, Inc.", "US88160R1014", "88160R101", "NASDAQ", "Consumer Cyclical", "Auto Manufacturers", "United States", 258.80, -4.20, -1.60, 255.10, 266.00, 138.00, 271.00, 68900000, 75000000, 825.0, 78.4, 58.2, 3.8, 3.30, 0.00, 2.10, 12.5, 18.1, 7.8, 0.12, 48.0, 9.4, 8.2, 49.2, false, 68, 18.0),
            Security("JPM", "JPMorgan Chase & Co.", "US46625H1005", "46625H100", "NYSE", "Financial Services", "Diversified Banking", "United States", 238.90, 1.85, 0.78, 236.40, 240.20, 180.00, 245.00, 11200000, 10500000, 685.0, 12.8, 11.9, 1.3, 18.60, 2.10, 1.05, 16.4, 18.2, 42.0, 1.85, 9.2, 1.8, 3.9, 59.1, false, 82, 32.1),
            Security("BRK.B", "Berkshire Hathaway Inc.", "US0846707026", "084670702", "NYSE", "Financial Services", "Multi-Sector Holdings", "United States", 472.10, 0.80, 0.17, 469.50, 474.00, 390.00, 485.00, 3100000, 3400000, 1025.0, 19.4, 18.2, 1.6, 24.30, 0.00, 0.88, 11.2, 14.5, 32.1, 0.38, 14.1, 1.6, 2.8, 51.4, false, 75, 45.0),
            Security("LLY", "Eli Lilly and Company", "US5324571083", "532457108", "NYSE", "Healthcare", "Drug Manufacturers", "United States", 945.60, 12.40, 1.33, 930.00, 952.00, 550.00, 970.00, 2800000, 3200000, 898.0, 68.2, 42.1, 1.9, 13.86, 0.55, 0.75, 24.8, 48.2, 12.4, 1.65, 38.5, 19.4, 21.0, 63.8, false, 89, 7.8),
            Security("AVGO", "Broadcom Inc.", "US11135F1012", "11135F101", "NASDAQ", "Technology", "Semiconductors", "United States", 178.40, 4.20, 2.41, 173.50, 179.90, 118.00, 185.00, 24100000, 22000000, 835.0, 38.2, 26.5, 1.5, 4.67, 1.30, 1.25, 22.1, 28.4, 21.5, 1.20, 21.4, 12.1, 16.4, 62.1, false, 80, 14.2),
            Security("XOM", "Exxon Mobil Corporation", "US30231G1022", "30231G102", "NYSE", "Energy", "Oil & Gas Integrated", "United States", 118.90, -0.65, -0.54, 117.80, 120.10, 98.00, 126.00, 16200000, 18000000, 472.0, 13.5, 12.8, 1.4, 8.80, 3.20, 0.95, 14.2, 17.5, 34.2, 0.18, 6.8, 2.1, 1.2, 48.6, false, 62, 88.4),
            Security("ASML", "ASML Holding N.V.", "NL0010273215", "001027321", "NASDAQ", "Technology", "Semiconductor Equipment", "Netherlands", 892.30, 8.50, 0.96, 880.00, 898.00, 620.00, 1080.00, 1800000, 2100000, 352.0, 41.2, 31.8, 1.7, 21.60, 0.85, 1.35, 38.4, 49.2, 7.8, 0.45, 28.5, 10.4, 12.8, 56.4, false, 93, 6.2),
            Security("SAP", "SAP SE", "DE0007164600", "716460000", "NYSE", "Technology", "Enterprise Software", "Germany", 242.10, 1.90, 0.79, 239.50, 244.00, 160.00, 252.00, 1200000, 1400000, 285.0, 34.2, 28.4, 1.9, 7.08, 1.05, 0.98, 18.5, 22.1, 8.4, 0.22, 19.8, 5.2, 7.4, 58.2, false, 92, 5.4),
            Security("AZN", "AstraZeneca PLC", "GB0009895292", "098952920", "NASDAQ", "Healthcare", "Pharmaceuticals", "United Kingdom", 81.20, 0.40, 0.50, 80.50, 81.90, 62.00, 88.00, 3800000, 4200000, 251.0, 28.4, 18.2, 1.4, 2.86, 2.45, 0.65, 16.8, 22.4, 9.2, 1.15, 14.5, 4.2, 4.8, 53.2, false, 87, 8.9),
            Security("SHEL", "Shell plc", "GB00BP6MXD84", "BP6MXD840", "NYSE", "Energy", "Oil & Gas Integrated", "United Kingdom", 74.80, -0.30, -0.40, 74.10, 75.50, 60.00, 78.00, 4100000, 4500000, 235.0, 11.8, 10.4, 1.2, 6.34, 3.80, 0.85, 12.8, 15.6, 22.5, 0.35, 5.4, 1.4, 0.8, 49.8, false, 64, 76.5),
            Security("GS", "The Goldman Sachs Group", "US38141G1040", "38141G104", "NYSE", "Financial Services", "Capital Markets & IB", "United States", 512.30, 4.10, 0.81, 506.00, 515.00, 360.00, 528.00, 2100000, 2400000, 165.0, 15.2, 13.8, 1.3, 33.70, 2.35, 1.32, 14.2, 15.8, 18.2, 2.10, 10.8, 1.5, 3.4, 60.4, false, 81, 28.4),
            Security("MS", "Morgan Stanley", "US6174464486", "617446448", "NYSE", "Financial Services", "Investment Wealth", "United States", 112.50, 0.90, 0.81, 111.00, 113.40, 82.00, 116.00, 5400000, 5800000, 182.0, 16.8, 14.5, 1.4, 6.70, 3.02, 1.28, 13.8, 14.9, 14.2, 2.45, 11.2, 1.8, 3.1, 57.8, false, 83, 24.1),
            Security("BABA", "Alibaba Group Holding", "US01609W1027", "01609W102", "NYSE", "Consumer Cyclical", "Internet Retail", "China", 98.40, -1.80, -1.80, 97.20, 101.50, 68.00, 118.00, 18500000, 22000000, 235.0, 14.2, 11.2, 0.9, 6.93, 1.80, 0.72, 14.8, 16.2, 24.5, 0.15, 8.4, 1.4, 1.6, 44.5, false, 69, 38.2),
            Security("TCEHY", "Tencent Holdings Ltd", "US88032Q1090", "88032Q109", "OTC", "Communication Services", "Interactive Media", "China", 52.80, -0.40, -0.75, 52.10, 53.60, 36.00, 60.00, 2900000, 3400000, 492.0, 21.4, 18.2, 1.1, 2.47, 0.95, 0.85, 19.4, 21.8, 28.4, 0.28, 14.2, 4.8, 5.2, 48.1, false, 72, 21.0),
            Security("SANCTION-DEMO", "Global Restricted Corp (SANCTIONED)", "US9999999999", "999999999", "OTC", "Energy", "Restricted", "Restricted", 14.50, 0.00, 0.00, 14.50, 14.50, 10.00, 25.00, 0, 0, 1.2, 8.0, 8.0, 1.0, 1.80, 0.00, 2.50, 5.0, 5.0, 0.1, 5.0, 4.0, 0.5, 0.5, 30.0, true, 20, 180.0)
        )
    }

    private fun createInitialGlobalIndices(): List<GlobalIndex> {
        return listOf(
            GlobalIndex("SPX", "S&P 500", 5982.40, 24.80, 0.42, "5,958.20 - 5,994.10", "4,953.56 - 6,025.20", "3.82B", "OPEN"),
            GlobalIndex("NDX", "NASDAQ 100", 21340.80, 142.10, 0.67, "21,180.40 - 21,390.50", "17,250.80 - 21,480.00", "4.21B", "OPEN"),
            GlobalIndex("DJI", "DOW JONES IND.", 44210.60, -38.20, -0.09, "44,120.00 - 44,380.00", "37,611.50 - 44,486.20", "420M", "OPEN"),
            GlobalIndex("UKX", "FTSE 100", 8390.20, 18.40, 0.22, "8,360.50 - 8,410.80", "7,450.20 - 8,485.40", "850M", "CLOSED"),
            GlobalIndex("DAX", "DAX 40", 19680.50, 52.10, 0.27, "19,590.20 - 19,720.00", "16,800.00 - 19,800.00", "640M", "CLOSED"),
            GlobalIndex("PX1", "CAC 40", 7420.80, -12.40, -0.17, "7,390.00 - 7,450.00", "7,150.00 - 8,250.00", "510M", "CLOSED"),
            GlobalIndex("N225", "NIKKEI 225", 38940.00, 280.50, 0.73, "38,620.00 - 39,050.00", "35,247.80 - 42,426.70", "1.25B", "CLOSED"),
            GlobalIndex("HSI", "HANG SENG", 19850.20, -180.40, -0.90, "19,720.00 - 20,110.00", "14,794.10 - 23,241.70", "1.90B", "CLOSED"),
            GlobalIndex("AS51", "ASX 200", 8410.60, 31.20, 0.37, "8,380.00 - 8,430.00", "7,490.00 - 8,460.00", "580M", "CLOSED"),
            GlobalIndex("SENSEX", "BSE SENSEX", 79802.40, 195.80, 0.25, "79,510.00 - 80,100.00", "70,319.00 - 85,978.20", "720M", "CLOSED")
        )
    }

    private fun createInitialMacroInstruments(): List<MacroInstrument> {
        return listOf(
            MacroInstrument("VIX", "CBOE Volatility Index", MacroType.COMMODITY, 14.82, -0.45, -2.95, "pts"),
            MacroInstrument("US10Y", "US 10-Year Treasury Yield", MacroType.BOND_YIELD, 4.412, 0.024, 0.55, "%"),
            MacroInstrument("US02Y", "US 2-Year Treasury Yield", MacroType.BOND_YIELD, 4.285, 0.012, 0.28, "%"),
            MacroInstrument("XAU/USD", "Gold Spot", MacroType.COMMODITY, 2684.50, 14.80, 0.55, "USD/oz"),
            MacroInstrument("XAG/USD", "Silver Spot", MacroType.COMMODITY, 31.42, 0.38, 1.22, "USD/oz"),
            MacroInstrument("CL1", "Crude Oil WTI", MacroType.COMMODITY, 69.45, -0.82, -1.17, "USD/bbl"),
            MacroInstrument("NG1", "Natural Gas", MacroType.COMMODITY, 3.24, 0.09, 2.86, "USD/MMBtu"),
            MacroInstrument("BTC/USD", "Bitcoin", MacroType.CRYPTO, 96420.0, 1850.0, 1.96, "USD"),
            MacroInstrument("EUR/USD", "Euro / US Dollar", MacroType.CURRENCY, 1.0542, -0.0018, -0.17, "rate"),
            MacroInstrument("GBP/USD", "British Pound / USD", MacroType.CURRENCY, 1.2680, 0.0022, 0.17, "rate"),
            MacroInstrument("USD/JPY", "US Dollar / Japanese Yen", MacroType.CURRENCY, 154.25, 0.45, 0.29, "rate")
        )
    }

    private fun createInitialPositions(accountId: String, secList: List<Security>): List<Position> {
        val secMap = secList.associateBy { it.ticker }
        val rawPositions = listOf(
            Triple("NVDA", 185000, 124.50),
            Triple("AAPL", 220000, 188.40),
            Triple("MSFT", 110000, 440.00),
            Triple("AMZN", 140000, 192.00),
            Triple("META", 45000, 580.00),
            Triple("GOOGL", 125000, 164.00),
            Triple("JPM", 95000, 198.00),
            Triple("LLY", 28000, 780.00),
            Triple("AVGO", 90000, 142.00),
            Triple("GS", 35000, 440.00)
        )

        val totalEstVal = rawPositions.sumOf { it.second * (secMap[it.first]?.price ?: 100.0) }

        return rawPositions.mapIndexed { idx, (ticker, qty, avgCost) ->
            val sec = secMap[ticker]
            val curPrice = sec?.price ?: 100.0
            val marketVal = qty * curPrice
            val totalCost = qty * avgCost
            val unPnl = marketVal - totalCost
            val unPnlPct = (unPnl / totalCost) * 100.0
            val weight = (marketVal / totalEstVal) * 100.0
            val contrib = (weight * unPnlPct) / 100.0

            Position(
                id = "POS-00$idx",
                accountId = accountId,
                symbol = ticker,
                companyName = sec?.name ?: ticker,
                quantity = qty,
                averageCost = avgCost,
                currentPrice = curPrice,
                marketValue = marketVal,
                unrealizedPnL = unPnl,
                unrealizedPnLPercent = ((unPnlPct * 100).roundToInt() / 100.0),
                realizedPnL = if (idx % 2 == 0) (idx * 240000.0) else 0.0,
                portfolioWeight = ((weight * 100).roundToInt() / 100.0),
                sectorWeight = if (sec?.sector == "Technology") 54.2 else 12.8,
                countryExposure = "United States",
                contributionPercent = ((contrib * 100).roundToInt() / 100.0)
            )
        }
    }

    private fun createInitialOrders(): List<Order> {
        val now = System.currentTimeMillis()
        return listOf(
            Order("ORD-9824A", now - 3600_000, "ACC-INST-001", "NVDA", OrderSide.BUY, OrderType.LIMIT, 10000, 178.50, null, TimeInForce.DAY, 10000, 178.50, OrderStatus.FILLED, "RHINO-DARK-POOL", "T. Sterling (ID: RS-8092)", 15.0, 1.2, 1785000.0),
            Order("ORD-9825B", now - 7200_000, "ACC-INST-001", "AAPL", OrderSide.BUY, OrderType.LIMIT, 25000, 214.00, null, TimeInForce.GTC, 25000, 213.98, OrderStatus.FILLED, "NYSE-ARCA", "T. Sterling (ID: RS-8092)", 25.0, 2.1, 5350000.0),
            Order("ORD-9826C", now - 1800_000, "ACC-INST-001", "MSFT", OrderSide.BUY, OrderType.LIMIT, 5000, 525.00, null, TimeInForce.DAY, 0, null, OrderStatus.OPEN, "RHINO-DARK-POOL", "T. Sterling (ID: RS-8092)", 15.0, 0.8, 2625000.0),
            Order("ORD-9827D", now - 900_000, "ACC-INST-001", "TSLA", OrderSide.SELL, OrderType.STOP_LIMIT, 8000, 250.00, 252.00, TimeInForce.DAY, 0, null, OrderStatus.OPEN, "NASDAQ-DIRECT", "T. Sterling (ID: RS-8092)", 15.0, 1.4, 2000000.0),
            Order("ORD-9820X", now - 14400_000, "ACC-INST-001", "META", OrderSide.BUY, OrderType.LIMIT, 3000, 710.00, null, TimeInForce.DAY, 3000, 709.80, OrderStatus.FILLED, "RHINO-DARK-POOL", "T. Sterling (ID: RS-8092)", 15.0, 0.9, 2130000.0),
            Order("ORD-9818Z", now - 28800_000, "ACC-INST-001", "XOM", OrderSide.SELL, OrderType.MARKET, 12000, null, null, TimeInForce.IOC, 12000, 119.40, OrderStatus.FILLED, "NYSE-FLOOR", "T. Sterling (ID: RS-8092)", 15.0, 1.8, 1432800.0)
        )
    }

    private fun createInitialNews(): List<NewsItem> {
        return listOf(
            NewsItem("NWS-1", "09:42:15", "Federal Reserve Signals Data-Dependent Stance on Benchmark Rates", "FOMC minutes indicate sustained vigilance on sticky services inflation, but policy committee remains open to measured cuts if labor cooling accelerates.", "Rhino Research Wire", NewsCategory.CENTRAL_BANKS, listOf("US10Y", "US02Y", "SPX"), Sentiment.NEUTRAL),
            NewsItem("NWS-2", "09:30:00", "NVIDIA Unveils Next-Gen Blackwell Ultra Enterprise AI Architecture", "Hyperscalers expand long-term capital expenditure commitments; custom silicon demand surges +38% YoY with strong backlog through 2027.", "Bloomberg Terminal Feed", NewsCategory.TECHNOLOGY, listOf("NVDA", "MSFT", "AVGO"), Sentiment.BULLISH),
            NewsItem("NWS-3", "09:14:22", "Apple Reaches Preliminary Multi-Year AI Cloud Infrastructure Accord", "Ecosystem services division expected to expand operating margins by 120 bps as high-margin enterprise AI workflow monetization begins.", "Reuters Institutional", NewsCategory.COMPANIES, listOf("AAPL", "GOOGL"), Sentiment.BULLISH),
            NewsItem("NWS-4", "08:55:10", "Global Crude Futures Consolidate as OPEC+ Reaffirms Voluntary Output Limits", "WTI hovers near $69/bbl with geopolitical supply risk premia countered by robust North American production rates.", "Rhino Commodities Desk", NewsCategory.ENERGY, listOf("CL1", "XOM", "SHEL"), Sentiment.NEUTRAL),
            NewsItem("NWS-5", "08:20:45", "JPMorgan Chase Reports Record Institutional Markets & Advisory Revenues", "Fixed income, currencies and commodities trading desk beats consensus estimates by 14% amid elevated global yield dispersion.", "Financial Times Desk", NewsCategory.BANKING, listOf("JPM", "GS", "MS"), Sentiment.BULLISH),
            NewsItem("NWS-6", "07:45:00", "European Central Bank Notes Steady Growth in Corporate Credit Spreads", "Governing council emphasizes balance sheet normalization and liquidity resilience across Tier-1 financial institutions.", "ECB Surveillance", NewsCategory.ECONOMY, listOf("EUR/USD", "DAX", "PX1"), Sentiment.NEUTRAL)
        )
    }

    private fun createInitialEarnings(): List<EarningsEvent> {
        return listOf(
            EarningsEvent("AAPL", "Apple Inc.", "2026-10-29", "Q4 2026", 1.62, 1.68, 94.8, 95.4, 3.7),
            EarningsEvent("MSFT", "Microsoft Corporation", "2026-10-22", "Q1 2027", 3.12, 3.24, 65.2, 66.1, 3.8),
            EarningsEvent("NVDA", "NVIDIA Corporation", "2026-11-19", "Q3 2027", 0.78, 0.86, 34.0, 35.8, 10.2),
            EarningsEvent("AMZN", "Amazon.com, Inc.", "2026-10-29", "Q3 2026", 1.15, 1.22, 158.0, 160.2, 6.1),
            EarningsEvent("META", "Meta Platforms, Inc.", "2026-10-28", "Q3 2026", 5.25, 5.60, 40.2, 41.5, 6.7),
            EarningsEvent("GOOGL", "Alphabet Inc.", "2026-10-27", "Q3 2026", 1.85, 1.94, 86.4, 88.2, 4.8),
            EarningsEvent("TSLA", "Tesla, Inc.", "2026-10-21", "Q3 2026", 0.62, 0.58, 25.8, 25.1, -6.5),
            EarningsEvent("JPM", "JPMorgan Chase & Co.", "2026-10-14", "Q3 2026", 4.02, 4.37, 42.6, 43.3, 8.7)
        )
    }

    // Stress Testing Calculations
    fun getStressScenarios(portfolioAum: Double): List<StressScenario> {
        return listOf(
            StressScenario("SC-1", "Global Market Shock (-10%)", "Broad equity drawdown with correlation spikes across all liquid asset classes.", -7.8, portfolioAum * -0.078, "All Sectors"),
            StressScenario("SC-2", "Severe Equity Crash (-20%)", "Systemic liquidity compression, high beta equities collapse, defensive Treasuries rally.", -16.2, portfolioAum * -0.162, "Tech, Discretionary, Small-Cap"),
            StressScenario("SC-3", "Technology Sector De-Rating (-25%)", "Valuation multiple contraction in AI hardware, semiconductor, and SaaS infrastructure.", -14.4, portfolioAum * -0.144, "Technology, Communications"),
            StressScenario("SC-4", "Interest Rates Spike (+100 bps)", "Aggressive central bank hawkishness, yield curve shift upward, duration impact on growth equities.", -4.8, portfolioAum * -0.048, "Real Estate, High P/E Tech, Utilities"),
            StressScenario("SC-5", "Interest Rates Pivot (-100 bps)", "Rapid policy easing, expansion of multiples, cyclical and small-cap outperformance.", 6.2, portfolioAum * 0.062, "Growth Equities, REITs"),
            StressScenario("SC-6", "Crude Oil Price Shock (+30%)", "Supply disruptions in Straits, stagflationary impulse, energy outperformance.", -2.9, portfolioAum * -0.029, "Airlines, Retail, Industrials"),
            StressScenario("SC-7", "US Dollar Appreciation (+10%)", "FX translation drag on multinational S&P 500 earnings, emerging market stress.", -3.6, portfolioAum * -0.036, "Multinationals, Exporters")
        )
    }

    // Backtest Strategies
    fun getBacktestStrategies(): List<BacktestStrategy> {
        return listOf(
            BacktestStrategy("Rhino Quantitative Multi-Factor Alpha", 24.8, 2.14, 2.92, -9.4, 68.4, 2.45, 142, 38.0),
            BacktestStrategy("Institutional Volatility-Managed Momentum", 19.5, 1.82, 2.41, -12.1, 62.0, 2.10, 88, 52.0),
            BacktestStrategy("Fundamental Quality & Free Cash Flow Yield", 17.2, 1.65, 2.15, -11.0, 65.5, 1.95, 45, 22.0),
            BacktestStrategy("Statistical Arbitrage & Mean Reversion", 14.8, 2.42, 3.20, -5.2, 74.2, 2.80, 480, 185.0)
        )
    }

    // Financial Statements Mock Data
    fun getFinancialStatements(ticker: String): List<FinancialStatementItem> {
        val sec = _securities.value[ticker]
        val baseRev = (sec?.marketCap ?: 500.0) * 0.12
        return listOf(
            FinancialStatementItem("FY2025 (TTM)", baseRev, baseRev * 0.46, baseRev * 0.35, baseRev * 0.30, baseRev * 0.24, sec?.eps ?: 6.83, baseRev * 0.22, 112.0, 68.0, 380.0, 220.0, 160.0),
            FinancialStatementItem("FY2024", baseRev * 0.88, baseRev * 0.88 * 0.44, baseRev * 0.88 * 0.33, baseRev * 0.88 * 0.28, baseRev * 0.88 * 0.22, (sec?.eps ?: 6.83) * 0.86, baseRev * 0.88 * 0.20, 115.0, 62.0, 355.0, 215.0, 140.0),
            FinancialStatementItem("FY2023", baseRev * 0.76, baseRev * 0.76 * 0.42, baseRev * 0.76 * 0.31, baseRev * 0.76 * 0.26, baseRev * 0.76 * 0.20, (sec?.eps ?: 6.83) * 0.72, baseRev * 0.76 * 0.18, 120.0, 55.0, 330.0, 210.0, 120.0),
            FinancialStatementItem("FY2022", baseRev * 0.65, baseRev * 0.65 * 0.40, baseRev * 0.65 * 0.29, baseRev * 0.65 * 0.24, baseRev * 0.65 * 0.18, (sec?.eps ?: 6.83) * 0.60, baseRev * 0.65 * 0.16, 124.0, 48.0, 305.0, 200.0, 105.0)
        )
    }

    private fun formatCurrency(amount: Double): String {
        return DecimalFormat("#,##0").format(amount)
    }
}
