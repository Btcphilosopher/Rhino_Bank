package com.example.data.model

enum class AccountType(val displayName: String) {
    INSTITUTIONAL("Institutional Alpha Fund (USD)"),
    HEDGE_FUND("Global Long/Short Equity Fund"),
    MANAGED_PORTFOLIO("Prime Wealth Segregated Mandate"),
    CORPORATE("Rhino Corporate Treasury Reserves"),
    PERSONAL("Principal Partner Account")
}

data class Account(
    val id: String,
    val name: String,
    val type: AccountType,
    val cash: Double,
    val buyingPower: Double,
    val marginUsed: Double,
    val baseCurrency: String = "USD",
    val allocationEquities: Double = 0.68,
    val allocationBonds: Double = 0.18,
    val allocationFunds: Double = 0.08,
    val allocationAlternatives: Double = 0.04,
    val allocationCrypto: Double = 0.02
)

data class Position(
    val id: String,
    val accountId: String,
    val symbol: String,
    val companyName: String,
    val quantity: Int,
    val averageCost: Double,
    val currentPrice: Double,
    val marketValue: Double,
    val unrealizedPnL: Double,
    val unrealizedPnLPercent: Double,
    val realizedPnL: Double,
    val portfolioWeight: Double,
    val sectorWeight: Double,
    val countryExposure: String,
    val contributionPercent: Double
)

data class PortfolioPerformance(
    val daily: Double,
    val weekly: Double,
    val monthly: Double,
    val ytd: Double,
    val oneYear: Double,
    val threeYear: Double,
    val fiveYear: Double,
    val inception: Double
)

data class PortfolioRiskMetrics(
    val volatility: Double, // annualised %
    val beta: Double,
    val sharpeRatio: Double,
    val sortinoRatio: Double,
    val maxDrawdown: Double,
    val var95Daily: Double, // Value at Risk 95%
    val cvar95Daily: Double, // Conditional VaR
    val trackingError: Double,
    val concentrationRatio: Double
)

data class StressScenario(
    val id: String,
    val name: String,
    val shockDescription: String,
    val estimatedPortfolioImpactPercent: Double,
    val estimatedDollarLoss: Double,
    val affectedSectors: String
)
