package com.example.data.model

enum class NewsCategory(val label: String) {
    BREAKING("Breaking"),
    MARKETS("Markets"),
    COMPANIES("Companies"),
    TECHNOLOGY("Technology"),
    ENERGY("Energy"),
    BANKING("Banking"),
    CENTRAL_BANKS("Central Banks"),
    ECONOMY("Economy"),
    GEOPOLITICS("Geopolitics")
}

enum class Sentiment { BULLISH, BEARISH, NEUTRAL }

data class NewsItem(
    val id: String,
    val timestamp: String,
    val headline: String,
    val summary: String,
    val source: String,
    val category: NewsCategory,
    val relatedTickers: List<String>,
    val sentiment: Sentiment,
    val isSimulated: Boolean = true
)

data class EarningsEvent(
    val symbol: String,
    val companyName: String,
    val reportDate: String,
    val quarter: String,
    val epsEstimate: Double,
    val epsActual: Double?,
    val revenueEstBln: Double,
    val revenueActualBln: Double?,
    val surprisePct: Double?
)

data class DividendInfo(
    val symbol: String,
    val dividendYield: Double,
    val annualPayout: Double,
    val exDividendDate: String,
    val paymentDate: String,
    val payoutRatio: Double,
    val growth5y: Double,
    val growth10y: Double
)

data class FinancialStatementItem(
    val period: String, // e.g. "FY2025", "FY2024", "Q4 2025"
    val revenueBln: Double,
    val grossProfitBln: Double,
    val ebitdaBln: Double,
    val ebitBln: Double,
    val netIncomeBln: Double,
    val eps: Double,
    val freeCashFlowBln: Double,
    val totalDebtBln: Double,
    val cashBln: Double,
    val totalAssetsBln: Double,
    val totalLiabilitiesBln: Double,
    val totalEquityBln: Double
)

data class ScreenerCriteria(
    val minMarketCap: Double = 0.0,
    val maxPe: Double = 100.0,
    val minRoic: Double = 0.0,
    val minRevenueGrowth: Double = -50.0,
    val maxDebtEquity: Double = 10.0,
    val selectedSector: String = "ALL",
    val selectedExchange: String = "ALL"
)
