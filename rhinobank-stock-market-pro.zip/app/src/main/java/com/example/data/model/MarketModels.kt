package com.example.data.model

enum class MarketDataMode(val label: String) {
    SIMULATED("SIMULATED DATA"),
    LIVE("LIVE DATA"),
    DELAYED("DELAYED (15m)")
}

data class Candle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Long
)

data class Security(
    val ticker: String,
    val name: String,
    val isin: String,
    val cusip: String,
    val exchange: String,
    val sector: String,
    val industry: String,
    val country: String,
    val price: Double,
    val change: Double,
    val changePercent: Double,
    val dayLow: Double,
    val dayHigh: Double,
    val yearLow: Double,
    val yearHigh: Double,
    val volume: Long,
    val avgVolume: Long,
    val marketCap: Double, // in Billions
    val pe: Double,
    val forwardPe: Double,
    val peg: Double,
    val eps: Double,
    val dividendYield: Double,
    val beta: Double,
    val roic: Double,
    val roe: Double,
    val fcf: Double, // in Billions
    val debtToEquity: Double,
    val evEbitda: Double,
    val priceToBook: Double,
    val priceToSales: Double,
    val rsi: Double,
    val isRestricted: Boolean = false,
    val esgScore: Int = 82,
    val carbonIntensity: Double = 14.2 // tCO2e / $M rev
)

data class GlobalIndex(
    val symbol: String,
    val name: String,
    val value: Double,
    val change: Double,
    val changePercent: Double,
    val dayRange: String,
    val yearRange: String,
    val volume: String,
    val status: String
)

enum class MacroType {
    BOND_YIELD, COMMODITY, CURRENCY, CRYPTO
}

data class MacroInstrument(
    val symbol: String,
    val name: String,
    val type: MacroType,
    val value: Double,
    val change: Double,
    val changePercent: Double,
    val unit: String
)

data class OrderBookLevel(
    val price: Double,
    val size: Int,
    val total: Int,
    val depthPercent: Float
)

data class OrderBook(
    val symbol: String,
    val bids: List<OrderBookLevel>,
    val asks: List<OrderBookLevel>,
    val spread: Double,
    val spreadBps: Double,
    val midPrice: Double
)
