package com.example.data.model

enum class UserRole(val title: String, val badge: String) {
    TRADER("Trader (Institutional Execution)", "EXEC"),
    PORTFOLIO_MANAGER("Portfolio Manager (CIO / Alpha)", "PM"),
    RESEARCH_ANALYST("Research Analyst (Equity / Quant)", "RES"),
    RISK_MANAGER("Risk Manager (Enterprise CRO)", "RISK"),
    COMPLIANCE_OFFICER("Compliance Officer (Surveillance)", "COMP"),
    ADMINISTRATOR("Administrator (Enterprise Ops)", "ADMIN"),
    EXECUTIVE("Executive (C-Suite Workstation)", "EXEC-VIEW"),
    READ_ONLY("Read Only Auditor", "AUDIT")
}

data class AuditEvent(
    val id: String,
    val timestamp: String,
    val user: String,
    val account: String,
    val action: String,
    val instrument: String,
    val oldValue: String,
    val newValue: String,
    val ipSession: String,
    val reason: String,
    val approvalStatus: String,
    val tamperProofHash: String
)

data class ComplianceRule(
    val id: String,
    val name: String,
    val ruleType: String,
    val thresholdDescription: String,
    val currentBreaches: Int,
    val isEnabled: Boolean = true,
    val status: String = "ACTIVE"
)

data class PriceAlert(
    val id: String,
    val symbol: String,
    val condition: String, // ">", "<", "% CHANGE >"
    val targetPrice: Double,
    val isTriggered: Boolean = false,
    val triggeredTime: String? = null,
    val note: String = ""
)

data class WorkspaceLayout(
    val id: String,
    val name: String,
    val description: String
)
