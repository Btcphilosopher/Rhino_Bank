package com.example.data.model

data class DcfAssumptions(
    val revenueGrowthPct: Double = 12.5,
    val ebitdaMarginPct: Double = 33.0,
    val taxRatePct: Double = 21.0,
    val capexPctOfRev: Double = 4.5,
    val workingCapitalPctOfRev: Double = 2.0,
    val waccPct: Double = 8.8,
    val terminalGrowthPct: Double = 2.8,
    val sharesOutstandingBln: Double = 15.2,
    val netDebtBln: Double = 45.0
)

data class DcfResult(
    val enterpriseValueBln: Double,
    val equityValueBln: Double,
    val fairValuePerShare: Double,
    val upsideDownsidePct: Double,
    val projectedFcfList: List<Double>,
    val terminalValueBln: Double,
    val pvOfFcfBln: Double
)

data class ValuationScenario(
    val name: String,
    val revenueGrowth: Double,
    val ebitdaMargin: Double,
    val fairValue: Double,
    val expectedReturnPct: Double,
    val epsEstimate: Double,
    val fcfBln: Double
)

data class ComparablePeer(
    val ticker: String,
    val name: String,
    val marketCapBln: Double,
    val pe: Double,
    val evEbitda: Double,
    val priceToSales: Double,
    val roic: Double
)

data class OptimizationResult(
    val title: String,
    val expectedReturnPct: Double,
    val expectedVolPct: Double,
    val sharpeRatio: Double,
    val estimatedMaxDrawdown: Double,
    val allocations: Map<String, Double>
)

data class BacktestStrategy(
    val name: String,
    val cagr: Double,
    val sharpe: Double,
    val sortino: Double,
    val maxDrawdown: Double,
    val winRate: Double,
    val profitFactor: Double,
    val numTrades: Int,
    val turnoverPct: Double,
    val benchmarkCagr: Double = 11.4
)
