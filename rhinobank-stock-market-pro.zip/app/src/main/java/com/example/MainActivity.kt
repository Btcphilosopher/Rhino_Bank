package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.RhinoMainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RhinoBankTheme {
                RhinoBankStockMarketProApp()
            }
        }
    }
}

@Composable
fun RhinoBankStockMarketProApp(
    viewModel: RhinoMainViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val isSearchOpen by viewModel.isSearchOpen.collectAsState()
    val isAlertModalOpen by viewModel.isAlertModalOpen.collectAsState()
    val isReportModalOpen by viewModel.isReportModalOpen.collectAsState()
    val notification by viewModel.notification.collectAsState()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(RhinoBackground),
        topBar = {
            Column(modifier = Modifier.statusBarsPadding()) {
                RhinoTopBar(viewModel = viewModel)
                RhinoTickerTape(viewModel = viewModel)
            }
        },
        containerColor = RhinoBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(RhinoBackground)
        ) {
            // Workspace Screen Switcher
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "workspace_screen_transition"
            ) { tab ->
                when (tab) {
                    MainNavigationTab.MARKETS -> MarketsDashboardScreen(viewModel = viewModel)
                    MainNavigationTab.TERMINAL -> StockTerminalScreen(viewModel = viewModel)
                    MainNavigationTab.TRADE_DESK -> TradeDeskScreen(viewModel = viewModel)
                    MainNavigationTab.PORTFOLIO_OMS -> PortfolioOmsScreen(viewModel = viewModel)
                    MainNavigationTab.RISK_ANALYTICS -> RiskAnalyticsScreen(viewModel = viewModel)
                    MainNavigationTab.QUANT_MODELS -> QuantitativeScreen(viewModel = viewModel)
                    MainNavigationTab.SCREENER_NEWS -> ScreenerNewsScreen(viewModel = viewModel)
                    MainNavigationTab.COMPLIANCE_AUDIT -> ComplianceAuditScreen(viewModel = viewModel)
                }
            }

            // Universal Search Dialog
            if (isSearchOpen) {
                GlobalSearchModal(viewModel = viewModel)
            }

            // Alert Builder Dialog
            if (isAlertModalOpen) {
                AlertBuilderDialog(viewModel = viewModel)
            }

            // Report Export Dialog
            if (isReportModalOpen) {
                ReportExportDialog(viewModel = viewModel)
            }

            // High Priority Institutional Notification Toast
            AnimatedVisibility(
                visible = notification != null,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 12.dp, start = 16.dp, end = 16.dp)
            ) {
                notification?.let { notif ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = RhinoSurfaceElevated,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (notif.isPositive) RhinoCyan else MarketRed),
                        shadowElevation = 8.dp,
                        modifier = Modifier.testTag("app_notification_toast")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (notif.isPositive) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (notif.isPositive) MarketGreen else MarketRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = notif.title,
                                    color = if (notif.isPositive) RhinoCyan else MarketRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = notif.message,
                                    color = TextPrimary,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
