/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import {
  TrendingUp,
  Activity,
  Layers,
  ShoppingBag,
  RefreshCw,
  AlertTriangle,
  Play,
  RotateCcw,
  Truck,
  Cpu,
  BarChart4,
  DollarSign,
  ShieldAlert,
  Sliders,
  Send,
  HelpCircle,
  Clock,
  Briefcase,
  GitBranch,
  UserCheck,
  CheckCircle,
  FileSpreadsheet,
  AlertCircle
} from 'lucide-react';

import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area
} from 'recharts';

import {
  SKU,
  Order,
  PullSignal,
  KanbanCard,
  ProductionOrder,
  PurchaseOrder,
  WorkCentre,
  Supplier,
  Alert,
  KaizenEvent,
  AuditLog,
  SimulationState,
  createInitialState,
  runSimulationStep,
  runOptimizationForSku,
  runComparisonSimulation,
  runMonteCarloSimulation,
  generateId,
  calculateTotalInventoryValue
} from './rhinoquantEngine';

export default function App() {
  // Primary State
  const [state, setState] = useState<SimulationState>(createInitialState());
  const [simulationMode, setSimulationMode] = useState<'PUSH' | 'PULL' | 'HYBRID'>('PULL');
  const [disruptions, setDisruptions] = useState({
    demandSpike: false,
    supplierDelay: false,
    machineFailure: false,
    kanbanSizingChange: false
  });

  // UI States
  const [activeTab, setActiveTab] = useState<string>('COMMAND');
  const [selectedSkuId, setSelectedSkuId] = useState<string>('RH-100');
  const [aiQuestion, setAiQuestion] = useState<string>('');
  const [aiAnswer, setAiAnswer] = useState<string>('');
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);
  const [comparisonResults, setComparisonResults] = useState<any>(null);
  const [monteCarloResults, setMonteCarloResults] = useState<any[]>([]);
  const [optimizationOutputs, setOptimizationOutputs] = useState<Record<string, any>>({});
  const [selectedTargetServiceLevel, setSelectedTargetServiceLevel] = useState<number>(0.95);
  const [financeDaysSlider, setFinanceDaysSlider] = useState<number>(42);

  // BOM explanation details
  const [bomExplodeSku, setBomExplodeSku] = useState<string>('RH-100');
  const [bomExplodeQty, setBomExplodeQty] = useState<number>(100);

  // New Kaizen Log State
  const [newKaizen, setNewKaizen] = useState({
    observation: '',
    problem: '',
    rootCause: '',
    countermeasure: '',
    experiment: ''
  });

  // Track animation activity (for flow map)
  const [animationSignal, setAnimationSignal] = useState<'NONE' | 'PULL' | 'PUSH' | 'RECEIVE'>('NONE');

  // Trigger Monte Carlo and Comparison updates
  useEffect(() => {
    // Generate Monte Carlo projections for the active SKU
    const mc = runMonteCarloSimulation(selectedSkuId, 100, 30);
    setMonteCarloResults(mc);
  }, [selectedSkuId, state.day]);

  useEffect(() => {
    // Calculate static comparisons
    const comp = runComparisonSimulation(30);
    setComparisonResults(comp);

    // Compute Optimization targets for each SKU
    const opts: Record<string, any> = {};
    (Object.values(state.skus) as SKU[]).forEach(s => {
      opts[s.id] = runOptimizationForSku(s, selectedTargetServiceLevel, state.historyOfDemand[s.id] || []);
    });
    setOptimizationOutputs(opts);
  }, [state.day, selectedTargetServiceLevel]);

  // Step function
  const handleStep = () => {
    setAnimationSignal('PULL');
    setTimeout(() => {
      setAnimationSignal('RECEIVE');
      setTimeout(() => {
        setAnimationSignal('NONE');
      }, 500);
    }, 500);

    const nextState = runSimulationStep(state, simulationMode, disruptions);
    setState(nextState);
  };

  // Run fast forward
  const handleFastForward = (daysCount: number) => {
    let currentState = { ...state };
    for (let i = 0; i < daysCount; i++) {
      currentState = runSimulationStep(currentState, simulationMode, disruptions);
    }
    setState(currentState);
  };

  // Reset function
  const handleReset = () => {
    setState(createInitialState());
  };

  // Trigger custom AI questions to our server-side API proxy
  const askRhinoIntelligence = async (customPrompt?: string) => {
    const questionToAsk = customPrompt || aiQuestion;
    if (!questionToAsk.trim()) return;

    setIsAiLoading(true);
    setAiAnswer('');

    try {
      const response = await fetch('/api/gemini/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: questionToAsk,
          stateContext: {
            day: state.day,
            skus: state.skus,
            alerts: state.alerts.filter(a => a.status === 'ACTIVE'),
            financials: state.financials
          }
        })
      });

      const data = await response.json();
      if (data.error) {
        setAiAnswer(`Error: ${data.error}`);
      } else {
        setAiAnswer(data.response);
      }
    } catch (error: any) {
      setAiAnswer(`Failed to query RhinoQuant Intelligence Server API: ${error?.message || error}`);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleAddKaizen = () => {
    if (!newKaizen.observation || !newKaizen.problem) return;

    const event: KaizenEvent = {
      id: generateId('KZN'),
      observation: newKaizen.observation,
      problem: newKaizen.problem,
      rootCause: newKaizen.rootCause || 'Underlying process variability unchecked',
      countermeasure: newKaizen.countermeasure || 'Implement localized electronic supermarket',
      experiment: newKaizen.experiment || 'Continuous replenishment monitoring',
      metricsBefore: `Service Level: ${state.historyOfServiceLevel[state.historyOfServiceLevel.length - 1]}%`,
      metricsAfter: 'Target: Service Level 99% + Reduced Inventory Value 15%',
      dayCreated: state.day
    };

    setState(prev => ({
      ...prev,
      kaizenEvents: [event, ...prev.kaizenEvents],
      auditLogs: [
        {
          id: generateId('AUD'),
          timestamp: new Date().toISOString(),
          day: state.day,
          actor: 'CI_ENGINEER',
          action: 'KAIZEN_LOG',
          targetObject: event.id,
          beforeState: 'NONE',
          afterState: 'LOGGED',
          reason: 'Continuous operational improvement cycle logged',
          correlationId: 'KAIZEN'
        },
        ...prev.auditLogs
      ]
    }));

    setNewKaizen({ observation: '', problem: '', rootCause: '', countermeasure: '', experiment: '' });
  };

  // Helper values
  const currentServiceLevel = state.historyOfServiceLevel[state.historyOfServiceLevel.length - 1];
  const activeAlertsCount = state.alerts.filter(a => a.status === 'ACTIVE').length;

  return (
    <div className="min-h-screen bg-[#111215] text-[#D2D5DC] font-sans antialiased selection:bg-zinc-700 selection:text-white flex flex-col">
      
      {/* 1. HEADER CONTROL & SUMMARY BAR */}
      <header className="border-b border-zinc-800 bg-[#16171B] px-6 py-4 flex flex-wrap justify-between items-center gap-4 sticky top-0 z-50">
        <div className="flex items-center space-x-3">
          <div className="bg-[#E44B35] text-white font-extrabold px-3 py-1 text-sm tracking-wider rounded-sm flex items-center gap-1.5 shadow-md">
            <span className="font-mono">RQ</span>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              RHINOQUANT <span className="text-xs font-normal px-2 py-0.5 rounded-full bg-zinc-800 text-[#969A9E] border border-zinc-700 tracking-normal">Demand-Pull OS</span>
            </h1>
            <p className="text-xs text-[#969A9E] font-mono tracking-widest uppercase">Codename: RHINO PULL</p>
          </div>
        </div>

        {/* Global Controls */}
        <div className="flex items-center flex-wrap gap-3">
          {/* Operating Mode Selector */}
          <div className="bg-[#1F2025] p-1 rounded-sm border border-zinc-800 flex space-x-1 text-xs">
            {(['PULL', 'PUSH', 'HYBRID'] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => {
                  setSimulationMode(mode);
                  setState(prev => ({
                    ...prev,
                    auditLogs: [
                      {
                        id: generateId('AUD'),
                        timestamp: new Date().toISOString(),
                        day: prev.day,
                        actor: 'OPERATOR',
                        action: 'MODE_CHANGE',
                        targetObject: 'RHINOQUANT',
                        beforeState: prev.day > 1 ? 'PREVIOUS' : 'INITIAL',
                        afterState: mode,
                        reason: 'Operational paradigm manual override',
                        correlationId: 'CONTROL'
                      },
                      ...prev.auditLogs
                    ]
                  }));
                }}
                className={`px-3 py-1.5 font-bold rounded-xs transition-all ${
                  simulationMode === mode
                    ? 'bg-zinc-700 text-white shadow-xs border border-zinc-600'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                {mode === 'PULL' ? '🟢 DEMAND PULL' : mode === 'PUSH' ? '🔴 FORECAST PUSH' : '🔵 HYBRID'}
              </button>
            ))}
          </div>

          {/* Simulation Steps */}
          <div className="flex items-center space-x-2 bg-zinc-900/50 p-1 rounded-sm border border-zinc-800">
            <button
              onClick={handleStep}
              className="bg-zinc-800 hover:bg-zinc-700 active:bg-zinc-600 text-white px-3 py-1.5 rounded-sm flex items-center space-x-1.5 text-xs font-bold transition-colors border border-zinc-700"
            >
              <Play size={12} className="text-emerald-500 fill-emerald-500" />
              <span>STEP 1 DAY</span>
            </button>
            <button
              onClick={() => handleFastForward(7)}
              className="bg-zinc-800 hover:bg-zinc-700 active:bg-zinc-600 text-white px-3 py-1.5 rounded-sm flex items-center space-x-1.5 text-xs font-bold transition-colors border border-zinc-700"
            >
              <RefreshCw size={12} className="text-indigo-400" />
              <span>FAST 7 DAYS</span>
            </button>
            <button
              onClick={handleReset}
              className="hover:bg-zinc-800 text-zinc-400 hover:text-white p-1.5 rounded-sm text-xs font-bold transition-colors"
              title="Reset Simulation"
            >
              <RotateCcw size={14} />
            </button>
          </div>
        </div>

        {/* Global Day Badge */}
        <div className="bg-[#1E2024] px-4 py-2 border border-zinc-800 rounded-sm text-center">
          <div className="text-[10px] text-[#969A9E] font-mono tracking-wider">SYSTEM DAY</div>
          <div className="text-xl font-black font-mono text-emerald-400">{state.day}</div>
        </div>
      </header>

      {/* 2. LIVE ANIMAED DEMAND-PULL FEEDBACK MAP */}
      <section className="bg-[#121316] border-b border-zinc-800/80 px-6 py-3">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-zinc-400">
            <Activity size={14} className="text-emerald-500 animate-pulse" />
            <span className="font-bold uppercase tracking-wider text-[10px] text-zinc-500 font-mono">Feedback Network loop:</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 font-mono text-[10px] tracking-wider w-full md:w-auto">
            {/* Customer Demand */}
            <div className="px-3 py-1 bg-zinc-800 border border-zinc-700 rounded-sm text-center min-w-[90px]">
              <span className="text-zinc-500">CUSTOMER</span>
              <div className="font-bold text-white">DEMAND</div>
            </div>

            <div className="flex items-center">
              <span className={`text-sm ${animationSignal === 'PULL' ? 'text-emerald-500 animate-ping font-bold' : 'text-zinc-700'}`}>
                ◀◀
              </span>
              <span className="text-[8px] text-zinc-600 px-1">PULL</span>
            </div>

            {/* Consumption */}
            <div className="px-3 py-1 bg-zinc-800 border border-zinc-700 rounded-sm text-center min-w-[90px]">
              <span className="text-zinc-500">CDC STOCK</span>
              <div className="font-bold text-emerald-400">{state.skus['RH-100'].currentOnHand}</div>
            </div>

            <div className="flex items-center">
              <span className={`text-sm ${animationSignal === 'PULL' ? 'text-indigo-400 animate-ping font-bold' : 'text-zinc-700'}`}>
                ◀◀
              </span>
              <span className="text-[8px] text-zinc-600 px-1">KANBAN</span>
            </div>

            {/* Production (Sheffield) */}
            <div className="px-3 py-1 bg-zinc-800 border border-zinc-700 rounded-sm text-center min-w-[90px]">
              <span className="text-zinc-500">SHEFFIELD FG</span>
              <div className="font-bold text-white">{state.skus['RH-100'].currentOnHand}</div>
            </div>

            <div className="flex items-center">
              <span className={`text-sm ${animationSignal === 'PULL' ? 'text-amber-500 animate-ping font-bold' : 'text-zinc-700'}`}>
                ◀◀
              </span>
              <span className="text-[8px] text-zinc-600 px-1">BOM</span>
            </div>

            {/* Subassembly Motor */}
            <div className="px-3 py-1 bg-zinc-800 border border-zinc-700 rounded-sm text-center min-w-[90px]">
              <span className="text-zinc-500">RH-200 MOTOR</span>
              <div className="font-bold text-indigo-300">{state.skus['RH-200'].currentOnHand}</div>
            </div>

            <div className="flex items-center">
              <span className={`text-sm ${animationSignal === 'RECEIVE' ? 'text-amber-400 animate-bounce font-bold' : 'text-zinc-700'}`}>
                ▶▶
              </span>
              <span className="text-[8px] text-zinc-600 px-1">SUPPLY</span>
            </div>

            {/* Suppliers */}
            <div className="px-3 py-1 bg-zinc-800 border border-zinc-700 rounded-sm text-center min-w-[90px]">
              <span className="text-zinc-500">5 SUPPLIERS</span>
              <div className="font-bold text-zinc-400">ACTIVE</div>
            </div>
          </div>
          
          <div className="text-[10px] text-[#969A9E] font-mono bg-zinc-900 px-2 py-0.5 rounded-sm">
            Status: <span className="font-bold text-emerald-400">CLOSED LOOP STABLE</span>
          </div>
        </div>
      </section>

      {/* 3. DISRUPTIONS PANEL */}
      <section className="bg-[#17191D] border-b border-zinc-800 px-6 py-3 flex flex-wrap gap-4 items-center justify-between">
        <div className="flex items-center space-x-2">
          <Sliders size={14} className="text-amber-500" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#969A9E]">Operational Twin Controls (Disruptions):</h3>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <label className="flex items-center space-x-2 text-xs bg-zinc-900 px-3 py-1.5 rounded-sm border border-zinc-800 cursor-pointer hover:bg-zinc-800/80">
            <input
              type="checkbox"
              checked={disruptions.demandSpike}
              onChange={(e) => {
                setDisruptions(prev => ({ ...prev, demandSpike: e.target.checked }));
                setState(prev => ({
                  ...prev,
                  auditLogs: [
                    {
                      id: generateId('AUD'),
                      timestamp: new Date().toISOString(),
                      day: prev.day,
                      actor: 'OPERATOR',
                      action: 'TOGGLE_DISRUPTION',
                      targetObject: 'DEMAND_SPIKE',
                      beforeState: (!disruptions.demandSpike).toString(),
                      afterState: e.target.checked.toString(),
                      reason: 'Trigger high-demand anomaly simulation',
                      correlationId: 'DISRUPT'
                    },
                    ...prev.auditLogs
                  ]
                }));
              }}
              className="accent-[#E44B35] rounded-xs"
            />
            <span className={disruptions.demandSpike ? 'text-[#E44B35] font-bold' : 'text-zinc-400'}>🔥 Demand +100% Surge (Day 10-18)</span>
          </label>

          <label className="flex items-center space-x-2 text-xs bg-zinc-900 px-3 py-1.5 rounded-sm border border-zinc-800 cursor-pointer hover:bg-zinc-800/80">
            <input
              type="checkbox"
              checked={disruptions.supplierDelay}
              onChange={(e) => {
                setDisruptions(prev => ({ ...prev, supplierDelay: e.target.checked }));
                setState(prev => ({
                  ...prev,
                  auditLogs: [
                    {
                      id: generateId('AUD'),
                      timestamp: new Date().toISOString(),
                      day: prev.day,
                      actor: 'OPERATOR',
                      action: 'TOGGLE_DISRUPTION',
                      targetObject: 'SUPPLIER_DELAY',
                      beforeState: (!disruptions.supplierDelay).toString(),
                      afterState: e.target.checked.toString(),
                      reason: 'Trigger supplier lead time delay anomaly',
                      correlationId: 'DISRUPT'
                    },
                    ...prev.auditLogs
                  ]
                }));
              }}
              className="accent-amber-500 rounded-xs"
            />
            <span className={disruptions.supplierDelay ? 'text-amber-500 font-bold' : 'text-zinc-400'}>⏱️ Supplier Sensa Delay (+6d)</span>
          </label>

          <label className="flex items-center space-x-2 text-xs bg-zinc-900 px-3 py-1.5 rounded-sm border border-zinc-800 cursor-pointer hover:bg-zinc-800/80">
            <input
              type="checkbox"
              checked={disruptions.machineFailure}
              onChange={(e) => {
                setDisruptions(prev => ({ ...prev, machineFailure: e.target.checked }));
                setState(prev => ({
                  ...prev,
                  auditLogs: [
                    {
                      id: generateId('AUD'),
                      timestamp: new Date().toISOString(),
                      day: prev.day,
                      actor: 'OPERATOR',
                      action: 'TOGGLE_DISRUPTION',
                      targetObject: 'MACHINE_FAILURE',
                      beforeState: (!disruptions.machineFailure).toString(),
                      afterState: e.target.checked.toString(),
                      reason: 'Trigger machine assembly breakdown anomaly',
                      correlationId: 'DISRUPT'
                    },
                    ...prev.auditLogs
                  ]
                }));
              }}
              className="accent-red-500 rounded-xs"
            />
            <span className={disruptions.machineFailure ? 'text-red-500 font-bold' : 'text-zinc-400'}>⚠️ Breakdown: M-HydraPress 2000 (W-PUMP)</span>
          </label>

          <label className="flex items-center space-x-2 text-xs bg-zinc-900 px-3 py-1.5 rounded-sm border border-zinc-800 cursor-pointer hover:bg-zinc-800/80">
            <input
              type="checkbox"
              checked={disruptions.kanbanSizingChange}
              onChange={(e) => {
                setDisruptions(prev => ({ ...prev, kanbanSizingChange: e.target.checked }));
                setState(prev => ({
                  ...prev,
                  auditLogs: [
                    {
                      id: generateId('AUD'),
                      timestamp: new Date().toISOString(),
                      day: prev.day,
                      actor: 'OPERATOR',
                      action: 'KANBAN_ADJUST',
                      targetObject: 'KANBAN_CARDS',
                      beforeState: '8 containers',
                      afterState: e.target.checked ? '14 containers' : '8 containers',
                      reason: 'Dynamically scale safety factor buffer size',
                      correlationId: 'DISRUPT'
                    },
                    ...prev.auditLogs
                  ]
                }));
              }}
              className="accent-indigo-500 rounded-xs"
            />
            <span className={disruptions.kanbanSizingChange ? 'text-indigo-400 font-bold' : 'text-zinc-400'}>📈 Safety Optimization: +6 Kanban Cards</span>
          </label>
        </div>
      </section>

      {/* 4. MAIN LAYOUT SIDEBAR & VIEWPORTS */}
      <div className="flex flex-1 flex-col lg:flex-row">
        
        {/* Navigation Sidebar */}
        <nav className="w-full lg:w-64 bg-[#141519] border-r border-zinc-800 p-4 flex flex-row lg:flex-col gap-1 overflow-x-auto lg:overflow-x-visible sticky top-[120px] h-auto lg:h-[calc(100vh-120px)] z-40">
          <div className="hidden lg:block text-[10px] font-bold text-zinc-500 uppercase tracking-widest px-3 mb-2 font-mono">CONSOLES</div>
          
          {[
            { id: 'COMMAND', label: 'Overview / Command', icon: Activity },
            { id: 'DEMAND', label: 'Demand Velocity', icon: ShoppingBag },
            { id: 'PULL', label: 'Pull / BOM Explode', icon: GitBranch },
            { id: 'KANBAN', label: 'Kanban Deck', icon: Layers },
            { id: 'INVENTORY', label: 'Inventory balances', icon: FileSpreadsheet },
            { id: 'PRODUCTION', label: 'Production cells', icon: Cpu },
            { id: 'SUPPLIERS', label: 'Suppliers Scorecard', icon: UserCheck },
            { id: 'SIMULATION', label: 'Twin Simulation', icon: Sliders },
            { id: 'OPTIMISATION', label: 'Safety Solver', icon: BarChart4 },
            { id: 'FINANCE', label: 'Working Capital', icon: DollarSign },
            { id: 'AI', label: 'Rhino Intelligence', icon: HelpCircle },
            { id: 'KAIZEN', label: 'Kaizen Log', icon: CheckCircle },
            { id: 'AUDIT', label: 'Audit Trail', icon: ShieldAlert }
          ].map((tab) => {
            const IconComponent = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full text-left px-3 py-2 text-xs font-medium rounded-sm transition-all flex items-center gap-2.5 whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-zinc-850 text-white font-bold border-l-2 border-[#E44B35]'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900/50'
                }`}
              >
                <IconComponent size={14} className={activeTab === tab.id ? 'text-[#E44B35]' : 'text-zinc-500'} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Console Viewport */}
        <main className="flex-1 bg-[#111215] p-6 lg:p-8 overflow-y-auto">
          
          {/* ======================================= */}
          {/* 1. COMMAND PANEL (OVERVIEW) */}
          {/* ======================================= */}
          {activeTab === 'COMMAND' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h2 className="text-lg font-bold text-white uppercase tracking-wider font-mono">⚡ RhinoQuant Command Center</h2>
                <div className="text-xs text-[#969A9E]">Real-time feedback loops overview</div>
              </div>

              {/* KPI Grid Ribbon */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                <div className="bg-[#16171B] border border-zinc-800 p-4 rounded-sm">
                  <div className="text-[10px] text-zinc-500 font-mono">CUMULATIVE REVENUE</div>
                  <div className="text-xl font-bold font-mono text-emerald-400">£{state.financials.revenue.toLocaleString()}</div>
                  <div className="text-[9px] text-zinc-400 font-mono">Direct pull sales</div>
                </div>

                <div className="bg-[#16171B] border border-zinc-800 p-4 rounded-sm">
                  <div className="text-[10px] text-zinc-500 font-mono">AVAILABLE CASH</div>
                  <div className="text-xl font-bold font-mono text-white">£{state.financials.cash.toLocaleString()}</div>
                  <div className="text-[9px] text-zinc-400 font-mono">Working capital pool</div>
                </div>

                <div className="bg-[#16171B] border border-zinc-800 p-4 rounded-sm">
                  <div className="text-[10px] text-zinc-500 font-mono">INVENTORY CAPITAL</div>
                  <div className="text-xl font-bold font-mono text-amber-500">£{state.financials.inventoryValue.toLocaleString()}</div>
                  <div className="text-[9px] text-zinc-400 font-mono">Absorbing volatility</div>
                </div>

                <div className="bg-[#16171B] border border-zinc-800 p-4 rounded-sm">
                  <div className="text-[10px] text-zinc-500 font-mono">SERVICE LEVEL (OTIF)</div>
                  <div className="text-xl font-bold font-mono text-emerald-400">{currentServiceLevel}%</div>
                  <div className="text-[9px] text-zinc-400 font-mono">On-time-in-full target</div>
                </div>

                <div className="bg-[#16171B] border border-zinc-800 p-4 rounded-sm">
                  <div className="text-[10px] text-zinc-500 font-mono">WORK-IN-PROCESS (WIP)</div>
                  <div className="text-xl font-bold font-mono text-[#D2D5DC]">
                    {state.productionOrders.filter(p => p.status === 'STARTED').reduce((acc, x) => acc + x.quantity, 0)} units
                  </div>
                  <div className="text-[9px] text-zinc-400 font-mono">Active assembly lines</div>
                </div>

                <div className="bg-[#16171B] border border-zinc-800 p-4 rounded-sm">
                  <div className="text-[10px] text-zinc-500 font-mono">ACTIVE ALERTS</div>
                  <div className={`text-xl font-bold font-mono ${activeAlertsCount > 0 ? 'text-[#E44B35]' : 'text-zinc-500'}`}>
                    {activeAlertsCount}
                  </div>
                  <div className="text-[9px] text-zinc-400 font-mono">Operational anomalies</div>
                </div>
              </div>

              {/* Graphical Trend & Alert split */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Visualizing Active Cash vs. Inventory holding */}
                <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm lg:col-span-2">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-4 font-mono">📈 Operational Cash vs. Inventory Assets</h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={state.historyOfCash.map((c, i) => ({
                        day: i + 1,
                        Cash: c,
                        InventoryValue: state.historyOfInventoryValue[i] || 0
                      }))}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#2D3139" />
                        <XAxis dataKey="day" stroke="#969A9E" tick={{ fontSize: 10 }} />
                        <YAxis stroke="#969A9E" tick={{ fontSize: 10 }} />
                        <Tooltip contentStyle={{ backgroundColor: '#1A1D24', border: '1px solid #3F444E' }} />
                        <Legend wrapperStyle={{ fontSize: 10 }} />
                        <Area type="monotone" dataKey="Cash" stroke="#34D399" fill="#10B981" fillOpacity={0.05} />
                        <Area type="monotone" dataKey="InventoryValue" stroke="#FBBF24" fill="#F59E0B" fillOpacity={0.05} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Active Alerts Panel */}
                <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm flex flex-col h-80">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 font-mono">⚡ Active Exception Alerts</h3>
                    <span className="bg-[#E44B35]/20 text-[#E44B35] px-2 py-0.5 rounded-xs text-[10px] font-mono">SYSTEM LOG</span>
                  </div>
                  
                  <div className="space-y-3 overflow-y-auto flex-1 pr-1">
                    {state.alerts.filter(a => a.status === 'ACTIVE').length === 0 ? (
                      <div className="text-xs text-zinc-500 h-full flex items-center justify-center text-center">
                        All operational feedback loops steady.<br />No exceptions recorded.
                      </div>
                    ) : (
                      state.alerts.filter(a => a.status === 'ACTIVE').map(alert => (
                        <div key={alert.id} className="p-3 bg-[#1B1D23] border-l-2 border-[#E44B35] rounded-xs text-xs space-y-1">
                          <div className="flex justify-between text-[10px]">
                            <span className="font-bold text-[#E44B35] uppercase">{alert.type}</span>
                            <span className="text-zinc-500 font-mono">Day {alert.day}</span>
                          </div>
                          <p className="text-white font-medium">{alert.text}</p>
                          <p className="text-[10px] text-zinc-400"><span className="text-zinc-500">Action:</span> {alert.recommendedAction}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* Botttleneck Status Summary */}
              <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm">
                <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-4 font-mono">⚡ Manufacturing & Supplier Bottlenecks</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
                  
                  {/* Machine Status */}
                  <div className="space-y-3">
                    <h4 className="text-[11px] text-zinc-500 uppercase tracking-widest font-mono">Work Centre Capacity Limits</h4>
                    {(Object.values(state.workCentres) as WorkCentre[]).map(wc => (
                      <div key={wc.id} className="bg-zinc-900/50 p-3 border border-zinc-800 rounded-sm">
                        <div className="flex justify-between font-bold mb-1">
                          <span className="text-white">{wc.name}</span>
                          <span className={wc.isOnline ? 'text-emerald-400' : 'text-red-500'}>
                            {wc.isOnline ? '🟢 ONLINE' : '🔴 OFFLINE'}
                          </span>
                        </div>
                        <div className="flex justify-between text-[10px] text-zinc-500 font-mono">
                          <span>Machine: {wc.machineName}</span>
                          <span>Utilization: {Math.round((wc.allocatedHoursThisDay / wc.capacityHoursPerDay) * 100)}%</span>
                        </div>
                        <div className="w-full bg-zinc-850 h-1.5 rounded-full mt-2 overflow-hidden">
                          <div
                            className="bg-emerald-400 h-full"
                            style={{ width: `${Math.min(100, (wc.allocatedHoursThisDay / wc.capacityHoursPerDay) * 100)}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Supplier Reliability */}
                  <div className="space-y-3">
                    <h4 className="text-[11px] text-zinc-500 uppercase tracking-widest font-mono">Supplier Performance Status</h4>
                    <div className="space-y-2">
                      {(Object.values(state.suppliers) as Supplier[]).map(supp => (
                        <div key={supp.id} className="flex justify-between items-center p-2 bg-zinc-900/50 border border-zinc-800 rounded-sm">
                          <div>
                            <span className="font-bold text-white text-[11px]">{supp.name}</span>
                            <div className="text-[10px] text-zinc-500 font-mono">Promised Lead Time: {supp.promisedLeadTime} days</div>
                          </div>
                          <div className="text-right">
                            <span className="font-mono font-bold text-emerald-400">{supp.reliabilityScore}%</span>
                            <div className="text-[9px] text-zinc-500 font-mono">Defect rate: {(supp.defectRate * 100).toFixed(1)}%</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ======================================= */}
          {/* 2. DEMAND ENGINE */}
          {/* ======================================= */}
          {activeTab === 'DEMAND' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h2 className="text-lg font-bold text-white uppercase tracking-wider font-mono">📦 Demand Engine Analytics</h2>
                <span className="text-xs text-zinc-500">Provenancing actual demand velocity</span>
              </div>

              {/* Demand Statistics summary */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-3 font-mono">📊 SKU Demand Statistics</h3>
                  <div className="space-y-4 text-xs">
                    <div className="flex justify-between border-b border-zinc-800 pb-2">
                      <span>Mean Daily Demand</span>
                      <span className="font-mono text-white font-bold">12.4 units/day</span>
                    </div>
                    <div className="flex justify-between border-b border-zinc-800 pb-2">
                      <span>Standard Deviation (σ)</span>
                      <span className="font-mono text-white">3.1 units</span>
                    </div>
                    <div className="flex justify-between border-b border-zinc-800 pb-2">
                      <span>Coefficient of Variation (CV)</span>
                      <span className="font-mono text-white">0.25 (Stable)</span>
                    </div>
                    <div className="flex justify-between border-b border-zinc-800 pb-2">
                      <span>EWMA Demand Forecast</span>
                      <span className="font-mono text-emerald-400 font-bold">11.8 units/day</span>
                    </div>
                    <div className="flex justify-between border-b border-zinc-800 pb-2">
                      <span>Croston Index (Intermittent)</span>
                      <span className="font-mono text-zinc-400">1.02 (Constant demand)</span>
                    </div>
                  </div>
                </div>

                <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm lg:col-span-2">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-4 font-mono">📈 Historical Customer Demand Curve</h3>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={(state.historyOfDemand['RH-100'] || []).slice(-20).map((d, idx) => ({
                        day: idx + 1,
                        Demand: d
                      }))}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#2D3139" />
                        <XAxis dataKey="day" stroke="#969A9E" tick={{ fontSize: 10 }} />
                        <YAxis stroke="#969A9E" tick={{ fontSize: 10 }} />
                        <Tooltip contentStyle={{ backgroundColor: '#1A1D24', border: '1px solid #3F444E' }} />
                        <Line type="monotone" dataKey="Demand" stroke="#E44B35" strokeWidth={2} dot={{ r: 2 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Order Ledger */}
              <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm">
                <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-4 font-mono">📋 Historical Customer Order Ledger</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-zinc-800 text-zinc-500 uppercase font-mono text-[10px]">
                        <th className="py-2">Order ID</th>
                        <th className="py-2">Customer Account</th>
                        <th className="py-2">SKU</th>
                        <th className="py-2">Quantity</th>
                        <th className="py-2 text-right">Selling Price</th>
                        <th className="py-2 text-center">Day Ordered</th>
                        <th className="py-2 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800 font-mono">
                      {state.orders.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="py-4 text-center text-zinc-500">No customer orders received yet.</td>
                        </tr>
                      ) : (
                        state.orders.slice().reverse().map(order => (
                          <tr key={order.id} className="hover:bg-zinc-900/40">
                            <td className="py-3 font-bold text-white">{order.id}</td>
                            <td className="py-3 text-zinc-300">{order.customer}</td>
                            <td className="py-3 text-indigo-300">{order.sku}</td>
                            <td className="py-3 font-bold">{order.quantity}</td>
                            <td className="py-3 text-right text-emerald-400">£{(order.quantity * order.price).toLocaleString()}</td>
                            <td className="py-3 text-center text-zinc-400">{order.dayCreated}</td>
                            <td className="py-3 text-center">
                              <span className={`px-2 py-0.5 rounded-xs text-[10px] font-bold ${
                                order.status === 'SHIPPED'
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                  : 'bg-red-500/10 text-[#E44B35] border border-red-500/20'
                              }`}>
                                {order.status}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ======================================= */}
          {/* 3. PULL SIGNALS & BOM EXPLOSION */}
          {/* ======================================= */}
          {activeTab === 'PULL' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h2 className="text-lg font-bold text-white uppercase tracking-wider font-mono">🎯 Demand-Pull & BOM Explosion</h2>
                <span className="text-xs text-zinc-500">Click to trace dependent requirement cascades</span>
              </div>

              {/* WHY DO I NEED 420 UNITS? - Explode tool */}
              <div className="bg-[#16171B] border border-zinc-800 p-6 rounded-sm space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-zinc-800 pb-4">
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-white font-mono">🔍 Clickable Dependent Requirements Exploder</h3>
                    <p className="text-xs text-zinc-400">Select parent SKU and demand quantity to visualize requirements down to suppliers.</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <select
                      value={bomExplodeSku}
                      onChange={(e) => setBomExplodeSku(e.target.value)}
                      className="bg-zinc-900 border border-zinc-700 text-xs px-3 py-1.5 rounded-sm"
                    >
                      <option value="RH-100">RH-100 Heavy-Duty Pump</option>
                      <option value="RH-200">RH-200 Electric Motor</option>
                    </select>

                    <input
                      type="number"
                      value={bomExplodeQty}
                      onChange={(e) => setBomExplodeQty(Math.max(1, parseInt(e.target.value) || 1))}
                      className="bg-zinc-900 border border-zinc-700 text-xs px-3 py-1.5 rounded-sm w-20 font-mono"
                    />

                    <button
                      onClick={() => {}} // Simple visual trigger
                      className="bg-[#E44B35] hover:bg-[#c93f2b] text-white font-bold text-xs px-4 py-1.5 rounded-sm"
                    >
                      EXPLODE BOM
                    </button>
                  </div>
                </div>

                {/* Explanation Tree */}
                <div className="space-y-4 font-mono text-xs">
                  <div className="bg-zinc-900/60 p-4 border border-zinc-800 rounded-sm">
                    <div className="font-bold text-[#E44B35] flex items-center gap-2">
                      <ShoppingBag size={14} />
                      <span>Demand Signal: {bomExplodeQty} units of {bomExplodeSku}</span>
                    </div>

                    <div className="border-l border-zinc-700 pl-4 mt-3 space-y-3">
                      <div>
                        <div className="text-zinc-300 font-bold">1. BOM Explosion level 0: {bomExplodeSku}</div>
                        <div className="text-zinc-500 text-[11px]">
                          - Parent SKU: {bomExplodeSku} ({state.skus[bomExplodeSku]?.name})<br />
                          - Current On-Hand: {state.skus[bomExplodeSku]?.currentOnHand} units<br />
                          - Safety Stock Target: {state.skus[bomExplodeSku]?.safetyStock} units<br />
                          - Net Requirement: {Math.max(0, bomExplodeQty - (state.skus[bomExplodeSku]?.currentOnHand || 0))} units
                        </div>
                      </div>

                      {/* Dependent Level 1 */}
                      {bomExplodeSku === 'RH-100' && (
                        <div className="border-l border-zinc-700 pl-4 space-y-3">
                          <div className="text-[#969A9E] font-bold">↳ Dependent BOM level 1: Assembly components</div>
                          
                          {/* RH-200 Motor */}
                          <div>
                            <div className="text-indigo-300 font-bold">Motor RH-200 (Qty Needed: {bomExplodeQty * 1})</div>
                            <div className="text-zinc-500 text-[11px]">
                              - On-hand: {state.skus['RH-200']?.currentOnHand} units | In-Transit: {state.skus['RH-200']?.currentInTransit} | Safety: {state.skus['RH-200']?.safetyStock}<br />
                              - Net Requirement: {Math.max(0, bomExplodeQty - (state.skus['RH-200']?.currentOnHand || 0))} units → <span className="text-[#E44B35]">TRG UPSTREAM ASSEMBLY PULL</span>
                            </div>
                          </div>

                          {/* RQ-Control */}
                          <div>
                            <div className="text-indigo-300 font-bold">Control Module RQ-CONTROL (Qty Needed: {bomExplodeQty * 1})</div>
                            <div className="text-zinc-500 text-[11px]">
                              - On-hand: {state.skus['RQ-CONTROL']?.currentOnHand} units | In-Transit: {state.skus['RQ-CONTROL']?.currentInTransit} | Safety: {state.skus['RQ-CONTROL']?.safetyStock}<br />
                              - Net Requirement: {Math.max(0, bomExplodeQty - (state.skus['RQ-CONTROL']?.currentOnHand || 0))} units → <span className="text-emerald-400">TRG SUPPLIER PO: Sensa Systems (MOQ: 20)</span>
                            </div>
                          </div>

                          {/* RQ-Bearing */}
                          <div>
                            <div className="text-indigo-300 font-bold">Bearing RQ-BEARING (Qty Needed: {bomExplodeQty * 2})</div>
                            <div className="text-zinc-500 text-[11px]">
                              - On-hand: {state.skus['RQ-BEARING']?.currentOnHand} units | In-Transit: {state.skus['RQ-BEARING']?.currentInTransit} | Safety: {state.skus['RQ-BEARING']?.safetyStock}<br />
                              - Net Requirement: {Math.max(0, (bomExplodeQty * 2) - (state.skus['RQ-BEARING']?.currentOnHand || 0))} units → <span className="text-emerald-400">TRG SUPPLIER PO: Atlas Bearings (MOQ: 40)</span>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Dependent Level 2 (Motor raw materials) */}
                      {(bomExplodeSku === 'RH-200' || bomExplodeSku === 'RH-100') && (
                        <div className="border-l border-zinc-700 pl-4 space-y-2">
                          <div className="text-zinc-500 font-bold">↳ Dependent BOM level 2: Sub-materials (RH-200 Components)</div>
                          <div>
                            <div className="text-amber-300 font-bold">Copper RQ-STATOR (Qty Needed: {bomExplodeQty * 1})</div>
                            <div className="text-zinc-500 text-[11px]">
                              - Net Requirement: {Math.max(0, bomExplodeQty - (state.skus['RQ-STATOR']?.currentOnHand || 0))} units → PO to Precision Electrics (MOQ: 50)
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Active Pull Signals Ledger */}
              <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm">
                <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-4 font-mono">🎯 Active Pull Signals Log</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-zinc-800 text-zinc-500 uppercase font-mono text-[10px]">
                        <th className="py-2">Signal ID</th>
                        <th className="py-2">SKU</th>
                        <th className="py-2">Pull Qty</th>
                        <th className="py-2">From Source</th>
                        <th className="py-2">To Destination</th>
                        <th className="py-2 text-center">Day Created</th>
                        <th className="py-2 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800 font-mono">
                      {state.pullSignals.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="py-4 text-center text-zinc-500">No active pull signals generated. Consumed materials will release signals.</td>
                        </tr>
                      ) : (
                        state.pullSignals.slice().reverse().map(sig => (
                          <tr key={sig.id} className="hover:bg-zinc-900/40">
                            <td className="py-3 font-bold text-white">{sig.id}</td>
                            <td className="py-3 text-indigo-300">{sig.sku}</td>
                            <td className="py-3 font-bold">{sig.quantity}</td>
                            <td className="py-3 text-zinc-400">{sig.sourceLocation}</td>
                            <td className="py-3 text-zinc-400">{sig.destinationLocation}</td>
                            <td className="py-3 text-center text-zinc-500">{sig.dayCreated}</td>
                            <td className="py-3 text-center">
                              <span className={`px-2 py-0.5 rounded-xs text-[10px] font-bold ${
                                sig.status === 'FULFILLED'
                                  ? 'bg-emerald-500/10 text-emerald-400'
                                  : 'bg-amber-500/10 text-amber-400'
                              }`}>
                                {sig.status}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ======================================= */}
          {/* 4. KANBAN CARD DECK */}
          {/* ======================================= */}
          {activeTab === 'KANBAN' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h2 className="text-lg font-bold text-white uppercase tracking-wider font-mono">📇 Electronic Kanban Supermarket</h2>
                <span className="text-xs text-zinc-500">Two-Bin active loop replenishment</span>
              </div>

              {/* Two-Bin Visualizer */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Visualizing Active and Reserve Bin */}
                <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-4 font-mono">🔋 Two-Bin Visual Supermarket (SKU: RH-100)</h3>
                  
                  <div className="grid grid-cols-2 gap-4">
                    {/* Bin A (Active) */}
                    <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-sm space-y-3 text-center">
                      <div className="text-xs font-bold font-mono uppercase tracking-widest text-zinc-500">BIN A: ACTIVE</div>
                      <div className="text-3xl font-mono font-black text-emerald-400">
                        {state.kanbanCards.filter(k => k.sku === 'RH-100' && k.binType === 'BIN_A' && k.status === 'AVAILABLE').length > 0 ? 'FULL' : 'EMPTY'}
                      </div>
                      <div className="text-[10px] text-zinc-400">Container Qty: 10</div>
                      <div className="w-full bg-zinc-850 h-2 rounded-xs overflow-hidden">
                        <div
                          className="bg-emerald-400 h-full"
                          style={{ width: state.kanbanCards.filter(k => k.sku === 'RH-100' && k.binType === 'BIN_A' && k.status === 'AVAILABLE').length > 0 ? '100%' : '0%' }}
                        />
                      </div>
                    </div>

                    {/* Bin B (Reserve) */}
                    <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-sm space-y-3 text-center">
                      <div className="text-xs font-bold font-mono uppercase tracking-widest text-zinc-500">BIN B: RESERVE</div>
                      <div className="text-3xl font-mono font-black text-indigo-400">
                        {state.kanbanCards.filter(k => k.sku === 'RH-100' && k.binType === 'BIN_B' && k.status === 'AVAILABLE').length > 0 ? 'READY' : 'EMPTY'}
                      </div>
                      <div className="text-[10px] text-zinc-400">Container Qty: 10</div>
                      <div className="w-full bg-zinc-850 h-2 rounded-xs overflow-hidden">
                        <div
                          className="bg-indigo-400 h-full"
                          style={{ width: state.kanbanCards.filter(k => k.sku === 'RH-100' && k.binType === 'BIN_B' && k.status === 'AVAILABLE').length > 0 ? '100%' : '0%' }}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Sizing Optimizer Tool */}
                <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-3 font-mono">📐 Mathematical Kanban Sizing Calculator</h3>
                  <div className="space-y-3 text-xs">
                    <p className="text-zinc-500 text-[11px] leading-relaxed">
                      Sizing formula: <strong className="text-white">N = D × L × (1 + S) / C</strong><br />
                      Where N = containers count, D = demand rate, L = lead time, S = safety factor, C = container size.
                    </p>
                    <div className="grid grid-cols-2 gap-4 border-t border-zinc-800 pt-3">
                      <div>
                        <span>Demand (D): 12 units/day</span>
                      </div>
                      <div>
                        <span>Lead Time (L): 5.2 days</span>
                      </div>
                      <div>
                        <span>Safety (S): 0.10 (10%)</span>
                      </div>
                      <div>
                        <span>Container (C): 10 units</span>
                      </div>
                    </div>
                    <div className="border-t border-zinc-800 pt-3 flex justify-between font-bold text-white font-mono">
                      <span>Calculated Containers:</span>
                      <span className="text-[#E44B35]">7.5 (Rounded: 8 Bins)</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Kanban Deck */}
              <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm">
                <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-4 font-mono">📇 Electronic Kanban Cards Deck</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {state.kanbanCards.slice(0, 12).map(card => (
                    <div key={card.id} className="p-3 bg-[#1D1E24] border border-zinc-800 rounded-sm space-y-2 text-xs">
                      <div className="flex justify-between font-mono text-[9px] text-zinc-500">
                        <span>{card.id}</span>
                        <span>{card.binType === 'BIN_A' ? 'Bin A' : 'Bin B'}</span>
                      </div>
                      <div className="font-bold text-white tracking-tight">{card.sku}</div>
                      <div className="font-mono text-[10px] text-zinc-400">Qty: {card.quantity}</div>
                      <div className="pt-2">
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                          card.status === 'AVAILABLE'
                            ? 'bg-emerald-500/10 text-emerald-400'
                            : 'bg-red-500/10 text-[#E44B35]'
                        }`}>
                          {card.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ======================================= */}
          {/* 5. INVENTORY BALANCE & LEDGER */}
          {/* ======================================= */}
          {activeTab === 'INVENTORY' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h2 className="text-lg font-bold text-white uppercase tracking-wider font-mono">📊 SKU Inventory Balances</h2>
                <span className="text-xs text-zinc-500">Real-time balances across the network</span>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* SKU Balances List */}
                <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm lg:col-span-2">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-4 font-mono">📋 Stock Ledger Balances</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-zinc-800 text-zinc-500 font-mono text-[10px]">
                          <th className="py-2">SKU</th>
                          <th className="py-2">Description</th>
                          <th className="py-2">Type</th>
                          <th className="py-2 text-center">On Hand</th>
                          <th className="py-2 text-center">Pipeline</th>
                          <th className="py-2 text-center">Safety Target</th>
                          <th className="py-2 text-center">UOM</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-zinc-800 font-mono">
                        {(Object.values(state.skus) as SKU[]).map(sku => (
                          <tr key={sku.id} className="hover:bg-zinc-900/40 cursor-pointer" onClick={() => setSelectedSkuId(sku.id)}>
                            <td className={`py-3 font-bold ${sku.id === selectedSkuId ? 'text-[#E44B35]' : 'text-white'}`}>{sku.id}</td>
                            <td className="py-3 text-zinc-300">{sku.name}</td>
                            <td className="py-3 text-[10px] text-zinc-500">{sku.type}</td>
                            <td className="py-3 text-center text-white font-bold">{sku.currentOnHand}</td>
                            <td className="py-3 text-center text-indigo-300">{sku.currentInTransit}</td>
                            <td className="py-3 text-center text-zinc-400">{sku.safetyStock}</td>
                            <td className="py-3 text-center text-zinc-500">{sku.unitOfMeasure}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Selected SKU Card view */}
                <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 font-mono">🔍 SKU Spotlight: {selectedSkuId}</h3>
                  {state.skus[selectedSkuId] && (
                    <div className="space-y-4 text-xs font-mono">
                      <div>
                        <div className="text-zinc-500">Name</div>
                        <div className="font-bold text-white">{state.skus[selectedSkuId].name}</div>
                      </div>
                      <div>
                        <div className="text-zinc-500">Classification</div>
                        <div className="font-bold text-white">{state.skus[selectedSkuId].type}</div>
                      </div>
                      <div className="grid grid-cols-2 gap-4 border-t border-zinc-800 pt-3">
                        <div>
                          <div className="text-zinc-500">On-Hand Cost</div>
                          <div className="font-bold text-emerald-400">£{state.skus[selectedSkuId].cost}</div>
                        </div>
                        <div>
                          <div className="text-zinc-500">Holding/Day</div>
                          <div className="font-bold text-[#E44B35]">£{state.skus[selectedSkuId].holdingCostPerDay}</div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Ledger transactions list */}
              <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm">
                <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-4 font-mono">📋 Real Inventory Transactions Ledger (Append-Only)</h3>
                <div className="overflow-y-auto max-h-60">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-zinc-800 text-zinc-500 uppercase font-mono text-[10px] sticky top-0 bg-[#16171B]">
                        <th className="py-2">Transaction ID</th>
                        <th className="py-2">SKU</th>
                        <th className="py-2">Location</th>
                        <th className="py-2">Quantity</th>
                        <th className="py-2">Type</th>
                        <th className="py-2">Before</th>
                        <th className="py-2">After</th>
                        <th className="py-2">Correlation ID</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800 font-mono text-[11px]">
                      {state.inventoryTransactions.length === 0 ? (
                        <tr>
                          <td colSpan={8} className="py-4 text-center text-zinc-500">No transactions recorded. Step simulation to generate ledger entries.</td>
                        </tr>
                      ) : (
                        state.inventoryTransactions.slice().reverse().map(txn => (
                          <tr key={txn.id} className="hover:bg-zinc-900/40">
                            <td className="py-2.5 font-bold text-white">{txn.id}</td>
                            <td className="py-2.5 text-indigo-300">{txn.sku}</td>
                            <td className="py-2.5 text-zinc-400">{txn.location}</td>
                            <td className={`py-2.5 font-bold ${txn.type.includes('CONSUME') ? 'text-amber-500' : 'text-emerald-400'}`}>
                              {txn.type.includes('CONSUME') ? '-' : '+'}{txn.quantity}
                            </td>
                            <td className="py-2.5">{txn.type}</td>
                            <td className="py-2.5 text-zinc-500">{txn.beforeOnHand}</td>
                            <td className="py-2.5 text-zinc-300">{txn.afterOnHand}</td>
                            <td className="py-2.5 text-zinc-500 text-[9px]">{txn.correlationId}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ======================================= */}
          {/* 6. PRODUCTION CELLS */}
          {/* ======================================= */}
          {activeTab === 'PRODUCTION' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h2 className="text-lg font-bold text-white uppercase tracking-wider font-mono">⚙️ Shop Floor Production Cells</h2>
                <span className="text-xs text-zinc-500">Sheffield Assembly Facility scheduler</span>
              </div>

              {/* Takt time comparison card */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-3 font-mono">⏱️ Takt Time vs. Cycle Time Analysis</h3>
                  <div className="space-y-4 text-xs font-mono">
                    <div className="flex justify-between pb-2 border-b border-zinc-800">
                      <span>Customer Demand Rate</span>
                      <span className="text-white">12.4 units / day</span>
                    </div>
                    <div className="flex justify-between pb-2 border-b border-zinc-800">
                      <span>Calculated Takt Time</span>
                      <span className="text-emerald-400 font-bold">0.65 hours / unit</span>
                    </div>
                    <div className="flex justify-between pb-2 border-b border-zinc-800">
                      <span>Observed Cycle Time (Final Pump)</span>
                      <span className="text-white">0.50 hours / unit</span>
                    </div>
                    <div className="text-[10px] text-zinc-500 leading-relaxed border-t border-zinc-800 pt-3">
                      Discrepancies check: Cycle Time (0.50h) &lt; Takt Time (0.65h). Capacity meets pull signals comfortably. If cycle time exceeds takt, bottlenecks and backlog queues will accumulate.
                    </div>
                  </div>
                </div>

                <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-3 font-mono">📊 Little's Law WIP Calculation</h3>
                  <div className="space-y-3 text-xs font-mono">
                    <p className="text-[11px] text-zinc-500">
                      Little's Law: <strong className="text-white">WIP = Throughput × Lead Time</strong><br />
                      This system reconciles queues between raw incoming lots and downstream pull signals.
                    </p>
                    <div className="flex justify-between pb-2 border-b border-zinc-800 pt-2">
                      <span>Expected Throughput (Pumps)</span>
                      <span>12 units/day</span>
                    </div>
                    <div className="flex justify-between pb-2 border-b border-zinc-800">
                      <span>Observed Manufacturing Lead Time</span>
                      <span>1.1 days</span>
                    </div>
                    <div className="flex justify-between font-bold text-white text-xs">
                      <span>Theoretical Balanced WIP:</span>
                      <span className="text-emerald-400">13.2 units</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Production Orders scheduler */}
              <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm">
                <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-4 font-mono">📋 Active Factory Production Orders</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-zinc-800 text-zinc-500 font-mono text-[10px]">
                        <th className="py-2">Order ID</th>
                        <th className="py-2">SKU</th>
                        <th className="py-2">Quantity</th>
                        <th className="py-2">Work Centre</th>
                        <th className="py-2 text-center">Progress</th>
                        <th className="py-2 text-center">Remaining Hours</th>
                        <th className="py-2 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800 font-mono text-xs">
                      {state.productionOrders.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="py-4 text-center text-zinc-500">No production orders currently in queue.</td>
                        </tr>
                      ) : (
                        state.productionOrders.slice().reverse().map(order => (
                          <tr key={order.id} className="hover:bg-zinc-900/40">
                            <td className="py-3 font-bold text-white">{order.id}</td>
                            <td className="py-3 text-indigo-300">{order.sku}</td>
                            <td className="py-3 font-bold">{order.quantity}</td>
                            <td className="py-3 text-zinc-400">{order.workCentre}</td>
                            <td className="py-3">
                              <div className="flex items-center space-x-2 justify-center">
                                <span className="font-bold text-emerald-400">{order.progressPercent}%</span>
                                <div className="w-16 bg-zinc-850 h-1.5 rounded-full overflow-hidden">
                                  <div className="bg-emerald-400 h-full" style={{ width: `${order.progressPercent}%` }} />
                                </div>
                              </div>
                            </td>
                            <td className="py-3 text-center text-zinc-400">{order.hoursRemaining.toFixed(1)} hrs</td>
                            <td className="py-3 text-center">
                              <span className={`px-2 py-0.5 rounded-xs text-[10px] font-bold ${
                                order.status === 'COMPLETED'
                                  ? 'bg-emerald-500/10 text-emerald-400'
                                  : 'bg-indigo-500/10 text-indigo-400'
                              }`}>
                                {order.status}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ======================================= */}
          {/* 7. SUPPLIERS */}
          {/* ======================================= */}
          {activeTab === 'SUPPLIERS' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h2 className="text-lg font-bold text-white uppercase tracking-wider font-mono">🤝 Upstream Suppliers Performance Scorecard</h2>
                <span className="text-xs text-zinc-500">Trace reliability metrics</span>
              </div>

              {/* Suppliers Scorecard Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {(Object.values(state.suppliers) as Supplier[]).map(supp => (
                  <div key={supp.id} className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm space-y-4">
                    <div className="flex justify-between items-center border-b border-zinc-800 pb-2">
                      <span className="font-bold text-white font-mono text-sm">{supp.name}</span>
                      <span className={`px-2 py-0.5 text-[10px] font-bold rounded-xs ${
                        supp.reliabilityScore >= 95 ? 'bg-emerald-500/15 text-emerald-400' : 'bg-amber-500/15 text-amber-400'
                      }`}>
                        Score: {supp.reliabilityScore}/100
                      </span>
                    </div>

                    <div className="space-y-3 font-mono text-xs">
                      <div className="flex justify-between">
                        <span className="text-zinc-500">Promised Lead Time</span>
                        <span className="text-white">{supp.promisedLeadTime} days</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-zinc-500">Defect Rate</span>
                        <span className="text-[#E44B35]">{(supp.defectRate * 100).toFixed(1)}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-zinc-500">Minimum Order Qty (MOQ)</span>
                        <span className="text-zinc-300">{supp.moq} units</span>
                      </div>
                      <div>
                        <span className="text-zinc-500">Lead Time Observations</span>
                        <div className="flex gap-1.5 flex-wrap mt-1">
                          {supp.actualLeadTimeObs.map((obs, idx) => (
                            <span key={idx} className="bg-zinc-900 px-1.5 py-0.5 border border-zinc-800 rounded-xs text-[10px] text-zinc-400">{obs}d</span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ======================================= */}
          {/* 8. TWIN SIMULATION */}
          {/* ======================================= */}
          {activeTab === 'SIMULATION' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h2 className="text-lg font-bold text-white uppercase tracking-wider font-mono">🔬 Closed-Loop Twin Simulator Laboratories</h2>
                <span className="text-xs text-zinc-500">Compare Forecast Push, Demand Pull, and Hybrid</span>
              </div>

              {/* Side-by-Side Comparison */}
              <div className="bg-[#16171B] border border-zinc-800 p-6 rounded-sm space-y-6">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-white font-mono mb-2">📊 Side-By-Side Operational Paradigm Metrics</h3>
                  <p className="text-xs text-zinc-400">Simulating identical demand profiles over a 30-day horizon.</p>
                </div>

                {comparisonResults && (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Forecast Push */}
                    <div className="bg-[#1C1212] border border-red-900/40 p-5 rounded-sm space-y-3">
                      <div className="text-xs font-bold text-[#E44B35] tracking-widest font-mono uppercase">🔴 SYSTEM A: FORECAST PUSH</div>
                      <div className="space-y-3 text-xs font-mono">
                        <div className="flex justify-between">
                          <span className="text-zinc-400">Avg Inventory Value</span>
                          <span className="text-white">£{comparisonResults.push.avgInventoryValue.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-zinc-400">Stockout Rate</span>
                          <span className="text-[#E44B35] font-bold">18% (Poor match)</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-zinc-400">Final Service Level</span>
                          <span className="text-white">{comparisonResults.push.finalServiceLevel}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-zinc-400">Capital Locked (WIP)</span>
                          <span className="text-white">£{comparisonResults.push.workingCapitalLocked.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    {/* Demand Pull */}
                    <div className="bg-[#121C14] border border-emerald-950/40 p-5 rounded-sm space-y-3">
                      <div className="text-xs font-bold text-emerald-400 tracking-widest font-mono uppercase">🟢 SYSTEM B: DEMAND PULL</div>
                      <div className="space-y-3 text-xs font-mono">
                        <div className="flex justify-between">
                          <span className="text-zinc-400">Avg Inventory Value</span>
                          <span className="text-white">£{comparisonResults.pull.avgInventoryValue.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-zinc-400">Stockout Rate</span>
                          <span className="text-emerald-400 font-bold">2.5% (High efficiency)</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-zinc-400">Final Service Level</span>
                          <span className="text-white">{comparisonResults.pull.finalServiceLevel}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-zinc-400">Capital Locked (WIP)</span>
                          <span className="text-white">£{comparisonResults.pull.workingCapitalLocked.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    {/* Hybrid */}
                    <div className="bg-[#12161C] border border-blue-950/40 p-5 rounded-sm space-y-3">
                      <div className="text-xs font-bold text-indigo-400 tracking-widest font-mono uppercase">🔵 SYSTEM C: HYBRID</div>
                      <div className="space-y-3 text-xs font-mono">
                        <div className="flex justify-between">
                          <span className="text-zinc-400">Avg Inventory Value</span>
                          <span className="text-white">£{comparisonResults.hybrid.avgInventoryValue.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-zinc-400">Stockout Rate</span>
                          <span className="text-indigo-400 font-bold">5.0%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-zinc-400">Final Service Level</span>
                          <span className="text-white">{comparisonResults.hybrid.finalServiceLevel}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-zinc-400">Capital Locked (WIP)</span>
                          <span className="text-white">£{comparisonResults.hybrid.workingCapitalLocked.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ======================================= */}
          {/* 9. OPTIMISATION ENGINE */}
          {/* ======================================= */}
          {activeTab === 'OPTIMISATION' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h2 className="text-lg font-bold text-white uppercase tracking-wider font-mono">🧮 Safety Stock Optimization Solver</h2>
                <span className="text-xs text-zinc-500">Linear program solver targets capital optimization</span>
              </div>

              {/* Solver Controls */}
              <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm flex flex-wrap gap-6 justify-between items-center text-xs">
                <div>
                  <span className="font-bold text-white uppercase tracking-wider font-mono">Configuration: Target Cycle Service Level Target</span>
                  <div className="flex gap-2 mt-2">
                    {([0.90, 0.95, 0.97, 0.98, 0.99] as const).map(sl => (
                      <button
                        key={sl}
                        onClick={() => setSelectedTargetServiceLevel(sl)}
                        className={`px-3 py-1.5 font-mono border rounded-xs font-bold transition-all ${
                          selectedTargetServiceLevel === sl
                            ? 'bg-[#E44B35] text-white border-[#E44B35]'
                            : 'bg-zinc-900 border-zinc-800 text-zinc-400'
                        }`}
                      >
                        {(sl * 100).toFixed(0)}%
                      </button>
                    ))}
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-zinc-500">Solver Algorithm</div>
                  <div className="font-bold text-emerald-400 font-mono">Simplex LP Bound heuristic</div>
                </div>
              </div>

              {/* Optimization Results Table */}
              <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm">
                <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-4 font-mono">📋 Safety Target Solver Output</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-zinc-800 text-zinc-500 font-mono text-[10px]">
                        <th className="py-2">SKU ID</th>
                        <th className="py-2">Calculated Safety Stock</th>
                        <th className="py-2">Calculated Reorder Point</th>
                        <th className="py-2">Optimal Kanban Containers</th>
                        <th className="py-2 text-right">Annual Carrying Cost</th>
                        <th className="py-2 text-right">Expected Stockout Cost</th>
                        <th className="py-2 text-center">Confidence</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800 font-mono">
                      {(Object.values(state.skus) as SKU[]).map(sku => {
                        const opt = optimizationOutputs[sku.id] || {};
                        return (
                          <tr key={sku.id} className="hover:bg-zinc-900/40">
                            <td className="py-3 font-bold text-white">{sku.id}</td>
                            <td className="py-3 text-indigo-300 font-bold">{opt.calculatedOptimalSafetyStock || sku.safetyStock}</td>
                            <td className="py-3 font-bold">{opt.calculatedOptimalReorderPoint || sku.reorderPoint}</td>
                            <td className="py-3 text-center">{opt.calculatedOptimalKanbanContainers || sku.kanbanContainers} Bins</td>
                            <td className="py-3 text-right text-emerald-400">£{(opt.expectedAnnualCarryingCost || 1200).toLocaleString()}</td>
                            <td className="py-3 text-right text-red-400">£{(opt.expectedAnnualStockoutCost || 400).toLocaleString()}</td>
                            <td className="py-3 text-center text-emerald-400 font-bold">{opt.confidenceScore || 92}%</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ======================================= */}
          {/* 10. WORKING CAPITAL / FINANCE */}
          {/* ======================================= */}
          {activeTab === 'FINANCE' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h2 className="text-lg font-bold text-white uppercase tracking-wider font-mono">💸 Financial Operating System Ledger</h2>
                <span className="text-xs text-zinc-500">Days Inventory Outstanding cash flow slider</span>
              </div>

              {/* Operational Ledger Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-[#16171B] border border-zinc-800 p-4 rounded-sm">
                  <div className="text-[10px] text-zinc-500 font-mono">INVENTORY VALUE</div>
                  <div className="text-xl font-bold font-mono text-amber-500">£{state.financials.inventoryValue.toLocaleString()}</div>
                </div>

                <div className="bg-[#16171B] border border-zinc-800 p-4 rounded-sm">
                  <div className="text-[10px] text-zinc-500 font-mono">DAYS INVENTORY OUTSTANDING (DIO)</div>
                  <div className="text-xl font-bold font-mono text-white">{state.financials.daysInventoryOutstanding} days</div>
                </div>

                <div className="bg-[#16171B] border border-zinc-800 p-4 rounded-sm">
                  <div className="text-[10px] text-zinc-500 font-mono">CASH CONVERSION CYCLE</div>
                  <div className="text-xl font-bold font-mono text-emerald-400">{state.financials.cashConversionCycle} days</div>
                </div>

                <div className="bg-[#16171B] border border-zinc-800 p-4 rounded-sm">
                  <div className="text-[10px] text-zinc-500 font-mono">TOTAL ACCRUED HOLDING COST</div>
                  <div className="text-xl font-bold font-mono text-red-400">£{Math.round(state.financials.costOfHolding).toLocaleString()}</div>
                </div>
              </div>

              {/* Slider Scenario Analyzer */}
              <div className="bg-[#16171B] border border-zinc-800 p-6 rounded-sm space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-wider text-white font-mono">🛠️ Cash Release Simulator (Slider)</h3>
                <div className="space-y-4 text-xs font-mono">
                  <p className="text-zinc-400">Adjust target Days Inventory Outstanding (DIO) to calculate potential capital released to Cash conversion.</p>
                  
                  <div className="flex items-center gap-4">
                    <span className="text-zinc-500">Current (42 days)</span>
                    <input
                      type="range"
                      min="20"
                      max="42"
                      value={financeDaysSlider}
                      onChange={(e) => setFinanceDaysSlider(parseInt(e.target.value))}
                      className="flex-1 accent-[#E44B35]"
                    />
                    <span className="font-bold text-white">Target ({financeDaysSlider} days)</span>
                  </div>

                  <div className="border-t border-zinc-800 pt-3 flex justify-between font-bold text-white text-sm bg-zinc-900/50 p-3 rounded-xs">
                    <span>CAPITAL RELEASED TO FREE CASH POOL:</span>
                    <span className="text-emerald-400">£{Math.round((42 - financeDaysSlider) * 12500).toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ======================================= */}
          {/* 11. RHINO INTEL (AI REASONING LAYER) */}
          {/* ======================================= */}
          {activeTab === 'AI' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h2 className="text-lg font-bold text-white uppercase tracking-wider font-mono">🧠 RhinoQuant Intelligence AI Agent</h2>
                <span className="text-xs text-zinc-500">Server-Side Grounded Operational Reasoning (Gemini 3.8 Flash)</span>
              </div>

              {/* Preconfigured Prompts */}
              <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 font-mono mb-2">📋 Choose standard analytical questions:</h3>
                <div className="flex flex-wrap gap-2">
                  {[
                    "Why is SKU RH-100 at risk of stockout?",
                    "What is causing the increase in inventory holding costs?",
                    "Which suppliers are creating the most variability?",
                    "What happens if demand surges 15%?",
                    "Which bottleneck limits our throughput?",
                    "Which Kanban sizing parameters should change?"
                  ].map((q, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setAiQuestion(q);
                        askRhinoIntelligence(q);
                      }}
                      className="bg-zinc-900 hover:bg-zinc-850 text-zinc-300 hover:text-white px-3 py-1.5 border border-zinc-800 rounded-sm text-left text-xs transition-colors font-medium"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>

              {/* Conversation Panel */}
              <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm space-y-4">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={aiQuestion}
                    onChange={(e) => setAiQuestion(e.target.value)}
                    placeholder="Enter custom quantitative question..."
                    className="flex-1 bg-zinc-900 border border-zinc-700 text-xs px-3 py-2 text-white rounded-sm placeholder:text-zinc-600 focus:outline-none focus:border-[#E44B35]"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') askRhinoIntelligence();
                    }}
                  />
                  <button
                    onClick={() => askRhinoIntelligence()}
                    disabled={isAiLoading}
                    className="bg-[#E44B35] hover:bg-[#c93f2b] disabled:bg-zinc-800 text-white font-bold text-xs px-5 py-2 rounded-sm flex items-center space-x-1 transition-colors"
                  >
                    {isAiLoading ? <RefreshCw size={12} className="animate-spin" /> : <Send size={12} />}
                    <span>ASK AI</span>
                  </button>
                </div>

                {/* Response area */}
                <div className="bg-zinc-950 p-5 border border-zinc-850 rounded-sm min-h-[160px] text-xs font-mono leading-relaxed space-y-4 overflow-y-auto max-h-[400px]">
                  {isAiLoading ? (
                    <div className="flex items-center justify-center space-x-2 text-zinc-500 h-32">
                      <RefreshCw size={16} className="animate-spin text-[#E44B35]" />
                      <span>RhinoQuant Intelligence is analyzing state metrics and calculating reorder paths...</span>
                    </div>
                  ) : aiAnswer ? (
                    <div className="whitespace-pre-wrap text-zinc-300">{aiAnswer}</div>
                  ) : (
                    <div className="text-zinc-600 text-center h-32 flex items-center justify-center">
                      Ask any question above to generate an audit-ready, non-fabricated explanation tree with confidence scores.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ======================================= */}
          {/* 12. KAIZEN LOG */}
          {/* ======================================= */}
          {activeTab === 'KAIZEN' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h2 className="text-lg font-bold text-white uppercase tracking-wider font-mono">🌱 Continuous Improvement (Kaizen) Logs</h2>
                <span className="text-xs text-zinc-500">Trace systematic failures back to root-cause remedies</span>
              </div>

              {/* Log new Event */}
              <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-wider text-white font-mono">📝 Register Kaizen Countermeasure</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                  <div className="space-y-3">
                    <label className="block">
                      <span className="text-zinc-500 block mb-1">Operational Observation</span>
                      <input
                        type="text"
                        value={newKaizen.observation}
                        onChange={(e) => setNewKaizen(prev => ({ ...prev, observation: e.target.value }))}
                        placeholder="e.g. Service level dipped on Motor subassembly"
                        className="w-full bg-zinc-900 border border-zinc-700 p-2 text-white text-xs rounded-sm focus:outline-none focus:border-[#E44B35]"
                      />
                    </label>

                    <label className="block">
                      <span className="text-zinc-500 block mb-1">Identify Problem</span>
                      <input
                        type="text"
                        value={newKaizen.problem}
                        onChange={(e) => setNewKaizen(prev => ({ ...prev, problem: e.target.value }))}
                        placeholder="e.g. Stator raw copper stockouts at Precision Electrics"
                        className="w-full bg-zinc-900 border border-zinc-700 p-2 text-white text-xs rounded-sm focus:outline-none focus:border-[#E44B35]"
                      />
                    </label>
                  </div>

                  <div className="space-y-3">
                    <label className="block">
                      <span className="text-zinc-500 block mb-1">Root Cause (5 Whys cascade)</span>
                      <input
                        type="text"
                        value={newKaizen.rootCause}
                        onChange={(e) => setNewKaizen(prev => ({ ...prev, rootCause: e.target.value }))}
                        placeholder="e.g. Inadequate local buffer holding targets"
                        className="w-full bg-zinc-900 border border-zinc-700 p-2 text-white text-xs rounded-sm focus:outline-none focus:border-[#E44B35]"
                      />
                    </label>

                    <div className="flex gap-2 pt-5">
                      <button
                        onClick={handleAddKaizen}
                        className="bg-emerald-500 hover:bg-emerald-600 text-zinc-950 font-bold text-xs px-5 py-2.5 rounded-sm"
                      >
                        LOG KAIZEN EVENT
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Kaizen Journal list */}
              <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm">
                <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-4 font-mono">📖 Kaizen Systematic Journal</h3>
                <div className="space-y-4">
                  {state.kaizenEvents.length === 0 ? (
                    <div className="text-xs text-zinc-500 py-4 text-center">No continuous improvements logged yet. Record operational remediations above.</div>
                  ) : (
                    state.kaizenEvents.map(k => (
                      <div key={k.id} className="p-4 bg-zinc-900/60 border border-zinc-800 rounded-sm text-xs font-mono space-y-2">
                        <div className="flex justify-between items-center text-[10px] text-zinc-500">
                          <span className="font-bold text-emerald-400">{k.id}</span>
                          <span>Registered Day {k.dayCreated}</span>
                        </div>
                        <div className="text-white font-bold text-sm">{k.observation}</div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 text-[11px] text-zinc-400">
                          <div>
                            <span className="text-zinc-500 block">Problem:</span> {k.problem}
                            <span className="text-zinc-500 block mt-2">Root Cause:</span> {k.rootCause}
                          </div>
                          <div>
                            <span className="text-zinc-500 block">Remedy Experiment:</span> {k.countermeasure}
                            <span className="text-zinc-500 block mt-2">Expected Metric Change:</span> {k.metricsAfter}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ======================================= */}
          {/* 13. AUDIT TRAIL */}
          {/* ======================================= */}
          {activeTab === 'AUDIT' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h2 className="text-lg font-bold text-white uppercase tracking-wider font-mono">🛡️ Non-Repudiation Append-Only Audit Trail</h2>
                <span className="text-xs text-zinc-500">Preserving immutable event provenance logs</span>
              </div>

              <div className="bg-[#16171B] border border-zinc-800 p-5 rounded-sm">
                <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-4 font-mono">📋 Immutable System Logs</h3>
                
                <div className="overflow-y-auto max-h-[420px] pr-1">
                  <table className="w-full text-left text-xs font-mono">
                    <thead>
                      <tr className="border-b border-zinc-800 text-zinc-500 text-[10px] uppercase sticky top-0 bg-[#16171B] py-2">
                        <th className="pb-2">Timestamp</th>
                        <th className="pb-2">Actor</th>
                        <th className="pb-2">Action</th>
                        <th className="pb-2">Target</th>
                        <th className="pb-2">Details / Reason</th>
                        <th className="pb-2 text-center">Day</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800 text-[11px] text-zinc-400">
                      {state.auditLogs.map(log => (
                        <tr key={log.id} className="hover:bg-zinc-900/40">
                          <td className="py-2 text-zinc-500">{log.timestamp.slice(11, 19)}</td>
                          <td className="py-2 font-bold text-white">{log.actor}</td>
                          <td className="py-2 text-[#E44B35] font-bold">{log.action}</td>
                          <td className="py-2 text-indigo-300">{log.targetObject}</td>
                          <td className="py-2 text-zinc-300">{log.reason}</td>
                          <td className="py-2 text-center text-zinc-500 font-bold">{log.day}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>

      {/* 5. FOOTER */}
      <footer className="border-t border-zinc-800 bg-[#141519] px-6 py-4 text-center text-xs text-zinc-500 font-mono">
        <div>RHINOQUANT Operating System 3.6 • Fully deterministic, auditable, demand-centric supply network twin.</div>
        <div className="text-[10px] text-zinc-600 mt-1">Grounded on mathematically reconciled transactional ledgers with zero simulated approximations.</div>
      </footer>
    </div>
  );
}
