import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';
import { GoogleGenAI } from "@google/genai";

export default defineConfig(() => {
  return {
    plugins: [
      react(), 
      tailwindcss(),
      {
        name: 'api-server',
        configureServer(server) {
          server.middlewares.use('/api/gemini/analyze', (req, res, next) => {
            if (req.method !== 'POST') {
              res.writeHead(405, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ error: 'Method Not Allowed' }));
              return;
            }

            let body = '';
            req.on('data', chunk => { body += chunk; });
            req.on('end', async () => {
              try {
                const { prompt, stateContext } = JSON.parse(body);

                const apiKey = process.env.GEMINI_API_KEY;
                if (!apiKey) {
                  res.writeHead(400, { 'Content-Type': 'application/json' });
                  res.end(JSON.stringify({ 
                    error: 'Gemini API Key is missing. Please add GEMINI_API_KEY in Settings > Secrets.' 
                  }));
                  return;
                }

                const ai = new GoogleGenAI({
                  apiKey: apiKey,
                  httpOptions: {
                    headers: {
                      'User-Agent': 'aistudio-build',
                    }
                  }
                });

                const systemPrompt = `You are RhinoQuant Intelligence, the principal quantitative operational reasoning engine of the RHINO PULL operating system.
You are analyzing active simulation state data for RHINOQUANT INDUSTRIAL SYSTEMS LTD.

The user is asking: "${prompt}"

Current Simulation Context:
- Day: ${stateContext?.day || 1}
- SKUs On-Hand Balance:
${JSON.stringify(stateContext?.skus || {}, null, 2)}
- Active Alerts:
${JSON.stringify(stateContext?.alerts || [], null, 2)}
- Financial State:
${JSON.stringify(stateContext?.financials || {}, null, 2)}

Strict Guidelines:
1. Do not fabricate or invent quantitative results. Rely only on the provided context.
2. Output your response as a professional industrial audit report.
3. Your response MUST include the following structured sections:
   - **DATA SOURCES**: List the SKUs, locations, or balances used in this calculation.
   - **CALCULATIONS**: Detail the mathematical math applied (e.g., Net Requirement = Gross - OnHand - InTransit + SafetyStock).
   - **ASSUMPTIONS**: Detail any lead times, standard lot sizes, or variances assumed.
   - **TIME PERIOD**: The exact day range this context represents.
   - **CONFIDENCE**: A quantitative percentage reflecting confidence in the data.
   - **RECOMMENDATION**: A clear, actionable procurement or production recommendation tree (e.g., RECOMMEND BUY X units because...).

Always speak in a calm, precise, and highly quantitative industrial tone. Avoid flowery corporate language.`;

                const response = await ai.models.generateContent({
                  model: "gemini-3.8-flash",
                  contents: systemPrompt,
                });

                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ response: response.text || "No response generated." }));
              } catch (err: any) {
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: err?.message || 'Internal Server Error' }));
              }
            });
          });
        }
      }
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
